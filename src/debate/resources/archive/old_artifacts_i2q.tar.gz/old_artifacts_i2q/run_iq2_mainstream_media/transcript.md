# Debate Transcript

Topic: Good Riddance To Mainstream Media
Motion: Good Riddance To Mainstream Media

Debate ID: mainstream-media


## Round 1

### Moderator
Claim: Good evening, everyone. Good evening, everyone. I would like to begin our evening by introducing the CEO of Intelligence Squared US, Mr. Robert Rosenkranz.

### Moderator
Claim: Thank you all for being here and welcome. You know, there’s not much of a debate about whether mainstream media is declining. The network evening news audience is shrinking, daily newspapers are folding, established magazine titles are being shut down. Nearly one of every five newspaper journalists has been fired in the last couple of years. Increasingly people get their news from the Internet and from cable channels.

In the past two years the number of people in the US going online for news has jumped 19 percent. Advertisers are moving to Google and to other non-traditional sources. But there is a very interesting debate about whether these developments leave us better off or worse off. Now no one seriously questions that a free press is an essential national value. And a free press does not come cheap. The major networks and leading newspapers have traditionally spent heavily on the news, they support foreign news bureaus, investigative reporting, in-depth news analysis, fact-checking and other quality controls. So why might we say, good riddance. Perhaps it’s because mainstream media did exercise extraordinary power, to shape the national agenda, and our perception of events. Might we be better off getting our news from an unfiltered Internet, to which all bloggers and news aggregators have equal access. Should we not encourage a diversity of voices competing to provide information and analysis. Can a network of bloggers tell us more about events on the ground than a reporter in a hotel bar in Baghdad or Cairo? Or could we conceivably enjoy the best of both worlds, as mainstream media reinvents itself to thrive in a digital age. These are interesting questions, I think we’re going to have a lot of fun hearing them debated tonight, and it’s my pleasure to turn the evening back to John Donvan.

### Moderator
Claim: Thank you. And may I just invite one more round of applause for the person who makes all of this possible, Robert Rosenkranz. Well, welcome, everyone, to another debate from Intelligence Squared US, I’m John Donvan of ABC News, and it is my honor once again to serve as host and moderator, as the six debaters you see sharing the stage with me here at the Skirball Center for the Performing Arts at New York University.

Three teams—sorry, two teams, three against three, will be debating this motion, “Good riddance to the mainstream media.” And I know that we have a hall full of journalists here, a topic that is close to many of our hearts, if not many of our throats. But it is an important topic for debate, and that’s what this is, it is a debate, a contest. There will be winners and losers tonight, and you the audience will be our judges, by the time the debate ends you will have voted twice, once before the debate, and once again after the debate on whether you side with or against the motion. You pick the winners. So let’s move on to our preliminary vote, and if you again look to the keypads on the left of your seats…that will be your little voting machine. Press number one if you agree with the motion, “Good riddance to the mainstream media,” press number two if you disagree with the motion, and press number three if you are undecided. And if you make a mistake, just correct the mistake and the system will only record your last vote.

### Moderator
Claim: Do you have to log in first?

### Moderator
Claim: You do not have to log in. You are logged in. We hope. All right, we’re going to lock it out… So let’s get to the debate, our topic is “Good riddance to the mainstream media,” and this is a contest in which we hope to hear a clash of ideas and logic, and wit and perhaps humor, as each team tries to change your minds and tries to persuade you to their point of view, and speaking first for the motion, “Good riddance to the mainstream media,” I’d like to introduce Michael Wolff, who in a way has one of the most mainstream of all media positions as a columnist for Vanity Fair but he also for some time has had a position on the other side of the technological divide having been involved in many Internet startups, including Newser.com which Michael, you say, has as one of its goals to kill newspapers, is that correct?

### Conspiracy Advocate (CA)
Claim: Well, also to make me rich.

### Moderator
Claim: Make you rich, ladies and gentlemen… Is that working out?

### Conspiracy Advocate (CA)
Claim: Oh yes, of course.

### Moderator
Claim: Michael Wolff—

### Conspiracy Advocate (CA)
Claim: Always—

### Moderator
Claim: —ladies and gentlemen.

### Conspiracy Advocate (CA)
Claim: I went to work for the New York Times in 1973, and I was going to say that that probably makes me one of the people who’s been in this business in this room the longest. But then I notice you’re an old crowd. My… My mother went to work as a daily reporter in 1942, my father began as an ad man in 1946, after the war. So, the thing that I know is that this business is always changing. So, the idea that somebody is going to defend the status quo of this business is to me a little silly. And my first point is, that we ought to remember, that this business, the business that those guys are going to defend, is a new creation. It’s at most, 20 years old. And it’s essentially— And the other thing that’s going to happen is that they’re going to talk about the news business, and that’s not the proposition, the proposition is the media business as it should be, because the news business has been subsumed by this superstructure. Now this superstructure, which essentially is five companies which dominate the landscape— Time Warner, Viacom-CBS, Newscorp, Disney, and NBC Universal.

What these companies are are—listen to this—more than 1,000 independent media companies, which in the past 20 years have been aggregated into five. So what they’re going to be defending, is actually a business theory. And the theory is we bring all these companies together, and we create value. Here’s the point. That theory has been all but utterly exploded. Disproven. Break it down into its component parts. Look at its constituencies. From an audience point of view, the audience has been in flight for 20 years. Just yesterday, what we’ve learned is that there was, newspapers have lost another 10 percent of circulation, some newspapers are down in a year, 25 percent. You can see those numbers not just in newspapers, across the media landscape. Television networks, books, magazines, the music business, the movie business. And now the cable business. People are in flight from what was supposed to be the bastion of mainstream media.

This is an extraordinary moment, it is a moment in which you see literally breakdown at every level. The… You have—it’s not only—you have an audience flight, you have an advertiser flight. What happens with advertisers, it used to be that consumer brands, you had 90 percent of consumer brand spending was in the mainstream media, that’s down to under 50 percent, why is that the case. Because it doesn’t work anymore. You have from a shareholder perspective, and this is key. Shareholder perspective, what you have is—well actually you’ve been screwed if you’re a shareholder in a modern media company. Media moguls rich, shareholders across the spectrum of these companies, are underwater, not one of these companies, in… 20 years has kept pace with the S&P.

This is a devastating result. What you have is your customers, your—the consumer, the advertiser, and the marketplace itself, saying that there is something phenomenally wrong here. Technology. The media is a technology business. That’s what it is. That’s what it has always been. Technology changes, the media changes. There is no media without technology. We’re… We’ve come to a funny moment however in this business because the mainstream media is run by people who are fundamentally technology-phobes.

They don’t get it, they don’t want to get it, they’re averse to it, they resist it. They are lost when it comes to making plans about it. I spent a lotta time in the recent past with Rupert Murdoch who runs I would say the leading-edge media company, and he runs it with an iron fist. He doesn’t run it with a computer because he doesn’t use one, he doesn’t run it with email because he doesn’t get email. And he can’t get that cell phone to work, he’s always kind of waving it…in the air. What you’re going to hear here tonight is that the media is necessary for the commonweal. An informed citizenry is what this nation is about. The media may be flawed but it delivers us what we need to know. That is self-serving crap. I— The New York Times, is a good newspaper, sometimes. The Washington Post is a good newspaper. The LA Times before it became a bad newspaper was a good newspaper. But after that, it’s off the cliff, it’s oblivion. The news business in this country is nothing to be proud of. What— You know, I think the thing to remember here—I mean the really important thing is that something else is happening, something is… This is easy. Change—and I have four seconds—change is good. And it’s happening and we are part of it, and we’re going to all tell our grandchildren that, we were here, we saw the monster die, and we saw the shock of the new—

And— Thank you.

### Moderator
Claim: Michael Wolff, your time is up. Thank you.

### Conspiracy Advocate (CA)
Claim: And— Thank you.

### Moderator
Claim: I want to point out, I did not give you the structure of the evening, we are doing three rounds, Round 1 we’re in now is opening statements, Round 2, the debaters will go head to head, in Round 3 we’ll have brief closing statements. We’re in— this is Round 1, opening statements by each debater in turn, they are seven minutes each, the closing statements will be two minutes each. Now, moving on, the motion is “Good riddance to the mainstream media” and here to argue first against the motion is Phil Bronstein. Phil Bronstein began his career as a television reporter and over the years moved to print and became ultimately the editor of the San Francisco Chronicle, was there during the most difficult of times, and it was he who called the staff together, and said, the business model is broken, and no one knows how to fix it. Phil, was there a “yet”?

### Scientific Advocate (SA)
Claim: Yet.

### Moderator
Claim: “Yet,” in that, ladies and gentlemen, Phil Bronstein.

### Scientific Advocate (SA)
Claim: Well, you all look very young to me. It’s a challenge to try and defend the vitality of something that’s already been declared dead. And no one has been quicker to declare it dead than people who have been preachers of the mainstream media, rushing to write the obituary. But let’s— first of all, I should caution you, we should be very careful tonight, because, we can’t touch on certain topics because, we could all go to jail if we do. What am I thinking, of course we can’t go to jail, we can talk about anything we want. And one of the reasons we can talk about anything we want is because the institutions that have made up the mainstream media, not over the past 20 or 30 years but over the last hundred years, have provided the authority, and the experience and frankly, the money, to stand toe to toe with government and all-powerful institutions and individuals.

For your rights, for all of our rights, and for the benefit of all of us. I have some notes here because I’m a newspaper person, I like reliability to the extent that I get it. A few years ago, we had two reporters at the Chronicle facing 18 months in prison each, on the Balco steroids story, for refusing to be tools of government prosecution and in fact for just being reporters. Well, we spent two years, in addition to the time we spent on the story, two years defending these reporters, and a million dollars. Eve Burton, our chief corporate counsel at Hearst, who personally oversaw this case, I think is here tonight. That’s something that I’m not so sure, that these other emerging operations in media can do. Do they have the money. Does Talking Points Memo which does great work have the money, to do that. Have the will to do that. And you know the New York Times the other day just said that Barack Obama, about Barack Obama, the cover-up continues.

So you may like this President more than you like the last one, but you may not like the next one. Because I can tell you from the Balco case experience, that that was a concerted effort on the part of the Bush administration, to go after the press, and its ability to report. I’m standing here very humbly tonight in the very long shadows of a lotta great editors, Ben Bradlee, John Carroll, Marty Barron, Gene Roberts, who are known for things, other than encounters with large reptiles, they’re known for working to change our world very profoundly.

They do stories about the deaths of 300 kids in the Washington public school system. Fraudulent fertility packages, Walter Reade Hospital took at least half a year to do, sexual abuse by— of kids by members of the Catholic clergy, the Boston Globe, a year to do that.

When Bill Keller went toe to toe with the Bush administration on domestic wiretapping you may not have liked the results of the negotiations but the fact that there was a debate, served us all. Served us all. I’m not here to defend a business proposition. As, I’ve already said, the business model’s broken, so I’m not going to do that. What I am defending is the idea of sustained professional journalism done with integrity and done in the public interest. And that is something that mainstream media has supported, we’ve gotten lost in all this business model discussion and disintermediation and granularization and it just, doesn’t get to the point. Our death by the way, would be I think a little untimely for the 50 million people who still pay to get a daily newspaper, for the 74 million people who go online, a month, of daily newspaper sites, and even for the $38 billion worth of advertising that still exists.

But, another issue I think that we should raise, in terms of the service that we provide, that mainstream media has supported all these years, Freedom of Information Act requests. Now, Freedom of Information Act requests are sort of like a New York apartment with a view. They’re hard to get, it’s expensive, it’s time-consuming, but boy, what a result. These are windows, on very dark places occasionally and very corrupt places. Lucy Dalglish, and I’ll read the quote, director of Reporters Committee for Freedom of the Press, “Access litigation has dried up, because of what’s happened to mainstream media.” And a public defender in Georgia wondered, quote, “Can underfunded bloggers, are they able to carry the financial burden of opening our courtrooms.” And that Georgia case in fact started, or was based on a case that—where the Riverside Press Enterprise, went to court to expensively—to open the courtroom. So, look. This isn’t just domestic, and it isn’t just about the government.

Seth Mydans, an old colleague of mine from Southeast Asia, said not too long ago, when he shows up at places in Southeast Asia, for stories that matter to all of us…he’s often the only reporter. Well we’re supposed to be the witnesses to history. Where are the witnesses? How are those witnesses going to be provided. I don’t think they’ll be provided solely by tweets from people on the streets of Tehran. An old colleague and mentor of mine, Max Vanzi of the Associated Press, when I went to the Philippines for the first time he said, here’s a clue.

Nothing is ever what it seems. And I thought, oh, that’s a lotta help. But, the Hearst Corporation, and the Examiner at that point took care to give me five years to learn what that meant, and by the end of that five years I knew. You want to talk about corporate greed? Well, we’ve also talked about nonprofit models, the Chronicle’s been unwillingly a nonprofit… newspaper for many years now.

But despite that fact, because of a commitment to the kinds of things that I’m talking about, that are so important to us, the Chronicle remains in business. So from the New York Times taking on Boss Tweed in the 1870s, to a young William Randolph Hearst supporting blue-collar workers…the public has been very well-served by the mainstream media, and at a minimum we can’t afford to let it go, and kiss it off, because it’s entirely unclear what other form of journalism, support for that journalism, is going to be successful. I’m under, thank you very much.

### Moderator
Claim: Thank you, Phil Bronstein, our motion is “Good riddance to the mainstream media.” And now speaking for the motion, Jim VandeHei, and Jim had the perfect job at a great paper, a respected political reporter at the Washington Post, he gave it all up, to start a start-up news organization. The good news is it turned out to be Politico.com. Ladies and gentlemen, Jim VandeHei.

### Conspiracy Advocate (CA)
Claim: Thank you. I’m here to tell you that you not only look young, you look good too. And I urge you to vote for the proposition because, to be blunt, I think new media is better than old media, and I think that we’re the hope for them. I think—I agree with most of what Phil said, I agree that all that investment, all the accountability that old journalism has done, is great and that we need those values. But there’s also another side to mainstream media and another side to new media.

For starters, mainstream media, for the longest time, I don’t think it was always as good as portrayed or always as great as we sort of mythicize. And, for the longest time it was basically run by old white men who are left of center who are deciding how all of us view the news, the only diversity was how much hair they had left or whether they drank gin or scotch. And what new media’s done is it’s injected a ton of vitality and a ton of competition into the media. And it’s also created, it gives you ideological, racial, and gender diversity that we never had before, and it gives all of us, all us news junkies, everyone in this room obviously cares a lot about news— It gives us a whole new menu of information to choose from. I also think, I—my background is I worked at the Wall Street Journal and the Washington Post and then we started Politico three years ago, so I think I’ve seen both sides of it.

And I can tell you there’s probably a lot of businessmen and women in the audience because this is New York. And I think, I think your stomach would be turned if you went into some newspapers to see how they’re run, because they had profits that were so high for so long, an almost like not-for-profit mentality took on and there became distance between the institutions that were covering the news and the readers. And I think that, it led to a real disconnect between what institutions were producing and what readers wanted, and I saw this all the time when I was at those institutions, and when I was there three years ago at the Washington Post… and I include myself in that, I saw online, I saw the Web as a nuisance, I wanted to write front-page stories for a newspaper, despite the fact that I could look at the Web metrics and see that I was getting 10 or 20 times as many people reading my story online, that that’s where people wanted the news.

And I think that creates a culture that I don’t think works for the modern news consumer. And what new media’s done is it’s ripped down that wall, between the institution and the reader, and it’s opened up, I think it’s made it more transparent and it’s allowed you the reader to participate more in what we’re doing and even some of you to participate in the journalism that we’re doing. I also want to clear up some of the myths about new media, because I think all the things that Phil said are really important and I think…you always have to remember that new media is in its infancy and that, it’s going to grow and it’s going to mature. And you’re going to hear stuff tonight about how there’s a demise of serious journalism, that you know, that if you look online, if you look at new media it’s just not as serious and substantive.

I’ve been in Washington for 15 years, and I would say that the coverage of the health care debate, has been the most substantive, the deepest coverage, the most accountable coverage that I’ve seen of a domestic policy issue in some time. And the best of it is coming not from the mainstream media, but from outside of the mainstream media. Whether it’s Jonathan Cohn from The New Republic or Ezra Klein who’s doing his stuff sort of deep down in the WashingtonPost.com, whether it’s Politico where we have three or four reporters just doing the policy element, we have investigative reporters doing the accountability element. Huffington Post often has their reporters dispatched to this issue. Dedicates a lot of its home page to this issue.

You have Propublica, a not-for-profit organization run by Paul Steiger who I used to work with at the Wall Street Journal, and the Center for Public Integrity, doing some accountability reporting and making that available to readers throughout the country. You have the Kaiser Foundation…which has stepped in and has started to produce non-partisan news about the health care debate, a lot of it about the human element of it, they have 20 reporters, that stuff’s available to any newspaper that wants to run it, so for people who care, there’s more information than ever, and it’s coming mostly from new media. You’re also going to hear about the demise of foreign coverage. And I think that’s a serious problem. But we didn’t start this fire. It was dying before new media ever came along, it’s really expensive to do foreign coverage. And guess who is actually creating that bridge until we can figure out how to finance it.

It’s new media. It’s Global Post which was started by some folks over at the Boston Globe. They have 65 reporters around the country that are doing work on a freelance basis in every corner of the country. During the aftermath of the Iranian debate which was mentioned in Phil’s column, or in Phil’s comments. The best coverage was often online, Huffington Post took the above-the-fold part of its home page, and the Huffington Post gets more traffic now than the Washington Post, and dedicated it to a running blog where you had video and text and audio coming in from Iran, so you could have a peek into what was happening on the streets that you never could’ve had in the old days, and I think that is a good thing. Andrew Sullivan was doing a similar thing on his blog. He had 1.2 million visitors in one day, which is more than you would get people reading a newspaper, all but the top three newspapers that are out there. David Wood, who is married to someone that works at Politico-- he was a foreign policy reporter covering Afghanistan on the ground.

Got laid off because of cutbacks at mainstream media. Who hired him? It’s American Online Politics Daily. It’s new media that’s giving these people a chance to do journalism. And I do believe that as new media matures, we’re going to take over that social responsibility of funding the expensive to do journalism, like accountability and like foreign policy reporting because you can’t cover anything if you’re not in business. And I think that it’s new media that’s going to crack the code on the business models that actually work. You’re also going to hear from that side on the demise of accountability and investigative reporting. I think new media is leading the charge and they’re leading it by keeping all the mainstream media reporters employed.

A lot of the best people in the business-- Bill Hamilton was Bob Woodward’s editor at the Washington Post, one of the best editors in Washington-- we, he just came over to Politico to help do our investigative stories and our longer form stories. Huffington Post started the Investigative Fund, which is a not-for-profit arm that does investigative reporting. It’s going to be run by Larry Roberts, who is running investigations for the Washington Post. Propublica, which I mentioned a little bit earlier, has thirty-three reporters, including Jeff Gerth from the New York Times, and many other people have been doing investigative reporting for a long time.

I mentioned Talking Points Memo, and Phil was saying, Well, can they make money? Is there an ability for them to finance the type of journalism that takes on government? Well, I think so. They just got another round of funding. They’re doubling the size of their staff. They’re starting a Washington bureau and they’re predicting that they can get to a path to profitability. And I believe that because Politico’s done it. In year three, with a hundred and twenty employees, doing that type of journalism, we’re profitable. And I think it proves that this works. So I urge all of you to vote for the, the resolution because new media has given journalism the tools, the tricks, the metabolism and the journalists to succeed. Thank you.

### Moderator
Claim: A reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I’m John Donvan of ABC News. We have six debaters on the stage here, two teams of three. And they are arguing over this motion: Good Riddance to the Mainstream Media. You have heard three opening statements and now on to the fourth. I’d like to welcome Katrina vanden Heuvel, who is editor of The Nation-- a small magazine with a fiercely loyal following, in many ways a targeted elite readership that would be the envy of many online websites. However, The Nation is how old?

### Scientific Advocate (SA)
Claim: A hundred and forty-four, and I feel it every day.

### Moderator
Claim: Ladies and gentlemen, Katrina vanden--

### Scientific Advocate (SA)
Claim: So you look real young. You not only look young, but you look fabulous. Okay. I-- Ah heh. I never imagined that as editor and publisher of The Nation I’d be standing here against the resolution: Good Riddance to the Mainstream Media. For a hundred and forty- four years The Nation has challenged the limits, exposed the flaws of what we call the MSN. Let me quote an old media guy, Antonio Gramsci: We are witnesses to the old media order dying. But a new one is not yet born. And Jim VandeHei can talk about all of those examples. But Propublica, for example, is very keen and explicit about partnering with what might be called legacy old media publications to get the big bang they want for their stories-- the New York Times, the Washington Post. Michael Wolff, Newser basically lives off of aggregating mainstream media sites. So I think to say, Good Riddance to the Mainstream Media may get the testosterone flowing up here, but it distracts from the tough work of salvaging and reviving quality journalism in newsrooms that will hold accountable the powerful.

So I’m ready to separate my frustration with the many weaknesses of the mainstream media from a recognition of the valuable role it plays. And I would, you know, suggest to anyone to go back and look, not just twenty years ago, but at the last two years of the Pulitzer prizes or the Hellman Media Award, which I am on, and look at who is winning awards to reform, correct, shame, expose-- and it’s still largely the mainstream media. I’m not going to speak in ways I was going to about my frustration with the mainstream media. You can imagine it, from the run-up to last year’s financial meltdown and most centrally, the Iraq war. So many mainstream media outlets have operated as stenographers to power, not as tough, hardheaded reporters. And this is a real problem, but this is not about throwing out the baby with the bath water.

It’s not defending the indefensible. It is about talking about, yes, the capacity of institutions for the health of our democracy. And for someone to say, Oh, it’s just the commonweal and you’re going to hear about people who want to protect the health of our democracy, I consider quality, independent reporting a public good. And for all the frustration the mainstream media has caused us, we can’t live without it until we have some idea of what’s going to replace it. And I would argue right now, nobody has a clear idea. The fact is that nobody but institutions like the New York Times, the Washington Post, the Wall Street Journal, excluding the nutty editorial pages, and a small group of regional papers do most of the reporting in this country that the rest of us depend on to try to hold power accountable. And yeah, there are mistakes. But it’s the hardworking reporter, whether in Congress, the federal bureaucracy. You talked about Ezra Klein, Jim. Fair enough, he’s done some great work on the health care. He’s at the Washington Post.

State houses, City Hall are on the warfronts, which, you know, unfortunately, we’re in a number of them. That is the expensive legwork, drudge work that allows our system to operate with even a dose of accountability. And that is expensive. So, for all their flaws, think about what newspapers-- and not just newspapers-- have done to provide a check on corruption and crooked politicians. Think about not only what my partner, Phil, spoke about-- journalists as not only witnesses to history but witnesses to oppression, journalistic enterprises keeping people safe, the most vulnerable from torture, oppression, injustice. People do awful things to each other but it’s worse in places where everybody is kept in the dark. Twitter isn’t going to feed that right now. It is building their other sources-- Global Post, one of the better for-profit models.

But the capacity is not there yet. At the local level there are reports which correlate a measurable decline in the quality of local democracy with the demise of local papers. So if the current journalistic model is unsustainable-- and you may think it is-- it’s up to those in our society who care about the continued ability to function as a democracy to find ways to fund reporting and insure the dissemination of quality journalism and information. This is a transformational moment. You’re going to hear from the other side. In crisis is opportunity. But it’s not a moment to toss out what has value, despite the flaws. There is a journalistic eco-system emerging out there but it is still very fragile. And to make the divide between old and new media into something, I would argue, artificially inflated by the other side, is to pit against each other what should be evolving together for the benefit of our country.

So the fundamental problem remains. Without powerful media institutions to take on the powerful on behalf of the rest of us we become more vulnerable as a society to those who would use their influence for private gain, damn the public consequences. We need a plan B and we don’t have one yet-- which, come to think of it, reminds me of how the Bush Administration went into Iraq and we all know how that turned out. Thank you.

### Moderator
Claim: Our next debater, who will be speaking for the motion: Good Riddance to the Mainstream Media, John Hockenberry, has been, I would say, an old colleague of mine who has dabbled in the mainstream media, working at both NBC and ABC. But his career has really been built around experimentation. I wager he is the only person in the hall who has written, produced and acted in a one-man show off-Broadway. He’s been breaking the rules a long time. He is currently the host of public radio morning news program, The Takeaway. Ladies and gentlemen, John Hockenberry.

### Conspiracy Advocate (CA)
Claim: Thank you. And thank you, Katrina. I would say that new media has a lot to learn from The Nation, which most these days resembles a blog, more than anything else in the mainstream media. And I think we owe The Nation a debt. But speaking directly to people is nothing new. And the idea that our opponents would have us believe that somehow freedom of the press and the accountability of the media to hold institutions accountable and to keep them honest-- is somehow created by this for-profit structure that my colleague Michael describes compellingly is dead and that my colleague Jim describes is alive and well, at least in terms of its voice and its passion for accountability in the new media is at odds with what the Constitution is about.

The first amendment enabled the mainstream media and what have they done with the custodianship of this authority and this sense of holding us all accountable in this democracy and in doing the quality reporting that we so value? What have they done? What are we defending here? In September, The Beatles Rock Band Project was, a product,was unveiled. And it was extraordinarily successful and it was a profound argument to those in the corporate for-profit media in the music business that said somehow the means of distribution being freed from the record companies to people who actually play and use music was going to destroy music in some sense: that if the record business went away somehow music would be affected, that somehow the art form of music and the quality of music would be affected.

What instead happened was people bought Beatles Rock Band because they wanted the music. They also wanted the experience of being in the band. They wanted to part of the music itself. The technology enabled people suddenly to be a part of something that they were not permitted to be a part of. Why? Because the for-profit structure of mainstream media prevented them. It’s an old story in America. When the means of distribution goes out of the hands of the small set of individuals and individual institutions that control it, change is afoot. This is a moment we should embrace. All of the institutions described by our opponents were created in times of similar transformation. The Hearst era, the New York Times, the tabloid era in American history which formed the basis of the American Revolution were all transformational moments when mainstream media was going away and new media was coming in.

This is a moment to celebrate. Good Riddance to the Mainstream Media-- it should be written in the Constitution. What are they trying to preserve here? John Donvan says that I dabbled in the mainstream media. No, no, no-- I was handcuffed to the wall of the mainstream media, ladies and gentlemen. Are we preserving the office culture and mentality at a television network where the senior editor of a news program holds an office poll to bet on the ratings for next morning’s program-- that culture? The obsession with the ages of the audience, as many jokes have been made here tonight-- this is something for the mainstream media. Chasing eyeballs, commodifying eyeballs-- that’s the business. At the height of the war in Iraq, that Katrina suggests President Bush led us into, the number one news broadcast reporting on that war was owned by a defense contractor.

Is that what we’re preserving here? Is there not a conflict of interest in that situation? Do we want to perpetuate that? Are we saying that the mainstream media, which has so humored these wonderful journalists who get paid not as much as the executives at the for-profit media, but we want to have them around because they hold the media accountable. They hold the government accountable. This is a disservice, number one, to the first amendment. It’s a disservice to journalism. My first job as a journalist was a volunteer. Now, I’m not saying that I would give up all of my income at this stage in my life, but the best journalists are people who don’t do it for the money. We want to create institutions that are all about doing it for the money and then we expect that the values of journalism and reporting are going to be maintained in that structure?

And then when it changes and institutions like my colleague Jim describes, Politico.com-- where that I will do journalism whether I’m paid or not kind of passion comes into play-- we’re going to say, Oh, my gosh, what’s happening? We’re throwing out the baby with the bath water. There’s something wrong here. We’ve gotta stop this. No, this is how it works. We do not look to the mainstream media to preserve the first amendment. We look to the first amendment to preserve the voices of the people-- on Twitter who are holding the people accountable: on Facebook, on social media, in blogs - - who are creating media and publishing media on their own. When the means of distribution leaves the hands of the few the many benefit. Now, are we to judge the success of this transformation by who is making money or not? Is that consistent with the values of we want to hold the government accountable?

We want journalism to be the Fifth Estate. This is the mechanisms of democracy. If our gauge for the health of the media is whether some folks are making money then we’ve given up at the beginning. We basically conceded the debate and I won’t concede the debate. Good Riddance to the Mainstream Media. They had custodianship of this sense of authority for quite a while. And what did they bring us? Two words: balloon boy. Iraq.

### Moderator
Claim: Finally, to debate against the motion: Good Riddance to the Mainstream Media-- David Carr, who is a media columnist and reporter for the New York Times and also frequently capable of getting off a good line or two. His take on the situation we’re in now, a column from last September, he said: Clearly, for the mainstream media the sky is falling. The question is whether anyone will be left to cover it. Ladies and gentlemen, David Carr.

### Scientific Advocate (SA)
Claim: Thank you, John. Thank you, John Hockenberry. I’ve had time to sit there for a little bit and really do some study on the audience and I want to co-sign, young, good looking, fabulous and I’m thinking, hot. It just came to me while I was looking. Do I mention that because I want you to vote against this proposition, which is a per se dumb idea? Why? Number one: I should mention it’s how I get hamburgers for my family so there is a small bit of self-interest. But number two: these are really smart lawyers over here, but we got good facts. And the fact is, as opposed to what? You want us to take the weight off Balloon Boy. Balloon Boy was a trending topic on Twitter for four days straight. It’s all Twitter could talk about.

They weren’t talking about the elections in Iraq, the elections in Afghanistan that have gone wrong. They weren’t talking about the bombings in Iraq. They were talking about John and Kate. Twitter, I love Twitter. I’m on there every damn day. But, but the best links in Twitter are always, always into the data stream of mainstream media. Because I work at the New York Times I’m cast here as the dad in the basement at the teen party. Cool guys over there, but us old fuddy-duddies. Well, I work at the New York Times. We have seventeen million people that come to our website. We put out a hundred videos every month. We have eighty blogs. We are fully engaged in the revolution that John talks about and we are at the vanguard, as is the Washington Post, as is the Wall Street Journal. To suggest that somehow, a hand created citizen media is going to support-- for instance, the New York Times has a news budget of two hundred and twenty million dollars, dozens of bureaus all over the world, many other news organizations, the same footprint.

And we’re going to toss that out, which is the proposition-- toss that out and kick back and see what Facebook turns up. I don’t think so. Look, we’re gathered here around a bonfire and I stipulate to the business problems of the media. Larger national newspapers, some of them are doing pretty well. Small community papers are doing great. Michael wants you to think that it’s five large media companies. It’s hundreds and hundreds of newspapers, local stations representing thousands and thousands of reporters who are bringing accountability to their community every day. I live in New Jersey, which is a petri dish, a game preserve of corruption. The last time that they came out to get the bad guys in government it took three busses. Do we need fewer reporters? Do we need less accountability? The next time they’re going to need a choo-choo train, to There is, there is a delight in dancing around the bonfire, there’s a delight, in grave-dancing, I’m not a grave-dancer, you shouldn’t be either, you should vote against this proposition.

The hybrid model that Katrina talked about, where old and new media gradually developed ways of dealing with the business challenges of supporting independent accountability reporting, is what’s real. That’s what is true. It feels great to throw out the babies and stare into the bathwater so let’s go ahead and throw out a few. Okay, there goes Glenn Beck… There goes Keith Olbermann. It felt great. They’re gone. And it’s true that newspapers and broadcasters have used their monopoly powers to make millions but they’ve funded reporting over and above what the culture ever had. Michael suggested the business is only 20 years old.

Paper I work at has been around for 150 years… I think that part of the reason that people get riled up is it’s easy to dwell on the barnacles, but what would you really know about Walter Reade, what would you really know about Katrina, what would you really know about 9/11. A million bloggers, typing a billion posts, I don’t think could get you to the place you need to be as a citizen to make important decisions, I consume new media, I believe in new media, I love Politico, it’s a great brand build-up. But unless you got a millionaire that’s going to absorb a lotta losses to get things going— The shop I work for occasionally makes money. None of those guys can say that. Okay. The model that they’re selling you has not demonstrated a business efficacy. And so, when Jim himself described it as an industry that’s in its infancy, are we to take the old, and throw it away, and grab a nascent industry that’s done a world of good, but in very small numbers. Global Post which has been brought up.

They’re paying reporters hundreds of dollars, who are there because legacy media assets put them out there, to train them out there. All of these new media enterprises, many of them, are staffed with legacy assets from old media and once those assets peter out they’re going to have to figure out a way to make money. I mean, I get it, I’m here from the New York Times and I’ve received my orders from the dark overlords of the mainstream media. They put a chip in, I gotta tell you it hurts a little bit. And they also told me, if you fail tonight, do not come back to headquarters. So keep that in mind. Look— It’s fun to build a bonfire, it’s not much fun to figure out what you’re going to replace it with. All the plucky citizens in the world, all the networked intelligence that you can come up with, are not going to give us what we need. Which is real-time data as citizens on a variety of platforms from a variety of voices, to make an informed choice every time we step outside that door. Vote against this proposal.

## Round 2

### Moderator
Claim: And that concludes Round 1 of this Intelligence Squared debate where the motion is, “Good riddance to the mainstream media.” And I’ve now received the results of the preliminary vote, just to remind you and to remind listeners and viewers, our live audience voted before the debate began, their positions on our motion, “Good riddance to the mainstream media.” They will vote again at the end of the debate and the team that changes the most minds over the course of the debate will be declared our winner.

Here are the preliminary results. Before the debate 25 percent were for the motion, 50 percent against the motion, and 25 percent undecided. That is where things started, you will vote again at the conclusion to pick our winner. Now we’re—now we’re moving on to Round 2, this is our middle round in which the debaters address each other directly, and we will also take questions from you in the audience. And as you ponder your questions I’ll once again ask you to think in terms of real questions and to think in terms of something that’s very brief, and if you have to write it on a piece of paper it’s probably not what you want to do. Something that is spontaneous, fresh, and real, will always work best. But I would like to ask a question of the side that is arguing against the motion, Katrina, you said that there is no Plan B, but what I heard from the other side sounded like, Plan C, D, E, F, G, all the way through Z, what— why do you feel that the argument particularly that Jim VandeHei made that there are plenty of already evident… forms of real, legitimate replacement, good journalism happening, why don’t you take those seriously as actually stepping up and filling the gap that you say is absent without a Plan B.

### Scientific Advocate (SA)
Claim: You know, I spent the last year or so going to many conferences about the future of journalism, the crisis of journalism, just last week there was a big report on the reconstruction of American journalism, I’ve read all of Michael Massing’s pieces in the New York Review of Books. There are many models. There are many models, and I think—believe I was arguing for a hybrid. I don’t think we throw out what has strong elements, that have worked, for—I want to pick up on John Hockenberry’s points, about NBC owning a defense contractor, one of the first centerfolds, the only…first centerfold The Nation ever did was on the national entertainment state in 1996 where we tracked five octopi. And the news operations were little cogs in these enterprises. And many of these are newspapers but there are strong MSM operations, which have a capacity, which Phil spoke to for example, on access, Freedom of Information. On sending journalists around the world, sending journalists around this country, and funding them. Nonprofit funding of journalism was about $128 million between 2005 into 2009. That’s one major newsroom. Their for-profit models are very small at the moment, and I think all of these foundations and all of the people looking at new models, want to build on elements of the MSM, I spoke of ProPublica. A group in Washington founded by David Bennahum. The Independent. He monitors the impact of his website, by how his stories, his reporters get picked up in the mainstream media—

### Moderator
Claim: Go to Michael Wolff, what do you make of that, it’s basically an argument that somebody will step up and reach into his own pockets and pay for it.

### Conspiracy Advocate (CA)
Claim: Katrina. You reach into your pocket, you pay for The Nation. And—

### Scientific Advocate (SA)
Claim: I thought you were talking about Rupert for a moment, Michael—

### Conspiracy Advocate (CA)
Claim: And, and this is— Well, Rupert—

### Scientific Advocate (SA)
Claim: In fact that’s, in fact—

### Conspiracy Advocate (CA)
Claim: —Rupert—Rupert—

### Scientific Advocate (SA)
Claim: —if I could interrupt, that’s not fair—

### Conspiracy Advocate (CA)
Claim: —reaches into many, many pockets to do

### Scientific Advocate (SA)
Claim: The Nation has a circle—

### Moderator
Claim: But Katrina, let him—

### Scientific Advocate (SA)
Claim: No, could I just say we are—

### Moderator
Claim: —Katrina, Katrina—

### Scientific Advocate (SA)
Claim: —the old model, reader-supported—

### Moderator
Claim: Katrina, please let him speak.

### Conspiracy Advocate (CA)
Claim: Well, but you’re supported by a foundation, I don’t know about what—how much comes from your pocket or your family’s pocket but you’re really not talking about the media business, you’re not talking about journalism, you’re talking about a philanthropy, which is great, and that’s another conversation that we might have, but if you’re talking about a robust, self- supporting, profit-making, entrepreneurial, live, real, continuing reason for being business, that’s something different. Now in your—everything you’ve said is incredibly noble, and it’s good, I wish it would happen, but it’s not the media business. And maybe you’re not a part of the media business which I would argue that you’re not. That you do something else. But the proposition is about the media business. It’s the mainstream media is actually at various times, it’s been the biggest business in this country. And you’re talking about something that is you know, worthy but not really, the discussion—

### Moderator
Claim: Phil Bronstein I see getting ready to respond?

### Scientific Advocate (SA)
Claim: Well first of all I mean I think that it’s really, the issue is not…what do we think of Plans B through Z. I think we might all agree that there are interesting plans in there somewhere in that alphabet soup. The proposition here is getting rid of A. Not the plans B through Z. And I think John Hockenberry created a bit of a false case, money case. The issue really isn’t about, are these capitalist organizations. Evil capitalist organizations. They must make money and they go against the grain of the great passion of journalism. Believe me, to be at a newspaper these days you have to be passionate because, you’re like the guy in the L’il Abner cartoon with the cloud over his head all the time. The point I tried to—I wanted to make about money was, that you needed to be able to sustain that kinda journalism, Propublica has a three-year, $10 million-a-year grant essentially from a single family. Is that going to continue? What happens if Propublica writes about that family—

### Moderator
Claim: But Phil, Phil, John’s argument—

### Conspiracy Advocate (CA)
Claim: Look, wait, wait a minute—

### Moderator
Claim: —John also made the argument—

### Conspiracy Advocate (CA)
Claim: —here, here’s the problem, here’s the problem with that. I mean, okay, there’s a lot of moaning and handwringing about what’s going away and it—that somehow new media is ending the old media, well no, we’re in a transformational moment, things are ending and other things are beginning. Where you don’t go, and this is surprising to me. Are you arguing for an explicit protected subsidy of these media divisions, of these news divisions of these organizations where, somehow in the federal tax code they’re going to be permitted some status, some subsidy that’s going to allow them to survive because we’ve decided, that it’s constitutionally important to maintain these businesses?

You don’t argue that—

### Conspiracy Advocate (CA)
Claim: You don’t argue that.

### Moderator
Claim: David Carr—

### Scientific Advocate (SA)
Claim: You say we can’t let it go away—

### Moderator
Claim: David Carr—

### Scientific Advocate (SA)
Claim: But—but John, do you disagree then with George Washington who did subsidize the distribution of newspapers, the founding fathers were very explicit, that the government had a role—

### Conspiracy Advocate (CA)
Claim: Then why didn’t you argue that there—

### Scientific Advocate (SA)
Claim: —in regulatory policy, tax policy—

### Conspiracy Advocate (CA)
Claim: But George Washington was on your side.

### Scientific Advocate (SA)
Claim: I’m sorry—

### Conspiracy Advocate (CA)
Claim: Why didn’t—why didn’t you argue that up there if George Washington was on your side?

### Conspiracy Advocate (CA)
Claim: because it’s a young crowd—

### Conspiracy Advocate (CA)
Claim: That’s not what you said.

### Scientific Advocate (SA)
Claim: Geor—I’m talking about— I think this debate should not be about business models, it should be about, how do we salvage and revive—

### Conspiracy Advocate (CA)
Claim: But, but—

### Scientific Advocate (SA)
Claim: —using elements of the mainstream media—

### Conspiracy Advocate (CA)
Claim: —but Katrina, it could only be not about business models—

### Scientific Advocate (SA)
Claim: Quality of journalism—

### Conspiracy Advocate (CA)
Claim: —because you’re not—

### Moderator
Claim: Excuse me—

### Conspiracy Advocate (CA)
Claim: —you’re not in a business.

### Scientific Advocate (SA)
Claim: I am in the business, Michael—

### Conspiracy Advocate (CA)
Claim: Well, this is, if you—

### Moderator
Claim: Michael, Michael and Katrina—

### Scientific Advocate (SA)
Claim: If you don’t think I’m in the business—

### Moderator
Claim: Michael—Mic—Katrina and Michael— I need you to alternate. So— I’ll be directing traffic for the next minute. Michael. Make your point again because I don’t think you could be heard. And then Katrina, you’ll come back.

### Conspiracy Advocate (CA)
Claim: Well, the, Katrina’s point is to remove this from a business discussion. In other words, and let’s be clear about what she’s saying, she’s saying, this is about journalists, this is about what journalists want. This is live having the health care debate decided just by doctors. It’s not true. I mean it doesn’t work that way. Nothing works this way, except if you want to just sequester something and make it part of— I don’t know, maybe a university—

### Moderator
Claim: Okay, Katrina, come back to this—

### Scientific Advocate (SA)
Claim: You know, you know, let me jump in—

### Moderator
Claim: David, David, just a second, I gave—told Katrina she would get next to—

### Scientific Advocate (SA)
Claim: She gave—she gave

### Scientific Advocate (SA)
Claim: I gave him my proxy—

### Moderator
Claim: Then—then David Carr, it’s yours.

### Scientific Advocate (SA)
Claim: The—let’s take these hardcore business guys at their word, over here, okay—

### Conspiracy Advocate (CA)
Claim: Public radio, David.

### Scientific Advocate (SA)
Claim: The,— The… Let’s just think about what they’re doing, Katrina is apparently guilty of running a magazine that doesn’t make money. Newser is an interesting model which involves either imitation or theft of other material depending on which— Politico—

### Conspiracy Advocate (CA)
Claim: Or abbreviation of stuff, of David Carr stories which are vastly too long, who’s the last—

### Scientific Advocate (SA)
Claim: Okay—

### Conspiracy Advocate (CA)
Claim: —who read a full David Carr—

### Scientific Advocate (SA)
Claim: Good one. Good one, have any of you—

### Moderator
Claim: Back to you, David Carr.

### Scientific Advocate (SA)
Claim: Have any of you ever read Michael in Vanity Fair? No…

### Conspiracy Advocate (CA)
Claim: I…

### Scientific Advocate (SA)
Claim: Every word—

### Conspiracy Advocate (CA)
Claim: I take that—

### Scientific Advocate (SA)
Claim: —a shining diamond, anyways— These guys…these guys are saying, your business is over, we’re the new crowd. Their models are completely and totally untested, with the exception of John, public radio has been an amazing model that’s produced an enormous amount of journalism. But it’s not a for-profit model—

### Conspiracy Advocate (CA)
Claim: If our models are—

### Moderator
Claim: Michael—

### Conspiracy Advocate (CA)
Claim: Can new media fact-check mainstream media for a second, because there are profitable models, Politico in its third year, 120 employees—

### Scientific Advocate (SA)
Claim: What about the money—

### Conspiracy Advocate (CA)
Claim: —come on David, David—

### Scientific Advocate (SA)
Claim: —that went in.

### Conspiracy Advocate (CA)
Claim: David— profitable. Doing serious nonpartisan journalism. The Huffington Post which you can argue is partially aggregator, is not profitable now but if you look at its traffic which this month surpassed the Washington Post, if they weren’t in a heavy investment mode, could probably be profitable. What you’re also forgetting to know, to note, is that it’s early, we’re all trying to figure out the business model, we haven’t even started to charge for content. Trust me, people, you’re going to be paying for content a lot of it is going to be new media content, and I think the whole argument over here is, we’re not saying get rid of mainstream media altogether, we’re saying, get rid of it, get rid of it the way you’ve been! The reason you guys are arguing that you survive or that people should vote with you is that by adopting all of our techniques, by get—the speed, the transparency, the openness, the Twitter, all of the things that are thriving in new media, that’s—we’re equipping some of the mainstream media institutions, to have at least a chance of survival and there aren’t that many—

### Moderator
Claim: Jim, do you think they’re on your side without knowing it?

### Conspiracy Advocate (CA)
Claim: Pardon, I think they are, I do think they’re on our side without knowing it. And I think they would privately concede that they’re on our side.

### Conspiracy Advocate (CA)
Claim: But I can’t tell the difference—

### Moderator
Claim: John Hockenberry—

### Conspiracy Advocate (CA)
Claim: —between…I can’t tell the difference between, are you arguing that your institution should be maintained as they are now, or are you simply saying, I want to know I have a job when the New York Times goes under. I mean is that the argument. Because the latter one I’m not interested in. The former one I am interested in, of course there are things about the New York Times, and there are qualities of the mainstream media that we want preserved. They aren’t the core of those businesses—

### Scientific Advocate (SA)
Claim: Well, the—

### Conspiracy Advocate (CA)
Claim: —and the strategy for making those businesses profitable is not to do more of that, as we’ve amply demonstrated, they do less of that now—

### Scientific Advocate (SA)
Claim: But we do want some of the qualities preserved, and that is why we are against “Good riddance to the mainstream”—

### Scientific Advocate (SA)
Claim: Yeah, “good riddance” is not—

### Conspiracy Advocate (CA)
Claim: Luckily they are—they have been preserved, there’s a lot of new media institutions that have the same values of fairness, of— same values of accountability. And thank God for it—

### Scientific Advocate (SA)
Claim: But you’re—

### Moderator
Claim: —and that’s where the growth is—

### Scientific Advocate (SA)
Claim: There are old mainstream organizations—

### Moderator
Claim: That’s where the innovation is— the innovation in the industry is coming—

### Moderator
Claim: Let me address—

### Moderator
Claim: —from new media, the innovation about business models, about the type of journalism, about the ways that we can use technology to make journalism a lot more accessible to all of you, to give all of you guys input into—to journalism, and I think it’s a much better thing, like I hate the pessimism that I see, in the mainstream media about what’s happening, this is a great time, it’s a great time if you want to be a journalist, it’s a great time if you’re a news consumer, because there’s more information than you could’ve ever asked for, and a lot of it is coming from where? From us, not from them—

### Moderator
Claim: Phil Bronstein.

### Conspiracy Advocate (CA)
Claim: Let me just say here is how—

### Moderator
Claim: John, John, John, let me just get to the other side, Phil Bronstein, please.

### Scientific Advocate (SA)
Claim: Well I hate the pessimism too. But John Hockenberry, John made a very eloquent case about the First Amendment a few minutes ago, and he and I were together earlier today and I mentioned the Balco case, or, the problems that came up in the Balco case with the government, and he said well, at least we have the First Amendment, or we have the First Amendment, something to that effect. And the reality is the First Amendment did not help us when Alberto Gonzalez was the Attorney General. The First Amendment did not help us as that administration, the previous administration went Circuit Court by Federal Circuit Court, to take away the rights of reporters to maintain the confidentiality of their sources and do their job. The First Amendment didn’t mean anything in that circumstance. And so, we’re all great believers in the First Amendment, I would assume. But it really required years of hard work, years of struggle, and millions and millions of dollars, for newspapers whether it’s the San Francisco Chronicle or the New York Times or the Washington Post, or the Riverside Press Enterprise, to make sure that the government was held accountable, to the notion of the First Amendment, that there was a First Amendment and that there would be people fighting for it. So, I think that was a false sort of argument to make about the First Amendment, I think the argument is very different—

### Moderator
Claim: John Hockenberry, you want to come back on this—

### Conspiracy Advocate (CA)
Claim: Sadly you used the worst case for endorsing the mainstream media. The war was endorsed by the mainstream media in the United States, the war in Iraq was the worst moment of the mainstream media in the United States, similar to the—

### Conspiracy Advocate (CA)
Claim: Alberto Gonzales period. These were aspects of the Bush administration that were not questioned by the mainstream media, it was only much, much later, that the media stepped in and questioned those points.

### Scientific Advocate (SA)
Claim: Alberto Gonzalez—

### Conspiracy Advocate (CA)
Claim: And indeed—

### Conspiracy Advocate (CA)
Claim: —the mainstream media apologized for its endorsement of both the war and some of the tactics of the Bush administration, long after the fact. The idea that you were on the front lines of being accountable to the government run amok under the Bush administration, is just completely at odds with the facts—

### Scientific Advocate (SA)
Claim: So to maintain mainstream media you would like us to be perfect.

### Conspiracy Advocate (CA)
Claim: No, no, no, I’m not saying that, I’m just saying—

### Scientific Advocate (SA)
Claim: You’re saying we have flaws and we’ve agreed we have flaws—

### Conspiracy Advocate (CA)
Claim: —you’re picking the wrong period of time to win a trophy for.

### Scientific Advocate (SA)
Claim: We—you’re saying we have flaws, we agree we have flaws—

### Scientific Advocate (SA)
Claim: What would you know about the conduct of the war in Afghanistan right now, you as citizens, you as a broadcaster, absent mainstream reporting. Who has boots on the ground—

### Conspiracy Advocate (CA)
Claim: David, David, the prob—

### Scientific Advocate (SA)
Claim: What—just say—

### Conspiracy Advocate (CA)
Claim: You’re absolutely right—

### Scientific Advocate (SA)
Claim: —what is Twitter, going to tell you about what’s going on in Afghanistan.

### Moderator
Claim: Michael Wolff—

### Conspiracy Advocate (CA)
Claim: We—yeah, no—David, I think the better question is, don’t we feel that we don’t know what’s going on in Afghanistan, this war has been going on for— Jesus Christ. And suddenly, suddenly, suddenly we wake up and we find, oh my God, we’re losing the war! Where has the New York Times been—

### Scientific Advocate (SA)
Claim: How did you know that—

### Conspiracy Advocate (CA)
Claim: —the New York Times has not told me, we’re losing the war… Jesus Christ, David, that is the worst excuse, it’s Afghanistan—

### Scientific Advocate (SA)
Claim: I—

### Conspiracy Advocate (CA)
Claim: —where we are dying.

### Scientific Advocate (SA)
Claim: Afghanistan, we have had people there doing rigorous reporting that

### Conspiracy Advocate (CA)
Claim: Oh yeah, really rigorous—

### Scientific Advocate (SA)
Claim: But Michael, I mean—

### Scientific Advocate (SA)
Claim: —you know—

### Scientific Advocate (SA)
Claim: —I can’t—

### Conspiracy Advocate (CA)
Claim: Jesus—

### Scientific Advocate (SA)
Claim: I can’t believe—

### Conspiracy Advocate (CA)
Claim: —this is appalling—

### Scientific Advocate (SA)
Claim: —I’m going to defend the New York Times but let me do that on this case because I do think, the reporting around the corruption of the Karzai government and the run-off, contributed in some measure to a public waking up and the fact that a majority of Americans now oppose this war, and if I could, in between…the Iraq war and Afghanistan, or at a certain point around Iraq, how would we have learned about the torture sites, the black sites, rendition, Abu Ghraib…

### Conspiracy Advocate (CA)
Claim: Yeah, we—

### Scientific Advocate (SA)
Claim: Those were the—

### Conspiracy Advocate (CA)
Claim: We’re not saying—

### Scientific Advocate (SA)
Claim: —those were the strong elements—

### Scientific Advocate (SA)
Claim: —of reporting—

### Conspiracy Advocate (CA)
Claim: There are some—

### Scientific Advocate (SA)
Claim: —in the mainstream.

### Conspiracy Advocate (CA)
Claim: Yeah, there are stories here. But this is— actually maybe one of the things I’m, I do this a lot, I go around the country and I talk about the end of newspapers and one of the things that invariably comes up, let’s see if it comes up here is the Boston Globe and its investigation of abuses in the Catholic church, and everybody goes well, what would happen with that. And I thought about this for a long time and I—then I thought…well, where was the Boston Globe for the 30 years this was going on? And, this is one of those things, yes, we know. But we know too late, nobody, nobody should get an award here. This is not, this is not what—you shouldn’t say, oh, we’re really proud of our coverage in Iraq and Afghanistan. My God, it’s a dollar late, whatever that—

### Scientific Advocate (SA)
Claim: So Michael, that’s your view of the Boston Globe— That’s your view of the Boston Globe coverage of pederasty in the Catholic church is that, it was useless because it was late?

### Conspiracy Advocate (CA)
Claim: Well, for God’s sake, yes, you can’t always defend yourself like this—

### Moderator
Claim: Michael, are you serious, you’re saying yes, that it’s better—not better late than never?

### Conspiracy Advocate (CA)
Claim: No, I’m saying you did your job poorly, we did our jobs poorly—

### Scientific Advocate (SA)
Claim: But the job, the job—

### Conspiracy Advocate (CA)
Claim: —that’s the job that should—no, you can’t do that, you can’t say, oh yes, well we came in finally, we got it in the end. We got it, 30 years it took us to get it—

### Moderator
Claim: But I think their argument is that nobody else did, ever—

### Scientific Advocate (SA)
Claim: Yeah, yeah—

### Moderator
Claim: —until they came in.

### Scientific Advocate (SA)
Claim: Wait, wait, wait, wait—

### Conspiracy Advocate (CA)
Claim: no. They are missing the point. Nobody else did because, in this case the Boston Globe was in the pocket of the archdiocese, they stood right in the way of that story. They blocked that story. Those are the guys who should go to jail.

### Moderator
Claim: David Carr—

### Scientific Advocate (SA)
Claim: Big powerful institutions in government, in business, need big, powerful institutions in opposition of them, Exxon… big tobacco, Exxon, the current White House, the last White House. How would you know that we’re using remote robotic airplanes in a systematic way, to go into Pakistan right now, with the CIA’s finger on the trigger—

### Moderator
Claim: Okay, David, we get the point of your question and it’s a good one—

### Conspiracy Advocate (CA)
Claim: Yeah—

### Moderator
Claim: —let’s let take—John Hockenberry take that—

### Conspiracy Advocate (CA)
Claim: Look, we are off the proposition. Totally off the proposition. There would be total agreement on this stage…possibly not with Michael. But— If the proposition was, “Good riddance to journalism.” No one is saying that. I would not participate on a panel that said “Good riddance to journalism.”

### Conspiracy Advocate (CA)
Claim: Oh yeah, I would.

### Conspiracy Advocate (CA)
Claim: The main—right, there we go. I know my colleagues. What we are talking about is good riddance to a business model, that has a mixed record on the kinds of virtues that David Carr is talking about. That is now going down the tubes for reasons that have to do with an economic transformation that is both productive and useful, and the idea of the baby being thrown out with the bathwater, that there is no alternative, Jim amply demonstrates that the alternative is emerging. If it’s with partnerships with the mainstream media so be it, but it is a good thing, vote with the proposition.

### Moderator
Claim: I want to—

### Moderator
Claim: —go to the audience for some questions now, and what we’re going to do is bring up the lights, and…microphones will travel, and I’m shading my eyes because I still can’t quite see. There’s a woman in the seventh row up with your hand up, if you put two hands up everybody—I know it’s an odd thing to do but, now they can find you. And we want to ask anybody who is a member of the media or a blogger, to identify them—so let’s say if you’re an A-list blogger, to identify yourselves, so you— You can self-select on that one. Ma’am, your question, please. And, question rules.

### Moderator
Claim: Yes, of course, thank you, I do work for a public radio station in Washington D.C. I cut my teeth on investigative journalism. I’m not quite so sure I really care about the delivery system, whether it’s a blog, a newspaper, a television story. Of all the models we’ve talked about tonight, I’d like to hear the panelists debate the best delivery system for really deep investigative journalism, I think of everything that’s really missing in our media today.

### Moderator
Claim: All right, and Phil Bronstein has argued that it takes very deep pockets, John Hockenberry, to do exactly what that questioner is asking about, the very deep kind of journalism. And you actually argued the opposite, that having deep pockets leads to terrible conflicts of interest. Take that question.

### Conspiracy Advocate (CA)
Claim: Well I would say that the deep pockets that supported one investigative series, which I applaud, was also used for other purposes, for the other 364 days of the year, so, the deep pockets are used for various things at various times. You—if you exist under the illusion that the deep pockets merely support investigative journalism, then you’re really supporting our point here. Obviously we support and endorse the virtues of investigative journalism that holds institutions to account. But to say that the only delivery system for that is newspapers financed by shareholders in a corporate model, is to really ignore the present moment. I think newspapers do a great job. I think Politico.com does a great job. I think any one individual platform is not the model. And I think what we’re talking about here is a proliferation of platforms being a good thing, a transformational moment. And if it makes some very, very well- paid people in the mainstream media worried, then, you know, that’s the kind of worry that we journalists cut our teeth on it seems to me.

### Moderator
Claim: Phil Bronstein?

### Scientific Advocate (SA)
Claim: Yeah, and we’ve heard a lot from our opponents tonight about, “You will hear from the other side,” and we really, you haven’t heard a lotta those things that they say you’ll hear from us. And I mean first of all, John Hockenberry just said a minute ago, if we could roll back the tape-- I’d suggest we do it. If it’s in partnership with mainstream media, so be it, meaning the future. Well, there goes their side of the argument. Because, if mainstream media is good riddanced, then there’s no partnership with mainstream media to be had. I don’t know what the other purposes John was talking about, the 364 days a year, it sounds like, you know, we’re cutting people’s shoes off those other…the rest of the year. But I don’t believe, I mean—the quote when I went up to the podium was, you know, you said to your newsroom, the business model’s broken and no one knows how to fix it yet, so…I’m not making the case for the business model, and I am not making the case that that top- down, vertical kind of mass medium is really the only model. I don’t know that you’ve heard anyone from this side say it’s the only model which is the phrase that John just used.

### Moderator
Claim: Gent—

### Conspiracy Advocate (CA)
Claim: I would like to hear how your side is going to support yourself at some point.

### Moderator
Claim: Gentleman in the fourth row?

### Scientific Advocate (SA)
Claim: We’re going to get VC’s just like you, Mike.

### Conspiracy Advocate (CA)
Claim: No, I—

### Moderator
Claim: All right—

### Conspiracy Advocate (CA)
Claim: —will get VC’s, you won’t.

### Moderator
Claim: Let’s respect our audience member. Sir.

### Moderator
Claim: Thank you first of all to all the panelists, we’ve heard a lot about what is purportedly wrong with mainstream media. I’d like to hear a little bit about what might be wrong with new media, and also some comment on the recent calls from the regulators on regulating new media, bloggers and so forth disclosing what they receive from corporations, and how the new media, this nascent institution if you will, might evolve and what we need to watch out for if anything.

### Moderator
Claim: That was a question. Yes. Katrina, would you like to take it?

### Scientific Advocate (SA)
Claim: I’m—yeah, you can

### Scientific Advocate (SA)
Claim: Uh…

### Moderator
Claim: David Carr—

### Scientific Advocate (SA)
Claim: Part of the problem that goes on on the Web, and there are so many wonderful examples of brand build-out on the Web, the Huffington Post, I’ve never encountered anything like it in my media career, watched something explode like that. Jim’s ability to take reporters who have worked elsewhere and just start breaking stories right away, has just been breathtaking to watch as a media reporter. That’s the exception, not the rule. Out on the Web, people assemble into verticals of self-interest. They often speak only to each other. They become an echo chamber of half-truths, sometimes outright lies, without any real data points coming in. And so you end up with a sort of mass of people talking to each other, no one has read anything. No one knows anything. They’re talking about something that someone else read that read that read that read. And we end up in a meta-world. The people that I follow on Twitter always include a link to what they’re talking about. The blogs that I follow, and Politico is a great example of this, live in the ecosystem of blogs, so you have transparency to what they’re talking and why they’re talking about it. You can look into the database. But there isn’t a lot of it going on. As these guys have said themselves, it’s a very nascent state. In the mainstream media, and the blogosphere, are—we’ve adopted the tools of the insurgency in terms of presentation, going to the Web, or Afghanistan reporting as video, as maps, where the drug lords are, blogs in real time of what’s going on. At the same time, you have new media adopting standards, reporting, approaches, starting to beef up. I think the two are coming together.

### Moderator
Claim: Jim VandeHei, sounds like again you’re agreeing—

### Conspiracy Advocate (CA)
Claim: Well we just—we keep hearing about that, you were just talking a little bit about the echo chamber like it’s just noise and people are amplifying positions that they already have and there’s a lot of misinformation out there. But who’s doing the fact-checking, some of the best fact-checking’s being done by new media. Factcheck.org, which I think is the name of the arm of the St. Petersburg Times which won a Pulitzer Prize for its fact- checking—that online, that new media component made the old media relevant, who’s been fact-checking, who was quickest to fact-check the death panels and all the other nonsense that we’ve had in different debates in recent months.

It’s websites like ours, it’s the Huffington Post. It’s various bloggers who are checking this stuff in real time, and they’re setting the record straight, and I think that that’s a fabulous, advance. Is there a bigger burden on you as the reader right now than there was, 10 years ago, when five people at the three big networks and the two big newspapers told you how to view world events? Yes. But I think there’s so much more information now for you to consume, thanks to new media, that you’re a much more educated consumer of news and you can make probably a much, a better decision based on the facts.

### Moderator
Claim: Right, there was a second part to that question about regulation of the new media, and I’m sure you’re against it. So I’m going to—

### Conspiracy Advocate (CA)
Claim: I mean I’m—

### Moderator
Claim: —move on, to—

### Conspiracy Advocate (CA)
Claim: I mean—yeah, I mean I’m against regulation and I’m against any, any government funding for, for journalists—

### Moderator
Claim: Gentleman—

### Conspiracy Advocate (CA)
Claim: —I think it needs to be—

### Conspiracy Advocate (CA)
Claim: Needs to be attached to a robust business model.

### Moderator
Claim: Jacket, tie, eyeglasses, and two hands up. Can’t use the two hands up trick everywhere.

### Moderator
Claim: I’m the—

### Moderator
Claim: Oh, I’m sorry, I actually was going to the gentleman behind you, and I’ll come back to you, ma’am.

### Moderator
Claim: As a consumer I—

### Moderator
Claim: Can you stand, please?

### Moderator
Claim: Yeah, as a consumer I think one of the values that I see in mainstream media is comprehension of coverage where you can look at a source, and really understand what’s going on in the world. And I worry that socially, how does media, if that goes away and there’s not funding for that breadth of coverage, what’s the social impact of that, if we all move to new media, certain verticals where people just choose…to read what they want to read and they’re not exposed to all these other things.

### Moderator
Claim: John Hockenberry, why don’t you take that.

### Conspiracy Advocate (CA)
Claim: Well, again, I think what is the argument there, do we preserve an institution and do we choose which newspapers are worthy of having this subsidy to maintain their position? And then are we to call them independent? Are we to say that because now they are supported by the government, they’re supported by some sort of tax on say, television or Internet service providers that that revenue now flowing to those institutions makes them secure and independent in some sense that’s going to make the journalism better? No, I think what you’ve done there is create a jobs program for some great journalists and, let’s hope they stick around. But if they leave, there’s absolutely no guarantee that the virtues that you talk about that are associated with the brand of those institutions, is going to remain. What— the only thing—

### Moderator
Claim: But John, do you—do you agree with the premise of the question that, that the new media tends toward people…seeking out views that they know they already agree with?

### Conspiracy Advocate (CA)
Claim: But I think the mainstream media is at least as guilty of that as anything in the blogsphere, I mean it is the Fox News Network I believe that created a theme park out of a conspiracy of liberals taking over the world. And— And so I think that model has worked for newspapers, as well as it’s worked for blogs, it’s certainly nothing that was invented by the Huffington Post.

### Scientific Advocate (SA)
Claim: I’m just—

### Moderator
Claim: Katrina—

### Scientific Advocate (SA)
Claim: —I’m thinking of a news story in the Las Vegas Sun, which was a six-month project by a paper which wasn’t that well-funded but, part of the mainstream media, may have been a chain. And it was a journalist who covered what unaccountable officials had not covered, what the labor unions had averted their eyes to. And she uncovered…deaths. Accidental deaths of about 30 workers. And what she did with her reporting over a sustained period of time, and I think it would’ve been difficult to do though I’m all over many platforms, and I’m for hybrid. But people aren’t reading sustained, comprehensive series, on the Web, in a new media way. And what she did was save lives. And I think that is—

### Moderator
Claim: But why couldn’t the Web very quickly adapt to that sort of model?

### Scientific Advocate (SA)
Claim: Well, I think, that, in a different instance— I mean again a sustained series over the course of a year, by Nina Bernstein of the New York Times, she not only had her newspaper behind her in filing FOIA’s which lawyers didn’t have the funding to do, this is on immigration detention. SoI think, she had the support of the funding, which is difficult in these untested models of new media… Even ProPublica as I said earlier, wants to get its stories in what you would consider the mainstream media, high- quality investigative journalism that exposes wrongs, corrects and reforms. I think the new media, and I don’t want to sound retro because I think we want a hybrid, we want a healthy journalism. But I think it’s tougher to do those kinds of things now, on the Web. People are doing Politico, they’re doing quick takes, they’re doing quick stories. But it’s rare to find people who are reading long investigative series…

### Moderator
Claim: Okay, the questioner I asked—

### Scientific Advocate (SA)
Claim: —on the Web—

### Moderator
Claim: —to wait before, ma’am—?

### Scientific Advocate (SA)
Claim: —and it doesn’t have the impact in some way, I’m sorry, because of the institutional authority, historically, which may change and is changing slowly, but not yet, of a New York Times taking on a scandal, and pushing for reform which in my view is what public interest-watchdog-accountability journalism is about.

### Moderator
Claim: Ma’am, your question.

### Moderator
Claim: Yeah, I’m the general counsel of the Hearst Corporation and 20 minutes ago the Houston Chronicle sued the governor of Texas for failing to turn over a clemency report, which a source told us contained information that the person they killed today was innocent. My question to you all is, how many lawsuits are you aware of that, let’s call it new media, has brought on behalf of the public interest for important information.

### Moderator
Claim: Jim VandeHei.

### Conspiracy Advocate (CA)
Claim: We applaud what the Houston paper is doing, we applaud what the Las Vegas paper is doing, but I think when you decide that you’re going to vote for the proposition, one of the things you have to keep in mind is that it is a false argument to say that this cannot and will not be done by the new media. You were talking about how you recall the— this Las Vegas series. I recall Talking Points Memo doing a series of pieces on the series of firings of US Attorneys under Bush and was relentless in doing it, and was—and did a great job of using the technology that new media’s created, to be able to get more documents, get more information and over time, build up a story that forced other people to reckon with and, and got attention and made a difference and I think increasingly—

### Scientific Advocate (SA)
Claim: You used a lotta stories from local papers.

### Conspiracy Advocate (CA)
Claim: Increasingly—

### Scientific Advocate (SA)
Claim: And aggregators—

### Conspiracy Advocate (CA)
Claim: And using a lot of like, the information that’s coming in

### Conspiracy Advocate (CA)
Claim: And you have files in your offices at the Chronicle as well, where you clip newspapers from other sources. And you use that as part of your research to develop stories, for heaven’s sakes—

### Scientific Advocate (SA)
Claim: Right, but I wouldn’t then want to go kill those other sources.

### Moderator
Claim: David Carr… David Carr.

### Scientific Advocate (SA)
Claim: Right now in Chicago there’s something called the Innocence Project which is one of these hybrids of student journalists and a coach and they’ve got nearly a dozen people wrongly convicted, off of Death Row and helped the governor change the policy. This week, new case, prosecutors sensing an opportunity, doesn’t address the issue of whether the person they brought forth is guilty or innocent, says I want your notes. I want your emails. I want all of your reporting materials to prove, whether you got a better grade or not if you got this guy off. Again and again…you need large, powerful institutions, barnacles attached, to take on large, powerful government forces—

### Moderator
Claim: Michael Wolff—

### Scientific Advocate (SA)
Claim: —there’s no way around it.

### Moderator
Claim: Michael Wolff.

### Conspiracy Advocate (CA)
Claim: Just briefly and I think it’s worth pointing out and this is something that people up here are loath to say and people don’t like to say in a, you know, among a polite group here, but, and I like the people at the Hearst Company. But you put out terrible newspapers and you’ve put out terrible newspapers for at least half a century, so, the question is should we fight to preserve Hearst newspapers and again I love the people at Hearst and you put out some good magazines, et cetera, et cetera. But I don’t think anyone wants to make the case for Hearst newspapers—

### Moderator
Claim: Ma’am, do you—

### Conspiracy Advocate (CA)
Claim: —or for any—

### Moderator
Claim: Do you—

### Conspiracy Advocate (CA)
Claim: —of the chain newspapers—

### Moderator
Claim: Do you feel, ma’am, that your question was answered?

### Moderator
Claim: No, I was looking for a numeric answer to the question—

### Moderator
Claim: I’m sorry, repeat—

### Moderator
Claim: I was looking for a numeric answer to the question, how many lawsuits have you brought in the public interest as part of original reporting, rather than the barnacle… pieces that you use, I’m not criticizing it but just curious as to whether or not you’ve put any energy into that.

### Conspiracy Advocate (CA)
Claim: Look, we stipulate that new media does not have the track record that the New York Times or the Houston Chronicle has because it is new media. And, and indeed, if the metric is, what have you done for me over the last century, then new media will lose. But what we are talking about is, what have you done for me lately. And I think the question is that over time, mainstream media will have less ability to do what Katrina and David and Phil are talking about, and new media will have more capacity to do it, and the intent is absolutely there, and the panel has not demonstrated that, for some reason, new media has no interest in the kinds of things you’re talking about it, take Katrina’s thing for just one moment. She’s describing how a woman reporter worked for six months on a story that saved lives, and that’s getting more difficult now. I mean, imagine, at a small local paper in New Jersey, a reporter goes in to an editor and says, you know, I’ve been working for a month on this story but…it’s so difficult, I wish I was working for the New York Times.

It would be so much easier if I was working for an organization with the deep pockets to support me, what would that editor say? He would say go back and do your story. That’s how journalism works. The idea that this is tough, is not an argument, for them. The idea that it is tough, is an argument for all the journalists who will continue to keep working regardless of whether the New York Times or the Washington Post go away tomorrow or not.

### Conspiracy Advocate (CA)
Claim: Yeah, but that’s not even what would happen, if I can argue with people on my own side—side. If they went in, if that person in New Jersey went in and said I’ve been working on this for a month and it’s really hard, what would the editor say, the editor would say forget it, okay, it’s over, done with, let’s get on to something else.

### Scientific Advocate (SA)
Claim: But you know there are interesting models, again I go back to this reconstruction of American journalism, this is how I spend my evenings when I’m not watching Monty Python. But, I was— Eight newspapers in Ohio have come together, to continue the newsroom, the news reporting that that state needs. In New Jersey and New York there’s a tristate—I’m sorry, two-state collaboration, so that you can continue some of the reporting, these are mainstream media organizations—

### Conspiracy Advocate (CA)
Claim: I don’t think your opponents are—

### Scientific Advocate (SA)
Claim: —trying to navigate their way—

### Conspiracy Advocate (CA)
Claim: I don’t think your opponents are against that.

### Scientific Advocate (SA)
Claim: Well, they’re mainstream media—

### Conspiracy Advocate (CA)
Claim: We’re just saying that it doesn’t—

### Moderator
Claim: Let me, let me go to another question—

### Conspiracy Advocate (CA)
Claim: I’m saying—

### Scientific Advocate (SA)
Claim: And I would just say on the new—in respect to the new media—

### Moderator
Claim: Right there in front—

### Scientific Advocate (SA)
Claim: —I was on the Hillman Media Awards, a year before Josh Marshall got a Polk Award, and we gave it to him for the Attorneys General reporting he did, there are good models. But, that doesn’t mean you throw out…

### Moderator
Claim: The baby with the bathwater.

### Scientific Advocate (SA)
Claim: I don’t know, some people over there might want—

### Moderator
Claim: We have to have an anti-cliché rule. Yes.

### Conspiracy Advocate (CA)
Claim: Too late.

### Moderator
Claim: So I think a lot of this conversation has been about capacity capacity to provide… good reporting, integrity around reporting, accurate reporting. And I think everyone here would agree that, there’s a lot of respect for places like Huffington Post and Politico.com. That you all have the capacity, or are at least thinking about developing the capacity to provide that quality control. I’m curious about, um, what about the other, all the other mechanisms on the Internet that don’t necessarily have the capacity, nor are interested in developing the capacity to provide that quality control. So the Twitters, the Facebooks, the YouTubes where you, you log in to something and they actually say, this is what’s happening, but it’s folks, I had an experience so I downloaded something from YouTube—

### Moderator
Claim: Ma’am, cut—

### Moderator
Claim: Sorry, okay, so—

### Moderator
Claim: —short to the chase, so focus in—

### Moderator
Claim: —the question is, who has the capacity, and who is going to be responsible, for looking at quality control outside of the places we already know are interested in doing so.

### Moderator
Claim: What you’re really saying is that there are a lotta crazy people on the Internet.

### Moderator
Claim: A lot—a lot of crazy people.

### Moderator
Claim: Okay, and I think that’s a fair point, because, Jim, for example, it’s not all Politico.com and I think that’s really her point, that they’re not all playing by your rules, which you brought in with you from the mainstream media.

### Conspiracy Advocate (CA)
Claim: Crazy people aren’t a new invention. They’ve been around for a long time, people who tell lies have been around for a long time, people who think crap information is true, have been around for a long time. And I think that…what you’re going to see, it does put more of a burden on you, and I’ll keep coming back to this because there is so much information, you have to figure out what you trust. The reason that I’m optimistic is I feel like new media is going to solve that for you, it’s not going to be old media, it’s going to be new models in your local communication, it might not be a paper that has four or five hundred employees. It might be a series of three or four smaller websites that do very specialty reporting in those communities, some might be not-for- profit, some might be ad-supported, some might be paid content.

But that’s going to happen. And it’s happening now—that’s why I’m optimistic that together we can figure this out, we are figuring this out.

And there’s a reason that mainstream media is losing readers, they lost touch with their readers, there’s a reason, look at the circulation numbers that just came out. Across the board they lost 10 percent. Some newspapers lost a much higher percent, in six months, they’re just losing the readers because they didn’t retool and they didn’t start trying to get news to you the way that you wanted, maybe you want it on Twitter, maybe you want it on Facebook, maybe you want it in a newspaper, maybe you want it online. It’s companies like ours and I think companies in new media that are figuring that out and are going to be the ones that continue to provide that and continue to fact-check for you.

### Moderator
Claim: The pink jacket, ma’am. Can you stand up, please.

### Moderator
Claim: Yes, just to your point. You said that they’re losing readership because consumers are looking for alternate ways of getting information. And I think part of the reason for that and a question to the panel is consumers are also looking for alternate opinions. And they’re finding that the mainstream media, when 70 percent of reporters say that they are Democrats or registered Democrats, are only giving one view. And this creates a problem because the people for getting information besides the mainstream media.

### Moderator
Claim: Phil Bronstein. And that also goes to John Hockenberry’s point, that by, just by the nature of the Internet, the people working in it, to the degree that it’s journalism, are a far more diverse group than you’ll see in any newsroom you and I have ever worked in.

### Scientific Advocate (SA)
Claim: Well, I think it was Jim who made that point and I read on the plane here a story-- I think it was Michael’s story, maybe-- about Politico. And that it was the founders of Politico walking towards the camera. And they, while young, so there was a diversity there, they were all white males, as far as I could tell. Maybe I’m wrong about that. So I don’t know how much diversity there is. I do know, I mean, I can tell you from personal experience. I did a blog post on SF Gate, the Chronicle site, talking about how nicely the press was treating President Obama. And that post, widely circulated. I found out I had all sorts of friends I didn’t know. But, you know, that is not a story that I… that’s been scarce.

In fact, I’ve read them in the last week, not just, by the way, in mainstream media but on Politico. It had a story today in which I was quoted, about how President Obama is getting treated better than President Bush was being treated, for doing some of the same things. So I don’t think that that’s an opinion that has been left out of mainstream media. I do realize there’s at minimum, a perception issue about the political bent of mainstream media. No question.

### Moderator
Claim: John Hockenberry.

### Conspiracy Advocate (CA)
Claim: I think the question is much more profound than simply are there more registered Democrats in whatever sort of hall of the media that you’re talking about. What is happening here is that the editorial process is fundamentally shifting to your point. And to your point if, distribution means of information is taken away from a small number of institutions the diversity is naturally going to increase. Further, if you have people who want to actually engage in the editorial process they don’t go to one Twitter.

You know, they go to sixty or they go to sixty different platforms. I mean, they are a part of the editorial process in the same way that people who buy Beatles Rock Band get to play Ringo, if they want to. The idea is existentially being a part of the editorial process. Truth telling and fact checking on their own is part of the experience that will become the business model of the future. And if the mainstream media can’t do that because their editorial process is closed they’re going to lose circulation exactly the way Jim is talking about here. So we’re not abolishing journalists and we’re not abolishing newspapers. We are talking about a fundamental shift that changes the way these institutions have managed to survive. And good riddance to that.

## Round 3

### Moderator
Claim: And that concludes round two of our debate. And here’s where we are. We are about to hear brief closing statements from each of the debaters. They will be two minutes each. And it’s their last chance to try to change your minds. And from the live audience vote beforehand we knew where you stood before this debate and here’s what we have. Our motion is: Good Riddance to the Mainstream Media. And before the debate the vote among the audience members went like this: twenty-five percent are for the motion, fifty percent are against and twenty-five are undecided. You will be asked to vote one more time and pick the winner just a few minutes from now. But we want to move into round three, closing statements. And to speak first, against the motion-- and this is fortunate because you wanted to respond to what was just said-- speaking first against the motion in his summary remarks, Phil Bronstein, Executive Vice-President and Editor-at-Large of The San Francisco Chronicle.

### Scientific Advocate (SA)
Claim: You know, I’m-- Thank you. On the car ride over here I rode with Jim. And Jim actually acknowledged that many people, even himself, consider Politico to be mainstream media. The point is really not about definitions. The arrogance that Jim referred to in newspapers for losing circulation, I think that’s a very real problem. It has been a real problem and we have lost sight-- I call it the Higher Calling Disease – of our mission. But I’m afraid I’m hearing a little too much of that same arrogance on the other panel about new media. Because, let me tell you something, you haven’t heard from any of us that we think new media is bad. They’ve made a great case that new media has all sorts of possibilities. It’s like a great, wonderful shiny object. But the proposition you’re being asked to vote on is: Good Riddance to the Mainstream Media.

Therefore, the proposition says, Mainstream media has to die. That’s the proposition. And my own experience is not that. My own experience is when I get together with Biz Stone, who is the co-founder of Twitter, we talk about ways in which their massive pipeline of all that data and information and Tweets might be able to be narrowed down into a verifiable set of facts that then professional journalists-- this is his view, and Twitter’s view-- professional journalists then take it and run with it. Wikimedia, I talked to one of their executives. He said, We rely deeply on mainstream media journalism. We are not arguing that that is the only way to go. Our opponents are arguing that their way, that the new media way, is the only way to go. And I just find that to be not a credible proposition. So I urge you to vote... against the proposition.

### Moderator
Claim: It can be confusing, yes. Thank you, Phil Bronstein. Summing, summing up his position, for the motion, Michael Wolff, a columnist for Vanity Fair and the founder of news aggregator, Newser.com. Michael.

### Conspiracy Advocate (CA)
Claim: I’ve asked before how they’re going to do it. If they want to save, the mainstream media they gotta have a plan other than a government bailout. Phil says we want the mainstream media to die, that’s what we’re advocating. That’s not the case. What we’re saying is that the mainstream media is dying. And it’s, going to die because things have changed. It’s become obsolete.

There is new technology. So even if we wanted to preserve it and most of my day is spent in the mainstream media and I would love to preserve it another year, another couple of years. Many of us about whether we will make it to retirement. I think actually we won’t. And I think that’s what we are trying to say here. It’s not to deny anything about the mainstream media-- its virtues or its faults. It’s just to acknowledge that something new has happened, a change is here. The mainstream media now is functionally Detroit. So actually, it can probably go on. It can limp on and on and on. And then it won’t be able to limp on anymore. Remember, we are all journalists here. We are arguing for our livelihoods. They’re arguing for their livelihoods. We are arguing for a new version of our livelihoods. But what you should focus on is the other people, the people we serve. We serve readers, we serve advertisers and we serve shareholders. And the mainstream media has failed in that regard and there’s no picking up the pieces.

### Moderator
Claim: Thank you, Michael Wolff. Our motion is: Good Riddance to the Mainstream Media. And summarizing her position against the motion, Katrina vanden Heuvel, editor and publisher of America’s longest running weekly, The Nation.

### Scientific Advocate (SA)
Claim: It’s folly to deny that change is happening. I believe in accuracy. No one is talking about a government bailout for the media. But we are talking about a moment of transition and transformation.

And in that moment your models-- some exciting-- are untested in terms of sustainability. And I believe, and I’m not going to use a cliché, John-- but I believe that it is not a moment to dispense with what has been of value in the mainstream media for what I believe is important, though it might be scorned up here-- which is accountability, democracy.

I believe those are noble principles. And I do believe that we do need large, powerful institutions, barnacles attached, to take on powerful forces, whether corporate or government, and that the new media is beginning. Not to demean the new media, but we need to find ways of working together to salvage quality journalism, which I believe is a public good in a society where there are too many voiceless and powerless. And to me that is much more important than the myth of this liberal bias in the media. It is who is heard and how people are heard and on a variety of platforms and of all political and ethnic and racial persuasions. So that is what I believe we should today understand coming out of this hall, and be against the motion: Good Riddance to the Mainstream Media, because there are important elements of that to preserve. And the new media lives with it, feeds on it and continues to need that, even though there is denial on the other side of the aisle.

### Moderator
Claim: Thank you to Katrina vanden Heuvel. Summarizing for the motion, Jim VandeHei, Executive Editor and co-founder of Politico.com.

### Conspiracy Advocate (CA)
Claim: I would urge you to vote for the proposition and I think when you’re about to vote you should think about their argument. Because I think they’re making a pretty powerful argument for us. What they want you to believe is that the mainstream media is something that it’s not. They want, they use words like hybrid or advancement or transformation. They’re basically trying to argue that they are new media and they’re not. The culture is different, the metabolism’s different. I think it’s emphatically clear that not only is new media superior, I think it’s our only hope for saving timely, serious, revelatory and profitable news.

So I say, Good riddance to the slow, detached, monolithic mainstream media, which we’ve had for the past twenty years. And I say that new media, we should respect the things that these guys have talked about. We do respect the values of fairness and accuracy. But I also think that all of us in this room should embrace the diversity, the transparency, the timeliness and the innovative spirit that you see in new media. That’s where the optimism is. That’s where the ideas are. That’s where our, for us news junkies, that’s where salvation is. I urge you to remember that new media is very much in its infancy. And we can sort of laugh it off and we can talk about baby water, all we want. But new media is working out its flaws. Our people balance better the serious with the superficial. Everyone’s aware that that’s an issue.

People are grappling with it and it will be solved. And we will fill the role of, the traditional role of a public servant. You can’t do public service journalism, investigative reporting or foreign policy unless you make money or unless you have government subsidy or unless you have a not-for-profit status. You have to make money to be able to support doing the foreign coverage, to support doing the investigative coverage. I’m proud to say that profit, that Politico is, in its third year, profitable and that soon we’ll be able to do more and more funding of the type of investigative reporting that we all love. We all share that. Nobody is disputing that value. So with all that in mind I think it’s abundantly clear that you should vote in favor of the proposition because the news depends on it.

### Moderator
Claim: Thank you, Jim VandeHei. Summarizing against the motion, David Carr, media columnist and reporter for the New York Times.

### Scientific Advocate (SA)
Claim: I want to thank the audience for their attentiveness and you, John, for keeping all the frogs in the wheelbarrow and moving them down the road. Tough job. And even though I said these guys had what I thought was a very tough set of facts, I take my hat off. I think you argued your case and argued it well. It does not mean I want you to vote for them. Here’s the thing: we’re losing audience. Mainstream media is not losing audience. We’re not a hybrid business. Who is it that, to take one website I know about-- the New York Times. We have eighteen million viewers. We have eight hundred and fifty thousand paper subscribers. We need people on all manner of platforms.

Politico, you’ll be interested to know, three times a week, puts a paper out on the street. Why do they do that? Because you gotta put the white paper out to get the green paper back. Okay, that’s how it works. The problem that he has and the problem that I have is that over time the audience has switched to the web. The audience that’s worth a buck in print is worth a dime and sometimes a penny on the web. Because we end up competing oftentimes against our own work, aggregated. Newser is a great looking site and you might want to check it out. It aggregates all manner of content.

But I wonder if Michael’s really thought through getting rid of mainstream media content. Okay.

### Moderator
Claim: Well, I’m thinking of the radio audience. I’m thinking of the radio audience and I was going to try to describe what you’re doing but I can’t.

### Scientific Advocate (SA)
Claim: I have a rather holy sheet of newspaper-- Newser, it’s absent mainstream media content. It looks like Swiss cheese but who would want to eat Swiss cheese every day? Vote against.

### Moderator
Claim: Thank you, David Carr. And finally, summarizing for the motion, John Hockenberry, co-host of the public radio morning news program, The Takeaway.

### Conspiracy Advocate (CA)
Claim: So, David, thank you. Now we know what those pilots on Flight 188 were doing in the cockpit. Cutting out little, pictures from Newser. I indeed am honored to be here with my colleagues and it’s great working once again with John Donvan. They have argued the point well. They have made a lot of points that remind us, perhaps nostalgically, of the journalism that we all love and that we all want preserved up here.

But you must vote against them and for the proposition for the following reasons: They’ve not demonstrated that there is a way to stop the changes that are afoot. In fact, they’ve agreed that the changes are taking place. There’s no way to stop them. They have not demonstrated how journalism is, in fact, going away under our model. And they have not demonstrated that the current institutions they call the mainstream media are the only means for delivering quality journalism. What do they say? It sounds sometimes they’re saying, We are going away. Don’t hate us. That’s pathetic and sad, but it’s not relevant. It sounds like they’re saying, We are being abolished. Don’t let them. Well, that’s simply untrue. They’re not being abolished. And in fact, they would argue that we should be abolished or that the new media should be regulated so as to prevent their content from being used in new media and having access to readers.

Finally, sometimes it seems like they are saying, We deserve to be protected, but they don’t say how. And because they don’t you must vote against them. They haven’t given us a practical reason why the mainstream media either should not go away or can be prevented from going away. Finally, my brilliant colleague David Carr would have you believe that the New York Times started on this island with Pulitzer prize winning journalists who said, We gotta start this paper to confront the government. And that’s not what happened. They started selling, they sold a lot, they made a lot and the core values of the New York Times arose out of their success. The moment has passed. Vote for the proposition.

### Moderator
Claim: And that concludes our closing statements and I just have to say to all six of the debaters, no matter how this turns out after we ask the audience to pick a winner, you came with passion and commitment and I congratulate all of you. It was a pleasure. And now it is time to pick the winner. We are going to ask you again to decide which side you agree with and from that we will figure out, from that we will determine which side has argued best. We are asking you now to go to the key pad of each seat that will register your vote. And we will get this readout almost instantaneously. Remember, push number one if you are for the motion: Good Riddance to the Mainstream Media. Push number two if you are against, number three if you became or remain undecided. I’m going to have the results in just about ninety seconds so in the meantime I want to take care of a little bit of business. First of all, I want to thank of you and, again, our debaters for a terrific evening.

Our next debate will be on Monday, November 16th. The motion is: Obama’s Economic Policies Are Working Effectively. Panelists for the motion are: Steve Rattner, who served as Counselor to the Secretary of the Treasury and as Car Czar: Elliot Spitzer, former Governor and Attorney General of New York: and Mark Zandi, Chief Economist and co-Founder of Moody’sEconomy.com. Against the motion we’ll have: James Galbraith, Economics Professor at the LBJ School of Public Affairs at the University of Texas: Economist Robert Kuttner, who is the co-founder and co-editor of The American Prospect: and the seventy-second Secretary of the U.S. Treasury, Paul O’Neill. Tickets are still available through our website and at the Skirball box office. All of our debates, as we said at the beginning, all of our debates will continue to be heard on more than two hundred NPR stations around the country and you can now also watch the debates on the Bloomberg Television Network. Air dates and times can be found in your program. I...Oh, here they come. Okay, here are the results of the debate. And remember, the team that changes the most minds will be declared our winner. And we now have the final results and they are: before the debate, twenty-five percent of you were for the motion, Good Riddance to the Mainstream Media: fifty percent were against and twenty-five percent were undecided. And before we reveal that, actually, when I come to the final result I’m going to raise my hand. I’ll ask you to applaud, and that’s for-- a little bit of a flourish on the radio broadcast. So when you see my arm go up, applaud. So I’m going to start this again. Before the debate, our motion being: Good Riddance to the Mainstream Media, twenty-five percent of you were for the motion, fifty percent were against, twenty-five percent were undecided. After the debate, twenty-four percent of you are for the motion, sixty-eight percent against, eight percent undecided. The side against wins the debate. Our congratulations to them. Thank you. In the meantime, John Donvan from Intelligence Squared U.S.
