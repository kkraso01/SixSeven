# Debate Transcript

Topic: Individuals and organizations have a constitutional right to unlimited spending on their own political speech
Motion: Individuals and organizations have a constitutional right to unlimited spending on their own political speech

Debate ID: 062614%20Independent%20Spending


## Round 1

### Moderator
Claim: If you are a Twitterer, we would love to have you Tweet during or after the debate. Our handle is @iq2us. And the National Constitution Center's handle, constitutionctr. And the hash tag is speechdebate. Now, what we always do at the beginnings of these faith debates is we have a little bit of a chat on stage to talk about how this topic came to be, why we're doing this one at this time, why it's actually phrased the way it is and why we're at, in this case, at the National Constitution Center. And for that reason I'd like to invite two gentlemen to the stage; Nicholas Quinn Rosenkranz. He is professor of law at Georgetown. He's a director of the Rosenkranz Foundation which initiated the Intelligence Squared U.S. debate series in 2006; and also Jeffrey Rosen. He is the president and chief executive officer of the National Constitution Center, and he's a professor at the George Washington University Law School. Let's please welcome both to the stage. Oh, you're here already.

Have a seat. So, Jeffrey, tell us, you know-- you do a lot of debates, but you bring us in from time to time. And it's a great honor to us to get a little-- a little focus. And for us it's this focus on the fact that, as I was just explaining, we're really doing Constitutional debate.

### Moderator
Claim: Well, I-- first of all, I can't say how thrilled I am that IQ2 is back at the National Constitution Center. Nick and I had the idea last year of creating a special series of debates that focus, as you said, John, not on political issues, but on Constitutional issues. People disagree firmly about politics. But when it comes to the Constitution, we believe there are good arguments on both sides of the debates at the center of American politics. And people should educate themselves enough about those things to make up their own minds. So I was so excited by the first debate in our series: Does the president have the power to Constitutionally target and kill American citizens abroad?

And I was impressed that although the audience initially voted, no, he doesn't have the power, after Allen Dershowitz gave the best closing argument I've ever heard--

### Moderator
Claim: It was amazing.

### Moderator
Claim: --they switched their vote and said yes. So I'm really struck by the fact that tonight you know that-- am I allowed to reveal the preliminary vote? I won't-- let's just –

### Moderator
Claim: Oh, the online vote.

### Moderator
Claim: The online vote--

### Moderator
Claim: Yes.

### Moderator
Claim: --is overwhelmingly against the motion that individuals have an unlimited right to spend. But what I want you to do as an audience is listen to these debates not as a policy matter but as a Constitutional matter; what does the First Amendment allow or prohibit? And you're going to hear two prominent civil libertarian liberals who believe that the First Amendment actually does not allow restrictions. So have an open mind, set aside your policy views, listen to the Constitutional arguments. Make up your own mind. And I cannot wait to hear the vote afterward. I am thrilled by this collaboration, and I'm so excited about tonight's debate.

### Moderator
Claim: And Nick you actually contributed to the language for this and worked on it quite specifically. And what's interesting is we're doing a debate in the fall in which you are enormously pithy. We're doing something on genetically modified food. And you said, well, let's have the motion be: "genetically modified food," three words. Tonight our motion is 15 words, the longest we've ever had. Why did it have to be that long?

### Moderator
Claim: So our IQ2 motions are usually very short and very punchy, and we go out of our way to have them-- have a sharp ring to them when we're on NPR in particular. And-- but in Constitutional law, every word matters. And Constitutional doctrine often just doesn't lend itself to the three-word summary or the six-word summary. We sometimes need several words to really get at the concept you're trying to get at. And in this case, actually every word matters. So I would just urge the audience to have a really careful look at the resolution, the words that we chose.

### Moderator
Claim: Let me recite it. "Individuals and organizations have a Constitutional right to unlimited spending on their own political speech."

### Moderator
Claim: So this may sound wordy or clumsy or something, but each word matters. So, for example, individuals and organizations, right, that's not just big corporations, but it might also be unions, could also be the New York Times, might also be Intelligence Squared. Have a right to unlimited spending, if not unlimited, then what are the limits? What are the Constitutional limits? And on their own political speech, this is not-- we're not talking about donating money to someone else for their political speech. We're talking about you spending money on your political speech. And so each of these words matter to get at exactly the Constitutional question here: Are such limits consistent with the First Amendment which was on the screen a moment ago, "Congress shall make no law abridging the freedom of speech." That's what we're here to debate tonight.

### Moderator
Claim: And it's a pretty funny one, actually, and that's why it's such a good one.

### Moderator
Claim: It's a great one. And as Nick put it, we're not debating the issue about whether contributions to candidates can be limited. There are some principal First Amendment advocates, both liberal and conservative, who think that limits on expenditures or contributions violate the First Amendment. We didn't choose that motion because that's a rather high octane position. As Nick put it, we rather carefully tailored the motion to be something that should be open to all of you, and I want you to think about it seriously. I do want to just give a shout-out to our great sponsors tonight. Daniel Burger and Craig Snyder, they're here-- talk about a civil libertarian, liberal libertarian conservative, they are on opposite sides of the political spectrum. But as Craig put it to me before we started the show tonight, he said, "I am a tea bagger, and Dan is a progressive of the worst sort, but we want to model civil discourse because we believe in the Constitution." And I am thrilled. That's exactly what we're doing here.

### Moderator
Claim: Thank you.

### Moderator
Claim: Thank you, Craig and Dan.

### Moderator
Claim: Thank you, gentlemen down there, and thank you, gentlemen on the stage. And let's begin our debate and welcome our debaters to the stage.

And I would just like to invite one more round of applause to the National Constitution Center for bringing us here. It's a pleasure to be here. So look as all of the ways that Americans can use their own money to give themselves a voice in politics. They can buy TV time, they can pay to get books written, they can put ads in the newspaper, they can put up yard signs. And here is the argument about that: It doesn't seem they're that people with the most money get to have the loudest voices. It seems like it would be corrupting. It seems un-American.

But here is the counter argument. It doesn't seem fair to tell people how much of their own money they can spend to say what they want because that sounds like censorship, and that seems un-American. That sounds like it has the makings of a debate. So let's have it. Yes or no to this statement: Individuals and organizations have a Constitutional right to unlimited spending on their own political speech, a debate from Intelligence Squared U.S. I'm John Donvan. We are here at the National Constitution Center in Philadelphia. We have two teams of two, superbly qualified all, arguing for and against the motion: Individuals and organizations have a institutional right to unlimited spending on their own political speech. Our debate, as always, goes in three rounds, and then the audience votes to choose the winner, and only one side wins. Let's meet our debaters. On the team arguing for the motion that individuals and organizations do have this Constitutional right, please, let's welcome first Floyd Abrams. One of the most important First Amendment lawyers, litigators in the country, you represented the New York Times in the Pentagon Papers case, you represented Senator Mitch McConnell in Citizens United.

In your book, which was called, "Speaking Freely," you said that when you were going to college in the mid-1950s, you were actually not that much of a First Amendment supporter, so what actually changed your mind?

### Conspiracy Advocate (CA)
Claim: I met some journalists. A time came in the late 1960s when I met a bunch of journalists. I was very impressed, almost awed by what they were doing, the skill with which they were doing it, and the national service that I thought they were doing by supporting the First Amendment.

### Moderator
Claim: We journalists aren't hearing that very much these days, so let me just say thank you. Well, thank you, Floyd Abrams. And-- and, Floyd, who is your partner?

### Conspiracy Advocate (CA)
Claim: My partner, I am very honored to be with one of the great civil liberties lawyers, and I mean this, in the country's history, Nadine Strossen.

### Moderator
Claim: Please welcome Nadine Strossen. Nadine, you are also here to argue that individuals and organizations have a Constitutional right to unlimited spending on their own speech. You are a professor of law at New York Law School, and you were president of the ACLU, the nation's largest, oldest civil liberties organization, for 18 years, first woman, youngest to ever hold that position. Now, on free speech, that organization, the ACLU, has often found itself to be at odds with some of its seemingly natural allies; and on this one also, money and political speech, it seems that there is this split. So how difficult was it for you to stick to the First Amendment side of this argument while, you know, facing your friends at the ACLU?

### Conspiracy Advocate (CA)
Claim: Not at all difficult, I've been doing this since at least the late 1970s when the ACLU controversially and successfully defended the free speech rights of Nazis to march in Skokie, Illinois.

I have enormous faith in free speech, and I love to try to spread that.

### Moderator
Claim: So you are being consistent by being here tonight.

### Conspiracy Advocate (CA)
Claim: Yep, thank you.

### Moderator
Claim: Thank you, Nadine Strossen. The team arguing for the motion. And now the team arguing against this motion that "Individuals and Organizations Have a Constitutional Right to Unlimited Spending on Their Own Political Speech," please let's first welcome Burt Neuborne. Burt, you are one of the nation's foremost civil liberties lawyers. You're a professor at New York University's School of Law. You're the founding legal director of the Brennan Center for Justice, a former national legal director of the ACLU, so, Burt, almost sort of the same question, but the flipside, on most issues you would probably be on the other side of the stage here with your opponents. On this issue you disagree. So where are they getting it wrong?

### Scientific Advocate (SA)
Claim: Well, maybe they're not getting it wrong. This is an issue that divides the free speech community, and it's a very, very hard one.

Where I think they've gone wrong is that they're willing to tolerate the degree of inequality that uncontrolled spending brings into the democracy, and I think it destroys any notion of a truly egalitarian democracy.

### Moderator
Claim: Which sounds like we're getting into your opening statement, so I'm going to stop you right there. Thanks very much, Burt Neuborne. And, Burt, your teammate is?

### Scientific Advocate (SA)
Claim: Oh, my teammate is my colleague at Fordham Law School, Zephyr Teachout.

### Moderator
Claim: Ladies and gentlemen, Zephyr Teachout. Zephyr, you are also arguing against the motion that "Individuals and Organizations Have this Constitutional Right to" spend as much money as they want on speech-- political speech. You're a professor of law at Fordham University. You were the first national director of the Sunlight Foundation. Before that you were dabbling in politics. You made a name for yourself as director of online organizing for Howard Dean's 2004 presidential bid. You're an academic. But you're dabbling in politics again.

You are running against Andrew Cuomo for governor of New York on the Democratic ticket. What made you decide to get back into politics?

### Scientific Advocate (SA)
Claim: Well, I see in Albany, New York, unfortunately, that money in politics has too much power. And it's really undermining the democracy of New York.

### Moderator
Claim: Also arguing and consistent from principle, ladies and gentlemen, Zephyr Teachout. So this is a debate. It's a contest. It's a competition of ideas well argued. And you are a live audience here in Philadelphia. The National Constitutional Center will be our judges. By the time the debate is ended, you will have voted twice, once before the debate and once again after the debate. In our debates it's the team whose numbers have changed the most between the opening and closing votes who will be declared our winner. So let's go to the preliminary votes. Each of you has a keypad at your seat. It's on the right hand side. And what I want you to do is just pay attention only to the numbers one, two, and three. The other numbers are not live.

If you agree with this motion, "Individuals and unlimited spending, in-- on their own political speech, push #1. If you disagree with it, push #2. And if you're undecided, push #3. And if you push the wrong button, just correct yourself. The system will lock in your last vote just before we lock out everything. And it looks like everybody-- I have eye contact from everybody. So, well done. So, let's go on to Round 1. Round 1, opening statements from each debater in turn. They will be six minutes each. Up first, arguing for the motion, Individuals and organizations have a constitutional right to unlimited spending of the-- let me do this again. Up first, for the motion, Individuals and organizations have a constitutional right to unlimited spending on their own political speech-- Nadine Strossen. She is a professor of law at New York Law School and former president of the American Civil Liberties Union. Ladies and gentlemen, Nadine Strossen.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you. I'm delighted to be here at the National Constitution Center defending a proposition that is supported by the constitution's grand opening words. You all know them. "We the people." As those words underscore, we individuals are sovereign. Therefore, we have no right more essential than the right to engage in our own political speech-- speech about public affairs, speech about political campaigns. As the Supreme Court put it, speech concerning public affairs is more than self-expression. It is the essence of self-government. Especially essential is our right to criticize candidates, officials, and policies.

Therefore, it's hard to imagine a greater violation of our precious free speech rights than for the government-- in other words, incumbent officials-- to limit our right to criticize them and their policies or to limit our right to advocate alternatives. It's likewise anathema for government to limit our right to band together with other like-minded individuals to amplify our voices. The Supreme Court first so held in landmark cases from the civil rights area involving the NAACP, which was a corporation. And from them, what I've said so far, individuals and our organizations clearly have a constitutional right to unlimited political speech. So, that means there's only one aspect of tonight's resolution that's really at issue. And that is whether we also have a constitutional right to unlimited spending in support of our political speech.

But logically, the answer to that question clearly has to be yes, because unlimited spending is a pre-requisite for unlimited speech. When the government limits how much we may spend on our speech, it necessarily limits the speech itself, in quantity and or quality. Think about it. Suppose the government imposed maximum spending limits on IQ Squared or on the National Constitution Center or-- dare I say, on the Brennan Center for Justice? All of which are corporations, by the way. Those spending limits would clearly limit the amount that could be said by any of those fine organizations. Every communication requires some spending. And since costly TV ads are so important in election campaigns, you have to spend a lot to reach a critical mass of the voters. So, for government to limit what we may spend on our own political speech, including our criticism and our dissent, is for the government to limit our criticism and dissent.

And that violates not only the rights of all of us dissidents, but also the rights of everyone to hear us. That point was well-made back in 1957 by three of the greatest, most liberal egalitarian justices ever to grace the Supreme Court bench-- Chief Justice Earl Warren, Hugo Black, and William O. Douglas. They were reviewing the very first federal law to limit spending on political speech. It banned such spending by corporations, and by labor unions on a rationale that we continue to hear, including from our esteemed opponents tonight, namely that these organizations are so rich and so powerful that they could be unduly influential. They could drown out others. But these justices resoundingly rejected that rationale as anti-democratic.

As they explained It is we the people who are sovereign. It is there are vitally important that we the people have access to every view of every group in the community. After all, if there are any groups that are disproportionately powerful in the political process, it's the Constitutional media with their unique impact on public opinion. Yet we wouldn't even dream of letting the government limit what even the most powerful media company could spend on its political views. Even those who want to limit what the rest of us spend draw the line at the media even when they're part of conglomerates. But since media moguls have the right to unlimited spending on their political speech, surely it follows that the rest of us must have the very same right, otherwise it unfairly amplifies the voices of the rich and powerful people in groups who can afford to buy a media outlet.

So that's just one of the reasons why spending limits actually undermine their stated goal, namely of leveling the playing field. Another reason is that spending limits favor incumbents and the two major particular parties, which should hardly surprise us because after all it's the incumbents who pass these laws. Now, our opponents are going to argue, and they already have, that these limits promote equality and integrity in our political system. Certainly these are extremely worthy goals. But as I've already noted, the goals are not in fact served. They are underserved by spending limits as Floyd will amplify on that further. For these reasons, please vote yes on the motion for unlimited political speech and therefore the unlimited spending that facilitates it and against government limits on what we the people may say and hear about it.

### Moderator
Claim: Thank you, Nadine Strossen--

--who finished with three seconds to spare. That was masterful. Our motion is "individuals and organizations have a Constitutional right to unlimited spending on their own political speech." And here to debate against this motion, Burt Neuborne. He is the Milholland professor of civil liberties and the founding legal director of the Brennan Center for Justice at New York University School of Law. Ladies and gentlemen, Burt Neuborne.

### Scientific Advocate (SA)
Claim: Thank you, John. I too am delighted to be at the National Constitutional Center. I too care about we the people. I like to think I care about we, all the people, not just the people that have enough money to be able to engage in the kind of speech that occurs when you have utterly unlimited amounts of spending.

We can't consider this in a vacuum. We have to look at facts. We can't think about this in a bubble. In the last election cycle, $6 billion we spent on campaigning. Of that $6 billion, almost 99 percent came from 1 percent of the population with the capacity to spend enough money to be able to bring their views into powerful play in the electoral process. Of that, 1/10 of 1 percent contributed vast amounts, about $6 billion, many of it unreported because of loopholes in the discovery laws. And of that 569 billionaires maxed out in a way in which they contributed vast sums and spent vast sums in impressing the rest of us with their views. Now, that means a small group of Americans, super citizens, I call them, has the ability to decide who gets to run for office because there's a wealth primary.

Unless you can convince the rich to support you, you cannot run for office. They have a disproportionate effect on who wins because they can control the speech patterns in ways that allow them to speak to the community in an effective way even though their opponents may not be able to do so. And they control what we see and hear because they set the agenda because if they don't agree, then they simply don't support the candidate in the first place. Now, every election is turned into a one dollar, one vote election unless there are some restrictions, some restrictions on what people can spend in asserting their own views. Now, it doesn't have to be this way. It's correct for us to talk about Constitutional law. What does the First Amendment actually say about the proposition that we're talking about tonight? It says Congress shall make no law abridging the freedom of speech. We can't read it literally because that would mean only Congress would be president, not the governor, not the cop on the beat.

So we don't-- we can't read it literally. And then it says, "Shall make no law abridging the freedom of speech," not abridging speech, but abridging the freedom of speech. Some human being must make a judgment about what goes in that protected category and what does not. So what fundamental mistakes have we made in saying that the freedom of speech gives the richest 1/10 of 1 percent of this country the capacity to dominate a democracy that is supposed to be one person, one vote? First, the-- we said that equality doesn't matter, that trying to equalize the rough ability of all of us to affect the political process is not an adequate basis for justifying limits, not saying that you can't spend anything, not saying that you can't even spend a lot, but saying that there is absolutely no limit.

The sky is the limit on what you can spend. And if you have a regime like that, forget about any idea of equal political participation because it's a fiction. Secondly, the idea that spending money at astronomical levels, it equals speech instead of power I think is a fiction. When you start spending money above a hundred thousand, 200,000, 500,000, a million, 5 million, to push your ideas into the public, at some point you have got a loudspeaker that is louder than anybody else's. And everybody, I think, would say that the volume of the speech is not the same thing as the speech so that there has to be some limit on the up side or else forget about any idea of egalitarian democracy.

And we don't have to say that speech equals-- that money equals speech. That was a mistake we made in 1976, and we can fix it. Third, the idea that corporations, profit making corporations-- and we have to distinguish here between nonprofit corporations that are essentially just a group of people that gather together to advance their politics in a corporate form and corporations like Citicorp or pharmaceuticals or the oil companies that are essentially collections of individuals designed to sell things for a profit where the money comes from investors, it comes from consumers, and it comes from shareholders. Why should the management of those companies that assemble vast amounts of money in connection with their commercial activity-- why should the managements of those companies be able to tap that money to advance their own political views in the give and take of an election?

We made it much worse in 2010 when we took a system that said, very rich people could do that, and we parachuted in on top of it. Large corporations, profit making corporations without any attempt at distinguishing between a small corporation, a membership corporation like the NAACP or the Brennan Center or the ACLU, which is not in it for profit, and which has people that share their views and a huge corporation like General Motors.

### Moderator
Claim: Burt Neuborne, I'm sorry, your time is up. And thank you very much. And here is a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two fighting it out over there motion: Individuals and organizations have a Constitutional right to unlimited spending on their own political speech."You have heard of the first two debaters and now onto the third. At the lecturn, Floyd Abrams, he is a partner at Cahill, Gordon and Reindel, and he represented Senator Mitch McConnell in Citizens United versus Federal Election Commission. Ladies and gentlemen, Floyd Abrams.

### Conspiracy Advocate (CA)
Claim: Good evening. I want to start with a point that Nadine made, which I don't think was responded to, and that is that without the ability to spend money, we don't have political speech, at least we don't have enough political speech to have a chance to win most elections. Look around this room. Imagine that this was not the national Constitution center but a political hall, but otherwise just the same, with all you people here. We couldn't have this event, we couldn't have a debate without paying for the lights, the microphones, the cameras, everything in the room.

There are people here, I want to assure you not the speakers, who are being here tonight. And none of this could occur if people didn't spend money to back it up, to make it happen, to allow it to happen. Now, Burt talked about-- he used the phrase about "One man, one vote." We have never ever lived in a system of one speech, one person, or limited speech per person. We don't say that. We wouldn't imagine saying that to our newspapers or our media entities, however large they are. If you were to take Burt's point literally, you would say, "It is-- we cannot persist in the notion that Rupert Murdoch can have all the money and power he has," or that the Philadelphia Inquirer could have all the power that at least it once had in Philadelphia and that it certainly does to a significant degree today.

It's perfectly true to say that people with money have more influence and power than people who don't. That's the way of the world. How do we deal with that? We can deal with equality as best we can as a public. We can have laws. Some of them we have already. We can have better laws about people being able to vote instead of closing polls early in the day. We can limit the money if that's what we're after. We can have higher taxes. I'm not advocating anything today. I'm just saying it doesn't violate the First Amendment to have a wealth tax. It doesn't violate the First Amendment to crack down on banks. It doesn't violate the First Amendment to have tougher antitrust laws. It does violate the First Amendment to limit speech.

And that is what the negative side of this proposition necessarily is urging on you. Indeed, Burt did it. He is always straightforward. He was straightforward tonight. What is the argument? Too few people have too much power. And, therefore, what? They should not be allowed to speak as much as their money might allow, or, to put it differently, because they have more money and are prepared to spend it on political speech, our Congress, the very people who as Nadine pointed out have the most direct personal interest in passing legislation which will keep them in power-- that the Congress can pass Constitutional legislation limiting the amount of their speech. The Supreme Court put it very well in 1976 in the Buckley case referred to by Burt.

I want to read you one line. The court said, "The concept that the government may restrict the speech of some elements in our society in order to enhance the relative voice of others is wholly foreign to the First Amendment." That's what the court said. That's what the law is right now. And I think it is a glorious articulation of First Amendment principle. And these were not the five supposedly rabid rightwing conservatives who gave us Citizens United. This was Justice Brennan, this was Justice Thurgood Marshall, this was Justice Potter Stewart, three of the most stalwart defenders of the First Amendment in our history.

And what they were saying is, "You can deal with problems in a lot of ways, you can deal with the equality problem in lots of ways, but the one way you can't deal with it is by shutting up the voices of others or limiting the voices of others, wholly foreign to the First Amendment." This is one of the things that makes us so special in the world. I mean, it's only we, and we should be proud of it, but only we have a first amendment as strong, as totally controlling over what Congress can do as we do. So I would urge on you that while to some degree I understand that it seems not fair that people who have more money should have more power, if you want to deal with it, and we should sometimes, if you want to deal with that, don't deal with speech.

One of the First Amendment principles that's first is hurt speech last. So, I urge you to vote yes on this resolution.

### Moderator
Claim: Thank you. Floyd Abrams. And the resolution is this: Individuals and organizations have a constitutional right to unlimited spending on their own political speech. And here to argue against this motion-- Zephyr Teachout. She is an associate professor of law at Fordham Law School and a former National Director of the Sunlight Foundation. Ladies and gentlemen, Zephyr Teachout.

### Scientific Advocate (SA)
Claim: Thank you so much. I want to point out, first of all, that my worthy opponents both relied heavily on arguments about limiting the press from speaking. That's an interesting debate, but that is not the debate we are having tonight.

There is a separate clause in the constitution, a freedom of the press clause, which is put in there to protect especially particular kinds of institutions that play particular roles in our democracy. What I do think we are debating is we're having a debate about reality and we're having a debate about history. Both of my opponents, very persuasively argue, but I would argue they mostly argue from abstraction. Burt started his argument talking about money and how it actually influences politics. And I want to talk about history, because I think this is a constitutional debate in the most fundamental sense. It's about who we are, how we want to constitute ourselves, and what our most fundamental principles are.

So, instead of starting with a text of the First Amendment, sort of separated from its own purpose and principles, I want to return to the Constitutional Convention across the street, 230 years ago and look at the core purposes of the constitution itself, because only once we really understand the constitution and what it is for, and what it was for, can we understand the place of the First Amendment in it. I've spent a lot of time reading the transcripts of the debates of the Constitutional Convention. And I'll tell you, there's one fear-- the core principle is representative democracy. Figuring out a system where the public good could be represented. It's a really difficult puzzle. And there's one fear that dominated over every fear, and that was the fear of corruption. They talked about corruption more often than they talked about violence, more often than they talked about the threat of faction, more often than they even talked about this-- current problems of the day.

The threat was that this beautiful new country would fall victim to the power of money to distract representatives from their job to tend to the public good, the same way that they had seen Britain do. Pierce Butler said, "Look at Britain. You know, there we've built the fairest society ever. And yet, corruption has destroyed that fabric." So, they weren't worried about some technical question of non-representative democracy. They were worried about how money-- in all these different guises-- could come in and take away this sort of precious young country. At the time, the concerns were focused around gifts from kings-- the king of France kept giving these really luxurious snuff boxes to diplomats. And there was a lot of anxiety that that would lead people like Benjamin Franklin to forget that his obligation was to this country and not to France.

Another major concern was that people would go into office in order to get good jobs later-- or at the same time. Butler also said, "A man takes a seat to get an office for himself, for his friends. This is the source from which flows venality and corruption." If you look at the constitution, there's not just the First Amendment when it comes to money and politics. There's dozens of clauses. And each of these clauses is communicating that what the founders cared about was protecting against this thing which is the danger to all republics. So, when Alexander Hamilton was asked, "What were you doing at the convention?" he said, you know, "Our job was to protect against - - but to create every practicable obstacle against corruption." And Mason said, "If we do not provide against corruption, we will soon be at an end."For the next 200 years in this-- Courts understood that protecting against corruption was one of the core jobs of law itself. And so you would never see a lobbying case, lobbying was illegal in this country for a long time-- a lobbying case or a money in politics case without a serious investigation about-- of whether the laws that issue-- or the structures that issue might lead representatives to forget their obligations to the public and instead serve other masters. 200 years after 1776, in 1976, you saw courts starting to forget that. I'm not going to go into the full history here, but my objection to the proposition is not what's in it, it's what's not in it.

If you can't talk about the First Amendment without also talking about why it's there and without also talking about the ways in which it might lead to money taking over this extremely precious and rare thing, which is representative democracy. So starting in 1976, the character of money in politics has gradually dwindled and become smaller and smaller in all our court cases until recently, in Citizens United and McCutcheon vs. FEC where the great tradition of the First Amendment is weighed against basically a corruption which the justices call the same as bribery law instead of the old corruption that our founders understood. So I urge you to reject this proposition because so much is at stake; representative democracy itself.

### Moderator
Claim: Thank you, Zephyr Teachout, your time is up.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is, "Individuals and organizations have a institutional right to unlimited spending on their own political speech."Keep in mind how you voted at the beginning of the evening. Again, we're going to have you vote immediately after all of the arguments. And it's the team whose numbers have changed the most in percentage point terms who will be declared our winner. Now we go on to round two. And round two is where the debaters address one another directly and take questions from me and from you in the audience. We have, in this second round two teams of two debating this motion: Individuals and organizations have a Constitutional right to unlimited spending on their own political speech. You've heard the arguments for this motion from Floyd Abrams and Nadine Strossen. They have argued that, yes, very likely the fact that the rich would have more of a voice in a marketplace where there's no limb mitts to spending, they would have that louder voice, and that's a real problem. But they say the solution cannot be the limiting of what they spend on that voice because that runs right into something called the First Amendment.

They say if anything, that amendment was conceived to protect political speech which is the essence of self-government. The team arguing against the motion, Burt Neuborne and Zephyr Teachout, they are saying that there can and should be limits on spending for speech in politics because they're arguing that spending is more than just speech. It's actually action. It's the accumulation of power and that this has consequences, particularly when the source of that power, the source of that money is large corporations driven by their own profits. They also make a philosophical argument that whatever the text of the First Amendment they say that there are values that fight corruption embedded in the Constitution's history and its own philosophy and that those also have standing in this debate. I want to go to the team that is arguing against the motion. You're arguing-- in other words, you're arguing for the government being able to limit speech, to limit the spending on speech. And as I said, you're opponents are saying the First Amendment is your problem on this argument. And your response to this is what?

Is it that the First Amendment is not a problem to this argument, that the First Amendment is irrelevant, or is it that it's a problem that can be worked with? Burt Neuborne.

### Scientific Advocate (SA)
Claim: Well, the First Amendment is the central thing we have to think about. It is the text that the Constitution has that gives us the answer. But the answer is not self-evident in the First Amendment. It's not as though God spoke from the mountaintop, and we know that the First Amendment says that unlimited spending is protected under the First Amendment. The text itself doesn't say so. Our history for 200 years doesn't say so. The Constitutional convention doesn't say so. And representative democracy doesn't say so. So it's not that the First Amendment-- it's not that we have to get around the First Amendment. It's that they're misreading the First Amendment. Read directly, the First Amendment is democracy's best friend. And they are reading it as a kind of conspiracy to destroy it, and therefore--

### Moderator
Claim: Whoa, whoa. That's--

### Conspiracy Advocate (CA)
Claim: We apparently have very different views of democracy and--

### Moderator
Claim: Nadine Strossen.

### Conspiracy Advocate (CA)
Claim: And I think there's something extremely paternalistic and antidemocratic in the assumptions that both of my esteemed colleagues are making, that they're assuming that just because somebody spends a lot of money on ads that we the people are going to be duped and necessarily vote for that person? Or if information gets out that somebody has received a lot of campaign contributions and is voting accordingly that we the people are going to support that politician? The record speaks to the contrary. Look at Eric Cantor, Exhibit A, very recently vastly outspent his unknown opponent, was supported by all of the big corporate interests and yet that money was drowned out by the local grassroots people.

### Moderator
Claim: Nadine, you're acting the pragmatics of what your opponents are saying, but they're also making the point that the text doesn't actually-- the text doesn't actually protect spending.

### Conspiracy Advocate (CA)
Claim: But the text talks about "Congress shall make no law abridging the freedom of speech." The Supreme Court consistently and correctly has said that any measure that abridges, i.e., cuts back on speech, makes it more difficult and burdensome to engage in speech is an abridgment. If you are told that you cannot spend as much money as you would like to speak as much and effectively as you would like, that clearly is an abridgment.

### Moderator
Claim: Zephyr Teachout, that's a coherent and logical argument.

### Scientific Advocate (SA)
Claim: Yeah, no, and I want to be just very precise about the way in which we imagine political reform working. It's not political reform mandated by the Supreme Court, but the public demanding a set of rules, Congress enacting those rules, and then the court, I would say, should only then intervene in these democratically demanded rules when there is something truly disturbing, some violation of the First Amendment which requires it, because the court itself--

### Moderator
Claim: But-- but are your opponents not saying that having the rule, period, is a violation of the First Amendment?

### Scientific Advocate (SA)
Claim: No, I was-- yes, but I was responding to your first argument that basically there-- what we want to do is empower Congress to actually respond to the constantly changing game of the corrupted

### Moderator
Claim: All right. But that doesn't go to the-- that doesn't go to the core of the argument they're making which is absolute on the First Amendment. And I just want to hear your response to that. Does the text not say, as Nadine just spelled out, and I said coherently, that the-- that the Congress may not pass any law abridging freedom of speech. Is that not clearcut?

### Scientific Advocate (SA)
Claim: It's not.

### Moderator
Claim: I'll let Burt Neuborne take it.

### Scientific Advocate (SA)
Claim: It's not clearcut.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: She left out the three most important words. The First Amendment doesn't say "Congress shall not-- shall pass no law abridging speech." If that's what it said, they couldn't outlaw extortion, they couldn't outlaw bribery, they couldn't outlaw threats. It says "Congress shall pass no law abridging the freedom of speech." The freedom of speech is not a self-evident idea.

You have to figure out what goes inside the freedom of speech and what goes outside the freedom of speech otherwise why are those three words there?

### Moderator
Claim: Floyd Abrams.

### Conspiracy Advocate (CA)
Claim: What you're missing is that the one area of speech which is most protected is political speech. There's nothing that we protect more than that. There's no area in which we give the Congress less leeway to act for a variety of reasons, not least that the single most important purpose for adopting the First Amendment was as a protection against the government, against the government influencing, affecting, limiting, chilling speech. That's why Thomas Jefferson, sitting in Paris, said he wouldn't support the Constitution at all unless there was a Bill of Rights which contained a clear, unambiguous-- what became the First Amendment.

### Scientific Advocate (SA)
Claim: No, but Floyd, you're making two different arguments, and I want to separate them out, because one is a very important argument that I think we should pay attention to. When Congress passes laws that increase their own power or entrench their own power, we should be very wary of them, and we should be wary of them because it's a basic democratic principle against corruption, not because it's a first free speech principle but because it's an anticorruption principle. And then there's a separate principle which is embodied in the First Amendment totally distinct, which is the principle that we should be free from government censorship and government telling us what to think, whether or not we can say something about a particular invasion, what we think about a particular policy issue. And that is not threatened when--

### Moderator
Claim: Do you agree--

### Scientific Advocate (SA)
Claim: That is not threatened when Congress passes a law saying that a corporation cannot spend more than $60,000.

### Moderator
Claim: Do you concede you're opponent's point, Burt or Zephyr, that there is no political speech without money?

### Scientific Advocate (SA)
Claim: Sure. I concede-- there's no speech here, you can't have speech anywhere. It costs money to run a democracy. The question is since it costs money to run a democracy, are we going to essentially say that the people with the money get to control the democracy--

### Conspiracy Advocate (CA)
Claim: They –

### Scientific Advocate (SA)
Claim: --or are we going to try to pass laws that say, "Look, we have to figure out how to fund this thing"? But the way we don't want to fund it is to let the top 1/10 of 1 percent of the population have a disproportionate say in what democracy is--

### Conspiracy Advocate (CA)
Claim: They don’t--

### Moderator
Claim: Nadine Strossen.

### Conspiracy Advocate (CA)
Claim: --have a disproportionate say, Burt, in all of the recent elections, including the post Citizens United elections, when everybody was forecasting that big money, especially corporate money, would drown out all voices-- even the New York Times had to eat its own words and say, "These elections have been a landslide loss for big money." We, the people, are not such dupes. That's what democracy is about.

### Moderator
Claim: Nadine--

### Conspiracy Advocate (CA)
Claim: And I also--

### Scientific Advocate (SA)
Claim: No, we--

### Conspiracy Advocate (CA)
Claim: --I really-- I also have to make this point because Burt suggested that you have to choose between equality principles, which I hold as dear as First Amendment principles and free speech, the opposite is true, when the ACLU challenged the initial Federal Campaign Finance Law in Buckley versus Valeo in 1976, we argued that, that violated equal protection as much as it violated free speech because it is an incumbent protection act, as all of these laws are.

### Moderator
Claim: Okay, let's defer to I think misstated his position on that. Burt Neuborne.

### Scientific Advocate (SA)
Claim: Well, I mean, my position is that, of course, speech costs money. The question is, "Where do we find it?" Now, Nadine says, "Don't worry. Money doesn't always win." Well, look, I'm one of these poor souls that's rooted for the Mets for many, many years." I live in New York City and I have to face Yankee fans every day. guess what? The Mets beat the Yankees every once in a while but over time the team with the most money to buy the best players wins the Series.

### Conspiracy Advocate (CA)
Claim: Well, why don't you get an owner who spends some money?

### Scientific Advocate (SA)
Claim: Well, that's true, but-- that's true in politics. The team with the most money wins, and the rich win in this country because they control the democracy.

### Conspiracy Advocate (CA)
Claim: Burt, that is the worst--

### Moderator
Claim: Floyd Abrams.

### Conspiracy Advocate (CA)
Claim: --argument. Look, we have a disagreement here not just about what the First Amendment means but about what democracy means. To me there is nothing more inconsistent with the notion of democracy than stifling speech, period. When a government comes in and says either, "You can't say that," or, "You can't say it too often, it's just going to have too much of an effect.

And we're telling you, we, the government, the Congress, we're telling you we're not going to allow that. And it's in your interest. It's really pro-democratic that we're doing that. You'll like it." That's why we have a first amendment.

### Moderator
Claim: But, Floyd, let me take the point that your opponents made in their opening statement, that spending is not just speech, it's actually action. And it's the accrual of power. It's the imposition of views, and that these have consequences, and that it's doing, not just talking, and that, therefore, I'm taking it the point being this overleaps just the issue of the First Amendment.

### Conspiracy Advocate (CA)
Claim: It's not just talking, but speech is never just talking. Speech has impact. Speech is dangerous. A lot of speech does harm. I mean, we live in a country that protects pornography, that protects a Nazi's speech.

We live on a country that protects-- I'm just thinking of the movie "The Wolf of Wall Street" because of all the reference to corruption. No one in this country would imagine saying that, "You know, a movie that makes corruption look pretty good and drugs rather attractive can be banned because of its pro-corruption in some way." This country doesn't think that way. It is in the words of the Supreme Court in that case I quoted to you, "wholly foreign" to the First Amendment to say that, you know, too much speech is too dangerous, that it can do harm, and it can hurt people.

### Moderator
Claim: Let's let Zephyr respond to some of this.

### Scientific Advocate (SA)
Claim: Yes, well, Floyd, there's something--

### Moderator
Claim: Zephyr Teachout.

### Scientific Advocate (SA)
Claim: --that you repeatedly do which is sort of make an elision between unlimited speech and speech itself. if you go back to the founding era and the first 200 years of this country, there is a great support for actual limits, like you need a seven-year residency before you can run for certain offices. You can't have elections without districts, but that doesn't mean you need unlimited districts.

### Moderator
Claim: But is that--

### Scientific Advocate (SA)
Claim: No.

### Moderator
Claim: --in the First Amendment?

### Moderator
Claim: Zephyr, who figures out, then, what the limits are for some rich guy, or a company, or a union?

### Scientific Advocate (SA)
Claim: The key is the people. And Floyd talks about the government as if the government is some alien other as opposed to one of the most extraordinary places in world history where we have figured out, in our fumbling way, but pretty well, how to have the government actually represent the--

### Moderator
Claim: Can you hold on for just one--

### Scientific Advocate (SA)
Claim: --will of the people.

### Moderator
Claim: --second--

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: Because I-- I'm going to bring it right back to you, but I just want to have you say your two sentences, because I heard you whisper.

### Conspiracy Advocate (CA)
Claim: Oh, sorry. The government is the other.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: It is--

### Moderator
Claim: Let's--

### Conspiracy Advocate (CA)
Claim: --accountable to us, and we have to hold it accountable by being able to have unlimited criticism.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: And when we have--

### Moderator
Claim: Okay. Okay. Okay. Okay. I'm stopping you there because – this was only an insert in Zephyr's point. So, I'm going to let you continue.

### Scientific Advocate (SA)
Claim: Yeah. I don't want to limit the kinds of criticism. I want to empower the public, the people, to say that we need certain kinds of rules about bribery.

### Conspiracy Advocate (CA)
Claim: We have them.

### Scientific Advocate (SA)
Claim: And those rules about bribery implicates speech, but they're important rules. And one of those rules about bribery-- the founding fathers would have thought of all our campaign finance laws as anti-bribery laws. That's how Teddy Roosevelt talked about them. And that's how all the progressive populists talked about them, is understanding that these are anti-bribery laws, because whether or not you're in the same room and having a quid pro quo, you know that somebody's basic obligation to the public is lost when there's 2 million dollars spent to quash their campaign from a private interest.

### Moderator
Claim: All right. I'm going to give it back to Nadine in a second, but I – just want to say, after Nadine-- after Nadine's comments, I'd like to start taking questions from you in the audience. And once again, I want to ask you-- the way that this would work is you'll raise your hand. A microphone will be brought to you. I'll ask you to wait for the microphone so that the live stream audience can hear and the podcast listeners can hear you. Just stand up. Wait for the mic. Hold it about as far away from your mouth as I am here so that you're crystal clear. State your name. And then ask a question. Please make it a question. Don't debate with the debaters, but just get them to debate with each other. So, I'm fine with a very short one-sentence statement of your premise, but then pop out a question. If a-- if a question mark naturally fits at the end of what you said – you have nailed this. Nadine?

### Conspiracy Advocate (CA)
Claim: Well, bribery is already a crime. The far broader concept of corruption that Zephyr has advocated here is one that says any time there happens to be an overlap between a position that somebody who contributes to a campaign advocates and what the candidate advocates-- that's corruption. That's not corruption. That is democracy in action.

We spend money in support of candidates or issues because we agree with the positions they have already taken. When they are in office, they take those positions. They listen to their constituents. And by the way, every study that's been done to try to show a connection between spending and action shows that politicians are most influenced by their party, by their ideology, and by their constituents, not by donors.

### Moderator
Claim: So, Burt Neuborne, your opponents are saying not only do you want to abrogate the First Amendment, which they consider an illegitimate move, but that you're doing it without a very good reason, that the problem isn't what you say it is.

### Scientific Advocate (SA)
Claim: If I had enough money to buy more time on this program-- if I could have 12 minutes and Floyd could--

### Moderator
Claim: What are you offering, actually?

### Scientific Advocate (SA)
Claim: --only have six – I would do much better in this debate.

### Conspiracy Advocate (CA)
Claim: So would I.

### Scientific Advocate (SA)
Claim: And – the fact of the matter is, money buys influence. Why do you think large corporations give to both Republicans and Democrats? You think it's because of seventh grade civics?

### Moderator
Claim: But we're not talking about that kind of-- that kind of political money, where they're giving to the parties. We're talking about a group like MoveOn.org, making a documentary, or--

### Scientific Advocate (SA)
Claim: It--

### Moderator
Claim: --somebody buying an ad in the newspaper.

### Scientific Advocate (SA)
Claim: The idea that you were somehow not influenced by and not enormously grateful to some person who has independently spent money to put you into office is a fiction. There's no difference between contributions and independent spending in the sense that the politician who knows that his or her staying in office depends on continuing to get that money-- that's a politician who can't do what Zephyr said the founders wanted. The founders wanted-- maybe this is an ideal that is impossible to achieve.

But the founders wanted a representative democracy where the representatives would think, "What's good for us all? What is the common good? Not what's my largest donor want? Now, whether or not you could do that – “

### Moderator
Claim: I'm going to go to questions now, and if you can just raise your hand. Sir, right in the middle, you've got a blue blazer on. If you stand up, the mic will come to you.

### Moderator
Claim: My name is David Keating. I'd like to go back to the text for a minute and ask you, this idea that you can limit money or limit speech, if that principle is right, what does that mean to the free exercise of religion and freedom of press? Does this mean that Congress could limit the amount of money spent on religion and publishing?

### Moderator
Claim: Okay. I'm taking it that's a question for the side arguing against the motion.

### Conspiracy Advocate (CA)
Claim: That's a great question.

### Scientific Advocate (SA)
Claim: Do you want to do it?

### Moderator
Claim: And the other side loves the question. Burt Neuborne.

### Scientific Advocate (SA)
Claim: It's a great question. But in each of those situations, you have to answer the antecedent question that I asked, is that is, is it speech, is it religion, or is it the press? Because if it isn't, then you don't get a freedom of-- "get out of jail" card. So if I make up a phony religion and run around and tell people that my religion consists of stealing money from other people so that I can advance my own principles, I would expect anybody in this room and a court to tell me bologna, you're not entitled to be treated as a religion because you are not engaged in religion. And I'm suggesting when you're spending astronomical amounts of money, you're not engaged in speech.

### Moderator
Claim: Let's have Floyd Abrams respond to that point.

### Conspiracy Advocate (CA)
Claim: Well, let me--

### Moderator
Claim: a round of applause, and then –

### Conspiracy Advocate (CA)
Claim: I wanted to repeat-- okay.

### Moderator
Claim: Floyd Abrams.

### Conspiracy Advocate (CA)
Claim: I want to repeat Burt's last line. He said if that's what you're doing, you're not engaged in speech.

The problem that they're addressing is nothing but speech. Their problem is the money goes, and it buys lots of ads. It buys speech. If it didn't buy that, it's nothing. That's their articulation of the problem. It just cannot, in my view, be plausibly argued that this is not a speech issue or not a freedom of speech issue. If you wanted to say to us, there are other interests you're not thinking enough about, or sometimes freedom of speech gets trumped by some national security issue or something like that, you know, we could have that debate. But this debate, we're having a debate now where our opponents are telling us that all these ads aren't even speech, that all this money that they find so offensive, which is going into the purchase of what? Things designed to persuade you.

### Moderator
Claim: Let's let Zephyr Teachout respond.

### Conspiracy Advocate (CA)
Claim: Or a political purpose, whatever the ultimate--

### Moderator
Claim: Zephyr.

### Conspiracy Advocate (CA)
Claim: --whatever the aims are, even taking the most venal aims--

### Moderator
Claim: Okay, Floyd, hang on. I want to let Zephyr respond to some of what you've said already.

### Scientific Advocate (SA)
Claim: So I think we haven't talked enough about what the core purpose of the First Amendment is. I mentioned it briefly. But the idea that the speech, the freedom of speech that I see is a freedom to speak about politics, about any issue in any way you want without government censorship. And we've seen two equivalences here that I think are very dangerous equivalences, and they get sort of snuck in. One is that ads are speech, as opposed to-- and not-- and the other is that constituencies--

### Moderator
Claim: Wait. Just for some clarity, why are ads not-- why are ads not speech?

### Scientific Advocate (SA)
Claim: Well, let me--

### Moderator
Claim: Okay. You're-- just for the radio audience now, your partner is taking this question.

### Scientific Advocate (SA)
Claim: Okay, so my partner's taking this question, although I'm happy to pile on.

### Moderator
Claim: All right. Burt Neuborne.

### Scientific Advocate (SA)
Claim: A metaphor: Suppose I had a huge megaphone or some way to amplify my speech, and I kept turning it up, and I kept turning it, and it kept getting louder, and it kept getting louder. At some point, although I was technically involved in speech, I would be involved in an exercise of power. And so what I'm saying is that at some point spending morphs into power when it is so high--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --that what you're doing now--

### Conspiracy Advocate (CA)
Claim: And then the other--

### Scientific Advocate (SA)
Claim: --over and over and over.

### Conspiracy Advocate (CA)
Claim: That's a completely--

### Moderator
Claim: All right. Hold it, hold it. Burt, you've made that point twice, and I took it once to your opponents. But the fact that you've come back a second time tells me you're not satisfied with the answer and Nadine is ready to go with it. Nadine Strossen.

### Conspiracy Advocate (CA)
Claim: It's not a fair analogy because-- then that's why I reject this drowning out metaphor that's often used by my opponents here, because it is true that if I shouted really loud then maybe you wouldn't literally be able to hear them.

That is literally a drowning out. But to amplify speech by spending more money so that it reaches more people or that it's more effectively created or more persuasive does not drown out anybody else's speech. Moreover, it does not translate--

### Moderator
Claim: Wait. How can you--

### Scientific Advocate (SA)
Claim: The argument they're making is so out-- I want to talk how radical this is because--

### Moderator
Claim: Zephyr Teachout.

### Scientific Advocate (SA)
Claim: --it is against--

### Conspiracy Advocate (CA)
Claim: I love being

### Scientific Advocate (SA)
Claim: --what Constitutional lawyers thought for the first 200 years of this country, and that they recognized the importance of protecting the ability to speak one's conscience did not extend to the ability to spend unlimited money. These are separate ideas. And if we equate them, we really equate them at our peril. And it is very similar to the equation that you just heard Nadine talk about, which is--

### Moderator
Claim: But Zephyr--

### Scientific Advocate (SA)
Claim: --saying that constituents

### Moderator
Claim: --just a reality check on the point that Nadine was making about, there's a point where you can shout louder than anybody else.

Is it just not self-evident that if one-- one point of view has billions-- millions of dollars behind it, putting ads on television-- I know you don't call those speech-- that that does in fact drown out the other side.

### Conspiracy Advocate (CA)
Claim: Wait, no.

### Moderator
Claim: Oh, I'm arguing--

Sorry, that was meant for you.

### Scientific Advocate (SA)
Claim: We enthusiastically endorse that.

### Conspiracy Advocate (CA)
Claim: I mean, that--

### Moderator
Claim: That's never happened before.

### Conspiracy Advocate (CA)
Claim: That could only--

### Moderator
Claim: I've stepped through the mirror.

### Conspiracy Advocate (CA)
Claim: That could only--

### Moderator
Claim: Sorry. Nadine.

### Conspiracy Advocate (CA)
Claim: That could only literally be true in what I assume is a hypothetical situation that somebody literally bought up every single minute of TV time so the other person didn't have a chance to--

### Moderator
Claim: So would that not be a problem?

### Conspiracy Advocate (CA)
Claim: Every study shows and elections show that these ads reach a point of diminishing returns. You know. How often do you turn off the TV or hang up on the robo calls? So there is a diminishing marginal return from extra expenditures.

We are--

### Scientific Advocate (SA)
Claim: And that's why they spend it because they know it doesn't work.

### Conspiracy Advocate (CA)
Claim: --smart enough not to be persuaded just because somebody is advertising more and more.

### Moderator
Claim: Let me go to another question. And by the way, that last question was superb in how it stimulated continuing debate. Sir, right down-- you have a card you're looking at. Were you raising your hand? Yeah, it's you. And if you can stand up please too.

### Moderator
Claim: I actually have a question for both sides. Would I be able to pose?

### Moderator
Claim: No. Just pick one. Pick the best.

### Moderator
Claim: Okay then. Maybe I'm misinterpreting Nadine's point, but what about speech that isn't dissent? I feel like you were kind of implying that what is applicable is only dissent towards the government. And that was it.

### Conspiracy Advocate (CA)
Claim: Okay. Well, by definition, any political speech is going to be dissenting from either-- from one candidate or another candidate from one policy or another policy, right?

You are-- even if ostensibly-- let's say I'm arguing in favor of the Supreme Court decisions protecting free speech, that is to disagree with those who take an opposite position; members of Congress who pass campaign-- limits on campaign spending. So every opportunity to comment on a government policy, by definition, involves the right to dissent.

### Scientific Advocate (SA)
Claim: I just want to also--

### Moderator
Claim: Zephyr Teachout.

### Scientific Advocate (SA)
Claim: --point out what I continue to see happening. So they keep saying this is a debate about reality and talking about the kinds of realities that we see. I think it was explicitly in the most recent Supreme Court decision, a debate about reality. The majority used the word "reality" a lot, and the dissent was talking about what's really happening. And I think your question goes to this, if the First Amendment is for protecting dissent, let's talk about what unlimited money in politics is already really doing in the last four years and what it is really doing in the last four years is corrupting our system so it makes it impossible for candidates to actually do their best job and serve the public.

And that's the reality, not the word dissent, but the reality, the political reality.

### Conspiracy Advocate (CA)
Claim: And I don't--

### Moderator
Claim: Floyd Abrams, quick response.

### Conspiracy Advocate (CA)
Claim: I don't think the last four years reflect anything of the sort. I think we've had a lot of unpleasant disagreeable and, from my own political perspective, outrageous speech, but we haven't lacked for speech, and we haven't lacked for all sides being represented in a public debate. And indeed that happens more and more with the internet and more and more because it is easier for less and less money to get messages out. That's the reality.

### Conspiracy Advocate (CA)
Claim: And more competition.

### Moderator
Claim: I want to remind you that we're in the question and answer section of this intelligence squared U.S. debate. I'm John Donvan, your moderator, we have four debaters, two teams of two, who are debating this motion: Individuals and organizations have a Constitutional right to unlimited spending on their own political speech.

Let's go back to questions. Ma'am, right up there.

### Moderator
Claim: Isn't it if constitutional right is absolute, why would speech be different? Not even true. There is no right to shout, "Fire," in a crowded theater, so, therefore, why wouldn't limitations on spending, even if speech be reasonable with a showing of a compelling interest?

### Moderator
Claim: Ma'am, do you think that, that's what you hear this side arguing-- that the right to unlimited spending on your political speech is absolute? Do you think that's what you're hearing them say?

### Moderator
Claim: There's-- first of all--

### Moderator
Claim: Wait, what was your answer to that?

### Moderator
Claim: I just wanted to

### Moderator
Claim: No, I want to know if you think that's what their claim is.

### Moderator
Claim: Yes.

Yes.

### Moderator
Claim: Yes? Okay. Okay. It's mine, too, and I just-- I want to see if-- are you, in fact, making that argument, that it is absolute and there is no-- there are no exceptions, there is no

### Conspiracy Advocate (CA)
Claim: No, and, first of all, there is a right to shout, "Fire," in a theater if the theater is on fire. You want people to shout it. And by paraphrasing that the way 99 percent of people do wrongly, you miss the central point which answers your question, which is that only if the speech in that case is false and, therefore, it leads to a harm-- directly leads to a harm that can't be averted in any other way, then and only then may you restrict speech as a last resort. So if we could show that there was some harm that is definitely going to occur and can only be averted by restricting speech, then we can do so. That is exactly why we can have laws against bribery even though bribery is committed through speech, laws against extortion.

But there has-- with all the trials there is no evidence that there is undue influence that causes this enormous harm that is positive. It's all speculative, that's why the Supreme Court has talked about the appearance of corruption. It's because there's no evidence of actual corruption.

### Moderator
Claim: All right. Nadine, let's let Burt Neuborne respond to your point.

### Scientific Advocate (SA)
Claim: So let me tell you the two harms, Nadine. The first harm is the destruction of political equality, the fact that we all know we live in a country now where it is a sham to say that we have a fundamental egalitarian democracy. We have a plutocracy that's run by the rich, and that harm seeps into every piece of our democratic fiber, including the alienation that turns people off from democracy and keeps people from voting in the first place. And the second harm is corruption, the corruption that Zephyr talked about, the fact that we have representatives-- who don't have to be bribed. They don't have to be in the same room and get a quid pro quo.

A wink and a nod and a day at the country club is plenty of time to send the message that, "We expect you to support us on this."

### Moderator
Claim: Okay, so--

### Scientific Advocate (SA)
Claim: And I'll ask the last thing, whose telephone call do they take after the election, your telephone call or the guy that gave him $2 million? That's the corruption.

### Moderator
Claim: All right. So, Nadine, you got a direct response to your challenge. Tell us what the harms are that would justify curbing this right.

### Conspiracy Advocate (CA)
Claim: And if you--

### Moderator
Claim: And you got two answers there.

### Conspiracy Advocate (CA)
Claim: --and I disagree with both of them. And let me say that-- so, again, we've had all these trials, there is no evidence, we're just hearing conclusory allegations here, but in 100,000 pages of testimony, and in these cases not a single instance could be proven of that kind of alleged harm, which is exactly why the Supreme Court has said, "Well, we can recognize just the potential appearance or the risk of harm."Another requirement, prerequisite, before limiting speech, as I said, is that the limitation is necessary. If there is a less restrictive alternative that will protect the values that are being asserted, prevent the harm, that's less restrictive of speech, you have to use that. And what we advocate, and the Supreme Court has upheld, is disclosure, immediately disclose, fully disclose where the money is. And we, the people, can be trusted to hold people-- politicians accountable accordingly.

### Moderator
Claim: Another question, sir, yeah, that's--

### Moderator
Claim: Thank you. My name is Theodore Simon and I'm happy to say, which will be evident by the question, I'm a Philadelphia lawyer. And my question goes to the way you frame the question, which is "Individuals and Organizations Have a Constitutional Right to Unlimited Spending on Their Own Political Speech."And whether you reframe it or whether to this side I guess, to the right side of you, would it be any different if it was framed that "For profit corporations," that's "for profit corporations," because you've only alluded to organization, for-profit corporations have a constitutional right to unlimited spending on their own political speech, but more particularly, for their own candidate and campaign spending.

### Conspiracy Advocate (CA)
Claim: The-- well, my-- I'm sorry. I thought you were addressing it to us.

### Moderator
Claim: It is-- it is addressed to you. I'm just-- I'm just questioning whether anybody here has eliminated for profit in their understanding of this motion. I'm fine with the question, but I'm just surprised that you felt the conversation was going in that direction. But Floyd Abrams, why don't you take it?

### Conspiracy Advocate (CA)
Claim: Yeah. There is evidence about what happens with respect to for-profits.

First, I would say, our answer would be the same, just as it would be the same if a legislation were adopted, as this would have-- barring Citizens United itself-- a conservative organization-- from putting on a movie denouncing Hillary Clinton when she was running for president, because it took some for-profit corporate money. So, that blends together. Now, beyond that, the Supreme Court in the Citizens United case referred to the fact that 24 states, as of that time, have laws barring for-profit corporations from expending money on political matters. 26 did not. Had no laws. Anything of that sort. Unlimited spending was allowed. There was no evidence ever-- there is none now-- that the 26 states were more corrupt, less democratic, less responsive than was true with respect to the 24 states.

I'm not surprised by that and I have to confess to you, even if I thought that the 26 states were probably less well-managed, I'd have the same First Amendment view. But the empirical evidence is that it doesn't affect corruption in a state and there's no reason to think that it affects it in the federal government.

### Moderator
Claim: Let's-- let Zephyr Teachout respond to that, because--

### Moderator
Claim: Of course--

### Moderator
Claim: --corruption has been your theme on this one.

### Scientific Advocate (SA)
Claim: Yeah. No, I would-- I also took some issue with the framing of the question. And actually, Floyd alluded to this. He said we might take a-- I might take a different stance if I saw that there was another value that was outweighed. So, I would-- might maybe frame it, you know, "Do the people, through their representative electives, have the power to protect against corruption in ways that don't then infringe upon the core right to dissent and express one's views? or something else-- that I do think these framing questions matter a great deal.

I understood the question to cover for-profit as well, and to be framed in a way to be-- for-profit, non-profit, and individual.

### Conspiracy Advocate (CA)
Claim: Well, and it also covers not-for-profit, because I think I heard Burt trying to carve that out.

### Scientific Advocate (SA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: And we--

### Scientific Advocate (SA)
Claim: Yeah. I don't-- I don't have a problem with not-for-profits speaking.

### Conspiracy Advocate (CA)
Claim: Well, that's what I'm saying. You tried to carve it out of the restrictions, and yet the laws haven't done so.

### Scientific Advocate (SA)
Claim: Well, but--

### Conspiracy Advocate (CA)
Claim: The laws haven't--

### Scientific Advocate (SA)
Claim: --we're not-- we're not debating-- we're not debating whether the statutes were well- drafted. We're debating a proposition. Let me answer--

### Moderator
Claim: Burt, would-- just-- just for the point, would unions also be--

### Scientific Advocate (SA)
Claim: Unions--

### Moderator
Claim: --part of it?

### Scientific Advocate (SA)
Claim: --would be covered too. Of course.

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: Corporations have no souls. The First Amendment is about protecting human dignity. It is a-- it is an obscenity to take one of the sublime protections in human history and turn it into an instrument of protection for managers of these corporations, to use other people's money to advance their own views.

There is absolutely no basis for thinking that a corporation can speak, can pray, can marry, can adopt, can do the things that a human being does-- because what we care about is protecting souls--

### Conspiracy Advocate (CA)
Claim: Burt--

### Scientific Advocate (SA)
Claim: In the First Amendment.

### Conspiracy Advocate (CA)
Claim: Burt – I mean, I-- I've spent most of my life representing large corporations with-- no, with enormous power called the New York Time, and called CBS, and called NPR. I could represent this-- this is a corporation here. Our hosts here are corporations. The National Constitution Center is a corporation. And it doesn't have blood, and it doesn't have a soul. Stop.

### Scientific Advocate (SA)
Claim: Floyd, you're the best –

### Moderator
Claim: And--

### Moderator
Claim: We have time for one more question. Let's bring it down here.

### Moderator
Claim: Richard Phillips. We all-- we laughed earlier at Burt Neuborne's hypothetical about buying more time in this very debate. But I didn't hear a direct response. And I think it's worth asking-- if the purpose of the First Amendment is truly to increase the free exchange of ideas because it's so critical to the health of the rest of the document that we need that free exchange of ideas. If we had begun this debate by measuring everybody's bank accounts and allotting the debate time accordingly, would it have resulted in a free exchange of ideas or a less free exchange of ideas?

### Moderator
Claim: And I want to--

### Scientific Advocate (SA)
Claim: I would certainly have spoken last.

### Conspiracy Advocate (CA)
Claim: I want to answer that by saying--

### Moderator
Claim: Floyd Abrams.

### Conspiracy Advocate (CA)
Claim: --if the government had a law saying that the amount of time for each of us must be equal because otherwise it just wouldn't be fair, that would be a terribly and obviously unconstitutional law.

It isn't fair-- it isn't fair to have a situation in which we get-- I want to posit it in our favor now-- in which we get all the time and they get just a bit. But the purpose of the First Amendment I think is different than you think. One of the results of the First Amendment is more things are said, hopefully more people get educated. But we don't limit the First Amendment if people don't get educated or if less is said. The First Amendment is designed to protect us first from the Congress, the entity that they think should pass laws limiting speech. That's the beginning and almost the end of it.

### Moderator
Claim: Last word in this round goes to Burt Neuborne.

### Scientific Advocate (SA)
Claim: Floyd, you're the best lawyer I know. And what you've just done is twisted. The question was not should we all be equal. No one is suggesting that legislation gets passed mandating strict equality.

The question is, should some of us, 1/10 of one percent of the population be so unequal that we get to dominate everybody else?

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate where our motion is "individuals and organizations have a Constitutional right to unlimited spending on their own political speech." And remember again how you voted before the debate. We're going to have you vote immediately after our closing round in which the debaters will have two minutes each to summarize their positions. Onto round three, closing statements from each debater in turn. Our motion is this: Individuals and organizations have a Constitutional right to unlimited spending on their own political speech. And here to summarize her position supporting this motion, Nadine Strossen, a professor at New York law school and former president of the ACLA.

### Conspiracy Advocate (CA)
Claim: Tonight's debate ultimately turns on the following question: How much faith do we have in our democratic egalitarian ideals?

Are we willing to assume, as our Constitution does, that our fellow citizens can be entrusted with the right to decide which speakers and ideas to accept and which to reject? Are we really going to trust we the people? Sure, many of us have a healthy distrust of powerful, wealthy people in groups. But no one has anything approaching the power or wealth of the United States government. Here's what--one judge put it this way: The government has unlimited resources for touting its agenda. Those on the outside must rely on private wealth to make their voices heard. So it violates democratic egalitarian ideals that we hear our opponents espouse for incumbents to limit what the rest of us may spend to make our voices heard.

Basically you have government insiders trying to justify these limits on all of us, the outsiders, by speculating, well, maybe some people will have dangerous ideas, or they're suspect speakers because they happen to be organized in corporate form. And that might lead to some potential appearance of corruption. But that kind of paternalism has always been rejected in our free speech tradition. We can't say because speech might lead to a risk of crime that it can be suppressed, much less to an appearance of a risk of crime. And we've cited many examples where people-- it's as inaccurate as it is insulting and condescending to say that we are automatically going to vote for the candidate who spends the most money or trust the candidate who's in the pocket of high financiers. So please show your trust in the people by voting for the proposition.

### Moderator
Claim: Thank you, Nadine Strossen.

Our motion: Individuals and organizations have a Constitutional right to unlimited spending on their own political speech, and here to summarize his position opposing this motion, Burt Neuborne, a professor at NYU Law and former national legal director of the ACLA.

### Scientific Advocate (SA)
Claim: Please, show your support for the people by voting, because the people want these laws. Every single law that we're talking about are laws that were overwhelmingly supported by the people and overwhelmingly passed by a representative democracy. It is five members of the Supreme Court and a group of ideologues who are telling us that we cannot have these laws because there is some magic formula in the Supreme Court that tells us that our democracy has to be dominated by the rich. Floyd correctly-- because Floyd is-- has values that I share. We've worked together so many times. Floyd says there's many things wrong with this country, and we should fix it.

We should fix our tax system, we should fix all sorts of things that are desperately wrong. And I tell you, we can't fix it. There is no way that fixing a system that is rigged in favor of the rich-- and if you allow the rich to control who gets elected to fix that system. Our system is broken. It's broken because a few of us have so much power that we can control what the rest of us do, not every time, of course not every election is dealt that way. But over time, and through most of what we do, the rich have an immensely larger political influence than any of the rest of us. And unless we can do something about dealing with that, unless we the people can pass legislation that will limit their ability to spend unlimited amounts to carry out their policies, those are the policies that you had better learn to live with because there will never be a representative democracy in this country that will change those policies until we change the power structure of how we run our elections.

### Moderator
Claim: Thank you, Burt Neuborne. The motion, "Individuals and organizations have a Constitutional right to unlimited spending on their own political speech," here summarizing his position supporting this motion, Floyd Abrams, an attorney who represented the New York Times in the Pentagon Papers case and Senator Mitch McConnell in Citizens United. Floyd Abrams.

### Conspiracy Advocate (CA)
Claim: I want to close with a story and I hypothetical. Suppose we had a situation in which a not for profit or for profit company made a movie denouncing a leading candidate for the presidency of the United States. Suppose it were a crime for that movie to be shown on television, a crime for that to be shown on cable, a crime for it to be financed and shown in either of those places.

That is what the Citizens United case was about. Those are the facts of the Citizens United case. It was a not for profit. It could have been a for profit. That doesn't change what this is about. This is a situation in which once you say that, look, we'll leave it to Congress to draw some lines, and they represent the people. Congress after all is doing the people's work in a representative democracy. Sometimes they are. The view of the First Amendment of Congress is Congress is dangerous. Congress is something we need protection against. Congress is something we have to be really sure doesn't get involved with speech of anyone.

And in this respect, speech includes not just individuals but institutions, labor unions, corporations or the like. So I would urge you that we have really a wonderfully representative audience here tonight. And it is very important that that audience focus on the underlying value of the First Amendment. That value is keep the government out of speech areas. That's what the First Amendment is about. And I urge to you vote yes on this proposition.

### Moderator
Claim: Thank you, Floyd Abrams.

And to repeat the proposition, individuals and organizations have a Constitutional right to unlimited spending on their own political speech. And here to summarize her position against this motion, Zephyr Teachout, a professor at Fordham Law School and former national director of the Sunlight Foundation.

### Scientific Advocate (SA)
Claim: Thank you.

I urge to you oppose the proposition, and I'm also going to tell a story, but it's a much more recent story. I started running for governor in New York on the Democratic party line about two months ago. And so I'm sitting in my office, and I have a staff of six. And some of our job is getting on the fundraising, and some of our job is talking to the press, but there's something that we talk about a lot. I happen to-- I was excited to hear you mention antitrust. I happen to care a lot about taking on the monopolies in our current system. So I am actively opposing the Comcast merger. So because it is 2014 and not 1973, what we talk about is what the risk in my opposing that Comcast merger means because of the potential millions of dollars that could be spent against my campaign, defaming me, telling all kinds of barely true things about me.

So we sit in fear while we talk about that. And because it is not 1972, I'm not-- or I'm not Jack Kennedy, I have to worry about these things. I have to think about, "What is it that I could say that the Koch Brothers could spend unlimited money on?" I'd like to think it's not influencing me, but I will tell you it is hard for it not to influence you, it is hard not to say, "I'm just going to pick one target and not tell the truth about those other targets," because you can feel the potential power of those incredibly wealthy interests wanting to spend money to keep me quiet. So I have a commitment in the campaign, but I have an emotional experience right now of the effect of money in politics, and that's the thing the founders talked about is, "How do we make our representatives care about the public? And if we don't figure out the right relationship between money and power, we are moving towards an oligarchy, not a democracy, and that is the most unconstitutional thing we could move towards."

### Moderator
Claim: Thank you, Zephyr Teachout. And that concludes our closing statements. And now it's time to see which side you, our live audience here in Philadelphia, feels has argued the best. We're going to ask you again-- we're going to ask you again to go to the keypads at your seats and to register your vote on this motion for the last time, "Individuals and Organizations Have a Constitutional Right to Unlimited Spending on Their Own Political Speech." Push number one if you agree with this motion, push number two if you disagree, and push number three if you became or remain undecided. I just need to repeat for the radio broadcast-- I just got a note-- I just need to repeat the text that I just read. I'm just going to do that quickly. And now it is time to learn which side has argued the best. We're going to ask you again to go to the keypad at your seat. Okay. It's back to you.

So if you take the next 10 to 15 seconds to register your vote, and then we will lock it out. And while that's happening, I just want to say a couple of things. One is that about a week ago an email went around inside the offices of Intelligence Squared asking our staff members, several of whom are here tonight among you, for recommendations or our suggestions for staff favorite debates of the nearly 90-- the more than 90 debates we've done now. We wanted to put together a sort of "staff's picks list." I just wanted to say I think that this debate goes to number one in my list tonight. I think this-- what we saw here tonight was spectacular and so hits the ideals of what Intelligence Squared is about. really, really excellent. It was respectful. And it was intelligent. And it took the issues seriously. It took you as members of the audience seriously. And I also want to say that it's never happened before that every question from the audience was good. So I'm going to have to talk to the crowd back in New York about this. But thank you for everybody who asked a question. I also want to say that we would love it if you would Tweet about this. Our hashtag is "Speech Debate." Our handles are at @iq2us and @constitutionctr. That's for "center." Thank you also to Jeffrey Rosen and the National Constitution Center for inviting us here today. And some further thanks because this program was supported by the Daniel Berger Esquire, Programming Fund and the Snyder Foundation for the National Constitution Center, our thank you to them as well, please. If you can get up to New York, it's a short train ride, our regularly scheduled fall Senate starts at the Kaufman Center on September 9. We'll be briefly announcing all of our fall lineup topics soon, but here's a sneak peek at some of what we're looking at debating. Right now we're working with these motions: "Embrace the Common Core," "Iraq is Not Worth Saving," "Income Inequality Impairs the American Dream of Upward Mobility"-- "Legalize Assisted Suicide," and the one we mentioned before, "Genetically Modify Food."Tickets will be available through our website, wwwiq2us.org. And if you can't join our live audience, there are other ways, as we've talked about. You can watch us live or on four.tv and you can listen to the debates on NPR stations, which-- in Philadelphia, as you know, is WHYY 90.9 FM. And we have a mailing list. All of this you can get to by finding us on Twitter and on our Facebook. And we also actually welcome your feedback and topic ideas. And some of the debates that we're putting up in the fall actually came from members of the audience, and we're getting great ideas from all of you. Thank you all for coming. And now, I think it's time to announce the final results. Okay, so it's all in. You voted twice. And remember, the team whose numbers have changed the most between the first and the last vote will be declared our winners.

Our motion is this-- individuals and organizations have a constitutional right to unlimited spending on their own political speech. Before the debate 33 percent of you agreed with this. 49 percent were against. 18 percent were undecided. Those are the opening results. You voted again. Now it's the team whose numbers have changed the most in the second vote. Let's look at the second vote. The team arguing for the motion, in the second vote, 33 percent. They went from 33 percent straight across. They picked up no percentage points. Zero is the number to beat. The team arguing against the motion, their first vote, 49 percent. Second vote, 65 percent. They pulled up 16 percentage points. That's enough to make them a winner.

The team arguing against the motion declared our winner, the motion defeated is this-- Individuals and organizations have a constitutional right to unlimited spending on their own political speech. Our congratulations to that side. Thank you from me, John Donvan and Intelligence Squared US. We'll see you next time.
