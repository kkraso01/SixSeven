# Debate Transcript

Topic: Let's Stop Welcoming Undocumented Immigrants
Motion: Let's Stop Welcoming Undocumented Immigrants

Debate ID: UndocumentedImmigrants-100907


## Round 1

### Moderator
Claim: Welcome. As is often the case, uh, in New York on evenings of public discourse, the event begins with a bad joke. But I’m going to begin this event with a dangerous joke that I overheard on a reporting assignment that I did out in California very recently. And I was in the company of some, of a very diverse group of very successful business people who were sitting around in California talking about issues of the day. And one just was dying to tell the following joke, which I will repeat. It’s not one that I would necessarily tell except in the context of this debate and what we’re going to be discussing tonight. It seems at the Alamo – you know the Alamo – at the conclusion of the defeat of the defenders of that fort in Texas, Jim Bowie – who was one of the defenders – and one of his colleagues looked out the window and saw in the grounds of the fort the victorious Mexicans swarming in. And Bowie turned to his colleague and said, Are we pouring concrete today? The laughter catches in your throat. And Rosenkranz Foundation-Intelligence SquaredUS-Undocumented Immigrants that joke and its relevance, its humor, its whatever that sort of hit on that day was very, very meaningful to me.

Because it really sort of depicted for me, in a visceral kind of way, just how electrifying the immigration debate is, is in America right now. Um, on the eve of an election year, we see an issue in which American culture, American race, American economics, America’s sense of its own notion of freedom, inclusion and what we are as a nation, the actual definition of what it means to be American is all tied up in this thorny knot called the immigration debate. Um, and so it is in that context that I offer that very bad and dangerous joke tonight, um, to set the stage for what we hope will be a very, very lively event. Some of you have come to these before, um, and know the rules of the road. Others I will, um, like to lay out some of the details for all of you. Now, you know, we like audience participation. We like the fact that this is done before a live audience.

You’ll notice this is a radio show here, microphones all over onstage, microphones all over on the side. Um, fill in the empty seats. Move forward. Kind of, you know, get, get collegial. Um, and, uh, of course, as is always the case, turn off your cell phones and beepers. We kinda like the sound track we have for our program here. We don’t necessarily need an addition from Rosenkranz Foundation-Intelligence SquaredUS-Undocumented Immigrants one of your electronic devices. Um, we, of course, want questions from you. You have cards, I believe. Does everyone see their cards that they have at their seat? Um, we’re going to try something a little different on the questions this, this time around. We have pencils and let me just make sure that I get this right. Now, if you have a question fill out your card. Write the question. And unlike other debates, we’re going to do it a little bit differently. At the top either put your name, if you’re comfortable having me read your name or some way of identifying you.

But I’m really, if it’s really hard to identify you I’m probably not going to use your question. So if you want your question used, even if you don’t want your name used, put Donald Duck at the top or something, just so I can at least say whoever said they’re Donald Duck, it’s your question. Cause I’m not going to waste a lot of time going, the person who says that they’re wearing the green shirt in the fourth row. I’m not going to do that, okay? If you want your question answered a name or your name. Um, the ushers will collect your cards and they’ll give you a new card so you can ask as many questions as you like. Um, that is it. But obviously, we want something lively and wonderful and interesting. And, you know, the bar is high here because the debates that, uh, you have very previously attended have been Rosenkranz Foundation-Intelligence SquaredUS-Undocumented Immigrants very, very successful. I’m thrilled to be here. I am John Hockenberry. I, uh, previously you may know my name from, uh, National Public Radio. You may know it from, uh, NBC television. Um, I would like to introduce our sponsor and sort of uber host for this, uh, entire series – uh, Robert Rosenkranz, who is Chairman of the Rosenkranz Foundation and of course the sponsor of this evening’s debate.

### Moderator
Claim: Well, thank you very much, John. Uh, Dana Wolfe, our Executive Producer, and I are very pleased to welcome you to tonight’s Intelligence Squared debate. Immigration will almost certainly be a major issue in the next Presidential election. It’s front page news when Governor Spitzer wants to issue driver’s licenses to illegal, uh, immigrants because these are our de facto identity cards. The very term illegal is emotionally charged – so much so that, uh, some of our panelists insisted on the word undocumented in our resolution. And yet the division and viewpoint does not fall along conventional liberal/conservative lines. In, in classical economics labor mobility benefits both the worker and his employer.

And the gains seem obvious, just by a casual glance at our daily lives. Consider the growing number of immigrant laborers, many from Mexico and Central America, who have taken up Rosenkranz Foundation-Intelligence SquaredUS-Undocumented Immigrants housekeeping jobs, gardening, childcare jobs throughout the New York Metropolitan area in recent years. And then consider the large number of immigrant Ph.D. candidates, many of them Asian and Indian, who study science, engineering, mathematics and go on to key roles in our technology firms. At both ends of the economic spectrum, both the immigrants and those who employ them are better off. Surely this enhances our economic dynamism and global competitiveness. On the other hand, these benefits may come with associated costs, particularly for the unskilled migrants.

Who bears the cost of their emergency medical care, of educating their children, of dealing with increased criminality and social unrest? And isn’t the term undocumented just a euphemism for illegal? And shouldn’t illegality be punished rather than rewarded? In a post-9/11 world don’t we need special vigilance about who crosses our borders? Well, emotions notwithstanding, there are good arguments on both sides and a lot to learn from our outstanding panel. Our moderator is John Hockenberry. He is an author, columnist, veteran broadcast news correspondent and teller of very bad jokes. He holds an array of astonishing, an astonishing a…array of awards or an array of astonishing awards and is the host of a new morning news program on WNYC, which is going to be starting early next year.

Rosenkranz Foundation-Intelligence SquaredUS-Undocumented Immigrants John, the evening is yours.

### Moderator
Claim: Thank you, Robert. I’d like to welcome you all to the second debate of the second Intelligence Squared U.S. series. I want to give you a brief rundown of how the evening is going to go. First, the proposer of the motion – and let me remind you what the motion is. The motion for tonight is: Let’s Stop Welcoming Undocumented Immigrants. The motion tonight is: Let’s Stop Welcoming Undocumented Immigrants. So, first, the proposer of the motion will start by presenting their side of the argument. The opposition will follow. Each person will get a maximum of eight minutes and we will go back and forth from one side to the other. Second, when all six speakers are finished with their opening remarks I will open up the floor to brief questions from the audience, questions that I may have, questions that are motivated by our panelists who may want to address each other directly. Third, when the question and answer is complete, each debater will make a final statement, lasting not more than two minutes per person.

And fourth, after the final closing statement is made you will vote on tonight’s motion with the key pad attached to the armrest at your seat. It looks like this. Look down, you all have one. And fifth, and last, I will announce the results of the audience vote Rosenkranz Foundation-Intelligence SquaredUS-Undocumented Immigrants and tell you which side carried the day. Beforehand, from our panelists let’s start with a pre-debate vote. Let’s do a little base line data here. Pick up the key pad attached to your armrest on the left. Remember this little guy here. For audience members sitting along the aisle to my right, your key pad is attached to the arm rest on your right side next to your neighbor’s. Does everyone have a key pad? All right, when I prompt you, you will press one to vote for the motion, two to vote against the motion or three if you are undecided.

Let’s Stop Welcoming Undocumented Immigrants – are you for, are you against or are you undecided? You may begin voting now. All right. You seem very, very methodical and definitive there. Hmm, I’m very anxious to know the results. And I will reveal the results of your vote a little later in the evening. I will now introduce the panel. Please hold your applause until all six are introduced. We are thrilled to have all six of these people with us. Professor at the School of Industrial and Labor Relations at Cornell University, Vernon M. Briggs, Jr. is the, is speaking for the motion. Executive Director of the Center for Immigration Studies and Contributor to the National Review, Mark Krikorian, is also speaking for the motion. And the John M. Olin Fellow at the Manhattan Institute and contributing Editor to City Journal, Heather Mac Donald, is also Rosenkranz Foundation-Intelligence SquaredUS-Undocumented Immigrants speaking for the motion.

Against the motion, Director of the Cato Institute Center for Trade Policy Studies, Daniel T. Griswold. Speaking against the motion, President and Founder of Border Angels, human rights activist, Enrique Morones. And also speaking against the motion, President and Executive Director of the Asian-American Justice Center, Karen K. Narasaki. All right, let’s begin. As you recall, each speaker will have eight minutes. Beginning tonight, speaking for the motion, Heather Mac Donald.

### Conspiracy Advocate (CA)
Claim: Thank you very much, John. Two principles require that we stop welcoming undocumented immigrants, otherwise known as illegal aliens – respect for the rule of law and respect for facts on the ground. The ongoing violation of our immigration laws has reversed the traditional roles in a sovereign nation. It is now people living outside our border who determine our immigration policy, not Americans. The facts that result from this constant violation are these: a significant portion of the children of illegal Mexicans and Central Americans are adopting an underclass culture, as anyone can verify for himself by looking at social statistics or spending time in heavily Hispanic schools. Until we figure out how to prevent this from happening our unrestricted immigration flows guarantee social problems for years into the Rosenkranz Foundation-Intelligence SquaredUS-Undocumented Immigrants future. Now, on paper, our elected representatives continue to make our immigration rules. In reality, however, the power to determine who comes into the country and on what conditions, the most basic attribute of sovereignty, has passed from Congress to the world at large. A net half million aliens enter the country illegally each year. Once inside, they have enjoyed virtual immunity from any risk of penalties, as well as receiving a host of taxpayer benefits.

Such immunity is now considered an entitlement. Any hint of enforcement, no matter how limited, inevitably provokes a massive outcry from immigrant advocates and immigrants themselves, that the government is behaving unfairly and, indeed, unlawfully. Disapproving headlines will blare from newspapers across the country. Quote: Fear among immigrants spreads, unquote. Mexican Consul Generals will complain bitterly that the government is psychologically abusing their countrymen by causing them to worry about their status. It seems that not only ill…do illegal aliens have the right to live here without being deported, they also have the right to live without thinking that they face even a minimum risk of being deported. This sense of entitlement does a great injustice to the thousands of law-abiding foreigners who are patiently waiting to enter the country legally.

And it makes a mockery of our laws. I would like to ask our esteemed opposing team if they think that anyone should ever be deported for coming into the country illegally or whether they believe that once across the border he should be home free. Now, you may hear from Mr. Griswold tonight that our immigration laws are economically unwise. I and my colleagues vehemently disagree. But even if it were the case that controlling the border was bad economic policy, the sanctity of the law does not rest on whether it meets someone’s idea of optimal economic efficiency. Until the American people decide to change the law it should be respected and enforced. You may also hear tonight that we have tried immigration enforcement and that it has failed and therefore that we have no choice other than to allow the present inflood to continue.

In fact, until a few months ago, there has been almost no immigration enforcement in the interior of the country. In 2004 a mere three firms were issued fine notices for employing illegal aliens out of the hundreds of thousands of such law-breaking employers across the country. To be sure, the country has progressively put more agents on the border. But once an illegal alien got across the border he entered a three million square mile sanctuary zone. This means that mass deportation is not required to revive the effectiveness of our immigration laws. The illegal population has burgeoned precisely because illegals assume they face absolutely no risk of enforcement, as the complaints about psychologically harassing illegal aliens with de minimis enforcement show. Increase that risk even slightly and calculations change. After 9/11, the Department of Homeland Security deported fifteen hundred illegal Pakistanis living in, in New York, leading fifteen thousand more to leave on their own.

A modest increase in enforcement would result in a similar reduction over time of the broader illegal alien population. The second principle supporting tonight’s motion is respect for facts on the ground. Those facts show that unrestrained illegal immigration is producing an underclass culture among many children of Hispanic illegal aliens. Talk to students in any heavily Latino school and you’ll hear something like this – told to me by an undocumented Guatemalan girl in Los Angeles – Quote: "Most of the students I hung out with when I started school have dropped out. Others got kicked out or got into drugs. Five graduated and four homegirls got pregnant." This testimony is perfectly representative. Hispanics now have the highest teen pregnancy rate in the country. Moreover, fifty percent of Hispanic children are born out of wedlock, a rate two times that of whites and three times that of Asians.

The stigma against unmarried child-rearing among teens has virtually disappeared. Hispanics have the highest school dropout rate in the country – fifty percent. And gang life is sucking in large numbers of Latino youth. The incarceration rate of Mexican-Americans jumps eightfold between the first and second generation, resulting in an incarceration rate three and a half times that of whites. Gang counselors in schools from Washington, D.C. to San Diego –

…despair at the fact that younger and younger kids are joining gangs. To be sure, most Hispanic immigrants are industrious strivers who seize every opportunity available to them. But as long as many of the children are assimilating into the underclass and adopting its values, maintaining the current high levels of illegal entry will bring in its wake rising welfare and crime. In conclusion, we should continue to welcome legal immigrants who have respected American law from the moment they entered the country and in the way they entered it. But it is an insult to them to accord the same privileges to so-called undocumented immigrants who have chosen to flout the law. And it is not in the country’s self-interest to do so. Thank you very much.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …despair at the fact that younger and younger kids are joining gangs. To be sure, most Hispanic immigrants are industrious strivers who seize every opportunity available to them. But as long as many of the children are assimilating into the underclass and adopting its values, maintaining the current high levels of illegal entry will bring in its wake rising welfare and crime. In conclusion, we should continue to welcome legal immigrants who have respected American law from the moment they entered the country and in the way they entered it. But it is an insult to them to accord the same privileges to so-called undocumented immigrants who have chosen to flout the law. And it is not in the country’s self-interest to do so. Thank you very much.

### Moderator
Claim: Thank you, Heather Mac Donald, speaking for the resolution. Now, to speak against the resolution, Daniel Griswold.

### Scientific Advocate (SA)
Claim: Well, thank you, everybody, for coming out tonight. Uh, first I want to lodge a protest at the, uh, proposition that we’re debating. It’s a little bit like, uh, Have you stopped beating your wife?, kind of question. I don’t think anybody up here is thrilled about having illegal immigrants in the United States. Our side would like to see them able to come legally. And I’d like you to think of the motion as, uh, Let’s Stop Welcoming More Legal Immigration. And I’d urge you to vote against it. Immigrants have made the United States a prosperous, dynamic and free country. They have throughout our history, they continue to do so today – both on the higher end of the skills spectrum – but I will argue tonight that low-skilled immigrants are also benefiting the United States. There are two powerful economic and demographic trends, two very positive ones, that are driving low- skilled immigration to the United States. On the demand side, our economy continues to create hundreds of thousands of net new jobs every year for low-skilled workers in fields like retail, cleaning, landscaping, food preparation.

And at the same time, the supply of Americans who traditionally filled these jobs – Americans without a high school diploma – has been dropping steadily. We’re getting older, we’re getting better educated. Uh, less than ten percent of Americans, adult Americans, do not have a high school diploma, compared to fifty percent in the early 1960s. 4.6 million fewer Americans are in the work force without a high school diploma today than just a decade ago. So we have a, a structural mismatch between demand and supply in our economy. And yet there’s no legal channel for a peaceful, hardworking twenty-four year old Mexican or Central American to come into the United States legally and fill these jobs that there are simply not enough Americans, uh, there to fill. And yes, we have tried enforcement and it’s failed. We have ramped up real spending on enforcement six-fold in the last two decades, line watch hours at the border eight-fold. We’ve built walls for miles into the desert.

We have gone through periods of increased interior enforcement in the late Nineties and now again. It has made no dent. Enforcement without reform is doomed to fail. It has failed in the past and it continues to fail. You know, we rounded up a few thousand, uh, workers at a chicken processing plant, uh, in Georgia a while back. You know, two thousand down, eight million to go. It’s a futile exercise. There have been perverse consequences. Because of our enforcement those trying to get in are actually, uh, more successful because they’re going through more remote regions in the desert. It’s more dangerous. The death rate has tripled. Three or four hundred people are dying every year for the crime of wanting a better job and trying to cross the border. And here’s the irony: once they’re in they’re more likely to stay. Because of the expense and risk of crossing the border once they’re in they tend to stay.

Traditionally we’ve had a strong circular component to Mexican migration. Eighty percent of them who came here eventually went back home, uh, as temporary immigrants. And we’ve interrupted that now and I think a legalization program would restore that circular flow. The only answer is immigration reform. We need to change the law. This is a broken, dysfunctional law. We need to change the law. You know, uh, and I think we need to both create a temporary worker program and legalize those who are here. We’re not talking amnesty. They would pay a fine, they would serve probation. That’s the penalty for a misdemeanor. It’s not a felony. It’s not a crime to be here. It’s a civil infraction. The punishment should fit the crime. The Immigration Reform and Control Act of 1986, of course, did, did none of that. Uh, but the missing piece was that it had no temporary worker program, no provision for legalizing future workers, and it failed.

Let’s not make that mistake again. Back in the 1950s we had a problem with illegal immigration. We had the Bracero Program but the Visas were insufficient. We dramatically increased the Visas and illegal immigration dropped by ninety-five percent. Our side’s not talking about letting in more immigrants. We’re talking about turning in a flow of illegal and a population of illegal immigrants into a legal flow and population of i…of immigrants. You’ll hear the argument from the other side that this is bad for low-skilled Americans. Well, if you’re twenty- five years old and you don’t have a high school diploma you’re getting it from all sides. The best thing you can do is stay in school. You’ll get a thirty-eight percent raise just over somebody who’s dropped out. So it’s, the answer isn’t to build walls. It’s to encourage people to stay in school.

You’ll hear about the fiscal and social costs and you’ve already heard that. Uh, I just don’t see it. Yes, low-skilled workers tend to consume more in government services than they pay in taxes, but I think the other side exaggerates those costs. The costs are manageable. We can control access to the welfare state. And they’re overwhelmed by the economic benefits to having a more, uh, expansive, uh, dynamic economy. The social costs: You know, Heather talked about this swelling underclass. I just don’t see it. In the last decade the poverty rate is down in the United States. Cri…crime is down by a third from the early 1990s – and this is with a doubling of the illegal immigrant population. The number of U.S. households headed by somebody without a high school diploma has dropped by more than ten percent, uh, in the last decade.

So we have a shrinking underclass, uh, in this country and immigrants are helping to create, uh, opportunities throughout our economy. The answer, my friends, is to fence off the welfare state, not to fence off our country. Let me end by talking a little bit about national security. And I don’t need to remind people in New York how important that is. None of us want to see a repeat of September 11th. I think a sensible immigration reform program would enhance our security and bring order to the border. This is a very important thing. We would begin to drain the swamp of smuggling and document fraud that can facilitate, uh, terrorism. We’d encourage people to come forward, announce themselves to authorities, to cooperate, uh, with the police rather than living in the shadows and being afraid.

And also we would free up resources to go after the real criminals and terrorists. Uh, I think that’s one reason why our Homeland, uh, Security boss, uh, Michael Chertoff, has been such a strong supporter of immigration reform. It would make his job easier. As he told Congress recently, uh, Immigration reform would, quote, "dramatically reduce the pressure on our borders, aid our economy and ease the task of our law enforcement agents inside the country." What in the world is our Homeland Security Department doing using its scarce resources going after janitors and dishwashers and meat packers when it should be going after criminals and terrorists? We need to stop wasting our dollars, manpower and lives in a futile effort to close our borders and turn away hardworking, peaceful immigrants. We need to change the law –

…so that our country can welcome more legal immigrants to help us grow. And let me just end with a world about the rule of law. I’m all for enforcing the law. I’m all for obeying the law. But the law must be reasonable. It must be consistent with how normal people live their lives. In the 1930s we had alcohol prohibition. It made criminals out of millions of people who just wanted a drink after dinner. The American frontier was settled by illegal squatters and instead of clearing them off we passed the Homestead Act. Uh, we need to change the law so that our immigration law better reflects our needs as an economy, our need for a more secure nation and our highest values. Thank you very much.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …so that our country can welcome more legal immigrants to help us grow. And let me just end with a world about the rule of law. I’m all for enforcing the law. I’m all for obeying the law. But the law must be reasonable. It must be consistent with how normal people live their lives. In the 1930s we had alcohol prohibition. It made criminals out of millions of people who just wanted a drink after dinner. The American frontier was settled by illegal squatters and instead of clearing them off we passed the Homestead Act. Uh, we need to change the law so that our immigration law better reflects our needs as an economy, our need for a more secure nation and our highest values. Thank you very much.

### Moderator
Claim: Thank you. Daniel Griswold, speaking against the resolution. I want to remind the audience if you have a question don’t wait. Jot it down on your card, pass it to the ushers on the aisles and you can ask for another card so that, uh, it’s not a one shot deal here. Uh, we definitely want to encourage your questions for the question and answer part of the program. We continue now. Speaking for the resolution, Vernon Briggs.

### Conspiracy Advocate (CA)
Claim: Thank you very much. It’s a pleasure to be here. Please don’t let the other side confuse you. This is not about legal immigration. There’s a difference between legal immigration and illegal immigration. The topic tonight, which the vote is supposed to be on, is illegal im…immigration-- undocumented workers, if you want to call them that – but illegal immigration. That’s the issue and that’s the principle that I’m, uh, uh, that I’m in favor of stopping. Ille…And there are three reasons, basically. And I want to elaborate on each in a moment. The first is that illegal immigration is not a victim…victimless crime.

There are people who lose and lose in big ways. And these are the most vulnerable people in our society – not the privileged, not the well-off, who…whom government is suppo…does a very, a pretty good job of protecting – but the most vulnerable, the unskilled, the poorly educated, the poorly trained, disproportionately youth, disproportionate minority, disproportionately women who bear the, the competition with illegal immigrants. And they’re hurt very badly. Just because some people win and other people lose doesn’t mean it’s on average, nothing happens. It’s a very, it has a very detrimental impact on those who lose. Secondly, and I to go back and talk about a moment, illegal immigration does erode one of the basic pillars of this society – the, the rule of law. And when we make mockeries of our laws we br…we, we engender, we, we, we encourage cynicism about the society in which we live in.

What’s the sense of passing laws if nobody obeys them? And lastly, I want to talk about the fact that illegal immigration exposes in a very obvious way the seamier side of our wonderful democracy. Uh, the willingness of some to tolerate the exploitation of human beings, uh, in our society, to find some ways to rationalize it. And the failure to stop this, these sores allows them then to, to fester and make conditions in this country much worse. It breeds cynicism about what our really core values of this nation are. But before I elaborate on those I want to say briefly how I got involved with this. I was invi…I became involved in this when I was a very young professor teaching at the University of Texas, when a man named Cesar Chavez came through Austin on the way to try to organize farm workers in south Texas in 1966.

And I joined with that movement and I went down to the border for the first time. I was not a Texan. I saw the border and I knew right away that the first day I was on the picket line that this strike was lost. We were overwhelmed by strike breakers and I’m saying to this day those, those people are still not organized in south Texas. And, uh, from those years in the Sixties and Seventies there was no greater spokesman for ending illegal immigration in this country than Cesar Chavez, who sued the Carter Administration for, uh, for its unwillingness to enforce immigration laws before we even had employer sanctions. Just trying to say these people shouldn’t be in here. That was Chavez’s line. And he believed it very strongly in those days when he was actively trying to organize farm workers. And he certainly made a big impression on me for the rest of my life.

It’s also the case that I believe the position that we’re arguing is supported by the overwhelming balance of re…of research and findings about the adverse impact of illegal immigration on individuals and on our society. I want to elaborate on the three points now. First of all, with respect to adverse impact, there are ninety million – in a newspaper article just in last week’s Ithaca Journal – ninety million people that are adults in a population in the United States who only have only a high school diploma or less – ninety million. That’s half of the adult population of the entire country. Of that number, fifty million are in the civilian labor force. Almost one-third of the labor force doesn’t, has only a high school diploma or less. The problem this country faces, as this article makes, discusses very clearly, is that we have an over-supply of unqualified people in the country. It’s not that we have a shortage of unskilled workers that we need undocumented workers.

And that over-supply is the group that are so adversely affected by illegal immigration. Those are the people overwhelmingly who are adversely affected in terms of their wage depression and limited opportunities. They’re the ones who have to compete with illegal immigration, immigrants for jobs. Uh, and that’s the ones we should, would be concerned with – the people that had the highest unemployment rates. The highest unemployment rates in the United States are those people in the high school grades, or high school-less, uh, uh, uh, cohort. Uh, the unemployment rate is, is over, it’s almost six percent for people without high school diplomas and for those people in some groups, even blacks without high school diplomas, it’s all…it’s, it’s twelve percent right now. So it’s hard to make any argument that there is a great shortage of unskilled workers when the highest unemployment rates in the United States are held by those who have the lowest level of education.

Just what we’d expect, but the other side makes it out as if there’s a great shortage of unskilled workers in this country that would document, that would, uh, warrant the, uh, the coming of undocumented workers. That is absolutely not true. Absolutely not true. This, uh, this labor market is in surplus and that’s the problem. Why income levels at the bottom, uh, don’t go up, wages at the bottom don’t go up, why income distribution in this country is coming, uh, increasingly skewed, heading toward greater inequality. It’s, uh, and it’s, it’s a very dangerous thing for a society to have happen to it. Uh, we all know that if undocumented workers were pouring into the professional and legal ranks of this country, if they were coming into the professor ranks or the lawyer ranks or the doctors’ ranks or the business executive ranks, this issue would have been solved a long time ago. We all understand very clearly that this, uh, that the undocumented workers coming into the legal profession or the doctors’ profession five hundred thousand a year, was not good for the doctors in this country or the lawyers in this country who have to invest, uh, invest in their education and training and the, all the rest of it to get to those positions. Undocumented, not legal immigrants, but undocumented, illegal immigrants. But somehow when it comes to low-wage workers, low-skilled workers, farm workers, maids, yardmen and all the rest of these things – landscapers and restaurant employees and hotel employees – people forget about the laws of economics – that, uh, that, that, uh, increasing the supply of those workers when you have unemployment already, of high unemployment rates already in those markets, can only depress wages and working conditions and make conditions worse for those at the bottom of our society, and society.

So, again, this is the first reason. Uh, illegal immigrants will always win in the competition for jobs. They become preferred workers. It’s not that U.S. citizens will not do these jobs. Employers don’t want them. Illegal immigrants will always work for the longest hours, the lowest pay or the worst working conditions because no matter how bad conditions are in this country, they’re infinitely better than they are in the countries that they came from. Remember, two billion people on this planet today earn less than two dollars a day. Two billion – half of all the workers in the world today. That’s what they make. So any condition in this country is way better than what they have had from most of the countries that they’ve come from.

So in the competition for jobs they will always be a preferred worker if employers can have them. My view is they should not be allowed to have access to that supply of labor. That is a, that, that – and that’s what our law says, that’s what our law requires. It’s just we don’t enforce our laws. Secondly, the, the issue of, of, of the rule of law. Illegal immigrants, those who enter without inspection or overstay Visas are creating, are committing, uh, criminal misdemeanors. If they, if they over-stay their Visa – sorry, if they, if they’ve been deported and then come back in, it’s a felony offense. But we don’t enforce the laws. Uh, they get away, so there’s little risk, really in actually following any of those laws.

Since, since 1986 illegal immigrants who come to the United States, um, uh, uh, are not required to work but they do work. Again, the laws that are not being enforced. I’m, I’m real, way behind, I guess, in what I wanted to say. It’s, uh, it’s illegal to use false documents, it’s illegal to, to use somebody else’s identity. It’s illegal to use someone’s else, the Social Security number. All those things have criminal offense but then nobody applies the laws. How many laws are these people of, uh, are entitled to violate without people becoming cynical about our rule of, our rule of law? Uh, uh, driver’s licenses, social services, all the rest of it. Um, uh, the last point I wanted to make was about the, about the, the fragileness of our democracy. Uh, this exposes the seamier side of it by, by allowing illegal immigration to go on. It gives tacit, uh, uh, approval to their presence in our society and to its human, its human smugglers and abusive employers and unsafe work environments. And all those things are, are, go hand in hand with illegal immigration. The result is to encourage millions to keep coming. Um, so that they – and it also--

Thank you. Much more to say.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: Since, since 1986 illegal immigrants who come to the United States, um, uh, uh, are not required to work but they do work. Again, the laws that are not being enforced. I’m, I’m real, way behind, I guess, in what I wanted to say. It’s, uh, it’s illegal to use false documents, it’s illegal to, to use somebody else’s identity. It’s illegal to use someone’s else, the Social Security number. All those things have criminal offense but then nobody applies the laws. How many laws are these people of, uh, are entitled to violate without people becoming cynical about our rule of, our rule of law? Uh, uh, driver’s licenses, social services, all the rest of it. Um, uh, the last point I wanted to make was about the, about the, the fragileness of our democracy. Uh, this exposes the seamier side of it by, by allowing illegal immigration to go on. It gives tacit, uh, uh, approval to their presence in our society and to its human, its human smugglers and abusive employers and unsafe work environments. And all those things are, are, go hand in hand with illegal immigration. The result is to encourage millions to keep coming. Um, so that they – and it also--

### Moderator
Claim: Speaking for the resolution, Vernon Briggs. Thank you very much.

### Conspiracy Advocate (CA)
Claim: Thank you. Much more to say.

### Moderator
Claim: Our next speaker against the resolution, Enrique Morones.

### Scientific Advocate (SA)
Claim: Thank you. Yeah. Buenos noches. Good evening. Shalom. I’m glad to be in, uh, beautiful New York City once again. I wanted to, uh, first of all, thank everybody here and, and for the invitation to share a few moments with you. It’s important that we discuss in a civil manner and, uh, that we talk about the truth about this immigration situation. And I want to find out in the audience, uh, how many Native Americans are here? How many hundred percent Native Americans that are indigenous, that could trace their roots to the tribes that were here thousands of years ago? You know, maybe I might be the only one but I’ve gotta admit, only my dad’s side of the family-- eight thousand years. And on my mom’s side of the family I can only go back to the 1600s. And so it’s just to kind of say that even though this is a great country and I love the United States – I’m a U.S. citizen. I was born and raised in San Diego – my family came from Mexico and it came like most Mexican families. It came legally. And it came, like most immigrants come to this country, looking for a better opportunity. And it was driven by economics. My dad’s job had an opportunity in San Diego and, and we moved to San Diego. And I was born in San Diego.

It’s very important that we look back on the history of this great country. And I don’t think that we’ve had a lot of welcoming, uh, to immigrants, especially if you look at it from the Native American point of view or the people of color point of view. I don’t see very much diversity but we’re all the same race – the human race. And I think it’s important that we treat each other in such a manner. And Cesar Chavez was mentioned a, a moment ago. They’re one of our biggest supporters, the United Farm Workers. And I ask you in your prayers to pray for Elena Chavez who was diagnosed with colon can…cancer just a couple of days ago – Cesar Chavez’s wife. And, uh, they’re, they’re big supporters of our movement and they’ve helped us in, in the efforts that we’re continuing, to have more humane laws. Ethel Kennedy, uh, Robert Kennedy’s wife, is really the one that inspired me to come out of the shadows when we started our work as, as Border Angels back in 1986.

And you’ll see some information on some flyers I have in the back for our all-volunteer organization. What we’re best known for is putting water in the desert – putting water in the desert to save people’s lives. But that’s not the only thing we do. We also were instrumental in the massive demonstrations last year which had three and a half million people take to the streets and say, We want humane and comprehensive immigration reform. We don’t want to have any more deaths on the border. We don’t want to have this hate radio and hate television that many of you are familiar with, that’s really sprung up in the last several years. Border Angels is a non-partisan faith based organization and our mar…what our mission statement says, "If I was hungry did you give me to eat, if I was thirsty did you give me to drink?" Period.

In October of 1994 the United States government decided to build a wall between the United States and Mexico. We protested against this wall. What the government said it’s gonna stop the flow of migrants. And I said, Why would it stop the flow of migrants? The United States invaded Mexico in 1846, took half its territory and there was a treaty that was signed – the Treaty of Guadalupe de Hidalgo – where people were supposed to be able to go back and forth, freely. That was never honored. But there’s nobody alive today that was there when the United States invaded Mexico in 1846. What country has not committed sins? Every country. Every country has racist, every country has people that misinform the public. So let’s stick to the facts. And I want to tell you a couple of stories. In October of 1994 the government put up this wall, called Operation Gatekeeper. And it’s been estimated by the flyer that I have in the back that four thousand five hundred people have died in the last thirteen years.

And that’s an estimate, according to the Border Patrol. But I think the number is closer to ten thousand people. It, whether it’s four thousand, five hundred or ten thousand, people should not be dying because they’re coming here for a better opportunity. Lucretia Dominguez was one of those people. She crossed with two of her children, Jesus and Nora. Jesus, a fifteen year old little boy and Nora, a seven year old little girl. She crossed from Sonora to Arizona. And she crossed the only way she could because poor people cannot get Visas. So when people tell you, Why don’t they just get in line? – What line? There is no line. So she crossed. She crossed with an unethical smuggler, like many of them are – and we’re opposed to that, of course – and a group of migrants. And what happened was, they ran out of water. The smugglers said, "You’re slowing us down. You gotta cross on your own…" They left, she left her behind with two of her children. She literally died in the arms of Jesus, her fifteen year old son. And her sister, his sister Nora was watching this. Two children in the middle of the desert were wandering around with their dead mother there. Thank God the border patrol found them and sent them back to Mexico. Their grandfather, Cesario, who is from Zacatecas, says, I don’t want to leave my daughter out there. So he went out looking for his daughter. He found one body, another body, another body before he found the body of his daughter. So if Cesario can find three other bodies, how many bodies are out there? We think it’s approximately ten thousand people that have died. Not only men, but also children. Marco Antonio Viasenor – he died.

He was a five year old little boy. And when he ran out of water he asked his dad for water. But his dad didn’t answer him. So he asked seventeen other men. They didn’t answer him. Cause all eighteen men had died, including Marco Antonio Viasenor, in the back in the back of a semi-truck in Victoria, Texas. This is the real story of what’s happening right now. It’s inhumane and we can do better than that as a people. We are a great people and we are a great nation. There’s a lot of myths and mis…misinformation that’s out there. And we’ve heard some hateful terms, even in the discussion today-- sucking in, homegirl. This type of terminology to dehumanize people is unacceptable. Jose Luis Cisneros was attacked by three American kids – a hate crime, which is at an all time high right now in the United States. We see the vigilante groups, like the Minute Men, which President Bush has called vigilante, uh, hate groups.

Today is like yesterday. Second and third generation immigrants and half of them are not from Mexico. It was referred to Mexican immigrants. Half of the undocumented people are not from Mexico. They come from other parts of the world for economic opportunity. They assimilate. They learn the language, just like your, like you did in, in the, in the many years that you’ve been here. There was a man that said, They’re not learning the language, they’re not assimilating. They want to just practice their own culture. We gotta stop them.

Arnold Schwarzenegger’s in that category. Maybe we should have sent him back. But then there’s eight million other people that cannot get a Visa. These are poor people looking for a better economic opportunity and they’re sacrificing everything coming across the border. Ninety percent of them come for economic reasons, ten percent come from fam…for family reunification. They already have a relative living here. As Dan mentioned, it’s an economic plus, the undocumented people in this country. They’ll tell you that schools and hospitals are closing. They are. We need health care reform, we need educational reform. But don’t blame the migrants. It’s easy to blame the most vulnerable sector of society. Four percent of the world’s population lives in the United States-- three hundred million people – yet we consume over twenty percent of the world’s natural resources, fifty percent of the world’s illegal drugs. We have thirty percent –

…of the world’s population, uh, uh, environmental damage is caused by American companies. We could do better than that. Crime, the Department of Justice issued a study in which undocumented people are less prone to commit crime and less violent. Criminals are lazy people. Why are they going to cross a border to commit crime? It’s legal versus illegal. If we use that premise all the time we would still have slavery, women could not vote, we’d still have children working in factories. We need to build bridges of communication and triple fences of su…se…of separation. What good is it if we gain the whole world but lose our souls? There’s three and a half million people that have marched for immigration reform. Your grandchildren are going to ask you one day, What did you do when they were raiding families at three in the morning, when, when two people were dying every day crossing the border?

The whole world is watching. Do the right thing. We need humane and comprehensive immigration reform. We’re a better country than that. We’re a better people than that. And it’s important that we practice what we preach. We should love our neighbor. And we were, when we were told to love our neighbor I’m sure it didn’t mean to kill ‘em. Thank you all and God bless you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …of the world’s population, uh, uh, environmental damage is caused by American companies. We could do better than that. Crime, the Department of Justice issued a study in which undocumented people are less prone to commit crime and less violent. Criminals are lazy people. Why are they going to cross a border to commit crime? It’s legal versus illegal. If we use that premise all the time we would still have slavery, women could not vote, we’d still have children working in factories. We need to build bridges of communication and triple fences of su…se…of separation. What good is it if we gain the whole world but lose our souls? There’s three and a half million people that have marched for immigration reform. Your grandchildren are going to ask you one day, What did you do when they were raiding families at three in the morning, when, when two people were dying every day crossing the border?

The whole world is watching. Do the right thing. We need humane and comprehensive immigration reform. We’re a better country than that. We’re a better people than that. And it’s important that we practice what we preach. We should love our neighbor. And we were, when we were told to love our neighbor I’m sure it didn’t mean to kill ‘em. Thank you all and God bless you.

### Moderator
Claim: Enrique Morones, speaking against the resolution, Enrique Morones. If you have questions pass them to the aisle at the end of the row where you are so that we can make sure that we have plenty of questions for the question and answer period. Our next speaker is speaking for the resolution, Mark Krikorian.

### Conspiracy Advocate (CA)
Claim: Apparently I’m here to argue that we should not love our neighbor. But that won’t be the substance of my talk. Uh, the other side is claiming that, uh, the flow of people into the United States is inevitable, that it’s like the tides or continental drift and that we need to lie back and pretend to enjoy it. The fact, though, is that there’s nothing inevitable about, uh, the flow of people from abroad. It’s an artifact of government policy. The analogy they often use is to the fifty-five mile an hour speed limit on an interstate and that it’s unnatural and therefore it has, that’s why people are violating the, uh, speed limit. The fact, though, is that an interstate highway is engineered for a particular speed. It’s designed for seventy mile an hour traffic-- the, uh, angles, the sightlines, the width of the shoulders. No economy, our economy is not engineered for any particular level of immigration.

It can adapt to high levels of immigration, even higher than we have now. It can adapt to dramatically lower levels of immigration. The question is, what are the side effects, what are the consequences, what level of immigration do we want? Through our elected representatives we’ve made a decision – incoherent sometimes as it is – about what our legal immigration policy should be. Given what our legal immigration policy is it needs to be enforced, whatever it happens to be. If it’s changed, if the numbers are increased, decreased, what have you, the, the law needs to be enforced if it’s to mean anything. And there’s two ways you enforce immigration law. One is the conventional method of arresting and detaining and deporting people. We do that. We don’t really frankly do as much of that as, uh, you might think, but we do some of that and we need to do more of it.

But at least as important, if not more important, is the other element of enforcement of any laws-- but specifically in immigration laws-- is to deter lawbreaking, to dissuade those abroad from sneaking in or overstaying their Visas and to encourage, especially the more recent illegal immigrants, to leave and go home. Um, and the welcome that we have, in fact, extended and been extending to illegal immigrants for many years now, uh, it subverts that second element of law enforcement. So what that means is we have two choices-- either focus even more on rounding up, arresting, detaining and deporting people, leaving that as our sole approach to enforce immigration law – or just give up enforcing immigration law and have de facto open borders – which, despite all the disclaimers, is what the other side wants. Now, um, just enforcing immigration law in the conventional way – border patrol agents, uh, immi…uh, immigration agents inside the country raiding work places and homes – relying only on that kind of enforcement can’t work.

Uh, we haven’t actually done all that much of it, uh, but however much we increase it, it can’t be the sole basis of our immigration enforcement approach. We need to have, uh, deterrence and what you might call encouraging voluntary compliance. After all, the IRS doesn’t arrest everybody. It doesn’t, it isn’t in everybody’s, uh, accountant’s office, making sure the rule, the, the forms are filled out properly. Uh, a few people are made examples of, and everyone else - most everyone else, uh, in our country remarkably compared to most places - complies with the law more or less, voluntarily.

And so, what is it that we are doing? What is this “welcome” that we are talking about? What does it consist of? What are we doing to essentially subvert enforcement of our own immigration laws? Some of these things you have already, um, you are familiar with, of course. Uh, Mr. Rosenkranz referred to, uh, Governor Spitzer’s rule on driver’s licenses. Uh, the driver’s license is, in fact, our national ID system. And anything that makes it easy for illegal immigrants to get licenses, means it makes it easy for them to live here and to embed themselves in our society.

Jobs. In 19… It was only in 1986 that the employment of illegal immigrants was prohibited by law. Before that, it was explicitly permitted in something called, not coincidentally, the Texas Proviso, where employers were held, uh, unaccountable for employing illegal immigrants. We did change it in 1986. But contrary to Dan’s claims, we have done nothing to enforce it in the past 20 years. Nothing. Bupkis. We have gone through sort of, uh, cabooky efforts at finding a few people, as Heather mentioned. Uh, in 2003 was the low point of enforcement. And three employers, in the entire United States, were fined for knowing employment of illegal immigrants. We don’t even do basic things like tell employers, that they have submitted a fake or stolen Social Security number, uh, from an illegal immigrant employer…uh, employee. And that matters, because the majority of illegal immigrants work on the books. They actually gave their employers a fake or a stolen Social Security number. We don’t even tell employers and hold them accountable for making sure that that information is correct.

Another example of the “welcome” we extend immigrants is, uh, bank accounts. The Treasury Department, just a couple of years ago…told banks inexplicitly, in writing…that it was OK for them to give bank accounts to illegal immigrants using, um, the Mexican government’s illegal alien ID card. That that was explicitly permitted by the law, and they shouldn’t, uh, be dissuaded from doing that.

Um, another example. In-state tuition. Now, there is not that many illegal aliens going to state universities and getting, uh, in-state tuition subsidies. But symbolically, it’s very important.

It is another part of the “welcome” that we extend illegal immigrants, which subverts our efforts to make whatever our immigration policy is stick.

What we really need in ending this “welcome” is to pursue what I’d like to call a “firewall” strategy. Make it not just difficult to get in the country, which is something we need to do, but also make it hard to gain access to the important institutions of our society…so that it becomes as difficult as possible to be an illegal immigrant. So you can’t get a driver’s license, you can’t get a job, etc. Only in that way can we successful dissuade new illegal immigrants from sneaking into the country, and persuade some significant portion of those to leave. That’s… I describe that as an “attrition” policy. In other words, not magically eliminating the illegal immigration problem, but causing the illegal immigrant population…

…instead of growing every year, to start declining every year. It’s a realistic approach. It’s not a pipe dream. Heather mentioned the Pakistani illegal immigrants after 9/11. But, um, the New York Times and the USA Today just in the past couple of weeks have written about how the new, very modest but real, increases in immigration enforcement are in fact impelling significant numbers of people to get the message - that the party is over, and it’s time for them to go home.

It works. Our research shows we could reduce the illegal population by half in five years, through normal law enforcement methods - not tattoos, not machine guns, not landmines - normal law enforcement, consistently applied. And that’s the key. Normal law enforcement, consistently applied. And not welcoming illegal immigrants with one hand, while we - in some instances - make it harder on the other hand. We need a consistent, unmixed message to illegal immigrants. And you’ll be surprised…

Thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …instead of growing every year, to start declining every year. It’s a realistic approach. It’s not a pipe dream. Heather mentioned the Pakistani illegal immigrants after 9/11. But, um, the New York Times and the USA Today just in the past couple of weeks have written about how the new, very modest but real, increases in immigration enforcement are in fact impelling significant numbers of people to get the message - that the party is over, and it’s time for them to go home.

It works. Our research shows we could reduce the illegal population by half in five years, through normal law enforcement methods - not tattoos, not machine guns, not landmines - normal law enforcement, consistently applied. And that’s the key. Normal law enforcement, consistently applied. And not welcoming illegal immigrants with one hand, while we - in some instances - make it harder on the other hand. We need a consistent, unmixed message to illegal immigrants. And you’ll be surprised…

### Moderator
Claim: Speaking for the resolution, Mark Krikorian. And thank you very much, Mark.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Our last speaker for this portion, speaking against the resolution, is Karen Narasaki.

### Scientific Advocate (SA)
Claim: Thanks. Good evening. While superficially the topic tonight is about “undocumented immigration,” the debate taking place in this country is really a deeper one. And it’s about whether immigrants - legal or not - are bad for America. And if you listen closely to Heather, it’s about whether Latino immigrants specifically are in fact destroying the fabric of our culture.

Now, everybody here actually on stage agrees on one thing, and that is our current immigration system is broken. What we disagree about is what is broken about it, and how best to fix it.

If you vote for us, it’s because you share our belief, that immigrants are in fact integral to who we are as America, and that they and their children are integral to the betterment and future of our country. Indeed, our core values as a nation are constantly renewed by immigrants, who come here seeking freedom and fairness, and opportunity for themselves and their families. The vibrancy and boldness of the youthful “can do” attitude, the spirit of America, is refreshed by immigrants who have the courage, the strength and initiative to leave their homes and their loved ones - and in many cases, uh, as Enrique said - risk their lives to be part of the American Dream.

Throughout our history, there have been people arguing that immigrants are “taking jobs and failing to assimilate.” That immigrants from certain religious, ethnic or racial backgrounds are “culturally unfit or unwilling to be Americans.” That they bring “ignorance, poverty and disease, and threaten the dominance of English.” That’s what was said about the Know Nothings who argued about the Italians, the Irish, the Germans, the Jews, and even the Asians in the last century. And that’s what’s being said by the restrictionists today. Yet, in every case, immigrants and their children built businesses, they learned English, they joined the military - often in the face of discrimination against them, because of their religion or because of their race. Current immigrants are learning English even faster than the past - and are helping to drive the creation of small businesses here in New York and around the country. And as we stand here debating tonight, immigrants and their sons and daughters are in Afghanistan and Iraq, defending American values. And I am talking about immigrants who are not even yet citizens.

Now, restrictionists have consistently been on the wrong side of history. And if you vote with them, it’s because - despite our long experience as a nation - you share their doubt about the power of American culture and American values. Rather than dealing with their very discomforting dislocations - and they are scary, brought about by globalization and the new Internet driven economy - it’s easier to blame immigrants and target them for their fears, as if, if they all went away, magically we wouldn’t have these new challenges.

They hope to keep jobs in America by building high walls. And if we follow their old-school, isolationist prescription, America’s ability to generate jobs and compete in the global economy will fail. Before computers and the Internet maybe, and the globalization of corporations, it might have been possible to lock those jobs in. That’s no longer the case. Even agra business, is moving across borders, with American companies buying farmland in Mexico, because they can’t get the workers they need here in the U.S. And what about…? What does that mean in terms of our food security…that we can no longer fully feed ourselves?

Vernon talked about “class.” Well, it’s true that immigration challenges at all levels, actually. The American Bar Association magazine this month featured a story on the outsourcing of legal work to India. Because the reality is today, with the Internet, even if you keep immigrants out, it doesn’t mean that the jobs are staying here. All of us agree that a system which results in a huge number of undocumented… undocumented immigrants who are extremely vulnerable to the exploitation that the professor talked about, is not good. Because many restrictionists believe that immigrants are the root of these problems, their solutions tend to be reactionary policies that foster division, and actually backfire on communities and American citizens.

I want to be clear. Despite the back and forth, we are not arguing for open borders, and we are not arguing that our laws should not be enforced. What we are saying is let’s be smart. Let’s talk about what laws need to change, so in fact they are enforceable and they make sense. Laws only function when they are humane. And right now, our immigration laws are not humane, and they do not make sense.

As Dan said, we don’t provide a realistic number of visas or permanent green cards. The backlog for spouses and children to join with a legal permanent resident is now five to ten years. Is that smart? That’s why we have so many undocumented immigration. How many people would wait ten years to be with their spouse or child? The backlog for high-tech workers to get a green card, once they have already proven their value to our economy, is now five to seven years. The number of visas available for temporary, low-skilled workers is 5,000 a year. Now we could debate what the numbers should be. But I think most of you would find it strikingly unrealistic to say, that 5,000 is the right number.

Restrictionists talk about attrition through raids and hostile policies. And what they really mean is making our community so uncomfortable that people who - as was pointed out by Mark - are finding much better wages here, are gonna be forced back across the border. We believe that it makes sense to reform the system to provide sufficient channels for legal entry, bring the current undocumented out of the shadows. Nobody really believes we can get 12 million out. And more vigorously enforce existing anti-discrimination, wage and hour, health and safety laws in the workplace. The restrictionists don’t talk about that. That is why undocumented get exploited. That’s why employers like to hire them. Because we are not enforcing the wage and hour, and health and safety. Ten years ago, there was one inspector of restaurants in New York for wage and hour. That is ridiculous. We can reduce incentives without punishing everybody.

For example, what is going to happen now, Bush… The Bush administration is going to now require employers to match their Social Security numbers. And if you don’t… Uh, if you have a “no match,” you have 30 days to clear it up. 30 days? The Inspector General of the Social Security Administration says, “We have at least 17 million errors in the data.” There is only 12 million undocumented. So what does that mean? That means a lot of us…

…are gonna get caught up in that system. So what we are saying is, let’s have reasonable laws.

Mark talks about “licenses.” Well, we are not giving licenses to immigrants to help them. We are giving licenses because we would prefer that everybody driving on the road can get insurance and take the tests and know the rules of the road. By not providing them with licenses…with driver’s license, we are only punishing everybody else who is on the road with them.

At bottom, the question is - do we really want to be the kind of community that refuses emergency health care to someone because they can’t produce a birth certificate or a green card? Do we want to be the kind of community like Riverside, New Jersey, that found that their economic revival of their downtown was reversed overnight when they decided it was best to pass hostile symbolic measures? And now Main Street is boarded up, and property values have tanked.

Thank you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …are gonna get caught up in that system. So what we are saying is, let’s have reasonable laws.

Mark talks about “licenses.” Well, we are not giving licenses to immigrants to help them. We are giving licenses because we would prefer that everybody driving on the road can get insurance and take the tests and know the rules of the road. By not providing them with licenses…with driver’s license, we are only punishing everybody else who is on the road with them.

At bottom, the question is - do we really want to be the kind of community that refuses emergency health care to someone because they can’t produce a birth certificate or a green card? Do we want to be the kind of community like Riverside, New Jersey, that found that their economic revival of their downtown was reversed overnight when they decided it was best to pass hostile symbolic measures? And now Main Street is boarded up, and property values have tanked.

### Moderator
Claim: Speaking against the resolution…

### Scientific Advocate (SA)
Claim: Thank you.

## Round 2

### Moderator
Claim: …Karen Narasaki. Thank you very much. Let’s give a warm applause to all of the speakers who have set the table for the debate. Thanks to all of you.

I am now ready to announce the results of the pre-debate vote, however you are thinking now. This is a bit of a snapshot of what you were thinking just a few moments ago. Before the debate, this is how you voted. For the resolution, 42 percent, let’s stop welcoming undocumented immigrants. Against the resolution, 34 percent. Undecided, 24 percent. Now we’ll have a chance to vote and see if those numbers change, at the conclusion of the debate tonight.

We are now ready to begin the question and answer portion of the program. If you haven’t done so, please write your question down and send it to the aisles, it will get to me, and we’ll have a chance to be a part of this, uh…a part of the, uh…this more lively part of the debate.

Now, if I call on you…I will pick from the cards, I will call on you. Please stand, don’t ask your question until a microphone comes to you. And please identify yourself, if you are a member of the press. You know, I can’t say this enough. Make your question short and to the point. Um, there is only one Charlie Rose. We love him.

I am gonna begin though by offering a question to each side of, uh, the audience here. Um, and I, and I think it focuses on what I consider to be something of the elephant in the room in this whole debate. There are an estimated 12 million undocumented immigrants in the United States. Um, for those of you supporting the resolution - and I’ll address to you, Heather. Uh, under any regime that you have discussed tonight of “law enforcement” or “changes in laws,” how would you define “success”? And in the case that you would achieve that success, how many fewer of that 12 million undocumented immigrants would be in the country, after your regime is adopted? And to this side of the table, under any sort of change in immigration laws that any of you envision, how many of those 12 million would be allowed to stay, conditionally, unconditionally, or under any sort of regime that you envision? I’ll begin with you, Heather.

### Conspiracy Advocate (CA)
Claim: Well, I, uh, I sort of reject the question, John, ‘cause I don’t think it’s necessary to put an absolute number on it. I would think “success” would be, uh, seeing the changed decision making that, that Mark and I spoke about. That once you start enforcing the law, you are gonna see much fewer people come across the border.

### Moderator
Claim: Well, “much fewer”? How, how many fewer?

### Conspiracy Advocate (CA)
Claim: In, in one stretch of Texas that started, uh, not just putting people on the border, but detaining them, uh, after they were apprehended - rather than the current “catch and release policy” - there has been a 50 percent drop in illegal, uh, crossings…in a few months. The Washington Post itself declared that this shows that the way to get control of the border is simply to enforce the laws…on the books. We don’t need new laws; we just need to enforce what’s already there…

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: …something that has not been done.

### Moderator
Claim: So, in five years, if enforcement - under the regime that you are talking about - actually took place, how many “fewer” undocumented immigrants would you expect to be in the United States…down from 12 million?

### Conspiracy Advocate (CA)
Claim: I, I, I really couldn’t predict. But fewer… Any fewer would be a success. Whether it would be half that, uh…I, I can’t say. But the fact is, is that right now, we are sending a message to the, hmmm, billions of people in this world that, once they get across the border, nothing happens to them. If we have an “amnesty,” I can predict what will happen: More will be coming in illegally. That is what the consequences have been of every amnesty…in this country…and in Europe. Uh, that record is quite clear.

### Moderator
Claim: All right. Thank you, Heather. Uh, Enrique, let me ask the question to you. How many would you offer, uh, the chance to stay, of that 12 million?

### Scientific Advocate (SA)
Claim: Well, we have approximately 12 million undocumented people in the country today. And I think that the people that have…that are the real criminals…those are the people that should be in prison and…that which is a very, very slow - a very, very small percentage. So the overwhelming majority of these people would be allowed to stay and become documented. They are not looking for citizenship; they are looking for a document, like the driver’s license. Some sort of document. And a driver’s license doesn’t give ‘em the right to be here, by the way. But they are looking for a document that allows them to stay. It’s an economic plus to have the economic…the, the undocumented people here. There is people from the Wall Street Journal here, Business Week. They have all said that it’s an economic plus. Seven billion dollars a year goes to Social Security just from the undocumented community. The median age of the U.S. population is 40 years old. The undocumented community is 25 years old. We need to replenish our workforce. Uh, uh, uh, uh, you know, what, what’s happening in this country today, it’s very, very important. These people are here to work. When was the last time you saw a Latino on a corner with a sign that says, “We’ll work for food”? You don’t see it. You’ll see ten of them at the Home Depot ready to jump in your car. We need the workers. Unemployment is at 4-1/2 percent in this country. So they are an economic plus. They are, they are a plus to the values of this country. And it’s what that makes this a great country - a United States of America with all the colors. And so I say the 12 million people that are here - with the exception of the criminals, which is a very, very small percentage - they should be allowed to stay and have a pathway to legalization.

### Moderator
Claim: So very close to 12 million undocumented immigrants would be allowed a chance to become citizens, under your plan?

### Scientific Advocate (SA)
Claim: Mm-hmm. To have document. To become documented.

### Moderator
Claim: Right. To become documented citizens. All right. Uh, Gerry Ohrstrom has a question. He is on the left-hand side, in Row H. Could you stand? Please.

### Moderator
Claim: Uh, thank you. Um, Heather, I think I’ll address this to you, my good friend.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Uh, given my utterly blind luck in being born American, by what moral authority can I deny that same opportunity and privilege to any of the world’s other six billion inhabitants? And any of your colleagues are welcome to respond to that as well.

### Conspiracy Advocate (CA)
Claim: I think it is what nations do. They have borders. Uh, if you are suggesting that there should be no more nations in this world, that is a very radical change. Uh, and I don’t think that our, uh, neighbors to our south would agree with that either. You know, uh, Enrique talks about our “inhumane laws.” Well, Mexico has about the fiercest, uh, border patrol that you can imagine, that rounds up Central Americans that are coming in transit to get to the United States. Uh, this has been a prerogative of nations uh, throughout history, to decide who comes in. It, it’s not a “moral” question. It’s simply the right of, of nations to decide who is, is within their borders and who is outside of them. Mexico, uh, you know… Several years ago, a governor of Baja suggested that perhaps Mexico has some responsibility for preventing these deaths, uh, in the desert, because they have a law that requires people leaving the country to exit through lawful ports of exit and entry. Uh, and he suggested that maybe if Mexico started enforcing that law, it would decrease the deaths. And of course, this created a massive outcry, uh, among the Mexican elites, who believe that it is the right of Mexicans to immigrate into the country illegally. I disagree with that and I think, uh, Mexico itself would say the same about people from Nicaragua and El Salvador.

### Conspiracy Advocate (CA)
Claim: John, could I just answer that?

### Moderator
Claim: Yeah. Go ahead, Mark.

### Conspiracy Advocate (CA)
Claim: And I would have to disagree just a tiny bit and say that it is a moral question. That the nation is a moral good. Uh, it often doesn’t behave morally, but that’s a different question. It is, hmmm… Peoplehood is part of what we as human beings have programmed in us; belonging to, uh, a people. And that means that we have a greater moral responsibility to those who are - us - who are, uh, fellow members of our people, than we do to foreigners. It doesn’t mean we have no responsibility to those who live outside our national community, but our priority has to be those who are our countrymen: Just as you feed your children first, before you give money to charity. And so, I would submit that, um, that, uh, arguing that everyone in the world has a right to come to the United States is itself immoral. The argument itself is morally wrong.

### Scientific Advocate (SA)
Claim: John, if I could…

### Moderator
Claim: Uh, Mark Krikorian, thank you very much.

### Scientific Advocate (SA)
Claim: I want to…

### Moderator
Claim: Enrique.

### Scientific Advocate (SA)
Claim: I want to address a couple of quick…

### Moderator
Claim: Enrique Morones.

### Scientific Advocate (SA)
Claim: …quick comments. One about the Mexico part. And that was a, uh, senator, a former… a former mayor of Tijuana that made that statement, Hector Osuna. And the, uh… And, and he is right. We cannot ask of the north what we don’t do in the south in Mexico. And I was just down in Mexico just two weeks ago. And this is a worldwide phenomenon. And Mexico definitely needs to do more, as do the other countries around the world. So that, that… With that being said. But the, the impact of U.S. policies affects the entire world. When you talk about the United States doing something, and it has a cold, it…it sneezes, the entire world - especially the Americas - get a cold. When Mexico does something and it has problems, that stays within Mexico. Mexico doesn’t want the people to leave. They know that the future of Mexico is within Mexico. But the people are starving. We need to, uh, help the United States…help Mexico more develop, and help other countries as well. We have that moral responsibility. Remember…remember what I said about four percent of the world’s population consuming over 20 percent of the world’s natural resources - the drugs and, and all these other things? That greatly impacts the neighboring countries. It’s very, very important. And we should have some sort of a… The, the constitution of Mexico says that we have the freedom of movement. We are not denied the opportunity to go to other…to other countries. But it doesn’t encourage - contrary to what you have seen in these myths - people crossing to other countries without papers. My organization does not encourage that. People should cross…cross in a humane manner. And that’s what we are asking for - humane and comprehensive immigration reform. Comprehensive - that 12 million people get a pathway to, to legal…the document. And humane - having a humane manner in which people can enter, which doesn’t exist right now.

### Moderator
Claim: Enrique, do you…do you believe that anyone who wants to come to America should be allowed to come here?

### Scientific Advocate (SA)
Claim: I think there should be a process that they would go through. That right now, if you are poor, you don’t get that opportunity. And there should be that opportunity. We should have humane laws to address that.

### Moderator
Claim: Karen Narasaki.

### Scientific Advocate (SA)
Claim: Well, I think this is where we get into these false choices. Um, and one of the false choices here is, we either enforce and become a police state, or we let everybody in the world in. That’s not really the choice. I mean, if we want to deal with Mexico… As Enrique says, a lot of the policies…the trade policies and other things… that Americans have done is why…is what drives a lot of immigrants here. That’s why we have a huge refugee population here. So what we need to do is - in addition to looking at what we are doing with the system here - we need to look at, what are our policies around the world? How much help are we giving to Mexico and other countries, who are sending countries? How are we helping them to stabilize their democracies? How are we helping them to grow their economies? I mean, the Philippines is one of the large…the largest sending countries in the world. They get more money from remittances from Filipinos who are around the world…than they get in foreign aid. We have to change that. We have to really think outside the box. It’s not just about punishing people who are here who are looking for a better life, but it’s - what can we do as a nation to change how we approach the problem? Because it isn’t a choice of, we beat up people, or we let everybody in. That is not the choice.

### Conspiracy Advocate (CA)
Claim: But it does sound like that’s the choice. I have yet to hear anybody on the opposing team say whether they think there should ever be any immigration enforcement. Do you think a penalty should ever be levied against somebody who comes…?

### Scientific Advocate (SA)
Claim: We say…

### Conspiracy Advocate (CA)
Claim: …into the country?

### Scientific Advocate (SA)
Claim: As Heather said, we believe in enforcement. And we are not talking about…

### Conspiracy Advocate (CA)
Claim: What would you do?

### Scientific Advocate (SA)
Claim: We are talking about smart enforcement.

### Conspiracy Advocate (CA)
Claim: But tell me what you would do…

### Scientific Advocate (SA)
Claim: But I am talking about…

### Conspiracy Advocate (CA)
Claim: …if somebody comes into the country illegally.

### Scientific Advocate (SA)
Claim: I talked about…waging our health and safety. And I talked about, if we are gonna do…

### Conspiracy Advocate (CA)
Claim: But that’s not immigration laws…

### Scientific Advocate (SA)
Claim: …and if we are going to… And if we are going to de…deportation, I don’t think it should be by raiding people, pre-dawn raids, with people wearing cowboy hats, carrying machine guns aimed at children.

### Conspiracy Advocate (CA)
Claim: So should raids be at noon?

### Scientific Advocate (SA)
Claim: I don’t think that’s who we should be, as a nation.

### Conspiracy Advocate (CA)
Claim: Should people wear different kinds of hats? I mean, I think it’s a legitimate question. I mean, I am not trying to make the joke here, but…

### Moderator
Claim: That’s Mark Krikorian.

### Conspiracy Advocate (CA)
Claim: I, I have to say - and I have been doing this now for more than 12 years, specifically in this job - and I have got to say, I have never heard someone on that side of the debate say, “Yes, this specific enforcement action” - and I am not talking about, you know, criminals, uh, you know, drug dealers or something - regular immigration violation - that “This specific enforcement action is OK. This, I approve of.” I have never found…

### Scientific Advocate (SA)
Claim: Mark… Mark, that is not…

### Scientific Advocate (SA)
Claim: I, I want to answer this question…

### Conspiracy Advocate (CA)
Claim: …a single person ever…

### Scientific Advocate (SA)
Claim: Mark, that is not true. We supported…

### Moderator
Claim: Daniel Griswold.

### Scientific Advocate (SA)
Claim: Yes. Heather…

### Scientific Advocate (SA)
Claim: …we supported comprehensive reform…

### Scientific Advocate (SA)
Claim: …Heather, I, I would…

### Scientific Advocate (SA)
Claim: …which had…

### Moderator
Claim: Well, let…let Karen finish, and then Daniel.

### Scientific Advocate (SA)
Claim: Yeah. And which had tough employer standards…

### Conspiracy Advocate (CA)
Claim: I am talking about actual enforcement, not the…

### Scientific Advocate (SA)
Claim: …that they were done reasonably.

### Conspiracy Advocate (CA)
Claim: …not promises of future enforcement. Is there anything that’s ever happened - any enforcement action in the past say 20 years - that’s, that anyone on your side would be able to say, “Yeah OK, that’s good enforcement. That, I am all for.”

### Scientific Advocate (SA)
Claim: All right.

### Conspiracy Advocate (CA)
Claim: Never. I have never heard a single one.

### Scientific Advocate (SA)
Claim: All right. And I would…

### Moderator
Claim: Daniel.

### Scientific Advocate (SA)
Claim: …I would favor enforcement, if we had a law that was…

### Conspiracy Advocate (CA)
Claim: And who doesn’t? I am very interested…

### Scientific Advocate (SA)
Claim: …if we had a law that was enforceable, and we weren’t throwing money down a rathole, which is what we are doing now. And until recently…

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: But it is enforceable…

### Moderator
Claim: Hold on, hold on one second.

### Scientific Advocate (SA)
Claim: But isn’t it interesting…

### Moderator
Claim: Let’s focus on the specific question. Is there any…? And go down the, the, the, the three of you here on this side - Karen, Enrique and Daniel. Is there any enforcement that you would consider to be “good” enforcement, in terms of immigration? Not, not so much the wage and hour issues that you were talking about - and I take your point. Uh, any enforcement of immigration laws that you would consider to be rational and not “money down a rathole”? Daniel Griswold.

### Scientific Advocate (SA)
Claim: Well, one, the law has to be rational. And our law is irrational. And we have two very different views here…

### Moderator
Claim: Give me a rational law.

### Scientific Advocate (SA)
Claim: A rational law recognizes the reality of the U.S. economy. We need these workers. We are better off with these workers. The reason half a million come a year - and not two and a half million but just half a million - is that’s about the demand of our economy. If we had a law that reflected our needs as an economy, our values as a nation, you would not have, uh, people coming across the border just to work. So…

### Moderator
Claim: So in that case, the regulation would be… If, if, if, you know, Burger King here in, uh, you know, uh, Austin, Texas can guarantee you a job, you get a visa.

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: And if… And if there is no job for you, you can’t just show up on a street corner?

### Scientific Advocate (SA)
Claim: Right. And that would be…

### Moderator
Claim: And that would be a law that you would support…

### Conspiracy Advocate (CA)
Claim: Whatever happens in the market. And the wagering.

### Scientific Advocate (SA)
Claim: And they, and they don’t come, if there is not a job. And it’s very expensive to come here and not have a job and hang around. In the 1950s, we dramatically increased the number of visas. Illegal immigration dropped by 95 percent. That’s our vision. It’s a system that worked in the past. It’ll work in the future. And they are asking you to buy a pig in a poke. “This time, if we just spend enough money, if we just station enough agents on the border, if we just raid enough chickens…”

### Conspiracy Advocate (CA)
Claim: And that’s absolutely false. So you can’t use false statements…

### Moderator
Claim: Vernon…

### Conspiracy Advocate (CA)
Claim: And you can’t just lie to people…

### Scientific Advocate (SA)
Claim: “And, and the discount…”

### Moderator
Claim: Vernon Briggs.

### Scientific Advocate (SA)
Claim: “And the discount stores. It’ll, it’ll work this time.”

### Conspiracy Advocate (CA)
Claim: And the reason… The reason that it…that illegal immigration failed during the 1950s was because we had this awful program called Operation Wetback in the early ‘50s, which was a massive roundup - of which nobody would defend on this side of, uh, of the, of the borders. And that we had a large number of illegal immigrants. When that program ended, because of the massive violation of civil rights, illegal immigration went down. And it wasn’t because we had…we introduced more visas.

### Scientific Advocate (SA)
Claim: Well, illegal immigration…

### Conspiracy Advocate (CA)
Claim: In other words, you are going to acquire…

### Scientific Advocate (SA)
Claim: And it started going up, after the, the ‘60s.

### Conspiracy Advocate (CA)
Claim: Your view requires massive roundups. And I’d actually like to know, from Enrique and Karen, do they support…?

### Scientific Advocate (SA)
Claim: We do.

### Conspiracy Advocate (CA)
Claim: …another Bracero program? Because that’s what he is talking about.

### Scientific Advocate (SA)
Claim: These, these are…

### Conspiracy Advocate (CA)
Claim: Roundup guest workers.

### Scientific Advocate (SA)
Claim: Using that terminology, like Operation Wetback, actually deported a lot of U.S. citizens as well.

### Scientific Advocate (SA)
Claim: That’s right.

### Scientific Advocate (SA)
Claim: If you were Mexican, whether you were born in the United States or not, you were deported. And we have somebody here whose, whose, uh, Mom was in a detention facility during the Second World War. So we cannot accept this type of, of, of, of a situation at all. And, and the guest worker program…

### Conspiracy Advocate (CA)
Claim: Well, that’s what the program is calling for…

### Scientific Advocate (SA)
Claim: When was the last time…?

### Conspiracy Advocate (CA)
Claim: That’s what the program is calling for…

### Scientific Advocate (SA)
Claim: When was the last time you had a guest in your house and you said, “Now I want you to clean the bathroom and mow my lawn”? Either you are a “guest,” or you are a worker. So we need to have some sort of a humane program. We need to have some sort of a humane program which addresses this issue. Another thing that was mentioned about Mexico. It, it is true. We don’t have a border patrol, but the military is down in the southern border, partially funded by the United States, because they are trying to stop the flow right down there, be…before they get into, uh, Mexico. And it’s very important to note, that if the wall had been built from the Pacific Ocean to the Gulf of Mexico on September 10th…September 11th would have happened exactly the same way. One of the solutions that we should be doing is, is working with Mexico, creating bridges of communication, and not triple fences of separation. We know people who have come from the north, from Canada. Yet the National Guard, the wall, the Minutemen, they are on the southern border. So we need to be working… And I don’t want a wall up in the north, I don’t want a wall in the south. We need to be working with our neighbors, and treating them as neighbors, not as enemies. And that’s one of the things that we are looking for. Look at the European common Union, how they have gotten together and improved the economy of all of the countries. A rising tide raises all, all, all ships. And we need to do the same thing in helping…

### Conspiracy Advocate (CA)
Claim: By enforcing the immigration law along the border.

### Scientific Advocate (SA)
Claim: …in helping Latin America. And we send billions to the Middle East, and only millions to Latin America. Help Mexico and the other countries in Latin America develop, and the people will stay. We are still gonna need immigrants here, though. We are still gonna need it.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: But let’s think about it intelligently. Not with all this rhetoric. Not with laughing about people dying at the border. I am the only one that’s here that’s at the border every day. Has seen dead bodies out there. Has picked them up. This is no laughing matter. Our people are dying. It’s inhumane. If the world… The world is watching us.

### Moderator
Claim: OK.

### Scientific Advocate (SA)
Claim: And they are saying, “How could this country allow them to build this wall, and attack a community in the land of the free.”

### Moderator
Claim: Enrique Morones, thank you very much.

### Conspiracy Advocate (CA)
Claim: But let me…

### Scientific Advocate (SA)
Claim: But wait…

### Moderator
Claim: I want to take another question from the audience. Uh, Judith Zucker, I believe, on the right side, Row H. Could you stand, please? Judith? OK. Yes, please. State your question. And, uh, direct it to who you would wish to answer it, please.

### Moderator
Claim: And I believe I asked, uh, a question. _____ in this era of Homeland Security, when we are supposed to be keeping our country safe. Why is it that we have this immigration issue at such an extreme, uh, level at this point? And the irony is very strange to me.

### Conspiracy Advocate (CA)
Claim: Could I take a whack at that?

### Moderator
Claim: Please. Go ahead.

### Conspiracy Advocate (CA)
Claim: Yeah, um…

### Moderator
Claim: Mark Krikorian.

### Conspiracy Advocate (CA)
Claim: The, the… The reason immigration policy is relevant to security now, is not just some opportunistic thing. “Well, 9/11 was a big deal, so let’s concoct some rationale based on ‘security’ to reduce immigration.” Kind of like these lobbyists for “farm subsidies” talk about “food security.” You know, “The, uh, uh, the terrorists are gonna…are, are trying to attack us, so we need subsidies for food security.” No, this is an integral… There is…there is a reason that immigration policy and security are related. Uh, years ago, World War II, they talked about “the homefront.” That was part of the government’s propaganda at the time, and I use that in a positive term…way. Um, and it was designed really… The, the use of the term “homefront” was to get people motivated to, you know, recycle their old tires and not grumble too much about butter rationing. But it wasn’t a real “front”; it was a metaphor. Today, the homefront is not a metaphor anymore, as obviously we all know - it’s the actual front. Because of modern technology, modern transportation and communications and weapons technology, the homefront is the real front. And the number one defensive tool we have - not “offensive” tool, but “defensive” tool - is immigration control. And the fact that we have enormous levels of, uh, illegal immigration. Half of new immigration, mind you, each year’s… Half of each year’s immigration is illegal now. There is 800,000 illegal aliens settled here each year, plus 800,000 new legal immigrants coming from abroad. The fact that we permit this is an enormous vulnerability. Because any system that the Mexican illegal busboy can get through is something that a terrorist can get through.

### Moderator
Claim: All right, Mark. Let’s…let’s focus on this…

### Conspiracy Advocate (CA)
Claim: And the fact is that all of our borders have been used by terrorists.

### Moderator
Claim: Let’s focus on that for just a second. I mean, Judith raises a point that sounds actually quite alarming. And you make the point that if it’s easy to walk into the United States, uh, under whatever pretense you want, um, that we are less secure. But what is the evidence that changing immigration policy will make us more secure? What is the specific threat that will be eliminated? And, and how does it specifically manifest itself in the immigrant population? That I haven’t heard.

### Conspiracy Advocate (CA)
Claim: Sure. Now, good question. Um, we looked actually, uh, after…after 9/11, we looked at the 48 al-Qaeda related terrorists who had either committed criminal acts or who had been arrested before they were able to commit their crimes, starting with the first World Trade Center attack, finishing with 9/11. And there were a lot in between - either smaller attacks, or conspiracies - that were, um, interrupted. And the majority of those people committed immigration violations. The fact is that a more, uh, vigorous, consistent, comprehensive enforcement of the immigration laws would have exposed probably - as far as we can tell - every single major terrorist conspiracy, uh, against the United States. Even when you look at 9/11. The fact is that, four of the hijackers were - in some form or another - illegal aliens. And one of them came to study English, and then just never showed up, and there was no way for us to know. Uh, a couple had overstayed. One had overstayed earlier, and shouldn’t have been allowed back in but was. Others… One of them was an illegal alien and was stopped by the police for driving - whatever it was - 95 miles an hour in a 50 mile an hour zone and nobody checked whether he was legal or illegal. So that… The fact is that, every major terrorist, uh, uh, conspiracy in the United States - every effort at attacking the United States has involved - must necessarily involve immigration law. And has - almost inevitably, and almost always will involve - violations of immigration law…

### Scientific Advocate (SA)
Claim: John…

### Conspiracy Advocate (CA)
Claim: …that if we detect…

### Scientific Advocate (SA)
Claim: …can I respond to that?

### Conspiracy Advocate (CA)
Claim: …we can unravel…

### Scientific Advocate (SA)
Claim: It’s a bunch of nonsense.

### Moderator
Claim: Thank you, Mark Krikorian.

### Scientific Advocate (SA)
Claim: Who is “they”?

### Moderator
Claim: Dan Griswold.

### Scientific Advocate (SA)
Claim: Who is “they”? They were born and raised right here…

### Moderator
Claim: Dan… And we’ll get a response from Dan Griswold. And then you, Enrique.

### Scientific Advocate (SA)
Claim: The last time I checked, not one of those 48 terrorists was a Mexican. They weren’t from Central America, they were from a particular part of the world, for historical reasons…

### Conspiracy Advocate (CA)
Claim: Oh, so we discovered the Arabs first. OK.

### Scientific Advocate (SA)
Claim: …and for historical reasons. Uh, they were not from Central America. None of them snuck across the Mexican border to get into the United States, and yet that was where we were obsessed with our resources. So we were basically guarding our back door, while the terrorists waltzed in through JFK through the front door. It’s not an immigration problem. You know, every day… Today was a typical day. One million people entered the United States. About a million foreigners a day enter the United States legally. The vast majority of them turn around and go home within 30 days or 60 days. That’s our vulnerability. And yet, we are sending these resources down there to catch dishwashers and roofers and people who have no criminal intentions, no criminal records. They just want to come here and work. And you talked about “interior enforcement.” Uh, again, what in the world are we spending all these resources going after businesses and peaceful, normal workers, when the real vulnerability are bridges and nuclear power plants and other infrastructure? That’ why the raids tailed off so much in 2003, it was because we were trying to guard our critical infrastructure. Well, I like McDonald’s, but it’s not critical infrastructure. If they want to hire a worker, I think they should be able to do, and we should create that legal channel. If we had a sensible legalization program, all these problems would be more manageable. We would be more secure, if our Homeland Security Department was going after the real criminals and terrorists…

### Conspiracy Advocate (CA)
Claim: Oh, you want to abolish all employer sanctions. That’s all you want to do.

### Scientific Advocate (SA)
Claim: …and not going after workers.

### Moderator
Claim: Vernon Briggs.

### Conspiracy Advocate (CA)
Claim: That’s what…that’s what you are saying. Uh, uh, uh, the reason we have these, these job sites - and these, these roundups and what have you - is because we have got a law that says they are not supposed to be there. And there are people that it have hurt. There are low wage workers - of all races and ethnic groups. I am not just concerned about Mexicans. I am concerned about people of all races - who are both illegal immigrants and those who are hurt in this country by the…by illegal immigration.

### Scientific Advocate (SA)
Claim: You cannot… You cannot… It was Martin Luther King that said, “You cannot legislate morality.” And once again, they are…they are using fear tactics - tactics of fear. As, as, uh, it was mentioned by Daniel - none of those people were from Latin America. Timothy McVeigh was born and raised in the United States. And there is countless other people - within this country - that have committed terrorist acts. Terrorism doesn’t come from a country; it comes from an ideology. And it comes from the policies that has been exhibited - especially these last few years - in many cases, by this country…and people are reacting to it. Nobody supports terrorism in general. Nobody. We want to stop it. It’s horrible.

### Conspiracy Advocate (CA)
Claim: We want to stop it coming. Is that it, Enrique?

### Scientific Advocate (SA)
Claim: It’s horrible what’s going on. But look at what happened with the Canadian border - with the, uh, the people that… The Millennium Bomber. People that… Toronto, a terrorist cell. These types of situations… We should be working with our neighboring countries, and intelligence - gathering an intelligence, working together. That’s the way that we solve these issues. Just stop blaming… Continuously they are blaming one country - Mexico. It’s not Mexico. It’s, it’s, it’s, it’s an ideology. And let’s start working together. It’s very important that we don’t succumb to these scare tactics…

### Conspiracy Advocate (CA)
Claim: The reason… And that’s why you won’t address the question of undocumented workers.

### Scientific Advocate (SA)
Claim: …and, and, and, and, and… What they are trying to do, is use the politics of fear.

### Conspiracy Advocate (CA)
Claim: No. If, if you want…

### Scientific Advocate (SA)
Claim: And many people in this audience are familiar with the politics of fear. If you look back in your history, the politics of, of fear was, uh, uh, one of the horriblest, uh, times in our history; with the annihilation of so many different people…

### Moderator
Claim: All right, Enrique. I want to move to one, because we are running…

### Scientific Advocate (SA)
Claim: And I think that right now…

### Moderator
Claim: …and we are running short on time here, and I want to get at least another…

### Scientific Advocate (SA)
Claim: But I… Actually, I wouldn’t mind, but I…

### Moderator
Claim: OK. Go ahead, Karen. Go ahead. Karen Narasaki.

### Scientific Advocate (SA)
Claim: And I actually want to, uh, respond to the professor’s question and your earlier question, and that is, uh… In fact, there are some enforcement that we support. We just want it to work. And so, for example…

### Conspiracy Advocate (CA)
Claim: Which?

### Scientific Advocate (SA)
Claim: If I could finish. For example, uh, you know, it… If we are going to have an employer system, uh, of checking - that’s great. But we need to have the database then be accurate. Because it’s a big thing not to be able to get a job, because somebody has fingered you. And if anybody has tried to go straighten out something with the government, you know it’s not an easy task. So we just want to have a system that’s gonna work, where people have the right to challenge. Where the government has an obligation to fix its database. Where employers… Where the sanctions are not so high, that employers are just going to randomly start to racial profile as a way to avoid the problem. And let me say. I mean, one of the things about driver’s licenses. California passed a law a while ago, saying we are not gonna give, uh, driver’s licenses to undocumented. Well, they started denying licenses to Puerto Ricans, because the people working at the DMV didn’t understand who the Puerto Ricans were. They thought - since they couldn’t produce a, um, a green card - that they were illegally here. We cannot put those kinds of decisions…at that level. We need to have a more professional border enforcement. And we need more people. We need better training. Border enforcement is great, and let’s have a citizens commission to make sure it’s done humanely, and to make sure that, that, uh, people are being held accountable for how they act.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: But the bottom line, illegal immigrants don’t work. That’s, that’s…that should be the principle. And if you would say that, I would go along with everything you said. But the bottom line of employer sanctions must be… What we are saying is…that illegal immigrants…do not work in the United States. That’s the law of the United States… since 1986…

### Scientific Advocate (SA)
Claim: But can I tell you?

### Conspiracy Advocate (CA)
Claim: …because they don’t work.

### Scientific Advocate (SA)
Claim: You, you were right… And you were right, that employer sanctions did not work in the ‘90s. Because there was a wink and a nod about really employers wanting them, and issues. Well, you know, the immigrant community has come to grips with that. And there was very hard negotiations between…with labor and Chamber of Commerce and businesses…that was brokered by Senator Obama…to come up with a system that works. That’s all people are asking for.

### Moderator
Claim: All right. And we are reaching a…

### Scientific Advocate (SA)
Claim: We are not saying “no enforcement.”

## Round 3

### Moderator
Claim: …we are reaching a passionate point here in the question and answer. And I want to channel some of those passions into the summing up remarks of all of the, uh, panelists, who are going to give their final pitch for and against the resolution. Speaking now. And of course, remember, the margin of victory for the resolution in the vote before the debate… And we will have a chance to re-visit that vote at the conclusion of the final sum-up. But to conclude in the final rebuttal, against the resolution, Daniel Griswold will speak first.

### Scientific Advocate (SA)
Claim: And those workers who come here illegally are not bad people. They are not “criminals” in the usual sense of the word. They are good, decent, hard-working family people who have run afoul of a very bad law that needs to be changed. You know, the, uh, the proposition here about “welcoming illegal immigrants.” Some welcome. If you want to come here, you have to pay a, a smuggler, a coyote, $2,000, risk your life in the desert, and sometimes not make it and die a terrible death. Live a shadow existence here. Not having full employment opportunities. Not being able to go home and visit your family, uh, on holiday, because you may not get back into the country. Uh, that isn’t “welcoming” them. And these people may be low skilled, but they are not dumb. They’ll respond to incentives. If we give them an alternative - a legal alternative to the current dysfunctional system - I think they’ll obey the law and enter the country legally, as they did in the 1950s when we offered sufficient number of, uh, the Bursaro visas. Allow them to come in in a safe, orderly…

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …legal way, through our normal ports of entry, to assume all the responsibilities and privileges of working in our above ground economy. They love their country. Believe it or not, not everybody in the world wants to live in America. In fact, most people don’t. They love their country, they love their culture and their family, and they want to stay home. And traditionally, back when we had a kind of, uh, “don’t ask, don’t tell” policy of immigration for Mexico - most of them went back home, because that’s where their family is, and that’s where they want to go. Right now, we have a broken law that needs to be changed. I think we should welcome more legal immigrants, and that’s why I urge to vote against this resolution.

And those workers who come here illegally are not bad people. They are not “criminals” in the usual sense of the word. They are good, decent, hard-working family people who have run afoul of a very bad law that needs to be changed. You know, the, uh, the proposition here about “welcoming illegal immigrants.” Some welcome. If you want to come here, you have to pay a, a smuggler, a coyote, $2,000, risk your life in the desert, and sometimes not make it and die a terrible death. Live a shadow existence here. Not having full employment opportunities. Not being able to go home and visit your family, uh, on holiday, because you may not get back into the country. Uh, that isn’t “welcoming” them. And these people may be low skilled, but they are not dumb. They’ll respond to incentives. If we give them an alternative - a legal alternative to the current dysfunctional system - I think they’ll obey the law and enter the country legally, as they did in the 1950s when we offered sufficient number of, uh, the Bursaro visas. Allow them to come in in a safe, orderly…

### Moderator
Claim: Daniel Griswold, thank you very much, speaking against the resolution. Now, to speak for the resolution, in final rebuttal, Heather Mac Donald.

### Conspiracy Advocate (CA)
Claim: Well, we have heard, I think, a lot of, uh, sleight of hand by the opposing team, which is to conflate illegal immigration and legal immigration. They basically have been debating a proposition that is not before us tonight, which is - we should continue welcoming legal immigration. All of our team member is for that. We agree that legal immigration is part of this country’s history. Uh, it is appropriate. It is, uh…it brings values. But, but one of the values that this country stands for, is the rule of law. Uh, if we continue to wink at illegal immigration, I think that we are cutting away at the fabric of what makes this country great. There is nothing “inhumane” about enforcing laws in a color-blind, fair manner. We have yet to do that. Uh, but it is not inherently…

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …“inhumane” to have an immigration law. We haven’t tried it. Uh, when we start, we will be sending a message to people that it is not right to come here. We are working with Mexico. Uh, we are giving them aid. We are working on the border. They have a responsibility. Other countries have a responsibility, it seems to me, to, to, to do something about their own economies, uh, which we are trying to help them with, and to prevent their citizens from trying to come into this country illegally. Uh, again, we are a great country, and part of that is the rule of law. And that currently, the system is broken. The thing to do is to start fixing it, by enforcing it. Thank you.

Well, we have heard, I think, a lot of, uh, sleight of hand by the opposing team, which is to conflate illegal immigration and legal immigration. They basically have been debating a proposition that is not before us tonight, which is - we should continue welcoming legal immigration. All of our team member is for that. We agree that legal immigration is part of this country’s history. Uh, it is appropriate. It is, uh…it brings values. But, but one of the values that this country stands for, is the rule of law. Uh, if we continue to wink at illegal immigration, I think that we are cutting away at the fabric of what makes this country great. There is nothing “inhumane” about enforcing laws in a color-blind, fair manner. We have yet to do that. Uh, but it is not inherently…

### Moderator
Claim: Speaking for the resolution, Heather Mac Donald. Now to speak against the resolution, in final rebuttal, Karen Narasaki.

### Scientific Advocate (SA)
Claim: All we are trying to debate tonight is, what kind of country do we want to be? How do we want to enforce these laws? Restrictionists, for example, object to allowing undocumented immigrants to have bank accounts and pay taxes. They say “that’s welcoming. ” Yet, without bank accounts, these immigrants are vulnerable to criminals who know to rob their businesses or invade their homes because they know they will find a lot of cash. And how does it help Americans to stop immigrants from being able to pay taxes to help cover their share of the cost of building roads or running schools? Isn’t that one of the reasons restrictions give for what they feel is unfair about undocumented immigrants in the first place? Which, by the way, do pay taxes. And in fact, in a recent study that was done on Long Island, for example, immigrants were paying much more of their share of taxes than they were actually using as benefits. So let’s jettison the old way of thinking, because it really hasn’t served our country well. Let’s ask ourselves…

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …do we want to be a country where we turn teachers and co-workers, ministers and nurses and neighbors into immigration police? Or one where we have sense… sensible, realistic immigration flows, with a well-trained border enforcement agency, who are held accountable for following their own laws? One that continues to hold agencies accountable for following the rules when they make decisions about people’s lives, or one that illuminates the systems of checks and balances and sacrifices due process along the way? If you vote for our side, it’s because you believe that it’s time for us to stop scapegoating immigrants, and instead focus on how do we fix the real problems? How do we fix the push that pushes immigrants here? And what do we do with immigrants once they are here, to make sure that our communities are healthy and thriving, and that we continue to be able to compete well in the global marketplace. Thank you.

All we are trying to debate tonight is, what kind of country do we want to be? How do we want to enforce these laws? Restrictionists, for example, object to allowing undocumented immigrants to have bank accounts and pay taxes. They say “that’s welcoming. ” Yet, without bank accounts, these immigrants are vulnerable to criminals who know to rob their businesses or invade their homes because they know they will find a lot of cash. And how does it help Americans to stop immigrants from being able to pay taxes to help cover their share of the cost of building roads or running schools? Isn’t that one of the reasons restrictions give for what they feel is unfair about undocumented immigrants in the first place? Which, by the way, do pay taxes. And in fact, in a recent study that was done on Long Island, for example, immigrants were paying much more of their share of taxes than they were actually using as benefits. So let’s jettison the old way of thinking, because it really hasn’t served our country well. Let’s ask ourselves…

### Moderator
Claim: Thank you. Karen Narasaki speaking against the resolution. Now to speak for the resolution, in final rebuttal, Vernon Briggs.

### Conspiracy Advocate (CA)
Claim: Uh, the current situation we have, of massive user immigration system, breeds widespread cynicism throughout the country by illegals and by citizens about what are American values? Illegal immigrants know they are exploited, but they have no choice but to take the jobs that are offered to them; they are still better what they had where they came from. Citizens are appalled with the lack of concern by their own government… country, uh, on the…about the unfairness of the competition that low wage workers are confronting with the presence of illegal immigrations. Perversely, we has set up a system, where those lawyers - uh, sorry - where those employers who try to follow the immigration, uh, laws of the United States are, are…or who, uh, or law… are put at a competitive disadvantage by firms that are allowed to violate the laws and can under, uh, uh…underbid them and under…and undersell them in the labor market. Currently, by the way, because we don’t enforce our immigration laws, we are, we are basically, well, rewarding law breaking…and, uh, and those who follow the law, they are actually punished. Many years ago, the famous CBS correspondent Edward R. Murrow said, “The duty of journalists is to separate slogans from policies.”

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: I think that’s the duty of scholars also. Tonight, we have heard a lot of slogans from the other side, but no policies. Our position is one of clear policy - not slogans about “scapegoating” and “nation of immigrations” and “who we are as Americans” and all that. We are talking basically here about policy. That if we could…if we could actually begin to enforce our immigration policies, we could then turn to the real issues of what’s pushing people out of these countries, that I would love to discuss. And those are the big issues. But we can’t get to those issues - human rights violations, uh, population pressures, unfair trade policies and all the rest of them - because the system is so out of kilter, because we don’t enforce our immigration laws. We desperately need to do so. The Jordan Commission said, the credibility of the immigration policy can be measured by a simple yardstick. Do people who get in, uh - who should get in, do get in? The people who should not get in are kept out. And the people who are deportable - are required to leave. That’s Barbara Jordan. No racist. And it can’t be said any clearer.

Uh, the current situation we have, of massive user immigration system, breeds widespread cynicism throughout the country by illegals and by citizens about what are American values? Illegal immigrants know they are exploited, but they have no choice but to take the jobs that are offered to them; they are still better what they had where they came from. Citizens are appalled with the lack of concern by their own government… country, uh, on the…about the unfairness of the competition that low wage workers are confronting with the presence of illegal immigrations. Perversely, we has set up a system, where those lawyers - uh, sorry - where those employers who try to follow the immigration, uh, laws of the United States are, are…or who, uh, or law… are put at a competitive disadvantage by firms that are allowed to violate the laws and can under, uh, uh…underbid them and under…and undersell them in the labor market. Currently, by the way, because we don’t enforce our immigration laws, we are, we are basically, well, rewarding law breaking…and, uh, and those who follow the law, they are actually punished. Many years ago, the famous CBS correspondent Edward R. Murrow said, “The duty of journalists is to separate slogans from policies.”

### Moderator
Claim: Thank you, Vernon Briggs. Before our last two speakers, let me remind you of the motion. Let’s Stop Welcoming Undocumented Immigrants. Our final speaker, against the motion, Enrique Morones.

### Scientific Advocate (SA)
Claim: Well, thank you all very much. And I want to pass on my, my love and my, uh, support to, uh, the fact that, that we are all here today. And, and I appreciate the fact that we would going to be able to debate this. Remember that, um… What right do we have to deny anybody to have a better life? What right do we have? We want a… We have a solution that six… Like, three and a half million people demonstrated when they marched in the streets last spring. Like, 65 percent of the country, according to a Gallup Poll, supports it. It’s comprehensive and humane immigration reform. I, I, I keep on repeating this. Many of you, in your history, are familiar with the politics of hate. Shouldn’t somebody have stepped in and said, “We have got to stop this?” Love is in action, and not in words. It’s important that we go and, and demonstrate the best of America. The best of America - the diversity. The whole world used to hold us up and look at us and say, “That’s what we strive to be.” That’s not taking place right now. We want to get back to that. And we can. Sleight of hand. Well, the sources that I have are Business Week, the Wall Street Journal, the Good Book. And I am talking about serious…

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …serious, uh, documentation, and not using this type of rhetoric, this type of dehumanizing language, which only promotes the politics of fear. We want to have the rule of law. I believe in a, in a law from, uh, above - but I also believe in the laws of a country. But remember, sometimes laws are wrong. And we had slaves in this country, and that was a law. Women could not vote, that was a law. Child labor, that was a law. Somebody had to stand up and say, “This is wrong.” And that’s why it’s important that you vote against this motion. It’s wrong what is taking place. And we have a lot of work to do. There is not easy solutions. But you have got to look at yourself in the mirror and say, “Hey, I did the right thing.” When your grandkids ask you, “What did you do when all those people were dying, when the families were being raided, what did you do? Did you do the right thing?” And let’s build a better America. And it’s the immigrants that build a better America. Give those people a humane way in which to enter, and not die at the border - as two people per day are dying. Two people died today. We cannot continue to allow this to happen. We have a lot of work to do - a lot of work to do within this country. It’s a great and generous country.

Well, thank you all very much. And I want to pass on my, my love and my, uh, support to, uh, the fact that, that we are all here today. And, and I appreciate the fact that we would going to be able to debate this. Remember that, um… What right do we have to deny anybody to have a better life? What right do we have? We want a… We have a solution that six… Like, three and a half million people demonstrated when they marched in the streets last spring. Like, 65 percent of the country, according to a Gallup Poll, supports it. It’s comprehensive and humane immigration reform. I, I, I keep on repeating this. Many of you, in your history, are familiar with the politics of hate. Shouldn’t somebody have stepped in and said, “We have got to stop this?” Love is in action, and not in words. It’s important that we go and, and demonstrate the best of America. The best of America - the diversity. The whole world used to hold us up and look at us and say, “That’s what we strive to be.” That’s not taking place right now. We want to get back to that. And we can. Sleight of hand. Well, the sources that I have are Business Week, the Wall Street Journal, the Good Book. And I am talking about serious…

### Moderator
Claim: Enrique Morones…

### Scientific Advocate (SA)
Claim: Let’s practice what we preach.

### Moderator
Claim: …speaking against the motion. Thank you very much. Our final speaker, in rebuttal, for the motion, Mark Krikorian.

### Conspiracy Advocate (CA)
Claim: And I am a bad person. I would love to debate what the level of legal immigration should be, how we should organize it, who we should pick, who we should not. In fact, I have a book coming out in the summer that, uh, addresses that very question from Sentinel, available in July. Um, but that’s…

### Moderator
Claim: But you are a bad person.

### Conspiracy Advocate (CA)
Claim: That’s not the debate before us, though. The question really we are facing, for our purposes tonight is, are we willing to enforce the law? We have a heard a lot of “if’s” and “would’s” and “should’s” and “need to’s” from the other side about enforcement. But I think we all understand that if the Bush amnesty bill that was debated in the Senate this summer had passed, that, um, the commitment to enforcement would last only until the last illegal alien in line got his green card - at which point it would just, like in 1986, evaporate. And a few years after that…

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …we would have a burgeoning illegal population, because the market does not determine illegal immigration - our policies do, in large part - and we would have the same debate, saying “We need to have realistic laws that legalize all the next batch of illegal immigrants.” We need to decide - are we willing to enforce the borders of the United States and the laws determined by the American people through their elected representatives - or do we want, in effect, to abolish American sovereignty and embrace the, say, E.U. or other, uh, model that the other side has used…where we, the American people, no longer decide what our immigration policy is.

That’s not the debate before us, though. The question really we are facing, for our purposes tonight is, are we willing to enforce the law? We have a heard a lot of “if’s” and “would’s” and “should’s” and “need to’s” from the other side about enforcement. But I think we all understand that if the Bush amnesty bill that was debated in the Senate this summer had passed, that, um, the commitment to enforcement would last only until the last illegal alien in line got his green card - at which point it would just, like in 1986, evaporate. And a few years after that…

And I am a bad person. I would love to debate what the level of legal immigration should be, how we should organize it, who we should pick, who we should not. In fact, I have a book coming out in the summer that, uh, addresses that very question from Sentinel, available in July. Um, but that’s…

### Moderator
Claim: Thank you, Mark Krikorian. It is now time to vote. The motion before the House: Let’s Stop Welcoming Undocumented Immigrants. Once again, pick up the keypad attached to the left armrest on your seat. And after my prompt, press “1” if you are for the motion, “2” if you are against the motion, or “3” if you are undecided. All right. Please cast your vote now. Thank you, voters. Thank you, audience. And I want to thank the debaters and the audience for their good work. This is a terrific discussion. Much, much more to discuss. Before I announce the results of the audience vote, I want to, uh, take care of just a few things up here. The next Intelligence Squared U.S. debate will be on Tuesday, October 30th, right here at Asia Society and Museum. The motion to be debated at that time is - is Russia…? “Russia is becoming our enemy again.” That’s the motion. And it will be moderated by the Economist’s Edward Lucas. The panelists for the next debate are: For the motion, Staff Journalist in Residence at the Foundation for Defense of Democracy’s Claudia Rosett; Foreign Affairs columnist for the Wall Street Journal Bret Stephens; and the Annenberg Chair in International Communication at the Institute for World Politics, J. Michael Waller. Again the motion will be speaking: Professor of International Affairs at the New School, Nina Khrushcheva; Professor of Political Science at Columbia University Robert Legvold; and Vice President for Studies of Russia, China and Eurasia at the Carnegie Endowment for International Peace, Mark Medish. I know that many of you that were here tonight will be very interested in that debate, and please join us for that. An edited version of tonight’s Intelligence Squared U.S. debate can be heard locally on WNYC-AM 820, on Sunday, October 21st, at 8:00 P.M. Please check your local NPR member station listings for the dates and times of broadcast outside of New York City. Mark, you didn’t even let me, and I had to plug all ready for you. And copies of, uh, books of the panelists… Vernon Briggs’ book Mass Immigration in the National Interest, Heather Mac Donald’s The Immigration Solution, are on sale upstairs in the lobby. And you can also purchase DVD’s from previous debates here tonight, or from the Intelligence Squared U.S. website. And now, the debate results. After our debaters did their best to sway you, you voted… Uh, before the debate, you voted 42 percent for. After the debate, 60 percent for the motion. Before the debate, 34 percent against the motion. After the debate, 37 percent against the motion. Before the debate, 24 percent of you were undecided. After the debate, 3 percent were undecided. Congratulations to those supporting the resolution.

### Conspiracy Advocate (CA)
Claim: Yeah, and thank you.

### Moderator
Claim: The House is adjourned. Thank you very much. I am John Hockenberry.
