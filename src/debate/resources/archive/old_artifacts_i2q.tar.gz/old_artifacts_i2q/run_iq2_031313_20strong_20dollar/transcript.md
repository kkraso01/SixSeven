# Debate Transcript

Topic: America Doesn't Need A Strong Dollar Policy
Motion: America Doesn't Need A Strong Dollar Policy

Debate ID: 031313%20strong%20dollar


## Round 1

### Moderator
Claim: At this point in the evening, just before we begin, I like to bring out to the stage the gentleman responsible for bringing Intelligence Squared U.S. to the United States. He is chairman of Intelligence Squared U.S.-- Bob Rosenkranz. So what Bob normally does is he takes a minute or two to talk about how we got to choosing this topic and where we think the chips fall in the argument. So let's talk, Bob, with the side that's arguing for the motion, and this motion is-- and against. It's a double negative. They are-- the U.S. does not need a strong dollar policy. And is that basically the same as saying no policy is needed, or does it mean they're asking for a weak U.S. dollar?

### Moderator
Claim: Well, I think what they're saying is that the price of the dollar is a price like any other. It's determined by supply and demand. The dollar is strong right now against the yen and against the pound. It's weak against the euro. And this is just normal economic forces operating. They're probably going to say that at times like this, with the U.S. economy weak, a weaker dollar is actually helpful, because it makes imports more expensive, makes exports cheaper, and therefore encourages domestic growth and domestic employment.

And so they would argue that we should just let the dollar go where it goes, and I think there's a point here, which is that the government can control interest rates or they can control the price of the currency, but they cannot do both. So a strong dollar policy is essentially an open mouth policy, and it's an open mouth with no teeth.

### Moderator
Claim: All right. And on the other side of the argument, the team that's arguing for a strong dollar, what do you expect to hear from them?

### Moderator
Claim: Well, I expect to hear from them the importance of the role of the U.S. dollar as a reserve currency. When we were on these enormous fiscal deficits for the government and trade deficits, in order for them to be sustainable, foreign central banks have to be willing to hold the overwhelming majority of their reserves in the form of U.S dollars.

And if we pursue a policy that's indifferent to the value of the dollar or, worse, deliberately tries to trash the dollar, they're going to lose confidence. The result will be rising interest rates in the United States, an economic slowdown, and disaster for the U.S. government, which has so much debt outstanding.

### Moderator
Claim: So if you actually want a track record here, there's a lot of history that both sides can cite which makes the point that this has been going on for a long time. So why bring this to the stage tonight?

### Moderator
Claim: Well, I think tonight we were stimulated to do this in part by the partnership that we have with the Richmond Center at Columbia. It's a joint venture of their law and business schools. And we collectively felt that this was very timely. You can't pick up a newspaper without seeing some kind of discussion about the, quote, artificial strength of the U.S. dollar versus that of our biggest trading partner, China's renminbi. So there's a lot of talk about trashing the dollar relative to China's currency.

And then the efficacy of the federal government or the Fed's policy on printing money, quantitative easing, is, again, a very hot policy debate right at the moment. It's clearly fueled a stock market rally. It's fueled a turnaround in the housing market, all of which are good things. But clearly whether in the long run it's going to result in a decline in the value of the dollar, and does that really matter?

### Moderator
Claim: We have four debaters who are raring to go on this. Their opinions, I know from talk to them, are very strong, and they're a little bit revved up, so let's bring them out to the stage.

### Moderator
Claim: Indeed. Thank you.

### Moderator
Claim: Have a seat, everyone. And I would just like to invite one more round of applause for Bob Rosenkranz for doing all of this. George Washington, Andrew Jackson, Ulysses Grant, Abraham Lincoln: four strong leaders, three of them generals, all of them presidents, and all of them get to have their faces on our money, because we like our leaders strong. But what about the greenbacks that those faces decorate? Do we want those dollars to be strong too? Of course we do, we normally say. A muscular dollar is a good thing. Or is it a goal that is greatly overrated?

Well, get ready to get current on currency. Yes or no to this statement: America doesn't need a strong dollar policy, a debate from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters, two against two, who will be arguing for and against this policy: American doesn't need a strong dollar policy. Our debate goes in three rounds, and then the audience votes to choose a winner, and only one side wins. Let's meet our debaters. On the side arguing for the motion that America does not need a strong dollar policy, Frederic Mishkin, a professor at Columbia Business School and the former governor of the Federal Reserve. His partner is John Taylor. He is chairman and founder of FX Concepts. against them, saying that America does need a strong dollar policy, Steve Forbes. He is chairman and editor of Forbes Media. And his partner is James Grant, editor and founder of Grant's Interest Rate Observer. And I'm going to introduce them again. What we just did is going to be used for a television broadcast, and now I'm going to introduce them again, and this will actually be used for our radio broadcast, so your continued enthusiasm and utterly spontaneous applause is working perfectly well. Our motion is America doesn't need a strong dollar policy. Let's meet the team arguing for the motion. First, let's welcome Frederic Mishkin. And, Frederic, and we're going to call you "Rick" is your-- is how you like to go, okay. You're a professor at Columbia Business School. You were a member of the Board of Governors of the Federal Reserve. You used to go around the country giving a talk on the issue of whether a certain amount of inflation falls into a comfort zone.

The title of your talk was "Comfort Zones, Schmomfort Zones." Now, this word, " Schmomfort," this is a technical economic term that you--

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: --Yeah, well, we're hoping that all of you will keep it in plain English tonight. Can we count on you for that?

### Conspiracy Advocate (CA)
Claim: Not necessarily. I thought to make this interesting, I'm going to do the debate both in Yiddish and actually-- I was the first person to do that in a Federal Reserve speech, but I also used Latin in this speech. So I'll do it in both languages and see how it goes.

### Moderator
Claim: Thank you. Rick Mishkin, ladies and gentlemen. And your partner is John Taylor. Ladies and gentlemen, John Taylor. John, you are also arguing that America does not need a strong dollar policy. You are chairman and founder of the investment managing company, FX Concepts, "FX" being shorthand for "foreign exchange."You've been watching the markets-- currency markets for over 40 years from back in a time when-- before the euro there were French francs, and German deutschmarks, and Greek drachmas, and they were all very pretty colorful currencies, do you miss those guys?

### Conspiracy Advocate (CA)
Claim: I sure do. They were fun.

### Moderator
Claim: They were fun, and they were pretty. Ladies and gentlemen, John Taylor. Our motion is "America doesn't need a strong dollar policy." Now, here, arguing against that motion, that means they're arguing for a strong dollar policy, first let's welcome Steve Forbes. Steve, you're chairman and editor-in-chief of Forbes Media. But what thrills all of us up here is that you are the only person on this stage to have once hosted "Saturday Night Live." Is that true? And I think that's an event that you-- you guys never did that, right, on the opponents' side?

### Conspiracy Advocate (CA)
Claim: I'm a wild and crazy guy.

### Moderator
Claim: Okay. Steve, you are also the only person on our stage to have run for president of the United States twice. If you had won either of those times, what would this debate be about tonight?

### Scientific Advocate (SA)
Claim: Why the Gold Standard worke and why Rick and John are now in favor of it.

### Moderator
Claim: Ladies and gentlemen, Steve Forbes. Your partner is James Grant. You're also arguing against the motion that "America doesn't need a strong dollar policy." You're also for a strong dollar. You're editor and founder of Grant's Interest Rate Observer a financial markets journal. Now, during the 2012 election cycle, Ron Paul, who, to put it lightly, is not a big fan of the Federal Reserve, dropped your name as the potential chairman of the Federal Reserve. What would have been the outcome of that?

### Scientific Advocate (SA)
Claim: There would be fewer employees at the Fed.

### Moderator
Claim: Fewer employees. Ladies and gentlemen, James Grant. And I like that we're seeing a certain economy in the words tonight and the language so far tonight.

So our motion is "America doesn't need a strong dollar policy." As always, we ask you, our live audience, to act as our judges. By the time the debate has ended, we will have asked you to vote twice, both once before the debate and again after you've heard the arguments and the team whose numbers have moved the most will be declared our winner. So let's have you go to our preliminary vote. Let's register your preliminary vote. If you go to those keypads at your seat, our motion is "America doesn't need a strong dollar policy." If you agree with the motion, if you think America does not need a strong dollar policy, you push number one. If you disagree with the motion, you push number two. That means that you fell America does need a strong dollar policy. And if you're undecided, which in our forum is a perfectly reasonable starting position, push number three. You can ignore all of the other keys. They're not live. And if you push the key incorrectly, just correct yourself, and the system will lock in your last vote. And what happens at the end of the debate, soon as the debate is-- the third round is over, you vote again, and then about one minute later, thanks to the miracle of computing, we instantly are able to declare a winner.

So let's get on to round one. Our motion is "America does not need a strong dollar policy." And here to argue first for the motion, Frederic “Rick” Mishkin, professor of banking and financial institutions at Columbia Business School and a former member of the Board of Governors of the Federal Reserve.

### Conspiracy Advocate (CA)
Claim: So just to start, I have to tell you I went to Oxford for a year, and my mother, of course, I was a New Yorker, she said, "How come you still talk like a New Yorker?" So it didn't work. But I never actually went to Oxford Union debates. And this is actually styled after it. I wish I had. So what I'd like to do first is just to talk about the way that we're going to branch out in terms of my teammate and I. I'm going to focus first on the domestic economy. And actually because of what I do for a living, both in terms of the research I've done and the fact that I was a policy maker at the Federal Reserve, and my teammate John Taylor is going to focus on the international ramifications of a strong dollar policy.

So let me actually go out and make two points. And the first point is that when we think about what is good policy, I'm going to say what is a good policy for the American economy. And in particular, the first thing we have to do is ask where are we right now? And two things that I want to talk about is where are we in terms of our business cycle, where are we in terms of unemployment? Not very good. We have unemployment rate of 7.7 percent. People are out there struggling. And furthermore, we're in a situation where we also have inflation which is actually too low, so inflation right now is actually running in the preferred measure, 1.2 percent, which is below their target level. So in fact we're in a situation where we're not doing as well as we'd like on either component of what we think s important in terms of stabilizing the economy. Furthermore, the economy is not growing that fast. It's been growing very, very slowly, hasn't really picked up yet. So we're in a situation with a weak economy and actually inflation, which is on the low side. So now let's ask what would a strong dollar do?

Well, a strong dollar would actually mean that the currency would go up in value; that would make American goods and services more expensive; if they're more expensive people will buy less of them; that foreigners are not going to buy our goods and services the way they did before. What will that do? That will actually end up lowering the demand for our goods and services; as a result, our economy would actually weaken further. Is that what we want? Absolutely not right now, because we'd actually get an economy with higher unemployment and actually inflation, which would be even lower, which has been trending down, it'll go actually down lower. So it's not the right policy at this particular point in time. And so, in that sense, I think that it's a very bad policy to think that what we need to do right now is to strengthen the dollar. So that's point one.

Point two is a little bit more subtle and I'm going to be a little more academic here, that I'm actually going to argue that it's a mistake to have any dollar policy, whether a strong one or a weak one. Why? Because what policy should focus on is stabilizing the economy; we should use our tools, both in terms of monetary policy and also fiscal policy, to actually stabilize the economy. At the current juncture we're in a situation where inflation is on the low side, we're actually in a situation where unemployment is on the high side, so in this case, actually, we would think that we don't want to have a strong dollar. In fact, if our policies are expansionary, they might actually produce a weaker dollar; however, there are other circumstances where, in fact, a strong-- having tight policy would be the right thing to do. In particular, we raise interest rates rather than keep them low. And that would be a situation where we have a lot of inflation. And we've been in periods where, in fact, we've had high inflation, very worried about it, and in that situation we would want to have tighter policy, either higher interest rates for monetary policy or tighter fiscal policy. That would also result in a stronger dollar, then that would be okay, that would work in the right direction.

A stronger dollar would weaken the economy, actually help lower inflation, and indeed in periods where we actually had to go out and control inflation we actually needed to go to policies that result in a strong dollar. The point here is that in a situation where you focus on the dollar, you may very well get it wrong because that's not the ultimate objective for policy makers. The ultimate objective for policy makers should be to have a very strong economy. So I'm going to end a little early, I'm told I get a little points for ending a little early. But I made those two points and clearly there'll be a lot of other discussion on these issues, maybe even the gold standard, which would be fun. I have bad news for you, Steve, your wish is not going to be fulfilled. I'm not a big fan of the gold standard. I'm sure we'll discuss that later. But with that, why don't I leave it to the other side?

### Moderator
Claim: All right. Thank you, Rick Mishkin. So your economical with time, as well, that's very good. Our motion is America doesn’t need a strong dollar policy, and here to argue against the motion, James Grant. Sorry, I was-- I was looking at a page that didn't have your name on it and I thought, "One of us is wrong," but it was me.

### Scientific Advocate (SA)
Claim: I forget it-- I forget it sometimes myself.

### Moderator
Claim: I thought we had gone out of order, but it's my fault. I apologize. Our next debater against the motion America doesn't need a strong dollar policy, ladies and gentleman, James Grant; he is the editor and founder of Grant’s Interest Rate Observer, and originator of the “Current Yield” column in Barrons. Ladies and gentlemen, James Grant.

### Scientific Advocate (SA)
Claim: What a strange proposition we are wrangling over this evening, ladies and gentlemen, a strong dollar, a not so strong dollar. The dollar is a unit of measurement. It measures the price of everything and anything. It preserves us from barter. It stores the value of work. The sine qua non of any unit of measurement is that it be fixed exacting, unwavering, true.

My teammate and I, Steve Forbes favor a stable dollar so we oppose the motion in the same spirit we support the 12 inch foot, the well calibrated bathroom scale, and the more than 16 ounce serving of Mountain Dew.

Now among the enumerated powers of congress is that to coin money and to regulate the value thereof and of foreign coin, and fix the standard weights and measures. The constitutional dollar was no placing of our monetary mandarins; it was a standard like the mile. Through most of the nation’s history, a dollar was defined under law as a particular weight of gold and silver, more often of gold, specifically of 23.22 grains fine. A little more than $20 was convertible on request into an ounce of gold, by and by the dollar was redefined. In the mid 1930s it was cheapened to 1/35th of an ounce of gold but still, still it was defined, anchored as something.

Then came the fateful evening of August 15th, 1971, pre-empting the beloved popular horse opera, Bonanza, President Nixon announced that henceforth, the dollar would have no definition, no anchor. No longer would America’s creditors have the option of converting 35 George Washingtons into an ounce of bullion, that universal monetary medium that nobody can print. Henceforth said Nixon, lashing out against unnamed speculators, they always do, the dollar would be as good as paper. And that at least, is one political promise that Washington D.C. has faithfully kept. And what has this soft, undependable malleable post-1971 pure paper dollar wrought? Well in 1971, the gross public debt totaled 408 billion, or 38 percent of GDP. As of yesterday, the gross public debt totaled16.7 trillion, or more than 100 percent of projected 2013 GDP.

Now think of the long-grade line of plans and resolutions to bring our national finances under control. The institution of the Congressional Budget Office. Gramm-Rudman- Hollings, the emergency deficit control act, Reaffirmation Act of 1987, and on and on, and now comes Paul Ryan. Will he be our messiah? Well maybe, but I doubt it. As long as the treasury can borrow at 2 percent and as long as the Federal Reserve can conjure hundreds of billions of what they are pleased to call dollars, with which to buy up these emissions of debt, the red ink will continue to spill. Alexander Hamilton himself might have succumbed to the temptation. Anyway, in 1971, the final year in which the dollar was anchored by something, anything, foreign governments held U.S. government securities on the order of $31 billion. $31 billion.

These holdings today top $3.3 trillion. They are the spore of our non-stock deficit on dirt goods and services. Consuming more than we produce, Americans remit dollars by the boatloads to our Asian creditors who obligingly return them by return mail in the shape of American investments in American IOUs. It’s as if the dollars never left the 50 states. Sweet it has been this privilege of America, the privilege of paying its foreign creditors in the currency that only it may lawfully print. But the unprivileged are fighting back. They too are cheapening their currencies through the modern techniques of ultra- low interest rates and that cut glass phrase, quantitative easing. You know, some years ago, the Financial Times published a letter to the editor concerning quantitative easing, that is to say in laymen’s language, central bank’s conjuring of new paper money secured by nothing except the good faith of the government that prints it. I finally think I understand the meaning of quantitative easing this correspondent wrote. What I no longer understand is the meaning of the word money.

Under the rules of the true blue gold standard, governments tended to balance their budgets and international debtors and creditors tended in a timely fashion to square up accounts. I don’t have to tell you that no such constraints bind us today. Deficits grow and imbalances pile higher and higher, as you would expect them to, in a monetary sense. After all, we are playing tennis without a net. And for that matter, without baselines or sidelines and with imaginary green balls. Incongruous this is as well, volatile currencies, due to their mis-shift in a world increasingly and finely calibrated, the international system of units binds every commercial nation in a rigorous regime of weights and measures. And a good thing too, as 21st century engineering projects involve myriad interrelated elements which all must be measured alike, sometimes to an accuracy of up to one part in a million or more, as Robert Crease relates in his book, "World in the Balance."Well, well, it's an ill wind that blows no one any good. Unanchored exchange rates have created a cottage industry and monetary volatility. John Taylor. John Taylor, from whom you'll hear in a moment has built a thriving foreign exchange trading business on the ashes of the good as gold dollar. Well, just look at the quality of that man's suit. It's a fabulous business. The more the currencies dance and swerve, the better it is for Mr. Taylor and his hedge fund. To him, as to others in the forex trades, the very idea of monetary stability is-- it's worse than anathema. It's unprofitable. I would no more expect him to espouse a system of stable currencies and fixed exchange rates than I would an oncologist to welcome a cure for cancer. No, that is-- that's not my best one. post-1971 helter-skelter monetary system also favors the prodigious talents of John's sparring partner and my sparring partner, his partner, Rick Mishkin. The holder of a Ph.D. in economics from MIT, a prolific author, and coach at Fred ought to be at NASA. He should, if for not his sake, for our sake. And so should every holder of a Ph.D. in the Federal Reserve Board. Ladies and gentlemen, we've alighted from the gold standard over a course of decades into something that we should all regret, the Ph.D. standard.

### Moderator
Claim: Thank you, Jim Grant. Our motion is-- well, a reminder of where we are, we are halfway through the opening round of this Intelligent Squared U.S. Debate. I'm John Donvan. We have four debaters, two against two, fighting it out over this motion, "America doesn't need a strong dollar policy." You've heard two of the opening statements, and now on to the third.

Debating in support of the motion that "America does not need a strong dollar policy," the chairman and founder of the investment management company FX Concepts, and a former vice president at Citibank where he headed research for foreign exchange. Ladies and gentlemen, John Taylor.

### Conspiracy Advocate (CA)
Claim: My cottage business happens to be dealing with the world and the reality in the world, not like Jim's which is dealing with the world the way he would like it to be. I would start out by saying that, Jim, your first statement to Rick was that you would be cutting the number of employees at the Fed. I would say that if we follow any of your policies, we'd be cutting the number of employees everywhere. And, unfortunately, unfortunately, yes, the dollar is as good as paper, and every currency in the world is as good as paper.

We're not worse. We're not better. But the fact of the matter is, is that your dollar that's as good as paper is convertible into anything. You don't have to hold those dollars. I give another speech trying to sell our cash management program where I tell people-- I hold up a Zimbabwean hundred trillion dollar note that's worth about 20 cents and tell people that "You shouldn't just keep your money in the United States, you should put your money around the world. You should be free." But the fact of the matter is, is that almost everybody wants to keep their money in the United States. Why can the Treasury borrow at 2 percent? They're not forcing you to lend them at 2 percent. They're not forcing the Bank of England to invest its money at 2 percent. They're not enforcing the Chinese to invest their money at 2 percent. But they do. And, therefore, the dollar has a value. Paper or not, it's got a value. And gold is not necessary.

Also today everybody has the pleasure of borrowing with their own currency unless, of course, your currency is Zimbabwe and nobody wants to hold that. By the way, the latest figure I saw was that the National Bank of Zimbabwe had $210 in its account. That's the central bank. I don't know. The value's probably changed in the last week or two. But because everyone has the privilege of borrowing in their own currency, and that means Brazil, all kinds of emerging countries, we're no longer on this standard where the U.S. has a-- you know, there's power over the world, we borrow in our own currency, and everybody else is stuck. They have to, you know, balance their budget, do all the right things. No, unfortunately, in a way, from Jim's point of view, and I'm sure Steve's, as we'll hear, everybody has this ability to borrow too much. I don't think it's a good idea, I don't think it's necessarily going to end well.

I believe in a lot of things that tend to be conservative, but the fact of the matter is that a strong dollar policy has a lot of impact on the United States, as my partner Rick has pointed out. It would hurt us dramatically if that happened, and also, the dollar has a very strong impact on the rest of the world. If you're looking at the easy side of this from the U.S.'s point of view, what impact does a strong dollar have? Well, for a start it has a lot of impact on jobs in Ohio, in Michigan, in places where we actually produce things in the United States, because the stronger our dollar is, the less likely it is we are to have a manufacturing sector. In 1985, when the U.S. had a strong dollar policy, and after a while a stated strong dollar policy under Ronald Reagan and Volcker, we began to develop something that we now call, and it came into practice then, "the rust belt."And the reason that was the rust belt is all of a sudden we couldn't produce anything that could compete with the rest of the world because the dollar was too damn strong. So now we all drive Mercedes and Toyotas and whatever, we do not drive things that come out of Michigan. Now, let's face it, Michigan has other problems, and if you were-- I know I'm going to get defeated on this, Toyotas are all made in the United States, Hondas are made in the United States, yeah, in Kentucky, Tennessee, Alabama. There are reasons for that. But the fact of the matter is that the strong dollar-- the weak dollar today has brought these European and Japanese companies into the United States, even Korean, and if we had a strong dollar they would go, too. One of the things that the Japanese are trying to do with their latest effort is to make the Toyota plants come back to Japan so that they can actually employ Japanese to make Toyotas instead of people from Kentucky or Tennessee.

So the dollar is very, very important domestically for us, and basically if you have a strong dollar you end up with a situation where the rich get richer and there aren't a hell of a lot of jobs. How does the world do with the dollar? A strong dollar is bad for the world as well. And it's kind of perverse, because if you would argue that, oh, gee whiz, if you’ve got a strong dollar, then anybody can sell anything to us. Right? Because everything looks cheap to us, right? And I must say that, you know, in the 1960s everything did look cheap to us. Now a lot of things look quite expensive. In fact, one of the worst things about a weak dollar is the fact that we can't go to Europe on vacation; it's too damn expensive. If we had a strong dollar, Europe would be cheap and we could all go on vacation, but at the same time, all the New York City hotels would be empty, whereas now you walk around the New York City hotels, well, they're just loaded with people from places that I never thought could possibly afford New York. And it's always interesting for me to sit and talk with somebody and have him tell me how much more expensive Belgrade is than New York. That's like, "What? You got to be kidding. But they were seriousBut overseas, it's a little difficult to understand, but if the dollar is declining, then it's very inexpensive to build a plant, to finance your trade, because a weak dollar, which is the global currency because the dollar has been out there for years-- a weak dollar is the thing that you finance your trade in. And if you know the dollar is going to be weaker in a year or two or three, you don't repay it. You might be paying 6 percent for your dollars, but hell, if the dollar goes down 10 percent a year, you're paying minus 4. So it's a gift. So when the dollar is weak, people borrow money from Citibank, from JP Morgan, from Goldman Sachs, the people doing these deals, and our banking system does very well.

When the dollar is strong, all of a sudden these people are, "Oh, my god, I now owe more for this loan, and my plant that I built in Thailand isn't as successful as I thought, and so I have to close it down and I have to lay off workers." So when the dollar gets strong, all of a sudden the rest of the world economies go down, and so, actually, the United States is in a bit of a problem. Can we have a strong dollar policy? We argue strongly that we can't, because there is no place for us to do it. We have to support the world.

### Moderator
Claim: John Taylor, I'm sorry. Your time is up. Thank you very much. John Taylor. Our motion is, America doesn't need a strong dollar policy, and here to argue against the motion, Steve Forbes, chairman and editor in chief of Forbes Media and the author of "Freedom Manifesto: Why Free Markets are Moral and Big Government isn't."

### Scientific Advocate (SA)
Claim: Thank you. Thank you. Thank you all very much for coming here tonight. I want to emphasize with Jim that we believe in a strong and stable dollar. We don't like inflation; we don't like deflation. We like "flation." Stability.

This-- so let's lead. What is money? Money makes it easier to buy and sell with one another, to do transactions with each other. It is through buying and selling that wealth is ultimately created, doing things, interacting with each other. Before we had money, in the old days we had barter. If I sold an ad in Forbes Magazine 3,000 years ago, how would I get paid? Perhaps with a herd of goats. Let's say I wanted to buy iPads for our writers, so I go to the iPad store 3,000 years ago with my goats. Store owner says he doesn't want goats; he wants sheep. So then I have to figure out how I swap my goats for sheep. Perhaps I have to hire a sheep herder so the wolves don't eat the sheep. Sheep herder wants to be paid in wine. I've got red wine; he wants white wine. So it becomes very, very cumbersome.

Money makes all this easier, more convenient to do those transactions. So we got coins in Lydia 2,600 years ago. Then Athens picked it up, became a great commercial and cultural center. Got coins, and then paper, and then blips on a computer, but all of it means it makes it easier to do commerce, makes it easier to buy and sell with one another. That's the function of money.

If we had barter today, imagine what it would be like, trying to deposit a cow into an ATM or take out a pig from an ATM. So we have money, and money is like anything, fixed weight and measure. If it has a fixed value, it becomes extremely useful.

We have-- when you go to the supermarket, say, buy a pound of hamburger, you assume it has 16 ounces, not 18, not 12. We don't float that pound from the British pound. But you know when you go to the market, 16 ounces. Twelve inches in a foot, that doesn't float. Imagine building a house 3,000 square feet if the rule floats each day. Take-- what would your life be like if the Federal Reserve did to the clock what it does to the dollar? Float the clock. So it's 60 minutes in an hour one day, 20 minutes the next, 22 the next, 90 the next. You'd soon need to have hedges, derivatives futures, to figure out how many hours you're working. So let's say you hire somebody, 15 bucks an hour, do you pay that-- is that a New York hour? New Jersey hour? Bangladesh hour? Let's say you're baking a cake. It says bake the batter 45 minutes. You have to figure out, is that an inflation-adjusted minute? a weak dollar, unstable dollar, makes commerce harder, and it has very destructive impacts. First of all, it misdirects investment. Without investment, we don't get a higher standard of living. A weak dollar is like a virus in a computer, corrupts the information. When the dollar becomes weak, what happens to the flow of investment money? It becomes defensive. It goes into commodities. Try to preserve what you have instead of invest to grow in the future. You saw it in the 1970s. $3 oil went to $40 a barrel. When Reagan and Volcker stabilized the dollar in the '80s, crashed down to $10, stabilized to $20. From the mid-1980s to the early part of this last decade when the Fed went off the rails again, dollar average-- average price of a barrel of oil more than $21. And now look what it is today, $80, $90.

You saw it with the housing. We had an artificial housing boom in the late '70s, even worse one this time. The housing bubble could not have happened without a weak dollar. So you get financial bubbles. Another thing that happens is, when you have a week currency, real wages go down, which is why the median income in the country's gone nowhere for 10 years. Your salaries go down in real terms, which is why after 40 years of this nonsense, of having floating dollars like a floating clock, it takes two incomes in the family to do what one income could do several generations ago. So when the dollar goes down in value, you pay more for food; you pay more for gas; you pay more for electricity, which means money-- less money for other things. And so U.S. median incomes, as I mentioned, went down. And so workers do better when you have, in terms of improving their standard of living, people do better when they're in countries where the currency is stable, and they do worse in currency-- in countries over time that have weak currencies. It also harms our security. Weak money, as I mentioned, has an artificial boost to commodity prices, particularly oil. That means vast transfers of wealth to commodity producers and the like, and also vast transfers lending trillions of dollars to countries unfriendly to the U.S. like Iran, Venezuela, and Russia. Weak dollar also has a moral dimension. It undermines social trust. It severs, or certainly weakens, the link between effort and reward.

Wealth and progress is achieved less by hard work like gaining new skills, perhaps starting a new business, and more by speculation and gambling. Weak dollar means windfall gains, as I mentioned, for commodities and for exotic financial instruments and hurts small businesses and many start-ups. Faith in the future is undermined because it then suddenly becomes the present. Hard work is made a mockery of. You worry about whether you and your children, your grandchildren, are going to have a higher standard of living. The economy seems more like a casino rather than something where hard work can get you a better life. John Maynard Keynes summed it up very well. Keynes said, "Lenin was certainly right. There is no subtler, no surer means of overturning the existing basis of society than a debauched currency." That is, weaken the currency. The process engages all the hidden forces of economic law on the side of destruction and does it in a manner in which not one man in a million is able to diagnose.

What this means is, what we see happening today, this feeling that something is not right, this feeling that speculation, doing exotic financial instruments, greedy oil companies and the like is the way to get ahead instead of hard work-- it all relates to a weak and unstable currency. So just as you want 60 minutes in an hour, just as you want 16 ounces in a pounds, just as you want 5,280 feet in a mile, you need stability, fixed measure of value. That's all the dollar is, makes it easier to do commerce when it's stable in value. You do more commerce, pure productive commerce. So bottom line is, wages suffer, investment gets skewed, we don't have a higher standing living that we would have had, and it weakens social trust. Stable dollar is what we need, not funny money from politicians who think they know how to do our lives better than we do. Thank you.

## Round 2

### Moderator
Claim: Thank you, Steve Forbes.

And that concludes round one of this Intelligence Squared U.S. debate. And now on to round two, where the debaters address each other directly and also answer questions from me and from you in the audience. Here's where we stand at the beginning of round two. Our motion is, America doesn't need a strong dollar policy. Arguing in support of that motion, in other words arguing against a strong dollar policy, we have Fred Mishkin and John Taylor. They have told us that you need a dollar that matches the economic times that you're in, and sometimes like the president, they say a strong dollar actually hurts. It hurts exports, and that hurts jobs, prosperity. And the government needs flexibility to work fiscal and economic policy. The team arguing against, and that means they're arguing for a strong dollar, James Grant and Steve Forbes, are arguing, yes, we do need a strong dollar, that a strong dollar is one that is fixed, that money was invented to represent and hold value so that business could be done. When that doesn’t happen, when your 12 inch ruler doesn't have 12 inches anymore, the meaning of money begins to slip out of sight.

They said specifically, workers do better when the economy is stable, and workers-- the workers do better when the currency is stable, and worse when it's not. I want to put that question to their opponents. To Ric Mishkin. You’re arguing that America doesn’t need a strong dollar policy. Steve Forbes is saying workers do better with a strong dollar policy.

### Conspiracy Advocate (CA)
Claim: So the first thing I should tell you is, I actually am proud that I have a Ph.D. and that I’m a rocket scientist. What can I tell you. But I, first I want to talk about, I think that there’s a sense jujitsu going on in that I actually strongly agree with the view that price stability should be the overriding long run-- overriding policy in the long run for monetary policy. And in that context, you’re absolutely right, that if you actually debauch the currency, if you have a lot of inflation, this is a very, very bad thing. I’m in no way advocating that.

And indeed, when we actually look at the technology of actually producing stable inflation, the idea that in fact we should go back to the horse and buggy and go back to the gold standard, I think doesn’t fly. So let me give you reasons why. If you actually look at the gold standard period, one of the things that you see, is that when you tie the currency to gold and you say a dollar is worth let’s say 20 ounces, 20 dollars is worth ounce of gold for example, is what was done in that period. The problem is that you’re now in the vagaries of what happens to supply and demand for dollars. And in particular, this is a period where in fact there wasn’t a good dollar yardstick in the following sense, which is, the variability of inflation was much higher during the gold standard period than we have now. Now what did happen in that period and one of the problems here was, that you actually very much affected by acts of God.

So indeed we actually had a deflationary period in the 1880-- from 1880 to about 1896, because they couldn’t find any gold. Then we had the Klondike and South Africa and actually there was inflation, because there were huge amounts of gold found in the ground. So there’s really an issue of technology here. The question is, can you actually get states stable inflation so you meet the definition of price stability, which Alan Greenspan I think said rightly so, is it’s like pornography, you know it when you see it. It’s when you don’t worry about what’s happening to the price level in your day to day decisions. We completely agree that that’s the right way to run the economy.

### Scientific Advocate (SA)
Claim: I think that’s -

### Moderator
Claim: Jim Grant.

### Scientific Advocate (SA)
Claim: I can speak to the period of the 1890s. I’m older than you and I remember it very well.

And your critique of the gold standard, if I may say, I think, reveals some of the weaknesses of the Federal Reserve’s approach to our monetary affairs of the present day. The Fed has its knives out for the thing they are pleased to call deflation. You, ladies and gentleman, might know this as every day low and lower prices.

Most Americans spend most of the weekend looking for the thing the Fed deplores. The Fed means to create this amount of credit such that prices do not dwindle, fall, weaken. Now, what will you expect prices to do in a world of technological wonder in which hundreds of millions of willing new hands are added to the world’s labor force? In which digital technology breaks down the barriers to production the world over. In which marvels of engineering shove each other out of the news every day. We can’t keep up with the rate of gain in productivity. What will you expect price to do? Well prices, I would suppose dwindle, the supply curve is shifting downward and to the right. Therefore prices might benignly fall. The Fed will have none of it. The Fed insists on creating that amount of dollars that will deliver unto us that measure of inflation the Fed thinks we need, namely two percent, which by the way, they can’t really measure. So what we have is persistent credit bubbles, in the name of what they are pleased to call price stability. Which is not price stability, it’s--

### Moderator
Claim: All right Jim, let me step in for a moment because you actually made that point in your opening statement. And what I want to do is break down some of the points that were made in the opening statements. And I asked you a question Fred, Rick, that you didn’t answer, and I’m very sensitive to that reality. Steve’s point that workers do better when a currency is stable and worse when it’s not. Can you respond to that directly? Then I want Steve to--

### Conspiracy Advocate (CA)
Claim: Workers do better when there is low and stable inflation, that we agree on. And in fact, low and stable inflation means that it’s not fluctuating a lot.

### Moderator
Claim: So what is he saying that’s different from what you believe?

### Conspiracy Advocate (CA)
Claim: Because what he’s saying that’s different is that he wants a fixed value of the currency, the dollar, in terms of a commodity, let’s say gold. And that actually is not a situation where it produces stability in the price level. During the gold standard, the price level went up, went down. Now you are right, that over very long rises, over 40 year period, there was no change in price level. That’s the good news. The bad news is, that horizons are not 40 years. As Cain said, in the long run, we’re all dead.

### Moderator
Claim: Okay, Steve Forbes. Back to your point. Bring us some examples or make the case in specific terms about the stable currency being good for workers.

### Scientific Advocate (SA)
Claim: Well again, what prices do is, should be determined by a free market. We’ve had a huge fall in the price of memory. You take an iPod today. Memory costs what, $40, $50? Ten years ago, it would have cost $10,000. So as Jim said, with productivity prices might go down, which is good for us. So in terms of the free markets, prices may go up, may go down. You have a drought, they'll go up. Again, the money should be stable in value. The United States, from the time we went on the gold standard in 1789 right through-- some on and offs, through '71, had one of the most extraordinary growth periods in human history. We surpassed our neighbors in Latin America. We surpassed Europe in terms of growth, which is why we attracted more immigrants than any other country in the world where it seems a place of opportunity.

And one of the key things that Hamilton and Washington brought in was realizing if you fool around with the money, what that does is hurts commerce. People hold physical assets instead of going out, and doing, and investing in the future. You know, when you invest something, John, you don't know whether-- you know, you might not get a return for three years, five years, seven years down the road. That's risky, but it's even riskier, and you're less likely to do it, if you don't know what you're going to be paid back in. Is it going to be a 100 cent dollar, an 80 cent dollar, a 20 cent dollar? If you don't know, get less of that productive investment and look at--

### Moderator
Claim: Okay, so you're broadly saying, in terms of the workers' question, that stability is good for workers because there are factories, and they're working in their jobs, and they--

### Scientific Advocate (SA)
Claim: Well, you get an environment where people invest and things get done. You

### Moderator
Claim: John Taylor, your opponent.

### Conspiracy Advocate (CA)
Claim: Yeah, I don't think Steve answered the question at all about workers' salaries and how well they're doing.

### Scientific Advocate (SA)
Claim: Well, workers' salaries under the gold standard went up. You take any period of time, they went up in real terms, which is why our wages in real terms are the highest in the world.

### Conspiracy Advocate (CA)
Claim: Yeah, I wonder about Dickens and some of the stories of that period. But--

### Scientific Advocate (SA)
Claim: He was an Englishman, the last I heard.

### Conspiracy Advocate (CA)
Claim: Yeah, but I just wonder.

### Moderator
Claim: John Taylor.

### Conspiracy Advocate (CA)
Claim: The fact is, is that the example that Jim gave, where the Asians were beginning to develop products at cheaper prices and all this kind of stuff, implied a decline in U.S. wages. Absolutely positively, unless the U.S. government was pushing to keep the wage levels of U.S. workers up. And so I believe that, in fact, the movement to a weak dollar had a lot to do with the fact that we had a growth in Asia coming, and product was coming in much cheaper and basically undercutting, well, not only Detroit, but California, and the-- if you look at apples, or whatever, they're-- none of them are made in the United States, right?

### Scientific Advocate (SA)
Claim: Because the reason-- the reason, John, we got cars coming into this country starting in the late '60s was that unfortunately for a period of time the Germans and Japanese made a better car and people preferred that to what was being turned out in Detroit, which is how they got in trouble. It's not American workers. When other foreign companies came over and established car plants, they could turn out excellent cars. Our workers made excellent wages. It wasn't because cars were cheap, people felt they worked better, whether the low end of the car line or the high end. That's good competition.

### Moderator
Claim: John Taylor, continue your point, unless you were done.

### Conspiracy Advocate (CA)
Claim: I'm finished.

### Moderator
Claim: All right, so I-- so John's-- John was making the point, and you just disputed it by saying that there were other reasons that people bought cars, but this-- the team that's arguing that American doesn't need a strong dollar policy has made the point a couple of times that a weaker dollar boosts exports. We all see the logic of that argument, and I'm assuming you see the logic of the argument, but what's the flaw in the argument? Jim Grant.

### Scientific Advocate (SA)
Claim: With a cheaper currency, you pay more for what you buy, and you earn less from what you're--

### Moderator
Claim: Jim, I just got a signal that they need you to move a little closer to your mic.

### Moderator
Claim: Yeah, if you move it a little bit closer and then--

### Scientific Advocate (SA)
Claim: Okay,

### Moderator
Claim: Are you good? Is that good? Yeah, okay, thank you.

### Scientific Advocate (SA)
Claim: Okay, with a cheap currency, you pay more for what you buy, and you earn less from what you sell. Now, tell me what are the advantages of a cheap currency.

### Scientific Advocate (SA)
Claim: Yeah, look at the price of gasoline, $1.25 in the late '90s. What is it, three and a half, four, $5 today? How does that help a family? How does that increase their

### Moderator
Claim: Rick Mishkin.

### Conspiracy Advocate (CA)
Claim: I want to change this issue a little bit, that--

### Moderator
Claim: Well, no, actually, no, no, I like your question.

### Conspiracy Advocate (CA)
Claim: No, no, I want to deal with the question in the following sense, which is that what goes on in the real economy is actually much less associated with what goes on in terms of the inflation that in fact you're attributing it to, and in particular, that a lot of things you've talked about in terms of high growth and so forth, or whether you have good institutions, a good legal system, and so forth, so what we really need to focus on is a narrower issue that-- does a strong dollar actually help the economy? Does it hurt it? Does having a good dollar yardstick help the economy? Does it hurt it?

I think that's very important, but not-- let's not get into this view that having a strong dollar, or gold standard, or weak dollar actually solves all of our problems. This actually solves very little of the problems. It's still important.

### Scientific Advocate (SA)
Claim: The gold standard--

### Moderator
Claim: Jim Grant.

### Scientific Advocate (SA)
Claim: I mean, the idea that our fiscal affairs after 1971 when the dollar lost this anchor, what remained of the anchor-- the idea that our fiscal affairs were not affected by our capacity to print dollars to infinity just strikes me as something on its face--

### Moderator
Claim: Are you arguing that?

### Conspiracy Advocate (CA)
Claim: I would actually disagree with that. I think you're absolutely right that we went through an extremely bad period, we actually call it the great inflation period. It was extremely bad policy--

### Scientific Advocate (SA)
Claim: I mean the-- I mean, the--

### Conspiracy Advocate (CA)
Claim: Wait. And also the fiscal irresponsibility, but this is a choice of the governments are spending too much relative to what they take in.

### Scientific Advocate (SA)
Claim: No one in the face of the earth could resist the temptation to emit the reserve currency which we are privileged-- or not privileged to into the world at interest rates now prevailing-- manipulated interest rates, John, in the federal reserve. That's why they're 2 percent the world over. It's not as if we are improvident in a way our forbearers were not. They had strictures, they had a system within which they had to run their affairs. They had to balance the budget, that was the norm of the monetary regime and ruling the norm of monetary regimes over today is debt. And it's not-- as John himself said, it's not going to end well.

### Moderator
Claim: John Taylor.

### Conspiracy Advocate (CA)
Claim: I think that there's an argument being made here that what happened in the '70s is what's happening today, and there's an argument being made, also, that we cannot manage ourselves, our money, without having some Procrustean bed that we're forced into. I don't agree with that at all. I think that's really our point, is that you have be flexible; the dollar has period where it needs to be strong.

I-- Paul Volcker is one of my heroes. He did everything right when he came in. And I was there for the Saturday night massacre and I did not have a good time, but it was the right thing to do when he all of a sudden changed the way that the fed manage money and interest rates shot up by 4 percent over the weekend. That was a very, very good shock for the U.S. government, and it was a brilliant stroke. It had nothing to do with the price of gold, it changed it a great deal, but it really was a decision made by the fed and, obviously, with the agreement of the Treasury.

### Moderator
Claim: Steve Forbes, your opponent, John Taylor, has just used the word flexibility and that is-- that's a key theme for them, that the government needs to have the flexibility to move the dollar as it can depending on economic circumstances, it’s a tool. What about that argument?

### Scientific Advocate (SA)
Claim: It's like saying if you change the measuring rod, that'll increase prosperity. Why not change the number of minutes in an hour? Let's say you increase the number of minutes from 60 to 70--

### Moderator
Claim: But you've said that already and I--

### Scientific Advocate (SA)
Claim: All right. But I'm making-- but I'm making--

### Moderator
Claim: But, but, but-- I, I, I--

### Scientific Advocate (SA)
Claim: But I'm making the point. All right, you use whatever analogy you want. Flexibility in terms of a-- of a measurement is not the way you cure economic problems; what it does is reduce-- brings in a factor of instability so you don't know what you're going to get paid back in, you suppress people's wages. Why is that-- why is that a good thing? What country has ever become, in modern times-- what country has outpaced, in terms of a standard of living, with a weak currency, chronically weak currency, than those that have had traditionally strong currencies? Argentina--

### Moderator
Claim: Rick Mishkin.

### Scientific Advocate (SA)
Claim: --150 years ago thought it was going to be a rival of the U.S., but it went in for funny money and they're paying the price for it to this day.

### Moderator
Claim: Rick Mishkin. Steve Forbes just said why is that a good thing, being able to have that tool? Why-- you know, take 30 seconds and answer that--

### Conspiracy Advocate (CA)
Claim: First of all, I wouldn't want to say that the dollar-- the value of a dollar should be the tool we're using. What we do need is the technology in order to keep the dollar yardstick working in a way that we can actually plan in the future, know what the price level is going to be next year so that we actually can make good decisions. We actually agree on that. The question is what kind of technology do you want to use? Do we need to go back to the era with--

### Moderator
Claim: How are you using the term technology? Just take a moment.

### Conspiracy Advocate (CA)
Claim: So what I mean by this is that one technology is actually to tie the dollar to gold. That's a technology. Another kind of technology that you can use is, in fact, what central banks have been adopting and actually very successfully in terms of something called inflation targeting. They have actually adopted a policy of saying "We're trying to keep inflation stable, in the last 10, 15 years have been very successful at doing that. They have not solved other problems like financial stability, but there are reasons why that has to be a concern of a separate nature.

### Moderator
Claim: Jim Grant.

### Scientific Advocate (SA)
Claim: Rick.

### Conspiracy Advocate (CA)
Claim: Sorry that I got you so upset.

### Moderator
Claim: You know you're-- Jim, you're-- if only the radio audience could see your face, Jim.

### Conspiracy Advocate (CA)
Claim: And if your-- if your bowtie got unraveled, that's the question that I want to ask.

### Moderator
Claim: Or spin, that would be a good effect.

### Scientific Advocate (SA)
Claim: Look, inflation is a defined term. I think it is worth noting that the inflation of house prices, which went unremarked by our financial scholars at the Federal Reserve. The inflation in house prices almost brought this country, financially speaking, down. Now, the CPI or the, whatever the Fed’s preferred measure of inflation, was fine. Unbeknownst to the Fed and hundreds of monetary scholars on the payroll, some of them whom I’d keep by the way, just for the sake of equity. Unbeknownst to these experts, there was building up in the economy, something that models didn’t even look at, which is a huge build up of unsupportable debt, mortgage debt in the banking system and outside the banking system.

Now inflation is not a certain threshold reading on a CPI inflation, it’s too much money. Chasing something we’ll know about after the bubble burst. Now it could be inflation of the checkout counter, that was 1970, but you must keep up, right John? Must keep up with the modern times and inflation can be an inflation of bond prices, of equities, of LBO debt, of Greenwich real estate. Because by the way, the rich get richer in a regime of low interest rates, and they get richer big. They get richer big because they borrow for nothing. So inflation is a much subtler term than the Fed knows or acknowledges to this day. And they can’t control it. It’s like a bubble underwater. They squeeze part of it and another part of the bubble protrudes.

### Moderator
Claim: I just want to tell both of our panelists, after you make your point, I want to give each side an opportunity to ask a terse question to the other side, so you can be thinking about that. But this is not that turn.

### Conspiracy Advocate (CA)
Claim: Again, the issue is, you’re right, the bubbles can be very disastrous, particularly ones that involve credit markets. And we’ve just gone through a terrible period this way. But in fact this has been happening through history and in fact has been happening frequently when we’ve had gold standards and also when we didn’t. During the gold standard era, we actually had these bubbles all the times in the U.S. We had financial crises about every 10 to 20 years, so you’re right that this is something that we have to worry about. But catching the-- basically the strong dollar policy that you advocate is not going to produce the outcome you want. We actually need policies to think about moderating credit cycles. That’s something we have to worry about. I think we agreed on that. But in fact tying to gold, maybe you see it, but I sure as hell don’t/

### Moderator
Claim: Response? Steve Forbes.

### Scientific Advocate (SA)
Claim: Well, and if you look at some of the financial crises in the 19th century not to mention the 20th century, it’s precisely when there’s fears that the U.S. was going to go off the gold standard.

We briefly did during the War of 1812, played around with silver, which led to the panic of 1819. We had banks that weren’t regulated in the 1830s, they’d issued a lot of currency so we got a panic in 1837. And on and on you go. So it doesn’t prevent people from doing crazy things. But what a gold standard will do--and why gold? What it means is you have a fixed measure value, like a north star. Better than any other thing in the world, gold keeps its intrinsic value. It may go up a little bit, down a little bit, but it’s the best thing we humans have on earth for stability. So all it is is a measuring rod, making sure, the market should determine, not mandarins at the Fed, how much money is needed in the marketplace. And under a gold standard, if you have a vibrant economy, plenty of money is created. If you have a stagnant economy, money’s not created.

### Moderator
Claim: John Taylor.

### Scientific Advocate (SA)
Claim: Stable and also flexible.

### Moderator
Claim: John Taylor.

### Conspiracy Advocate (CA)
Claim: Thank you. Gold has been standard, 1800, 1200, the same year. Stability? My foot.

### Scientific Advocate (SA)
Claim: That says more about the dollar than gold.

### Conspiracy Advocate (CA)
Claim: Right. Stable, gold is a fantastic speculative tool and was in the 1800s and is today.

### Scientific Advocate (SA)
Claim: It wasn’t the 1800s, and what part of the 1800s was it a speculative tool John?

### Conspiracy Advocate (CA)
Claim: I’m sorry, I should have said 1900s. I speak Italian. So it’s a - 1800s that way.

### Moderator
Claim: John, elaborate, because the more specific you can be in talking about these periods in which gold was not stable, the more we’ll see your point.

### Conspiracy Advocate (CA)
Claim: Right, okay.

### Moderator
Claim: And then I want them to respond.

### Conspiracy Advocate (CA)
Claim: The number of crises in the gold market during that period were phenomenal. The number of times the U.S. goes into the Civil War, we’re off the gold standard. The Franco-Prussian War takes place, we’re-- they’re off the gold standard. Everybody, when there’s a crisis, they step away from the gold standard.

### Moderator
Claim: Because?

### Conspiracy Advocate (CA)
Claim: Because there was no way for them to handle the money.

### Scientific Advocate (SA)
Claim: Because there’s no way for them to wage war.

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: Inflation is associated with peace and other regimes of monetary organization.

### Conspiracy Advocate (CA)
Claim: That’s all very nice--

### Moderator
Claim: But there are times when you really need the money.

They’re also arguing this is one of those times too when we really need the money.

### Conspiracy Advocate (CA)
Claim: It’s not practical Jim. It’s not practical. We really need the money when you have a war, when you have something or other. So why didn't George Bush, II, go off of the--

### Scientific Advocate (SA)
Claim: George Bush, II?

### Conspiracy Advocate (CA)
Claim: Why didn't he raise taxes and do the kinds of things he should have done? I mean, it's the same issue.

### Scientific Advocate (SA)
Claim: It's a political decision made as it was in the Franco-Prussian War.

### Moderator
Claim: Steve Forbes.

### Scientific Advocate (SA)
Claim: During, when we had the gold standard, countries would go off gold when they fought a major war. Why? Because inflation's a form of taxation, of taking resources from you without putting a tax on you as John Maynard Keynes pointed out. This is the first time outside of a major war that we've had countries since the 1970s continuously undermining the value of their currencies.

Never happened in the developed world in peacetime like that. Wartime, you do everything. You raise taxes, borrow money, print money to win the war. After the war, you go back to stability. This time, we haven't done it.

### Conspiracy Advocate (CA)
Claim: I'm a little shocked here, which is we are talking as if we're in a period which we were in where we had super high inflation, and this was a huge problem, that's not the period we're in right now. We've had actually very stable inflation in the last 15 years.

### Scientific Advocate (SA)
Claim: As Jim just pointed out, when you trash your money, the symptoms aren't always the same. We had a huge housing bubble, disastrous housing bubble.

### Conspiracy Advocate (CA)
Claim: But let me

### Scientific Advocate (SA)
Claim: We had a commodity bubble. Oil went from 20 to $100 a barrel. That's not a good thing to absorb a lot of money that should have gone to finding cures for cancer.

### Conspiracy Advocate (CA)
Claim: One of the things we’ve learned--

### Moderator
Claim: Rick Mishkin.

### Conspiracy Advocate (CA)
Claim: One of the things that we've learned is that actually getting price stability doesn't solve the problem of financial instability, doesn't solve the problem that we sometimes have these bubbles. That's in fact something that we do have to deal with.

Indeed, one of the views in terms of research is that actually having a stable period may actually encourage a bubble because people don’t think there's enough risk, and in fact there is a lot of risk. So I can't see how we're going to solve the problems here of bubbles by actually being in a situation where we actually tied to some kind of commodity.

### Scientific Advocate (SA)
Claim: But you have to-- seems to me you have to distinguish between banking arrangements and monetary arrangements. We ought not to be surprised when in a system in which the capitalists get the up side in the banking business, and we the people suffer the down side when their bets go wrong, we ought not to be surprised that these bankers take exceptional risks. We are living in what the military people call an asymmetric world. To the up side goes Greenwich, Connecticut, to the down side goes Dayton.

### Moderator
Claim: John Taylor.

### Conspiracy Advocate (CA)
Claim: Yeah, I mean, one of the best economists who did not win the Nobel Prize, and I would argue the only reason he didn't win it was because he died first, was Hyman Minsky. And one of the--

### Scientific Advocate (SA)
Claim: They've all win a Nobel Prize.

### Conspiracy Advocate (CA)
Claim: One of the-- what?

### Scientific Advocate (SA)
Claim: They've all won a Nobel Prize, every single economist has won the a Nobel Prize it seems.

### Conspiracy Advocate (CA)
Claim: Minsky should have won the Nobel Prize. He died too early, but his-- one of the easy ways to remember him is stability breeds instability. And the more stable the situation is, the more you feel free at taking risk, the more risk you take, the more likely you are to get hit in the head.

### Moderator
Claim: All right, let's go-- let's see what the team that is arguing for a strong dollar policy, which is in our case the against the motion team, what's your killer question to the other side?

### Scientific Advocate (SA)
Claim: Well, this isn't a killer question.

### Moderator
Claim: Yeah, killer question. Rick that means really short.

### Scientific Advocate (SA)
Claim: Could you please tell us why you--

### Moderator
Claim: All right, Jim Grant, you go.

### Scientific Advocate (SA)
Claim: --why you feel we have too little inflation?

### Conspiracy Advocate (CA)
Claim: Excuse me?

### Scientific Advocate (SA)
Claim: Could you please tell us why you feel we have too little inflation?

### Conspiracy Advocate (CA)
Claim: Yes, because the way to think about this is that inflation is a-- it's what you think is the right rate of inflation is a means to an end. What we really want to have is high growth in the economy and stability in the economy, that's what we're really after. And if you have an inflation rate which is too low, then you're actually in a situation where you get deep deflation, something that you think is not a problem, but I can tell you, when you look at history and ask when we've had the worst crises, and the worst recessions, and the worst depressions, they were always associated with deflation.

So this is not something that I see as a particular positive. So you actually want to protect against not having too high inflation and not having too low. The second thing that's very important in this regard is that when you have an inflation rate which is too low, you actually get into a situation where sometimes, because of a very negative shock as we've had recently, you would actually like to drive nominal interest rates below zero. You'd like to drive the federal funds rate negative, and you can't do it, and, therefore, you can't stimulate the economy enough. So this is actually a problem that we worry about tremendously in terms of the policy circles. And what it tells you is you want to have a deflation rate which is, one, not so high that you spend a lot of time actually making decisions about where the price level's going to be, but instead produce, which produces a good economy, but secondly not so low that you end up in a situation where you get deflations, where you get this situation where you can't do expansionary policy when you need it, and as a result you have to pick a number in between. Most central banks have chosen around

### Moderator
Claim: Let me step in because I did you kill him because I don't think you killed him.

### Moderator
Claim: Okay.

### Moderator
Claim: Let-- I just wanted to get-- let him get his answer out. And this side, your question to the other-- to your opponents, the side arguing against a strong dollar.

### Conspiracy Advocate (CA)
Claim: So the issue that I would raise here is when we look at history--

### Moderator
Claim: No, not make a point, ask them a question.

### Conspiracy Advocate (CA)
Claim: Okay. So do you feel that, in fact-- that the economy was much more stable during the gold standard period than it has been in other periods?

### Scientific Advocate (SA)
Claim: During the gold standard period the United States had the highest growth rate in history, 4 percent real a year. That's why we became the greatest nation in the world. Thank you, George Washington, who understood what the fed doesn't understand today.

### Conspiracy Advocate (CA)
Claim: I would actually respond to that, which is when you actually ask what happens in terms of growth rates, most of this has nothing to do with monetary policy, with gold, or anything else--

### Scientific Advocate (SA)
Claim: What it has to do with is--

### Conspiracy Advocate (CA)
Claim: It has to do with technology and so forth--

### Scientific Advocate (SA)
Claim: Technology is created by people when you have a stable currency and people can invest in the future and not have to hedge in gold. Why would you want to buy a block of gold? People ask me, "Why do you invest-- should I invest in gold?" That tells you, why wouldn't they be investing in stocks and things like that? When you have a period of unstable currency, people hedge, people buy hard assets. And we've seen this time and time again. So we got the technology precisely because we had a stable money and people could invest the money, not have to worry about the value of the money.

### Moderator
Claim: I want to go to audience questions now. So if you raise your hand a mic will come to you. Please stand up. I might ask you to hold for a second so that the camera can catch up with you. Please tell us your name; if you're with a news organization we'd appreciate it if you would be willing to tell us that as well. And really be terse. You just saw two examples of really sharply focused questions. go right down in the front here. And-- yeah, if you stand a mic will come. I'm sorry, I thought we had somebody in that aisle but here it comes around the side.

### Moderator
Claim: Hi, Vicki Schmelzer, Market News International. What effect does a strong dollar policy have on the status of the dollar as reserve-- as the world's reserve-- world's premier currency?

### Moderator
Claim: I'm glad you asked that question. Who would like to start? Either side can start with that question. Steve Forbes, you look like you're-- like the wheels are turning. Yeah?

### Scientific Advocate (SA)
Claim: The dollar became so-called "reserve currency" because, thanks to the stable dollar, people wanted to use it around the world. We're the largest economy in the world, and so it was by nature, by markets, not by governments and central banks. Before us, you had the British pound, good as gold until the First World War. So that was the reserve currency. For a time, Dutch coins were used for global commerce, or silver. But you get it, the dollar became the reserve currency, we're the largest economy in the world, and we have to--

### Moderator
Claim: Is it-- is it--

### Scientific Advocate (SA)
Claim: --considered at one point--

### Moderator
Claim: Is it entirely-- Steve, is it entirely desirable to be the reserve currency?

### Scientific Advocate (SA)
Claim: It's entirely desirable to have a stable currency and high growth rates, absolutely.

### Moderator
Claim: Yeah, but is it a desirable-- is it desirable to the reserve currency?

### Scientific Advocate (SA)
Claim: I would--

### Moderator
Claim: Jim Grant, then I'll come back to this side.

### Scientific Advocate (SA)
Claim: May I add-- add to my partner's remarks--

### Moderator
Claim: Jim Grant.

### Scientific Advocate (SA)
Claim: I would submit that it's not so desirable, because we are given the irresistible invitation to consume more than we produce. Not since 1975, I believe, have we ran a surplus on account of trades and services. We ship these dollars abroad, they come back to us as investments, and we are given the-- as I say, this ever so sweet path to fiscal ruin. We have accumulated more than $3 trillion and the feds own balance sheet custody holdings of U.S. Treasuries that foreign governments and central banks hold against us. So the reserve currency is the invitation to, first the U.K. after 1914, and then us, to consume more than we produce, and it's not the swiftest way to prosperity.

### Moderator
Claim: Other side, side arguing that America does not need a stronger dollar policy.

### Conspiracy Advocate (CA)
Claim: Why did the-- why did the dollar become the world reserve currency?

### Moderator
Claim: John.

### Conspiracy Advocate (CA)
Claim: It was the only currency left standing in 1945, period. There was nothing else, we gave our money to everybody.

### Conspiracy Advocate (CA)
Claim: We were also, really, the only country left standing. At that point we had over 50 percent of the manufacturing capacity in the world.

### Conspiracy Advocate (CA)
Claim: Right. And the net effect of that is the dollar went out there and went out all around the world, and financed international trade, financed international growth, and more and more-- it does so today. And the world is path-dependent, i.e., history makes the future. And because the dollar is so dominant in the world, it's just there. And I agree--

### Moderator
Claim: Is it-- is this--

### Conspiracy Advocate (CA)
Claim: It's a hard spot.

### Moderator
Claim: Is this issue of it's being a reserve currency-- I think this is part of the sense of the question-- related to its strength or weakness or its stability or its flexibility?

### Conspiracy Advocate (CA)
Claim: No.

### Moderator
Claim: Why not?

### Conspiracy Advocate (CA)
Claim: I don't think-- I mean, it would have to completely collapse. I mean, the fact of the matter is is that everybody is investing in these 2 percent dollars even though Jim says we're forced to invest and the U.S. government is Nobody forces the Chinese to buy U.S. debt at 2 percent.

### Moderator
Claim: Another question.

### Conspiracy Advocate (CA)
Claim: They do, though.

### Moderator
Claim: Sir?

### Moderator
Claim: Michael McKee with Bloomberg News. Steve and Jim, right now, we’re seeing $1 buy about 96 yen and there are complaints from Detroit and other places that the yen is too weak. When the Clinton administration first formulated its strong dollar policy, a dollar bought 104 yen and their rationale was the dollar was too weak. Can you define what a strong dollar is, or in your term, a stable dollar, and how would you know?

### Moderator
Claim: Steve Forbes.

### Scientific Advocate (SA)
Claim: A stable dollar is one that’s fixed to gold, call it $1,500 an ounce. That’s stability.

### Moderator
Claim: Is that your price, and why?

### Scientific Advocate (SA)
Claim: Well if you’re going to go to a gold standard, you would have a period of adjustment. You don’t know today if that 15, 1600 price is factoring in a lot of future inflation. If people don’t expect it anymore, the price may come down. So you have a period of adjustment. But the fact of the matter is, what you see happening today is slow motion what happened in the early 1930s when countries thought that the way out was to devalue their currencies, starting with Germany, then Britain in 1931. Thirty countries followed afterwards, begger than neighbor policies, which is why Britain and others agreed to go back on gold in 1944. They saw what happened during the Depression.

### Moderator
Claim: Other questions? Sir.

### Moderator
Claim: Hi, my name is Kenton Phillips, and my question in this case is specifically to Mr. Forbes. In your opening statement, you mentioned that a lot of the mischief that occurred in the economy, a lot of the financial accounting scandals and tricks that people turned, that didn’t really produce any value, was attributed to the floating dollar. Could you state why exactly a strong dollar or gold based dollar would actually prevent that type of financial mischief?

### Scientific Advocate (SA)
Claim: Well first of all, if you had a stable dollar, then the ability to make money in terms of violent currency trading goes away. When you have a stable currency, even when you have unstable currency, most countries like to fix, or have at least an attachment to another currency to facilitate trade. So you’d see what you had under the Bretton Woods system, pretty good stability. When you have a stable dollar, since commodities are denominated in dollars, the violence you see in commodities goes down, so the ability to play games with that goes down.

And you also have, you can now then makepositive investments again, no need for exotic instruments to play games with the housing mortgages and the like. And I think you would see a smaller banking sector. One of the things that’s happened since we’ve gone off gold is that finance as a percentage of our GDP at one point had doubled. And it should have gone in the opposite direction. Finance should have gone in the way of agriculture and other parts, where technology takes over and other parts of the economy grow. So, bankers, don’t worry, you’ll have jobs tomorrow.

### Moderator
Claim: Rick Mishkin would like to respond to that point.

### Conspiracy Advocate (CA)
Claim: Not actually on that question, but I want to do a fact check, because Steve Forbes said something that I have some data in front me, actually by somebody they know very well. This is a paper that Anna Schwartz who I think you would consider to be the leading monetary historian of this generation along with Milton Friedman.

And in fact, she looked at different periods, and the period of the classical gold standard, when the U.S. was continuing in the gold standard, was not a period of high growth. So the numbers right here is that the U.S. grew at 1.8 percent per year at that time.

### Scientific Advocate (SA)
Claim: What period?

### Conspiracy Advocate (CA)
Claim: From 1881 to 1913. This is as paper that Anna wrote Mike Bordo called Monetary Policy Regimes and Economic Performance: the Historical Records. So it’s very much on this topic. Actually there was a lot of instability, that the standard deviation, how much variability there was, was 4.9. For her data, looking at the period from 1974 to 1995, which is after Bretton Woods went off the gold standard, that we actually had a situation where growth is about the same amount, with much less instability. My argument here is not that I think that the gold standard was good or bad for growth, but that it was not the key aspect.

### Moderator
Claim: What was the first time period?

### Conspiracy Advocate (CA)
Claim: The first period is from 1881 to 1913.

### Moderator
Claim: All right Jim, you were there.

### Conspiracy Advocate (CA)
Claim: And also they wore bow ties then too.

### Moderator
Claim: Jim, so he’s giving you data that throws it back at you, can you respond to it?

### Conspiracy Advocate (CA)
Claim: Well first of all, I think it’s unfair bringing an electronic device to one of these debates.

### Moderator
Claim: He’s got a piece of paper. It’s very analog.

He came prepared.

### Conspiracy Advocate (CA)
Claim: I use chalk and blackboard when I teach, which again, just shows what kind of person I am.

### Moderator
Claim: I just want to tell the radio audience that you held up a piece of paper with your data on it.

### Scientific Advocate (SA)
Claim: With respect to the late Anna Schwartz who was merely terrific, I don't believe those numbers. I've seen different numbers and I think-- but-- bigger numbers, describing growth. It, to me, defies common sense that the period 1880 to 1913 which saw the introduction of so much world beating and transformational technique, and production, and innovation, and invention would have yielded a growth rate so meager as 1.8 percent real over the course of that time. I don't credit it.

### Conspiracy Advocate (CA)
Claim: I'm sorry, but-- I can tell you that this is research done with the best data that was available by somebody whose integrity is impeccable. And in fact she's not the only one to come up with these kind of numbers. Now, you may not believe them, but you have different numbers, but unfortunately I have to go with what I think is good scholarship.

### Scientific Advocate (SA)
Claim: Well, I think there are other scholars who have produced better evidence that show a much rosier picture of growth in that era.

### Scientific Advocate (SA)
Claim: And then real, real wages went up in that era as well, which is again why we have millions of people coming to this country, more than any other country in the world. Saw it as a place of opportunity.

### Moderator
Claim: We are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, debating this motion, "America doesn't need a strong dollar policy." More questions from the audience. Sir, gray sweater. Do you mind standing up? Thanks.

### Moderator
Claim: Columbia Business School actually. So, Mr. Forbes and Mr. Grant, the-- you've asserted that the goal standard creates stability inherently, but we've seen numerous asset bubbles throughout the gold standard periods including, you know, the South Sea bubble in the United Kingdom, the Dutch Tulip bubble, et cetera, et cetera.

What prevents, in your opinion, the gold standard from creating or having more bubbles in that period as well?

### Scientific Advocate (SA)
Claim: Well, the gold standard to me is the least imperfect monetary regime, that has actually existed in human monetary history. The others have existed on blackboards at Cambridge and MIT, but the gold standard existed in practice for 100 years, the classical gold standard did. Now, one must distinguish between the definition of money under the gold standard and the banking systems in play-- in place during that period. Now, as Steve mentioned, human beings will err, and sometimes they'll err en masse, and there will be crashes and bubbles. What to me characterizes the gold standard period is the absence of growth throttling long dated depressions, owing to-- owing to uncertainty about the future value of money.

Such depressions as existed in that period were typically the result of uncertainty about monetary fears, such as the one that started in 1893, such as the depression of 1890, when there was a great hew and cry over William Jennings Bryant. But banking bubbles it seems to me were much less severe for the simple reason that bankers at the time were personally accountable in some degree, certainly bank stockholders were personally accountable for the solvency of the institutions in which they invested. There was a double liability

### Moderator
Claim: So I mean, really what they're saying is it would have been worse. They're not saying it's great, but it would have been worse.

### Conspiracy Advocate (CA)
Claim: But how can you say that the gold standard prevents this? The Great Depression was a period where we were actually on the gold standard.

### Scientific Advocate (SA)
Claim: It was not on the gold standard. That was the third rate variant on the gold exchange standard that happened after 1922 at Genoa. There's not the gold standard.

### Conspiracy Advocate (CA)
Claim: How do you define that?

### Moderator
Claim: John Taylor.

### Conspiracy Advocate (CA)
Claim: The gold standard--that's third rate, I'm sorry, what's second rate?

### Scientific Advocate (SA)
Claim: Second rate is Bretton Woods, third rate is 1920s and '30s, but the gold exchange standard was characterized by the buildup of reserve currency balances in other nations such as the British buildup in France and elsewhere.

### Moderator
Claim: Does anybody--

### Moderator
Claim: It was not at all

### Moderator
Claim: Is anybody planning to ask a question about what Steve Forbes mentioned was the moral dimension because I wanted to get to it in my questions, but my turn is over. So if anybody sort of signals to me that, that's your question-- you got an inside track. But in the meantime, in the meantime, right down here, sir.

### Moderator
Claim: John Feingold In light of trying to figure out the winner of tonight's debate, what measures should future historians look at to look back at tonight and determine who won? Is it the price of gold, or is it the volatility of some other measure, or is it yet still another measure?

### Moderator
Claim: All right, let me go put the question to this side because the last several questions have started on this side. I just want to balance it.

### Conspiracy Advocate (CA)
Claim: So I think volatility is key, and we can look at historical periods and say, "How much volatility has there been?" So volatility of the business cycle, of employment, volatility of the growth of GDP, which was much higher during the period 1881 to 1913 and which is the period of the classical gold standard, the first great gold standard according to Jim, than it was in later periods. That fact is very clear, I don't know of any serious scholar-- you may have people that you think have other numbers, but I can tell you that when I've seen the research that has been done in this area by people who have tremendous integrity and are incredibly respected, Anna Schwartz being one of those people, they come up with exactly that answer. And also there was actually much more volatility of the inflation rate during that period. That's the facts.

### Conspiracy Advocate (CA)
Claim: Right. Let me answer that in a different way--

### Moderator
Claim: Go ahead and-- both of you can talk

### Conspiracy Advocate (CA)
Claim: Because I think there's another way that's not anywhere near as technical as Rick's way.

### Conspiracy Advocate (CA)
Claim: That's right, I'm a Ph.D., remember.

### Conspiracy Advocate (CA)
Claim: Right, and I'm a political scientist, so I would mention this in social welfare. How well-- how much social welfare is there? I look at the gold standard and, I'm sorry, I don't think Dickens is an outlier; there were plenty of American Dickens and the equivalent, and a lot of our families lived those lives, right? I think that the point is is that is the future, which is what we're living now, more successful than the past, than what the gold standard was? And I can't-- unfortunately this is not-- I'd like to be a great social scientists and say I'm going to run a-- run a test here, but I can't run the test with the gold standard.

### Moderator
Claim: Other side. James Grant.

### Scientific Advocate (SA)
Claim: You know, there is, implicit in our opponent's line of argument, the idea that monetary thought runs in a line of progress from ancient times to the present, and we're now at the pinnacle of monetary technique and knowledge with and with

That's the implicit argument. Monetary thought does not run in a line of constant improvement, nor does human thought. Hugh Trevor-Roper wrote about a wonderful essay about the reappearance of witchcraft in the high renaissance, and during this period in which enlightenment supposedly prevailed around the earth, the leading lights of western thought were actually captive in this most cruel hoax of witchcraft. I submit to you that posterity looking back on this moment in monetary affairs will look upon the doings of the world central banks that have, as I say, alighted into a kind of a makeshift central planning from what is meant to be a very simple act. A central bank may look upon this as a period of kind of the dark ages of monetary application and thought. This--

### Moderator
Claim: Let's hear from Steve Forbes.

### Scientific Advocate (SA)
Claim: Money simply enables you to buy and sell with each other, and that's why it has a fixed value, so if you sell a loaf-- a bottle of wine and you want to get four loaves of bread in return, you suddenly don't find because the currencies change you only get three and a half or you get four and a half. It just makes exchange easier. Now, if you don't get fiscal policy right, you don't get regulation right, and things like that, you won't grow. But all it means is you have a fixed measure, just like 12 inches in a foot, for crying out loud, just a fixed measure. And if people realize that tonight, then a lot of mischief will be undone. Remember, median incomes in this country have fallen in the last 10 years because of this funny money. When you have stability--

### Conspiracy Advocate (CA)
Claim: That's nothing to do with it.

### Scientific Advocate (SA)
Claim: a chance to get ahead.

### Conspiracy Advocate (CA)
Claim: So-- listen, your point is a fixed measure in terms of gold, but there are lot of other elements of what we buy during the day. In fact, the CPI has very little gold in it. A smidgeon, but very little.

### Moderator
Claim: Tell us all what CPI stands for.

### Conspiracy Advocate (CA)
Claim: We need stability in terms of the bask of goods and--

### Moderator
Claim: Unpack the term CPI for--

### Conspiracy Advocate (CA)
Claim: Oh, I'm sorry, CPI is the consumer price index.

### Moderator
Claim: Sir.

### Moderator
Claim: Hi, I'm Roy Most of the arguments I've heard have been in the context of economic cycles, but I'm worried about the fact that the world could lose confidence in the United States just like it's lost confidence in other-- like a GE that was a AAA company and decided that, you know, going into the lending business was a good idea. Well, it wasn't. So how would you, on the for the motion side, recast your arguments in terms of confidence in the United States and what the United States has to do to keep that confidence.

### Conspiracy Advocate (CA)
Claim: So we actually-- we do need confidence in terms of-- in terms of not having inflation move around a lot. In fact, when we've had a problem is when we pursued extremely inflationary policies. In fact, this is why we went off Bretton Woods, because we actually had a situation of very bad monetary policy and also bad fiscal policy as a result of fighting the Vietnam War and some serious mistakes that were made. So stability--

### Conspiracy Advocate (CA)
Claim: And by the way, we came-- I would argue we came very close to that under the second Bush administration fighting the Iraq War. We spent too much money and we had-- we've had some issues since then.

### Conspiracy Advocate (CA)
Claim: So I think stability is very key, that people do have to know that the dollar will actually purchase a similar amount of goods and services over time. That, we’re in agreement of. I don’t think there’s really disagreement among us. The question is, what’s the best way to get that to happen? Fixing the dollar to gold is not the best way to get that to happen.

### Moderator
Claim: Is anybody cooking on that moral dimension question?

### Moderator
Claim: Up here.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: We got a moral person.

### Moderator
Claim: I’m going to call on you. Let’s get the mic up to you. And, but I’ll tell you, because I can’t see you, that it likely means--

### Moderator
Claim: I’ll just speak loudly.

### Moderator
Claim: No, no, the camera needs to see you. Where are you? I mean I’m still talking to, for my vision to a--

### Moderator
Claim: I’m up in the second row here.

### Moderator
Claim: Are you upstairs? Come running downstairs. I’m going to go to another question and we’ll take your question in the aisle, seriously. Sir.

### Moderator
Claim: Considering that the U.S. economy is 70 percent consumption based, is it better for the state of the economy to enhance the purchasing power of those consumers or diminish the purchasing power of those consumers over time?

### Conspiracy Advocate (CA)
Claim: Neither. Let’s keep--

### Moderator
Claim: Rick Mishkin.

### Conspiracy Advocate (CA)
Claim: A situation where, when you go out and buy something, it, it costs about the same thing over time, so that you can plan, very simple.

### Moderator
Claim: Your side would agree with that line of thinking, yes?

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: James Grant.

### Scientific Advocate (SA)
Claim: I would, yes, agree, well done Rick.

### Conspiracy Advocate (CA)
Claim: Giddy yap baby, giddy yap.

### Moderator
Claim: Where’s our visitor from upstairs? It’s not hard to get downstairs from there is it? It’s not complicated. I’m afraid I got her lost. We’ll take a few more questions, you in the blue shirt. Yeah, the mike’s coming down there on your left side.

### Moderator
Claim: Henry Sandberg Steve Forbes made a point that a weak dollar policy leads to potential currency wars and better thy neighbor policies. For Mr. Mishkin and Mr. Taylor, do you see this as a potential issue for a weak dollar policy?

### Conspiracy Advocate (CA)
Claim: In fact, I actually strongly oppose a policy which says we’re going to focus on the dollar. A weak dollar policy is not something I’d advocate either. And the reason is this, is exactly is, is you’re focused on how your exports are doing well to competitors. And that’s not a great way to do policy. Central banks and policy makers throughout the world should try to stabilize their economies. And in fact, whatever way the value of the currencies go in that context, so be it.

### Moderator
Claim: Steve Forbes.

### Scientific Advocate (SA)
Claim: Well you don’t get a long term good economic growth with an unstable currency. A weak dollar’s always meant a weak recovery. And what nation has become great with a weak currency?

### Moderator
Claim: Ma’am, it’s your turn. Let’s get the mic to you. I wonder what you’re going to ask.

### Moderator
Claim: It’s not specifically moral, but it is a global--

No, it is, it is.

### Conspiracy Advocate (CA)
Claim: I hope it’s not immoral. Let’s get it right here.

### Moderator
Claim: Well maybe--

### Moderator
Claim: What’s your name please?

### Moderator
Claim: Robin Bluementhal from Barron’s, thank you. Given the fact that we have a much more interdependent economy with a lot more participants in the third world-- in the developing nations, etcetera, and a lot of talk recently about currency wars, could the panelists please address the question of how having a fixed rate of currency would affect the rest of the world and whether it would do something to perhaps stop this kind of snowball effect?

### Moderator
Claim: Okay. Steve Forbes.

### Scientific Advocate (SA)
Claim: Most countries would prefer stable currencies, because it makes trade that much easier. And capital flows that much easier. Which is why in Africa, you have 14 nations that are attached to the Euro, 13 nations that have currency boards where they attach to a currency. So among our trading partners, they find it very disruptive when the dollar goes all over the place and their currencies wobble up and down. So in terms of stability, yes, it would be good for developing countries, because it would facilitate trade and facilitate the trade of capital. You never get ahead in a sustained way, productive way, by fooling around with your money, any more than you would changing, what now, feet in a mile.

### Moderator
Claim: Steve, what did you mean earlier, what did you mean earlier that a weak dollar breaks a sacred trust? And that was the moral issue that you brought up, which sounds like it’s much more about the practicality, there’s something else you’re talking about there.

### Scientific Advocate (SA)
Claim: Yes, because it undermines social trust. We depend on trust. When you go to the restaurant, you trust-- to pay the bill. When you go on an airplane, you trust that these people know what they're doing, and when you do transactions, you trust that you get in return what you've been promised, and you'll give what you promised. And with an unstable currency, what it does is undermine hard work and productive effort and give undue rewards to speculation, undue rewards to commodities.

That's why oil has gone from 21 to 90 or $100 a barrel. That's why you saw this speculation mad, speculation in housing instead of productive facilities or finding cures to diseases. So it misdirects investment. We saw that in the '70s, huge investment in farmland and commodities. They crashed in the '80s. Those investments had to be liquidated. A lot of wasted capital. Stability, again, it's just a measure of value.

### Moderator
Claim: All right, I want to add respond to that issue.

### Conspiracy Advocate (CA)
Claim: I also want the dollar to be a good measure of value, but this is an issue about having low and stable inflation. It's not tying to gold.

### Scientific Advocate (SA)
Claim: Inflation means you're debasing the value of the money.

### Conspiracy Advocate (CA)
Claim: the value of the dollar, it has to do with inflation, and I don't think there's anybody in this panel that is advocating any kind of inflation.

### Conspiracy Advocate (CA)
Claim: Or deflation for that matter. Well maybe you because you said you like it at one period.

### Scientific Advocate (SA)
Claim: to two and a half percent inflation which means higher prices. How does that enrich people when you raise their prices?

### Conspiracy Advocate (CA)
Claim: No, the people sitting around this room spend 99.-something or other percent of their dollars in the U.S. economy. It doesn't really matter whether the euro goes up or down 1 percent in one day or the next. What it matters is that the inflation that impacts everything that we consume on a daily basis, impacts our pay, is stable and is understandable to us. problem.

### Moderator
Claim: Is there any merit to Steve's moral argument, which is essentially saying that people make a deal that when they get a dollar and they put it in a bank, in 10 years, it's still going to be worth what it was when they earned it. Is there a moral argument to that? Is there a social trust that's broken?

### Conspiracy Advocate (CA)
Claim: The social trust in not having situation of having very high inflation, and we agree on that. The question is what is the best-- I use the word "technology," but the best way of getting that to happen, and my view on this is that in fact we do not get the stability that Steve would like to see us have

### Scientific Advocate (SA)
Claim: Rick, you are proposing-- you're proposing that the current regime of literally unprecedented central bank activism is one for the ages. This-- you must-- we must step back a second and realize what's going on in the world. Central banks are conjuring 100s of billions of dollars a year, trillions, from nowhere on the theory, mind you, on the theory that by so doing, they will enhance what is universally a lousy state of trade. This is unprecedented.

## Round 3

### Moderator
Claim: And on that note, I have to announce that this concludes round two of this Intelligence Squared Debate-- where our motion is, "America doesn't need a strong dollar policy." Remember, you voted before the debate. We're about to have closing statements. That's round three, and right after that, you'll vote a second time, and in that way, you will declare our winner. On to round three, closing statements by each debater in turn. Our motion is, "America doesn't need a strong dollar policy." And here to argue against the motion, which means he is for a strong dollar policy, James Grant, editor and founder of Grant's Interest Rate Observer. Buzz, buzz, buzz. I'm going to do that again because I needed-- you all missed the applause cue-- so badly. So I want to introduce James again and give him that robust welcome that you've been doing all night, thanks. No, no, no, no-- We're really out of sync now, I'm going to introduce him again, and when I say his name, then that would be the moment, thanks. And here to summarize his position against the motion, James Grant, editor and founder of Grant's Interest Rate Observer.

### Scientific Advocate (SA)
Claim: You know, Laura Ingalls Wilder wrote a wonderful series of books entitled, "Little House on the Prairie." And one of these books was the biography of her future husband called "Farmer Boy." It was about the life of a hardscrabble dairy farmer and his family in upstate New York. This was during the 1880s when, contrary to Anna Schwartz, America was on fire-- but from a very low base. People were not wealthy.

And one day, the farmer took his son to the fair, summertime, and lemonade was on sale. And the kid screwed up his courage and asked for a nickel to buy a round of lemonade for his friends, and the father astonishingly produced from his jeans a 50 cent piece. The child was speechless, and the father asked him, not wanting to let a moment go by without instruction, asked if he knew what that was, this coin. And the kid, of course, said nothing, how could we say anything? He was literally struck numb. And the father said, "It's money," so he asked the son, "Son, do you know what money is?" Again, silence. And the boy said, "I--" and the father said, "Money is work." And money is the stored value of work; this is the moral of the question.

So you work all day and you earn something for it and that something is called money, and you save some of that because there are only so many heartbeats and a lifetime is precious, you save some of it for later. Now, what our opponents would like you to-- would like you to believe is that through the most dexterous use of advanced mathematics they can calibrate the rate of depreciation in that money so that you will-- won't even notice it. But Steve and I are here to tell you that you will notice it, and we are also here to tell you that the ways of higher mathematics are not the ways towards price stability. What is attempted today is unique and it will not work. Vote against this proposition.

### Moderator
Claim: Thank you. James Grant. And our motion is America does not need a strong dollar policy, and here to make that argument and sum up his position, John Taylor, chairman and founder of FX Concepts.

### Conspiracy Advocate (CA)
Claim: I'm against a strong dollar policy, just to make sure that you know what I'm arguing against here. If stability is the goal of government and of government policy, then it must lean against the wind, whichever way that wind is blowing. If the economy is growing too fast, it must act to slow the economy; and if the economy is growing too slowly, it must act to speed it up. That is the policy that the government has been following for at least since World War II. That policy, at least according to Jan Tinbergen, who did win a Nobel Prize in economics, the first one, given in 1953, said that there were four independent variables that drove the government's ability to control the economy and the economic outputs that are important to the people who live there. And so that's why I'm worried about the social welfare of the people.

Those policies were money growth, interest rate levels, fiscal policy, i.e., the level of taxing and the level of spending, and the currency value. Currency value was one of the four instruments that was chosen to manage the government output. That was in 19-- actually, earlier than 1953. The Nobel Prize is never given to somebody who's done the work right then. But was involved with the Bretton Woods situation, and it was even-- by one of the leading economists of the world recognized that even under that time-- that currency movement was critical to keeping the world moving forward. So my argument is that we should have a flexible policy that allows us to lean into the wind, or lean, -against it, depending on which way we need the government to act. And so, therefore, we need that flexibility and we are against a strong dollar policy.

### Moderator
Claim: Thank you. John Taylor. Our motion is America does not need a strong dollar policy, and here to argue against the motion, meaning he is for a strong dollar policy, Steve Forbes, chairman and editor in chief of Forbes Media.

### Scientific Advocate (SA)
Claim: Thank you, thank you. Keynes was right about over time when you weaken a currency you do undermine the social order. Ask yourselves, why is it that two incomes in the family can't seem to do what one income could do 40 years ago? It's been gradual, but it's been acidic, very real. What the federal reserve is doing is the equivalent of what you might call the federal reserve diet. How much raising the number of ounces in a pound from 16 to 20? Your weight goes down 20 percent; if you weigh 200 pounds, suddenly you're 160 pounds; you weigh 150, suddenly you weigh 120. The fed could do the same thing with a mirror that makes you look svelte and thin. This way obesity goes away, this way you can eat more, weigh less, and look thinner.

Well, put that way, it is absolutely ridiculous thinking if you change a measure of something that, therefore, you can achieve a desired result. Inflation is the equivalent of changing the number of ounces in a pound or changing how a mirror makes you look, it is distortive, ridiculous, and destructive. Inflation is legalized counterfeiting, whether it’s two percent a year or 20 percent. Dollar should be a fixed measure of value. It’s simply a yardstick, to make transactions easier. Otherwise, it’s like a virus in a computer. It corrupts the information; you can’t trust prices. You get a decline in personal incomes, weakening social trust, distortion and misdirection of investment into things that, hard assets instead of things of the future. And also as a transfer of wealth, to nations that are not very friendly to the United States.

Whatever angle you look at, again, you’re not going to make yourself wealthy by fooling around with the integrity of the U.S. dollar. There are other ways you do it, hard work, risk taking, and the like. Thank you.

### Moderator
Claim: Thank you Steve Forbes. Our motion is America doesn’t need a strong dollar policy, and here to summarize his position in support of the motion, he does not think America needs a strong dollar policy, Frederick Mishkin. He’s professor of banking and financial institutions at Columbia Business School.

### Conspiracy Advocate (CA)
Claim: So I’m not going to use higher mathematics. In fact, that’s never been really part of this discussion. But I do want to talk about history. And in fact, there’s a very wonderful example about what happens when you pursue a strong currency policy. It happened to deal with a great man who was great in helping save the world against Hitler, but was not a very good economist. He was not a very good chancellor of the exchequer, which is the equivalent of the finance minister, or Secretary of the Treasury, and this is Winston Churchill.

But what the U.K. decided to do after World War I, was to pursue a strong pound policy. They went back on the dollar-- on the pound-- excuse me, they went back on the gold standard in 1925. They started taking measures to do this starting right after the war. What was the result of this? Well, in order to do this they actually had very tight monetary policy, very high interest rates. Were they successful? Absolutely, in 1925, they went back on gold. What was the outcome? The outcome was, that we had, the British had very high unemployment, they went to over 11 percent employment in 1921. They then had extremely high unemployment all through the roaring 20s when everybody else was doing wonderfully. Then of course it got worse. But then even more important to the current situation, they actually were trying to be virtuous. They had 130 percent of debt, sovereign debt, of their government debt relative to GDP after World War I, because it was so costly to fight it, they actually pursued very, very large, a budget surpluses, excluding interest payments.

What happened to them? Well, they went 140 percent of GDP in 1919, by the time you got to 1929, they were 170 percent of GDP. So indeed, in this current juncture, where in fact we have to worry about fiscal consolidation, this ended up doing several things. It meant it killed the economy. They actually had deflation. You talked-- Jim Grant talked about deflation as being a good thing during a period of American history. It certainly was not a good thing for the British. And what did you end up with? You ended up with a much more dire fiscal situation, even when there was virtue. A strong dollar policy would be something that would be very damaging to the economy and we do not need a strong dollar policy.

### Moderator
Claim: Thank you Rick Mishkin. And that concludes the closing statements and the final round of this Intelligence Squared US debate. And now it is time to learn which side you feel argued best. We’re going to ask you to vote the second time now. Go to the keypads at your seats and register where you stand on this motion. After hearing the arguments, and we’ll see how it compares to your vote before you heard the arguments. The motion is this: America does not need a strong dollar policy. The team arguing for the motion, to be clear, is the team that was against a strong dollar policy. If you agree with them, push number one. If you agree with the other team, America doesn’t need a strong dollar policy is the-- actually I think I’ve confused myself now. Ignore what I just said, because I’m sure you’ve got it. You heard the argument. If you’re with these guys, push number one. If you’re with these guys, push number two. I’m sorry. I knew it was going to happen at some point. But I’ll just restate it. Our motion is, America doesn’t need a strong dollar policy. If you agree with the motion, push number one. If you disagree, push number two. If you are, or remain, or became undecided, push number three.

The system will correct any mis-push. The other keys are inactive and we’ll have the vote in just a few seconds. But while the votes are being tabulated, I first of all want to say that the spirit and the energy and the entertainment value frankly of this rather potentially technical and arcane debate was terrific. It was a lot of fun and you made it really interesting. Thank you for all of that. And to be honest, a lot of times, I have to reject questions, and I don't like doing it. I didn't have to do it tonight. The questions were great. I even liked the elevator ride you took downstairs. Thank you for doing that, so to everybody who got up and asked a question, thank you to you as well. Your applause was robust and spontaneous throughout the evening. It was very, very helpful to us. So a few things I want to tell you about, first of all, we're encouraging anybody here to tweet about the debate, of course. Our Twitter handle is @IQ2US, @IQ2US. The hash tag for tonight's debate is #strongdollar.

Our next debate in New York, our monthly debate, is on Wednesday, April 17. The motion that night will be, "The GOP must seize the center or die." Steve, I'm just wondering if you had a reaction to that at all. Arguing in support of the motion, David Brookes, he's an op-ed columnist at the New York Times, and Mickey Edwards, he's a former Republican Congressman from Oklahoma. Arguing against the motion, Laura Ingraham, host of The Laura Ingraham Show, and Ralph Reed, chairman and founder of the Faith and Freedom Coalition. In about three weeks, we're going on the road. We're going to be in Washington, D.C. It's a special edition of Intelligence Squared. The motion that we'll be arguing on Wednesday, April 3rd, is, "Abolish the minimum wage." You can get details and tickets to this and our remaining spring debates at our website, www.IQ2US.org. The side arguing to abolish the minimum wage is Jim Dorn and Russ Roberts. Arguing against, Jared Bernstein and Karen Kornbluh.

For those who cannot join the live audience either here or in Washington, there are a lot of other ways to catch these debates. You can watch the live stream as I'm sure a lot of people are now on fora.tv. Thank you to all of you who are watching on Fora. And you can listen to these debates, and this one in particular, on NPR or watch it on PBS stations across the country. Just check your local listings for air times-- air dates and times. One other thing I want to tell you that normally we announce the results which I'm about to do-- for the first time, we're going to crunch the numbers in a different way. We're curious to see just in terms of the open-mindedness, and flexibility, and willingness to listen of the audience-- I mean flexibility, not in that way, but in a willingness to listen to other ideas-- we kind of wanted to see how many of you actually did change your positions, and how many of you voted the same way twice, how many of you voted different ways.

What we're going to do is in the-- it takes a little time for us to crunch that. It'll probably take about five minutes. So after I announce the debates and after we've concluded, if you watch-- stay and watch these screens, it'll come up in a couple of minutes, just that analysis, if you have some curiosity about that. So here are the final results. We had you vote twice, both before you heard the debate and once again after you heard the arguments, and the teams-- the team whose numbers have moved the most are declared-- is declared our winner. So the motion is, "America doesn't need a strong dollar policy." Here is the preliminary vote. Before the debate, 24 percent agreed with the motion, 29 percent were against, and 47 percent were divided. What did I do wrong? Oh, okay. I felt like my kids were laughing at me, and I wondered, "What did I do wrong?" those are the first results. Remember now that you have voted a second time. The winner is the team that has changed their numbers the most from the first vote to the second. So we're going to look at the second vote on "America doesn't need a strong dollar policy." The team arguing for the motion, their second vote, they got 54 percent. From 24 percent to 54 percent, that's an increase of 30 percentage points. That is the number to beat. So let's see if the team against-- Yeah, yeah, right. Team against, 29 percent before, they went to 37 percent, that's only eight percentage points they pulled over. It's not enough. The debate goes to the other side. The team arguing against a strong dollar policy has prevailed. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
