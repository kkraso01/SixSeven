# Debate Transcript

Topic: Don't Eat Anything With A Face
Motion: Don't Eat Anything With A Face

Debate ID: 120413%20veggies


## Round 1

### Moderator
Claim: So I’d like to start our program now by welcoming to the stage our chairman, Mr. Robert Rosenkranz.

Hi, Bob.

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hi, Bob. So, you know, as a rule, I'm looking back at this season, and we do a lot of debates that are sort of very, very up in the-- up in the ether. We've done the policies on drones, we've done international labor markets.

And today we're kind of going in the opposite direction and digging down deep inside the human digestive system. And I kind of want to get a sense of what-- what's lighting up this debate for us?

### Moderator
Claim: Well, we did a debate a couple of years ago on the resolution, "Organic Food is Marketing Hype." And if you will recall, you and I were really surprised that it created so much emotional intensity among the panelists, more than any of the other 80 debates that we've done. And I at least came to realize that at least for the people-- many people on the pro side of this motion, this is not simply about a dietary choice. This is a kind of a-- almost a defining expression of who they are as people. It's-- it has an ethical content, an aesthetic content, a kind of political content. It's really about the identity of people who believe passionately in this. And that's why that debate was so successful, and that's why I think this is going to be a very interesting evening.

### Moderator
Claim: Have you seen what's happening on our website already?

### Moderator
Claim: Oh, my god. It is totally crazy.

### Moderator
Claim: Yeah, I mean, you can all still go and join afterwards, but there already is a very, very lively debate among civilians taking place on our website. But beyond a sort of a broad statement of values, are there really separate lines of attacks, sort of empirical attack that these debaters can make?

### Moderator
Claim: Yes. I mean, there definitely are. There are health issues, obviously, with-- both sides will have evidence to marshal on why their preferred diet is in fact better for health. There are environmental considerations. There are ethical considerations about the way animals are treated in this process. There's aesthetic considerations, even if you don't-- they don't quite rise to a level of ethics. I think the whole process of raising and slaughtering animals is one that I think most of us prefer not to think about very much, and we're going to be forced to think about it tonight.

### Moderator
Claim: And what we have tonight are four debaters, Bob, who have life stories that actually interact with this subject in real and vital ways.

### Moderator
Claim: And I have to tell you, I saw them in the green room, and all four of them look very healthy.

### Moderator
Claim: It was very annoying. Let's welcome our debaters to the stage. And thanks to Bob Rosenkranz.

Thank you. And I would just like to invite one more round of applause for Robert Rosenkranz for bringing this here--

The simple act of eating a hamburger is, when you really think about it, one of the great acts of human denial, because what is a burger? It's edible protein in the shape of a disk every single time. And you can order it rare, you can order it well done, you can dress it up in ketchup, you can put a little onion hat on top of it, you can push it around on your plate, you can leave half of it behind, and never once have the thought cross your mind, as you're chomping away, I wonder what she looked like, the cow this burger came from. I wonder where she lived. I wonder how she died. Our thoughts just don't go there, which is fine if you believe that meat-eating is just nature's way, and that meat in the diet makes a lot of sense.

But what if you take the vegan or the vegetarian's view that eating meat is just wrong for your health, for your environment, for your soul. Well, that sounds like the dividing line in a debate. So let's have it.

Yes or no to this statement: “Don’t Eat Anything with a Face.” A debate from Intelligence Squared U.S. I'm John Donvan. We are here at the Kaufman Music Center in New York. We have four superbly qualified debaters, two against two, who will argue for and against this motion: “Don’t Eat Anything with a Face.” As always, our debate goes in three rounds, and then our live audience votes to choose the winner. And only one side wins. Our motion is, “Don't Eat Anything with a Face.” And let's meet the team arguing for that motion. First, let's welcome Dr. Neal Barnard. And, Neal, you are president and founder of the Physicians Committee for Responsible Medicine. You’re a clinical researcher. You study the effects of diet on health.

You do not eat meat now, but you come from a family of cattle ranchers in Fargo, North Dakota. So I'm wondering, do you ever get the craving?

### Conspiracy Advocate (CA)
Claim: You know, I have to tell you, it's like quitting smoking. Any moments of doubt you have as you're getting away from meat are quickly replaced by being very, very glad that you've broken a bad habit.

### Moderator
Claim: You are free now.

### Conspiracy Advocate (CA)
Claim: Free now and glad of it.

### Moderator
Claim: And your partner is?

Ladies and gentlemen--

### Conspiracy Advocate (CA)
Claim: --the president of Farm Sanctuary.

### Moderator
Claim: --Gene Baur. Gene, you are also arguing for our motion, “Don't Eat Anything with a Face.” You are president of the Farm Sanctuary, as your partner just mentioned. That is an animal rescue and refuge organization that you cofounded in 1986. You have been a vegan for decades. And when we first got in touch with you, you were up in Lake Placid, doing, at the age of 50, an ironman triathlon, which you said you were doing largely to prove that a plant-based diet could get you through 140 miles in the race. You did it under 12 hours. Congratulations.

And I just want to ask you, if you had had to narrow down your plant-based diet to just one vegetable to get you through that race, what would it have been?

### Conspiracy Advocate (CA)
Claim: Got to go with the leafy greens. Kale is what it's about.

### Moderator
Claim: Kale. We will be handing out kale in the lobby after the debate. Our motion is, “Don't Eat Anything with a Face.” We have two debaters who are arguing against it. First, please, let's welcome Chris Masterjohn.

Chris, you are a nutritional sciences researcher at the University of Illinois at Urbana- Champaign. You write two popular blogs, The Daily Lipid and Mother Nature Obeyed. And that's hosted by the Weston A. Price Foundation. And when we spoke to you a few months ago, you were taking salsa lessons, dance lessons. You are a competitive dancer. And we learned that your partner is a vegan, whereas you are a guy who not only eats meat, but you also like to eat the bones, the skin, and the organs.

So how does that dance partnership work out?

### Scientific Advocate (SA)
Claim: Well, ballroom dancing, like any other partner dancing, is a form of communication, and no communication can be successful without mutual respect, so, that's how it works.

### Moderator
Claim: So you work it out. Thank you. Thank you, Chris Masterjohn.

And, Chris, your partner is?

### Scientific Advocate (SA)
Claim: My partner is the nation's leading ethical, ecologically conscious, and health conscious farmer. His-- everything he wants to do is illegal. He is Joel Salatin.

### Moderator
Claim: Ladies and gentlemen, Joel Salatin. Joel, you are also arguing against this motion, “Don’t Eat Anything with a Face.” You are a third-generation alternative farmer. Your farm Polyface, Incorporated serves more than five thousand families, ten retail outlets, fifty restaurants.

You are a celebrity in this story ever since being featured in Michael Pollan's book The Omnivore's Dilemma and then later in the documentary Food, Inc. So we know how you treat the cows and the chickens. The question is, how do the cows and chickens treat you?

### Scientific Advocate (SA)
Claim: Well, they treat me like a servant. They wait for me to move them. They wait for me to feed them and water them and take care of them. And I love serving them. In fact, all my life I have served them first before I eat breakfast.

### Moderator
Claim: They have a good deal.

### Scientific Advocate (SA)
Claim: They have a good deal. And-- and it's a distinct pleasure and privilege to be able to serve them and make them happy every day.

### Moderator
Claim: Thank you, Joel Salatin. And those are our four debaters, ladies and gentlemen. So this is a debate. Our motion is, “Don’t Eat Anything with a Face.” We have two team-- two teams, one arguing for and against. Only one team will win. And you, our live audience, will be our judges. By the time the debate has ended, you will have been asked to vote twice, once before and once after the arguments are made.

And the team whose numbers have changed the most in percentage point terms will be declared our winner. So let's go to the first vote. You go to those key pads at your seat. Again, looking at the motion, “Don’t Eat Anything with a Face.” If that statement resonates with you, if you embrace that, you believe it, you champion it, push number one. If you take the opposite view, if “Don’t Eat Anything with a Face" sounds ridiculous to you, nonsense, you push number two. And if you are undecided, which is a perfectly reasonable opening position, you push number three. And you can ignore the other keys. They're not live. And we will lock out in about ten seconds. If you made a mistake, just correct yourself. We'll register your last vote.

And remember how you voted because right after the debates-- the arguments are made-- we will have you vote a second time. And, once more, it's the team whose numbers have changed the most in percentage point terms from their starting position who will be declared our winner.

On to round one. Round one are opening statements from each debater in turn. Our motion is this, “Don’t Eat Anything with a Face.” And here to speak first in support of this motion, Dr. Neal Barnard. He is an adjunct associate professor of medicine at George Washington University School of Medicine. Neal, you can make your way to your lectern. He is also president and founder of the Physicians Committee for Responsible Medicine. Ladies and gentlemen, Dr. Neal Barnard.

### Conspiracy Advocate (CA)
Claim: Thank you. Gene will be talking about the ethical and environmental issues. I'm going to talk about health. In 2009, the Archives of Internal Medicine published a massive research study. The NIH-AARP study had a half a million participants. They were followed for 10 years. Some of them didn't eat meat or didn't eat very much. Some ate quite a lot of meat. And what they showed was that among those eating the most meat, the risk of dying of cancer was increased by fully 20 percent and heart disease deaths were increased by 27 percent among men and 50 percent among women.

And in 2012, the Archives of Internal Medicine published another study. One hundred and twenty thousand people. This was coordinated all at Harvard University. And it showed exactly the same thing: if you ate a lot of meat, your risk of dying of heart disease was much higher; your risk of dying of cancer was higher. And studies have clearly shown that people who don't eat meat cut their cancer risk by anywhere between 12 and 40 percent. Well, why would meat be linked to cancer? Hold that thought for a second. I grew up in Fargo, North Dakota, and I come from a long line of cattle ranchers. My dad raised cattle, my grandpa raised cattle, as far back as I can trace. Now, my dad did not like the cattle business. He objected to it a great deal. He went to medical school. He spent his life treating diabetes in Fargo, North Dakota. But we still ate like we were in the cattle business.

Every day it was roast beef, baked potatoes, and corn, except for special occasions when it was roast beef, baked potatoes, and peas. And my grandfather had a heart attack, and he then became quite severely demented, and he died. And we took that as normal because he was old. He was 65. My other three grandparents lived longer, but each one of them succumbed to severe dementia year after year after year, and they all finally died. And none of us thought that maybe food had something to do with this. Now, I got my first wake-up call at Fairview Hospital in Minneapolis, where I was the autopsy assistant. One day a man died in a hospital of a massive heart attack, probably from eating hospital food, but that's another story. And the pathologist came in the room, and he knew that I was headed for medical school. So he removed a section of ribs, and he sliced open one of the coronary arteries, and he said, "Look inside."And it looked like chewing gum in this coronary artery, but when I felt it, it was hard like a rock. And he said, "That's atherosclerosis. That's your morning sausage, Neal. That's your bacon, Neal. That's your roast beef in there." And he said, "We see the beginnings of this in three quarters of people by age 23," which happened to be the age I was at the time. And he wrote up all his findings. He left the room. And I had to clean up. I took the ribs. I put them back in the chest. I tried to make them fit with the other ribs. And I sewed up the skin, cleaned up, and I went up to the cafeteria, where they were serving ribs for lunch. Now, fast forwarding a little bit, a little-- a few years later Dr. Dean Ornish brought in to a research study people who had atherosclerosis, they had narrowed arteries, he took the meat out of their diets, and something happened that had never been shown before. The arteries actually started opening up again, so much that you could see a measurable difference in 82 percent of patients in the first year with no surgery and no medications.

Grass-fed beef does not do that, including the beef my family raised. It just doesn't work. Eating chicken and eating fish just can't do that. And so my research team tried this same kind of diet for people who wanted to lose weight, and NIH funded us to try this kind of diet for people who had diabetes. And it works better than any other diet. Why? Because when you get meat out of the diet, meat has fat in it and every gram of fat has nine calories. That's its job. You get it out of the diet, and you get rid of a lot of calories. Meat has zero fiber, none. Fiber fills you up without calories, and if the foods you have don’t have it, you’re going to eat too much, and you’re going to gain weight. Why diabetes? Because getting the meat out of the diet helps fat to drain out of the muscle cells, allowing insulin to start working on its own.

And we saw something I never saw in medical school, which is diabetes improving, sometimes even disappearing for all intents and purposes.

And when we look at broad population studies, the meat-eaters are always the heaviest group, and the people who eat no meat are always the thinnest. Diabetes is the same way. It’s about 8 percent of adult meat-eaters, and among vegetarians, 3 percent. High blood pressure, exactly the same. You just don’t see it very much in people following vegetarian diets. But why more cancer? Well, when we heat up meat, something happens that doesn’t happen with plant foods, and that’s that carcinogens called heterocyclic amines form in the meat, especially chicken, but any kind of skeletal muscle, which is what meat is. But that’s not the only carcinogen. We also see polycyclic aromatic hydrocarbons, there’s heme iron, there are a lot of things. Plus meat doesn’t have fiber that protects you. It doesn’t have any vitamin C. It’s low in important antioxidants.

So it’s like tobacco. We know for sure tobacco causes lung cancer, but we’re not 100 percent sure which part of the tobacco smoke is responsible.

We know clearly that meat causes cancer in other parts of your body. The stomach, the intestinal tract-- but we’re not sure. Is it the HCAs? The PAHs? We’re not quite sure yet. I asked Dr. Richard Leakey, the famous paleoanthropologist, how did we get into meat- eating? And he said humans are naturally primates. We’re great apes. We are not carnivores, and we ate things we could pick with our hands, until the Stone Age gave us stone tools, and meat-eating began, he believes, as scavenging. Lying with leafs and bones, we would scrape it up with these stone tools that we now had. Problem: we have pre-Stone Age bodies that get cancer and get heart disease when you eat meat. Of course, if your life expectancy is 35 or 40, it doesn’t matter, but if you live to a mid-age and beyond, then these things matter a lot. And what matters now is Alzheimer’s disease. We have now learned that a diet high in saturated fat-- that’s the bad fat in meat-- is linked to Alzheimer’s disease in studies in Chicago, in New York, in Finland.

And meat-eaters actually have very poor nutrition. Yes, they get protein, but they don’t get many vitamins, they don’t get any complex carbohydrates, they’re missing fiber. A vegetarian diet gives you all the protein you’re going to need, plus many more vitamins, many more minerals. So Bill Clinton did. Al Gore did it. Bob Barker did it. Serena Williams did it. Since 2004 meat-eating has dropped by 9 percent. That’s where we’re going. That’s the future. Thank you very much.

### Moderator
Claim: Thank you Neal Barnard. Our motion is: “Don’t Eat Anything with a Face.” And now our first debater to speak against the motion: Chris Masterjohn is a researcher at the University of Illinois at Urbana-Champaign, where he studies interactions between fat- soluble vitamins A, D, and K. Ladies and gentlemen, Chris Masterjohn.

### Scientific Advocate (SA)
Claim: First, thank you to everyone involved tonight for providing us with an opportunity to debate this issue in such an excellent forum.

And John, every time that I buy meat, I always think about the conditions the cow was raised in. Tonight my partner Joel Salatin and I will urge you to vote against the motion, "Don’t Eat Anything with a Face." I’d like to begin by telling you a personal story. When I was 18, I became a vegetarian, because I believed that this would be the most healthful, ethical, and ecologically conscious dietary choice I could make. Six months later I became a vegan, meaning I excluded all animal products from my diet. After all, I had to follow the inevitable conclusion of my own logic. All animals die regardless of whether we kill them, and what I opposed most strongly was the cruelty and abuse seen in the industrial factory farm, which is often worse for laying hens and dairy cows than it is for animals raised for meat. I’m sure that my opponent, Gene, will explain some of this abuse to you later tonight.

A year and a half down the road, it became clearer and clearer that my dietary journey through vegetarianism and veganism was failing to bring me into any promised land of vibrant health. Many pre-existing health problems, that had mostly been a nuisance to me in the past, devolved into burdens that crippled my day-to-day function. My digestion worsened, my energy tanked, and my irritability skyrocketed. Intense exercise began giving my anxiety and heart palpitations. In a single dental examination, I found out that I had over a dozen cavities and needed two root canals. Worst of all, my anxiety disorders aggravated to the point that I had several panic attacks per week and was often afraid to eat my own food or even begin driving my own car.

But then I encountered the work of Weston Price, which really changed my life. Weston Price was the first research director for what became the American Dental Association and was a pioneer in nutritional and medical anthropology.

He documented-- all over the globe, in different climates, in different altitudes and latitudes, in groups with radically different cultural and genetic backgrounds-- the consistent effects of the nutritional transition from traditional diets to what he called the “displacing foods of modern commerce”: white flower, white sugar, white rice, vegetable oils, and canned goods. In every case, the transition was one from radiant and vibrant health to not only tooth decay and dental deformities, but often to tuberculosis, cancer, ulcers, appendicitis, cystitis, gallbladder disease, physical degeneration of all kinds. All of the groups that successfully maintained vibrant health on their traditional diets placed special emphasis on the need for animal products rich in fat-soluble vitamins. Some groups emphasized dairy products, others emphasized organ meats and egg yolks, others the animal life of the sea, and yet others small animals and insects. Price went on to provide laboratory and clinical evidence that the emphasis on these foods was in fact a critical reason for the success of these traditional diets.

After reading Price's work, I began emphasizing high-quality, nutrient-dense animal foods in my own diet, and within months my anxiety disorders completely disappeared, and my tooth decay came to a crashing halt. I truly felt like a new person. Indeed, my mental and physical health had undergone a revolution.

My experience raises two questions: First, am I alone in it? And second, what happened to me and why? The scientific literature shows that I'm not alone. Seven out of eight relevant studies found that compared to omnivores, vegetarians have a greater risk of mental disorders, including eating disorders, depression, poor self-esteem, anxiety, and contemplated or attempted suicide. A study published in 2010 found that compared to omnivores, vegans had eight times more lesions involving poor mineralization of the teeth. Why might this be? Well, simply put, many nutrients are much easier to get from animal products than from plant products. Perhaps the most underappreciated of these is cholesterol. Many people are aware that high cholesterol is associated with heart disease.

But few people are aware that low cholesterol is associated with mental disorders, violent and self-injurious behavior, hemorrhagic stroke, cancer, and increased total mortality. Dr. Barnard himself has published scientific papers showing that, although his diet leads to increased intakes of many nutrients, primarily from fruits and vegetables, it also leads to decreased intakes of vitamin B12, vitamin D, and selenium, and fails to guarantee an adequate intake of zinc. Dr. Barnard recommends supplementing with vitamin B12 and vitamin D and emphasizing vegan foods rich in zinc, but the foods richest in zinc aren't vegan at all. They're oysters, beef, and cheese. It is unlikely that supplementing our way out of these nutrient deficiencies, moreover, will be a complete success, because all of these nutrients have very complex interactions with the other components present in the foods in which we find them. Vitamin B12, for example, synergizes with key amino acids found most abundantly in meat, bones, and skin. Is it possible to design an adequate diet that does not include the meat of animals with faces?

I actually think that it is. It would include egg yolks, dairy products and shellfish. Shellfish are neither vegan nor vegetarian, after all; they're animals. But many people might argue, perhaps correctly, that they don't have faces. Such a diet, however, would not be adequate for everyone. Let me provide, by way of example for now, just one reason why: Vitamin A. Vitamin A is found most abundantly in liver and cod liver oil or the liver oils of other fishes, while more moderate amounts are found in egg yolks and butter fat. Red, orange, yellow and green vegetables provide carotenoids such as beta- carotene which we can convert into vitamin A. However, the efficiency of this conversion is relatively poor and highly variable. Half of people with European ancestry have a genetic variant that cuts their ability to make the conversion in half, and a third, other variant that cuts it fourfold. These people are extremely unlikely to get enough vitamin A from plant foods alone and would do best if they included liver or cod liver oil in their diet which are derived from animals with faces.

In order to construct an optimal dietary approach that is robust to error and adaptable to individual needs, we need to abandon the false dichotomy between healthy plant foods and supposedly unhealthy animal foods, and instead embrace the health value of high-quality, nutrient-dense foods of all types. Fortunately, animal foods are highest in quality and richest in nutrients when the animals are raised in an ethical and ecologically conscious manner, with high-quality soil, out on pasture in the fresh air and sunshine. My partner Joel Salatin will explain more about how this is done and will conclude our opening argument for why you should vote against this motion.

### Moderator
Claim: Thank you, Chris Masterjohn. And here's where we are: We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion: "Don’t Eat Anything with a Face." You have heard the first two opening statements, and now onto the third, to debate for the motion, “Don’t Eat Anything with a Face.”We're going to bring to the lectern Gene Baur. He is president and co- founder of the Farm Sanctuary, the nation's largest farm animal rescue and protection organization. Ladies and gentlemen, Gene Baur.

### Conspiracy Advocate (CA)
Claim: Thank you very much, and thank you for this opportunity. It's wonderful to be discussing this issue. Most people don't think enough about our food choices and about the animals who suffer terribly for the meat, milk and eggs that is produced in this country. I grew up eating animals without really thinking about it. My parents ate animals, my brothers and sisters ate animals. Everybody around me was doing it, so I just adopted the habit, without really thinking about it. But as I started learning about the fact of how these animals were treated and about the fact that I could live well without eating animals, I made the choice to become a vegan. I did that back in 1985.

It's one of the best choices I've ever made. And the fact that we can live well without eating other animals, without causing harm, I think is the key question here, the key point.

If we can live well without causing harm, why wouldn't we do it? And the main reason is that we just sort of grow up doing it, without thinking about it. So, the question is, how can we live well? How do we want to feel when we treat other animals the way we treat them? And on these factory farms, they're treated horribly. I visited farms across the country. I've seen animals put in these small cages where they can't move. You walk into these farms, and you're hit with this horrible stench. They're living in their feces. They're screaming to get out of their cages, and they live that way their whole lives, and then they're killed young so that we can eat them. And, you know, when people see this, they don't like it. And oftentimes people say, "Don't tell me. I don't want to know," when the issue of factory farming comes up, because it is so upsetting and because we are compassionate, and because we are hardwired to have empathy.

When we look at other animals, and we see them suffer, when we look at other people, and we see them suffer, we feel something. That is one of the best parts of our humanity, this empathy, this ability to feel something when we look into somebody else's face. When the executioners at the Salem witch hunts were charged with killing witches, they were told, “Don't look into their face, because if you do, they'll cast a spell on you, and you won't be able to kill them.” Basically, when you look into their face, there's empathy, there's a connection, there's an understanding that there's a living creature there. And when you abuse another animal or another person for that matter, there's this tendency to try to denigrate them and to say, well, they don't really have feelings. They don't really deserve any better. And that's unfortunately what has happened to farm animals. There are these misconceptions and incorrect ideas about animals on farms not being smart. For instance, people think turkeys are so dumb they'll go outside and they'll drown in the rain. This is one of these myths that people say, probably to feel better about mistreating animals.

But we've raised turkeys at Farm Sanctuary for many years. They go outside. They've never gone out and drowned in the rain. They enjoy, you know, going indoors and outdoors. And when the animals come to us, they're often afraid because they've only known cruelty. But when they start recognizing they're in a safe place, and they start being treated with kindness, they respond. And it's a beautiful thing to see. We had a turkey at our farm in California we used to call Lydia the Hugging Turkey, because you'd go out into the barnyard and kneel down, and she would come up to you, and she would crane her neck around your neck like she was giving you a hug. So these animal show companionship and friendship. And I'm not the only one that has seen this. People who visit Farm Sanctuary and work there have seen this. Jane Goodall, also, is now speaking out about the fact that these animals have feelings and much more intellectual and emotional depth than we ever knew before. She said, "Farm animals feel pleasure and sadness, excitement and resentment, depression, fear and pain.

They are far more aware and intelligent than we ever imagined. They are individuals in their own right." Now, on factory farms, these animals are treated horribly. I think there is widespread support among this panel even among those who think that it's okay to eat animals, that factory farming is an abomination, that it should not occur. It is outside the bounds of acceptable conduct. The real challenge is discussing, what about animals who are not treated so badly? Should we eat them? And I would suggest, no, we should not. We do not need to. We do not need to cause them harm. And whenever animals are seen as consumable products, there is a tendency to treat them not very well. I've been to factory farms, I have been to small farms, and even on these farms that are purported to be humane, there are significant problems. Whenever the animals are seen as consumables, the relationship is one of exploitation, and that is a huge problem that we need to face, and something we don't need to do.

In addition, animal production is very wasteful. The United Nations came out with a report a couple years ago talking about how animal agriculture is one of the top contributors to the most serious environmental problems we're facing on the planet, including climate change. And these animals are routinely fed antibiotics as well, so we have these antibiotic-resistant pathogens that are now developing on these farms. And so these are other problems associated with this attitude of looking at animals just as commodities. So, eating animals is bad for the animals. It is bad for the environment. It is bad for us. It is not necessary. We can live and be healthy on eating plants alone. I urge you to vote yes on the motion that we should not eat anything with a face. So thank you very much.

### Moderator
Claim: Thank you, Gene Baur. And that's our motion: “Don’t Eat Anything with a Face.”And here to argue against this motion, we want to bring to the lectern Joel Salatin. He is a full-time farmer in Virginia's Shenandoah Valley and the author of eight books. Ladies and gentlemen, please welcome Joel Salatin.

### Scientific Advocate (SA)
Claim: We're going to have an interesting evening since potatoes have eyes. Corn has ears. Cabbages have heads. And, goodness, what are we going to do about those navel oranges? Eating things with faces is great, so I'm happy with our negative position. Chris and I have some overarching positions.

Number one: affirmative studies, affirmative studies impugning animal farming or omnivorous nutrition must be based on pasture-based data, not chemical, pharmaceutical, concentrated animal feeding operations, like CAFOs. On our farm, the nutrient difference in folate-- just pick one nutrient-- between a USDA-blessed-- we call it the "U.S. duh"--The USDA-blessed egg at 47 micrograms and a Polyface-pastured egg at 1,200 micrograms are incomparable. Chris and I categorically reject any and all CAFOs, chemical fertilization, aquifer irrigation, and genetic modification, as being necessary or meritorious in food production. Factory food has no merit in this debate, and none of the studies will hold water if they use factory food, and you'll find that they all do.

Number two: Plants are sentient beings. They attack, communicate, respond, and build communities. Their language is chemical. Plants have faces, even though we might not recognize them. The affirmative promotes a segregated view toward life. Chris and I promote an integrated view.

Number three: The motion before you does not allow for climate, cultural, economic, or hunger contingencies. An essential thing: the affirmative has not asked for any contingencies. If the affirmative wanted some contingencies, they should have worded the resolution or not agreed to their position. Chris and I will hold them to the motion's clarity.

Number four: Domestic livestock are owned by 60 percent of the world's poor, primarily because they represent portable wealth to the unlanded poor and nutrition density protected from spoilage and vermin. The affirmative position is a direct attack on the world's poor.

Number five: Not a single affirmative study assumes modern, pasture-based models, using high-tech electric fencing, portable shade cloth shelters, permaculture, hydration techniques, or cottage-based, localized processing infrastructure. This oversight dooms every affirmative conclusion to obsolescence.

Number six: Life requires death.

The fact that all of us can come to this luxurious room, comfortable and well-fed, and entertain ourselves by debating whether we should viscerally and actively participate in our role on an ecological continuum is bizarre. Native Americans ate 10 pounds of buffalo a day, when they could get it. And plenty of starving children in the world would be grateful for a morsel of anything, whether it wiggles or not.

Number seven: Everything is eaten and being-- is eating and being eaten. If you don't believe that, go lie naked in your flowerbed for three days, and see what gets eaten.

Number eight: Humans are the ultimate caretaker species, and the notion that my dog is my uncle is my cat is my child does not indicate an evolutionary newfound state of heightened spiritual cosmic awareness, but rather a profound devolution into ignorance and disconnection to our ecological umbilical.

Number nine: Killing and eating are interchangeable. If it is wrong to eat, then it is wrong to kill. Killing without eating is an insult to life and resource.

Number ten: Environmental integrity demands certain patterns whether we like them or not. Chris and I believe these patterns supersede Mickey Mouse, Bambi, and Templeton, the rat. When my parents purchased 550 acres in Virginia’s Shenandoah Valley in 1961, it was a cheap and great. Gullies, many measuring maybe 12 feet deep, incised the fields-- deep scars, testifying to the death from grain production. Organic matter averaged one percent. Large areas that had lost three to five feet of top soil were barren rock. At the time, the farm would only support 20 cows. Now, a mere 52 years later, organic matter averages 8 percent, the gullies are healing, the barren rock faces are covered with a foot of new top soil, and the farm supports 150 cows. Out of ashes came a phoenix. How? By mimicking the foundational principle of ecological health.

Animals (primarily herbivores), perennials, and predation. In case you missed this in biology class, here’s how it works: Sunlight converts to biomass through photosynthesis. The biomass grows slowly at first, then rapidly, then goes into senescence. The herbivore prunes the senescence biomass back to restart the rapid growth cycle. Predation-- both carnivorous and otherwise, like weather or fire-- creates movement patterns, even intensifying herbivores into mobs. All fertile soils have been built with perennials, herbivores, and predators, not tillage and annuals, like wheat and corn. By practicing this mob stocking herbivorous solar conversion lignified carbon sequestration fertilization, our farm is growing soil, growing organic matter, healing the water cycle, and pulling greenhouse gases out of the atmosphere. Every single nook and cranny on the planet is full of animals. Why? Because they convert biomass into soil. From kitchen scraps fed to the homestead chickens to caribou converting lichens to manure, animals create ecological integrity. Humans can’t eat most biomass.

The few types we can, like vegetables, require extremely fertile soil. Not one single organic vegetable or produce regimen exists that doesn’t rely on animal or fish manures for fertility. The principle of life requiring death or sacrifice is a most profound spiritual and ecological truth. How we treat the plant and animal in life impart sacredness to the sacrifice. The reason herbivores and seafood form the basis of all diets in antiquity is because these were the only nutrient-rich options that didn’t require tillage and storage. Until mechanization and cheap energy, tillage was extremely laborious. Another critical ecological function for animals was that they were the only way nature had of moving around fertility. Gravity pulls biomass downhill. The only way to defy gravity and pull it back uphill is to either walk it up or fly it up. What makes it do that? Predation. The most efficacious way to remediate environmental degradation while producing the nutrition required by our human population is to embrace animal husbandry in a biomimicry paradigm: perennial, animal, predator.

Alan Savory’s eloquent TED talk explains proper animal management is the best hope for stopping climate change and desertification. So vote for ecological integrity and nutritional superiority that we should eat both plants and animals. In case you forgot, it’s the negative position in this debate.

### Moderator
Claim: Thank you, Joel Salatin.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is, "Don’t Eat Anything with a Face." And now we move on to round two of this Intelligence Squared U.S. debate. I’m John Donvan. This is our motion: "Don’t Eat Anything with a Face." We have heard from each of our teams in opening statements. We heard from Neal Barnard and Gene Bauer, who are arguing in support of the motion, "Don’t Eat Anything with a Face." We heard them make the argument that meat raises the risk of getting sick; that it is simply wrong to kill animals for food, to deny their feelings, and to-- they argue for a respect for animals as a fellow life form.

They basically argue, bottom line, that we can live well without causing harm to animals, and killing them for food is indeed causing them harm. The team arguing against the motion, Chris Masterjohn and Joel Salatin, they’re saying it’s basically-- it’s about the nutrition, folks. And they’re saying there is nothing as nutritious as meat, that it delivers nutrients in far greater density than any other form of food, and they also make the interesting argument that even to be discussing a world of veganism is really a privilege of modernity – that in fact in parts of the world that are not as privileged as the United States, an animal is an investment, an animal represents wealth, and an animal represents food that can be kept alive and fresh until the time that it has to be eaten, and that's the way it always was until very recently. Now, we've seen several strains of argument here: practical, health, and ethical.

And I'd like to explore all of them. I want to stipulate that it's clear that these debaters do agree about one thing. No one on this stage is in favor or arguing to justify factory farming. What they are disagreeing about is whether it is right to kill an animal for food or not. So we want to be focusing on that aspect of this. And on that, there is a strong disagreement among them. What I want to do is take to the side that's arguing for the motion, "Don’t Eat Anything with a Face," who opened with the health argument, that food-- that meat-- makes you sick, that this is well-documented. And we heard personal testimonial of Neal Barnard as a young medical student, seeing that for himself, firsthand, with patients that he was treating, and bring to you, Neal, your opponent Chris Masterjohn's testimony to the opposite. He went on a vegan diet, got really, really sick from it. His teeth started falling apart. He felt terrible, and he went back to meat because his argument is that's where the nutrients are. Neal Barnard.

### Conspiracy Advocate (CA)
Claim: Well, I don't want to speak for Chris. But having read the documents that he circulated in advance, he had the psychiatric issues before he went vegetarian, while he was vegetarian, and after. And if I read them correctly, he said that eating cholesterol was not sufficient, that he also needed religion in order to fight his way back. And I say this not to mock it, but to say that these problems were pre-existing before the diet change. And the studies that he cited were observational studies. We have put this to the test. We worked with the insurance company Geico in ten different cities. And we introduced plant-based diets for about 300 people, and we measured levels of depression, levels of anxiety. They got better. And we have now about three randomized trials along these lines. People get better. And as people who have done this, they find they feel more energetic, which is why a lot of athletes are doing it. Dental health acts exactly the same. In fact, even the study that he cited, when you looked over the longest period of time, the vegetarians kept their teeth more while the meat-eaters tended to lose them. This is not a reason to have a--

### Moderator
Claim: Let's let Chris respond. And, Chris, we're not-- we're not going to make this a debate about your personal history, okay? And I don't at all think that that's the spirit in which Neal responded, so he was-- he's making the point on the science, and I'd like you to respond on the science as well.

### Scientific Advocate (SA)
Claim: Sure. So I think – the science about whether those studies indicate a causal relationship between vegetarianism and mental disorders?

### Moderator
Claim: No.

### Scientific Advocate (SA)
Claim: Or all of it?

### Moderator
Claim: Bottom line, you made an argument that you can get sick being a vegan.

### Scientific Advocate (SA)
Claim: Oh, sure.

### Moderator
Claim: He's making an argument that there's a whole load of science and statistics that just say you're wrong.

### Scientific Advocate (SA)
Claim: Right. Well, Dr. Barnard is entirely correct, first of all, that all of the studies that I cited about vegetarianism and mental disorders are observational studies, and they cannot show whether vegetarianism causes mental disorders, mental disorders cause vegetarianism, or there's some other type of-- or there's some other type of relationship. This is-- I mean, it's serious. Any of those are possibilities, and they're not mutually exclusive. What we do know is that there is a wealth of information about biochemistry and the effects of the specific nutrient deficiencies that can be most common in vegetarian diets that are all related to mental health. And so biologically, it's very plausible. But I would like to also make the point that Dr. Barnard cannot have his low- fat, low-glycemic, vegan, chocolate cake and eat it to, because the studies that Dr. Barnard cited at the beginning about the relationship between eating meat and cancer and coronary heart disease are also observational studies, and they also tell us absolutely nothing about cause-and-effect relationships. And--

### Conspiracy Advocate (CA)
Claim: Well, let me take issue with you there, if you don't mind.

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: Neal Barnard.

### Conspiracy Advocate (CA)
Claim: I'm going to suggest that, Joel, if I went to your farm, and I got one of your chickens who, as I'm sure you'll agree, they are not natural chickens.

These are-- these are freaks of breeding over time. They are bred to become obese. And if I took one of them who maybe never had even any chemical given to that chicken, but if I kill them and cooked them, these same heterocyclic amines, these clear- cut carcinogens, would form on your chickens just like any other. So, regardless of whether it's organic or not, cooking skeletal muscle produces carcinogens. And that's why every epidemiologist agrees that vegetarians have less cancer. There's just no question about it.

### Scientific Advocate (SA)
Claim: Well--

Anything, if you're trying to create cancer out of something-- an excess of anything can - - you can drink too much water and get sick.

So, you know, in Argentina, their per capita consumption of red meat is double what it is in the U.S. In Argentina, the average person eats half a pound a day of red meat, and their cancer rate is half of the U.S. Why? Because it's grass-finished beef. And so there is a huge difference in the nutritional profile. I mean, you know, Chris would probably be able to speak to this better, but there are-- you know, there are carcinogens in virtually all foods. And, you know, you can isolate those however you want to.

### Moderator
Claim: And Neal, or Gene, the argument that your opponents are making as well, that meat is just really damn nutritious and nothing can match it, and if you want B12 in your diet, which is vital, you're not going to get it without eating meat, unless you take supplements. Gene, do you want to take that?

### Conspiracy Advocate (CA)
Claim: Yeah, well, I--

### Moderator
Claim: Gene Baur.

### Conspiracy Advocate (CA)
Claim: --I’ve been a vegan since 1985, and I have not been very religious about taking B12 supplements. But I get everything I get from plant sources, so the B12 I get is from plant sources. B12 is the only nutrient that you need to think about, and that's made by microorganisms. So it's available in the environment. It's available in the soil. And otherwise you get everything--

### Scientific Advocate (SA)
Claim: So it's in soil?

### Conspiracy Advocate (CA)
Claim: There's soil on vegetables, isn't there?

### Scientific Advocate (SA)
Claim: Yeah.

The thing is, don't wash your kale.

### Moderator
Claim: Joel Salatin, and then I'll come to you. Joel Salatin. Sorry.

### Scientific Advocate (SA)
Claim: So the point is, don't wash your kale.

### Moderator
Claim: No.

### Conspiracy Advocate (CA)
Claim: Don't sanitize and don't zap it.

### Moderator
Claim: Neal Barnard.

### Conspiracy Advocate (CA)
Claim: Vitamin B12 is not made by animals. It's not made by plants. It is made by bacteria. And historically, one theory is that the bacteria on plants, on the soil, on our fingers, in our mouths, give you that 2.4 micrograms, the tiny amount that you need. The other theory-- and people have shown that the bacteria in the human digestive tract actually produce absorbable B12, but in modern civilization, most of those bacteria are gone. They're too low. They produce the B12 so you can't absorb it. But in more primitive cultures, in cultures in developing countries, you do see production of B12 in humans just like in the other primates, and it's fully absorbable. The truth is, nobody really knows for sure.

But what we do know is that most B12 people in hematology clinics are meat-eaters. And they are low on B12 because they are not absorbing it. It's hard to absorb B12 from meat. You need good stomach acid. You need intrinsic factor. And the U.S. government recommends that all meat-eaters over the age of 50 take B12 supplements because otherwise--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --they are deficient.

### Moderator
Claim: Chris Masterjohn.

### Scientific Advocate (SA)
Claim: Yes. I would like to take this discussion back down to earth for a minute. So to put this in perspective--

### Moderator
Claim: What do you mean by that? Why do you feel--

### Scientific Advocate (SA)
Claim: Well, I mean, no, these are all great points, and it's a fascinating discussion to think about how we could get vitamin B12 from intestinal bacteria or from soil or from feces left on vegetables. But to--

### Conspiracy Advocate (CA)
Claim: No, that's not what I'm arguing.

### Scientific Advocate (SA)
Claim: I think we want to-- I think we want to--

### Conspiracy Advocate (CA)
Claim: I'm not arguing that. I'm arguing, take a supplement because you don't want to be relying on it.

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: Okay. That’s good clarity.

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: I mean, to put this back into context, we should just look at what are the studies on vitamin B12 deficiency levels in vegetarians, in vegans, and in elderly subjects who have poor digestion.

And, so, one of the ways that we can get a bird’s-eye view of this literature is to look at what's called a meta-analysis, which is just a study that looks at all of the other relevant studies and pools the data together. And the most recent study-- the most recent pooled analysis of 18 studies using the highest quality markers of vitamin B12 deficiency found vitamin B12 deficiency in between 30 to 73 percent of vegetarians, between 43 to 90 percent of vegans, and the length of time on the vegetarian diet was also related to the deficiency. So, for example, one study found that 67 percent of lifelong vegetarian children and only-- or 25 percent of other vegetarian children-- were deficient. So it's a deficiency that can take years and years to develop.

### Conspiracy Advocate (CA)
Claim: But studies also show that giving meat to those children doesn't solve the problem. What solves the--

### Moderator
Claim: Is that-- is that true?

### Conspiracy Advocate (CA)
Claim: Absolutely. You can take a B12 deficient person, give them meat, and they will still be B12 deficient.

What everybody recommends, every doctor always recommends, don't rely on meat for B12. They always recommend a supplement because it's cheap, and it's safe. And that's true whether you're a vegan or a meat-eater. It's a complete red herring. Everybody ought to be taking B12. It's been the U.S. government position for years. They say start at 50. I--

### Scientific Advocate (SA)
Claim: Well, I certainly believe everything the U.S. government says.

### Moderator
Claim: It’s Joel Salatin.

### Conspiracy Advocate (CA)
Claim: You can take your chances. But the other thing to just mention, when you're talking about grass-fed beef, when my grandfather had his heart attack and died, it was grass- fed beef that my family raised, that we all ate because there weren't CAFOs back then.

### Scientific Advocate (SA)
Claim: You know, you're trying to poke fun at this side for not being scientific or anecdotal. What's more anecdotal than when you're dad died? Mine-- my mom's 90, independent, drives every day, dances every weekend. She's 90. She's eaten meat from day one, all of her life. The fact is we're different.

### Conspiracy Advocate (CA)
Claim: We are different.

### Scientific Advocate (SA)
Claim: We're different.

### Conspiracy Advocate (CA)
Claim: Most smokers don't get lung cancer.

### Scientific Advocate (SA)
Claim: That's right, yeah.

### Conspiracy Advocate (CA)
Claim: Most smokers don't get lung cancer, but so many do. Most meat-eaters are not going to get colorectal cancer, and they're not going to get stomach cancer, but so many do.

### Moderator
Claim: But they're saying that you have a problem in establishing causality.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: You do?

### Conspiracy Advocate (CA)
Claim: Oh, yeah, well--

### Scientific Advocate (SA)
Claim: Yes. Absolutely.

### Conspiracy Advocate (CA)
Claim: --It depends on what we're talking about. With something like cancer, you can't ethically do a randomized trial where you have half the people eat meat, and you track their cancer risk and have the other become vegan. There are ethical issues about doing that because it is so clear that meat is linked to cancer, you couldn't get-- you couldn't do such a study. You couldn't ask half a group to smoke cigarettes. We know cigarettes cause cancer. We know meat is going to increase cancer risk.

### Scientific Advocate (SA)
Claim: There are two things that we could look at to improve our perspective on the meat and cancer relationship. One would be to try to control for all the differences between vegetarians and non-vegetarians to better understand in those observational studies.

The other point would be to go back to the evidence that I brought up in the beginning. And I'd like to start there just very briefly. Weston Price found, in numerous cases with good data from the same doctor reviewing--

### Moderator
Claim: Who is Weston Price?

### Scientific Advocate (SA)
Claim: Weston Price, I mentioned his research in the beginning--

### Moderator
Claim: Oh.

### Scientific Advocate (SA)
Claim: --he was the first research director for the American Dental Association and a pioneer in nutritional and medical anthropology. His approach was to try to look at populations that were actually free of disease. And so what he found was that in some cases-- his data on tooth decay were far better than his data on cancer. But he had some data on cancer, and there were cases of populations that did not have modernized diets but had meat in their diets that were free of cancer. What that means is that even the most vulnerable members of the population were protected. We don't know if they were protected by meat. But if you take a population of smokers, that's not what you find.

There is no population of heavy smokers where all of them are free from cancers. So it’s a fundamentally different point.

### Moderator
Claim: So, you're also saying, you also have the causality problem.

### Scientific Advocate (SA)
Claim: Yes. Yeah, absolutely. So--

### Moderator
Claim: Okay. So we really don't know whether--

No, I'm trying to establish what we know or not.

### Conspiracy Advocate (CA)
Claim: We do know, and we had exactly the same issue with tobacco. There has never been a study where you bring in people and you give them tobacco to see if they get cancer. Once you have such consistent evidence, you have to make this decision. And back in 2007, the American Institute for Cancer Research said, look at hotdogs, bologna, all the processed meats, and colorectal cancer. And they concluded the evidence was so convincing, they said, the amount you should feed a child, the amount you should eat yourself, was zero. You should just not have it. And the evidence has only gotten more convincing since that time. What hasn't changed is the fact that these things are marketed, and they're pushed, and they sound folksy. And isn't it nice to go to a ballgame and have a hotdog with your kid?

But I think in the same way as my dad gave us cigarettes once in a while and now we're embarrassed about that, I think our generation is now going to say, "Holy cow."

### Moderator
Claim: All right.

### Moderator
Claim: "We know food is an issue. We've got to make--"

### Moderator
Claim: Joel Salatin.

### Scientific Advocate (SA)
Claim: Yeah. But the problem is that all of your meat studies are based on toxin-laden meat that's been raised in a factory-farming situation. If you take that out of it, the nutrition and the analysis is completely different. And not only that, but I'd like to ask a question-- you're talking about cooking, cooking, cooking, does that mean-- I'd like to get back to the topic actually-- that if we don't cook it and eat raw meat, then we're okay and it's okay to eat meat with a face if we don't cook it?

### Conspiracy Advocate (CA)
Claim: The point that I made is that when you analyze meat, some of the carcinogens are produced by cooking. The HDAs and the PHs are just from heating it up--

### Scientific Advocate (SA)
Claim: Yeah, same thing happens with vegetables.

### Conspiracy Advocate (CA)
Claim: --and good heavens, no--

### Moderator
Claim: I want to bring-- Gene Baur has been the polite guy in this debate so far.

### Conspiracy Advocate (CA)
Claim: I just wanted--

### Moderator
Claim: And you get points for that, but come on--

### Conspiracy Advocate (CA)
Claim: Well, in terms of the science, there's The China Study which the New York Times called the "Grand Prix of Epidemiology," done by T. Colin Campbell, a biochemist at Cornell University. And what he found was that the more animal foods people ate, the more problems they had; the more plants foods people ate, the healthier they were. And these were animal foods that were not necessarily produced in factory farms, so just the animal foods were correlated with human health problems, including cancers. And so that was not factory-farmed meat. It was range-fed meat or grazing animals, and they were still problems.

### Moderator
Claim: All right. I want to move-- I think we have an impasse on this point. And I acknowledge that both of you have said causality is difficult to prove, but you're talking about trends, and we respect that, but--

### Scientific Advocate (SA)
Claim: The China Study has been debunked by so many experts it’s-- it shouldn’t even be brought up in this debate.

That’s how bad it is.

### Scientific Advocate (SA)
Claim: I don’t want to parse it tediously, but I just would like to say one sentence--

### Moderator
Claim: Don’t be tedious.

### Scientific Advocate (SA)
Claim: Just the one-sentence point. If you go to the original data, there is no correlation between meat intake and cancer. If you read T. Colin Campbell’s book, what he does it make a rather convoluted argument that some things are associated with meat, those things are associated with cancer, and so on, but the actual data doesn’t show a direct correlation like that.

### Moderator
Claim: Let’s go to this question-- the ethics and the values part of this discussion. And by the way, you as audience members can circle back on some of this when we go to you for questions, but I want to go to Gene Bauer, because where you really stood out in your opening statement was making this-- really, really making this-- strong statement in support of-- I don’t know if the term is oxymoronic, but-- a humanity towards animals. And you have rescued farm animals and arranged for them to have a good, long life, not ending up on somebody’s plate.

And one of your opponents, Joel Salatin, who raises animals in an organic system, basically made the argument that eating and being eaten is part of life, and that the kind of argument that you’re making about wanting to take supplements and eat only vegetables is a privilege of the 21st century and the United States, and that this is new, and that history, evolution, reality, and most of the rest of the world is: you’ve got to eat meat, and there’s nothing wrong with that. Take that on.

### Conspiracy Advocate (CA)
Claim: Well, I think over the course of our history, we’ve done what we’ve had to do to survive, and often that has been eating meat, but it’s also sometimes been eating other people. And we’ve also done a lot of things over the course of our history that have not been very good, you know? You know, you think of institutions like slavery. And as time goes, we come to look at these things more critically and we start making decisions and choices that are, I think, more humane. And when it comes to animals, they have feelings like we do.

They’re not that much different than we are, and there’s been attempts to rationalize and say, well, they are different. They don’t use tools, for example. Then Jane Goodall found that animals were using tools, and we had to change our thinking and say, well, they don’t use language; but now we see that these other animals use language. You know, turkeys and chickens have many different calls for different things, and as we learn, you know, I think our responsibility grows. And the fact is, we can choose not to eat other animals. In the case of a lion, they don’t have a choice. In the case of us, we do have a choice.

### Moderator
Claim: Gene, where do you go on the evolutionary scale, and putting ourselves fairly high up and putting insects fairly low down? I mean, would you swat a mosquito? Would you kill a snake? Would you trap a rat?

### Conspiracy Advocate (CA)
Claim: To me, it’s about not causing unnecessary suffering. So if I don’t need to cause harm to somebody else, I’m going to try not to do that. And, you know, there’s a difference between dying and being murdered. You know?

And even people like E. B. White wrote about this, you know, who wrote Charlotte’s Web. He said a farm is a peculiar problem for a man who likes animals, because the fate of most livestock is that they are murdered by their benefactors. The creatures may live serenely, but they end violently and the odor of doom hangs about them always. So there’s-- it’s about our relationship with other animals. Is it about compassion and kindness or is it about cruelty--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --and exploitation and killing?

### Moderator
Claim: Let’s go to the farmer on the other side, who’s arguing against the motion, Joel Salatin.

### Scientific Advocate (SA)
Claim: Yeah, well, you know, I don’t have any problem with vegans. I really don’t. They become our best customers when they find out they can get healthy with our meat, but--

--where I really get my dander up is when I’m accused of saying you can’t love because you dress the animals. That’s a powerful statement--

### Moderator
Claim: Did you say “dress animals”?

### Scientific Advocate (SA)
Claim: “Dress” is a euphemism for slaughter. It just sounds nicer on the radio.

### Moderator
Claim: It sure did.

I was picturing a tutu and a little hat. I’m glad I caught that one.

### Scientific Advocate (SA)
Claim: --it means like you dress them for the table, you know? Nobody wants a live chicken on their dining room table, you know? You want it dressed. You want it, you know--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: At our Thanksgiving we have live turkeys, actually. We feed them, we don’t eat them so…

### Moderator
Claim: No, but let’s--

Joel Salatin, the floor is yours.

### Scientific Advocate (SA)
Claim: Yeah, so the problem becomes-- you know, it’s nice to sit here and say we’re going to rescue all these animals. The problem is that it just doesn’t work. How are you going to fertilize the vegetables that you’re eating?

### Conspiracy Advocate (CA)
Claim: Well, there’s actually veganic farms, including one right across the street from us that grows produce without any animal inputs, and there’s another veganic farmer I know of in the UK that’s been in business for 37 years, and there’s several of them-- they’re starting to now develop around the country. So this type of agriculture is possible, and it is a growing area.

### Scientific Advocate (SA)
Claim: It's possible on soils that have been built by manure.

### Conspiracy Advocate (CA)
Claim: No, not necessarily.

### Scientific Advocate (SA)
Claim: Oh, yes.

### Conspiracy Advocate (CA)
Claim: No, green manure. You know, you can grow hay and things like that. Cover crops can be used. And there have been people doing this for decades.

### Scientific Advocate (SA)
Claim: Okay, so how much acreage-- how much extra acreage-- is it going to take to farm that way?

### Conspiracy Advocate (CA)
Claim: Well, you need to do rotation.

### Scientific Advocate (SA)
Claim: It's going to take about three or four times, maybe five times, the amount of acres we're currently using.

### Conspiracy Advocate (CA)
Claim: Well, if we're not having to grow a lot of crops to feed a lot of livestock, we'll have enough land for that.

### Scientific Advocate (SA)
Claim: We don't--

### Moderator
Claim: Well, I don't think his point is whether there was land--

### Scientific Advocate (SA)
Claim: --I already said we don't have to grow the crops to feed the livestock because there's that much scavenging and that sort of thing going on. The problem is that we're not using animals in their historically normal role, which is as scavengers, whether it's pigs scavenging acorns in the woods, chickens eating, you know, vegetable scraps. If every household had a couple of chickens to eat their vegetable scraps, there wouldn't even be a factory farm chicken industry, and you wouldn't even have to put the garbage on a garbage truck to send it to a composting facility to go onto your, you know, ornamental flowerbeds.

### Conspiracy Advocate (CA)
Claim: Well, I'm not against, you know, somebody having chickens that they feed the scraps. But then where I have the issue though is when somebody goes up and then cuts off their head. You know, that's where the problem is. And, you know, in one of your books, you even mentioned how, you know, “I believe it is psychologically inappropriate to slaughter animals every single day.”

### Scientific Advocate (SA)
Claim: That's exactly right.

### Conspiracy Advocate (CA)
Claim: So I mean, it's a harsh interaction. It's a violent, bloody interaction.

### Scientific Advocate (SA)
Claim: It is.

### Conspiracy Advocate (CA)
Claim: And it’s not necessary.

### Scientific Advocate (SA)
Claim: Well, the necessary part is fascinating since there is no animal-less place. So where are we going to put all these animals? You know, if we're going-- are we going to sterilize all of them? Are we going to make natural parks?

### Conspiracy Advocate (CA)
Claim: The reason is we're mass producing them. We’re mass producing-- turkeys today can't even reproduce naturally. They're all artificially inseminated.

### Moderator
Claim: Wait, wait. For clarity, let's keep it on the terms in which-- in which Joel farms, because the retreat to the farm factory scenario is not one that he's defending.

### Conspiracy Advocate (CA)
Claim: Well, I'm not so sure because I’m guessing that you get little chicks that have been genetically bred to get obese, and they live about eight weeks, and then you slaughter them.

And I'm guessing they are not grazing freely in the pasture. I'm guessing they're in a tiny little pen, and they grow up to be obese, and then-- and you are-- these are among the animals that add up to about a million animals per hour, bred and killed, bred and killed, bred and killed. And if people were not eating animals with a face, or even years ago, people didn't eat animals anywhere-- anywhere-- like that. I've been doing--

### Scientific Advocate (SA)
Claim: The topic-- the topic--

### Moderator
Claim: Just one--

### Scientific Advocate (SA)
Claim: I'm not going to let you weeble on that, because the topic is, "Don’t Eat Anything with a Face." One of the things that Chris and I are committed to is holding you guys to say, “No exceptions,” because that's the topic. It's not about eating less meat. I would even advocate eating less meat. In fact, I think meat should be about three times more expensive than it is--

### Conspiracy Advocate (CA)
Claim: Yeah, agreed.

### Scientific Advocate (SA)
Claim: I think that would be a good thing.

And that would actually rectify a lot of the issues that I'm sure all four of us agree on.

### Conspiracy Advocate (CA)
Claim: Well, I think we have to go one step further--

### Scientific Advocate (SA)
Claim: But the topic-- the topic is that it is morally reprehensible, and you cannot be compassionate if you're eating meat. That's the motion. And it's one. It's not a few less. It's one.

### Conspiracy Advocate (CA)
Claim: Now, we're talking about whether--

### Moderator
Claim: I want to go to the audience for questions. I'm going to let this comment be made by Gene, but after that-- can you hold onto your question for a bit?

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: And I'll come to you. Just remember to raise your hand. Let me call on you. If you're upstairs, you need to come downstairs and really make it tight and a focused question. Go ahead, Gene.

### Conspiracy Advocate (CA)
Claim: You know, the motion is, do we eat anything with a face? And we say, we should vote for the motion that we do not eat anything with a face. So it's great that we all agree that we should eat less animals, and factory farming is bad, but again, it comes down to each individual animal who is killed and eaten. I agree with the point that life often comes from death. You know, animals die, plants die, they go back into the soil. But dying is one thing. Killing is an entirely different thing.

### Moderator
Claim: What about-- your opponents argue that vegetables also have sentient existences, that they communicate.

### Conspiracy Advocate (CA)
Claim: Well, I mean, I don't know the science about that. I kind of doubt it. But even if that were the case, even if that were the case, eating plants directly, you're causing much less death, because--

### Scientific Advocate (SA)
Claim: That's false, however, because when you--

### Moderator
Claim: Chris Masterjohn.

### Scientific Advocate (SA)
Claim: --monocrop soybeans and corn, you kill countless animals-- snakes, rodents, insects and so on-- through tillage. So you kill a lot more animals when you eat veggie burgers than you do when you eat beef, because--

### Conspiracy Advocate (CA)
Claim: No, no, because you're feeding the soybeans then to the cows.

### Scientific Advocate (SA)
Claim: I'm sorry. Say that again?

### Conspiracy Advocate (CA)
Claim: You're feeding the soybeans to the cows.

### Scientific Advocate (SA)
Claim: No, no, no--

### Scientific Advocate (SA)
Claim: We've already agreed soybeans don't need to be fed to cows. We don't need to grow a single soybean.

### Scientific Advocate (SA)
Claim: --no, no, no. Excuse me, when you eat the soybeans--

### Moderator
Claim: It is question time.

### Scientific Advocate (SA)
Claim: When you eat the soybeans yourself--

### Moderator
Claim: --you need to kill animals to grow them. That's the point.

### Moderator
Claim: A mic will come in from this side.

### Moderator
Claim: Thank you very much for the lively debate, and thank you for taking my question. My name is Kendra. I have a question for Dr. Barnard.

You mentioned, in your opening statement, about some of the health benefits of a plant-based diet, and one of them was weight reduction. I'm wondering what the prevalence of the high-protein, low-carb diets and the Atkins diet, can you speak a little bit about, you know, what your thoughts are on such a diet and the long-term effects and--

### Moderator
Claim: I'd like to-- I'd like to see if you could focus this, so that they're actually debating on the point of the motion.

### Moderator
Claim: Okay. Is a high-protein, low-carb diet a healthy diet, sustainable diet? Is that--

### Conspiracy Advocate (CA)
Claim: Okay. The short answer is no. People-- but you're raising an important paradox, is that in some of these fad diets, people would eat what seemed like a lot of meat, but they were still losing weight because they were avoiding all carbohydrate. But in more careful study, it all came down to calories. If people eating that way did not reduce their overall calorie intake, they didn't lose an ounce. And that's why a lot of people on Atkins and other diets like that, they just don't lose weight.

And that's why almost all of them end up regaining and going beyond later, plus their cholesterol levels go through the roof, and they have-- over the long run, these people do miserably.

### Scientific Advocate (SA)
Claim: Sir?

### Moderator
Claim: You can take cracks at these questions each time if it goes to one side. If you want to, you can take the other side.

### Scientific Advocate (SA)
Claim: I would like to take a crack at that.

### Moderator
Claim: Sure. Chris Masterjohn.

### Scientific Advocate (SA)
Claim: So I've read a lot of Dr. Barnard's studies, and I'm very impressed by the way that they're designed and the way that they're reported. But if you look at the data, what I think Dr. Barnard has clearly shown is that the metabolic effects and the improvements in almost every health measure are due to weight loss. And what Dr. Barnard has created is a run-of-the-mill, weight-loss diet with mediocre efficacy, where there's lots of positive effects due mostly to the weight loss that occurs in the first three to six months and then starts creeping back up. And if you –

### Conspiracy Advocate (CA)
Claim: No--

### Scientific Advocate (SA)
Claim: Wait a second. Just let me-- please let me the point, and then you can respond--

### Moderator
Claim: You know, Chris, I want to stop you. I want to stop you on this,

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: --because it's turning into a personal attack. And then he's going to have to spend 15 minutes defending everything that you say.

### Conspiracy Advocate (CA)
Claim: I can do it much quicker.

### Moderator
Claim: And--

And so I would prefer that we move on and go to a question up here. Sir in blue. We just discourage, you know, going after people in terms like that. Sir, go ahead.

### Moderator
Claim: My name is Alex. This is for Dr. Barnard too. The motion is, “Don’t Eat Anything with a Face.” And one thing which may have slipped through the cracks is fish, which has a face as well, and we haven't really--

### Moderator
Claim: I got an email from a friend saying, could you please change the motion to, "Don't Eat Anything with an Ass."

### Moderator
Claim: That may work as well.

### Moderator
Claim: Because he wants to eat fish. But go ahead.

### Moderator
Claim: Fish has kind of slipped through the cracks in this debate, and it hasn't really been discussed, and I wonder what your thoughts are about fish, and can you eat a mainly vegetarian--

### Moderator
Claim: Gene Baur, can you--

### Moderator
Claim: --or a pescatarian diet.

### Moderator
Claim: Let's-- we haven't heard from Gene. Let's let him take that, and then the other side respond.

### Conspiracy Advocate (CA)
Claim: Again, the more that we look at these animals, the more we learn that they have sentience, that fish have feelings, they have memory, they learn from each other. And, again, we don't need to kill them and eat them.

So from an ethical standpoint, I say we don't need to. And again, I've been a vegan since 1985, gotten everything I've needed from plants.

### Moderator
Claim: Joel Salatin, you're talking about populations that live near the water, that's where they go.

### Scientific Advocate (SA)
Claim: Well, absolutely. And, you know, I find it fascinating that all of the attributes given to animals plants have too. The DNA structure of grasses, for example, when you introduce a species, it nativizes its DNA structure to become more climatically nativized to a certain place. That's memory. That's genetic memory and adaptation to a certain place. If that isn't responding to things, I don't know what is. And I just absolutely don't appreciate this false dichotomy that when I take the life of a carrot the carrot doesn't scream.

### Moderator
Claim: And in answer to the fish question: you're good with the fish eating?

### Scientific Advocate (SA)
Claim: I'm absolutely good with the fish.

I like fish.

### Moderator
Claim: Down front here.

### Scientific Advocate (SA)
Claim: But-- but I will say this: I only eat fish when I'm on the coast. I don't eat fish in Oklahoma City. That's part of the local-- the integrity, the nesting in the womb, that creates that-- that food integrity.

So I love to eat clam chowder when I go to New England, but I don't want to get clam chowder in St. Louis.

### Moderator
Claim: We skipped over the health issues. Let me just-- 30 seconds on this.

### Moderator
Claim: Can you make 15?

### Conspiracy Advocate (CA)
Claim: 15.

### Moderator
Claim: Go.

### Conspiracy Advocate (CA)
Claim: When we look at fish eaters and compare them to meat-eaters, they are marginally slimmer than people who eat heavy amounts of meat, but they are nowhere near as slim as the vegetarians. The fish eaters as a group have more diabetes. Carcinogens form in cooked salmon just like in cooked chicken. And there's nothing like getting the skeletal muscle out of your diet.

### Scientific Advocate (SA)
Claim: And fish also have a central system and brains.

### Moderator
Claim: Down front here.

### Moderator
Claim: Hi. My name is Angela. I'm just wondering, for this side on the affirmative, and not trying to be funny at all, we focused on killing and cooking, so if we have left a chicken to lead a long, lovely life and let it die a natural death, is it okay to eat it raw?

### Conspiracy Advocate (CA)
Claim: You know--

### Moderator
Claim: That's a great question.

### Conspiracy Advocate (CA)
Claim: And once-- and once that animal is dead, do they still have a face? I mean, I would say that from an ethical standpoint, if somebody has lived and then they die, they're going to be eaten by somebody, either worms or bugs or another animal. So from my standpoint, ethically, you know, you've not taken the life of somebody with a face in that case.

### Moderator
Claim: Right in the middle there. Did anybody come downstairs by any chance? Okay. And just wait for the mic to come up.

### Moderator
Claim: Hi. This is a question for Joel. So Peter Singer talked about speciesism, which is that-- as humans we practice this-- we put our species over other species, so I kind of just wanted talk about this from an ethical standpoint, regardless of what's-- what is our-- the historical process or health or any of that, how is speciesism any different than racism or sexism?

As humans we fight for equality between humans all the time, and it's not about--

### Moderator
Claim: Okay, I'm going to stop you, because you actually put the question right in the middle there.

### Moderator
Claim: Okay.

### Moderator
Claim: How is speciesism, which is the elevating of humans above other species, any different from racism?

### Moderator
Claim: Yeah.

### Moderator
Claim: You said it. It was good.

Joel Salatin.

### Scientific Advocate (SA)
Claim: Humans are part of the ecology. You know, we can't wake up one day and say, "I'm not going to participate in this, like a frog can't wake up on the edge of a pond one morning and say, "You know, I'm just not going to practice being a frog today." We are the caretaker species. Humans are the only ones who can decide to procreate and not. Animals don't, animals just do. You know, we tend to not eat each other. You know, if a chicken dies in the yard, why, you know, the others eat it right up.

Pigs the same way. I always tell my kindergarteners when they come out for farm tours in the pigpen, you know, "Keep moving, guys. These are omnivores." You know. So I would simply say that instead of viewing what I would call our role as caretakers, as some sort of an elitist dominion idea, rather take it as, "Heavy rests the head that wears the crown." Therefore, we must exercise the greater responsibility in massaging our ecological umbilical, so that it actually attracts more solar energy in the biomass than it would in a static state. And that's exactly what pasture-based agriculture does.

### Moderator
Claim: And, Chris Masterjohn, you wanted to add?

### Scientific Advocate (SA)
Claim: Joel and I essentially agree on this, so I'm not going to add too much, but I do think one of the things that the other side needs to articulate is a way to approach this harm reduction in a way that is economically and ecologically sustainable.

So one of the things that I wonder-- and this could be taken as an open-ended question, definitely not a criticism-- one of the things that I wonder in reading your book, for example, Gene, which I really love and I agree with you on, you know, 95 percent of it, is-- what I'm wondering is, if we are to say we should have a world without animal farming, what does that post animal farming world look like? For example, on your Farm Sanctuary, you sterilize the male mammals and make sure that you don't have any reproduction, so we're exercising some responsibility in minimizing harm to those animals by keeping the population size down. So when we shift to a post-animal farming world, do we move towards eradication of the domesticated, farm species, or do we have something like your sanctuary on a larger scale?

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: And if it's a larger scale, how is it economically sustained?

### Moderator
Claim: Gene Baur.

### Conspiracy Advocate (CA)
Claim: Well, as I mentioned, there are some veganic farms now that are forming, and I think that's a very good model. I think it's also important to recognize that all species of farm animals, with the exception of the turkey, have been imported into the U.S. So cattle, for example, are now ranging where bison used to range. And so I think bison should be back there. And when we're growing plants and eating them directly, it requires far less acreage. So a lot of wild space could be left wild. And veganic farming is not necessarily no animals. There are wild animals. And you're interacting with animals but in a less harmful way. And that's what it's about, it’s doing as good as you can, causing as little harm as possible, and this is an evolving process. So I think there's some good signs, like--

### Scientific Advocate (SA)
Claim: I would disagree vehemently with the fact that it takes--

### Moderator
Claim: Joel Salatin.

### Scientific Advocate (SA)
Claim: --more area to grow this food this way.

That, again, is coming straight out of the United Nations, which I don’t trust as far as I can throw a bull by the tail, which isn’t very far. And these are studies paid for by the industrial food system--

### Conspiracy Advocate (CA)
Claim: Wait a sec--

### Scientific Advocate (SA)
Claim: --which is assuming--

### Conspiracy Advocate (CA)
Claim: When I go back to Fargo and see acre after acre, as far as the eye can see, of corn and soy beans, and not one ear of that corn is going to be eaten by a human being--

### Scientific Advocate (SA)
Claim: I know, and--

### Conspiracy Advocate (CA)
Claim: All of the irrigation, all--

### Scientific Advocate (SA)
Claim: Yeah, and you know what--

### Conspiracy Advocate (CA)
Claim: --of the pesticides--

### Scientific Advocate (SA)
Claim: --If all that land were growing prairie under intensive grazing management, it would be building soil, bringing springs back, replacing the aquifers, and growing far more nutrition per acre than corn and soy beans.

### Conspiracy Advocate (CA)
Claim: As Gene said, you could let it go--

### Scientific Advocate (SA)
Claim: You’re--

### Conspiracy Advocate (CA)
Claim: --wild.

### Scientific Advocate (SA)
Claim: --assuming-- you’re assuming an inappropriate model. You’re looking at this saying, you know, most marriages are dysfunctional so I’m not going to participate in marriage. You know, we don’t solve problems by just walking away from the issue. We embrace it, we participate in it, and offer an alternative, and what I’m suggesting is that a biomimicked-- like the bison and the wolf – system. You know, the U.S. 500 years ago had more pounds of animals on the U.S. than are here today with all of our intensive agriculture.

### Conspiracy Advocate (CA)
Claim: You know, you also speak about dominion--

### Scientific Advocate (SA)
Claim: That’s the truth.

### Conspiracy Advocate (CA)
Claim: You know, we have dominion, as you mentioned, and we have-- we can play a role and either be kind or kill, you know? And we don’t need to kill. So-- and there are ways to grow food with plants without using animals. There’s veganic agriculture. It is coming.

### Moderator
Claim: I need to say this. I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate. I’m John Donvan. We have four debaters, two teams of two, debating this motion: "Don’t Eat Anything with a Face." Sir?

### Moderator
Claim: Thank you, guys. I’d like to frame this-- the health aspect of this debate. I think when you’re exploring--

### Moderator
Claim: Can you keep the mic just a little bit closer?

### Moderator
Claim: Sure. When you’re exploring optimal health, especially for the human genome, you have to look at anthropology and evolution.

So, what role-- you guys touched upon this a little bit-- what role has animal protein played in the evolutionary success of Homo sapiens? And what proof of that, if any, is left over in today’s modern humans?

### Moderator
Claim: Does any-- is that a question that anybody can answer without being wildly speculative? It’s a really interesting question, but I don’t know if we have-- go ahead, try it. Try it, Chris Masterjohn.

### Scientific Advocate (SA)
Claim: Sure, I just want to make two really quick points. One: since you bring up-- since you bring up evolution and Dr. Barnard brought up primates, I just-- worth pointing out that chimpanzees according to Dr. Craig Stamford, whose expertise is in that area-- eat 50 to 100 grams of meat per day. They hunt it and they use it as a commodity to trade it for food and sex, and also for their sustenance. But on evolution, I think, the lesson that evolution gives us is that there’s variation in the population. That variation changes over time. And so I’m not arguing that no one can be healthy on a vegan diet.

I think Gene proves that you can, but the point is the motion doesn’t say, “Some People Should Not Eat Anything without a Face.” It says, "Don’t Eat Anything without a Face,” and what we see is that there are genetic variations, like I mentioned in the beginning and many others, where not everyone can get the nutrients from plant foods as well as other people. Some people will do well; some people won’t. That’s the lesson from evolution is that variation.

### Moderator
Claim: Okay.

I was actually past-- sorry, sir. There was-- I was going for youth on this one.

### Moderator
Claim: Okay.

### Moderator
Claim: Not that that’s a comment on you. I didn’t mean it that way.

You’ll see what I mean. Sir, can you tell us your name?

### Moderator
Claim: Hello, my name is Max Allendy and I have a question for the proposition side. The-- the motion is that you cannot eat-- nobody should eat anything with a face.

Why has factory farming been abandoned in this, because people still eat animals from factory farms, so why has that been abandoned?

### Moderator
Claim: I’m going to pass on that question, because as I explained earlier, they all agree already that that’s not what they’re debating about, but thank you for your question. And sir, I’ll come down to you.

### Moderator
Claim: My name is Paul Strauss Meat is inexpensive, and I wonder what those in favor of the motion would say to those who cannot financially afford a meat- free diet?

### Conspiracy Advocate (CA)
Claim: There’s actually a book out on--

### Moderator
Claim: Gene Bauer.

### Conspiracy Advocate (CA)
Claim: --eating vegan on four dollars a day. So eating vegan does not necessarily have to be very expensive. You can get beans and rice and-- you know, cooking also is something that we’ve lost sight of, and it’s another part of this process-- is preparing food. Instead of just going to the store and getting a bag of potato chips, we can go get a sack of potatoes and work with that. And--

### Conspiracy Advocate (CA)
Claim: Meat is very expensive. You have to raise the corn or whatever that you're feeding them, you have to irrigate it, do all these things. You feed it to the animal. The reason it's cheap at the store is that your tax dollars are going to subsidize the feed grains. And if those subsidies were ended suddenly, a burger-- the price of a burger would be through the roof. Dried beans are-- cost pennies.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Dried rice costs pennies.

### Moderator
Claim: The reason-- the reason I want to--

The reason I want to move on is this side agrees with that argument, and it goes to the young man's question that we're not actually arguing the farm food system. Ma'am right there. Yeah, thanks.

### Moderator
Claim: Hi. I'm Victoria Moran with Unity Online Radio. My question is for Dr. Barnard. We know the research that was done about reversal of heart disease with the plant-based diet. Has anything been done with an animal-based diet that shows that this number one killer in this country can be reversed or prevented?

### Conspiracy Advocate (CA)
Claim: No. And in fact, when Dean Ornish did that work that I was describing, he had a control group that was allowed to eat meat, leaner cuts and that kind of thing. But by and large, they got worse, not better.

And when we started seeing cases of reversal of diabetes, we couldn't do that with the meat-based diet. It just-- it just doesn't work at all. Same with--

### Scientific Advocate (SA)
Claim: That's, of course, meat from a factory farm.

### Conspiracy Advocate (CA)
Claim: No, no--

### Scientific Advocate (SA)
Claim: I just want to point that out.

### Conspiracy Advocate (CA)
Claim: No, it doesn't matter. And the same with--

### Scientific Advocate (SA)
Claim: The study wasn't used pasture-based meat, was it? Did it? No, it didn't!

### Moderator
Claim: Sir--

### Conspiracy Advocate (CA)
Claim: Up until relatively recently--

### Moderator
Claim: Let’s move on on this point.

### Conspiracy Advocate (CA)
Claim: --none of it was CAFOs. The reversal of erectile dysfunction that we've seen took a-- always occurred with vegan diets. It never occurred with a meat diet.

### Moderator
Claim: Okay. The answer to the woman's question was no.

### Moderator
Claim: Hi. Hello? My question is for the side arguing for the motion. You cite meat-eating as a major health hazard. But isn't it a question about balance and moderation? I mean, excessive amount of vitamins can be harmful to one's health as well. So isn't it about balance and moderation?

### Conspiracy Advocate (CA)
Claim: Well, the fact is that, you know, we can live without eating animals. And if you eat some animal products, it probably won't kill you, but it will kill the animal. And that's a key issue here. And, you know, even as a vegan, it's good to eat a variety of foods, like anybody. It's good to eat a variety, like beans, whole grains, vegetables, fruits, and things like that. But, you know, with factory farming, to the point that was raised earlier, most people in this country who are eating animals are eating factory-farmed animals. So that should be, I think, a very strong point for voting for the measure-- why we should not eat anything with a face-- because almost everything with a face is coming from a factory farm.

### Moderator
Claim: But, Gene, how would it change things if the world were Joel Salatin's world everywhere, for you?

### Conspiracy Advocate (CA)
Claim: There is still a relationship there with animals that is violent, and bloody, and it's unnecessary. We don't need to kill other animals to live.

### Scientific Advocate (SA)
Claim: How many animals--

### Moderator
Claim: Joel Salatin.

### Scientific Advocate (SA)
Claim: How many animals do you kill when you plant a tomato plant?

### Conspiracy Advocate (CA)
Claim: Plant a tomato? Not that many. I mean--

### Scientific Advocate (SA)
Claim: A lot!

### Conspiracy Advocate (CA)
Claim: --it's pretty easy to plant.

### Scientific Advocate (SA)
Claim: Every-- every meter of soil-- every tablespoon of soil-- every tablespoon has a million living organisms that are communicating, reacting, exuding auxins, creating DNA memories, having little, you know, mitochondria dances and, you know--

### Conspiracy Advocate (CA)
Claim: But they don't have a face.

### Scientific Advocate (SA)
Claim: They're probably--

### Conspiracy Advocate (CA)
Claim: They don't have a face.

### Scientific Advocate (SA)
Claim: You don't think they have a face.

### Conspiracy Advocate (CA)
Claim: I don't think they do. I've not seen it. They don't have a nervous system.

### Scientific Advocate (SA)
Claim: --what constitutes a face--

### Moderator
Claim: They're very small.

### Scientific Advocate (SA)
Claim: Just because it's not a face like you, why is it no less important? Only things that look like you are more important?

### Moderator
Claim: You know, that's---- that's--

### Conspiracy Advocate (CA)
Claim: No, I think that it's good to be respectful to all.

### Moderator
Claim: Gene, I'm sorry that I interrupted you because I didn't mean to talk over you. I'd love to hear your answer to that question, so go for it.

### Conspiracy Advocate (CA)
Claim: It's about being respectful to others. And there are lots of little bugs that live in the world-- and live in our bellies even-- that we interact with without an intentional harm being caused. When we're raising animals to kill them and eat them, there's an intention to kill them.

And that is the difference between planting a tomato plant and going and slitting the throat of a chicken. There's a big difference.

### Scientific Advocate (SA)
Claim: But, but--

### Moderator
Claim: Chris Masterjohn.

### Scientific Advocate (SA)
Claim: Five seconds. The millions and millions of animals that die during tillage for large-scale plant operations that are needed to-- that would be needed to provide calories and protein for human beings do have faces.

### Conspiracy Advocate (CA)
Claim: I don't think we need those factory crop farms either. We're looking at small-scale, local-- I mean, we're kind of on the same page with that type of agriculture, and it could be plant-based, so it doesn't have to be these massive compounds where--

### Moderator
Claim: You like what he's doing with plants on his farm. You don't like what he's doing with animals, period.

### Conspiracy Advocate (CA)
Claim: That's right, yeah.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: Well, you're assuming-- you're assuming--

### Moderator
Claim: Joel Salatin.

### Scientific Advocate (SA)
Claim: --that we can get the-- I mean, two-thirds-- two-thirds of the planet's surface is not arable. This is the-- what we call the nooks and crannies, the fringes, you know, where - - that's why herbivores are all over the planet, because they are not only pruning the biomass, but they are actually stimulating photosynthetic activity, and they are-- they're doing all these wonderful things. And they are, by and large, not living on areas that are corn and soybeans. You guys keep bringing up corn and soybeans, and I'm suggesting we don't need any of that either.

### Conspiracy Advocate (CA)
Claim: It’s not about all of the wonderful things that they’re doing--

### Scientific Advocate (SA)
Claim: What we need is a balanced approach of plants and animals that mimics the kind of complex, relational interactions between plants and animals that the ecology illustrates.

### Moderator
Claim: Ma'am? Yes.

### Moderator
Claim: Thank you. This is really interesting. My name is Rosa Matar I'm a Swedish journalist over for two weeks to improve my English, and this is great. I just want to change focus a little bit because we're talking a lot about ethics and farm animals.

And I come from an area in Sweden where we hunt a lot of moose, deer, wild boar, et cetera, et cetera. I know that a lot of hunters, they think they're doing an ethical job keeping down the numbers of animals, because if they didn't, the animals would get sick--

### Moderator
Claim: Just for time, I need you to zoom into your question.

### Moderator
Claim: Okay, sorry-- go out into the roads and get, you know, like road killed and all. How do you look upon that? Is it more justified to kill wild animals, like moose--

### Moderator
Claim: Through hunting, through hunting.

### Moderator
Claim: Through hunting, yes.

### Moderator
Claim: I’ll put it to both sides. Gene Baur.

### Conspiracy Advocate (CA)
Claim: I think it's really all about the relationship, you know. And in this country, you know, the deer populations are actually managed so we can have people go out and kill them. So the hunting is actually used as an excuse to go kill. We've removed all the natural predators. So I'm in favor of a more natural ecosystem and then for human beings to interact in a humane way and to not cause harm if we don't need to. And hunting is certainly harm.

### Moderator
Claim: Other side like to respond to that?

### Scientific Advocate (SA)
Claim: Go ahead.

### Moderator
Claim: Chris Masterjohn.

### Scientific Advocate (SA)
Claim: I guess, isn't this a matter of the directness of our complicity rather than our complicity? So if we move towards a world that has more wild animals with more predators, where those animals are not-- I know there are issues with humane slaughtering now-- but those animals will suffer the same fate of factory-farmed animals, where they can get ripped apart where they're still alive. You still have those animals dying. The slaughter is less humane than it could be with humans. So aren't we just removing our directness in the complicity rather than our actual complicity?

### Scientific Advocate (SA)
Claim: Pre-14--

### Conspiracy Advocate (CA)
Claim: One thing I have to do--

### Scientific Advocate (SA)
Claim: Pre-1491, there were 100 million bison in the U.S. and 1 million wolves. That doesn't count all the other herbivores, beavers, and birds.

### Moderator
Claim: Let's let Gene Baur answer that question.

### Conspiracy Advocate (CA)
Claim: You know, you can't control others. You can only control yourself. And other animals, you know, have the world they live in. And, you know, we talk about dominion and hubris and human arrogance, in a sense. And, you know, we're part of this planet. And saying that we need to go there to save those animals is, I don't think, a very good way to look at it. We interact with other animals. It's about the relationship. What is that relationship going to look like? And if we can live with other animals without killing them, without exploiting them, without putting them in small cages, and, you know – ‘cause once we start doing that, it tends to go pretty badly. And I've been to your farm, Joel, and, you know, I really appreciate that it's open, and people are allowed to visit, but some of the conditions were pretty bad.

## Round 3

### Moderator
Claim: All right. Let's not go in that direction either. Let it go. And that concludes round two of this Intelligence Squared U.S. debate. And here's where we are: We are about to hear brief closing statements from each debater, in turn. These closing statements will be two minutes each.

Remember how you voted before the arguments began. Right after this, your second vote, and that will decide the winner for us. On to round 3: closing statements. Here to summarize his position against our motion, "Don’t Eat Anything with a Face," he's against this motion, Chris Masterjohn, a nutritional sciences researcher and author of the blog The Daily Lipid.

### Scientific Advocate (SA)
Claim: Large-scale, epidemiological evidence that has been recently published shows that vegetarians who shop at health food stores, or otherwise health conscious, have no benefit over meat-eaters who shop at health food stores, or otherwise health conscious.

And this tells us nothing about causation because it's a correlation. Dean Ornish showed that a program limiting sugar, sugar derivatives, corn syrup, white flour, fat, alcohol, smoking cessation, peer-support exercise and stress management, through meditation, stretching, and visualization, along with the exclusion of meat, reverses heart disease, perhaps, but hasn't shown that reversing meat, specifically, does. What this means is that science is very complex, so I'd like to offer a way to synthesize the information in a way that embraces the uncertainty as a source not of frustration and confusion but of empowerment. We should take as our baseline the spectrum of traditional diets associated with population-wide freedom from degenerative disease, where even the most vulnerable members of the population were protected. These diets all lacked refined foods and all contain nutrient-dense animal foods regardless of whether they ate a little or a lot. We should build on this with our scientific understanding of physiology which shows that animal foods provide nutrition and that dietary needs vary from one individual to another, and it may, in the same individual, vary from one period of life to another. We should-- this emphasizes the importance of fine-tuning our dietary approach to achieve what makes us personally as individuals healthiest.

The motion tonight fails to prevent the death and suffering of animals in an ecologically and economically sustainable way. It's inconsistent with traditional diets not validated by modern science and reduces our ability to individualize our diets as needed. Because its particular form of absolutism is so lopsided, it's even more harmful than the converse proposition to always eat something with a face. So I urge you to vote against it.

### Moderator
Claim: Thank you, Chris Masterjohn. And that is our motion, “Don’t Eat Anything with a Face.” And here to summarize his position in support of the motion, Neal Barnard, a clinical researcher and president of the Physicians Committee for Responsible Medicine.

### Conspiracy Advocate (CA)
Claim: If your teenage son or daughter were to say to you, "Mom, Dad, I made up my mind. I'm going to eat my fruits and vegetables, and I'm going to have veggie burgers and things, but I'm just not going to eat anything with a face. I-- don't worry, I know how to do it. I know where to get my protein." If you then looked at the numbers and you realized that your child's risk of becoming obese or having a heart attack or developing cancer just plummeted, you would be thrilled.

And if you were part of an insurance group where your costs were dependent on the health of that group, and if every other member said, "I'm not going to eat any meat," you'd be thrilled, because you're going to save a huge amount of money. The world's strongest man is Patrik Baboumian, who recently lifted 1,210 pounds on an entirely plant-based diet. The world's greatest ultra long distance runner is Scott Jurek. He runs 100 miles, 125 miles, 150 miles at one stretch faster than any living human being on an entirely plant-based diet. This past Monday, the World Memory Championships were held in London. And contestants there can memorize a pack of cards in 30 seconds. And the winner was 25-year-old Jonas Von Essen, of Sweden, who-- was powered by an entirely plant-based diet. And, arguably the world's greatest brain, Albert Einstein wrote some words I want to share with you, "In my view, that the - - “-- It's my view that the vegetarian manner of living, by its purely physical effect on the human temperament, would most beneficially influence the lot of mankind." And Einstein continued, "So I am living without fats, without meat, without fish. And I'm feeling quite well this way. It always seems to me that man was not born to be a carnivore." A generation ago we tackled tobacco, and while everybody is free to smoke we just know that we're not going to do it. And today the issue is food-- for yourself, but most importantly for that animal who is your child or your neighbor's child. This resolution makes the most health sense, “Don’t Eat Anything with a Face.”

### Moderator
Claim: Thank you, Neal Barnard. Again, that is our motion, “Don’t Eat Anything with a Face.” And here to summarize his position against this motion, Joel Salatin. He's a third- generation alternative farmer in Virginia's Shenandoah Valley.

### Scientific Advocate (SA)
Claim: You know, it's fascinating how you can just kind of trade study for study for study. And that's I think what's happened tonight. The fact is that science is subjective based on the prejudice of the researchers. They set up the experiments this way. And so you got to look at who finances them, where the money goes, and decide what to do. That's how Monsanto got the, you know, GMOs through. They used geriatric rats. When the same experiments were repeated in Scotland with juvenile rats, all sorts of problems came up with GMOs. So I kind of, I kind of go philosophical on this, you know. We can trade dead bodies and thin people and heart attacks all night, alright? So, I find it fascinating that Gene says that Jesus and Muhammad could not show compassion. That's a powerful statement. Neither one of them was vegans. They both advocated eating meat. And if there certainly was an ethical dimension to this, one of those prophets should have said something about it, don't you think?

The anatomy of a human is predacious. Our eyes are in the front of our heads. We have incisors. We're not built like prey. We are predators. And remember, there are no exceptions in this topic. So remember my initial point about the poor and why 60 percent of the world keeps livestock: because it’s portable wealth for the landed poor, and it’s real-time nutrition for those who can’t afford the high-fertility soil necessary to grow kale, and it’s not subject to vermin infestation like grain is, or like spoilage when you don’t have refrigeration. This motion, when you vote for the motion, is an unbelievable disrespect and dishonor of this world’s poor people who rely on real-time livestock for nutrition, and survival. So--

### Moderator
Claim: Joel Salatin, I’m sorry. You’re time is up.

### Scientific Advocate (SA)
Claim: Yep. Leave and legacy--

### Moderator
Claim: Thank you very much.

### Scientific Advocate (SA)
Claim: --and vote against the motion.

### Moderator
Claim: And our motion is, "Don’t Eat Anything with a Face,” and here to summarize his position in support of the motion, Gene Bauer, the president and co-founder of Farm Sanctuary.

### Conspiracy Advocate (CA)
Claim: Voting for this measure is voting for sustainability. It requires far fewer resourses to grow plant foods as opposed to animal foods. It is the way people with few resources have eaten for thousands and thousands of years. Our massive, animal-consuming lifestyle is fairly recent. We all agree that factory farming is bad, and we need to look at that because most of the animals who are killed and eaten today come from factory farms. If we think that that is unacceptable, we need to vote yes on the motion not to eat anything with a face. And going more philosophically, this is ultimately about our relationship with other animals.

Historically, humans have eaten other animals, and as I mentioned, in tough times people have eaten other people. We’ve done a lot of very bad things, but when we have choices, when we have options, when we can live in a way that does not cause harm, why wouldn’t we? The word “humane” and “slaughter” don’t go very well together, and when you try to rationalize that these animals are there to be killed and eaten by us, many other bad things do happen. And I have been to a number of factory farms, I have been to a number of small farms, where animals are put in small areas, where they’re put in cages even, at these so-called “humane” farms. When the animals are seen as commodities, and as edibles, they are not treated with respect. That is bad for the animals, and I would also suggest it is bad for us. I’m not saying everybody who eats animals is a mean person. You know, we all grow, we all learn, we evolve, and when we learn, we can do better, and that’s what it’s ultimately about.

It’s about intent. And if you vote yes on this, that doesn’t mean you’ve got to be vegan tomorrow. This is a principle that we should not eat anything with a face. These are other animals. They have feelings just like our cats and dogs. They deserve to be treated with respect. Please vote yes on the motion.

### Moderator
Claim: Thank you, Gene Bauer. And that concludes our closing statements, and now it’s time to learn which side has argued the best. We’re going to ask you again to go to the keypads at your seat to register your vote on this motion after having heard all of these arguments. The motion is, "Don’t Eat Anything with a Face." If you now embrace this motion, as stated, push number one-- if you’re with this side, push number one; if you’re against it, with this side, push number two; and if you became or remain undecided, push number three. And we will have the results in about 90 seconds.

Before that happens, one thing I’d like to do, first of all, is to ask all of you to show your appreciation for four debaters who took this into really interesting areas. And, as an audience, asking audience questions, they were all really good tonight, and to the young man whose question I passed on, I just want to say, I apologize that I couldn’t take it, but for you to get up took a lot of guts. So congratulations to you. And we always like it when former debaters come back to sit in the audience, and we have Sheldon Krimsky here, who was here last year arguing-- He argued one of our toughest ethical debates, where the motion was, “Prohibit Genetically Engineered Children,” and I bet Sheldon fixed it-- a bow. I bet it’s a lot easier to-- A lot easier to watch from there than to be up here. We’d love it if you tweeted about this debate tonight. Remember our Twitter handle is @IQ2US, and our hash tag is #VEGDEBATE. Our next season starts back here in January. We're starting on the 15th. The motion that night will be, "Obamacare is Now Beyond Rescue." For the motion, Dr. Scott Gottlieb-- he's a practicing physician and former FDA deputy commissioner. His partner is Megan Mcardle, a columnist for Bloomberg View, who writes on economic business and public policy. Opposing them, and supporting the rescuability of Obamacare, Jonathan Chait-- he's a commentator and writer for New York Magazine-- and Dr. Douglas Kamerow. He is a professor of family medicine at Georgetown and a former assistant surgeon general. The rest of our spring topics, going from January through May, will be-- we're going to cover labor unions, affirmative action on campus, targeted killing of U.S. citizens, Russia, MOOCs (massive online open courses), where we're looking at whether online is the future of universities, millennials, and death. Tickets for all of our spring debates are on sale now through our website, www.iq2us.org. And for those who can't join our live audience, there are a lot of other ways to catch the debates. You can watch the live stream, as I mentioned a few times tonight, on iq2us.org or on FORA.tv. And you can listen to the debates on NPR stations across the country. You can check your local listings for air dates and times. And make sure to visit our website for up-to-date information. Stay in touch with us on Twitter and Facebook, because we welcome your feedback. And we do take ideas. We put debates on stage that have come from audience members. And one other thing, I only wanted to mention this after the vote was in because I wasn't sure how, if at all, it might sway your vote. But Joel Salatin's neck tie, it looks like just polka dots to you. Those are all little piggies. Each one of those. But it can't change anything now. Because the results are all in. You have now heard the arguments. You have voted twice, once before the arguments and once after. And as we count this, the team that has changed the most minds in percentage point terms will be declared our winner. So here are the results: The motion, "Don’t Eat Anything with a Face." Before the debate, in polling the live audience, 24 percent agreed with this motion, 51 percent were against, and 25 percent were undecided. So those are the first results. Remember, you have to have beaten-- you have to have moved your number in percentage point terms by the most in order to win. So onto the second vote, on "Don’t Eat Anything with a Face.” The team arguing for the motion: their second vote was 45 percent. They went from 24 percent to 45 percent. That means they picked up 21 percentage points. That is the number to beat. Let's see, the team against the motion, their first vote was 51 percent. Their second vote was 43 percent.

They lost 8 percentage points. That means the team arguing for the motion, "Don’t Eat Anything with a Face" is our winner. Our congratulations to them. And thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
