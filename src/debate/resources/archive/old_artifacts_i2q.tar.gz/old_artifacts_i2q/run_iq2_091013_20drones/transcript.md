# Debate Transcript

Topic: The U.S. Drone Program is Fatally Flawed
Motion: The U.S. Drone Program is Fatally Flawed

Debate ID: 091013%20drones


## Round 1

### Moderator
Claim: So I’d like welcome to the stage the Chairman of Intelligence Squared U.S., Mr. Robert Rosenkranz. Hi Bob. How are you?

### Moderator
Claim: I’m good.

### Moderator
Claim: Good. Thank you. So at "Nightline," we've always said sometimes we work on some stories for months, and then suddenly the day we put it on the air, something breaks that makes it very relevant. And we say, "Well, the news gods have smiled on us today." It's not in a happy way, but there's a real timing relevance to what we're doing tonight, isn't there?

### Moderator
Claim: Yeah, of course there is. There's a presidential address this evening, and it concerns obviously Syria, where if there's any action taken at all, probably will involve drones. Drones are in active roles now in Yemen and Somalia. So it is an extremely timely issue.

### Moderator
Claim: So looking at this argument, these two teams we know have actually lived this in ways that they'll reveal very, very directly. Some have sent them, and some have been near or close to the receiving end.

The side that's arguing in support of drone warfare, actually, in our case, the side arguing against the motion, the side that is enforcing it and standing up for drone warfare, what arguments do they have going for them?

### Moderator
Claim: Well, I think their best argument is that it has been highly effective. It has killed a lot of terrorists. And it does it in a very precise way because these unmanned aerial vehicles can provide surveillance for many, many hours, days, coordinate with other forms of intelligent cell phone intercepts and really identify targets to a degree of precision that no other weapon system can do. So it's very accurate. It minimizes collateral damage to civilians, does not eliminate it. And, of course, it keeps the U.S. operators many, many thousands of miles out of harm's way.

### Moderator
Claim: And the side arguing against it, what do they have to put forward here?

### Moderator
Claim: Well, I think their best point of view is that this just doesn't feel like conventional warfare. These are not soldiers on a battlefield. These are individuals on a kill list. They're targeted. They feel like assassinations. And it raises questions about the morality, about the legality, who is it that approves these targets, how are they vetted, how precise is that process? What are the legal safeguards around it? And particularly when the administration reserves the right to kill American citizens abroad with this program, it just shows how difficult and problematic the legal environment is around these issues.

### Moderator
Claim: And the nice thing about our debaters tonight, none of this is theoretical for them. So let's bring them out. And thanks to Bob Rosenkranz for that introduction.

### Moderator
Claim: Thank you.

### Moderator
Claim: Thanks, Bob.

Also, as I mentioned, because we are a radio broadcast, there will be a few points in the evening when I want to encourage spontaneous applause. Laugh when we come back from breaks and things like that. I think you kind of caught it. If I give you one of these - - yeah, you all got it. I'm getting nods. Well, done without any training whatsoever. And I also, at this point, want to just ask for one more round of applause for Robert Rosenkranz who really made this all possible.

The U.S. Air Force-- it's the agency that makes pilots. And in one recent 12-month period, it made 250 of them trained up to fly bombers and fighter jets.

But that is versus the 350 who were trained during the same period to fly drones by remote control, never leaving the ground themselves. 350 drone pilots versus 250 traditional, clearly a trend that has good reasons behind it as the U.S. and especially the CIA sends these riderless aircraft week after week after al-Qaeda. But there's also a backlash against the drones and worries that the way we're using these weapons could come back to bite us. Well, this sounds like the makings of a debate. So let's have it. Yes or no to this statement: The U.S. drone program is fatally flawed, a debate from Intelligence Squared U.S. We're at the Kaufman Music Center in New York City. I'm John Donvan. We have four superbly qualified debaters, two against two, who will argue for and against this motion: The U.S. drone program is fatally flawed. As always, our debate will go in three rounds. And then the live audience votes to choose the winner.

And only one side can win. Our motion is "the U.S. drone program is fatally flawed." And let's meet the team arguing for this motion, but first welcome, ladies and gentlemen, Ahmed Rashid. And, Ahmed, you are a journalist, you're a bestselling author. In your youth straight out of Cambridge you moved to Baluchistan in Pakistan and became a guerrilla fighter and a political organizer for 10 years. You came home with fewer teeth and a case of malaria. You then became a journalist and before September 11 you spent some time with the Taliban and wrote a book called "Taliban: Militant Islam, Oil, and Fundamentalism in Central Asia." It was a book that everybody wanted to read after September 11. According to the New York Times, when you wrote this book you, quote, "wore out welcome with the Taliban," meaning that it wasn't exactly a fluff piece.

### Conspiracy Advocate (CA)
Claim: Well, that's not entirely true because there is and there always has been a peace lobby within the Taliban. And they do talk to me still, but the hardliners, I agree, don't like me very much.

### Moderator
Claim: And thank you, Ahmed Rashid. And your partner is?

### Conspiracy Advocate (CA)
Claim: Kael--

### Moderator
Claim: John Kael Weston, thank you. Ladies and gentlemen, John Kael Weston. Kael, you are also arguing that "The U.S. drone program is fatally flawed." You had a very interesting and unorthodox career in the State Department. You were there for 10 years. Seven of those years you were in Iraq and Afghanistan but you were not on a red carpet inside an embassy, you were in the dust with U.S. Marines. You were out there in the field more than any other State Department officer. Newsweek, Kael, called you a "renegade diplomat" in part because of this style in the field but also because you had some issues in dealing with authority. So this debate, you're up against a general and an admiral, both four stars. Are you a little intimidated by that?

### Conspiracy Advocate (CA)
Claim: Not really, not because they're-- not because they're not great gentlemen, but, you know, I got star struck my first year and then realized that I would no more rather be with people in the military than with the gentlemen across the table but I have to say, that being said, you know, Ambassador Holbrooke used to remind me what Premier Clemenceau said about war, which is "It's too important to leave to military men." If they're feeling bad about that, they just need to Google what General Jack Rippersaid in response, which is even a better quote. So, thank you.

### Moderator
Claim: All right. We're going to come back to you to find out. Ladies and gentlemen, John Kael Weston. And our motion is "The U.S. drone program is fatally flawed." And here to argue against this motion, two debaters. First, ladies and gentlemen, please welcome Dennis Blair. you are a former director of National Intelligence, a retired four-star general in the Navy, sixth generation Naval officer in your family. You've commanded the United States Pacific Command. Words used about you pretty often include often "cerebral, brainy, workaholic." You're fluent in Russian. You're a Rhodes Scholar. But we've also heard that you once tried to waterski behind the Navy destroyer-- which tells us what about you?

### Scientific Advocate (SA)
Claim: Well, you can be over prepared for the task at hand.

### Moderator
Claim: Thank you, Dennis Blair, ladies and gentlemen. And, Dennis, your partner is?

### Scientific Advocate (SA)
Claim: One of the wise warriors of my generation in the armed forces, retired Air Force General Norty Schwartz.

### Moderator
Claim: Ladies and gentlemen, Martin Schwartz, General Martin Schwartz. Norton Schwartz, you're also taking this position against our motion. The motion is "The U.S. drone program is fatally flawed." You're arguing against it.

You have only recently retired as the U.S. Air Force's top officer. You were chief of staff in 2012 after 39 years of service. You got interested in flying as a kid. You graduated from the Air Force Academy. As a command pilot, you have more than 4,400 hours under your belt. And it was under your leadership that actually the Air Force retooled significantly in the direction of drone aircraft remotely piloted aircraft. And I just want to know have you actually piloted one of the-- one of those riderless planes?

### Scientific Advocate (SA)
Claim: I have. And interestingly enough, it's harder than it looks. It's not a cartoon. The interesting thing, ladies and gentlemen, is that you don't have the sensations of flight that you actually have in an aircraft. And it makes a big difference.

### Moderator
Claim: So it's a different kind of pilot.

### Scientific Advocate (SA)
Claim: Is it-- well, it is a different piloting experience for sure.

### Moderator
Claim: Okay, thank you. Ladies and gentlemen, Norton Schwartz, General Norton Schwartz. as we said at the beginning, this is a debate. It's a contest. And in this contest only one side wins. And we have you, our live audience, make that choice. By the time the debate is over, we will have asked you to vote twice-- once before and once again after you've heard the arguments. And the way we decide victory here-- the team who has changed your percentage point-- your vote by the most percentage points will be declared our winner. So, let's go now to do the preliminary vote. You go to those keypads that are at your seat. And it's on the right hand-- right arm of your seat. You look at the motion-- I want to be careful, but there's kind of a negative built into this motion. The U.S. Drone Program is Fatally Flawed. This is the team that's taking that position. They're for that motion. If you agree with them at this point, push #1. If you take the opposite side-- which means that you're with this team, push #2. And if you're undecided, which is perfectly reasonable, push #3. And we'll lock the votes in a couple of seconds. If you pushed the wrong button, just correct yourself and the system will record your last vote. And you can ignore all of the other keys.

And then you stick around to the end to the debate. We have you vote immediately. And then within about 90 seconds, we find out who has picked up the most percentage points. Okay. We're going to close those out now. Our motion is: The U.S. Drone Program is Fatally Flawed.

Onto Round 1. Opening statements from each of our debaters in turn. They will be seven minutes each. First to speak-- John Kael Weston. He is a former State Department officer. He spent seven years in Iraq and Afghanistan as an advisor to U.S. Marine Combat Units. He is now a regular contributor to the Daily Beast. He's writing a book, due to be published in 2014. Ladies and gentlemen, John Kael Weston.

### Conspiracy Advocate (CA)
Claim: Thank you. And I want to say, it's great to be back in New York City. I was a resident here for four years, and I think it's one of the two most scrappy and resilient places in America. I won't say what the other one is, but you can probably guess.

I also have to say that although our topic tonight is drones, I think in the back of our mind, we know that our nation is having a very important debate about Syria. And I just want to say I'm grateful that we the people are leading our government on that issue, and at least we're pausing for a while, perhaps, before a decision is made.

The issue at hand is the motion that Ahmed and I are going to spend seven minutes each-- as well as the rest of the evening, of course-- we believe strongly that the program is fatally flawed. Ahmed will cover some of the issues that I won't. We've divided the labor as follows: he's going to look at lot of the legality questions. He'll look at-- from his perspective in Pakistan and all the great books he's written-- how much recruiting has actually increased. And contrary to, I think, some of the conventional wisdom, how effective and how targeted some of these drone strikes are.

My points are going to be based on having lived in interesting places like Fallujah, Khost, Helmand . I view my role tonight as being the ambassador for the people that don't get a voice on this debate, which are really the Afghans and the Pakistanis-- most of the people I sat across a table from and heard the stories after the drones launched the hellfire missiles. So, if I do that well enough, hopefully you'll get some of their voices, which is what motivated me mostly in this debate, is to not speak as a former State Department official, but to actually speak for the people. So, it's not a headquarters perspective. It's not a State Department official perspective. It's their perspective.

One thing left out of my bio was that my mother is a fifth-grade schoolteacher, so if you'll bear with me, I'm going to ask you to do a couple things she taught me. I've got about 30 seconds to ask you for this, so, the first is show and tell, and the second is a pop quiz. I'm going to start with the show and tell because-- I think it reinforces, again, what's lost in the drone debate too often.

This is a pakol, which is a wool cap that basically, the more rural parts of Afghanistan, you'll see the tribal people wearing. Again, I'm trying to give voice to these guys, some of my friends.

It's a wool cap that kind of looks like-- I don't know how I'd explain it, but it's a pretty cool cap that's round and rolled up at the bottom. The--

Worn by Afghans in the tribal regions. This sparkly cap is called a kandahari, which is what I consider the next generation of leaders that you'll see wearing a lot. And again, if we're listening to them, what they tell us is basically that the drone program is undercutting them and undercutting their future.

And then finally-- and I'll be quick-- I think I'm speaking on behalf of the front-line troops, because contrary, again, to conventional wisdom, this Kevlar helmet-- which is a Marine helmet-- I think represents those of us who dodge more IEDs and dodge more bombs when these drone strikes actually don't hit their target.

Okay. The quiz. If you could pull out a piece of paper, my mom will be proud. Or if you can take some mental notes-- I'm going to ask you two questions, and I think they're important questions, and they're relevant. The first is, after 12 years of constant warfare, which really started in the scarred city of New York with Lower Manhattan, what words or adjectives do you think Afghans or Iraqis or Yemenis associate with the United States of America? Nouns, adjectives, whatever comes to mind.

And then secondly, what words would you associate with our nation, the United States of America, after 12 years of basically constant warfare? Second question is, why is May 1, 2010, relevant to this debate? Don't Google it. Don't use your iPhones. But if you happen to-- if that rings a bell with you, we'll come back to it. The two case studies I'm now going to focus on in about the-- half of the time I've got left are one from Iraq, Fallujah, and a couple basically from Afghanistan.

In 2004, drones were not armed. They were eyes in the sky. When drones became a fatally flawed program is really the X that I'm trying to hit here. The Fallujans would look up, they'd hear a flying lawnmower. The women would hang their clothes and get awkward and uncomfortable. The city leaders would come into our meetings and be irritated, but they weren't yet strategically against us. And, of course, this is the site of the largest battle of the Iraq war. When did they become fatally flawed, and who did they become fatal to? I will argue, and Ahmed will argue as well they became fatal to civilians, more than a few. And they became fatal, I believe, to all of us. In Afghanistan, in early 2009, marine general Larry Nicholson and I were in a place called Tagaz, which is basically the southern reaches of our area of operation.

We met a bunch of Marines who were alone and unafraid at the edge of the American military empire, overstretched. We all know the story. The next day, in the same location, a suicide bomber blew himself up, killed two marines and killed a corpsman. If anyone wanted revenge, I did. If anyone wanted revenge, General Larry Nicholson did. If anyone wanted revenge, the United States Marine Corps did. Within a few days, we identified some suspicious looking guys who were near the area from above. Two drone strikes landed a couple hellfire missiles. One of the men was killed right away. The other one was split in two. And we all watched as he tried to drag himself into the hole from the first strike. He couldn't hide. He bled out. He died. Was it a good guy? Absolutely not. But was he found out to be directly tied to the attack? No. That happens more than we'd like to admit. The next example is based on a New York Times article that just came out on Sunday. You may have read it, but I wanted to be as topical and as recent as I could.

Reportedly 14 Afghans were killed. So I asked a friend of mine, who lives in Kunar, what he was hearing. And he quoted a villager who said this: "May Allah give me power for one day to use a single drone on the American people so that the American politicians understand how much it pains when a missile comes from the sky and kills your relatives in front of your eyes, and you can't revenge them any more." I've got another quote, but I don't have time to get there. In closing, I found a very convincing op-ed by a very senior former member of our government, highly experienced, wrote it brilliantly, brilliant perspective. And it was titled, "Drones alone are not the answer.” And it was a New York Times op-ed that came out on August 14th, 2011. He said, "the important question today is whether continued unilateral drone attacks will substantially reduce al-Qaeda's capabilities. They will not.” And I am pleased that he is on stage with us. It's Admiral Blair. And I look forward to hearing more comments based on the argument he made in the New York Times. So I'm out of time, but thank you.

### Moderator
Claim: Kael, just for the-- our radio audience, can you tell them that you're holding up--

### Conspiracy Advocate (CA)
Claim: It's a wool cap that kind of looks like-- I don't know how I'd explain it, but it's a pretty cool cap that's round and rolled up at the bottom. The--

### Moderator
Claim: Worn by?

### Conspiracy Advocate (CA)
Claim: Worn by Afghans in the tribal regions. This sparkly cap is called a kandahari, which is what I consider the next generation of leaders that you'll see wearing a lot. And again, if we're listening to them, what they tell us is basically that the drone program is undercutting them and undercutting their future.

And then finally-- and I'll be quick-- I think I'm speaking on behalf of the front-line troops, because contrary, again, to conventional wisdom, this Kevlar helmet-- which is a Marine helmet-- I think represents those of us who dodge more IEDs and dodge more bombs when these drone strikes actually don't hit their target.

Okay. The quiz. If you could pull out a piece of paper, my mom will be proud. Or if you can take some mental notes-- I'm going to ask you two questions, and I think they're important questions, and they're relevant. The first is, after 12 years of constant warfare, which really started in the scarred city of New York with Lower Manhattan, what words or adjectives do you think Afghans or Iraqis or Yemenis associate with the United States of America? Nouns, adjectives, whatever comes to mind.

And then secondly, what words would you associate with our nation, the United States of America, after 12 years of basically constant warfare? Second question is, why is May 1, 2010, relevant to this debate? Don't Google it. Don't use your iPhones. But if you happen to-- if that rings a bell with you, we'll come back to it. The two case studies I'm now going to focus on in about the-- half of the time I've got left are one from Iraq, Fallujah, and a couple basically from Afghanistan.

In 2004, drones were not armed. They were eyes in the sky. When drones became a fatally flawed program is really the X that I'm trying to hit here. The Fallujans would look up, they'd hear a flying lawnmower. The women would hang their clothes and get awkward and uncomfortable. The city leaders would come into our meetings and be irritated, but they weren't yet strategically against us. And, of course, this is the site of the largest battle of the Iraq war. When did they become fatally flawed, and who did they become fatal to? I will argue, and Ahmed will argue as well they became fatal to civilians, more than a few. And they became fatal, I believe, to all of us. In Afghanistan, in early 2009, marine general Larry Nicholson and I were in a place called Tagaz, which is basically the southern reaches of our area of operation.

We met a bunch of Marines who were alone and unafraid at the edge of the American military empire, overstretched. We all know the story. The next day, in the same location, a suicide bomber blew himself up, killed two marines and killed a corpsman. If anyone wanted revenge, I did. If anyone wanted revenge, General Larry Nicholson did. If anyone wanted revenge, the United States Marine Corps did. Within a few days, we identified some suspicious looking guys who were near the area from above. Two drone strikes landed a couple hellfire missiles. One of the men was killed right away. The other one was split in two. And we all watched as he tried to drag himself into the hole from the first strike. He couldn't hide. He bled out. He died. Was it a good guy? Absolutely not. But was he found out to be directly tied to the attack? No. That happens more than we'd like to admit. The next example is based on a New York Times article that just came out on Sunday. You may have read it, but I wanted to be as topical and as recent as I could.

Reportedly 14 Afghans were killed. So I asked a friend of mine, who lives in Kunar, what he was hearing. And he quoted a villager who said this: "May Allah give me power for one day to use a single drone on the American people so that the American politicians understand how much it pains when a missile comes from the sky and kills your relatives in front of your eyes, and you can't revenge them any more." I've got another quote, but I don't have time to get there. In closing, I found a very convincing op-ed by a very senior former member of our government, highly experienced, wrote it brilliantly, brilliant perspective. And it was titled, "Drones alone are not the answer.” And it was a New York Times op-ed that came out on August 14th, 2011. He said, "the important question today is whether continued unilateral drone attacks will substantially reduce al-Qaeda's capabilities. They will not.” And I am pleased that he is on stage with us. It's Admiral Blair. And I look forward to hearing more comments based on the argument he made in the New York Times. So I'm out of time, but thank you.

### Moderator
Claim: Thank you, John Kael Weston. Our motion is "the U.S. drone program is fatally flawed." And here to speak against the motion in the opening position, General Norton Schwartz. He retired as chief of staff of the U.S. Air Force in 2012 after serving 39 years. He is currently president and CEO of Business Executives for National Security. Ladies and gentlemen, General Norton Schwartz.

### Scientific Advocate (SA)
Claim: Good evening, ladies and gentlemen and our fellow debaters. On behalf of Admiral Blair, it's a privilege to be here to address with you a very, very important topic. And, Kael, I would argue that I'm representing the troops in the field tonight. And we can talk about the relative advantages. But I think it's important also to address the issue Kael mentioned of the strike on Sunday.

It's important to know that that strike killed the individual who publicly admitted to kidnapping Sergeant Bowe Bergdahl of the United States Army who was still the only American service person who is incarcerated in Afghanistan today. Now, it may be that others were also injured and/or killed in this event. But I would argue that Afghanistan is a declared combat zone, ladies and gentlemen. And under the rules of armed conflict, that this individual was a legitimate target and clearly a combatant. And he will kidnap no more American servicemen.

But let me go back to a bit more balanced discussion. What I want to do tonight-- and I submit, ladies and gentlemen, that the employment of U.S. strike-capable systems is a viable and a rational response to a vexing battlefield problem, one that must be calibrated, used with care, synced withpolicy. But nonetheless, one that allows us to pursue our objectives in a fashion that minimizes loss of life for friendly forces and maximizes the opportunity to avoid needless casualties of friendlies; in other words, collateral damage.

Simply remotely piloted aircraft, or drones, permit more considered and more accurate and, as a result, more proportionate application of lethal force than any other comparable weapon system. Because they can spend longer time over the target than equivalent manned aircraft, they give their operators the time to maximize the certainty but not necessarily achieve absolute certainty that they are engaging the right enemy combatants and that they have the time and the means to confirm the presence of noncombatants in the presence of the intended target. Thoughtful observers like our partners tonight have mentioned a number of criticisms. Let me talk quickly about a couple of them.

One is that the absence of physical risk to the operator encourages our political leadership to use remote systems more often than they would if they had to put American troops in harm's way. I would counter by asking whether those who use this argument would prefer for the American military to absorb casualties just for the purpose of making war less numbing to the political leadership. In addition-- that's a tactical level-- is the ability of remote systems to maintain surveillance of target areas with remote operators carefully and deliberately evaluating potential targets against the criteria that allows them to shoot, that makes this system so discriminating and effective.

Soldiers and airmen under fire on the ground I think you would agree, Kael, are far more likely to shoot back at the sources of fire aimed against them, with greater danger to noncombatants than are remote operators whose safety and lives are not at immediate risk. There's also a concern that nonstate or state actors will use these technologies against us in a more crude and indiscriminate fashion than do we. And well, they might. But the reality is is that this technology is proliferating, and not because we chose to use it. It is a fact of technology advancing. And our lead was and remains significant.

So, let me go to a quick summary of some data. This goes back to 2011 in Afghanistan during the surge period. There are about 150,000 Air Force flights in Afghanistan in 2011. Sadly, about 3,000 of those flights were medical evacuation sorties of our wounded, and our dead. Compare that total to 25,000 close air support sorties and support of ground forces, your Marines, of which 1,400 had at least one weapon release. So what this means is, is out of 25,000 sorties, 1,400 actually released a weapon. There were many sorties that flew with no weapon release at all. That's what a professional Air Force does. Ready, finger on the trigger, but extremely careful and deliberate about applying lethal force in practice and in principle. 333 of those 400 weapon releases were by remote systems. Now, I ask you, were those releases-- the three quarters of the releases-- from manned aircraft somehow more practical, less immoral, less unfair than those 25 percent that were released by unmanned aircraft? I think not.

### Moderator
Claim: Thank you, Norton Schwartz. Our motion is "The U.S. drone program is fatally flawed," and here to speak in support of the motion, in other words, he feels the program is fatally flawed, Ahmed Rashid. He is a Pakistani journalist based in Lahore and the bestselling author of several books, including "Taliban” and “Pakistan on the Brink." Ladies and gentlemen, Ahmed Rashid.

### Conspiracy Advocate (CA)
Claim: The first thing I think to make clear is that unfortunately drones-- which is-- it's a weapon, it's a tool, it's a tactic-- has almost become a strategy in itself, and this is how foreign governments and countries where drones are being used see it. All the good of U.S. foreign policy, aid, foreign aid, training of security forces, bank loans, et cetera, et cetera, all are demolished when at the same time the U.S. uses drones. So in fact drones are undermining U.S. foreign policy. They become the only symbol of foreign policy which people abroad remember when they are-- when those countries in particular are targeted. And some of the countries like Yemen, like Pakistan are in fact allies of the United States and drones are being used against allies, naturally that is infuriating the population even more.

Secondly, how badly have drones affected the counterterrorism strategy, the much more sophisticated strategy that has emerged from the U.S. in the last few years, where the whole strategy is made to protect population, to provide economic incentive, development, et cetera. Again, here we see the counterterrorism strategy being undermined completely by drones because the people are very scared of them, and they do take out civilian targets just as much as they take out al-Qaeda. The other question which I think has to be agitating the minds of many Americans is how legal is this?

How legal is it to bomb and kill individuals in another country with which you are not at war, with which nothing has been disclosed, there's no transparency involved, nobody is informed as to why and how these people are being killed, and often this is, again, taking place in countries, you know, that are allies of the U.S. The lack of transparency is not helped by the fact that the CIA has been mostly involved in using drones, especially in Pakistan. If-- and certainly there's a move now to move some of these drone attacks to the defense department, but-- and that could increase transparency, but at the moment the CIA's running it and nobody knows how these targets are chosen or whether killing these individuals are justified or not. Now, what all this is leading to is an enormous buildup of hatred for the United States, and that is not just affecting people in the target countries but people all over the Muslim world in particular.

It's quite shocking to see the figures in Pakistan. One poll puts 74 percent of Pakistanis now hate the U.S. more than India, and remember, Pakistan has fought three wars against India, and India is the proverbial enemy. Another poll that I just read recently in Chicago, yesterday, put it at 94 percent. And here, as I sit, we're talking about a so- called ally of the United States.

Now, what should also be worrying is the precedent that is being set. What happens when another country will start using drones? First of all, what happens if a European country, or Russia, or a so-called ally of the United States uses drones? What is the U.S. strategy going to be? How is that going to affect U.S. foreign policy? Are you going to slap that country down? Are you going to tell that country to behave itself and say, "No, only we have the right to kill people in other countries. You don't have that right."Even more dangerous, what happens when an enemy of the United States uses drones? What happens if North Korea, tomorrow, uses drones to kill South Koreans? What happens if Al-Qaeda itself develops drones? What happens if any-- if the Syrians or any of the problematic regimes, dictatorships, start using drones? So, what will be the U.S. policy then? Are you going to go and bomb those countries? What is the U.S. strategy policy going to be? There's a complete vacuum here. There's no thought being given to this. But this could happen tomorrow. Drones now are everywhere. Drones are being used for all sorts of other, peaceful projects. And any of those drones can be bought on the market and they could be converted into drones that kill people. And I think that the idea that somehow, the U.S. is going to have a monopoly over this instrument forever is very short-sighted.

I think the other thing that is-- that I must answer, the issue of civilian casualties. There is, for example, a drone strategy now, where drones fire what are called signature strikes. That is if a bunch of militants are seen or one or two militants are seen in a group of civilians, or sitting in a bus or sitting in a truck, or something like that, drones are used-- can be used to kill that militant. But of course, they kill everyone else in the truck, too. Women, children, men, civilians. Now, the last drone strike, actually, on Sunday, was not the one that the general mentioned, but was one in which 16 civilians were killed. And President Karzai just complained to the Americans. And they were killed by a drone, because there were a couple of militant guys in the midst of these people.

I think they were in a bus or a truck or something like that. So, the fact is-- I mean, the issue of civilian casualties is very controversial. The Americans do not tell us what-- you know, how many civilians have been killed. But estimates from other groups put the casualties in Pakistan alone somewhere between 500 and 1,000. I mean, that's the level of inaccuracy that we have, because we really don't know. These areas are inaccessible or-- and the people who would know, certainly, by watching the video screen, the drone firer, that kind of information is available. And lastly, I think we have to understand how drones have been a recruiting poster for Al-Qaeda and global jihad. Even local groups-- local militant groups in countries which have nothing to do with Al- Qaeda, nothing to do with global jihad-- if they have been droned, they become global jihadists.

They want to strike back at America. They want to kill Americans. And that is really what is very dangerous, that more and more groups who are really fighting local wars and conflicts are becoming militarized and wanting to strike back at the United States and those other countries.

### Moderator
Claim: Ahmed Rashid, your time is up. Thank you very much. And here's where we are. We are in the opening round of this Intelligence Squared U.S. Debate, where our motion is: The U.S. Drone Program is Fatally Flawed. You have heard three of the opening statements, and now on to the fourth. Let's welcome to the lectern Adm. Dennis Blair. Dennis Blair-- served as director of National Intelligence and during his 34-year Navy career, served as commander in chief, U.S. Pacific Command. Ladies and gentlemen, Adm. Dennis Blair.

### Scientific Advocate (SA)
Claim: Gen. Schwartz addressed the use of drones in a battlefield area with U.S. troops deployed. I'm going to talk about the more controversial program, in which we use drones in areas in which we do not have our troops in action. And Pakistan, of course, is the primary example that comes to mind. In fact, probably our motion tonight, "U.S. drone program is fatally flawed," is shorthand for "the American drones in Pakistan have been a failure." And you've heard from Mr. Rashid some of the objections to that.

I would tell you that there in fact is no independent drone program. The drones are part of a wider strategy which is dedicated to ending the threat from al-Qaeda, a threat with which this city is very, very familiar.

The policy of the drones, a tactic to an end, are to take care of the hard core leaders and fighters who are not persuadable, who are not going to change their demonstrated and committed intention to kill as many Americans as they can before they-- before they can accomplish that. The-- a conflict between a country, the United States, and a non- state group like al-Qaeda, is allowed under international humanitarian law. And that's what we are involved in. It began here almost 12 years ago, 12 years ago tomorrow. It has continued with al-Qaeda's affiliates. Al-Qaeda in the Arabian Peninsula sent a bomber to try to kill a bunch of Americans in an airplane over Detroit. TTP, Tehrik-i- Taliban in Pakistan, sent Faisal Shahzad a few blocks south of here to Times Square to kill a bunch of innocent Americans if he could. We are at war with this group. And the leadership of these organizations holed up in places like northwest Pakistan and Yemen, places where the governments of our allies, as Mr. Rashid said, do not control their territory.

It's worse in Pakistan. They not only do not control their territory. They give permission to the United States to take action where they cannot, and then they blame us for doing it, which accounts for a great deal of the sentiment in Pakistan when a dissembling hypocritical policy of Pakistani politicians allows them to blame us for actions which they themselves permit. But they could stop us from doing it any time. And the government in Yemen, by way of contrast, openly cooperates with us and tells its people that it does.

Now, the drones have been successful. We have killed most of the people who planned, who directed, and then who gloated over the felling of the Twin Towers, the attack on the Pentagon and the aborted attack that ended in Shanksville, Pennsylvania.

And we have done that not only with drones, but by armed raids, as we saw in Pakistan, by a lot of cooperation with other countries and a lot of hard intelligence. So drones have played a key role in a successful, but I would argue first phase, of our overall campaign against al-Qaeda. But what about the next phase? I think the role of drones in the next phase should be much different, not because the program has been a failure, but because the situation has changed, and the drones and other tactics have been successes. Now the job is to reduce al-Qaeda from a small-scale threat, which is where it now is, to a nuisance. And to do that, we have to undercut support for al-Qaeda. We have to make sure that Muslim mothers and fathers don't think it's a good idea to send their sons and daughters to strap on suicide vests and to kill innocent people around the world. Al-Qaeda is doing a wonderful job against itself. It has killed far more Pakistanis, far more Muslims than it has Americans and Europeans. But we need to help it further along.

And we must do that by becoming even more selective, even more discriminating, even more careful in our use of weapons like drones in the future. And the great bulk of our efforts must be dedicated to helping countries like Pakistan, like Yemen, like Mali, like the southern Philippines, like Somalia, like Libya, like Afghanistan, to make their lives better for their people so that they do not support those who attack the United States and their own governments and others. And this means that we need to continue to work with them. We need to train their security forces to do their jobs to provide security, to do it humanely, respecting the rights of the people. More than that, we need to help them provide economic opportunity, security, dignity, in the words of the Arab Spring. There will be a role for drones in that next phase of this-- of this long-term combat against al-Qaeda. But it will be a more limited, more discriminating role.

And the policy in the past certainly has not been a failure, and it must adapt to be a success in the future. And it's only through a campaign like this, ladies and gentlemen, that I believe that we can turn al-Qaeda into just one more in a long line of terrorist groups that flared up, guttered, and then died, which is where it belongs. Thank you.

## Round 2

### Moderator
Claim: Thank you, Dennis Blair. And that concludes Round 1 of this Intelligence Squared U.S. debate, where our motion is "the U.S. drone program is fatally flawed." Now we move on to Round 2. And Round 2 is where the debaters address one another directly and answer questions from you in the audience and me-- and from me as well. We have two teams of two arguing against this motion. The team arguing for the motion that the program is fatally drawed-- Ahmed Rashid and John Kael Weston, the journalist and the diplomat. We've heard them argue that drones give a bad name to the United States, that they have become a negative symbol to many people in the world who live under doctor underneath them.

That they are killing civilians as much as they're killing al-Qaeda; that signature strikes are taking out civilians and that they're a factor that is building up hatred against the United States and working as a recruiting poster for al-Qaeda. The team arguing against the motion, the admiral and the general, Dennis Blair and Norton Schwartz are arguing that drones are far more accurate than any comparable weapon systems; that they minimize loss of life certainly for U.S. troops, but also for civilians on the ground because of that accuracy; that they're a tool That lets the U.S. military reach the enemy in extremely difficult-to-reach places; and that they have done their job, that they have decimated al-Qaeda.

I want to go to the team that's arguing against the motion, which means that you do not think the program is flawed, and quote back to you something that one of your opponents, Ahmed Rashid said, in which he said-- and I'm pretty close to verbatim here.

He said that the drones take out civilian targets just as much as they take out al-Qaeda. And I don't know, Ahmed, how literally you meant that. But I want to put the question to this side. In terms of this proportion of civilian casualties to desired targets, what do we know about that? Norton Schwartz.

### Scientific Advocate (SA)
Claim: The best information we have, one of the best sources, is the Long War Journal. And it's-- it estimates that civilian casualties versus legitimate combatants in the Afghan theater is about one to seven; in other words, one civilian casualty to seven legitimate combatant casualties. In Yemen, the numbers are somewhat different, about one civilian casualty to five. Now, you can question whether Long War Journal's analysis is accurate. It's consistent with some of the UN reporting as well.

I would argue again that any loss of life, any civilian loss of life, is not what uniform personal strive for. They strive to avoid that outcome.

### Moderator
Claim: Let me take it over to Ahmed Rashid. Ahmed, I was quoting you as saying that the civilian loss is just as much as the-- the death of al-Qaeda targets. I don't know if you meant it 50/50, if that's what your point was.

### Conspiracy Advocate (CA)
Claim: Well, we really don't know. I mean, but certainly there's enough evidence in countries like Pakistan and Afghanistan that civilians have died in considerable numbers. Now, that's probably getting less and less as drones become more and more accurate. But as long as things like what I described, the signature strikes continue, where it is justified for a controller to drop a bomb on a group of people in which some of them may be militants and others not, obviously, you are going to get civilian casualties.

And as the admiral said this is a war zone. And, in a war zone, you're going to get civilian casualties. The fact of the matter is that this is really undermining and destroying everything else that the U.S. is trying to do in these countries.

### Moderator
Claim: I want to come a little bit later back to the topic of signature strikes and talk about those more specifically. But just back to Dennis Blair on this notion of the accuracy of these weapons. Your team is arguing that, in fact, because they can hover over an area for so many hours, because-- maybe you're even saying because there's not a pilot with his heart beating and racing and being shot at, that there's a more rational and sober process happening at the pilot end of this, and that that makes them safer and more accurate. Is there something--I'm trying to get at, is there something in the nature of the weapon itself that-- that resulted in accuracy that's being produced on the battlefield? Because your opponents are saying that they're sloppy.

### Scientific Advocate (SA)
Claim: Well, I think you have to say compared to what? And when one compares the accuracy and the killing and wounding of bystanders from drones compared to, for example, artillery which is another means of close air support from a manned aircraft. Then it has fewer innocent casualties. That doesn't mean it's zero, and everyone as General Schwartz said is to be greatly regretted, but it is a-- I can tell you, your regrets are fewer if you're operating drones than if you're shooting artillery or having manned aircraft being called in.

### Moderator
Claim: Okay, let me take that then to the other side-- take it to John Kael Weston. The other side is making a compelling argument that in fact the number of casualties is going to be lower than if somebody were dropping a bomb, firing an artillery shell, or even putting boots on the ground, that the proportion is lower.

### Conspiracy Advocate (CA)
Claim: No, I think that the key part of the ratio of one to seven and one to five is the equals sign behind, and that equals sign is a factor of two, three, four, five. What basically I think we're losing focus of is what kind of reaction are you getting in village, after village, after village, and how many more enemies and how many more targets are you creating even if one Afghan or one Pakistani is killed.

### Moderator
Claim: John, I want to let you have a run at that point, but it doesn't actually answer the question of--

### Conspiracy Advocate (CA)
Claim: I think that the numbers--

### Moderator
Claim: --in terms of body count.

### Conspiracy Advocate (CA)
Claim: --the body count, yeah, I haven't been close to these drone strikes. You know, we tell ourselves often what we want to hear, and that gets translated into memos in Washington, but the Afghan and Pakistani stories that I have heard is that it's-- whether it's one to seven or one to five, it's a lot more than any of us would like to admit to each other. So I don't want to argue numbers. I think it's a strategic equals sign at the end of the ratio that is the real problem.

### Moderator
Claim: Okay, I do want to come back to what you're talking about, the equals sign being the impact on the image of the United States, but I-- the other side has already heard you make that argument.

So I want to give them a chance to respond to that, and I'll go to Norton Schwartz. So your opponents have said-- they've referred to the drones as a recruiting poster for al- Qaeda because of the bitter resentment that is resulting in areas where they're being used, and do you see that?

### Scientific Advocate (SA)
Claim: I understand the argument, but I-- but the counter to it is the reality that the U.N. reports that 80 to 84 percent of the civilian casualties in Iraq and Afghanistan were caused by the insurgency.

### Conspiracy Advocate (CA)
Claim: General, I-- absolutely. I think Muslims are killing more Muslims than Muslims were killing me, or the Marines, or the generals that I worked with. They wanted to kill us. We're hard to get. I think the issue--

### Scientific Advocate (SA)
Claim: I-- you make my point.

### Conspiracy Advocate (CA)
Claim: Well-- but drones, you've made a point earlier on about pilots being somehow more rational, being removed from the battle, operating out of Nellis Air Force Base in Nevada or wherever they're operating out of.

I would disagree. We don't give medals for restraint, we give medals for combat valor, but I saw a lot of restraint on the front lines.

### Scientific Advocate (SA)
Claim: Look, your Marines were rigorous about applying the rules of engagement, and so are our pilots, Kale. The bottom line is this is about discipline, and I agree. Civilian casualties is the equals sign, and everyone knows that. And are mistakes made from time to time? Yes, but that is not the policy, nor is it the training, nor is it the supervision of those assets.

### Moderator
Claim: Ahmed Rashid.

### Conspiracy Advocate (CA)
Claim: Look, I-- if I can just make one point, neither of you two, with all due respect, have addressed this whole issue about U.S. foreign policy and the use of drones. The fact is that today, you know, you are throwing technology at foreign policy conundrums where you should throw aid, or diplomats, or peacekeepers, or whatever it is.

What we are seeing today in many parts of the world where drones are being used, that foreign policy is being subsumed by technology. We've never had this before. I mean, how can you allow technology to determine what your foreign policy--

### Moderator
Claim: Are you saying, then, that drones represent a-- that drones in themselves represent a new dimension in this conflict? In other words, are you-- would you be making the same argument if planes were dropping bombs in these communities that you are making because drones are hovering over them?

### Conspiracy Advocate (CA)
Claim: I'm saying that this is the impact that they are having in the countries that received these drones. This is what the public thinks. This is why there's so much--

### Moderator
Claim: But is that drone-- is that drone specific or is that ordinance? Is that explosive specific?

### Conspiracy Advocate (CA)
Claim: No, it's about drones because drones are a very sinister way of of killing people. I mean, they're not accepted as a normal--

### Moderator
Claim: All right, let me bring in Dennis Blair. General, let me just bring in Dennis Blair.

Kael, one second, and let's let them--

### Conspiracy Advocate (CA)
Claim: --by saying the drones are going to come after you.

### Moderator
Claim: You'll get your turn and--

### Scientific Advocate (SA)
Claim: Let me--

### Moderator
Claim: Dennis Blair.

### Scientific Advocate (SA)
Claim: Let me talk about Yemen and just take us a little bit out of Pakistan here for a while. In the last two years, we have given $200 million in assistance-- $600 million in assistance to Yemen. Of that, virtually two-thirds has been economic assistance, humanitarian assistance, and governance assistance. Roughly one-third has gone to security assistance. That is, to Yemen. And so, we do have a broad-based program in places like Yemen. We are trying to work on places. The media impression, however, is fascinated with the drones. They're sexy. They're sinister. They're so on. So, I'm sorry, but the reality is that it is a broad-based program of which drones are a part and used very selectively.

And the people who look carefully can understand that. The people who just want to read the first headline and say, "That's all of American policy" are going to stop there.

### Conspiracy Advocate (CA)
Claim: You know, there are two narratives--

### Moderator
Claim: Kael Weston.

### Conspiracy Advocate (CA)
Claim: --at work here. There's the American narrative and there's their narrative. We spent a lot of time talking to each other about our narrative, but if you listen to the future leaders of Afghanistan, you listen to the next generation-- drones is a big issues, because it is about the legalities. The law students at Khost University used to ask me, "What is your case for drones?" Just like Guantanamo, just like the language of these wars that we're in. They are very, very big on how we're doing our wars. So, if we lose that narrative to Al-Qaeda, I think that ratio is actually the equals sign. And if I lined up a bunch of Afghans on this stage, I can tell you, what they tell us is probably what we don't want to hear but we need to hear, and that's really the goal for me tonight, is to bring their voice into this debate. Back on the issue, though, of whether-- you know--

### Moderator
Claim: But before you go to the issue-- and tell me what it is-- because I do want to remember it--

### Conspiracy Advocate (CA)
Claim: --it's back to, you know, dropping bombs from Nevada in Pakistan.

### Moderator
Claim: All right. I want to come back to it, because the point that you just made-- you're reporting from the ground. You're basically telling the high-ranking officers that you were there and that despite their understanding of the situation that because you're on the ground, you're reporting back what you think the Afghans think, that you're sharing your perception of their hearts and minds. I just want to take that to this side. Because I think it's offered in honesty.

Yeah. And so, what they're saying regardless of intentions and even the structure, that word is out not just in the American media, but the word is out in the communities that the drones are different, drones are more dangerous, drones-- you used the word "sinister," that it's a different kind of thing. I just want to-- if you were having dinner about this conversation, and he shared that-- just fact, what would you say to him?

### Scientific Advocate (SA)
Claim: I-- it's pretty--

### Moderator
Claim: Norton Schwartz.

### Scientific Advocate (SA)
Claim: --straightforward, actually. And that is that the reality is that we have a scenario where the weapon-- the platform is not the issue.

It's the legitimacy of the target. And the targeting methodology that goes along with it.

### Conspiracy Advocate (CA)
Claim: Could I put on the table the issue of double and triple tapping? There--

### Moderator
Claim: Explain it-- explain it to--

### Conspiracy Advocate (CA)
Claim: --are a number of cases where-- and I've lived this-- where-- especially in Khost Province, where Mohammed Atta was trained. This is territory directly tied to 9/11, unlike Iraq. When you double and triple tap, you're not even going after the initial target. You're actually dropping bombs on the people that come after Round 2 or Round 3. What's the rationale? What's the intelligence? What's the argument that you would make to a law student sitting at Khost University.

### Moderator
Claim: One second. Did everybody follow what double tap and triple tap means? No? All right. It's when-- basically, it's a follow-up-- it's a second wave, a third wave--

### Conspiracy Advocate (CA)
Claim: --of bombs.

### Moderator
Claim: --attack. And what Kael is saying, that he believes he's seen it happen, where the second wave comes when the firefighters and the hospital people are around. I think that's what you--

### Conspiracy Advocate (CA)
Claim: Family members--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --community member, whoever it is. They--

### Moderator
Claim: All right. I just wanted to--

### Conspiracy Advocate (CA)
Claim: --get bombed, too.

### Moderator
Claim: --have clarity for you on that.

### Scientific Advocate (SA)
Claim: But just to--

### Moderator
Claim: Norton Schwartz.

### Scientific Advocate (SA)
Claim: --set the stage, when I became the chief in 2008, we had 32 24/7 orbits of remote aircraft. When I left, we had 58. Now, we didn't do that because we're sort of generous. The reason we did it is because there was a demand signal from the supportive forces, the Marines and the Army--

### Conspiracy Advocate (CA)
Claim: Could I--

### Scientific Advocate (SA)
Claim: --to-- No. No.

### Moderator
Claim: Kael, let him finish.

### Scientific Advocate (SA)
Claim: Let me finish. To provide the kind of overhead surveillance and strike capability that minimized the risk to their forces. And I would argue, Kael, that this was not just some perception in Washington, but this was real down on the ground.

### Conspiracy Advocate (CA)
Claim: No. I-- General, you know, I have the greatest respect for you. My sand is still deep in my shoes, and so I bring baggage with me. However, I found that the commanders on the ground are the 12 to 14 Marine generals I worked with-- the closer they were to the drones, the more skeptical they were. Doesn't mean that all of your arguments are false. It doesn't mean I think every drone needs to be, you know, eliminated from the battlefield. But the closer you are to where the strategic effect is with the people, the more critical I found the marine commanders to be. I don't want to speak for all of them, but it was-- it was a pretty clear pattern

### Scientific Advocate (SA)
Claim: They should probably speak for themselves.

### Moderator
Claim: Ahmed Rashid, I want to move this to-- in a different direction. Your opponents have made the point, repeatedly, particularly in their opening statements, that the drones have killed a lot of guys that they were supposed to kill, that they have decimated al- Qaeda; and that al-Qaeda is on the way to becoming a footnote in history because of it, which was the whole purpose. These are the guys who blew up buildings in this city. Do you dispute their effectiveness in-- on that agenda?

### Conspiracy Advocate (CA)
Claim: no, I don't dispute their effectiveness. Obviously, this is a military weapon that has been developed to do a certain thing. And it is going to be further developed, and it's going to be used even more. I think the point is that it is being-- it is being used very indiscriminately and without any kind of scrutiny or self-knowledge even amongst Americans. The whole issue of legality, the whole issue of the precedent that it sets for other countries to follow, there are a whole range of political issues and political answers that are needed in order for this weapon to be really legal, be legitimate and be justified. And that is the point. I don't dispute at all that certainly many senior members of al-Qaeda have been killed. But this is a weapon that has opened up a Pandora's box of questions, especially for those countries who are in receipt of this weapon, you know, at the receiving end. And I think we need-- we need answers. I think this question of precedent is absolutely paramount at the moment with what-- if Syria is using--

### Moderator
Claim: Let's take it to Dennis Blair.

### Scientific Advocate (SA)
Claim: Just because you've discovered the drones doesn't mean that this is the first time that anybody has ever thought about these questions. This is a weapons system which combines the capabilities of surveillance and attack, and it is operated according to the rules of law, the control procedures, the follow up procedures that the U.S. armed forces use for all of the weapon systems that we have over the years. We know how to take new weapon systems, use them for mission purposes, control them so that they're done legally, with lawyers in the command loop to a much greater extent than they are for most any other weapons, and you use them for your purpose, and you try to minimize the harmful side effects of which there are many, as there are for any weapon systems in order to get the mission done. And that's how we do it.

### Moderator
Claim: I'm going to let this side respond. I just want to let the audience know that after this response I want to start going to your questions. And the way this will work, if you raise your hand, and I call on you, just stand where you are.

Somebody will come down the mic-- aisle and hand a microphone to you. Hold it about this distance from your mouth so that the radio broadcast can get you. We would really like it if you would state your name and then ask a tight, focused question that's on point for us. Okay. Let's go to this side for the response.

### Conspiracy Advocate (CA)
Claim: Just briefly, I want to actually give voice to a real live Afghan. And I'm going to read a quote. When that incident happened that the New York Times covered, a friend of mine went to a tribal elder, and this is what the tribal elder said. “Siraj Haqqani, the senior most leader of the Haqqani said that since the USA is using drones against people, the people will use Patriot missiles against the U.S.A. Someone in the village asked what he meant, where are the Patriot missiles? Siraj replied, ‘Suicide bombers are our Patriot missiles.’" The question I don't think we still had answered, for example, on the legality question-- and I know we're not in a law seminar, but it's an important one because it's what motivates terrorists to hurt us. Because at the end of the day, I think everyone in this room needs to ask fundamental question, which is, are you and your family safer because of the drone program as it's currently structured, or not?

What is the legality of the third wave of drone strikes in terms of the triple tap? What is the legality of that? What are the lawyers in Washington arguing? They're not the initial targets. There's not intel tied to them.

### Moderator
Claim: Norman Schwartz.

### Scientific Advocate (SA)
Claim: If you are in a declared combat area, as was the case in Fallujah or in other areas that you're familiar with, if you have combatants that depart that initial strike area, this is not unlike what happened with Zarqawi. The bottom line was, now, that was a manned strike. And hopefully, I make no apologize for that either. But the bottom line is that we have a situation where you have people that depart a site that-- that had combatants, that was identified as a location.

And they depart that area, and you reengage. This is what happens when people leave a foxhole or when people depart a tank in a tank battle. The bottom line, Kael, I think is that you argue for discretion. I believe in that too. But on the battlefield, the principle is to engage the enemy. It is that.

### Conspiracy Advocate (CA)
Claim: Well, we went through a phase in Fallujah where everyone was a military-aged male. And I finally told the generals in Baghdad-- at that point, I was young enough that I was still a military-aged male according to our definition. We then switched that definition because we started to treat every Iraqi as a potential threat. And I'll be honest with you, if you're a Taliban member, and you're living in a community around family and friends, with all due respect, I don't think that that makes you a legitimate target. And that's in effect what's been happening.

### Scientific Advocate (SA)
Claim: I agree with that. I agree. But if you're carrying an arm, if you have a weapon, I would argue in a combat zone, that makes you a legitimate target.

### Moderator
Claim: Let's go to some questions. Right down in the front here.

### Scientific Advocate (SA)
Claim: And the point is you can see the weapons from these platforms.

### Conspiracy Advocate (CA)
Claim: Yes and no.

### Moderator
Claim: Thank you for taking my question. I just wanted to address this question--

### Moderator
Claim: Would you mind telling us your name?

### Moderator
Claim: Oh, my name is Jordan Bennett

### Moderator
Claim: Thanks.

### Moderator
Claim: I just wanted to address this question to the gentlemen on the left. You bring up these points that the Afghani people, the Pakistani people are upset, and it's increasing recruitment for al-Qaeda and other anti-U.S. sentiment in these areas because we're using drones. Would the effect not be the same if we were using cluster bombs or snipers or land mines or any other way of killing these people? Is it the drone that's the issue or is it just killing them?

### Moderator
Claim: That's an excellent question. I had actually put it before, and didn't feel that I got answered. So thank you for bringing it up a second time. Yeah. Let's put it to-- let's put it to Ahmed Rashid.

### Conspiracy Advocate (CA)
Claim: No, it is a drone. The drones are an issue because as I said, this is the most sinister weapon that has come into the marketplace, that, you know, there's no individual behind it. There's no judgments being made. And people are very, very scared.

### Moderator
Claim: Ahmed, you-- Ahmed, I just want to ask you, because it's a bold statement. You're seriously saying no judgments are being made in these-- after everything

### Conspiracy Advocate (CA)
Claim: well, this is what people presume, that somehow, these automatic weapons come up into the sky, and they shoot at will, and they shoot down whatever is on the ground. I mean, there are all sorts of stories and mythologies about drones which, unfortunately have been created. And-- and as I said, this is why this weapon-- the chances of this weapon getting out of hand, getting into the wrong hands and being used indiscriminately in many other parts of the world is-- you know, we should take the example of what the reaction already we are seeing in Pakistan, Yemen and other places.

### Conspiracy Advocate (CA)
Claim: I'll briefly-- rules of engagement are pretty tight in marine combat units. And so, yes, there's going to be blowback. It's a good question. It's a very legitimate question. The drones are being used in Pakistan, northwest province basically, outside which is a very different arena than in the conventional side, on the Afghan side of the border. Bottom line is, though is it's what the rules-- the lack of the rules actually, I believe, in our drone program that is the biggest problem. There is not, for example, a marine general necessarily that technically can command where those drones go because they're operated in a different chain of command. And we don't need to get too technical, and that may be changing. But, yes, Afghans are going to respond to a cluster bomb going off or an RPG being launched in the wrong direction. But I have faith that our forces, if one thing over 12 years have learned, is they've learned quite a bit of restraint. And then the rules of engagement have gotten a lot tighter.

### Moderator
Claim: Here's my bias tonight. We have five guys on the stage, and all I see are guys raising their hands. Are there any women who would like to get their voices into this conversation? Right there. Thank you. Be good, okay. If I could just-- stand up.

### Moderator
Claim: Well, I'll try. Hi. My name is Elisa. And this is directed towards and Admiral Blair and General Schwartz. And we talked a lot about how the drones may be causing a lot of innocent civilians to really have hate towards the American people. So do you think that the number of terrorists who have successfully killed using drones is greater than the number of young people who will be conditioned to hate America from the drone strikes and therefore become terrorists themselves?

### Moderator
Claim: But do you seriously-- I mean, I see where you're getting with the question. They just can't count on that. They can't count--

### Moderator
Claim: Oh, of course not.

### Moderator
Claim: --they wouldn't have a count. But your larger point is-- I mean, I'm just kind of rephrasing, but your larger point is, are they creating more enemies than they're killing? Is that basically what you're--

### Moderator
Claim: Yes. That is, yeah, the basis of my question.

### Moderator
Claim: Okay. So you don't mind if they answer that with the question phrased that way?

### Moderator
Claim: Yes, no, of course.

### Moderator
Claim: I want you to have ownership. Okay.

### Moderator
Claim: That's good.

### Moderator
Claim: Okay, so go ahead. I think it's a great question, I just didn't want to-- I didn't want their dodge to be, "Well, I don't have account of that." I wanted-- okay, go ahead.

### Scientific Advocate (SA)
Claim: That wasn't going to be my dodge.

### Moderator
Claim: Dennis Blair.

### Scientific Advocate (SA)
Claim: It's a judgment. It's a judgment. If there were a wonder weapon that would only kill al- Qaeda, dedicated card carrying members, would touch no one else, could be deployed from this room by pressing this button, I'd be all for it. We'd use it. We'd invent it first, and then we'd use it. It doesn't. We have a set of imperfect tools that we use to try to deal with this group of people who has declared war on us and who is far less discriminate, more ruthless, more killing in their approach than we are.

And you have to make a call as to just how hard you use that weapon because it kills other people and it causes other effects which our opponents have ably said. I think that judgment has to be made to continually reevaluate it as you go, and I'm sure that there have been times in the past in which we have erred on the side of using it too much. I think we learned from those, and as the president has said in his opening statements, or his statements, in recent weeks, we've decided to cut it down so I think it's a judgment, and I think we're making it in the right direction.

### Moderator
Claim: I'm not sure, though, that you answered the question of whether--

### Scientific Advocate (SA)
Claim: I think a different--

### Moderator
Claim: --you think it's really-- whether you think the blow back is so serious-- in other words, are you saying that-- and she's to some degree channeling this side's argument, that it - - the use of the weapon, the way it's being used, it creating such ill will that it's creating enemies, and I'm not sure that you addressed whether you think that it is or not or whether you think it is, but not enough to make it a disqualifier for the weapon.

### Scientific Advocate (SA)
Claim: I think the only overall judgment we can make is that al-Qaeda is far less capable of the sort of attacks that it was in the past than it is now. Drones have been a part of reducing it in that capability and, therefore, overall the balance is in favor of the sort of campaign the United States has conducted.

### Scientific Advocate (SA)
Claim: And I would only amplify by--

### Moderator
Claim: Norton Schwartz.

### Scientific Advocate (SA)
Claim: --if I may, by suggesting that you have a situation where you want desperately to avoid having a larger military presence, which I-- , clearly would have its own negative effect on local population perceptions.

So my counter question would be, "What's the alternative? What is the least intrusive, invasive alternative? That, we have been seeking for some time. And all I can tell you is that every flag-- senior flag officer on the military side that has looked at this problem, has sought that solution.

### Moderator
Claim: That's the question I'd like to put to the other side since you've actually phrased it as a question. If you want to kill al-Qaeda in these hard to reach places today, what is the alternative to the drones? Kael Weston.

### Conspiracy Advocate (CA)
Claim: My view has always been the most important battle going on does not include U.S. Marines versus Taliban. It's inside the mosques, inside the madrasas, it's inside the communities. And actually our best allies are the ones that are most critical of this program. So if we're undercutting--

### Moderator
Claim: Bottom line you are saying not to try to kill them.

### Conspiracy Advocate (CA)
Claim: Well, no, no. I-- yeah, I'm not a person that says, "All drones need to be taken off-- out of the sky." But what I am saying is that we've lost the strategic narratives so that General, I'm all in favor of not sending in the first Marine division anywhere again for the most part. However, I think that we've lost sight of who the best fighters are in these battles. And it's actually not an American anywhere. It's an Afghan. It's a Yemeni. It's a Pakistani. So when you listen to our allies who want us to succeed, who want us to be safe, they are pretty uniform in their indictment of drones, and--

### Scientific Advocate (SA)
Claim: if they don't control their own territory.

### Conspiracy Advocate (CA)
Claim: Well, that's a government to government discussion. I agree with that. As far as the tactic, it's what Ahmed my well spoken and famous colleague here at the table have said, which is that the tactic can't be the strategy. We've enabled the tactic to become a failed strategy and a failed narrative.

### Moderator
Claim: But, Ahmed, it's the-- coming back to the question that your opponents put a minute ago, if the goal of the strategy is to destroy al-Qaeda physically, what alternative is there to drones to reach them in these places where it's very hard to get to?

### Conspiracy Advocate (CA)
Claim: Well, I think there's no doubt that there are obviously ungoverned areas and the Pakistanis have not been active enough in undermining and destroying Al-Qaeda. But I also think that U.S. policy has-- there's been enormous tension between the U.S. and Pakistan over the years, as there has been between Yemen and the U.S. Now, it's not all centered around drones, but it's centered around, frankly, a lack of long-term strategy and vision by both countries. And both are to blame. Now, I think what we need is much greater diplomacy and, you know, diplomatic efforts to strike better relationships. We had a situation where-- as you know--

### Moderator
Claim: But just so, just to get to my point-- and I'll-- then I'll let you continue-- are you saying, therefore, that a campaign at this point, to continue to try to kill Al-Qaeda operatives, planners, et cetera, strategists, by the United States, is ill-founded? They should stop trying to kill them by drones or any other means?

### Conspiracy Advocate (CA)
Claim: No. I think they should continue trying to kill them. They should be urging the Pakistanis to do much more to do this. This is the problem, you know?

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Well, yeah, there's a lot of mythology about what seals and drones can do together. And I think what-- the American people look at joystick warfare and think, "Well, why not have seals and drones fix everything?" But that's also not a strategy.

### Moderator
Claim: Ma'am? A mike is coming down from the aisle for you.

### Moderator
Claim: Hi. My name is Colleen Quinn. This question is for Admiral Blair. Admiral, I was very pleased to see that you are also a member of the Security Leadership Council, securing America's future energy. So, you all here today are talking about, you know, overall strategies for the U.S. And one of the things that particular council talks about is how we can frankly, you know, develop alternative energies to-- so that we can--

### Moderator
Claim: Ma'am, I apologize.

### Moderator
Claim: Not-- oh, sorry.

### Moderator
Claim: I need the topic to be on the motion.

### Moderator
Claim: Oh, okay. Sorry.

### Moderator
Claim: But thanks anyway. You missed my briefing. Right down in front, right by-- but you can chat afterward.

### Scientific Advocate (SA)
Claim: I think it's a great cause. Thank you.

### Conspiracy Advocate (CA)
Claim: That's an easier debate for you to have, that's for sure.

### Moderator
Claim: Could you stand, please? Thanks.

### Moderator
Claim: Yes. Ellie Roth I just want to know, who decides what drones are to be sent out? Is it the CIA that tells the military? That's the mystery. When we hear about drone strikes, we don't understand who's responsible, who's made the decision. Is it policy, is it someone who's mad at someone?

### Moderator
Claim: Okay. I'll let these guys answer your question. Let's go to Admiral Blair-- Dennis Blair.

### Scientific Advocate (SA)
Claim: Right. The decision on what is a target can be struck either by a military or by an intelligence CIA drone is made under criteria that are approved by the White House, that are then promulgated.

And a series of officials, including lawyers, officials in each of those agencies and the chains of command, then apply them to actual names of Al-Qaeda and other combatants. Once they satisfy that criteria, then they are a legitimate target at that point. The question is, can you truly tell-- is that a person that you found and can strike, and is there a relatively small level of collateral damage? That is, innocent people around that person before you make the strike. That's how it's done.

### Moderator
Claim: So, Dennis Blair, your opponent Ahmed Rashid has mentioned-- and I said that I would get back to this whole notion of signature strikes, in which the target is chosen by a pattern of suspicious-looking behavior, maybe going frequently to a house where there are known to be bad guys. And then he's tracked back to his house. You don't know his name. You don't know who he is, but he's targeted because it's an association or some other pattern that I'm unfamiliar with.

And I want to know, do you put that in a different category? Is that morally more challenging an issue, when you don't actually have a name, but you just have a kind of profile?

### Scientific Advocate (SA)
Claim: It is.

### Moderator
Claim: Norton Schwartz.

### Scientific Advocate (SA)
Claim: It certainly is. Now, signature strikes in a declared combat area are different than those that occur outside declared combat areas. And I-- and the criteria are different. But the bottom line is, if in a combat area, if the individual or individuals appear to be hostile, you can engage them in the context of that signature of hostility. On the other hand, activities in non-combat areas-- and this does apply to Pakistan, I would argue-- it is much more problematic to conduct signature strikes there or elsewhere, where it's not a declared combat zone.

### Scientific Advocate (SA)
Claim: Yeah. I can talk about those, because I received the phone calls every--

### Moderator
Claim: Dennis--

### Scientific Advocate (SA)
Claim: --time we conducted a strike. This is up to the middle of 2010. And I think that the administration has been really derelict in not talking about these, because they are based on the self-defense of American and Afghan forces. The signature strikes that were conducted in Pakistan, all of them during my time, and the great majority over all, had to do with armed groups of men who were coming out of known Taliban, TTP areas on road headed towards Afghanistan. And we knew that they were not friendly. They were armed. We know what their arms were. And we knew that they were coming to attack Afghans and Americans and others. And we killed them before they could do that

### Moderator
Claim: I want to let Ahmed Rashid respond to that. But first, I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, debating this motion: The U.S. drone program is fatally flawed. Ahmed Rashid, signature strikes?

### Conspiracy Advocate (CA)
Claim: I just want to answer the question which the lady posed, which I think we should go back to. And I think you're absolutely right. For the admiral to describe the individuals who are involved in this decision making doesn't give us the criteria. I mean, what is the criteria for choosing who's going to live and who's going to die? The fact is the U.S. media itself has portrayed that, the president is sitting there ticking off on a list as to who is going to live and who is going to die, or today, who is going to be drone or not. Now, I mean, we have no idea what the criteria is, how these people are chosen, what is the level of evidence about them being al-Qaeda? Now, I'm not asking for all this to be made public. But I think there must be much-- a much greater degree of satisfaction that people understand, why these targets are being chosen. And that is just not there at all.

### Moderator
Claim: I agree. I agree.

### Conspiracy Advocate (CA)
Claim: Well, could I add, I mean, it became a live issue in the United States only when an American citizen was killed. So all my Afghan and Pakistani friends are like, well, you guys care when it's an American kid named Awlaki that's killed, but not when our cousins and brothers are killed.

### Scientific Advocate (SA)
Claim: Awlaki was a self-declared combatant.

### Conspiracy Advocate (CA)
Claim: The son of-- I mean the 16-year-old. And again, that still hasn't come out. But all I'm saying is that, again, the battle is a battle that involves them more than us. And it's a narrative that I think is really the challenge here. And I think in some ways we agree more than we disagree on who's winning and who's losing that narrative.

### Scientific Advocate (SA)
Claim: So the adverb here is important, fatally.

### Moderator
Claim: I'm going to take another question, right down in front here. Folks, if you're upstairs and raising your hands, I apologize. I-- number one, I can't see you. And we don't have mics up there. But if you are really enthusiastic and come down through the back doors, I'll find you. But if you do that, really make it a good question.

### Moderator
Claim: Hi. My name is John Dagastino. This question is for the "for" side, particularly John. You've made the point several times talking about our allies’, quote, "Indictment" of this policy. I presume by that you mean Pakistan. How do you reconcile that indictment with their cooperation? And consequently, how much of that indictment is actually hypocrisy?

### Conspiracy Advocate (CA)
Claim: Well, yeah, I should have defined ally. I'm talking about the people that I dealt with on the ground. So whether they were in Khost or in Helmund or even in Fallujah, although the drones weren't armed then, I'll let Ahmed take the bigger issue of the Pakistani maybe duplicity. And I'm sure there's a lot of double winks that go on every day of the week over there.

But my concern is the allies that actually are the future leaders of Afghanistan, the university students, the Madrasa students, the tribal elders, the Mullahs, the whole host of people that get killed in these drone strikes when they go wrong. Because I don't think the Taliban hold up a red flag. I know they don't, and say, "I'm Taliban. What happens is there's a bad guy in the family or a bad guy in the village, and we identify maybe he's a bad guy, and we drop a hellfire, and then you turn three villages against us.

It goes to the ratio and the equal sign. I'll come back to it. Yes to the woman I thought who asked a very good question, elaborated on by you, our moderator, is the number of enemies we're making and the number of targets we're making. And I'll defer to you, Ahmed, on the question about his point on as far as the Pakistan government or the Pakistan--

### Moderator
Claim: Yeah, why don't you let Ahmed get to that. Yeah.

### Conspiracy Advocate (CA)
Claim: Can I just say one thing first? And that is that most allies of the U.S. in Europe, are against drones. As far as I know, only the British have openly-- support the U.S. policy of drones. Most of the Europeans, European governments and European parliaments, are against it. And they've been--

### Moderator
Claim: What does it mean, "Against it," that they want it to stop completely?

### Conspiracy Advocate (CA)
Claim: Sorry?

### Moderator
Claim: They want a total cessation of the use of use of drones in that area?

### Conspiracy Advocate (CA)
Claim: Yes. I mean--

### Moderator
Claim: Okay. Just wanted to clarify.

### Conspiracy Advocate (CA)
Claim: They do. Or they want greater transparency, or they want greater information as to,-- but in other words, nobody in the world basically is backing the U.S. use of drones. And I think that's very-- that's a point that is often completely forgotten in-- the American media and--

### Moderator
Claim: Let me ask your opponents, is that-- is that relevant? Dennis Blair? And I'll back to you, Ahmed.

### Scientific Advocate (SA)
Claim: Well, I mean, what's your evidence, Mr. Rashid? No one in the world--

### Moderator
Claim: Well, now we're counting everybody in the world.

### Scientific Advocate (SA)
Claim: --use of drones. I mean can you be a little more specific?

### Conspiracy Advocate (CA)
Claim: Well, you look at the--

### Scientific Advocate (SA)
Claim: Can you give me resolutions by legislatures in other countries? Can you give me--

### Conspiracy Advocate (CA)
Claim: Well, with all due respect, I haven't heard a lot of, "rah, rah, drones." And I've been in the State Department for 12 years. So I'll help my friend out here; that whether NATO raises their arm and says, we approve the drone program, I know General Dunford and his political adviser, Carter Malkasian have their hands full all the time on these issues. But is it a popular thing? I highly doubt that. I don't know any--

### Scientific Advocate (SA)
Claim: And it's not a popular thing in the United States. We don't like killing people, but we only do it when we have to.

### Conspiracy Advocate (CA)
Claim: Well, I'm not sure we only go when we have to. I think it's actually, I think, easier for the American people to think it's joystick warfare and send in seal team 6. And that's also another issue that we could get into.

### Scientific Advocate (SA)
Claim: Well, I would simply-- I would simply say that the drones are handled with the same care, concern, discrimination that the armed forces, the United States and other American agencies handle all other weapons, which they know can kill the innocent as well as the enemy. And drones are used with the same set of procedures. And I think their inherent characteristics allow them to be more on the side of killing those who they intend to kill with fewer others.

### Moderator
Claim: Dennis, but let me follow up on that and ask you this question. It came up a little bit before. Sometimes in certain circumstances, some weapons seem to raise different moral or ethical challenges to their use. Nuclear weapons, classic example. Your opponents have used the word "sinister" about drones, that they're different somehow. You, I think, alluded to the fact that maybe presidents will be tempted to use drones a great deal more because U.S. casualties are lower, that there's always going to be a temptation for a president. What about this notion that there's a different, perhaps sinister quality to the weapon itself, because it's in a different category?

### Scientific Advocate (SA)
Claim: I'll-- I mean, General Schwartz was involved in it much more closely than I was. But I was pretty close to it. There is a novelty factor. Anything that's new and long range and all is-- seems inherently more fascinating, sinister and interesting. We've seen that with new weapons over the generations as they come along.

Certainly, the sort of media discussion centers on drones. I mean, we're not having an Intelligence Squared debate about overall U.S. policy against Al-Qaeda. We're talking about drones. Why? Because it's sexy, and it's new, and it has a lot of

### Moderator
Claim: Yeah, but we would if there were chemical weapons. I mean, I'm not comparing them, but--

### Scientific Advocate (SA)
Claim: But, no, I think the media effect is important in this, John.

### Moderator
Claim: Yep, okay.

### Scientific Advocate (SA)
Claim: I think novelty, media, it tends to give it that overwhelming force that Mr. Rashid has talked about. I think we have to get beyond that to what are the actual facts about what's going on on the battlefield. Are we achieving our objectives? Are we-- are we not? Narrative, shhmarative. You know, it's are you getting to your objectives, which are to be able to defeat the Taliban--

### Scientific Advocate (SA)
Claim: And protect Americans.

### Scientific Advocate (SA)
Claim: And protect Americans, yeah.

### Moderator
Claim: Sir, right down here. Yes. Mic-- mic will come for you.

### Moderator
Claim: My name is Robert Klein. We have to vote. And what I've heard from this side is that the use of drones is indiscriminate without a lot of substantiation in my view.

And from this side I've heard incredible amounts of care and preparation and diligence before drones are launched. Which is the more accurate of the two? Because on the face of it, that would be the basis of our vote.

### Moderator
Claim: Mr. Klein, there's always the undecided category.

But it is their task to persuade you.

### Scientific Advocate (SA)
Claim: It's a question of who's more credible. Seriously, though, I take your point. Based on the available numbers, again, I would go back to that, you can question Long War Journal, you can question the UN studies and-- and so on, the New America Foundation is another organization that monitors this.

But the number-- from 2006 to the present time in Afghanistan, the estimate is that drones have engaged and killed some 2600 al-Qaeda and Taliban combatants. Out-- the same organization estimates 330 civilian casualties. Now, once again, please don't take the-- that my view is that it doesn't matter. It matters a hell of a lot, and I think Kael is-- and Mr. Rashid have made this point. It matters a lot, but you have to keep this in perspective, and the numbers are pretty clear, one to seven, one to five, you know, you can say that that's anecdotal, but it's the best we have. And my point is, is that I know what the kids do.

And I would ask all the parents in here if your youngster as we were talking out in the reception earlier was on the ground, what would you prefer to have in the air, something that passes over in 30 seconds and goes away or something that is overhead constantly and provides surveillance and an ability to engage the enemy that might well keep that soldier, sailor, airman, Marine safe? I know what my answer as a commander is.

### Conspiracy Advocate (CA)
Claim: Well, again--

### Moderator
Claim: Kael Weston.

### Conspiracy Advocate (CA)
Claim: --General, I get that point to an extent. I had lived five out of my seven years in these wars with Marine grunts. Surveillance overhead is a part of war. The issue is when the drones strike, what the net effect is. In Province on the border with Pakistan I can tell you when those one to five, one to seven-- I think numbers to me is not an issue I like to get into because it's that equals sign.

Which is how many family members, tribal members, community members are affected by one loss of life? The IED strikes are where most of our guys are losing their legs. So do the IEDs go up when an operation like that goes wrong, and you've got a cousin in Miranshah, you've got brothers in Miranshah, and you live in Khost? I would argue with all due respect that the odds of getting a Marine or a soldier's legs blown off go up because of this program, not go down.

### Scientific Advocate (SA)
Claim: Okay, that's your view. My view--

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: --is killing bomb makers makes the numbers go down.

### Conspiracy Advocate (CA)
Claim: Fair enough, it's two sides of a--

### Moderator
Claim: In the center, there. And the mike will come down-- up the aisle. It's coming from your left hand side now. If you can state your name, please.

### Moderator
Claim: My name is Peter Burgess I was in Afghanistan just after the Soviets withdrew so, you know, I have a bit of a feeling for the neighborhood. The question is, is the drone program fatally flawed or some words to that effect, and--

### Moderator
Claim: That's exactly it. Peter Burgess-- we used to talk about nation building. We used to talk about not having failed states. Can somebody please explain to me how a drone addresses the issue of nation building and stopping failed states?

I think it's not intended to though, is it or--

### Scientific Advocate (SA)
Claim: It’s intended to kill Taliban so that they don't keep the nation builders from going and doing their job.

### Moderator
Claim: I think you're going to be our last question, and I've been saving you because you have had the most vigorous arm waving of anyone tonight.

### Moderator
Claim: It worked. My question is for the side arguing against the motion, does the fact that the drone program cuts down on American armed forces casualties, does that enable the U.S. to engage in more reckless conflicts around the world?

### Scientific Advocate (SA)
Claim: It-- look, I mean, this is--

### Moderator
Claim: Norton Schwartz.

### Scientific Advocate (SA)
Claim: --this is the fundamental question. Remember, that is not a military call. That is a call for civilian leadership, where we go and what we do. And there is an argument that fewer American casualties might encourage political leadership to be more aggressive or more reckless. There is that potential, but that's what best military advice is all about. Remember, we have a chairman of the Joint Chiefs of Staff who is the president's principal military advisor. And if you've watched Mike Mullen, or Marty Dempsey, or in his day Denny Blair, offer military advice, it's not to encourage political leadership to be reckless.

Ultimately, we salute, but the key thing here is that, that is a legitimate concern, but it is one that the military, the uniforms feel personally.

### Scientific Advocate (SA)
Claim: And I'd say, if you see a political candidate who thinks a few American casualties are okay, but a lot or not, I wouldn't vote for him.

### Moderator
Claim: Ahmed Rashid, when you say that it's already becoming a strategy as opposed to a tactic, do you think that dynamic is already in play, that presidents are authorizing these strikes, in part, because they can, without a cost back home?

### Conspiracy Advocate (CA)
Claim: Yes. I think so-- I think that's very true. And I fear very much that given the turmoil going on now in the Middle East and other parts of the world, the reluctance of the Americans and the Europeans to want to get involved in by putting troops, or peacekeepers, or anything on the ground-- we're going to get more and more of this, that we throw technology at the problem.

We throw drones at the problem. And that, I think, is going to be a very, very dangerous world to live in, frankly.

## Round 3

### Moderator
Claim: And that concludes Round 2 of this Intelligence Squared U.S. Debate, where our motion is: The U.S. Drone Program is Fatally Flawed. And remember, you voted just before the debate. And right after this very brief section-- two-minute closing statements by each debater in turn-- you'll get to vote again. So, onto Round 3. Round 3, closing statements by each debater in turn. We'll do these from our seats, General. Round 3 are closing statements by each debater in turn. They will be two minutes each. And here to summarize his position against the motion, Norton Schwartz. He's former chief of staff of the U.S. Air Force. Ladies and gentlemen, Admiral Norton Schwartz. General Norton Schwartz.

### Scientific Advocate (SA)
Claim: Hi. Denny wishes I was an admiral. some people in the Air Force would’ve, too. I don't know. Let me just say that I think that our partners here in the debate tonight have expressed absolutely legitimate concerns. And while we've jousted a bit, it's been done with respect and an appreciation for their passion and their conviction on this issue. I'd just like to relate a quick vignette. In earlier days, when I was flying airplanes, I flew a gunship-- a C1-- it's a C-130 with guns on it. And there was one occasion when I remember the following call came from the ground. And it was this-- “troops in contact need help now.”When an airman hears-- no matter what service-- Navy, Army, Marine Corps, Air Force-- hears "Troops in contact need help now," there is an immediate response. And it is visceral, but not necessarily as accurate or as coherent as you might like it to be if you were-- if you could have been there for hours prior, and will remain there for hours after, which is the case with the remote aircraft or the drone technology today. I would just conclude by saying that use of drones is neither sport nor a failed tactic. And you must vote against the proposition and the adverb "fatally." Thank you.

### Moderator
Claim: Thank you, Norton Schwartz. Our motion is The U.S. Drone Program is Fatally Flawed. And here to argue-- here to share his closing statement in support of the motion, John Kael Weston. He is former State Department Advisor to Marine units in Iraq and Afghanistan. Ladies and gentlemen, John Kael Weston.

### Conspiracy Advocate (CA)
Claim: Thank you. And I would echo what the general just said. I-- this is raising the level of debate and we should all be grateful for that. I've got two minutes and I'm going to run through these pretty quickly. I opened with a quiz about what words or nouns, adjectives you think they associate with the United States of America after 12 years of constant warfare. I don't have time to ask you what those words are, but occasionally I would hear words like Apple-- they had the Apple phone-- Obama, money. But unfortunately, toward the top of that list was D for drones. It wasn't D for democracy. It actually, to be frank, wasn't the nation-building. It was the CT. It was the counter- terrorist platform. And I think we should think about that.

Do we want that to be kind of at the top of the list of what they think about us after 12 years, billions of dollars, thousands of Americans killed, over 100,000 Iraqis, et cetera, et cetera?

The second point I'm going to now just cite to the question of what happened on May 1st, 2010? I think it was Admiral Blair who referenced this. And I'll add a little detail. It was Faisal Shahzad, who just a few blocks from here tried to blow up the blue 1993 Nissan Pathfinder. In that Pathfinder was three 20-gallon propane tanks, a big green metal gun locker that contained a metal pressure cooker pot, 250 pounds of urea based fertilizer, and eight plastic bags with 120 M88s. The New York City police commissioner, Ray Kelly, said the bomb would have killed many. The police later on said it would have had shrapnel and probably killed mostly tourists but a number of people. What did Faisal Shahzad say? New Yorkers get that. What did-- I used to ride my mountain bike through there, but I didn't go very often--Faisal Shahad was asked by a judge what motivated him to try and blow up that Nissan. Here's what he said, "Well, the drone hits in Afghanistan and Iraq," he said finally, "They don't see children. They don't see anybody. They kill women, children. They kill everybody. It's a war. And in war they kill people." One final point, Boston Marathon bombing, April 15, 2013, I don't have time to read what Dzhokahar Tsarnaev said, but basically he said the same thing, "We Muslims are one body. You hurt one, you hurt us all. The U.S. government is killing our innocents."

### Moderator
Claim: John Kael Weston, you're out of time. Thank you very much. Our motion is "The U.S. drone program is fatally flawed." And here to summarize his position against the motion, Dennis Blair, former director of national intelligence. Ladies and gentlemen, Dennis Blair.

### Scientific Advocate (SA)
Claim: I've listened closely to our debaters on the other side. And there are an awful lot of anecdote and generalization there.

Let me tell a quick story from November 2011, a U.S. patrol that was on the eastern border of Afghanistan, on Pakistan, thought it was being fired on in the night, called for close support fire. A U.S. manned armed helicopter came up, under direction of these ground units fired at the units they thought were threatening them, and ended up killing 24 Pakistani soldiers. Things happen that are bad in war whether you have manned systems or unmanned systems. Things happen that affect U.S.-Pakistani relations whether you have manned systems or unmanned systems. This is the nature of combat and you have to make a balanced judgment about it. I do find it ironic to be on this side of the motion because as Mr. Weston said I was one of the first people who came out in public against some ways in which the drones were being used in Pakistan well over two years ago.

However, I was not against the technology itself. I was against the way it was being used at that time. I think we've adjusted since that time. I think that's the nature of this dynamic campaign against a group that's shown it's wanted to kill us, and has killed us in the past, and wants to kill us in the future. So I believe you have to vote against this motion. That doesn't mean that you like all of the drone program, doesn't mean you think it needs to be adjusted, changed, and the narrative needs to be improved, but I don't think we should take it out of the hands of those who are trying to defend the United States. Thank you.

### Moderator
Claim: Thank you, Dennis Blair. Our motion is "The U.S. drone program is fatally flawed," and here to summarize his position in support of this motion, our final speaker of the evening, Ahmed Rashid, a journalist and author of "Pakistan on the Brink." Ladies and gentlemen, Ahmed Rashid.

### Conspiracy Advocate (CA)
Claim: I would just hope that you would consider the long term implications of what drones mean-- will mean in the future for the United States, the day that your enemies get hold of drones and use drones against Americans. The day that even your allies, that drones become a kind of free for all in this world. After all, the whole crisis that we are facing today over Syria is that the danger of chemical weapons becoming a free for all. Because so many rogue states hold chemical weapons, and if you allow this one to get away then others can follow suit quite easily.

And the other thing I'd really like to mention here is that the use of drones has immensely complicated America's relations with its allies. You look at the situation in three countries where drone bases have been set up secretly, Pakistan, Saudi Arabia, and Yemen.

The U.S. set up drone bases with the help of the local regime, which were invariably dictatorships of one kind or another. They lied to their own people, these governments. They lied and said, "No, no, there's no such thing as U.S. bases here. There're no drone bases here at all. These are-- people are being killed by artillery shells, or by bombing, or something else. And what happened was that the public became more and more anti-regime and anti-American, which led to political crises in certainly two of these three countries. And it could well still lead to a political crisis in Saudi Arabia. So, you have now such a complicated scenario operating, where drones are creating-- I mean, one weapon, one weapon, and the use of this weapon is delegitimizing regimes in the region and also creating immense hatred for the United States.

Now, this is just one aspect of what I see as a future fraught with immense problems related to drones, which we are not even beginning to think about and I--

### Moderator
Claim: Ahmed Rashid, I'm sorry. That-- at that point, particularly, your time is up.

### Conspiracy Advocate (CA)
Claim: Thank you very much.

### Moderator
Claim: And that concludes our closing statements. And now it's time to learn which side you feel argued the best. We're going to have you go to the keypads at your seats again and vote a second time. And I'll remind you that it's the team whose numbers move from the first vote to the second vote most in percentage point terms who will be declared our winner. Push #1 if you agree with this statement as argued by this side: The U.S. Drone Program is Fatally Flawed. Push #2 if you disagree with that statement, you agree with the arguments made by this side. That's #2. And if you're undecided, became undecided or remain undecided, push #3. You can ignore the other keys. And we'll lock it out in about 15 seconds.

And we'll have the results in about 90 seconds. And while we're doing that, one thing I want to do-- I felt that this debate tonight had a-- an emotional undertone to it. These are very, very passionate issues and difficult ones. And yet, the level of the debate was remarkably civil and informed and respectable, so I want congratulate all of our debaters-- for bringing that. And I also-- I'd also like to thank everybody who got up to ask a question. They were all good questions tonight, so thank you for that. And nobody debated the debaters, and that was even better. So thank you to all of you-- all of-- I want to point out that tonight, the president is giving a speech in 32 minutes. He's laying out the case for military action in Syria following this suggestion put forward by the Russians, to have international monitors go in and lock down the chemical weapons.

It's only a month ago, actually, that Intelligence Squared was in Aspen. And we debated the following motion: the U.S. has no dog in the fight in Syria. So in light of that speech, I thought you would like to hear what the results of that debate were. Again, the motion was the U.S. has no dog in the fight in Syria. At the end of the debate, 61% of the live audience in Aspen was in support of that motion. And that was a gain for them of 21 percentage points. 33 percent were against. So, they only picked up three percentage points. So, that was a clear win for the side that was voting to keep America out of this fight. As it happens, one of those winning debaters is with us tonight-- Richard Falkenrath. I just want to ask you to take a little bow. He was dying to ask a question tonight, but you're a stage guy, not an audience guy. I'd like to also just ask-- remind you about Tweeting about the debate.

Our Twitter handle is @IQ2US. We're delighted if you Tweet afterwards your reaction to how it was handled and the results of the vote. The hashtag is #drones. Our next debate is on October 16th here. The motion is: Break Up the Big Banks. Supporting the motion-- supporting the break-up-- Richard Fisher. He's president and CEO of the Federal Reserve Bank of Dallas. And his partner is Simon Johnson. He's a professor at MIT Sloan School of Management and former chief economist at the International Monetary Fund. Opposing them-- opposing the bank break-up-- Douglas Elliott. He is a fellow at the Brookings Institution and a former investment banker-- and Paul Saltzman, who is president of the Clearing House Association, which is America's oldest banking association. Other topics coming up this fall include the global job markets, the second amendment, and the case for going vegan. Tickets are available at our website for that one-- www.IQ2US.org.

On Friday, October 18th, we'll be in California debating this motion, For a Better Future, Live in a Red State. Watch the-- you can watch that live streamed. It's going to be noon on the East Coast and 9:00 a.m. on the West Coast. Of course, as we've said before, our live stream is on FORA.tv, but you can also hear our debates, including this one, on NPR stations around the country and on WNYC. And our website has information updated on all of these items.

So we have the final vote results. Remember, the team whose numbers have changed the most in percentage point terms before the debate and after the debate will be declared our winner. The motion is this, "The U.S. drone program is fatally flawed." The vote went this way before the motion, 23 percent agreed that the program is flawed, 34 percent were against, 43 percent were undecided. Those are the first results. Remember, now, this change in votes.

The second vote, "The U.S. drone program is fatally flawed. The team arguing for the motion, their second vote was 23 percent. They gained zero. That is the number to beat. The team arguing against the motion, their first vote was 34 percent. Their second vote was 64 percent. That's a gain of 30 percentage points. The motion "The U.S. drone program is fatally flawed" has been defeated. Our congratulations to that team. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
