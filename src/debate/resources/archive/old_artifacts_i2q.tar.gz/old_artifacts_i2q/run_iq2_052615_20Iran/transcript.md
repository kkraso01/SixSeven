# Debate Transcript

Topic: Obama's Iran Deal Is Good For America
Motion: Obama's Iran Deal Is Good For America

Debate ID: 052615%20Iran


## Round 1

### Moderator
Claim: And we always begin them by having Bob Rosenkranz come to the stage and talk about our thinking in putting this debate on at this time and what’s at stake. So please, one of these moments, a round of applause for Mr. Bob Rosenkranz. Hi, Bob.

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hi, Bob. So, you know, we’re doing one of these strategy debates. It’s one of those, probably for a lot of people in the audience and myself, it’s one of those learning debates where we’re going to learn from both sides. But you, we were talking before-- earlier in your career, you worked for the Rand Corporation out in Santa Monica thinking strategy. During the period of the Cold War-- and just what-- you know, in terms of helping us understand what we mean when we say “nuclear strategy.”

### Moderator
Claim: Well, I was at Rand in the ‘60s when it was the epicenter of research and thought about nuclear strategy.

And, you know, it’s been 70 years since a nuclear bomb was used in war. But in spite of that passage of time, it still has a great deal of relevance as a strategic construct. And in Rand’s view then and, frankly, in my view now, the biggest relevance of nuclear weapons is really as a deterrent because countries that possess nuclear weapons can-- can pursue a more aggressive projection of power and a more aggressive foreign policy than they might be able to do otherwise.

### Moderator
Claim: So if you look at a case like Iran, and very often Iran’s leaders are disparaged as crazy and nuts, but for them to want to deter, have a weapon to deter doesn’t seem entirely irrational.

### Moderator
Claim: No. I would argue that it’s not irrational at all. And if you do a thought experiment, imagine if Saddam Hussein had nuclear weapons when he went into Kuwait or prior to 9/11.

He would probably still be in office today. So having nuclear weapons does have a strategic value even if they are extraordinarily unlikely to ever be used.

### Moderator
Claim: So do we think, then, Iran, if it gets a weapon, would be not so likely to use it?

### Moderator
Claim: Well, I think the strategic issue is not so much their likelihood to use it because I suspect that they would be deterred by the specter of a counter attack from whomever they used it against. But the more relevant thing is that having nuclear weapons would embolden them to pursue even more aggressively the clear policy that they have of being a revolutionary power in a pretty dangerous neighborhood.

I mean, they’re using Hezbollah and Hamas to project power. They’ve, in effect, destabilized Iraq. They are a revolutionary power that seeks regional dominance.

### Moderator
Claim: In terms of their apparently moving towards making this deal, they get in return now the lifting of sanctions, money. Does that have-- is that an asset that, for them, could have as much value as the deterrent power?

### Moderator
Claim: Well, absolutely. And I think the point is that while they might be emboldened by having nuclear weapons, they would also have a much greater ability to project power in the region if the sanctions were lifted because their economy would be much stronger, they’d have much more revenues from oil. They’d have much more investment in their society. The people ruling it would probably be in a stronger domestic position.

So, I think that as we listen to tonight’s debate, at least I’m going to be listening not just about whether or not they get nuclear weapons, but whether or not they are in a stronger or weaker position as a result of this deal to in effect act as a regional hegemon and adversely to the U.S. interests.

### Moderator
Claim: So looking at the whole range of the deal, it’s a very thorny issue. And we have four great debaters to take it on for us, so let’s thank Bob Rosenkranz and bring our debaters out to the stage.

### Moderator
Claim: Thank you.

### Moderator
Claim: --and this again is one of those times to formally begin the evening.

Once more, if you could give a round of applause for Bob Rosenkranz Buying time, that is what President Obama’s deal with Iran on nuclear weapons does in the first instance. In a sense it’s getting Iran to lay aside its activities related to its ambitions to build a nuclear weapon for a set number of years and then the deal ends. It’s kind of like having a kid put his firecrackers up on the top shelf, and you can take them down a few years later maybe with the hope that at that point the kid isn’t going to want to blow things up anymore. And maybe the hope is that in time Iran will evolve in such a way that it won’t be a threat to its region. That may be what buying time can deliver. Nobody loves this deal, but the White House argues that it is better than nothing and better than all of the alternatives. But is it?

Well, that sounds like the makings of a debate. So let’s have it, “Yes,” or, “No,” to this statement, “Obama’s Iran Deal is Good for America,” a debate from Intelligence Squared U.S. I’m John Donvan. We have four superbly qualified debaters, all firecrackers, on our stage here at the Kaufman Center in New York to argue for and against this motion, “Obama’s Iran Deal is Good for America.” As always, our debate goes in three rounds, and then our live audience here in New York votes to choose the winner, and only one side wins. Our motion again, “Obama’s Iran Deal is Good for America.” Let’s welcome the team arguing for the motion. Please, ladies and gentlemen, welcome Philip Gordon. And, Philip, you are a senior fellow at the Council on Foreign Relations, but until very, very recently you were at the White House working on these issues. You were a coordinator for the Middle East, North Africa, the Gulf Region, a senior advisor to the president.

You have been pretty busy and pretty intimately involved with these negotiations the-- whose conclusions we’ll be talking about tonight. We want to know, you know, since you were so close to it, is there anything that you can tell us about being inside the process that would shed some new light on these negotiations?

### Conspiracy Advocate (CA)
Claim: New light, John, I can. After many, many rounds, more than I can remember, of difficult contentious negotiations, I can share with you the insight that people that haven’t slept for five or six days at a stretch get very irritable-- of all nationalities.

### Moderator
Claim: Have you slept before coming here tonight?

### Conspiracy Advocate (CA)
Claim: Just before coming here.

### Moderator
Claim: You just caught up? All right, ladies and gentlemen, Philip.

### Conspiracy Advocate (CA)
Claim: Hopefully I’m not irritable.

### Moderator
Claim: Hope so, too. Philip Gordon. And, Philip, can you tell us who your partner is?

### Conspiracy Advocate (CA)
Claim: Yeah, my partner is one of America’s finest and most experienced diplomats, Ambassador Tom Pickering.

### Moderator
Claim: Ladies and gentlemen, Tom Pickering. Tom, you are also arguing for the motion that, “Obama’s Iran Deal is Good for America.”You’re vice chairman of Hills & Company, and you have had, as Philip just said, a long career, five decades as a U.S. diplomat. You were undersecretary of state for political affairs and ambassador to the U.N. You were ambassador to Moscow, Israel, Nigeria. For a number of years, though, in the absence of any formal U.S.-Iran relations, you were a participant in what is called, “Track II Diplomacy.” For those who are not familiar with the term, “Track II,” can you explain briefly what that is?

### Conspiracy Advocate (CA)
Claim: Short answer is, one more than Track I. The long answer: it’s non-officials engaged in diplomacy to see if they can find a way to crack the nut.

### Moderator
Claim: From the inside, we’ll be hearing some of that. Ladies and gentlemen, let’s welcome please Tom Pickering-- and the side arguing for the motion, and that motion is, “Obama’s Iran Deal is Good For America.” And we have two debaters arguing against it. Please, let’s welcome Mike Doran. welcome back your second time debating with us. You are a senior fellow at the Hudson Institute, a former deputy assistant secretary of defense, a former senior director in the National Security Council, also an insider in this process. You helped devise and coordinate a lot of U.S. strategies on Middle East issues, including efforts to contain Iran. You recently Tweeted this, “In--” 144 characters-- “In Obama-land, the kiss of the nuclear deal will turn the Iranian frog into a beautiful prince,” but don’t you have to kiss a lot of frogs before you find a prince?

### Scientific Advocate (SA)
Claim: They’re kissing a lot of frogs. It’s true.

### Moderator
Claim: They’re kissing a lot of frogs?

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: And you’re against that?

### Scientific Advocate (SA)
Claim: I’m against that, yes.

### Moderator
Claim: Okay. We’re going to hear why. Ladies and gentlemen, Mike Doran. And, Mike, tell us who your partner is.

### Scientific Advocate (SA)
Claim: My partner is actually a foreigner. He’s a Canadian. He’s my favorite Canadian, but he’s also the executive director of the Foundation for Defense of Democracies.

He’s Martin Dubowitz, and he’s one of the leading experts on everything financial to do with Iran: sanctions--

### Moderator
Claim: --everything I was going to say. So, let me just cut through the same place-- and Mark Dubowitz. Known to his friends as “Dubo.” Mark Dubowitz is arguing against the motion “Obama’s Iran Deal is Good for America.” And Mark, as just pointed out, you’re with the Foundation for Defense of Democracies. Your think tank has been described as the political brain trust on Iran sanctions so much so that a few years back, a white paper that you co-wrote was adopted by the Obama Administration, largely without them changing it very much. But they don’t seem to be listening to you now. Are they off your mailing list?

### Scientific Advocate (SA)
Claim: That is true. That is true. We keep sending them ideas, and the White House keeps saying, you know, “Iran sanctions are just so yesterday.”

### Moderator
Claim: Here tonight is your chance-- because I’m sure they’re listening-- to change their minds. Ladies and gentlemen, the team arguing against the motion. Now, this is a debate. It’s a contest of ideas, well-presented. And the team whose numbers change the most between two votes of our live audience here in New York will be declared our winner. That is to say, we have you vote before the debate, and once again, after the debate, on these motions. And the team whose numbers have changed the most between the two votes will be declared our winner. So, let’s have you register your preliminary vote. If you go to the keypads at your seat-- again, the motion is “Obama’s Iran Deal is Good for America.” If you agree with this motion, push number one. If you disagree, push number two. And if you’re undecided, push number three. The other keys are not live; you can ignore them. And if you make a mistake, just correct yourself. The system will lock in your last vote. And to remind you one more time, we will reveal the results of this vote you’re doing now at the end of the debate, at the same time as our reveal of the second vote.

And the team whose numbers have changed the most in percentage point terms will be declared the winner.

Okay, it looks everybody’s-- it looks like everybody’s good. Let’s move on to Round 1. Round 1 are opening statements by each debater in turn. They will be seven minutes each. Our motion is “Obama’s Iran Deal is Good for America.” And here to go up first for the motion to the lectern, Phil Gordon. He is a Senior Fellow at the Council on Foreign Relations. He was special assistant to the president and White House Coordinator for the Middle East, North Africa, and the Gulf Region. Ladies and gentlemen, Philip Gordon.

### Conspiracy Advocate (CA)
Claim: All right. Thanks very much, everybody. Thanks for coming. I’m really pleased to be here and honored to be joined on my side of the debate by Tom Pickering. Also glad to be up here with Mark and Mike. They play an important role. We disagree on this subject, but they play an important role in what is a really important debate. Let me get straight to the point. Tom and I are going to argue that the Iran deal of President Obama is good for America for three basic reasons.

One, it’s important for the United States to stop Iran from acquiring a nuclear weapon. Two, this deal effectively does that, and it does it while avoiding a costly and unpredictable conflict. And three, the alternatives to this deal-- the alternatives to this deal are far worse. And I’m going to ask you to pay particular attention to this third point, because I suspect our opponents in this debate will spend a considerable amount of time telling you why this agreement is imperfect and why it should also have X, Y, and Z.

What I don’t think you’ll hear them do is present a credible and realistic alternative to it. And I remind you as we start, that the proposition on the table is not, “Is this a perfect deal that you would write alone if you didn’t have to negotiate it with somebody else?” but “Is it good for America?” And I think if that’s the question, it clearly is. In fact, I don’t even think it’s much of a close call.

The first point, I’ll be very brief on. The United States has an interest in stopping Iran from getting a nuclear weapon because an Iran with a nuclear weapon could threaten the region and some of our close allies, including Israel. It could be a precedent and a stimulant for other countries in the region to develop nuclear weapons. And it would be harder to deter and contain it in terms of its foreign policy in the region. I just want that to be clear. I don’t think our opponents disagree with that, so I would just want to stipulate it upfront. That doesn’t require a debate. It is important for the United States. What we disagree on is whether this deal effectively does that. And Tom and I will assert that it does, and let me tell you why and why it’s good for America. The framework agreement that the Obama Administration negotiated cuts of all of the possible paths for Iran to get a nuclear weapon.

Now, in this brief opening statement, this is not the place for a very detailed analysis of every provision in the agreement.

I suspect most of you have already read it and are familiar with it. What I would do is underscore some of what this agreement does. And I would ask you to think about it in these terms: Imagine the world before us with the agreement, if we get it finalized and we implement it, and imagine the world without the agreement. Think about those two alternatives-- alternative worlds for the future and ask yourself which one you want to live in, which one is good for America.

I said the deal cuts off all of the possible paths to an Iranian nuclear weapon. There are three basic paths: Enriching uranium to be able to use it for a bomb, using plutonium to create a nuclear weapon, or a covert path. And this agreement stops all of those tracks. On enrichment, what does the agreement do? With the agreement, Iran would have to take its current stockpile of low enriched uranium, which is around 10,000 kilograms or 12 tons, enough for several nuclear weapons today, as we discussed this, and get rid of 98 percent of it, keep only 300 kilograms.

Without it, they could have whatever stockpile they like. With this agreement, they would have to get rid of two-thirds of their installed centrifuges. Today they have 20,000 installed centrifuges. With this agreement, it would have to go down to 6,000, of which only 5,000 could be operating for 10 years. And they would all have to be the oldest technology, the least efficient. Without it, they can operate whatever centrifuges they like. With the agreement, they would have to stop all of their enrichment at an underground facility called Fordow and they could only keep nonoperating centrifuges there. Without the agreement, they can use Fordow for whatever they like. With the agreement, Iran couldn’t use its more advanced centrifuges to do enrichment for 10 years and would have long-term limits on research and development.

Without the agreement, they can do whatever R&D they want and develop more advanced centrifuges very quickly. With this agreement, Iran could not enrich uranium to 20 percent, the level, if you recall, when the Israeli prime minister was here in New York a couple of years ago, he identified as the most concerning thing. So if you enrich uranium to 20 percent, it’s a short step away from 90 percent and the ability to use it for a bomb. The interim agreement that we negotiated got rid of that 20 percent stockpile, this agreement requires Iran to not enrich at all to 20 percent, closes off all the potential paths to highly enriched uranium for a bomb. It also closes off the plutonium path. With the agreement, Iran has to get rid of its current heavy water reactor at a place called Arak and replace it with one that would not produce any weapons-grade plutonium at all. And it couldn’t do any reprocessing. It has to ship the core out and can’t use this site. Without the agreement, they can finish production of that heavy water reactor and start producing weapons-grade plutonium.

Finally, and maybe most importantly, this blocks the covert path. With this agreement in place, Iran would be bound to accept unprecedented intrusive inspections, forever, with a mechanism for resolving disputes. We would have access to their entire fuel cycle from the mines and mills of uranium to production sites for centrifuges all the way to the enrichment sites themselves where there would be cameras and inspectors on a regular basis. That’s what we have if we get this agreement, if we conclude this agreement. Without this agreement, we don’t have any of that, and we have no idea what Iran is up to. The bottom line of all that, when you put it all together, is Iran’s breakout timeline, the amount of time it would take them to get enough material for a bomb, goes from around two months, what it is today, to over a year, which our military specialists are confident give us enough time to react if they seek to violate it.

I could go on, but you get the bottom line point. When you compare these two worlds that we could live in with the agreement or without the agreement, clearly, this agreement is good for the United States. Indeed, I think it’s not even a close call. When Tom takes the floor-- I’ve made the positive case for this agreement. When Tom takes the floor, he’ll be able to talk about some of the reasons why not only is this a good agreement, but all of the potential alternatives to it are much, much worse. Thank you very much.

### Moderator
Claim: Thank you, Philip Gordon.

And our motion is Obama’s Iran deal is good for America. And here to debate against this motion, Mike Doran. He is a senior fellow at the Hudson Institute and former national Security Council senior director for the Near East and North Africa. Ladies and gentlemen, Mike Doran.

### Scientific Advocate (SA)
Claim: Thank you. Thank you, John, and thanks to all of you. It’s fantastic to be here. There’s nothing more wonderful than Central Park in the springtime except the IQ2 debate.

Now, as you know, we’re going to argue-- Mark and I are going to argue against. We think this is a very bad deal. Let me just get right to the point. To me, this is like-- say you’re a legitimate businessman, and a Mafioso comes and you’re in a little bit of-- you’re in a little bit of trouble financially, and he offers you a loan, and you take it, and you tell yourself that this is a temporary thing and that as the Mafioso becomes your partner, over time, he’s going to moderate, he’s going to understand what it’s like to get honest profits, and he’s going to change, and he’s going to start abiding by the law. This agreement would be fantastic if we were making this agreement with Denmark, but we’re not. We’re making it with Iran. We know Iran well. We’ve known them for 35 years. We know what they’re like. The Iran that we have today is the Iran that we had 10 years ago. It’s the Iran that we had 20 years ago. It’s the Iran that we had 35 years ago.

And that’s-- that is actually the single most important question that I want to put to you tonight is, why do we think that this regime is going to abide by this agreement? That’s the-- that is the single most important-- the single most important question, and the administration never, ever-- never ever talks about it.

Now, there are two stories out there that are being told. One is the story that the Obama administration is telling, and the other story is the one that our allies in the Middle East are telling. The story the Obama administration is telling us goes something like this: Back in-- back in April of 2013, there was an election in Iran which brought to power this guy Rouhani, who is a reformer. And Rouhani wanted to change relations with the West. He wanted to change all of this enmity and conflict between Iran and the West. And so he started this negotiation with the Americans, and he made some very important concessions to the Americans, concessions that they had never made, along the lines of the ones that Phil was talking about, basically the essence was a willingness to constrain their nuclear-- their nuclear program.

And that then has led to this process that we have here before us today. That’s not the story that our allies are telling. They’re saying that this process is not the result of a strategic change in Iran. It’s the result of a strategic change in Washington. The United States-- the United States started this process with major concessions. It ripped up six Security Council resolutions that called for zero reprocessing and zero enrichment. It gave Iran, in the first step, as part of the interim agreement, it gave it the right to enrich, and it said also that the restrictions on its program would be temporary, right? So the negotiation after that-- after the initial interim agreement and the negotiations were over how long would that period of temporary restriction be? And under what-- how big would the restrictions on the-- on the program be?

And what would Iran get in return? Now, just for signing up to the interim agreement, we started paying Iran $700 million a month. We’re paying them to negotiate with us. We’re going to-- when they sign the deal, we’re going to give them $50 billion right up front and shortly thereafter and additional $70 to $90 billion. Now, when you ask John Kerry, what’s the evidence that there’s been a strategic change on the part of the Iranian regime? He says, “Well, look, they signed the interim agreement, and they have negotiated for over a year now with us, and they have abided by the terms of the interim agreement during this period of negotiation.” We paid them to do that. We paid them to do that, and we have dangled out a big prize at the end of this signing bonus and the relief from-- and the relief from all sanctions. So, of course, they’re going to be-- they’re going to play nice at the negotiating table.

What other evidence do we have other than the fact that they have allowed us to pay them to negotiate with us, that they have made a strategic shift? No evidence whatsoever. They still are the-- they still spout the same anti-Semitic rhetoric, they still call for the destruction of Israel, they still destabilize their neighbors. They still have four Americans who are hostage there. They have a Marine, they have a cleric, they have a newspaper reporter, and they have a former FBI agent. They didn’t even have the-- they didn’t have-- they didn’t even have the grace and the good manners to release the hostages during this-- during this negotiation.

Now, Mark and I are going to divide our duties here. Mark is going to explain to you why all of those characteristics of the deal that Phil went through are basically a fiction, why it’s a fantasy to think that any of this-- that the Iranians will abide by any of these-- by any of these terms that Phil mentioned. I am just going to make a couple of statements about the broader problem of the deal in the region.

Mark’s going to talk about the nuclear breakout. I’m going to talk about the regional breakout. We are turning-- with this deal, we are turning Iran into the regional hegemon in the Middle East, all right? We have turned a blind eye to the expansion of Iranian power in Iraq, in Syria, in Yemen, and elsewhere across the region. And when we hand them $50 billion a few months from now, if, in fact, we do, we’re going to see an expansion of those-- an expansion of those activities. That’s one problem. Another problem is we have set off with this deal a regional nuclear arms race. The Saudis have said openly, explicitly, that they are going to match the Iranians capability for capability. They’re not going to wait for this deal to end before they start developing their own capability, and they have made that explicit. There’s no way to deny, absolutely no way to deny, that there is not a regional nuclear arms race underway right now.

The other thing is this deal does not make the United States any safer. One of the things that has been left off the table, not part of the negotiations, is the illegal ballistic missiles program of the Iranians. So before long we’re going to have an Iran-- a nuclear Iran with a ballistic missile capability capable of hitting the United States.

A good deal, a good deal-- and this is what we need to define-- a good deal is one that stops Iran from getting a nuclear weapon, A; B, makes our allies in the region feel safer and stabilizes the region; and, three, makes the United States safer. This deal does not meet that basic criteria. Thank you.

### Moderator
Claim: Thank you. Michael Doran. And a reminder of what’s going on, we are halfway through the opening round of this Intelligence Squared U.S. Debate. I’m John Donvan.

We have four debaters, two teams of two, arguing for and against this motion, “Obama’s Iran Deal is Good for America.” You have heard the first two opening statements, and now on to the third.

I’d like to welcome to the lectern Tom Pickering. He is vice chairman of Hills & Company. He has served as undersecretary of state for political affairs and as ambassador to the U.N. and several countries, including Russia, Israel, and Jordan. Ladies and gentlemen, Tom Pickering.

### Conspiracy Advocate (CA)
Claim: Thank you, John, and thank you for your warm welcome. It’s a pleasure to be here with Phil and also with Mike and Mark. I have much I think to say tonight in a very short period of time, and I will do what I can to compress it. Not too long ago when he was still alive, Daniel Patrick Moynihan said famously that, “You’re each entitled to your own opinion but not your own set of facts.” Tonight from Mr. Doran we’ve heard an extremely interesting, unusual, and strange set of facts.

So let me just cover a few of those that I think will be helpful to your understanding of the arrangements that we have to deal with.

First and foremost is the notion in his part that somehow $50 billion will pass on the moment of signature. The truth is, of course, that until Iran complies with four major requirements of the deal-- that they put their centrifuges aside; that they change their stockpile from 10,000 kilograms to 300 kilograms; that they, in fact, dismantle the central piece of the reactor that can make plutonium; and that they agree on that the past efforts that they made in a nuclear direction, in a nuclear weapons direction, are fully explained to and satisfactorily explained to the International Atomic Energy Agency-- they get nothing out of this deal.

No sanctions relief until those particular steps take place, no money passes hands to Iran.

Secondly, the notion that Iran is somehow going to enjoy, when it does get this money, the opportunity to play havoc in the Middle East is both strange and unusual. Certainly we watch carefully what Iran does. And none of us have undertaken the notion that the Iranians are angels, that the whole agreement is indeed put together with very strong inspection mechanisms well beyond what you have ever seen before in any country around the world in order to prevent the kind of cheating or indeed the kind of misuse of the agreement for narrow political advantage.

Were the Iranians, in fact, going to misuse this money, they would have far done it well before any receipts from sanctions relief, their priorities for the things that they’re doing in the region are high enough, I think, for them to continue to do that. It is important, too, to remember this is a nuclear agreement, not a ballistic missile agreement. Both sides have agreed on the importance of the nuclear agreement as a matter of priority. Obviously, a missile-- ballistic missile without a nuclear warhead is not the kind of threat that has been portrayed to you here. And there are plenty of opportunities in the next set of agreements, if this one is successfully concluded, to move on to that particular effort.

Now, let me turn, if I can, to the key questions, and they’re important to all of us here. You’ve already understood that both sides share a deep sense of the necessity to stop any Iranian nuclear weapon. That’s stipulated and agreed.

It’s important, however, to understand that the second question-- is this a good deal for America-- is one that we would certainly answer in the positive for a whole set of reasons that Phil set out for you. And the third question is, what are the alternatives to this deal? Well, the alternatives, quite starkly and quite frankly, are two: no deal at all, or an attempt to use sanctions to see if, in fact, we can achieve a better deal. You heard from Mr. Doran that he would like to have zero enrichment. I would like to have zero enrichment, too. I’d like to be a billionaire. I’d like to believe in the Tooth Fairy. But for 14 years, previous administrations attempted to negotiate for zero enrichment, and got nowhere.

And the value of zero enrichment, in my view, is not significant compared to the value of the arrangement that we now have on the table, with all of its inspection mechanisms, and with all of its limitations on Iran, and that’s extremely important to keep in mind.

In addition to that, what would happen if we walked away from an agreement? How and in what way would that affect the situation? It would affect it very badly. We would have turned down what our allies joined us in negotiating. The notion that we could achieve effective additional sanctions without friends, allies, and indeed, without the participation of the world community, is well beyond reality. It’s not there and it’s not The third question is, what would happen in the event we had no agreement. Iran, of course, could move freely to a nuclear weapon. They would have two to three months to breakout time. They would, if they-- they’re so inclined, use that opportunity, as we have a 10-year agreement with a 15-year limitation on the production of more than 300 kilograms of low-enriched uranium to hold them in place, and I think that’s important.

Finally, I think it’s significant that you understand that the alternatives to an agreement may well involve the necessity to use force under conditions where we would be highly isolated, having turned down the kind of agreement we participated centrally in negotiating-- a good agreement. If we were to use force, it would mean, I think, from the best judgment that I can get of military officials, a three to five-year cessation in the Iranian agreement before they could move back to where they are now. And a situation under which we would have to bomb pretty continuously to keep the Iranians under that kind of stricture and under that kind of pressure. To me, there is no alternative. This agreement is a good one. I hope that you will consider that carefully. And when the time comes to push your little button, push the button in the right order for the right set of arrangements that President Obama has put before you. Thank you very much.

### Moderator
Claim: Thank you, Tom Pickering. The motion is Obama’s Iran Deal Is Good for America. And here to argue against the motion, Mark Dubowitz. He is executive director of the Foundation for Defense of Democracies, where he also heads its Center on Sanctions and Illicit Finance. Ladies and gentlemen, Mark Dubowitz.

### Scientific Advocate (SA)
Claim: Thank you. Great. Well, thank you very much, John, Phil, Tom, Mike. It’s really a pleasure for this Canadian, want-to-be-American, to be in such distinguished company. I’m very humbled to be here. I’m going to discuss the emerging deal’s seven deadly flaws. I support a good deal, but this is not a good deal. I’m also going to suggest to you that this deal will make war more likely, not less likely.

And I’m going to actually take Phil up on his challenge, and I’m going to sketch out what a better deal looks like.

The seven deadly flaws: First of all, President Obama and his administration only about 18 months ago committed to, quote, unquote, “Dismantle substantial portions” or “a lot” of Iran’s nuclear program. This deal will leave Iran’s nuclear infrastructure virtually intact. And Iran will be a turn of the screw away from developing a nuclear weapon, only a year’s breakout from that weapon. And that year breakout will only last for 10 years. Thereafter, the breakout time will diminish significantly, and by year 15, Iran will have zero breakout, that’s undetectable breakout. Number two, the administration gave up on long-standing U.S. policy and multiple UN Security Council resolutions, and they gave Iran domestic enrichment which is the key element it needs to develop a nuclear weapon. Now, that was fine, except this most valuable concession wasn’t given up at the end of the negotiation in exchange for other valuable concessions.

No, this was given at the beginning of the negotiation, before Iran had really done anything significant. And now we’re in a situation where Iran is going to have significant enrichment capacity. The administration started off by offering 500 centrifuges. Now Iran’s going to have 6,000 centrifuges. That’s a 1,200 percent increase in the course of these negotiations. Well, here’s a fun fact for you: 6,000 centrifuges, woefully inadequate if you want peaceful nuclear energy. But it’s exactly what you need if you want to weaponize uranium. Number three, we’ve heard about missiles quite extensively from the folks over here. Let me just talk about an ICBM, an-- intercontinental ballistic missile is not for putting monkeys into space. It is for delivering a warhead to New York City. And the Iranians said that this was non-negotiable. The administration said, “Fine. We’ll take it off the table.” Number four, the Fordow enrichment facility. This is an enrichment facility that is buried under a mountain on a Revolutionary Guard military base. The administration promised to dismantle it, then to shutter it.

And now it’s going to be left open for 15 years to develop medical isotopes. It’ll be the most heavily fortified, heavily guarded medical isotope facility in the Milky Way. And the problem is, in 15 years’ time, the Iranians can reconvert it to do advanced centrifuge powered enrichment in a heavily guarded, underground bunker underneath a mountain. Number five, and this is the serious issue with this deal. It’s the poison pill. Many of the restrictions on this deal are going to start sunsetting, in other words, disappearing, after year 10. And by year 15, most of these restrictions are going to go away. Iran is going to have an industrial sized military program, with unlimited centrifuge capacity, zero breakout, multiple heavy water reactors, and the ability to actually develop a program that is widely dispersed and very, very difficult to verify. This deal would have converted this Iranian regime, this regime, from a nuclear pariah into a nuclear partner.

Let me talk about verification and inspection because I believe our opponents are going to bet their debate and bet the security of the United States of America on verification and inspection. This is the idea that we will have unprecedented inspections. Well, the problem with unprecedented inspections is that Ali Khamenei, Iran’s Supreme Leader, just last week said, “You are not getting into my military bases, into my Revolutionary Guard bases.” Revolutionary Guard commander said anybody who tries is going to be met with hot lead. I looked up “hot lead” in the dictionary. It means a bullet. Now, that’s a serious problem because this is a bet on verification and detection. And let’s talk about the U.S. track record in detecting and stopping countries from going nuclear. We missed the Soviet Union, China, India, Pakistan, Israel, North Korea. We underestimated Saddam’s program in 1990. Then we overestimated his program in 2003 and went to war to stop a nonexistent WMD program. We have a lousy record of detecting when countries go nuclear.

And this is going to be a massive program on a territory more than twice the size of Texas. That is what the IAEA will have to verify, particularly when this is an industrial sized program. Number seven, and finally, the IAEA doesn’t enforce. They verify, they monitor. The United States of America enforces. Now the only way we’re going to enforce this deal peacefully is through economic coercion, what is known as snapback sanctions. Here’s the problem with snapback sanctions. They don’t snap back very well. Iran will have a powerful economy in 10 to 15 years. They’re going to get hundreds of billions of dollars of sanctions relief. They’re going to be increasingly immunized against future economic pressure. We’re going to end up in snapback disputes with the Russians and the Chinese at the Security Council. In fact, we’re going to end up in snapback disputes with the Europeans when we try snapback sanctions against our French and British and German friends. We will hit a wall of intransigence at the Security Council, and we will hit a wall of human greed in the marketplace.

And the problem is as we give up our peaceful enforcement mechanism in order to enforce the deal, this is going to make war more likely, not less likely. Iran will be able to creep out, or inch out, or sneak out, or they’ll wait patiently until many of these restrictions disappear. And if we are lucky enough to detect an Iranian sneak-out or breakout, war will be our only option. And when that war comes, Iran will be much stronger, and the consequences will be much worse.

Now, what about a better deal? Well, let me spell out a better deal in seven quick points. Number one, no sunset provision based on arbitrary time period. Iran should have to be certified by the IAEA as having a peaceful nuclear program without any clandestine nuclear facilities. Number two, no long range ballistic missiles capable of carrying a warhead. Number three, shut down the Fordow facility. There’s only one purpose, and that is for weaponization. Number four, go anywhere, go any time, snap inspections into any Revolutionary Guard base.

Number five, Iran has been stonewalling the international community on its possible military dimensions of its program. Iran should come clean before the deal, not after a deal, and certainly before we give them hundreds of billions of dollars in sanctions relief. And number six, economic leverage. It should not be dependent on sanctions. President Obama said no deal is better than a bad deal. That is not this emerging deal. Let’s take time to negotiate a better deal. Why are we rushing towards a bad deal? My bet, compared to Obama’s deal, Hillary’s deal will be much better. In fact, compared to Obama’s deal, the leading Republican contenders will have a better deal. Hillary and the Republican contenders are the ultimate snapback. That’s why you should vote against the proposition that Obama’s deal is good for America. Thank you.

## Round 2

### Moderator
Claim: Thank you, Mark Dubowitz. And that concludes round one of this Intelligence Squared U.S. debate where our motion is “Obama’s Iran deal is good for America.” All right. Remember how you voted before the debate. Again, we’re going to have you vote right afterwards.

And I’ll say this one more time. The team-- well, I’ll probably say it many more times. The team whose numbers change the most between the two votes is how we declare our winner.

Now we move on to round two. Round two is where the debaters address one another directly and take questions from me and from you, our live audience here in New York. Our motion is this: Obama’s Iran deal is good for America. We have heard Philip Gordon and Thomas Pickering arguing for the motion by saying that this deal is not perfect, but that it will contain Iran’s nuclear ambitions, that it cuts off all paths to its ability to construct a bomb in a short period of time. They would not be able, they say, to sneak one through the system. They say not having an agreement in place in the near future leaves Iran with a freehand to do whatever it wants, that it would be a staggered deal, that Iran doesn’t get everything up at once, but it’s through stages of give and take and that a deal that-- that gives the U.S. everything that it wants, to aspire to that is like wanting to believe in the Tooth Fairy.

The team arguing against the motion, Michael Doran and Mark Dubowitz, argue that there’s just no reason to think that the leadership in Iran is going to abide by the terms of any deal and that it’s going to change soon; that the United States gave away way too much, way too early in the negotiations, that there is only a future in both ends of this deal in which Iran just becomes a bigger power in the region and more of a troublemaker. They have issues with the temporariness of this deal, the fact that 10 to 15 to 20 years from now we would be back where we started. And they point out that basically this deal leaves Iran’s nuclear infrastructure essentially intact and that it can be revived with the turn of a screw.

I want to go to the team that’s arguing for the motion, “Obama’s Iran deal is good for America.” And in a very broad sense, gentlemen, your opponents, they seem to be making an argument that at best, you’re naive, that you-- you’re not-- I don’t think they’re saying you’re willing to trust, because it sounds like you’re not willing to trust.

But you trust in the mechanisms of the deal and that you’re just putting way too much hope in bad guys who know how to cheat. Why don’t you take that on, Philip Gordon?

### Conspiracy Advocate (CA)
Claim: Yeah. I will start. But, frankly, I don’t know where to start, given what we heard about this agreement, speaking of Tooth Fairies. I don’t get all of my predictions right. I’m probably wrong most of the time. But when I stood up there a few minutes ago and predicted that what we wouldn’t hear was an alternative path to get somewhere, instead we just hear a litany of the things that we would love to see if we could write it ourselves, I got that prediction right. And, Mark, I think you misunderstood my challenge. My challenge wasn’t to describe a better deal. I can describe a better deal, and you did a great job of it. I love your deal. I’d sign it right now. I can describe the salary package that Tom would have if he was a billionaire. I can’t do is tell him how to get there. And that’s what you didn’t tell us, how to get that better deal.

### Moderator
Claim: Okay. We can get to that point, but I’d like it if you answer my questions. And my question was that these guys are saying that you’re just naïve to believe that this--

### Moderator
Claim: Right.

### Moderator
Claim: --thing would stand up. And I’m not saying that disrespectfully because I actually want to get to the points you’re making.

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: But just to keep a shape to it.

### Conspiracy Advocate (CA)
Claim: I’ll say one word on trust. And I think Mike understood that point on trust, the Denmark analogy. We don’t need this agreement because we trust Iran. It’s precisely because we don’t trust them that we need a verifiable agreement with binding restrictions.

### Moderator
Claim: Let’s go to the other side. Mike Doran.

### Scientific Advocate (SA)
Claim: The agreement doesn’t have binding restrictions. This is the-- the reason that we have gotten any compliance out of the Iranians thus far is because we’re paying them to do it.

The-- you know, Tom mentioned that the agreement is going to require the Iranians to come clean on all of their past program, which is an incredibly important aspect of the monitoring mechanism. Unless you understand what the program was, you can’t monitor it. The fact of the matter is the Iranians have stiffed the IAEA for a decade about this. We have not stood firm on it. We have not forced them to come clean on their past program. And the agreement that we got from them about that is that, yes, they will address that question in the future. I’m willing to bet anything-- I’m going to make a prediction right here, Phil. And my prediction is that if this deal is signed, we’re going to give them sanctions relief before they ever come clean on their past program, because they have never ever come clean and they’re not going to let us into military sites.

### Moderator
Claim: Tom Pickering.

### Conspiracy Advocate (CA)
Claim: Look, let me offer you the facts, not your imagination, not your predictions--

### Scientific Advocate (SA)
Claim: Have they ever come clean to the IAEA?

### Conspiracy Advocate (CA)
Claim: --these are the facts--

### Scientific Advocate (SA)
Claim: Have they ever come clean to the IAEA?

### Conspiracy Advocate (CA)
Claim: --yes, of course they have. They’ve started.

### Conspiracy Advocate (CA)
Claim: They’ve started.

### Scientific Advocate (SA)
Claim: They’ve started.

### Conspiracy Advocate (CA)
Claim: But that’s a step. But we will not--

### Scientific Advocate (SA)
Claim: You just said that.

### Conspiracy Advocate (CA)
Claim: --conclude the release of sanctions until they have come clean with the IAEA. That’s an indisputable negotiating objective of the United States. That’s what we have said we will agree to, nothing less. And so that’s-- you’re sitting here making up fairy stories about what it is that’s going to be agreed or not agreed. Nobody that I know of, when the framework came out on April 2nd, who knows anything about this agreement was not surprised by the degree to which Iran had come in our directions, including, I have to tell you, a number of very senior Iranians. The notion that somehow we have been snookered or somehow that this process will not work, totally defeats the fact that throughout the Cold War we made a whole series of agreements with the Soviet Union. President Reagan said in his best Russian, “Doveryai, no proveryai,” “Trust but verify.” That’s the basis of this agreement.

### Moderator
Claim: All right, let me--

### Conspiracy Advocate (CA)
Claim: This is nothing new here.

### Moderator
Claim: --Mark Dubowitz.

### Scientific Advocate (SA)
Claim: Yeah. Tom, it’s interesting. I mean, you know, these are stories you tell children to keep the nightmares away, that, “Don’t worry, the Iranians will come clean. Don’t worry, the Iranians have come clean.” But, Tom, you know better than anybody that the Iranians have been stonewalling the IAEA for years. There are 12 outstanding questions about past and possibly continuing military dimensions of the Iranian program. The head of the IAEA has made it very clear that he is deeply frustrated that Iran refuses to answer those 12 questions. They’ve answered half of one, Tom. Half of one is not answering the questions. There are 11 and a half outstanding questions. We also know that the administration will give sanctions relief based on Iranian nuclear compliance, and that includes centrifuges, it includes Fordow, it includes some of the nuclear elements of this.

So Iran is going to get sanctions relief before they ever have to come clean on all 12 dimensions of the weaponization efforts--

### Conspiracy Advocate (CA)
Claim: Just not accurate, Mark.

### Scientific Advocate (SA)
Claim: And you know what?

### Moderator
Claim: Phil. Phil.

### Conspiracy Advocate (CA)
Claim: They’ve already come on 8 according to the IAEA, but let’s not argue about the details.

### Scientific Advocate (SA)
Claim: 12, Tom, half of 12.

### Conspiracy Advocate (CA)
Claim: Let’s argue about the notion that they cannot get sanctions relief until they do.

### Scientific Advocate (SA)
Claim: But, Tom, they already have gotten sanctions relief. They’ve gotten $11.9 billion in oil escrow funds that have returned to them since November 2013. They’ve gotten petrochemical sanctions relief. They’ve gotten auto sanctions relief. Their economy-- Tom, their economy was on its back in 2013--

### Conspiracy Advocate (CA)
Claim: That’s in return for the joint program of action.

### Scientific Advocate (SA)
Claim: --but they came-- but they got sanctions relief before they ever came clean on weaponization, which completely contradicts your thesis.

### Conspiracy Advocate (CA)
Claim: But that’s--

### Moderator
Claim: Let me bring in Phil Gordon.

### Conspiracy Advocate (CA)
Claim: Well, they have gotten exceedingly modest sanctions relief, access to a small fraction of their money that has been frozen in foreign accounts, which you know very well the Iranian economy is at least $500 billion or a trillion dollars.

And getting access to 700 million of their own does not make a significant difference. The PMD point I think is the essential one. We agree with you that they haven’t yet come clean on PMD, and that they need to. What Tom is saying is that there won’t be real sanctions relief until they do. Now, you can assert that that’ll never happen, but I think we need to debate-- you know, the proposition on the table is “Is this framework good for America?” You can attack some alternative version of the framework, but the one on the table is the one in which they have to come clean on PMD before they get to--

### Scientific Advocate (SA)
Claim: And so, here’s the problem.

### Moderator
Claim: Let’s--

### Scientific Advocate (SA)
Claim: Because you’re getting the economics wrong here.

### Moderator
Claim: Mark, let’s hear from your partner, Mike.

### Scientific Advocate (SA)
Claim: Let me shift it a little bit and just--

### Moderator
Claim: Mike Doran.

### Scientific Advocate (SA)
Claim: --say that, you know, Tom said what I want is a fantasy. I want zero enrichment, zero reprocessing. That’s not what I want.

What I want is an American side that will, A, behave like a great power, and B, not give the store away, that will use the leverage that it has to get the best kind of deal, the kind of deal that Mark described. Now, what

### Moderator
Claim: What-- let me just-- why do you think that that hasn’t happened? What do you-- what if this actually is the best deal that they can get--

### Scientific Advocate (SA)
Claim: Oh, no, no, no, no--

### Moderator
Claim: --given the realities?

### Scientific Advocate (SA)
Claim: No, no, no, no-- we-- listen. I have it from European partners to the negotiations that they have been shocked by the giveaway. The idea that we are responding, that we are responding to the demands of allies is simply not true. This has been a bilaterally negotiated deal.

### Moderator
Claim: Motivated by what?

### Scientific Advocate (SA)
Claim: --by the desire for detente with Iran. The president has sold the world on the notion that he is-- that what he’s trying to do is get a nuclear arms agreement. What he is-- his strategic goal is to have detente with Iran, and he’s using the arms control agreement as the vehicle--

### Moderator
Claim: So--

### Scientific Advocate (SA)
Claim: --for getting it.

### Conspiracy Advocate (CA)
Claim: The way that--

### Moderator
Claim: Tom Pickering.

### Conspiracy Advocate (CA)
Claim: --European allies-- the Russians, the Chinese, the Brits, the French, and the Germans have been with us. Even with an--

### Scientific Advocate (SA)
Claim: Not true.

### Conspiracy Advocate (CA)
Claim: --occasional protest from Francais.

### Scientific Advocate (SA)
Claim: Not true.

### Conspiracy Advocate (CA)
Claim: So, but it’s very true.

### Conspiracy Advocate (CA)
Claim: Every step of the way.

### Scientific Advocate (SA)
Claim: Not true.

### Moderator
Claim: Mike, wait.

### Moderator
Claim: Gentlemen, I--

### Moderator
Claim: No. No. I just-- Hold it. Let’s negotiate this. I just-- I do need to point out that when everybody’s talking over each other, that’s the section that absolutely gets cut from the podcast--

### Moderator
Claim: --after about two seconds, for a little energy. But then we can’t hear what anybody’s saying. So--

### Scientific Advocate (SA)
Claim: So, guys, stop talking--

### Moderator
Claim: --let’s keep it going.

### Scientific Advocate (SA)
Claim: --over me.

### Moderator
Claim: Let-- let me-- let Phillip respond.

### Conspiracy Advocate (CA)
Claim: So, then, I’m just puzzled. So, Mike is sure that the British, and the French, and the Germans, and the Russians, and the Chinese hate this agreement and think we’ve given away the store, but the foreign ministers of all those countries have endorsed it, and explained it, and defended it. That’s a tricky one for me.

### Scientific Advocate (SA)
Claim: Well, that-- the fact is--

### Scientific Advocate (SA)
Claim: --I mean, that’s easy, Phil. And you know this. The fact the matter of is is those countries don’t believe they can stop the Obama runaway train to essentially surrender. I mean, the French have--

### Conspiracy Advocate (CA)
Claim: Sure, the Russians are totally compliant--

### Scientific Advocate (SA)
Claim: The European--

### Conspiracy Advocate (CA)
Claim: runaway train.

### Scientific Advocate (SA)
Claim: The Europeans have told me-- the Europeans have told me their biggest nightmare, okay, is U.S. negotiators at one minute to midnight in a room with the Iranian negotiators. And they believe at that point, major concessions come. And listen, major concessions have come, Phil. The fact of the matter is Iran’s economy was on its back in 2013 as a result of sanctions. As a result of sanctions relief that your administration-- that you were in-- negotiated, the economy is on its knees getting up to its feet. We’ve lost economic leverage. Iran went from a severe recession to a modest recovery. When you lose peaceful economic leverage, you lose the ability to actually negotiate strong nuclear concessions. And when you lose peaceful economic leverage in a post-deal environment, you have no way to enforce this deal. And then you have to use military force to enforce this deal, which is something nobody at this table wants.

### Moderator
Claim: Phillip Gordon.

### Conspiracy Advocate (CA)
Claim: So, one percent--

### Moderator
Claim: So--

### Conspiracy Advocate (CA)
Claim: --of their economy--

### Moderator
Claim: Hold it. I--

### Conspiracy Advocate (CA)
Claim: --one percent changed their economy.

### Moderator
Claim: Hold-- Tom, wait. I want to hear from Phil.

### Conspiracy Advocate (CA)
Claim: We agree on sanctions, Mark, at least that part of it. That’s why they agreed to this deal that required them to do so many things that they didn’t want to do. You’re right. Their economy is on its back. It’s because of the sanctions that we put together, together with our allies. And that’s how we got this deal.

### Scientific Advocate (SA)
Claim: And then you diminish the pressure.

### Moderator
Claim: Mike Doran.

### Scientific Advocate (SA)
Claim: Then you the negotiations--

### Moderator
Claim: Mike-- you-- Mark--

### Scientific Advocate (SA)
Claim: --and diminish the pressure, and you gave on key nuclear demands, and that’s why--

### Moderator
Claim: Mark--

### Scientific Advocate (SA)
Claim: --we’re getting a sloppy--

### Moderator
Claim: Mark, your partner is touching your elbow.

### Scientific Advocate (SA)
Claim: That was out of affection.

### Moderator
Claim: Talk-- you on your--

### Scientific Advocate (SA)
Claim: Mark was nice. Mark toned down the story a little bit. The story that he heard was, “Our nightmare”-- this is from our European allies. “Our nightmare is that Zarif and Kerry are in a hotel room, and it’s one minute to midnight, and there’s a-- then there’s a deadline.” That’s what they said. Now, the story that the Obama Administration told when it signed the interim agreement, is it said, “Oh, the Supreme Leader is under such economic pressure, he’s dying for an agreement.

What he needs from us is a face-saving agreement. A face-saving agreement. So, we’re going to rip up these Security Council resolutions, zero enrichment, zero reprocessing, and we are going to-- we are going to give him a face-saving nuclear enrichment program of 1,000 centrifuges.” And then I heard from our European allies, a little bit later the Americans came and said, “It’s not going to be 1,000, it’s going to be 3,000.” A little bit later they came and said, “No, 4,500.” Now it’s 6,104. And that’s why I can sit here and I can tell you, with absolute certainty, and I will be correct on this, there has been a pattern of concession, unilateral concession from the United States, and in forcing our partners along, and in the end--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --the Iranians won’t come clean, and we’ll give them sanctions relief.

### Moderator
Claim: Going to Tom, please.

### Conspiracy Advocate (CA)
Claim: Look, your predictions are your predictions.

They have nothing to do with the framework. They have nothing to do with what we now have in hand, and they have nothing to do with what is now being currently negotiated as the final language of the agreement, which I am told is moving well. So if you want to believe the Tooth Fairy, if you want to believe the worst of all possible predictions, there’s your choice. But it’s not up on the board. You’re not voting for anything but the Obama proposal at the present time or some alternative imaginary set of ideas. We constantly have asked, how is it that you would get done what it is you want to get done? And why is what you want to get done so much more worthwhile in the process of moving ahead? Everybody knows they negotiated for a house here in this room. How many in this room have negotiated for a house? Everybody knows your first bid is not the acceptable answer to what it is you get.

It’s plain and simple.

### Scientific Advocate (SA)
Claim: John, you gave away the house.

### Moderator
Claim: Almost everybody knows that. I bought John’s house, actually-- best deal of my life.

The two guys over here didn’t raise their hands so--

### Moderator
Claim: Mark Dubowitz. Mark Dubowitz.

### Scientific Advocate (SA)
Claim: Well, here’s the problem. We have outlined a better deal. And one of the key elements of a better deal is that the restrictions of the Obama administration of putting on this program are not going to expire after 15 years. I mean, 15 years. So let me ask how many of you are remember 9/11? 9/11 was 14 years ago. How many of you have kids? All right, college senior was in first grade 15 years ago. And parents know that in geopolitics, as in life, 15 years is a blip in time. In 15 years, most of these restrictions are going to vanish. Iran will have an industrial sized program. It’ll have zero breakout. Zero breakout is undetectable breakout. Tom, we can negotiate a better deal by making one simple modification to the Obama deal.

And that is that the restrictions will not sunset. They will not disappear until the International Atomic Energy Agency has reached a broader conclusion that Iran’s nuclear program is only for peaceful purposes and there are no clandestine activities, which why not demand that?

### Moderator
Claim: Let’s take that to Phil. I mean, I think that a lot of people in the audience would wonder is, what’s so great about a deal that gets Iran to stop for 20 years and then they could start again? So what-- what’s supposed to happen after that?

### Conspiracy Advocate (CA)
Claim: Well, one thing that’s great about it is Iran stops for 20 years. So you may not-- it may not be your ideal scenario. But if Iran doesn’t stop for 20 years, then they start tomorrow. So that’s one thing about it. Secondly, I keep coming back to this, and I’m sorry. You need a deal that you actually get and not one that you would, like I said earlier, write if you only had to write it yourself. We could have-- of course, Mark, we could do that. We could go to the Iranians now and say, “You’re currently in the doghouse because people don’t trust you. You violated Security Council resolutions, and that’s why we need these real commitments, binding commitments from you.

But you know what? You’re going to be the doghouse forever. You have to accept uniquely-- you’re the only country in the world-- you have to accept these binding-- not for 20 years, not for 30 years, but for infinity.” I would submit to you we could do that and we would have a zero chance of getting an agreement, and then we’d be right back to what we’re talking about now. And so you won’t like the 20-year restrictions. You won’t have any restrictions and see if you like that much better.

### Scientific Advocate (SA)
Claim: No, you’re mischaracterizing. The IAEA could reach that broader conclusion in five years. They could reach it in seven years. All Iran has to do is declare to the IAEA that we have no clandestine facilities, we have no clandestine activities, and the IAEA reaches a broader conclusion that it has done so with 60 countries, to say this is a peaceful program. So this is not about eternity. This is not about the Tooth Fairy. This is about a restriction--

### Conspiracy Advocate (CA)
Claim: But you’re-- you’re now for eternity.

### Scientific Advocate (SA)
Claim: It could be five--

### Conspiracy Advocate (CA)
Claim: Last point about it.

### Scientific Advocate (SA)
Claim: Phil, it could be five years. It could be seven years.

### Conspiracy Advocate (CA)
Claim: No, no. If the agreement says--

### Scientific Advocate (SA)
Claim: Peaceful nature of the program.

### Moderator
Claim: Okay, okay. This is what we’re going to do.

### Scientific Advocate (SA)
Claim: Peaceful. Phil, peaceful.

### Moderator
Claim: Bringing out the bell. We’re going to calm things down, but to lighten things up at the same time, we’re going to continue for the next two minutes, but you each get 30 seconds. Nobody else can talk during one side’s 30 seconds. When you hear the-- when you hear that bell, you have to stop, and the other side has to start. You’ll see the clock in front of you. I’m going to let it go to Tom Pickering or Phil. Who’d like to start? Your 30 seconds starts now.

### Conspiracy Advocate (CA)
Claim: The question, please, before they start my 30 seconds. What question--

### Moderator
Claim: Oh, you were-- well, so you were responding to your opponent.

### Conspiracy Advocate (CA)
Claim: Well, one last point on sunset, about the 20 years. This is agreement doesn’t say, and we don’t believe, that as soon as the restriction is over, whether it’s 10 years on centrifuges or 20 years on something else, Iran can do whatever it wants and get in a nuclear weapon. Whenever these phases end, and in many cases, 15 and 25 years down the road, the U.S. president, the Israeli prime minister, the leaders of the P5+1 will decide how they want to approach Iran at that point.

Doesn’t mean they get a free pass. What it does mean is we get a couple of decades of peace until 2030, which is a lot better than not having it next week.

### Scientific Advocate (SA)
Claim: You get-- you don’t--

### Moderator
Claim: Mike Doran.

### Scientific Advocate (SA)
Claim: You don’t get a couple of decades. You don’t get 10 years, you don’t get 15 years. You have an agreement. You have a Mafioso who’s going to sign an agreement, is going to say he’s going to abide by certain restrictions for 10 or 15 years. But all of the leverage that we have, other than military force, we are giving up on the front end of the-- on the front end of the deal. We’re paying them to sign this. We are paying to say that they will be good citizens for 10 or 15 years. And then you’re coming to me and saying that we’ve got this in hand. This is the way-- this is the Iran that we’re going to be dealing with for the next 10 or 15 years is not the one that we’ve been dealing with for the last 35.

### Conspiracy Advocate (CA)
Claim: Pieces of this deal last forever, including the fact that Iran is obligated not to do anything to move toward nuclear weapons. Secondly, the additional inspection protocol stays on forever. So those are very important because they will signal to us plenty early as to whether the Iranians are keeping their commitments or staying out of the nuclear weapons business as we go ahead. And it’s important that we have those to guarantee the process is moving ahead. And we have the force at the end of the day if they violate this agreement.

### Moderator
Claim: Mark.

### Scientific Advocate (SA)
Claim: Here’s the problem: If I’m Iran, here’s what I do. I comply with the agreement for the first few years. I get my sanctions relief. I get the billions of dollars returned to me. I build my economy. I rebuild my economy. I create economic immunity against future economic pressure. I am a good boy for the first few years, and then I start to cheat. But I cheat incrementally, not egregiously, even the sum total of my incremental cheating will always be egregious if I’m an Iranian regime. And I will then wait until those restrictions start to disappear, year 10, year 13, year 15, year 20.

### Moderator
Claim: All right. Hoo that felt so orderly. Thank you. I want to-- I want to go now to audience questions and to remind you, I’ll call on you. A microphone will be brought to you from the aisles. Just wait till it gets to you. Hold the mic about the distance from your mouth as a fist, as I am here. And please ask a question that’s relevant to-- to the motion that’s before us, that it relates to this Iran deal. I would be interested if anybody has a question about an Iran that is sanction free. Is that such a great thing also, which is not part of the discussion we’ve gotten to very much.

Let’s go to some questions. Right down front, sir. And a mic is coming down the aisle from your right. And if you could stand and tell us your first name, please.

### Moderator
Claim: Sure. Thanks. Thanks, John. My name is Kayvon Afshari. I’m the director of communications for the American Iranian Council. It’s an organization for which Ambassador Pickering serves as an honorary board member. And actually, that is what my question is about.

So I want to leave aside your--

### Moderator
Claim: You’re not a plant as--

### Moderator
Claim: No, no, no. I have a lot of respect for him but not at all.

### Moderator
Claim: He’s our plant.

### Moderator
Claim: Well, actually, I want for the side what Iran is conceding in this deal and focus on the sanctions relief that it will hypothetically receive. And I kind of want to ask two sides of this question, one for each side. So for the side in favor of the deal, do you see any veracity in the argument that, you know, an Iran which has sanctions relief will be more aggressive regionally, you know, spend that money in Yemen and Syria. And for the other side, do you see the argument that an Iran that has sanctions removed might, you know, through economic interdependence-- it’ll have kind of a moderating effect on its regional behavior.

### Moderator
Claim: So is the sanction for Iran basically good for America or bad for America by being good or bad for Iran? Let’s take it first to Tom Pickering.

### Conspiracy Advocate (CA)
Claim: You want to take it?

### Moderator
Claim: Okay, Phil Gordon.

### Conspiracy Advocate (CA)
Claim: Yeah, sure.

### Moderator
Claim: You’re recusing yourself. That’s very respectful.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: Look, Iran having access to its frozen funds is not something we would welcome. We’ve been very clear, the administration has been very clear that Iran is a destabilizing factor in the region. It’s a state supporter of terrorism, and we don’t want to see the Iranian regime have more money at its disposable to pursue some of these activities. But as Tom reminded the group earlier on, this is a nuclear agreement. The reason these specific sanctions are in place-- the only reason we got the rest of the world to join these sanctions-- and, by the way, it was only when the rest of the world joined them that they became effective-- is that they were focused on Iran’s nuclear weapons program. Now, it seems to me what our opponents are suggesting here, or those who don’t want to move ahead with this deal, is that we focused it on the nuclear program to get international support for the sanctions, we brought down the Iranian economy, and then in the 11th hour we say, “Oh, by the way, even though we’ve gotten what we want on the nuclear side, let’s keep on the sanctions because we actually now want Iran to stop supporting terrorism, recognize Israel, stop messing around in Yemen--” and, let me just be clear, I’m for all of those things.

We should be vigorously trying to pursue all of those goals, but the idea that we can just shift gears and say, “We’re not even doing the deal until then,” is a recipe not for getting both a nuclear deal and constraining Iran in the region, it’s a recipe for getting neither.

### Moderator
Claim: Mike Doran.

### Scientific Advocate (SA)
Claim: This deal isn’t a deal about nuclear weapons, but it has profound implications for Iran’s place in the world. It has profound implications for Iran’s ability to make mischief around the region. Phil says he and the Obama administration would say as well that they are for doing something about the Iranian backed militias in Iraq, they’re for stopping Hezbollah from turning South Lebanon into an armed camp. Hezbollah has 100,000 missiles and rockets that can-- that could hit Israel-- what are they doing about it? They’re not doing anything about it.

All of the region, everyone in the region, all of our allies are up in arms, hair on fire about this issue, and the answer is, “Look, it’s just a nuclear agreement.” The only way this agreement makes sense, is what Kayvon asked here, is if the Obama administration believes that if it kisses the frog it will turn into a prince, that through this economic-- through the economic transformation of Iran, through greater relief of sanctions and greater business opportunities Iran is going to miraculously transform into something other than what we know it to be.

### Moderator
Claim: Well, that actually was the second part of the question. What of that proposition?

### Scientific Advocate (SA)
Claim: The Iranian regime has-- the Revolutionary Guard Corps has set up front companies that dominate the economy of Iran. They have positioned themselves very well to benefit from this. What we are doing, like I said, is making a deal with the mafia and assuming that it will become a legitimate businessman. There’s no reason to believe that. Maybe, maybe it could possibly happen, but it is wishful thinking. It is definitely Tooth Fairy thinking.

### Moderator
Claim: Is it at the core-- the side arguing for the motion-- is it in any way at the core of the thinking on the agreement that Iran in 10 to 20 years may be nicer than it is today?

### Conspiracy Advocate (CA)
Claim: I think it’s clear that they will be deeply invested in being part of the international community from which they have been excluded. So there is no question that at least one possibility is that they will behave and not move toward a nuclear weapon. The other possibility is we will certainly, as I pointed out a minute ago, know if they do. And we will have exactly the same retributive capabilities then as we have now. And in my view that is the arrangement that makes the most sense and the best deal that we have been able to get up until now, and our friends have shown us absolutely no way to improve the deal.

I would love to find ways to improve the deal, but I am totally satisfied that the deal we have now on the table is a deal which we can certainly live with and that we will have every opportunity to assure that Iran does not get a nuclear weapon.

### Moderator
Claim: Okay, Tom, one second-- Tom, I just got to note that the next time you don’t need to actually look to me, and when you turn you lost the mike. So you got-- you can all speak out when you’re speaking. But take it to Mark.

### Scientific Advocate (SA)
Claim: All right, John, thank you. Look, Tom is actually putting his finger on their case. Their case is of an economic seduction case, not economic coercion. We’re going to seduce the hard men of this regime, and in 15 years they are going to be integrated in the global economy. And by being integrated they’re going to be moderate and pragmatic, because that’s the only way this deal makes sense, because all those restrictions are going to go away in 15 years.

Now, Tom and Phil have both said, “We will have the same coercive power in 15 years that we have today.” It took decades to build up the sanctions regime. It took decades to change the political calculus of the hard men of Iran to get to the table to start negotiating seriously. You don’t snap back sanctions overnight. In fact, it takes decades to reconstitute them. And, as I said before, we’re snapping back sanctions not just against the Russians and the Chinese, we’re going to be snapping them back against the Europeans. We’re going back into Iran and investing tens of billions of dollars back into the Iranian energy sector and the financial sector. We will not have the same coercive instruments in 10 to 15 years. We will have military force as an answer to Iranian cheating or challenging of the IAEA. And if economic seduction doesn’t work, Phil, if economic seduction doesn’t work, Tom, it’s the same regime in power. And this is not King Wilhelm Alexander of Holland. All right? This is Ali Khamenei of Iran. And he’s a hard man. And these are the Revolutionary Guards. And they are hard men. They cannot be economically seduced.

### Moderator
Claim: Sir, if you could stand up. Thank you.

### Moderator
Claim: Yeah. My name is Gibran I wanted to address a question to the side arguing for the motion.

Your opposition made a point about whether this deal is good for America or not, how it’s perceived in the region, with our allies, Saudi Arabia and Israel, they’re very unhappy with that. How is that going to influence the direction that it goes?

### Conspiracy Advocate (CA)
Claim: Let me just--

### Moderator
Claim: Tom Pickering.

### Conspiracy Advocate (CA)
Claim: --say the following, that before the November 24th preliminary agreement was even reached, Prime Minister Netanyahu said it was the worst of all possible agreements ever negotiated. Within a year, he was back to us, pleading with us to accept this agreement as the “forever document” in the process of moving ahead. He said the same thing about the comprehensive framework before it appeared. Now that it is appeared, I hear nothing from Prime Minister Netanyahu further about the arrangement. There is no other alternative in my view that is achievable, that has the capacity to stop the Iranians from making a nuclear weapon.

And my view is at this stage, that the allies may be jealous of the fact-- which is purely imaginary-- that somehow, Iran is going to emerge as some kind of new hegemon in the Middle East. The president, I’m sure, made it clear to them at the Camp David summit, that was the farthest thing from his mind. But it is important, in fact, that we deal with realities and not with the kind of imagination that sits across the table from us.

### Moderator
Claim: Would your side like a response on that?

### Scientific Advocate (SA)
Claim: They’re not--

### Moderator
Claim: Mike Doran--

### Scientific Advocate (SA)
Claim: --the allies are not upset about imaginary things. They allies are upset about militias that the Iranians are running inside Iraq, and that the United States is cooperating with indirectly in fighting the Islamic State. Our airpower comes in, and knocked out the Islamic State of Ramadi, and the Shiite militias controlled by Tehran took it over.

In Israel, now, we have Iranian forces-- not just Hezbollah, but actually Iranian forces across the border from Israel in Syria. We’ve got an Iranian proxy, Hezbollah, on Israel’s northern border. We’ve got an Israeli proxy, Hamas, in Gaza. We’ve got Iranians on the--

### Moderator
Claim: You meant Hamas as an Iranian proxy. You--

### Scientific Advocate (SA)
Claim: Hamas is an Iranian proxy.

### Moderator
Claim: Yeah. You referred to Israelis--

### Scientific Advocate (SA)
Claim: It’s a-- it’s-- Hamas is not as closely controlled as Hezbollah is by Tehran, but the military wing of Hamas is armed and equipped by the Iranians. So, the Israelis are now surrounded by Iranian power. And when you-- when the Israelis or the-- and the Saudis see the Iranians in Yemen, when the Saudis and the Israelis go to the Americans and they say, “What’s your answer to this? The rise of Iran across the region,” the-- what they get is rhetoric. They get President Obama saying, “We’re concerned about that. We’ve got your back. We’ll help you.”They say to the Saudis, “We’re going to help you with your intraoperative missile defense, and we’re going to give you some other capabilities against conventional threat, which doesn’t even address the issue at all.

### Conspiracy Advocate (CA)
Claim: Might I have a word on that?

### Moderator
Claim: Yes. Please do. And then I’m going to go ahead.

### Conspiracy Advocate (CA)
Claim: Just to remind people, the proposition on the table is whether this deal is good for America. Now, a lot of our allies in the region and elsewhere have real concerns about Iran, and so do we. And we stand with them on that. But a lot of our allies in the region would not mind if we went to war against Iran. And we used force in Syria against Iran’s proxy there. And we stood up and fought militia in Iraq. And that may well be in their interest. The proposition on the table is, is this good for America?

### Scientific Advocate (SA)
Claim: A destabilized--

### Scientific Advocate (SA)
Claim: --Middle East is bad for the United States.

### Scientific Advocate (SA)
Claim: Yeah, and Phil, so is proliferation in the Middle East bad for America. I mean, the Saudis have made it very clear that they want the deal that Iran is going to get. So, the Saudis are going to have a one-year breakout capability, as are the Emiratis. The Turks are going to want that. A deal that was designed to stop proliferation is enabling proliferation.

A nuclear armed Middle East with nuclear threshold states to turn the screw from a nuclear weapon is bad for America. That’s why Obama’s deal is bad for America.

### Moderator
Claim: So, I want to remind you that we’re in the question and answer section of this Intelligence Squared U.S. debate. I’m John Donvan, your moderator. We have four debaters, two teams of two, arguing it out over this motion: Obama’s Iran deal is good for America. Tom Pickering.

### Conspiracy Advocate (CA)
Claim: John, we’ve strayed a long way from that-- but I cannot help to ask--

### Moderator
Claim: Good point.

### Conspiracy Advocate (CA)
Claim: --who here has heard of ISIS? Here is Michael suggesting that in fact the Iranian opposition to ISIS is somehow in Iraq a dangerous development for American interests. That, I find, very hard to jump to that conclusion. I just wanted to make sure that you understood that thinking.

### Scientific Advocate (SA)
Claim: I want to-- I’d like to explain that.

### Moderator
Claim: My name is Devon

I just would like to pose a question to both sides concerning the narrative coming out of both countries on this agreement. One reads about an Iranian narrative that sounds substantially different, but I’m sure you are negotiating with just those people, so I just wondered what the-- what the explanation is for quite a discrepancy there.

### Moderator
Claim: Phil Gordon.

### Conspiracy Advocate (CA)
Claim: It’s actually explanation because there’s not a great discrepancy. I’d actually urge you to read-- the Belfer Center at Harvard did a really nice comparison of the U.S. fact sheet and what Iranians have been saying, because a lot of people have picked up on this. You know, it’s a different agreement, and they don’t really agree to it. Not surprisingly, each side is emphasizing what it gets and minimizing what it’s giving. And the Iranians are really doing that.

But when you actually look at what the Iranians have said, they don’t take issue with our fact sheet. They’ve called it “spin,” and they’ve emphasized what they don’t have to do. But it’s, I dare say on their side, all spin. Right?

So, you know, they’ll emphasize all of the things that they’ll preserve without-- they’ll have a 300-kilogram stockpile. This sort of overlooked the fact that they’re going to give up 98 percent of what they currently have. And they’ll have 5,000 operating centrifuges. They don’t emphasize the fact that to get there they have to dismantle more than 5,000 others. So if you actually look at the details of the two sides, you don’t find a huge gap. You find a huge gap in emphasis, but they don’t-- they don’t deny the agreement that we articulated

### Moderator
Claim: Mark Dubowitz.

### Scientific Advocate (SA)
Claim: Well, that’s totally right. There’s no big gap because Iranians know exactly what they’re getting. They’re getting a great deal. They understand that they’re getting to preserve their entire nuclear infrastructure. They understand that 6,000 centrifuges keep them a year away from breakout.

### Scientific Advocate (SA)
Claim: Now, wait a second, Tom. Wait a second. Wait a second.

### Scientific Advocate (SA)
Claim: Wait a second.

### Conspiracy Advocate (CA)
Claim: Ninety percent of their low enriched uranium, that’s their entire infrastructure?

### Scientific Advocate (SA)
Claim: I got a fact sheet here.

### Conspiracy Advocate (CA)
Claim: centrifuges.

### Scientific Advocate (SA)
Claim: I got a fact sheet-- Tom.

### Moderator
Claim: All right. They take the--

### Scientific Advocate (SA)
Claim: Tom, Tom, Tom.

### Conspiracy Advocate (CA)
Claim: of their reactors. Is that their entire infrastructure?

### Moderator
Claim: Tom, let him-- let him make his point, and then you’re going to get the floor. All right, go ahead, Mark.

### Scientific Advocate (SA)
Claim: The fact of the matter is that this Iranian regime understands very well that they are going to get a significant nuclear infrastructure that will expand over time. It’ll be industrial sized. It’ll be massive, and they’ll have zero breakout. Tom and Phil, you have not explained to us, when Iran reaches zero breakout in year 15-- in fact, President Obama said, in an interview with NPR, that they’re going to reach near zero breakout by year 13. You haven’t explained to the audience, and you haven’t explained to us how near zero breakout or breakout or undetectable breakout is a good deal for America.

### Moderator
Claim: Do 12 seconds reminding everybody what the term “breakout” technically means.

### Scientific Advocate (SA)
Claim: “Breakout” means the length of time it takes to weaponize a bomb’s worth of uranium. It effectively means the most difficult element of developing a nuclear weapon and the element of developing a nuclear weapon that is easiest for us to detect.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: It’s very difficult for us to detect warhead design in a laboratory.

### Moderator
Claim: 19 seconds

### Scientific Advocate (SA)
Claim: It’s complicated stuff, you know--

### Moderator
Claim: The bottom line is if the government decides on March 1st that they want to build a bomb, their argument, it’s going to take a year to get one, or they’re going to have it in May is what we want to get to. So

### Conspiracy Advocate (CA)
Claim: breakout and Tom will do infrastructure. Specifically breakout timeline is the amount of time that would be required to accumulate enough fissile material for one nuclear weapon. And we err on the side of caution when we calculate it. They’ve actually been at two months for quite a long time. When you keep asking, we don’t have to deal with that. They’re there now, today, as we sit here. But you should address the virtually preserved infrastructure

### Conspiracy Advocate (CA)
Claim: Just-- just one point. With too much breakout and no agreement, we have a problem. Secondly, this infrastructure--

### Scientific Advocate (SA)
Claim: breakout and no-- with zero breakout in 15 years, Tom, we have a huge problem. Zero breakout.

### Conspiracy Advocate (CA)
Claim: And who--

### Conspiracy Advocate (CA)
Claim: And that was because we needed zero enrichment to solve the problem.

### Scientific Advocate (SA)
Claim: No, Tom, you’re conflating issues.

### Conspiracy Advocate (CA)
Claim: Not at all. That was the key question.

### Scientific Advocate (SA)
Claim: Tom, under this agreement, President Obama has said--

### Conspiracy Advocate (CA)
Claim: I was asked to respond to your point--

### Moderator
Claim: Mark.

### Conspiracy Advocate (CA)
Claim: --on infrastructure.

### Moderator
Claim: Tom.

### Conspiracy Advocate (CA)
Claim: And I just said carefully and quietly-- giving up 90 percent of your low enriched-- 98 percent of your low enriched uranium--

### Conspiracy Advocate (CA)
Claim: --is certainly preserving your infrastructure. Getting rid of 14,000 of 20,000 centrifuges is getting rid of your infrastructure-- it’s not getting rid of your infrastructure. It’s preserving it. Keeping the Arak reactor in a position where it can make kilograms of weapons grade plutonium per year, but taking it out of that particular capacity, that’s certainly keeping the infrastructure in place. And we could go on. But those three examples, in my view, are serious degradations of Iraq’s nuclear infrastructure.

### Scientific Advocate (SA)
Claim: John, could I make a quick--

### Moderator
Claim: Ma’am, you can-- yes. You go ahead, Tom, while that mic gets up here.

### Scientific Advocate (SA)
Claim: Just quickly, on the question about whether the fact sheets of the Iranians and the U.S. contradict each other, there was two ways in which they contradict each other greatly. One is on the question of immediate sanctions relief and the other is the question of anytime, anywhere-- anytime, anywhere inspections.

### Conspiracy Advocate (CA)
Claim: Not at all. The Iranians--

### Scientific Advocate (SA)
Claim: Sorry, sorry, Tom. Sorry, Tom. Tom, Tom, just a second, Tom. .

### Moderator
Claim: Tom, hang on.

### Scientific Advocate (SA)
Claim: And the third point-- and the third point, Tom keeps saying they’re going to get rid of centrifuges. They’re not going to get rid of-- they’re not dismantling. They’ve made it a point they will not dismantle a single centrifuge. Some of them won’t be spinning, but they’re still going to exist.

### Moderator
Claim: You know what’s interesting to me is I’m often asked, like, which was the hardest panel to control, and I thought it was going to be like Alan Dershowitz or maybe the football debate. But it’s the diplomats.

### Conspiracy Advocate (CA)
Claim: That’s why we’re such successful negotiators.

### Moderator
Claim: My name is Stella The question is, why isn’t the solution more and more choking sanctions? And why does this deal have to happen right now? Why can’t we just choke them further with sanctions until we’re in a better bargaining position to do a better deal?

### Moderator
Claim: Phil Gordon.

### Conspiracy Advocate (CA)
Claim: Well, one reason is that’s partly what got us here. You know, the world, as Iran started to do enrichment and move toward the potential weapons capability, go back to 2003, decided that the outcome had to be zero enrichment. And we insisted on that, and we insisted on that as they increased from, at the time, 160 centrifuges. And we said, “No, it has to be zero.” Then they got up to 3,000, we said “It has to be zero.” And they had 6,000, “It has to be zero.” And we’ve done that all the way to 19,000. So we could, as you suggest, and as I think Mike and Mark would suggest, keep choking. While we choke-- you know, we could take that gamble. As I said before, we could have showed up at the talks in the first day, said “The only outcome here is zero enrichment, no civilian reactors and fill Fordow with cement and let us go anywhere, anytime, including your military bases.” We could have said that. I’m just suggesting that had we done so, choking, choking sanctions, instead of 19,000 centrifuges, we’d get to 25, and then 30, and then they’d finish the heavy water reactor at Arak, and then they’d harden Fordow-- and then we would have another debate three years from now, and they’d be at 30,000 centrifuges and all the rest--

### Moderator
Claim: Let’s-- let’s--

### Conspiracy Advocate (CA)
Claim: Be careful--

### Moderator
Claim: Let me-- let me frame a little bit of what you said into a question for your opponents because I do find it an interesting point. They are basically saying that if you push too hard, if you set the terms too hard, there just wouldn’t be a deal and that they’re living in the real world, and they’re-- the grownup world, and the non-idealistic world, and that they want to come away with a deal.

So what is your response to that, that if you push too hard, there just isn’t going to be anything?

### Scientific Advocate (SA)
Claim: Well, the reality is is that I don’t believe that we should have imposed choking sanctions to these negotiations, that it’s not-- again, it’s the fallacy of the false alternative that Phil is very good offering. The fact of the matter is we should increase the sanctions.

We continue to ratchet up the pressure. We didn’t have to stick at zero enrichment, but we could have offered exactly what President Obama offered in the beginning, which was 500 to 1,000 centrifuges. Why the willingness on the part of the United States to continue to diminish our nuclear demands step by step? The fact is that the Iranians fear U.S. escalation dominance. They began in 2003 negotiating the Europeans over 13 years. They only increased their operating centrifuges by 9,500. That’s about 700 centrifuges a year. They increased their program incrementally. They fear escalation dominance. They fear our crippling sanctions.

They fear our military power. And so you’re right, we could have actually increased our sanctions, but we could have done so in an incremental way. We could have ratcheted up the pressure. And most importantly, we could have stuck to our nuclear demands. Why the rush, you ask? The rush is because President Obama has 18 months left in his term. And President Obama wants a legacy-capping nuclear deal. I said in my introduction, why not let Hillary negotiate this? Why not let Marco Rubio negotiate this? Why the rush to negotiate, right? Stick to a-- I’m trying to be bipartisan-- stick--

### Moderator
Claim: You’re being so Canadian now.

### Scientific Advocate (SA)
Claim: --so Canadian about it.

### Moderator
Claim: Let’s let Phil Gordon respond.

### Scientific Advocate (SA)
Claim: Let Steven Harper, the prime minister of Canada, negotiate this deal.

### Moderator
Claim: Phil Gordon.

### Conspiracy Advocate (CA)
Claim: Yeah, let’s just turn this all over to the Canadians.

Look, an important point on number of centrifuges, because it allows me to correct the negotiating records, and Mark’s suggesting that we caved on number of centrifuges, and Mike said the same thing, to correct the negotiating record. We’ve been very consistent from the very start on what outcome we needed on enrichment. What we needed was a breakout timeline of a year. The breakout timeline is not just a function of the number of centrifuges. It’s a combination of the number of centrifuges, the type of centrifuges, and the stockpile that you have. We told Iran, “There are a lot of different ways to make us comfortable that you’re at least a year away from fissile material for a bomb. If you want a higher number of centrifuges, then you have to have a lower stockpile or you have to rely on these old out-of-date IR-1s, because what we care about is that you can’t quickly breakout.” So you-- we could have gotten a lower number of centrifuges but maybe of a different type or a bigger stockpile. What we got was extending their breakout timeline from what we’re living with today, which, as Tom said, is not where we would like to be, to an agreement that for at least a decade they’re going to be more than a year-- at least a year away. And that’s where the number of centrifuges

### Scientific Advocate (SA)
Claim: We haven’t stuck to a single principle in this negotiation.

### Scientific Advocate (SA)
Claim: The principle that we enunciated with the interim agreement was that they had to verify that it was a peaceful program. For example, the president said, “Fordow is absolutely inconsistent with a peaceful program.” He caved on Fordow.

### Conspiracy Advocate (CA)
Claim: He said they don’t need enrichment at Fordow, and the agreement is very clear, there will be no enrichment at Fordow. There will be no fissile material at Fordow--

### Scientific Advocate (SA)
Claim: There will be no enrichment of what? There’ll be no enrichment of what?

### Conspiracy Advocate (CA)
Claim: --of uranium, which is how you make a nuclear weapon.

### Scientific Advocate (SA)
Claim: But there will be enrichment of what? There will be enrichment of what?

### Conspiracy Advocate (CA)
Claim: And still

### Scientific Advocate (SA)
Claim: Can you make a nuclear weapon--

### Moderator
Claim: Yeah.

### Moderator
Claim: And that concludes round two-- of this Intelligence Squared U.S. Debate-- where our motion is, “Obama’s Iran Deal is Good For America.”

### Moderator
Claim: Sorry, sir. We ran out of time because, I don’t know if you’re on this guy’s side, but he just took your time up.

### Scientific Advocate (SA)
Claim: He was. That’s my plant.

## Round 3

### Moderator
Claim: Our motion is, “Obama’s Iran Deal is Good for America,” and that concludes round two.

Now we move on to round three. Round three will be closing statements by each debater in turn. They will be two minutes each. Remember how you voted? Immediately after they conclude their statements, we’ll have you vote again, and then we’ll have the results within about a minute and a half. So round three, closing statements by each debater in turn. The motion is, “Obama’s Iran Deal is Good for America.” Here to summarize his position supporting this motion, Tom Pickering, a former undersecretary of state and U.S. Foreign Service career ambassador.

### Conspiracy Advocate (CA)
Claim: I want to take you to two stories that I think are important and throw light on this question. Two years ago a few of us met with then the leading Iranian negotiator. He said to us frankly that “For eight years we have been in the doghouse. Ahmadinejad put us there, and we’re now coming out. We will come forward with a set of ideas and principles for the negotiation that will deal effectively with the problem of your suspicion about our nuclear weapon. And we will accept inspections, a wide variety of them. And we want sanctions relief. And if we cannot achieve this with you in a reasonable period of time, we won’t be back.” And that’s, in fact, what has happened, interestingly enough. And that’s where we are now.

A second story: Two weeks ago I had the opportunity on successive days to hear again from the lead negotiators on both sides. And as Philip mentioned just a moment ago, each one of them said to us, “This is a good deal for the following reasons,” and the Iranian reasons were, guess what, quite friendly to the Iranian point of view and ignored the question of the major negotiating concessions they had to make. The Americans were less so but, nevertheless, reflected their view.

But when I sat down just as the Belfer Center sat down, I could not find any reason to believe that what they had said was so inconsistent that, in fact, we didn’t have a deal very close to in hand, and that nothing contravened the framework.

We now have a new opportunity in the region, but we have a new opportunity first with Iran now, to stop any effort toward a nuclear weapon. So, I urge you to vote “Yes” when the time comes, to support this arrangement. It is, in my view, the answer to this difficult problem.

### Moderator
Claim: Thank you, Tom Pickering. The motion is “Obama’s Iran Deal is Good for America,” and here to summarize his position against this motion, Mike Doran, a former National Security Council Senior Director for the Near East and North Africa.

### Scientific Advocate (SA)
Claim: Wishful thinking among highly intelligent and experienced people is a very common thing. Just remember all of the very intelligent investors who put their faith in Bernie Madoff.

The men sitting over here are intelligent, and they are experienced, and they are engaging in the worst kind of wishful thinking, as is the White House. It calls to mind Ronald Reagan in 1987, when he appeared before the American people and he said, “Three months ago I told you that I didn’t trade arms for hostages with Iran. Today, my heart and my best intentions still tell me that that is true. But the evidence has shown that actually something else is true. I did trade arms for hostages.” Now, who traded the arms for hostages? Who was involved in that deal? You may recall, for those of you who are old enough, that Bud McFarlane, the former National Security Advisor, and Ollie North, of the Iran-Contra scandal, went to Iran with a plane-load of weapons. And they delivered it to the Iranians.

And in return, the Iranians gave up hostages that were held by Hezbollah in Lebanon. What was the thinking behind it? The thinking behind it was “We’re not trading arms for hostages. What we’re doing is we’re finding the moderates in Tehran. We’re making-- we’re reaching out across the political divide with them, and we’re going-- we’re going to create a new relationship.

Now, Ollie North wakes up and bites off the heads of snakes for breakfast. Bud McFarlane was a former Marine. Ronald Reagan was a very experienced politician. And he had this fantasy of finding the moderates in Iran and coming to an agreement with them. And he got led down the garden path and made a fool of himself. The exact same thing is happening now to the-- to the Obama Administration. There’s a fantasy in the American national security elite that across the Persian Gulf, there is this ally in waiting. And if we just embrace it properly, everything is going to get better.

### Moderator
Claim: Mike Doran, thank you very much. Your time is up. Our motion is “Obama’s Iran Deal is Good for America.”And here to summarize his position favoring the motion, supporting the motion, Phil Gordon. He’s former White House coordinator for the Middle East, North Africa, and the Gulf region.

### Conspiracy Advocate (CA)
Claim: So, this has been a good debate. And we’ve had a bit of fun with it. But the truth is, it’s a very serious topic. And I have a lot of respect for a lot of the arguments that we’ve heard. As you sit here and think about how you want to vote, whether you believe this deal is good for America or not, I would ask you to imagine not that you’re just sitting here and you get a free vote as a citizen, but you’re the president of the United States. And it’s June 30th. And your team has come back and said, “Mr. President, Madame President, it’s been really hard, but we got the framework that we’ve talked out. Well, we’ve got it. Now you just have to decide if it’s good for America or not.” Now, maybe Mister, Madame President-- Mike and Mark have persuaded you it’s not good for America and you should reject it. And if you do, maybe we’ll put on more sanctions, and somehow the world will follow us, even though we walked away from the agreement.

And maybe Iran will then come back to the table and agree to zero or 500 centrifuges. And maybe they’ll get rid of their heavy water reactor anyway. And maybe they’ll accept anytime, anywhere inspections, including military bases. And maybe they’ll recognize Israel and stop terrorism. Maybe all that will happen, speaking of fantasies-- because you thought this deal wasn’t good and you rejected it, and you hoped all those things would happen, Mister, Madame President. On the other hand, maybe we’ll walk away. We won’t be able to keep the international sanctions coalition together. Iran will start resuming all of those things it stopped doing with the joint plan of action, stockpiling 20 percent uranium, spinning 10,000, 19,000 centrifuges and more, finishing the heavy water reactor at Arak. And at that point, you-- and think about this very seriously-- will be faced with a choice. Either you acquiesce and let them finish that heavy water reactor and build more centrifuges, or use military force to stop it, which would have all sorts of other consequences in the region.

That’s what I’d ask you to think about when you decide if this agreement is good for America or not. I would suspect that--

### Moderator
Claim: Thank you, Phil Gordon.

### Conspiracy Advocate (CA)
Claim: --if we got to that point--

### Moderator
Claim: Thank you, Phil Gordon. Your time is up--

### Conspiracy Advocate (CA)
Claim: --the deal you walked away from would look very good indeed.

### Moderator
Claim: Thank you, Phil Gordon. Our motion is “Obama’s Iran Deal is Good for America.” And here to summarize his position against the motion, Mark Dubowitz, executive director of the Foundation for Defense of Democracies.

### Scientific Advocate (SA)
Claim: Phil and Tom, it’s been a real pleasure. And I want to thank you both for your great service to our country. I-- two years ago, I went to see someone in the White House. That’s when the White House would still see me. And I met a senior White House director there. And at the beginning of the meeting, he said to me, Mark, I want to be very clear before we start this discussion on an Iran deal, that no deal is better than a bad deal. And I said to him, “I understand this. I think President Obama just said that last week.” And he said, “Absolutely. I want to reiterate no deal is better than a bad deal.”We spent about an hour and a half debating the emerging Iran deal. And at the end of it, he was showing me out of his office. We were walking down the hall, and he turned to me, and he said, “Mark, I just want to be clear. As I said at the beginning of our discussion, that a bad deal is better than no deal.” Now, that’s what’s known in Washington as a gaffe. A Washington gaffe is when the White House tells you the truth. And I think that’s where we are at today. We are at, today-- and you’ve heard the argument from Phil. You’ve heard the argument from Tom. That really a bad deal is better than no deal. But the fact of the matter is that the fallacy of false alternatives? There is an alternative to a bad deal. It’s not no deal. It’s a better deal.

Our side outlined seven specific ways to make this deal better. They are not fictions. They are real alternatives. Without go anywhere, go any time inspections into military bases, we’ll have no way of knowing whether the regime is developing warheads.

Without the ability to actually meet the scientists that have been involved in this and see the documentation and get into the Parchin site that is currently being blocked and sanitized, we’ll have no way of creating a baseline for a proper verification and inspection regime. And without effective, peaceful snapbacks, economic leverage that helps us actually respond to Iranian cheating and challenging. We will only be able to respond using military force. If you believe that economic seduction will change the hard men of this regime, then you should support their side. If you believe that this terror sponsoring, holocaust-denying--

### Moderator
Claim: Thank you, Mark Dubowitz, your time is up.

### Scientific Advocate (SA)
Claim: cheating regime--

### Moderator
Claim: We can see where you’re going. Thank you.

And that concludes round three of this Intelligence Squared U.S. debate where our motion is “Obama’s Iran deal is good for America.” And now it’s time to learn which side you feel has argued the best. We’re going to ask you here in New York once again to go to the key pads at your seat and register your vote a second time. Remember to push number one if you’re for the motion, two if you’re against, three if you became or remain undecided.

The motion: “Obama’s Iran deal is good for America.” Sir-- I just wanted to say to the gentleman who was all set with the mic to stand and ask a question. I’m so sorry. I wasn’t teasing. So maybe afterwards you can come down and chat with the debaters and put your question to them. You just won’t-- you just won’t be on the podcast but--

### Moderator
Claim: That’s all we provide here.

### Scientific Advocate (SA)
Claim: He’s a--

He’s a published author on this topic.

### Moderator
Claim: Oh, is he? Oh, well, I’m sorry. I just want to say this. This debate was fantastic. And these guys were-- You know, that was hard and relatively technical and--

### Moderator
Claim: It’s a great audience.

### Moderator
Claim: Isn’t it? It is a great audience. With very good questions.

But I appreciated that it was fairly technical and yet you made it accessible. And that you responded to the bell. And I appreciate that as well.

### Scientific Advocate (SA)
Claim: Just not the way you wanted to

### Moderator
Claim: I want to thank everybody who got up and asked a question because the questions were all great tonight. They really moved the debate along, so thank you for that.

I want to thank-- something I’ve been saying at the end of every debate, and I want to say it with full sincerity. I want to thank the people who are supporting Intelligence Squared. We are a philanthropy, and we have some key supporters, but we actually rely on a much broader basis of supporters. And we encourage you, if you had a good time, I want to let you know that the ticket price doesn’t come close, even close to what it costs to mount one of these. And so we encourage you, if you’re in the spirit, to go to our website and make a contribution. And our website is iq2us.org. You can even do it from your seat right now. Oh, I see everybody moving to their phones. Think about it.

This is the last debate of our spring season here in New York, but next week we’re going to be on the road in Philadelphia. It’s June 2nd. We’ll be at Philadelphia’s National Constitution Center. And what we do when we’re at the National Constitution Center, it’s a special series. We look at issues but through a strictly Constitutional arguments. So if you happen to be there, it’s a fascinating way to hear these arguments. We work with Constitutional scholars who, like these gentlemen, also bring that complex issue down to an understandable level. The issue we’re going to be looking at is the Constitutionality of same-sex marriage and states’ requirements or lack of requirements to license them. Tickets are still available through our website, iq2us.org. Also, we’re going to be, this summer, in Aspen. We’ll be partnering with the Aspen Strategy Group. That’s August 9th, and our debate is going to be on ISIS. And we’ll be back here. September our season starts again, our fall season.

We’re putting it together, but we’ll announce the lineup this summer. But you can check on our website, and you’ll get our eblast. And the other thing is to let you know about our app. It’s downloadable through the Apple store and through the Google Play store. And the app has all of the debates we’ve ever done, both as a podcast and as-- you can watch the video. You can look at the research that goes into the debates is there. You can pose questions. You can suggest debates. And a bunch of debates that we’ve been doing lately have come from audience members, so we take those seriously. So we really would love your participation on all of those levels.

Okay. So it’s all in-- and remember I asked you to vote twice, once before the debate and once again after the debate on this motion: “Obama’s Iran deal is Good for America,” and the team whose numbers change the most between those two votes will be declared our winner. Let’s look at the first vote on this motion, “Obama’s Iran deal is Good for America.” Thirty-seven percent agreed at the outset. Nineteen percent were against at the outset. A large 44 percent were undecided.

So, those are the first votes. You remember, it’s the team whose numbers move the most and between these two votes.

So in the second vote, the team arguing for the motion, their second vote was 50 percent. That means they picked up 13 percentage points. That is the number to beat. Let’s look at the team against the motion. In the first vote, they were 19 percent. Their second vote went up to 43 percent. That’s a 24 percent increase. That team wins. The argument is defeated. The motion is defeated by the team arguing against. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We’ll see you next time.
