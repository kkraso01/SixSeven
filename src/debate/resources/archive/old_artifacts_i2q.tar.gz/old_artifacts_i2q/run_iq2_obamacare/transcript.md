# Debate Transcript

Topic: Repeal Obamacare
Motion: Repeal Obamacare

Debate ID: obamacare


## Round 1

### Moderator
Claim: And now to open what is our spring season of our fifth year of Intelligence Squared U.S. the chairman of the organization that makes it all possible, Mr. Robert Rosenkranz.

### Moderator
Claim: Well thank you all. Thank you all for braving the weather to come and for joining us tonight. You know I do have in addition to my role on Intelligence Squared a day job and it’s running an insurance company which gets around two percent of its premiums from medical insurance. So this debate is not very material to our business but I thought I should share that fact with you in the interest of full disclosure. You know, I also want to share some of my own insurance expertise as it relates to tonight’s motion. What seems clear to me is that healthcare costs are out of control.

They amount to around 16 percent of the U.S. economy compared to nine percent in other rich countries. Health costs have been a major drag on employment and growth and have jeopardized the financial position of the federal government, state governments and frankly we have no better health outcomes to show for these costs. In considering the arguments of our panelists tonight, you might want to think about the effect of this bill on costs. There is a credible argument that the bill makes a serious effort to address Medicare costs in particular. After all, some 30 percent of all healthcare costs in America are incurred in the last hundred and eighty days of life. Some Republicans, by the way, have been quite disingenuous about this, raising the specter of “death panels” and World War II vets languishing without appropriate care.

But another major driver of out-of-control costs are tort lawyers, medical malpractice insurance premiums and especially the defense of cover-you-rear medicine that they foster. Democrats, traditional allies of the tort bar, have hardly been forthright about this aspect of the situation. Another factor is that consumers of health care generally have little incentive to control costs. Why should they economize if insurance companies are paying? Most insurance covers things you can’t budget. Car insurance doesn’t cover oil changes. Home owners insurance doesn’t cover a soiled rug. But when it comes to health insurance, we expect coverage of every conceivable medical benefit. Most insurance policies are priced to reflect risk. Teenagers pay more for auto insurance. Smokers pay more for life insurance and so forth.

But for health coverage, most states have mandated that everyone in the community pays the same. What this means is that healthy young people pay excessive premiums they can’t well afford in order to subsidize their better-off but more illness prone elders. They often quite rationally elect to not buy the over-priced coverage. This bill would force them to do so. But whether requiring someone to purchase something they don’t want is even constitutional will surely be touched on in tonight’s debate. So in considering the arguments you’ll hear this evening, I encourage you to listen with the following kinds of questions in mind. Does the bill address unproductive and undignified end-of-life care? Does it rein in tort lawyers to discourage defensive medicine? Does it encourage us as consumers to care about what we spend?

Does it provide appropriate incentives for healthy life styles and preventive care? These are not rhetorical questions. But they’re very complex just like the bill we’re discussing. We have a stellar roster of panelists to help illuminate these issues and it’s now my pleasure to turn the evening over to them and to our moderator, John Donvan. Thank you very much.

### Moderator
Claim: Thank you. Thank you, Robert. And I would just like another round of applause for Robert Rosenkranz. Two words, “Repeal Obamacare,” that is our motion. That is what we are here to debate. I’m John Donvan of ABC News at the Skirball Center for the Performing Arts at New York University and on hundreds of NPR stations across the nation for another debate from Intelligence Squared U.S. “Repeal Obamacare,” and to debate this motion we have a congressman, presidential advisers, and a man who has written more about the topic than anybody, I think we can say literally.

And in this debate, we want you to listen carefully because you are a live audience. You act as our judges. By the time this debate has ended, you will have been asked to vote two times, once before the debate and once again afterwards. And the team that has been most persuasive, that has changed most of your minds will be declared our winner. So let's go to our preliminary vote. Go to those key pads at the right hand side of your seat. Our motion is "Repeal Obamacare." And if you agree with this motion, push number one. If you're for repeal, it's number one. If you disagree, it you are against repeal, it's number two. If you are undecided, it's number three. And if you feel that you've made an error, just correct it, and the system will lock in your last vote. And you can ignore the other keys.

All right. We're locking out the system, and we will present the results of both votes at the end of the debate.

So on to round one. Our motion is it "Repeal Obamacare." And first, to argue for this motion, for repeal, I'd like to introduce John Shadegg, a congressman from Arizona. Let me say, former congressman. After eight terms, John Shadegg decided to step away from the job which is not something that a lot of people in your position-- actually, he tried twice. The first time-- the first time your fellow Republicans asked you not to leave.

### Conspiracy Advocate (CA)
Claim: That's true.

### Moderator
Claim: Finally, you got away, John. And they liked your rhetoric, which included on this topic a reference to the Obama reform program as Soviet style gulag healthcare. I want to say, come now. Hey. Do you stand by that?

### Conspiracy Advocate (CA)
Claim: No. I think that it is a-- it is a part of the dialogue that you try to get attention. And that was an attempt to gather some attention.

### Moderator
Claim: And it worked. We'll see what else you have to say tonight. Ladies and gentlemen, John Shadegg.

### Conspiracy Advocate (CA)
Claim: Thank you very much, John. And thank you to the audience. You play a key role here tonight. I want to thank Intelligence Squared for sponsoring this debate. And I want to recognize my opponents, one of whom has written more than anybody else in the world on this topic. And most of all, I want to thank my debate partner, Douglas Holtz-Eakin, former CBO director and a senior policy advisor to Senator John McCain. My partner, Douglas Holtz-Eakin is a numbers guy, and he will focus on the numbers. And I believe he will be able to clearly show you that Obamacare both won't work and perhaps more importantly, will put a critical strain on our nation's fiscal stability. Let me begin, however, by refuting two arguments. First, supporters of Obamacare will say that Republicans simply don't believe in healthcare and indeed that they favor the status quo. That is simply wrong. I believe in my tenure in Congress I had written more healthcare reform bills than any other member of Congress. I wrote a number of patients rights bills in the early debate.

But I was also joined throughout this with the help of Paul Ryan and Tom Coburn and Jim DeMint and Richard Burr and Dr. Tom Price and Dr. Burgess and on and on. And you would find countless proposals by Republicans to reform our nation's healthcare.

Second, supporters of Obamacare will tell you that it will actually save the government money. And they will tell you that repealing it will cost the government money. Now, Douglas Holtz-Eakin will demonstrate with the numbers that those claims are unfounded. But I urge you to begin by just looking at this question with common sense. Obamacare insures roughly 32 million additional Americans, most through Medicaid. That will increase costs. It creates a massive new bureaucracy, some 150 plus agencies and bureaus. That's got to increase costs. And it extends dramatic new mandates over health insurance in America. And that will increase costs.

Now, let me move on to one point that I think is very important to understand.

The current system is in fact broken. As I said, I have written numerous bills to try to fix it. Costs are way too high, and they're going up too quickly. There are too many uninsured and too many Americans have pre-existing conditions and cannot get affordable coverage. I have a pre-existing condition, and I have an older sister who has-- who is a breast cancer survivor, probably the worst kind of pre-existing condition.

One aspect of the current system is in fact indefensible. It's the provision that says your employee-provided care is tax free. It costs them no taxes and you no taxes. But it punishes those without employee-provided care. Indeed, it tells them, we want you to get insurance so much we're going to force you to pay for it with after-tax dollars, making it a third more expensive. That is simply outrageous and indefensible. And stunningly, Obamacare does not fix that problem.

Obamacare is simply the wrong answer. First, it addresses symptoms, namely the uninsured, which are too high.

But it does not address, I do not believe appropriately, certainly not with incentives, cost.

Second, it will not only increase the cost to the government, but it will drive up your premiums. And the experts agree on that point. It moves-- and perhaps this is most important--healthcare decision making away from employers and the insurance companies they hire, and they're making lousy decisions, and they shouldn't be deciding. But it doesn't give those decisions to you and me. It gives them to the government.

What we need to do is take decision making away from employers and insurance companies and give it to people. Give it to patients, individuals and their families, and let them consult with their doctor and make those decisions. Republican proposals in Congress do exactly that. Why? Because if the health insurance is yours, not your employer's and not the government's, it's personal, and it belongs to you. You can make the changes.

You aren't trapped in a plan your employer picked. You can force the insurance companies to compete, which they don't do now. You can hire the plan of your choice. And because it's yours, you can fire it, meaning you can hold it accountable to you.

Briefly, let me touch on why Obamacare will drive costs up. By its terms, Obamacare institutes lots of mandates. One is guaranteed issue, meaning nobody can be turned down. That will increase cost. One is modified community rating. That will increase costs. And a third is an array of new benefit mandates. All of those will increase costs. Indeed, in every state, with guaranteed issue and community rating, and in every state where they mandated more and more benefits, costs have gone up dramatically. In Massachusetts, after adopting a plan very similar to Obamacare, costs have continued to go up at a rate faster than the national average.

Let me touch on some of Obamacare's broken promises.

The president told us over and over, and quite frankly, over again, that if you like your plan, you can keep it. Not true. He said if you like your doctor, you can keep it. You can keep him or her. Not true. And he said that Obamacare would send the cost curve down. None of those promises, as we examine the plan, turn out to be true. The Medicare actuary has already estimated that some 14 million people will lose their current coverage. Leading experts say few plans will actually survive. How could they survive? They have to meet benefit mandates that haven't even yet been written.

In fact, thousands of Americans will lose their employer-provided healthcare because their small employer or large employer cannot afford to continue to offer it. They will lose their healthcare. AT&T, a study was done and provided to the commerce committee that showed AT&T will save $2 billion, $2 billion if they cancel their employees' care and pay the fine.

John Deere will lose $150 million a year. Caterpillar, $100 million a year. 3M, $90 million a year. The numbers go on and on. Those employers will have no choice to their stockholders but to drop that care. They'll be forced. And think about their workers. Their workers will lose their current plan, and they'll lose their doctor. We simply have to do better than that.

The new, indeed, one provision of the law is outrageously unfair, as unfair as the tax code is now. It provides, in the new healthcare exchanges, that if you are uninsured, or if you buy in the individual market, you can enjoin the exchange. And if you join the exchange, you can get a government subsidy. But if you have employer-provided care, you cannot join the exchange. That simply isn't fair because it means the cost of your care is subsidized, some with the exact same income cannot get subsidized care.

Thank you very much.

### Moderator
Claim: John Shadegg, your time is up. Thank you very much.

### Conspiracy Advocate (CA)
Claim: Thank you very much.

### Moderator
Claim: Thank you, John Shadegg. We're debating a motion, "Repeal Obamacare" in this Intelligence Squared U.S. debate. And now to argue against the motion, Paul Starr, who is a professor of sociology and public affairs at Princeton. He's a Pulitzer Prize winner for his book on healthcare called “The Social Transformation of American Medicine.” Paul, you also were an advisor to President Clinton the first time the Democrats tried to pull off a major reform and failed. What got right this time that you got wrong last time to at least get the act-- get the law passed?

### Scientific Advocate (SA)
Claim: Well, I think one of the big differences this time was more consensus. Might seem strange in the light of what Congressman Shadegg has said, but more consensus among Democrats in Congress, consensus between the White House and Congress, more consensus also with the stakeholder groups in healthcare who realize that the current course is unsustainable, that we need to change and--

### Moderator
Claim: Well, let me let you get launched on your seven minutes.

### Scientific Advocate (SA)
Claim: Okay, well, because--

### Moderator
Claim: I feel like I should deduct.

### Scientific Advocate (SA)
Claim: All right.

### Moderator
Claim: I'm joking. Ladies and gentlemen, Paul Starr.

### Scientific Advocate (SA)
Claim: Thank you. We should uphold the Affordable Care Act because it is morally the right thing to do and it is in our common interest. And when I first began work on the healthcare back in the 1970s, the official number for the uninsured was 26 million, 12 percent of the population. By the early '90s, it was up to 37 million. Now it's reached 50 million. And if we were to do the kinds of things that the Congressman has advocated, the number will go higher. Fifty million, that's already a lot of people for whom illness is devastating, who may lose everything they have because of illness. For years surveys have shown that anxiety about not being able to pay for the healthcare you need ranks at the top of Americans' anxieties.

And Americans are more likely-- much more likely than people in the other rich democracies to put off getting medical care for fear of the cost. Still, the majority of Americans, and I guess most of the people here tonight, do have insurance, and it's tricky to figure out how to help the millions who get a raw deal while protecting the interests of those who already have protection. The Affordable Care Act is an intelligently crafted effort to do that. It extends coverage in two ways, by expanding Medicaid for poor people who've been cut out of that program, and by creating insurance exchanges where other people can easily and efficiently buy a private insurance plan under a new set of rules that, for example, prevent insurers from excluding preexisting conditions, and where subsidies are available to keep the premium for a medium leveled package at no more than eight percent of income.

Now, the insurance exchange is not just a hypothetical concept. Massachusetts has a working exchange, The Health Connector, adopted as part of the reforms introduced by Governor Mitt Romney and passed overwhelmingly by both parties. If you move to Massachusetts, you can use The Connector's website and, in half an hour, sign up for an insurance plan, no broker's fees, no hassle. No wonder brokers don’t like the idea of the insurance exchange but we don’t kill off Expedia or Travelocity for the sake of the travel agents, do we? And currently, if you buy coverage individually or through a small business, and if we all bought coverage individually the way the Congressman wants, 30 cents or more out of every premium dollar gets sucked up in administrative and marketing costs. The exchanges are just one way the reform squeezes out costs from the system. In regard to coverage, the Affordable Care Act is modeled on the Massachusetts reforms.

It does a lot more on cost containment, and far from being a government takeover, the program aims to create a better functioning market for private insurance. The origins of this idea go back to old Republicans-- Republican proposals, to a plan that Richard Nixon proposed in 1974, and to a bill introduced by Senator John Chafee, with 20 Republican cosponsors, back in 1981-- 1991, a bill by the way that had an individual mandate in it. And substantively, the Affordable Care Act is bipartisan legislation. We just don’t happen to live in a bipartisan political era. Consider the law's moderate responsible approach to financing. The basic idea is to find most of the money to expand coverage from within the healthcare system. We spend enough on healthcare, we just don’t allocate it well.

Healthcare providers and insurers will get more than 30 million new paying customers, and since the law's purpose is not to provide them with windfall profits, it claws back some of the revenue, for example, by reducing the future growth in Medicare payments, and by cutting excessive payments to private Medicare plans. The law also imposes a tax on high cost health plans that really should bring a smile to Douglas Holtz-Eakin because he defended a proposal that was functionally identical when he was John McCain’s Health Policy Advisor. Our Republican friends will tell you that this legislation will explode the deficit, even though the CBO tells us it will reduce the deficit. Now, Jon is my partner in this. Jon Cohn is going to talk more about cost. But while you're listening to the other side, please bear in mind that when Bill Clinton left office we were looking at a $3.1 trillion surplus back then.

And Bush came in, cut taxes, passed a Medicare prescription drug benefit with no financing, sent us to war in Iraq without taxes to pay for it and, of course, the deficit exploded. It exploded on their watch leaving us in the end with a financial crisis and the great recession. What happened to health care costs in that period, in the years between 2001 and 2006 when Republicans had control of both the White House and Congress? What did they do about health care costs? Here are the facts. Family health insurance premiums went up 87 percent compared to 20 percent increase in general inflation and a decline of three percent in real median household income. Faced with a potential death spiral in the individual and small group markets, many of the interest groups that opposed healthcare reform in the past, the American Medical Association, the hospitals, the for- profit hospitals, too, even many of the insurers decided that the current situation had to be changed.

And that’s why we got legislation in 2010 and not just because of the Democrats but because so many in healthcare saw it was wrong and worked to make it-- to change it. Now just a word on Mr. Shadegg’s proposals. We have low-regulation states, states that don’t regulate the insurance industry. His own state of Arizona is one of those states and their costs are just as high as elsewhere. Arizona has 20 percent uninsured. The high deductible insurance policies combined with tax-advantage savings accounts that he and other Republicans favor and put into law haven’t shown any sign of reducing costs or extending coverage. They are, however, a great tax shelter and in fact if you’re in a high tax bracket, it’s great to have a health savings account.

You can put money in the account, don’t even use it for healthcare and withdraw it after age 65 without penalty. So those are proposals that are great for people who are healthy and well-off. They just don’t happen to do much for the low-income workers and the others who really face the difficulties in paying for healthcare.

### Moderator
Claim: Sir, your time is up. Thank you very much. We are halfway through the opening round of this Intelligence Squared U.S. debate. I’m John Donvan of ABC News. We have four debaters, two teams of two, who are fighting it out over this motion, “Repeal Obamacare.” You have heard from the first two debaters and now on to the third. To argue for the motion, to argue for the repeal of Obamacare, I’d like to introduce Douglas Holtz-Eakin, who is president of the American Action Forum. He was with the McCain campaign as an adviser and in his critiques of the Obama health plan, came up with the telling phrase, “fantasy in, fantasy out.”I believe that’s yours. You own that. You also--

### Conspiracy Advocate (CA)
Claim: Not very profitable but I own it.

### Moderator
Claim: Yes. I also learned through Google another delicious fact-- you were a good sport about it-- but after leaving the McCain campaign, you couldn’t get health insurance for some time.

### Conspiracy Advocate (CA)
Claim: Not exactly right but I have a pre-existing condition. Actually, I have two kidneys on my left side from some extensive work before the 21st Century and I was left on COBRA coverage and the solution, of course, is to start your own employer so I started a think tank to get insurance.

### Moderator
Claim: So you’re covered.

### Conspiracy Advocate (CA)
Claim: I am covered.

### Moderator
Claim: You took it the hard way. Ladies and gentlemen, Douglas Holtz-Eakin. Thank you.

### Conspiracy Advocate (CA)
Claim: So thank you very much for the chance to be here tonight to our sponsors and to our opponents. You know, I’m going to ask you to support the motion but in the end, you’ve all realized that what we’re debating tonight is about getting healthcare reform in the United States because there is no dispute about the need for healthcare reform.

My own history, John’s history, probably the histories on the other side of the table of which I’m unaware are stark tribute to the need to do things better in the United States. Real healthcare reform has two pieces. Number one, it extends healthcare coverage to Americans, gives them options for insurance and insurance is a product which shifts around the cost of your healthcare. In the end, an insurance system takes the nation’s health care bill and shifts around who picks up the ultimate cost, moving it from some people who are unable to shoulder the full burden of the cost of their care to some others who may be able to. The second piece, the piece that drives everything, is the overall healthcare bill. And the United States has a health care bill which is far too large and certainly far too large for what we get. At one-sixth of our economy, it’s one of the most inefficient pieces of economics that one could imagine. And the key fact to remember in thinking about this debate is that over the past four decades. If you look at income per person in the United States and healthcare spending per person, the resources versus the costs, costs have been winning at two to two and a half percentage points every year for four decades.

Republicans, Democrats alike. It is the costs and the spending on healthcare that ultimately has to be covered by insurance premiums. And if you don't control costs, you cannot control insurance premiums, and you cannot deal with extending coverage to Americans, which is ultimately what real healthcare reform is about. I favor repeal because this reform flunks the test of healthcare reform. It does not deal with the cost problem.

Now, I don't need to say so. Many people, far more qualified than I, have said so. The Congressional Budget Office, in the aftermath of passage of the Affordable Care Act, put out its new long-term care-- or its new long-term budget projections. Did health spending in the federal budget grow more slowly as a result of this? No, it does not.

You can look at the CMS actuary, the administration, the Obama administration's own chief actuary, Richard Foster, who estimates that the affordable care actually will raise national healthcare spending, not lower it, and will actually endanger the future of Medicare, not make it more solid.

You can ask Jonathan Gruber. Jonathan Gruber is one of the architects of Obamacare. He's one of the architects of the Massachusetts reform on which Obamacare was founded. And in his article in the Journal of Policy Analysis and Management, he says, “This isn't about cost reform. This is health insurance reform. There's nothing in it. Much like Massachusetts, it's just about covering people. It doesn't control costs.” And you can look at the experience in Massachusetts where, prior to reform, Massachusetts had costs that were 25 percent higher than the national average. And after reform, they were at 30 percent higher than the national average, no improvement in the fundamental requirement of healthcare reform.

So we need to get the healthcare reform. And without that, we will never control the budgetary costs that threaten our nation.

Now, I'm a former CBO director. It is my obligation to stand up in public and say apocalyptic things about the budgetary future. I'll spare you the numbers tonight because I like you more than my children. But the bottom line is this nation, looking forward-- forget re-litigating the past. Mr. Starr is good at that. But looking forward in the administration’s budget 10 years from now, after the financial crisis is in memory, after we’re soon to be out of Iraq, out of Iran, after the economy is back at five percent unemployment, we are running a deficit of a trillion dollars. Nine hundred billion of it's to pay interest on previous borrowing. We are headed to that magical position where we're borrowing to pay previous borrowing and nothing else. Along the road, we will pass the criteria for downgrade as a sovereign nation. We will no longer be a top- rated borrower.

This act makes that situation worse, not better. It says that two new open-ended entitlement programs that will grow, according to CBO, at eight percent a year, as far as the eye can see, the economy is not going to grow at eight percent. Revenue's not going to grow at eight percent.

The only way you could make that kind of a move add up budgetarily is smoke, mirrors and gimmicks. And that's what the Affordable Care Act is riddled with, in which the CBO was forced to acknowledge in its score. If you give them handcuffs, they'll come up with any answer that you might want.

So we can't afford this as a nation. It is dangerous because it doesn't control costs. It's not really healthcare reform. You need to vote for healthcare reform, not Obamacare.

One sixth of our economy is underperforming. If we care about economic performance, we should repeal Obamacare. Forget the mandates, forget the taxes. We had a system that was broken to begin with. One-sixth of our economy is broken. Why not fix it instead of writing checks and papering over it?

But you hear some other arguments from the other side, the popular ones, now, the issues of fairness. Let us stipulate this is one of the most unfair pieces of legislation ever passed. There are the inequities between two people similarly situated, making $70,000.

One's going to get $7,000 in federal subsidies, 10 percent of their income. The other's going to get zip. That is grotesquely unfair. And if any future Congress acts pass one, it'll get solved in a nanosecond. They'll give everybody the money. And my first problem will blow up even worse. Terrible idea. And for every young person in this audience, this is a disaster. Through the individual mandate you'll be obligated to be in the pool. The purpose is to put you in there to pay the healthcare bills of people who are older and sicker than you. And at the end of your life, you get to pick up the debt that's been incurred through Obamacare. You'll get it at the front end. You'll get it at the back end. It is one of the most inter-generationally unfair things that has ever been scripted by the United States Congress. Should be repealed on those grounds alone.

There are other sort of detours along the way. The insurance companies, that's where all the costs come from. Oh, my God, there are administrative costs. There are profits. The top 10 insurance companies in 2009 made $260 billion. That's a lot of money. I'd like to have it. The cost growth problem every year is $175 billion. So go for it.

Nationalize the insurance companies, confiscate their profits. You get about a year and a half's worth of relief, and we're right back where we were. This isn't about insurance companies. This is about fundamental changes to the delivery system so that we coordinate care so that we deliver high quality care at lower costs. And the greatest missed opportunity here was the chance to fix Medicare, which is at the root of our problems. Medicare pays doctors. It pays hospitals. It pays some insurance companies, and it pays drug companies. And it has silos to pay them all. And nowhere in there can you find a beneficiary. Nowhere in there can you get coordination of care. Nowhere in there is the kind of healthcare Americans deserve. We should fix that first. We should repeal this now. Thank you.

### Moderator
Claim: Thank you, Douglas Holtz-Eakin. Our motion, "Repeal Obamacare" and our final speaker in opening statements to speak against the motion, Jonathan Cohn who is a senior editor at the New Republic.

He wrote a book called “Sick: The Untold Story of America's Healthcare Crisis,” which in some ways explains his evolution from pure journalist into advocate with these scores and scores of stories of people in dire straits that he reported and is very passionate about. You also had a blog throughout the debate called The Treatment. And you signed off, after the legislation passed, saying, and I quote you, "The debate has ended." So why are we here?

### Scientific Advocate (SA)
Claim: I like to think it's been a full employment act for people like me who write about healthcare.

### Moderator
Claim: Ladies and gentlemen, Jonathan Cohn.

### Scientific Advocate (SA)
Claim: Thank you. I want to thank the audience. I want to thank the foundation. I want to thank my opponents. I want to thank Doug Holtz-Eakin in particular for some of the comments he just made about the dire fiscal straits of the country, the importance of trying to get healthcare costs under control because if we don't get healthcare costs under control, we're not only going to bankrupt our government, we're going to bankrupt our entire society. And you know, I agree with all of that. I do.

Where we differ you may-- as you may imagine, is that I happen to think the Affordable Care Act, Obamacare, helps us in that regard. Now, you listened to this team over here. You've listened to their argument. And they painted a very dire picture of a program out of control that's going to cost more than anybody thinks. It's going to leave us all paying tons in insurance premiums. And you know, they have to paint an apocalyptic picture because I think the honest truth is most of us, when we hear that-- about the benefits of the plan, that we'll be able to guarantee coverage for people who have pre-existing conditions, the right to appeal treatments when their insurance company turns it down, subsidies for people who can't buy coverage now. People like that. They think that is a good idea. So they focus on this cost question. And, you know, during the healthcare debate, we had all this scare talk about death panels and other things that just were simply not in the with all due respect to my-- to our debating opponents here who I know have spent a lot of time talking about it, I think they're giving you, well, I don't want so say they're making things up out of whole costs but I think they're giving you a slightly, let's say, one-sided picture of things.

So I did two things here. First, I want to explain why I have faith that the Obama healthcare bill will in fact reduce costs. And I want to specifically go through some of the arguments they have made and tell you why they are misleading.

Now, why do I have faith that this healthcare bill will save money? I mean isn't-- Congressman Shadegg said, isn't it common sense that it won't? I don't think it's common sense. I look around the world. I look at countries like France and Germany and Switzerland and Japan, countries that get just as good healthcare as we do or better, people who have easier access to healthcare, and yet they spend less than we do. Now, is there something about the United States that we're not capable? We're not innovative enough? We can't do that? I don't think so. Certainly it is possible, certainly, to get excellent healthcare, cover everybody and save money. So the question is, will this bill do it? And I believe it will.

Let me take a second to explain how the bill is designed to do that. It has three basic approaches. One is to get the low-hanging fruit of healthcare, the waste. A lot of it's corporate welfare. Right now, for example, insurance companies that provide benefits through Medicare, study after study has shown that we pay them too much.

They're making too much in profits. So we say we're going to take some of that back. We're going to take back that corporate welfare.

Another source of offsetting revenue for the healthcare program is to go and ask people who have benefited the most from our economy, the people who are the very wealthiest in our society, to pay back a little more in taxes. And we get money from there. Now, I don't think either of those propositions are in dispute in terms of that those things will generate money to offset the costs of the healthcare plan. Now, they may not like those ideas. And that's fine. And maybe in the question and answer period they can tell us why they think we need to keep giving insurance companies corporate welfare. Why the richest people in this country, who are enjoying far lower tax rates than they had during the Clinton administration, can't afford to pay a little more.

But it's the third part of healthcare reform, the third part of cost control that's the most important. And this is where we really look at the way the American medical care system works. Everybody who is-- every expert left and right says we waste a ton of money in our medical care system.

Some of this is administrative waste because everyone's dealing with 10 different insurance companies. Some of this is duplicative treatments because Dr. A doesn't know what Dr. B is doing to patient C. Some of this is the fact that we pay tons of money for treatments that don't work. The Obama healthcare bill, what it does is it tries to attack those, and it tries dozens of different approaches, and it's not a liberal takeover, it is not something crazy extremists cooked up on one side, it's actually the best ideas of the left and the right. It's ideas like not paying hospitals if they run high rates of in-hospital infection. It's things like developing electronic medical records so we can keep track of what patients are getting as they move through the medical system. It's about giving financial incentives to doctors and hospitals that coordinate care and focus on prevention, and efforts like this that together, the smartest people have stated this, all believe will help control healthcare costs. Now, Douglas Holtz-Eakin got up here and said these numbers are crazy, that of course this is going to explode the deficit, and again, common sense, well, the most reliable authority we have on this is the Congressional Budget Office.

Congressional Budget Office is the gold standard of accounting. The CBO-- my reading of the CBO report is that they looked at the healthcare bill and they said, "You know what? This bill will reduce the deficit. It will reduce the deficit in the first 10 years, it will reduce it by a lot more afterwards." And by the way, the rate of growth in healthcare spending is going to start to slow down. Now, it is true that the CBO, you can say, "Well, the CBO ought to use these rules," or whatever. Well, what the CBO rules mean is that we are assuming that the laws that we have passed are going to be implemented, and that is the way-- and that is the way the government accounting system works. Douglas Holtz-Eakin says, "Well, that never works because we've never seen it happen." Well, you know what? It's happened before. During the late 1990s we tried to control costs in Medicare and we did for a while. We passed very large cuts to Medicare during the Balanced Budget Act.

It was the late 1990s, and you know what? Those cuts stuck, and we were able to reduce the growth of Medicare from where it would’ve been otherwise. It’s entirely possible to do this. Now, in order to do this you have to actually stick with a program. As my colleague mentioned, during the Bush administration they passed a different-- they tried to approach healthcare in a different way. They said, “All right, let’s try a different approach, and let’s have a healthcare bill, let's not pay the cost for it.” Well, that did increase the deficit, and that is the sort of choice we’re talking about facing here. Now, my colleague-- my opponent, Mr. Holtz-Eakin, cited a number of authorities he believed, and he said, “Well, John Gruber of MIT says this is not good,” or he said, “The CMS actuary said this." Well, in fact, if you look at the written record, the people-- the list of experts who have endorsed this, it’s not just the Congressional Budget Office, it’s people like David Cutler, a professor at Harvard University, who won the John Base Clark Medal for the most accomplished economist under 40.

It's people like Jonathan Gruber from MIT-- I know he quoted Jonathan Gruber-- Jonathan Gruber has said many times he endorses this bill. He thinks it's our best shot right now to get healthcare costs under control. It's people like Mark McClellan, who hasn said that he believes the Affordable Care Act will start to reduce healthcare spending, and why do we care about Mark McClellan? Because Mark McClellan ran Medicare in the Bush administration, and it’s people like the Simpson-Bowles Commission, the bipartisan fiscal commission said, "The cost control in the Affordable Care Act will be affected, and we need if anything to double down on it." This is not my opinion, it’s not some crazy opinion, it is in fact the opinion of the best experts of left and right.

Thank you.

### Moderator
Claim: Jonathan Cohn, your time is up.

### Scientific Advocate (SA)
Claim: Thank you.

## Round 2

### Moderator
Claim: Thank you very much. And that concludes round one of this Intelligence Squared U.S. debate, where the motion being argued is "Repeal Obamacare." Now, keep in mind how you voted at the top of the evening, because you’re going to be asked to vote again at the conclusion, and I want to remind you that the team that changes the most minds will be declared our winner.

So, now, on to round two where the debaters can address one another directly, and also take questions from me and you in the audience. I’m John Donvan of "ABC News." We are at the Skirball Center for the Performing Arts at New York University. We have two teams of debaters, two against two, who are arguing over this motion, "Repeal Obamacare." On one side, a former Congressman and former aide to John McCain are arguing that the plan passed by the Obama administration is going to blow up financially and will hurt America and is headed for the dust bin. Arguing against them, a former advisor to the Clinton administration and a journalist who has written extensively about healthcare, arguing that this act-- that this law should be preserved, and not only preserved, but built upon. I want to ask a question about philosophy. Both sides agree that the system we’ve lived with for the last 30 years, particularly in its last 15 or 20 years, is broken. You agree that something needs to be done. You're arguing over the solutions.

Your opposition on one side to the president’s program and you’re supporting the other side says what fundamentally about what you think we are as a nation, as Americans. I want to put that question first to you, John Shadegg, former congressman.

### Conspiracy Advocate (CA)
Claim: I’m thrilled to have that question because I think it’s vitally important. I think we’re already-- we’re a nation that does support taking care of those who can’t care for themselves. We’re a nation-- and my legislation covers every single American-- we’re a nation that thinks it’s outrageous that anybody would lose coverage because there are pre-existing condition like my heart condition or my sister’s breast cancer. But we’re also a nation that honors limited government and honors individual choice. I think on the one hand what you hear from the other side is that the government can manage this issue better. And what I would suggest to you is we are in this problem because the government made changes that took you and I out of the equation. The government said health insurance is available only if your employer buys it and you get a tax deduction.

But if you go out and buy it, it’s one-third more expensive. If you can’t hire and fire somebody’s who delivering a service to you, you can’t hold it accountable including its costs.

### Moderator
Claim: John, you’re saying there’s an issue of individual freedom here

### Conspiracy Advocate (CA)
Claim: Absolutely. The individual freedom is tied back to the cost of the service and because we can’t control it, you are controlling its cost.

### Moderator
Claim: Let me take your response to the other side, Paul Starr who worked for the Clinton administration.

### Scientific Advocate (SA)
Claim: I do think this is a question of our public philosophy and the obligations that we owe to one another. And it is, I think, a sad commentary on us that we remain the only advanced country that doesn’t provide protection to all of our citizens. Now the reason that we have-- let’s go back to why we have this employer-based system. If you don’t have government share, spread the costs of healthcare, there needs to be some organization that serves as the pool for risk.

And the employer is the most convenient way to do it. That’s actually why this first developed in the 1930s and ‘40s before we had the tax advantages. It’s simply going to default from the government to employers. It’s not as though the government took this away from individuals. That individual market that the Congressman loves is phenomenally inefficient.

### Moderator
Claim: But Paul, what about your opponents point that as a nation, philosophically as a nation, we’re defined by a commitment to limited government and that this program actually assaults that notion?

### Scientific Advocate (SA)
Claim: But it is a program, as I said before, that is trying to create a functioning market, a better functioning market than the one that currently exists. Those exchanges will give people choices that they don’t now have.

### Conspiracy Advocate (CA)
Claim: All the Republicans are arguing is that you ought to give that choice to people.

I do not favor individual purchase. That was the attack made against Senator McCain throughout the campaign and it was absolutely unfair. I favor a plan which says I as an individual can buy an individual plan, I can take my employer’s plan or I can buy from a whole group of expanded choices. We could have my social club. The Kiwanis Club can offer a plan. My university alumni can offer a plan. Give me that choice, force those insurance companies to compete. They don’t compete right now. They don’t care what you and I pay for health insurance and they don’t, quite frankly, care whether it treats us well. They only care that our employer bought the plan.

### Moderator
Claim: Jonathan Cohn. Jonathan Cohn, arguing against repeal.

### Scientific Advocate (SA)
Claim: Well, I would say I think all of us favor choice. Choice is a wonderful thing. We want to give choice. People who buy, I mean, we need to realize that the employer-- people who are getting private insurance are now divided into two groups. There are people who get it from their employers and there are people who buy it on their own. Neither of them has choices right now. You’re buying insurance on your own? Good luck buying a coverage policy.

You’re going to have trouble finding one, particularly if you have pre-existing conditions.

### Conspiracy Advocate (CA)
Claim: You’ve got to shop across state lines.

### Scientific Advocate (SA)
Claim: We’ll talk about that in a second. This Affordable Care Plan, what it does is it says, all right, let’s create a market, a real market, a place-- kind of like Expedia, like they have in Massachusetts now where everybody who’s buying one actually gets a choice of insurance programs, a set of plans that they know they can afford that will be made available to them regardless if they’re a cancer survivor and let all of those people shop. Meanwhile, employers who have insurance for their employees will continue to provide that. Look, at some point it is very easy to say we want to open up exchanges for everybody and let everybody shop. You can build on this system to do that. You can do that. But you’re never going to get to that system you’re talking about. You will never get to a system where people have choice and a choice of actual plans that are available to everybody, that cover what they need, until you build these exchanges that are in the affordable care act.

### Moderator
Claim: Douglas Holtz-Eaken. You’re against the plan.

I want to ask you, what-- what do you think the public actually wants?

### Conspiracy Advocate (CA)
Claim: I have no idea. Let me just-- I would never speak for 300 million Americans. And that's one of the beautiful things about this country. And I think the-- you know, I agree, obviously, with a lot of what Jon has said. Go back to the beginning of the evening when we were asked to think about end of life care. Now, do you really think that Americans want an insurance company making decisions about the end of life care? No. They've already seen that model and rejected it--

### Moderator
Claim: So you are telling us what Americans want, or not.

### Conspiracy Advocate (CA)
Claim: That you can't do that. They told us, I’ll read that evidence. I don't think they want the government making those decisions. I think we know who makes those decisions. It's the family. It's-- those are the only people who are ethically well situated to make those tough calls. And so we must, in the end, invest in families, the authority to make decisions, invest in them, their insurance.

Invest in them the information and the ability to make those decisions and center this system around families and Americans, not around these large government entities.

What does that mean in practice? I'm an economist. I mean, economists are practical people. You follow your nose and incentives. If I have an insurance policy when I'm 21, and then I develop an odd thing where I have to have my kidneys transplanted, I'm still on that insurance policy. Any insurance company now has to recognize they've got me for life. It's not a one-year sign-up proposition where they can minimize on preventive care or they can try to cut off covering some things. They have to deal with the right lifetime incentives. Pay for the cheap prevention up front. A lot of them eventually want to do that. And align the insurance and the medical incentives to transform the way we deliver medicine in America. That's what we need. And in the process, guess what? My insurance goes with me from job to job, job to home when I stayed home with my kids. You don't have to spend the whole time fighting over who works full time to get the insurance. It's madness. Americans are rearranging their lives for the insurance.

Let's rearrange the insurance so it fits American lives. That's what this system will be.

### Moderator
Claim: Jonathan Cohn, you said in your opening remarks-- Jonathan Cohn, you have said that the Obama plan took the best from both left and right. Give me one idea from the right that your opponents will recognize as an idea that is from their side, that they just love.

### Scientific Advocate (SA)
Claim: Sure, absolutely. Well, first of all, to start, there's a pilot program funding for malpractice reform. You know, believe it or not, people who wrote the Affordable Care Act, and I would include myself among this, actually believe that there is some money to be saved by reforming the malpractice system. So there's money out there for--

### Moderator
Claim: Let me just take that to this side. Do you recognize that as one of your ideas?

### Conspiracy Advocate (CA)
Claim: Can I just say the big problem--

### Moderator
Claim: Douglas Holtz-Eakin.

### Conspiracy Advocate (CA)
Claim: I will stipulate late one thing I want to get very clear on the table. I support exchanges. I support-- I always support good competitive markets. And you can build exchanges that enhance competition left to do that. There is a lot in the bill that is bipartisan. It's in the delivery system reforms, not in the coverage expansions which are madness. But they're all tiny.

They're pilots. Pilots have a terrible track record of actually turning into real policy. In fact the road to healthcare hell is paved with pilots and demonstrations. And that's a pilot and a demonstration for a known problem. If you've got a problem, fix it. The problem with this bill, it doesn't fix what we know is the issue, healthcare costs. Instead, it's got a bunch of pilots that Congress will never actually implement. And it doesn't fix the biggest source of our problem, which is the Medicare system which pays for fragmentation, pays for overuse. It's a fee for service system. We have more problems created by those programs than this could ever solve.

### Moderator
Claim: So what's the point of the program.

### Scientific Advocate (SA)
Claim: I have to respond to this because really, you know, that's amazing for you to say about the Medicare program. We had legislation under the Republicans to reform Medicare, to introduce private insurance plans into Medicare. And what is the result?

We now know that those plans cost Medicare an extra $1,000 per beneficiary compared to what it would have cost Medicare just to deal with them in a traditional program. So.

### Moderator
Claim: --this is a very important point.

### Moderator
Claim: John You want to share some time with your--

### Conspiracy Advocate (CA)
Claim: No. I'd like to--

--30 seconds of getting facts straight. The problem is the healthcare bill. Medicare Advantage is one way to shift it from one person to another. Tax policy, which he said would save us money, doesn't. It just shifts the bill around from one person to another. The problem is the bill. This law does not change our healthcare bill. That's its issue.

### Scientific Advocate (SA)
Claim: Can I just say--

### Moderator
Claim: Jonathan Cohn.

### Scientific Advocate (SA)
Claim: With all due-- did you read the bill? I mean, I-- is. And did you read the-- I know you've cited CBO reports. There are page-- I mean, we all know it's a thousand-page bill. Let me tell you--

### Moderator
Claim: No, no, it's not a thousand page bill. It's $2800. 2800 pages.

### Scientific Advocate (SA)
Claim: Okay. Well, the type's very big.

That's how they do congressional--

### Moderator
Claim: There you go.

### Scientific Advocate (SA)
Claim: Okay. Whatever. You know, I think if you condense it-- true story, if you condense it, it actually comes down to about 300 pages, which you know, is less than a John Grisham book so take that into account.

### Moderator
Claim: But not nearly as good, right? Not nearly as good.

### Scientific Advocate (SA)
Claim: I'm actually not a John Grisham fan. But your mileage may vary.

But I mean there are-- and you yourself admitted the delivery reforms in there--you think they're not big enough, okay? And you know what? I would agree with you. I would like those delivery reforms to be stronger. So here is a proposition. You're talking about repealing Obamacare.

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: How about let's reinforce it. Let's make those bigger.

Why do you want to go back and start from scratch?

### Moderator
Claim: John Shadegg.

### Conspiracy Advocate (CA)
Claim: I have to raise an issue which your side has raised, and that is you say it gives people choices. It takes a lot of gall to say that it gives people choices. For example, in Medicare Advantage, it repeals Medicare Advantage for millions of Americans and takes them off.

### Scientific Advocate (SA)
Claim: It reduces subsidies that are

### Conspiracy Advocate (CA)
Claim: No, no. It takes-- it will drive people off of Medicare Advantage. Every expert agrees on that.

Two, you say that people will have choice of plans. There is one plan prescribed by the government, actually has three different components, but that's it. Three. Secretary Sebelius can grant exemptions. She already has too many companies. She has the ability to impose new benefit mandates. She has ability to say what premium increase is effective or not effective. The notion that this bill gives the average American more choice is ridiculous. It's going to take away the choices Americans have now, and it's going to force them into essentially a one-size-fits-all plan. When you say, for example, to employers, that your costs are going to up, such as AT&T, to the tune where you could pay the fine for not insuring every one of your employees and still save $2 billion, they're going to have no choice but to drop their coverage and put people into the government- run plan.

### Scientific Advocate (SA)
Claim: Can I just respond to this because this is the second time that you've mentioned this.

### Conspiracy Advocate (CA)
Claim: Let me finish. Let me finish.

### Moderator
Claim: Let him finish, Paul, because I do want to hear the response to this.

John Shadegg.

### Scientific Advocate (SA)
Claim: If AT&T or any of these other companies wanted to drop coverage now--

### Moderator
Claim: Hold on just one minute. And you get 15 more seconds to finish your point. Sit this thing down.

### Conspiracy Advocate (CA)
Claim: No, he can go. That's fine.

### Moderator
Claim: Oh, I give you 15 seconds, and you throw it away.

### Conspiracy Advocate (CA)
Claim: I mean--

### Moderator
Claim: Okay. Paul.

### Scientific Advocate (SA)
Claim: Under current law, if any of those companies wanted to drop coverage, they could do it legally. This law introduces a penalty for dropping coverage. So how can you say that the law encourages them to--

### Conspiracy Advocate (CA)
Claim: Precisely because right now they choose to provide that coverage for their employees because that competitive market requires them to do that. People want good coverage. If they drop that coverage, there's no place for those employees to go. Under this bill, they will all get government subsidies. And oh, by the way, AT&T can take that $2 billion savings and add it to people's salaries. So the notion that this is going to give you more choice, when, for example, we don't allow interstate competition in health insurance now. Your employer makes the choice of your plan.

You can't hire--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: You can't fire.

### Moderator
Claim: Jonathan-- Jonathan--

I want you to have--

It's actually quite cogently put.

### Scientific Advocate (SA)
Claim: And you know, it makes sense. And then, gosh, why would AT&T keep providing coverage? If you're right, and I know Doug has written a paper on this also, if you guys are right, that in offering all of these subsidies companies are going to drop, then we should see that in Massachusetts right now because that's what they have in Massachusetts. They offer the subsidies, and companies-- but you know what? It hasn't happened. Employer-sponsored insurance in Massachusetts--

No, no, no, no. Let me... It hasn't happened. And the best estimates from the experts are that it won't happen. And there's a very complicated-- I mean, I could go through all the math-- I read Doug's paper on this, and I know it seems like it makes sense, but it doesn't happen. Would it happen right now with Medicaid? And you know, you don't see company-- half the people who qualify for Medicaid

### Moderator
Claim: Let's let your Massachusetts Respond to that.

### Conspiracy Advocate (CA)
Claim: Actually, number one, in Massachusetts, we're down to, I think, to only four carriers. Several of them are in dire straits. Many of them have demanded from the governor that he allow them to raise rates. The governor has said no. And some of them--

--are on the verge of folding. Now, let me ask you something. The plan, under Obamacare, says that if you're in an exchange, a government-run exchange, and you only offer the policy that the government exchange allows, then you can get a subsidy. Every Republican plan says let's give every single American a tax refund, a tax credit to go buy the plan of their choice. Now, I guarantee you, if we do that, so we say to every American, you get a refundable tax credit, a refund, and for the poor, it's cash, to go buy the plan of your choice. And you can buy your employer's plan. You can buy in the individual market. You can join a new group sponsored by the Kiwanis club. You can join a new group sponsored by--

### Moderator
Claim: Would you mandate a purchase? Would you mandate it?

### Conspiracy Advocate (CA)
Claim: No, I would not mandate it because I think freedom is a hallmark of this country. And I think if we offer great--

### Moderator
Claim: So maybe a lot of that money would end up at the amusement park or the race track?

### Conspiracy Advocate (CA)
Claim: Well, let me tell you how my plan works.

It offers every single American, every single American that refundable tax credit if they don't make enough money if they do not enroll because they are homeless and don't get the notice we automatically enroll them because we know their Social Security number and we knew it as one point, they show up for care somewhere, and they say, "What plan did you enroll in?" And the individual says-- she's a mother of three that was moving from Idaho to Arizona on the day that the notice came to her, she says, "I didn't enroll." They look her up on a Social Security number and they say, "Oh, yeah, you're in the pool."

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: "And you're covered." That's the way Paul Ryan's bill works, that's the way Tom Coburn's--

### Moderator
Claim: Okay, John, you've made that point. I want to stay on the merits of the Obama plan. Do you want to respond to that, either of you, gentlemen?

### Scientific Advocate (SA)
Claim: I want to respond to this whole notion that it's a complete individual free market here, to talk a little bit about the way insurance works. Healthcare is very different from other kinds of services and commodities.

Seventy percent of the healthcare costs in any year are concentrated in 10 percent of the people. So insurance companies have a very strong incentive to cherry pick, to go out and to look for the 50 percent of people who actually account for only three percent of the costs. And when you have this market where supposedly everybody has individual choices, you also have a market where the insurance companies are going to cherry pick and avoid the sick people. They will do everything in their-- it is the best business model for them. Rather than try to control healthcare costs, it's just to avoid sick people. The way the exchanges work is that if you want to sell insurance in the exchange, you have to agree to take anybody. That’s the bargain. And what the exchange does, so the people pay in on a community rated basis, but the insurance companies get paid according to the risk of the population they enroll. So if they enroll an older population, if they enroll a sicker population, they get paid more.

That’s what goes on through the exchange that won’t go on through this market. I realize this is complicated. Insurance is a complicated business, and this law is trying to take account of the way this business characteristically malfunctions. That’s why we end up with millions of people uninsured.

### Moderator
Claim: Okay, I’m going to come to questions and-- I’m going to come to questions from you in just a minute. I want to give this side one 35- second shot at

So John Shadegg is taking

### Conspiracy Advocate (CA)
Claim: This criticism is often made, and the Democrat answer, the Obamacare answer is to say, “Okay, we’re going to do guaranteed issue, everybody gets insurance even if you're already sick." The incentive of that is not to buy insurance until it’s too late or until the costs have gone up. I’d like to ask Paul, “How is it the insurance companies know who’s going to get sick before the people know, and how is it that they can cherry pick the healthy?” But let me tell you how Republicans solve this problem.

### Conspiracy Advocate (CA)
Claim: Let me tell you how Republicans would solve this problem, I know because I happen to have written it, what you do is you say to everyone that has a preexisting condition or has a chronic illness, "You have the right, the absolute right to join what’s called a high risk pool. You may enroll in that plan if you are either denied coverage altogether or if your coverage is priced at, we’ll say, 20 percent, or 30 percent, or more above the average cost, because you have a preexisting condition. Once you enroll in the high risk pool, your health is covered comprehensively including my sister's breast cancer or my heart condition, and the-- so that means that the cost of insuring that pool is higher than the cost of insuring any other pool. That’s a high risk pool. The costs of insuring that group are then subsidized either by dividing it equally, the extra costs amongst every insurance company in the jurisdiction, it could be the state or it could be federal, or by general revenues from the state, often done by sin taxes.

I happen to know that because it’s already the law in 22 different states.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: I happen to know it because I wrote the last federal law that allows it.

### Moderator
Claim: John, John, let me move on to some questions from the audience. And if you-- what I’d like to ask you to do, I’ll call on you, wait till a microphone reaches you, and then hold the microphone about one fist's distance from your mouth so that the television and radio can hear you very clearly. And there’s a gentleman in a black sweater. Hey, sir, before you begin, I just want to ask you something, what have you heard so far that you thought, "Well, I hadn’t thought of that before"?

### Moderator
Claim: Hmm. That's a tough question. I thought I was asking the question.

### Moderator
Claim: Guess we haven't-- Your turn will come. And I’ll give you a pass if you don’t have a ready answer to that. And I'm not meaning to put you on the spot, I’m actually quite curious to know how it’s being received out there. So if you have no thoughts on that, we will pretend that question didn’t come up.

### Moderator
Claim: My only thought is, next time I will not be the first questioner.

### Moderator
Claim: Go ahead.

### Moderator
Claim: My question is for the gentleman on this side. Recently my house burned down and I tried to buy fire insurance after the fact and the insurance company said it was a pre- existing fire. Now, that doesn’t sound fair to me. Does it sound fair to you?

### Scientific Advocate (SA)
Claim: No, no it’s not. That is why--

### Moderator
Claim: So I should be able to buy fire insurance after my house burns down.

### Scientific Advocate (SA)
Claim: No, no absolutely not. Look, one of the reasons that there is a mandate in this law is precisely to avoid the possibility that people will refuse to buy insurance until they get sick. That’s the whole rationale for the mandate. Now I’ve actually proposed another way to accomplish the same purpose because the mandate is the single most unpopular part of the bill. People don’t understand that the mandate is directly related to the elimination of pre-existing condition exclusion. You can’t eliminate those exclusions just for the reasons you said unless you have some way to get the people into the pool.

My alternative is the following. If you want to opt out, if you don’t want to be part of the system, okay, you can do that without penalty. But you have to sign a form saying “I won’t come back and I cannot come back in. For five years, I can’t use the exchanges, I can’t get the subsidies, I can’t get a policy without the pre-existing conditions.” So I understand your position completely. We need to be able to avoid the possibility that people will behave opportunistically.

### Moderator
Claim: So Paul, you don’t want to repeal but you do want to tinker.

### Scientific Advocate (SA)
Claim: Oh, I am willing to make changes.

### Scientific Advocate (SA)
Claim: Tinkering’s fine. We’re not against it. Everybody who understands this plan thinks it’s not a perfect bill. No bill is perfect. The question is is it a good foundation.

### Moderator
Claim: Let me do a very quick thing for radio. This is a U.S. debate-- This is a great debate. I just wanted to say that.

I’m John Donvan of ABC News. This is a debate from Intelligence Squared U.S. We are at the Skirball Center for the Performing Arts at New York University, New York and hundreds of NPR stations across the nation. Our motion is “Repeal Obamacare” and we are taking questions from the audience. How was that? Not bad.

### Moderator
Claim: Very good.

### Moderator
Claim: Woman with your hand up right there. Yep. I’m going to ask you the same question and if you’re not prepared to answer that’s fine, I just want to-- what are you hearing that has caught your ear?

### Moderator
Claim: What I’m hearing is that the Republicans have a plan. I’ve never heard of any Republican plan in all the years that Republicans were in control.

### Moderator
Claim: Okay, your question. Maybe that was it.

### Moderator
Claim: That was it.

### Moderator
Claim: Oh, that was a comment. Okay. Well, there you go. On the side, gentleman, yes, right there. Thanks. If you could stand. Also if you happen to be a member of the news media, we would appreciate it if you could identify yourself as such.

### Moderator
Claim: I’m from the state of Massachusetts, actually. My question is not about that. I’m the son of a surgeon and I’m wondering if the bill does anything to address the so-called doctor fix with regards to Medicare pay outs to doctors? That comes up in Congress pretty frequently. I was wondering--

### Moderator
Claim: Fourteen seconds on what that means for people who don’t know what that is.

### Moderator
Claim: To my knowledge, I’m not an expert on it. I just hear my father rant and rave about it. The-- I believe it was in the cost bills back in the ‘90s to try to reform Medicare, they had a formula to try to pay doctors at some rate pegged to inflation and it doesn’t work. I’m not an expert on it myself. But I know it comes up in Congress quite frequently. It causes a stir. I think it somehow drives pay outs to doctors who see Medicare patients. Down 40 or 50 percent every six months. I know it comes up in Congress pretty frequently. I--

### Moderator
Claim: Okay. If you don’t mind, I’m going to pass on the question unless it’s quite relevant.

### Conspiracy Advocate (CA)
Claim: --on this broken formula that reimburses doctors under Medicare, part of the BBA that Jonathan lauded which in the end failed miserably. The bottom line is it’s not part of the bill because they left it out. It’s part of the cost they don’t want to acknowledge. If you want to know why this doesn’t reduce the deficit, they left out $300 billion worth of costs. And the CBO doesn’t have the option of saying hey, you left that out. They have the obligation to price only what is in there.

### Moderator
Claim: Jonathan Cohn.

### Conspiracy Advocate (CA)
Claim: And they are precluded by law from raising their hand and saying but you left out the doctors.

### Moderator
Claim: Jonathan Cohn.

### Conspiracy Advocate (CA)
Claim: I ran the CBO.

### Scientific Advocate (SA)
Claim: Here’s something else. You look at the CBO report on the Affordable Care Act and you’ll discover something shocking. It doesn’t account for the cost of the war in Afghanistan. Now that’s because the war in Afghanistan is a separate piece of legislation. During the late 1990’s, as part of a much larger balanced budget bill that I recall quite correctly working and getting us balanced budgets for a while--

### Conspiracy Advocate (CA)
Claim: You’ve given back all those savings. You’ve given them all back. They don’t work.

### Scientific Advocate (SA)
Claim: Before tax cut, I remember, I was against it.

### Conspiracy Advocate (CA)
Claim: --has nothing to do with tax cuts.

### Scientific Advocate (SA)
Claim: Nothing to do with tax cuts?

Nothing to do with tax cuts? Really.

### Conspiracy Advocate (CA)
Claim: The BBA health provisions have--

### Scientific Advocate (SA)
Claim: Wait, wait, wait. You're really saying the Bush tax cuts have nothing to do with the deficits?

### Conspiracy Advocate (CA)
Claim: No. It has nothing to do with healthcare.

### Scientific Advocate (SA)
Claim: I agree.

### Conspiracy Advocate (CA)
Claim: So this is--

### Scientific Advocate (SA)
Claim: You're making my point.

### Conspiracy Advocate (CA)
Claim: This is a debate about healthcare. And the fact of the matter is the balanced budget agreement healthcare provisions passed in the late '90s failed. They did not control costs.

And in the end, the Congress had to give the money back, as they will have to give it to the physicians under Medicare. That--

### Moderator
Claim: Jonathan, 20 seconds.

### Moderator
Claim: did not work.

### Scientific Advocate (SA)
Claim: Okay. You're hearing a very interesting version of the history of the '90s and healthcare. The doctor fix was built into our budgets for the government long before healthcare reform came on the scene. It is something that needs to be fixed separately. It would have to be fixed separately if we never had Obamacare. It is a separate cost.

### Moderator
Claim: Who can tell me in 15 seconds what it is, because I don't know.

### Moderator
Claim: It is literally this. It was a formula for reimbursements for doctors. Doctors are very expensive.

And so they keep pretending they're not going to fulfill the formula. And then doctors face a big pay cut. And then Congress says, “Well, I guess we do have to pay doctors. Doctors are part of healthcare.”

### Scientific Advocate (SA)
Claim: They are part of healthcare.

### Conspiracy Advocate (CA)
Claim: Part of healthcare reform.

### Moderator
Claim: So your dad is afraid he's going to be paid less, but he isn't--

### Conspiracy Advocate (CA)
Claim: Twenty five percent less next year unless they, once again, put the money back in.

### Moderator
Claim: Another question, please. From the far side with the gray hair.

### Moderator
Claim: I found it interesting that the panel is assuming that healthcare runs on a perfect market economy, which is fundamentally flawed. I wanted to know about, you keep addressing costs. And I think that this debate is mostly about access to care and not really about costs. Do either of you have an answer to utilization and patient and physician-induced demand, which is really the cost--

### Moderator
Claim: So is the bill designed to get people insured, or is it designed to keep the costs down primarily? Paul Starr.

### Moderator
Claim: But nobody's addressed cost, which is utilization.

### Scientific Advocate (SA)
Claim: Well, it's both of those things. But the questioner used a phrase which probably went by a lot of people. He talked about physician-induced demand or provider-induced demand. So this is another aspect of how healthcare is different. Normally, when you are the customer, you make decisions about what to buy. But when you're a patient, particularly when you're very sick, you're in the hospital, other people are making decisions. They're prescribing drugs, procedures and so forth. And if you're really sick, and most of the big costs are generated for people who are very ill, it's not-- the demand isn't coming from you. It's coming from the supplier. This is a very bizarre system.

### Moderator
Claim: a very interesting point. I want to hear-- and that's one of Paul Starr's basic arguments for why this is not like other things that you pay money for. Can you respond to that, John-- Douglas Holtz-Eakin.

### Conspiracy Advocate (CA)
Claim: Couple responses. Number one, there are no perfect markets.

And to somehow compare health markets against perfection misses the point. All markets are, at some level, imperfect and have anomalies of the same type. The solution to this is to better inform-- hang on. Let me finish. Let me finish. The important thing here is to have reforms which Republicans include as well as the-- your arguments, to better inform patients so they can distinguish between valuable and invaluable treatments. And we have a system riddled with low-value care. And all of the reforms Republicans propose address that issue. An important thing to recognize, the reason I'm deeply opposed to this bill is, it is fundamentally-- there are pages attached to all the issues. But it is fundamentally a coverage bill. And if you look at half the expansions, they are in Medicaid. Sixteen million Americans we've put into Medicaid. Medicaid's a terrible system. Fifty percent of providers will not see Medicaid patients. Medicaid patients are twice as likely to show up at the ER for regular medical care than are the uninsured.

And it is a great joke to give someone an insurance policy called Medicaid and not let them actually see a physician.

### Moderator
Claim: John Shadegg, you want to add to that briefly?

### Conspiracy Advocate (CA)
Claim: I do.

### Moderator
Claim: To what your partner said.

### Conspiracy Advocate (CA)
Claim: In a New Republic article that came out some time ago, I'm sorry, the New York Times-- New York--

### Moderator
Claim: One of those.

### Conspiracy Advocate (CA)
Claim: --article.

New Yorker magazine was the article. It documented--

### Moderator
Claim: John, start that again for the editing later on.

### Scientific Advocate (SA)
Claim: You're taking out our--

### Moderator
Claim: For radio.

### Conspiracy Advocate (CA)
Claim: In a recent authoritative article which appeared in the New Yorker, they studied where healthcare costs are the highest. And interestingly, they found that the highest place for healthcare costs in America is a little town called McAllen, Texas. And they went to McAllen, Texas, and tried to find out why are costs so high. And what they found was a couple of different factors.

Number one, they found that doctors in fact do prescribe lots of procedures that are unnecessary. And they do so in McAllen, Texas. They noted that, for example, great healthcare centers do not prescribe that many procedures. And so they figured out there needed to be a way. They actually began interviewing doctors. And they said, you know what? In the current system, we are not incentivized to control costs. Why are they not incentivized to control costs? Because nobody's watching the store. The reality is--

### Moderator
Claim: But you’re agreeing with that sort of monitoring.

### Conspiracy Advocate (CA)
Claim: As Paul said, if the consumer isn't paying the bill, then nobody's watching.

### Scientific Advocate (SA)
Claim: Yeah, yeah.

### Conspiracy Advocate (CA)
Claim: And in this circumstance, yeah, if you're sick, you're not making the decision. But right now, your family could be making that decision. But right now under the current system and under Obamacare, you will not be making that cost decision because you're cut out of the process.

### Scientific Advocate (SA)
Claim: So I'm having this very disoriented feeling listening to a lot of this because you're stealing some of my talking points here. Maybe--

### Conspiracy Advocate (CA)
Claim: I love to do that.

### Scientific Advocate (SA)
Claim: But, no, I agree. That article was very influential. Actually President Obama was known to have read it.

### Conspiracy Advocate (CA)
Claim: He did.

### Scientific Advocate (SA)
Claim: He handed it around to his staff.

And I think most people who study the healthcare system agree that, you know, one of the weird things about our healthcare system is you have these bizarre regional variations. So you go to some parts of the country, and they're doing all kinds of extra procedures, and other parts of the country, they're not. And why is that? Well, the people who wrote this bill, they all read that article. They all know this. And the article actually built on years and years of studies showing that and it’s very specifically designed to help address that problem. And there're all kinds of ways it does. I mean, it would be-- I would love to be able to sit here and say, here is the silver bullet that will change it. Because that's what he thinks. “Oh, you know, if we just give everyone choice, you know, if we give everyone the consumer power it will somehow sort this all out.” Well, good luck with that. I mean, I don't know about you. But the last time my kid was sick, it took me three hours on WebMD to figure out even what the symptoms were.

### Moderator
Claim: Did you-- do you just not like what you're hearing, or did you have a question to follow?

### Moderator
Claim: 40 percent of all healthcare costs, so--

### Moderator
Claim: Okay. I'm going to pass on to another question. This gentleman right in the center. You've been very patient. Here.

### Moderator
Claim: I'd sort of like to get to the heart of the cost things because I think there's a little bit of denial going on. An early mentor said to me if the financial analysis defies common sense, go with common sense. So now we get 35 million new people coming into Medicaid. We've got baby boomers retiring in droves going into the Medicare program. And we've got all that intercepting with all advancements in care and treatments, procedures and drugs which extend life and make life more livable. And a big underpinning, a big way that the Obama bill is going to get this under control is by slowing the cost of Medicare and Medicaid. I believe the number is about--

### Moderator
Claim: So can you focus to a question.

### Moderator
Claim: Pardon me?

### Moderator
Claim: Can you focus to a question, having studied your premise.

### Moderator
Claim: Well, yeah, yeah, yeah. Here's what I think is going to happen. I want you to tell me it's not.

### Moderator
Claim: Yeah.

### Moderator
Claim: That will result-- there's a videotape of every president since Richard Nixon saying they're going to solve this problem by getting waste and fraud out of the system.

I think it's going to reduce reimbursements. And I think that's going to drive more and more of the better docs out of the system. It's already happening. Where I live in Sarasota, Florida--

### Moderator
Claim: I need a question, please.

### Moderator
Claim: Tell me why that's not going to happen and why it's not going to hurt the people at the bottom of our economic scale.

### Moderator
Claim: Thank you. Jonathan Cohn, who is against repeal.

### Scientific Advocate (SA)
Claim: Very quickly on this question about physician-- and what you're-- if I understand what you're saying, your last question there is about if we're going to spend less on Medicare, if Medicare is going to pay less, then why won't doctors just leave the system? Well, we've done reductions in Medicare like this before. We've done reductions larger than the ones we've done before. And by the way, during the McCain campaign, Mr. Holtz- Eakin, I remember, very vividly, saying that they were going to pay for their healthcare plan by enacting Medicare cuts that were even larger. Now, I don't think he was trying to deprive Medicare patients of access. But the fact is we've had these cuts before. And every time it happens, you hear a lot of predictions, oh, my God, people are going to stop seeing Medicare patients.

And I understand that. Look, my father is a surgeon. He's in south Florida where you see people walking around with little dollar signs because there are cataract surgeries and, you know, that's what it's like. And I understand that. The fact is, every single time that we have done this, there have been predictions that doctors are going to flee the system. And you'll always get the anecdotal, of course, this doctor is leaving that-- but the Medicare payment advisory committee looks at this. There's a government, independent, not partisan authority that looks at these statistics to monitor this, because they want to make sure that's not happening. There's a group called the Center for the Study of Healthcare System Change, which is the longest acronym ever for a think tank. But believe me, they're very reliable, totally nonpartisan. Everyone trusts--

And what they all found is it never happens. The doctors have not left the system.

### Moderator
Claim: Douglas Holtz-Eakin. Douglas Holtz-Eakin.

### Conspiracy Advocate (CA)
Claim: I want to, first, stipulate late, that the place they send old CBO directors to die is the Medicare payment advisory commission. I've been there.

And prospectively, the MedPAC as well as the CMS actuary would say that the kinds of cuts and vision for Medicare will either lead to inadequate care, inability to see providers, or you can go put the money back in. So there are no real changes in the business model that would allow a physician to practice more cheaply in Medicare, and that is why we should have fixed the problem instead of written the checks that is this system. I think that is the fundamental indictment, we are not fixing the problem, and it is important to recognize that although there's all these bells and whistles that Jonathan likes to point to, there are lots of pages, they don't have any teeth. They put something in called the "Independent Payment Advisory Board," that's like MedPAC on steroids, and-- but the law says they can't make beneficiaries pay more, they can't touch the hospitals and the nursing homes for 10 years, they can't mess with the way the docs get paid, so where's the big change in the way the delivery system's going to happen?

### Moderator
Claim: Let's go to the audience for more questions. Ma'am.

### Moderator
Claim: Yes.

### Moderator
Claim: Can you stand, please?

### Moderator
Claim: Hi.

### Moderator
Claim: And just give a second for the camera to find you.

### Moderator
Claim: Yes. I am retired psychiatric social worker, and I haven't really heard much about the pain and suffering, it's cost, cost, and I know money's an issue, but I haven't heard the human side of this at all, and it's very dismaying. The other thing is, what about the issue of Americans are not taking very good care of themselves and they say 75 percent of the health issues of course are people's bad habits, or a lot of them.

### Moderator
Claim: But do you think that's about a law?

### Moderator
Claim: Well, no, but, I mean, but a law, I mean, I think one of the things Obamacare wanted to do was try to get people to take care of themselves better and reward, you know, doctors who concentrate on prevention, and change of habits, and diet, and exercise. And that’s a very important--

### Moderator
Claim: Paul Starr, is there any traction in that argument? And I’ll come back to you, John.

### Scientific Advocate (SA)
Claim: Well, there are a number of measures in the bill that promote preventive services but-- and they are very important.

Medicare beneficiaries will get preventive services that have never been covered before. Those are some of the terrible mandates for private insurance that’s going to have to cover vaccinations, things like that. But, you know, I’m not counting on that for big savings. I don’t think the government really can change personal behavior in that profound a way, and I-- personally, actually, I don’t want to change that.

### Moderator
Claim: I bet, John Shadegg, you agree with that point?

### Conspiracy Advocate (CA)
Claim: I don’t think government can change personal behavior, but I think law can change personal behavior because right now this system does not incentivize you or I to take care of ourselves. There are companies that have looked at this. Safeway, for example, has said, “You know what? Having obese employees, having employees with out of control blood pressure, having employees with severe cholesterol is a severe problem," and so they’ve gone in and they have

### Moderator
Claim: John, you’re talking about the system that existed prior to the reform, or you’re talking about the reform plan does not address these issues?

### Conspiracy Advocate (CA)
Claim: The reform plan says government’s going to do it. What I’m saying is you have to incentivize people to do it, and the way you can incentivize people to do it is to give them skin in the game. Actually, Safeway cuts the cost of its employees’ healthcare if they lower their blood pressure, or if they consistently take their cholesterol medicine. We can’t--

### Moderator
Claim: May I just say so does the Walt Disney Company, of which I am an employee.

### Conspiracy Advocate (CA)
Claim: There you go.

I take the human side of this argument very, very seriously. When we were kids growing up, our parents bought indemnity plans, and the doctors cared about us because there was a physician-patient relationship. We put the cash on their table. The system we have created now divorces us completely from our doctor. It says your doctor isn’t hired by you, your doctor is hired by a plan who was hired by your employer.

And that is what has caused medicine to-- caused damage to the physician-patient relationship, it’s caused a loss of control in costs, and it has caused the kind of devastation that you’re talking about. I know people that can’t afford care because the insurance companies don’t give a damn about what it cares. It’s time to stop shoveling money to them and put the power and control in your hands, not to give it to the government so Secretary Sebelius could write a thousand new regulations. That’s not going to make it more personal, and then the plan I propose covers every single American, every one.

### Moderator
Claim: I think you agree with most of that.

### Scientific Advocate (SA)
Claim: Do I agree that I-- I think that people sometimes are at the mercy of their insurance company? Absolutely, and that is why I support this bill and don’t think we should repeal it. I mean, remember right now your insurance company says you can’t get that treatment, you’re stuck. Right now you’re moving between insurance companies--

You know, you're-- right now you're moving between insurance company and insurance company, you change plans and tomorrow you have to change doctors because they’re not in the same network.

This plan allows people to stay on the same insurance plan longer and when that denial comes down, guess what? You can appeal it. What a notion. You can actually go to an impartial person and say “You know what? They’re saying I can’t get this premium because they think it’s too expensive. I think I have the medical evidence that it works,” and the board says, “You know what? You’re right.” That’s a mandate. That’s a regulation, and you know what? It helps people.

### Moderator
Claim: Yeah. You just raised your right hand. Will you stand up and the mic will come to you, thanks. Can I ask you what you’re hearing so far that in any way changed your mind?

### Moderator
Claim: It hasn’t changed my mind. It’s been a lot of the same rhetoric I think. But I keep hearing always the proponents of repealing the law about consumer choice and way before this law they kept talking about consumer choice will lower costs. And I want to ask you if you really believe that a parent with a child that needs heart surgery is going to choose the cheapest heart surgeon and the cheapest hospital.

And when your father’s dying of prostate cancer they’re going to choose to not give four months of very expensive treatment and thus lower cost.

### Moderator
Claim: That’s a question for the side arguing for repeal.

### Conspiracy Advocate (CA)
Claim: I’m going to give you a bad answer and I will hand it over to Mr. Shadegg. This is what I would say to you. Healthcare is not a one thing. It’s not just the circumstances tragic and threatening as you described. Healthcare and where we spend this is an enormous range that involves elective procedures, it involves chronic conditions, it involves traumatic injury and we have a system that does not provide individuals with anything like the ability to manage their care, anything like information needed to choose from high and low value care and never gets them in a preventive way in a position to avoid being stuck with a tragic choice.

That’s wrong. We need a system that they control all aspects of their life cycle up to those very moments. And I have a great faith in the ability of the American people. They do it in every other aspect of their lives some of which are enormous, they have kids. That’s a pretty life and death situation.

### Moderator
Claim: Paul Starr who is against repeal.

### Conspiracy Advocate (CA)
Claim: I have great faith in the ability to do it.

### Moderator
Claim: Paul Starr who is against repeal.

### Scientific Advocate (SA)
Claim: Well, I agree with the sympathies of the questioner that there’s something really fundamentally amiss here, this image of the patient as economic man. How really out of touch it is with the conditions of illness. How, in fact, it assumes a kind of marketplace where, for example, prices would be available. Actually, you can’t find out what the prices are for different things. And in fact a hospital has 12 different prices for the same thing depending on who it’s treating. We don’t have a system of posted prices in healthcare. Now, maybe you want to change all that.

Maybe you want to transform it but you were in power for years and you didn’t do anything about it.

### Moderator
Claim: John Shadegg.

### Conspiracy Advocate (CA)
Claim: Yeah. The decision point that you referred to, once they’ve gotten sick, is not the right one. The reality is people are economic beings and they do make economic decisions. Indeed, I proposed a bill in the United States Congress that would allow you if you live in New Jersey to buy a plan that was written and offered for sale in Arizona or Idaho or Illinois or Connecticut. No, no. Let me explain how it works. You could buy that policy-- and the reason I wrote that bill is because the people in New Jersey today pay at least four times more than the people in Pennsylvania because of those strictures of the law in New Jersey. Indeed, Americans who go to New Jersey are going to their friends that live in Pennsylvania and say, “What are you paying? And they’re saying “Well, I’m paying one-fourth of what you’re paying.” And people are actually buying health insurance by pretending they live in Pennsylvania when they really live in New Jersey because it costs one-fourth as much.

Now we heard the argument that nobody would shop but people really do shop. But here’s why shopping-- ah-- if they can shop-- what makes me maddest about all of this- -

### Moderator
Claim: To quote you, you’re saying from the audience, cheaper premiums do not mean cheaper healthcare. John, respond to that.

### Conspiracy Advocate (CA)
Claim: The ability, for example, to buy across lines. People are not going to pay, are not going to choose to pay cheaper premiums unless they have to. What they’re going to do is pay, they’re going to spend as much as they can on healthcare and get the best product they can. They won’t choose to buy a cheap policy, some may, but most people buy the most expensive policy they can. In fact, that was a study done on my bill allowing across state line health insurance sales and indeed, no less than the Department of Health and Human Services said if you simply allowed cross state sales of health insurance we would have eight million fewer people uninsured in America today.

Now, here's the point. It's not-- the key isn't that you will be able to get a cheaper policy. The problem is the insurance companies are cheating us right now. They're charging too much because they don't have to compete.

### Moderator
Claim: Okay--

### Conspiracy Advocate (CA)
Claim: The reality is--

### Moderator
Claim: On the far right. You're standing in the aisle and making yourself known.

### Moderator
Claim: Thank you. Hi. I know we're here to discuss to repeal or not to repeal. But that is not the question. I think the central question should be-- and it is also my question to you, what is our path to a truly universal, affordable healthcare system? Because whether we have the Affordable Care Act or whether we have the status quo, both systems are asking us to put our faith in the private health insurance industry which is profit driven. And life and death matters should not be decided by the profit motive. So that what is the path--

What is the path to an improved Medicare system open to all?

### Moderator
Claim: Repealing Obamacare is the question. But given your passion and verve, I'd just like to give each side 30 seconds each to respond to that. And either of you can take it from there.

### Scientific Advocate (SA)
Claim: This law reflects a conviction that we can regulate a private system, not just private insurers, but also private hospitals, private doctors, and achieve the goals that you're interested in, a universal system. And in fact, really, if you look at other countries, they're not all government controlled. They have many private insurance funds in many European countries and achieve a universal--

### Moderator
Claim: Thank you. On this side. Douglas Holtz-Eakin.

### Conspiracy Advocate (CA)
Claim: There's nothing about insurance companies, per se, that anyone should like. But the alternative, a monopoly that you have to deal with, is completely inferior to having a vibrant insurance industry that has to compete for your business.

I would much rather force them to give me a decent service than have a mandate that I have to use the one that's supplied by the government. The second thing is, remember, for those advocates of a single big national payer, a national payer cannot negotiate any better between one hospital in Wichita and another hospital in Wichita which is ultimately where you have to negotiate who can provide this care at the cheapest price. They can't do it any better than the guy in Wichita. So there is literally no advantage to a national plan. It's a charade.

### Moderator
Claim: John Shadegg, your partner.

### Conspiracy Advocate (CA)
Claim: Your goal is my--

### Moderator
Claim: All right. Debaters are here on this one. John Shadegg, very quickly.

### Conspiracy Advocate (CA)
Claim: Your goal is my goal. Long ago, I embraced universal coverage. One point we haven't talked about tonight very much is how many people are going to lose the coverage they have. You said how do we get to that right healthcare system. I'll tell you how. Number one, allow the people that like their plan to keep their plan. Number two, deal with the issue of the uninsured by giving them a refundable tax credit.

Give them cash--

### Moderator
Claim: John, you've made this point before so I'm going to-- in the interest of time, I'm going to move on. One more question. And, ma'am, purple scarf, yeah.

### Moderator
Claim: My question is, why should we not trust our elected officials? Why, if people have their lives in public service-- well, I mean, you were voted into office. Why should we not? I lived in Great Britain for 25 years. I was a beneficiary of the National Health Service as well as private medicine. But there was an implicit trust that my tax pounds from my paycheck would help subsidize healthcare.

### Moderator
Claim: Okay.

### Moderator
Claim: But I trusted that they would, regardless of whether they were labor or conservative. And same in this country, Republican, Democrats, we're all--

### Moderator
Claim: So your question is why be so suspicious and skeptical of the ability of the bureaucracy to do the job well. I want to put that--

### Moderator
Claim: Bureaucracy-- people who have devoted their lives to public service who are elected officials, because some Americans--

### Moderator
Claim: The elected officials. Let's put that to the side that's arguing to repeal. John Shadegg.

### Conspiracy Advocate (CA)
Claim: I think we should trust them. However, in this instance, we didn't. And point of fact, when Obamacare passed, it was opposed by roughly 54 percent of the American people. Each day it's opposed by somewhere closer to 60 percent of the people. There is no poll out there yet that says that it's favored by more people than not. But more importantly than that-- and this is a key point-- when a nation that is a democracy makes a radical change in public policy, it should be reflected not by the narrowest of consensus but by a very broad consensus. When Social Security was adopted, more than 80 percent of the members of the Congress, House and Senate, voted for the creation of Social Security. When Medicare and Medicare were created, more than 70 percent of the members of Congress supported those programs. When SCHIP was adopted, again, the numbers were well over 75 percent of the members of Congress.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: When this bill passed, it passed by the slimmest of margins. In the House, 50.8 percent, purely partisan vote. And without the kind of consensus that I think will make it sustainable.

### Moderator
Claim: Jonathan Cohn.

### Conspiracy Advocate (CA)
Claim: If it were sustainable, we wouldn't be having this debate.

### Moderator
Claim: Jonathan Cohn, 30 seconds.

### Scientific Advocate (SA)
Claim: Okay. Very quickly, the polls-- if you scratch those polls even a little bit, what you will find is that it's a country overall. Do you like the healthcare reform? Yes, no, about divided. Ask the people who don't like it, do you think it should be repealed and just we should go back to the way we were, or make it stronger? About half the people break off, say, “Oh, no, we want it to be stronger.” And if you test the individual elements, they're wildly popular-- protection against pre-existing conditions, getting kids under 25 on parents’ insurance. All of these things are wildly popular. And yes, it's true, the Republican Party did not-- this was a closed vote. You know why that is? It's because we live in a world not like the one 20, 30 years ago, where you had a responsible Republican party, where you had moderate Republicans--

### Conspiracy Advocate (CA)
Claim: Oh. Ooh!

### Scientific Advocate (SA)
Claim: Just like, as my colleague said. The ideas in this plan were virtually identical in the broad framework to what the Republicans were proposing just 12 years ago. It's what Mitt Romney said. This is not a radical plan.

### Moderator
Claim: John Shadegg, equal time for you on that.

### Conspiracy Advocate (CA)
Claim: I think it's offensive to say that the Republican Party is irresponsible. You know, I'm sorry. I take offense at that. I have offered healthcare reform bills every year I've been in Congress. There are many. I'm sorry the woman over there didn't hear them. Yes, Republicans passed the opportunity when they hold both majorities of Congress. But quite frankly, we did not have the demand that we have now seen. But how do you defend the fact that broad consensus is necessary to support this legislation? Have you defended it other than to say-- other than to say, well, back then, the Republican Party was responsible, and now it's not. That's really-- quite frankly, in the context of what happened last week, inappropriate.

### Scientific Advocate (SA)
Claim: When you pass the Medicare prescription drug program--

### Moderator
Claim: Paul Starr.

### Scientific Advocate (SA)
Claim: When you pass the Medicare prescription drug program, the polls ran two to one against it among seniors and the general population. Eighty percent of people in polls said this is too complicated. You did it anyway.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate. And here's where we are. We are about to hear brief closing remarks from each of the debaters in turn. They will be two minutes each. And it's their last chance to try to change your minds to their point of view. Our motion is "Repeal Obamacare." You've been asked to vote once. And we'll ask you to vote again in just a couple of minutes. But first, round three. Round three, closing statements from each debater in turn. They will be brief. And first, to speak against our motion, “Repeal Obamacare,” against repeal, Paul Starr, professor at Princeton University, cofounder and coeditor of the American Prospect and Pulitzer Prize winning author of “The Social Transformation of American Medicine.”

### Scientific Advocate (SA)
Claim: Thank you. Two months ago, the editor of an Austrian newspaper, a conservative, by the way, asked me how Americans could possibly oppose giving health insurance to the millions who don't have it. To Europeans across the political spectrum, it's unthinkable to withhold health insurance, just as we would regard it as unthinkable to deny an education to children. The Austrians, the French, the Germans, who have excellent medical care, don't become uninsurable when they get ill. They don't get locked into a job for fear of losing health coverage. Universal coverage makes it more secure, and it actually makes them more free. But every time the issue of universal coverage has arisen here, the opponents have used innuendo and fear to defeat health reforms that are common to every other advanced democracy.

And last year, we finally broke through that drum beat of fear with moderate legislation and to creating a more just and efficient system to cover the excluded and create mechanisms to slow the growth in costs. Repealing the law would mean denying coverage to more than 30 million people. It would mean repealing the laws' protections against abusive insurance practices, some of which have already gone into effect like barring the rescission of policies just because the subscriber gets sick. It would mean giving up a whole series of cost-containment measures that show a lot of promise for reign in medical inflation. But even more importantly, repeal would be a concession of political helplessness in the face of a problem that has nagged at the national conscience for a century. It would be a confession that we simply are not capable of the elementary decency toward the sick that characterizes every other advanced democracy. There are surely changes that should be made in the law. And it can be made. But it would be an unspeakable tragedy for millions of people if we were to repeal it.

### Moderator
Claim: Thank you, Paul Starr. Our motion is "Repeal Obamacare." And here to speak for the motion, for repeal, John Shadegg, former eight-term Congressman from Arizona and a Senior Fellow at the Goldwater Institute.

### Conspiracy Advocate (CA)
Claim: The current system is broken. There is no question about it. It's broken because it costs too much, it's broken because there are too many people who don't have insurance, and it's tragically broken because some people are denied care because they have a chronic illness or preexisting condition. We need to address those problems, and there are lots of reforms that we can to address them. We can allow group pooling. We can force the insurance companies to become cost conscious and to have to compete with each other. We can give you control over your health insurance. We can move away from third party payer systems. And we can begin to redo the system. But we don't have to say that it's not universal care. Indeed, my legislation and other legislation that Republicans have offered provide universal coverage.

My legislation says you give every single American a tax credit. For the poor, you give them a refundable tax credit, an amount of money. In the Coburn legislation and the Ryan legislation, you write specific dollar amounts for people to buy health insurance, and it's cash in their hands to go buy a coverage that they choose. So we achieve universal coverage, every single American. You can do universal enrollment as I described, where you're automatically enrolled in that process. We can deal with the problem of the uninsured without forcing a million Americans who like their current coverage to lose it, which is what Obamacare will do. You will force millions of Americans to lose the coverage they currently have and they currently like. And we can deal with the problem of preexisting conditions. I had heart bypass surgery. I have a preexisting condition. I care about this issue. I have an older sister-- my oldest sister, who has breast cancer. No one should be denied healthcare because they have a preexisting condition. But we can do that without forcing everybody out of the coverage they have now.

But rather by creating high risk pools that are funded by all the other insurance companies or by government, and helping those who are in need because they have high risks. Americans will happily pay to support people who have that kind of condition because they don’t know when they will have it next. High risk pools will work for those with preexisting conditions.

### Moderator
Claim: John-- John Shadegg, your time is up. Thank you very much. Our motion is, "Repeal Obamacare." And to speak in his closing remarks against the motion, Jonathan Cohn, senior editor at the New Republic, Senior Fellow at Demos, and author of "Sick: The Untold Story of America’s Healthcare Crisis and the People Who Pay the Price."

### Scientific Advocate (SA)
Claim: There was a question at some point that talked about the human side to this, and I wanted to just take this and say that’s where I started. About 15 years ago I started interviewing people all over the country, and I met people who had their own firsthand experiences with the healthcare system, and I remember very, very vividly a man in upstate New York who had a good job, a good college education, was a defense contractor, he lost that job, he got the job back, but without benefits, and because of that, two years his wife who was ill did not get any medical visits, ended up she had cancer, it went undiagnosed, she died, and the family had to declare bankruptcy. For me, hearing that story and literally hundreds like it is where this all starts for me. This is a problem we have had in this country for a long time. It is a problem that keeps getting worse. Two years ago we had a presidential election. And we debated, what are we going to do about this? One, President Obama won, the Democrats got in and this was job number one. They reached out to the Republicans. They took ideas that Republicans had for years claimed as their own and said, "All right, we’ll meet you halfway, and we’ll try-- we will come up with a plan that builds on your ideas and our ideas and we’ll work together." And the Republicans walked away, and they said, "Fine. We have to go it alone, we’ll go it alone." But they kept the same ideas, they took the best from left and right, and what did they get? It’s not a perfect plan, but it is a plan that will mean 30 million people have health insurance.

It will mean that the insurance people have will be good insurance that will cover what they need. It will mean that people will have financial assistance. Congressman Shadegg never tells you this part of his plan, but the credit he would offer people isn’t enough to pay for a good plan and people with pre-existing conditions, it would basically work out to second class insurance for second class people. This is the plan they're talking about. The cost control, not perfect, it could be better, fine, as Doug Holtz-Eakin, himself, said, these are the same ideas, we all agree on them, let's work together and double them down. But repeal Obamacare? Tom Harkin said, "This is a starter house, it’s got a good foundation, and it’s got room for expansion." I say let’s keep that foundation, let’s build onto it, and let’s not repeal Obamacare, let’s not start over, let’s go forward.

### Moderator
Claim: Thank you, Jonathan Cohn. Our motion is "Repeal Obamacare." And finally, to speak for the motion, for repeal, Douglas Holtz-Eakin, who is President of the American Action Forum and a former Director of the Congressional Budget Office and former advisor to John McCain.

### Conspiracy Advocate (CA)
Claim: I thank you for listening tonight and this is ultimately a debate about our future and I don’t think anyone should question the aspirations or good will of either side of this stage in terms of what one would like in affordable coverage for every American and access to high quality care. Those values are shared. What is at issue is what is the best way to go forward and to try to build on this foundation, one that is riddled with financial cancer and one that has only window dressing at attempting to deal with the real problems of the American healthcare system is a dangerous place to begin and it should be repealed in favor of a real future of the American healthcare system. Now, we’ve heard that somehow the Republicans got all their ideas and I believe that the vigorous debate tonight would stipulate that’s not the case. This is not something on which we can build a future. This is a dangerous beginning.

It does not fix the broken programs that are threatening the financial future of the United States. Medicare and Medicaid are not touched by this program. They are important pieces of the social welfare system in the United States. They deserved the attention of the healthcare reform. They were dismissed as unimportant. Instead we got a strategy to double down on those broken failures and try to write checks to paper over a broken system and in the process we are threatening the very future of this country, threatening the freedom and prosperity of Americans on which the healthcare system and everything else will be built. And we are most tragically doing it at the expense of our youngest and most vulnerable, our kids. They didn’t get a vote. They aren’t going to be able to believe what we have done to them when they grow up. They will pay the bills now. They will pay the bills later. They won’t see higher quality care. They’ll see more expensive care. And we will, in the process, take many of them into systems that ostensibly give them “access” but where no physician can treat them, no hospital will want them in their beds and they will not get good care and they will be broke to boot.

Repeal Obamacare today.

### Moderator
Claim: Thank you, Douglas Holtz-Eakin and that concludes our closing statements and now it’s time to learn which side has argued best. We’re having you vote twice, once before the debate and again after the debate and we’re going to get the results and choose the winner. We’re asking you to go to the keypad at your seat. Our motion is “Repeal Obamacare.” If you agree with the motion after hearing the debate, push number one. If you disagree, push number two. If you remain undecided or became undecided, push number three. And we’ll have the results of that vote in about 90 seconds but before we get to that, I just want to thank both teams for coming to this debate with the kind of arguments that they did. We aspire to ideas here and we certainly heard them tonight.

Thank you to all of our debaters for the way that they conducted themselves and did this-- Thank you also to those of you in the audience who asked questions. I like your passion. I’m glad that question got in there. Thank you for doing that, for forcing that issue. We’d like to first of all thank the American Clean Skies Foundation for helping to underwrite this season of debates. This season we have a theme throughout the winter and the spring for all five of our debates. That theme is “America’s House Divided” and we are focusing on themes that reflect this division, this basic philosophical division in our society. Our next debate is Tuesday, February 15th. The motion on that Tuesday night is “Two Party System is Making America Ungovernable.” Arguing for the motion are New York Times op/ed columnist David Brook and co-founder and editor-in-chief of Huffington Post, Arianna Huffington.

Against the motion we have Zev Chaffets who is a journalist and he’s the former director of the government press office in Israel where the system is a parliamentary system and works differently. His partner arguing against the motion is P. J. O’Rourke, a political satirist and author of “Don’t vote, it just encourages the bastards.” Tickets to those debates are available through our Web site and at the Skirball box office and do not forget to follow the Intelligence Squared U.S. on Twitter and to make sure to become a fan on Facebook. If you do that you can get a discount on our upcoming debates. And for those of you who want to learn more about our debate topics, you can now visit the online research center that we have at Intelligence Squared’s Web site, that’s IQ2US.org. All of our debates can be heard on NPR stations across the country and you can watch this debate on Bloomberg television starting next Monday at 9:00 p.m. So visit Bloomberg.com to find out your local channel. Alright. It’s over now. I have been given the results. Remember you have been asked to vote twice in this debate, once before and once again at the end.

And the team that has changed the most minds is declared our winner. And here it is. Our motion is "Repeal Obamacare." Before the debate, 17 percent were for repeal. 47 percent against, 36 percent undecided. After the debate, 22 percent are for “Repeal Obamacare.” That's up five percent. Seventy-two percent are against. That's up 25 percent. Six percent are undecided. The motion, “Repeal Obamacare” is defeated. That's it for us at Intelligence Squared. Thank you from John Donvan, and we'll see you next time.
