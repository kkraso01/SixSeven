# Debate Transcript

Topic: The Equal Protection Clause Does Not Require States To License Same-Sex Marriages
Motion: The Equal Protection Clause Does Not Require States To License Same-Sex Marriages

Debate ID: 060215%20Same-Sex%20Marriage


## Round 1

### Moderator
Claim: So I want to welcome to the stage-- just want to make sure I have titles correct, although I know the gentleman personally. Nicholas Quinn Rosenkranz, he is director of the Rosenkranz Foundation and a professor at Georgetown University. And Jeffrey Rosen, he is president and CEO of the National Constitution Center and a professor at the George Washington University Law School. Please welcome them to the stage.

There you go. You can sit down and grab a mic. Jeffrey Rosen. I want to start with you. First let's talk a bit about the exhibit downstairs because it relates directly to what we're doing here tonight.

### Moderator
Claim: It's so exciting. You, ladies and gentlemen, are the first people in the United States to have seen the first exhibit in the United States that describes the constitutional evolution of gay rights in the courts. And what's so exciting about this exhibit is that it examines a constitutional question, not a political question, and presents all sides.

And it shows how courts have changed their views about the status of gay rights. And it culminates in-- at the end, asking you to vote about whether or not you think that the Constitution requires the states to recognize marriage equality. And that is the very question that you're going to be voting on tonight. And the timing of both the exhibit and this debate, just weeks before the Supreme Court is expected to hand down a landmark decision about the meaning of gay rights in the Constitution, couldn't be better.

### Moderator
Claim: And, Jeffrey, just take a moment to explain that point, that this is a debate where everybody has a view, they have their own sources of information, their own value systems. But we're looking at it deliberately through a very, very specific lens tonight.

### Moderator
Claim: Yes. This is going to be a constitutional debate, not a political debate. And when I started at the National Constitution Center two years ago, I think during my first weeks I went to see Nick Rosenkranz, my friend and fellow law professor in DC.

And I said, and he agreed-- we both had a meeting of minds-- let's have a special series between the National Constitution Center and Intelligence Squared that will have constitutional debates and not political debates. What does that mean tonight? It means that you might believe that marriage equality is a fundamentally moral and necessary policy matter. But you don't think that the Constitution requires it. Or, conversely, you might think that marriage equality is a really bad idea, and you'd like to preserve tradition, but you do think that the Constitution requires the States to accept it.

So what Nick and I are trying to do with this series-- which I think is among the best things that the National Constitution Center is doing, I'm prouder of our collaboration than anything else we're doing-- we're going around the country, debating issues in constitutional, not political, terms, from NSA surveillance to campaign finance reform. We're asking you to think not what you believe is a policy matter but what you think the Constitution requires or does not require.

And that's the way I'd like you to view this debate tonight, recognize there are good arguments on both sides of this question, have an open mind, and vote for the side that you find most constitutionally persuasive.

### Moderator
Claim: So in a sense it's what lawyers would have to be saying to judges to make the case. And Nick Rosenkranz is going to now share-- share with us some of what-- give us an-- a sense of a glossary of terms and concepts that would help us ease into this framework.

### Moderator
Claim: Sure, so just a few things you might want to keep your eye on during this debate, I'll leave the substance to the debaters, but you'll see the Equal Protection Clause up on the screen. The first thing, of course, is pay careful attention to the text of the Constitution. That's going to be the most important touchstone for us. Second thing to keep your eye on is the role of history. So, of course, traditional marriages existed for millennia.

And in 1868, when the Equal Protection Clause was ratified, when the 14th Amendment was ratified, gay marriage was literally unthinkable, inconceivable. Does that matter? What role should that play in our analysis of the meaning of the Equal Protection Clause? Just an important thing to keep your eye on. Another thing you might want to keep your eye on is quite what kind of equality are we talking about? This debate has really been framed in terms of-- or the Supreme Court case has been framed in terms of equality between gay people and straight people. But consider the law never actually makes a distinction based on whether or not you are gay. The law never says, "You can't marry Steve because you're gay." The law says, "You can't marry Steve because of your gender." And does that matter? Should this really be-- should we be talking about this as a matter of gender equality more than as a matter of sexual orientation equality?

What do we think about that? And just keep your eye on that. And then, you know, a third thing you might want to keep your eye on is at bottom this question, like all constitutional questions, is a matter of who decides, who's going to get to make this choice here in the United States? Most things here in the United States are left to democracy. For most things, state legislatures get to decide, and state legislatures have been expressing their views about this.

Some states have legalized gay marriage. Other states have not. But is this one of those things that democracy does not get to decide? Is this a thing that the Constitution removes from the democratic process and says, "You know what? Even if 80 percent of you in Utah don't want this, you have to have it anyway"? Is this one of those things? Does the Equal Protection Clause require that? So those are some of the things you want to keep your eye on as we listen to this debate tonight.

### Moderator
Claim: There will be a quiz at the end of this for all the law students. Let's thank Jeffrey Rosen and Nicholas Rosenkranz and bring our debaters to the stage.

Let's spontaneously explode into applause and bring our debaters onto the stage.

Same-sex marriage, everybody's got a view on it. More states than ever before are licensing it. But in most cases that was not initially because of a law being passed, enshrining same-sex marriage as a right. Most often it was because courts struck down laws that were passed against it. Judges are making the call, using the Constitution for their guide, which is a different filter on the issue from the ones that most of us use.

But what then does the Constitution tell us about same-sex marriage? Well, it sounds like there must be a debate in that, so let's have it, "Yes," or, "No," to this statement, "The Equal Protection Clause Does Not Require States To License Same-Sex Marriages," a debate from Intelligence Squared U.S. I'm John Donvan. We are in Philadelphia, partnering with the National Constitution Center, for one of our constitutional debate series programs. We have four superbly qualified debaters who will argue for and against this motion, two against two, "The Equal Protection Clause Does Not Require States To License Same-Sex Marriages." Our debate will go in three rounds, and then our live audience here in Philadelphia will vote to choose the winner. And only one side wins. Let's meet our debaters. First of all, please welcome John Eastman. Ladies and gentlemen, John Eastman.

John, welcome. You are chairman of the board of the National Organization for Marriage, a professor at Chapman University's Fowler School of Law and Founding Director of the Center for Constitutional Jurisprudence.

You are counsel of record-- that organization is counsel of record in two of the briefs that are filed in the Supreme Court's same-sex marriage case, and you have an insider's view, personally, of the Supreme Court because you were a former clerk for Justice Clarence Thomas. Any doubt in your mind where he would be on this issue?

### Conspiracy Advocate (CA)
Claim: No more doubt on my mind on his views than on Justice Ginsburg's views on the case.

### Moderator
Claim: And Justice Ginsburg being the left-leaning member of the court. Ladies and gentlemen, thanks, John Eastman. And John, your partner is?

### Conspiracy Advocate (CA)
Claim: My partner is Sherif Girgis, and he's an Ivy League-educated expert on the institution of marriage.

### Moderator
Claim: Ladies and gentlemen, Sherif Girgis.

Sherif, you are also arguing for the motion that The Equal Protection Clause Does Not Require States To License Same-Sex Marriage. You are co-author of the book, "What is Marriage? Man and Woman: A Defense." You're currently pursuing both a PhD in philosophy from Princeton and a law degree from Yale.

You've got a lot of free time on your hands.

You were born in Cairo, but didn't stay there very long. Isn't that right?

### Conspiracy Advocate (CA)
Claim: Right. Actually, I grew up mostly in Delaware, which, in other parts of the country, is a conversation-stopper.

### Moderator
Claim: But it's the first state.

### Conspiracy Advocate (CA)
Claim: That's true. Yeah. The first ones to sign on to the Constitution. We had nothing to lose.

### Moderator
Claim: Ladies and gentlemen, Sherif Girgis. Our motion is “The Equal Protection Clause Does Not Require States To License Same-Sex Marriage.” We have two debaters arguing against it. They're against the “Not.” Let's please welcome first Evan Wolfson.

Evan Wolfson, you are founder and president of Freedom to Marry. You are author of the book "Why Marriage Matters." You are widely thought of as the architect of the national marriage equality movement.

And we read recently that your greatest hope is that the Supreme Court's upcoming same-sex marriage ruling will put you out of a job. Does that mean early retirement for you?

### Scientific Advocate (SA)
Claim: Well, I do hope that the Supreme Court will allow Freedom to Marry to close its doors, having achieved its mission. But neither my temperament nor my finances will really allow for retirement. So, hopefully there-- and fortunately, there are many other good causes to plunge into.

### Moderator
Claim: All right. Well, we're glad to have you on our stage, and we want to know--

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: --who is your partner?

### Scientific Advocate (SA)
Claim: My partner is my good friend Kenji Yoshino.

### Moderator
Claim: Ladies and gentlemen, Kenji Yoshino.

Kenji, you're a professor at New York University School of Law. You're the author of a lot of books, including the just-released "Speak Now: Marriage Equality on Trial." That tells the story of the Hollingsworth v. Perry case out in California that overturned Proposition 8, California's ban on same-sex marriage. Considering what's coming up on the Supreme Court's docket this season, the timing for that book could not be better. Was that the plan all along?

### Scientific Advocate (SA)
Claim: I wish I could claim such prescience, John, but it was totally happenstance. And I can say that the two people in the country who could match the same-sex couples who wanted to get married and wanted the Supreme Court to take the case, in terms of their euphoria when the Supreme Court finally did take the case, were my editor and my publisher.

### Moderator
Claim: Publishing is happy. Ladies and gentlemen, Kenji Yoshino and the team arguing against the motion The Equal Protection Clause Does Not Require States To License Same-Sex Marriage. Now, this is a debate. One team will win and one team will lose. And that decision will be made by our live audience here in Philadelphia. By the time the debate has ended, you will have voted twice, once before hearing the arguments and then again after hearing the arguments. And the team whose numbers have moved the most in percentage point terms, between those two votes, will be declared our winner. So, let's register your first vote. Take a look at those keypads at your seat. There are 10 digits on them. You only need to pay attention to 1, 2, and 3.

Take a look at the motion. Look at it carefully. The Equal Protection Clause Does Not Require States To License Same-Sex Marriages. If you agree with this motion, push number 1. And if you disagree, push number 2. And if you are undecided, which is a perfectly reasonable starting position, push number 3. You can ignore the other keys. They're not live. And if you push the wrong key by mistake, just correct yourself and the system will lock in your last vote. And pay attention to this-- to the word "not" in the motion today. Don't get caught by that.

Okay. Looks like everybody's registered. Let's move on to round one. Round one, opening statements by each debater in turn. Our motion is "The Equal Protection Clause Does Not Require States To License Same-Sex Marriages." Here to speak first for this motion, Sherif Girgis, co-author of the book, "What is Marriage? Man and Woman: A Defense."Ladies and gentlemen, Sherif Girgis.

### Conspiracy Advocate (CA)
Claim: Well, thank you. And first I want to say it's a huge honor to be speaking opposite these really distinguished guests. I mean, Evan Wolfson, as they said, is the architect of the movement for same-sex marriage. He's a remarkable visionary and leader whatever you think of the substance of the issue. And Kenji Yoshino it rightly regarded, including by lots of my conservative friends, as one of the best teachers in the legal academy and certainly one of the best writers. I think you'll see all of that on display tonight.

And it would worry me, except that I think that you can be fully onboard with their view of same-sex marriage as a policy matter and still agree with us that it's one of those very important policies where the Constitution's just silent. It leaves you free to pick. And the reason, in a nutshell-- and I'm going to be focusing on big picture in this part-- is that the Equal Protection Clause is not enough. It says don't be arbitrary.

So have a reasonable vision of what marriage is and of its public purposes and apply it equally, not arbitrarily. It doesn't tell you what vision of marriage to adopt. But that's what this whole debate is exactly about. Do we adopt the consent-based view of marriage that says it's fundamentally about deep romantic love and commitment and that the reasons to recognize it are stability and dignity, in which case, yes, recognizing that equally requires recognizing same-sex relationships.

Or do we have a different vision of marriage? The more traditional vision in our law, the conjugal view of marriage that says marriage is fundamentally about that union in which a man and a woman are coming together and oriented to family life by the very nature of the bond, the act that makes marital love is the kind of act that makes new life. The only relationship that can give kids a shot at being reared by their own mother and father.

The problems for the other side in this particular debate are that the Constitution doesn't tell you which of those views to adopt, and there's nothing inherently wrong with the conjugal view. And they're going to say that's not true. That last part's not right. The only way you could make your way to the conjugal view is if you were motivated by animus. I think this is one of the easiest parts of the argument to solve, and I'd be interested to see if they have a response to it. History disproves this. This isn't the only way you can get to this view.

In fact, there have been cultures that span the spectrum of attitudes towards homosexuality and still have the conjugal view of marriage in their law, cultures that we're perfectly aware of and celebrated long-term same-sex relationships-- in ancient Greece in various forms, for example-- but still thought it had nothing to do with marriage; cultures that were totally ignorant of our concept of gay identity. They didn't even know of the class in the way that we do today, to have animus against it. Couldn't have been motivated by animus.

They might say, well, maybe the view itself isn't motivated by animus, but the idea that same-sex marriage has anything to do with linking kids to their own mom and dad does. It's unreasonable. There's no link. And the problem with that view is that even some prominent same-sex marriage supporters reject it or reject something very close it. So, for example, E.J. Graff says, of course, ideas have consequences. Changing our idea of marriage is going to have consequences for marriage, practice. And he says, in particular, it will be breathtakingly subversive to recognize gay marriage. It will introduce a revolt against the institution to its very heart, forever cutting the link between it and diapers.

Andrew Sullivan says, of course, it's going to liberate us from not just complementarity but lots of other patriarchal or oppressive norms that restrict the personality, like sexual exclusivity, norms that were tailor-made for opposite-sex relationships.

Masha Gessen, a same-sex marriage advocate said it's a no-brainer that the institution of marriage shouldn't exist and that this is a stepping stone to its deinstitutionalization. They all agree that sexual complementarity, the idea of a man and woman coming together as mother and father to their kids and marriage law historically are all linked together. They just disagree on whether it's good or bad to delink them. So whatever you think of that view, you might reject it.

But it can't be motivated by irrationality. And maybe someone will say, well okay, so the case law makes it clear that we can't have this vision of marriage. Professor Yoshino sometimes points to Turner that says, look, you don't lose your marriage rights when you enter a prison because after all you can have things like emotional commitment. And Professor Yoshino will say, well, there we go. That's the revision, the consent-based view being enshrined in our case law.

But just two lines down it talks about the expectation of ex--- of consummation. It talks about the legitimation of children born into the union.

It's clearly taking for granted the conjugal view that had always been the law and just saying, apply that equally. That's the pattern for all the cases that he has brought up in his own writings. The last thing might be this: Well, it just imposes a separate status, a disadvantage and so a stigma that's Justice Kennedy's words about DOMA. Maybe that's the problem, just excluding same-sex relationships is all. That's directly a violation of equality. You don't have to go to all this stuff about picking views and which one's based on what reasons.

And the only problem with that view is that if it works against this vision of marriage, it works against all of them. Every marriage law creates a separate status. The whole question is where to draw the lines and do we have a reason for drawing them where we do? Does it make sense? Does it serve any public interest? Nothing our opponents tonight will say-- can say will undermine the idea that there may be-- that it's reasonable at least-- whether you agree with it or not, to think that it's worth preferring biological parenting wherever possible, giving kids their best shot at it by using our marriage law unobtrusively to do that and leaving other adults to live and love the lives of their choice.

Thank you.

### Moderator
Claim: Thank you, Sherif Girgis.

Our motion is "The Equal Protection Clause does not require States to license same-sex marriages." And here to present his argument against this motion, Evan Wolfson. He is founder and president of Freedom to Marry. Ladies and gentlemen, Evan Wolfson.

### Scientific Advocate (SA)
Claim: Thank you. Thank you, John. My friend, Professor Yoshino will address the arguments put forward by the opposition in support of continuing discrimination in marriage. In my time, I will focus on the Constitution's command of equality and the importance of the freedom to marry to same-sex couples, and thus why you should vote against the motion. I think it's important to begin by noting, we're not talking here about same-sex marriage, some other new thing.

What we're talking about is the freedom to marry. The freedom to marry is the fundamental right affirmed by the Supreme Court at least 14 times. In the United States, rights belong to individuals, not categories. A super majority of Americans now support the freedom to marry for gay couples. Several polls showing over 60 percent with majority support in every region of the country and across virtually every demographic. Now, even if there were not majority support, the courts should uphold the Constitution.

But the shift in public opinion tells us something. It tells us about the growing understanding as to how and why the Constitution does apply to gay people's lives and dreams and to our claim under the Constitution. As Americans have gotten to understand the real consequences of exclusion from that right of marriage, and as Americans have gotten to see real families not just theoretical categories and stereotypes and prejudices.

They've come to understand how the Constitution's command applies equally to loving and committed couples of the same-sex. The courts, too, like the American people, have shed what Justice Blackman in his dissent in the infamous 1986 case, Bowers v. Hardwick called "willful blindness." And in the past two years, 65 courts-- state and federal, appellate and trial level, Republican appointees and Democratic appointees,-- have ruled now in favor of freedom to marry with only the smallest handful coming out the other way, one of which is now on appeal to the United States Supreme Court. And in all those 65 cases, my favorite passage comes from the case in which we brought the freedom to marry to Utah.

The judge in that case says, "It is not the Constitution that has changed, but the knowledge of what it means to be gay or lesbian." Only those who are willfully blind to the common humanity of gay people today can deny what is clear under the Constitution. The Supreme Court, for example, has long recognized, "The freedom to marry is one of the vital personal rights essential to the orderly pursuit of happiness by free men.” Loving v. Virginia. The court, in another marriage case went on to say, "The right to marry is of fundamental importance for all individuals." Gay people share the same mix of reasons for wanting and needing the freedom to marry and for wanting and needing respect for their lawful marriages as non-gay Americans do.

And the Supreme Court has spelled out what these attributes, what these aspects, what these interests in marriage are.

My opponent just referred to the case, the case of Turner v. Safley, the case asking the question whether prisoners could be arbitrarily denied the freedom to marry. And in that case, the Supreme Court enumerated four important attributes of marriage. "Marriage," the court said, "under our constitution, in our time," not ancient Egypt, Rome, and Greece, under our Constitution and our time, "the important attributes of marriage," the court said, "are: number one, the opportunity to make a commitment to another person and to make a statement publicly about that commitment and have that commitment reinforced and ratified by the community in the law; number two, the spiritual and religious and personal meanings that marriage brings to many; number three, the prospect," the court said, of what the court called "physical consummation," which we usually call something else, particularly on a Saturday night; "and, number four, the tangible and intangible protections and responsibilities that marriage brings under our system of law."Gay people share an equal and vital interest in every single one of these important attributes. The freedom to marry is important. And, therefore, to be denied it is to not be treated equally, which, under the command of our Constitution, is a guarantee each and every American has. Under the Equal Protection Clause a classification, particularly one that disadvantages a historically disfavored group of Americans, or a classification that implicates fundamental liberties, fundamental freedoms, or individual dignity, under the Equal Protection Clause, the government must have a sufficient and legitimate reason for drawing that line because the Constitution guarantees that all Americans subjected to a classification must be treated alike.

In this case, because of the importance of what is being denied and because it is being denied to a group of Americans who are historically disadvantaged, who have been oppressed, who have been discriminated against, not only in private life but by the government itself, there's all the more reason for the courts to apply what court after court have now done, a meaningful review. And under that meaningful review, there is no justification for continuing this discrimination. And you should vote, "No."

### Moderator
Claim: Thank you, Evan Wolfson. And a reminder of what's going on, we are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two against two, fighting it out over this motion, "The Equal Protection Clause Does Not Require States To License Same-Sex Marriages." You have heard two of the opening statements, and now on to the third.

I'd like to welcome to the lectern John Eastman. He is the Henry Salvatori professor of law and community service at Chapman University Fowler School of Law, where he also served as dean. Ladies and gentlemen, John Eastman.

### Conspiracy Advocate (CA)
Claim: Thank you very much. I, too, am delighted to be here and to participate in this debate with such esteemed colleagues. In the brief that Evan Wolfson filed in the Supreme Court in the marriage case that's currently being heard there, he repeated over and over again, "The real definition of equal protection is-- comes to us from Supreme Court precedent. It's not a requirement that everybody be treated equally no matter what the circumstances, it's that all persons who are similarly situated shall be treated alike." And he repeats this over and over again.

On page seven on the brief the operative presumption is that the legislature has presumably permissively determined that the persons affected by a classification are not similarly situated in the first place. The real question for us is whether the Equal Protection Clause require us to understand or to adopt one version of marriage by which everybody agrees people are similarly situated.

If the institution of marriage is simply about the loving relationships between adults and the dignity that the state might confer on that relationship, then there's no reason to distinguish one set of relationships from another. But if marriage is about something different than that, if it's about that unique biological complementarity of men and women structured in a institution that gives life to the offspring of that relationship, then it's quite obvious that same-sex and opposite-sex couples are not similarly situated. And it doesn't violate Equal Protection not to treat groups who are not similarly situated differently. That's the real question for us, what is the very purpose of marriage therefore?

Is it for the state to confer a dignity, to recognize this adult relationship, as Evan has claimed? Or is it something else, something much more profound? Why is it that every society in human history, across cultures and ages, have adopted something very similar to the man/woman understanding of marriage that we're talking about today?

It's because there's something inherent in the nature of men and women, and that function that they alone can provide that is essential to the marital relationship and to the creation of the next generation. When the Supreme Court 14 times in its cases has talked about marriage as a fundamental right, it has always been in the context of that basic understanding. In Loving v. Virginia, it went on in the sentence after the one Evan quoted to say because it's necessary-- it's essential to our very existence and survival. That's not true if you remove from that purpose of the institution this unique procreative ability of men and women.

So, what is the purpose of marriage? What is the state's interest or reason for getting involved in the institution of marriage at all? There are all sorts of relationships that the state doesn't have anything to say about: friendships, brother-sister relationships, mother-father, cousins, all sorts of relationships. The state has no interest in getting it-- even if they're very loving relationships, even if they're romantically loving relationships.

That's not why the state got in the marriage business in the first place, and why it is the third party in every marriage contract. It's this unique procreative ability of men and women. And the third is, if we're going to radically redefine that purpose to be about adults rather than that child-centered focus, who decides that question? Well, in our society, in almost every case, the Constitution does not settle those questions. It leaves it up to the people to decide. And that's the real question we have here.

Has this constitutional provision adopted in 1868 already decided this question for us, and said, "You know, you people, you don't get to decide this question." We're not talking about discriminating against a group of people. That the Constitution has decided. We're talking about redefining a core societal institution to be a dramatically different purpose than it has ever had before. That question the Constitution doesn't decide. And it's that question that we have to answer on the get-go.

So, we've got a lot of history here to try and figure out what exactly this purpose of marriage is. You go all the way back to California cases-- I'm from California, so I'll start with some there-- 100 years ago, we had this clear. The first purpose of matrimony, by the laws of nature and society, is procreation. And then 100 years later it shows it hasn't changed. The sexual procreative and child-rearing aspects of marriage go to the very essence of the marital relation. Justice Kennedy, in his opening of his opinion in the Windsor case, striking down the Defense of Marriage Act just two years ago, he says this at the very beginning: "For marriage between a man and a woman, no doubt it's been thought of by most people as essential to the very definition of that term. And to its role and function throughout the history of civilization." Those are the questions-- those-- that's what we understand marriage to be. And it takes a radical redefinition of it, a change in its core purpose, to create-- to create an equality of claim here.

And it's that change in purpose that raises a lot of concerns and raises the state interest about not changing this.

So, what happens if we just change the institution of marriage? Well, we've got an experiment with this. 50 years ago, we changed another core aspect of marriage-- the norm of its permanence. We did it by adopting no-fault divorce laws. We said, you know, if things hit a bump in the road, you can get out of your marriage a lot easier than you could. Everybody said at the time "It won't affect the institution of marriage. It won't alter your marriage." But what we've seen over those 50 years is a dramatic reduction in the societal norms the-- the incentive that the institutional understanding, the definitional understanding provided.

People no longer-- in many instances-- think that marriage is a life-long commitment. "It's a life-long commitment unless I hit bumps on the road, ceases to be in the way of my adult fulfillment, and then I get out of it." That little shift changed it from a child- centered institution to an adult-centered institution.

And it has had dramatic consequences. Well, we're now talking about a shift that's even more profound, to remove the gender complementarity, the gender diversity in the raising of children-- all of those things-- to make this more about the adult relationship than the child who are the offspring of that man-woman union-- is going to dramatically reduce the incentives that that institution provides as a cultural norms-- cultural--

Sorry.

I ran out of time. I wasn’t watching.

--very much.

### Moderator
Claim: John Eastman. I'm sorry.

### Conspiracy Advocate (CA)
Claim: Sorry.

### Moderator
Claim: Your time is up.

### Conspiracy Advocate (CA)
Claim: I ran out of time. I wasn’t watching.

### Moderator
Claim: Thank you very much.

### Conspiracy Advocate (CA)
Claim: --very much.

### Moderator
Claim: Thank you, John Eastman.

Our motion is The Equal Protection Clause Does Not Require States To License Same-Sex Marriages. And here to argue against this motion, Kenji Yoshino. He is the Chief Justice Earl Warren Professor of Constitutional Law at the New York University School of Law. Ladies and gentlemen, Kenji Yoshino.

### Scientific Advocate (SA)
Claim: So I, too, am so honored to be here with esteemed colleagues to debate this crucial issue.

And I want to begin with the language of the Equal Protection Clause, which says, "No state shall … deny to any person within its jurisdiction the equal protection of the laws." When this language was ratified in 1868, we were coming off of a civil war. And the framers of that amendment could easily have limited the equality in question to the context of race. In fact, if we look at the adjacent, roughly contemporaneous 13th and 15th Amendments, the three together known as the Reconstruction Amendments, we see that there are limitations to race, to color, to the previous condition of servitude.

So why is it that the framers did not cabin the notion of equality to race, but instead adverted to a higher level of generality and said, this means equality for all individuals.

I would offer to you that they jumped up to that level of abstraction because they wanted to leave it to intelligence of successive generations to determine what equality meant for them.

Indeed, if the Equal Protection Clause had not been framed in these majestic and soaring abstract terms, gender equality would not have been able to be a heightened scrutiny classification, by which I mean a classification that draws the particular solicitude of the court, moving us from the presumption that a law is constitutional to moving us to the presumption that it's unconstitutional when heightened scrutiny is applied. Gender discrimination would not be a protected classification under the Equal Protection Clause if we adhere to the understanding of equality that obtained in 1868.

So the question for my opponents is, do they believe that the meaning of the Equal Protection Clause, even though it was textually framed at that level of generality, does not protect women as a heightened scrutiny classification.

And if it protects women, then why would it not protect sexual orientation? I would also offer to you that we can think about this, as Mr. Rosenkranz said at the beginning of this debate, either as a sex discrimination issue or as a sexual orientation discrimination issue. If we think about it as a sex discrimination issue, they will already make bars on same-sex marriage presumptively unconstitutional. If we think about it as a sexual orientation discrimination issue, this is a harder lift, because the Supreme Court has not yet taught us or told us whether or not heightened scrutiny will be applied in a formal way to the classifications based on sexual orientation.

So I want to make the steepest climb. I want to both assume that the most deferential level of review will be applied by the court under the Equal Protection Clause.

And I want to assume the definition of marriage that was forwarded by my opponents and to say that the Equal Protection Clause requires, right, gays to be included within the institution of marriage even if we understand that marriage has at least a procreative dimension. The first thing I want to point out here, going to Professor Eastman's comments about the propagation of the species, is that gay individuals are not infertile. Gay individuals procreate. And in fact, my husband and I have two children, and those two children are among the hundreds of thousands of children in this country alone who are being raised by same-sex couples.

So the argument has to be that we're doing a worse job at raising them-- and this would be Mr. Girgis' point-- than heterosexual couples are doing with their children. And I would only say that this is not a theoretical question. It's an empirical question.

And every major professional organization that touches the interests of children-- including the American Academy of Pediatrics, the American Medical Association, the American Psychiatric Association, the American Psychological Association, the National Association of Social Workers-- all of these professional organizations have said that gay parents are doing just as well as straight parents in raising their children. The kids are all right. With regard to the second rationale that might be offered, is the notion that Professor Eastman alluded to which is the deinstitutionalization of heterosexual marriage. And the idea here is that if gay people are permitted to get married, then heterosexual couples will lose esteem for the institution and engage in procreative activity outside of the institution. Now, this is counterintuitive at best, you know, as was articulated by one of the witnesses in the Prop 8 trial.

I don't think many of you heterosexual people are going to go home and say, you know, we've had a good run, but now that Ted and Steve down the street can get married, we have to throw in the towel, and we're not going to get married anymore. So I think more needs to be said empirically about the deinstitutionalization argument.

I want to close with the words of Justice Ruth Bader Ginsburg in a canonical 1996 Equal Protection case, because we are talking about equality. She said the history of our Constitution is a story in which constitutional rights and protections were extended to groups that were previously ignored or excluded. To include those groups, ladies and gentlemen, I ask you to oppose this motion. Thank you.

## Round 2

### Moderator
Claim: Thank you, Kenji Yoshino. And that concludes round one of this Intelligence Squared U.S. debate where our motion is "The Equal Protection Clause does not require states to license same-sex marriages."Now we move on to round two. And round two is where the debaters address one another directly and take questions from me and from you, our live audience here in Philadelphia. Our motion is "The Equal Protection Clause does not require states to license same-sex marriages." Arguing in support of this motion, we've heard from John Eastman and Sherif Girgis. They have argued that the Constitution does not actually settle this issue. It is not explicit at all, but they argue that the traditional vision of marriage, which they use the term "conjugal," that that vision has historical roots that need to be respected, that in fact the Equal Protection Clause is only to be summoned in situations, very rare instances when majority rule needs to be asserted, but that this is not one of those cases.

They also make the point that, repeatedly, when the court has addressed the issue of marriages of fundamental right, it has made it clear that the court, in the court's opinion, that is marriage between one man and one woman. Arguing against them, we have heard from Evan Wolfson and Kenji Yoshino. They argue that, look, it's very simple. The freedom to marry is the freedom to marry. They site the fact that there are 60 percent support in polls for single sex marriage and argue that given historical disadvantage of gay people, that only willful blindness would allow the perception that same-sex marriage is not constitutionally protected.

And they go back into history to the time in 1868 when the Equal Protection Clause was written into the 14th amendment, pointing out that they believe that it was left unspecified-- left to future generations to decide what equality was going to mean. I want to go to the team arguing against the motion which in this case means that you actually are arguing that the Constitution supports and requires states to license same- sex marriage.

Your opponents are saying that by citing the Equal Protection Clause, you can only do so by fundamentally redefining marriage, and in doing so, actually creating a new right. And I want to ask you to respond to that.

### Scientific Advocate (SA)
Claim: Yeah. I would say that we're not asking for a new right. We are a new group asking for access to an existing right. So, for example, if we look at Loving v. Virginia, or Turner v.

Safley, which my friend and colleague Evan Wolfson referred to, those are cases pertaining to interracial marriage and inmate marriage. However, when those plaintiffs sought the right to marry, they did not seek the specific right to interracial marriage. They did not seek the specific right to inmate marriage. They sought the right to marry.

### Moderator
Claim: John Eastman, you want to respond?

### Conspiracy Advocate (CA)
Claim: Yeah, I do. Look, because the test the Supreme Court has developed for addressing these equal protection questions is whether the groups are similarly situated, you have to be adopting a view of marriage in which the groups are similarly situated to make that claim. And you necessarily have to be rejecting the view of marriage in which the groups are quite obviously not similarly situated. And it's that change in the understanding of the purpose of the institution of marriage that requires us to treat this as a new claim rather than just access to the existing institution.

### Moderator
Claim: John, just for clarity, what do you mean-- just if you can be more concrete about the sense of "similarly situated."

### Conspiracy Advocate (CA)
Claim: Yeah. So-- any two adult relationships are similarly situated if the purpose of the relationship is to foster the love and commitment between the relationships. And if that's what the purpose of marriage was, then I would say it violates equal protection not to extend same-sex marriage to-- or not to extend marriage to same-sex couples, to polyamorous or polygamous couples, to consenting adults in familiar relationship of all sorts.

If instead the purpose is this unique biological complementarity of men and women that bring men and women together for the purpose of producing the children that are the result of that union, then two men are not capable of having-- women, you're saying you're fertile, that's right, but not-- you know, Kenji says at some point in his book, "To say that only men can be fathers and only women can be mothers is to engage in sex stereotyping." No, it's not. It goes to the very essence of the difference between men and women on this core biological purpose.

### Moderator
Claim: Okay. Let me bring it to-- yeah, let me bring it to Evan Wolfson.

### Scientific Advocate (SA)
Claim: Well, very quickly to that, people marry for many reasons, and we do not dictate-- we do not have the government dictating to you why you marry the person you love and what your marriage needs to be about. For many people it is about procreating. For many people it isn't. For many people it's about raising children, gay and non-gay parents raising their kids. And for many people it's not about raising kids at all. There are many reasons why people marry. And in this free society, that belonged-- that choice belongs to us, not to the government, and government is not to be used as a weapon to impose one ideological view on everyone else.

But I want to go back to your question, John, where you talked about this question of a new right. You know, from 1776 until 1948 not a single court in the country was willing to strike down restrictions on people seeking to marry someone of, quote, unquote, "the wrong sex." And finally in 1948 the California Supreme Court, John Eastman's state-- I'm not sure how you felt about it-- but John Eastman's state said that-- struck down race restrictions on marriage. And what the court said in that case was, "The essence of the freedom to marry is the right to marry the person who is precious to you. People are not interchangeable," the court said, "like trains. It's not like if someone else goes-- one goes by and you're not allowed to marry that one, you'll just marry the next one." Gay people share the same interest in marrying the person who is precious to us without arbitrary restriction by the government because that's what the freedom to marry is all about.

And that's not a new right, that's the right that we as Americans have, and it's the right that gay people seek to share.

### Moderator
Claim: Sherif Girgis, I'll come to you one last time on this question of whether it's a new right or not.

### Conspiracy Advocate (CA)
Claim: No. I mean, of course it's a new right. I mean, it's basically changing the understanding of marriage in order to say that same-sex couples are similarly situated. I mean-- so the answer to Professor Yoshino's question is of course the Equal Protection Clause applies to everybody. If a gay person walking into this building-- is this a state-run institution-- if it were and a gay person were charged one cent more, however trivial the cost, that's an Equal Protection violation. That's not what we're talking about. That just basically runs right over the question of what marriage is. And here's a clear way to put it. I want to know by what principle Professor Yoshino or Evan Wolfson would say, "Look, if someone says to you"-- and there are people who say this now-- "'There are three of us, we're three men, we've thrown our lot in for the long haul, we're committed to it through thick and thin'-- " and here's why, it's not because-- you say, "Oh, well, it's perfectly substituted.

You can settle for one." They say, "No, for our identity." That doesn't work. It's not the most fulfilling bond. Surely the principle is recognition of the relationship in which you find most personal fulfillment. We don't want to be stigmatized. We don't want our kids stigmatized. We've been forced into the closet partly because of the gay marriage progress, because we're an embarrassment to the movement, but now we want our turn. What is the answer to that? commitment--

### Scientific Advocate (SA)
Claim: I'm astonished it took them that long to go there because whenever somebody starts talking about polygamy or all this other stuff, it means they do not have an answer to the question that's on the table. Gay people are not saying, "Let's have no rules and lets have everything happen." What gay people are saying is, "Let us have what you have. Just as you have the freedom to marry the person who is precious to you and to build a life together under the law, so would we to seek that-- "

### Moderator
Claim: Are you, however, then to some degree calling upon tradition? You do want to preserve certain traditional aspects, for example, monogamy.

### Scientific Advocate (SA)
Claim: I'm not sure where you came to that from what I said, but what I--

### Moderator
Claim: Well--

### Scientific Advocate (SA)
Claim: say is that--

### Moderator
Claim: --I think that you were-- I think you were casting aspersions on their argument that things were going to move to polygamy. And so I'm coming back and saying, "Huh, well, that sounds as though you are-- you would not support polygamy," and that you do not think that, that would be a right, that you actually have--

### Scientific Advocate (SA)
Claim: --no.

### Moderator
Claim: And I'm not debating you. I'm actually looking for clarification.

### Scientific Advocate (SA)
Claim: Right, and what I said is when people try to drag the conversation over to polygamy, it's that they don't have an answer to the question that we're debating tonight, which is, "What reason does the government have for excluding loving and committed gay couples from what other couples have?" We could have a million different other debates--

### Moderator
Claim: Actually, I--

### Conspiracy Advocate (CA)
Claim: It wasn't an evasion, actually. I just wanted to come to this point.

### Moderator
Claim: Sherif Girgis.

### Conspiracy Advocate (CA)
Claim: Here's what I was saying. I was saying you have a principle by which you say whether people are being excluded unfairly or not. Now, we can just name our principle, we can pick it out of a hat. Then, of course, we could win by stipulation. I could say, "Well, my principle is any man and woman as long as one of them has freckles.

And of course we would laugh at them and we can say, "Oh, go apply it equally." I'm asking you why your vision isn't arbitrary compared to this better one. Not the one person--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --I find most

### Moderator
Claim: Let--

### Conspiracy Advocate (CA)
Claim: But the relationship--

### Moderator
Claim: Let's let Kenji answer that question.

### Scientific Advocate (SA)
Claim: There're so many answers to that. But let me just begin with one, which is-- you know, where Chief Justice Roberts is going during oral arguments with-- by asking whether this is sex discrimination. So, if you actually think about the current definition of marriage that you hold, and you say, "A man can marry a woman but a man cannot marry a man," that is spatial sex-discrimination. So, he asks whether this is sex discrimination. And I think that on its face, it's very hard to argue that it is not.

So, when we get to the issue of polygamy, if you have polygamists coming in on the day after the Supreme Court rules, hopefully, in favor of same-sex marriage this June, and they say, "We want to get married," numerocity is not a heightened scrutiny classification in this country, right? So, the sex discrimination argument drives a clean wedge in between the argument about what we're keeping intact about marriage and what we're changing about marriage.

And I would go on, just a little bit, to say, you know, Mr. Girgis has written a very, I think, thoughtful book about-- called "What is Marriage?" about the marriage debate. And essentially, he says that-- three principles of marriage-- one is that there's a kind of mind-body union, which is only attainable, apparently, by heterosexual couples. The second is that it is oriented towards family, right? And then the third is it that it is monogamous and it is hopefully permanent, right, because I don't think you're against all divorces. I think you're against only no-fault divorce.

So, I go down each one of these, and I say-- well, let me go in reverse order. I think gay couples are just as capable of monogamy and of permanence. I think gay couples are just as capable of having children in the same way that adoptive parents who are heterosexual have children.

So, unless you want to denigrate, you know, adoptive parents who are heterosexual, unless you want to denigrate heterosexuals who use assistive reproductive technology-- with the assistance of a sperm donor or an egg donor-- unless you want to denigrate sterile couples, I think that it would be an arbitrary distinction to keep out gay couples simply because they can't procreate internal to the union. And with regard to the mind- body union, essentially, what Mr. Girgis says in his book is that a man and a woman-- even if both of them are sterile-- accomplish something in their sexual coitus that is different in kind-- right, not in degree-- from two men having sex with each other, right?

And so, if anyone is stipulating something, or suggesting that something should be given to him simply by fiat or stipulation, I would posit that it is the person who says, "There's just something categorically different, even in the absence of procreation, about heterosexual sex and coitus that makes it categorically different from homosexual sex."

### Moderator
Claim: Well, Sherif, would you make that point to a judge? Would you make-- actually make that argument? Well, do you stand by that characterization, and would you actually say, "Well, in fact, your honor, yes, there is something different, and that's what we're here arguing."

### Conspiracy Advocate (CA)
Claim: Well, I would say a couple of things about it. First of all, you know, you disparaged the Greeks and the Romans earlier. The reason in the book that we bring up people who had no connection to Judaism or Christianity, had nothing like our modern concept of gay orientation, and made remarkably convergent view of marriage-- the reason we do that is to show that there is a question for the other side that they haven't been able to answer, which is, "How did that come about?" There wasn't religion or it wasn't bigotry. And now, there are-- what Professor Yoshino's question shows is that there are ways to describe any view that make it look less plausible. But I can do that from a revisionist view, too. I can say, "What's the-- when two men throw their lot in together, and do it for the long haul, and share all the burdens and benefits of common-law what's so special about whether-- what brought them together is that they're two brothers or two best friends, or what brought them together is climax?

What's so morally significant about orgasm?" There's a way of describing the views that denigrates it, but that wouldn't be fair to Professor Yoshino, and it wouldn't be fair to mine either. Let me just take one dimension of the questions that he brought. He said, "How can two men not have a bodily union?" Well, here's the question. Why is sex integral to bodily union? Everybody in the debate agrees that somehow, if it's just about fostering and expressing affection, and vulnerability, and tenderness, than other activities can do that. And yet, in the book, we develop an Aristotelian account, where it's about coordinated action towards a single, common end that completes and encompasses them both. And that's why the kind of union that a man and a woman can have is different in that respect.

### Moderator
Claim: Let me-- I'm going to let Evan respond to that. I feel that we're losing our constitutional filter, to some degree.

Not-- no. No. Not wildly off. That's why I'm asking "Would you say these things to a judge?" I'm trying to herd you back in there. You didn't pick up on it. But let me let Evan respond.

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: But I want to try to return to the constitution.

### Scientific Advocate (SA)
Claim: Well, to try to bring it back to the Constitution, but from where Mr. Girgis just left it, the-- the Greeks' and the Romans' conception of marriage, not to mention many others in between, is not one unified history-- historical embodiment of what you're talking about that suddenly is changing. The idea of marriage, the concept of marriage, the rules of marriage were so completely foreign to anything we as Americans, particularly under our Constitution will tolerate. The subordination of women, the patriarchal domination of the household, including slaves. I mean, the ownership of the procreative rights and the ability to alienate or even kill your own children. I mean, one could go on and on and on.

And so it's just sort of ironic to hear that exalted when actually the very plain words of our Constitution guaranteeing equality and the multiple cases talking about the freedom to marry and the evident humanity of gay people seeking that freedom to marry for the same mix of reasons, some of which may have to do with children, but many of which don't and they are yet equally important and valid.

I think it really just shows, if you want to make an argument and you suddenly find something you like in the Greeks and Romans, you're willing to overlook a lot. And apparently, you’re-- willing to overlook a lot in the Constitution if you want to deny something important to gay people.

### Moderator
Claim: Okay. John Eastman, I want to-- I want to take a question to you, or are you dying to respond?

### Conspiracy Advocate (CA)
Claim: No, you can give me the question. I’ll figure out a way to respond--

### Moderator
Claim: Okay.

You can save it for your two-minute closing. So-- so the-- we understand the Equal Protection Clause being something that's triggered in relatively extraordinary circumstances, particularly when there's a disadvantaged group of people, sometimes called a class of people. And you've made the argument that this is a matter that should be left up to state legislatures because it doesn't trigger that. I want to know why you're saying,-- you know, your opponents made a compelling argument for centuries of discrimination and abuse and that, you know, the story-- the story is pretty much told, that it's time for the Equal Protection Clause to kick in on this. Why not?

### Conspiracy Advocate (CA)
Claim: Well, so-- so it requires us so have a rethinking about the purpose. And Evan has done a very nice job in turning this to why adults enter into the institution of marriage. That's not the relevant question. The question is, why did the state get involved in the marriage business in the first place. And that has nothing to do with, it lays its hands on and gives my dignity because they've given me a marriage license or it sanctions my adult relationship.

The state has no interest or business, quite frankly, in getting involved in the institution of marriage for those purposes. It's this unique procreative ability that does it. And that's-- you know, and you go back to the Greeks and every-- it's not just the Greeks and the Romans, it's every society in human history that's come up with the same thing. The leading anthropologist, Claude Levi Strauss, the family, based on a union more or less durable, but socially--

### Moderator
Claim: John, my question is a little bit different. Why should this not be decided by judges but decided by legislatures?

### Conspiracy Advocate (CA)
Claim: Because the question is, in order to treat them as an equal protection violation, we have to assume that the groups are similarly situated. That then requires that I answer a question that the Constitution does not answer: Which view of marriage are we going to have; this adult-centric consent view or the long-standing conjugal view?

That question is not answered in the Constitution. And only if you answer that question on the former is it a violation of equal protection. And that's-- and who decides that question I think is the real critical one.

### Moderator
Claim: Kenji Yoshino.

### Scientific Advocate (SA)
Claim: Yeah, I'm-- I'm a little puzzled by that characterization because, to me, it sounds like if we were debating this back in 1966 in the year before Loving vs. Virginia, it would be like saying, oh, well there are two views of marriage on the table. One view says that, you know, God put the five races-- this is actual quotation from a trial court judge-- on five different continents, and but for a violation of his will, the races would not have mixed.

So I think the hidden irony of this is that if we were to take that trial court judge's word, Europeans would all have to go back to Europe or Caucasians will have to go back to Europe, and I would have to go back to Asia and so on and so forth. So I think, that-- unintended consequences there.

But the view is, are we going to choose the vision of marriage that allows for bans on interracial marriage? Or are we going to choose the more inclusive definition of marriage that allows interracial couples access to this existing right? And to me, that's what he's saying. And I do think that the Equal Protection Clause has an answer to that. So I don't think that there's one vision of marriage that the Equal Protection Clause is impermeable to and another vision of marriage to which it speaks. I think that the Equal Protection Clause speaks to the definition of marriage that we have, right. And just to make a final point here, I haven't heard anything yet about adoptive parents or about sterile couples or about couples that use this reproductive technology or heterosexuals.

So, you know, if a 70-year-old and an 80-year-old want to get married, right, why should we allow them to marry under your vision? If procreation is so central to the definition of marriage, why would you allow individuals who could not procreate and were demonstratively unable to procreate or unwilling to procreate if they chose not to procreate when they were younger.

### Moderator
Claim: Do you want to take it, Sherif?

### Conspiracy Advocate (CA)
Claim: I do, yes. A couple-- there are a couple points in there. So, first of all, the interracial marriage thing is a red herring. Do you know where the first place in the world that interracial marriage first came up? It was in the colonial United States. Nancy Cott says this. Why? Because that was a regime of slavery. It was clearly-- now, you look at the history, it's impossible to conclude that it was about anything about oppressing marriages. To believe that there's an analogy here, you would have to believe that biological parenting-- thinking that that matters is on par with thinking that your skin color matters.

And Justice Sotomayor herself has written, in a recent case, "It's a principle recognized in our cases that the biological bond between a parent and child is meaningful." She would never say the same thing about racial purity which is the language of these-- while a second thing, on the idea that this isn't something new, here's a quote. "Enlarging the concept to embrace same-sex couples would necessarily transform the institution into something new."That is Bill Eskridge, one of the pioneer legal scholars in favor of same-sex marriage and gay rights for 25 years admitting the plain fact and just saying it's a good idea. Now, on the last point, of course, no matter what your marriage policy is, artificial reproductive technology no matter what your policy is, there will be households in which kids are being reared without a marriage at the head of the household on their vision as well. But they want to smuggle this off stage to say that that consideration just for same-sex couples requires just extending it to marriage. I say if there are concrete needs that are arise wherever kids are in a home, you need to make a policy available wherever kids are in a home, whether it's a mom and her mom who moved in to help her raise the kid because she's a single mom, which is the most common kind of same-sex parent-led household or otherwise.

### Moderator
Claim: I want to go to audience questions, so I just want to remind you, but before I do it, I just want to put one question to Evan Wolfson to take something back from what your opponent said earlier when they cited, I think 14 cases where they say the Supreme Court, when discussing marriage as a fundamental right, made it clear that it was between a man and a woman.

Do you concede that they-- that's actually accurate? And if so, does it matter? Evan Wolfson.

### Scientific Advocate (SA)
Claim: Well, it is accurate that those cases that had reached the Supreme Court and triggered the rulings in those cases were not about gay people's freedom to marry, because it's this case that has brought that--

### Moderator
Claim: Right. But-- but does that mean the silence on-- relative silence means that it would-- necessarily meant one man, one woman?

### Scientific Advocate (SA)
Claim: No, because we're talking about-- we're talking about the freedom to marry and the question is to whether the freedom to marry can be denied to this group of people, this individual, this couple and the reasons that they bring before the court.

### Moderator
Claim: The notion that there's this precedent does not weigh very heavily with you.

### Scientific Advocate (SA)
Claim: Well, I don't-- that's not a precedent.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: That's just-- that's just where we-- the record in which we've gotten to right now. And, you know, 65 courts have had no problem taking the principles that underlay those rulings and applying them now to this question involving these people being denied for these reasons.

And I just have to say, it's now my turn to be a little puzzled about the reference to children because, again, marriage is not just about children. There are many, many reasons why gay people should and deserve the freedom to marry just as many many non-gay people deserve the freedom to marry. Even Justice Scalia has said that if your argument rests on the procreative argument, your denial of marriage to gay people is on very shaky ground.

Now, I rarely agree with Justice Scalia, but when he's right, he's right. And he was right there. But what does speak in this conversation and in this debate is the voice of those children who, like Kenji's kids, are being raised by gay parents. And the denial of the freedom to marry harms those children and harms those families, and there's no good reason for it, and that's another good reason why the Constitution forbids this kind of discrimination.

### Moderator
Claim: Let's go to some questions. Just wait for the mic to come down from your right side. And if you could stand up and tell us your name, please. It's going to be handed down to you. It's back three rows. Thanks.

If you can wave to the mic. Thanks. Oh, I have this request. Really pose a question. Don't debate with the debaters. So whatever you want to say, go for it. Okay. You have the confidence, now go for it.

### Moderator
Claim: Okay. You want my name. It's Lynne Litz The question is, I would like those who are talking about children to ask if they would require, in the marriage certificate, to-- for those people getting married to swear in addition to all the other information that they have to put in, that they are going to have children or if they are unable to have children, and if that will be a requirement for marriage.

### Moderator
Claim: Okay. I'm going to-- I'm going to-- I prefer to pass on the question. And I think you can come up and chat with them because it's an interesting one, but I don't think it's helping us on the constitutional thing that you all need to vote on.

So with respect I'm going to pass on it-- right here, and you can pass the mic down front. So that's sort of what I'm hoping for, and I say that with respect to the questions that I don't take. Try to keep it on the topic. And, by the way, it was a perfectly framed question.

### Moderator
Claim: Hi. My name is Samantha Harris. And what I want to know is looking at marriage as a child-centered institution there are now large numbers of people in two-parent households, gay and straight, where it is not, I think the way that you put it was, "the best." They're not-- the child is not the biological product of the union. They may be adopted, maybe donor eggs, and maybe donor sperm.

But you have similarly situated families, two parents and a child who is not the biological child of both or either parent. And in that situation, with those two-parent households, I want to know why the state does not have an interest in affording all of those children and their parents the same legal protection.

### Conspiracy Advocate (CA)
Claim: Yeah, so look, couple of--

### Moderator
Claim: John Eastman.

### Conspiracy Advocate (CA)
Claim: --look, a couple of things, one, we don't have any evidence yet one way or the other whether issuing a marriage license itself to adoptive parents to same-sex parents has any effect on the upbringing of their children. What we do know is when it's-- when you move away from both biological parents, the increased risk to serious emotional and development problems to the children more than doubles. That's true whether the parents are same sex. It's true whether the parents are opposite sex. It's true when you have one lacking in the biological connection.

And so if you take that-- and the most comprehensive dataset we have is from the Centers for Disease Control that demonstrates-- you go from 7 percent to 17 1/2 percent risk to the kids when both biological parents are not involved. Now if that means there are 82 percent in non-biological parent households, the kids are doing just fine.

But that differential is significant. It's significant for the state's reason in getting involved in the marriage business in the first place. And when you alter the understanding of marriage that discourages a significant number of people who are the biological parents of that child from entering into that relationship and that institution for raising that child, you cause pretty catastrophic harms to kids. And that's why the state has a fundamental interest here in not weakening that institutional draw that every society in human history is settled on for the best way to encourage that relationship and that structure.

### Moderator
Claim: Kenji Yoshino.

### Scientific Advocate (SA)
Claim: Put very simply, that seems to be a very good argument on your part for why you should be against artificial reproductive technology, but not a good argument for why you should be against same-sex marriage.

### Moderator
Claim: Another question. Right there.

### Moderator
Claim: Hi there. My name is My question is for John Eastman.

So as you may be aware, marriage and familial relationships often provide-- are given a package of government benefits, you know, tax purposes, birth, death certificates, things like that. So if there can exist single parents and married heterosexual couples without children that are on the receiving end of some of these government benefits, what is the legitimate state interest in preventing same-sex couples from being on the receiving end of these same benefits?

### Conspiracy Advocate (CA)
Claim: So the same question. The state's interests-- we're not looking at any individual case, but institutionally. And if I create an institution where I encourage people to enter in that institution who have the unique capability of creating children through their own sexual relations in a way that no other relationship has, the state has an interest in encouraging as many of those people as they can in the institution of marriage, and that's why we preside-- we provide all sorts of incentives, including benefits to that.

Now, I suppose I could get more perfect in my drawing of the line. I could have some government dictate out there and say, "I'm going to-- I'm going to come by your house every Thursday night to make sure you're having sexual relations."I could do all sorts of things, but we know for a fact that when men and women have sexual relations, they tend to have kids whether by on purpose or accident. It's a result of that conduct. It's part of the nature of the relationship. And that's why we create the institution to channel that unique ability there. And if I alter that and I say, "This is all about the parents-- the loving relationship between the parents," I have undermined the reason the state got involved in the business in the first place, and I've weakened the institutional draw. Let me just-- you know--

### Moderator
Claim: Let me –

### Conspiracy Advocate (CA)
Claim: --sorry, yeah, I-- filibuster. It's--

### Moderator
Claim: --I want to remind you that we're in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, arguing it out over this motion, "The Equal Protection Clause Does Not Require States To License Same-Sex Marriages." Well, we're sort of arguing it out over that motion.

Let's see if we can-- would you like to respond to--

### Scientific Advocate (SA)
Claim: Well, I

### Moderator
Claim: --because I-- again, I-- in the end you're going to have to vote on whether you think the equal protection clause applies, which is a different issue from the policy debates that we're discussing now and effects on family. So, I want to-- I want to ask you to raise your hand knowing that that's what you're going to do. But go ahead and have a--

### Scientific Advocate (SA)
Claim: I think one of the striking consequences of the degree to which we have shown there is no good reason for denying gay people the freedom to marry is that our opponents are left making such an impoverished argument about marriage, such a dismissive argument about heterosexuals, or about parents, or what they need in order to preserve their bonds, or to get married in the first place, when in fact, what we're talking about something that it-- for many people is a high aspiration, and a worthy thing, and a thing of great dignity and meaning. And it involves kids, and it involves parents.

But it also involves people coming together in love, to care for one another. It brings families together. It knits the community together. And you would know none of that from their argument.

In fact, Professor Eastman said a little while ago that the state has no interest in any of that. All it has an interest in is imposing his ideological view about biology and complementarity. Well, I don't think that's right. And I think it's precisely because the American people have come to understand that that just doesn't hold up. It's not true that they've understood how it is unfair to sever out gay people as the one group of people who cannot get married. Octogenerians can get married. Sterile people can get married. People who renounce having children can get married. But gay people, even when they're raising children, under this view, would be denied the freedom to marry. And that makes no sense--

### Moderator
Claim: The mic is coming from your right side.

### Moderator
Claim: Hi. My name is Sheherazade Jackson and I am from a mixed couple. So, a hundred years ago, I would not have been able to get married, let alone my children would have had many issues. But my question is, are you saying the Constitution can't grow and breathe with our generation?

### Moderator
Claim: That was perfect.

Let's let-- let's kick that one around a little bit. Let's-- you want to take that? Sherif Girgis.

### Conspiracy Advocate (CA)
Claim: I think the Constitution, from the moment the 14th Amendment was passed, was big enough to say that interracial marriage is a fundamental right. At every step of the way, they have to allide over the difference between seeing marriage as a romantic bond where the other connections are by case-by-case, optional, by choice-- in which case, by the way, it does-- it's not very clear why it has to still be linked to romances. If two people who aren't romantically interested in each other, or if a single mom has her sister move in to raise the kids together, have they made their relationship oriented to family life? I mean, it goes back to this question, you know, the interests-- does the state interests change when the two adults aren't in a romantic bond?

So, I think their vision can't explain any of these connections, but I have to allide over it, whereas the interracial marriage thing is straightforward. There's no way of reading the history and thinking this wasn't fundamentally about keeping blacks and whites apart, to keep the whites on top. And the court itself said that. Here by contrast, again, it's impossible to look at the history and think the only purpose is to oppress gay people.

### Moderator
Claim: Kenji Yoshino.

### Scientific Advocate (SA)
Claim: Yeah, so, I think that one of the reasons why we keep collapsing into a policy debate is that we're offering them the lowest level of review possible. So, if you're only applying rational basis review, you ask the other side what are your even conceivable justifications-- right? And so, that's why I think we're getting a lot of policy debate and policy questions, because they're producing justifications that are, in my view, inadequate. I want to make another point, though, about the equal protection clause, to be responsive to something that Mr. Girgis said, about how is it that organizations or cultures-- cultures, really-- that were very progressive with regard to gay rights, at least on the surface, nonetheless were opposed to same-sex marriage.

So, he raised the example of the Greeks. So, I would say, this often takes, I think, the more plausible form-- and that's not a knock. I mean, Mr. Girgis has made this more plausible argument of how can we argue that in this country, same-sex marriage was the bars on same-sex marriage were not enacted with any kind of animus, given that the gay rights movement wasn't even in existence--

### Moderator
Claim: Can you give everybody-- the term animus came up earlier. Can you just give the one sentence meaning?

### Scientific Advocate (SA)
Claim: Yeah. Animus, then, is a term of art in constitutional law. It means "moral disapproval" of a particular group. And it is not-- simply moral disapproval of the bigger group is not sufficient in order to carry the day, with regard to justifying a law. And I would actually be interested in hearing both of my parties opposite.

You know, I would be very curious to know whether or not you believe-- whether you morally disapprove of same-sex relationships, not same-sex individuals, but whether or not you have moral disapproval of same-sex sexual conduct. And I think that's a relevant issue because not under the animus, torch-wielding villagers, you know, "You're a terrible people," kind of thing, but just simple moral disapproval, which is the only Constitutional standard that we need in order to cite down this ban, whether or not you have that--

### Moderator
Claim: Why is it-- again, why is it relevant to what their personal views are?

### Scientific Advocate (SA)
Claim: Yeah, but let me-- let me tell

### Moderator
Claim: Wait, I just want to send-- why is it relevant what his personal views are as opposed to the Constitutional argument?

### Scientific Advocate (SA)
Claim: Because I think that when you run out of arguments in Constitutional law, what's left is the residue. And the way that things are reasoned out under rational basis review, is you ask the other side to produce all of their justifications, and then if there’s nothing left, then the idea is there's animus involved, a simple moral disapproval.

### Conspiracy Advocate (CA)
Claim: John, we've offered lots of rationales. You disagree with them or don't like them, but that doesn't mean they're perfectly valid rationales. Here’s what was said when the North Carolina statute was proposed.

Moms and dads are not interchangeable. Two men do not make a mom, two moms do not make a dad. Children need both a mother and a father. Now, I'm going to quote that other real radical conservative on the Supreme Court, Justice Ginsburg in the VMI case—Professor Yoshino earlier, “physical differences between men and women, however, are enduring. The two sexes are not fungible. A community made up exclusively of one sex is different from a community composed of both. That's the critical understanding, this natural understanding of marriage, that it brings together the unique biological, rooted in nature complementarity of men and women for a purpose that is different than all of the collateral purposes we often assign to marriage. But the states' interest in furthering that institution for that purpose is why we are here and

### Moderator
Claim: But, John, what about the gauntlet that was just threw down, asking whether you have moral disapproval, and that's informing your argument--

### Conspiracy Advocate (CA)
Claim: It's completely irrelevant whether I think gay sex and heterosexual sex are on a moral, similar plane or not, it's irrelevant to the--

### Scientific Advocate (SA)
Claim: It's Let's say it--

### Conspiracy Advocate (CA)
Claim: It's completely irrelevant to the Constitutional question.

As it was, to what 6 million or 7 million Californians voted who voted for Proposition 8 thought about that question. The issue is under rational basis review, Professor Yoshino, as you under-- know the issue is whether there is any plausible explanation that is it rational. We have offered several, which you have not rebutted. And under rational basis review, that is more than sufficient. And, quite frankly, because of the compelling interest that the state has in fostering this bond, it meets heightened scrutiny as well.

### Scientific Advocate (SA)
Claim: So I've given you one assumption, which is to say, right, let me say, heightened scrutiny does not apply. Give me one assumption, which is to say now let's assume that, you know, I don't credit your rationales, right? So I just want a yes or no question, do you believe that there's something-- this is a policy matter, morally objectionable, about same-sex sexual conduct.

### Conspiracy Advocate (CA)
Claim: It's completely irrelevant.

### Scientific Advocate (SA)
Claim: It's a yes or a no. I don't care-- I mean, so give--

### Conspiracy Advocate (CA)
Claim: You can press it all you want. It's completely irrelevant to the Constitutional question.

### Moderator
Claim: We've reached an impasse.

### Conspiracy Advocate (CA)
Claim: It's not going to get--

## Round 3

### Moderator
Claim: And we have also reached the end of round two of this Intelligence Squared U.S. debate, where our motion is "The Equal Protection Clause does not require states to license same-sex marriages." Now we move on to round three. Round three will be closing statements by each debater in turn. They will be two minutes each. And immediately after that, we'll have you vote a second time, and your vote, the difference between your two votes will determine our winner. Motion is, "The Equal Protection Clause does not require states to license same-sex marriages." Here to summarize his position supporting the motion, Sherif Girgis. You can sit for this one. Sherif Girgis, co-author of the book, "What is Marriage: Man and Woman, a Defense." Ladies and gentlemen, Sherif Girgis.

### Conspiracy Advocate (CA)
Claim: Well, I think love and companionship and commitment and mutual care are valuable in themselves wherever they show up. Here's a quote. "I understood marriage as the rare place where law and love converge."That's from Professor Yoshino's lyrical account of his own story in conjunction with a policy case for same-sex marriages, which is what his book on Prop 8 is. It's giving you reasons for that policy. Now, here's another quote and another view. "I've never been fully out as poly. I have to live knowing that someone I love thinks that if her mother knew that she has a second partner no love and support her, take care of her kids, it might lead to shaming and rejection." Some people's innate personality means they would never feel emotionally satisfied in a monogamous relationship any more than a gay man would in a straight marriage. That's from Michael Kerry who had to write under a pseudonym in Slate.

Now, maybe Professor Yoshino wants to say that if he's against polyamory, it must mean that he thinks these are sinners. I doubt that. It doesn't make any sense as an inference. They also want you to squint at the Constitution and see that the Constitution requires ratifying Professor Yoshino's view in his book but somehow leaves this one out in the cold. I don't see that, either. They're both policy debates. Here's a third view.

A woman who-- this is from a woman who grew up in a gay welcoming community by her own lights with two moms. She said, "I have a few fuzzy memories of my father's unfamiliar voice wishing me a happy birthday. Wonderful memories with my two mothers. But one need they couldn't meet was for a father, not because they weren't good enough parents. I love a man I don't even know who, by all counts, is a lousy father. I ached for him to love me. Promoting same-sex parenting guarantees that a child will miss out on her mother or father." That's Heather Barwick writing to the Supreme Court in this case.

Look, we're not telling you any of these is immoral or moral. We're not telling you that any of them is off the table, but they are. They're saying that somehow the Constitution rules Heather's voice out of this conversation, and we're saying it treats all of them on a par.

### Moderator
Claim: Thank you, Sherif Girgis.

The motion is "The Equal Protection Clause does not require states to license same-sex marriages." Here to make his closing statement against this motion, Kenji Yoshino. He's author of the book, "Speak Now: Marriage Equality on Trial."

### Scientific Advocate (SA)
Claim: So I always wear a suit when I teach my classes in Constitutional law. And one of my colleagues once asked why I dress so formally. And I said, "I think the law is an honorable profession." And he guffawed. And he said, "Most of your graduates are going to go out and help large corporations beat the crap out of each other. So don't get on your high horse. Why do you think this is such an honorable profession?" And so I had to think about why I thought it was such an honorable profession. So I went back up to my office, and I thought about it for a while. And here's what I came up with: Were it not for the law, a life that would have previously been as unimaginable as the questioner who talked about her interracial marriage would have been unimaginable for me. At the time when I came out, I was extraordinarily fortunate that sodomy laws were on the wane and that I would no longer be deemed a criminal for engaging in sexual conduct with somebody who is same-sex.

By the time I met the man to whom I made a monogamous life-long commitment to, it was possible to marry him in the state of Connecticut. And by the time Ron and I, my husband and I, decided that we wanted to have children, surrogacy laws and adoption laws made it possible for us to welcome first a daughter and now a son into the world.

So whenever I hear people like my parties opposite, as much as I respect them, make arguments about how this is just about the selfish desires of adults rather than giving a maximum protection to our children, or that we're somehow radically changing the definition of marriage rather than fulfilling everything that marriage might mean, I always think back to my husband and to my two children and think that I have been completely deprived and inoculated of any capacity to be cynical about the law because every time I needed the door, to push a door open in my life, it pushed.

And now we're at a moment where we can stop living under the Equal Protection Clause and finally as gays and lesbians couples live up to it.

### Moderator
Claim: Thank you, Kenji Yoshino.

The motion is "The Equal Protection Clause does not require states to license same-sex marriages." And here to make his closing statement in support of the motion, John Eastman, chairman of the board of the National Organization for Marriage.

### Conspiracy Advocate (CA)
Claim: So 50 years ago, legislatively, we changed one of the core aspects of marriage with no fault divorce, and that's had pretty dramatic consequences. If you change an institution, you're necessarily going to change that institutions norm-inducing behavior. In 2012, the European court of human rights said that the European convention of human rights, their Constitution does not require member state governments to grant same-sex couples access to marriage. And yet just last week Ireland voters chose to do that.

What we're asking here is that the same thing applies in our Constitution. It doesn't settle this question.

The question ought to be up to the voters on whether we're going to embark upon such a fundamental retransformation of the very purpose of the institution of marriage. Justice Kennedy himself, a year ago, said that "the respondents in this case," in a different case, "insist that a difficult question of public policy must be taken from the reach of the voters." That is inconsistent with the underlying premises of a responsible, functioning government. He went further. He said, it's demeaning to the democratic process to presume that voters are not capable of deciding an issue of this sensitivity on decent and rational grounds.

He says, "Freedom embraces the right, indeed the duty, to engage in a rational civil discourse--" we've had one tonight "-- in order to determine how best to form a consensus to shape the destiny of the nation and its people." If we settle this through the normal political means, we will all have a much greater stake in the resolution than if it’s imposed on us by the court. Abraham Lincoln, in his first inaugural address said-- addressed that point.

A candid citizen must confess that the policy of the government upon vital questions affecting the whole people is to be irrevocably fixed by decisions of the Supreme Court the instant they are made an ordinary litigation between parties and personal actions. The people will have ceased to be their own rulers, having to that extent practically resigned their government into the hands of that eminent tribunal. The Constitution doesn't settle this question. We ought to let, "We, the people," do it.

### Moderator
Claim: Thank you, John Eastman.

And the motion is, "The Equal Protection Clause Does Not Require States to License Same-Sex Marriages," and here to make his statement-- his closing statement in opposition to the motion, Evan Wolfson. He is author of the book, "Why Marriage Matters: America, Equality, and Gay People's Right to Marry."

### Scientific Advocate (SA)
Claim: A little over a week ago I flew home to Pennsylvania where I grew up to celebrate my sister's wedding. And after 10 years together-- 11 years together with her longtime partner, she and Patty were able to marry because we had brought the freedom to marry to Pennsylvania.

At the wedding were our parents, my niece and nephews, my brothers, my sister, of course, getting married, Patty's family, our friends, their friends and family, and it was beautiful. In a few days my husband and I will fly home again to Pittsburgh to celebrate my parents' 60th wedding anniversary. And I am quite sure that my parents, as we toast them and celebrate 60 years of love and commitment and joy and sacrifice and dedication, will insist on offering a toast to my sister and her wife. Nobody's wedding took anything away from anybody else's wedding. Nobody's marriage took anything away from anybody else's marriage. There was enough marriage to share.

And sharing the rights that guarantees the joy, the love, the dignity, the support that our Constitution makes affordable to all of us is exactly what our Constitution requires. What our Constitution does not require and does not tolerate is that we have to ask permission of others to share in the same freedoms, the same rights, the same dignity that are our birthright as Americans under the Constitution. The Constitution guarantees the freedom to marry, and there is enough marriage to share. Happily, a majority of Americans have come to understand this. An overwhelming majority of judges now, who have had to look at these kinds of arguments and assess the evidence, have found it, too. And I urge you to do what we hope the Supreme Court will do, reject this discrimination and affirm the freedom to marry for all.

### Moderator
Claim: Thank you, Evan Wolfson.

And that concludes round three of this Intelligence Squared U.S. Debate, where our motion is, "The Equal Protection Clause Does Not Require States to License Same-Sex Marriages."And now it's time to learn which side you feel has presented the stronger argument. We're going to ask you again to go to the keypads at your seat and vote a second time. Take a look at the motion-- we'll put it up on the screens-- "The Equal Protection Clause Does Not Require States to License Same-Sex Marriages." If you agree with this statement, if you're with this side, push number one. If you disagree with it, you're with this side, push number two. If you became or remain undecided, push number three. And we'll lock out the votes in just a minute, and then we'll have the results about one minute after that.

But while we're waiting, I just want to say, you know, John Eastman said in his closing statement that we had a civil and respectful discourse here tonight, I agree with that. There's a-- you know, this is one of those where there is a very, very large, large gulf, and it can get very personal. And it did, but not in a way that was-- I don't think hurtful. It was respectful, and respect was shown by all sides to all sides. So I want to congratulate all of you for how you conducted yourselves and for the level of debate you brought.

And, again, even the questions that I didn't take, I want to thank everybody who got up and asked a question, and especially down in front for your wonderful question where I had to stop you from going on. It was perfect. So thank you for that, and it was great to have all of your participation today in the debate. I want to thank also our partners in this, the National Constitution Center. We love doing this series and taking these constitutional cracks at these issues. And I take your point, this was one where it's hard to keep the public policy out of it because in a certain way it actually becomes relevant to the arguments that are going to be made before judges in any case. The program was also made possible through a grant from the John Templeton Foundation to the National Constitution Center. Our thanks also to the foundation for that.

And I want to thank everybody who bought tickets for tonight's event and would love to see you coming to future events and also visit us in New York. Our ticket sales do not come close to covering the cost of mounting one of these debates. So, if you are-- if the spirit moves you, if you go to our website, IQ2us.org, you can make a donation. Every gift really does count. And it keeps us going so that we can do more. If you happen to find yourself in Aspen this summer-- if you happen to find yourself in Aspen this summer –

--I shouldn't read things straight from the card. If you happen to find yourself in Aspen this summer, having arrived there by your private jet, we will be, I'm happy to say, partnering with the Aspen Strategy Group on August 9th. We're going to be debating ISIS. And tickets will be available through our website again. And we're going to be back in New York for our fall season, which will include another debate partnered with the NCC, but that one will be in New York. And we're going to be announcing our fall lineup-- full fall lineup this summer, but you can get that on our website as well.

So, I have the final results. Again, the team whose numbers have changed the most between the first and the second votes will be declared our winner. The motion is this The Equal Protection Clause Does Not Require States To License Same-Sex Marriages. On the first vote, 13 percent agreed with that motion. 53 were against. And 34 percent were undecided. Those are the first results. Remember, the team that changes the numbers most between the two votes is declared our winner. Let's look at the second vote. The team arguing for the motion, their second vote was 14 percent. That was up one percentage point. That will be the number to beat, one percentage point. Let's see. The team arguing against their motion, their first vote was 53 percent. Their second vote was 83 percent. They pulled up over 30 percentage points.

So, that's the team arguing against the motion declared our winner. They argued against the motion The Equal Protection Clause Does Not Require States To License Same-Sex Marriages.

Our congratulations to them, and thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
