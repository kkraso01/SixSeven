# Debate Transcript

Topic: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization
Motion: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization

Debate ID: 033115%20War%20Powers


## Round 1

### Moderator
Claim: We're delighted to have you taking part in this-- what for us is a special series, the fact that we have the word, "constitutional," in the motion is very relevant.

And I want to now bring to the stage Nick Rosenkranz, who is at-- a professor at Georgetown University, and with Intelligence Squared U.S. as well, to talk about how-- why it is we're framing the debate this way and what this series is all about. So let's please welcome to the stage Nicholas Rosenkranz. So as I just told the audience, the constitutionality of this issue is critical. It's why the word is in the motion, which to be-- clarify, that means we're not doing what tonight?

### Moderator
Claim: Yes, so we have a series of public policy debates, "Do you think X is a good idea or a bad idea?" This is emphatically not that debate. This is about whether this is constitutional or unconstitutional quite regardless of whether you think this is a good idea or a bad idea. So this is--

### Moderator
Claim: Okay, can you just bring the mic a little closer?

### Moderator
Claim: --so this is very much not a debate about your thoughts on a particular military action or on Obama in particular; this is about constitutionality. Consider, you know, a vote for Obama here tonight is-- it might implicitly be a vote for George W. Bush of yesterday or Ted Cruz of tomorrow. This is not a vote about this president or this policy; it's about constitutionality.

### Moderator
Claim: And, Nick, you are the law professor, so give us a little glossary about-- you know, take us for a minute to the text of the Constitution, and give us a little sense of what language is actually there.

### Moderator
Claim: Yeah, so the Constitution quite deliberately divides up war powers and gives some war powers to the Congress in Article I-- I see that you have got in on the screen here-- and some war powers to the president in Article II. So most importantly the president-- Congress is given the power to declare war, but on the other hand the president is given the commander in chief power.

And so this debate is largely about where the line is between those two clauses: what the significance is of Congress's power, what's the significance of the president's power, and how these clauses fit together.

### Moderator
Claim: And it would seem obvious, "declare war," what that means, but obviously this is tangled. So what is it about the reality of the world we live in that makes this a constitutionally tangled question?

### Moderator
Claim: So oddly, interestingly, the Congress has not declared war since World War II, so that was the last time-- that one was clearly a war. That was clearly a war, right? But since then we've got all sorts of military actions that are, you know, I guess you could say, "quasi-wars." They're police actions or we're hunting terrorists or we're acting in self-defense. They don't exactly look like armies marching into battle on a particular battlefield. They're much more ambiguous than that, and so that's-- how do these clauses apply to this more fluid, more modern use of our military?

### Moderator
Claim: So and that is why there is a constitutional debate.

### Moderator
Claim: That's it, exactly.

### Moderator
Claim: All right, well, we'll look forward to it. Thanks, very much, Nick Rosenkranz. Let's bring our debaters to the stage. A welcoming round of applause. Everybody settled? Terrific. I want to-- again, to kick off our broadcast, ask for one more of those special rounds of applause that you're doing so well already. In its two centuries-plus of existence, the U.S. has committed troops to conflicts overseas at least 182 times and counting.

Congress has declared war 11 of those times, and not since Pearl Harbor, and certainly not during the administration of Barack Obama, who has initiated drone attacks in Pakistan and Yemen, bombing runs in Libya, air strikes on ISIS, with his administration taking the position that he does not require a declaration of war, or really, even any sort of new permission from Congress. So, is he right? Well, that sounds like the makings of a debate. So, let's have it. Yes or no to this statement: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization, a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Miller Theatre at Columbia University. We're in partnership with the Richard Paul Richman Center and the National Constitution Center. We have four superbly qualified debaters-- two against two-- who will argue for and against this motion: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization.

As always, our debate will go in three rounds, and then our live audience here at the Miller Theatre at Columbia University will vote to choose the winner, and only one side wins. Our motion, again: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization. Let's meet the team first arguing for the motion. Welcome, ladies and gentleman, Gene Healy. Gene, you are vice president of the Cato Institute. You research there executive power and the role of the presidency. Right on target. You have said in the past that our presidential candidates talk as if they are running for guardian angel, shaman, and supreme warlord of the earth. And we like it. We got what we deserved, you said. But I want to ask, though, have we had any elected officials who are non-supreme warlords in our recent history?

### Conspiracy Advocate (CA)
Claim: Well, I'm afraid I don't have anything good to say about any of the recent ones, but I do always tell people that Warren G. Harding gets a bad rap. It's time America forgave him for teapot dome.

### Moderator
Claim: Thank you. Gene Healy. And Gene, tell us who your partner is.

### Conspiracy Advocate (CA)
Claim: The distinguished and charming Deborah Pearlstein.

### Moderator
Claim: Ladies and gentlemen, welcome Deborah Pearlstein. Deborah, you're also arguing for the motion that The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Approval. You are a professor of Cardozo Law. You served as the founding director of the Law and Security program at Human Rights First. Like your partner, Gene, you believe that the president has overreached, but you trace the problem back to the framers of the Constitution, who made what critical mistake?

### Conspiracy Advocate (CA)
Claim: If I had to sum it up, I'd say they expected that the legislature would actually want to legislate.

### Moderator
Claim: And it hasn't worked out. Ladies and gentlemen, the team arguing for this motion. Again, the motion is that The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization. Two debaters arguing against this motion. Please, let's first welcome Philip Bobbitt. Philip, you have a bit of a hometown crowd here because you are a professor at Columbia Law School, and director of its Center for National Security. You are a constitutional scholar. You've been a history don at Oxford. You've advised presidents on national security issues since the Carter Administration. You wrote, a few years back, that the seeds of confusion that surround the whole question we're debating tonight-- presidential war powers-- actually started building up 50 years ago, beginning with what?

### Scientific Advocate (SA)
Claim: I think it began with a number of senators experiencing buyer’s remorse over the Gulf of Tonkin resolution.

### Moderator
Claim: And here we are now, 50 years later. Not much progress made.

### Scientific Advocate (SA)
Claim: And counting.

### Moderator
Claim: Ladies and gentlemen, Philip Bobbitt. And Philip, please tell us who your partner is.

### Scientific Advocate (SA)
Claim: This is Akhil Amar, who has been called the most celebrated constitutional scholar of his generation.

### Moderator
Claim: Ladies and gentlemen, please welcome Akhil Amar. And Akhil, you're also arguing against this motion, that The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization. You are a professor at Yale Law. You have been described as, quote, "commendably unorthodox." Congratulations. You are also the author of a lot of books. Most recently, "America's Unwritten Constitution." So, in a sentence, tell me who writes America's unwritten Constitution.

### Scientific Advocate (SA)
Claim: The American people. We've given our hearts and minds to Thomas Jefferson's Declaration of Independence, to Abe Lincoln's Gettysburg address-- in the middle of an undeclared war, by the way-- to Martin King's "I have a dream" speech, to Brown v. Board of Education. These are all elements of America's unwritten Constitution.

### Moderator
Claim: So, a lot of history in this story and in this debate tonight. Please welcome all of our debaters. Thank you as we-- move forward to the first vote by the audience. Because this is a debate it's a contest, and you our live audience here at the Miller Theatre, will determine the winner by your vote. By the time the arguments have been presented you will have been asked to vote twice, once before and once after hearing them, and the team whose numbers have moved you the most in percentage point terms will be declared our winner. So let's register your first vote. If you go to those keypads at your seat, again, pay attention to numbers one, two, and three. Take a close look at the motion The President Has Exceeded His Constitutional Authority By Waging War Without Congressional Authorization. If you agree with this motion, push number one. If you disagree push number two. If you are undecided push number three. You can ignore the other keys, which are not live, and if you inadvertently push the wrong key just correct yourself and the system will lock in your last vote.

No one needs more time, correct? Okay. Let's move forward. Let's move onto round one. Round one, opening statements by each debater in turn. They will be six minutes each, and here speaking in the first position, I'd like to welcome to her lectern, Deborah Pearlstein. She's an assistant professor at the Cardozo Law of-- the Cardozo School of Law, and former director of the Law and Security program at Human Rights First. She is arguing for the motion: The President Has Exceeded His Constitutional Authority By Waging War Without Congressional Authorization. Ladies and gentlemen, Deborah Pearlstein.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you. Well, it's a pleasure to be here, and thank you for the opportunity. The president has certainly exceeded his constitutional power by waging war without Congressional authorization for the following reasons.

First, as Nick Rosenkranz mentioned at the top, the text of the Constitution, the history, are actually quite clear on the idea that power over armed forces, power to commit those troops, to make war wherever they do it, is shared between the executive and the Congress. The executive would have the power as commander in chief to superintend the armed forces. He would also have the power to repel sudden attacks in the event our nation came under attack, but the vast majority of the power over the armed forces, and over war making in the United States, if you look in the Constitution, it's there under Article I Section 8. It's given to Congress. They have the power to raise and support an army, to provide and maintain a navy, to issue letters of mark and reprisal, an old fashioned way of saying to appoint agents or to hire agents of the U.S. government, who would carry out lesser military actions against our enemies.

And of course, Congress also has the power to declare war. The reason this matters, the text matters, is because the purpose of the framers was also clear. The president would have the power to act in our national defense if it was necessary, but actually commencing war, risking huge sums in national blood and treasure, that no one man should have the power to do. Madison said, "In no part of the Constitution is more wisdom to be found than in the clause which confides the question of war or peace to the legislature, and not to the executive. The trust and the temptation would be too great for any one man." Now, my opponents will tell you that it's not so much what the text of the Constitution says, or even why the Constitution said it that way, but what matters is what we've actually done, and in particular, what presidents have actually done in the past, say, 50 or 60 years of the nation's history, because before that they almost always went to Congress to at least get an authorization for the use of force.

So, let's set aside for the moment the notion that it's a little bit of a weird way to interpret the Constitution by saying, well, it means whatever the president has been doing, and thinks he can get away with, in every-- any given administration. Let's set that aside for a minute. Let's also set aside the problem of that methodology, which is how do we decide we agree on what particular presidents did, and more importantly, why they were doing it. Were they acting in national defense or did they have a clear sense even in their own minds of what the purpose was for deploying force in a given case? Let's set both of those aside for now and make it clear that no president in the United States has declared or asserted an unlimited power to make war without congressional authorization. The Office of Legal Counsel-- right, this is the office in the Department of Justice that counsels the president on how much power he has to use force abroad-- recognizes in its memoranda limits that the president has to follow when he uses force without congressional authorization.

And even this president, his OLC said "Look, you can only do this without Congress if it's in the national interest, and if the force that you're using is less than war." Why does it matter? Well, of course, because the Constitution gave Congress the power to declare war. So if what you're doing is actual war, then you actually have to go to Congress. How do you tell the difference between what's war and what's not war by this president's own metric? Well, in Libya, the last time he used force without congressional authorization, he said it was because, this is a short term commitment, right? We're not going to be there very long. We're going to get in. We're going to get out. We're going to have a very limited mission, right? Just protecting civilians pursuant to a U.N. Security Council Resolution, and there will be minimal risk to Americans in any event, right? The problem today is that the conflict against ISIL in Iraq and Syria is, even by the president's own metric, war, in a constitutional sense.

The president said when he committed troops, when he expanded our operations in Iraq and Syria, that this is going to take some time. He announced a broad mission. Our mission is not to protect particular individuals or even keep the peace. Our mission is broadly to destroy and degrade another organization, ISIL, the "Islamic State" as it calls itself. By January of this year, the United States had carried out close to 10,000 airstrikes in the region; we have 7,000 contractors in our employee-- in our employ on the ground; and 4,500 military personnel already serving in the theater. "Okay," my opponents will say, "but that's fine." So what matters is not even so much what the president has done in the past. What matters is what works. We need the flexibility. The president needs the ability to respond to new threats, to new dangers. And that does matter. But in this case, that's not what's going on.

There has been more than enough time, there remains enough time for Congress to authorize the use of force. Indeed, the president has gone to Congress and asked it to authorize the use of force in the case of ISIL. There is plenty, further, of strategic cause for Congress to authorize force. Congressional authorization is an incredibly important signal. It signals our allies that we're serious about the fight. It signals our enemies that we're serious about the fight. And it signals, particularly in a conflict like this, to what our security friends call, "Wavering neutrals in the region," right? Those folks who looked at what we did in the past conflicts, they looked at Abu Ghraib, they looked at Guantanamo, they said, "I don't buy the United States," and it shows them we're as good as our word. For all of these reasons, the framers thought so; it remains a good idea. You need to vote for the resolution. Congress needs to authorize the use of force. Thank you.

### Moderator
Claim: Thank you, Deborah Pearlstein. And our motion is, "The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization."And here to argue against this motion, please welcome Philip Bobbitt. He is the Herbert Wechsler Professor of Federal Jurisprudence at Columbia Law School, and a distinguished senior lecturer at the University of Texas. Ladies and gentlemen, Philip Bobbitt.

### Scientific Advocate (SA)
Claim: I agree. I'm not going to dismiss the text and the history. I'm not going to rely on the practices of the last 60 years. I agree. Congress should be on record about this. Congress should authorize war against the Islamic State. And I believe, and my partner, Professor Amar, believe that Congress has, that the Authorization for the Use of Military Force in 2001 empowers the president to use deadly force against the Islamic State.

Now, you may be told that the AUMF, as we’ll call it, of 2001 authorized retaliation against al- Qaeda for the atrocities on 9/11, and therefore, it can't apply to the Islamic State because the Islamic State didn't exist in 2001, and furthermore, that since it has distanced itself from the core al-Qaeda leadership, it can't be responsible for the 9/11 attack. To see if this is as clinching as it sounds, let's take a close look at the joint resolution adopted by both houses of Congress and signed into law by the president that we'll be discussing tonight. That law is not simply about holding an organization responsible for the past attacks on the U.S., but about deterring new attacks. It is not even about one organization, al-Qaeda, or about plural groups. The AUMF advanced in 2001 provided for the use-- and I will quote-- "of all necessary and appropriate force in order to prevent any future acts of international terrorism against the United States by organizations," plural, “that the president determines authorized the terrorist attacks of September the 11th.” Unquote.

If the president determines that the use of force against the Islamic State is necessary and appropriate in order to prevent future acts of terrorism by the network of which the Islamic State was admittedly a part, which had authorized the attacks of 9/11, then Congress's language is quite sufficient to authorize the actions the president proposes. To vote for our opponents, you must conclude that there is no rational way the president could make this determination, that there is no conceivable way he could find that action against the Islamic State might deter the loose network of shifting alliances that is united in its objective to found an Islamist caliphate, and by acts of terror like 9/11, to intimidate the United States from acquiescing in this objective.

It is significant that the Congress agrees with our view. So, they have recently passed-- as we all know-- legislation appropriating funds for air attacks on the Islamic State, which they would scarcely have done if they believed the president could not constitutionally execute the legislation they passed. It is also significant that the federal courts in the Guantanamo cases have unanimously accepted the view that the Islamic State is an associated force of Al-Qaeda, bringing the Islamic State within the ambit of the charters for the use of force that Congress has passed. Moreover, there are ample precedents for using congressional authorizations for war to apply to subsequent groups when later hostilities emerge where conflict initially authorized.

The most pertinent example is not the last 60 years, but from the Philippines War in 1898, in which U.S. forces, having defeated the Spanish against whom Congress had authorized war, found themselves attacked by Philippine insurgents, who had actually fought the Spanish. U.S. forces proceeded to wage war against the Philippine insurgents without any further congressional authorization, choosing instead to rely on the initial declaration of war against Spain. No one doubts that the Islamic State emerged out of the conflict in Iraq, authorized by the AUMF of 2002, nor that it was created as an arm of Al-Qaeda-- its original name was Al- Qaeda in Mesopotamia-- against whom the AUMF of 2001 was directed. There are other examples of Albania, Croatia, Slovakia in World War II that stand to the principle that fresh authority is not needed if the new belligerent emerges from an originally authorized conflict and wages war against us.

Finally, it is simply absurd to hold that the Islamic State would be free from those pre-existing authorizations on the ground that it has changed its name or denounced its former leaders. While this might make some sort of sense in a world of nation-states, in the wars we are currently fighting, new groups pop up all the time, change their names, denounce their leaders. Just two weeks ago Boko Haram announced it was going to be part of the Islamic State. Would we really want a rule that required a fresh congressional statute every time a terrorist leader changed his name after he'd attacked us or tweeted an attack on his former allies? Congress, the courts, and the president all agree on the constitutional and statutory proposition that Professor Amar and I are asserting.

If you disagree, you must have good constitutional grounds. That's right. In the text, in the structure, in the history, you must find the case law, the historical precedents, the strategic practicality, which counts too-- and only then can you be compelled to disagree.

### Moderator
Claim: Thank you. Philip Bobbitt. And a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization. You've heard from the first two debaters. And now onto a third. We're going to welcome to the lectern Gene Healy. He is a vice president of the Cato Institute and author of "The Cult of the Presidency: America's Dangerous Devotion to Executive Power." He is arguing in support of the motion that the President Has Exceeded His Constitutional Authority. Please welcome Gene Healy.

### Conspiracy Advocate (CA)
Claim: Thank you. The president has exceeded his constitutional authority by waging war without Congressional authorization, or to put tonight's debate resolution another way, the president does not have power under the Constitution to unilaterally authorize a military attack in a situation that does not involve stopping an actual or imminent threat to the nation. You may have heard that second formulation before. It's how candidate Obama described the limits of presidential war powers when he was asked about it during campaign 2008. And it came up a lot about three years later when President Obama unilaterally launched a seven-month bombing campaign against Libya. Not only was there no actual or imminent threat to the nation in that case, but 10 days into the bombing, the president's own secretary of defense went on “Meet the Press” and admitted that Libya wasn't a vital interest to the United States.

The president took us into our latest war in the Middle East, the ongoing conflict against ISIS, last August. Here again there was no imminent threat. "We have not yet detected specific plotting against our homeland," President Obama told the country in his nationally televised address, and yet he waited six months and over 2,000 airstrikes before he got around to sending a draft request for authorization to Congress, along with a cover note insisting that “existing statutes provide me with all the authority I need to wage war anyway.” The central basis for that claim, as Professor Bobbitt notes, is the 2001 AUMF, the resolution that Congress passed three days after 9/11 empowering the president to take military action against "those nations, organizations, or persons he determines planned, authorized, committed, or aided the September 11th attacks, or harbored those who did."Now, not exclusively, but principally, obviously, al-Qaeda and the Taliban. And judging by what the people in Congress said about it at the time, the people who passed it certainly didn't think they were committing the United States to open-ended, multi-generational war. Now, nearly 14 years later, this war has gone on 10 years longer than World War II, four years longer than Vietnam, and counting. Under the 9/11 AUMF President Obama has launched six times the number of drone strikes as President Bush against groups with evermore tenuous and remote connections to the language-- to the resolution's language and original target. Two years ago Obama officials told the Washington Post that they were increasingly concerned that the law is being stretched to its legal breaking point.

That was before they'd stretched it still further. President Obama now argues that the 9/11 AUMF allows him to go after-- go to war with groups like ISIS that have not just distanced themselves from al-Qaeda, but have been denounced and excommunicated by al-Qaeda. It may even allow, and the theory-- the administration's theory of the 2001 AUMF, it may even allow him to go after ISIS’s offshoots and sympathizers as so-called “associated forces” of a force that al-Qaeda refuses to associate with. Earlier this month at a Senate hearing, President Obama's new secretary of defense acknowledged that the resolution may be broad enough to allow the president to wage war in Nigeria against Boko Haram, which recently pledged allegiance to ISIS on Twitter.

In fact, the administration's interpretation of the 9/11 AUMF is so broad they can't tell you how broad it is. For one thing, who we're at war with is classified. In testimony last May, the Pentagon's general counsel told the Senate that which groups the administration claims legal authority to target under the AUMF, well, that's something that they're "just not prepared to discuss in an open session." Meanwhile, Obama administration officials admit that there's no end in sight to worldwide war making. The war on terror will go on "at least 10 to 20 years more," which means, I suppose, that in 2032, when we're all filled with excitement about the impending presidential contest between Chelsea Clinton and George P. Bush-- we can rest assured that the winner will get to use the September 2001 AUMF as the basis for his or her presidential kill list. This is not how constitutional democracies are supposed to make the most important decision that any society can make. President Obama has exceeded his constitutional authority by waging war without congressional authorization, but it's worse than that. The arguments he's advanced will make it even easier for future presidents to do the same. I urge you to vote, "Yes," on the motion. Thank you.

### Moderator
Claim: Thank you, Gene Healy. And the motion is that “The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization." And here to argue against this motion, please welcome Akhil Amar. He is Sterling Professor of Law and Political Science at Yale, where he teaches constitutional law at both Yale College and Yale Law School. Ladies and gentlemen, Akhil Amar.

### Scientific Advocate (SA)
Claim: Good evening. So you've heard this expression a couple of times from our distinguished opponents, "AUMF." Let's just slow down a second and hear what the AUMF is. It's the authorization of the use of military force. Here's the resolution, "The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization." The AUMF is a congressional thing. It's a self-described authorization of the use of military force; that is "waging war." Sometimes-- you know, I don't know how many of you have kids, but I've got three, and sometimes my wife and I say like, "What part of, 'No,' did you not understand?" What part of the “authorization of the use of military force” are we not understanding here?

Let's go over, once again, what that statute says, because we've heard, "Well, Congress didn't intend this and didn't intend that." Congress uses words to express its intent. If they didn't want an authorization to be temporally open-ended, you know what they can do? They can put a sunset provision in that authorization that says, "This sunsets after a certain point in time." They did not do that. And they do do that in other laws. See the Patriot Act. In fact, what they say in the law very explicitly in this authorization is to prevent, quote, "any future attack against the United States by these various organizations.” Let me go over once again what it says, "The president”-- the president-- "is authorized to use all”-- what part of all don't you-- "necessary and appropriate force against nations," with an S, "organizations," with an S, "and persons he determines”-- and I think I will concede in brackets-- in good faith and reasonably, on the basis of information that he has that not all of us have in this room, frankly, "that he determines planned, authorized, committed, or aided the 9/11 attacks, or harbored such organizations or persons," okay? "in order to prevent any future attack," okay?

Now, if you know just general legal principles, you can have persons and organizations, who are aiders and abettors after the fact. They're harborers after the fact, and that's what ISIS is. It's an offshoot of al-Qaeda, as you've heard. Here's what winning a war actually means: sometimes you smash one organization, and it splinters, and now you have to deal with the splinters, you know? Hercules is making some progress when he slices off each of the heads of the hydra, but initially you get two that grow back. But it's the same basic hydra, and you've got to deal with the root. It's the same problem.

So-- and the president gets to make this determination, at least if it's in good faith. These, ladies and gentlemen, ISIL, ISIS, involve some of the same persons. You have not heard our distinguished opponents deny that, and I'd like to hear if they deny that they're some of the same persons. And that's not fighting everyone around the world at any time. No one in this room is a member-- was a member of al-Qaeda, a leader. So it's only certain organizations that have the same persons. ISIL and ISIS are using the same tactics, the tactics of terror, as al- Qaeda. They have the same murderous purpose, and frankly it's a murderous purpose to murder us, and our ideals, and-- which takes me to the fourth point-- they have the same target, us, U.S. That's U.S., the United States, that's us, small U, small S, no periods.

Okay? Same persons. At least a subset of them. Same terror tactics. Same murderous purpose. Same target. You heard my distinguished colleague, Professor Bobbitt, channel Shakespeare. "What's in a name?" You know, so they-- so they changed their name. Are you going to allow the same-- you know, this offshoot entity to escape the clear language of this authorization, which is about preventing future attacks, just because they changed their name? I invoked Lincoln earlier. By the way, you know that Civil War wasn’t a formal declaration of war back then. But Lincoln was surely not exceeding his authorization because-- his constitutional authority because Congress actually authorized it-- although not by formal declaration-- in the same way that Congress authorized John Adams, in the same way that Congress authorized Thomas Jefferson.

We don't have to just pick the last 50 years. And John Adams is fighting the French. And Jefferson is fighting the Barbary Pirates. And these are not formal, declared wars, but they are congressionally authorized military actions. So, let me-- let me just close with Abraham Lincoln-- since I invoked Shakespeare. And I told you, he's part of our unwritten constitution. There's a reason he's up there on Mount Rushmore. And you know, he's a very simple, common- sensical fellow who says, "If you call a tail a leg, how many legs does a dog have?" And the answer, ladies and gentlemen, is four. Because calling a tail a leg don't make it so. Okay? And changing the name doesn't mean that this is any different from the very forces that this authorization of the use of military force was essentially about. Thank you very much.

## Round 2

### Moderator
Claim: Thank you, Akhil Amar. And that concludes opening statements in this Intelligence Squared U.S. debate, where our motion is: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization.

And now we move on to Round 2. In Round 2, the debaters address one another in-- directly, and they take questions from me and from you, our live audience here at the Miller Theater at Columbia University. We have this motion in front of us: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization. The team arguing for this motion-- that the president has gone too far-- Deborah Pearlstein and Gene Healy have argued that it's right there in writing. It's in the Constitution. Congress declares wars, not the president; that this president, President Obama, has taken more license with war- making than any president in history; that ISIL is an enemy in the conventional sense of conventional war, and therefore, all of the normal rules should apply.

But presidential actions, like the bombing of Libya, amount to one man unilaterally taking the nation to war without-- in some cases-- justification of true threats to the nation, and that this is not how a constitutional democracy makes the most important decisions that it ever has to face. The team arguing against the motion-- Akhil Amar and Philip Bobbitt-- are arguing that indeed the president has the authorization to take the war to ISIL, that it is the same authorization that was given to George Bush in 2001 after September 11th to defeat enemies, such as Al-Qaeda. It was inherited by Barack Obama; that its elasticity is a matter of practicality, because the enemy changes, and it hasn't changed that much; that in a lot of ways, the guys in ISIL are the same people, with the same tactics, and the same target-- us-- as the target that was chosen by Al-Qaeda on September 11th.

I want to take that part of the argument to the team that's arguing for the motion and ask them about that notion: that, in fact, what-- the authorization given to George Bush in 2001 still applies, primarily because we're still fighting the same guys in the same extended war. Do you want take that, Deborah Pearlstein?

### Conspiracy Advocate (CA)
Claim: Sure. So I find the notion, to use the word, absurd. The text of the authorization for the use of force doesn't name them. Congress never conceived that ISIL was the group that they meant to be authorizing force-- again, in part, because ISIL and even Al-Qaeda in Iraq-- as it used to be called by the United States-- didn't exist in 2001. And this group, just because it once had some association with Al-Qaeda that did exist in 2001, isn't it. You know, the United States is an offshoot of Great Britain in some fundamental way, but I'd like to think, after a certain time and a certain set of disagreements, you can tell the difference--

### Moderator
Claim: But do--

### Conspiracy Advocate (CA)
Claim: --between one and another.

### Moderator
Claim: Deborah, do you concede the sameness argument, that they're-- they might be somewhat different people, different name, but that their game is the same?

### Conspiracy Advocate (CA)
Claim: I don't. In fact, it's not just a name. It's a fundamental mission. So, when Al-Qaeda attacked us on 9/11 and before, Osama Bin Laden named the United States its primary enemy. He declared war against the United States. He attacked the United States repeatedly. He viewed the United States and its political operations and factions in the Middle East as the source of the problem. ISIL is in essence an apocalyptic cult. They fight the United States today for the same reason that they fight al-Qaeda today, because they believe that they are not true believers of Islamism in the way they believe it should be practiced, and they do not take the United States as its enemy per se any more than they take anyone else. In other words, it’s not just the name that’s different, the mission of the group--

### Moderator
Claim: Okay. Let me take that to your opponent. Phillip Bobbitt, do you want to respond to that?

### Scientific Advocate (SA)
Claim: Sure. The current leader of ISIL, the Islamic state, al-Baghdadi, said when he was released from our custody where he'd been for some months, “I'll see you next in New York.”

### Moderator
Claim: And your silence speaks for the rest of your thought. I'll take it back to Gene Healy.

### Conspiracy Advocate (CA)
Claim: Yeah, the notion that all they did was change their name is not right, as Deborah's pointed out. I'd also say that, as she pointed out, the ISIS strategy is to focus on the near enemy. Al-Qaeda's strategy is to focus on the far enemy. The fact that ISIS has local apocalyptic and monstrous goals may explain-- and the fact that they're locally focused probably helps explain why evey major figure in the national security establishment, from the chairman of the joint chiefs to two heads of the National Counterterrorism Center, has said that there is no evidence that ISIS has plans or major capability to attack the homeland.

### Moderator
Claim: I'll take that to Akhil Amar.

### Scientific Advocate (SA)
Claim: So remember that the authorization of the use of military force that I tried to read slowly and carefully to you addresses not just the original organizations, but any other organizations or persons that aided them or that harbored them, and their successors. So, it's about, I think to paraphrase my partner, a broad network of affiliate organizations. I should've also probably said it's the same basic theater of war and the same geographic target, namely New York--

### Moderator
Claim: Okay, respond to Gene's point, though, that this particular group, ISIL, is not necessarily-- actually, stronger than that, that it appears not to be a direct threat to the United States. Is that relevant?

### Scientific Advocate (SA)
Claim: Well, the president of the-- that might go to the wisdom of, and proportionality of what sort of force is to be used, but he invoked a lot of people that I don’t actually see in this authorization the use of military force.

What I see talks about the president, not the joint chiefs of staff or anyone else. In our system we elect a president, and actually we elect him because we think he has good judgment. He tells us basically what his fundamental approach is, and actually we re-elected him-- and that was true of Mr. Lincoln and that's true of Mr. Obama-- and he's the one who determines that he has to have some evidence for it in good faith and I've seen no evidence of that

### Conspiracy Advocate (CA)
Claim: There might be some limits to that proposition, right? The president determines, he alone. So if the president determines alone in a fit of pique that China is in fact now al-Qaeda, right, does the authorization for the use of military force to authorize the president to go after those who attacked us on 9/11 authorize the president to use force against anyone?

### Scientific Advocate (SA)
Claim: How many people who are in charge of China have any-- are the same people who are in al- Qaeda? And the answer is zero, okay? There are a gazillion organizations in the world and nation states, and they do not have any overlap whatsoever with the original al-Qaeda.

### Conspiracy Advocate (CA)
Claim: We detained people in Guantanamo who were from China. We let them go actually not all that long ago, right? So the notion that there are some of the same people in some of these same places I think is insufficient to establish what the administration says, which is not that ISIL is an associated group of al-Qaeda or an off-shoot, but that ISIL is al-Qaeda, right? The administration can't say they're an associated force. ISIL and al-Qaeda are shooting at each other.

### Scientific Advocate (SA)
Claim: I'm glad you mentioned--

### Moderator
Claim: Phillip Bobbitt.

### Scientific Advocate (SA)
Claim: --Guantanamo. What do you do with the fact that all the Guantanamo cases that have considered this, every single federal court that's considered this question, has held that the Islamic state is in fact an associated force with al-Qaeda? What do you do with that? What do you do with the fact that--

### Conspiracy Advocate (CA)
Claim: Which court has held that--

### Scientific Advocate (SA)
Claim: --Congress-- what do you do with the fact that Congress has authorized funds for air attacks on the Islamic State? You say, what do we do if Barak Obama decided to attack Brooklyn, or what would we do if they decide to attack Norway, what would we do-- well, one thing you would do is that Congress would say this is not appropriate, as the statute requires, but the Congress has spoken about this. What do you guys say about the authorization of our air attacks on the Islamic state? That's

### Moderator
Claim: Deborah Pearlstein.

### Conspiracy Advocate (CA)
Claim: If I took everything that Congress does as proof of its constitutionality, I would have to challenge, right, Marbury versus Madison. Just because Congress has passed a law doesn't mean the law Congress has passed is constitutional.

### Scientific Advocate (SA)
Claim: So you think the authorization for funds for air attacks on the Islamic state is unconstitutional?

### Conspiracy Advocate (CA)
Claim: I think--

### Scientific Advocate (SA)
Claim: Fine. Why?

### Conspiracy Advocate (CA)
Claim: --I don't think-- Congress's authorization--

### Moderator
Claim: Does it violate the text--

### Conspiracy Advocate (CA)
Claim: --for the use of funds is constitutional, but I don't think we can take their authorization for the use of funds as a commentary on whether or not they think the president has the power to wage war without congressional authorization.

### Moderator
Claim: Can we take a-- can we take a little bit--

### Scientific Advocate (SA)
Claim: congressional authorization. See, there's authorization of the use of military force, and then there's a second congressional authorization with the House and the Senate and the president once they actually know who's being bombed.

### Moderator
Claim: Can we take a step back from these specifics for just a bit and then return to them? But I just want to go a little bit to the constitutional-- to the textual issues, and just ask each of you, by looking at the language of the constitution what does-- what power does it give Congress over-- what check does it give over the president in your opinion, in the broad, in broad principle? And I'll go to this side first. Either one of you wants to take it, Gene Healy, or Deborah Pearlstein.

### Conspiracy Advocate (CA)
Claim: Well, as Deborah said, the bulk of the war powers are with Congress. The declare war clause, which Madison identified as the part of the Constitution, where the most wisdom was to be found, is an independent check on-- or it was intended to be an independent check on presidential ability to initiate war. All the-- you know, most of the framers who spoke about this power, James Wilson, the architect of the presidency, said, "This system will not hurry us into war. It is calculated to guard against it."And he identified the declare war clause as the clause he was talking about. George Washington wasn't sure he had the power to launch offensive operations against Indians without an authorization from Congress. So this was an important check. Moreover, where does the president get the power? The president doesn't get the power from the commander in chief clause, and Alexander Hamilton said that was-- that meant nothing more than that he was the first general and admiral of the United States, and generals and admirals don't get to decide whether and with whom we go to war.

### Moderator
Claim: All right, let me take that to the other side. Do you agree with that assessment of

### Scientific Advocate (SA)
Claim: I'm surprised.

### Moderator
Claim: Philip Bobbitt.

### Scientific Advocate (SA)
Claim: I thought-- and I must say, I was very impressed by this-- I thought our opponents were not going to say that we required a declaration of war. I thought their point was that we required congressional authorization. It could be by a declaration of war, it could be by a joint resolution, it could be by a statute, but we had to have congressional authorization.

Now Mr. Healy begins to suggest that perhaps that isn't enough, that you also need a declaration of war. Now, if we want to talk about that--

### Moderator
Claim: Well, I didn't ask-- wait, wait, wait-- in fairness to Gene, I did not ask him whether there needed to be a declaration of war in this instance. I was asking him in the broad principle where the power line goes.

### Conspiracy Advocate (CA)
Claim: You don't need the magic words, you didn't-- it was recognized from the first generation that you did not need formal authorization. You need some kind of substantive authorization that perhaps is renewed more than once a generation.

### Scientific Advocate (SA)
Claim: How about a statute whose title is, "The Authorization of the Use of Military Force," that--

### Scientific Advocate (SA)
Claim: --explicitly has no sunset and says that it applies-- it's adopted in order to, quote, "prevent any future attack of a 9/11--"

### Conspiracy Advocate (CA)
Claim: You've mentioned that clause several times, and the actual history of that--

### Scientific Advocate (SA)
Claim: --yeah.

### Conspiracy Advocate (CA)
Claim: --no, the actual history of that clause was the Bush administration's original draft of the AUMF gave the president the power to deter and-- an independent power to deter and preempt all future acts of terrorism against the United States.

That was so horrifying to a Congress, even in the aftershock of 9/11, that they changed that language to dis-link that as an independent power.

### Scientific Advocate (SA)
Claim: To apply--

### Conspiracy Advocate (CA)
Claim: He has the power to go after persons or organizations linked to 9/11 for the purpose of--

### Scientific Advocate (SA)
Claim: --linked to al-Qaeda, linked to the folks who did it in 9/11, and that's our claim, these guys are linked to them.

### Scientific Advocate (SA)
Claim: I think it's an important distinction--

### Conspiracy Advocate (CA)
Claim: Well, they're shooting at each other.

### Scientific Advocate (SA)
Claim: --the language isn't linked to 9/11. The language is linked to the perpetrators of 9/11.

### Scientific Advocate (SA)
Claim: Aiding or harboring them, ex-ante or ex-post--

### Conspiracy Advocate (CA)
Claim: The language isn't linked. The language is “responsible for the attacks of 9/11.”And I want to come back to the question that was posed here a minute ago, which is "Why is it that we should have”-- and we all agree, right, some congressional authorization is required-- the notion is, "Well, you don't have to say specifically who the enemy is, right? The enemy can be al-Qaeda, the Taliban, associated forces, people responsible for the attacks of 9/11, or whoever, right? The reason why you need Congressional authorization and the reason why you have to name who the enemy is, is the same. It is in order for Congress to have a meaningful check in a democracy. You can't lead a people into war without telling them who they're going to war against and why. So--

### Scientific Advocate (SA)
Claim: So, this is--

### Conspiracy Advocate (CA)
Claim: --that's why naming the enemy is as important--

### Scientific Advocate (SA)
Claim: This is--

### Conspiracy Advocate (CA)
Claim: --as the authorization in the first place.

### Scientific Advocate (SA)
Claim: This is the second time that you've actually suggested-- at least the second time-- that the real constitutional culprit here is not the president, but that Congress has somehow passed an unconstitutional statute, which is a very odd proposition to me.

### Conspiracy Advocate (CA)
Claim: I don't think I was suggesting Congress passed a--

### Scientific Advocate (SA)
Claim: So, Congress passed a statute that didn't read the way you would have drafted it, mentioning al-Qaeda by name, and for very good reasons, because we wouldn't want to let them change their-- you know, just call themselves "Shal-Qaeda" or, you know-- they actually-- you're saying, "Well, unless you actually name the organization, it's not valid." And we're saying, where did you get that from?

### Conspiracy Advocate (CA)
Claim: I'm saying the statute is entirely constitutional. And all three branches of government have concluded that the statute authorized the use of force against three groups-- al-Qaeda, the Taliban, and associated forces. ISIL is not the Taliban. The administration says they're not associated forces, because after all, they're fighting with each other. The administration says they're Al-Qaeda, and I'm telling you, there's no sense in which they're Al-Qaeda. And I'm not the only one who says that, because I'm after all, not that persuasive, right? You've got to read the West Point Counterterrorism Center report. You've got to read, actually, a wonderful piece in the Atlantic about who ISIL is. And no matter what the president says, at some level, there's got to be a recognition of who we're talking about. And this isn't it.

### Moderator
Claim: Philip Bobbitt.

### Scientific Advocate (SA)
Claim: Well, this is what puzzles me. You say we have to read a West Point manual, but you're not prepared to take what every federal court that has considered this matter has said: that the Islamic State is an associated force. You say, "We want to reassess this and decide how the phrases ought to have been used." But you're not prepared to answer what you do with a Congressional appropriation.

### Conspiracy Advocate (CA)
Claim: I haven't--

### Scientific Advocate (SA)
Claim: This is a--

### Conspiracy Advocate (CA)
Claim: that it--

### Scientific Advocate (SA)
Claim: If I may just say one more thing.

### Conspiracy Advocate (CA)
Claim: --what federal court is it that has--

### Scientific Advocate (SA)
Claim: In the Guantanamo--

### Conspiracy Advocate (CA)
Claim: --opined on ISIS?

### Scientific Advocate (SA)
Claim: --in the Guantanamo cases. These are Guantanamo prisoner cases. Habeas--

### Conspiracy Advocate (CA)
Claim: They didn't talk about ISIL at all. It didn't exist then.

### Moderator
Claim: Let me move onto another question, to the side that's arguing for the motion that the president has exceeded. Your opponents have-- on the one hand, while arguing that ISIL is the same as the-- essentially, the same as the group that was specified in the 2001 authorization, they're-- they also argue that the state of-- in the state of the world today, war is a very changing thing, that it would be-- as Philip Bobbitt said-- absurd to have to issue a new resolution every time a new entrant showed up on the field, a new combatant showed up on the field.

Some permutation of-- and that you just can't-- you can't operate that way, which is a very compelling argument. I want to see what your response is to that, Gene Healy.

### Conspiracy Advocate (CA)
Claim: I think the president has residual powers under Article II to deal with-- you know, Deborah mentioned the phrase, "Repelling sudden attacks," which comes up at the Constitutional Convention. And I think you can be flexible with that. I don't think you have to be wedded to an 18th century understanding, or one that doesn't comport with modern warfare. But you do have to-- for the president to legitimately use this reserved Article II power, it has to actually be a threat to the country. And it--

### Moderator
Claim: Was Libya--

### Moderator
Claim: --was Libya a threat?

### Conspiracy Advocate (CA)
Claim: Not in the remotest sense.

### Moderator
Claim: Let me take that to the other side. Libya. Your response. Akhil Amar.

### Scientific Advocate (SA)
Claim: I'll say something about Libya in one second, but-- again, just remembering the statute, the statute is about not just repelling attack, but preventing future attack, okay?

Now, if we-- if they've conceded on ISIL and ISIS-- I'm happy about that. If that's now put off the table, and now we're just talking about Libya, I'm happy to address Libya. And--

### Moderator
Claim: For the record, they have not conceded.

### Scientific Advocate (SA)
Claim: Okay. Well--

### Moderator
Claim: I believe you say you won the point, but they have not conceded.

### Scientific Advocate (SA)
Claim: Now, on Libya-- just like a simple point. You know, how many body bags were there in Libya? And apart from one embassy attack, this does not seem to me like full-blown war.

### Moderator
Claim: Ah.

### Scientific Advocate (SA)
Claim: And there's language in the war powers resolution-- and if you want to read my piece on this, I wrote a piece in Slate on this that I think actually authorized the use of force in that situation.

And you could read the testimony. But we know what war looks like. Vietnam was a war. And there were body-bags. 50,000 of them. We know what wars look like. Korea. There were no body bags in the Libyan intervention, and in that sense, it's much more like all sorts of things that Ronald Reagan did in Grenada, all sorts of uses of force that really don't rise to the level of full-blown war.

### Moderator
Claim: Okay. I want to go to audience questions in a moment. I want to remind you again, if you raise your hand someone will-- I'll call on you. If you could stand up. Someone will come to you with a microphone. Hold it about as far away from your mouth as this is so that we can all hear you. Tell us your name and ask your question. Again, it needs to be tight and a question, but most importantly needs to be on this topic of the constitutional divide. And while you're getting ready to do that, I just want to take-- to decide arguing for the motion what your opponent was just saying in terms of Libya wasn't a war, and I think we need maybe to spend one minute or so on talking about language here, what we mean by a war. Does it matter how we define war in this conversation?

### Conspiracy Advocate (CA)
Claim: Well, you just said--

### Moderator
Claim: Gene Healy.

### Conspiracy Advocate (CA)
Claim: --Professor Amar was doing a lot better than Secretary of Defense Gates in that he was able to make that argument with a straight face. When Gates, once in Congress and once on 60 Minutes, tried to sell the idea that launching thousands of Tomahawk missiles at another sovereign country wasn't war, he had to smirk. That was the line he was given to sell and he did not sell it.

### Moderator
Claim: Did he smirk?

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: What did that look like?

### Conspiracy Advocate (CA)
Claim: Well, you know, it's hard to discern, but a quarter of his mouth turned up.

### Moderator
Claim: So it was a clear smirk? Phil Bobbitt. Phil Bobbitt.

### Scientific Advocate (SA)
Claim: I just want to point out there was U.N. Security Council resolution on Libya. It's not-- it wasn't done pursuant to Congressional authorization. It was done pursuant to a treaty. We can constitutionally wage war by at least four roots, repelling a sudden attack as our opponents have noted, relying on the Article II power of the president, by a statute or joint resolution adopted by both houses of Congress, by a treaty, as in Korea or as in Libya, and by a declaration of war.

### Moderator
Claim: Let's go to some questions. Any hands up? Sir, right there. So, a mic is going to come down the aisle to you. If you could just hang on.

### Moderator
Claim: What is the substantive difference between a declaration of war and an AUMF, and is there a different constitutional threshold for a president's ability to drop a bomb given one or the other?

### Moderator
Claim: That's-- that doesn't actually have them debating, but I like that question because it might get them debating on this topic, because they might disagree about the difference on that. I'll take it to Deborah Pearlstein.

### Conspiracy Advocate (CA)
Claim: I think maybe we might agree. I think for present purposes especially there's no constitutional difference between declaring war against ISIL and authorizing the use of force against ISIL.

In either event, depending on the terms of the authorization for the use of force, Congress could of course impose a limitation, right? The president can't use ground troops, for example, but assuming the authorization for the use of force in the statute didn't authorize anything different, I think they have the same effect in this case.

### Moderator
Claim: Is there disagreement on that side? Phil.

### Scientific Advocate (SA)
Claim: There's a bit of a difference, as I'm sure my partners here would agree. A declaration of war perfects a war.

### Moderator
Claim: What does that mean?

### Scientific Advocate (SA)
Claim: It's the way you perfect a lien. It allows for additional authority, the authority to blockade enemy ports, to intern enemy civilians domestically. It's-- you move from a limited war to a total war in international law when you perfect the war by a declaration. That's why if you look back on our declared wars, they are something like total wars, and if you look at the wars that are done by authorizations and statutes and joint resolutions, they don't rise to that level. And as my opponents know, this is a Supreme Court case, 1800, Bas v. Tingy.

### Moderator
Claim: Deborah Pearlstein, looking at your face maybe there is an argument there.

### Conspiracy Advocate (CA)
Claim: Actually-- right, so I don't quite agree with that. Right, so and let's take practice and current practice as an example, right? We used an authorization for the use of military force, the 2001 authorization of which Professor Amar is so fond, right, to invade Afghanistan and to detain an intern over the course of that war, and indeed the broader war with al-Qaeda, tens of thousands of prisoners. And we repeatedly-- and Congress embraced this, the president embraced this, the courts have embraced it-- repeatedly invoked the international law of war, international humanitarian law, the law of armed conflict, exactly those laws. So if we thought it required a declaration of war as such to do that, everything we've done more or less

### Moderator
Claim: Was that not a discretionary move as opposed to a move compelled by a declaration of war?

### Conspiracy Advocate (CA)
Claim: To--

### Moderator
Claim: To trigger international conventions, et cetera. There was no obligation. I would think that their argument is there would be no obligation.

### Conspiracy Advocate (CA)
Claim: So, the United States has an obligation under its treaty commitments, which after the supreme law of the land, and to observe that law of war in any armed conflict, and it would say it applied here.

### Moderator
Claim: Okay. Let's go to another question. Sir. Again, the mic will find you. From behind you this one's coming, if you turn around. Thanks.

### Moderator
Claim: Thank you very much.

### Moderator
Claim: Sure.

### Moderator
Claim: This is for the group that was against the declaration. What level of separation would you see from an affiliate of al-Qaeda and the perpetrators of 9/11 would you need a new authorization of military force? Would it be those who were affiliated directly with 9/11 or would it be-- how far would you--

### Moderator
Claim: How different do these guys have to be from al-Qaeda before you would think that, in fact, a new resolution was justified?

### Scientific Advocate (SA)
Claim: I suppose if there were no evidence on which the president could make a determination, and that an attack on that party or that group would or could reasonably be thought to deter future attacks on us, if the action taken were so inappropriate or so bizarre, so farfetched, if the group itself had-- did not have-- has never had-- did not share the objectives, the weapon sources and funding with the persons and groups that aided the perpetrators, financed them and planned the attacks on 9/11, yes, I think that would go beyond the statute.

I'll just emphasize this one point. When we start talking about all the crazy things the president might do, all the odd groups he might suddenly decide to make war on, we have not silenced the Congress. We haven't stopped our political process. When the president really does decide that, I don't know, the New York Yankees or Norway or something is the next associated group, we have ways of stopping him. And the way we do it is not by both houses of Congress approving air attacks.

### Moderator
Claim: Gene Healy, can you respond to the first part of Philip Bobbitt's answer in which he spelled out a scenario in which he would think that a group that wants to do us in would require a new resolution because it would be different enough?

### Conspiracy Advocate (CA)
Claim: Well, the administration has changed its own criteria for what it includes in associated forces, a term that doesn't appear anywhere in the AUMF. It used to require co-belligerency with al- Qaeda. ISIS is not a cobelligerent with al-Qaeda. It's an organization that is not only in competition with al-Qaeda, but at times actively fighting al-Qaeda affiliates. So, you know, I think at some point you have to read that organization out of the definition. And they were concerned about the legal basis for this and how open-ended it was two years before they shifted to expand their own definition to allow ISIS in. Before the--

### Moderator
Claim: You mean the Obama administration?

### Conspiracy Advocate (CA)
Claim: --yes--

### Moderator
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: --the Obama administration attorneys were-- there was a-- you know, from what you-- from what you can tell from public accounts of it, a pretty fiery debate over whether they had the authority, even before ISIS came on the scene, to stretch the law as far as they'd already stretched it.

### Moderator
Claim: Okay, let's go to another question. I wanted to say that if you're not sitting in the area that has direct light on you, it's difficult for me to see you, but you might want to move forward. But I'm going to scan again now. Right down front here, and the mic's coming down on your right hand side.

### Moderator
Claim: If the Senate passes a new AUMF that gives the president authority to fight ISIL or ISIS, does that make current actions in Iraq and Syria unconstitutional or does it give them added authority, like you said previously, with perfecting that lien?

### Scientific Advocate (SA)
Claim: Well, I suppose--

### Moderator
Claim: Akhil Amar.

### Scientific Advocate (SA)
Claim: --wouldn't be just the Senate, of course. It would be a resolution subject to the constitutional principles of bicameralism and presentment. It would require the House and the Senate and the-- that would be presented to the president for his signature, and it would all depend on how it was worded. And one of the things I believe that the administration was proposing is, "Maybe let's swap out the existing AUMF," which actually does not have a sunset, with one that would actually not merely supplement it, but supersede it, and supersede it in a way that actually was perhaps more limited, that did have a sunset provision, and other things. So it all depends on how it would be written.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, arguing it out over this motion, "The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization." Would either of you like to respond to the points that were just made or move on to another question? Deborah Pearlstein? No?

### Conspiracy Advocate (CA)
Claim: No.

### Moderator
Claim: Okay. Another question? Sir, right down here. The mic is coming from your right side.

### Moderator
Claim: So, Professor Bobbitt, you've alluded to the president's determination that ISIL is an affiliate or associate of Al-Qaeda. Is there a standard of review here for the president?

### Scientific Advocate (SA)
Claim: Yes, I think there is. I think that Congress is the standard. Let me make this absolutely clear. There are many persons who believe that the president's Article II powers, standing alone, would be sufficient for him to wage war against the Islamic State: it has attacked us, it has attacked our aid workers, it has attacked our diplomats, it has attacked our troops, it has attacked our allies.

That's not the position that Professor Amar and I are taking. There may be a lot to that, but that's not our view. We want the Congress involved. We think Congressional authorization is crucial. And the real review, as you say, isn't so much judicial review. It is congressional review. You've got to go back and get funds from Congress to actually fund those air strikes. And that's what the president did and that's what the Congress adopted. And we just can't get away from that. I don't think we can get-- sugar coat that or airbrush it out of this debate. We want congressional authorization. We want the Congress to look at this. We want them to say the president has done the appropriate thing or he hasn't.

### Moderator
Claim: But you think it has? You think that's already done?

### Scientific Advocate (SA)
Claim: Indeed I do. Indeed I-- it's not just what I think. It's what the Congress thinks.

### Moderator
Claim: Gene Healy.

### Conspiracy Advocate (CA)
Claim: There's a long history of Congress's feeling compelled to continue wars and to provide funding for wars that the president has launched. In Libya, as I recall, there was no specific-- separate appropriation for the Libyan conflict. It came out of the Overseas Contingency Fund. And what's more, the House actually voted down authorization. At some point, when you say the president can go and wage war wherever he wants and if Congress funds it, that's fine, you've sort of turned the Constitution on its head. You've put all the checks that are supposed to stand in the way of unilateral action, and then Congress-- and then the president's action stands unless-- as you know, in the Vietnam War, there's an actual effort to defund it. I think that puts-- that makes things exactly backwards.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Indeed. It would render--

### Moderator
Claim: Deborah Pearlstein.

### Conspiracy Advocate (CA)
Claim: --the declare war clause and the associated clauses there, effectively moot. If all Congress had to do to authorize war was appropriate funds, then why include a declare war power at all? What would the point of that ever be? And we just talked about how perfecting it, in the sense of international law, can't be it. In fact, the administration itself doesn't make the argument that the funds Congress has appropriated for military action, part of which-- a large part of which at the beginning was in defense of our own assets in the region, to the extent that they were being attacked. The president himself says the conflict has gone much beyond that now. But the president himself doesn't rest on that. He says he rests on his Article II Authority and then he asks Congress for additional authorization, which is why the House and Senate are debating the need for a new authorization now.

### Scientific Advocate (SA)
Claim: Look. I could understand why--

### Moderator
Claim: Philip Bobbitt.

### Scientific Advocate (SA)
Claim: --you want to talk about Libya. I could understand why you want talk about the president. But this debate is not about Libya, and the president is not here debating with Professor Amar and I.

### Conspiracy Advocate (CA)
Claim: Actually, this debate is about whether the president has exceeded his constitutional authority by waging war without Congressional authorization.

### Scientific Advocate (SA)
Claim: True. And I am quite happy to take it on that stand. If you find that the president has exceeded congressional authorization, that he needs a declaration of war-- that the congressional authorization was ill-considered, that he is going to them now because he thinks he doesn't have the authority-- a charge that was just made, which is not the way I read the president's statements-- he's been quite clear--

### Conspiracy Advocate (CA)
Claim: I didn't say that.

### Scientific Advocate (SA)
Claim: --that he does not need this authority, which is the way I read it. I'll leave it to you. He can--

### Scientific Advocate (SA)
Claim: He already has it.

### Scientific Advocate (SA)
Claim: Yeah. If you believe this-- if you believe that the funding was just a lark, it has nothing to do with authorizing the war, that Congress is being gulled into this, well, then you should vote for our opponents.

### Conspiracy Advocate (CA)
Claim: Professor Bobbitt, you have a pretty broad view of what appropriations authorize. If I-- looking at the Foreign Policy article that you-- that is on the Intelligence Squared website, I believe you said in 2013 that the very fact that Congress funded bunker busters meant that they couldn't be surprised if the president decided to launch them against Syria. Isn't that a pretty broad view of-- it's sort of if I lease my-- if I give my employee a company car I should not be able to complain if he takes it on a joyride.

### Scientific Advocate (SA)
Claim: Maybe not, but if you give him a tank you shouldn't be surprised if he--

### Conspiracy Advocate (CA)
Claim: If he uses it to invade another country?

### Scientific Advocate (SA)
Claim: If he doesn't go to the movies with it.

### Moderator
Claim: One more question. Sir.

### Moderator
Claim: Thank you. This is for the ‘against’ side. You seem to be saying that Congress has provided authority, but also should provide additional authority for strikes against ISIS. If Congress does vote on a new authorization and that authorization doesn't pass, where does the president's authority stand at that point?

### Moderator
Claim: Does that change the game? Akhil Amar.

### Scientific Advocate (SA)
Claim: Well, it all depends on what it says, but our position is Congress already has spoken, and spoken about as clearly as it is possible to speak in the English language.

### Moderator
Claim: So a new resolution refusing to extend the president's authority to ISIL by name would still leave him empowered by the 2001 authorization?

### Scientific Advocate (SA)
Claim: Well, the way to change law in our system is to pass a new one, and it's possible-- it's very easy to pass a new resolution that passes the House and passes the Senate, and is signed by the president that says the 2001 authorization of the use of military force is hereby repealed, and section two can say, “and in its place the following shall be the rules,” and the rules could have tighter restrictions on scope of hostilities.

They could have sunset provisions. They could have all sorts of stuff, just like you can have a new tax law or a new antitrust law, or any new statute really on any topic where Congress has already legislated it.

### Moderator
Claim: Is he right about that analysis, Deborah Pearlstein?

### Conspiracy Advocate (CA)
Claim: Well, is he right about, it'll depend what the new authorization says? It'll certainly depend what the new authorization says, right, but part of the necessity for a new authorization, and indeed I think part of the reason, and I know we're not debating the administration, but the fact is even the president, if we are deferring to his judgment, thinks we should have a new authorization. Part of the purpose for that is to clarify exactly what we're doing and against whom we're doing it. And I think the sort of notion that the 2001 AUMF was sufficient to get us through pretty much anyone in that messy Middle East because they're close enough is not only a legal error, it's a strategic error of the most profound sense.

We don't want to lump them together. They're different groups, and if we do that we only strengthen both of them. I think it's that strategic error that the president is most worried about.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate-- where our motion is: The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization. And now we're going to move on to round three. Remember, how you voted in the first round. Immediately after the summary statements, you'll vote again and then we'll declare our winner. Onto round three, closing statements by each debater in turn. They will be two minutes each and here-- you can sit down for all of these. Here to summarize his position in support of the motion that the president has exceeded his authority, Gene Healy, vice president of the Cato Institute and author of "The Cult of the Presidency."

### Conspiracy Advocate (CA)
Claim: Thank you. To agree with our opponents on tonight's motion you'd have to accept some pretty extraordinary propositions. You'd have to believe that the president has not just the power to repel sudden attacks, but the right to launch them. You'd have to accept the proposition that three days after September 11, Congress delegated its war powers to the president in near perpetuity, one Congress, one vote, one time; and that that war can be conducted for decades to come on a need-to-know basis with minimal public debate. You'd have to swallow the notion that seven months of regime change bombing in Libya isn't war for constitutional purposes. It isn't even hostilities under the war powers resolution, so long as-- and this is the actual argument they've made, the administration that is-- it's not hostility so long as the country we're bombing can't easily hit us back.

That last one has what I think are pretty staggering implications in an age of remote controlled warfare. It's also, I have to say, a somewhat grotesque doctrine for a humane, internationalist president to advance. Put starkly, it says, "Killing a bunch of foreigners isn't war; war is what happens when actual Americans might get hurt. Then it's serious. You might even need congressional authorization,” unless, of course, our president thinks there's an emergency threat to our humanitarian values, as in Libya. Well, our constitutional values demand debate and authorization before the resort to deadly force. They demand a vote. Tonight, please vote, "Yes," on the motion, "The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization." Thank you.

### Moderator
Claim: Thank you, Gene Healy. And with that being the motion, Akhil Amar, professor at Yale Law School, and author of "America's Unwritten Constitution: The Precedents and Principles We Live By," is here with his closing statement.

### Scientific Advocate (SA)
Claim: So you've heard it suggested by our distinguished opponents that the president can't go after ISIL because it's a different group than al-Qaeda. And you've heard questions about, "Well, how similar this has to be?" Here's at least one just very basic point that has gone unrebutted for the entire conversation. Some of the leaders of ISIL were the leaders of al-Qaeda on 9/11.

And that's not true of Norway or the New York Yankees or Brooklyn or the leaders of China, for that matter. So the authorization of the use of military force that Congress passed was not limited, didn't mention al-Qaeda by name. It talked about other organizations that may have aided or harbored al-Qaeda, either before or after the fact. It said, "Its purpose is to prevent future attacks." It has no sunset provision, and yes, these folks are sometimes at odds with each other. Frankly, that's what winning a war means: that you want to divide the folks on the other side. You want to have sufficient military strength so that they start to squabble amongst themselves. That's actually how you win these conflicts and serve the ultimate purposes that are emphatically authorized by Congress, preventing this from happening again by affiliates of the same organizations that hit New York the first time.

### Moderator
Claim: Thank you, Akhil Amar. And the motion is, "The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization." And here to argue in her closing statement in support of the motion, Deborah Pearlstein, a Cardozo Law Professor, and former director of the Law and Security Program at Human Rights First.

### Conspiracy Advocate (CA)
Claim: Thank you. So I would like to know the names of the members of ISIL that were part of al- Qaeda when it attacked us at 9/11. The leader of ISIL, al-Baghdadi, right, was radicalized when the United States invaded Iraq after 9/11, another nation that was not responsible for the attacks of 9/11. I think the fundamental point as this, right? There is a difference between al- Qaeda and ISIL, enough of a difference that there needs to be new authorization, and the president himself, the expert that Professor Bobbitt suggests we look to first, agrees with that, which is why he has gone to Congress.

More broadly, the framers of the Constitution wanted it to be hard to go to war. They imposed a series of checks in order to make it hard. We were going to have appropriations for military funding in the full view of God and everyone every two years. The Constitution requires it. Now we fund military operations substantially through funding contractors; through different departments, the funding is hidden. They wanted citizens to be-- to serve in the military. These days about .5 percent of Americans serve in the military. 80 percent of us support the troops, 90 percent of us can't find Afghanistan on a map. Congress and Congress's ability to say, "This is the war we want to fight, these are the reasons, these are the people"-- Congress is one of the last and most significant checks we have of limiting, constraining, in any way slowing the march to war that we might otherwise be inclined to take.

The president has asked Congress to help us define what that war is. We should keep this one last check. You know, I was briefing some young Congressional staffers last week on what this would mean if they passed a new authorization. And they despaired of Congress taking any action. You can tell them, "It's not despairing. We think you should take action." Vote for the resolution in this debate.

### Moderator
Claim: Thank you, Deborah Pearlstein. And the debate is this-- The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization. And here, summarizing his position against this motion, Philip Bobbitt, a Columbia law professor, and former director for intelligence at the National Security Council.

### Scientific Advocate (SA)
Claim: Why is your vote important tonight? It's because many people in our country have been thoroughly misled into doubting that of which they should be confident: the legal basis for the president's actions against the Islamic State; and feel confident about widespread popular opinions of which they should be very dubious.

One of those opinions is, the wars in Afghanistan, Iraq, Syria, Nigeria, Yemen, Somalia, and Libya have nothing to do with each other; that a global terror network is just a fantasy, full of sound and fury. Another is that the Congress must adopt a declaration of war, or yet a new authorization, which the president does not say is required, to authorize an otherwise constitutional war. Pressure groups have become quite eager to frustrate government action by mobilizing public opinion on the grounds that the Obama administration is acting unlawfully. And we've seen this in area after area. We hope you won't be a party to this.

The interplay between the president and the Congress should not be a game that has the zenith of insight in the question "If that's what you meant, why didn't you say so?" Rather, the strategic and moral problems we all know we face should inform on our opinions as well as our decisions.

### Moderator
Claim: Thank you, Philip Bobbitt. And that concludes closing statements in this Intelligence Squared U.S. debate-- where our motion is, "The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization." And now, it's time to learn which side you feel has argued the best. We're going to have you again go to the keypads at your seats and vote the same way, same system. Push Number one if you support this motion. Number two if you are against it. Number three if you became or remain undecided. And you can ignore the-- as I said before, you can ignore the keys that are not on the screen, as they're not live.

Okay. And while we're doing that and while the results are tabulated, I want to take a little bit of a break and welcome two gentlemen to the stage, and some chairs are going to miraculously-- well, they're not going to miraculously appear. Two guys are going to carry them in. They're angels. Please welcome to the stage Jeffrey Rosen and Ed Morrison. Have a seat. Gentlemen, the reason the two of you have been brought up here is because you've been partners for us. Normally we-- as I said-- do our debates downtown, but we are delighted to be here at Columbia, and invited by the Richman Center, and to be in this hall which we've been backstage saying is actually a spectacular place to do a debate. And Jeffrey Rosen, we've been partnering with you on these constitutional debates for some time, normally doing them in Philadelphia at the National Constitution Center, which I want to say, if you have not been to, you should get to. It's a short trip. It's a spectacular place. It's a day out. I mean, it's constitutional amusement park-- constitutional Disney World. It's really worth going to do - - going to see.

But Jeffrey, take a minute to-- just to share with us just this whole notion that you've experienced, this audience has experience-- I'm sure the law professors and law students are used to it-- but that we're taking a slice of this thing that's about the Constitution.

### Moderator
Claim: Well, the National Constitution Center is constitutional heaven. That is what it is. And I believe there's nothing more important in these polarized times than citizens having the opportunity to hear the best arguments on the constitutional questions that are at the heart of the most important questions of our democracy, so that people can make up their own minds. And that's the inspiring mission at the National Constitution Center was created by Congress during the bicentennial of the Constitution to promote. Our congressional charter says that we have a mission to disseminate information about the U.S. Constitution on a non-partisan basis. And when I had the incredible luck of leading this amazing institution about a year-and-a-half ago, I decided-- I asked, "What's the leading forum for, well, intelligent debate in America?"And of course, that's Intelligence Squared. So I'm a law professor at GW in D.C. I went to go see Nick Rosenkranz, who teaches at Georgetown, and I said we need to start a constitutional debate series so citizens can understand the difference between political arguments and constitutional arguments. And Nick said, as you heard in his intro, that's exactly right. There's nothing more important than educating people about the difference between political and constitutional arguments. So we started up this incredibly series and this is the fourth debate we've hosted. I'm so thrilled that it's in New York City. And this model is so successful that it's become the basis for all of our constitutional education. We've persuaded the heads of the Federalist Society, the leading conservative lawyers organization in the country, and the American Constitutional Society, the leading liberal organization to co-chair an advisory board of the National Constitutional Center. Nick-- That is worth an applause. I think it's thrilling. I think there's nothing more exciting than seeing these two great organizations joining together for civilized debate, and Nick is also co-chairing this board. And last week in Washington we launched the series of a national series of town hall constitutional debates that I think are going to be like the Lincoln-Douglas debates, and transform discourse in America. And we're having these We The People podcasts for constitutional debate that also bring together the top liberals and conservatives. And we're creating the best interactive Constitution on the web, summoning top liberal, conservative, and libertarian scholars to write about every clause of the Constitution, both what they agree about and what they disagree about. But for all of this our partnership with Intelligence Squared is the core of this model, and it's really a model of faith that believes that people are intelligent enough that when they hear good arguments on both sides, they'll engage, they might separate their political and constitutional views, they might even change their minds, and that's why I'm so eager to hear the vote. I'm so thrilled to be in New York, and please join us for the next of our constitutional debates June 2 in Philadelphia.

Do the states have the constitutional authority to define marriage? That debate is going to be right before the Supreme Court decides that question later in June, and it's going to be an amazing discussion, just as this one was.

### Moderator
Claim: Also, you and Nick Rosenkranz have something else in common and it's that guy over there.

### Moderator
Claim: Oh, well, Akhil Amar was my first teacher in law school and he's the greatest teacher that I've ever had and a great friend, and he did a great job tonight along with all the other debaters.

### Moderator
Claim: Okay. Now it's time for Ed Morrison. He's co-director of the Richard Paul Richman Center for Business, Law, and Public Policy here at Columbia. We are delighted to be here with you, but why are you delighted to be here with us?

### Moderator
Claim: Well, tonight's debate is a terrific example of why we do what we do at Columbia University. It's why we do research. It's why we teach. Most, I think all of us at Columbia are here to engage in a deep way with policy makers, with the media, with industry-- frankly with you about the issues of our day.

And one of our earliest graduates, think of Alexander Hamilton, he used debates like tonight to shape the way an early America thought about the issues of its time. And frankly those issues are not so dissimilar from what we talked about tonight. Through his words, through his debates, he permanently changed the way we think about the scope of federal authority, the scope, the conflict between Congress and the president. It's what we're debating tonight. It's the Hamiltonian style of debate that we at Columbia crave, and yet it's all too rare. Newspapers want sound bites. They call me all the time for them.

### Moderator
Claim: And you don't give them.

### Moderator
Claim: And I don't give them. I try not to. I'm not good at it. The Op-Eds. They want 300 to 500 words. Tweets are becoming the common currency. That's our world, but yet then there's IQ Squared, and it provides the forum that I think we at Columbia crave, which is an opportunity to engage with you in a deep way about issues that really matter.

### Moderator
Claim: Weren't the questions good tonight?

### Moderator
Claim: They were. They were terrific.

### Moderator
Claim: I have to say they're not always that good. They were really good.

### Moderator
Claim: I want to-- I'm the director of the Richard Paul Richman Center for Business Law and Public Policy at Columbia University. It's a joint effort of a Law and Business School to engage with the public in an evidence-based, deep way-- this kind of conversation we had tonight-- and it's why we were just so thrilled to be able to host this kind of debate. It's exactly what we want to achieve at Columbia. And I also want to extend a thank you to Richard Richmand and Geoffrey Colvin, who are here tonight, whose support made this debate possible.

### Moderator
Claim: Thank you from us as well. Gentlemen,

### Moderator
Claim: One last thing. I know I'm taking up your air time, but the last thing I want to say and I want you all to remember this, is that I hope tonight's debate has convinced you to come back. Come back to Columbia University, because we'd love to have you join us in our ongoing I think pretty exciting conversations about issues that matter.

### Moderator
Claim: And you should do the soundbites. I mean, you're-- you should go with that. Gentlemen, thank you very much. And, again, thank you to both of you for One other thing about upcoming debates, I want to let you know our Intelligence Squared Debate series moves on. In two weeks, April 15th, we're back at the Kaufman Center on 67th Street. Our debate motion that night will be, "Abolish the Death Penalty." And we're not doing that as a constitutional issue, although that will be part of it. It's more of a social issue. We would be delighted to have as many of you come down to that as you can.

Okay, so it's all in now. I have the final results. The motion is this, "The President Has Exceeded his Constitutional Authority by Waging War Without Congressional Authorization." To remind you, the team whose numbers have changed the most between the first and the second votes will be declared our winner. Let's look at the first vote. In the first vote, 27 percent agreed with the motion, 33 percent were against, and 40 percent were undecided. So a high number for us. The second vote went like this: the team arguing for the motion, their vote went from 27 percent to 38 percent. They picked up 11 percentage points. That is the number to beat. Let's see the side against the motion. They went from 33 percent to 53 percent. They picked up 20 percentage points. That means the team arguing against the motion has won this debate, the motion being, "The President Has Exceeded His Constitutional Authority by Waging War Without Congressional Authorization." Our congratulations to the team that argued against. Thank you from me, John Donvan, at Intelligence Squared U.S. We'll see you next time. And we-- all of those invitations you have to all of these upcoming programs, follow through. We'll see you there.
