# Debate Transcript

Topic: It's Wrong To Pay For Sex
Motion: It's Wrong To Pay For Sex

Debate ID: sex-debate


## Round 1

### Moderator
Claim: After the debate: For the motion: 27% Against the motion: 66% Undecided: 7% My name is John Donvan, and we will formally begin the debate in a couple of minutes but first I wanted to explain a couple of things, most particularly about your role as the audience, if you have been here before you know this but if this is the first time, I wanna point out that as audience members you are actually part of the debate in a few different ways. Most importantly you are the judges of the winners of the debate, we ask you to vote twice, both before the debate and again at the end, to share your— whether or not you agree with the motion, whether you’re against the motion or whether you are undecided.

And tonight we’re doing something a little bit more nuanced, we are going to ask you to vote in such a way that we can tell—we can tally votes from men, and votes from women, at every step of the way. Ah! The way that we’ll vote, there’s a keypad next to your seat, attached to your seat…and if you are female, the numbers that concern you are 1, 2, and 3…1 means that you are for, 1 means that you are female and you are for the resolution, 2 means that you are against the resolution, and 3 means that you’re undecided. If you are male, you are concerned with the numbers 4, 5, 6. 4 means that you’re for the resolution, 5 means that you’re against and 6 means that you’re undecided, and we’ll vote…shortly after the debate officially begins. Takes about 30 seconds to vote and I’ll give everybody a chance. …A couple more things very briefly, we are being broadcast on National Public Radio as all of these debates are, now on more than 185 stations across the nation. We are going to have two endings tonight, one of them will be, the ending that will be broadcast on radio in which we will simply, report at the end of the debate…the accumulated results without breaking them down by sex.

After that we’ll have our second ending which is just for you, in which we’ll share what the results were by sex, how men voted, and by how women voted.

I’d like to begin by introducing the chairman of Intelligence Squared US, Mr. Robert Rosenkranz.

### Moderator
Claim: Well thank you all very much for joining us this evening. Tonight’s resolution is the same language that was used in an IQ Squared debate in London. And that was a very, very lively debate and we thought it’d be fun to, or interesting to repeat it here. My role typically in these evenings is to sort of frame the debate, to summarize the arguments that we might expect to hear on both sides. But as I thought about the language of today’s resolution, it seemed to me that it was not quite the crisp, clear proposition that we usually try to put forth. And it might be more useful for me to reflect a little bit on the actual words of the, of the resolution.

The first the word “wrong.” Well, it’s certainly wrong to pay for sex if you wanna keep your job as the governor of New York. And…you know—I predict a laugh. But wrong in that sense is wrong as a matter of public morality. And that’s one way of discussing right and wrong. Another way of discussing it is in terms of, just private individual conduct, is this gonna make you feel like you’ve lived a well-lived life if you abide by these principles or don’t abide by these principles. And the third kind of possible definition of wrong, is it should be illegal, or it should be legal. So those are three different meanings of “wrong,” and might lead to three very different takes on tonight’s, resolution. The language “to pay” is quite deliberate, because it’s focusing on the economically advantaged party, and that was a very conscious choice, both in London and by ourselves.

And finally the notion of paying for sex, can encompass such an incredibly broad range of ideas,— from patrons of child prostitutes in Thai brothels, to rich Wall Streeters who support their girlfriends in graduate school. So there’s such a huge range of meanings here, in the language of, of the resolution, and we have such an able group of panelists. But I think sorting this out and keeping these proceedings orderly, is a difficult task tonight and it falls to the very able John Donvan who’ll take the evening from here.

### Moderator
Claim: Thank you, and may I invite one more round of applause for Robert Rosenkranz. Ladies and gentlemen, welcome to another Intelligence Squared US debate, I’m John Donvan of ABC News “Nightline,” and I will be moderating the debaters that you see sharing the stage here with me at the Caspary Auditorium at the Rockefeller University in New York City. Six debaters, two tables, three against three, will be debating this motion, “It is wrong to pay for sex.” Now this is not a seminar or a penal discussion, this is a competition, winners and loser, it is a contest of ideas and logic and quick-wittedness and perhaps charm, but most of all, persuasion, because by the time this debate concludes, you the audience will have voted twice, both before the debate and once again at the end, your vote is to tell us whether you side with or against the teams on this stage and their arguments, and the team which has changed the most minds over the course of the debate, will be declared the winner. So now we’re gonna bring up the house lights, and we are going to hold our first vote and I will reemphasize for those who might have arrived late, tonight, we are asking men and women to vote using separate keys.

Keys 1, 2, and 3 are for women, 4, 5, and 6 are for men. If you are female vote 1 if you are with the proposition, 2 if you vote against, and 3 if you are undecided, if you are male, vote 4 if you are for the proposition, 5 if you are against, and 6 if you are undecided. If you have made a mistake, and you regret…your key punch…just correct it, and we will lock in your last vote. And I’m seeing the faces that everybody gets this and we’re good, does anybody need more time? Okay, so we’re gonna lock in the vote. And proceed with the debate. And now Round 1, arguing for the motion, Wendy Shalit, a writer, who has… made something of a career of writing about the topic of modesty, and seems to come up with an excellent gift for titles. Her first piece for Commentary when she was a college student at Williams College criticizing the co-ed bathroom policy was, “A Ladies’ Room of One’s Own.” And your all but last book is titled, Girl— Girls—

### Conspiracy Advocate (CA)
Claim: The Good Girl Revolution.

### Moderator
Claim: Oh, I was thinking of Girls Gone Mild.

### Conspiracy Advocate (CA)
Claim: Yes, that, that’s the hardcover—

### Moderator
Claim: Which—which was its previous title and it’s also brilliant.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Wendy Shalit, ladies and gentlemen—

### Conspiracy Advocate (CA)
Claim: We changed it ‘cause there was some confusion. Thank you. Ladies and gentleman, thank you so much for joining us tonight to consider this most important topic. Before delving in I still have in my mind a song I heard on the way to the airport on the radio, which went like this. “I’m not a saint but I’m not a sinner, everything’s cool as long as I’m getting thinner.” Which, I think, expresses a profound truth, actually. It’s a serious question. In a society in which the self is the body, to some degree, as long as we’re getting thinner, do we even believe that there is such a thing as a sexual right, and a sexual wrong. Nobody wants to judge. Adultery is now a lifestyle choice. A 22-year-old woman from San Diego, is now auctioning off her virginity to the highest bidder. Right? And we’re not supposed to judge. And yet I would submit that we do judge, all the time. When I was living here in Manhattan some 10 years ago, I’ll never forget the time when I was innocently buying my Metro pass, and sipping my coffee, and a man came up from behind me and barked at me and he said, you know, you shouldn’t drink those frappaccinos, they’re very fattening. And I was shocked that a perfect stranger would presume to judge my beverage choices that way.

But then I realized that everybody has a notion of right and wrong and to this man frappaccinos were just wrong. My worthy opponent, Sydney Barrows, writes in her memoir, Mayflower Madame, that a DNS in the call girl business stood for “Do not send.” Men who were obnoxious or who had really gross apartments, she wouldn’t send her girls to such men. And she also writes, “Whenever I read about a business who had done something I didn’t approve of, such as a building an ugly high- rise in a residential neighborhood, I added his name to the list, just in case he ever called us.” Which I thought was really funny, also. To some people, building an ugly high-rise is morally wrong. It’s an offense against the aesthetic order. Ladies and gentlemen, I would submit to you that paying for sex is at least as wrong as building an ugly high- rise. Perhaps more so.

Why, because we’re using— we’re talking about using a human being as a means to your ends. Today people want to believe that paying for sex is just like paying for a hamburger. But a sexual transaction is different, because it teaches on the deepest, most personal aspects of ourselves. The proof that sex is different, in my opinion, is our response to the terrible crime of rape. If paying for sex were as morally neutral as paying for a hamburger, well then, rape is akin to just forcing someone to eat a hamburger. Right? But of course it is not. It is a horrible crime, that is serious, precisely because sexuality touches on the deepest, most personal aspect of our humanity. And to take something so intimate, and to turn it into a commodity, has far- reaching, devastating effects, for men, women and children.

Everyone agrees that after the Netherlands adopted legalization that this has added fuel to the gangs who trafficked in underage girls, and that the abuse in child prostitution exploded rather than was reduced. It’s time to ask why. Well, firstly what we value in women, eventually trickles down to girls. For example today we place a lot of value on hotness in women, have you noticed this? And so, now in, for example in the Bratts Babies video, which is watched by three- and four-year-old girls by the way, you can hear cartoon babies singing songs about “being hotter than hot, show what you’ve got, ready or not.” For three- year-olds. What we value in women inevitably trickles down to girls. Secondly prostitution, like all industries, is demand-led. Someone could go to great trouble manufacturing coats made from cockroaches, but since nobody wants cockroach coats, the supplier would soon find that there’s no market, no demand, and no money in it, except may Ozzy Osbourne would buy it.

But because prostitution is demand-led, it’s the paying for sex that’s a problem. That’s what creates the demand, and given that the average age of entry into prostitution is 13 or 14 years old, I think this presents a huge moral problem. I receive a ton of emails from girls who are 14, 15, leave home, because they’ve been abused, only to try to escape prostitution. Unfortunately at the time, one writes to me, “It was all I felt I had to offer the world, my body. As you can no doubt guess, I was molested by my father for many years when I was a child. It’s why my mother let me leave. So in a sense I was raised to believe my body had only one use, and I was worth only this one thing.” We can talk later about why the molestation rates for prostitutes are so high, why the suicide rates are so high.

But, right now I wanna focus on the fact that the problem is that nobody knows if these girls are 14 or 18. And, we think about the sheer number of sex slaves in captivity in the US, we’re talking about, anything from 30,000 to 50,000. It’s staggering, and it’s sickening. We’re talking about girls that are having sex with 20 to 30 men per day, one girl told the New York Times about her cell of traffickers, her captors offered three age ranges of sex partners, toddler to age four, age five to 12, and teens as well as the damage group…where they could do anything that they wanted. When one of the Mexican child-trafficking rings was busted in a house in Plainfield, New Jersey, uh, another Mexican ring was recently busted--but this one was a few years ago—the neighbors, in retrospect thought about all the cars that came, and all of the girls that… left that house to buy candy, but they always said no one knew what was going on. I’m always struck that the neighbors always say this, well somebody knew what was going on because someone was paying for the sex.

To those who are against trafficking, but they insist that some women have nothing else to sell but their bodies, I say that they suffer from a real lack of imagination. About the power of the human spirit and about the strength of women in particular and if you keep up with the Harvard Business Review, you may have noticed, that they’re now talking about micro-loans to poor women and only lending them, only having these loans to poor women. Right? Because they notice that the poorest of women reinvest in the household and the men do not. So…we have to believe in the women first, it takes a risk to give them that loan. If instead we demand their bodies instead of appealing to their intelligence, it’s this philosophy of this is all she can do, and the not too subtle misogyny behind it, that feeds the demand and expectations that cause the problem.

Thank you—

Thank you.

### Moderator
Claim: Wendy Shalit, your time is up.

### Conspiracy Advocate (CA)
Claim: Thank you—

### Moderator
Claim: Thank you very much.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: And again for newcomers, in the opening round each speaker has even minutes uninterrupted to speak so Wendy had just reached the seven-minute point. Up first to speak against the motion that it’s wrong to pay to sex, Lionel Tiger, the Charles Darwin Professor of Anthropology at Rutgers University, the anthropologist who gave us the term “male bonding.” He has been arguing more recently that it is men who get the short end in society. Given, Lionel, your writing about men’s issues I’ve always wondered…Tiger, is that something you adopted late in life or were you born a Tiger.

### Scientific Advocate (SA)
Claim: It’s appropriate for that branch of show business known as the academic profession. It works quite well.

### Moderator
Claim: Ladies and gentlemen, Lionel Tiger.

### Scientific Advocate (SA)
Claim: Thank you very much, thank you, Wendy, for starting this off in a serious and interesting manner. I have to say, I’m quite confounded by this, because it’s quite clearly wrong to pay for wrong sex. There is no one in this room I daresay, who will shed a tear for anyone who is jailed for trafficking in toddlers. That I think is an absurdity, to start a discussion about the very serious, momentous issue of human sexuality.

So, we’re all opposed to coercive, we’re all opposed unequivocally, I’m sure, to the kind of stories we hear about the Russian Mafia trafficking women whose passports are stolen from them and then they have to work off their fare and so on. These are all obvious. They’re not debatable. I won’t debate them, therefore. But what we have with respect to, Wendy just heard is a perfect contemporary exposition of the early 20th century sociological fallacy, which is you look for a deviant phenomenon, and attribute to that the nature of the normal. So by talking about rape, talking about toddlers being abused sexually, this then frames the entire discussion of what you guys and gals may decide to do in your own homes with your own lust, with your own love, and that is simply methodologically wrong.

Furthermore, it begins from a premise that legal distinctions constitute the vocabulary of life’s distinctions. And again, this is simply methodologically improper. So for example in American sociology many early sociologists would look at prison behavior and say ah-ha, this is what life is really like. It’s not. It’s a prison. It’s what it is because of what it is. It’s not reflective. And furthermore, I get here, and forgive me for maybe being, counter-casting here, but I think this entire argument somehow is profoundly disrespectful to females. If you want to see people paying for sex, I suggest you go to the ground floor of Bloomingdale’s. The place is full of women paying for garments, colors, clasps, various instruments of torture— lust, you name it, but they’re paying for their own sense of themselves as sexual creatures, and they’re not on that floor because they don’t like sex and they don’t like what it means.

And furthermore, what it tells us about is, that there’s an inner economy to sex, that doesn’t have to do with raping toddlers, with raping girls who are abused by their fathers, please. If you’re raped by your father you’ve got a problem independently of the one we’re discussing. That’s just how it is. There was a remarkable story in the Times, last couple of weeks ago, about a website called SeekingArrangement.com. In this website, men and women can sign up to be-- essentially a rich Wall Street executive, thank you, Mr. Rosenkranz for the metaphor—to be set up and go through graduate school. Now in this system, which is not explicitly about sex, it’s about a wide variety of things, the ratio of women applying to men, is 10 to one. Free choice. 10 to one. These are probably women you know, I know, who knows. But the fact is that—and this is just one anecdote and it’s not typical of everything, please don’t overextend it, but the fact is that women have a deal with men which requires that they have some relationship with men, especially if they’re inclined to reproduce which still 80 percent of women in North America. And women know that they will have five to eight years when they’re out of the labor force, and, it helps to have a guy around the place. And so… The fact is that if we’re looking just now, Mr. Donvan mentioned the current male- female balance. In this current recession or depression or whatever it’s called, 82 percent of the jobs lost are male jobs. That means that, women will not have a guy—if they want one…this is free choice, please, I’m not an obligatory heterosexual mastermind here but if women want a mate, then they’re not going to have…one of those men that has lost a job.

It’s a complicated argument but it’s a long story, I’m an anthropologist, we’re interested in what people around the world do, 90—over 90 percent of human marriages are arranged. They’re determined by families in terms of the larger interests of the two clans, they usually involve a bride price or a dowry, or something like that in which the male usually commits himself to sustaining the female, we don’t do it with cattle, we do it with some exotic unit called the diamond ring. An engagement ring is the world’s stupidest object, the moment you take it out of the store, it’s lost 80 percent of its value, if in fact it has any value at all, just ask DeBeers, there’s—they’re crying. But, the guy has to pay two months’ after-tax income for this diamond ring, to give to the gal to assure her that he’s going to be okay. Now, if he’s not, she keeps the ring. But the point is that this is a— This is a classic anthropological phenomenon, my time is quickly run out, I had no idea that…

—it would— I—

### Moderator
Claim: It’s up—

### Scientific Advocate (SA)
Claim: —it would— I—

### Moderator
Claim: Lionel, Lionel Tiger, ladies and gentlemen, whose time is up. Of all of our debaters tonight, our next speaker who will be arguing for the motion that it’s wrong to pay for sex has truly brought the arsenal of the researcher to this topic. Melissa Farley is a clinical and research psychologist with Prostitution Research and Education which is a non-profit that she founded. She is an Associate Scholar with the Center for World Indigenous Studies, her position on prostitution has been described as abolitionist and I’m assuming, Melissa, that our familiarity with that word and the topic of slavery is no coincidence for you.

### Conspiracy Advocate (CA)
Claim: It is not.

### Moderator
Claim: Ladies and gentlemen, Melissa Farley.

### Conspiracy Advocate (CA)
Claim: Thank you. Thanks. Some words hide the truth. Just as torture is named, “enhanced interrogation,” and the logging of old-growth forests is called the Healthy Forest Initiative, so also prostitution is named a choice, a job, work, a victimless crime, and on Craigslist it’s called “a wide range of personal meeting and relationship opportunities.” These pimp-messaged slogans are good for business but there’s not much truth to them. What’s wrong with prostitution is the renting out of a woman’s mouth, vagina, or anus, and what it does to her, psychologically.

What’s wrong with prostitution, and what’s wrong with buying sex, are the same things that are wrong with other forms of violence against women, incest, rape, and battery. I’ve been researching prostitution for 15 years, we’ve interviewed 900 women, men, and transgendered people in prostitution, in nine countries on five continents. And over the course of that time we’ve also interviewed 500 johns. Prostitution is not a choice because the precise conditions that make a choice are absent. For example, equality with buyers, and physical safety, and real alternatives. If you imagine a pyramid, remember that only about the top 5 percent of all women in prostitution are at the top of that pyramid. These are people that are privileged by race and class. The other 95 percent don’t have those kinds of privilege or alternatives for escape. Let me give you some examples of the sex inequality, the race-ethnic inequality, and the economic inequality in prostitution that are often invisible. A woman in Lusaka, who knew that five blow jobs would get her a sack of mealy meal to feed her kids. That’s not a choice.

A woman in India who worked in an office where she concluded that she might as well be paid for the sexual harassment that was expected of her anyway, in her job. That’s not a choice. The teen in California who said that in her neighborhood, boys grew up to be dealers and pimps and girls to be ‘hos. She was the third generation of prostituted women in her family. And prostitution more severely harms people who are indigenous or ethnically marginalized because of their lack of alternatives. That’s not a choice. Or the young woman sold by her parents in a brothel in Nevada.

She took six different psychiatric drugs to make it through the day, selling sex, that’s not a choice, or Ashley Dupre, who was bought by Governor Spitzer. Dupre ran away from what she called an abusive home at 17, she’d been homeless, she had a drug problem, a convicted New York pimp bragged that he turned her out. And at 17 pornography was made of her by a man who had a prostitution conviction. The Emperors Club, where Spitzer bought her, was run by pimps who charged a lot because they said it was high-class call girls. But it was the same as any other pimps, they took their 50 percent off the top. Like a majority of johns, Spitzer most likely enticed, coerced or persuaded her with money to put her life on the line by not using a condom. That’s not a freely made choice. Women in prostitution face a statistical likelihood of weekly rape. A Canadian woman in prostitution said, what’s rape for others is normal for us. A woman at a legal brothel in Nevada said, it’s like you sign a contract to be raped. And in Chicago, the same frequency of rape was reported by women in both escort and street prostitution.

Women in prostitution are seen as body parts or fake girlfriends and their feelings don’t matter, and they’re not seen as human which is perhaps why they’re murdered at a higher rate than any other group of women ever studied. The emotional consequences of prostitution are the same in widely varying cultures. Whether it’s high-class or low-class. Whether it’s legal or illegal, whether it’s in a brothel, strip club, massage parlor, or the street. Symptoms of emotional distress in all forms of prostitution, are off the charts. Depression, suicidality, post- traumatic stress disorder, substance abuse, dissociation… Two thirds of the women we interviewed, and all of the people we interviewed in prostitution, two thirds of them had PTSD at the same level of the most emotionally traumatized groups ever studied by psychologists. That would be combat vets, women who had just been raped, women seeking shelter from batterers, and also state-sponsored torture survivors.

What’s wrong with sex is what johns themselves tell us about it. For example, if you look at it, it’s paid rape. She has to do what you want. I use them like I might use any other amenity, a restaurant, or a public convenience. It’s like renting an organ for ten minutes. In research interviews with johns, we found that their abuse of women extended to women who had not been prostituted yet. The johns that bought the most women in prostitution were the most likely to commit sexually coercive acts with non-prostituting women. When women are turned into objects that men masturbate into, it causes immense psychological harm to the person acting as a receptacle. Please don’t be fooled by people who tell buying sex is just another job. It’s wrong to set aside a special class of women, those who are the most vulnerable among us, for men’s sexual use. What’s wrong with paying for sex is it’s the business of sexual exploitation. Thanks.

### Moderator
Claim: We are halfway through our opening round. I'm John Donvan, of ABC News “Nightline,” your moderator. We have heard from three debaters arguing this motion, “It’s wrong to pay for sex.” Our next debater will rise now to argue against that motion. I would like to introduce Tyler Cowen, who is a professor of economics at George Mason University, and director of the Mercatus Center, a think tank that uses economic tools to solve real world policy issues. And Tyler, we heard Wendy Shalit talk about the hamburger defense, that this is not about buying hamburgers, that it’s different. I'm assuming as an economist you're going to step back a little bit from that argument. I introduce you once again to the audience, Tyler Cowen.

### Scientific Advocate (SA)
Claim: This is a very serious matter, and to take it seriously, I propose we start by looking at human diversity. Consider an example, you're a nineteen year old American soldier, and you’ve been drafted to fight the Nazis in France, and you have, to put it bluntly, never done it before. And before the event of a big battle, you go and you buy sex from a Frenchwoman who maybe needs the money to feed her kids. Or maybe you're a young man and you have sexual problems, and you hire a sexual surrogate to help you with those problems, and you go on to have a loving and successful marriage. Or maybe you're a handicap person who, for whatever reasons finds that a better way to achieve sexual ends is to pay for sex. These are all examples of the diversity of the human condition. What the other side is neglecting is this diversity, a diversity of individuals, a diversity of situations, a diversity of cultures.

If you look at the broad sweep, the history of mankind, there’s a big, long book by Nils Ringdahl on the history of prostitution. He looks at Medieval India, he looks at the Tang Dynasty, he looks at Renaissance courtesans, and what you find is a wide variance of outcomes. You find a lot of cases where things go fine, and you find a lot of cases where things don’t go fine. I propose what we have here is a human activity which very frequently is badly regulated, and when it is badly regulated, you will see massive amounts of abuse, unfairness, exploitation. And I recognize the other side in pointing out these abuses. But the problem is that it is a badly regulated activity. There are many, many cases, three of which I’ve outlined, where consenting adults meet, they meet voluntarily, both of them are better off, and buying of the sex is not wrong. All of the abuses listed by the other side you can find in another institution called marriage.

If you go around the world and go to poorer cultures and ask within marriage how often is there rape, how often is there abuse, exploitation, unequal terms all the way down the line, women who are too young to be married, you see this happen all the time. But to go back to our resolution, the correct answer is not to condemn marriage, to say that marriage is wrong. In a way you can think of prostitution as a bit like, dare I say, banking. As we know here in New York, banking is very frequently badly regulated. And you find in many countries, believe it or not right here in Manhattan, you find examples of abuses, fraud, exploitation in banking. But again, the correct attitude or answer is not to say that all banking is wrong.

There’s simply a category error being made by the other side in this debate. And again, think back to your core intuitions, there are many, many cases, millions, billions of cases in human history where informed, consenting adults have gotten together and someone has bought sex from another person. And again, I am submitting that these cases are not wrong. Go take a look at New Zealand, where prostitution is legal. It has been legal since 2003. The other side didn't mention New Zealand at all. There’s a big long report written by the New Zealand government about how this experiment has gone. Uh, there’s a lot of evidence that it’s actually gone pretty well. A survey of the prostitutes revealed that seventy-three percent of them do it to pay household expenses, twenty-four percent of them are doing it to pay for education, thirty-eight percent are doing it to help out their children, or support an older family member, and the rates of abuse, coercion, and rape, the rate of rape is extremely low.

It seems to be lower in prostitution than in a lot of other settings. But again, these are not the examples you're hearing. The point, again, that I'm stressing is this diversity, that when you have consenting adults there are, again, many cases where it’s simply possible that it is a okay thing to do. There are many other sectors of the economy that we can look at. If you ask the Bureau of Labor Statistics, what is the most dangerous job in the United States, at least according to the bureau, it’s being a fisherman and going out on a fishing boat. It’s an extremely hazardous occupation. There’s a lot of loss of life, loss of limb, people being crippled, unfair conditions, illegal immigrants who work under conditions that are not right.

And again, these are real problems. But to think of it in terms of morality, we ask, what is the moral issue here? The moral issue is when you have unsafe fishing boats, or when fishing is not regulated properly, or when we as society don’t think about fishing and industrial safety in all the right ways. No one thinks to say fishing is wrong, buying fish is wrong, fishing boats are wrong. Again, it is simply this category error. I would even submit that if we take the point of view suggested by the opposition, the more we try to blackball, ban, condemn an activity that we all know has existed in every society, it always pops up, there is always a black market, there are many different ways of trading sex. It is not going away. If there’s one thing that we all should realize in this room, is that the buying of sex is not going away. What we want is that it happen in a better way rather than a worse way. We need to have a constructive attitude. I do not hear that constructive attitude from the other side. What I hear is an attitude that will put this practice under a greater veil of secrecy, it will make it harder for the people who are selling to go to the law when they have problems, it will make it more of a social disgrace, and it will worsen the problems with the working conditions rather than improve it. I’d also note, just as an aside, just how culturally-bound and institution specific the complaints are. For instance, in Melissa Farley’s presentation, it’s always man and woman, man buying from woman. There’s no talk of gay prostitution, there’s not much talk of the broader sweep of human history, of practices of dowries, of the numerous tribes in human history who have taken very different attitudes than that which we hold. In fact, if you polled the majority of human beings over time, the most likely answer you're going to hear is that the people who are doing something wrong are the men who are trying to get sex without paying for it simply by seducing the woman. Anyway, thank you all.

### Moderator
Claim: Tyler Cowen, with a very good sense of the clock. Our next speaker is speaking for the motion that “It is wrong to pay for sex,” it’s interesting in the context of a debate, is actually somebody who has changed the terms of debate in this country in a way that has changed all of our lives, Catharine MacKinnon, a professor of law at the University of Michigan, and also Harvard, pioneered the legal claim for sexual harassment as sex discrimination. Catharine also has been arguing on behalf of women raped in Bosnia, making the argument that rape was a form of genocide. And Catharine, the result of that trial? You won.

### Conspiracy Advocate (CA)
Claim: We won seven hundred and forty-five million dollars in the southern district of New York before a jury like you.

### Moderator
Claim: Ladies and gentleman, Catharine MacKinnon.

### Conspiracy Advocate (CA)
Claim: What I know about prostitution I know from the prostituted women that I work for, representing them because they asked me to. We have found the sanctimoniousness and the superiority of the moral position against prostituted people, that is that they are bad, to be insulting and insufferable. And we have also found the rescue impulse to be demeaning and typically ineffective. But, no one opposes the normal business of prostitution for money, that is of sex for money, more, or more eloquently than the women who really know what it is because they're living it.

That is the women who are living in this industry, most of whom are trafficked by international definition, because they are being pimped. And they want to get out, and they can't. Thus fitting the international definition of slavery. When you want to get out of marriage there’s a term called divorce. Eighty-five percent of women, when asked what they most want, that is women in prostitution, say what they want is to get out, but they don’t know how to. Usually they got in as children. Normally they got in as children. The majority. They were, most of them, sexually abused, actually, even before that. This is in the ninety percent plus range.

That is, they were treated as a thing for sex before they ever had a chance to become a person first. And usually they are women, meaning their economic options are limited already by sex discrimination, precluding a vast majority of what men do for better pay, leaving, for the women who end up in prostitution the one remaining thing to be called her choice. This is a myth that one woman described for herself as, to be able to get out I had to believe I chose to get in. Sex, when it’s right, like friendship, is its own reward, it’s mutual, it’s equal in its diversity. You can't buy the real thing. In prostitution, women have sex with men they would never otherwise have sex with. The money thus acts as a form of force, not as a measure of consent. It acts like physical force does in rape. And as Kathleen Barry put it, the only difference between rape and prostitution is time, one ends, the other doesn't. And then she is stigmatized and deprived of dignity by society, and criminalized by the legal system. So for her, what’s wrong with it is, it’s abusive, it’s intimately violative, it’s destructive, it’s damaging, it’s dangerous, it’s exploitative, and it’s unequal. It’s up to you to decide if this is right or wrong.

We're not here, actually, to discuss the proposition “it’s wrong to be paid for sex.” We are here to discuss the proposition, “it is wrong to pay for sex.” I’ve just been talking about what’s wrong with it for her. What’s wrong with it for him is, he’s using her, he’s exploiting her, he’s exploiting his inequality to her, which is usually a desperate economic inequality. In order to have access to her person in a form of bodily invasion, while he gets off on the illusion that he has chosen this freely, when he is taking more than can ever be paid for. And what he is buying is not only that chunk of her humanity called self-respect… And it isn't sex only, it’s you do what I say, sex. Now, to be against this is why those of us who are today supporting this proposition support the Swedish model. In this model, the seller is, well, the buyer is strongly criminalized. The seller has, is also strongly criminalized. In criminalizing the person who is the one who’s buying the sex, you are criminalizing the one that my desperately poor Indian clients, from India, call the real criminal.

And you de-criminalize the sold. You couple this with real education, real employment opportunities, real jobs, real money. Women are entitled to real equality and real choices. Men presumably also need to pay for household expenses to put themselves through school, and you don’t find them, in general, not in anything like the numbers you find women, selling themselves on street corners. Women need real equality and real choices. We're asking you to vote yes for the proposition as a way to weigh in on the side of the view that women and children are not for sale. And I'm going to reserve the balance of my time for my rebuttal.

### Moderator
Claim: We’ll remember that. Thank you. And that concludes round one of the debate tonight. Oh, I am so sorry, I skipped ahead on a card. I'm so glad that you're all here… …to keep me on the straight and narrow. I'm sorry, Sydney. Sydney Biddle Barrows is a successful businesswoman and consultant who is most known for her work running a prostitution ring called Cache in the early 1980’s for about five years until her arrest. The tabloids were particularly drawn to the fact of your lineage, which you have captured in the title of the book you wrote about your experience as The Mayflower Madame. You had how many ancestors on the Mayflower?

### Scientific Advocate (SA)
Claim: Both sides, two—

### Moderator
Claim: Both sides. Okay, so you have Puritans in your past. Ladies and gentleman, arguing—

### Scientific Advocate (SA)
Claim: They're all rolling over in their graves.

### Moderator
Claim: Arguing against the motion, Sydney Biddle Barrows.

### Scientific Advocate (SA)
Claim: Thank you. Freud once asked the question, what do women want? And I would argue that what women want is their own money. And I have heard a lot of stories about, some really horrifying stories about young girls, people being trafficked, as Lionel said, this is just something, I mean I want them to throw away the key on these people. But what’s interesting is some of the statistics that I’ve been hearing, because what’s interesting is the only people that you can get these statistics from are the people at the very, very bottom, and they constitute a very small percentage of all of the working girls, at least in the United States. I cannot speak for anywhere else. And because I have to tell you that I don’t recognize any of the kinds of clients that the opposition has talked about, I don’t recognize any of the kinds of girls that the opposition has talked about, so let me tell you a little bit about the experiences that I had, and that because I know so many people all over the United States that run escort services, or that have worked as working girls.

There’s tens of hundreds of thousands of them. And let me tell you a little bit about a story. First of all, who’s really taking advantage of who? I would argue that it is the women taking advantage of the men’s need for us. After all, who ends up with the money? We do. Who’s the one who sets the price? We do. They're the ones who shell out because they want what we have. And if they don’t want to pay it, then they don’t get it. I mean, that's, it’s as simple as that. So, I just, and by the way, can I just say that building an ugly building affects millions of people over hundreds of years, so… …so I didn't feel bad… But that was something just, she’s right, it absolutely offended me.

I just, there’s some, a lot of ugly buildings out there. So let me tell you about some of the gals who worked for me, and who are fairly, this is the, first of all, most of them are students. I did not hire anyone under the age of nineteen, no one I know, and I know dozens and dozens of madames, ever hires girls under the age of eighteen. Never. I only took forty percent of the young lady’s earnings, and they wanted to give that money to me. They didn't have to. But, I took the phone calls, I'm the one who set it up, I'm the one who checked them out, I'm the one who made sure they got the money if for some reason, you know, at the end of the evening he didn't pay, I would still pay her. And can I tell you something, in five and a half years, you should pardon the expression, we never once got stiffed. And we got… And we got the money at the end. So you know, they use the word pimp, and I'm not saying that there aren't people out there that, that really fit that description, that aren't horrible people, but we’re not all like that.

So, let me tell you about Colby. Colby was the daughter of a doctor, and she was used to living a very privileged life. She was in medical school, and she had several siblings who were either in college or medical school or law school or whatever. And Colby had a thing for, you know, beautiful clothes, six hundred dollar boots is actually the example she gave to me. And she came to work for me because she felt guilty asking her father, who had so many other, you know, of her siblings in school, to give her six hundred dollars for a pair of boots. This was Colby’s choice. But this is the reason she worked for me, so that she could have six hundred dollar boots.

Sandy was a singer in a rock and roll band, and she and her band had finally broken through and had gotten a, a tour put together. And about three months before they were supposed to go on tour someone broke into the van and stole all their equipment. This was their chance to really be someone and really make it, and so everyone went to work doing something else, and Sandy came to work for me. You hear, and most of the girls, as I said before, were students. And the way I used to look at it is, here were the girls’ dreams on this side of the river. They wanted to be models, actresses, dancers, singers, they wanted a degree, they want, I had girls who wanted to be nurses, I had girls who wanted to be all different kinds of things. And, so this is their dream on this side of the gulch. And here they were over here, and they needed the money to pay the toll to the bridge to get to the other side so that they could have the life that they wanted.

And they decided, and they could have done anything else, they decided that they wanted to do this. And it was their choice. And I know it’s going to, a lot of people are going to find this offensive, but I don’t think there’s one single solitary girl that worked for me who didn't come back after the very first time and say, I can't believe it was so easy. I can't believe I didn't do this before. I know, I know this is offensive to some people, but I mean, may a lightning bolt come down, this is what they said. And with respect to the guys, I mean, you should, we had terrific, we had a little Saudi prince who… …who wanted to have pillow fights, because when he was a kid he never got to have pillow fights. We had workaholics who had no time for a personal life, especially back in the early eighties, we had currency traders who, you know, were awake at all different times. They didn't have time for a girlfriend. Women weren't going to put up with guys who were never around.

I mean, these were guys that women pay thousands of dollars to join these matchmaking services in order to meet. They were people who were between relationships, they wanted a sure thing. There were lonely travelers. There’s a lot of guys out there who were on the road, you know, week after week after week. They just want a little company. Now, when you figure that, we euphemistically call it the nitty-gritty, only lasted maybe five, seven, eight minutes, and yet the clients kept the young ladies for one hour, two hour, three hours, four hours. What were they really paying for? If they, all they wanted was the sex, believe me, they could have gotten it for a hell of a lot less, we charged top dollar, that that’s not all that they pay for. A lot of them pay for the company, they pay because they just, they want a pretty girl to talk to and to have a good time with.

I had a couple clients who had invalid wives who felt that it was cheating if they had a girlfriend, but they still had needs that they needed to have met. So, while it is true that there are a lot of bad people out there doing bad things to girls, I think to say that all of these girls are abused, that all of these girls are taken advantage of, that they're all traumatized, yes, there are some, but it’s certainly not the majority, and I, believe me, I want them to throw away the key on these people too. But, I think to tar everyone with the same brush is just not being realistic, because there are a lot of good people out there who are doing this. And to criminalize these girls, and to give them records so that they can't go and live a normal life just to me doesn't seem right.

## Round 2

### Moderator
Claim: Thank you, Sydney Biddle Barrows. That concludes round one of our debate. I need to say that without you laughing at me for the radio broadcast, or you can just sit in silence, but I just need to say it without the laughter, because it would be impossible to explain to the audience, radio audience… That concludes round one of our debate. You're, you're very kind. What had happened, I got distracted by the results from the initial vote, which I find quite surprisingly lopsided, but we will share them with you now. As things stand now, twenty percent of you are for the motion, fifty percent of you are against, and thirty percent of you are undecided. And recall that we will have you vote again towards the end, and we chose the winner depending on which side has moved the most votes. So we’re going to move now onto round two, and in round two the debaters speak directly to one another, and we also take questions from you. What will happen is, we have people in the audience who will come to you if you raise your hand. Catch my attention, and I’ll signal a microphone to be brought over toward you.

And when you take the microphone please hold it about a fist away from your mouth so that we can hear you in the hall, and also so that the radio recording can pick you up as well. But I want to kick off the questions first by turning to the panel and saying, after hearing the opening statements I feel as though I'm hearing two teams debate two entirely different worlds, one in which, in one world, in one of these worlds prostitutes are workers. In the other world, prostitutes are captives. In one world prostitutes have free choice, in another world prostitutes have no choice whatsoever. And I, especially given the description that you left us with, Sydney, of you're talking about young women making choices, I want to ask anybody from the opposing side to address that point with Sydney on the matter of choice. Particularly Catharine, you had said that there really is no free will, if you are a prostitute it is never your choice. I would like you to address that, or any of your teammates, to the other team.

### Conspiracy Advocate (CA)
Claim: I didn't say what you just said. I said that it’s always in a context of sex inequality in which your options are precluded, to begin with, and as Melissa pointed out, there’s a dramatic amount of racial and class based bias in the people who are actually in this industry. And you know, prostitution is what women do when all else fails, and all else fails often. And there are a lot of things that men do, in general, when all else fails, and prostitution is not that thing. And that means this is an institution of sex inequality. It is. And you know, when, but I would also note, that we actually agree with, that is, Miss Barrows and us concur in the view that the sold in this, the women, the girls, when they are boys or men, should not be criminals. They should be, the prostituted people need to be de-criminalized, firmly. That is the Swedish model. And it’s the buyers who we’re here to talk about, the johns that Melissa described. And whether, what it is, what it is they are doing when they are buying people.

### Moderator
Claim: You're teammate, Melissa Farley.

### Conspiracy Advocate (CA)
Claim: I would like to quote, to respond to what Sydney said, and quote from her book, which is, she said, “A call girl is simply a woman who hates poverty more than she hates sin.” I would use the word prostitution and not sin, so I would say a call girl is simply a woman who hates poverty more than she hates prostitution. I think that’s the whole point we’re making here, that shouldn't be the choice. If we’re seeking an end to inequality between men and women, if we’re seeking an end to violence against men and women, women should not have to make the choice between poverty and education, paying the next month’s rent, and prostitution.

### Moderator
Claim: From the other side, Lionel Tiger.

### Scientific Advocate (SA)
Claim: I'm sorry that this whole discussion now is focused on prostitution. I thought that what we were talking about was the economics of human sexuality, and that is really the parsimonious fundamental issue that we have here. People engage, and I mention the engagement ring in marriages, which have immense responsibilities to the next generation, to communities, to relatives, to friends, and we’re somehow putting the immensely complex and, and both luxurious and difficult business of being an adult lover into the same rubric as prostitutes who, and I think there’s an argument to be made that it, yes it’s terrible, now we’re starting to hear how this all expresses sexual inequality and racial equality. Please, let’s try to limit the discussion to the subject of human sexuality and stop including every single allergic category that comes into these discussions—

### Moderator
Claim: When, when do—

### Conspiracy Advocate (CA)
Claim: Like reality, for example?

### Moderator
Claim: When, what Lionel is doing is saying that buying a diamond ring is paying for sex, and do—

### Conspiracy Advocate (CA)
Claim: Yeah, I think it’s actually the negative team that is equating, in equating marriage and dating with paying for sex. The negative team is conflating things that should not be conflated. First of all, in prostitution there’s no shared desire. Right? Which means one person is an object. That's a big difference. Also, marriages in which there is a transactional element, in which it’s, okay, you give me this, I’ll give you this, there’s a fifty-fifty exchange of services, end up failing precisely because that’s not what a marriage is. Right?

But I want to address the free choice issue, because Miss Barrows says that she doesn't recognize any of the girls, or the men. So I just want to refresh her memory. Because I thought her book was really interesting. And she said, quote, quite a few of the new girls that she used had no money and nothing appropriate to wear, so I would take them to Saks and charge whatever they needed on my credit card. They would pay me back from their future earnings. When she found a fabulous ground floor apartment for her office, which was super cheap, the rate was made up for by making the girls sleep with the landlord, who she said was only interested in one thing, and lived in a seedy semi-furnished apartment and made them feel cheap.

She says the girls weren't crazy about the plan, and really one can see why. Is that free choice? That doesn't sound like empowerment to me. To me empowerment comes from actualizing your unique potential in the world. That’s what empowerment is. Realizing you're unique, and you have a unique contribution to make to this world, not being forced to sleep with a landlord to enrich somebody else’s pockets. I'm sorry.

### Moderator
Claim: Tyler Cowen, you want to come back to that.

### Scientific Advocate (SA)
Claim: Our moderator is a very objective fellow, and what he’s pointed out is that there are many different worlds here. And this is true. And what I would like you to do is to think through the implications of there being many different worlds. The other side is asking for a blanket condemnation of a practice. I'm asking you to see many different worlds, to understand this diversity of human preference, experience, and culture.

And once we view the debate in this terms, in my view, the correct answer is to side with us, that there is no blanket condemnation, it is a diverse set of situations with many entirely acceptable outcomes, a lot of very bad outcomes, and the other side is simply pressing the emotional buttons again and again and again on the bad outcomes, and trying to press all of our buttons. And I urge you to resist that, to stand back, look at the bigger picture, and do not issue the blanket condemnation.

### Moderator
Claim: Tyler, you're saying sometimes it’s okay to pay for sex?

### Scientific Advocate (SA)
Claim: There are many instances where the practice is badly regulated and we observe bad outcomes. Trafficking is an example. None of us are defending that, but that’s not the proposition.

### Moderator
Claim: Is it, to the other team, is it ever, is there a sometimes, or sometimes it’s okay to pay for sex? Melissa Farley?

### Conspiracy Advocate (CA)
Claim: I would like to address this trafficked toddlers issue, which is basically ranking victims. When you decide that a battered woman is not really harmed because her arm wasn’t broken, or a slave isn't harmed as much if they're in the house as opposed to in the fields, or a woman in prostitution is not harmed as much if she’s a little older. And I’d like to tell you that a friend of mine who works in the field of child prostitution recently told me that there’s now a move to only rank genuine victims of prostitution of children if they're pre- pubescent. So the age is always going down, we’re always carving out some group that it’s okay to use in prostitution. I think when we make these false distinctions, we’re agreeing to set aside a class of human beings, the ones that make more, they're a little older, a little this, a little that. We’re setting aside some people who’s suffering we agree to ignore.

### Moderator
Claim: We're going to go to audience questions now and bring up the house lights, and begin to raise your hands, and we’ll get microphones over to you. But Melissa, I don’t, in a way I think you actually glanced off my question with what you were saying, but Tyler Cowen is arguing that sometimes it’s okay to pay for sex. He used the example of sexual surrogates, he used the example, not using the word quadriplegic, but that was implied, that somebody who may not have an opportunity for another sexual experience, and therefore hires a prostitute. And he says that in those cases sometimes it is okay to pay for sex.

### Conspiracy Advocate (CA)
Claim: Right—

### Moderator
Claim: Wendy Shalit?

### Conspiracy Advocate (CA)
Claim: Yes, I’d like to address that, because I think those are really important points that he raised. If you show me anyone who, a man who is handicapped, I will give you a man with the same disability who has a woman who loves him. And women are not that superficial. And if somebody, if, I'm sorry, there’s a lot of women who love men… And, and… If there’s somebody who’s using prostitution as an excuse, I think that's a problem. And I, about this issue of, that prostitution is really altruism because it’s feeding, you know, poor women, and that’s part of the diversity, I understand that, but I fail to see how that justifies it from the male perspective. If you really want to be altruistic, just give her a loaf of bread.

### Moderator
Claim: A question from the middle of the aisle. And, and I beg you to keep it terse.

### Moderator
Claim: Oh yeah, no, of course.

### Moderator
Claim: Thanks.

### Moderator
Claim: Hi. So I'm in college, and I remember very distinctly that when I was in middle school our sexual education is a three year program, but there are only so many ways that you can describe, you know, the act of sex, so what we focused on eventually was disease, and I was wondering if anybody on the panel had any opinions about disease in this scenario, especially, I would like to ask specifically Miss Barrows about, if she had any experiences with this while she was running Cache.

### Scientific Advocate (SA)
Claim: Back when I was in business, there was no such thing as AIDS. Well, there was in the gay community but no one really heard about it yet, because I was out of business in 1984. The way that this, the upscale call girl business ran back then is, the young ladies did not wear condoms. If, I mean, the men didn't wear condoms, and young ladies couldn't insist on it. If they did not agree to that, then they didn't have to work for us. But I mean, the thing, there was pretty much nobody they could have worked for in the city, because that’s the way everybody did it. I do have to say that we did have, once, we had a problem with gonorrhea, I paid for all my young ladies to go to the doctor, and I also called up all the other agencies that I knew were sort of in my category, and told them that, you know, we should, everybody should insist that the clients wear condoms. And you know what these other women said to me, what do you care about these girls? They, you know, they wouldn't care this much about you. And I was absolutely horrified. So you know, there… It’s true that there are a lot of bad people out there who are running businesses like this, but there are also a lot of people out there, because I'm not the only one, who genuinely care about the girls who work for us, and would never, ever, ever put them knowingly in harm’s way.

### Moderator
Claim: Melissa Farley do you want to also take up the question of, based on your research, and take up the disease question, and is it central to the argument?

### Conspiracy Advocate (CA)
Claim: It’s not what we heard from women in prostitution that this is their main concern, is physical, even physical injuries. The main concern is to get out and to figure out how to get out. And the thing that causes them the most suffering is the psychological damage that’s extremely long lasting. The bruises and the--they even heal from the rapes. So this is what I’ve heard. I think when someone, let me, cac I say one other thing—

### Moderator
Claim: Yes, please do.

### Conspiracy Advocate (CA)
Claim: …about disability? I think prejudice against someone who has a physical or emotional disability is wrong. The cure to that prejudice is not selling someone to that person so they can have sex. The cure is to address the disability-ism, and the looks-ism in our culture.

### Moderator
Claim: I’ve told you that you’d be number two, I’d like to put you to number three, because I’d like to bring different sexes into the discussion. And there’s a gentleman, and you’ll be third… Yes, you’ll be number three.

### Moderator
Claim: My question is for Professor Cowen, there was a case in Germany, I actually don’t know what the outcome was, but assuming that this is a country where there is well regulated prostitution, where a woman was denied unemployment benefits because she had not tried to become a prostitution. So, my question for you is, if prostitution, is if we’re going to have a well regulated prostitution, is it going to be treated like any other profession? Because if so, obviously every woman always has that alternative, and therefore the state can ask women to become prostitutes instead of getting unemployment benefits.

### Scientific Advocate (SA)
Claim: My understanding of the German story is that it’s quite different from how you described it, that the woman simply was given a list and asked what other professions she had tried to seek out, that she was not in any way forced to become a prostitute. But putting that example aside, if indeed that were the case, that is an example of a silly rule, a silly regulation. None of us here are for that. But pointing out that that’s a silly way of running unemployment benefits does not establish the blanket condemnation behind this principle.

### Moderator
Claim: Does the opposing team have a response to that? No? Ma'am, your turn.

### Moderator
Claim: Norma Ramos from the Coalition Against Trafficking in Women. My question I would like to have addressed by Dr. Farley and Catharine MacKinnon. We keep hearing that the solution is better regulation. I’d like you both to address what the real experiences are in the countries such as the Netherlands and Germany that are regulating the commercial sexual exploitation of women, which we at the coalition against trafficking in women refer to as the world’s oldest oppression.

### Moderator
Claim: Catharine MacKinnon.

### Conspiracy Advocate (CA)
Claim: Yeah, Germany is actually thinking about the Swedish model at this point, having discovered that a tremendous amount of trafficking is produced by the draw of legalization. And that’s the same as in the Netherlands, although they're not considering the Swedish model at this point, but are looking to try to address the abuses that happen as a direct result of their legalization, across the board legalized initiatives. The other thing that happens in countries, for example, or in parts of countries like Australia where you regulate it better, that is in the interest of trying to reduce the violence and the illness and other forms of abuses of the people, women in prostitution, you create a legal industry so you can regulate it well, that’s their whole attempt. What ends up happening, you know, apart from the fact that you can't put anything in the rooms like pillows because they're a lethal weapon, or sheets, because somebody might get tied down by them, so it’s a pretty bare prostitution experience. What happens is that the men who want to buy all the things that are abusive and dangerous and destructive to the women, in addition to the psychological, which remains the same, go to the ever-exploding illegal industry around it. Right? So you legalize it in the name of having a well regulated prostitution industry, and exploding around it is the illegal industry for which there is no legal structure to address, for all the men who, to begin with, want to have sex without condoms.

### Moderator
Claim: Tyler Cowen, your opponent, does that mean you're, you have been arguing that it can be regulated to safety and—

### Moderator
Claim: Go ahead.

### Conspiracy Advocate (CA)
Claim: Apparently he’s a lot smarter than, you know, several hundred years worth of other people who have tried to regulate and who have a million different ideas about how to do it.

### Moderator
Claim: Tyler Cowen.

### Scientific Advocate (SA)
Claim: I spoke at length about New Zealand, there’s a several hundred page study about the experience which I have read. The other side has not uttered a peep about this, and even in the example of Germany, it’s just been admitted, the real problem is the illegal trade, which in some way should be de-criminalized. The European model can be improved, but for the most part the Western European model has worked better than what we do right here. This is widely understood throughout the world.

### Moderator
Claim: Melissa Farley.

### Conspiracy Advocate (CA)
Claim: I actually have read the New Zealand report, and I also have studied prostitution in New Zealand, and one of the things that happened in New Zealand is what a Maori community activist called an apartheid system of prostitution. In New Zealand, the Maori people are prostituted much younger and much longer, and they're more frequently homeless, so we again have that situation in New Zealand of a special class of people who are more vulnerable—

### Moderator
Claim: But Melissa are, are you saying that regulation can never wipe out abuses, or do you just not like the idea anyway?

### Conspiracy Advocate (CA)
Claim: Well, let’s talk about the regulation. What happens in real life in New Zealand, to stick with that for a moment, is that zoning is the sine qua non of regulation of prostitution.

### Moderator
Claim: You mean where, where an establishment is, where it happens?

### Conspiracy Advocate (CA)
Claim: The people who have a lot of money don’t want it in their backyards, so it’s zoned into the neighborhoods of poorer people, thereby increasing trafficking, johns, solicitations, and their general vulnerability to all aspects of the sex industry. This happened in New Zealand, so—

### Moderator
Claim: But the clarification I'm looking for is that—

### Conspiracy Advocate (CA)
Claim: Sorry.

### Moderator
Claim: …if Tyler is right, and ultimately a system could be, of regulation could be developed to avoid the sorts of abuses that have been talking about, would that be okay with you?

### Conspiracy Advocate (CA)
Claim: I, what… Here’s the answer to that… It’s counter- intuitive. It’s been tried, and it didn't work. The Mayor of Amsterdam said, and I think this is true of many people, we thought it would work to regulate. Well-intentioned people thought it would work to regulate, and it didn't. It actually, it’s very counter-intuitive. He said, what, they're shutting down over a third of the legal brothels in Amsterdam right now. Why?

Because eighty percent of the women in Dutch legal prostitution are moved there from economically stricken Europe, and because there’s organized crime that’s out of control. Legalization is a pimp magnet, so I mean, that’s the answer. If we know that it doesn't work, it’s been tried, but—

### Moderator
Claim: A, a quick, I—

### Conspiracy Advocate (CA)
Claim: Can I just respond to that, I—

### Moderator
Claim: I was going to actually try to get the next question to go to you, how about that?

### Conspiracy Advocate (CA)
Claim: I just wanted to know, I'm just—

### Moderator
Claim: I guess not.

### Conspiracy Advocate (CA)
Claim: No, I do. I just wanted to know, because I haven't heard the answer to this, on this point, if I may. If it’s a question of being badly regulated, then why do we see in the countries where it’s been legalized, we see that the trafficking has increased. Nobody has addressed my point that nobody asks the ages of the girls when they pay for sex, and that’s the link between the trafficking. And no one has addressed that so far.

### Moderator
Claim: From the, from the black please. Gentleman?

### Moderator
Claim: Okay, this is for the women who say it’s wrong to pay for sex—

### Moderator
Claim: Let’s aim this towards one—

### Moderator
Claim: First, just want to establish, fact, is it okay for you guys that a woman be a professional female masseuse and give massage therapy to a man.

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: No problem with that.

### Moderator
Claim: It is okay if a man goes to a particular masseuse because he finds her extremely attractive and is turned on by it, and only receives massage therapy?

### Moderator
Claim: We’re talking slippery slope here, I think.

### Conspiracy Advocate (CA)
Claim: I can see it getting slippery.

### Moderator
Claim: That’s, so that’s okay? All right, third question, if during that process—

### Conspiracy Advocate (CA)
Claim: Not if the man were my husband.

### Moderator
Claim: If during that …he has an orgasm, even though the woman didn't do anything out of the ordinary, did only professional massage therapy, is that okay?

### Conspiracy Advocate (CA)
Claim: I don’t know, I mean, I think this is a kind of…extreme example—

### Moderator
Claim: This one has stymied…

### Conspiracy Advocate (CA)
Claim: I think what you're—

### Conspiracy Advocate (CA)
Claim: I don’t think what—

### Conspiracy Advocate (CA)
Claim: I think what you're trying to do with the question is collapse the distinction between human touch and the significance of sex. And I think sex is different and just because you're giving someone a massage, I mean, there’s nothing wrong with that. But I think that sexuality is something different, and you can always come up with an extreme example to collapse that distinction, but that just begs the question.

### Moderator
Claim: Okay, we are halfway through the direct head to head part of the debate. I want to remind you I'm John Donvan, your moderator, and I want to now go to the other side of the table, Lionel Tiger, who argues against the motion, wants to pick up on that last point.

### Scientific Advocate (SA)
Claim: Well, first of all I, there’s a kind of a historical component to the other side. There’s a famous syndrome in Turkey, rural Turkey, the Natasha. The Natasha is a Russian woman who goes to a small town in Turkey and capsizes the entire system because she’s sexually available. Now, the reason Natasha is there is because the men in Russia are drunk all the time, they have very low longevity, they are improper and not very useful husbands, the result is the birth rate in Russia, which is plummeting, it’s a major crisis actually. But the reason for the Natashas comes out of a really poignant human story. And I continue to feel that we’re losing not the nicety of the argument here, we’re losing the grandeur of the human issues that force some people into a small, intimate room, where they do something, and yes, it causes some people the distress that we’ve heard about. None of us on this side applauds that. At the same time, this is not exactly a trivial issue and I’m afraid it’s being reduced in its importance into a sentimental kind of grab bag of victim complaints—

### Moderator
Claim: Why sentimental.

### Scientific Advocate (SA)
Claim: Well… Because it’s easy. It’s all very—it’s easy in this country and everywhere else to talk about racial, class distinctions and so on. Many of the clients of prostitutes I suspect, don’t have a great deal more money than the prostitutes, I don’t know. Essentially what I’m trying to do here is, get the argument into the larger context of, of human sexuality, and away from a relatively, again sentimental concern. There was just—if I may make one final comment on this, there was recently the publication and we’ve known in the primatology trade about it for years, that it turns out that chimp males who hunt, will give meat to women who—

### Moderator
Claim: To women?

### Scientific Advocate (SA)
Claim: —will—if—a female— Maybe. To female chimps, and the—but the fascinating thing is it’s not just a quid pro quo. Because these become sustained and durable relationships, in which the male is a consort and an associate of the female, even when she’s not in estrus and therefore sexually available. And that is, it’s kind of haunting. Because it suggests that, this is actually a more elegant phenomenon than just giving meat to a female.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: Uh—

### Moderator
Claim: I see Wendy Shalit is quite anxious to come in on this.

### Conspiracy Advocate (CA)
Claim: I’m— I have to admit I’m—

### Moderator
Claim: Wendy, can you just find your microphone—

### Conspiracy Advocate (CA)
Claim: Sure—

### Moderator
Claim: Thanks.

### Conspiracy Advocate (CA)
Claim: Sorry. I’m surprised by the negatives’ reliance on the argument that it’s not going away and historically, a lot of people have been doing it. We’re not debating whether it’s common, to pay for sex, we’re not debating whether it’s happened, we’re arguing whether it’s right or wrong. And, I think, I mean, if you bring up primatology, I’m just—I have to bring up, Mr. Tiger, your book which I really enjoyed The Pursuit of Pleasure which was a pleasure to read…by the way, I must say. I found one example really interesting, you mentioned female genital mutilation. And you said what’s significant about female genital mutilation, is that men, males want sexual access to women, but they cannot bear it when other men have access to their mates. A common solution to the problem is the double standard, of which female genital mutilation you say is the extreme representation. Here the effort is to try to control both sex and reproduction at once, by imposing strict controls on the sexuality of women. In an effort to prevent their wives’ impregnation by men other than themselves. Now, I think we can always, you bring up chimps and primatology, we can explain yes female genital mutilation in terms of primatology but I hope we can all agree that that’s still wrong. And, just because—

### Moderator
Claim: Question from the right side—

### Conspiracy Advocate (CA)
Claim: —just because the chimps can provide an explanation doesn’t mean that it’s right.

### Moderator
Claim: The questioner is over on the far right here.

### Moderator
Claim: My question is for Mr. Cowen. You made a distinction between toddlers who are prostituted and adults who are prostituted. Sometimes, adults who are prostituted enter prostitution as toddlers or children. So—

### Moderator
Claim: Now, could you move the mic—

### Moderator
Claim: Yeah.

### Moderator
Claim: Thank you.

### Moderator
Claim: My question to you is…a simple one. Is it okay to buy a 20-year- old woman, if that woman entered prostitution as a four-year-old, a 10-year-old, a 12-year-old.

### Scientific Advocate (SA)
Claim: Probably not. There are plenty of cases, as I am more than willing to admit, where what goes on, is wrong. But again, look at the resolution. The key point is that there are diverse practices, and multiple worlds. What you’re finding from the other side, is to take a woman in a difficult situation, choosing her best option. I’m saying, blame the difficult situation. They’re saying, blame the best option. It’s a very simple choice. Which one are you going to blame. Again I say blame the difficult situation.

### Moderator
Claim: Gentleman in the far left.

### Moderator
Claim: Hello, good evening. My name is I’m a professor of psychology at the New School for Social Research and I have a question for the panel in favor of the motion. When you were describing your prototypical prostitute, it came to mind for me, a prototypical coalmine worker. Typically exploited for two or three generations, they had no other chance but going to the mines, and typically they suffer long-term mental and physical health consequences, consequences for their employment. And I suspect that you would make a difference between this and you would argue that they’re two different cases. And my—I suspect that your making difference on this would be based on disgust. And as many a philosopher of law have argued, and I agree with basic—

### Moderator
Claim: I need you to get— I think we see where you’re going but I need you to get to a question.

### Moderator
Claim: Yes, so the question is where it is on disgust that you make this, this difference, and I would argue that this would not be appropriate, as many philosophers have argued, we should not, legislate on the base of disgust.

### Conspiracy Advocate (CA)
Claim: We’re talking—

### Moderator
Claim: Melissa Farley—

### Conspiracy Advocate (CA)
Claim: —about the evidence of harm here, not a moral or emotional reaction. And the evidence of harm, I think the other side has just conceded the debate, if it’s wrong to prostitute someone who was a child when they entered prostitution, then what we know, and there’s no argument about these numbers, is that in the vicinity of 75 to 85 or 90 percent of everyone in prostitution, entered prostitution as a legal minor, oftentimes, a 13- or 14- year-old. That’s a fact.

### Moderator
Claim: Sydney Barrows.

### Scientific Advocate (SA)
Claim: When she says that’s a fact, you—that may be a fact with respect to the people who have been interviewed, but you have to remember, that the people who are interviewed for this sort of thing are a great minority, they are the ones that are in the most trouble, they’re the ones that end up, you know, being the most messed up. And so they’re the ones that these people get to talk to and to interview, and I’m not debating that these people have horrible problems. But to take a small minority and to apply their problems to the majority, is just— wrong.

### Moderator
Claim: Catharine MacKinnon.

### Conspiracy Advocate (CA)
Claim: This research has been very carefully designed so that they really are a representative sample of people at all levels, at all stages, at all class divisions, positions, in the industry. What’s being described by Ms. Barrows is research she doesn’t know. And, it… What—and the PTSD rates don’t vary according to class level, is the other thing to remember. As to coalmine work and its negative consequences, what you describe is some people’s human rights are being violated through this work, that—in the way that it’s being done, in the coalmine industry. They have human rights and they need to be recognized. What we’re talking about is people whose human rights are being violated, and they need to be addressed. Now as it happens, whenever someone else is selling you for sex, you are trafficked, and your human rights are being violated. The vast majority of people in the sex industry, somebody else is taking the pimp’s cut off their prostitution. And they’re do—and this is what is being bought when you’re buying sex, this is the reality of it, it is an industry of human rights violation.

### Moderator
Claim: Question from the top, please.

### Moderator
Claim: We have criminal laws against child abuse, we have criminal laws against slavery, there are criminal laws that cover this kind of, of repression of human rights. Now, as far as prostitution is concerned, if you take out the children that have been prostituted and the people who are held against their will, what you have is a contractual relationship. And…I don’t see anything wrong with that.

### Conspiracy Advocate (CA)
Claim: Then what you have is at most 3 percent of the industry. Is that what you’re defending?

### Scientific Advocate (SA)
Claim: Yeah, but I don’t know where you get that— Why would an upscale call girl even bother to be interviewed. The people that you don’t hear from are the ones—what’s in it for them? They have no problem with it, they’re not about to go and bitch and complain that they’re being, you know, abused, when they’re perfectly happy about it, you only hear from the unhappy people.

### Conspiracy Advocate (CA)
Claim: Well, I don’t think that’s—

### Conspiracy Advocate (CA)
Claim: One of the things—

### Moderator
Claim: Melissa Farley—

### Conspiracy Advocate (CA)
Claim: One of the things—

### Conspiracy Advocate (CA)
Claim: research is done.

### Conspiracy Advocate (CA)
Claim: One of the things—

### Scientific Advocate (SA)
Claim: We don’t get to hear what your—

### Moderator
Claim: Melissa—Melissa Farley. One of the things researchers have attempted to do is to increase the numbers of people we interview in indoor prostitution. Because it has been argued, and it has been my experience, that indoor prostitution and legal brothels and massage parlors and upscale call girl agencies, is often the—where the most harmed people are held, the most trafficked, the youngest. And so, you can’t make that assumption. Researchers, not myself, another person in San Francisco, and I’ve had this experience too, is that when we try to talk to pimps about interviewing their…“girls,” we’re denied permission to speak with them.

### Scientific Advocate (SA)
Claim: I don’t think it—

### Moderator
Claim: Syd—Sydney, I’m, I’ve…you’re rolling your eyes and I’d like to put some words behind that.

### Scientific Advocate (SA)
Claim: I just…this whole thing is just so absurd I wouldn’t even know where to start. I mean… There is nothing in it for the girls who don’t have a problem with it to talk to these researchers, why would they bother.

### Moderator
Claim: Wendy—

### Scientific Advocate (SA)
Claim: You don’t even know how many of them are out there—

### Conspiracy Advocate (CA)
Claim: they don’t have a problem.

### Moderator
Claim: Wendy Shalit?

### Conspiracy Advocate (CA)
Claim: I don’t think it’s accurate to say that we haven’t heard from these high-end call girls, we have heard from them. For example in your book, Ms. Barrows, you talked about Claudette, she’s the most empowered call girl, right, and she herself said this kind of work can be very taxing both physically and emotionally. “I’ve never met a man who can really understand what it takes out of you.” And I think that even the most supposedly empowered call girls when they are interviewed, do say thing— say things like this—

### Scientific Advocate (SA)
Claim: But see you took that in a negative way.

### Conspiracy Advocate (CA)
Claim: No, but— I think that—

### Scientific Advocate (SA)
Claim: Claudette loved—

### Moderator
Claim: Ladies and gentlemen—

### Scientific Advocate (SA)
Claim: —being a call girl—

## Round 3

### Moderator
Claim: —ladies and gentlemen, that concludes Round 2 of our debate. So, we are now in the final stretch and soon you in our audience will be choosing the winner, and recall that at the start of the debate we asked you whether you took sides with or against the motion before us, which is, “It is wrong to pay for sex.” Here are the results from your vote before the debate. 20 percent of you were for the motion that it is wrong to pay for sex. 50 percent were against, and, 30 percent were undecided, and we don’t have it on the graphic but I’ll share with you, that the for— in the “for” category, it was 2 to 1, women to men. In the “against” category, it was 3 to 2, men to women. And undecided was roughly equal. So, we’re gonna go to closing statements now, that’s Round 3, and right after that, we will ask you to vote another time and remember we’re gonna end twice, once with the simple results and then, round of applause from all of you, and then we will share with you the breakdown by sex for those votes. So on to Round 3, closing statements by each of the debaters, speaking first against the motion, Lionel Tiger, anthropology professor at Rutgers University.

### Scientific Advocate (SA)
Claim: You’re using my time. Basically—I’ll have to repeat I’m afraid what I already said which is that, we have taken a subset of human behavior which we all disagree with and despise, which is coercive, which is as the speaker just before mentioned is covered by painfully wrought criminal law and so on, and we’ve turned that into a metaphor, and then a description of the common human experience that we all have of men and women or men and men or women and women together. And somehow, in the description we lose the generosity of spirit, the sense of adventure, the intensity, and, let us not forget, and not mentioning primates again, but sex is about human evolution, it’s about reproduction, it’s the most important thing any species has to attend to. And it would be a great surprise, if it were not confounded by glitches, sometimes tragic ones, it would be a great surprise if everyone was in agreement about it. We have, talking about prostitution, Indian girls are betrothed at the age of four to a guy who’s five and they are married, but they obviously can’t perform as married couples until they reach a certain age. The Kama Sutra, that famous book that nobody’s ever been able to succeed in emulating, was given to the new couple when they finally were married so they could practice this great craft of sex. I’m, all I want to protect here, is the notion that sex is not a disease, that sexual interaction is not necessarily an expletive, exploitative phenomenon, that it has its own legitimacy, its own agenda, and it will and has continued, in much the same way and a sensible society will try to make it better—

### Moderator
Claim: Thank you—

### Scientific Advocate (SA)
Claim: —not to criminalize it—

### Moderator
Claim: Thank you, Lionel Tiger. I wanna point out that in our closing round, each debater is given a brief amount of time, two minutes each, to make a closing statement and a final appeal for your vote and now, summarizing her position for the motion, Wendy Shalit, author of The Good Girl Revolution: Young Rebels with Self-Esteem and High Standards.

### Conspiracy Advocate (CA)
Claim: Thank you, I certainly agree that sex is not a disease, so I’m glad we can perhaps all agree on that… Look, nobody has addressed my point that, no one asks the ages of the girls, when they pay for sex, and that is the link between the trafficking of children, as well, and, so you wanna, I think, consider that, that’s something that nobody has addressed and it makes those paying for sex responsible. Look, I think…since the 1960s, we’ve been beholden to this false dichotomy that, you know, you’re either a repressed person who has no feelings, or the prudes, or you’re the liberated who goes around with everyone, and treats sex casually and I don’t think this dichotomy really captures the experience of most women or most men for that matter. And I think we need to revive the idea of higher standards for both sexes. And, that sex is a good thing, but we don’t have to take advantage of the most vulnerable in our society when we choose our sexual partners. The devaluing of women and children’s innocence that happens in a society that makes sex into a commodity, to validate that, and to declare that paying for sex is perfectly fine, is to say something about society’s relationship to women and especially girls that I think would be detrimental. But also to men. You’ve—yes, we’ve all read that Times article about sugar daddies, but to me what was so touching was the man who went on the website, and he just gave the girl a monthly stipend for her education. And he refused to have sex with her and this is what the debate is about, it’s about who we want to be. And who knows the far-reaching consequences of that, that he went on this somewhat depressing website, but he was capable of such greatness and saying no, you know what, I’m not going to pay for sex. And, if you think that what the man did didn’t matter, that he supported her education without even meeting her, and you think he could’ve just as easily paid for sex, and that would’ve been the same choice morally then vote for the negative team, but if you can see the beauty in that choice, which he made in the privacy of his own home, and not in any courtroom, then, vote for the proposition—

### Moderator
Claim: Thank you—

### Conspiracy Advocate (CA)
Claim: —because we’re not a monkey, men are not monkeys and women—

### Moderator
Claim: Thank you, Wendy Shalit—

### Conspiracy Advocate (CA)
Claim: —women are not chicken. Thank you.

### Moderator
Claim: Thank you. Summarizing against the motion, Tyler Cowen, economics professor at George Mason University.

### Scientific Advocate (SA)
Claim: Rather than repeat my major points, I’d like to focus on one small answer. The issue came up, what if a man is a quadriplegic, and wants to buy sex. The opposition still hasn’t answered this question, in my opinion, their responses were, to put it bluntly, lame. Women will come around, let’s teach women disability should not be a problem, that’s fine, no one will disagree with that. But what about, dot, dot, dot. There simply was no answer. The other side would’ve been much better simply saying look, that’s an exception to the principle, in that case it’s fine. But they cannot bring themselves to give that humane answer. I think when push comes to shove, there’s something about the notion of informed, consenting adults, which is what’s at stake here…making an exchange that they simply do not like. If you’re in any doubt, just consider different parts of the world, and where they would line up in this debate. The notion that there are real abuses, but that buying sex is something that we should tolerate, is extremely common in western Europe. The kinds of arguments you’re hearing on the other side. If you look at the debates over prostitution in the country of Iran, you hear exactly, and I mean exactly the same arguments in Iran, that you have heard from the people on the other side of this debate. If you look at what some aspects of what the religious right push for, the arguments they make, it is very similar to what you have heard on the other side of this debate. If you’re in any doubt, ask yourself, in which set of societies with which set of attitudes would you rather live. Western Europe, or the kinds of places and cultures, where the attitude toward prostitution is that which you find to my right. Think about that, and then please vote accordingly. Thank you.

### Moderator
Claim: Thank you, Tyler Cowen. Summarizing her position for the motion, “It is wrong to pay for sex,” Melissa Farley, a psychologist and Prostitution Research and Education.

### Conspiracy Advocate (CA)
Claim: I think it’s wrong to pay for sex, there’s no mutuality of sexual pleasure or any other kind of power in prostitution, where one person has the social, legal, and economic power to buy another person, and to use them as a sexualized puppet. By the way one of the kinds of damages we haven’t talked about today, is the damage to women’s sexuality after being in prostitution for a long time. They usually are not capable of any kind of sexual intimacy, that reflects the years of selling that act in prostitution. They say, that’s stolen from them. Men who are sold in prostitution experience exactly the same kinds of damage to their sexuality, and the similar symptoms of traumatic stress. Maybe the primates we should take a lesson from, are the bonobos, who, when female bonobos are co-dominant, males are less aggressive and females are more sexual. There’s a lot of sexuality in bonobo society, everyone’s having sex. But it’s used for mutual pleasure, it’s used to cement social bonds. And by the way the first time a male—adolescent male gets sexually aggressive, the female elder bonobos get together and kick his ass. He— He learns from that one experience that that’s not what sex is. So, one other comment about legalization of prostitution, it really is a failed experiment, the same numbers of women in legal prostitution in Nevada want to escape it, the same numbers are homeless, as in other kinds of prostitution. The institution of prostitution is built on the exploitation and abuse of women, it can’t be fixed, only abolished. I’m relentlessly optimistic about men’s capacity for change. It’s wrong to buy sex.

### Moderator
Claim: Thank you, Melissa Farley. Summarizing her position against the motion, the Mayflower Madame, Sydney Biddle Barrows.

### Scientific Advocate (SA)
Claim: Well, people have tried to legislate human nature and morality for centuries, and it’s never worked. It’d be great if it did, but it doesn’t. So we have to get real. Now, it is true that, it’s…when it comes to the younger girls, I think it’s tragic and I don’t understand why we are not absolutely prosecuting to the fullest extent of the law, men who want to have sex with a young girl—I mean I’m talking really young girls and children. So she goes up, she sees his etchings, and he has his way with her ‘cause she’s so drunk that she can’t practically say no, and then oh yes, oh sure, I’ll call you tomorrow, he never does…she’s just been used. But a guy who thinks that a woman is worth it, he calls up and he says, I think that it’s worth $500 an hour, for me to pay to have sex with you, I think you’re worth it, I wanna give it to you, I don’t wanna pour $40 worth of drinks down your throat and steal it from you. I wanna give it to you. And so, I don’t think that there’s anything—I mean, you have a lot of very honest men out there, who pay for it because they feel it’s being more respectful. Not for children, not for trafficked women, but there are huge amounts of men out there who pay for it because they believe it’s the right thing do, that it’s a fair exchange, and they want and they choose to do it, and we should—the women should be allowed to take the money. Why not.

### Moderator
Claim: Thank you, Sydney Barrows. And our final speaker tonight, summarizing her position for the motion, “It is wrong to pay for sex,” Catharine MacKinnon, professor of law at the University of Michigan.

### Conspiracy Advocate (CA)
Claim: Thanks. From the other side we’ve heard that paying for sex is old. That it’s diverse. That it’s natural. Although I don’t think there are any pimps among chimps. That… that there’s a global grandeur to human sexuality. And, also I think in essence that there’s nothing wrong with it if you get paid for it but you aren’t the one that has to do it. But we haven’t heard an argument about why it’s right. And little bit about why some aspects of it might not be wrong, entirely. But nobody’s really saying why it’s right. And to be on the cash nexus, with sex. When this gets, you know, pushed down to the fine edges of the slippery slope we essentially are having a, you know, if they get their way, what can we still have, department. And UNESCO, which is a United Nations entity, has this to say about the relation of what we’ve been talking about, sexual victimization, and the economic exchange, they say, “Sexual victimization”— this is a quote— “has been found to be the first step in the breakdown of a woman’s identity, which is necessary, to render the human body into a sexual commodity for economic exchange.” That’s I think what it is. It’s not only about—what that’s saying is, I think, is that what’s right about sex, is what paying for it violates. The hard issue I think for our side is, what to do when women aren’t paid for anything else. I’ve recently been working with 13-year-old girls who are the sole support of their families, an inter-generational caste-based prostitution in India. And they are the ones who are saying, not…how can you take this one and only thing away from us that is the only thing that anyone will buy. They are the ones who are saying, give us any real option. This—our economic desperation that has put us in this position, is not all our lives can be. And, they’re saying, in Mr. Cowen’s terms, change the difficult situation. Now, the other thing that is not being addressed by the other side is the question, why aren’t men being sold for sex. Like by the millions worldwide in the same ways and in the same proportions women are, it seems me, that if being bought and sold for sex is part of the grandeur of human sexuality that men are really missing out on something here.

### Moderator
Claim: Thank you, Catharine MacKinnon.

### Conspiracy Advocate (CA)
Claim: So…

### Moderator
Claim: And that concludes Round 3—

### Conspiracy Advocate (CA)
Claim: Women vote—women vote 1—

### Moderator
Claim: Clo—closing statements—

### Conspiracy Advocate (CA)
Claim: —men vote 4. Okay?

### Moderator
Claim: And it is now time for you to pick the winner, the motion before us once again is…it is wrong to pay for sex. And if you turn to your keypads…keys number 1, 2, and 3, are for females in the audience, 4, 5 and 6 are for males. All the other numbers are for the bonobos. And we’ll give you about 30 seconds to lock that in.

### Conspiracy Advocate (CA)
Claim: Is it bone-a-bos or bon-a-bos.

### Moderator
Claim: Bon-a-bos—?

### Conspiracy Advocate (CA)
Claim: Bonobos,

### Moderator
Claim: Does anybody need more time? Okay, recall, in about three or four minutes we’ll have the results tabulated and we are going to announce them two different ways. And please, when I raise my arm like that, some applause would be appreciated. So, while the votes are being tabulated I wanna talk with you, first of all thank your debaters for a very, very spirited evening. And I also wanna thank everyone in the audience who asked a question and everyone—all of you were—you could feel it from the stage here, you were on the edge of your seats, you were very alive and present in this debate and it just really added to the energy, so to you as well. Now the final debate of our season will be Tuesday, May 12th, the motion is, “Diplomacy with Iran is going nowhere.” Panelists for the motion are Liz Cheney, the daughter of Vice-President Dick Cheney and a former State Department official, who oversaw Middle East policy during the George W. Bush administration. Her partner will be Dan Senor who recently co-founded the think tank Foreign Policy Initiative Bill Kristol. He is married to CNN’s Campbell Brown. Against the motion, Nicholas Burns, ambassador who served across five Presidential administrations over 27 years and was the highest-ranking diplomat at the US Department of State until his retirement last year, his partner will be Kenneth Pollack, a former CIA intelligence analyst and expert on Middle East politics, and son-in-law of my former boss Ted Koppel.

This debate will take place here once again at Rockefeller University’s Caspary Auditorium. In May we will also be announcing the motions for our upcoming fall 2009 season of five debates, so next month, we’ll have a clear look at what next year looks like for us. Tickets will then become available through our website. We know the dates will be September 15th, October 6th, October 27th, November 17th and December 8th. Scheduled to participate so far, across a range of topics, are Vanity Fair columnist and founder of news aggregator Newser.com, Michael Wolff, that will be on the death of the mainstream media… Congressman Asa Hutchison, the former head of the US Drug Enforcement Agency and Mexico’s former Foreign Minister Jorge Castañeda on Mexico’s drug wars. Eliot Spitzer on the economy. And former US trade representative, Ambassador Susan Schwab on buying American.

All of our debates as we’ve said before can be heard on more than 185 NPR stations across the country, you will hear yourselves, if you tune in. Please check your local NPR member station listings for the dates and times of broadcast, also copies of books by our panelists tonight as well as past debate DVD’s are on sale in the lobby, and are the results coming down? The wave-off means, keep talking. Here they come. So I’ll do this twice. Okay. So you voted before the debate on whether you agree or disagree with the motion, “It is wrong to pay for sex,” you have just now voted again, and here we go, before the debate, 20 percent of you were for the motion, 50 percent were against the motion, and 30 percent were undecided. After the debate, 45 percent of you are for the motion, 46 percent are against, and 9 percent are undecided, the side for the motion wins… Congratulations to all of them and of course, to the art of persuasion itself, for me, John Donvan, and intelligence Squared, thank you.

And now I’ll share with you how it broke down by sex of the voters. In the after-debate vote of 45 percent for the motion…58 percent are women, and 27 percent are men. Well, there’s an undecided as well. Undecided I have as 7. Are we gonna put a slide up ‘cause this’ll— All right, let me just read the numbers to you, it’s a lot of numbers. Women in the audience before the debate, I’ll read it to you this way, before the debate, women in the audience voted 25 percent for the motion, after the debate, they voted 58 percent for the motion.

Women in the audience before the debate voted 41 percent against the motion, and after the debate, 34 percent against the motion. In the undecided category, women. Before the debate, 34 percent of women here were undecided, 8 percent were undecided at the end. Now looking at men. Before the debate…13 percent of men were for the motion, after the debate, 27 percent of men were for the motion. Against the motion, men. Before the debate, 61 percent were against the motion, after the debate, 66 percent… were against the motion. And the undecided category, men, before the debate, 26 percent were undecided, after the debate, 7 percent were undecided. Thank you for your patience, for the calculators in your heads, for our debaters, thank you very much for this evening.
