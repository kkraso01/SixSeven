# Debate Transcript

Topic: Liberals Are Stifling Intellectual Diversity On Campus
Motion: Liberals Are Stifling Intellectual Diversity On Campus

Debate ID: 022415%20Liberal%20Stifling


## Round 1

### Moderator
Claim: So please welcome me-- please join me in welcoming to the stage Mr. Robert Rosenkranz.

Hi, Bob.

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hi. So, just to begin-- to begin on this, Bob, you mentioned a few minutes ago that you had recently been at an interesting dinner at Yale.

### Moderator
Claim: Well, I was invited to a dinner at Yale, and it's called “An Invitation to a Disinvitation.” And it was organized by a conservative group, and the people who were invited were a group of people who were disinvited to speak at other campuses, including, Ayaan Hirsi Ali, Condoleezza Rice and Christine Lagarde.

### Moderator
Claim: So, it touches very directly on the topic we're talking about. Now, we're at George Washington University. I want to make clear this is not-- we're not talking about George Washington University per se in this debate.

### Moderator
Claim: No. This is a much, much broader thing. We're just happy to be here because this is a splendid facility.

### Moderator
Claim: And great students.

### Moderator
Claim: Terrific guys.

### Moderator
Claim: And the-- talk to me a little bit about what's-- what are the tensions that are inherent in this topic that we're talking about, about intellectual diversity.

### Moderator
Claim: Well, I think Intelligence Squared was sort of started with the idea that you want to hear both sides of arguments. You want them-- the truth comes from the competition of ideas. And that critical thinking skills involve listening to both sides of-- of ideas before you formulate an opinion. And that's what we're hoping that the audience is going to do here tonight.

### Moderator
Claim: And yet we do set limits. We set – we have rules and--

### Moderator
Claim: We certainly do, and our goal is civil discourse. And I underline "civil." And I think that campus speech codes, for example, are trying to assert a degree of civility. And the question is, are they doing that, or are they, in a sense, squelching free speech?

Campus speech codes being one of the topics that I suspect will be touched on tonight.

### Moderator
Claim: And I think both sides are going to stipulate probably that by and large, at most American universities, most of the faculty is liberal. And I wonder, does that, all by itself, mean, well, there's no debate here if it's through the faculty?

### Moderator
Claim: Well, I don't think so. And I think anybody in the audience that’s a parent would know that people of college age do not believe what their elders tell them.

### Moderator
Claim: Oh, so it may not be relevant.

### Moderator
Claim: It may not be relevant.

### Moderator
Claim: All right. Well, we'll see. Let's-- let's see what we hear from our debaters, and let's welcome them all to the stage. And thank you, Bob Rosenkranz.

### Moderator
Claim: Thank you.

### Moderator
Claim: Oh, I'm sorry. He was meant to shake your hand, so I'm going to do it. Come on in.

### Moderator
Claim: Thank you.

### Moderator
Claim: Hi. See what happens when we get out of New York?

We lose all the cues. All right. Yeah. Okay. So one more time to remind you that we're-- we're going to go for about an hour and a half. And we ultimately turn into an hour- long radio broadcast and podcast. And hearing from you is critical, so that-- this is not like a presidential debate. We absolutely are delighted to hear your response to the things you're hearing. It's fine to applaud points you like or to chuckle at jokes you like. We discourage hissing and booing, and we really do discourage hissing and booing. We want to keep it in a positive way. But that does not mean that you have to remain silent throughout. And in a way, it helps the debaters know how they're doing, and it totally helps the people at home know that you're here. So, we're going to launch now. And to do that, I'd like to ask for one more round of your spontaneous applause to get us launched.

I'm John Donvan. This is Intelligence Squared U.S. It happened to the director of the CIA, it happened to the head of the International Monetary Fund. It happened to comedian Bill Maher. All of these people within the past few years, and several others, were offered honorary degrees or chances to speak at universities and then protesters from the left demanded that those offers be rescinded and the speeches canceled. And in some cases, that actually did happen. And what was that? Was that censorship, or was that the left also exercising its right of free expression? And are conservatives, when given the chance, going to do exactly the same thing? Well, that sounds like the makings of a debate. So let's have it, "Yes," or, "No," to this statement, "Liberals Are Stifling Intellectual Diversity on Campus," a debate from Intelligence Squared U.S.

I'm John Donvan. We are at George Washington University in Washington, D.C. We have four superbly qualified debaters, two against two, arguing for and against this motion, "Liberals Are Stifling Intellectual Diversity on Campus." As always, our debate will go in three rounds, and then our live audience here at the Jack Morton Auditorium will vote to choose the winner, and only one side wins. Let's meet our debaters. Our motion is this, "Liberals Are Stifling Intellectual Diversity on Campus," and here to argue in support of that motion, please welcome Greg Lukianoff.

Greg, welcome. And you are president of the Foundation for Individual Rights and Education, that is FIRE, and you were the inaugural recipient of the Playboy Foundation's Freedom of Expression Award. The Wall Street Journal described you as "born to fight college censorship" in part because of, quote, "your unruly red hair," FIRE again.

But my question is this. You know, it's--for those who are listening who can't see your hair, how are they going to know how fiery you are?

### Conspiracy Advocate (CA)
Claim: I--it's funny. I actually think of myself as fairly mild-mannered. I mean, besides free speech, which I do get very worked up about, I mostly only get worked about how bad the "Star Wars" prequels were, the canceling of "Firefly," and, of course, that people really don't appreciate Beyoncé enough.

### Moderator
Claim: All right, thank you, Greg Lukianoff. And tell us, who are you debating side-by-side-- who's your partner?

### Conspiracy Advocate (CA)
Claim: The fabulous Kirsten Powers.

### Moderator
Claim: Ladies and gentlemen, Kirsten Powers.

Kirsten, you are also arguing for the motion, "Liberals Are Stifling Diversity on Campus." You began your career in the Clinton administration. You became a deputy assistant U.S. trade representative. You served as a consultant to the New York State Democratic Party. But you have a book coming out now, "The Silencing: How the Left Is Killing Free Speech," and you're on Fox News.

So, our question is, do your friends from the old days still talk to you anymore?

### Conspiracy Advocate (CA)
Claim: They do. They call me up usually to tell me they saw me--you know, cheer me on for brawling with Bill O'Reilly. And they always claim that they accidentally saw Fox News when they were flipping through the channels.

### Moderator
Claim: Yeah, of course it was an accident. All right, that's our team arguing for the motion, "Liberals Are Stifling Intellectual Diversity on Campus."

And we also have a team arguing against the motion, two debaters, first, please, let's welcome Angus Johnston.

Angus, you founded the website, studentactivism.net. You are--you're an historian of student activism and student life. You teach at the City University of New York. You yourself were an activist as an undergraduate. You took part in sit-ins and in demonstrations. In your own words, you yelled and screamed plenty of times and you even got arrested once for something like really exciting.

### Scientific Advocate (SA)
Claim: Actually, I was sitting quietly in a student lounge discussing blood donation policy.

### Moderator
Claim: Oh, you were--that was radical.

Angus Johnston, thanks very much. And who is your partner?

### Scientific Advocate (SA)
Claim: The incredibly erudite Jeremy Mayer.

### Moderator
Claim: Ladies and gentlemen, Jeremy Mayer.

Jeremy, you are also arguing against this motion that "Liberals Are Stifling Intellectual Diversity on Campus." You are an associate professor at George Mason University. You are coauthor of the book, "Closed Minds? Politics and Ideology in American Universities." A New York Times article cited your book's findings, and in it you are quoted as saying that, "When it comes to shaping a young person's political views," quote, "professors are among the least influential." So, as a college professor, how does that make you feel?

### Scientific Advocate (SA)
Claim: Hey, it makes me feel pretty good. A college professor should not tell you what to think. He should give you-- he or she should give you the tools to think for yourself.

### Moderator
Claim: And debaters as well. All right, ladies and gentlemen, that's the team arguing against the motion.

Now, this is a debate. It's a contest.

It's a clash of ideas, and you, our live audience at the Jack Morton Auditorium, will be serving as our judges. By the time this debate has ended, you will have been asked to vote twice, once before you've heard the arguments and once again after you've heard the arguments. And the teams whose numbers have moved the most in percentage point terms will be declared our winner. It's the difference between the two votes. Let's get the first vote registered. If you go to those keypads at your seat, you'll see a set of numbers. Just pay attention to one, two, and three. Those are the only ones that are active. Look at the motion, "Liberals Are Stifling Intellectual Diversity on Campus." If you agree with this motion, push number one. And if you disagree, push number two. If you're undecided, push number three. If you made a mistake, just correct yourself and the system will lock in your last vote. The other keys are not live. And we'll lock it out in just a second while I pick up this piece of paper. I'll pretend I didn't drop it. Excuse me.

That did not happen. All right. So, remember how you voted.

We've locked it out. Remember how you voted. We're going to ask you to vote after you've heard the arguments, and again, it's the team whose numbers have changed the most in percentage point terms who will be declared our winner. Onto Round 1. Our motion is this: Liberals Are Stifling Intellectual Diversity On Campus. Opening rounds. Opening statements in the opening round are six minutes each. And here to make his opening statement in support of the motion, Greg Lukianoff. He is president of the Foundation for Individual Rights in Education and he was the inaugural recipient of the Playboy Foundation's Freedom of Expression award. Ladies and gentlemen, please welcome Greg Lukianoff.

### Conspiracy Advocate (CA)
Claim: Let me start by whisking you back to a magical time-- 2001. A conservative would have dismissed me as a liberal cliché. I was a floppy-haired, Burning Man regular, San Francisc-ite who turned down big law salaries to work for social justice.

I had worked in refugee camps in Eastern Europe, for an environmental justice mentoring program in D.C., and for the ACLU of Northern California. And most of all, I loved the First Amendment, the quintessential liberal cause-- or so I thought. 2001 was also the year I started working at FIRE, which proudly defends speech and academic freedom for speakers of any political stripe. As soon as I started at FIRE, however, I was inundated with hundreds of pleas for help. It wasn't long before I learned this unfortunate truth: if you're going to be censored on the modern college campus for your opinion, chances are you're going to be censored by the Left. And this is what we mean by the Left, and most Americans mean when we say "Liberal" these days, either people on the left side of the political spectrum or people who self-identify as liberals, and people to their left. I have been-- I have seen so many crazy examples of politically- correct censorship.

A student at Indiana punished just for publicly reading a book, a sorority sister forced to publicly repent for insensitivity for a Taco Tuesday event, and Yale students banned from calling Harvard students "sissies" on a t-shirt, which was a quote from F. Scott Fitzgerald by the way. This is heartbreaking to me and my teammate, since both of us consider ourselves liberals. Of course there are many, quote, good liberals out there who still support free speech, both on and off campus. These include former ACLU President Nadine Strossen, The Nation's Michelle Goldberg, renowned First Amendment attorney Floyd Abrams, and many more. But one thing all of these liberals have in common is that they also believe that the campus liberals have become distressingly intolerant of dissent. Take any hot topic in America today and I can point you to examples of students and faculty members getting in trouble for being on the conservative side of the issue. Take abortion. While FIRE has proudly supported the free speech rights of pro-choice students, we are far more likely to have to come to the defense of pro-life students. How bad is it? At Northern Kentucky University, a professor actually led her students to destroy a pro-life display.

The display was only dozens of little white crosses to protest Roe V. Wade. At Dartmouth, a similar pro-life display-- this time involving tiny American flags, was considered so offensive that another student ran it over with his car. That reckless censor-- have you any guess about what his politics were? He had a COEXIST sticker on the back of his car.

Or take immigration. At UCLA, a student group faced ferocious protest and a massive fine when they simply attempted to invite someone to come to campus to debate against their pro-immigration stance. And though I'm an atheist, I have been horrified by repeated attempts to censor campus evangelicals. Kirsten will tell you more about those cases. Last year, campus liberals made national headlines for demanding that speakers they did not like be disinvited from campuses across the country. This problem has been growing for years. According to extensive research by FIRE, if you're going to face a disinvitation push arising from campus, it's about three times as likely it's going to come from your left.

This is especially shocking when you consider how rare it is for a conservative to be invited in the first place. Last year's commencement season saw 25 Democratic political figures speech-- speak at the commencements of 60 of America's top universities. And how many Republicans were invited to speak? Zero. And this statistic comes from Nate Silver's decidedly non-conservative FiveThirtyEight website. Some conservatives were invited to talk at universities outside the top 60, including Rutgers. However, even there former Secretary of State Condoleezza Rice bowed out after months of pressure from faculty and students. Even mild satire from conservatives isn't tolerated. Take the case of Omar Mahmoud, a Muslim conservative at the University of Michigan. When this past December, he wrote a satirical column poking fun at micro aggressions and privilege theory-- very mild. He was not only fired from the student newspaper, but his dorm room door was vandalized. This prompted famous liberal writer Jonathan Chait to criticize the rise of a new wave of political correctness.

If Angus and Jeremy concede that there is a problem with free speech on campus, they may blame the massive corporatized modern university. And on this we agree. Much of the censorship does come from out-of-control administrators. However, we must understand that liberals so thoroughly dominate the current academy, as Kirsten will show, that if they were serious about freedom of speech on campus, this kind of administrative outer-- overreach would not be possible despite liberal dominance on campus or maybe because of it. 55 percent of over 400 colleges surveyed last year maintain wildly unconstitutional speech codes while only 4 percent maintain codes that fully meet First Amendment standards. And this in spite of nearly three dozen lawsuits against politically correct speech codes since 1989, successful lawsuits. And we can't forget that the tools that are most often to silence dissent on campus are the brain children of professors, including Katherine McKinnon, Mary Matsuda and Richard Delgado, all of whom were liberal leaders of the speech code movement in the 1980s.

Though it gives me no joy to say it, you must vote in favor of the motion, yes, liberals do stifle intellectual diversity on campus. Thank you.

### Moderator
Claim: Thank you, Greg Lukianoff.

And that is our motion: Liberals are Stifling Intellectual Diversity on Campus. And here to argue against this motion, Jeremy Mayer. He is an associate professor in the School of Policy, Government and International Affairs at George Mason University. Ladies and gentlemen, Jeremy Mayer.

### Scientific Advocate (SA)
Claim: Thank you. The picture that Greg drew is a common one. It is the conservative picture of the modern university. Perhaps best summarized by former Pennsylvania senator Rick Santorum who called universities "indoctrination mills." In this picture, we are-- higher education is infused with an overly liberal professoriate, biased classrooms and stifled campus debate.

If this picture is true, it is indeed very serious. If it is an accurate portrait of higher education in America, then we should all be alarmed, and we should all donate money to Greg's group. Is it, though? I will handle those first two, are professors liberal? And why? Is the classroom a biased place? And mostly leave the third to Angus. So, are professors liberal? Well, yes. When we did the research, a national random sample survey for our book, we found that 61 percent of college professors are left or liberal. But this is nothing new. The very first time we looked at college professors in a structured survey in 1933, we found almost the same number. So, it isn't like the '60s: radicals all went into faculty positions and moved young minds to the left. So, why-- what explains this? Well, the conservative explanation for the overwhelming liberal campus is simple: Conservatives are squeezed out of grad school, convinced that their ideas aren't worthy of a PhD.

And those few that escape this thought police then find it very hard to get a job because liberals discriminate and won’t hire conservatives. And then those few conservatives that get through this gauntlet are denied tenure by bitter liberal colleagues. This simply is not so. When we surveyed faculty members, 85 percent argued that ideology played no role in tenure in their department. And this was true of 87 percent of conservatives we surveyed, so-- of the very conservative. So, it is not the case that conservatives need not apply for jobs. Why aren't there more conservative professors to fight the good fight? Well, the first answer I’d give you is money. If you are someone who believes in the market uber alles, you might want to make more than $29.5k, which is what I made my first year as a young college professor in 1996.

If you work four years for a PhD like I did, you might think you deserve something better. That's what we got. So, I think the market keeps conservatives from wanting to be in the academy. I also think there's a pocketbook issue here. Professors depend on two sources of government for their income. One is those many professors like myself who work for state government. If conservatives win, you may not get a raise for four years. And a lot of professors also work on federal grants. The Republican party is not the Republican party of 1955, which was very supportive of higher education. It is a party that is devoted to cutting government spending. We aren't surprised when oil executives vote Republican. It's in their economic interest. The same is true for college professors. We also have seen the conservative movement have a hostility to science which it didn't have 40 years ago. So, in our survey, we found, contrary to earlier ones, that natural science professors were moving to the left.

Well, if a party attacks evolution, you're going to lose a lot of natural and social scientists because we happen to believe in the scientific method. It's good politics for Republicans. I give them that. There's a lot more people who think the world was created in seven days than people with PhDs. So it's a good move, but it hurts them on college campuses. There's also another thing that we found is conservatives on college campuses are pretty much like other professors. They're also very, very pro gay rights. While one party has embraced that social movement, the other party is fairly fervently against it. So, that is again moving professors away from any tendencies to be Republican or conservative. Finally, an anti-intellectualism is occupying certain wings of the Republican party. It used to be that that was more the Democrats that were anti- intellectual. Anyone remember George Curly Wallace? When George Wallace ran for president as an Independent after being a Democrat, he almost got no faculties’ support-- in '68.

The inheritors of the Wallace movement today are in the Republican party. It is that kind of anti-intellectualism that turns off college professors. So, I don't think that college professors are becoming liberal out of a viewpoint discrimination. Is the classroom biased against conservatives? I would argue no, that if you ask students, do you feel that your viewpoints aren't welcome on your college campus? In survey after survey, the majority of students say no. So, I think this portrait of an overly liberal campus can be discredited with Greg's own research, that in his work where he identified the 12 worst campuses in 2013, and he said, "These are examples of liberal viewpoint discrimination, conservatives being squelched." Well, in fact, of the 12, three were nonpolitical, entirely conservative, small “c” conservative administrators just saying, “Oh, I don't want people talking about sex on my campus.

We might lose donations.” Three of them were conservatives squelching liberals. And finally, there were four of the classic where liberals were being-- were squelching conservatives. There is a place in this very city where I would not be allowed to speak on any topic at all. It's Catholic University. Catholic University, like many conservative campuses, is very explicit about not allowing liberals to speak. I'm not exactly a liberal, but I am pro choice. Catholic University has an official policy: No one who has ever publicly advocated for the right to abortion is allowed to speak.

Yep.

Thank you.

### Moderator
Claim: Jeremy Mayer, I'm sorry, your time is up.

### Scientific Advocate (SA)
Claim: Yep.

### Moderator
Claim: Thank you very much.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate where our motion is “Liberals are Stifling Intellectual Diversity on Campus.” You've heard the first two debaters, and now onto the third. Let's welcome to the lecturn Kirsten Powers.

She is a columnist for USA Today and the Daily Beast, a network contributor on the FOX News Channel, where she is also a panelist on the program, "Outnumbered." Ladies and gentlemen, Kirsten Powers.

### Conspiracy Advocate (CA)
Claim: Thank you. Thanks to Intelligence Squared for doing a debate on such an important topic. And I'm always happy to be anywhere where Bill O'Reilly can't interrupt me, so I'm happy to be here. Our opponents are telling you that liberals are not stifling intellectual diversity on campuses. Sadly, this could not be further from the truth. A perfect example of this is a 2013 case that happened at the University of Alaska, Fairbanks, where I'm from. My parents were professors there. A feminist professor filed multiple sexual harassment complaints against the student university-- the campus university there-- because of an April Fool’s Day issue of an article that was mildly mocking feminism. The professor filed another complaint after the newspaper published an article that was critical of hate speech.

The university's repeated investigations dragged on for almost nine months and-- and it only really ended when FIRE had intervened and informed them they were violating the First Amendment. Ironically, the editor-in-chief, who wrote this article, was herself a feminist and thought she was doing a very mild, mocking, April Fool’s Day story. And she told FIRE that the chilling investigation that was launched by the University of Alaska prevented her from publishing stories on important issues, including sexual assault. Recently, at Milwaukee's Marquette University, a political science professor there, John McAdams, blogged about an exchange where a Marquette philosophy professor had told a student that debating gay marriage in class was, quote, "not appropriate and homophobic."For this, Marquette suspended the professor, McAdams, who blogged about it, banned him from campus, and they are now in the process of trying to revoke his tenure. Greg and I both support gay marriage, but this is an extremely chilling way for Marquette to handle this issue. As Jeremy acknowledged, the decks are stacked against those who express non-liberal views on campuses. And I would just point out, to the point that campuses have always been liberal, liberals are very-- liberals-- the liberals in the past actually supported free speech, and I think that would be the big difference of today, is that the liberals that we're talking about today are enacting very hostile policies against free speech. And so there's a big difference. They may be voting for the same people, but they are behaving in a very different way. And many studies will back up the fact that there are vastly more liberals on campuses. There was one study that found that 72 percent of college professors identify as liberal, while only 15 percent identify as conservative.

It's gotten so bad that several prominent social psychologists have written an article recently arguing that the field of psychology is being badly hurt by the lack of political diversity. One of the papers-- and, by the way, none of them are conservatives who wrote this-- one of the paper's authors is NYU Professor Jonathan Haidt. At a 2011 social psychologist symposium, he asked the audience to show hands for their political leanings. Out of a thousand people only three raised their hands to say that they were conservative. And Haidt points out that, of course, there were more conservatives in the audience-- that can't be the actual ratio-- but they were too afraid to identify themselves, which speaks for itself. He explained that this gross political and ideological disparity is evidence of a, quote, "tribal moral community that actively discourages conservatives from entering."He explained that there were-- in preparing for his speech, he wanted to talk to some non-liberal graduate students. He was able to only identify two in the-- of social psychology graduate students, and that he said that he-- they reminded him of closeted gays from the 1980s. And he referred to them as "closeted conservatives" because they were-- they felt that they were forced to hide their identities and-- from their colleagues and from their professors, and it really affected the research that they did. And so Haidt argued that more ideological diversity would lead to, quote, "better science and freer thinking." The ideological slant, it's not just a passive preference. During the 2012 election, 96 percent, which is almost 100 percent as we all know, of political contributions from Ivy League faculty and staff went to the Obama campaign. And during the 2004 election, professors donated $19 to John Kerry's campaign for every dollar that went to George Bush.

And as sociologist Neil Gross has pointed out, our colleges and our universities are one- party campuses. Last year at the University of California at Santa Barbara, one of the worst cases probably that we'll talk about tonight, a feminist professor's study-- she was found guilty of grand theft, vandalism, and battery after a physical altercation in which she stole and destroyed a 16-year-old pro-life demonstrator's sign. The professor claimed she was triggered by the poster's graphic images, called the demonstrators "terrorists," and told police she had a moral right to her behavior and was just setting a good example. She still has a job and was basically defended by scores of professors. We've also seen discrimination against Christian groups on campuses – it’s getting much worse at Vanderbilt. Fourteen campus groups lost their organizational status in 2012 because they wanted to choose their own leaders based on religious belief.

And there are just many more campus fellowship groups from University of-- State University of New York or the Cal State system who've lost-- have been driven off campus. And, you know, Harvard Professor and former Obama administration appointee Cass Sunstein has warned that when a group becomes ideologically homogenous, it tends to drift farther and farther in that direction and become more hostile to outsiders.

But it's reason

Yep.

### Moderator
Claim: Kirsten Powers, I'm sorry, your--

### Conspiracy Advocate (CA)
Claim: But it's reason

### Moderator
Claim: --your time is up.

### Conspiracy Advocate (CA)
Claim: Yep.

### Moderator
Claim: Okay, thank you very much, Kirsten Powers.

And our motion is, "Liberals Are Stifling Intellectual Diversity on Campus." And here to argue against this motion in his opening statement, Angus Johnston. He teaches history at City University of New York and is founder of the website, studentactivisim.net. Ladies and gentlemen, Angus Johnston.

### Scientific Advocate (SA)
Claim: Thank you. My adversaries have made some really cogent points this evening, and so as an actual campus Leftist, I look forward to denouncing them as bigots.

But before I do that, I'd like to take a step back and talk a little bit about the campus.

What the actual, average American campus is like today. The American campus today, as it has been in the past, is a site of robust and passionate debate. And that's true not only because it's a place of learning, but also because it is a haven for young people. And the reality is that most of us, at some point in our lives, give up on debating people we profoundly disagree with. We decide that it's too hard, it's too uncomfortable, it doesn't usually work. And so, we give up. But college students haven't given up yet. And so, they argue, incessantly and angrily. But here's the thing. In my experience, on campuses across the country-- and this is backed up by my opponent's own data-- where free speech is curtailed on campus, it's overwhelmingly not by students or campus liberals, but by administrators who are motivated not by ideology, but by opposition to disruptiveness and clamor.

A perfect example of this is a case that many critics of campus leftism and campus liberalism have talked about-- the case of Robert Birgeneau, the former chancellor of the University of California Berkeley, who, as Berkeley chancellor, presided over the arrests of dozens of peaceful, non-violent student protestors on multiple occasions, including one occasion in 2011, where students who were demonstrating peacefully were beaten viciously by campus police with batons. After he stepped down as Berkeley's chancellor, Birgeneau was invited to give a commencement address at Haverford College in Pennsylvania. And some Haverford students were understandably not so happy about this. So, what did they do? Did they burn down the building? Did they lock him out?

Did they beat him with batons? No. They did none of those things. What they did is write a letter. They wrote a long letter expressing their concerns in which they offered suggestions for how he could repair the harm that he had done to civil liberties at Berkley. And they urged-- that was their word-- "urged" him-- to-- as they put it, "confront the issues before you." If he didn't do that, they said, they would ask the college to withdraw his invitation, a request that they had no power to enforce. In a two-line reply, Birgeneau said that he would not respond to what he called their “violent verbal attacks." Period. He wouldn't meet with them. He wouldn't respond to the claims that they had made. He wouldn't debate them. And in fact, he wouldn't even come to their campus. He withdrew his decision to come and speak at their commencement.

Now, FIRE has written about this incident many times. Op-ed writers all over the country have written about this incident. And every time they do, Birgeneau-- an administrator who presided over the beating and arrest of student protestors-- is portrayed as a free speech martyr. Well, the students who had just wanted to talk to him about that-- are portrayed as his oppressors. And I say that that is absolutely wrong. I say that is absolutely backwards. Now, I'm not asking you to embrace every argument made by every member of the campus Left, because frankly, some of their arguments are really bad arguments. But speech that nobody opposes is not speech that needs protecting. And there's a recurring tactic that we see in critics of the campus Left in which students who are engaging in free speech are condemned as violent or condemned as censors.

And you know, hyperbole is free speech, whether it's the hyperbole of students calling a speaker who said something unfortunate a racist or the hyperbole of an administrator calling a polite letter a violent attack. Demonizing your opponents is free speech. But so is refusing to demonize them. And that's what I'm asking you to do today. I want you to vote against this motion, because it's not liberals who are stifling free speech on the American campus, but bureaucrats. Bureaucrats who are scared by the rowdy, messy vitality of the marketplace of ideals-- ideas. So, what I'm asking you to do here is to stand up for free speech on campus-- the freedom of speech of the Left and the Right and the Center by voting against this ill-conceived and prejudicial motion. And I'd just like to close by saying one thing.

A few days ago we lost a champion of speech and debate and dialogue in this country, David Carr, who wrote for the New York Times. And on the stage at the Intelligence Squared debates a couple years ago, he said something that I would just like to quote to you now. He said, "I urge you to vote against, against, against this motion which is per se dumb." Thank you.

### Moderator
Claim: Thank you, Angus Johnston.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is Liberals are Stifling Intellectual Diversity on Campus. They're all wearing black so that you don't see this happening.

It's working, right? Yeah? Okay, round of applause for these guys.

Thank you.

Our motion is Liberals are Stifling Intellectual Diversity on Campus. Now we move on to round two. Round two is where the debaters address one another directly and take questions from me and from you and our live audience here at George Washington University. The team arguing for this motion, Kirsten Powers and Greg Lukianoff, we've heard them argue that socially conservative views are the ones that are most being suppressed on America's campuses, that they are the-- the censorship is three times as more likely to come from the left. They say is that the decks are stacked because the high rate of liberal representation in faculty and administration, and they were the ones who drew up the speech codes that are affecting speech. That's certain groups in particular, not just politically conservative groups, but Evangelical groups also are having their views suppressed through a sort of social pressure as well as enforcement of these speech codes that are aimed to silence them.

The side arguing against the motion, Angus Johnston and Jeremy Mayer, they're risking a rather nuanced response to this. They're conceding that in fact the campuses are by and large overwhelmingly liberal in terms of their faculty makeup. 61 percent, they cite. But they also are making the argument that conservatives also, when they have the opportunity, on campuses that are overwhelmingly conservative, also try to suppress speech. They make the strong argument that criticism in itself is not censorship that the tilt towards liberal faculty has to do with self-selection among conservatives. They don't particularly want to go work in these places and that, by and large, there are debates still on campuses. There's just not that much stifling going on altogether. I want to take this question to the side arguing against the motion, to Angus Johnston and Jeremy Mayer.

Your opponents are saying that-- let's talk about speech codes, and I think we all know what those are, certain rules enforced on some campuses that there are certain topics that cannot be discussed, and certainly, certain words, formulations in language that cannot be used. And your opponents are making the argument against your argument that this is a big corporate thing, that it's affecting both sides, that the roots of these speech codes, their actual content was drawn up-- were drawn up by liberals to satisfy their political agendas, and their sensibilities, and they've stayed in place. And therefore, that-- they feel nails their argument that it's a liberal dominance over conservative thought because of who got to write up these codes in the first place. Which one would like to take it? Angus Johnston?

### Scientific Advocate (SA)
Claim: Yeah. I think there are a few things that need to be said in response to that. First is, the folks who draw up these speech codes are not intending to impose ideological conformity.

### Moderator
Claim: I just want to say, I know that I asked the question--

### Scientific Advocate (SA)
Claim: Oh, yeah, sorry.

### Moderator
Claim: You need to persuade these people.

### Scientific Advocate (SA)
Claim: I will do that. That's right, you are-- you are my actual audience as well as "the" audience. So, okay, so the folks who have drawn up these speech codes are for the most part not intending to impose ideological conformity.

They are trying to keep trustees happy, they are trying to keep alumni happy. They are trying to avoid having parents feel like their kids who they think of as still children are living in a den of iniquity. And so there is certainly a tremendous amount of pressure from the top to keep things calm on the campus. But that's a very different thing than an attempt to impose ideological conformity. And in fact, in the 2015 speech code report that Fire just produced, they cite that the setting aside speech codes which are not currently being enforced, they cite 15 examples of freedom of speech violations and 12 of those are nonideological, things like people getting-- students getting written up for passing out constitutions on campus.

That's not anti- conservative.

### Moderator
Claim: Let's let--

### Scientific Advocate (SA)
Claim: --that’s anti-free speech.

### Moderator
Claim: --your opponents respond to it. Who would like to take that?

### Conspiracy Advocate (CA)
Claim: I'll-- I think I can start with that.

### Moderator
Claim: Greg Lukianoff.

### Conspiracy Advocate (CA)
Claim: I mean, it was interesting to have your own research sort of cited, because when we watch how these codes are written, you know, as I said, they came from liberal thinkers, they came from the Catherine MacKinnons. They are used disproportionally against conservative points of view consistently. And the idea that, yes, absolutely, administrators are largely the big problem, and they have been, and I'd be willing to say that. But the administrators themselves lean overwhelmingly left. It's 96 percent donations to the Obama campaign came from--when you take staff and faculty together. So, they're using the same tools. And just-- and I really have to say, the-- I have seen genuinely heartbreaking case of things that you should never do to people coming from administrators that are very much left.

There was the University of Wisconsin case where they were telling a student he couldn't have a Bible study meeting in his own room on his own time because people knew he was an Evangelical Christian. They might find that offensive. Again, I'm an atheist, but that's wrong.

### Moderator
Claim: All right. Let me just take-- I want to take this question back to Angus, because I don't feel that you satisfactorily responded to the point made that because the writers-- the initial writers were-- that they would themselves would reflect their own sensibilities and those have a legacy staying power. Your response was, the administration writes them. But you didn't actually address the issue of who got to write them in the first place and instill that legacy, if not the left, as your opponents are arguing. And there is a logic to. And so-- and so the law became the law, and the law was leftist.

### Scientific Advocate (SA)
Claim: Okay. Well, I think one of the things that we need to look at here is what are the circumstances in which students who are not conservatives, who are being caught up in these. And I think honestly, I think, yes, you can say that they were probably liberal in their political views, but they were centrist in their views about what is appropriate discussion and debate on campus.

And here's an example of it. There was a case recently where two students who were joking around with each other and one of them was white, and one of them was black, and one of them-- the white said to the black one, "Can I get a white power?" And this was a joke that they had between themselves. And neither one of them was offended by it. And they were both brought up on charges because the kind of humor that they were engaging was found offensive by the administration. Now, is that suppression of conservative speech? Is it suppression of liberal speech? No. It's just a jerk administrator being a jerk.

### Moderator
Claim: But it is political.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: Well, let's let Kirsten come in. Kirsten Powers.

### Conspiracy Advocate (CA)
Claim: The point isn't that it's always conservatives. I don't-- that's not actually our position. The position is that it has overwhelmingly been used against conservatives, but liberals absolutely are affected by it as well, and that's a good example of it by liberals. And, you know, what we're talking about is liberals stifling intellectual diversity. And that kind of behavior is extremely chilling.

So, if you're those students that you just described, and you're on a campus where you think you're going to get in trouble for a private conversation which we have a lot of-- you know the stories too. There are a lot of stories like this. You are going to be very careful about what you say. And that is going to stifle intellectual diversity if people feel like I can't say something. At Marquette University, there was another case where-- in their training of the professors, they had a slide that said to the professors-- it was an example of something that they might have to respond to. Two students are talking. They oppose same-sex marriage. They're talking about how they oppose same-sex marriage. A third student overhears them and reports them to the administration. They were told this was the proper handling of this incident. They're turning-- they're turning students into informants on each other for having a conversation. And what even the conversation had become very heated and even they said things that were bigoted?

I mean, people are supposed to, on campuses, be able to debate things and say offensive things. And in that case, it's not even offensive.

### Moderator
Claim: Jeremy Mayer.

### Scientific Advocate (SA)
Claim: I couldn't agree with you more. And I was meeting with some of the students who are here in the audience before this began, and they were Libertarians. And I said, "Have you been stifled on campus?" And one of them from James Madison said, "Yes, because James Madison has a policy that you cannot as a student group have anything about drugs or alcohol on your posters. And we wanted to have a debate about drug legalization, and we felt clamped down." Well, trust me, that is not a liberal policy. That is your generation of young people have been wrapped in bubble wrap all your lives. And when I was in college, if they'd even tried to do that, liberals, conservatives, moderates and the crew team would have been out there fighting this. So, it is--

### Moderator
Claim: You really know how to compliment your audience.

### Scientific Advocate (SA)
Claim: It is what Angus said is that it is conservative, small C, administrators who don't want trouble with donors and press, it is not liberals.

Liberals don't like bans on what can appear on student posters any more than you do.

### Conspiracy Advocate (CA)
Claim: Are you saying administrators are conservative?

### Scientific Advocate (SA)
Claim: Am I saying administrators?

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: No, small C conservatives, in other words, conservative in the sense of cautious.

### Conspiracy Advocate (CA)
Claim: Okay, but we're talking about big C and big L here, so, I mean, they're liberals. I mean, the data overwhelmingly shows the--

### Scientific Advocate (SA)
Claim: Okay, but-- okay, so--

### Moderator
Claim: Angus Johnston.

### Scientific Advocate (SA)
Claim: --thank you. So, I think that--

### Moderator
Claim: I do that so that the--

### Scientific Advocate (SA)
Claim: --oh, so the-- right.

### Moderator
Claim: --that folks listening know who's talking.

### Scientific Advocate (SA)
Claim: Oh.

### Moderator
Claim: So, you can ignore me most of the time when I do that.

Angus Johnston.

### Scientific Advocate (SA)
Claim: Where was I?

Are most administrators liberal? Absolutely. Are most-- is most of the suppression of speech that occurs on campuses directed at conservatives? Absolutely not. The majority of the suppression of speech that occurs on campuses is non-ideological.

It is not directed at conservatives or liberals. And I'd also like to take this conversation a slightly different direction, if I may, and say the most-- the most chilling examples of suppression of free expression occur when students are beaten and when they are arrested for engaging in free speech. And the students who are on the receiving end of that are overwhelmingly liberal and left students.

### Conspiracy Advocate (CA)
Claim: And--

### Moderator
Claim: Greg Lukianoff.

### Conspiracy Advocate (CA)
Claim: --there's something really important that I want to say, is that we're talking about how, you know, Jeremy was talking about the consistency of liberals. And the kind of liberal that I grew up with and was one that adamantly believed in freedom of speech. And Angus is good on freedom of speech, and we have a lot of cases on which we agree, but if the administration-- which overwhelmingly leans left-- if modern liberals were as good on free speech as the old '60s and '70s liberals were, as me and Angus are on these issues, these administrative overreach things, as I said in my statement, would be impossible. Sometimes it's active, sometimes it's just complicit, but it's allowing the stifling of intellectual diversity.

### Scientific Advocate (SA)
Claim: But you don't ever complain about the real stifling of intellectual diversity, which happens at hundreds of campuses across this country that are conservative, and explicitly--

### Conspiracy Advocate (CA)
Claim: Oh, yes, we do.

### Scientific Advocate (SA)
Claim: --no, I've read-- you have this whole statement on your website that says, "We will not take on Liberty University, and stop asking us to--

### Conspiracy Advocate (CA)
Claim: Oh, Liberty, yeah.

### Scientific Advocate (SA)
Claim: --because they are open about their stifling, so it's okay.

### Conspiracy Advocate (CA)
Claim: Yeah, so--

### Scientific Advocate (SA)
Claim: I'm sorry. If you care about free speech, care about the kids at Liberty, care about the kids at Catholic, care about the kids at BYU, care about the BYU professor who was fired for saying he was in favor of gay marriage.

### Conspiracy Advocate (CA)
Claim: --we have taken on religious university after religious university, but I like how people kind of play dumb on this particular issue, where it's kind of-- Liberty University makes you sign a contract saying you essentially give up all your rights at the door. What are we supposed to argue, that you don't know-- or that you don't know that you're going to BYU and suddenly you're like, "Oh, my God, it's Mormon. It's super Mormon."

You have the right to give up some free-- to agree to that.

I would never attend any of these schools. But I want to point out we take on religious schools all the time and for that matter we're coming out with a list of worst schools for freedom of speech. One of the schools that we're going to be listing-- and I'll-- and you'll have to wait to see why-- is Georgetown University, a Catholic university in D.C. Wait a week to see the article, but, yes, we take on religious schools all the time. But, yes, if you tell people, you give up your rights on the door and you agree to that, then you have the right to do that. Meanwhile, at Yale and Harvard and Princeton, the big schools that people would mean when they're talking about higher education, they all promise free speech to high heaven, and they should be held to those promises.

### Scientific Advocate (SA)
Claim: But when Harvard had a civility--

--when Harvard tried to put a civility contract-- which I didn't agree with-- you guys were very angry. So, when Harvard's open about it, you guys nail them, but when Liberty is--

### Conspiracy Advocate (CA)
Claim: Basically what we said is if they want to go to their donors and go to their students and say, "Sorry, you know those glowing promises of free speech that we make? Eh, we don't really mean them. We're going with the civility idea," they are actually free to do that.

And I-- and, you know, it'd be interesting to watch them try it, but they would start losing those professors and those donors in a heartbeat. But they absolutely are free to do that.

### Scientific Advocate (SA)
Claim: But they weren't keeping it a secret.

### Moderator
Claim: Angus Johnston, do you want to jump in?

### Scientific Advocate (SA)
Claim: Well, I think that-- I absolutely respect the position that you all take on this issue of saying that these conservative campuses are in another category, these particular ones are in another category, and as a matter of law and as a matter of their legal right to repress free speech, yes, they have the right under the Constitution of the United States, but I think it's also important to note that they are repressing free speech. And it's also really important to note that, no, you don't go, "Oh, my God, BYU is really, really Mormon," when you arrive, but you might go, "Oh, my God, I'm gay." And so the repression that students are facing in these campuses is real, and I think you and I agree on that. I think that the disagreement is you don't think that that's something for FIRE to take on. I suspect that personally you find it as repugnant as I do.

### Moderator
Claim: Let me move this along a little bit further to a slightly different topic, although we've circled around it. And that is speech codes. And I just want to ask the side arguing for the motion-- that Liberals Are Stifling Intellectual Diversity On Campus-- having made the argument that speech codes have been constructed by liberals, and therefore, that's a leg of your argument-- do you believe that there's a role for speech codes, period? Is there speech that does need to be suppressed--

### Conspiracy Advocate (CA)
Claim: No.

### Moderator
Claim: On a campus--

### Conspiracy Advocate (CA)
Claim: No. And no-- there is no role for speech codes. And I think especially on a campus. A campus is-- we hear a lot about how campuses are now supposed to be these safe spaces. They should be physically safe. But they should be places that you go and you feel challenged. And you might feel angry, and you might feel upset, and you might read things and hear things that are-- that are intellectually diverse, and that you would actually encounter people who think differently than you. And I think that a speech code just creates an extremely chilling environment-- especially because these speech codes are so arbitrary. So, there-- it's left to the administrators to decide what violates the speech code. And it's-- they're too-- they're overly broad.

And they are sort of disproportionately used, I think, against--

### Moderator
Claim: And--

### Conspiracy Advocate (CA)
Claim: --people who are expressing so-called wrong views.

### Moderator
Claim: And is there an obligation of civility?

### Conspiracy Advocate (CA)
Claim: Civility to a point, but I think that that is overstressed, honestly. I think that it should be robust debate in people. It should be a place where students are allowed to make mistakes, you know, to say something that is offensive.

### Moderator
Claim: I'm guessing you agree--

### Scientific Advocate (SA)
Claim: I couldn't agree more.

### Moderator
Claim: --with this.

### Scientific Advocate (SA)
Claim: I couldn't agree more.

### Moderator
Claim: I think the speech codes are wrong. And I don't-- I wouldn't support them. I just don't think they're part of a liberal ideology crushing conservatism. And I also agree that speech can be painful and should be painful on a college campus. One of FIRE's cases is when conservative students hold out an affirmative action bake sale. And they price the goods at different prices so black kids can buy them up at 25 cents, but white kids have to pay $2. And it's a graphic representation of white resentment of affirmative action. And it really makes some black students very, very angry.

But I would, as a liberal-- side today-- fiercely defend the right of conservative students to do that, even if I would think it violates civility, by inflicting that kind of pain. But that's what a college campus must do, is be open to those kinds of debates.

### Moderator
Claim: Greg, can you hang on one second? I just want to say, after Greg's response-- and maybe a little bit more back and forth-- I want to go to you for questions. And just remind you again how it will work. Just raise your hand, stand up. Tell us your name. First name is fine. If you're with a media organization or blog, we'd appreciate knowing it. And wait until the mic reaches you so that you can be heard clearly. And really, try to keep it on topic and keep it terse. Thanks very much. Greg Lukianoff.

### Conspiracy Advocate (CA)
Claim: Just a simple sort of basic philosophical point. John Stuart Mill, in his wonderful 1859 book "On Liberty," talks about civility. And this is why you should always be concerned about calls for civility. He points out that civility ends up getting defined by the people who are in charge. And you'll notice that when people argue for civility, they tend to actually believe that whatever they say is civil. And if they're angry about it, it's righteous rage.

But if you say it and it's kind of sharp or mean, then it's incivil And this-- this is the one of the reasons why it is a problem that you have this incredible sort of liberal dominance on campus, is that you end up actually seeing, in some cases, what your point of view is as a-- and anybody opposing as being fundamentally uncivil. And sometimes, disagreement-- to be productive-- can't be all that civil.

### Moderator
Claim: Would you like to respond? And then I'll go to questions after that.

### Scientific Advocate (SA)
Claim: I think that is something that flows in both directions. A perfect example is an op-ed that was written by Wendy Kaminer just a few days ago, where she described participating in an event which was sponsored by a campus, in which they were talking about free speech and racial slurs. And she used the word-- which I will refer to as the N word-- three times, and not only did she do that, she also, in using the word-- N word-- and please don't do this-- she said, "When I use the word-- when I say the N word, what word comes into your mind," soliciting the audience to say back the slur.

And she was criticized for this. Which I think is reasonable, because I think that's a messed up thing for her to do. Does she have a right to do it? Absolutely. But is it right for other people to say, "Wow, that was really kind of gross?" Yes. Here's the thing. In her op-ed, she used the word censorship three times to describe her critics. Nobody made an attempt to censor her. Nobody--

### Scientific Advocate (SA)
Claim: --made an attempt to fight.

### Conspiracy Advocate (CA)
Claim: No. That is absolutely not true.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: What--

### Conspiracy Advocate (CA)
Claim: She was censored in the transcript. Okay.

### Scientific Advocate (SA)
Claim: No-- no-- no--

### Conspiracy Advocate (CA)
Claim: So, part of the story that you're missing is that when the-- when the students reported this, not only did they put a trigger warning at the beginning of the transcript of her speech and they didn't just censor the N word. They did-- they put "expletive"-- they put, brackets, "N word." They also, when she referred to this as being crazy, they put brackets, "ableist slur" in there. I mean--

### Scientific Advocate (SA)
Claim: So, is it your opinion that a campus student newspaper doesn't have the right--

### Conspiracy Advocate (CA)
Claim: No, this wasn't a student newspaper. This was a transcript of the--

### Scientific Advocate (SA)
Claim: --no it was prepared by an individual student, a recent alum. It wasn't at a formal

### Conspiracy Advocate (CA)
Claim: They have the right to, but that's censorship.

### Scientific Advocate (SA)
Claim: How is it censorship?

### Conspiracy Advocate (CA)
Claim: They literally censored it. They literally took it out. How is that not censorship?

### Scientific Advocate (SA)
Claim: How is it censorship for an-- if it's not censorship for a private individual-- a private university to say, We are going to make these rules, how is it censorship-- well, let me just frame it this way: Was it censorship-- is it censorship if The Washington Post says, "We won't print the word 'nigger'"? Is that censorship?

### Conspiracy Advocate (CA)
Claim: I mean, they can choose to-- they can choose to do that.

### Scientific Advocate (SA)
Claim: Is that censorship?

### Conspiracy Advocate (CA)
Claim: I would say yeah.

### Scientific Advocate (SA)
Claim: I don't consider that censorship. I consider that a private institution

### Moderator
Claim: I think you probably just got bleeped on NPR.

### Conspiracy Advocate (CA)
Claim: Yeah, I--

### Moderator
Claim: I want to go to questions. And right there, sir, in the aisle. A mic's coming up the aisle from behind you.

### Moderator
Claim: Greetings. My name's Jeffrey Damic I'm a United States army veteran of over 10 years and a veteran of ground zero, and I'm also a former graduate student at Syracuse University which serves as a pretext to my question.

Before I get to the substance of my question, I wanted to--

### Moderator
Claim: I need you to go-- I need you to zoom into your question.

### Moderator
Claim: I'm sorry. I just want to thank the panel for extending me-- extending us here the courtesy of your time. And I wanted to thank you, Ms. Powers, because even though we disagree on many different policies--

### Moderator
Claim: Sir, I'm going to have to cut you off just because we need everybody to have questions. But that's--

### Moderator
Claim: So my question is this:

### Moderator
Claim: --much appreciated.

### Moderator
Claim: I currently have a Department of Justice office of civil rights complaint levied against Syracuse University for the consistent harassment, threats and abuse I received when I exercised my First Amendment rights and rights as a student and questioned the lack of forethought regarding Ground Zero politics mosque demonstration held on September 11, 2010. Tragically, my experience is not singular in nature.

### Moderator
Claim: Sir, I'm going to have to pass. And you guys can chat afterwards only because I really need a terse question.

### Moderator
Claim: Okay, my question is what advice would you give--

### Moderator
Claim: I-- I'm going to-- I'm going to have to pass here because I gave you three chances. Sir, down in front here, please. But have a chat afterwards. I don't mean to disrespect at all. Down front.

### Moderator
Claim: Hi. Thank you so much.

### Moderator
Claim: Do you mind standing up just for the camera? Thanks.

### Moderator
Claim: My name is Ilan I'm a lawyer here in Washington, D.C. My question is for Angus. Your proposition boils down to this notion that small C conservative administrators who are afraid of clamor, who are afraid of disruption on campus, and therefore it's not an ideological cause. But who is responsible for this potential clamor? Who is responsible for this potential disruption? Who is threatening to do--

### Scientific Advocate (SA)
Claim: Overwhelmingly liberal students.

### Moderator
Claim: Exactly. And so my question, isn't that the proposition? Don't we have to vote in favor of the proposition?

### Scientific Advocate (SA)
Claim: No-- liberal students are the victims of the--

### Moderator
Claim: From liberals, though.

### Conspiracy Advocate (CA)
Claim: But that's not our argument. We never argued it was just conservatives.

### Scientific Advocate (SA)
Claim: I guess I-- well, so I think the question is, if-- if the answer-- if the premise of this question is, if any time an administrator who is a liberal in their personal life is violating free speech rights of somebody else, then-- then the answer is that, yes that is a liberal, stifling intellectual diversity on campus.

But, any time a liberal-- any time a campus does anything, it's usually liberals doing it. And so the-- I think that the question of whether it is an ideological stifling of primarily conservatives, I think that that's the more interesting question.

### Conspiracy Advocate (CA)
Claim: And I should like to point out in--

### Scientific Advocate (SA)
Claim: The first example in Greg's excellent book is a student protesting a garage being built from an environmentalist perspective, saying why are we doing this? And the university president, I don't know if he's a liberal or a conservative. I know nothing about that president. But he went after that student in and egregious way. And I appreciate that Fire supported that guy because I'm glad somebody did. But it was not a conservative student standing up and saying, "Build more garages because burning carbon's good." It was a liberal student being punished for being stridently environmentalist.

### Conspiracy Advocate (CA)
Claim: I just-- I just-- I'm going to reiterate again that it is not our argument that it is only conservatives or even that it's-- that it's necessarily an ideological crusade, though it often is.

The point is intellectual diversity is being-- is being stifled and that-- and it does-- and when you-- when you do it to a liberal or whether you do it to a conservative or do it to an agnostic, it creates a culture of fear and makes it impossible for people to speak openly.

### Moderator
Claim: I'm curious also, are you saying that this stifling stems primarily or only from the administration.

### Conspiracy Advocate (CA)
Claim: No.

### Moderator
Claim: Or are you also talking about a social milieu that it's peer pressure as well?

### Conspiracy Advocate (CA)
Claim: Right. I think-- I mean, we haven't talked about a lot of cases where it actually doesn't have anything to do with the administrators. It has the-- the Kaminer, that was derived completely from students. In fact, the administrator that the president of Smith was there when it happened and-- and it really wasn't that much of an incident. It was something that came from students, and students who then started protesting and demanding, you know, that the president of Smith condemn this and all these other things. So, I think you see it with Bill Maher, same thing.

You know, it was a student-led revolt against him for his comments about Islam. These were, again, from the left. But it all has the same effect of making people feel that they can't-- they cannot say how they think because they don't know what kind of retribution

### Moderator
Claim: Angus Johnston.

### Scientific Advocate (SA)
Claim: I think it's pretty clear that Wendy Kaminer is not afraid of saying what she thinks because she said it in The Washington Post again.

### Conspiracy Advocate (CA)
Claim: called a racist

### Scientific Advocate (SA)
Claim: That's fine.

### Conspiracy Advocate (CA)
Claim: You even mis-rep-- you've done exactly what they did. You've misrepresented what she did. She was actually trying to explain free speech to people, and she was actually arguing against censorship on campuses, and she was trying to make the point, you know, that we actually can handle hearing certain words. Now, would I have done what she did? No, I don't think so. It was provocative. But for her to be tarred as a racist the way that she was and accused of making racist comments when you know perfectly well--

### Scientific Advocate (SA)
Claim: Is what?

### Conspiracy Advocate (CA)
Claim: --she did not say something racist. It's chilling.

### Scientific Advocate (SA)
Claim: But how-- wait a minute, wait a minute.

### Conspiracy Advocate (CA)
Claim: It's a mess to make people feel that they can't-- they can't criticize censorship in the way that she did.

### Scientific Advocate (SA)
Claim: I think that what you are left with then is saying that if something thinks that somebody is a racist, they shouldn't say so.

### Conspiracy Advocate (CA)
Claim: No, that's not what I said.

### Scientific Advocate (SA)
Claim: Because-- well--

### Conspiracy Advocate (CA)
Claim: But that's not what they did. You're saying that they said they was a racist. You know that's not what happened.

### Moderator
Claim: Wait, wait--

### Conspiracy Advocate (CA)
Claim: No. What happened-- what I mean is she was tarred-- I mean, yeah, they shouldn't say she is a racist. They can say, "We don't think she should have said that." That's not what happened.

### Moderator
Claim: Are you saying there are certain words that are silencing in their effect. "Racist" would be one of them.

### Conspiracy Advocate (CA)
Claim: I think the-- I think the reaction to what she did was-- has a silencing impact in the sense that it misrepresented in the same way I that you, frankly, misrepresented what she did. She was saying-- she was talking specifically about how they are trying to censor certain works of literature on campuses because of words that are offensive to people. And she was making the point that this is not something we should do.

### Moderator
Claim: Huckleberry Finn

### Conspiracy Advocate (CA)
Claim: Yeah, Huck Finn specifically. And then to have her now portray it as like the-- you know, like Bull Connor.

You know what I mean? It's not-- that people know what happened--

### Scientific Advocate (SA)
Claim: People will make mistakes and use the word "racist" inappropriately. I don't think she was a racist, but I fiercely would protect the right of people to call her racist. That's not censorship. That's free speech. If you're a conservative on campus, and you feel stifled by a liberal majority in your student body, put on your big boy or big girl pants and go out there and take it because that's what free speech is.

### Moderator
Claim: I want to remind you we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator, and we have four debaters, two teams of two debating this motion: Liberals are Stifling Intellectual Diversity on Campus. We're taking audience questions. Let's continue. Sir. Sir, there. Also, I just want to say, as I'm looking at the show of hands. Women are allowed to raise their hands and ask questions also.

### Moderator
Claim: We don't mean to stifle you.

Napp Nazworth with the Christian Post.

The "for" side brought up the issue that's taking place now, Christian groups being kicked off campus. And so-- but I haven't heard from this side, you know, addressing that issue. You know, how is that not stifling diversity, often done in the name of diversity, when Christian groups are being booted off campuses?

### Moderator
Claim: Who would like to take that question? Because I'd like you to pay it the respect that it deserves because--

### Scientific Advocate (SA)
Claim: Sure. I think it-- I think it is a very important question as--

### Moderator
Claim: Jeremy Mayer.

### Scientific Advocate (SA)
Claim: --I understand it, it has to do with leadership roles. So, certain campuses have a rule that says, any student organization has to have an open membership and open leadership voting which produces the odd outcome that you could have a Christian group of a small group of students that a group of malicious 19 years old, who were really jerky atheists could join the group and take it over. And so some campus groups have said, "We'd like to have our bylaws that said the leader of the campus Christian crusade needs to be an Evangelical Christian," right? How do we resolve that? I don't know, but I would not be in favor of booting Christian groups off campus.

I think that is a violation of free speech as well.

### Moderator
Claim: And they're being voted off why? Violation of the law, is it not?

### Scientific Advocate (SA)
Claim: It's because the campus has an organization that-- campuses are trying to keep the student KKK group from founding. So, in order to keep white Aryan groups from forming that would not admit black students, they try to write campus rules that would make every student group open to members of all races and religions and beliefs. But when you do that, you create a problem for some Christian groups if an angry group of other believing students want to join their group

### Moderator
Claim: Okay. Let's get Greg Lukianoff respond.

### Conspiracy Advocate (CA)
Claim: I have to go back the big boy pants argument that-- then. I think you actually get in trouble on a campus for saying something that sexist, though.

### Scientific Advocate (SA)
Claim: I'm ready.

### Conspiracy Advocate (CA)
Claim: But I want to be serious for a moment in addressing that. Again, let's talk about Emily Brooker. She's an evangelical Christian student trying to get her degree in social work at Missouri State University.

She's an evangelical, and she doesn't believe in gay marriage, and she doesn't believe in gay adoption. She was told to do an activity where she would actually act gay in public, which she pretended she did, as part of her degree, and then she said, "I'm never doing this again." She put on her big boy pants, as it were, when she was asked to sign a petition as part of her class supporting gay adoption. She fundamentally did not believe this was right. She said she wouldn't, and they brought her into the room, and they threatened her basically with being kicked out of the program unless she actually changed her point of view, unless she decreased the distance-- the difference between her and the administration. There was a full investigation of this. It was absolutely horrible, the extent to which they were intolerant of an evangelical Christian's belief. But she did fight. Then there's also Ed Felkner, who was told he had to-- he actually had to-- he had to lobby for liberal causes at Rhode Island College or else not graduate.

And what he-- when he actually said, "Wait, I'm not a-- but I want to be in this field, but I don't actually believe in any of these things," he was not given the option to actually lobby for causes he believed in. The-- you've got to be really far gone if you think you have the power to compel people to take political stances they don't actually believe in.

### Moderator
Claim: Questions?

### Scientific Advocate (SA)
Claim: Unless it's at Liberty University, then it's okay.

### Conspiracy Advocate (CA)
Claim: I wouldn't go to Liberty University.

### Moderator
Claim: Down on the side here.

### Moderator
Claim: My name is Allison, and I'm just interested in what you're talking about. And I have a question about trigger warnings. Do you see those-- and somebody did bring them up - - do you see those as stifling free speech? I mean, I can see as a college professor thinking, "What do I label with a trigger warning? What don't I? How much trouble am I going to get into if half the class leaves, and how much trouble am I going to get into if I don't have a trigger warning--"

### Moderator
Claim: So your question is, "Does anybody here support them"?

### Moderator
Claim: "-- and half the class is suspended--"

### Moderator
Claim: My guess is that nobody supports them.

### Moderator
Claim: --well, where--

### Moderator
Claim: okay.

### Scientific Advocate (SA)
Claim: student here tonight. We talked about date rape statistics--

### Moderator
Claim: Jeremy Mayor.

### Scientific Advocate (SA)
Claim: --without trigger warnings just last week.

### Moderator
Claim: Well, so where does it fit? Should it be on campus at all? That my question.

### Scientific Advocate (SA)
Claim: No, it shouldn't be. It's a ridiculous--

### Moderator
Claim: Uh-oh.

### Scientific Advocate (SA)
Claim: --perversion of--

### Moderator
Claim: Oh, I think we have a division on the against side.

Awkward.

### Moderator
Claim: Were you about to say

### Scientific Advocate (SA)
Claim: I think I actually am the nation's most prominent faculty supporter of trigger warnings at this point. I use trigger warnings in my classes. I think they are absolutely appropriate. I think they should never be mandatory. But I also think that it is absolutely crucial to create an environment where everybody can participate in a classroom discussion. And part of that is recognizing that we all come into the classroom as whole people who have our own experiences. And so if I am talking about the murder and the desecration of the body of Emmett Till, I would kind of like to know whether one of my students has just lost a son.

And if one of my students has just lost a son, I would talk about Emmett Till in a different way than I would under other circumstances. I don't think that my free speech is being violated if I make that choice. And so what I do in my classrooms is I say, "A, we're going to be discussing some really hard, difficult stuff. And if that brings up emotional issues or psychological trauma, let's talk about that."

### Moderator
Claim: So, your partner made the big-boy pants argument, and you're making the opposite of that I think or are you not? Are you not?

### Scientific Advocate (SA)
Claim: No, I think that-- I think that it's absolutely crucial that people have the-- I-- well, let me put it this way, I think that being called a "racist" is not the worst thing in the world. It's something that has happened to me. I have been on the receiving end of that, and I dealt with it.

### Moderator
Claim: You can address that.

### Scientific Advocate (SA)
Claim: Oh, yes, sorry. I-- you know, I've had that experience, and sometimes the people calling me a "racist" were kind of right and sometimes they were kind of wrong.

And in either situation, I learned something from it. And I would-- if somebody thinks that I'm a racist, I would far rather have them tell me that than not.

### Moderator
Claim: All right, let me let your opponents respond to the-- to your argument for those limitations on-- well, do you call those a "limitation on speech," by the way? Do you call them a "facilitator" or an "enabler of speech"? Which are they?

### Scientific Advocate (SA)
Claim: Yeah, no. I think that I-- what I call it is a "content note," and I-- it's a way of--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --enhancing discussion.

### Scientific Advocate (SA)
Claim: It should not be mandatory, and on that we agree.

### Moderator
Claim: Okay, Kirsten Powers.

### Conspiracy Advocate (CA)
Claim: Yeah. I-- well, I mean, this reminds me a little of Eric Posner, who is a University of Chicago law professor, just wrote an article for Slate Magazine basically arguing that-- in defense of a lot of these different-- of speech codes in particular, and he didn't-- I don't know if he mentioned trigger warnings because he said that what people don't understand is that students today are really our children and that they need to be protected. And that's sort of what is behind this idea-- which, to me, doesn't seem like something that's really encouraging a robust sort of intellectual debate.

But look, if you want to do trigger warnings, you can do trigger warnings. The problem that has been raised has been with professors who have been told that they must provide trigger warnings. So, at Oberlin, for example, a lot of professors revolted. And the-- University of California, Santa Barbara, there-- the students were demanding them. And I think that that is a very different thing, especially because, if you look at the list of the things that could potentially trigger something-- students, at Oberlin, they said it could literally be anything. And so, how that-- you know, how does that not chill a professor--

### Conspiracy Advocate (CA)
Claim: --of living in fear that they're going to trigger anybody?

### Moderator
Claim: Angus Johnston.

### Moderator
Claim: Do trigger warnings make you rage-filled? Do you need trigger warnings about?

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: I guess, two things-- first of all, in terms of the idea that this is infantilizing people-- the person who did the most to make me think about the importance of trigger warnings is actually in the audience here tonight. And she's a combat veteran. So, I don't believe that it's infantilizing.

Secondly, I would say that in Oberlin, there was never a-- it was never proposed as mandatory. Yes, students at Santa Barbara suggested that it should be mandatory, but students suggest things that are not that great of an idea all the time.

And in fact, in fact, the student who was behind-- one of the students who was behind the proposal at Santa Barbara wrote to me privately much later, saying that she thought that my solution was an excellent one, and she thought that the way that I had approached it, which was not mandatory, had advanced the debate in exactly the way she wanted it to be.

### Moderator
Claim: Do we have time for one more question? Sir, there. And I-- you can go ahead, sir.

### Moderator
Claim: Hi. I'm Casey Given with Students for Liberty. And my question is about-- tonight, a lot of the discussion has been about administrators stifling free speech, but what about students?

At my alma mater, the University of California Berkeley, recently, members of the Occupy movement actually raided a speech by Peter Thiel, the venture capitalist, and not just raided the speech, but also raided the stage, causing him to flee. So, is this-- is there also not liberal students stifling free speech?

### Moderator
Claim: I think we somewhat covered it, but if-- because I took that question to Kirsten a little bit ago. But do you want to very quickly respond to that?

### Scientific Advocate (SA)
Claim: Hecklers veto is a horrible thing, and it shouldn't happen, and frankly, it's pretty rare. I would also note, though, if we're talking about the Hecklers Veto, that one of the situations that springs to my mind is an Israeli ambassador a few years ago, at UC Irvine, who was not actually prevented from speaking. Students heckled him, but they didn't actually succeed in creating a veto. 11 students were arrested and charged with misdemeanors for engaging in free speech in that incident.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: So--

### Moderator
Claim: So, one thing I would-- I-- we're going to conclude this round in a second.

But I want to do one thing, since we devoted this time to trigger warnings-- is to relate it to our motion. I just want to go back to the side that's arguing for the motion, that Liberals Are Stifling Intellectual Diversity, and tell us why trigger warnings-- if trigger warnings actually support your argument, their existence and their implementation--

### Conspiracy Advocate (CA)
Claim: Oh, they absolutely do.

### Moderator
Claim: Greg Lukianoff.

### Conspiracy Advocate (CA)
Claim: They absolutely do. They're a liberal idea based on sensitivity. I think they're well- intentioned. I think a lot of speech codes ideas are well-intentioned. But here's my problem with trigger warnings. I wrote a short book called "Freedom from Speech," and I'm afraid that's kind of where we're headed. And but-- and here's-- and I can go to philosophical reasons why I think trigger warnings are dangerous. But here's the practical reason. Because seven humanities professors wrote Inside Higher Education, saying, "Oh, my God. These are becoming expectations. They're not mandatory yet, but because they're becoming expectations, I am receiving angry e-mails and angry letters from students and from administrators saying I better provide these." But guess what? It's impossible to know what actually might trigger them--

### Moderator
Claim: But why are they liberal? Why is it a liberal thing?

### Conspiracy Advocate (CA)
Claim: Because it's sensitivity-based-- it's a sensitivity-based warning idea that is absolutely in line with all of the speech codes we've been talking about--

### Moderator
Claim: Kirsten.

### Conspiracy Advocate (CA)
Claim: --the entire time.

### Conspiracy Advocate (CA)
Claim: Yeah. Well, there was also a New Yorker article that was written by a Harvard Law professor, about the fact that she-- she teaches rape law. And she has been-- had students demand that there be trigger warnings--

### Conspiracy Advocate (CA)
Claim: Or that she not teach it--

### Conspiracy Advocate (CA)
Claim: And-- well, and the-- and has ultimately sort of culminated with the idea. And she says specifically that this is, you know, perpetrated by left-wing groups who are advising the students, to tell them that they shouldn't have to sit in a rape law class if it's upsetting to them, to the point that she said, surveying various professors across the country, that they are now giving up teaching rape law because of the fear--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --of the backlash from--

### Conspiracy Advocate (CA)
Claim: --the students.

### Moderator
Claim: But let me-- let Jeremy Mayer respond to--

### Scientific Advocate (SA)
Claim: But could I ask her a question?

### Moderator
Claim: Sure.

### Scientific Advocate (SA)
Claim: If a campus said, "We are going to be the campus of sensitivity"--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: --and they said that "We're going to do trigger warnings"--

### Moderator
Claim: Sure.

### Scientific Advocate (SA)
Claim: --"because of the danger"-- you'd be fine with that, right, because we have, again, in this town Catholic University, where students are so sensitive to prochoice.

### Moderator
Claim: Right.

### Scientific Advocate (SA)
Claim: --that if anyone goes there, even if they're there to talk about acting or cooking have they ever been publicly prochoice? That speech is banned.

### Conspiracy Advocate (CA)
Claim: And what was really ironic about Catholic is that they actually used to have relatively good policies on freedom of association. And they tried to start an NAACP chapter there, and Fire came in trying to-- defending the NAACP and holding them to their promises, and then they rescinded all those promises. So it was one of the times where it actually ended up backfiring.

### Scientific Advocate (SA)
Claim: But by your own principles, if a campus said we are sensitive to university PC plays, you'd allegedly be okay with that because you're okay when right wing groups set up a campus and say, all right, no pro choice can say--

### Conspiracy Advocate (CA)
Claim: They can. But if you really take this to its logical extreme, then they couldn't be universities because they literally couldn't talk about anything.

### Moderator
Claim: But--

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate where our motion is Liberals are Stifling Intellectual Diversity on Campus.

## Round 3

### Moderator
Claim: And now we move on to round three, round three, closing statements by each debater in turn.

They will be uninterrupted. They will be two minutes each. And here to summarize his position in support of this motion, Liberals are Stifling Intellectual Diversity on Campus, Greg Lukianoff, president of the Foundation for Individual Rights in Education.

### Conspiracy Advocate (CA)
Claim: This evening, Kirsten and I have provided data and real examples demonstrating how liberals are stifling intellectual diversity on campus. But you don't have to take it from us. Just ask the professors themselves. In a 2012 study, a representative sample of about 300 social psychologists were asked if two job candidates with equal qualifications were to apply for an opening in your department, and you knew one was politically conservative, would you be inclined to vote for the more liberal one? 82 percent of liberal social psychologists said they would at least be a little bit prejudice against the conservative applicant. This is shocking, especially when you consider that social psychologists are so often concerned about the harm of unconscious bias. It can be very hard to get respondents to concede that they might be prejudice. Not-- not so apparently with conservatives and Christians.

It's a well-known rule of social science that the more politically homogenous a group is, the more radical in that direction it tends to become and the more the group begins to act as a tribe that sees outsiders as enemies who are either stupid or simply bad or greedy. Unfortunately, we're seeing this play out within our colleges and universities. Too many liberals are stifling intellectual diversity on campus and in doing so, they are encouraging people just to talk with those who they already agreed. There are endless rules for collect speech-- correct speech are encouraging people to keep their opinions to themselves. This only makes the tribalism problem worse and the walls of the echo chamber thicker. It's not supposed to be this way, and it doesn't have to be this way. But the first step towards recovery is admitting you have a problem. And on our campuses, we have a problem. And I hope you will all recognize tonight that liberals sadly are stifling intellectual diversity. Thank you.

### Moderator
Claim: Thank you, Greg Lukianoff.

And that is the motion, Liberals are Stifling Intellectual Diversity on Campus.

And here to summarize his position against this motion, Jeremy Mayer. He is co-author of "Closed Minds, Politics and Ideology in American Universities."

### Scientific Advocate (SA)
Claim: A long time ago, I was a Republican at Brown University. And that was a tough gig. There was social ostracism sometimes. People called me a racist. There are things that you go through with a Libertarian-minded Republican that I sympathize with. But I don't believe, overall, that liberals are stifling intellectual kinds of diversity. I think a lot of these ideas, even the idea of trigger warnings are creating discussions about trauma and how we talk about it. When I was at college, my first month, a gay student group had a kiss-in in the mailroom. And back in-- '80-- and today that's pretty normal at GW. That happens a lot of-- Thursday I think is the gay kiss-in.

But in '86, that was revolutionary to see boys or men and men and women and women kissing deeply. It really created a discussion. That's free speech.

And was it offensive, was it dangerous? Did people-- yeah. But that's what a campus should be. A lot of the things we've heard tonight are anecdotes. The plural of anecdote is not data. There are things that happen on college campuses that I don't approve of, that I don't think a good liberal or for someone committed to free speech should approve of. But you know what? That's what happens when 18 and 21-year- olds are passionate about their beliefs and they engage in a debate that we must desperately have. So, at the end of the day, I think a lot of conservatives are worried that their children are going to change to the left. And I have good news, we don't change children to the left. Jennings and Stoker in a longitudinal study found that college had absolutely no effect on political views of college students. Mariani and Hewitt found a small leftward change over time in college students that was exactly mirrored by what happened with the same age group that didn't go to college.

So, please consider well that liberals are not stifling intellectual diversity on college campuses.

### Moderator
Claim: Thank you. Jeremy Mayer.

And that's the motion: Liberals Are Stifling Intellectual Diversity On Campus. And here to summarize her position supporting this motion, Kirsten Powers. She is author of "The Silencing: How the Left is Killing Free Speech." It's due out in May.

### Conspiracy Advocate (CA)
Claim: If you're part of the dominant culture, which, on university campuses-- as we've established-- is primarily liberal-- it's easy to mistake your beliefs for objective truth. It's also easy to imagine there are no reasonable or intelligent people who think differently on important topics, because you're not encountering them. I know this because I've lived most of my life in the liberal bubble. There were two experiences that took me out of this. One was becoming a contributor at Fox News. And the other was a later in life conversion to Christianity. I can remember actually saying to somebody that I was debating at Fox that Harriet Miers-- who George Bush was-- had nominated for the Supreme Court-- didn't count as a female appointment, because she was a conservative and an evangelical Christian.

I'm embarrassed, frankly, that I ever thought that. It was a prejudiced view, and unfortunately, I wasn't alone in my prejudice. A 2007 study of faculty on college campuses found that 53 percent had cool or negative feelings towards evangelical Christians. These levels of disapproval raise curious questions about how evangelical students are treated on campus. The only way that one could believe that liberals aren't stifling intellectual diversity on campuses is if they never visit FIRE's website and if they don't have any friendships with non-liberals. At a dinner party a couple weeks ago, I met a retired Stanford professor and a Harvard Law School student-- both evangelicals - - who described to me how they felt they had to hide their beliefs, lest they be ostracized or punished.

A third person, who was a former professor at a DC area university, was passed over for a position because she was suspected-- correctly-- of being a conservative. And this was in writing. These stories are all too familiar. I hear them regularly, but people are too afraid to speak publicly. They don't want to lose their jobs or academic careers, and FIRE receives calls from people like this nearly every single day. I believe you must vote "YES" on this motion tonight: Liberals Are Stifling Intellectual Diversity On Campuses.

### Moderator
Claim: Thank you, Kirsten Powers.

The motions, Liberals Are Stifling Intellectual Diversity On Campus. And here to summarize his position against this motion-- Angus Johnston. Founder of the website StudentActivism.net.

### Scientific Advocate (SA)
Claim: When I was an undergraduate student, involved in various student organizations, I remember feeling afraid to talk about certain issues. I remember feeling like if I said the wrong thing, that I might get yelled at, or maybe somebody would even stop liking me.

I remember that that scared me. And I remember that what it did sometimes is make me keep my mouth shut-- which, as a 19, 20, 21-year-old white guy, was maybe not the worst thing that could happen to a person. But the other thing that it did is it made me think more seriously about what I was going to say. It made me chew on the stuff. And sometimes I did think seriously about what I was going to say, and I still said something that offended somebody else. And they let me know it. And here I am today, still alive, still doing okay. Part of free speech on campus is people being passionate about the degree to which they abhor what you say. I absolutely think that we need more free speech on campus when we're talking about administrators, and faculty imposing their own values, whether ideological or not.

But I also absolutely think that we need to stand up for the right for people to engage in rowdy, obnoxious debate, because rowdy, obnoxious debate is what made me what I am and it's what made a lot of you what you are. So, in standing up for free speech, and standing up for rowdy, obnoxious debate, I would encourage you all to avoid stereotyping who are the people who are censoring and who are the people who are silencing. And the best way-- I was going to say the best way you could do that is vote against this motion, but I don't want to pressure you. I don't want you to feel silenced. So,--

--do whatever will make you feel that you are whole and that you are a part of this community, because this is a hell of a community. Thank you very much.

### Moderator
Claim: Thank you, Angus Johnston. And that concludes--

--our closing statements. And now it's time to learn which side you, our audience, feel has argued better here. We're going to ask you again to go to the keypad at your seat and once again to vote, and we'll get the readout almost immediately.

Again, the motion is, "Liberals Are Stifling Intellectual Diversity on Campus." If you agree with this motion, have been persuaded to it, push number one. If you've come out against it, push number two. And if you became or remain undecided, push number three. And we'll lock it out in about 15 seconds, and we'll have the results in about 90 seconds. While we're waiting for that to happen, I just want to say this, that this was a great exercise in free speech, number one. I know it's a cliché, but it really was-- and I-- everybody on this panel-- both panels absolutely believes in that value, and despite your disagreement, which was quite visceral, you brought respect to one another and civility and yet it was robust and it wasn't boring ever. So, congratulations for the way you did that. Thank you.

We've had a great time at George Washington University, and we hope to come back again. And I also want to thank everybody who got up and asked a question in the audience, including the gentleman's question I didn't take. I don't-- I don't mean any disrespect by that at all. In fact, in a-- again, in the spirit of free speech, I hated saying, "No," but come on down afterwards and chat with us because I think that would work. So congratulations, and thanks for everybody who got up and asked a question. So one more round of applause for them.

Our next debate will be in New York at the Kaufman Music Center. That's our usual home. It's going to be on March 11. That's a Wednesday. We're going to be debating whether the U.S. should adopt Europe's right to be forgotten online principle. And we'll be debating, having on our stage a global public policy former director from Google.

We'll have law professors from Harvard and the University of Chicago, and we'll have the European Union Commission's director of fundamental rights in citizenship.

We really do mean it when we say, "Come on up." And if you can't, we'll be livestreaming and of course it'll live on as a podcast and as an NPR broadcast. You can find our podcast. We have a really lovely app that we launched this year. It's available in the Apple store and the Google-- the Google store as well for Android. And it contains-- you can hear all-- we've now-- this is our 101st debate, and 100 of them are on there. Enjoy both the video and visual, and you can also vote and do research, et cetera. So, please take a look at that in our website, iq2us.org. And to everybody who joined our live stream today, from wherever you are in the world, thank you. Okay, so I have the final results now. It's all in. The motion is this, "Liberals Are Stifling Intellectual Diversity on Campus." And, again, reminding you that the way this works is that the team whose numbers have moved the most in percentage point terms between the first and second vote will be declared our winner.

So, let's look at the first vote on the motion, "Liberals Are Stifling Intellectual Diversity on Campus," and the first vote, 33 percent supported this motion, 21 percent were against, 46 percent were undecided. So those are the first results. Looking now at the second results, the team arguing for the motion, their second vote was 59 percent. They went from 33 to 59 percent. That's up 26 percentage points, and that is the number to beat. The team against the motion, their first vote was 21 percent, second vote, 32 percent. That's only an 11 percent increase. It means the team arguing for the motion, "Liberals Are Stifling the Intellectual Diversity on Campus," are our winners. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.

Thank you, everybody. It was really a pleasure to have-- to be doing this in Washington, and, again, it's a cliché, you were a terrific audience, but actually you were a terrific audience. So, thank you.
