# Debate Transcript

Topic: The Rich Are Taxed Enough
Motion: The Rich Are Taxed Enough

Debate ID: 102412%20taxes


## Round 1

### Moderator
Claim: Tonight we have a partner, a new partner in this. We are sharing credit with the fact that we're putting this debate on with Columbia University's Richard Paul Richmond Center for Business Law and Public Policy. That-- I can see the spontaneous applause thing is going to work really well. I do want to say that it's a joint venture of the law school and the business school. And they have, as we do, a goal of trying to raise the level of public discourse, in their case where law, and markets, and business intersect. So, again, I thank you, let's give them a round of applause-- The other reason we have these debates, of course, is because of the Rosenkranz Foundation, which launched them six years ago and sponsored them, and I want a welcome now to help us frame the debate and talk about why we're doing this by inviting onto the stage the chairman of the board of Intelligence Squared U.S., Mr. Robert Rosenkranz. So, Bob, as I always ask you before these debates, why this one and why now?

### Moderator
Claim: Well, the reason why now is because the theme of taxes and tax policy has been a very divisive theme throughout the presidential campaign and the presidential debates, and we're trying to bring this to a-- perhaps more sophisticated level here tonight.

### Moderator
Claim: And this motion has a tricky word, "enough," what do we intend by putting the word, "enough," into this motion?

### Moderator
Claim: Well, I thought really that there would be three criteria by which one might decide that. One is the matter of fairness, one is efficiency, and one is sufficiency.

### Moderator
Claim: Okay, take us through fairness, what it means for each side.

### Moderator
Claim: Well, for the pro the motion side, fairness would be the point of view of somebody in the top 1 percent who's paying 40 percent of all the taxes in America or the top 5 percent which is paying 60 percent, they're going to see the system as fair. On the other hand, if you work for a billionaire who's paying a lower tax rate than you are, you're not going to see it as fair.

### Moderator
Claim: And sufficiency.

### Moderator
Claim: Sufficiency really means, "Are we raising enough revenues to put the government on a fiscal path that makes some sense?" And I think the pro motion side is going to point to the fact that it's really spending that's the problem.

We're spending about 24 percent of GNP on federal expenditures. The norm in the last 20 years have been about 21 percent, and we've got to get spending under control. The other side is going to say, "Wait a second. Tax collections are only about 16 percent of GNP compared to 19 percent. We need to raise more money." And if we remember the words of Willie Sutton, "Go where the money is."

### Moderator
Claim: And efficiency was the last part of it you mentioned.

### Moderator
Claim: Well, efficiency is the idea of promoting economic growth. What kind of tax system would best stimulate the growth in the economy? And I think the pro the motion side is going to argue that it's very, very important to preserve the incentives that the "rich," quote, unquote, have to risk money to invest to create jobs for others. The against the motion side is probably going to point to the fact that a dollar in the hands of a middle class family is going to be spent, and in a direct way stimulate economic activity; whereas a dollar in the hands of a rich person might just sit there.

### Moderator
Claim: All right, Bob, thanks very much in that slicing the word “enough,” enough has a lot of meanings, and thank you for framing this for us. And let's welcome our debaters to the stage.

### Moderator
Claim: Good.

### Moderator
Claim: Thank you, thank you. And may I invite one more round of applause for Robert Rosenkranz for bringing this to us. If you ask, "do the rich pay their fair in taxes?" you really do have to ask a couple of other questions. You’ve got to ask, well, what do you mean by rich?

How much, how much is rich? How much money does that take? And, what do we mean by "enough"? Now, consider that to be counted in the top 1 percent of earners in America, you need to be making approximately $380,000 a year. Consider, also, that that 1 percent pays more than a third, as of 2009, pays more than a third of all of the federal income tax that comes in to the federal government. Is that too much? Is that too little? Well, let's make a debate of it. True or false, the rich are taxed enough. Another debate from Intelligence Squared U.S., I'm John Donvan, we have four superbly qualified debaters who will be arguing for, and against, this motion: The Rich Are Taxed Enough. They go in three rounds and then the audience votes to choose a winner, and only one side wins. Our debaters include, on the side arguing for the motion, Glenn Hubbard, Dean of Columbia Business School and economic advisor to Mitt Romney. Your partner it Art Laffer, he is best known for the Laffer Curve, one of the main theoretical constructs of supply side economics. On the side arguing against the motion, Robert Reich, he's a professor at UC Berkeley and former Secretary of Labor in the Clinton administration. And his partner, Mark Zandi, he's chief economist of Moody's Analytics. Our motion is this: The Rich Are Taxed Enough. Let's meet our debaters and welcome first, Glenn Hubbard. Glenn, you are dean of the Columbia Business School, you are also-- throughout 2012, you've been advisor to Mitt Romney's campaign. Recently you were profiled in The New York Times, and you were described there as, "succinct, authoritative, and unabashedly partisan."I want to know, is that fair? Are you unabashedly partisan? And could you be succinct and authoritative?

### Conspiracy Advocate (CA)
Claim: Well, I am always succinct. To the partisan, I guess I'm old enough to remember when Bill Bradley and I collaborated on an idea that's not too far dissimilar to tonight. And President Obama's housing plans follow work by me and by a colleague at Columbia.

### Moderator
Claim: And your partner is?

### Conspiracy Advocate (CA)
Claim: My partner is Art Laffer.

### Moderator
Claim: Ladies and gentlemen, Art Laffer. Art, you were an economic adviser to President Reagan; you served as chief economist at the Office of Management and Budget. You're best known as the father of supply side economics because of the curve that is named after you. And I think it's fortuitous that your last name was not McDougal or Rabinowitz, or Kowalski, because we would be talking about the Kowalski curve. Your name adds a certain light-heartedness to your curve-- And you are a lighthearted guy. In two sentences or less, what is the Laffer curve about?

### Conspiracy Advocate (CA)
Claim: Well, number one, the Laffer curve really is my profile. And the other famous thing about me is I am a little bit taller than Robert Reich.

### Moderator
Claim: Our motion is The Rich Are Taxed Enough. The Rich Are Taxed Enough. And here to argue against the motion, Robert Reich. You're a professor of public policy at UC Berkeley, former Secretary of Labor in the Clinton administration. You are a bit of an intellectual brawler yourself, and you can dish it out. You've also had to take it. Bill O'Reilly recently called you "a communist who secretly adores Karl Marx." Neil Cavuto said you were a sanctimonious twit. Question is, does this stuff really hurt your feelings?

### Scientific Advocate (SA)
Claim: No, not at all-- No. Actually, I don't know how Bill Reilly knew that I was a secret admirer of Karl Marx because it was a secret.

### Moderator
Claim: And--

### Scientific Advocate (SA)
Claim: Logic on that side of the aisle.

### Moderator
Claim: And your partner is?

### Scientific Advocate (SA)
Claim: My partner is the incomparable Mark Zandi.

### Moderator
Claim: Ladies and gentlemen, Mark Zandi. Mark is--

### Scientific Advocate (SA)
Claim: I'm nervous about this now. You're going to be nice, right? You're going to be nice?

### Moderator
Claim: This is so easy.

### Scientific Advocate (SA)
Claim: Yeah, okay, all right.

### Moderator
Claim: You are the chief economist of Moody's Analytics, and you have one of the most widely followed economic forecasts. That was nice.

### Scientific Advocate (SA)
Claim: That was nice, yeah.

### Moderator
Claim: That was very nice.

### Scientific Advocate (SA)
Claim: Yeah. I'll take that. I'm a great guy, too.

### Moderator
Claim: Here's the other part of it. When the Bush cuts neared expiration in 2010, you at that time were in favor of their extension initially?

### Scientific Advocate (SA)
Claim: Yes, I was, yeah.

### Moderator
Claim: Now?

### Scientific Advocate (SA)
Claim: I think the president's proposal is the appropriate proposal, allow the tax rates for upper income individuals to expire.

### Moderator
Claim: So, you do get to change your mind?

### Scientific Advocate (SA)
Claim: No, I am an eclectic economist in that I think the economics depend on the times, and the times now are such that we've got to address our fiscal problems.

### Moderator
Claim: Thank you, Mark Zandi. Ladies and gentlemen, our debaters for this evening. Now, in this debate, you, our live audience, act as our judges. By the time the debate has ended, we will have asked you to vote twice, once before you've heard the arguments and once again after you've heard the arguments, and the team whose numbers have moved your votes the most from beginning to end will be declared our winner. So, let's register the first vote. If you go to the keypad that's at the right hand of your seat, our motion is this: The Rich Are Taxed Enough. If you agree with that motion as you come in off the street, push Number 1. If you disagree, push Number 2. If you're undecided, push Number 3. All of the other keys, you can ignore. They're inoperable. And you can also correct yourself if you've pushed the wrong button. And, again, this is being-- these are wireless devices, so they're all being recorded backstage and tabulated. And then, at the end of the evening, it takes about as long as it takes me to finish this sentence, we'll have the results again quickly comparing the two votes.

All right. Let's launch. Our motion is The Rich Are Taxed Enough. On to Round 1, opening statements from each of our debaters and turn, and speaking first for the motion, The Rich Are Taxed Enough, Glenn Hubbard, who is Dean of the Columbia Business School. He was chairman of the Council of Economic Advisers under President George W. Bush, a former deputy assistant secretary for tax policy in the Treasury Department, ladies and gentlemen, Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank-- I'd certainly like to thank Intelligence Squared and the Richmond Center for an event on topic this important. My partner, Art Laffer, the eponymous economist, will follow with some great thoughts on why raising tax rates is the wrong place to start. But I just want to make two points this evening.

First, raising tax rates on the rich is both counterproductive and unnecessary to fund the government that Americans have traditionally had. I'll come back to that point. Second, if we do want a larger government, and that's a political choice, the extra taxes to pay for that government will largely come from the non-rich. Now, let's start with how high tax rates are. If you look at survey data and ask Americans what they think is fair that about a quarter or a bit more would be fair in taxes paid. If that's true, the current and projected marginal tax rates-- that is the tax rate on the next dollar that you earn-- are very high for upper income folks, 35 percent for ordinary income. And, if you're New Yorkers in this audience, you know that by omitting state and local taxes, I'm leaving a lot on the table here. And 15 percent for dividends and capital gains, but of course corporate taxes were already paid there. And, on top of that, there's an estate tax that taxes money that had already been taxed once or twice in someone's lifetime.

All of these taxes are set to rise substantially next year, 40 percent for earned income, 44 percent for dividends, 24 percent for capital gains, and beyond. Now, the calls for higher tax rates really raise two concerns. First, if you step back, they treat the nation's income as an already big pie, and it doesn't really matter for the size of that pie how it's sliced. An economic observation of that is that ignores a lot of incentives that taxes have on the decisions we all make. Those sorts of incentives would lead to lower activity, lower jobs, and lower incomes. The second choice here is that the real fiscal policy choice facing the nation is really about the size of government. And here my observation isn't economics, it's just arithmetic: if we want the larger government, we all will have to pay for it.

The bulk of the taxes will come from the non-rich. Now, let's start, first, on the cost of raising tax rates. Now, I can look out and tell that your favorite course in college was, of course, economics, and you remember, from the public finance lecture in that class, you can boil it down to a simple sentence: if you tax something you get less of it. And economists worry, particularly, about tax rates that are already high. Now, some of the somethings we get less of are work and saving. And, here, I just want to offer you a forecast, and I should be honest with you that President Bush once said about me that "Glenn can't even forecast the past." And I think what the president meant was data get revised, but you take that for what it's worth. But economists, like me, and my own academic research, have forecast changes in taxable income from changes in tax rates. The responses of high income tax payers are not only absolutely high, they are much higher than the responses of other tax payers.

Of particular concern in this regard is the taxation of business income. High business taxes discourage investments in machines and ideas and jobs. More than half of Americans who work in the private sector work for businesses whose owner pay taxes at individual rates. Raising taxes on those business owners discourages hiring, discourages investment. If you make a comparison of next year's tax law, with higher rates, to the much bally-hooed Bowles-Simpson plan, you'd find that the lower tax rates in Bowles-Simpson that are financed by broadening the tax base, would raise investment in businesses by 54 percent, and raise hiring by 14 percent. And high tax rates don't necessarily produce revenue. The fact that revenue shares and GDP haven't varied substantially across periods when the top marginal rate was more than 70 percent, from when it was less than, or about, 28 percent, suggests that we have a lot of lost taxable income and a lot of wasteful tax planning when we have high tax times.

The right answer is tax reform to raise money from upper income households by broadening the tax base, and to seek expenditure reform that also reduces benefits for those tax payers. Now, what about the larger government? Before the financial crisis, federal spending in the U.S. averaged about 20 percent of GDP for many decades. What if we decide we'd like a bigger government? Let's say 25 percent, or maybe a larger number, like many European countries. Shouldn't raising tax rates on the rich pay for that government? Well, the simple answer is no. Or, more accurately, it can't. If you look across the OECD, the club of rich industrial nations, you'll find something that may surprise some of you. The U.S. has the most progressive tax system.

And, in fact, the U.S. tax system actually decreased inequality more than any other country's tax system. So you think to yourself, "Well, how can this be? We're thinking of European nations with large government and social welfare programs." But the answer is simple, for reasons of arithmetic, that is, there's just not that much income at the top, and economics, consequences for investment and for jobs would be too grim, those nations actually use broad based consumption taxes, like a VAT that are borne by all citizens to fund their spending. So the real choice is the size of government. That's the debate we need to have first. Taxation should be fair, but it should also seek to advance growth and living standards. The right tax system for this country can accomplish both. And so, for the government of the size that we all have been used to before the past few years, we can, we should, accomplish both fairness and growth without raising tax rates on high income individuals.

If we, the body politic, want a larger government, we all must pay. The rich are not a plug number in a budget gambit for a free lunch. For the proposition, The Rich Are Taxed Enough, the answer is clear, and it's yes.

### Moderator
Claim: Thank you, Glenn Hubbard. Our motion is The Rich Are Taxed Enough, and now here to speak against the motion, I'd like to introduce Robert Reich, he is the chancellor's professor of public policy at the University of California at Berkeley, and the former Secretary of Labor in the Clinton administration. Ladies and gentlemen, Robert Reich.

### Scientific Advocate (SA)
Claim: As you can see, the economy has worn me down. But we're in a recovery. Look. I think this is an absurd motion, and I urge you to vote against it when you have a chance to vote against it again. It's an absurd motion for the following reasons. Number one, we have a huge budget deficit. Even if we didn't want to expand the size of government, even if we want to contract the size of government, we still have a gigantic budget deficit. And the debt is about 85 percent, by some measures, of gross domestic product. And the question is how do you get the deficit down? How do you get the debt down? Well, almost everybody who has looked at the issue has said it's got to be some combination of tax increases and spending cuts. The Simpson-Bowles commission, to which my esteemed colleague referred to, said, "Well, we have one dollar of tax increases for every three dollars of spending cuts."But there have got to be some tax increases, and the real question here isn't the size of government, the real question here is who is going to bear the brunt of the tax increases. Is it going to be people mostly at the top, or is it going to be people who are in the middle, or is it people who are poor? And I want to tell you in terms of common sense and logic and fairness, it ought to be people at the top. Why, why, why? You can applaud, but don't take away from my time. Why? Because number one, people at the top have never had it so good. I mean, the percentage of total income in this country going to people who are in the top one percent, has doubled over the past 30 years. It used to be 10 percent back in 1980. It's now over 20 percent. That is people in the top 1 percent are now getting over 20 percent of total income. If you're in the top one tenth of 1 percent, your share didn't just double, it actually tripled over the last 30 years.

If you're in the top one-one-hundredth of 1 percent, your share quadrupled of total income over the last 30 years. The richest 400 Americans have more wealth than the bottom 150 million of us put together. And this kind of asymmetry, this kind of distorted gap between the top and the wealthiest people and everybody else is really something new in this country, at least within people's living memory. It wasn't this way in the '50s or '60s or '70s. It wasn't even nearly this way in the '80s. So, if we're going to have to raise taxes, obviously fairness and logic would indicate you raise them on the top. Now, Glenn Hubbard is talking about, "Well, you have a negative effect, a negative incentive effect." Come on. In the immortal words of Joe Biden, "Malarkey!" mean, look. The tax rate-- the marginal tax rate on top incomes-- go back before 1981-- for at least three decades before 1981, the top marginal tax rate in this country was at least 70 percent. Under Dwight D. Eisenhower, President Dwight D. Eisenhower, Republican, who nobody would have accused of being a socialist-- Bill O'Reilly would not have called him a communist-- and yet the marginal tax rate on the top incomes under Eisenhower was 91 percent. If you get rid of all the deductions and tax credits, it's still-- the effective tax rate under Eisenhower is closer to 56 percent, much higher than anybody today is talking about. We're talking-- right now, we're talking about the difference between, what, a 35 percent tax rate and maybe going back to Bill Clinton's days? I mean, this is a ridiculous debate. It should not even be debated obviously.

Given where we were before and where we are now, we shouldn't even be raising this question. I mean, they will say higher taxes have a negative impact on economic growth. Well, guess what? In the three decades before 1981, when taxes were higher on the rich, the economy on average per year grew faster than it has grown since 1981. There was no negative impact on growth. I mean, George W. Bush reduces-- remember 1981-- 2001, 2003, he reduces taxes on the wealthy, saying, "Oh, we're going to get this huge increase in growth, and we're going to get all kinds of jobs," using and spouting supply-side-- excuse me, Art-- nonsense-- and what did we get? We actually had less growth. We had fewer jobs, even before the great crash. We had an economy that did not perform nearly as well as it did under the president I was very proud to have served under, that is Bill Clinton, who raised taxes.

We had the largest and longest boom in modern memory, 22 million new jobs were created. That wasn't a negative growth, that was not a slowdown in growth. We raised taxes, 22 million new jobs were created. I was secretary of labor during those times. I created every single one of those jobs. Thank you. Thank you very much. So just to-- in summary-- we have to raise taxes in order to deal with the budget deficit, regardless of what your particular ideology is about a smaller or larger government. Number two, the rich have done extraordinarily well. Everybody else hasn't. In fact, median family incomes since 2000 have actually dropped 8 percent. You want to put more taxes on average working people? No. That's simply not fair.

It's not going to work. Number three, the rich right now bear a lower, smaller, marginal tax burden than they have at any time in the post-war era. Of course you have to raise taxes on the rich if we're going to get on with the business of this country. So please vote against this silly proposition. Thank you.

### Moderator
Claim: Thank you, Robert Reich. And I remind you of where we are. We are halfway through the opening round of this Intelligence Squared U.S. Debate. My name is John Donvan. We have four debaters, two teams of two who are arguing it out over this motion: The Rich Are Taxed Enough. You have heard the first two debaters, and now on to the third. I'd like to introduce and bring to the lectern Art Laffer. He is the founder and chairman of Laffer Associates and Laffer Investments. He is known as the father of supply side economics, was a former advisor to President Ronald Reagan. Ladies and gentlemen, Art Laffer.

### Conspiracy Advocate (CA)
Claim: If I can just start with this hotel you guys got for us today, I had the craziest thing happen. I came in a little early. And I went down to the health club. And now, I'm not an exercise freak or anything. But I was down there. And this absolutely gorgeous woman walked in. She's just beautiful. And the manager of the health club was standing right next to me, so I said, "Excuse me, by any chance do you have a machine that would attract someone like that to someone like me?" And the guy says, "Yes, I do." And he took me over to the Citicorp ATM. And I just want to say that the rich are not the Citicorp ATM. If you look at this world, and I-- but, Robert, you're a favorite of mine, and you have been for years; and, Glenn, you did a great job on this; and Mark, I'm anticipating your comments and-- but look at it, you got-- there would be three reasons you could possibly want to raise tax rates on the rich. You're jealous of them, and Robert may be but he's one of them. And the other thing is, you're going to get more revenue. And you're going to create prosperity. Those are the other two. And I'm going to land on the last two and look at the facts if I can. I mean, in the 30-- if you look at the growth rate there, we can go back in time, but, you know, if you look at the periods let's say from the Roaring '20s, we cut tax rates back then from 73 percent to 25 percent in the Roaring '20s. It was called the "Roaring ‘20s" for a reason. We had enormous expansion of growth, output, and employment. The top 1 percent of income earners, now, we have great data on the top 1 percent of income earners. The IRS really likes to know how much you owe them. And we have great data. The top 1 percent of income earners, their taxes as a share of GDP soared during the period of the Roaring '20s. If you look at the 1930s, we raised the highest margin-- well, we first had May of 1930 we had the Smoot- Hawley Tariff.

Then Hoover raised the highest tax rate on the rich from 25 percent to 63 percent. Then Roosevelt on January 1936 raised it from 63 to 79 percent and then up to 83 percent. There's a reason why it was called the Great Depression. The economy was in a shambles in large part because of the tax increases. The revenues from the top 1 percent of income earners as a share of GDP went down during this period. You look at the Kennedy period where we cut the highest tax rates from 91 percent to 70 percent. We also put in the investment tax credit, accelerated depreciation, cut the corporate rates, did tariff reform as well-- the Kennedy-run tariff negotiation, tax rate-- it was called the-- it was called the "Go-Go '60s," if you remember, a boom in the economy, and tax revenues from the top 1 percent of income earners went up during that period as a share of GDP. We then had the four stooges, Johnson, Nixon, Ford, and Carter. Which I consider to be the largest assemblage of bipartisan ignorance probably ever put on planet Earth.

If you look at that period, we had stagnation for 16 straight years. The stock market collapsed during that period. Tax revenues for the top 1 percent of income earners went down as a share of GDP. Then we had-- then we had Ronny-- oh, excuse me, the sky is opened, the sun shone forth on the planet, the grass turned green, the animals, they multiplied, the children danced in the street, but we cut the highest tax rates of everything we could find. We had Steiger-Hansen in '78, then we cut the-- I mean, under Reagan, cut it from 70 percent to 28 percent. If you look at the whole period from 1978 all the way to 2007, we cut the highest tax rate on earned income from 50 percent to 35 percent. We cut the highest tax rates on unearned income from 70 percent to 15 percent.

We cut the capital gains tax rate, we cut all of these tax rates across the board. We had a boom, and it wasn't just Ronald Reagan. Robert, your president, by the way, cut the capital gains tax rate dramatically; he got rid of capital gains taxes on owner occupied homes for everyone, he also got rid of the tax on retirees working, which was the group between 65 and 72. He also put in welfare reform, he also cut gtovernment spending as a share of GDP by more than the next four best presidents combined, and he had the greatest secretary of labor of all time-- But he was a big taxer. We had huge growth during that period. If you look at what happened to the tax revenues from the top income earners-- you know, in 1980 tax revenues as share of GDP from the top 1 percent was 1.5 percent of GDP. By 2007, tax revenues from the top 1 percent of income earners was 3.2 percent of GDP, it more than doubled.

Let me tell you really honestly, you're not going to get the money from these guys. You're not. They can hire lawyers, they can hire accountants, they can hire deferred income specialists, they can hire congressmen, they can hire senators-- They can hire-- when you see a group of people hanging with the president, don't for a moment think it's a group of street people trying to explain to the president what it's like being poor. They're in there for some reason and they find it. You know, what you really want to do is get a low rate, flat tax, where you have no exceptions, no exemptions, no deductions, none of that stuff. And get them out of the business of trying to finagle their tax codes, get them out of the business of trying to influence government, get them into a position where they create prosperity and economic growth. And that is the way you got to go. We all want increased tax rates on the rich, but we want to do it not by raising rates, which won't work, we want to do it by lowering rates and broadening the base. And if I can correct one other little mistake, Robert, just a little one.

Simpson-Bowles lowers the highest tax rates on the rich, and so does Rivlin-Domenici. They lower rates, they broaden the base. In '86, we cut tax rates on the rich dramatically, from 50 percent to 28 percent. In the Senate, 97 votes for that, three against it, including Joe Biden. What was his malarkey comment? Excuse me, maybe he was looking in the mirror. But you also had Bill Bradley, you also had Howard Metzenbaum, you had all of these-- and you had Chris Dodd and you had Teddy Kennedy. Everyone knows that you don't create growth by raising tax rates on the rich. You can't love jobs and hate job creators. And you can't tax an economy into prosperity, it ain't going to happen. Thank you very much.

### Moderator
Claim: Thank you, Art Laffer. Thank you, Art Laffer. Our motion is The Rich Are Taxed Enough. And here is our final speaker, making his opening statement, Mark Zandi.

Mark is the chief economist of Moody's Analytics and is one of the most frequently cited economists in Washington; he's also the author of this book, "Paying the Price, Ending the Great Recession, and Beginning a New American Century." Ladies and gentlemen, Mark Zandi.

### Scientific Advocate (SA)
Claim: Thank you, John. Thank you. Thank you, John. Thanks, Intelligence Squared and Bob Rosenkranz for the opportunity. I did notice that on Amazon the price of my book is falling; demand, supply, you know. We need a little more demand here to help me out. Let me begin by saying that, you know, it's obvious the American economy has very serious challenges. But I would put two right at the top of the list. The first, this is in no particular order of importance, but the first is, the skewing of the distribution of income consumption and wealth, and the second is our fiscal problems.

The statistics here are pretty startling. Let's begin with the income distribution, wealth distribution. If you take the top 20 percent of income earners, they take home over 50 percent of the nation's income, the top 20 percent take home 50 percent of the income. They consume 60 percent of the total pie. So, from cars to clothing and everything in between, they consume 60 percent. And they own 90 percent of the wealth. These are pretty skewed statistics. And the more startling thing is they've gotten more skewed over the past 30 years. You know, you go back to the early 1980s, late 1970s, these statistics were very different. I'll just give you one example. I mentioned that the top 20 percent accounts for 60 percent of the spending. If you go back to 1980, it was closer to 45 percent.

So, it's skewed, and it's getting more skewed. Our fiscal problems are obviously very significant as well. If you go back to the year 2000-- we'll give Bob credit for the 22 million jobs. Should we give you credit for the surplus in the year 2000, too? Okay, Bob. Let's clap for that. There was a surplus, 2000. We've been running deficits ever since. The last fiscal year just ended. We had a deficit of $1.1 trillion. You can ask, "Well, what's going on?" Lots of things. There's the wars. That's $1.2 trillion over the last 10 years. That's Afghanistan and Iraq. There's the Bush era tax cuts. According to the nonpartisan Congressional Budget Office, that cost us $1.6 trillion over a 10 year period. And, of course, there was a recession, the great recession, and by my calculation, that's cost us about $1.8 trillion over the course of the last 10 years. You add it up, it's a lot of money. So, we've got some big problems, very significant issues we have to tackle.

Now, the bad news is that-- it sounds pretty bad-- The bad news is that if we-- these trends will continue if policymakers don't act. If they don't act, these trends will continue, and this will harm economic growth, become very self-reinforcing in a negative way. Take the deficits. If policymakers continue on with current policy, if they don't do anything with the current tax rates, if they don't cut spending as agreed to as part of the sequestration, if they don't address the payroll tax holiday, you can go on and on and on, well, the nation's debt-to-GDP ratio is going to go from the current 70 percent-- and, by the way, it's doubled over the last 10 years from 35 to 70 percent-- it'll go over 100 percent by 2025. Now, all good research would show that we got a problem if that happens. The world's not going to work for us.

At some point, investors are going to balk. Interest rates are going to rise. It's going to affect investment, productivity growth, and our living standards. That has to change. And the income and wealth distribution, the forces that are driving that aren't going to - - are firmly in place, and they're not going to change. There's many. Globalization-- a great recent piece in the New York Times, going over this, globalization, technological change-- these are all really very good things for our economy. We need to continue on with the process of globalization and certainly technological change improves all our lives, but clearly it affects the distribution of income and wealth. I'm a person with no skills and talent, I'm getting creamed by trade. I'm competing against low-wage workers in China and India. I can't compete. I'm just getting crushed. And, of course, high income households are benefitting enormously, right? I mean, Glenn, Art, Bob go off to China, they go off to India, they go off to the UK to give a speech, they get paid very well.

Unfortunately, I'm not in their class, you know? I don't get paid as well. But, it's globalization that allows them to get these great returns, and their income and wealth rises. And I think the problem here is that if we don't address the skewing of the distribution and wealth, the disenfranchised are going to say, "Enough!" And they're going to stop the process of globalization, and they're going to rebel against the pace of technological change, and that's going to be to everyone's detriment, including higher income households. Now, here's the good news. We can solve this problem, and we can solve it together in a combined way. We have to think about addressing our fiscal problems through the prism of the income-- the distribution of income and wealth. So, we need to cut government spending? Absolutely. We have to do this. But, we have to do this in a way that's intelligent and maybe means-testing for entitlement programs. You know, take-- change the entitlement programs for the wealthy into insurance policies, but that only goes so far.

We don't want to go to the point where the insurance policies become a welfare program and we lose support for things like Medicare and Social Security. That'd only take us so far. So we have to address taxes. If I were king for the day, I wouldn't raise tax rates on anybody, and I don't think we need to, right? I am all for tax reform. Let's close the deductions, let's close the loopholes, let's make the tax code fairer, broaden the base, I'm all for it, but let's use the revenue to address our fiscal problems, not to cut tax rates, until we're able to do that, right? I mean, that is the best way, that is the way proposed by Simpson-Bowles, that's the way proposed by Domenici-Rivlin, and that is a bipartisan way. So this is not hard. It's-- we can do it, and that's the good news. Now, let me end this way with a personal note. I started my own company back 25 years ago with a good friend and my best friend and my brother. And I wasn't in the proverbial garage but I was pretty close. It grew into a pretty good size-- a small business.

I had 100 employees when I sold it to the Moody's Corporation. And the reason I'm telling you this is because I wanted to let you know that I'm not just an egghead. You know, I look like one maybe, but I'm not. So I look at these things through the-- in terms of data, theory, and experience. And my experience says, "You need to vote against this proposition." Thank you.

## Round 2

### Moderator
Claim: Thank you, Mark Zandi. And that concludes Round 1 of this Intelligence Squared U.S. Debate where the debaters are arguing it out over this motion: The Rich Are Taxed Enough. Now we move on to Round 2. And Round 2 is where the debaters address each other and take questions from me and from you in the audience. Our motion is this: The Rich Are Taxed Enough. We have two teams of two arguing it out. The team arguing for the motion, Glenn Hubbard and Arthur Laffer, are basically saying that taxing the rich is something that is absolutely going to backfire, that taxes have consequences on behavior, and that the wealthy, who would be the provider of jobs by being the builders of factories would be discouraged from doing so.

And that as a result of that, not only would they be able to dodge their taxes as Art Laffer pointed out by hiring lawyers and he also said hiring senators-- but they will also not be giving jobs to people who would help broaden the tax base. The side arguing against the motion, Robert Reich and Mark Zandi, are saying, "It's absolutely common sense when you have to close a budget gap to go where the money is, that you go to tax the rich because they have an-- disproportionate amount of the wealth in the country to a degree that they never have before, and that the argument that taxing the wealthy will lead to depressions and recessions has not been borne out over certain periods of time. And we know that both sides to some degree are wandering through forests of data, and each are finding their own path possibly through the same forest-- picking out different periods of time to prove their points, but I want to go to-- before we get to--

### Moderator
Claim: But that's what economists do, John.

### Moderator
Claim: Well, yeah, and it's very exciting, I have to-- before we get to the parsing of the data, I want to get to something of an overall theme. We've been talking about The Rich Are Taxed Enough. And "enough" has a couple of connotations, and one is "enough" to actually bring in revenues to pay for the government. The other is "enough" to be fair, to meet some sense of fairness. And I want to bring to the side that's arguing for the motion that The Rich Are Taxed Enough, the question of fairness. Is the system, as it is now, at tax rates that exist now, in a system that-- the one that we have, is it fair? Art Laffer.

### Conspiracy Advocate (CA)
Claim: Yeah. No, it's not. It's totally not. And let me use an example if I may, Warren Buffett. He was sitting there asking my friends and I need to have higher tax rates, and I looked at his letter to the New York Times, and he said he paid a little less than 7 million in taxes, and he said his tax rate was 17.4 percent, which I did the math, hold back, I'm a wiz, but I divided it. He had adjusted gross income of $40 million in that year.

I then went to Forbes. His wealth increased from 40 billion to 50 billion. I went to the Bill and Melinda Gates Foundation, and what you found there is he gave 1.75 billion to the Bill and Melinda Gates Foundation, not counting his sons’ foundations or his daughter's foundation. Now, as a definition of "income," to me income is what you spend, what you give away, and your increase in your wealth. It s called the Simon definition of income. If you look at Bill Gates-- I mean-- if you look at Warren Buffett, his income that year was $12 billion, and he paid 7 million in taxes. That is a tax rate of six 1/100th of 1 percent on his true income. That is obnoxious. But it's not because of any rates raising would change that tax. You've got to broaden the tax base by getting rid of all these exclusions, deductions, eliminations, and tax true income at low rates.

And that is what's fair. The guys who play the game, and you look at the Forbes 500 and you see all of them with their tax exemptions, look at all the 501c3s, all the loopholes. That's what we've got to go after, not raising tax rates on the last three people who actually pay it.

### Moderator
Claim: All right. Let me go to Bob, Bob Reich.

### Scientific Advocate (SA)
Claim: I keep on hearing my good friend Arthur Laffer talking about broadening the base. Now, do you know exactly what he's talking about when he talks about broadening the base? Because it sounds good, doesn't it? I mean, you want to broaden the base; everybody wants to broaden the base. But, Arthur, let's be specific. Are you willing to close loopholes that the very rich are mostly taking advantage of?

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: Okay, now, wait a minute. Isn't that an increase-- doesn't that mean a tax increase?

### Conspiracy Advocate (CA)
Claim: No. I'm not-- I thought we're talking about tax rate increases here. We've all gone to that it's tax rates we're talking about. Everyone wants to raise taxes by creating prosperity, it would be stupid not to.

### Scientific Advocate (SA)
Claim: Arthur, Arthur--

### Conspiracy Advocate (CA)
Claim: We are talking about tax rates here. At least me.

### Scientific Advocate (SA)
Claim: Oh, no, no, no, no, wait, wait, wait.

### Moderator
Claim: Mark Zandi.

### Scientific Advocate (SA)
Claim: Wait, wait, wait. The proposition, The Rich Are Taxed Enough. Taxed. What we're arguing is that we want to raise more tax revenue. We'd prefer to do it by broadening the tax base. I would love to do it. Now, we have to look at it from a clear eyed perspective. Can we really-- we've tried, and we've done it once or twice, to broaden the base sufficiently, to raise revenue. But, if we can't, then we raise tax rates. But everyone would agree that we want revenue, and we want to do it through broadening the tax base.

### Moderator
Claim: Let's bring in Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: Three quick points here. First of all, there's been some discussion of Bowles-Simpson, but I think it's important for everyone to understand the marginal tax-- the top marginal rate in the Bowles-Simpson compromise plan is 28 percent. And that's financed by broadening the tax base. If we have a healthy tax system, the growth that that engenders will, in fact, raise revenue, yes, but it's not by raising tax rates.

Second point, in fairness, is the OECD point that I made. If you look across industrial countries, the U.S. actually has, by far, the most progressive tax system. We rely much more on taxes that affect high income individuals that peer countries, and we do so for the reason I suggested. The third point I want to mention, if you add up all the tax increases on the rich that are currently being discussed in Washington, it's about 1 percent of GDP. The Congressional Budget Office has come up tonight. They would tell you that the long-term problem in Social Security and Medicare alone is on the order of 10 percentage points of GDP. Anybody who's selling you that taxes on the rich are going to get us out of the fiscal hole doesn't know the math.

### Scientific Advocate (SA)
Claim: Glenn, just one thing. Glenn, are you already saying-- Glenn, are you saying that the American system, compared to Europe, is more fair than any European tax system?

### Conspiracy Advocate (CA)
Claim: I'm saying it's more progressive, I think it's--

### Scientific Advocate (SA)
Claim: Is progressive fair?

### Conspiracy Advocate (CA)
Claim: We need a progressive tax system. The question is, can we balance progressivity and growth? We definitely can.

### Moderator
Claim: Robert Reich.

### Scientific Advocate (SA)
Claim: Okay. First of all, the reason that the European tax system looks more progressive than ours is because the gap between the rich and the poor in Europe is not nearly as great as it in the United States. We have the highest gap between the rich and the poor. Secondly, Arthur Laffer just admitted something that I hope you heard. That is that when you close loopholes that are taken advantage of, mostly by the rich, you are, in a sense, raising their taxes. They're actually providing more in taxes. The proposition we are debating is whether the rich are taxed enough. We are saying, Mark and I, that that is wrong. The rich are not taxed enough. If one way we use to get the rich to pay more is to close, for example, the carried interest loophole that allows private equity managers to treat their income as capital gains taxed at 15 percent, that means that Mitt Romney will be taxed more than he is now.

### Moderator
Claim: Art Laffer.

### Conspiracy Advocate (CA)
Claim: Come on. You got tax rate reduction. If you did tax rate reduction, broaden the base, and you created prosperity, of course we all want more revenues, we don't want deficits. I mean, no one wants it. How do you get it? The way you get it, by the way, is the Reagan, Kennedy, Clinton, and also Harding and Coolidge did in the U.S., lowering tax rates and creating prosperity with a broad base. That's what this proposition is. The tax rates--

### Scientific Advocate (SA)
Claim: --logical avoidance is going on on that side of the aisle.

### Moderator
Claim: Actually, I want to put that question to you, Art.

### Conspiracy Advocate (CA)
Claim: I’m bigger than you are.

### Scientific Advocate (SA)
Claim: But just barely.

### Moderator
Claim: Robert's point is that closing these loopholes would result in the wealthy paying more of their taxes is because they have more access to these loopholes now. Therefore, their taxes would be raised.

Therefore, he's saying that you're actually arguing for their side ending loopholes.

### Conspiracy Advocate (CA)
Claim: No, well, that's just not true unless it's a parallel arithmetic because the marginal tax rates are coming down at the same time. So, what you're doing is raising revenue in a more efficient way. Some individuals may pay more. And, if the economy grows, virtually everyone will pay more, and that's just fine. But, raising marginal tax rates, which has been the siren song of the tax debate, is just wrong.

### Moderator
Claim: No, can I--

### Conspiracy Advocate (CA)
Claim: Do you agree that we should lower tax rates on the rich?

### Scientific Advocate (SA)
Claim: If we generate tax revenue.

### Conspiracy Advocate (CA)
Claim: Okay. I think you just agreed with us.

### Scientific Advocate (SA)
Claim: Can I make a few points--

### Moderator
Claim: Yes, Mark Zandi?

### Scientific Advocate (SA)
Claim: --in response to some of the points that were made. First, this is my view. Glenn, I think we need to address spending. We have to. I mean, if you look at Simpson-Bowles or any proposal that's reasonable, most of the onus of addressing our fiscal problems is on the spending side. So, I'm with you on that.

But, all of these proposals also say we need to generate revenue. This has got to be a shared burden in terms of spending and tax. So, no disagreement there. The second thing I say is that if we can raise tax revenue by lowering the deductions and credits in the tax code-- and there're some very creative ways of doing it. Marty Feldstein has a great proposal. Both Governor Romney and President Obama have put proposals that are not dissimilar in this regard in terms of capping the amount of deductions and credits that an individual can take, and that would burden-- in theory, would land on higher-income households. I'm all for that. But I think it's also important that we do this in a way that we're clear-eyed, because-- in a political sense, a political economy sense-- because we know it's going to be really hard to scale back those deductions and credits in the tax code.

It's-- you know, for every credit and deduction in the code, there is a constituency that literally will go to war for it. So, we know that. So, in that context, we have to think about-- well, maybe we have to raise marginal rates to generate that revenue, to get to the point where we're going to address our long-term fiscal problems and--

### Moderator
Claim: As a temporary thing, not as a long-term principle of the way--

### Scientific Advocate (SA)
Claim: Yeah, absolutely. You can't--

### Moderator
Claim: Let's bring in Glenn Hubbard, please.

### Conspiracy Advocate (CA)
Claim: You can't do that either in the short-term or the long-term. So, let's be clear. The current budget has spending full three percentage points higher than traditional levels in the country. It is proposing to raise taxes on high-income people by 1 percent of GDP, and we just don't know what happens to the other two. In the long term, as I've said, just Social Security and Medicare alone are 10 times the cost, even of the most optimistic tax increases. So, taxes aren't even an important part of this conversation.

And, to the extent that they are, they would have to follow the European model, which is to raise them on everyone, a consumption tax.

### Moderator
Claim: Robert Reich.

### Scientific Advocate (SA)
Claim: We're getting tangled in a semantic dispute, and I want to be very, very clear about what we are actually arguing. There are two ways of raising revenues. Almost everybody up here agrees, I think, that we've got to raise some revenues. We may have to do a lot of spending reductions as well, but we've got to raise some revenues if we're going to deal with the budget deficit problem. There are two ways of doing it. One is raising marginal income tax rates, and the second is closing loopholes. Now, the question really is when you do one or both of those, are you going to have the rich paying more, or is the middle class going to have to pay more, or the poor going to have to pay more? What Mark and I are saying is that when you get more revenue, either by closing loopholes or by raising marginal rates, the rich should end up paying more as a matter of logic, as a matter of fairness, as a matter of history, as a matter of common sense.

### Moderator
Claim: All right. Art Laffer, so your opponent is saying-- this is a debate about-- this is a debate about whose hide is it going to come out of, and he's saying it needs to come out of the rich's hide.

### Conspiracy Advocate (CA)
Claim: Let's just talk about it. Of course you do. I mean-- and there's nothing wrong with the rich paying more in taxes if-- with the prosperity, which is exactly what happened, what I showed in the numbers there. During the Roaring '20s, the rich paid more as a share of GDP by lowering rates dramatically. If you look at the Kennedy period, the rich paid a lot more as a share of GDP by lowering rates dramatically. Under the Reagan/Clinton period, the rich paid a lot more by lowering rates dramatically and creating prosperity. That is the dream, and that's where we go. You cannot balance the budget on the backs of the unemployed. You just plain can't. And that's what you have to do.

### Moderator
Claim: Robert Reich.

### Scientific Advocate (SA)
Claim: I think that when Arthur Laffer, my dear friend When you just said--

### Moderator
Claim: My friend is kind of a dubious term here--

### Scientific Advocate (SA)
Claim: --when you just said that it's fine, it's fine for the rich to pay more through closing loopholes, I think you just lost-- the entire debate. But-- but beyond that, I want to point out, this is an interesting historic footnote-- Arthur, you keep going back to the 1920s, the Roaring '20s, there were two years over the last century, two years in which the richest Americans took home the highest percentage of total income in America. Those two years were 1928 and 2007. Now, does it strike anybody here interesting-- as a matter of what happens when the rich take home so much of the total income, does it strike anybody here that there may be a consequence? There may be.

### Moderator
Claim: But, Robert, how do you relate that to this motion? Land that on this motion.

### Scientific Advocate (SA)
Claim: I'm sorry?

### Moderator
Claim: Relate that point to this motion.

### Scientific Advocate (SA)
Claim: The motion should not be voted for. It's an insane motion.

### Scientific Advocate (SA)
Claim: Can I make one--

### Moderator
Claim: I think you did tonight's grandstanding but you didn't land--

### Scientific Advocate (SA)
Claim: Let me advance the ball just a little bit, and that is-- it's very important to look at effective tax rates, so that's how much I pay in tax relative to the income I earn, not the marginal rates, it's the effective tax rates. And if you look at effective tax rates across the income distribution, and not just income tax but you consider the payroll tax, you consider the incidence of corporate tax, excise taxes, you know, you roll it all up, this is data, you can go look it up, it's Congressional Budget Office data, and they have it over time, it's true that effective tax rates have fallen for everybody across the income distribution since the date it begins, 1979, 1980, but it's also true that it's fallen very significantly for higher income households.

And, in fact, interesting statistic, for the top 1 percent of earners, the decline in the effective tax rate, 1979 to 2010, has declined by more than any other income group, the effective tax rate. So you can argue, and this is often the argument you will hear, that the wealthy pay their higher share of total taxes, but the reason is because they're earning so much more income, and their effective tax rate is a lot--

### Moderator
Claim: Let's bring in Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: Yeah, again, if you look both at shares of income and shares of taxes paid, the U.S. is the most progressive, the CBO, not to get too much into the weeds here, really is not attributing the corporation income tax in any way that's really going to change those numbers, and on tax reform and growth it is certainly the case that if we broadened the base and lowered the rates we would get growth. Otherwise, why are we going to do tax reform? And that's fine, but that will raise revenue. But we are not arguing for non- revenue neutral tax changes.

It's up to you to argue that raising marginal rates, which you've referred to a few times this evening, actually is the way to go.

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: John, you asked me, "Why is it relevant that in two years, that is, 1928, and 2007, the rich took home the highest percentage of total income that they've taken--

### Moderator
Claim: That's why it's relevant to the motion.

### Scientific Advocate (SA)
Claim: --it's relevant to the motion in the following way, because behind this motion is a question about the relationship between fairness and economic growth. That's what we are discussing tonight. And my contention and the contention that I think Mark agrees with as well, is that there is not an inconsistency between fairness and economic growth. In fact, the rich would do better with a smaller share of a rapidly growing economy than a large share of an economy that's dead in the water. Why? Because it's dead in the water because the distribution of income is so crazy.

### Moderator
Claim: Yeah, but--

### Scientific Advocate (SA)
Claim: And that's why-- and that is directly relevant to the point that Arthur and Glenn are making, or are attempting to make-- and are not making actually very well--

### Moderator
Claim: Art Laffer.

### Conspiracy Advocate (CA)
Claim: There he was almost nice, but seriously, I mean, the point of it here is "Let's take the '20s that you're talking about." We had those tax cuts. We had that growth. We have the rich becoming very prosperous. There's nothing wrong with the rich being rich. The problem is when the poor are poorer. The dream has always been to make the poor rich, and during the '20s, when we had the Roaring '20s, no other country did the tax codes we did. After World War I they all stayed in depression the whole time. That is the key here. There's nothing wrong with the prosperity we had from the '80s on. But I'll tell you what happened in the 1920s-- and they paid a lot more in taxes.

### Scientific Advocate (SA)
Claim: And the exact same thing happened leading up to the crash of 2008, and that is the median wages were stuck in the mud, the-- really the growth and the gains from growth, went to the top. What happened? People in the middle, in order to maintain their standard of living, they borrowed, they borrowed, and they borrowed.

And people at the top gambled, and they gambled recklessly. And those bubbles exploded in 1929 and in 2008.

### Moderator
Claim: Again, a great applause line, but I'm not seeing how this is justifying taxing the rich. But I want to bring-- Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: Mark very helpfully, earlier, referred to a lot of structural problems facing the country. Those are problems that are subjects of another debate, but it is very important to ask the question to you, Mark, or to you, Bob, how is it that raising marginal tax rates on high income people gets at any of those structural problems? You referred to globalization, there are skill gaps among low income people, I'm not connecting the dots, from your tax policy to dealing with the problem that actually should concern America.

### Scientific Advocate (SA)
Claim: Yeah, that's a very good question. I think it's important that we address the distribution of income and wealth, because if we don't, we're going to have the situation that Arthur joked about but is very serious. And that is that the wealthy will capture the system. Art joked about buying a senator, buying a congressman. I don't think that's a joke. I mean, I think that's a very serious issue.

### Scientific Advocate (SA)
Claim: It's happening.

### Scientific Advocate (SA)
Claim: And we can't allow that to happen.

### Moderator
Claim: Agreed.

### Scientific Advocate (SA)
Claim: This is the reason why we have to be very, very conscious of this. We have to have enough revenue that goes to the government, to be able to build out the infrastructure we need. We need the revenue to go to the government sufficient to educate the population and bring the skill attainment of those workers that are getting creamed by China up, so that they can compete in a global economy. We can't do that unless we have sufficient revenue. Now, we all know revenue is very low, 17 percent of GDP. Since 1980, the revenue to GDP ratio was averaged 19.5 percent.

It's very, very low. Government spending is high. I'm all for getting government spending down. I think that's absolutely correct, but we also have to, in a balanced way, get revenue up--

### Moderator
Claim: Mark, can I bring--

### Scientific Advocate (SA)
Claim: Can I make one other point? I have to make one other point.

### Moderator
Claim: Sure, yeah.

### Scientific Advocate (SA)
Claim: Because this goes right to Arthur's--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: You know, Arthur, you may be right. You know, you may be right--

### Scientific Advocate (SA)
Claim: Don't me. We don't have to

### Scientific Advocate (SA)
Claim: This is very important. You know, you argue lower tax rates improve economic growth, all else being equal. And, you know, I have some sympathy to that argument when we're lowering tax rates from 90 percent, which is what they were when Kennedy took office and we lowered them to 70. And Ronald Reagan took them from 70 to 28. You know, the academic literature on this, frankly, is not clear. There's no proof academically, but, okay, I'm sympathetic to the idea. But what I think is prudent-- if I were a prudent planner, and if I was sitting at the ONB or the CBO, I'd say, "You know what? We better-- if we raise taxes or lower tax rates, if we move tax rates, if we move tax rates-- we better think about this in an accounting sense, not in, we can generate some economic growth and that's going to generate revenue, and, by the way, the kids are going to be dancing in the streets and eating chocolate bars.

You know, that's not what we should be doing. We should be thinking about this in a purely accounting-- well, and if it all works out and you're right, that's gravy, we're fine.

### Conspiracy Advocate (CA)
Claim: And it will and I am.

### Moderator
Claim: Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: I think it's important to know that there is actually a lot of work in economics, and pretty conclusive about the positive effects of tax reform. It's one of the few not--

### Scientific Advocate (SA)
Claim: No one’s arguing tax reform, Glenn. No one's arguing.

### Moderator
Claim: We are.

### Conspiracy Advocate (CA)
Claim: Lowering rates, broadening the base, that's one of the most fundamental results in economics. And I think the beauty has been-- or the difficultly, the politicians are normally scared. But, frankly, as an economic matter, I don't think it's controversial. If you had the size of government that we had before the financial crisis, the normally functioning tax system would, roughly, fund that size of government.

If you'd like, in your description of more for education and more for infrastructure, if what you mean is, you'd like a bigger government--

### Scientific Advocate (SA)
Claim: No.

### Conspiracy Advocate (CA)
Claim: I'll come back to the point I made before, you can't fund that on taxing the rich. That's just math.

### Moderator
Claim: Why not? Why not?

### Conspiracy Advocate (CA)
Claim: Because the-- if you look at all of the tax increases that are currently being proposed, and I haven’t heard any politician on the left say they'd like even more, that's about 1 percent of GDP. The present budget has an elevated spending level of more than 3 percent of GDP, and that's before the entitlement programs--

### Moderator
Claim: But isn't there still a lot of upward room to raise rates on the rich, other than what's proposed now?

### Conspiracy Advocate (CA)
Claim: I think there's a lot of pushback, both from economists, and probably more important, from politicians, on the tax increases that are being proposed now.

### Scientific Advocate (SA)
Claim: Why is there pushback from politicians on increasing the taxes on the rich or closing loopholes that the rich take advantage of, it's because of the increasing political power of many of those same rich.

That is the closed system we are dealing with. That is one of the reasons that you've got to start addressing this issue of inequality.

### Moderator
Claim: Art Laffer.

### Conspiracy Advocate (CA)
Claim: These are exactly the problems we had in '86, and that's exactly what we did. We took all of these loopholes and dumped them all, and we got a broader base. Reagan said he would not-- he would veto the bill if it were either tax-raising or tax-lowering. It was a tax reform bill that went across. We lowered the highest rate from 50 percent to 28 percent. And, in the Senate, we got 97 votes, three against us, and all these others voted with us. It was obvious for all those politicians. And they did it. It's quite obvious right now as well.

### Scientific Advocate (SA)
Claim: John, can I just--

### Moderator
Claim: Yeah, Mark Zandi.

### Scientific Advocate (SA)
Claim: --I just want to present some numbers. These are just accounting. It comes from Simpson-Bowles.

### Moderator
Claim: Not a ton of numbers.

### Scientific Advocate (SA)
Claim: Okay. It's pretty straight-forward.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: Now, under Simpson-Bowles, to achieve something-- what you might call fiscal sustainability, that is deficits in the future that are small enough that our debt-to-GDP ratio stabilizes, but the---- a little bit of arithmetic, we need $3 trillion of deficit reduction over 10 years. You know, we can debate the number, but let's go with it. Simpson-Bowles would say, Dominici-Rivlin would say let's do $2 trillion in government spending, let's get $1 trillion in tax revenue, right? And they would say, "Let's do the tax revenue by broadening the base, but if we can't broaden the base, we got to get the revenue from somewhere, right?" And if you do those things then, then-- Glenn-- then the expenditure-to-GDP ratio goes to 21 percent-- that's the average since 1980-- and the revenue-to-GDP goes to 19 percent. That's the average to 1980.

### Conspiracy Advocate (CA)
Claim: That's actually-- let me just correct the numbers. Bowles-Simpson actually would raise - -

### Moderator
Claim: Is everybody getting this down?

### Conspiracy Advocate (CA)
Claim: This is when economists really get down and dirty.

### Moderator
Claim: I know, I know. It's a problem.

### Moderator
Claim: The Bowles-Simpson would raise two percentage points of GDP in revenue to fund a 21 percent government, but it's important again to understand that Bowles-Simpson is delivering marginal rates at Reagan-era levels.

There wasn't any discussion in Bowles-Simpson of, "Oh, well, if we can't do this, we'll do that." Bowles-Simpson is a classic broaden the base, lower the rate.

### Moderator
Claim: Let me pull something out, let me pull something out--

### Scientific Advocate (SA)
Claim: It's $1 trillion in revenue--

### Moderator
Claim: Gentlemen, let me pull something out of the exchange we've just been through and bring to Mark Zandi. Basically, Glenn Hubbard was saying that he understood what your aspirations were for funding certain kinds of government programs that would be restorative of education, et cetera, and he said that you can't get it from the wealthy, that if-- politically, you can't get it, you can't raise rates to that degree for the reason that Bob gave because it's a closed loop. I want to know economically could you get it, because their argument is that economically you can't because the behavior of the wealthy would change in such a way that they just wouldn't-- they wouldn't participate. Number one, they wouldn't participate-- they would move their money offshore, and they wouldn't invest here. And that's kind of the core of their argument. Can you take that on?

### Scientific Advocate (SA)
Claim: Yeah. I mean, I don't think that-- first of all, I think the best way of approaching this is broadening the tax base.

That's-- I'm on board with that. But if we have to go down-- if we can't raise the revenue, the trillion in revenue through tax broadening, I'm all for raising marginal rates. But, when I talk about raising marginal rates, I'm talking about putting them back to the era when this fellow was labor secretary and generating 22 million jobs. I'm talking about 35 percent today to 39.6 percent on personal income. And you can-- we can talk about cap gains and dividend income and so forth and Obamacare and health care tax, all those kinds of things--those kinds of things will generate a trillion in revenue. And I don't think-- and, again, this is my view, experience-- I don't thinkthe American wealthy are going to move offshore and not pay their taxes.

### Scientific Advocate (SA)
Claim: We know that they aren't. We know that they aren't because there have been a number of experiments. One experiment is an experiment that we ran in this country between 1946 and 1981 when tax rates, as I said before-- officially, marginal tax rates were at least 70 percent, and the effective rate after deductions and tax credits was about 54, 55, 56 percent.

Maybe it was slightly more difficult then to move abroad or shift your money abroad, that's true, but also legally we could have then, as we can now, make it very difficult to do that. The real issue here-- and, Glenn, what you keep on wanting to do, and Art, you do too-- is you are saying in effect we ought to broaden the base and not raise marginal rates.

### Moderator
Claim: Lower.

### Scientific Advocate (SA)
Claim: And what you-- yeah, and what you're hearing from us is we're happy to do whatever you want to do to raise revenues, that is close the loopholes or raise the rates-- as long as most of those revenues come from the people who are best situated to bear the burden, and that is the rich who are richer now than they've ever been as a proportion of total income.

Now, if you agree with us, then this proposition--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --you have to vote against--

### Moderator
Claim: I want to let Glenn Hubbard respond to that, but I-- right after his answer, I'm going to come to you for questions so prepare terse focused questions on this motion, and we'll be delighted to have you participate. Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: Three quick points, first of all, again--

### Moderator
Claim: You don’t have to be that quick. He was pretty--

### Conspiracy Advocate (CA)
Claim: Yeah, well, what Art and I are arguing is to the extent that revenues come from faster growth from a reform system, we're fine for that. You keep moving the goalposts, but you're talking about marginal rates and not that. Second, there are significant real effects of raising taxes on business owners. There's a huge body of research out there. You might not like it, but it is there. And the third-- the question to you about your aspirations, again, Social Security and Medicare, these two programs are on track to rise 10 percentage points of GDP.

Now, if you want to tax, finance that, you mentioned that a healthy--

### Scientific Advocate (SA)
Claim: I don't.

### Conspiracy Advocate (CA)
Claim: --healthy revenue share in GDP is 19 percent, you'd have to raise every tax--

### Scientific Advocate (SA)
Claim: It's a red herring. It's a red herring. I don't.

### Conspiracy Advocate (CA)
Claim: You can't get there from here.

### Scientific Advocate (SA)
Claim: I agree with you. We need entitlement reform and we need spending cuts. I'm on board with that.

### Moderator
Claim: Let's go to some questions from the audience. And, sir, right down-- yeah, right there, yeah. And if you wait for a pause so the camera can find you, and it would help actually if you could step out to your left just so that you're bright-- in the brighter light, and let us know your name and really a good question.

### Moderator
Claim: I’m from Columbia Business School, the question is for Mr. Laffer.

### Scientific Advocate (SA)
Claim: Hey, hey, hey, is this fair?

### Conspiracy Advocate (CA)
Claim: We're everywhere.

### Moderator
Claim: Wait till you hear the question. My question is to Mr. Laffer, he just took the example of Warren Buffett, who's on a stated income of 40 million paid 7 million in taxes, whereas you think his income was 12 billion.

So if whichever way, the loopholes are closed or the rates increase, don't you think the rich man should be paying more and, therefore, don't you think this motion--

### Conspiracy Advocate (CA)
Claim: Warren is a Columbia Business School graduate. That’s how you answer this question.

### Moderator
Claim: Art Laffer, take that question.

### Conspiracy Advocate (CA)
Claim: But let me answer two things, there are two ways of raising revenues. One is to broaden the base and one is to lower rates, not raise them. And that is the way to get your prosperity. As you looked at every time, you go back to the Kennedy period where rates were much higher and all that, when Kennedy lowered those rates, guess what happened to revenues? They went up as a share of GDP, not down from the top 1 percent of income earners. Not only did those revenues go up, but there were secondary and tertiary rate-- revenues going in, for the jobs that they created the output, the employment, the production, all of that. They're huge revenue raisers.

That is not true of any other income group. It's not. You raise tax rates on the poor or the middle income and you collect more revenues, but not on the rich. You want more revenues from the rich, which I do, what you do is you broaden the base and you lower the rates, and both of those will bring you more revenue, period.

### Scientific Advocate (SA)
Claim: How low would you lower them? How low would you go?

### Conspiracy Advocate (CA)
Claim: Well, it doesn't go to zero, let's put it there.

### Scientific Advocate (SA)
Claim: to zero?

### Conspiracy Advocate (CA)
Claim: I will stipulate today--

### Scientific Advocate (SA)
Claim: Bowles-Simpson seems that 28 percent--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: --seems like a good place.

### Conspiracy Advocate (CA)
Claim: And, you know, we did an '86 down to 28 percent. That's a good number, or leave it where it is.

### Scientific Advocate (SA)
Claim: Why not lower, though?

### Conspiracy Advocate (CA)
Claim: How about--

### Scientific Advocate (SA)
Claim: Why not?

### Conspiracy Advocate (CA)
Claim: You could maybe go lower.

### Scientific Advocate (SA)
Claim: I’m asking you Art. Why not 15 percent?

### Conspiracy Advocate (CA)
Claim: If you broaden the base enough--

### Scientific Advocate (SA)
Claim: Why not 10? Why not 5?

### Conspiracy Advocate (CA)
Claim: --if you were-- I mean, I will-- none of you guys will agree with me here, but if you taxes unrealized capital gains and raise the bases, you could get it really low. If you wouldn't allow all the 501c3s and have football tickets at Oklahoma, be tax exempt, I think you'd get it really low. There's a huge amount of income out there that is not taxed at all, that.

And then you lower the rate like I did with Gerry Brown--

### Moderator
Claim: And I want to go to another question. Rob Reich.

### Scientific Advocate (SA)
Claim: The question before the House is not, "Do you broaden the base? And do you raise or lower marginal rates?" The question is, should the rich pay more or are the rich taxed enough? Now, let's take an example. Take the mortgage interest deduction, which is the most sacred of sacred cows. Now, here is what we know about the mortgage interest deduction. Mortgage interest deduction is essentially a subsidy for housing, but who gets the lion's share of the benefit of the mortgage interest deduction? Well, here's what we know, that four times more of that subsidy goes to the top 20 percent of Americans, than the total amount of public housing assistance that goes to the bottom 20 percent of Americans. So why not limit the total mortgage interest deduction per year, to something like, let's say, $10,000 per year.

Why not limit other deductions to, say, a total of $10,000 or $12,000 a year. You-- if you do that, you are increasing revenues from the rich. If you do that, you are actually voting against the proposition.

### Moderator
Claim: All right. I want to go to another question, but, first, I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have two teams of two who are arguing it out over this motion: The Rich Are Taxed Enough. Another question from the audience. Right down the front here.

### Moderator
Claim: I'm Jackie Hotlier I wanted to direct this question to you guys, with respect to--

### Moderator
Claim: You want to address to the side arguing against the motion?

### Moderator
Claim: Yes, the con side. I wanted to know what you guys think about small businesses, are they really going to be affected if the tax rate increases?

### Scientific Advocate (SA)
Claim: I love small businesses. My father was a small businessman. He was small and he was a small businessman. But, look, if we, for example, as a nation decide that next year we are going to continue the Bush tax cuts for people earning under $250,000, but the income over $250,000 is going to go back to the Clinton kind of rates, is that going to be such a huge burden for small businesses? Well, only about 2 to 3 percent of the small businesses earn over $250,000. And we're only talking about that amount of income over $250,000, so a small businessperson who earns $251,000 that year is only going to be paying the Clinton rate on $1,000 of income. And, by the way, that Clinton rate was not so onerous; small businesses did much better under Bill Clinton than they've doing recently over the last 10 years.

### Moderator
Claim: Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: The reference to small numbers, small businesses being at the top misses the fact that about half of the people in the top 1 percent are business owners. And, if you look at the calculation that I made for you, if you compare what's going to happen to investment and hiring by those individuals as they're paying taxes at individual rates, you're looking at changes on the order of 50 percent in investment, 14 percent in hiring, in an era when the economy is struggling. You know, there's a reason the president took a pass on raising marginal rates the last time.

### Moderator
Claim: Okay, another question.

### Scientific Advocate (SA)
Claim: John, can I?

### Moderator
Claim: Oh, sure. Mark Zandi.

### Scientific Advocate (SA)
Claim: Just to reinforce the point, this is why I told you my story about being the egghead entrepreneur, because I was an S chapter corporation, I was one of those of folks in the top 3 percent.

And my experience says, no, it doesn't matter. I'm driven by lots of other things and raising marginal rates from 35 to 40 or 45, it's not going to make a difference in terms of my thinking. So, no. My experience-- and I don't think the data suggests that this is going to have a significant impact. One other thing about small business that I just think it's very important to point out, that most small businesses are proprietorships, they're professionals like doctors and dentists, plumbers, electricians, they're not making $250,000, they're not going to be affected by this. The folks that are going to be affected by this are, you know, they're hedge fund owners, they're different kinds of small businesses that, they're motivated by different things. So when people talk about small business, they have some-- they're thinking about something totally different than the folks that will be affected by the higher marginal rates that we're talking about here.

### Moderator
Claim: Okay. Ma’am. Thanks. Could you stand up? Thank you. Just so we can you with the camera.

### Moderator
Claim: If it was up to me--

### Moderator
Claim: And would you mind telling us your name, also?

### Moderator
Claim: My name is Reba Shemanski If it was up to me, I'd love the marginal tax rate to go back to 91 percent; however, most wealthy people don't pay the marginal tax rate, they get paid in capital gains or carried interests, like your guy, Mitt Romney. Therefore, don't you feel that the capital gains tax--

### Conspiracy Advocate (CA)
Claim: Actually, he gets dividends, but that’s okay--

### Moderator
Claim: Don't you think-- please let me finish. Don't you think the capital gains tax should equal the marginal tax rate? And doesn't Mitt Romney feel guilty that he pays the same--

### Moderator
Claim: All right, all right, all right. You've just disqualified yourself. I'm going to take another question, because we're not playing it that way. Sir, right there.

### Moderator
Claim: My name is John Goldberg. The question is to Mr. Hubbard and Mr. Laffer. How much do you think that the social contract sort of justice or moral element should play into the conversation?

And, to be specific, at one of the debates Mr. Romney said that he still wants the top 5 percent to pay 60 percent of collections. Do you think that is the right number? Should it not go up from there? Which is, I think--

### Moderator
Claim: Do you mind-- and there reason I say this is that this debate will, we hope, will live on for months and be heard-- to rephrase your question without actually needing to make the reference to the recent debate, because I think you can and it would let us use this question.

### Moderator
Claim: Okay.

### Moderator
Claim: Thanks.

### Moderator
Claim: So, the question is, I guess, I've heard that the top 5 percent of these earners-- produce 60 percent of the collections. Do you think that's about the right number?

### Conspiracy Advocate (CA)
Claim: There's no question from a tax fairness or social justice point of view that we need a progressive tax system.

The wealthy in our society should pay a disproportionate share of the tax burden, and I don't think any serious-- at least economist-- has suggested otherwise. But, to me, there's a strong element of social justice that's forgotten in that conversation, and this goes back to the conversation Mark and I were having earlier. We really need a society that helps put people back on the ladder, and that's not a discussion of whose marginal tax rate is X or Y, but a discussion of how as a country we're going to help those people succeed. That's the social justice.

### Moderator
Claim: Bob Reich.

### Scientific Advocate (SA)
Claim: But I think that-- I think Glenn-- here I want to use the opportunity I have, we have, to agree. You're exactly right, Glenn. We want an economy and a society that enables everybody to have an opportunity to make the most of themselves and to go up that ladder. But, as the gap grows, what we are finding is that upward mobility in America is slowing.

In fact, relative to places like Canada, we have a much slower degree of upward mobility. The chances that a poor kid is going to be a poor adult is greater in the United States than it is-- not only in Canada, but greater than in Germany, greater than in most of Europe, greater than in every place in rich nations other than Britain and Italy.

### Moderator
Claim: Is it tax-related, this--

### Scientific Advocate (SA)
Claim: It is tax-related, of course it's tax-related, because if we didn't have the problem of upward mobility, that is, if people could easily move upward, than the issue of inequality and the moral essence of what we are talking about would not be as difficult.

### Moderator
Claim: But is the tax system a solution? Is it--

### Scientific Advocate (SA)
Claim: The reason that this proposition is ludicrous and why everybody should vote against it is because we have a system right now where the dice are loaded.

They're loaded in favor of people who--

### Moderator
Claim: But are you arguing to use the tax system to unload the dice?

### Scientific Advocate (SA)
Claim: Well, two ways. Now, Mark said before-- and I think it's a very important point-- that if we are going to have enough revenues to ensure that every child in America has an adequate education, not only K through 12, but hopefully early childhood education, hopefully access to a good public university or even private university-- if education is going to be back to where it was in the 1950s, '60s, and '70s in terms of quality for every young child, that is going to take, whether we want it or not, that's going to take some money to do. And if the rich are not going to pitch in, we are not going to be able to do it.

### Moderator
Claim: Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: First of all, it's useful to know that the tax system in the U.S. does actually lean against in a very powerful way some of the forces that Bob and Mark have mentioned.

I've already mentioned that in the context of the OECD. It's also the case, though, that there's a pretty poor link between changing marginal tax rates at the top and accomplishing much of any of this. It's really a question of setting priorities in government. Do we want to be a country that has a few entitlement programs that have all of our spending dollars, or do we want to invest in the future? That's a very legitimate discussion, but it has nothing to do with taxing the rich.

### Moderator
Claim: Mark Zandi.

### Scientific Advocate (SA)
Claim: Yeah, I-- I want to get to a point that Glenn has been making, and it's a reasonable one. The tax code does help reduce the skewing of the distribution of income and wealth. If you look at the so-called Gini Coefficient-- another-- I'm sorry, but this is very easy. So, Gini Coefficient, best way to measure the income distribution. If it's zero, you've got everyone getting the same income. If it's 1, that's bad. One person's getting all the income. So, the Gini Coefficient pre-tax is-- back in 1980 was .38. Today it's .48.

So that means the distribution of income is getting wider. Take the tax code, run it through, calculate the Gini Coefficient, we now go from .34 to .44. So, yeah, it did, in fact, reduce the skewing of the distribution of income and wealth, but the point is the skewing is still very significant and getting wider by the day. And this is a very significant problem. Our Tax Code really hasn't helped with that issue.

### Conspiracy Advocate (CA)
Claim: But put differently, the skewing is a pretax phenomenon. It relates to real phenomena out there in the world, and we can address those phenomena –

### Scientific Advocate (SA)
Claim: This is my point, this is the key point-- we have a fiscal problem, we have to address the fiscal problem, we have to do that by looking-- addressing the fiscal problem through the prism of what it means for the distribution of income and wealth. We cannot ignore that. When we think about government spending, and government spending cutbacks, and tax revenue, we have to think about it in the context of tax revenue.

### Conspiracy Advocate (CA)
Claim: But you got to think of it in dynamic terms. That's what you've got to do is what it does to the growth path, what it does to the poverty, unemployment. Never before have so many people been so unemployed as they are amongst the poor, amongst the minorities. You know, it's just shocking, what's happening today because of the growth being lost. We've got to achieve the income distribution we want and the prosperity-- through growth.

### Moderator
Claim: Arthur, I have a tweeted question from a Josh Wolinsky, who is asking about trading off the capital gains tax versus the income tax. And he's basically saying, "Should rates be lowered-- should rates be raised on income that comes from buying and selling stuff versus lowered on people who actually make stuff for a living?"

### Conspiracy Advocate (CA)
Claim: Well, my view is it should be flat rate across the board, just the way it was-- we raised capital gains tax rate in 1986 from 20 to 28 percent.

We made it the same as every other. I think that's the way you should go. I think you should get it so that all forms of income are the same.

### Conspiracy Advocate (CA)
Claim: Okay, that's not the view of the rest of the table, just so there's no misconception.

### Conspiracy Advocate (CA)
Claim: But that's true. I am truly for a flat tax across the board, and get the hell out of the way, and let people produce--

### Conspiracy Advocate (CA)
Claim: The optimal tax on savings is zero.

### Moderator
Claim: I’m Carl Pope and Dr. Hubbard I sense a deal, and I want to offer you the deal, but I think the other side would take, but I'm not certain you would. The four of you together come up with $2 trillion in cuts, you each have $500 billion, but you come up with $2 trillion together, you and Dr. Laffer then have to come up with some package of your choosing, unhampered by politics, of a trillion dollars from cutting marginal rates, closing loopholes, whatever you like, with the sole condition being that the trillion dollars has to be paid by the upper 1 percent and then--

### Moderator
Claim: I need you to zoom in for a landing here.

### Moderator
Claim: Okay. And-- all of the additional revenues which result from Dr. Laffer's anticipated growth, if you do it right, the four of you each get to spend a quarter of it either on the deficit or more federal spending.

### Moderator
Claim: Okay--

### Moderator
Claim: But would you take that deal?

### Moderator
Claim: I didn't understand your question.

### Conspiracy Advocate (CA)
Claim: Well, if I understand the question--

--then I can give a pretty simple answer to it. There's a recent study that Harvey Rosen, who's a professor at Princeton, has done, it is possible to lower marginal tax rates substantially, broaden the base, get down to a 28 percent rate, with the growth, still have the high income people pay exactly the same tax share, that is, the money is coming from them, if that was your question, that's the answer.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: Wait a minute. Wait a minute.

### Moderator
Claim: Everybody got the question but me--

### Scientific Advocate (SA)
Claim: It's getting close to the core of the issue.

### Scientific Advocate (SA)
Claim: The issue is not broadening the tax base and lowering the rates so the wealthy pay the same as they're paying now. The question is shouldn't the wealthy be paying a larger share? And what Mark and I have been arguing is that you have got to. If you are talking about getting the deficit down, reducing the debt, not only do you have to cut federal spending, you also have to rely on some net increase in revenues. And that net increase in revenues we believe should come primarily-- whether it's base broadening or rate increasing it should come primarily from the wealthy. And if you agree with us, then you think this proposition is wrong.

### Conspiracy Advocate (CA)
Claim: Let me just say--

### Conspiracy Advocate (CA)
Claim: You've moved the goalpost several times tonight, but it is the case that--

### Moderator
Claim: in the middle here. Gentleman in the-- a blue necktie. Thank you.

### Moderator
Claim: Thank you. My name is Phil Melville A question, broadly, for the group. I think you all believe growth is good, but I would like to understand that--

### Scientific Advocate (SA)
Claim: I'm not sure about Art on that one.

### Moderator
Claim: But the IMF recently put out a paper talking about multipliers, that tax increases have a great impact on the economy than spending cuts. Do you believe that's true? And, if so, particularly to Mr. Zandi, why would you advocate increasing taxes when it'd have a disproportionate effect on the economy?

### Moderator
Claim: Mark Zandi.

### Scientific Advocate (SA)
Claim: Well, to be clear and just to repeat myself, I'm all for raising tax revenue from broadening the tax base. I would prefer not to raise tax rates on anybody, I'd like to even cut them. And, in fact, if we broaden the base enough, Art's right, we can lower the tax rates and generate revenue, and that has to come from higher income households. So let's just make that very clear. Now, if we're debating the impacts of taxes and spending, it's just the opposite. I mean, my view is, the spending multipliers are larger than the tax multipliers, in general, on average.

You know, it depends on the situation, the tax, and the spending, so forth and so on. But, you know, on average that's the case. Spending multipliers are larger. Now-- but you've heard me before say, I think most of the onus of deficit reduction and achieving fiscal sustainability has to be on the spending cuts, because if you look, again, at current spending and current revenue, it's mostly the spending that's out of line, relative to our historical norms. And we have to get the spending down. And--

### Moderator
Claim: Let's let Glenn Hubbard--

### Scientific Advocate (SA)
Claim: And Glenn is right, in the longer run, 10, 20, 30 years, we have to address our entitlement programs. That's what's going to kill us. But we could also-- and I'll end here-- we also should do that through the prism of what it means for the distribution of income and wealth.

### Moderator
Claim: Glenn Hubbard.

### Conspiracy Advocate (CA)
Claim: I like your question a lot, because sometimes we slip into the use of a word like deficit, which is an accounting term, when what we really mean is taxes and spending.

Now, your question gets to the core of why it's important to separate those two parts. There's a big difference between changing the path of fiscal policy by raising taxes and cutting spending. And I think the bulk of the evidence would suggest, yes, that the tax increase way would be more costly on the multipliers. I'll tout my intermediate macro textbook, you can turn to the table of multipliers and you'll see that point pretty much from the literature.

### Moderator
Claim: One more question, sir.

### Moderator
Claim: Hi, Van Greenfield. When I listen to all these numbers, I'm kind of reminded of, I guess it was Twain, we have liars, damned liars, and statistics. And it seems like, probably either of you could argue the other person's point. But the question I have is really to the con side, and that is, it seems to me the fundamental question was raised by Glenn at the beginning, which is, what is the size of government that you want?

And I'd like to, kind of, move the debate, or move the question, back to what Bob was originally talking about, I think, when he was talking about sufficiency and fairness--

### Moderator
Claim: I need-- I'm sorry, I need you to repeat the question.

### Moderator
Claim: What is your position on the fundamental question that Glenn raised, which is, the real issue is the size of government, in terms of fairness--

### Moderator
Claim: I'm going to pass on that because that's not the issue that we're actually-- I understand that it's related, and I understand it was sandwiched into your argument, but I really want to have a question that provokes more of an understanding of this issue of whose hide is the money supposed to come out of. Ma'am, right in the middle there. Thank you, with respect. You need a microphone to come to you.

### Moderator
Claim: I think I'm okay.

### Moderator
Claim: No, no. The radio needs the microphone. You'll sound like a voice off in the distance and people will wonder what's wrong with that woman.

### Moderator
Claim: My name is and I'd like to know who's the broader base? What is encompassed in this broadening base that we keep talking about?

### Moderator
Claim: Okay. Art Laffer.

### Scientific Advocate (SA)
Claim: That's a great question. That's exactly-- That's exactly what we have been debating, and you can broaden--

### Moderator
Claim: It's Art Laffer's turn to talk.

### Conspiracy Advocate (CA)
Claim: My turn?

### Moderator
Claim: And it will be your turn right after that, Robert.

### Conspiracy Advocate (CA)
Claim: I did Jerry Brown's flat tax when he ran for president in 1992, we got rid of all federal taxes. You should look at every tax, not just income taxes. We got rid of the income taxes, corporate taxes, payroll taxes, employer and employee; we got rid of excise taxes, capital gains, estate taxes, tariffs. And the only ones we left were sin taxes, which are really small. And, in there, said we had two flat rates, one of business net sales, value added, and one on personal unadjusted gross income. If you did that at full employment, you could have a flat tax rate of 11.8 percent and have it statically revenue-neutral, that's it. You end up--

### Moderator
Claim: So who's in the--

### Moderator
Claim: Who's in the base that's been broadened?

### Conspiracy Advocate (CA)
Claim: Everyone's in the base. They're all forms, where you tax Warren Buffett on his $12 billion income that year, not on $40 million, which is what he had in his AGI after all the legal tax deductions.

### Moderator
Claim: But the mom living on $20,000 who needs to buy her cigarettes would also--

### Conspiracy Advocate (CA)
Claim: What?

### Moderator
Claim: The mom living on $20,000 with four kids who wants to buy cigarettes--

### Conspiracy Advocate (CA)
Claim: Yeah, but she'd have a job. That's the whole point. Come on.

### Moderator
Claim: Bob Reich.

### Conspiracy Advocate (CA)
Claim: I don't mind her paying for her cigarettes.

### Moderator
Claim: Bob Reich.

### Scientific Advocate (SA)
Claim: I want to talk to your question, because much of this debate has been about exactly that. What do we mean when we talk about broadening the base? And the reality is that average Americans, most people-- when they fill out their income taxes, they don't itemize their deductions. The wealthy have a lot of itemized deductions. They take-- I have a lot of tax credits.

They use a lot of-- accountants and tax planners who are taking advantage of every single possibility. So, if you are broadening the base in such a way that you are closing some of those opportunities for tax avoidance or tax mitigation, and the net effect is that the wealthy end up paying more than they were paying before, then you are increasing their taxes, and they are, in a sense, generating more revenues. And, if you support that, you don't support tonight's proposition.

### Moderator
Claim: Glenn Hubbard, I need you to be terse, because we're out of time.

### Conspiracy Advocate (CA)
Claim: Yeah, basically, just to try to really answer your question. There are two things that are on the table being discussed, I think, by tax reformers. One would be some sort of cap on deductions-- that could be a dollar, that could be a percentage of your income. Another would be an approach Bowles-Simpson took, which really cut back a lot on the deductions of affluent people, but left the more in place for moderate income people.

Either one of those would get you there.

### Scientific Advocate (SA)
Claim: Can I say just--

### Moderator
Claim: All right-- very-- you've got 10 seconds.

### Scientific Advocate (SA)
Claim: Yeah, really important question, because you have to really think about what we're talking about here. Mortgage interest deduction, charitable giving, state and local income taxes, property taxes, you get deductions for education--

### Moderator
Claim: One second.

### Scientific Advocate (SA)
Claim: --medical care, all kinds of--

### Moderator
Claim: Mark, I have to interrupt you.

### Scientific Advocate (SA)
Claim: And that's why it's so difficult to do it.

### Moderator
Claim: But you're cutting rates at the same time.

Yeah.

## Round 3

### Moderator
Claim: Ladies and gentlemen, this concludes Round 2 of this Intelligence Squared U.S. debate. And now we go on to Round 3. Round 3. Closing statements by each debater in turn. They will be two minutes each. It is their last chance to try to change your mind before you vote for the second time and choose the winner of this debate. Our motion is The Rich Are Taxed Enough. And here to summarize his position against the motion, Robert Reich. He is a professor at UC Berkeley and former Secretary of Labor in the Clinton administration.

Let's make that an applause line. That would be nice. No, no, no, no, no. I have to be saying it as-- there needs to be some overlap, so let's do that again. Thank you for your patience on this. I'm the one who messed it up, not you. Summarizing his position against the motion, Robert Reich, professor at UC Berkeley and former Secretary of Labor in the Clinton administration.

### Scientific Advocate (SA)
Claim: Well, this has been a great debate, and Glenn-- I've enjoyed enormously listening to you and trying to respond to you and besting your arguments. And Arthur Laffer, you are a dear, old friend, and you are as wrong as you always have been. And Mark Zandi, you are brilliant. let me just say, I think that if you look at the proposition here that we are debating tonight, the proposition is simply that the rich are taxed enough, and what Mark and I have been saying, whether you couch it in terms of closing loopholes, broadening the base, increasing marginal income taxes, doesn't matter how you cook it, the still of the question is given that we have a huge budget deficit, somebody has got to pay a little bit more, even if you do a huge amount of cutting of the budget and cutting spending, you still are going to have to raise some revenues. No matter what your ideology is, you're still going to have to raise some revenues. And if you believe, as I do and as Mark does, that the rich should bear the lion's share of that revenue raising, then you've got to, please, for the good of your children and your grandchildren-- For the good of America, as solid patriots, you have got to vote against this proposition, because it is, in its entirety, given where we are in this country right now, given the challenges we face, this proposition is simply and unalterably ludicrous.

### Moderator
Claim: Thank you, Robert Reich.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Our motion is: The Rich Are Taxed Enough. And here to summarize his position in support of the motion is Glenn Hubbard. He is the dean of Columbia Business School and economic advisor to Mitt Romney.

### Conspiracy Advocate (CA)
Claim: Thank you. You know, just as Oliver Wendell Holmes famously observed, that paying taxes is actually the price we pay for living in a civilized society. And a civilized society defends itself, it educates its citizens, it cares for those in need, but it's also got to be a society of opportunity and growth, a society of entrepreneurs and businesses, of seeing the fruits of one's own investment in time and in talents, of encouraging investment for tomorrow and not just consumption for today.

Tonight Art and I have argued that confiscatory success taxes are wrongheaded, but they're also wrong. I'd ask two questions of our partners tonight. First, what evidence suggests that the economic consequences of higher tax rates on the successful could improve the employment or the income prospects of the rest? And, second, is the nation better off by raising tax rates on high income people or by balancing fairness and prosperity, asking sacrifice from the affluent through the growth consequences of tax reform, and reforming our spending programs to be a safety net? The question at hand tonight is a broad one and an important one. This country has long identified with equality of opportunity. And I worry a lot right now in our country about economic opportunity.

I'm fond of an example that illustrates my worry with an image of the nation as a tall building with the bottom flooded out, the penthouse doing fine, and the elevator broken. We could throw rocks at the top or we could fix the elevator. I think most Americans make the latter choice viscerally. And to the points Art and I have made tonight, throwing rocks doesn't fix the elevator, and to torture the analogy, can't pay for it. We need to think about growth and fairness. The case for the proposition tonight is very strong. Tax rates should not rise. The rich are taxed enough.

### Moderator
Claim: Thank you, Glenn Hubbard. Our motion: The Rich Are Taxed Enough. And here to summarize his position against the motion, Mark Zandi, chief economist at Moodys Analytics.

### Scientific Advocate (SA)
Claim: Well, John, I think-- thank you. John, I want to thank you for moderating a great debate. And I really do want to thank Glenn and Art for being good counterweights here. And, Bob, thanks for that great comment.

Thank you. I appreciate that. Take that with me. And you're a great guy, too, by the way. Hey, you know, I actually am cheered by our conversation. It sounds like we were hitting each other over the head. To some degree we were mostly about hitting Art over the head. But I think there's a lot of commonality here. I think there's a lot of agreement. I think we agree that our fiscal problems need to be addressed, that these are key to our long term economic success. I think we agree that the distribution of income and wealth is a problem, you know, we're debating a little bit about how we should approach that. But I think we view that as a problem. I think we agree that to address these problems that we do need to cut back on future government spending, that the entitlement programs do need reform, and we do need to think about it in the context of who's going to pay for that reform. The burden of that should probably fall on higher income households.

And we agree that we need to generate-- we have to think about the tax side of this. We have to focus on this. But here's where we disagree and that is that we-- Bob and I believe that we need to raise tax revenue, that this has to be a balanced approach to getting us back to something that we would consider appropriate and normal. And I would love to do it through closing deductions and loopholes in the tax code. I think that would be the best way to do it, but we need to be clear eyed about this. And if we can't do it in the way you would like and I would like, we still need to raise the revenue, and we need to raise the revenue by taxing the rich. So you have to vote against this proposition. The rich are not taxed enough.

### Moderator
Claim: Thank you, Mark Zandi. And that is our motion: The Rich Are Taxed Enough. And here to make his closing statement in support of the motion, Art Laffer. He is founder and chairman of Laffer Associates and Laffer Investments.

### Conspiracy Advocate (CA)
Claim: Thank you. First of all, I'd like to congratulate Bob and Mark for trying to change the proposition to get a different one. The question is tax rates and, frankly, what Glenn have been arguing are, why would you ever want to raise tax rates on the rich if you know it's going to give you less revenue and a less prosperous economy? It's as simple as that and the evidence out there documents that time and time again. One of the ways I would do is lowering tax rates, but doing it by broadening the tax base to keep revenue neutral but creating the growth, prosperity, which would give higher revenues, but with lower rates. If you believe in lower rates and a broader base, you must vote for the proposition that the rich are taxed enough. Thank you.

### Moderator
Claim: Thank you, Art Laffer. And that concludes our closing statements.

And now it is time to learn which side you feel argued best. We're going to ask you again for your second vote, to go to the keypad at each of your seats. Our motion is: The Rich Are Taxed Enough. At this point, if you agree with that motion after everything you've heard, push number one on your keypad. If you disagree, push number two. If you are, became, remain, undecided, push number three. And we will have the results in about a minute and a half. I think the system is still open so, has anybody not voted? Everybody's good. All right. While we're waiting for those results to come, the first thing I want to say is that this was a really, really, real pleasure to listen to this debate. The way the four of you brought your game to this, a lot of humor, a lot of respect, actually, for one another. It's what we like to do, and I want to thank all of you for doing it. I'd also like to thank everybody who got up to ask a question, including the questions that didn't get used.

It takes a lot of nerve to get up and do it. And some of the questions were brilliant and on targets. And the others were just darn interesting. No, seriously, just not exactly where we wanted to take the discussion tonight. So everybody who got up and asked questions, thanks very much. Give them a round of applause. And, finally, in terms of thanks, we want to thank, again, the Richmond Center for their participation tonight and in making all of this possible. Thank you to them. We encourage you to talk about this debate; talk to your friends, tweet about it, blog about it. Our twitter handle is @IQ2US. The hashtag is actually #taxdebate. I think earlier I said our hashtag was #IQ2US, that would work, too, but #taxdebate is what we're looking for tonight. We have our next debate coming up next month, it will be on November 14.

The motion, the proposition, that we will be arguing is Legalize Drugs. For the motion, we have Paul Butler. He is a professor at Georgetown Law School; he is also a former federal prosecutor. His partner is Nick Gillespie-- he is one of America's foremost libertarians, and he is also editor in Chief of reason.com and Reason TV. Against the motion, Theodore Dalrymple. He is a retired prison doctor and a fellow at the Manhattan Institute. And Asa Hutchinson, who is a former administrator of the Drug Enforcement Administration and the first undersecretary of the Department of Homeland Security. We have tickets for that debate on November 14 and for our December 5 debate, which is Science Refutes God, available on our website. The website is www.iq2us.org. We would love to see all of you and we were delighted that we sold out and we love selling out, so help us do that. Well, that doesn't sound right.

Don't-- We don't want to sell out. We would like to sell all of our tickets. If you can't be in the audience for any of those upcoming debates, and also if you want to see this one again, there are a lot of ways that you can catch this one and the upcoming ones. We have a livestream on FORA.tv and then the debate lives on that site for some time. You can also, as I said earlier, listen to these debates on NPR, that's WNYC right here in New York City. Or watch them on WNET and the World Digital channel. Okay. So, you have listened to the arguments for and against on this motion: The Rich Are Taxed Enough. We had you vote once before the debate and once again afterwards on where you stand on this motion. Here are the results. The teams whose numbers will have changed the most will be declared our winner. Before the debate 28 percent were for the motion, 49 percent against, and 23 percent undecided. After the debate, 30 percent are for the motion, that's up 2 percent. Sixty-three percent are against. That is up 14 percent.

Seven percent are undecided, but this means the vote goes for the team arguing against the motion. Our congratulations to them. Thank you from me, John Donovan, and Intelligence Squared U.S. We'll see you next time.
