# Debate Transcript

Topic: Obama's Foreign Policy Spells America's Decline
Motion: Obama's Foreign Policy Spells America's Decline

Debate ID: foreign-policy


## Round 1

### Moderator
Claim: Proponents of tonight’s motion will say that President Obama is alienating our allies. He has snubbed the British and distanced himself from the Israelis. India feels it is taking a back seat to cozier relations with China. The Poles and Czechs are troubled that we cancelled long-planned, missile defense installations, presumably in the interests of better relations with Russia. Obama has committed vast American military resources to shoring up the corrupt Karzai government in Afghanistan, but hasn’t allocated a single dollar of the stimulus package to defense spending. And finally, his administration wasted a year on diplomacy with Iran. We are finally pushing a sanctions regime which will, at best, be watered down by the Russians and Chinese. Whatever the rhetoric, we seem to be acquiescing to an Iranian nuclear bomb. The actions of his administration accommodate our adversaries by respecting their domestic political institutions and their regional hegemony. In the words of historian Robert Kagan, “Instead of trying to reverse the decline of American power, they are reorienting American foreign policy to adjust to it.” The counter argument is that the substance of Obama’s policy simply represents a new realism in foreign affairs. It is less ideological and more pragmatic. His tone is conciliatory, a sharp departure from the perceived arrogance and unilateralism of his predecessor, and has generally improved America’s image abroad. He may not have made tangible progress on Israel and Palestine; but neither has any President. His Iranian policy has at least convinced the U.N. Security Council that stronger sanctions are required. In Pakistan, we have stepped up the predator war, and gained greater co- operation from the government there. Much of the Al Qaeda leadership is destroyed and the Taliban has suffered serious setbacks. Most important, Obama has restored confidence in our economic outlook, without which businesses would not be investing, or consumers spending, or markets rallying. The collapsing economy he inherited surely would have spelled America’s decline.

Which viewpoint will prevail tonight? An exceptional panel, who John Donvan will be introducing to you next, will help you decide. John, the evening is yours.

### Moderator
Claim: Thank you.

### Moderator
Claim: Thank you.

### Moderator
Claim: And I just want to point out that this is the final chapter, the final debate of the 4th series of Intelligence Squared U.S. which was founded by Robert Rosenkranz who made all this possible and on this occasion, the conclusion of the fourth season, a round of applause.

Welcome to another debate from Intelligence Squared U.S. I'm John Donvan of ABC news and, once again, I have the pleasure of serving as moderator as the four debaters as you see sharing the stage with me here at the Skirball Center for the Performing Arts at New York University. Two against two. We'll be debating this motion: “Obama's foreign policy spells America's decline.” Now, this is a debate. It's a contest. It will have winners and losers, you, in our audience, and you're one of our largest. This is a sellout for this debate. You will be serving as our judges. By the time the debate has concluded, you will have been asked twice, both once before and once afterwards to vote on this motion where you stand. Obama's foreign policy spells America's decline. At the end of the debate, the team that has changed most minds over the course of the argument will be declared our winner. So let's go to the preliminary vote. There is a key pad to the right of your seating position. If you agree with our motion, “Obama's foreign policy spells America's decline,” if you're with the for team press Number One. If you're against the motion, press Number Two, and if you are undecided at this point, press Number Three. And if you feel that you've made an error, just correct it and the system will lock in the last of your votes. And I'll have the reports of that fairly shortly. We're going to have opening statements first, and after that I'll be able to report the preliminary results. So on to the debate. Round one, opening statements by each debater in turn, they are seven minutes each.

I would like to begin by introducing our first debater for the motion, Obama's foreign policy spells America's decline. Dan Senor, I first met when he was serving as spokesman for the coalition for provisional authority in Iraq. He has a lifelong and keen interest in foreign policy. In that case he put his money where his mouth was. It was not a safe assignment at all. He has also recently been named as a putative candidate for senate from New York State, but you have shelved that for the time being?

### Conspiracy Advocate (CA)
Claim: I have. I hope you won't hold it against me.

### Moderator
Claim: No. If you're interested in foreign policy, it worked out for Hillary Clinton.

### Conspiracy Advocate (CA)
Claim: I will take that as a quasi endorsement?

### Moderator
Claim: Dan Senor.

### Conspiracy Advocate (CA)
Claim: Thanks, John.

Thank you, John. And thank you, Bob, for hosting this. It's an honor to be here with Bernard-Henri Lévy and General Clark and Mort Zuckerman. One caveat before I make my presentation. I'm not here tonight to issue a sweeping critique of every decision of President Obama's foreign policy. In fact, there are some that I have been quite supportive of, quite publicly supportive of. I thought it was incredibly courageous of President Obama to take on his own political base and commit to doubling down our troops in Afghanistan. Effectively under his presence, he will have doubled our troop levels. Maintain the commitment, the agreement in Iraq between Prime Minister Maliki and President Bush, and our presence there despite having campaigned against it, vigorously during the 2008 presidential campaign. Nor will I issue a sweeping defense of the foreign policy decisions of President Obama's predecessor. There were some decisions that President Bush made that I was very supportive of, and some that I have been critical of. What I'm here to do tonight is try to focus this question along with my friend Mort here who comes at this issue, by the way, from different perspectives. He was a supporter of-- public supporter of President Obama. I was not. But we both have deep concerns about America's power in world affairs today: America's status in world affairs today.

And whenever there has been a prospect of American decline as we think there is today, the-- one of the shock absorbers, if you will, to prevent that decline or at least slow it down, has been an enlightened understanding among Americans about America's role in the world, about American power. And the secret is not so-- not so secretive secret, is it's not just about American power, sort of an enlightened understanding of American power. It's about America's part of a liberal international order, about America as a builder of a Democratic world order. And you have seen these principles articulated, the notion that America helps to turn adversaries, whether there are autocratic regimes, totalitarian regimes, help them transition to democracies. You've seen this throughout American history. It's a bipartisan post World War II at least, bipartisan foreign policy commitment dating back to Truman and Acheson after World War II where they articulated certain principles. America will stand by Democratic allies around the world no matter what. America will stand by dissidents fighting for their freedom in human rights around the world no matter what. America will consult with its allies before it panders to its adversaries no matter what. And America will have a defense budget and military budget, not only to defend its own borders but to back up those principles and stand by its friends. And that is what I'm concerned about. Because you are seeing a realignment in American foreign policy today that backs away from those principles. Those principles are not Republican principles, they're not Democratic principles. As I said, you can look at Harry Truman, you can look at John F. Kennedy, America will bear any burden, pay any price to back up those principles. President Clinton, who under General Clark's superb leadership in the Balkans intervened to stop genocide in the heart of central Europe, in the spirit of human rights, in the spirit of helping out allies. And put American prestige on the line, by the way, not only American lives and resources but American prestige because he did it without U.N. support.

President Clinton enlarged NATO, was willing to bring central and eastern European powers into NATO, and not let Russia's ambition for hegemony in the region hold those countries hostage. This is the spirit you've seen throughout our foreign policy transcending party lines have been exceptions, obviously, the Carter years, part of the Kissinger years, and today. Today it's more than just a flare-up. Today it's a realignment in U.S. foreign policy. You are seeing a strategic decision by this administration to basically send a message to our friends and allies around the world that they can't count on us for very good reason--the administration would argue, because we're in an effort to reach out to new quote unquote friends. We're trying to turn over adversaries. In so doing, we may have to compromise our historic friendships. Look at the-- this is just not an abstract discussion. You just look at where we are in the world today. Iran is closer to having a nuclear bomb today than it was a year ago. This isn't hyperbole, this is a fact. Despite pleadings from our friends and allies in moderate Sunni regimes in the Arab world and leaders in Israel. This is a fact. Leaders in eastern and central Europe were completely off guard when President Obama announced a unilateral revoking of our missile defense agreement in the Czech Republic in Poland just a few months ago, all in an effort to reach out to Medvedev and Putin in Russia. Lech Walesa who personifies the appreciation and gratitude that millions of people around the world feel for America standing by the principles I spoke about earlier, said after Obama announced that decision after his administration announced that decision, he said this just shows you, you can't count on the Americans. Lech Walesa. Nicholas Sarkozy, the president of France, has called the president's foreign policy naive. And in the U.K. where they talk about the symbol of a special relationship, the U.S. has had a unique relationship with the U.K. going back to Churchill and FDR, and certainly in the past 30 years that special relationship between Reagan and Thatcher, President George W. Bush and Thatcher, President George W. Bush and John Major, Clinton and Tony Blair, and President George W. Bush and Tony Blair.

And yet an open discussion in London, the special relationship between the U.K. and the U.S. is in jeopardy. Gordon Brown, former Prime Minister Gordon Brown, had made five requests, five requests to have a one on one meeting with President Obama and couldn't get them to answer the phone. He wanted to meet at the UN, he wanted to meet at the G 20. Enormously embarrassing to the Brits. And Secretary Clinton, when she was in Argentina in March, she called on the British to reopen negotiations with Argentina over the Falklands, a wound that was in the process of healing 30 years ago and she ripped that scab off. A country-- to do this to the U.K., a country that has shed so much blood in its alliance with America and today has 10,000 troops in Afghanistan serving with us. So I would simply say that American alliances are in major jeopardy around the world. I think the message has been clear over the last 15 or 16 months that it’s a darn good time to be an adversary of America and it’s a pretty crummy time to be a friend and historic ally of America. And the moment our historic alliances and friendships believe that that they cannot count on America and its fidelity to the principles of Truman and Acheson, America truly will be in decline.

### Moderator
Claim: Thank you, Dan Senor.

Our motion is Obama’s foreign policy spells America’s decline and speaking first against the motion, Wesley Clark. You just heard him complimented by his opponent for his service leading NATO forces in the operations in Bosnia. He’s the former NATO Supreme Allied Commander, Europe. Again, a lifelong public servant who made a very credible run for President in 2004, actually winning primaries along the way. Although General, it occurs to me that had you won, these guys might be blaming you for America’s decline right now, so maybe it worked out. Ladies and gentlemen, Wesley Clark.

### Scientific Advocate (SA)
Claim: John, thanks for that introduction. I’d like to be up here debating my own foreign policy, but that isn’t the debate. But this is a very, very important issue. And I’m very honored to be here with Dan and with Mort and with Bernard. And thank you very much for moderating and thanks to all of you for being here. And for those of you who did support and donate to my presidential campaign, I thank you for that too.

I was very concerned about American foreign policy in 2002 and 2003. And I think my concerns at the time were warranted. I knew that going into the war in Iraq was a mistake. So did Barack Obama. We couldn’t stop the administration from going in. I testified in front of Congress. I warned-- of course we knew our armed forces were going to do great. Why not? We’ve been practicing and building for it for years and years and years. It’s the war that everyone expected to fight. It was like, why is it taking us so long? So we went in there and just as we expected in three weeks or less, we were in Baghdad and Baghdad fell and that was the end of it and the troubles began. The truth is, when we’re talking about American foreign policy, it didn’t begin on the 21st of January, 2009. And so I want to establish three things tonight. First, that Barack Obama began in a deep hole. And the first rule of when you’re in a deep hole is stop digging and start getting out of it. The second thing is I think he’s doing a lot of things right, and third I want to address some of the things that Dan brought up here. So first of all, the deep hole. I don’t think there’s been any period in American foreign policy and domestic policy where we’ve seen so many crises and difficulties. It started with 9/11 when the administration basically ignored the experience of the Clinton administration, didn’t pay enough attention to terrorism and we got clobbered. It then went into a war in Afghanistan that didn’t target the correct enemy, that was just a scattering of bombs.

Osama bin Laden was there; the military was never told to get him and he went to Pakistan. Then we withdrew our intelligence assets; we prepared to go to war with Iraq which for a variety of reasons that have never been fully explained, the administration was insistent on doing. That easy victory turned into a drawn-out, very expensive, very difficult insurgency. In the process, we lost friends and allies as they all fell by the wayside except for a couple of great allies like Britain and Italy. But the Europeans rightly had questions about how necessary this war was. We were no more in the deep insurgency then Katrina came and Hugo Chavez and others had to offer assistance to the United States because we couldn’t seem to take care of our own problems in Katrina. And then followed up by the financial collapse of 2007, 2008 which really put us in a hole as a nation that was in decline. So Barack Obama had a very tough road to hoe. I think he’s doing a lot of things right. He’s starting by trying to make more friends and fewer enemies in the world, so he’s reached out a hand of friendship to the Islamic world. His speech in Cairo was incredibly well received. He was nominated and received a Nobel Peace Prize based on the atmosphere he projected and that atmosphere goes a long way in international relations. He's kept our military strong. He has doubled down in Afghanistan. He's made it clear that there will be no easy path for terrorists in the United States. He stayed very tough on homeland security. He stuck with the commitments America made in Iraq. He's got a team in the Pentagon and elsewhere that will follow through on the effective policies of the previous administration and modify them where necessary. So I think he's doing a lot of things right in terms of keeping us safe. I think in terms of his work with NATO, they've made very strong presentations at the NATO summit. We brought in new members in NATO, Albania and Croatia, helping to fill out the Balkans and bring stability into that region.

And we've worked on other areas like trying to open up Burma. He's broadened the dialogue so that when we go to the Asia Pacific economic groups and OCEON and talk over there, we're not just talking about pursuing terrorists. We're talking about all the other things that are important for us. And he's taken a major role in international economic affairs. And really, there is nothing more important for America at this point after you keep America safe than to rebuild this economy and to work with our friends and allies around the world to do that. And he's doing all of that. As far as Iran is concerned, and here I want to turn to the third point, let's talk about Iran. Because of going into Iraq, the Bush administration was never able to bring moral force or intelligence to bear on Iran. In fact, there was an erroneous intelligence report in 2007 that said they'd given up their nuclear program. So let's give the president time to sort of get traction in world affairs. He's had it. He's brought consensus to bear in the United Nations that Iran is not complying. All options are on the table. That chapter is not over by a long shot, I would predict. As far as missile defense is concerned, there is a better way to do it. That's a missile defense that we have right now on our navy ships that can intercept mid course. We may need to go back to Europe at a later time when Iranians deploy an inner continental ballistic missile, but they're a long way from having it right now. Inside Eastern Europe, the policy of putting the missile interceptors and the radars on the ground had adherence. It also had opponents. And what Barack Obama has done is focused on the essential element which is the rationale for putting those interceptors in place and the radar in place. That was to deter and reassure vis-a-vis Iran. And that's exactly what the policy he announced will do.

Our Navy can do those intercepts. We do have that capability. It will be-- much more effective against Iran than the system that was being placed in the Czech Republic and Poland. I can't comment on what President Sarkozy said about Barack Obama's naivety. I'll leave those kinds of personal comments aside. But I think what you do have in the president is a man who is experienced in the world, a man who looks at the other side as well as what his own feelings are, someone who's running a pragmatic non-ideological policy, someone who's shown he's tough. He's hard headed. He means what he says. He's going to take America and lead us forward. I think you have to vote no to the idea that President Barack Obama's foreign policy spells America's decline. That's a no. Thank you.

### Moderator
Claim: Thank you, Wesley Clark.

We're halfway the opening statements portion of this debate. I'm John Donvan of ABC News serving as moderator. We have four debaters; two teams of two who are fighting it out over this motion: “Obama's foreign policy spells America's decline.” You have heard the first two debaters. Now, on to the third. I would like to introduce Mort Zuckerman who is chairman and editor in chief of U.S. News and World Report, and publisher of the New York Daily News, and I know that you're wounded tonight. Do you prefer to sit or - - we appreciate that in pain and with a cane, you made it here. Ladies and gentlemen, Mort Zuckerman.

### Conspiracy Advocate (CA)
Claim: If you thought you were in pain before I spoke, wait until you see what it's going to be like after I speak.

Good evening. I want to share with the other speakers the measure of being a part of this wonderful group and to speak to this audience. Let me just say when President Obama came into office, it was really a quiet sigh of relief around the world. He wasn't George Bush. The expectations--

No, I don't mean that. I think there was a huge concern in the world about the nature of American leadership at that point. And the expectations about President Obama were exceedingly high. Now, any president of the United States really inherits a great legacy. We stand at the top of the power ladder. We are not a dominant power but we're the leading power. We're the only power that can coordinate and coalesce groups of nations. Most countries distrust the United States less than they distrust one another. So they look for Washington-- to Washington for leadership. And they look for Washington to support them against regional opponents and other threats. They know they cannot solve most of these problems without the United States. And they need our leadership in the most severe and serious way. Now, my sense, however, is that President Obama on this level is uncomfortable with this role for the United States. He seems to be uncomfortable in leading a lot of other nations. And almost feels that there is nothing special about America's role in the world. What you have, it seems to me, is too much well intentioned belief in the power of rhetoric, good will, and too little appreciation of reality. The former president of the Council of Foreign Relations, Les Gelb put it, there is the impression that Obama confuses speeches with policies.

Now, foreign policy entails an understanding of the cultural historical and personal political circumstances of those we are dealing with. And this is where I think we have a real problem. Because there is, I think, a critical mass of influential people in world affairs who once held high hopes for this president and have begun to wonder whether or not they have misjudged the man. In the Middle East they always talk about the following. There are two chess games that are always being played in the Middle East. One is the chess board that you see on top of the table. The other is the chess board that is below the table that nobody sees except the people who know how to play the game. And the sense that they have is that this administration does not know how to play the game and has made mistake after mistake after mistake to the point where there is really an erosion of confidence in the United States and limitation therefore on what we can accomplish. And it also has contributed to a growing perception that Obama's management of American power is almost amateurish. He tends to speak as a teacher rather than as a leader. Now, in meetings with many of the leaders of the Arab world, particularly the Sunni leaders, they fear an expansionist Iran proceeding with full speed ahead on a program to develop nuclear weapons on top of programs testing intermediate range missiles. I will give you an illustration of how a major foreign leader of an Arab country put it to me. When you remember Obama said if people extend a hand to shake our hands instead of a fist, we will shake that hand. He says the problem with Iran is you can't deal with it by shaking their hand. You have to deal with them by showing that your capable of exercising the fist. And that is what-- it is that understanding and that understanding of the culture, not just in the Middle East, but in many parts of the world that is missing. And what you have, you have the centrifuges continuing to spin in Iraq.

And there is no sense, for example, when they had the uprising on the streets of Iran, that we were there with them, that we were on, as Fouad Ajami put it, on freedom's side. Now, the question is, is Iran going to be emboldened by what they see and experience as American weakness and the lack of real willpower? Well, as long as the Arab foreign-- the Arab foreign ministers put it the following one. One of them said-- now, this is a quote. He said they are hopelessly naive. The Americans are hopelessly naive. And they-- in that part of the world, naivety is not just naivety. It is seen as weakness as it really gives the impression that the leadership does not have the stuff that real leaders are made of. And that is the feeling that they have about America these days. Now, this is what French President Sarkozy was referring to. In fairness to what we said. Obama basically comes and gives a speech about wouldn't it be nice if the world did not have any nuclear weapons. Yes, it would. He basically said this is almost an alternative universe. It's as if nuclear weapons could be banished from the face of the earth. They cannot be he said and Sarkozy pointed out, that there are two countries he said, that’s in the meeting in which the president was in the audience. He said there are two countries right in front of us doing the exact opposite, referring of course to North Korea and Iran, an Iran that had ignored five U.N. resolutions on this issue alone. In the later diplomatic push, vis-a- vis Iran and North Korea: that yielded nothing. Sarkozy said we are right to talk about the future as the president was referring, but we also have to worry about the present and here you have these two countries, members of the United Nations who are pursuing exactly the policies that we find inimical. We’ve got to find some way to deal with the present he said and not with the future. In fact he pointed to the President-- looked at the President and said, this is not the real world that you are talking about; this is the virtual world.

Now this is in the full presence of many leaders of the United Nations in the audience and the French President says to an American President, you have to admit that the world is upside down when the French President sounds much stronger than the American one. And this is what it seems to me is what we have to address here. Now, it is, I can add to those things you’ve heard the references to when Obama withdrew the promises of ABM defenses, two countries in Central Europe, perhaps thinking that he might appease Russia into abrogating their patronage of Iran’s nuclear ambitions. Well frankly this has obviously failed and now in Central Europe, there is a fear that the United States may no longer be a reliable guarantor of their security. My time is up--

Well let me just, if I may just close. I just want to say one thing about this. What we are talking about here is an ability to play the game and an understand of how to play to the game and play the game well and effectively. That is what I see us lacking in the Obama administration and why it makes me feel that we are on the decline.

### Moderator
Claim: Thank you very much.

### Conspiracy Advocate (CA)
Claim: Well let me just, if I may just close. I just want to say one thing about this. What we are talking about here is an ability to play the game and an understand of how to play to the game and play the game well and effectively. That is what I see us lacking in the Obama administration and why it makes me feel that we are on the decline.

### Moderator
Claim: Thank you, Mort Zuckerman.

Our motion is, “Obama’s foreign policy spells America’s decline.” And our final speaker I’m very pleased to say is a European, given that we are speaking about foreign policy, I’d like to introduce Bernard-Henri Lévy, French philosopher and public intellectual. I would love to see the business card that says philosopher and public intellectual.

He has written extensively about the United States, very often in positive tones and he is here tonight to argue against the motion that Obama’s foreign policy spells America’s decline. Ladies and gentlemen, Bernard-Henri Lévy.

### Scientific Advocate (SA)
Claim: Yes, absolutely against for sure. In this debate I will have a big handicap and a little advantage. The big handicap is unfortunately my terrible and pitiful English. I must apologize. And my little advantage is to look at this topic, at this motion from outside and maybe from a slightly objective point of view. When you speak about Obama’s foreign policy spelling America’s decline, what do people think? Number one, they speak about the weakness, the supposed weakness of Barack Obama, his practice of compromise, his taste for compromise and so on. I think it is not true. I think that Obama, as I see him from outside, tries to compromise, does-- makes the most he can do with compromise and when it does not work, for example, when Syria proves to be continuing to bring some heavy weapons to a fascist party which is Hezbollah, then sanctions in strength. Barack Obama, as did any of your last presidents, believes in strengths but he believes in strengths as the great strategies, as Sun Tzu, Machiavelli, holding the fire and not this zero degree of strengths which is just Jacksonian politics. The second thing which is meant when one speaks about Barack Obama spelling the decline of America alludes to the fact that Obama would not be supportive enough to his natural allies and too much supportive for his enemies.

I don’t think so at all. I just believe that he does what the foreign policy must do. Foreign policy by definition speaks with enemies, speaks with ugly leaders, and in the respect of the natural alliance. I happen to be one of the Europeans who have had the chance to speak with Barack Obama about Israel six years ago before he was even candidate. My feeling again from outside is that to say that Barack Obama would not be supportive enough to the old natural allies of America is just untrue. Number three: the reproach, which is criticized, which is done to Barack Obama is that he speaks a lot and acts not enough. I'm not sure that he acts so little. I have one personal experience, rather recent, in Afghanistan. I was in the Uzbin Valley with some of your guys embedded in an American unit. I saw that the strategy of General McChrystal endorsed by your president is not so bad and is producing some real results on the ground. But this be put aside, it is true the Barack Obama speaks, speaks a lot, but why does he speak so much?

He speaks because he knows that foreign policy has changed its stage, that the new stage of foreign policy has new actors. And especially one new actor: not only the not only Sarkozy, not only the big leader of the world or the little leaders of the world, but the public opinion. Barack Obama understood that to have a real foreign policy supposes to address directly the world public opinion, that it is the only chance to achieve some real results as he did, for example, with the speech of Cairo. The other criticism which is done to Barack Obama is to admit too easily the rise of new powers and the subsequent diminution of the American influence: power of Russia, power of China, and so on. But again, who is really spelling the decline? Those who still believe in the world of yesterday, frozen in old schemes, or those who try to understand the world which is coming with a new lens, with new glasses, and trying to maintain the rank of America in this new world?

Barack Obama just knows that China is becoming a big power. He just knows that Russia is an actor de-freezing itself from the old Stalinist era. He knows that he has to deal with that and he does.

And the last reproach which is done to him is about exceptionalism. I read that Barack Obama is getting rid of this old American creed which is exceptionalism. And why? Because he apologized for Abu Ghraib, for Guantanamo, for torture, and so on. I believe the contrary. I believe that only dictators never apologize. And I believe that when you apologize, it means that you believe in your creed, that you believe in your values, and you believe in their superiority. Barack Obama more than ever believes in the house shining on the hill and that's why I vote no on the motion, he does not spell American decline.

## Round 2

### Moderator
Claim: Thank you, Bernard-Henri Lévy. That concludes opening statements for this Intelligence U.S. Squared debate. Here is where we are. We are about to enter into the part of the debate where the debaters address each other directly, and we also bring in you, the members of the audience, to ask questions. The way that we'll do that, is when we come to the questions is for you to raise your hand and I find you. There will be ushers with microphones. They'll bring a microphone to you. We'll ask you to stand. If you're a member of the news media or have any other relevant or interesting affiliation, we'd appreciate it if you'd share that with us. And when you get the microphone, if you can hold it about that far, distance away from your mouth, so that the radio broadcast where be able to hear you. Before the debate, we had you vote on where you stood on our motion, “Obama's foreign policy spells America's decline,” and we now have the results of that vote. Before the debate, this is where it stands, 23% of you are for the motion, 45% are against the motion, and 32% are undecided.

That's where it stands now at the end of the debate we'll have you vote once again and the team that has changed the most minds during the course of the argument will be declared our winner. So now on to round two where the debaters address each other directly. We have here at the Skirball Center for the Performing Arts in New York University, the teams of two, Dan Senor and Mortimer Zuckerman who are arguing that Obama's foreign policy spells America's decline. They have made the argument that President Obama has snubbed old friends. On the other side, Wesley Clark and Bernard-Henri Lévy, who have made the argument that President Obama is setting out to make new friends. What we're really talking about on some level in terms of the person of President Obama is the matter of respect. Does the world respect him? I want to put that question to both sides briefly. First to the team for the motion. Is President Obama respected? And is it the right kind of respect? Mortimer Zuckerman.

### Conspiracy Advocate (CA)
Claim: I'm going to speak with a French accent, if you don't mind.

### Scientific Advocate (SA)
Claim: This is unfair.

### Conspiracy Advocate (CA)
Claim: I will quote a major Asian leader who said-- very well-known Asian leader who said in the world of Asia, in the leadership of Asia which is the leadership that runs that part of the world-- we are concerned that Obama does not have the strength to confront his enemies, and we fear that he does not have the strength to support his friends. Now, I'm not saying that there isn't an expanded role for the media in many different parts of the world. In terms of the way political decisions and political power is exercised, I would ask you to think, if I may, do you think that the ability to speak is influencing the way political decisions are made in those parts of the world where we are trying to influence? Do we think that we are getting through to the leadership because Obama gives speeches?

### Moderator
Claim: So you do not think he's respected?

### Conspiracy Advocate (CA)
Claim: No, I think he is respected. I don't think he is effective.

### Moderator
Claim: To the other side. Wesley Clark.

### Scientific Advocate (SA)
Claim: I think he is effective. I think what he's done first is set up a base of public understanding for his values and America's values, and his vision. And I think he's very effectively captured world opinion on that. He's, then, set about restoring the relationship with allies, fulfilling his responsibilities to protect the United States which he's done, and then trying to work to head off the greatest challenges we face. So for example, you were talking about nuclear weapons, Mort. And he called together a nuclear non proliferation summit in Washington. People came. And it was important. And it was a private meeting. And they came because they respect him and they respect what he stands for in the United States of America. I think most of us would agree that the greatest single threat we face right now is a nuclear weapon in the hands of terrorists. And that's the problem Barack Obama is focusing on. So I give him high marks for the summit. I give him high marks for moving ahead with the symbolism of a start agreement with Russia to reduce levels of nuclear weapons. And I give him high marks for the general focus that he's brought to bear on looking to prevent future problems from emerging.

### Moderator
Claim: Dan Senor.

### Conspiracy Advocate (CA)
Claim: Yeah, I would just say that the fear of nuclear weapons getting to the hands of terrorists is not really an abstract debate. I mean Iran, according to IAEA, according to our own intelligence community Iran will have some sort of nuclear weapon, some sort of breakout capacity very soon: two years, three years. That’s really quick, 2015 perhaps, 2016. We still don’t have a Security Council resolution despite high approval, public opinion approval of President Obama around the world. The Chinese won’t get on board, the Russians won’t get on board.

The Iranians basically say and the IEAE says, that Iran has mastered something like 3000 centrifuges, enough to actually build a weapon. I mean, speeches and personal biography and personal charisma are wonderful, they’re nice; I think people around the world like us. I think they’re just limited commodities in foreign affairs. Nations--

### Moderator
Claim: You’re saying the goodwill does not translate.

### Conspiracy Advocate (CA)
Claim: Nations don’t make major decisions about their security because President Obama gives a nice speech. They do what’s in their interests. So I guess I would ask either of you, show me one example, one, that has generated any benefit in response to Obama’s wonderful speeches. What have we gotten? I mean the ultimate measure is Iran’s about the build a nuclear bomb so what have his speeches done to arrest that progress.

### Moderator
Claim: Bernard?

### Scientific Advocate (SA)
Claim: I give you two examples. Barack Obama is your first president and first leader of high rank that has said that the risk of the terrorist group having a nuclear device in their hands will happen, could happen in Pakistan. He is the first one who has designated Pakistan as a major problem. You had a president who said it was Iraq and who looked for the nuclear weapons with a lamp torch.

Barack Obama said that the problem is in Pakistan. This changed all the deal inside Pakistani power, inside the ISI, and more importantly inside civil society in Pakistan. Example number two.

### Moderator
Claim: Wait, while we hold that because I want to

### Scientific Advocate (SA)
Claim: Two examples.

### Conspiracy Advocate (CA)
Claim: Because number one, that is your big get, is that Obama said that Pakistan poses a threat? One of the rationales that Bush used for going into Afghanistan is that Pakistan could follow and has its hands on nuclear weapons and those nuclear weapons could get in the wrong hands. Your big get is that Obama basically confirmed something we all know.

### Moderator
Claim: Let’s here number two, example number two.

### Scientific Advocate (SA)
Claim: President Bush during his 8 years delivered huge, unconditional, untied aid to Pakistan government without any conditions regarding the topic we are speaking today. Barack Obama has changed that and this is not speech, this is act. Number two: the speech of Cairo. You know, the best way to help your friends is to disarm the enemies of your friends and the speech of Cairo had one concrete effect, which is to comfort the moderates in Islam, to isolate the people of al-Qaeda, the fanatics and the integrists, to divide the Muslim world, and this is--

Which has concrete effects on the ground, I can tell you. I know Pakistan; I went in Algeria; I went in Afghanistan, the new strategy of McChrystal for example, today consisting of isolating the Taliban inside the civil society, demonstrating to the people in Afghanistan that their interest is not to protect the Taliban.

### Conspiracy Advocate (CA)
Claim: Hamas is stronger today than it was a year ago. Syria’s announced or it’s been reported that Syria’s sending Katyusha rockets to Lebanon to give to Hezbollah and more sophisticated weaponry than that. I mean, Iran as I said is nowhere near slowing down their nuclear weaponization program. Exact-- so it was a great speech; it was very moving, and it was a poetic.

### Moderator
Claim: Dan, what Bernard is saying is that its concrete effect was to tell the moderates out there we are with you. Is that not meaningful?

### Conspiracy Advocate (CA)
Claim: I would say it’s nice, but at the end of the day, the moderates need to know that we are going to stand with them and exactly what has Barack Obama indicated in terms of what political capital and what resources America will expend to stand with these moderates?

You had an opportunity in Iran. It was a bona fide dissident movement, almost one year ago today. They were saying, where is America? Throughout modern histories, you know Bernard, because you’ve been very active on these human rights issues. America’s leaders and American presidents have put a spotlight on dissident movements, whether it was the anti-apartheid movement in South Africa; whether it was the Soviets dissident movement in the former Soviet Union, the oxygen for these movements is America keeping a spotlight on it. Our president was silent.

### Scientific Advocate (SA)
Claim: In the first place, the inspiration for a lot of that movement came from the words of Barack Obama and his symbolism. Secondly--

Secondly, I think it's very interesting that you want to ask what's the benefit of a speech because one of the things that we should be talking about is concrete policies and specific actions. One of the things we did learn during the previous administration was that harsh rhetoric doesn't help. Strong bull-headed rhetoric appeals to Americans, but it doesn't change foreign affairs.

It's what Ahmadinejad wants. It helps him consolidate his grip on power when we call him names. So Barack Obama played a very clever strategy in that. It didn't work, but no--

you can't-- America, I'm sorry. Even though I know that I would like to believe that America could cause a revolt inside Iran, we have been talking about a change in regime through six administrations, and it hasn't happened in Iran yet. And so I don't think it's a legitimate criticism to say that Barack Obama gave a speech and the Iranian revolt against the Ahmadinejad didn't work. I mean that's not cause and effect. But what is a demonstration of Barack Obama's strength is his staying with his commitment in Iraq. It is reinforcing in Afghanistan.

And there is not a leader in the world who would look at Barack Obama and say he made an easy decision on that. He did not pander to the American public. And those of you in this audience, I bet if you took a vote on that, the majority of this audience would not have supported him when he put those extra troops into Afghanistan, and yet that was the right call and it was a tough call. And he is recognized around the world for his courage in making that call. I, too, have talked to foreign leaders, and Mort, that's what they tell me.

### Moderator
Claim: Mort Zuckerman.

### Conspiracy Advocate (CA)
Claim: Well, again, I hate to say this, but I think you're speaking only to foreign leaders who speak with a French accent. I don't know what else to tell you. No, that's an unfair comment.

Look. Let me just say that. The one area of the world where we have to worry about is frankly the Middle East. And there you have, I think, a couple of countries, and a couple of movements that are really threatening a lot of our allies, Iran being one. The movements in Hezbollah and Hamas, basically terrorist groups of that sort. For Syria to have just provided scud missiles or their equivalent to Hezbollah is changing the whole military context of the region. Nothing is stopping these people. And I don't dismiss entirely the rhetoric of the president. I'm just saying that in that part of the world you need a lot more than rhetoric. I don't want to diminish what the value of rhetoric is. But you have to translate that into other policies that really do have an effect against the people who are threatening.

### Moderator
Claim: Wesley Clark just talked about a concrete move of putting more troops into Afghanistan. That wasn't rhetoric.

### Conspiracy Advocate (CA)
Claim: I don't disagree with that. I mean I wasn't referring at that point-- at that point, we were in a position in Afghanistan, and there is an issue, a connection between Afghanistan and Pakistan as we all know. If there was a rationale for going into Afghanistan, it is to make sure that Pakistan does not collapse. Because they do have 120 or whatever the number of nuclear weapons they have, and that is the worst thing that would happen if they fall into the wrong hands.

So in a sense, we are protecting Pakistan and all of that. So I don't diminish that. I'm not saying that everything he's done is wrong. I'm just saying that when you play this game out there, and it is, in a sense, an understanding of how to work in that community, I'm afraid that the rhetoric that is being saluted here is not nearly as effective as you would say and the policies that would be effective are simple not being carried out.

### Moderator
Claim: Our motion is “Obama's foreign policy spells America's decline,” and in arguing for this motion, are you saying that decline has begun already, we're in it? Dan Senor.

### Conspiracy Advocate (CA)
Claim: I think the prospect of decline is real. We are in an early stage of it.

### Moderator
Claim: What is the--

### Conspiracy Advocate (CA)
Claim: And it can be arrested. As General Clark and Bernard said-- General Clark in his opening statement said that America was in decline when Obama took over, that we were in a deep hole. Then you're arguing that we're already in decline. And the question is now is Obama slowing it down? And I would say that when you have a situation where leaders around the world, allies of ours, historic allies are openly calling us naive and questioning our commitment, and our loyalty, that will spell American decline because we can't do this on our own. And I want to ask a question. You know, I agree with you that George W. Bush was extremely-- I'll be the first to admit, unpopular around the world. He got much bigger crowds opposing him traveling around the world than Barack Obama gets supporting him. But one thing President Bush did have is very deep relationships with leaders, Aznar in Spain, Harper in Canada, Howard in Australia, Blair in the U.K., Sharon in Israel.

### Scientific Advocate (SA)
Claim: And Putin in Russia.

### Conspiracy Advocate (CA)
Claim: Hold on. Hold on. And that was an enormous mistake. And by the way, he basically stood by Georgia when Georgia went to war with Russia because of Russia's provocation.

So that was a big mistake by Bush, and I'm glad he ultimately agreed to move off that outreach to Russia. But you look at these leaders. Blair, Berlusconi, Howard, Harper-- these leaders stood by Bush through thick and thin, even though their populations despised him. I ask you to-- tell me one leader today that has that kind of relationship with Obama. One leader around the world that is so moved by his speeches and so moved by the press release he put out saying that Pakistan has terrorists in it, point one leader that is willing to stand by him and who he has a very close alliance. Just one.

### Scientific Advocate (SA)
Claim: I think it is because of my French accent that you did not get what I said. I suppose.

So I will repeat. The characteristic of the period where we are is that Berlusconi, Zapatero, and even Sarkozy might be less important today than the peoples, than the masses, the huge crowds who all over the world were fed by your rubbish anti- Americanism for ages, and who are slightly changing their mind. Maybe Sarkozy said that Barack Obama is naive, but--

He made – Sarkozy is not so important. More important than Sarkozy is that you have, as you know, an annual poll judging the big leaders of the world. And Barack Obama, the last poll two months ago arrive at 46 or 48--

### Conspiracy Advocate (CA)
Claim: Those polls don't make policy. Governments make policy. There is not a single government?

That's very nice. They applaud for him--

Tell me one leader. One leader.

### Scientific Advocate (SA)
Claim: History is not made by Berlusconi. Real people, suffering people, losing their houses, suffering from terrorism, being fed up by fanaticism: this is a real actor of history. And in front of these people Barack Obama is much more popular than has been your--

### Scientific Advocate (SA)
Claim: I think the question you're asking, Dan, is a naive question. I'll tell you why.

### Conspiracy Advocate (CA)
Claim: The inner Sarkozy in you.

### Scientific Advocate (SA)
Claim: Because if you believe that leaders stand by the United States because of some personal relationship with the president, then you're neglecting the whole political basis for their own mandate in their own country. So if you scratch--

If you scratch--

If you could scratch very deeply on someone like Prime Minister Blair, and no one has managed to scratch very deeply on him yet, he would tell you that he was trapped by his early support of the Bush administration in Iraq. He has defended it and defended and defended it because that's what political leaders do. But if you talk to the people who were around him at the time, and were there, and all of a sudden we jumped in without a second UN Security Council resolution, he thought he could influence President Bush the way he could influence President Clinton. He signed up on his team, he jumped in there and it turned out there was no influence at all. But political leaders act for their own survival. That's what motivates political leaders. Berlusconi, Blair-- all those people saw they had to hang on to the commitments and the statements they had previously made. They couldn't back away from them, not because of their great respect for an American president but because of their own domestic politics.

### Moderator
Claim: Put this in terms of Obama’s presidency in two sentences; its relevance.

### Scientific Advocate (SA)
Claim: He’s going to make smart policy decisions. He’s going to bring the people of the world with him. He’s going to moderate the domestic opponents around the world of our policies. He’s going to make it easier for foreign leaders to agree with and support us.

### Moderator
Claim: So Dan, you need a shot back. These have been two arguments against your point that the personal relationships are critical.

### Conspiracy Advocate (CA)
Claim: Yeah, I want to be clear here. It is clear that political leaders make decisions based on the domestic political situation. In fact, several of the leaders I cited lost their elections because of their commitment to standing with the United States under President Bush. Two: security matters. Probably security matters and I have a slightly less cynical view; security matters to these leaders, in many cases more than politics. And it was because not of some personal emotional relationship that they had with President Bush. I’m sorry if my American accent, I wasn’t able to make my point clear. Their sense of loyalty to President Bush was because of his commitment to them and his commitment to the security of their country which is what they ultimately care about and his commitment to security abroad. And those leaders were willing to go the mat even if it meant risking their political careers to stand with him. You say Tony Blair was trapped. To this day, Tony Blair is out of office. To this day, he defends the decisions he made. So I come back to you, you say policy makers don’t matter when it comes to policy? I mean that’s the most inverted metric I’ve ever heard. Policy makers make policy, and I don’t see a single policy maker in the world today despite the millions of people who have this affection for President Obama, which I think is heartfelt; I don’t see a single policy maker that is willing to stand up and go toe to toe and lock arms with this president. And I-- I think if they believed he was committed to them, that you’d have a different outcome.

### Moderator
Claim: I want to move on to some other topics. Bernard, I want to move on to some other topics. This may go on forever and I do want to move on. I want to-- and I say that with respect, but it’s beginning to circle. I want to go to the audience for some questions. If you raise your hand, we’ll bring up the lights a little bit more so perhaps I can see. But before we do that, I just want to go to a specific example to put this in more concrete terms and I would like to talk about China. Dan Senor, take on the president’s performance in China.

### Conspiracy Advocate (CA)
Claim: It was stunning. I’ve never heard such unanimous criticism of a president’s visit to China from across the political spectrum from the left and the right in the United States. It was a humiliating experience. The Chinese were allowed to censor his speech on the ground. The Chinese were allowed to choose who could attend this speech. Students as you know, many students were kept out and he left China with no concessions from the Chinese. Normally when presidents go, even if they intend to somewhat humiliate the president, they at least give them a couple of crumbs to leave with. We didn’t get anything. Here we are today, Iran is on the cusp of developing a nuclear weapon and China still won’t support sanctions on the U.N. Security Council, still won’t support sanctions. By the way they won’t support sanctions in Sudan; they won’t support sanctions anywhere. So, I keep coming back to my question, what do we get? What have we gotten for this new posture?

### Moderator
Claim: Response from the other side? Wesley Clark?

### Scientific Advocate (SA)
Claim: First of all, I’m not going to go into the details of the president’s trip to China except to say that our relationship with the Chinese is one of mutual need. We need them; they need us and he’s working to define that relationship in a most constructive way. Now, whether or not China ultimately support sanctions on Iran in the United Nations is not going to be the decisive factor, I would predict, in this president’s decision about what to do about Iran. So a lot of the case that has been made by the other side is predicated on hypothetical decline.

Hypothetically, Iran’s going to get this, hypothetically Barack Obama’s not going to do that or something of the sort; I don’t think the record demonstrates that. I think what the record demonstrates is a very systematic working with other nations and preparing the ground for what’s going to be a very difficult decision.

### Moderator
Claim: But I think Dan Senor was also talking about process and his point was also that the President’s trip left the impression of weakness.

### Conspiracy Advocate (CA)
Claim: Well he certainly did and what’s more, I think there was a wide sense within the Chinese leadership that he was weak. This was the worst visit of any president that has been made to China and it is a critical country, whether or not they support what we want to do vis-a-vis Iran or not. We came out of that with a greatly diminished sense of prestige or status or whatever, which are-- these are things that are very important to Chinese political culture. And to deny that is to deny really what happened. That was the reality of it. You can argue why it happened. I think it was very poor staff work on the part of the president's team. But whatever it was, it worked out in the worst way. They did not understand how to play the game with the Chinese.

### Moderator
Claim: Bernard-Henri Lévy.

### Scientific Advocate (SA)
Claim: My impression was not the same. I think that there are two ways of considering the relationship between America and China. One way, which probably would have been the way of another president, is conflict, opposition, revival of Cold War. We have an enemy. We have a new bipolar world. We have to win this battle. Cold War is still alive. This would be one way. The other way is to say that there is a partnership, that there is a new order of the world of which the Chinese are real partners, economical partners, financial partners. You know better than me. I am not an economist, that they own a huge quantity of American bonds and so on.

The impression which was released, which was delivered by Obama's visit was the impression of a non-hysterical relationship, of a real partnership, of new ground, a new departure for a relationship based, of course, on different visions of the world; a totalitarian regime on one side, the embodiment of modern democracy on the other side, but nevertheless a constructive partnership. And for this, we have to thank Barack Obama to have given this impression. And--

### Moderator
Claim: Let me go to somebody else here.

### Scientific Advocate (SA)
Claim: There is some road to be done still, of course. The road is not over. It's not the end.

### Moderator
Claim: Gentleman on the aisle.

### Conspiracy Advocate (CA)
Claim: That is a very optimistic vision of what happened on Barack's visit to China. I don't think there is a single-- I haven't seen-- and I've read most of them, maybe not all of them. I haven't seen a single person who understands what goes on in China, who thought that was a successful visit that in fact we came out with an enhanced relationship. Quite the opposite. It was a diminished relationship. I just-- you can give any interpretation you want to it, but I really cannot accept that description of what happened.

### Moderator
Claim: Yes, sir.

### Moderator
Claim: My name is Eric Edelman. I'm a retired foreign service officer and former undersecretary of Defense for Policy. I'd like to direct a question to General Clark. But before I do, I'd like to associate myself with the comments that Dan opened the debate with about General Clark's service as supreme allied commander. During Bosnia, I was the U.S. ambassador to Finland at that time and was proud to be working by his side. But I do have a somewhat critical question about the comment you made with regard to the administration's phased adaptive approach for missile defense announced last September in Eastern Europe. Putting aside the rather unfortunate timing announcing the decision on the 40th anniversary of the Soviet invasion of Poland to the Poles, the phased adaptive approach eight months on still has not got a deployment plan that the Department of Defense has been able to describe to the Congress.

They can't say how many Aegis ships with the SM3, block 1A and B missiles will be deployed, where they'll be deployed. Will they be deployed in the Black Sea? And these are important questions, given that the CBO study of missile defense--

### Moderator
Claim: Eric?

### Moderator
Claim: --described the--

### Moderator
Claim: I just want to ask you to translate yourself slightly.

### Moderator
Claim: Yes.

### Moderator
Claim: I mean, this is a pretty smart audience, but I just want to ask you if you could find a slightly more generic way, slightly more generic way.

### Moderator
Claim: The question is the general said that the phased adaptive approach the administration is deploying would provide greater capability. My question is, how can you judge that when we don't know what the deployment plan is?

### Scientific Advocate (SA)
Claim: If you know what the capability of the Aegis cruisers are, what the missiles are and what they could do when deployed there, then you have a pretty good appreciation for what it can do to protect the nations in the region when those ships are deployed. Now, like you, I haven't seen a plan. I'm not in on the classified planning, and I don't know why it hasn't been released. And I can't defend it. Should it have been released? Should it have been out there? Should it have been briefed to the allies? Well, we could discuss that. I don't know whether it should have or not because I'm not on the inside of the policy-making apparatus. You're raising valid questions, and I am sure that the administration has thought of those questions. I hope they have answers to them. They should.

### Moderator
Claim: Gentleman in the blue shirt.

### Moderator
Claim: Hi. My name is Stu Weiss I'm a physician here in New York. My question is for the people on the “for” side. I want to go back to Europe for a moment. So just yesterday, the European Central Bank decided to support the euro and to do one of the biggest bailouts in I think in history of several European countries. That was in spite the objections of Germany and several other countries. And the New York Times reported today that their objections were overcome in large part because of the actions of the administration and President Obama.

Does that not show that he is still a significant influence in Europe and still projects some strength among our allies and friends in Europe that they could overcome their reluctance and bail out-- and support the euro?

### Conspiracy Advocate (CA)
Claim: Yes, I would say that does show that there is influence on the part of the president in terms of issues like this. What we are also contending with, and let's be candid about it, most of the debt of these countries is in the hands of the European banks. Were those banks to go under because they didn't work out a plan, you would have had a major economic catastrophe in Europe. And it would have spilled over into the United States. Our own economic policies, I might say, leave something to be desired too in terms of building up deficits as far as the eye can see, that are going to really transform the economic wherewithal with which this country has been the bulwark of freedom in this world. And it's going to be a growing problem for us. But to have Europe collapse at this point, the United States had to put whatever influence they could to bear on these decisions. And I am glad they did, and I'm glad it worked out because otherwise we would have had a major collapse.

### Moderator
Claim: So somewhat, you give good points to the White House on this one?

### Conspiracy Advocate (CA)
Claim: Yes, absolutely, I do. I'm not-- I don't think everything the White House does is bad. Don't get me wrong on that. But I think on this--

### Moderator
Claim: Fair enough.

### Conspiracy Advocate (CA)
Claim: --absolutely.

### Moderator
Claim: Fair enough. Ma'am? Let's let the microphone come to you. Thank you.

### Moderator
Claim: Hi. How are you? My name is Kamini Kendika Abdul and I'm a resident of New Jersey. In terms of policy changing and making, this question is for Dan Senor. I think he does-- President Obama has some say in the world in policy changing, specifically in Afghanistan and the treatment of women sexually. I noticed in the news that there was a new policy change. So how do you equate what's of benefit in policy changes versus a deficit?

### Moderator
Claim: And just to clarify, you feel that his statements had impact?

### Moderator
Claim: Oh, I do feel that he has some kind of an impact.

### Moderator
Claim: No, I mean--

### Moderator
Claim: Because he is against--

### Moderator
Claim: Right. Okay.

### Moderator
Claim: He's against the old policy of women and sexuality in Afghanistan.

### Moderator
Claim: Right. But you think it's having-- it's not that it's being-- just being well received, but you think it's actually having an effect.

### Moderator
Claim: Well, it did actually have an impact. They changed the law. And--

### Moderator
Claim: Okay. That's what I wanted to nail down. Dan Senor.

### Conspiracy Advocate (CA)
Claim: I am the first to credit the president on some of the progress in Afghanistan. What I'm saying is it doesn't compensate for a complete realignment of U.S. foreign policy in every other corner of the world. So it is very important what you just cited about women's rights in Afghanistan. At the same time, the government of Russia, with whom this president celebrates a reset of relationships, is engaged in a fierce political repression of opponents, is murdering journalists. Putin is probably going to run for president in 2012 again. That's what it looks like. Dissident leaders like Boris Nemtsov who I hosted when he came over here from Moscow about a year and a half ago, couldn't get any hearing inside the administration. Iran, I mean, the dissident movement in Iran was basically left on their own, left hung out to dry. And the notion of the president not putting a spotlight on them, as General Clark said, somehow would weaken the Iranian regime. The Iranian regime blamed us and demonized us no matter what when he did. And they were more than happy to do it even though we were silent. And as I said, here we are a year later. The dissident movement is weaker than it was a year ago. And Iran is closer to getting a nuclear weapon. I think that makes the world a less stable place. And I think it is more consistent with American decline than it is American ascendancy. If Iran develops a nuclear weapon capability, we will have a nuclear arms race in the Middle East the likes of which we have never seen. And this is not like a hypothetical thing. The news reports coming out of Egypt and out of Saudi Arabia, out of Yemen of this happening.

### Moderator
Claim: Dan, I want to interrupt you because I want to bring it back to the question and let Wesley respond as well to the question. And if you felt that you were mischaracterized by Dan, I'm going to give you a crack at that. But the question was asking about the impact of the president's remarks about the rights of women. And she's claiming that it has some sort of real impact. And I think, Dan, you're saying, yeah, maybe it does, but it's not enough.

### Conspiracy Advocate (CA)
Claim: Yeah, it’s important, it just doesn't compensate for foreign policy framework.

### Scientific Advocate (SA)
Claim: No. I accept what Dan says. It is important. It's certainly not the whole plank of our foreign policy. It's an example of how a statement by a leader can have an impact. I agree that the question of Iran is hanging over our president as the judgment of his foreign policy. You know, before he was elected, he did go to Israel and he did speak to AIPAC and he made very clear he would not tolerate Iran having nuclear weapons. Every candidate did that-- both parties. So this is something that he's worked on assiduously. The administration's very well aware that this challenge is coming up. They're laying the groundwork to take effective action. And you know the verdict of history will await. He's going to have to make the call. But I don't want to minimize the significance of this decision because Dan is exactly right on this. This is a pivotal decision in the future of the Middle East, the future of nonproliferation, and the future of the world security structure as we know it. And that's why he called the nuclear nonproliferation summit. That's why he reaffirmed America's commitment that we undertook in the Nuclear Nonproliferation Treaty to eventual nuclear disarmament. That's why he's working to line up the support of public opinion, and it's moving in our direction, China notwithstanding for their own personal and economic reasons. So at this point this is one of those decisions that's going to have to be made at some point, but it hasn't been made, the time hasn't come yet to make that decision, and I think the whole world will await the outcome of the president's decision on this.

### Moderator
Claim: So your question wasn't about Iran but precisely in a sense, but I want to move on, but you got us into an interesting area. Sir, yes, you're pointing to yourself, and if you can stand, thank you.

You were the only one doing that.

### Moderator
Claim: Thank you, my name's Matt. I'm from Brooklyn. My question is directed at Mr. Zuckerman. It was mentioned that you were a supporter of Barack Obama during the campaign so it seems to me that he campaigned on this policy of engagement that you oppose, and has only become more--his policy in places like Afghanistan and Pakistan-- it's only become more muscular, alienating his base since he has come into office. So I'm wondering how you can explain that discrepancy. And I have another question, just very short for everybody.

### Moderator
Claim: I'm only going to take one question.

### Moderator
Claim: Okay.

### Moderator
Claim: That's just one of our rules.

### Conspiracy Advocate (CA)
Claim: Well, yes, I did support--

### Moderator
Claim: You're saying he's not engaging enough.

### Conspiracy Advocate (CA)
Claim: Obama, yes, I'm saying that engagement is not enough to deal with the issues that we have to deal with, not in Iran, frankly, not in the Soviet Union, not with China, and not in the Middle East. I'm not dismissing engagement. It's just not enough. And as I say, the view that so many of them have is that they don't think he is going to be tough enough to deal with the issues that really have to be dealt with in a tough-minded way. I hope that they are wrong and I hope that I am wrong. But the evidence so far frankly is not encouraging, and frankly when you deal with those people, they are not encouraged. I mean, this is not something that I'm making out of thin air. I promise you that this is what they are saying and what they are very concerned about. So I support engagement but engagement is one hand, the other hand is they have to-- you have to be able to deal not just with a handshake but with a clenched fist.

### Moderator
Claim: I need to say something for the radio broadcast. We are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan as moderator. We have four debaters; two teams of two, who are arguing over this motion, "Obama's Foreign Policy Spells America's Decline." And, sir, just, you can nod or not, I just want to ask you your critique of the President's performance is more a critique from the left, that he's become too muscular, am I correct about that, that you're citing that critique? So he's getting it from the other side, and I believe for now that's also the case often in Europe, that where people are disappointed in Europe with the President is that, in fact, he did send troops into Afghanistan and that he went to accept his Nobel Prize and made an argument in support of war and certain causes, and that, in fact, they thought he was too tough, which is the opposite of this side.

### Scientific Advocate (SA)
Claim: There are not so many critics against Obama in Europe. I don't think so. What is very positive and very positively appreciated in Europe is that Obama engaged some troops in Afghanistan, maybe not enough according to some, but with some concrete, effective, and important results on the ground. This is an important point, with some troops, not as many as some would have wanted some real results, two sorts of results, and you have to be very concrete and go into details to appreciate these sort of things. Number one, as I said, inside of Afghanistan, isolation of the Taliban. This is a new reality on the ground. The Taliban are less and less fish in water in some of the valleys where they were kings a few months ago. Number two, I happened to be-- I’m sorry but I was in Afghanistan two years ago and I saw some units, offensive units, which were American units, fighting units, with some Afghan scouts embedded in the American units. Two years after. Now, a few months ago, it is the reverse.

You have some national Afghan battling units with some embedded American-- not scouts but mentors. I mean by that that the situation on the ground is changing, that the new strategy implemented by Barack Obama and his high command has begun to give its fruits.

### Moderator
Claim: Let’s see if your opponents concede that point or not.

### Scientific Advocate (SA)
Claim: It is concrete. I emphasize.

### Conspiracy Advocate (CA)
Claim: Look. As I made it clear at the beginning of this talk this evening, I think President Obama’s decision to support General Petraeus and General McChrystal in Afghanistan was enormously important. I actually have deep concerns about Afghanistan right now, about the civilian/military coordination. I think we’re potentially heading for a crisis on the ground in Afghanistan as it relates to civilian-military coordination. But that said, I don’t take one ounce away from the President’s courageous decision on Afghanistan. To me, it’s important but it doesn’t make for a foreign policy. Bernard, look, I have been a great admirer of yours. Throughout your career you have advocated for human rights and the importance of standing with dissonant movements, even as a centerpiece of foreign policy. There were about 40 individuals that signed a letter to the President on the eve of his trip to Moscow asking to meet with opposition, with democratic opposition figures in Moscow while he was there. Only one leader from the Left in the United States signed it, the head of Amnesty International USA. And as one Left-wing blog commented, it’s a sad statement of the state of affairs that human rights has so been subordinated as a principle in our foreign policy that if someone from the Left wants to advocate for human rights being an important part of a president’s visit to Russia, to China, to any of these places, they have to sign a letter with a bunch of neocons like myself. It’s a sad statement of affairs, and I’m amazed that you are giving him a pass.

### Scientific Advocate (SA)
Claim: The question of human rights is also a question inside Islam. Today, the real shock of civilization is inside Islam, inside Islam between Islam, democratic Islam and integrist and fanatic Islam. In these battles, which is the most important battle of the moment, Obama is and his team and Clinton are playing a major role in separating the two in isolating the fanatics and the integrists from the moderates, in saying to the moderate Muslims that we are no longer their enemies. That we are on their side. That we’re facing the same problems and that we are sharing the same values. This also is human rights. Why--

All over the Muslim world heard, listened, and heard the message.

### Conspiracy Advocate (CA)
Claim: Can I ask you a question? Why didn’t he give that exact speech you just gave when the dissidents were rising up in Iran?

### Scientific Advocate (SA)
Claim: He did this in a way because it was a very complicated story. Mousavi was nearly under arrest, was threatened with death. You had some dissidents who were shot dead like Neda in the streets and this was a very responsible attitude to have in front of butchers. Ahmadinejad is not a president, he’s a butcher. And I think that the concern of every responsible Western leader was to avoid in Tehran a Tiananmen. There was the threat of a huge Tiananmen, ten times maybe more bloody than Tiananmen and I think that Obama acted not so badly between the human rights talks between the human right attitude and between the accountability in front of what could happen on the other side.

### Conspiracy Advocate (CA)
Claim: Iranian regime's response-- Iranian regime's response made Tiananmen look like a day at the park. The regime was more repressive today than it has been at any time. The regime is stronger today than it has been--

### Scientific Advocate (SA)
Claim: No, no.

### Conspiracy Advocate (CA)
Claim: --at any time.

### Scientific Advocate (SA)
Claim: Let me ask you--

### Conspiracy Advocate (CA)
Claim: Let me finish. And Mousavi and his leaders were calling on America. Where is America? Why isn't America putting a spotlight on our movement giving us the oxygen we need? Let's take them at their word.

### Scientific Advocate (SA)
Claim: No.

### Moderator
Claim: Sir--

### Scientific Advocate (SA)
Claim: John, I have to come back.

### Moderator
Claim: Okay, Wes, because you haven't been--

### Scientific Advocate (SA)
Claim: I have to come back on the human rights issue. Look, I don't think the United States government under Barack Obama has moved one iota off its steadfast commitment to human rights every country in the world. Now, what there is, is a disagreement about tactics. There are some who believe that you should carry human rights on the top of the banner and use it in a provocative way when you're making a visit abroad. There are others who believe that there's a more constructive way to go at it. I'm involved in a number of organizations, and I talk to people when I travel abroad, and I spied no difference in the solemn dedication of the United States government to human rights. But I do think that there is a difference in calling for human rights and making a big splash about it as a provocative gesture when you go into a country where you know you're going to have conflict on this and trying to work behind the scenes and more quietly to actually improve the opportunity for human rights. And so that's what this administration's trying to do.

### Moderator
Claim: Ma'am, if you don't read your question, if you are holding a piece of paper, if you are prepared to just blurt it out, I'll take your question and make it brief. Thanks. Don't read.

### Moderator
Claim: Hi. My name is Ana. I am a senior at the University of Vermont. And my questions are directed toward the opposition bench. Both of you spoke about how the leaders do what's best for their country and how now public opinion is now more important and even considered the new actor when it comes to foreign policy.

Why is it, then, when foreign policy is so important to public opinion, and public opinion says that what Obama did and his actions towards Israel and the Israeli government earlier this we're year was inappropriate, he did not listen to public opinion until two bipartisan letters came to him from Congress? If public opinion is so imperative to the president and his foreign policy, how come it took Congress to back it?

### Moderator
Claim: In that case, you're talking about U.S. public opinion. Okay.

### Scientific Advocate (SA)
Claim: I was not speaking about this public opinion only.

### Moderator
Claim: Yeah, I didn't think so.

### Scientific Advocate (SA)
Claim: I was speaking about world public opinion. And I was saying that we are going out, we are leaving a policy of big hugs, of good buddies, Sarkozy, Bush and so on, and we have good friends, blah, blah, blah. This was the old politics. And George W. Bush was very good at that, at hugs with Sarkozy, with Berlusconi, with Aznar in Spain and so on. And that today we are facing, we are discovering a real moving actor which is the public opinion, the fighting public opinion in Iran, which is the women in Afghanistan, which is all the people around the world. And to these, Barack Obama addresses for the first time a language which goes at the same time to the brain and to the heart. It is-- I travel a lot. It is the first time since many years that I see that the flag of America is again a new, bright flag, meaning hope for a major part of the world, especially in the very deserted parts of the world. And this is a renew-- and it's more important than the buddies, hugs between Sarkozy and George W. Bush.

### Moderator
Claim: The gentleman with the brown blazer in the next aisle, white shirt. No, farther up. Yeah. yes, sir.

### Moderator
Claim: Daniel Nadelman from New York City. Let's assume that Barack Obama and the United States have every intention with or without Israeli's assistance or cooperation, in taking out Iran's nuclear capacity. If that's the case, what sort of public foreign policy robust strength would you like to see Obama do between now and when that actually happens when they decide that's the right time to happen, for him to demonstrate the type of strength that you're showing, saying that he's not actually demonstrating now?

### Conspiracy Advocate (CA)
Claim: There is a bill before Congress right now that would impose sanctions on Iran on the import of petroleum products which the Iranian economy is dependent on. The House has passed this legislation overwhelming. The Senate has passed it overwhelmingly legislatively, and it is in conference right now. The administration is opposed to it. I think that's a grave mistake.

### Moderator
Claim: Another question?

Because I haven't gone to the dark section near the camera up there. Yes. Yeah. You're pointing to yourself again. If everybody points to yourself you can all stand up. Can you just step down a little bit into the brighter light so that we can see you and the camera can see you? Thanks. If you just come out to the aisle.

### Moderator
Claim: My name is Reese Schoenfeld and I’m an occasional journalist. And I have an advantage of being a little older than most of you. And I remember 1956 when the voice of America spoke loudly the people Hungary and suggested they revolt. And I remembered what happened afterwards very well. I can say with pride that our organization had one of the two Americans in there covering it at the time. And I think that what happened at Budapest in Budapest, in Hungary would have been absolutely repeated if we encouraged Iranians.

### Moderator
Claim: Can you take this to a question, sir.

### Moderator
Claim: We encouraged Iranian rebels.

### Moderator
Claim: Could you take it to a question, though?

### Moderator
Claim: Yes. Do you think it is more likely that the encouragement of Iranian rebels would have resulted in blood shed and with no progress or that we should have spoken loudly with no ability to protect them?

### Conspiracy Advocate (CA)
Claim: Well, I think that's a fair question.

### Moderator
Claim: Mort Zuckerman.

### Conspiracy Advocate (CA)
Claim: I don't know the answer. I don't know if anybody knows the answer. I think one of the rationales for the restraint of the American administration was to have the Iranian government be able to divert the attention from those people who were at home objecting to their government and to their policies and blame it all on America. And we didn't want to be the lightning rod, so to speak, for the opposition which they would have brought forth against the people who were dissenting. I don't know-- nobody will ever know what would have worked better. I do think that's a fair argument to make. I don't know the answer to that question.

### Conspiracy Advocate (CA)
Claim: I actually-- can I-- as Mort said, it's very difficult to prove as counterfactual, "what would have happened if" but we do know what actually happened, right? The administration chose to be silent, and there was bloodshed in the streets of Tehran. And the dissident leaders we hope are the future leaders of Iran, were saying where is America? That much we know. And we know the whole world watched that happen, where we looked impotent in the face of a major threat to the Iranian regime. We also know that the administration was saying at the time that if we stand back and are silent, this will make it easier for the Iranians to come to the negotiating table with us on a-- disarming their nuclear capability. That was an argument, that it'll help them moderate because they won't feel under siege. They won't feel under pressure, and they'll come to the table. Well, here we are, almost a year later, exactly, and the Iranians, as I said, just mastered 3,000 centrifuges. The IAEA is basically conceding that Iran is well on its way to having a nuclear weapon.

### Moderator
Claim: And with that, and we're running out of time. I want to let Wes respond. I want to let Wes respond to that, and then I want to do more one question.

### Scientific Advocate (SA)
Claim: I think you have to be careful in foreign policy not to adopt a feel-good foreign policy.

### Conspiracy Advocate (CA)
Claim: I agree.

### Scientific Advocate (SA)
Claim: And one of the persistent elements of what we're getting from our worthy opponents is a feel-good foreign policy. It's like, you know, I'm America. Stand up. This is what I believe. That's all well and good, and it goes great in a rotary club where I come from. But when you're actually trying to influence other nations, that kind of logic doesn't work. That's the logic that animated the last administration. It didn't work. We're not going to repeat it.

### Moderator
Claim: I have time for one more question. Yeah, in the white sweater. Yes? The microphone is on its way to you. Thank you.

### Moderator
Claim: Devon Cross. I just would be curious as to both sides, General Clark and Dan Senor, in the business of what America signals its intentions to be, the imposition of the deadline, the withdrawal in Afghanistan, how comfortable you would have been fighting under that and likewise the same for you, sir.

### Scientific Advocate (SA)
Claim: As I understand the question, how comfortable am I that we're going to start withdrawing in 2011? Well--

### Moderator
Claim: The question is how-- how comfortable you would have felt with a deadline in prosecuting a war against an enemy that was imposed by political--

### Scientific Advocate (SA)
Claim: Well, I wouldn't have been comfortable if we'd put a 2011 deadline on getting out of it. I mean, you can't-- you're dealing with a problem that has to be worked. It's not a mechanical process with a machine. So there are other actors involved, there're other intentions. In my view, most of Afghanistan is actually about Pakistan, and, therefore, we've got to take the right actions not only in Afghanistan but also in Pakistan, and the Pakistani system, yes, ma'am, because this is Osama bin Laden in Pakistan, the Pakistani Taliban in Pakistan, and we cannot put a large American force in there and do it directly ourselves.

It's a nation of 170 million people. It's simply beyond the capacity of the armed forces. So somehow we have to use action at a distance, diplomacy, efforts in Pakistan are done by drones and intelligence agencies, and a lot of other effort. So that's not amenable to a hard and fast deadline. I wish it were. But I'm concerned about what's going on in Iraq. I hope that what Bernard says is right. I know the policy makes sense. But these policies are incredibly difficult to execute. And so when Dan says he's worried about it, I'm worried about it, too. But, you know, I think our President has made the right decisions thus far. He's shown strength, he's shown resolve, he's shown proper planning and a deliberate planning process, and we've got to hope our men and women in uniform, and our diplomats, and our Congress will do the right thing to help do our part on this mission.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. Debate.

## Round 3

### Moderator
Claim: So here's where we are. We are about to hear brief closing statements by each of the debaters in turn. They will be two minutes each. And that is their last chance to change your minds before you vote for the second time. So to remind you of your vote on our motion when this debate began, the motion being "Obama's Foreign Policy Spells America's Decline," before the debate began, 23 percent of you agreed with the motion, 45 percent of you disagreed, 32 percent were undecided and here to listen. And we will have you vote again in a few minutes after closing statements. And the team that has changed the most minds will be declared our winner just a few minutes from now. But first, round three, closing statements, and speaking first against the motion, Wesley Clark, retired Four Star General, former NATO Supreme Allied Commander, Europe, and Senior Fellow at UCLA's Burkle Center.

### Scientific Advocate (SA)
Claim: Well, I guess the first thing I would say is that the position-- the power position of a nation is dependent on not only its military, but its economic strength, and its political processes, its decision-making, and a whole host of factors.

And Barack Obama took over a nation-- I'm not going to label it decline, I'm just going to say it was in a hole. And he's tried to work very systematically to pull us up out of that hole, keeping us safe, dealing with other nations. He hasn't accepted the old prejudices. He did not go to China and say, "I won't talk to you unless you release two human rights activists right now," because the issues between the United States and China are not best dealt with in that kind of a public forum. He went to Europe and reassured our allies. He's been very strong in the NATO summits. But he's also tried to reach out to Medvedev in Russia. Maybe it won't work, but he's done as much as he can to line up the strategy, he knows what the crucial decisions are that are coming. And every indication shows our President is a man of strong logic, strong convictions, and a man who doesn't hesitate to make tough decisions when they're necessary. He knows those decisions are coming in this administration, and when he makes them, I think you'll see that America is a strong, capable, and respected nation. America--our foreign policy under Barack Obama spelling America's decline? I don't think so. I think you're seeing America rebuilding itself, pulling itself up by the bootstraps to move forward into the 21st century. Thank you.

### Moderator
Claim: Thank you, Mr. Clark. Our motion is "Obama's Foreign Policy Spells America's Decline," and now summarizing his position against the motion, Dan Senor, Adjunct Senior Fellow of the Council of Foreign Relations. His new book on Israel's economic miracle, "Start-Up Nation," has just come out and I believe is on sale in the lobby. He's a former Pentagon and White House advisor. Ladies and gentlemen, Dan Senor.

### Conspiracy Advocate (CA)
Claim: You know, there was an interesting development about six, eight weeks ago after the administration caused a near rupture in the U.S./Israel relationship over an insult that the administration felt it had been subjected to by the Israeli government over the settlement issue in East Jerusalem. A week later, Secretary Clinton went to Moscow, and the purpose of that trip was to try and get the Russians to get on board on the Security Council for real sanctions against Iran. She arrived in Moscow and everyone knew that was the purpose of her trip, and upon her arrival, the foreign minister of Russia publicly announced that Russia was resuming its building of the nuclear plant in Bushehr, Iran. Welcome to Moscow, Madam Secretary. When a senior administration official was quoted in the Washington Post was asked, do you think that was an insult, he said absolutely not. Now anyone who believes that by the way shouldn’t be a senior administration official. But more importantly, it’s a metaphor for this administration’s realignment of its foreign policy, whether it’s in Latin America, whether it’s in the Arab world, whether it’s in Israel, whether it’s in eastern and Central Europe, we are sending a very consistent message and the leaders in that part of the world are no longer saying it quietly. They are saying it publicly that they feel that America is moving away from its historic commitments to those countries. As you’ve heard tonight, there’s not a single policymaker or government leader, as Bernard and General Clark said, there’s not a single policymaker or government leader that they can cite that is willing to stand with America today and expend real political capital to stand with America. There is-- there are no real concessions to point to for all this outreach we’ve done, for all the speeches that the President has given. As I’ve said before, personal biography is nice and it is moving to win over crowds around the world. It is not a substitute for a foreign policy, especially when your country is in decline.

### Moderator
Claim: Thank you, Dan Senor.

The motion: “Obama’s foreign policy spells America’s decline.” And summarizing his position against the motion, Bernard-Henri Levi, French philosopher and best-selling author.

### Scientific Advocate (SA)
Claim: Yes, to conclude, I think we are entering into a new world with new rules of the game, with new actors, and that means decline is possible. It is a possibility for America. But I believe that President Obama goes against, resists, this possible decline for the following reasons. Number One, he says bye-bye to this terrible illusion which was the neoconservative illusion that you could build democracy just like This is a very important move. Number two, about human rights. I am a militant of human rights all my life, but I know also when you are the chief of the first superpower in the world, you must be accountable for every single word you express. You cannot go to say to the Iranian people, “Go revolt, go in front of the tanks.” And then what? Are you ready to support? Are you ready to wage war or not? Obama has the wisdom not to act this way. Number three, he acts with a very wise mix of strength and retention of strength: fire and holding the fire. He never said that he was against the military option in, for example, the Iranian situation, but he opens the game. And this is what foreign policy is. And at the end, I must say that since a few-- since two years, it is more easy all over the world to be a friend of America.

You can be proud today to be a friend of America, which was not the case three, four, five, or eight years ago. I’m sorry to say that. Thank you.

### Moderator
Claim: Thank you, Bernard-Henri Lévy.

The motion: “Obama’s foreign policy spells America’s decline.” And finally summarizing his position in support of this motion, Mort Zuckerman, chairman and editor in chief of U.S. News and World Report and publisher of the New York Daily News.

### Conspiracy Advocate (CA)
Claim: The reference was made to the economy and to the economic condition of the United States, which I think is a critical part of everything that we’re talking about. We never got a chance in terms of time to do that, but if there is one area where in my judgment we have made huge errors that are going to compound the macroeconomic problems of the United States is in fact the way we have responded to the economic crisis. That in fairness to the extent Obama inherited, but in my judgment the policies he adopted were simply inadequate to the problem, they were wrongly focused. There isn't a country in the world that doesn't understand how serious the problems are for the United States and its economy. And if there is one area where we had a huge reach around the world, it was in the area of the economy. And that, I will suggest to you is the area where this administration has failed the most. And by the way, the people who know it most clearly are the American people. And that's why his support has dropped so dramatically. So without going into that in any more detail because there's no time, I think that it contributes mightily to the conclusions that we would urge you to have.

### Moderator
Claim: Thank you, Mort Zuckerman. And that concludes our closing statements. And now it's time to learn which side has argued best. We're going to ask you again to go to the key pads at your seat and to register your vote now. Our motion is "Obama's foreign policy spells America's decline." If you now agree with this side arguing for this motion, Dan Senor and Mort Zuckerman, push number one. If you disagree with the motion, Bernard- Henri Lévy and Wesley Clark, push number two. And if you remain or became undecided, push number three.

And we're going to have the results actually just in a couple of minutes. It takes an instant to get these in. So before that, I just want to chat about a couple of things. First of all, as I said at the beginning of the evening, this is the end of our fourth season. And we gave a round of applause to Robert Rosenkranz for making all this possible.

I also-- somebody else who absolutely needs to be thanked for making these things happen month after month is the executive producer and her rather spare team of support who put this thing together. It's very, very much more difficult than it would look, not just the care and feeding of all of those people on the stage but the hall, the public-- the publicity, all of it. She does everything but upholster the seats that you're sitting on. So Dana Wolfe, if you'll stand up, it's time to take some credit.

And finally, in light of tonight's debate, I just think it was one of the most intelligent and high level that we've had. I want to thank all of our panelists for this.

A special thanks goes to our venue, Skirball, and our partners, NPR, Bloomberg Television, Newsweek and everyone who has supported this fourth series of debates. On Tuesday, June 8th, Intelligence Squared U.S. is traveling to the Newseum in Washington, D.C. It's the first time that we are holding a debate outside of New York City. The motion is "the cyber war threat has been grossly exaggerated." And it will be debated by top cyber security experts including former NSA director, Vice Admiral Mike McConnell. Tickets are on sale through our website now, so everybody get to Washington. We'll see you there. We will be back here at Skirball in the fall. We will be debating topics that include the rights of terrorists, same sex marriage, bank reform, religion and profiling at airports. To receive updates and ticketing information, make sure to visit the Intelligence Squared U.S. website and sign up for our mailing list. And debate dates are already listed in tonight's program. All of our debates-- as we said at the beginning, all of our debates can be heard on more than 220 NPR stations across the nation.

And you can also watch all of the debates, including this one, on Bloomberg Television. The air dates and times can be found in your program. And don't forget to read about tonight's debate in next week's copy of Newsweek. And you can pick up a current issue on the way out. All right. It's all in. I've just been given the results. Remember, the team that changes the most minds is declared the victor. And here it is. Our motion, "Obama's foreign policy spells America's decline." Before the debate, 23 percent of you were for, 45 percent against and 32 percent undecided. At the end, 34 percent are for the motion, 58 percent are against and 8 percent are undecided. The team against the motion carries the night. Congratulations to them. Thank you from me, John Donvan and Intelligence Squared US.
