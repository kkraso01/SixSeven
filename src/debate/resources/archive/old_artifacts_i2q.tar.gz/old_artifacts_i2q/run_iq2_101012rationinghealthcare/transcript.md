# Debate Transcript

Topic: Ration End-Of-Life Care
Motion: Ration End-Of-Life Care

Debate ID: 101012rationinghealthcare


## Round 1

### Moderator
Claim: Good evening, everyone. Hi. Hello. My name is John Donvan, and I will be moderating the debate which begins in about four minutes. I wanted to have a quick chat with you about a few things relating to primarily your role as members of the audience. Normally, we do these debates in New York, and occasionally we go on the road, and it's really a pleasure for us to be here in Chicago. So I'm going to give you the spiel I give you in New York, which is this: We want you as members of the audience not to consider yourself passive listeners. We need you to be the opposite of that. You actually act as the judges in the debate. You choose the winner of the debate. And the way we have you do that, if you see at your seats, there's a keypad. And at the very beginning of the debate, I'm going to state the motion, "Ration End-Of-Life Care," and, before the debate, you agree with this motion, we want you to register that by pushing number one. If you disagree, we want you to push number two.

And if you're undecided, push number three. And you can ignore all of the other keys at that point. They are not live. And if you push a key incorrectly, just correct yourself, and the system will lock in your last vote. At the end of the debate, after you've heard the arguments, and we're asking you to keep an open mind through the course of the evening. After you've really listened to the arguments and listened closely, we're going to ask you to vote again. And we want to see whose minds have been changed or who came out of undecided to take one of the positions. And the team at the end of the evening whose percentage has changed the most according to your vote is going to be declared our winner.

The second way in which your role is critical as members of the audience is that after a round, a formal round of opening statements by each debater in turn, we will then have a session where it's more mixed up. They can address each other and take questions from me. At that point, I also want to take questions from you. And the way that will work is if you just raise your hand, and I find you, just stand up.

A microphone will be brought to you, and we want you to hold the microphone about this far away from your mouth. I'll explain why in a second. Basically so that we can hear you. We'd like you to state your name and then ask a question. Now, on the question, this does get tricky in New York at least. We don't want you to debate with the debaters. We-- that's what they're here to do. We want you really to ask a question that will move forward the discussion of this motion. What they're really here to debate and persuade you on is this short statement: "Ration end-of-life care." So I'd like you to think in terms of asking a question that focuses on that, not a secondary issue. And I'll be fine if you want to make a short, very, very short opening statement of your premise. But then I want you to get to a question. And you'll know that it's a question because if a question mark goes at the end of the statement naturally, then it's going to work. And I will-- I will respectfully decline questions that are really off topic.

And I may have to step in and help you phrase your question if you're struggling, but I do follow that very respectfully. We are being broadcast ultimately on NPR stations, on NPR-- on podcast downloads, on television in New York, not live, but we are live streaming right now as we speak. But because of that, a few things you need to know. There are certain formalities that we need to observe for the broadcast. I'm going to have to tell you many, many times that we're in Chicago and many times that I'm John Donvan. All things like that come back from the break. So just so you know that I haven't lost my bearings, that there's a purpose for that.

Also, a number of times through the evening, given that this is the home of the great program, "Wait, wait, don't tell me," whose sound is-- whose live studio sound is just spectacular, we want to hear from you in the evening; feel pleased, to laugh, to laugh, to applaud, to express your dissatisfaction as long as it's not in an ugly way.

You know, a well-placed guffaw is fine. We would-- we don't want you shouting out or anything. And-- but again, really give thought to things. And at certain times during the broadcast, during those times, probably just before I introduce myself yet again, I'm going to raise my hand, and that's an obvious signal for, "Can you please give a round of applause?" So I know that we don't even have to practice that. But in the beginning, I'm going to be introducing each of the debaters. It will be great if you could applaud each of them. My hand will be going up for that.

The last thing, because we're doing a radio broadcast, is we have a lot of microphones placed all over the room. And cell phones and Blackberries, et cetera, will cause interference with them if it reaches a certain critical mass. So we're-- we're fine if you're Tweeting about this. In fact, we're delighted by that. If you're live Tweeting, fine, because we don't think there will be enough people doing that to cause problems.

But if you're not using your phone for that purpose, please shut down entirely. And you don't want it ringing in the middle of the debate and then having that be heard on NPR stations across the station as you stifle your phone. So that's it. We're really, really delighted to be here and delighted that we have a full house upstairs and down. And folks upstairs, I need to tell you that our microphones for questions won't go up there. But if you make a special trip to come downstairs, and I notice, I'll try very hard to call on you to come into the debate. So we are put together-- we exist because of an organization called the Rosenkranz Foundation which started Intelligence Squared U.S. with the mission of raising the level of public discourse. And to help us now frame what this debate is, I would like to invite to the stage, to the seats out front, the chairman of the board of Intelligence Squared U.S., Robert Rosenkranz.

So Bob is just going to talk to us very briefly about what's going to happen here, why we're doing this. So what's at stake basically, Bob, in this debate?

### Moderator
Claim: Well, this is one of the most intense emotional kinds of issues that we've ever debated. It raises all kinds of questions about ethics, but it also raises huge public policy questions. In our country, we're spending about 17 percent of GNP on healthcare. Other rich countries spend about 9 percent. And a big driver of that is what's spent in the last year of life. And so like 30 percent of all Medicare expenditures are in the final year of life. And this is frankly driving the huge government deficits that all of us are worried about, and it also, when it gets down to the level of the individual family, it's kind of why families in America have seen no increase in their real incomes over the last decade.

All of the improvement in productivity and growth over that time has gone to healthcare.

### Moderator
Claim: So the side that's arguing for rationing has what going for it as its strongest argument?

### Moderator
Claim: Well, I think the strongest argument simply is that we cannot afford to provide unlimited healthcare, particularly at the end of life, as if it were a free good. There has to be a way to bring in under control. And either governments or insurance companies have to ration end-of-life care as a policy response.

### Moderator
Claim: And the opposite way, the side arguing against rationing.

### Moderator
Claim: The side arguing against would say that healthcare, particularly at the end of life, should be the subject of a discussion between your doctor and your patient and the patient's family. And the argument against is really summed up in very colorful language. No one wants death panels.

### Moderator
Claim: And why this debate now?

### Moderator
Claim: Well, I think the answer is the presidential debate. This is one of the critical national issues. And I expect, because it's such an emotionally difficult issue, it is not going to be debated forthrightly in the presidential debates. So I thought this was a good opportunity to do it.

### Moderator
Claim: So we'll do it here. Thank you, Bob. And so that is the shape of this debate. And let's bring our debaters to the stage.

And I would just like to ask for one more round of applause for Bob Rosenkranz for making all of this possible.

Yes or no to this statement: End-of-life care, we can't afford to keep every elderly person alive, so we're going to have to ration it. Is that right, or is that wrong? Well, since probably all of us at some point want to have our crack at it, when it's our turn, but probably all of us in the meantime, we're going to have to pay for it for everybody else, and since there really are two serious sides to this argument, then let's make a debate of it. I'm John Donvan, a debate from Intelligence Squared U.S. We are in Chicago, Chicago Ideas Week. It is a pleasure to be here.

The motion that's on the table, "Ration End-of-Life Care." We have four superbly qualified debaters, two against two, who will be arguing for and against this motion. Our debate goes in three rounds, and then the audience votes to choose a winner, and only one side wins. On the side arguing for the motion, "Ration End-of-Life Care," Arthur Kellermann, the Paul O'Neill Alcoa chair in Policy Analysis at the Rand Corporation. His partner, Peter Singer, professor bioethics in the University Center for Human Values at Princeton University. The motion, "Ration End-of-Life Care," and here to argue against the motion, Ken Connor, chairman and founder of the Center for a Just Society. And his partner, Sally Pipes, president and chief executive officer of the Pacific Research Institute. Let's start off with "Ration End-of-Life Care," and let's meet our debaters. First, Dr. Arthur Kellermann. Doctor, you worked in and you taught emergency medicine for about a quarter of a century.

That's the front line in this really, and I want to ask you, do you think the rest of us, we, civilians, in this world, really have any idea how often these end-of-life decisions come up in the ER?

### Conspiracy Advocate (CA)
Claim: John, we save a lot more lives than we lose, but we deal with the issues we're going to debate tonight far more often than anyone realizes.

### Moderator
Claim: Okay, and your partner, Peter Singer. Peter is a professor of bioethics at Princeton, and you wrote in the New York Times a few years back that a system of rationing care should include measures of the quality of life but not judgments about moral character or social value. Why not?

### Conspiracy Advocate (CA)
Claim: Well, I think that's not the business of physicians. I think they can judge. There are ways of judging quality of life and life expectancy, but moral character is something different. It's too subjective, I think. I wouldn't like to see it used as a criteria in there.

### Moderator
Claim: All right, Peter Singer. Our motion is this, "Ration end-of-life care," and here to argue against the motion, first, Ken Connor. Ken, you are chairman of the Center for a Just Society, and you played a major role in perhaps the most well known case that centered on end-of-life issues, the Terri Schiavo case, in which the nation and the family was divided over the question of whether to remove the feeding tube from a young woman. The governor of Florida was empowered by the law called "Terri's Law" to become involved in that. What was your involvement in that story?

### Scientific Advocate (SA)
Claim: I represented the governor in defending Terri's Law.

### Moderator
Claim: And the fact that in the end your side lost?

### Scientific Advocate (SA)
Claim: Terri's Law, was struck down by the Florida Supreme Court, and Terry was ordered to die by starvation and dehydration. She did so over a 13-day period. If the court had ordered that of Ted Bundy, it would have been deemed to be cruel and unusual punishment, but that's precisely what it was.

### Moderator
Claim: And your partner, Sally Pipes, ladies and gentlemen. are also arguing against rationing end-of-life care, and you wrote a book called "The Top 10 Myths of American Health Care." So what do you think is the number one myth about end-of-life care?

### Scientific Advocate (SA)
Claim: Well, I think that one should not have to die earlier than one might in order to benefit society and reduce costs. People should have the right to die and to live as long as they can.

### Moderator
Claim: All right. So we have already heard a taste of where this debate is going to go by listening, hearing all of our debaters in these brief introductions. Now, in this debate, you, our live audience here in Chicago, act as our judges. By the time the debate has ended, you will have been asked to vote two times, once before the debate and once again after the debate, on where you stand on this motion. And the team who has moved the most of you to their side by the end of the evening, and it's as a percentage term, will be declared our winner. So let's have our preliminary vote. If you go to the keypads on your seat, you'll see a series of numbers, but you only need to pay attention to one, two, and three.

We're going to ask you to push number one if you agree with the motion, "Ration end- of-life care," That's the side that this side is arguing for. If you agree at this point with this side, if you are against the motion, if you disagree with the motion, "Ration end-of- life care," push number two. And if you are undecided at this point, push number three. My guess is that the undecideds are who these debaters are really fighting for, but not necessarily. We have had a lot of debates where people said that they listened so closely that their minds are actually changed because the arguments were so good.

So we're going to lock that out now. And again, at the end of the debate, we'll have you vote a second time, and the team whose numbers have changed most as a percentage will be declared our winner.

So our motion is, "Ration End-Of-Life care." And on to round one, opening statements by each debater in turn. They will be seven minutes each.

And speaking first, for the motion, Arthur Kellermann, the Paul O'Neill co-chair and policy analyst at the RAND Corporation. Prior to this, he was a professor of emergency medicine. Ladies and gentlemen, Arthur Kellermann.

### Conspiracy Advocate (CA)
Claim: As you hear from each of us tonight, I urge you to not only listen to our arguments, but consider our different backgrounds and our different interests. Since 2010, I've worked for the RAND Corporation. RAND is an independent, nonprofit, nonpartisan research organization that's dedicated to objective analysis of some of the toughest policy questions confronting our country and the world. RAND analysts are expected to be dispassionate and detached. That's not a good way to win an "Intelligence Squared" debate. So this morning I advised RAND I was taking a day of annual leave. And I'm here tonight not as a RAND analyst but as an ER doctor.

Who, as John said, worked for 25 years taking care of severely ill, injured, and dying patients in some of our nation's busiest ERs. The goal of emergency medicine is always to save lives. But you would be surprised how often we have to make decisions in consultation with patients and their families about whether or not initiating heroic measures is, in fact, the right thing to do and what the patient really wants. It happens when a critically ill patient is rushed to the ER in the very last stages of a terminal illness. And that usually happens when the patient's personal physician, well, they never got around to having the conversation. They never got around to talking with the patient about, "What will they want us to do when they reach that point?" So we end up having that conversation with the patient or with their loved ones at 2:00 in the morning in a family conference room or at the bedside.

Now, from a medical or a business perspective, the easiest thing to do, by far, is just full- court press. Start resuscitation, incubate the patient, roll out the breathing machine, put in IV lines. But, you know, it doesn't always accomplish what we want. And rather than prolonging life, it simply prolongs the process of dying. That's why when "Intelligence Squared" called me and asked if I would do this debate tonight, my answer was an immediate yes, not only because of what the patient goes through, but what their family goes through too.

Now, to clarify what we're debating tonight, I think it's important for us to define just what we mean. What kind of end-of-life care are we talking about? Medical and surgical treatments that do not achieve a reasonable goal of medicine should not be used.

Limiting this type of care is not rationing; it's good medicine. Many treatments are used to achieve goals that patients did not want or were not proportionate to the burdens that the treatment imposed, because there was either ineffective communication about the disease prognosis, there is a failure to achieve adequate informed patient consent, or there was no advanced care planning. Avoiding these treatments is not rationing; it's simply rectifying poor-quality care.

And some treatments are deserved, but they're extremely costly and have a very low chance of success. Declining to pay for such treatments is what most people would consider rationing. And my teammate, Professor Singer, will have more to say about that in a minute. But I do think there is one type of end-of-life care that is not used often enough.

It's relatively inexpensive. It's highly valued by patients. And it's effective. It's palliative care. Palliative care is specialized care that's focused on relieving pain, relieving the burden of symptoms, helping the patient to be as comfortable and as functional as they can be as they approach the last days of their lives. Now, two years ago, a group of cancer specialists published an amazing study in the "New England Journal of Medicine." They took a group of patients with a very serious type of lung cancer. And they randomly assigned them to two treatment groups. One treatment group got palliative care and standard cancer treatment. The other group got very aggressive, advanced cancer care. And they followed the two groups. The palliative care group not only had a better quality of life and less depression prior to their death.

They lived longer than the group that got aggressive treatment. This past August another team followed nearly 400 cancer patients during their last months in life. Those that avoided hospitalization and avoided the intensive care unit were less worried. Those who prayed or meditated, those who were visited by their pastor in the hospital or in clinic, those who felt they had a strong bond with their doctors were happier, had higher quality of life and did better in the last days that they had on this earth. So at the outset of this debate, let's assume that our opponents did not come here to defend bad medicine. And you can be confident that Professor Singer and I did not come here to advocate limiting access to palliative care. So that leaves us with a pretty narrow set of situations in a highly charged question: Do patients in the last stages of terminal illness have an unqualified right to extremely costly treatments of uncertain value for as long as they want?

Because if the answer is yes, the rest of us have to be prepared to pay the price. Despite remarkable progress of medical science, the global death rate is still 100 percent. So the question is not whether we're going to live or die. The question is where and how we'll die and who will be with us when we do. Most of us don't want to die in an intensive care unit strapped to a bed under fluorescent lights separated from our loved ones. Yet that's precisely what happens to too many of us because all too often our healthcare system is too focused on making money, too preoccupied with its technical prowess and too busy to sit down with a patient and have an honest, thoughtful, candid conversation about prognosis and the patient's wishes at the end of life. As a physician, my goals are simple: To save as many lives as I can, to ease pain and suffering when I cannot, and always, always treat my patients with compassion and respect.

That's why at the end of this evening I urge you to vote for the proposition. Thank you.

### Moderator
Claim: Now, arguing against the motion, Sally Pipes. She is president and chief executive officer of the Pacific Research Institute. She also writes a weekly health column for forbes.com and is the author of "The Pipes Plan: The Top Ten Ways to Dismantle and Replace Obama Care." Ladies and gentlemen, Sally Pipes.

### Scientific Advocate (SA)
Claim: Thank you, John. And I am against the proposition that we should ration end-of-life care. My mother was Canadian and a senior. In July of '05, she felt she had colon cancer. Her primary care doctor said she did not because he did an X-ray and no cancer showed up.

Well, we all know that colon cancer is not detected by an X-ray but by a colonoscopy. But she could not get one in Canada because of her age and the fact that a waiting list for people under 65 with colon cancer symptoms was over six months. So by late November, my mother was hemorrhaging and had lost 35 pounds. She knew she was ill, and she went to the hospital in an ambulance and went to the emergency room, spent two days in the transit lounge. Then she did get her colonoscopy. But sadly, she passed away two weeks later from metastasized colon cancer. This is the outcome when government bureaucrats set the rules for who is going to get care and when. This is rationed care and what will face seniors in America if the Affordable Care Act is not repealed and replaced.

Rationing care at the end of life may be a sound solution in the abstract. But when it comes to your mother, your father or your child who has a terminal illness, it is wrong for social engineers and government bureaucrats to make these life decisions for you.

In Canada where I grew up, the government spends 11.4 percent of gross domestic product on healthcare. And private health insurance is outlawed. The government sets a global budget, the one that government can afford. The demand for healthcare is much greater than the supply. As a result, Canadians spend-- and they have long waiting lists, rationed care and lack of access to the latest treatments. 17 percent of Canadians are waiting to get a primary care doctor. In 2011, 940,000 Canadians were on a waiting list waiting for treatment. The average wait in 2011 from seeing a primary care doctor to getting treatment by a specialist was 19 weeks, up from 18.2 weeks the year before.

In the case of my own mother, it may have shortened her life, but it was definitely cheaper for the government. In the case of my mother, it may have shortened her life. But colon cancer is one of the most common diseases among our seniors. A study published in the British journal Lancet Oncology, suggests that America is one of the best countries for treating cancer and survival rates five years after diagnosis for 13 of the 16 most common cancers. Do we want to change this outcome by controlling healthcare costs through rationed care? For example breast cancer survival rates among American women is 83.5 percent, whereas in Britain, it's only 70 percent. Prostate cancer, survival rate 92 percent in the U.S., only 51 percent in Britain.

So how will the Affordable Care Act ration care for our seniors and in particular those in need of healthcare? In three ways: The Independent Payment Advisory Board, accountable care organizations and the patient-centered Outcome Research Institute. First, IPAB; on October 1, President Obama and Governor Romney spent a lot of time debating the issue of IPAB. IPAB will be a panel of 15 unelected members appointed by the president and approved by the Senate whose job it is to cut Medicare spending. It will go into effect when federal spending by doctors and hospitals on Medicare exceeds the average Consumer Price Index growth rate between 2014 and 2018. After that, costs will be tied to GDP growth plus 1 percent.

The board must propose spending cuts. Congress could overrule the board, but only if it has a 3/5 majority in the Senate and the House or comes up with another plan to reduce costs. The accountable care organization is second. They are delivery models for doctors and hospitals to give them financial incentives to provide good quality coordinated care to Medicare beneficiaries while keeping costs down. They would benefit by sharing in savings with the government if costs are lower than projected for treating Medicare patients. If higher, ACOs would have to pay back funds to the government. It is my belief that doctors and hospitals will ration or deny care to seniors if they feel that their costs would exceed the ceiling. ACOs are a giant HMO.

Third is the Patient-Centered Outcomes Research Institute (PCORI). It is similar to NICE in the UK, a government agency that determines which treatments are cost effective as compared to medically effective.

While no one can deny that there are problems in American healthcare, a system that empowers doctors and patients will solve them, not the federal government. I do think that everyone here would agree we all want affordable, acceptable quality care. How do we achieve that goal? Well, I believe there are two competing visions when it comes to healthcare reform and achieving universal coverage. One focuses on doctors and patient-centered solutions. The other focuses on increasing the role of government in our healthcare system. That was President Obama's vision. Liberal politicians, academics and the elite media tell Americans that socialized assistance such as exists in Canada and Europe are better and cheaper and can provide universal coverage for all.

And while it is true that 5 percent or 2.5 million seniors in their last year of life consume 25 percent of Medicare spending, it is still my belief it is not the government's place to limit costs by sacrificing lives. End-of-life decisions should be made by doctors and families, not bureaucrats such as those on IPAB and PCORI. They will ration the care our seniors receive, and I believe that is ethically and morally wrong. In my view, people have every right to live as long as they can. Therefore, I urge you to vote against the proposition. Thank you.

### Moderator
Claim: Thank you, Sally Pipes. And we are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion, "Ration end-of-life care." You have heard the first two opening statements, and now on to the third.

Debating for the motion, "Ration end-of-life care," the Ira W. DeCamp professor of bioethics at Princeton University, he's been called the most influential living philosopher by the New Yorker and is the author of a number of books including "The Life You Can Save" and "Animal Liberation." Ladies and gentlemen, Peter Singer.

### Conspiracy Advocate (CA)
Claim: Thank you very much. It's the position of our side that we are already rationing health care, so in a sense we can't really debate whether we should do so. The question that we can discuss is whether we should be open and explicit about what we're doing, and, therefore, try to do it in the best, most thought-out way possible, which essentially means, "Do it in the way that gets the best value for the health dollars that we're spending now," or whether we should continue to do it in a way that we don't bring out in the open so we cover up, that we don't really dare to discuss.

And we can see that politically it's not really a topic that people dare to discuss openly, and as a result, more people will die who could be saved than will die if we use the money we're spending effectively.

Now, it's clear that we are not spending our health dollars effectively in this country at present. We spend about between 17 to 18 percent of everything we have, of our gross national product, on health care. That's about 50 percent more than other comparable countries, the other industrialized countries that we compare ourselves with. There is no evidence, no evidence that we get any better outcomes for the extra 50 percent that we're spending, the extra 7 or 8 percent of GDP that we're spending, than those other countries.

And Dr. Kellermann will give you a more detailed rebuttal to what Sally Pipes just said when she specifically focused on cancer in those remarks. When we looked at not just what the health system does – but at health outcomes in America, we're actually terrible. It's the combination of what the health system does and our general health. We rank in terms of health outcomes somewhere around the level of countries like Slovenia and Costa Rica. They are countries that are much poorer than we are, and yet their health outcomes are comparable to ours. And the other industrialized nations have better health outcomes, including, incidentally, Canada.

It's also true-- it's also true that when you ask Canadians, as Gallop did a couple of years ago, and Americans, and Britons, people in the U.K., do they have confidence in their health care system, the Britons and the Canadians, 73 percent of them, just coincidentally the same number, say, "Yes," they do. When you asked Americans, only 56 percent of them say they do. I think that there's a general feeling that this health care system is not delivering what we want. But as I said it is rationing. It rations in many ways. For example, we about 44 million people, Americans, now, who are not insured at all. That number will drop significantly when Obama Care comes into effect, but it will not unfortunately drop to zero. Now, not being insured means that you are more likely to die if you have a serious illness or accident. In fact, Joseph Doyle, a MIT scientist, looked at people who were brought into emergency care as a result of road accidents, seriously injured.

And found that those who were uninsured died at a higher rate even when adjusting for other variables than those who had insurance. And when he calculated how much it would have cost to save these people's lives, it would have been about $280,000. Reasonable amount of money. But that was how much more was spent on saving the lives of the others. But given that these were mostly fairly young people, in terms of how much it would have cost to extend their lives for one year, it would be about $5,500. These people's lives were lost because we were not prepared $5,500 for each year of life that we could have saved. Compare that with the amount that those much criticized bodies Sally Pipes mentioned NICE, the National Institute for Clinical Excellence in the United Kingdom.

What they say is too much to spend. Apparently, NICE’s figure is around $49,000. In other words, almost 10 times, nine times as much as would have saved the lives of these young accident victims. And of course, we ration in a lot of other ways as well, because some people can't afford copayments. We have long waiting times. We don't pay doctors enough for Medicare, and so they don't take Medicare patients, or they don't take so many Medicare patients. So we are losing lives, and we're losing lives that we could save quite cheaply.

So I think we ought to be more explicit about this. We ought to be prepared to say, "Let's use the dollars--" maybe we should spend more dollars. I'm not necessarily opposed to spending more dollars. But let's use the dollars we spend in the most effective way in order to save the greatest number of lives.

Something has to be done, because health care costs are rising here much faster than the economy is growing. They're rising at 9.8 percent per annum. We all know the economy is not growing at anything like that amount. So as that keeps happening, what's going to happen? It will eventually soak up all available spending. But we know the government has to spend on other things. On the website, in the articles that were posted. There's a very moving piece by Ken Connor about the plight of elderly citizens in our country, how they are neglected, and how because of the demographic changes, there's going to be more of them. Effectively, we need to spend a lot more to give our senior citizens a comfortable and dignified life when they can no longer look after themselves. That costs money, and it's going to cost more money.

We cannot increase health care spending indefinitely and also spend more on the elderly and spend more on the environment, on education, on all of the other important things that we need. So, like it nor not, we are rationing health care. We are arguing that, indeed, we should. That's obvious. But whether we should be more explicit about it, because we want to get the best results we can. We want to save the most number of lives that we can. And the way to do that is to be explicit and vote yes for this motion. We should be rationing health care. Thank you.

### Moderator
Claim: Thank you, Pete Singer. And our final debater will be speaking against this motion. It's Ken Connor. Ken is chairman and founder of the Center for a Just Society. He is a successful trial lawyer. He represented Governor Jeb Bush in the long-running Terri Shiavo case, and for several years served as president of the Family Research Council. Ladies and gentlemen, Ken Connor.

### Scientific Advocate (SA)
Claim: Good evening, ladies and gentlemen. Sally Pipes' mother's situation is exhibit "A" for why Americans don't want the government to wind up rationing health care in this country. By contrast, my mom suffered from advanced colon cancer late in life at an older age than Sally's mom. She received aggressive treatment, both surgery and chemotherapy, made a full recovery, and went on to live more than a decade of a good and healthy life, until she finally died at 90 at home in good health in her own bed.

Which system would you prefer? Ladies and gentlemen, I'd like to make three points, if I may, about why government should not be in the business of rationing health care.

First of all, health care decisions should be made at the end of life, just as at any other point in life, at the bedside, by the people involved and who are affected, not by bureaucrats at a remote location.

Secondly, that rationing is unethical, because it ultimately devalues human life and inevitably winds up punishing the sick and the dying.

Thirdly rationing is the lazy man's way-- lazy man's attempt to balance the budget. It's easier to balance the budget on the backs of the sick and dying than it is to reform your ways of wasteful spending in government and try to wrench money back from the hands of the special interests at home and abroad. So back to the premises, first of all, that healthcare decisions should be made at the bedside. Americans don't want bureaucratic bean counters in Washington making decisions about what kind of care they're going to wind up receiving at the end of life. Decisions about healthcare and how it ought to be administered and when it ought to be administered ought to be decisions that are made by the patient informed by their doctors and by their families.

Decisions about what kind of care will be administered at any given time to any given patient should take into account the needs of the patient. In other words, healthcare should be both individualized and particularized to the needs of the given patient. A bureaucrat remote from the bedside, hundreds, perhaps thousands of miles away practicing assembly line medicine simply is not in a position to make those kinds of individualized decisions that are required. These are decisions that have to be based real time, sometimes at 2:00 or 3:00 a.m. in the morning as Dr. Kellermann has pointed out. And it's the people who have their feet on their floor-- on the floor in the hospital and their hands on the patient who ought to be making these decisions.

There's simply no way that a government functionary practicing assembly line medicine in Washington can make those kinds of decisions. Healthcare requires the fine edge of a scalpel, not the blunt end of an ax. And patients don't want their doctors straight- jacketed by some bureaucratic straightjacket fashioned in the federal city. They want decisions made by doctors who are taking their interests into account. They don't some interest that was decided in a smoke-filled room in Washington, in a room that was predominated by lobbyists to be the ones who are making the decisions.

And, folks, do we really want the men who are wearing the green eye shades in Washington to be making these kinds of decisions? Should cost be the primary driver of such decision, especially in the zero sum environment that prevails in Washington?

I would submit to you, ladies and gentlemen, that when the tradeoffs are made, we don't want decisions about healthcare to go by the board in preference to a new start in green energy or some other pie in the sky kind of effort. Now, no one is suggesting for a moment that we should not be good stewards of scarce healthcare resources. We absolutely should be. But rationing is not what we need. It's rational care. We ought to be asking ourselves, is the procedure under consideration necessary for the patient? Is it clinically appropriate? Is the cost reasonable compared to similar services? These are questions that ought to be answered by people with their feet on the ground in the hospital in real time by hospitalization-- hospital utilization committees and not by people who are removed from the bedside.

Now, folks, make no mistake about it, government rationing represents the first step down the road to the utilitarian philosophy of former Colorado governor Richard Lamb who said, "The elderly have a duty to die and get out of the way." This philosophy sees the elderly and the handicapped as resource hogs whose useful life is over and who now costs more to maintain than they produce. They reject the sanctity of life ethics that has long prevailed in this country, and that maintains that every human life is precious and out to be respected and protected under the law. That view affirms equal protection for all, the old, and the handicapped to the very young and to the very old. Instead the quality of life advocates maintain that we should use quality of life calculus and functional capacity studies in deciding who lives and who dies.

Of course, the elderly and the handicapped who suffer from dementia and disability don't score well using those formulas. And isn't that the point? Ladies and gentlemen, what criteria will the all-wise bureaucrats use to pick winners and losers at the end of life? Will they be any more successful than they were in picking Solindra and Bright Source and Abound Solar on whom the government squandered billions of dollars? But then again, what does it matter? At the end of life, we're all going to die, right?

Folks, I would suggest to you that there are many places that we can look to find the savings that we need to provide appropriate care for the sick and for the dying. For heaven's sakes, we spent $4 trillion on the Wall Street bailout to rescue businesses that engaged in profligate spending practices.

Surely, we can spend the money required to render appropriate healthcare to the sick and the dying. Ladies and gentlemen, I urge you to vote against the proposition because by the time you reach the end of your life, you'll be glad you did. Thank you.

### Moderator
Claim: Thank you, Ken Connor. That concludes round one of this Intelligence Squared U.S. debate.

## Round 2

### Moderator
Claim: Now we'll have the debaters address each other directly and also answer questions from me and from you in the audience, we have two teams of two. Arthur Kellermann and Peter Singer are arguing for the motion: "Ration end-of-life care." And we have heard them say basically that we already are rationing, that healthcare is rationed right now by the ability to pay for it by the individual and that it is time to be explicit, to ration in a different way, to step up and admit that's what we're doing and figure out a system for doing it.

They say that you need to figure out how much saving a life produces in terms of results. You have to compare that to how the resources could be used elsewhere. The team arguing against the motion, Sally Pipes and Ken Connor, argue that rationing end- of-life care is the wrong way to balance the budget. They say that it would be falling to government bureaucrats to make intensely personal decisions, that cost should not be the driver of a decision regarding the end of life, and that they depict a future where basically the elderly will be thrown overboard. Now, I notice that the two sides do agree that cost cutting needs to happen, that costs are out of control. They do agree that ideally these decisions will be made at the bedside by doctors and their families. The question is, who ends up controlling where the money comes from. And I want to put to the side arguing in support of rationing end-of-life care, particularly to Peter Singer, this basic question: Is there a way actually to arrive at a dollar value for what a few more months of life would be worth to an elderly person versus what it would be worth to a younger person?

And does that explain whether-- does that price carry over to whether a procedure is worth pursuing or not? Can you put a dollar number on these things?

### Conspiracy Advocate (CA)
Claim: It's very difficult to agree on dollar numbers. I mean, healthcare economists try to do it because really what they're doing is they're comparing what you get for your money if you spend it on one thing, let's say saving young people's lives and what you get for your dollar if you spend it on something else, perhaps let's say for cancer where it can only extend life by two or three months at significant expense. And I think what they can clearly say is we get better value in some cases rather than others. We extend lives for longer for the same amount, or we extend lives for an equal amount for less money.

### Moderator
Claim: You said in your opening remarks that younger lives are less expensive generally speaking to save than older lives with the outcome of a longer life lived because the person's younger rather than older. Am I reading you correctly?

### Conspiracy Advocate (CA)
Claim: Well, I think most of us would agree that it's a greater tragedy if a 20-year-old dies because they're in an accident and didn't have health insurance than if an 85-year-old dies. I think, you know, we would feel that people have lived most of their life, achieved most of what they're going to achieve when they die in their 80s, let's say. It's still sad, of course. I know it's sad. But it's a greater tragedy. It's worth spending more to prevent if we can save the life of somebody who still has most of their life in front of them and still has a lot of things that they can achieve.

### Moderator
Claim: All right. Sally Pipes I'd like your response to that in light of your saying in your opening remarks that each of us has the right to live as long as we can. Does age come into it? Do the young-- do the younger have more of a right to live as long as they can than the older?

### Scientific Advocate (SA)
Claim: No. I believe we all have the right to live as long as we can. Only when someone has died can we actually measure the cost of what the cost of keeping that person alive is.

But I think that people should be able to get the best healthcare they can and not have their care rationed by government bureaucrats. But you know, we all want to live longer lives, have affordable, accessible quality care. How do we do that? Well, we have to make some changes to our health care system. I believe in empowering doctors and patients, making changes to Medicare and Medicaid, changing the tax treatment because for people who have--

### Moderator
Claim: Sally, can I interrupt? But you made that point in your opening statement. And I want to kind of keep on this question that the other side has raised about-- and you were beginning on it-- on this question of older versus younger, that they're-- what they're constructing is the notion that if you save the life of a person who then lives for 50 years, that, therefore, there's more value in that than saving the life of a person who lives for two years. You get 25 more years of life out of it. And it's a mathematical calculation. And I want to know how that sits with you, that-- to take math and dollars - - and dollar figures to apply to these very sensitive issues.

### Scientific Advocate (SA)
Claim: Well, I would say I don't think we should be using mathematics to determine this. We should give people the best opportunity to get the best care that they can, regardless of their age. I mean, if you take an issue like infant mortality, people assume and probably will say, "Well, infant mortality is much higher in the U.S. than it is in countries in Europe," but you have to compare apples with apples. You know, Americans have-- we have the best neonatal care. When the children live-- survive a lot more in this country because they have this good neonatal care, in countries in Europe, they determine that as a fetus or a newborn, if under a certain weight and a certain length, they're not counted as a live birth. So I think we don't want to put dollars and cents on this. We want to give everyone the best possible care. And how we get there is-- well, we can talk about it a little bit later.

### Moderator
Claim: All right. And Ken Connor, your partner.

### Scientific Advocate (SA)
Claim: John, I'd like to weigh in against that kind of a calculating.

In America, we hold to the proposition that all men are created equal. Equal protection under the law is the hallmark of American justice. And I would suggest to you that any point of view that says that a person's dignity diminishes with age or that somehow their personhood erodes as they get older is a point of view really that is a bankrupt point of view. And inevitably that point of view will endanger everyone who reaches old age or anyone who should suffer from the slings and arrows of misfortune and wind up suffering a serious illness or injury.

### Conspiracy Advocate (CA)
Claim: But we haven't said their dignity is less or that their personhood is less. What we said is that they have less years to live. And that's a different question.

### Scientific Advocate (SA)
Claim: Well, let me ask you this point, if I may, you've been an apologist in your book-- in your books for infanticide, making the point that disabled infants who lack rationality or the capacity to grasp that they existed over time or that they lack some form of self consciousness were somehow not persons and could be disposed of, indeed you've gone so far as to make that argument about all newborn infants, maintaining that within a period of, say, 28 days after birth, parents should be able to decide to get rid of them or not.

### Conspiracy Advocate (CA)
Claim: Point of order.

### Scientific Advocate (SA)
Claim: My question would be--

### Conspiracy Advocate (CA)
Claim: Point of order.

This is not the topic we're debating tonight, but I'm happy to debate it some other time.

### Scientific Advocate (SA)
Claim: Well, it is the topic.

### Moderator
Claim: I want to give Ken a chance to relate it.

### Scientific Advocate (SA)
Claim: And here's the point I would make, old people who suffer from dementia often lack self awareness. They often lack the capacity for rationality. They often lack the capacity to grasp the notion that they exist over time. Would you declare them non-persons and say that they are not worthy of protection and preservation, as you have in the case of--

### Moderator
Claim: Okay, Art Kellermann, because I'm not hearing them make the argument in that extreme way, but I want to--

### Conspiracy Advocate (CA)
Claim: I just got to get a couple of things sorted out here. I'm easily confused. First of all, I want to make sure I came to the right debate tonight because I came here to debate whether-- how we approach end-of-life care. I did not-- I just want to make sure I'm at the right debate, because I'm not here to debate Solyndra, Wall Street, ObamaCare, or the presidential election. I'm just confused, but I'm southern, and we're easily confused. So second question is are we here to debate an elderly person's right to super expensive care paid for by the government versus simply very expensive care that we all agree is probably a reasonable deal, or are we here to debate whether or not poor people and other folks can get decent care versus no care, because I personally believe in the sanctity of life, but I think the sanctity of life extends beyond birth and goes all the way up and doesn't sort of kick in again the last few weeks before death.

It extends throughout life for the uninsured, the poor, and working class folks, too. And they should be part of this discussion.

### Scientific Advocate (SA)
Claim: Exactly my point. And the point is, we're going to use some kind of criteria to decide who lives and who dies. And for instance, if the eminent Dr. Singer were to become the rationer in chief in the next administration, what criteria would he use? Would we look at the elderly, the demented, the disabled and say that their quality of life years don't merit preserving their lives? Would we say that, as in the case of the infants that he's identified, that they are not persons whose lives are worthy of protection and preservation? Ideas have consequences. What we believe determines how we behave, and this logic applies at the end of life no less so than at the beginning.

### Moderator
Claim: Let's take one specific part of your question that relates most closely to this motion, to Peter. And, you know, if you were the rationer in chief--

### Conspiracy Advocate (CA)
Claim: That's not a very likely scenario.

### Moderator
Claim: No, it's unlikely to happen for anyone. But do you have a system? Or do you have the outlines of a system? Do you have a philosophy about how this should be approached?

### Conspiracy Advocate (CA)
Claim: I would try to look at the number of years that we can expect to extend people's lives for a given number of dollars. I would also try to look at the quality of life as well. Now, that certainly may be affected by dementia, but, in addition, especially with older people, I would hope that they would be encouraged to state their own wishes as to what should happen to them if they become demented, or if other things happen to them.

### Moderator
Claim: But, Peter, assuming that you're correct, that you're not going to get the job, what body do you see making the decisions?

### Conspiracy Advocate (CA)
Claim: So I think, actually, although it's much criticized, I think that the U.K. model of setting up-- they have a National Institute for Clinical Excellence.

Sally referred to it by its acronym, NICE. Not everybody thinks it's nice. But what they do is, they try to cost the various treatments that are out there, and they try to get expert data on how long those treatments extend life in a variety of different conditions, and they make recommendations. They're not binding, but they make recommendations to the local area health authorities throughout the United Kingdom to suggest that this treatment does give value for the money; you should be providing it. But perhaps this treatment for this specific condition is above the bar that we think reasonable, and you may consider not providing that. And the health authorities then reach those decisions.

### Moderator
Claim: And how often-- if you happen to know-- how often is there a recommendation not to use a particular intervention or treatment? Is it uncommon, or is it pretty common?

### Conspiracy Advocate (CA)
Claim: It's relatively common that there are some treatments for some specific conditions that are considered too expensive to provide. And I think that that's going to be inevitable, because medical technology really has no limits to how much it can cost, and the drug companies can charge more. In fact, drugs are much cheaper in the United Kingdom because the manufacturers know that if they price them very high, they're not going to be recommended by NICE, whereas here they can basically charge whatever they like, and they're still going to get users.

### Moderator
Claim: Let's hear from your opponent Sally Pipes.

### Scientific Advocate (SA)
Claim: So you are a proponent of NICE, which I think the Patient-Centered Outcomes Research Institute is patterned after, but if you read the British press about people-- the quality- adjusted value of life. If you're, say, 68 years old and the actuaries within the National Health Service bureaucracy say, "Your life is worth $49,000." You may have been diagnosed with a severe cancer, macular degeneration, but if the drugs to take care of this are costing more than $49,000, you are denied care in the United Kingdom.

Read the British press, the Daily Telegraph, the Daily Mail, any of it. People are complaining all the time, even ex-employees at the National Health Service will say, "It's wrong that we cannot get the care we need because it may be medically effective but it's not cost-effective." And on the issue of pharmaceuticals and medical devices, yes, drugs and medical devices are cheaper in Canada and in the U.K. and other countries in Europe. They don't develop these drugs and medical devices. The United States is the entrepreneurial capital for developing drugs and pharmaceuticals. Pharmaceuticals cost about $1.3 billion from the idea until it gets through. These other countries-- Canada, Britain-- they free-ride off our R&D, and it is wrong.

### Moderator
Claim: Sally, one question for you when you were describing what the British are doing, saying no to certain procedures that are not considered cost-effective or not effective enough to justify the cost. Don't insurance companies do that all the time?

### Scientific Advocate (SA)
Claim: Yes, insurance companies make decisions based on actuarial evidence. Would you prefer the government to making decisions about what drugs and treatments you can't, or would you prefer the private sector and insurance companies to make those decisions? I, personally, want insurance companies-- I prefer insurance companies.

### Moderator
Claim: Well, you know-- let's-- let's show some respect to this-- can you-- why would you prefer the private sector to do it, to the government?

### Scientific Advocate (SA)
Claim: Because the private sector provides all things that we-- we can make decisions about what kind of cell phones we want, what kind of bank accounts we want. The private sector is always good. But the problem in this country is that 50 percent of our healthcare today is already in the hands of government through Medicare, Medicaid, CHIP and the VA system. We don't have a private market. We need to move to a three- year market, get insurance away from employers. 60 percent of Americans have their healthcare through their employer. And if they don't like the plan or whatever, you're stuck with that. But if you lose your job, you lose your insurance, you go into the private market, you have to buy your insurance with after-tax dollars.

I want to see the tax code changed so that we can move to a more individualized basis on health insurance just like our car insurance, our life insurance, our long-term care insurance. This is the way America works. It's what makes America great. And we don't want to move to a Canadian style single-payer system which I think the president, Nancy Pelosi and Harry Reid, that is their ultimate goal.

### Moderator
Claim: Let me ask--

### Scientific Advocate (SA)
Claim: We will have Medicare for all.

### Moderator
Claim: Let me ask your partner, Ken Connor this point. We do have smaller versions of single payer systems. We have Medicare, we have the Veterans Administration. They have to make decisions. They have to cut costs. Do they need to-- do they need to have a system of rationing in the system that exists now as opposed to-- as opposed to what you're proposing a solution which just is not the world that we're in today?

### Scientific Advocate (SA)
Claim: Well, I think it's important to understand, as a practical matter, the truth of the notion that he who pays the piper gets to call the tune. And so it's a practical matter. Whoever's making those payments, in large measure, is going to call the shots.

What we advocate, though, in contrast to a central bureaucratized, central planning, decision making process is that we have consumer-driven decision making, informed by medical advice, mediated by markets. We believe that that system is a better system than the government system. We believe that that system is a better system and that those-- that's a better way to make decisions than relegating it to the people who brought us the bridge to nowhere, Solyndra, the Wall Street bailout. Now, look-- look, folks, plain and simple. There's an economic concept that our physician friend may not be aware of. It's called opportunity cost. And-- and your proposition assumes the fallacy of only two alternatives: Either we recoup the money from the sick and dying, or we don't.

But my point is there are other ways to recoup the money from other areas where we are wasting money. And it's much easier to balance budgets on the back of the sick and dying than to wrench it out of the hands of the special interests in Washington.

### Moderator
Claim: Arthur Kellermann.

### Conspiracy Advocate (CA)
Claim: I'm real glad I got a chance to talk.

Let's talk for just a moment about exhibit A, Sally. As a doctor, I've got to tell you, I've heard that story before. And I don't think –

### Moderator
Claim: Remind people just tuning in to--

### Conspiracy Advocate (CA)
Claim: Oh, yes. The story earlier about your mother not getting the colonoscopy she needed. And I feel badly about what happened. But I have to tell you, I don't think a government bureaucrat was the one who made the mistake. I think you got a bad doc. And the fact of the matter is-- I know this may come as a shock, sometimes Canadians screw up. If they didn't, we'd never win the Stanley Cup.

And Mr. Connor--

### Scientific Advocate (SA)
Claim: And Canadians are really nice people.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: And they are very patient, not like patients in need.

### Conspiracy Advocate (CA)
Claim: Yeah. Mr. Connor-- I'm with you, brother, on the market incentive. So let me suggest a market-based solution to what we're talking about. I think there's a big difference between deciding what we as a society can afford to commit folks to get, whether it's in ICU at the end of the life or whether it's at 25 years old when you're trying to get your first job and starting a family. And let's commit to that level of financial protection and coverage that we all kind of want to buy into. If beyond that, whatever that is, whatever we as a country decide we are prepared to shoulder, you can buy it. Sally, you could buy it. If you want Avastin, and it's worth $100,000 a year to pay for it out of your pocket, and you want to use your children's inheritance, go for it. It's okay with me. But I've got a problem with you using our inheritance to buy your Avastin if we don't have the evidence that it makes a difference. So let's have a market-based solution. That's the deal today that 50 million uninsured Americans get, except they don't even get a basic level of coverage. It's all out of pocket, or it's on the charity and mercy of individual doctors and hospitals. That's a pretty lousy deal.

### Scientific Advocate (SA)
Claim: Well, when you analyze the 48.6 million Americans who are uninsured, it doesn't mean they don't get healthcare. Anyone in this country under the federal law can turn up an emergency room--

### Conspiracy Advocate (CA)
Claim: I know we take care of them.

### Scientific Advocate (SA)
Claim: So but let's look at that 48.6 million. 14 million of them are people who are eligible for Medicaid and CHIP and haven't signed up. We're going to be adding 11 to 12 million more to Medicaid under the Affordable Care Act. Why have these people not signed up for Medicaid? Well, I believe doctors are reimbursed 35 to 42 percent below what they get from treating private patients. So Medicaid patients find it very difficult to get a doctor. This is only going to get worse.

The other point is that there are about 20 million of these people are people that are young people, like a lot of you in this audience. You're between 18 and 31. You're the young invincible. You don't want to spend $400 to $500 a month on healthcare. So you don't. You'll pay out of pocket when you need it. There are only about 9 million Americans who are chronically ill without health insurance for a period of two years or more. Those are the people that I want to take care of and that we should be taking care of. But you know, in the UK, in the country, if you decide that you want to buy Avastin because the actuaries have said your quality adjusted value of life is not worth the 80 to 90,000 a year for Avastin, you can pay out of pocket. But you are then out of the national health service. The government says you cannot get any more treatment from the government. And I feel that is not fair.

### Conspiracy Advocate (CA)
Claim: Yeah, but we don't support that system. I mean, that's not--

### Scientific Advocate (SA)
Claim: I know. But this is what-- under the PCORI under IPAB, under accountable care, this is what is going to happen to people in this country.

### Moderator
Claim: Let me bring in Peter. Let me bring in Peter Singer.

### Conspiracy Advocate (CA)
Claim: Well, let me just say, I mean, I've spent most of my life in Australia as you can probably tell from the funny way I speak. And we have universal health coverage, but we also have private insurance. It's not like Canada. You're not out of the Medicare, as we call it. You're not out of that scheme by taking out private insurance. It just gives you, if you want to do that, extra coverage for various things that you can do. So it's an option and--

### Moderator
Claim: All right. I don't feel I'm doing a very good job as moderator tonight.

I'm sorry. Because I want to shape this back to what we're talking about as a tradeoff of what you get for what you pay, and are you willing to pay it, and is it wrong to deny that payment? And I-- you know, Ken Connor, you actually did put your finger on it when you said that, he who is paying the cost gets to call the tunes on this. And right now we are in a world where Medicare is taking care of an awful lot of people. And it's very expensive. We know a crisis is coming.

Given where we are on that, their argument that at some point you have to say no, and let's figure out a way to say no, and let's make it fair for everybody, which is the principle of rationing, that if there's not enough of something to go around, you set up a system so that everybody gets an equal shot at it. But everybody doesn't get all of what they want. Just-- just that concept, what do you think of-- what is wrong with that? Because I know you think that it's wrong.

### Scientific Advocate (SA)
Claim: Well, I think you're talking about fundamental fairness here. Let's think of it in these terms: How fair is it when you pay into something all your life, you get to the end of your life, when you really need it, you've been told that you're paying in to receive healthcare, and you get down to the point when you really need it and say-- and the government says, "Sorry, you're going to cost us too much." Isn't there a fundamental fairness issue in that regard? No. We're going to take the money that you paid in over time, over all these years, and we're going to give it to younger people because they don't need as much of it as you do. Isn't that why we paid into it all of our lives? Isn't that-- isn't that part of fundamental fairness, is getting what you pay for?

### Moderator
Claim: Okay. And the question we'll put to this side out of this is that he's actually portraying what sounds like a very ugly situation. You're old, you're-- you got two years left. We got a limited amount of money. That group of kids over there, they've got all their lives in front of you. Sorry, Charlie. You're off the boat. It does sound ugly, nasty, and very hard to take. And I want you to take on that side of the argument.

### Conspiracy Advocate (CA)
Claim: Well, the only problem is that's not how it works, and that's not what we're talking about.

### Moderator
Claim: That is what we're talking about.

### Conspiracy Advocate (CA)
Claim: I mean, we're talking about, again--

### Moderator
Claim: No, it is-- but, Art, it's-- we are talking about having to make these hard choices and saying no to some people.

### Conspiracy Advocate (CA)
Claim: Yeah, well, no, what we're saying is we want to give everybody good, decent, high- quality, evidence-based medicine and care, including and especially palliative care at the end of life. But if you want a super expensive drug or an unorthodox treatment, it costs a freaking fortune.

And it is way beyond what we think as a society private insurance’s actuaries or the government's actuaries or the institute of medicine says is reasonable, then we should not, as a society, be obliged to go along for the ride. You should be able to pay for that out of pocket or in any other way you want to do it. That's a fundamental difference in saying, "No, you can't have it at all." And let me remind you, we talked about wasteful spending earlier--

### Moderator
Claim: But wasn't Peter describing a situation in the U.K. where they do look at specific treatments and they say, "If you want to stay in the national health, you can't have it at all"?

### Conspiracy Advocate (CA)
Claim: Well, I'm sorry. I thought we were in the United States.

### Conspiracy Advocate (CA)
Claim: No--

### Moderator
Claim: But Peter used the United Kingdom system as an example so I think it’s on the table--

### Conspiracy Advocate (CA)
Claim: Well, yeah, but let me just mention something that I think we’ve got to put on the table because I don't know how much time we're going to have, a cynical colleague of mine once said, "Americans don't mind throwing people overboard, they just don't like to hear the splash." And there's an awful lot of people that are getting thrown overboard every day in this country that we're not debating about tonight. no, it's really important. Sally told a story-- I'll just briefly tell a story. Early in my career, I saw a woman in her 30s, a mother of three, who rolled in the door with a hemorrhagic stroke, her blood vessel burst in her brain, she was neurologically devastated. We incubated her, we did everything that Sally and Ken would want. We gave her a full court all out best we could humanly do, and we could not save her life. I went to break the news to her sisters, and they told me that three weeks earlier she'd lost her job, lost her coverage, could not afford her three blood pressure medicines, and was forced to choose between groceries for her kids or medicine for herself. She chose her kids like any mother in this audience would choose, and she paid for it with her life. Her life had value. She died. We spent more money in the last three hours of a completely futile effort to save her life that could have kept her in blood pressure medicine her whole life, raised her kids, paid her taxes, contributed to our country. Those people matter, too!

### Moderator
Claim: I want to take questions from the audience, but I just want to finish this up. Should she have been denied that service since it didn't make sense economically?

### Conspiracy Advocate (CA)
Claim: What?

### Moderator
Claim: The extraordinary effort--

### Conspiracy Advocate (CA)
Claim: No, because early on you don't know how things are going to turn out and you-- but at some point you say-- and, again, what we said-- opening conversation here is the most important discussion to have is between a physician and the patient with an honest sharing of information, not get pulled into an industrial complex of modern medicine. Just remember, we were talking about the Affordable Care Act or Obama Care earlier. One of the first provisions that got knocked out of it was one that would have given doctors a little money every six months to encourage them to have a conversation with their patients. And you know what we called this, folks? We called it a "death panel." What the hell was that about?

### Scientific Advocate (SA)
Claim: Let me ask you this question.

### Conspiracy Advocate (CA)
Claim: I don't know 10 doctors in America that thought that was a good idea to knock that out.

### Moderator
Claim: I'm going to let Ken respond. I think you're going with the question, so, yeah, make it a question--

### Scientific Advocate (SA)
Claim: If I may, you've made the point, and you've written about it, it's a good point, that some 15,000 people die estimated every year because of the lack of insurance coverage. Easy. Then probably due to medicine estimates that 100,000 people die a year from medical malpractice. Are you willing to be as aggressive about reforming medical malpractice and ensuring that physicians meet the standard of care for those 100,000 as you are to argue for the 1,000s who don't survive because of a lack of insurance?

### Conspiracy Advocate (CA)
Claim: Absolutely. Sign me up. And you know what? And while we're at it, let's cut out the $750 billion a year that the Institute of Medicine says our health care system, the one I work in, is wasting due to inefficiency, wasteful management, missed opportunities for prevention, and fraud, $750 billion, folks. We could do a lot of good with that money.

### Moderator
Claim: And right then and, if you'll wait a second, a mike will come to you and you can stand up, if you wouldn't mind telling us your name, and just wait for the mic. Thanks.

### Moderator
Claim: I have a question for Sally. Sally, you--

### Moderator
Claim: Can you just identify--

### Moderator
Claim: Right. Oh, I'm sorry, John. My name is Judith Alexander. Sally, you were running through how many people are uninsured who could actually receive government assistance if they applied for it. But aren't you being inconsistent, because aren't you against a single payer and yet you seem to be advocating that many of the uninsured take advantage of the programs that really are single payers?

### Scientific Advocate (SA)
Claim: Well, first of all--

### Moderator
Claim: I think I'll pass on the question because I don't think this goes to the issue of rationing unless you want to rephrase.

### Moderator
Claim: Don't single payers ration?

### Scientific Advocate (SA)
Claim: Yes, definitely, in terms of rationed care, waiting lists, and lack of access to the latest treatments. Everyone in America is entitled to health care by turning up at an emergency room. And the real-- the hidden tax is not on the uninsured. It's on the low reimbursement rates by government to doctors and hospitals. That adds about 10 percent to the cost of an insurance plan by people who have private plans. The uninsured only adds 1 percent to the cost of premiums for those who have insurance.

### Moderator
Claim: Response from the other side? You don’t need to if you don’t want to. Art Kellermann.

### Conspiracy Advocate (CA)
Claim: No, just-- we don't do a really good job of giving chemotherapy and doing a lot of other stuff in ERs. I mean, I love practicing emergency medicine. That is the last place that poor and uninsured Americans should have to go to get their health care. It doesn't make any sense, and it never has. And it just boggles the mind. I'm sorry. I'll have to recalibrate. I've heard some things that have really got me spinning on this side and I need a moment to figure it out.

### Moderator
Claim: All right. Sir.

### Moderator
Claim: My name's Patrick Bachelor First, to Sally. Your story was both tragic-- I think it's irrelevant, unfortunately. Obama Care is very different than the Canadian model, both in terms of who pays for it as well as how it's structured. But to the other side--

### Moderator
Claim: Don't debate the debaters, please. Just ask your question. Put the question.

### Moderator
Claim: Yeah. The trick part of the question, I think, tonight is, do we really know what end-of- life is until we get there?

### Conspiracy Advocate (CA)
Claim: There are many, many cases-- I never try to predict for an individual patient. But what I do tell a patient is, "This is the situation. This is what could happen. What do you think is the right thing to do?" And I respect their wishes, and I respect the family's wishes.

But you've got to give them honest information. You've got to give people a sense of odds. Everybody is one or zero as an individual, but the odds and the outcome and the prognosis really matter, and people need to understand what they're signing up for. Ken talked earlier about cruel and unusual punishment. If we took prisoners on death row and subjected them to a week in an American ICU, the Supreme Court would rule that unconstitutional. So it's important to make your choice based on your values. And my advice to you, sir, is to go home tonight and talk to your wife and kids and tell them what you want at the end of the life, so they'll be there to represent your views.

### Moderator
Claim: I just want to understand, was the thrust of your question, "Who knows what a procedure is going to produce?"

### Moderator
Claim: No, it's, "How do you know when you're at that point, at end-of-life?"

### Moderator
Claim: Okay. All right, so I think he just answered it. Thank you. Sir, go ahead.

### Moderator
Claim: My name's Tom Oldfield Great job, everybody. It was very entertaining. I'm holding my phone because I wrote the question on there, but--

### Moderator
Claim: Could you move the mic a little closer?

### Moderator
Claim: Yeah, absolutely. Sorry about that. Thinking in two hypotheticals. One, we're thinking 60 years down the road, and the other being that the stereotype that Gen-Y all think they’re special is true. Which scenario do you think would be more likely? "A," as a result of our lives being so special, that the pool of end-of-life candidates would become so extreme down the road that we have no choice but to make reforms, and have this discussion and ration life care? Or "B," would-- as a result of having such a comfortable life, would the-- would the effect of the suffering that goes on during end-of-life become so extreme where the conversation actually switches to people-- do people have the capacity for-- to choose euthanasia, for example? Would there be a demand for that?

### Moderator
Claim: Let's take Ken Connor first on that.

### Scientific Advocate (SA)
Claim: I'm not sure I understood your question fully, and I apologize for that.

### Moderator
Claim: Can I restate? You're talking about, are we going to go to a world where-- well, the second scenario you were talking about, are we bound to a world where there are so many sick and elderly people, and we are so unable to pay for it, that people are going to be encouraged to off themselves? That's what you were asking?

### Moderator
Claim: No. It's actually-- It's actually more of sort of the-- I think of just killing as an example of when your quality of life, the drop-off of your quality of life is greater because of your upbringing, so having a more comfortable upbringing would naturally lead to a greater suffering, even though it's--

### Moderator
Claim: Yeah, I'm going to pass on the question, because I think there's so many premises that we would end up ripping apart, addressing the many premises. So I'm going to pass on it, but thank you.

### Moderator
Claim: Can you at least talk about the euthanasia?

### Moderator
Claim: Sure. All right.

### Scientific Advocate (SA)
Claim: I'll be happy to address that. Historically, in America, we have maintained that humans - - you know, it's a self-evident truth that human beings are endowed by their creators with certain inalienable rights, the first of which is the right to life. That right to life has been deemed to be the foundation of all other rights because if you don't preserve it, you don't get to enjoy any of the others. Now, I fear that rationing opens the door to euthanasia because decisions are made on a utilitarian basis about who lives and who dies. And that's the reason I injected the issue on the front end of this debate about personhood.

Because Dr. Singer has maintained that if you lack certain qualities, rationality, the capacity to reflect on your own existence, self-awareness, you're not a person. And he makes the point that if you're not a person, then it is not as morally culpable to destroy that entity than it otherwise would be for--

### Moderator
Claim: But Ken, he's not-- he's not making that argument.

### Scientific Advocate (SA)
Claim: Well, my point ultimately goes to this: Is that when we use these utilitarian criterion to decide who lives and who dies effectively, we wind up redefining who a person is and-- and that gives rise to a potential license to kill which invites euthanasia.

### Moderator
Claim: Peter Singer.

### Conspiracy Advocate (CA)
Claim: Well, if I can comment on that, I think what we are increasingly finding, and we will in the future, if you're looking to the future, is that more people want to have the right to make their own decisions about when they die, about when they've had enough.

At the moment, people generally can say, "I don't want any more treatment." But if there isn't treatment that's keeping them alive, they don't have that choice. Now the citizens of Oregon, the citizens of Washington state, have voted in favor of having that right, at least to get a physician to prescribe the medicine that they know will be lethal that can end their life. The courts in Montana have said that citizens there have that right as well. There are several nations in Europe that allow that and also allow-- some of them allow a doctor to give a lethal injection as well on the request of the patient, satisfying certain conditions like a second opinion. Those countries are satisfied with that. In the Netherlands, for example, that's been the case for at least 20 years now. And through different governments, through liberal governments, through conservative governments, through a Catholic prime minister who never tried to repeal that law because he knew it was too popular and would be political suicide if he did.

So I think that that is actually something that probably is increasingly going to happen as people start to see that this is something that they want for themselves. But that's a matter of choice. That's not a matter of rationing.

### Moderator
Claim: I want to remind you that we are in the question-and-answer section of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, who are debating this motion: Ration end-of-life care. Peter Singer, I had the sense that Ken Connor's point wasn't about voluntary euthanasia, and I think the question was also about a culture in which euthanasia becomes a suggestion overhanging the elderly as they become more and more in number and as they become more difficult to take care of, that this sort of-- I think the question is, will we get to a world once we open the world to explicit rationing where an old person will know that it's time to get on the ice flow and get the pushout.

### Conspiracy Advocate (CA)
Claim: No, I don't believe so. I think there's still going to be the possibility of choosing, providing, of course, as you're saying, that you're not imposing a huge burden on other people by opting for something very expensive and of doubtful benefits. So there are going to be limits there. But I think otherwise people are going to be able to make their choices in accordance with their own values, and there will be some people who'll want to hang on to life as long as possible and other people who will say, life has lost whatever quality is had that I think makes it worth living, and I think it's time to go.

### Scientific Advocate (SA)
Claim: But don't you think, Peter, that these decisions should be made between doctors and family and the patient in conjunction? And living wills is an area that is expanding because if you have a living will, you can say so that when you're very ill you won't-- it's not as if you're under anesthetic or under drugs, you've actually made a decision. I know it's hard to figure out when that time will be, but I think living wills are a great way to put things down.

But I think doctors and families and the person who is ill should be making these decisions. And we shouldn't be so concerned about the cost to the system because we have a lot of weight in our system right now.

### Conspiracy Advocate (CA)
Claim: Yeah, I entirely agree. The decisions about living and about voluntary euthanasia should be matters between doctors and patients. And that's why I think they're separate from decisions about costs and about when treatment is imposing so much of a burden on others and on the general health budget that it's not something that the public should be paying for.

### Moderator
Claim: So are we, or I, confusing euthanasia, which is a deliberate act to end life, with the withdrawal of an extraordinary measure which the patient hopes will save his or her life? Are those two different things?

### Conspiracy Advocate (CA)
Claim: They are somewhat different things, certainly. Again, I think patients should have those choices, and patients might choose that they don't want life support even though that is considered sufficiently cost effective to be worth providing. But that should be a choice.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: But they are different.

### Moderator
Claim: Ma'am, sorry. I didn't see you.

### Moderator
Claim: My name is Julie Goldstein. I am a palliative care physician and educator. And my question is to all of you, but particularly Dr. Kellermann. I see first hand all the way till that happens, particularly at the end of--

### Moderator
Claim: Sorry. Could you move the mic just a little closer?

### Moderator
Claim: Sure.

### Moderator
Claim: Thanks.

### Moderator
Claim: And my question is, do you think that if we were to address the waste head on by education, et cetera, that we might save enough money that we wouldn't even need to feel-- we wouldn't have the need to ration?

### Conspiracy Advocate (CA)
Claim: I'm glad you brought that up. I really believe that if we focused on getting rid of bad medicine and eliminating the kind of errors in communication problems that I discussed and reinforced the sustained palliative care, that takes care of 90 percent of this issue.

And the rest of it really does come down to a doctor, a patient and their family and what is meaningful and mattering to them. There may well be in a point in society where we have to say that if the other certain amount of dollar value you can pay for it yourself that Medicare or private insurance or whatever won't go past that point. But I'm never going to get between an American and their wallet. It's my wallet or your wallet I'm more concerned about in that very unusual circumstance. I just want to double back to the comment about euthanasia and say as a doctor, I'm not ready to go there. But if a patient tells me, in their terminal condition, that they don't want an oxygen mask because they want to kiss their wife, I want to let them kiss their wife.

### Moderator
Claim: Okay. Ken Connor.

### Scientific Advocate (SA)
Claim: Well, I affirm, doctor, that the premises of your question, which is if we can eliminate the waste broadly abused, doesn't that obviate the need for rationing? And that was the point I tried to make in my opening statement, is that the alternative is not simply ration or not.

The question is whether or not we're going to continue to waste money and then promote the need for rationing because of it. Now, the institute of medicine reports, for instance, that we spend $75 billion a year because of healthcare fraud. 190 billion in excess administrative costs. Inefficiently delivered services, $130 billion a year. Now, my point is this: It's easier to argue for balancing the budget on the backs of the old people who aren't voting and who don't have lobbyists and who don't have packs than it is to try to rest the money away from the people who are-- who are perpetuating the fraud or rendering these services inefficiently.

And so I'm saying, let's not take the path of least resistance. Let's not take the lazy man's way out. Let's do what we need to do to reform wasteful spending and not-- not force ourselves into a position where we think we have to ration healthcare at the expense of the elderly.

### Conspiracy Advocate (CA)
Claim: You just lost me there, Ken, because I thought you said earlier that what we wanted to do was to get government out of the business and let doctors do whatever the heck they want. But you just told us we were wasting $750 billion, so I--

### Scientific Advocate (SA)
Claim: When healthcare providers perpetrate fraud, government has a legitimate interest in stopping that fraud. That's a perfectly appropriate role for government.

### Conspiracy Advocate (CA)
Claim: But it isn't just fraud. I mean, the problem is that the financial incentives in the market system, that the opposition are defending all the way, provide incentives to do more. Here is an example. The national rate of cesarean sections is 34 percent of births.

There's an outfit called Intermountain in Utah healthcare that has a cesarean rate of 20 percent. It saved $50 million by doing fewer cesarean sections. But it cost it money. It lost money by doing fewer cesarean sections, by saving the system $50 million it suffered a financial hit itself because the financial incentives are to do more and you get paid more, and you can pay-- you can build up your financial base, expand, stop, et cetera. So this is the problem with allowing this to be done through the free market. We need something that puts a lid on not just fraud but also the incentives to do more medical treatments.

### Moderator
Claim: Thank you. I'm Peggy Lester.

And I've been a nurse for 30 years in an emergency room here in town. My question for everyone on the panel is if-- you know, the profit issue of all of this is what seems to me is what the issue is. And so eventually I see it that insurance companies, if we privatize everything, insurance companies will come to a point where they're not making a profit, and that they will then begin to ration care, which they actually already do. So I would like you to speak to, I think, any time we have a health care system that depends that everybody's going to make a profit off of it, we really don't do the best thing for everybody involved. So if you could just comment on that.

### Moderator
Claim: Do you mind if I tweak your question slightly?

### Moderator
Claim: Go ahead.

### Moderator
Claim: I don't think very much, but to ask Sally Pipes just, to your point, that ultimately, if you do go to an all private system, that private companies would have the same-- exactly the same motives to ration as anybody else, and that there would be rationing under the program that you're talking about.

### Scientific Advocate (SA)
Claim: Well, first of all, I'd like to say that--

### Moderator
Claim: So are you good with that?

### Moderator
Claim: Yes.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: Under the Affordable Care Act, I believe with the essential benefit plan that will be part of these exchanges, where government is going to determine what is a package, what is in the mandate, what insurance companies are going to be able to charge, I believe that a number of insurance companies are going to get out of the insurance market because it's not profitable for them to stay in the market. And so we've already seen Principal Financial in Indiana dropped all health insurance, 800,000 people lost their coverage, and--

### Moderator
Claim: But--

### Scientific Advocate (SA)
Claim: No, just a minute Aetna and several other--

### Moderator
Claim: I've seen that on television recently.

### Scientific Advocate (SA)
Claim: Oh, yeah. Aetna and some other companies have already done that.

I know that United Health is not writing individual policies in California because it's just too expensive, too much regulation. So, you know, I believe that Medicare should be there for those seniors who really need it. Medicaid should be there for those people who are at 133 percent below the poverty level. I think that Medicaid should be granted to the states so that they can make these decisions. I'm not saying the whole system should be private, but I'm saying if we can move away from employer based coverage to an individual system--

### Moderator
Claim: Okay, but-- all right, but-- I have to interrupt you because I do have an internal sense of the question not being answered.

And the question was, "Won't insurance companies-- if you went to a private system, won't insurance companies end up with exactly the same need to conserve resources and we heard this woman saying for the sake of making profit, but whatever the reason is, won't they have to conserve resources and end up rationing anyway?

### Scientific Advocate (SA)
Claim: Well, there's always going to be rationing, but the question is "Who do you want to be doing the rationing?" Do you want government to be making decisions about your care, or do you want an insurance company which doesn't-- isn't full of fraud and abuse-- As Obama said "Medicare and Medicaid, $500 billion in fraud and abuse." If those programs are so great, why are they the programs that have all the fraud and abuse in them?

### Conspiracy Advocate (CA)
Claim: Okay, John--

### Moderator
Claim: Oh, okay, Art, yes, sir.

### Scientific Advocate (SA)
Claim: --may I weigh in on that? I come back to the premise that I outlined earlier. And that is that we should be able to make consumer driven decisions, informed by the medical community, mediated by markets. Now, the difference between markets and the government is that within markets you have a choice. And so if you don't like the way the insurance company is rationing your care or the circumstances that it requires for you to participate in, then you have alternatives. When you're in a one size fits all government program, you have no alternatives. You have lost your liberty in that regard.

### Moderator
Claim: All right. I don't feel like there is a need from a response from this side because the question was posed to this side, so I'm going to go on to another question. Sir.

### Moderator
Claim: This is a question about rationing, correct, and whether or not ethically we at the government have the right to ration, is that--

### Moderator
Claim: Yeah, I would say so.

### Moderator
Claim: So last year my father-- sorry-- my brother-in-law's father was in a car accident, had his spine severed, and was in the hospital for six months, ICU, back and forth. He actually-- I think he had bills for about $1.5 million. So with that, he was 72. I want to put out a hypothetical story. You have three gentlemen, 72 years old. One is unemployed and always has been unemployed, always been on government care. One of them is a-- let's say, somebody who's in jail. And then a third person is someone who has actually been in the system paying taxes and everything else. They get in a car accident, same thing happens. Do all three deserve, from government care, the same result?

### Moderator
Claim: Which side would you like to hear answer that question?

### Moderator
Claim: Over here.

### Moderator
Claim: Did you follow it? If you didn't follow it, I want to say, "Neither did I."

### Scientific Advocate (SA)
Claim: Okay, good. Well, I didn't. I didn't.

### Moderator
Claim: It was a lot for me to follow. Can you simplify-- you know, turn it into a principle rather than a scenario?

### Moderator
Claim: Okay.

### Moderator
Claim: Thanks.

### Moderator
Claim: Three people--

### Moderator
Claim: No, no, no, no.

### Moderator
Claim: Does everybody, regardless of their status and stature in life, deserve exactly the same care when the government is what is going to pay for that care?

### Moderator
Claim: What a great question. Ken Connor.

### Scientific Advocate (SA)
Claim: Well, in America, we've historically said that we're entitled to equal protection under the law. And so the government, arguably, has an obligation to treat everyone the same. Now, in the marketplace, it doesn't always work that way.

We talk about equal opportunity, not equal outcomes. And so that's what I like about the marketplace, is that decisions can be made in the marketplace. Look, the notion that government is more qualified to make decision and to allocate resources than markets, I think, is a foolish notion. The history of the world suggests otherwise. The Soviet Union imploded on itself because its central managers were not efficient, but in the final analysis, I think we need to understand that the Constitution is a hedge against government. It's not a hedge against individuals. It's not a hedge against the markets. Bu the Constitution limits the powers of government. So if government is going to assume certain responsibilities, it's bound by the chains of the Constitution, and I think we want it that way.

### Scientific Advocate (SA)
Claim: Can I make a quick point?

### Moderator
Claim: There's another question. Your question was, "Does everybody deserve the same level of care, regardless of who they are?" And are you talking about extraordinary measures at the end-of-life care, which may need to be rationed because of scarcity of resources?

### Moderator
Claim: That's what this debate's about.

### Moderator
Claim: Yeah. All right. So your question-- but I think Sally Pipes said in her opening statement, each of us should have the right to live as long as we can.

### Scientific Advocate (SA)
Claim: Right. And these people are 72, you said, or 71. They're obviously on Medicare, because they're seniors. And I think I'd like to ask Art, when someone turns up at an emergency room, they're on Medicare, do you ask, "Are you an ex-prisoner, or are you unemployed?" I think there's a responsibility in the emergency room to treat these people. And most doctors I know who are ER doctors have no idea whether the person is wealthy or poor or whatever. So I think that under Medicare they should be treated by Art or whomever, in the equal way.

### Moderator
Claim: No, but they were in the hospital for six months.

### Moderator
Claim: All right.

### Moderator
Claim: So, over the course of six months.

### Scientific Advocate (SA)
Claim: Well, that's a new-- you've added something new to your scenario.

### Moderator
Claim: I'm going to move on, and not as a sign of disrespect, but just as a sign of the clock running. Thank you. Thanks for understanding. I want to get a couple more questions. Sir, right in the middle?

### Moderator
Claim: My name is Ganesh Ramani

### Moderator
Claim: Can you-- the mic wasn't on; sorry.

### Moderator
Claim: My name is Ganesh Ramani. My question is really for both parties, but I think more so for the side against the motion, because the side for the motion, I think, has more or less answered the question. But the question is, is there a scenario or situation under which you would consider rationing end-of-life care?

### Scientific Advocate (SA)
Claim: Well, look, I think we're all in agreement that rationing is a de facto matter. Rationing occurs. The question is, who should ration? And is government in a better position than others to ration?

### Moderator
Claim: But you've made that before, but, so, to his specific question, the answer is yes, there are situations--

### Scientific Advocate (SA)
Claim: The answer is yes, and I favor rationing through markets and individuals rather than through government.

### Moderator
Claim: Okay. Does the other side want to respond to that . Okay. Ma'am? I'm sorry. I'm going to take two more questions, then, if it's a serious question. Just let the gentleman go first because that-- because that's who has the microphone. And then we'll--

### Moderator
Claim: Thank you.

### Moderator
Claim: Yes.

### Moderator
Claim: So for scarce resources, I view that there's kind of two types: One is hospitals and doctors, and the other is government capital and government money to spend. So I view them as kind of differently when I think of rationing end-of-life care. And so I'm kind of-- first in terms of from this side, I believe I kind of heard that you're in favor of rationing, you know, government spending, while not rationing hospitals and doctors for those who want to pay for it. I'm kind of-- so first I want to know, is that kind of correct?

And then also for this side, do you view that, why shouldn't somebody be responsible to save up their money or pay for private insurance so that they can pay for that end-of-life care while the government can ration the government spending but not ration the doctors and the hospitals?

### Conspiracy Advocate (CA)
Claim: I want to take your question as an opportunity to bring up another key point which we spent a lot of time tonight talking about economics, and we spent a little time talking about the uninsured and the underinsured. But there's another group that really suffers under the current system. And those are the folks who are lining the hallways and in trauma centers and ERs waiting for the ICU bed that they can't get into and are there for two or three days. The ambulances are diverted from a trauma center to a non trauma center because all the beds are full. We are not a country of unlimited money or of unlimited critical care capacity.

And so my perspective, and I think my colleague's perspective, is given that we live in a finite world, we want to do the most good for the most people possible. And that should be our fundamental mission. You can call that rationing, you can call it rational use of resources. But every life has worth. And the fact that somebody got there first shouldn't be ultimately the prevailing decision. We've got to maximize the benefit and the value and the system to society--

### Moderator
Claim: What's the system then, Art? Then what's the system that--

### Conspiracy Advocate (CA)
Claim: The system is, again, you have to make decisions. You work with families. You have to figure out where--

### Moderator
Claim: But if it's-- does Medicare get to set up a panel to say we're going to provide this particular procedure or not because it's evidence-based medicine suggests it's not cost effective. Does Medicare get to say we're not going to do that?

### Conspiracy Advocate (CA)
Claim: I think Medicare gets to say we're not going to pay for it.

### Moderator
Claim: That's what I mean.

### Conspiracy Advocate (CA)
Claim: Yeah. I think if you say you're not going to pay for it, people will go, "Ah, never mind." I mean, we know that. The RAND Grant has done work for 40 years that showed that if people have to put their money on the table, they tend to make more careful decisions. And that's just human nature.

### Moderator
Claim: Do you want to respond to that, Ken or Sally?

### Scientific Advocate (SA)
Claim: I would, yes. I mean, I--

### Moderator
Claim: Ken Connor.

### Scientific Advocate (SA)
Claim: You've made a very good point that I think is a very important point, and that is that when we don't have skin in the game, we're less likely to be good stewards of the resources available to us. And so for instance I think one way that we can promote having skin in the game in the responsible consumption of medical resources is to allow young people, for instance, to have health savings accounts with high deductible insurance policies. And they've got skin in the game. Let the government subsidize or provide tax breaks to individuals who purchase health insurance, not just to businesses.

The way the current system is set up is that we tend to over consume the resources because we don't have any skin in the game. The employer is paying the bill. The government subsidizes the employer, and there's no skin off our nose. And so if we want to promote good stewardship, good stewardship, then I think we ought to-- ought to cause people to have skin in the game. And that would mean that they have a stake in their own healthcare decisions. If they do, they're less likely to over consume resources than they otherwise would be.

### Scientific Advocate (SA)
Claim: And that's a very good point: Consumer-driven healthcare, health savings accounts have shown that the cost of care is down because people do have skin in the game. And in fact, Art, Rand Corporation came out with a study on HSAs for small businesses showing that that is a way to reduce costs for small business employers. And I think that it was-- they were really good results about 13 1/2 million people in this country have HSAs combined with a high deductible plan because if you have employer based coverage it is what Ken said, first dollar coverage.

People have no idea what the doctor visit costs, they go more often. Consumer-driven healthcare is a terrific solution.

### Moderator
Claim: Okay. Ma'am, I owe you an apology. If this were the Oscars, the music would be playing. I-- I have to-- I have to stop because this concludes-- because this concludes round 2 of this Intelligence Squared U.S. debate.

## Round 3

### Moderator
Claim: And if you'll remember, before the arguments began, we asked all of you to vote on this motion. We're going to ask you again after you hear the closing remarks. This is their last chance to try to ease your mind. On to round three, closing statements. They are two minutes each. Our motion is this: Ration end-of-life care. And here to summarize her position against this motion, Sally Pipes, president and chief executive officer of the Pacific Research Institute.

### Scientific Advocate (SA)
Claim: Thank you, John. And you know by now I am against the proposition that end-of-life care should be rationed. The Medicare trustees have projected that the program Medicare will be bankrupt by 2024 at a cost of $1 trillion, almost double the costs today. One of the ways to reduce the costs of our Medicare programs is to deny end-of-life care. I believe it's morally wrong, but the position is supported by my opponent. There are 50 million seniors in this country today on Medicare. And that number is going to expand exponentially as the baby boomers retire. And I am one of the baby boomers. Doctors are already feeling the financial squeeze. They are reimbursed by government at a rate 20 percent below what they get for treating private patients. It is no wonder that 52 percent of doctors surveyed say they're limiting the access of Medicare patients to their practices. Unless reformed, this could result actually in bureaucrats setting an age limit for one's life. In order to save Medicare for those who truly need it, changes are necessary, including premium support, mean testing and raising the eligibility age from 65.

Former House speaker Nancy Pelosi who represents my district, “if the changes suggested by Romney and Ryan are implemented, seniors will die in the streets.” Well, I believe if we don't make these changes, based on the Medicare cuts seniors will die in the streets. They won't be able to get doctors or the care they need. Don Berwick when he was administrator at CMMS said, "It's not a question of whether we're rationing care or not. Will we ration it with our eyes open?" We do not want a NICE system in this country. It's not the American way where a government body determines what is cost effective rather than medically effective. America needs a healthcare system where doctors and patients make decisions about the best kind of care that is needed when their loved ones approach the end of their lives. Morally and ethically, this is the only way to proceed. I urge you to vote against rationing the end-of-life care. Thank you very much for listening.

### Moderator
Claim: Thank you, Sally Pipes.

And now in support of the motion, Peter Singer. He is professor of bioethics in the University Center for Human Values at Princeton University.

### Conspiracy Advocate (CA)
Claim: We've actually reached a surprising amount of agreement in this debate because both sides agree that rationing occurs. Sally said there's always going to be rationing. Ken said we are all in agreement that rationing occurs. The question is he went on to say, is who should ration? He says he favors rationing through markets rather than government. But you should read that article that he wrote that I mentioned before on the website about the problems of the elderly because his approach from that article, all-profits nursing homes have on average 32 percent fewer nurses and 47 percent higher deficiencies than their nonprofit counterparts.

This increased emphasis on profits has led to a distressing rise in neglected end of use seniors. So I have to ask, why does Ken have such confidence in the market, solving the problem of the allocation of medical resources, when he is broadly, I believe, critical of what all-profits nursing homes do to abuse seniors. We think that there has to be a better way than allowing profit maximization to determine how we are cared for.

Let me just conclude by referring to the case that Sally began with, the sad case of her mother, and say that although that is a tragic case, obviously we cannot generalize from a sample of one. I spent most of my life living under single-payer systems, either in Australia or in the United Kingdom.

I or rather my wife, had two of our children in the United Kingdom and one of them in Australia. I think that the quality of care that we have received in Australia has been outstanding. I've obviously had medical care in this country. I don't think that it's better than it is in Australia. And I don't think that it's even more a respectful of individual choice because Australians can insure themselves in addition to Medicare.

### Moderator
Claim: Peter Singer your time is up.

### Conspiracy Advocate (CA)
Claim: Thank you very much.

### Moderator
Claim: And here to summarize his position against the motion, Ken Connor. He is founder and chairman of the Center for a Just Society.

### Scientific Advocate (SA)
Claim: One of our founding fathers said, "If men were angels then we wouldn’t need government." Men are not angels and we do. Markets are not perfect. And they do need regulation. The question is "Where do we wind up striking the balance?" And I can tell you to Peter’s point that care in our nursing homes in America is America's dirty secret.

And it's in part because a-- real estate investors pose as health care providers. And the government doesn't adequately regulate them, plain and simple. And we have a absolute scourge of preventable bedsores, and avoidable malnutrition, and dehydration, falls, and avoidable infections. But let me say this, I think it's important to understand that rationing is not required in order for the health care system to remain solvent. That assumes the fallacy of only one alternative, that either we ration or we're going to go broke. That's not true. And that's why I brought up the point earlier in the debate, which Dr. Kellermann didn't seem to understand, that there are lots of places from which we can effect savings. But it's work to effect these savings.

It's hard work to wrest resources from the hands of the special interests. We should not ration. We should not balance the budget on the back of the sick and the dying. We can provide good health care for all people through and including the end of life. We need to ask good questions. We need to ask, "Are the procedures necessary? Are they clinically indicated? Is the cost reasonable?" What we need is a rational approach to end-of-life health care, not the rationing of end-of-life health care. Thank you.

### Moderator
Claim: Thank you, Ken Connor. And, finally, in support of the motion, Arthur Kellermann. He is the Paul O'Neill Alcoa chair in Policy Analysis at the Rand Corporation.

### Conspiracy Advocate (CA)
Claim: Most Western democracies have health care systems that provide you with all the care you need, whether or not you can afford it.

Our health care system has evolved to provide you with all the health care you can afford, whether or not you need it. Modern American medicine is a $2.8 trillion a year industry, and it is rapidly outgrowing our economy's capacity to support it. More high tech care is not necessarily better care. Sometimes the basics, pain control, bedside attention, love, matter a lot more than the most sophisticated $100,000 medicines there are. That's why, when terminally ill patients came into my ER, I did not immediately incubate, immediately start multiple IVs, immediately do anything I didn't absolutely have to do. I stabilized the patient the best I could, I assessed the situation, and I talked to the patient. If they were able to communicate or not, I would bring the proxy-- the son, the daughter of, a brother, the spouse to the bedside.

Let me tell you what happened one night as an example. I brought a daughter who had cared for her mother for 10 years to the bedside, and I said, "Your mom has severe pneumonia. She's septic. This is the third time she's been in the hospital in the last two months. We can do everything we know to do, and she will almost certainly die, but she might pull through. And the best we can hope for is she'll be the way she was a week ago when she didn't recognize you and was in the nursing home. So my question to you is not 'What do you want us to do?' I know what you want us to do. You want us to make your mother the way she used to be. I can't do that. So I want to ask you, 'What would your mother want if she came back now and stood next to you?'" And she said, "Mama would say, 'It's time.'" As you vote tonight, I ask you to consider what kind of doctor do you want to take care of your mother, and what kind of doctor will you want to take care of you, and that should guide your vote.

### Moderator
Claim: Thank you, Art Kellermann. We're going to have the second vote now. So if you go to the keypads in your seat. After hearing everything, we want to know where you stand, whether you have been persuaded to one side or the other. If you agree with the motion, "Ration end-of-life care," the side argued by this team, push number one. If you disagree with the motion, with this team, push number two. And if you are or became undecided, push number three. And you can ignore all of the other keys. And they will lock in pretty quickly, actually. We'll have the vote probably in about a minute and 45 seconds.

And so, while we're waiting, a few things that I want to say. First of all, ma'am, if we're lucky enough to be invited back next year, you find me at the beginning of the debate. I owe you the first question. Okay? All right. And everybody else who stood up and asked questions, including the ones that we didn't get to use, it takes a lot of guts to stand up, and a lot of the questions were great, actually. I want to thank all of you for doing that. I also want to thank, despite what I would professionally consider a little bit of meandering in the middle, I think we got into some very important places in this debate where the clash was head-on. We could see the values represented by both of these sides, because he doesn't actually have to think in real time. That's a very impressive thing to see happen. It's difficult to do. I want to thank this panel for what they've brought here to this stage. It's really been a pleasure to be part of Chicago Ideas Week and to be in the city at all. You actually are a very, very lively audience, and you're going to sound great on the radio.

Afterwards, after the debate, we would be delighted, of course, to have you tweet about the debate. Our Twitter handle is @IQ2US, and the hashtag is the same, #IQ2US.

I want to thank the CIW team, in particular I want to name some people. Brad Keywell, Carrie Kennedy, and Jessica Malkin who, again, was very instrumental in getting us on this stage. Our next debate is Wednesday, October 24th. It will be held in New York City. And the motion in this date is, "The rich are taxed enough." In support of the motion, we have Glen Hubbard, is currently dean of the Columbia Business School. He is also an economic advisor to presidential candidate Mitt Romney. His partner is Art Laffer, who is known as the father of supply side economics, the famous Laffer curve is his curve. He was a member of President Reagan's economic policy advisory board.

He's debated with us before, and he's actually very-- not only smart, he's very witty. He keeps everybody laughing. Against this motion, "The rich are taxed enough," we have Robert Reich, who is former secretary of labor in the Clinton Administration and professor at the University of California in Berkeley, and Mark Zandi, who is one of the most widely followed economic forecasters and the chief economist of Moody's Analytics.

So, all right. The results are being walked up. So, remember, we had you vote-- This never happens in New York. That was very generous. Our motion is, "Ration end- of-life care." We now have the results in on your votes. Remember, we had you vote before you heard the argument and once again after hearing the arguments, and the team who has changed your numbers the most, who has moved you to their side by the largest percentage, will be declared our winners.

So here is how it breaks out. Before the debate, 43 percent were for the motion, 22 percent against, and 35 percent undecided. After the debate, 38 percent are for the motion-- I'm sorry. After the debate, 81 percent are for the motion, up 38 percent; 12 percent are against it, down 10 percent; 7 percent are undecided. The side arguing for the motion carries the debate. Our congratulations to them. Thank you from, me, John Donvan, in Chicago, and Intelligence Squared U.S.
