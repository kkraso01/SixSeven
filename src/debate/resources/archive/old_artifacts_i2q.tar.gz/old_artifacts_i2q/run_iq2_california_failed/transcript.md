# Debate Transcript

Topic: California Is The First Failed State
Motion: California Is The First Failed State

Debate ID: california-failed


## Round 1

### Moderator
Claim: Let’s welcome our debaters to the stage, we’re about to begin. And if you look at the current issue of Newsweek there is an op-ed piece on the topic of the health care debate that is by our founding chairman, Robert Rosenkranz, pick it up and read it, it’s worth it, and at this point I’d like to introduce Robert Rosenkranz, ladies and gentlemen.

### Moderator
Claim: Well thank you very much and welcome to this evening’s debate. Well, I assume we’re mostly New Yorkers here, and we all know that New York has its problems. But California’s are worse, or at least so New Yorkers like to believe. California has Hollywood, Silicon Valley, and way better weather. But California’s credit rating is lower than ours, New York State legislators can look at the California legislature, and come away with delusions of adequacy. The political divide between San Francisco liberals and Orange County conservatives, is actually more acute than ours. And in California it takes two-thirds of the legislature to impose taxes. Which virtually assures recurring budget crises. California’s experiment with direct democracy, the referendum system, has demonstrated that voters like to receive benefits from the state, but don’t like to pay for them. A result, I suspect, you are shocked, shocked to learn. With a looming $20 billion budget gap, and 1 percent of the taxpayers already footing 50 percent of the bills, will California be able to squeak by? Or will it become the Lehman Brothers of state government? Will a vibrant private sector bail out its mismanaged state sector. Or is California our first failed state. And let me emphasize the “first” in this proposition. Are its problems the result of a uniquely dysfunctional political culture, or are they the harbinger of things to come, to a big- spending, highly-taxed state, close to home. With that, we have a terrific panel who I think will shed some light on these questions and it’s my pleasure now to turn the evening back to John Donvan and our panelists tonight.

### Moderator
Claim: Round of applause for Robert Rosenkranz, please, thank you. Well, hello everyone, and welcome to another debate from Intelligence Squared US, I’m John Donvan of ABC News, and once again, it is my pleasure to serve as host and moderator, as the six debaters you see sharing the stage with me here at the Skirball Center for the Performing Arts at New York University. Six debaters, three against three, will be debating this motion— “California is the First Failed State.” Now, I want to point out that this is a debate, it’s not a symposium or a seminar, it is a contest. These two teams are here to win. And you our audience serve as our judges, by the time the debate has concluded you will have been asked to vote twice, once before the debate and once again after. Vote on whether you agree with the proposition, “California is the First Failed State,” or whether you vote against it. At the end of the debate the team that has changed the most minds, will be declared our winner. So let’s go to the preliminary vote, if you look to the right arm of your seat, there’s a keypad… numbered 1 through 0, only pay attention to keys number 1, 2, and 3, if you agree with the motion, “California is the First Failed State,” press number 1. If you disagree press number 2. If you are undecided, press number 3, and if you make a mistake just correct yourself and the system will lock in the last key that you pressed. And I’m gathering from expressions that everyone has completed this. No one needs more time? Okay. And so to Round 1, opening statements by each debater in turn. Seven minutes each. Our first debater speaking for the motion, “California is the First Failed State,” Andreas Kluth, who is The Economist’s West Coast correspondent. He covers politics, society, and the economy in California and the western states, he spent a long time working out of New York. Having made the move to California, Andreas, I understand in your office you work from a yoga mat. Is this is not the influence of California, on—

### Conspiracy Advocate (CA)
Claim: On a tatami mat, in the lotus position, that’s true.

### Moderator
Claim: Ladies and gentlemen, Andreas Kluth—

### Conspiracy Advocate (CA)
Claim: I’m willing to prove it. Thank you. California is the first failed state, and most of you probably believe that already. Which is a tactical disadvantage for us on this side, but if you do, we want to keep your vote. For the rest of you, we’d like to convince you of that this evening. And, before I start doing that, I just want to clear away something that might be confusing. The proposition is cheeky, as all of you know, all good Oxford-style debates start with a cheeky proposition. The reason this one is cheeky, is that “failed states” usually refer to sovereign states.

Somalia, Sudan, Yemen, Haiti. And what those have in common, is that they have lost a monopoly on legitimate violence, if you think that through, or maybe back to Poli. Sci. When that happens, warlords take over or maybe Somalian pirates, and the state as such loses authority, well clearly, no one on the stage tonight is going to argue in the next two hours that California is already ruled by warlords or pirates. So what are we talking about when we talk about one of the 50 states, domestic states. We have to agree to a working definition to make this interesting. California and other domestic states that may follow have failed, if they fail to support their citizens and instead hinder them. What’s another way of saying that is, if a state, if the governance part of the state as opposed to private industry, can no longer address or solve the problems it faces, then it has failed. California easily meets those criteria. And I just want to quickly because that timer is running already, run down some of the problems to remind you, maybe we can go into them later in depth. Prisons, California has the worst recidivism rate in the country, how did it get like that. Water, it’s an infrastructure and a climate issue but it’s also a political, a governance issue. Education. Before California became a failed state in the Pat Brown era of the ‘50s and ‘60s it built the best public university system in the country, it is currently dismantling that because it is now a failed state. Budgets. And a state is supposed to have a budget, to pass it on time, California never does, that started well before the recession. California—or states are supposed to pay their bills to their vendors and so forth, as all of you know, probably all of you know, California has been paying with I.O.U.’s. Courts. I asked Ronald George, Chief Justice of the Supreme Court, whether he thought it was a failed state, he could say you could argue that, if the state no longer administers justice because its courts are closed part of the time, and dockets of cases is backlogged. California has the worst credit rating of the 50, you know that, it was just lowered again by S&P. Our opponents may try to convince you tonight that this has something to do with the Great Recession, and that as soon as there’s a recovery these problems will recede. It’s not true, all of you have heard Warren Buffett say it’s only when the tide goes out when you learn who’s swimming naked. California has been undressing since the 1970s, I hope to get into that. I argue that it’s been stark naked since the ‘90s, and indeed, the tide has just now gone out with the Great Recession but that’s not something that happened overnight, the failure that is, the nakedness. It’s just been revealed. Our opponents may also argue that California has problems, but all states have problems, as Mr. Rosenkranz reminded you here. And that that does not amount to failure, that’s not true, that’s not appropriate in the case of California, because only one state has all problems simultaneously. And when you have all problems simultaneously you tie them together into a straitjacket and that’s what California is in, it’s in a straitjacket, because of its governance structures. I want to develop that in the time that remains right now a little bit, and then hopefully go deeper into it later in the evening to show to you what the unique aspect of that confluence is. Unique number 1. Three states, for example, have the super-majority requirement that both houses of a legislature have two-thirds votes to pass a budget, three states. Arkansas, Rhode Island, and California, nothing unusual yet. 16 states have the same super-majority required to raise taxes. Only one state has both. How did California— California is that state. How did California get that second super-majority requirement. It was the infamous Prop 13, I understand it’s famous even on this coast…1978 when they started undressing. It is part of something called direct democracy that the founders of the nation, as opposed to the state, were very skeptical and afraid of—about, afraid of. It includes initiatives, referenda and recalls. 24 states have initiatives, have direct democracy. Only one does not allow its legislature, to amend initiatives that its own voters have passed, no matter how insane. Only one state, only one state has the process, has really run certifiably amok, out of control, insane, in only one state, do the inmates run the asylum. Tonight, you may hear that California, this usually comes up, has great weather. You may hear about its beautiful redwoods, Yosemite’s gorgeous. You may hear about the vibrancy of Silicon Valley which I used to cover. All that is true, it’s all irrelevant. Because we’re not talking about whether or not the state has assets. Whether or not there are some good things in the state. Of course there are. We’re talking about whether the state as such, the structures that make the state, the governance structures, have failed, and indeed they have, and the other states must be very careful unless they have the same unique—the same combination of problems that put them in the same straitjacket, and also lead to failure. Our opponents are great orators…don’t let them confuse you tonight… I’ll be back in a little, in a few minutes, but for now just remember what the definition of a domestic failed state is, remember to stay on our side, stay on our side, you probably are there already. California is the first failed state.

### Moderator
Claim: Thank you, Andreas Kluth. Our motion is “California is the First Failed State,” you’ve heard the first opening statement in support of the motion, now to speak first against the motion, I’d like to introduce Gray Davis, the 37th governor of California who happens to be like me, Bronx-born. Anybody else? Oh, a lotta hands, lotta hands. Governor, you can start heading for your lectern. Governor Davis encountered direct democracy head-on-head when he lost a recall election in 2003, but prior to that he had won almost every election he had ever run in as he served as State Controller and as Lieutenant Governor. He is, though Bronx-born, a true Californian, ladies and gentlemen, Gray Davis.

### Scientific Advocate (SA)
Claim: Thank you. Thank you, John, I’m thrilled to be back in New York, as John said I was born here, many of my relatives are here, actually most of my relatives. I graduated from Columbia Law School. And not to be undone, NYU sent me two graduate students to help me get reelected in 2002, so. I’m fond of New York, I think I have a sense of how New Yorkers think and I think a lot of you probably voted that California is the first failed state, so my hope is that I can impress you with what is right about California, and why it’s already an asset to the nation, and will be more of an asset as we move forward in this global society. First let me acknowledge that there are problems in Sacramento…but the shortcomings of our elected officials should not detract from the creative contributions of our 37 million citizens. Our GDP which is one way we measure societies in this world, is $1.9 trillion, far and away the largest in America. Larger than Russia, larger than India, larger than Canada. In fact the eighth largest in the world. And if we were a separate country, we would be a member of the G8. So one way we measure societies in a capitalistic world, is by their GDP and certainly California has no apologies for that. I’m also pleased to see that a recent edition of Time magazine agreed, and was very bullish on California. It titled its piece, “California is Still the American Dream,” and I quote: “It is”— “it” meaning California— “is the cutting edge of America’s future. It is the greenest, most diverse…most global…and most Asian-oriented society at a time when the world is moving in all those directions. It is an unparalleled engine of innovation, a Mecca of high-tech, biotech, and now clean-tech. In fact, from 2006”— and I’m still quoting—“2006 to 2008, it received 60 percent of all the clean-tech investments in this country, and in 2008 it received more venture capital funds than the other 49 states combined.” With all of its problems it still managed to nurture some of the most innovative companies in the world, Google, Apple, Hewlett-Packard, MySpace, Facebook, Twitter, YouTube, Cisco, Intel, Disney, eBay, and many other companies that are helping invent the future for California and for the— for America. California is all about change. It likes to get there first, and it frequently does, it was the first state to regulate greenhouse gases. It was the first to allow full-scale stem-cell research. It was the first to establish renewable energy portfolio standards. What do I mean by that. It said to its utilities, use renewable energy. Depend less on fossil fuel. As governor I was proud to sign all those bills into law, but prouder still, to be part of a 35-year tradition of promoting energy efficiency and energy conservation. Now why am I talking about this. Because, the green economy is the next great wave in the American economy. We have to be green, we have to be reorienting the grid, we have to live more lightly on the planet if we are going to compete globally. 35 years ago, during the first energy crisis, California decided, if it wanted to promote conservation, it has to give the utilities a financial incentive to permit that. So it said to the utilities, you can make more money if you encourage your customers to consume less. And ever since then, we’ve been regulating everything that uses electricity, from appliances, refrigerators, dishwashers, homes, all kinds of businesses, cars, and even lately flat-screen TVs, and along the way, we saved rate-payers $56 billion, and avoided building 24 new power plants. In fact, our electricity growth has been nada, zippo, zero, over 30 years, as we became the largest state in America--the rest of the country is more than 50 percent. Why do I tell you that? Because how America obtains energy in the future, will be critical to our economy, our environment, and to national security. And I submit to you that California’s proven leadership in this area over the last 35 years, will stand this nation in very good stead. Now to be sure, we have problems in Sacramento, but believe me, the voters have tuned in to this issue, and they have already made change that’s substantial. For many years the legislators drew their own districts, meaning they decided in what district they would run, they decided you would be in my district, you would not. And so not surprisingly, they almost never lose. Governor Schwarzenegger proposed a redistricting plan, it passed, I supported it because I believe it’s time the voters draw the line, not the people and it’s time we bring accountability to Sacramento, that will kick in in 2012 and that will make a big difference. Now voters get punished if they react harshly towards their core constituencies, Republican- raised taxes, they have all kinds of recall attempts against them, Democrats punish the teachers, there’s a primary opponent next time. Under a redistricting plan, if you don’t solve the problem, you will get defeated. Similarly in June there is an open primary…a change I predict California will embrace, I support it, I’m the only governor elected in an open primary, the Supreme Court of the United States struck it down, but they have approved this version. It’s essentially a municipal election. If anyone can vote, independents, Republicans and Democrats, and you can vote for a Republican for governor or a Green Party for governor or a Democrat for governor. The top two vote-getters run off in the general election, even if they’re from the same party. That’s going to produce pragmatic, moderate problem-solving candidates. Finally there’s a call for a constitutional convention. I support that idea. It’s time we eliminated in my judgment the two-thirds vote requirement to pass a budget. Yes, we have a two-thirds vote requirement to pass a budget, and a separate one to pass the budget. Just that requirement to get a two-thirds vote to pass a budget is the reason we are always late, it’s ridiculous, only three other states have it. I think that’s the kinda thing a constitutional convention will change, and if the changes are, are sensible, the voters will accept it. So in short, our private sector is the envy of the world, and innovation will lead America, into a future that is brighter and stronger. Our public sector is on the mend and will get better at the end of 2010. Vote no, number 2, vote no.

### Moderator
Claim: Thank you, Gray Davis. Our motion is “California is the First Failed State,” and up now to argue for this motion, to argue that California is the first failed state I’d like to introduce Sharon Waxman, who has a long and distinguished career working for the New York Times and the Washington Post both as a foreign correspondent and as a reporter covering the entertainment industry from the inside out, she’s written books about it. She has started a Web portal on the entertainment industry known as The Wrap.com, and though you are arguing that California’s a failed state you believe enough to base your business there. Am I right about that?

### Conspiracy Advocate (CA)
Claim: Yeah, I like the weather.

### Moderator
Claim: Okay. It makes sense, ladies and gentlemen, Sharon Waxman.

### Conspiracy Advocate (CA)
Claim: So before I get going I just want to know if Gray Davis’s relatives are going to get to vote this evening? If they’re filling half the room. I come to you tonight as a mother, as an engaged citizen, and as a journalist who has covered California for the past 15 years. So let’s start with the area I know best that I deal with every day and that’s Hollywood. Hollywood, the symbol, a signature of California. Part of the dream of what California represents. And a symbol of course to the world of California’s industry, creativity, prosperity, and the values of American culture. Here’s the only problem with that. Hollywood’s not really in Hollywood anymore. It’s gone to New Mexico, and Arizona, and New York, and Vancouver, and London. So Avatar, the movie that is now breaking all the box-office records was really filmed in New Zealand. And Twilight, that series that all your kids, all your daughters are going to see was filmed in Vancouver, and Harry Potter, that series of extremely successful movies was filmed in London. So the people who run the industry, which is a fairly small number of people, they still live in Brentwood and Bel Air and Beverly Hills and places like that but the hundreds and thousands of jobs that produce this, juggernaut of—not just of jobs but of tax revenues to the state, has largely fled, film production is down to half of what it was in California in 1996. This is the way things are going, and the reason for me it has a lot to do with California failing to create a sense of connectedness with this incredibly core industry, it’s so much of what we ought to be proud of, by the way of course the entertainment industry is one of America’s top exports, not only California. But it doesn’t feel like that there is a connection between what the state represents, and the identification that we have with Hollywood and that vast entertainment industry, with the state, and why is that. It seems to me that the state has neglected it as it has neglected so many things. And that goes to me to sort—one of the, one of my big observations about living in California especially after having lived around the world for much of the beginning of my adult life, is that there isn’t that sense of connectedness, as a community. And the state plays a big role in that. Where we live in California, is largely in gated communities, with private security, we live in isolation, and this is nothing new, we all know that. People, you can go to a place like Koreatown which has the largest ethnic community of Koreans outside of Korea, 800,000 people. That community feels extremely Korean. They feel extremely connected to the country of their parents’ birth or of their birth or of their ancestors. I don’t think they feel Californian. And I think that that’s true of so many of the ethnic groups that have come to live in enclaves in California. I see that as a failure of the state to create that sense of identity among them. Here’s another big thing that bothers me. People who know me know that this is my pet peeve. The state has not provided an infrastructure that allows us to be a community, and community is all about what the state is there to protect, and preserve, and to nourish. So I can’t tell you how many times I have driven up to the edge of the 10 freeway from where I live in Santa Monica, peered over the railing, hoping to go to a Lakers game, or to visit a museum, or to go visit Disney Hall for the first time which I would have never succeeded in doing when they were actually playing a concert, and, dared to jump into that essential parking lot of the 10 freeway. That’s because, there isn’t a transportation system that works. We are essentially a city that sits on the roads, and that we have of course made a decision not to have a public transportation of any significance, and the roads are long- neglected and the state has not invested in them, to me, that is, as a member of-- somebody who wants to participate in the community, I feel I can’t get to the community, and that to me is a failure of the state. Finally, I want to speak to you as a mother. I’m the mother of three children. And I moved my family from Europe actually, to raise them in California, and we all, all of us in our family, my husband and I and kids who were then small, were aware of what it meant to go pursue the California dream. That dream has really turned out to be one that we have to create for ourselves. We came from Europe where public transport was something that was a given. Medical care was a given, education was a given. At the very least, I knew that coming to California, that I was moving to a state that had the best public university system in the country, if not the world. Today, that system has been, I feel, taken away from us. Because of the problems with the state, they just, again, you probably all read about it, raised the fees some 30 percent in the UC system, and, they’re now approaching the fees of a private university, it now costs about the same to go to UCLA Law School—my son the lawyer, I’m just still as it is to go to a private law school. How is it that the state is abdicating its role in creating a generation of the best and the brightest in the state of California, which was all about what California represented. So…all of this together, leads me to say to you, that California is a failed state. I commend the governor on all of the changes that he’s laying out as hoping to come to California, and, as an entrepreneur having started The Wrap.com, I can tell you that there are wonderful companies there—and I chose to start my company in California, however, that doesn’t mean that that is because the state encourages us to do so or allows us to do so, that is a testament to the innovation that the citizens and the residents of California have shown. It is not proof that the state has not failed. And so I would like you to vote for the proposition that California is the first failed state. It has neglected its fundamental industries, it has neglected its fundamental functions, and it has neglected its fundamental values as a state.

### Moderator
Claim: Thank you, Sharon Waxman. Thank you, Sharon Waxman. Okay, a reminder of where we are, we are halfway through the opening round of this Intelligence Squared US debate, I’m John Donvan of ABC News, we are listening to opening statements from each side. We have six debaters, two teams of three and they are fighting it out over this motion, “California is the First Failed State.” Now on to our next speaker against the motion…I’d like to introduce Van Jones, Van Jones was the founder, co-founder of the Ella Baker Foundation for Human Rights and Green for All. He was part of the Obama administration as special advisor for green jobs, he resigned that position after being targeted in a nasty political imbroglio, but his standing in the greenest state in the nation is enormously high in the green movement, and Van, I saw on Facebook only today, a “Draft Van Jones for Governor” page? Would… Would you want the job?

### Scientific Advocate (SA)
Claim: Well, I—it would be and I’ll tell you this. One of the—I’m not running, but— Be an honor to serve butt--and I’ll tell you why, first of all, California is not a failed state and our colleagues have pretty much conceded that they cannot win this argument based on the assertion that it’s a failed state so instead they point to some failings. But what they haven’t told you is that every single one of the problems—structural and otherwise— that have been pointed to you, have solutions, and the solutions are now on the way. We have in our state… We are the biggest state—we have some of the biggest problems—we also have the biggest potential for problem solving, and the largest number of problem solvers. So every one of the structural problems that has been pointed out—from redistricting to the tax issues, to the budget issues—have gathered the combined wisdom across the political spectrum, there are now ballot measures moving forward, there are solutions for these problems. To say that California is a failed state is different than saying it has some failings. We have some serious failings, but we also have a set of assets, that our friend was trying to make sure you didn’t pay attention to, that will help us solve these problems.

First of all, when you look at a state like California, you look at a state that, on the three critical issues that are most important for our country, California is not failing—it is succeeding and it is leading. What are the three critical issues? Number one, how will we power America, as the governor just talked about. How will we power this country? Will we continue to rely on the post well oil strategy that we have been stuck in, with petroleum and coal for 100, 150 years now—it’s the post whale oil strategy—we’ll continue with that? Or will, will we innovate our way out? Will we invent and invest our way out? In California, that is what we are doing. In a failed state, capital does not flow in—capital flows out. In California, we have quadrupled—in the past two years— the amount of venture capital flowing into the state, because we are trying to solve the biggest problem humanity faces: the problem of global warming, and the biggest problem our country faces: the problem of energy independence. California is leading and succeeding in that. We just attracted a company, Electric Vehicles International, to come and build zero emission cars in California. They could have gone anywhere in the world. They came to California because of the policy certainty, because of the consumer demand, because we are on the front edge. We have policies in place passed—despite all the problems with our legislature—we have passed on a bipartisan basis with a Republican governor…a Democratic legislature, AB 32, our Global Warming Solution Act, which will drive the creation of 400,000 clean and green jobs. We have set high aspirations with regard to renewable energy. Possibly, as many as three-quarters of a million jobs that will be created there. 15,000 jobs right now in solar, in the solar industry, and growing. A failed state doesn’t do that. That is not a failed state.

Number two yes, Sacramento has a ton of problems. Help is on the way. Great ideas are on the way. But the entire State of California did not live in Sacramento. We have an incredible level of innovation at the governance level, cities, and regionally across the state, because the second big problem is—how are going to live together in cities? How are we going to live together at a community level? Can we solve problems? You see in California, problems are being solved every day—tough problems. Look at the problems with the port of Los Angeles—just to brag a little bit on the people of California—where the pollution was so bad that little kids who live close to the port of Los Angeles were getting asthma and dying, and people said that we can’t solve this problem because of the logjams and all the special interests. They got together, they sat down, they came up with a Clean Truck Program that helped lift the living standards of 10,000 truckers. Got new technology in those trucks on the roads, and took asthma inhalers out of little girls’ and little boys’ pockets. That is the kind of problem solving that’s going on at the local level. In Fresno, you have a wonderful new mayor, Ashley Swearengin, who has been able to pull people together in the agricultural heartland of our state, and create 19,000 new jobs, through a regional economic initiative. In Northern California, you have mayors like Gavin Newsom, Ron Dellums and others who had come together, who have come up with local creative financing to get green home improvements going, weatherization and solar panels attached to property taxes so people can actually get all these new technologies going. And these are the kinds of things that are happening on a daily basis. And those things don’t happen in a failed state. In a failed state, when things are tough, people turn on each other. In California, people are turning to each other, and working together across lines of class and color.

And the last thing I want to say is that the, the third big challenge for this country and for this world is—how are we going to live together? In the age of this kind of diversity, how are we going to live together? There is a miracle every single day in California, a miracle. And it’s a miracle of cooperation. In Oakland, California, there are 30 to 40 different languages spoken in the public schools—30 to 40 different languages spoken in the public schools. To the extent that there is conflict—it’s not about that…it’s not about that. We have been able to figure out a way to come together, to work together. That is not just a good example for the United States…that’s a good example for the world. There is no place in the world that has the kind of diversity and density that we have…that manages to do it with elegance, that manages to do it successfully. And when you have a state where 20 years ago there was a conflagration over race and ethnicity—people remember Los Angeles 20, almost 20 years ago. Somebody stood up and said, “Can’t we all get along? Can’t we all get along?” Californians have answered that question—yes we can, yes we can get along— and we do it every day. And it’s out of that community of many colors, many classes, with every faith, every sexuality, working together on a daily basis, that great solutions have come in our economy, have come in local governments, and are now coming from our state governance.

This is not a failed state. We have some failings, but this state is a state that is now rallying to solve those problems. Don’t vote against us, vote for us. Thank you very much.

### Moderator
Claim: Thank you, Van Jones. Our motion is, “California is the First Failed State.” And now to argue for that motion, to argue that California is the first failed state, I would like to introduce Bobby Shriver, who is a councilman in Santa Monica and co-founder of One.org, and a scion of one of America’s greatest political families, ladies and gentlemen, Bobby Shriver.

### Conspiracy Advocate (CA)
Claim: Thank you very much. I also want to put in a plug for Red, which I started also with my great colleague, Bono, my partner—which I always like saying. Because most of my life, people have been saying other things about me. I was President Kennedy’s nephew. When my dad started the Peace Corps, I was Sergeant Shriver’s son. When my mom started the Special Olympics, I was Eunice Shriver’s son. And then a terrible thing happened in our family—my sister went on national television and became the host of the CBS Morning News. So four brothers, very competitive Irish family, were faced with the prospect that we were going to be known forever as Maria Shriver’s brothers. So we had a meeting—what could we do about it? And we had various ideas, none of them very good. And at one point, one of my brothers said, “Well, face it, you know, it’s done, and it can’t get any worse.” And then Maria got married. So, I love it when I go and see in the program that I am Bono’s partner, because I am really tired of being Arnold Schwarzenegger’s brother-in-law. I appreciated our eloquence of some of our colleagues, but I want to point out very, very specifically that all of the answers are on the way. They are not here now. And I can tell you in local government, where I serve on the City Council in Santa Monica, that things are bad. We are lucky in Santa Monica because we have a great, diverse tax base. But just to give you a couple of illustrations… Our redevelopment agency had a budget this year of 30 million dollars—the state took 22 million of that. How can you work on that basis? And this is a reminder also, that when you talk about the state, you are not talking about Google and Intel…and you are not talking about local government…you are talking about the state government. It’s very important. The state is a constitutional entity, it’s a legal entity. It’s not California. When Steve Jobs writes on every Apple product, “designed in California, assembled in China,” he is not talking about designed in the State House of California…he is talking about in the culture of California, which I think we all agree is the greatest culture in America and maybe in the world. Thank you. There are local Californias in the culture.

Think about it. Right now… A good interesting point, segue, I’ll go to your idea. There is no art education in the state in the public schools. We are the last in the state, in all of the 50 states. We are below Guam in arts education.

I am serious. I mean, it’s… It’s kind of a little funny, but it’s hard to believe really… And that’s a state responsibility. The money is not there. Why is the money not there? Because the people have lost confidence in the government obviously.

I’ll give you another example. In Los Angeles, we have the biggest homeless population in America, 80,000-plus people. The L.A. County Jail is the largest mental health facility in the world…in the world. If you go there, every single one of you—I don’t care what your background or point of view on this debate would be— would be sickened to see what’s going on in there. There is a famous quote from the, uh, I think it’s Hammerati who said, “The purpose… One of the purposes of government is to protect the weak from the strong.” We have completely failed. You go in that L.A. County Jail and you will see the weakest people in our society…mentally ill people living in cages…there are 14 full-time pharmacists to medicate them…in Downtown L.A.

Of the 85 or some-odd thousand people that are homeless, about a third are veterans. We have a 400-acre property in West L.A. in Westwood…that have empty buildings in it…which were built as mental institutions for veterans that are empty—and have been empty for more than 20 years. Why is that? The state hasn’t cooperated with the feds to fix that… I don’t know…I can’t come here and give you an answer. I have been trying to fix it for the last five years, and so far I have failed. Although President Bush and Secretary Nicholson did designate three of the buildings for homeless veterans—which is a positive thing. And I understand that one of the answers on the way—there is 50 million dollars in the new defense appropriations bill for that building, which would be a great thing. But the fact that people burnt… And in my little ol’ Santa Monica, a man burnt to death in a dumpster…a homeless man, burnt to death in a dumpster several months ago…is unacceptable.

And you would say, well, that, you… as a senior official of the state said to me, “Well, Bob, you know, you gotta calm down. You know, you gotta… You are very hopped up about this homeless thing.” And he said, “Why are you so hopped up about it?” I said, “I am afraid my mom—God bless her and God rest her soul—is going to hear that a homeless guy burnt to death in a dumpster in my jurisdiction”…which is what she used to call it, “my jurisdiction,” not “my constituency.” Because she would be enraged.

So, going on to the kinds of things that Sharon said. The public community—which is really the primary goal of the state—not to get too esoteric about it—but to have a kind of political compassion for people does not exist. You can’t have that many homeless people…you can’t have the underfunding of education that exists…you can’t have that many homeless veterans…and say that the state has been successful in creating—amongst its citizens—a concept of political compassion. That we are going to get together… We have community interests. We are going to get together and we are going to do something about them. And ideas are on the way… And green tech, great. It’s all fantastic. For the least of these, it’s not fantastic in California. It’s really not.

I’ll give you another example—a local example. The City of Beverly Hills has a school system, Santa Monica has one. The state is organizing school districts like that. They had kids from out of the City of Beverly Hills in that district, because the state used to pay—and still may—a certain amount per student. So you would bring people from out of your district who were not there and educate them. They changed that formula recently, and what did Beverly Hills do?—and they are not bad people— they expelled all those kids. Why? We are not getting paid for it anymore. That’s a state failure—not a Beverly Hills failure, not a failure of those communities.

So as you think about how you are going to vote, it’s very important to say… And I like to be optimistic—and I am optimistic. When they asked me, which side of this debate did I want to be on, I said I wanted to be on this one. And they said, well, don’t you want to be on the optimistic side? I said, this is the optimistic side. This is the optimistic side. Because if you don’t know that the problem is as bad as it is…if you don’t go to the L.A. County Jail and see that…you think— and I mean this respectfully—that help is on the way. Help is not on the way. We, this year…I’ll give you one final example. The CalPERS—the pension charged to little, to cities—going up 25 percent. In our budget, that’s a breaker, you know? So it has nothing to do, as I said—I am repeating myself—with Google…it has to do with, can you run the trains on time? Thank you.

### Moderator
Claim: Wow.

### Conspiracy Advocate (CA)
Claim: I am serious. I mean, it’s… It’s kind of a little funny, but it’s hard to believe really… And that’s a state responsibility. The money is not there. Why is the money not there? Because the people have lost confidence in the government obviously.

I’ll give you another example. In Los Angeles, we have the biggest homeless population in America, 80,000-plus people. The L.A. County Jail is the largest mental health facility in the world…in the world. If you go there, every single one of you—I don’t care what your background or point of view on this debate would be— would be sickened to see what’s going on in there. There is a famous quote from the, uh, I think it’s Hammerati who said, “The purpose… One of the purposes of government is to protect the weak from the strong.” We have completely failed. You go in that L.A. County Jail and you will see the weakest people in our society…mentally ill people living in cages…there are 14 full-time pharmacists to medicate them…in Downtown L.A.

Of the 85 or some-odd thousand people that are homeless, about a third are veterans. We have a 400-acre property in West L.A. in Westwood…that have empty buildings in it…which were built as mental institutions for veterans that are empty—and have been empty for more than 20 years. Why is that? The state hasn’t cooperated with the feds to fix that… I don’t know…I can’t come here and give you an answer. I have been trying to fix it for the last five years, and so far I have failed. Although President Bush and Secretary Nicholson did designate three of the buildings for homeless veterans—which is a positive thing. And I understand that one of the answers on the way—there is 50 million dollars in the new defense appropriations bill for that building, which would be a great thing. But the fact that people burnt… And in my little ol’ Santa Monica, a man burnt to death in a dumpster…a homeless man, burnt to death in a dumpster several months ago…is unacceptable.

And you would say, well, that, you… as a senior official of the state said to me, “Well, Bob, you know, you gotta calm down. You know, you gotta… You are very hopped up about this homeless thing.” And he said, “Why are you so hopped up about it?” I said, “I am afraid my mom—God bless her and God rest her soul—is going to hear that a homeless guy burnt to death in a dumpster in my jurisdiction”…which is what she used to call it, “my jurisdiction,” not “my constituency.” Because she would be enraged.

So, going on to the kinds of things that Sharon said. The public community—which is really the primary goal of the state—not to get too esoteric about it—but to have a kind of political compassion for people does not exist. You can’t have that many homeless people…you can’t have the underfunding of education that exists…you can’t have that many homeless veterans…and say that the state has been successful in creating—amongst its citizens—a concept of political compassion. That we are going to get together… We have community interests. We are going to get together and we are going to do something about them. And ideas are on the way… And green tech, great. It’s all fantastic. For the least of these, it’s not fantastic in California. It’s really not.

I’ll give you another example—a local example. The City of Beverly Hills has a school system, Santa Monica has one. The state is organizing school districts like that. They had kids from out of the City of Beverly Hills in that district, because the state used to pay—and still may—a certain amount per student. So you would bring people from out of your district who were not there and educate them. They changed that formula recently, and what did Beverly Hills do?—and they are not bad people— they expelled all those kids. Why? We are not getting paid for it anymore. That’s a state failure—not a Beverly Hills failure, not a failure of those communities.

So as you think about how you are going to vote, it’s very important to say… And I like to be optimistic—and I am optimistic. When they asked me, which side of this debate did I want to be on, I said I wanted to be on this one. And they said, well, don’t you want to be on the optimistic side? I said, this is the optimistic side. This is the optimistic side. Because if you don’t know that the problem is as bad as it is…if you don’t go to the L.A. County Jail and see that…you think— and I mean this respectfully—that help is on the way. Help is not on the way. We, this year…I’ll give you one final example. The CalPERS—the pension charged to little, to cities—going up 25 percent. In our budget, that’s a breaker, you know? So it has nothing to do, as I said—I am repeating myself—with Google…it has to do with, can you run the trains on time? Thank you.

### Moderator
Claim: Thank you, Bobby Shriver. “California is the First Failed State” is our motion. And you have all heard all of the debaters but one. And next up to argue against this motion, Lawrence O’Donnell, who has one of these Renaissance men résumés, having held positions as a political analyst for MSNBC and having served as Chief of Staff for the U.S. Senate Finance Committee, and for being a writer and producer on West Wing and for being an actor on Big Love as well. It’s a lot. Thanks for coming by.

### Scientific Advocate (SA)
Claim: Do I…?

### Moderator
Claim: Lawrence O’Donnell.

### Scientific Advocate (SA)
Claim: Thank you. Do I really have seven minutes? Because, you know, on MSNBC, I never get out more than a sentence and a half before Pat Buchanan interrupts me, so I don’t know that I have seven minutes. I had some prepared material, which I will use some of. But I would like to very quickly go through some of the points that you have heard from the presenters of this preposterous idea.

I want to though give you the correct concept that you are aiming for here, in that, in the title of this proposition, is it the first, the first failed state? What that means is, is it the worst of 50 states? All this side has to do—all it has to do—is give you the idea that there might be somewhere the 50 states somewhere…one—one—that’s doing something worse than California…or maybe doing everything worse than California. And oh, by the way, might also be a slightly less desirable place to live. That’s our chore. We have to find you one that you don’t want to live in.

And you know, the proposition was defined by Andreas at the beginning. He had to admit that it was a cheeky proposition. The backing off from the strength of the declaration and the proposition. He mentioned recidivism rates in California prisons—they are not good. Crime is down, does that count? Does it matter that in Los Angeles crime is down dramatically because the mayor had the wisdom to import the police commissioner that Rudy Giuliani, Rudy Giuliani’s ego couldn’t stand in this city, Bill Bratton? Bill Bratton came out to L.A. in the process… and through an exercise of government—local government and local police work—got that crime rate down dramatically, as he did here.

You will hear about different problems. You will hear Bobby talking about the homeless. That’s important. That is, that is tragic. But remember what the case is here. The case is, is it somehow a California issue? Is what Bobby talked about a California issue? California has more homeless people than any other state. It has more wealth than any other state. It has more poverty than any other state. It has more agricultural production than any other state. It has more people. It has more. Every single thing they will tell you about anecdotally—yes, California has the most of it. But as we sit here in the lower end of Manhattan, is it conceivable…is it conceivable that a homeless person has died in gruesome circumstances, in gruesome circumstances in this zip code, ever? Or maybe, how often? Is that the question for this zip code?

You know, Sharon mentions getting around is difficult. The traffic is hard. It is hard. It’s hard to get your car to a Dodgers game from Santa Monica, where Sharon and I live, that is true. What time do you have to leave to get a 7:00 P.M. flight from JFK? From here. Not from up in the Upper West Side, where it’s even more difficult. But what time…? When would you leave? 3:00? I mean, you know, factor in some security issues at the airport… I don’t take 7:00 P.M. flights from JFK, because I can’t get there. It’s just not going to work—I am going to have to surrender too much of the day.

The budget cuts in the university system, budget cuts— educational budget cuts have been mentioned. Take your time. Take all the time you need to come up with the name of a better public university—not in the 50 states, in the world—a better public university than the University of California at Berkeley. Take your time. We have all night. The delicious irony…the delicious irony of having this debate…in this state… Today’s local paper, The New York Times, in its seemingly endless editorial series called “The Failed State.” It stars—as usual—Albany. They have… This one happens to be about the ethics bill that they are… the improvement in the ethics program that they are trying to introduce in Albany. Utterly hopeless. You would think there would be some momentum for that—after Joe Bruno gets convicted, of actually running businesses out of his office and all other sorts of illegalities— there would be some momentum for it. It’s hopeless, it won’t happen. You don’t know what the outside income is of your state legislators—and you don’t know it by law. So when you want to have this debate about failed states and failed state governments—with the state legislature that you have—having it here is cheeky. I lived here longer than I have lived in Los Angeles. I worked in government with Senator Moynihan. Very much concerned with issues facing this state. Very much concerned with its fair share, for example. The problem… And what we discovered…and what we harped on endlessly back in the ‘80s and ‘90s was New York sends more money to the federal government than it gets back— hence, all of its budget problems. Well, the problem is much worse in California. California gets 79 cents back for every dollar that it sends to the federal government. So the reason you don’t have 40 other so-called failed states is because California tax money is paying for Alabama, it’s paying to keep Alaska running, it’s paying to keep Arkansas afloat. You can’t balance any of the books in those states without the money that comes out of California pockets to fund it.

There is much more to be said about this. I am running out of time to do it. I didn’t think I had six minutes… seven minutes, thank you.

## Round 2

### Moderator
Claim: Thank you, Lawrence O’Donnell. And that concludes Round 1 of this Intelligence Squared debate. This is a debate from Intelligence Squared U.S. I am John Donvan of ABC News, serving as moderator. And our motion is “California is the First Failed State.” We asked you in the audience—who will be serving as our ultimate judges—before the debate began…to tell us where you stood on this issue. We had you all vote. I now have the first results of that vote, and we do have a contest. Before the debate, on the motion “California is the First Failed State,” 31 percent of you were for the motion, 25 percent against, and 44 percent are undecided. So it’s really wide open.

Now moving on to Round 2. And in Round 2, the debaters address each other directly, and they also take questions from myself and from you in the audience. When I come to you in the audience—which will be in a few minutes— if you raise your hand, I will find you. And we would like you to rise. If you are a member of the news media, we would appreciate it if you would identify yourself as such. And when you take the microphone, hold it about a fist’s amount away from where you are speaking, so that the NPR stations can hear you clearly, as well as Bloomberg. And I really want to urge you to keep the questions to 30 seconds, and really to make them questions. Don’t argue with the panel. Questions, with a question mark at the end of it. Round 1, our middle round. And I begin with the question to the team that is arguing that California is the first failed state. You have been making an argument—primarily, not entirely—but primarily that the failure of the State of California is largely a political failure, the failure of the political system leading to gridlock, and as a result, lack of services. The other team is arguing about… They are listing several kinds of successes.

They are listing successes in innovation, and in technology, and in the development of greening the state, and stem cells, and personal connections, political connections on the small scale. They are coming back at you with success.

Andreas, clearly, of The Economist, well, what’s wrong with that argument?

### Conspiracy Advocate (CA)
Claim: Well, in particular, Governor Gray Davis was making that point. I wrote down a direct quote from you, Governor, “In California, the private sector is the envy of the world. The public sector is on the mend.” You asked me, “What’s wrong with the logic of the first part?” And in fact, I would like to do that, and the second part as well.

And we examined the first part, and go and take a larger period of history—a few hundred years. The most elegant leather shoes come from a town nearly Bologna in northern Italy. The best violins come from another town in northern Italy. That’s been that way for hundreds of years. Would you honestly make the case…? Would you have made the case for much of post-war history that Italy was not a failed state in the European Union because they had a great shoe industry and a great violin industry in the northern Italy?

### Moderator
Claim: Gray Davis, do respond.

### Conspiracy Advocate (CA)
Claim: It is irrelevant. The other point—just briefly. You cannot seriously say that the public sector is on the mend—at the very moment when they are dismantling entire government programs that were intended to protect the weakest. And people are literally going to die, certain old people at home, because home visits are stopping.

### Moderator
Claim: Andreas, let’s now have Gray Davis respond to your first point.

### Scientific Advocate (SA)
Claim: The state is not an abstraction. It is the sum total of the energy, the vibrancy, the creativity and the innovation of 37 million people. It is an exciting place to live because when we have problems, we don’t moan and groan. We don’t bemoan our fate. We say, we are going to solve it, we are going to figure it out, we are going to do something different. So for Andreas to dismiss all the energy, the excitement, the creativity that is producing the iPhone and the social networking, and alternative energy, we… My God, we have got ExxonMobil investing 600 million dollars into a San Diego project that will turn algae into oil. I mean, if that’s not the establishment saying you are doing something smart in California, I don’t know what that’s about. Now to say that’s not part of the state, to say that the state is just some civil servants and some black boxes, we don’t know anything about it. The state are human beings, getting up every day, doing their best to make the world a better place. Expecting to succeed, frequently succeeding, but realizing that risk takers though they are, failure will eventually… Well, failure will occasionally occur.

### Conspiracy Advocate (CA)
Claim: Governor, did you say 60 million…?

### Scientific Advocate (SA)
Claim: Wait, let me just…

### Conspiracy Advocate (CA)
Claim: …or 60 billion? I just want to point out…

### Scientific Advocate (SA)
Claim: Let me just say this… That failure will occur occasionally when you take risk. But they don’t see failure as the end of the journey—they see it as an occasional stop on the road to success. That’s what separates California from a lot of other parts of the world. And that’s why it is—and will continue to be—a successful state, despite what is happening in Sacramento.

### Moderator
Claim: Sharon Waxman.

### Conspiracy Advocate (CA)
Claim: Yeah, I had a question. ExxonMobil, you say was 60 million dollars in San Diego?

### Scientific Advocate (SA)
Claim: 600 million dollars…

### Conspiracy Advocate (CA)
Claim: 600 million dollars…

### Scientific Advocate (SA)
Claim: …in an algae to oil project.

### Conspiracy Advocate (CA)
Claim: Right, OK. So the last quarterly statement for ExxonMobil, they were… Their profits were in the multiple billions of dollars. So in terms of their investments… And that’s a small multiple for…

### Scientific Advocate (SA)
Claim: Yeah, but algae to oil…

### Conspiracy Advocate (CA)
Claim: …for a company like…

### Scientific Advocate (SA)
Claim: And they are… And we are looking into algae and oil in New York? Are we looking to algae and oil in Kansas? Are we looking to algae and oil in Mississippi?

### Conspiracy Advocate (CA)
Claim: They are in Nevada and Arizona…

### Moderator
Claim: Andreas Kluth.

### Conspiracy Advocate (CA)
Claim: …and especially—if you want to talk about the green economy— look to Denmark, China, Israel…

### Scientific Advocate (SA)
Claim: Well, wait…

### Conspiracy Advocate (CA)
Claim: Yeah, and it’s not in California…

### Scientific Advocate (SA)
Claim: Andreas, let me, in your article…

### Moderator
Claim: Governor…?

### Scientific Advocate (SA)
Claim: …in your article…

### Conspiracy Advocate (CA)
Claim: Actually, I limit it to the United States.

### Moderator
Claim: Gray Davis?

### Scientific Advocate (SA)
Claim: Do we have…?

### Moderator
Claim: I just want to make one point…

### Scientific Advocate (SA)
Claim: Do I understand…? We just have to find one state that…

### Moderator
Claim: Well, Lawrence…

### Conspiracy Advocate (CA)
Claim: Well, one state.

### Scientific Advocate (SA)
Claim: …that runs from oil to algae…

### Moderator
Claim: Lawrence, Lawrence…

### Scientific Advocate (SA)
Claim: If there is one state that’s doing less…

### Moderator
Claim: Lawrence…

### Scientific Advocate (SA)
Claim: …on oil to algae, we win.

### Moderator
Claim: Lawrence, I just… I just want to make one point… I am going to refer to Governor Davis as Gray Davis throughout the debate, not out of any disrespect for the office, but because in the debates we keep everything on a first name basis, and I want to make sure that is clear. No disrespect is intended, and I hope nobody takes it that way. And Lawrence, I was talking all over you. And it looked great, so go at it again.

### Scientific Advocate (SA)
Claim: Well, you know, you are going to hear a lot about budget cutting and they are going to… You know, they are going to have to cut back on home healthcare visits and things like that. There are 43 states—43 states—that have cut their enacted budgets of 2009. They enacted budgets for 2009, they have—43 of them went back and cut them, OK? Tomorrow’s newspaper will reveal to you that the governor’s latest idea—your governor’s, New York governor’s, latest idea—is the largest cut in school aid in more than two decades. That’s the latest idea for how to get things going correctly in Albany. And now in searching for new areas of revenue so they don’t have to cut quite so much money, the brilliant idea that your governor here in New York is proposing is—to legalize Ultimate Fighting. Congratulations.

### Moderator
Claim: Bobby Shriver?

### Conspiracy Advocate (CA)
Claim: I just… And since Lawrence is so funny and so experienced, I just have to do a few little, catch-ups here. They don’t win if there is another failed state. That’s not true. It, it’s whether this is the first failed state. So he would have to say that New—and which he was actually saying…

### Moderator
Claim: That New York was first.

### Conspiracy Advocate (CA)
Claim: …right here in New York—that New York is the first failed state. Maybe that would give him a little bit of a point. But I…

### Moderator
Claim: Lawrence, I think he has got you on that one…

### Conspiracy Advocate (CA)
Claim: I really don’t think that that’s what it is. Let me do a couple of things. Berkeley is a great university. Do you know what it costs to go to Berkeley a year? Who knows? 30-plus thousand dollars a year.

### Moderator
Claim: Oh my.

### Conspiracy Advocate (CA)
Claim: Is that a public university? It’s owned by the public, but when you say “Find a better one than Berkeley…” That’s not a public university. The original act that created Berkeley…

### Conspiracy Advocate (CA)
Claim: …you went to Berkeley free. Free is public. Free is the community. 30,000 dollars of after-tax money—per year—is not free. That’s not…

### Scientific Advocate (SA)
Claim: Bobby, that… Bobby, that’s…

### Conspiracy Advocate (CA)
Claim: Just, just… Can I make one other…?

### Scientific Advocate (SA)
Claim: Well, that isn’t right…

### Moderator
Claim: Well, let’s let Gray Davis comment.

### Conspiracy Advocate (CA)
Claim: OK…

### Scientific Advocate (SA)
Claim: The under… The fees have gone up. As governor, I opposed every fee. But the fee to be an undergraduate in Berkeley this year is 10,000 dollars.

### Conspiracy Advocate (CA)
Claim: OK. Well then, I am wrong. I read that it was…

### Scientific Advocate (SA)
Claim: Undergraduate.

### Conspiracy Advocate (CA)
Claim: … in the L.A. Times…

### Scientific Advocate (SA)
Claim: The graduate schools…

### Conspiracy Advocate (CA)
Claim: …then it was lies…

### Scientific Advocate (SA)
Claim: The graduate schools of Law and Business—for several years— have been allowed to float up. And they are—as Sharon suggested—25, 30 thousand dollars. But Ph.D. candidates are very low. So it’s still a… it’s higher than it should be, but it’s still terrific compared to other alternatives available to students…

### Conspiracy Advocate (CA)
Claim: But when you have a student revolt for this…

### Conspiracy Advocate (CA)
Claim: Let me just stop for a second. You do have a student revolt, but I just…

### Conspiracy Advocate (CA)
Claim: That’s true.

### Conspiracy Advocate (CA)
Claim: …and I got the number from the L.A. Times, so… And this is after the new editions, so maybe that’s wrong… Even to me, at 10 grand, it’s… For a people who have modest incomes…

### Scientific Advocate (SA)
Claim: I agree. And I totally agree with you…

### Conspiracy Advocate (CA)
Claim: …10 grand of after-tax money…

### Scientific Advocate (SA)
Claim: …that it’s not fair to them.

### Conspiracy Advocate (CA)
Claim: …is a real thing. The second thing is: I think if you support— which I do too—a constitutional convention, your… When did people have constitutional conventions? The National Constitutional Convention was…when there was a big ol’ mess at hand. You don’t have a constitutional convention when things are going great. So if you support… Right? Right? So if you support…

### Moderator
Claim: All right, stop. Well, let me… And let me…

### Conspiracy Advocate (CA)
Claim: And let me, and let me, and let me just say. If you support a constitutional convention—and I think you should ask all three of these gentlemen whether they support it or not—.

### Moderator
Claim: Uh-huh.

### Conspiracy Advocate (CA)
Claim: —they have to lose, because now you… You don’t have…

### Moderator
Claim: Van Jones.

### Conspiracy Advocate (CA)
Claim: …a constitutional convention…

### Moderator
Claim: I would love to bring in Van Jones…

### Conspiracy Advocate (CA)
Claim: …in a successful—or a less than failed state—.

### Moderator
Claim: Van Jones is part of the weekend summit…

### Scientific Advocate (SA)
Claim: Well, the rules change by the minute here…

### Scientific Advocate (SA)
Claim: Yeah. Exactly. Well… First of all…

### Conspiracy Advocate (CA)
Claim: Oh yeah.

### Scientific Advocate (SA)
Claim: …you are conceding the point—which is that we have, in California, the tools to continue to solve these problems. One of the things that is so exciting about the State of California is that people who have ideas get a chance to actually act on them— maybe to excess at this point. And I would have no problem with rolling back some of the detritus as it accumulates on our constitution. But we actually have the problem solvers, and the tools to solve the problems. And when you say you have a failed state—which you are, and which you are suggesting. First of all, you are trying to take off the table the economic successes. The economic successes are a function—especially in the clean tech area—of policy successes, of political successes. We have been able to put aside partisan differences on one question, which is: If we are going to have the jobs of tomorrow in California, we have got to have the technology of tomorrow…make the products of tomorrow…and we have been able to get that done. And that sets the table for the forward motion that you are talking about. So when you try and take off the table… It’s striking to me. I have never heard of a failed state where the eighth largest economy in the world… I have never heard of a failed state that is literally one-eighth of the output for the entire country. California is to the rest of the country what Germany is to the EU. And I don’t hear anybody calling Germany a failed state, whatever problems they may be, that may be there. And so I think again, you are conceding—when you talk about the fact that we are talking about a constitutional convention, and we are talking about a whole raft—that California forward and other folks are talking about a whole raft of fixes—we have got the tools and the innovation and the determination to fix the problems in California.

### Moderator
Claim: So you are saying…

### Scientific Advocate (SA)
Claim: …and so we are not a failed state.

### Moderator
Claim: So you are saying then that the existence of an ambulance team, means that the hospital is basically not shut down quite yet?

### Scientific Advocate (SA)
Claim: Well, well… If you want to go with that… If you want to go with that analogy… I am saying that the patient is not dead.

### Moderator
Claim: OK.

### Scientific Advocate (SA)
Claim: And that’s what these guys are trying to do…

### Moderator
Claim: But that’s… I think that’s a valid… actually quite cogent argument. Andreas, can you take that on?

### Conspiracy Advocate (CA)
Claim: Sure. So if you say if you want to change it to California is dead… And I can tell you we are not debating that, and we are not arguing it…

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: What we are… By the way, I agree that failure—as you said—is an occasional stop. I happen to be writing a book at the moment about how failure and success are imposters. But you have to be honest that a failure has occurred, in order to fix it. Californians are honest about it—that’s why they will pass the two initiatives that will call for a constitutional convention—just as Americans, after the Revolutionary War, called a constitutional convention because the Articles of Confederation were a failure, and they accepted that and admitted that first, and then you start fresh. So you need to admit honestly that a failure has occurred…then you move on, move on.

A few… Just a little bit of mopping up. About the public universities. What is the still remaining excellence of the university system a sign of? It’s a sign of the Pat Brown legacy, when California was not a failed state. What are they dismantling? I wrote a story about this. I asked professors and the president of the UC system. A professor at UC Santa Cruz of astrophysics told me…the excellence is being lost in her department as we speak because of the budget cuts. The people she was hiring to be good professors have defected because they know there is nowhere for them to go in their careers. They are going to more competitive, private or other public universities in the state and world. So don’t get confused about this public university. It was a sign of something working well 30 years ago… And you are… You will see—when it’s gone—that something failed today.

### Scientific Advocate (SA)
Claim: And we will patiently await your naming of the state that spends more on its university system.

### Conspiracy Advocate (CA)
Claim: On a per-capita basis?

### Scientific Advocate (SA)
Claim: Spends more on its university system.

### Conspiracy Advocate (CA)
Claim: No, that’s… Exactly.

### Conspiracy Advocate (CA)
Claim: He kinda misses… He kinda missed that…

### Moderator
Claim: I want to go to the audience for questions now. And again, raise your hand, I’ll find you. A microphone to your mouth. There is a woman I think in the gray sweater, right? Yes, that’s right. And ma’am, it’s easier for us—and so for the camera to see you—if you stand up…

### Moderator
Claim: OK.

### Moderator
Claim: And hold that mic close and make a good question…

### Moderator
Claim: Well, sure. I am sorry? No one here has raised, the issue of what was passed in 1979—and that was a proposition where basically, negated the state from raising any tax revenues to feed everything that you are talking about, whether it’s schools, public universities, services, art, what have you. And I would ask Van Jones, let’s start with you. Great that we have clean tech and we have the private industry and we have capitalism and competition. But if you don’t have the public monies to support initiatives, where do you get it? Do you tax the capitalists?

### Moderator
Claim: Question mark, very good. Van Jones?

### Scientific Advocate (SA)
Claim: Well… The problem in California isn’t primarily a revenue problem. I mean, there are… We had a courageous governor, frankly, who was willing to do what needed to be done with regard to the so-called car tax. And the five billion dollars was on the table, and that’s off the table. And we are the only state, in California… The only oil producing state in the country that doesn’t tax the oil when it comes out of the ground. It is a billion dollars a year… There are revenue sources that are available. The problem in California right now is—which is why we are here—is that we haven’t agreed on the vision for California going forward.

### Moderator
Claim: Hmmm.

### Scientific Advocate (SA)
Claim: Now, a crisis of vision is an opportunity. And that is… Well, and that’s really, I think, what you are seeing in California. People now—and a critical mass of people—are trying to figure out how we go forward… I think obviously Prop 13, from my point of view, it has been disastrous for the State of California. I think it’s not all taxes, but it is property taxes. And what it’s done is, it has put the state on this yo-yo of tax income based on income tax and other sources of revenue… We would have done better, I think, if we had a little bit more opportunity to have a property tax regime in place. And also the other problem with Proposition 13—which was raised—is that it would…it requires two-thirds of the legislature to agree to any tax increase. And in California, that’s a very, very difficult thing to do given where the Republican Party is.

But what I would say is simply this: We have an abundance of opportunity in the State of California, because of the success of not just our clean energy—we brag on our clean tech because we are so proud of it—but we have nine different regional economies. Which gives us the ability to do what countries do, frankly. We have an agricultural region…we have, manufacturing, etc. And I think that where we are—at this stage in the development of California’s economy—is we will fix the tax structure, we will fix the budgeting structure. And we have already got redistricting done. And then, anybody who bets against California right now, is going to lose an awful lot of money.

### Moderator
Claim: Another question? And would you like to respond, to respond on this side before I go to a question?

### Conspiracy Advocate (CA)
Claim: I would like, I would like to start…

### Moderator
Claim: Oh, this is Sharon Waxman.

### Conspiracy Advocate (CA)
Claim: Oh yeah. I would like to not respond…I would like to ask… And clean tech is… And we keep hearing clean tech, clean tech… How about the industry that I brought up—Hollywood—where that is, that is just the subject of the most egregious neglect in the years that I have been covering the industry. This is a huge amount of money that the state has just allowed to leave. And only this past year has there been the tiniest, too little too late measure to keep it together…by passing a small fraction of the kinds of measures that other states have already had in place for years to incentivize productions to stay in the state. That’s money… That’s not money that’s out there to be created, as clean tech is a future and building, an economy of where we are going…it’s an industry that’s there, that the state has allowed to slip through its fingers, and has never actually created a sense of—as I keep using that word—connection between the people… Yeah, how…? I mean, California invented the motion picture industry. It created… It invented the entertainment industry. How is it possible that it has been allowed to slip away?

### Scientific Advocate (SA)
Claim: Well, that’s a very simple question. And what Sharon is talking about…

### Moderator
Claim: Lawrence O’Donnell.

### Scientific Advocate (SA)
Claim: …is what in California is referred to as runaway production. A show like The West Wing, for example, was shot on a sound stage at Warner Brothers, and we would go to Washington a couple of times a year and pick up some exteriors. Dick Wolf, who shoots Law and Order—the most successful show on television in terms of longevity and ratings—wanted higher production values than that, he wanted his cameras to be able to go on the streets of New York every day. And where would you suggest shooting The Sopranos. Do you think maybe we should do that on a back lot at Universal, you think we can just get the palm trees out of the way and give you the right feel, by moving The Sopranos out there? What’s happened is the artists involved in this giant industry which is thriving, which has had its biggest box-office year of all time this year, in a recession, the artists are looking for higher production values and opportunities to shoot in places that were never available before. You couldn’t shoot in Prague… 25 years ago if you wanted to.

### Moderator
Claim: Lawrence—

### Scientific Advocate (SA)
Claim: You can now—

### Moderator
Claim: —do—so, you’re basically saying that the migration of the industry has nothing to do with the management of the state. That’s—

### Scientific Advocate (SA)
Claim: It has absolutely nothing to do with the management of the state—

### Conspiracy Advocate (CA)
Claim: That’s absolutely false—

### Scientific Advocate (SA)
Claim: —nothing—

### Conspiracy Advocate (CA)
Claim: —and you know it. The taxes— That’s completely empirically false. Canada, London, 20 percent tax credits, it’s not the artists who make the decisions as you know, Dick Wolf is an exception, he’s not the artist in that case, he’s the executive producer. But it’s the producers and it’s the people who sign the checks who decide where these jobs go.

### Moderator
Claim: I’m declaring—I’m declaring impasse on the Hollywood question—

### Scientific Advocate (SA)
Claim: What you’re advocating is a tax hike—

### Moderator
Claim: I’d like to go to another question—

### Scientific Advocate (SA)
Claim: —for movie producers in California—

### Moderator
Claim: To, um… I haven’t come to this side, this gentleman in a blue shirt, sir, you— You have to stand up, thanks.

### Moderator
Claim: Thank you. First of all, I, I think that the dwelling on the word “first” in the “first failed state” is honestly frivolous. I’d like to pose though to Governor Davis, I was a San Francisco for 15 years and, and I arrived…feeling very, very excited about the idea of direct democracy. And it seems like we’re avoiding that topic because in—to my mind, it is the very prevalence of direct democracy that is ruining California and ruining California’s political system. And—

### Moderator
Claim: Can you formulate this as a question.

### Moderator
Claim: How do we fix the direct democracy problem in California—

### Moderator
Claim: Okay—

### Moderator
Claim: —as somebody who was an elected official—

### Moderator
Claim: I think everybody’s nodding on this one, I’d like to go to Andreas and Andreas, in, in 14 seconds—

### Scientific Advocate (SA)
Claim: Well, wait a minute—

### Moderator
Claim: —remind—remind—

### Scientific Advocate (SA)
Claim: question was put to me.

### Moderator
Claim: Was it—?

### Scientific Advocate (SA)
Claim: I feel like—

### Moderator
Claim: Was it—

### Scientific Advocate (SA)
Claim: —Reagan saying Mr. Green, this is my microphone.

### Moderator
Claim: I’m sorry.

### Scientific Advocate (SA)
Claim: I’m answering—

### Moderator
Claim: I—I apologize, Gray Davis, I had a moderator lapse—

### Scientific Advocate (SA)
Claim: And I—I can speak—

### Moderator
Claim: I just want to ask you—

### Scientific Advocate (SA)
Claim: —with authority on direct democracy because I am a victim of it as well as a—

### Moderator
Claim: Can you—Governor, can you…can you take 10 seconds for the people who missed civics class that day… 10 seconds—

### Scientific Advocate (SA)
Claim: I can’t answer in—

### Moderator
Claim: —to remind us of what direct democracy involved—

### Scientific Advocate (SA)
Claim: Direct democracy in California basically means that, all issues get to the voters sooner or later, and if they don’t get to them sooner the voters put an initiative on the ballot and take matters into their own hands. And basically, everything of consequence gets decided by the voters. And I think they make basically good decisions, I won an awful lot of elections, I lost my last election. But that doesn’t mean, people didn’t have a reason to want to change. What it does mean, however, is they have the power, and I would suggest, in our system of special interests, the only people who have the power to improve things in Sacramento. They’ve already improved them, by changing the way legislators draw—legislators will never— no longer draw the districts, that means they will lose if they’re unresponsive going forward. They can improve them further, with the passage of the open primary, which I assure you, the Republican party will oppose, the Democratic party will oppose, which oughta tell you how you should vote. And on all major issues like the constitutional convention, the vote in November will just be to go out and come back to us with recommendations. We don’t like the recommendations we will vote them down. But we know the legislature, Republicans won’t allow taxes to increase, Democrats won’t allow cuts in major programs—they are immobilized, they can’t solve the problem, the only people who can solve the problem are the voters, who will I predict with the open primary, have already with reapportionment, and will I believe, give voters the opportunity to come back to us with recommendations, hopefully to get away—get away with things like the two-thirds requirement to pass the budget. But if they don’t come back with good ideas, then the voters will knock it down, so—

### Moderator
Claim: Andreas—

### Scientific Advocate (SA)
Claim: —direct democracy can be a problem, but it also can be a saving grace.

### Moderator
Claim: Andreas Kluth.

### Conspiracy Advocate (CA)
Claim: First of all I have to say I agree exactly with you, you’ve—because you lived there and because you came from outside as I did you saw that direct democracy is a large part of the problem. Part of it is confusion over the word democracy, James Madison didn’t want it even used in the constitution of the country, because he was afraid—they had studied ancient Athens which was a failure because of direct democracy. They had studied Republican Rome, which was very stable, they wanted Rome, not Athens. Fast forward to a century ago, the Progressive era. Californians and other western states introduced direct democracy because they were afraid of corruption by the Southern Pacific Railroad of the young state California, they wanted direct democracies, voter directly passing legislation, as a safeguard, as a fourth branch of government to be used sparingly as in Switzerland which was their model. Fast forward again to Prop 13, and onward, and you have a circus, earlier I said, an asylum that is run by the inmates. Never mind the attack ads, the demagoguery… Here is the word count of the longest initiative, 15,633 words. That’s—it is, there was a, I remember driving in the car when several propositions were decided last year. An English teacher called in and said she’s not able to understand the initiatives in the ballot on grounds of syntax. That’s number one, people vote for double negatives when they think they’re voting for the triple negative. There is, it is in California…this is not a statement against representative democracy as the founding fathers of the nation said. I’m—this is a statement against direct democracy as practiced in California, where the legislature is hobbled, because it cannot amend initiatives, and it is unique in that respect. In California it is the least informed way of making decisions. Other people have said tonight, it is curious how often the tough-on-crime voters vote for longer prison terms but forget the taxes to pay for larger prisons. Vote for faster trains, for smaller school classes, for all these things and somehow forget, not only to vote for the taxes, but then also vote for Prop. 13 so that they can’t even be raised.

### Scientific Advocate (SA)
Claim: Taxes can be raised in California—

### Moderator
Claim: Lawrence O’Donnell—

### Scientific Advocate (SA)
Claim: —property taxes are the only taxes affected by Proposition 13 and what it tells you is how much they can be raised. When Proposition 13 came along and said you know what, you’re sitting here, you’re living in your house, you might be on a fixed income, your house may have gone up in value dramatically over the years while you’re sitting in—living on that fixed income. And now we cannot just come in and raise your property taxes 25 percent next year, they put a limit in how much you could raise them. Proposition 13 allows them to be raised, and the income tax, is sitting there, ready to be legislated at any time and the income tax is the fair way to fund government because it is based on your ability to pay. Property taxes are not based on your ability to pay, and California does make a mistake in not raising its income taxes and making them more progressive, raising top- end income taxes significantly, because, those income taxes are deductible on federal income tax returns which means at the top rate, 50 percent of that money is actually being pulled out of what the federal government would’ve taken for taxation. And you can, through a higher top-end income tax in California rebalance this relationship to the federal government’s take on California’s wealth. Taxes can be raised—

### Moderator
Claim: Okay—

### Scientific Advocate (SA)
Claim: —they’ve never passed a bill saying taxes—

### Moderator
Claim: Bobby—

### Scientific Advocate (SA)
Claim: —cannot be raised—

### Moderator
Claim: —Bobby Shriver to respond.

### Conspiracy Advocate (CA)
Claim: I just want to make one small quibble, actually it’s a large quibble with Gray which is—he used the phrase, “Voters put these initiatives on the ballot.” The real harsh truth I’m afraid is that voters do not put the initiatives on the ballot. There’s an—in fact a huge industry, which are in effect sort of semi-private legislatures… You really have to think about that. There are people who are very well-financed, may not even live in California, who can hire teams of people, which is a business, a big business, to write legislation for the state. They’ve had every conceivable, you all probably know, ridiculous things that have been put on and defeated. And some ridiculous things have been passed because people as Andreas was saying, can’t figure out the syntax, I’m a lawyer, and I can’t figure out some of them, the book that comes to you when you vote is that big, and you’re expected to read in very fine print those documents. And the correlative to this idea is the deprofessionalization honestly of the legislature itself which is to some extent the function of the term limits law which is going to be extended—

### Conspiracy Advocate (CA)
Claim: Passed by initiative.

### Conspiracy Advocate (CA)
Claim: Indeed. But the point there is that you have these permanent, semi-private, or entirely private groups of people, whose business it is every year, to make law for the state, who—

### Moderator
Claim: So are you making the argument—

### Conspiracy Advocate (CA)
Claim: No, and I want to say a second thing now that I hear Van’s dulcet tones. We’re— Switching gears a little bit to the—

### Scientific Advocate (SA)
Claim: I’m just shocked to hear a California—

### Conspiracy Advocate (CA)
Claim: —it—I just want to say that, what is the state, and I thank you for saying that the “first” point is a frivolous point which I entirely agree with. What is a state if it’s not the creator of the vision of the state. When Van says we’re having a crisis, I—to me, I was ready to get up and walk because we win.

### Scientific Advocate (SA)
Claim: No, no, no.

### Conspiracy Advocate (CA)
Claim: If there’s a crisis, that requires—

### Conspiracy Advocate (CA)
Claim: —a constitutional—

### Scientific Advocate (SA)
Claim: —resolve the crisis—

### Conspiracy Advocate (CA)
Claim: —a vision we have not yet agreed what the state of California is, that’s a—that’s the ultimate political failure. Because—and that’s why a constitutional convention probably will pass and that’s why— I mean, here’s the thing, that I always loved, was in the Declaration of Independence, not a constitutional convention but an important document nonetheless. Everybody knows the first sentence. Right? “All men are created equal,” very few people remember the last sentence, which is, “To these truths we mutually pledge our lives, our fortunes and our sacred honor”—

### Scientific Advocate (SA)
Claim: And our sacred honor.

### Conspiracy Advocate (CA)
Claim: That’s the last sentence. And I defy you, today, to get— And the people who signed it, George Washington, richest guy in the country. Thomas Jefferson—

### Moderator
Claim: Let’s, let’s bring in Van—

### Conspiracy Advocate (CA)
Claim: No—I’m just saying, I want to finish— Can you get the citizens of California to sign a pledge—

### Moderator
Claim: Bobby, let’s hear from the—let’s bring in the other side—

### Conspiracy Advocate (CA)
Claim: —today, to lives and fortunes, Lawrence maybe would sign it—

### Moderator
Claim: Gray Davis—

### Scientific Advocate (SA)
Claim: My good friend Bobby who I appointed to the Parks Commission before his relative, kicked him off the Parks Commission—

### Conspiracy Advocate (CA)
Claim: And my relative fired me.

### Scientific Advocate (SA)
Claim: Bobby, I want you to know that—

### Conspiracy Advocate (CA)
Claim: Thankfully he also fired Clint Eastwood on the same day—

### Scientific Advocate (SA)
Claim: —the entire— The entire…

### Conspiracy Advocate (CA)
Claim: It’s true.

### Scientific Advocate (SA)
Claim: …group in favor of this proposition—

### Conspiracy Advocate (CA)
Claim: And Governor Davis did in fact appoint me, thank you—

### Scientific Advocate (SA)
Claim: The entire group on my right in favor of this proposition all lives in Bobby Shriver’s district, so… Little cabal over there… I want to make two points. The constitutional convention is proposed by the Bay Area Business Council.

### Scientific Advocate (SA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: Apple. Google. Hewlett-Packard. Facebook. Because they think, Sacramento is not acting properly. And to get the constitutional convention on the ballot, they have to get the signature of several hundred thousand Californians. So people do put initiatives on the ballot. Now is it a perfect system, no, and do we have a lot of shysters out there, misrepresenting what’s on the ballot, absolutely. My, one of my…a sister of a dear friend of mine signed the recall petition against me. And I said how could that be and she said because—

### Conspiracy Advocate (CA)
Claim: She voting here tonight?

### Scientific Advocate (SA)
Claim: --signature gatherer said oh, this is good for teenagers, this is good for teenagers. So, you know, there are flaws in the system. But people do put the initiatives on the ballot, people will solve the problem through the open primary and the constitutional convention, and I have great faith that Van will wisely use the remainder of our time.

### Scientific Advocate (SA)
Claim: Well, I just wanted to point out this is classic California. Here you have the people who are saying, the ballot initiative is terrible, it’s awful, we’ve gotta get rid of it. So we’re going to use the ballot initiative to get the constitutional convention that we want. That’s exactly the beauty of the system that we have. Is that we, in California we have big problems but we also have big tools to solve those problems. And, I would, I’m shocked to hear—

### Conspiracy Advocate (CA)
Claim: Are you, are you really defending the—

### Scientific Advocate (SA)
Claim: Yes—

### Conspiracy Advocate (CA)
Claim: —the legislative system—

### Scientific Advocate (SA)
Claim: I—first of all, first of all—

### Conspiracy Advocate (CA)
Claim: —the—and the initiative system, really—

### Scientific Advocate (SA)
Claim: I’m shocked to hear a California politician arguing publicly that the people of California should give up their ability to participate in California’s governance which is basically what you’re saying. We—

### Conspiracy Advocate (CA)
Claim: Not exactly but go ahead—

### Scientific Advocate (SA)
Claim: — so—

### Conspiracy Advocate (CA)
Claim: Sophistry.

### Conspiracy Advocate (CA)
Claim: Not exactly but go ahead—

### Scientific Advocate (SA)
Claim: I would be happy and I think most of us here would be happy to see some curtailment of some of the abuses of the initiative process but I think, in California we should be proud. You say that people are ill-informed, et cetera, well that’s true about, you know, people going into the malls and making purchases. There’s no such thing as perfect information, but in California, every time we have one of these moments, people know their voice will matter, they will get a chance to vote directly on some of these issues, and we could not solve the problems that you’re describing, without the best thinking of all the people in California—

### Moderator
Claim: Let me go to another—

### Conspiracy Advocate (CA)
Claim: not an impasse—

### Moderator
Claim: —let me get—

### Conspiracy Advocate (CA)
Claim: —can I just, I have to say one little thing.

### Moderator
Claim: It’s gotta be really, really little—

### Conspiracy Advocate (CA)
Claim: I—it’s really— I didn’t say the people were ill-informed. I said I…am ill-informed. I can’t read. I went to Yale Law School with you. I can’t read… The thing that comes in my post office box, I’m ill-informed. So—

### Scientific Advocate (SA)
Claim: I want to stipulate that this side of the panel agrees with Bobby’s last statement.

### Conspiracy Advocate (CA)
Claim: We rehearsed that, we rehearsed that.

### Moderator
Claim: I want to go to another que—also I want to point out that Lawrence O’Donnell’s tactic of playing with the word “first” has been tried here before, we had a debate on whether George W. Bush was the worst President of the last 50 years, here in New York City. Karl Rove spent the whole night talking about Jimmy Carter. And he won the debate. So whether it works tonight is up to you, one more question, just down, this gentleman, yeah, with the laser.

### Moderator
Claim: I’d just like to ask both of you whether you think California will go bankrupt. And if it does go bankrupt does that mean it’s a failed state.

### Moderator
Claim: Great question.

### Scientific Advocate (SA)
Claim: I’ll answer that—

### Moderator
Claim: Gray Davis.

### Scientific Advocate (SA)
Claim: I can say with no fear of contradiction that it won’t, because, it can’t. It can’t legally go bankrupt but more importantly… It’s technically true. More importantly— it’ll work its way out of these problems and if you’re thinking of buying a California bond, I can assure you that the legislators understand the importance of lending to get them through these tough times. Bonds come not after schools, the first dollar goes to schools, that comes in the door, the second dollar goes to pay GO bonds, the third dollar’s the school, the fourth dollar— So as long as we have about 60 cents on the dollar in Sacramento we probably have about 85 to 95 percent extension now. Your bonds are in good hands. Buy California bonds.

### Moderator
Claim: Andreas Kluth.

### Scientific Advocate (SA)
Claim: Vote no in the proposition.

### Conspiracy Advocate (CA)
Claim: He just made a—

### Conspiracy Advocate (CA)
Claim: I hope he’s covered for his investment advice.

### Moderator
Claim: Andreas—

### Conspiracy Advocate (CA)
Claim: You just heard a great answer if you were wondering whether you should buy municipal bonds in California then you might.

Remember—because, it’s true, technically, legally a state cannot go bankrupt. The order of payments is indeed correct. Remember that California has the worst credit rating of the 50 states…that is a superlative. It has just been lowered to one notch above junk, by the time this debate is over it probably is junk, so— Even in the order of payments that you’ve just heard which was correct, it may indeed go, you know, the bonds may indeed default, which we don’t even need to prove, to carry our motion.

### Moderator
Claim: Well, Dana—I just—I want to—Dana, do we have time for one more? Okay, I’d like to get to one more question with your indulgence be—just to hear from the people. Anybody high, I…arbitrary left side, right side, right here, sure. Thank you.

### Moderator
Claim: I’d like to get the panel to focus on the task at hand and I think the task at hand is ours. We are being asked to cast a one-word answer, a vote, to a six-word question. And the six-word question is, “California is the First Failed State” and I’d like to focus the panel on the word “is.” Are we being asked to decide whether California at eight p.m. on January 19th, 2010, is failed, now, or are we being asked to cast a vote on whether you think, the proposition is that California is now and will be irredeemably or for some time to come, a failure—

### Moderator
Claim: Sir, can I just ask you to do something because this’ll be broadcast in different times and different places and rather than say, at eight p.m., would you mind just restating, the—in a very short way— And I might suggest you could say right now at this moment as we stand here, or something along that—

### Scientific Advocate (SA)
Claim: You’re in show business now.

### Conspiracy Advocate (CA)
Claim: You’re in show business.

### Moderator
Claim: Let me do another take—

### Conspiracy Advocate (CA)
Claim: show business.

### Moderator
Claim: Everybody’s a director. Right now as we stand here. Do—should I just say that, or do you want to repeat the whole thing—

### Moderator
Claim: You know what? I give up, let’s go to the question. Which side would like to take this first, Lawrence O’Donnell—

### Scientific Advocate (SA)
Claim: Well, I just want to check up here where it was determined that concentrating on the word “first” is frivolous. What’d you make of that one.

### Moderator
Claim: It depends on what the meaning of “is” is.

### Conspiracy Advocate (CA)
Claim: No, I think, I— Not at all, I—

### Moderator
Claim: Sharon Waxman—

### Conspiracy Advocate (CA)
Claim: We’re clearly saying, from a position of people who live in California, who believe in California, who’ve spent—who have decided to spend our lives there, that California is currently a failed state, it makes me very sad to hear the other side of the panel…giving, paying truly lip service to the notion that yeah, it has some problems. Talk—that’s about the understatement of this century, this early part of the century or the new decade. If you live in California and you read the news every day, it is a litany of failures, rogue laws, gridlocks, budget… Pick your billion, 20 billion this week, 30 billion last— three—six months ago, whatever the hole is that has to be filled, the latest service to be cut, the latest milk and cookies that will not be served. It is— this is the lives of the people of the state of California, it’s not a joke. It’s not, how bad is New York or how bad is Arkansas. It is—this is where we are spending our lives, and for us to be arguing this, it is because we believe that California does hold the promise of being the greatest state in the nation, not because we believe it is irredeemably failed and cannot be saved. But to hear people who are in our government, on the other side of, of the panel, suggesting that it’s all cheer, cheery and roses, is very disheartening I have to say for me as a resident of the state, the state is stuck. And it is not working, and if you live there, and if you pay attention at all, you have to know that.

### Scientific Advocate (SA)
Claim: I’d like to respond to that—

### Moderator
Claim: Gray Davis.

### Scientific Advocate (SA)
Claim: I have a lot of respect for Sharon.

### Conspiracy Advocate (CA)
Claim: You do?

### Scientific Advocate (SA)
Claim: But I want to— But I’m—

### Conspiracy Advocate (CA)
Claim: I’m so touched—

### Scientific Advocate (SA)
Claim: —I’m married to one out there, with me, Sharon Davis, but, Sharon Waxman, but…you are the reason— I have a lot of respect for Sharon Davis. And a lotta love for Sharon Davis.

### Scientific Advocate (SA)
Claim: As do we all.

### Conspiracy Advocate (CA)
Claim: But you’ll still vote for our side—

### Scientific Advocate (SA)
Claim: But here’s the point. I think you can see it in your first sentence. We live in California. We believe in California. We know it will solve its problems and get better. From 1998 to 2008, according to The Wall Street Journal two days ago, California’s economic growth was 25 percent, the rest—the national average was 16 percent, that’s real after inflation adjustments. Everywhere you look, people are doing their best to make this world a better place in California, and they’re doing it in other states as well. We are doing the best we can, in a very difficult time. I’m sure Sharon has noticed that there’s a national recession. We have 10 percent unemployment, there are problems all over America. We are bigger than other states and the problems sometimes are bigger in California. But they’re not too big for us to solve, and along the way, we are contributing enormous productivity and innovation to America. And I suggest to you, as we get more global, we’re going to rely more and more on states that can innovate. Because you can’t out-source an idea, until someone invents it.

## Round 3

### Moderator
Claim: And that concludes Round 2 of our debate. And here’s where we are, we are now about to go into Round 3 where we will hear brief statements, closing statements from each of the debaters in turn. They’ll be two minutes each. And this is their last chance to change your minds before you vote again. From the live audience vote beforehand, we know where you stood before the debate began, here again are the results, the results before the debate on the motion, “California is the First Failed State,” 31 percent of you agreed with the motion, you were for it, 25 percent were against it, and 44 percent were undecided, you’ll be asked to vote again in a short, few minutes from now, but, on to Round 3, closing statements from each of the debaters in turn and speaking first, against the motion, Lawrence O’Donnell, senior political analyst for MSNBC and former Democratic Chief of Staff of the US Senate Committee on Finance.

### Scientific Advocate (SA)
Claim: First failed state—

### Moderator
Claim: Oh, Lawrence, you can—the—we sit on all of these.

### Scientific Advocate (SA)
Claim: Okay, sorry—

### Moderator
Claim: Sure, no problem.

### Scientific Advocate (SA)
Claim: I thought…I’m sorry, I’m from the state where words matter. Same with you. So some people have doubts about what does “is” mean, that’s a familiar question. Some people have doubts that “first” should be in here which is to say, it’s allowable then if we drop “first” that there are other states doing things much worse than the California government is doing things. In the fiscal years that cover this current recession, 2009 through the 2010 fiscal years, states have faced $256 billion in budget gaps…nationwide, $256 billion. They’ve solved $73.1 billion of those budget gaps so far. They have a lot of work to do to close those gaps, this is one of those states, where we sit right now. Now, California, in its riches, just like New York in its riches, has been generous. It has a Medicaid formula that is more generous than other states. If you’re on Medicaid in California you get more benefits at a higher level of income, the high—the income cutoff is a higher level than in these other states. And so if you want to say to Alabama, go ahead, Alabama, keep it up… Keep it up, don’t let people have Medicaid—or if they make as much as $15,000 a year for a family of four, don’t let them have it. If you want to vote that way, and say, I’m going to penalize the state that has tried and in its trying, has to struggle then in this anti-tax environment in this country of raising the money to pay for what it has promised, and then ends up in this very difficult fight every year about how do we balance this budget that doesn’t seem to be balanceable— which is exactly what happens in this state every year, exactly what happens. If you want to penalize those governments, those liberal governments over generations of liberal advance in social programs, for overfunding health care for the poor if you want to call it that, because now it has to be cut back, or overfunding public education because now it has to be cut back under these burdens that they face today, then go ahead. Penalize those states. Declare here tonight, that Alabama has done a better job than California—

Okay, sorry—

First failed state—

### Moderator
Claim: Lawrence O’Donnell, your time is up, thank you very much. Our motion, “California is the First Failed State,” summarizing his position in favor of this motion, The Economist’s West Coast correspondent, Andreas Kluth.

### Conspiracy Advocate (CA)
Claim: I don’t want to summarize it because, I don’t think I need to, I want to say thank you to you, sir, for focusing our, our attention again on the proposition that you’re now deciding in this binary way, “California is the First Failed State,” you wanted me to focus on “is” and “first.” California is the first failed—failed state means simply that tonight as we speak it is a failure. It does not mean that, five years from now, it cannot have made a fresh start. In fact, the most important prerequisite for making a fresh start and insuring, just as it came up earlier-- in Pat Brown’s day, California was not a failure, today it is. Things can change, however, you have to take a a vital step first. You have to admit that something has failed for you to change it. This is sort of a microcosm of two organizations in California, one called California Forward, one called Repair California. The names will tell you nothing what they stand for, one wants to deny that the failure is fundamental and wants to fiddle, wants to fiddle here, fiddle there, muddle along, and hope that it’ll get better, the other is Repair California which is the organization now pushing the initiatives for the constitutional convention. They want you to say that the failure is fundamental, and therefore we need a new constitution because ours is unmanageably complex, with 500 amendments…in half the time that it took America’s constitution to have 27 amendments, all because of initiatives. The people of California will pass those initiatives calling for a constitutional convention…in any poll, opinion poll that you may now read. And that is because the people of California take it for granted, they just assume, there is a consensus that the failure is as of today, in fact there, that California has failed, and that we must start fresh with a new constitution, to prevent it, finally, “first” simply means, the other states, the other 49 have to watch out so they don’t repeat our mistakes.

### Moderator
Claim: Thank you, Andreas Kluth. Making his summarizing statement against the motion that “California is the First Failed State,” Van Jones, former White House Special Advisor for Green Jobs and co-founder of the Ella Baker Center for Human Rights and Green for All.

### Scientific Advocate (SA)
Claim: Well, first of all I just want to say, I do think that the question is properly stated about the present moment. I want to say that, it’s been posed that if you don’t believe that we are in …sub… collapse, that we don’t care about the people who are suffering in California, that’s not true. People are suffering in California right now. There are people who are suffering in prisons, way too many people, we’re spending way too much money, they have way too little hope and way too little help when they get out. But, I also know that we have great ideas, we have people throughout the state of California moving restorative justice ideas to fix that. Even the governor now says maybe we should make it unconstitutional to spend so much money on prisons, more than we spend on our four-year colleges and universities. When you are looking at how you evaluate any situation in your own life, you look at your problems, you look at your deficits, but you also look at your assets. And as long as you are breathing, as long as you have the ability to confront your problems, you’re not a failure. And, I’m going to say, anybody in this room going through anything, you’re not a failure, until you quit. People in California have not quit, we are moving forward, we are coming together in ways that are extraordinary, and we will solve these problems. And I ask you to vote to support us, to encourage us and say, that we’re not failures, you’re not failures, this country is not a failure, we have problems that we have to solve and we will solve them together.

### Moderator
Claim: Thank you, Van Jones. Making her summarizing statement for our motion, “California is the First Failed State,” Sharon Waxman, editor-in-chief of The Wrap.com, an entertainment and media business news source.

### Conspiracy Advocate (CA)
Claim: Well, I believe the other side has actually made our point this evening. They’ve said that California is full of innovative people, it’s full of ideas, its culture is rich, that invention is still vibrant in the state and the lifestyle is beautiful. All of that is true and that’s why we all choose to live there. But all of that is despite the fact that the state has failed. And it’s not bec—and we stay there for all those reasons because, we continue to push forward, but not because the state lends a hand, plays its role in providing education, transportation, security, a prison system, a medical system, the things that are the state. That is what we’re here to talk about tonight, it is a very serious matter for those of us who live and who have engaged our lives in the state. And to hear Van say that we are coming together in ways that are extraordinary, it sounds really lovely, I have no idea what that means. We’re not coming together, and there’s nothing extraordinary about what’s happening to California as a state except extraordinarily bad, I’m sad to say. So I ask you all to vote for this proposition as a gesture, of not only that we have proved the case, but as a gesture of helping take the step of consciousness, and of moving California toward the right future, which is not the path that it’s on.

### Moderator
Claim: Thank you, Sharon Waxman. The motion is, “California is the First Failed State,” and summarizing his position against the motion, Gray Davis, the 37th governor of California, also served as Lieutenant Governor, State Controller, and State Assemblyman.

### Scientific Advocate (SA)
Claim: I want you to vote against the proposition, because the proposition is what it purports to be, California…supposedly is the first failed state. By any measure, we are more generous than virtually any other state, I was proud to provide health care to 900,000 youngsters that didn’t have it when I became governor. Occasionally there’s talk that maybe we have to reduce that by a little bit. I don’t like it, but we’re living in tough times. As Mr. O’Donnell said, we’re more generous in our Calworks program, we have our own separate welfare program to tag onto what the federal government does. We’re more generous on our health care programs, we supplement what the federal government does. So sometimes in tough times, we’re not able to do all the things we would like to do. But we’re not sitting around moaning and groaning. We’re solving our problems, the people are taking matters into their own hands, I’m confident that they will adopt an open primary, I’m confident that they will give voters the chance to go out and make recommendations to change…what’s happening…because of the shortcomings of 121 people in Sacramento. But I just want to assure you that you’re going to be in very good company if you vote no, Time magazine would have you vote no. Wall Street Journal two days ago said, California, failed state, it’s such a big subsidizer of the other states that are in trouble in this country, it oughta secede. Now I don’t want us to secede because I don’t think we’re in great shape today. But we’re on our way to being in great shape again, and we’re going to be a very important part of America, going forward in our global economy. So I would ask you to look at the proposition and say to yourself, California’s doing a lot of things better than most other states, I’m not going to say it is the first failed state in America. Please vote no, which I think is number 2 on your list.

### Moderator
Claim: Very good, Gray Davis, thank you. Our final speaker, summarizing for the motion that “California is the First Failed State,” Bobby Shriver, Santa Monica city councilman, and co-founder of One.org and Red.

### Conspiracy Advocate (CA)
Claim: Thank you. I also appreciated the “is” question. Because, and I appreciate also Sharon’s seriousness about this matter, I mean we’ve had a little fun, which is great. But the truth is tonight, at this moment, people are suffering in really unimaginable ways, and this is a pretty wealthy crowd, a powerful crowd, we’re here in New York, it’s all good. The people that the government and the sense of political compassion is created to serve are really, really bad in California. Calworks that Gray mentioned’s about to be defunded entirely. The reason that we have a lot of homeless in people is not because LA is big as Lawrence suggested. It’s because the policies of the state, don’t work. Mental health financing is with the county, housing is with the city. They don’t work together, they haven’t worked. There’s been no progress made, enormous progress has actually been made in New York, on homelessness. Despite what other things New York hasn’t done well. I want to reiterate, we’re the optimistic people, we’re not moaning and groaning. We’re not, oh, woe is us, California doesn’t have a lot of brilliant people, a lot of venture capital, a lot of cool companies, we acknowledge all that. We’re not talking about that, we’re talking about the state which is a revenue-collection mechanism. It disperses money to people, to do things that the community wants done. If that isn’t happening, the state, not the people, not our energy, not our optimism, not our tools, none of that, is relevant. It’s a revenue- collection thing based on principles. We are not collecting and distributing the revenue to the most vulnerable people in the state today by an immense margin. The suffering…here, is immense. And that’s why you have to vote, to give a wake-up call, to the people who hold the power in the state and the people of California, so that they can feel comfortable to say you know what, we’re optimistic, we’re going to get it done, but we got a problem.

### Moderator
Claim: Thank you, Bobby Shriver, and that concludes Round 3 of our debate. And now it’s time to find out who our winners are, you in the audience will choose our winners, I’m going to ask you to go again to the keypad on the right arm of your seat, at each seat you will register your vote. And we will get the read-out instantaneously, practically. Vote number 1 if you are for—our motion is “California is the First Failed State,” vote number 1, push number 1 if you are for the motion. Push number 2 if you are against the motion, and number 3 if you remain undecided—

### Scientific Advocate (SA)
Claim: We’d like ‘em all to stand, because they’re New Yorkers. New Yorkers, they get to vote.

### Moderator
Claim: You know, I just want to thank this panel for the level of game they brought to this debate, they really put the intelligence in Intelligence Squared. It was really excellent. And also you in the audience, your questions were excellent tonight. But before I announce the results of the vote which I’ll have in just a minute, a few things to take care of, our next debate will be on Tuesday, February 9th, our motion is, “The US Should Step Back from its Special Relationship with Israel.” Panelists for the motion are New York Times columnist Roger Cohen and Columbia University professor Rashid Khalidi, against the motion are Ambassador Stuart Eisenstadt who served under both Presidents Carter and Clinton, and Israel’s former ambassador to the US, Itamar Rabinovich. Individual tickets are still available for that one by visiting our website and also at the Skirball box office outside. And you can follow, join, become a fan of Intelligence Squared on Facebook and by doing so receive a discount, on our upcoming debates. All of our debates as you know because we’ve talked about it tonight can be heard on NPR stations, now on more than 200 stations across the nation. I guess they’re going to have to edit around that dating thing that you did, but they can work. You can also watch the spring debates on the Bloomberg Television Network, airdates and times can be found in your program. And also don’t forget to read about tonight’s debate in next week’s edition of Newsweek, and there are copies in the library that you can pick up on your way out. So, now the results are in, they’ve just been handed to me, and remember the team that changes the most minds is the team that is declared the winner. Now our motion is, “California is the First Failed State,” when you voted before the debate, 31 percent of you were for the motion, 25 percent against, and 44 percent undecided. After the debate, 58 percent are for the motion, 37 percent against, and 5 percent undecided. The team for the motion, wins our debate, thank you very much to all of our panelists, to you in our audience, from me, John Donvan, thank you from Intelligence Squared US.
