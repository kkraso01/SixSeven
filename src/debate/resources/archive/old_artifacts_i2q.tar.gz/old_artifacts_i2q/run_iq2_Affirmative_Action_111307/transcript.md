# Debate Transcript

Topic: It's Time to End Affirmative Action
Motion: It's Time to End Affirmative Action

Debate ID: Affirmative-Action-111307


## Round 1

### Moderator
Claim: Right now, I’d like to introduce the, uh, chairman of the Rosenkranz Foundation, which is the sponsor of Intelligence Squared, Robert Rosenkranz, who will frame tonight’s debate.

### Moderator
Claim: Thank you, Robert, and, uh, welcome back. Uh, on my behalf and on behalf of Dana Wolfe our executive producer it’s a pleasure to welcome you. Well, our debate tonight is, in our minds anyway in the context of admissions to our elite universities and graduate schools: Is it time to end affirmative action? Our topic tonight seems on the face of it ideological. Uh, liberals feel it’s—affirmative action is needed to, uh, create opportunities for blacks and Hispanics and to meet a societal need, uh, for racial diversity in the universities, and in leadership positions thereafter. Conservatives believe that color-blindness is a bedrock Constitutional principle. We see the issue as more nuanced. Let me focus exclusively on what might be considered conservative ideas to— to show why. The conservative case against affirmative action includes these elements. First, affirmative action is a euphemism for admitting blacks and Hispanics to selective universities, despite wide gaps in SAT scores and grades. Discriminating on the basis of race is inherently unfair and offensive, particularly when it’s done by governments. The beneficiaries of affirmative action are not the truly disadvantaged, they are mostly middle-class. The legal framework around affirmative action offers no coherent rationale, and no clear guidelines to acceptable conduct. So, that’s the, uh, the conservative case. But there’s a conservative case for affirmative action as well. And it’s grounded in the ideas of free association, choice, and competition. Our elite universities compete with one another vigorously, for students, for faculty, for contributions, research funds, and most fundamentally, for the prestige and influence of producing future leaders. Their mission is not fulfilled simply by admitting candidates with the highest grades. Instead they routinely favor athletes, creative artists, students from poor families and unusual geographies, black and Hispanic applicants, as well as children of generous alumni. They must recognize that overweighting these elements in their portfolio of admitted students, underweights other elements, and most obviously Asian students with a predilection for the sciences. So either the portfolio of admitted students is optimal, or, competition with—among universities will correct it. Politicians or courts or voters for that matter, have little useful to contribute. So our debate tonight is, it’s time to end affirmative action, and that goes to the merits of the matter. But in listening to the facts and, uh, arguments marshaled by our panelists this evening, you might wanna keep in mind the question, time for whom. I’m delighted to welcome back our moderator Robert Siegel, the long-time National Public Radio host of “All Things Considered,” Robert, the evening is yours.

### Moderator
Claim: Thank you. Thank you, Bob. Thank you, Bob Rosenkranz, and I’d like to welcome you all to the fourth debate of the second Intelligence Squared US series. The resolution being debated tonight is, “It’s time to end affirmative action,” and let me give you a brief rundown of the evening. Uh, members of each team will alternate in presenting their side of the argument, presentations are limited to eight minutes each. Uh, when opening arguments are complete, I’ll open the floor to questions from the audience. Uh, after the question-and-answer session, each debater will make a final two-minute summation, and finally, you will vote on tonight’s motion with the keypad that’s attached to the armrest of your seat and I’ll announce your decision on what side carried the day after the debate, but we’ll start with a pre-debate vote. Uh, please pick up the keypad that’s attached to the armrest on your left…looks like this. Uh, and for audience members who are sitting along the aisle, uh, to my right, uh, your keypad is attached to the armrest on your right side next to your neighbor’s. Now again today’s resolution is, “It’s time, uh, to end affirmative action.” After my prompt, uh, press 1 to vote for that motion, 2 to vote against it, and 3 if you are undecided. You may gin voting—you may begin voting rather, now.

Good. And I’ll reveal the results of your pre-debate vote, uh, later in the evening. I’d like now to introduce, uh, the panel, and please, uh, hold your applause or any other reaction until after all six are introduced. Uh, first arguing for the motion, a senior fellow at the Manhattan Institute and columnist for the New York Sun, John McWhorter. The president of the Center for Individual Rights, Terence Pell, and actor, social commentator and syndicated columnist, Joseph Phillips. Uh, and against the motion are, staff attorney for the Asian-American Legal Defense and Education Fund, Khin Mai Aung, professor of law at UCLA and Columbia Law School is Kimberlé Crenshaw, and writer and educator, uh, Tim Wise. I’d like to now, uh, call our debaters, uh, to rise to the podium and to give their, their opening, uh, statements, on the motion, “It’s time to end affirmative action,” eight debater has eight minutes, I’ll give a one-minute warning. Uh, first, Joseph Phillips for the motion.

### Conspiracy Advocate (CA)
Claim: Thanks. Hoo, boy. Feel like I did before my first love scene with Halle Berry, so, you can— imagine, if you have any imagination at all the butterflies, and actually the excitement. Uh, because I’m here in defense of what I think is one of the, uh, cornerstones of our republic, that of non- discrimination. And I think it was articulated in Brown vs. the Board of Education when, decided that discrimination in our public schools was unconstitutional, became part of our cultural lexicon a few years later when Presidents Kennedy and Johnson issued an executive order, that stately clearly and unambiguously, that, affirmative action should be taken to ensure that hiring, uh, decisions were made without regard to race. And then of course it was given teeth in the law, uh, through the Civil Rights Act of 1964, which was very clear, that, uh, discrimination based on race was unlawful. And, uh, to quote, uh…an ‘80s sitcom, uh, it’s a different world from where ya come from. That was then, that was good old-fashioned non- discrimination, and it was good for America. Well times have changed, and what we’re talking about now, affirmative action is no longer about non-discrimination, it’s about racial preferences. And that is what we oppose—racial preferences. Now, that doesn’t mean that we believe that racism has suddenly disappeared. It hasn’t. We know that racism exists. Listen. I’m 45 years old. I’ve been black in America for a long time. I have seen racism, I have been the victim of racism, I’m not about to stand up here and pretend, that it doesn’t exist. But the question before us is not, does racism exist, the question is, are racial preferences an effective means to combat racism. And the answer is simply no. There isn’t any evidence at all, that racial preferences actually benefits us in terms of our race relations, in fact, what evidence there is points to just the opposite. What we do know, is that racial preferences tend to, to en—enhance, and, and firm up negative stereotypes, particularly as it pertains to black intellectual capacity and academic capabilities. Um… You know…there was a saying that my mother had. And I hear it in my head right now. There is no monopoly on brain power. That’s what my mother said all the time, there is no monopoly on brain power, black people can compete, we can compete on the athletic field, we can compete in the symphony halls, and we can compete in the classrooms. And what’s more, my mother said, you can compete, and you will compete. But there are some folks who, sadly, are gonna tell my children something very different. And you don’t have to take my word for it, let’s just look at what they say. Richard Atkinson, former president of the University of California at Berkeley, standing before an audience similar to this, at University of San Diego, said that it was highly doubtful if not impossible that we would achieve diversity on our nation’s premiere campuses without the use of racial preferences. Now Atkinson was not standing before a curious world, telling everybody he’s just a big fat racist, and unless you rein me in I’m gonna start discriminating right and left! No. What he was saying is that there is a monopoly on brain power, and that black students don’t have it in sufficient quantity to show up in significant numbers in our nation’s campuses. Now if you’re not sufficiently…offended, as you should be, let’s take something else that you often hear in discussions like this. Someone, maybe here or over here, is bound to stand up and say whoa! I benefited from affirmative action. You benefited from affirmative action, she benefited from affirmative action. And of course, they’re not saying, well, you benefited from non-discrimination. Well I did and that’s a good thing. What they’re saying is, I couldn’t qualify, you couldn’t qualify, she couldn’t qualify… Absurd. Miss Krimberle Crenshaw there. I’ve met her for the first time, I’ve read what she’s written, I’ve heard her on the radio, this is a smart, dynamic woman. The idea, that but for racial preferences, Miss Crenshaw would be standing on the corner singing doo wop someplace is offensive to me, and it should be offensive to all in the sound of my voice. Now, you’re gonna hear a lotta statistics today, I’m not gonna talk to you about statistics. I’m gonna talk to you about people, because racial preferences impact and affect people. This past April, spring, my wife was at a birthday party with our, with our children. And…the mothers are sitting there talking, the fathers in there, you know, that, you tend to avoid these things like the plague so I wasn’t there. Uh…but the mothers are grouped and they’re talking about their children, where they go to school and it comes to light, that my oldest boy attends a magnet program, uh, for highly gifted students. Without missing a beat…one of the other mothers says, well, you know, now, with this Supreme Court decision they won’t be able to accept, uh, kids in these programs for diversity. Well, my wife was kinder than I would have been. After she picked her jaw up off the floor she explained to the woman, look. He’s not in this program because he checked some box. You can’t get in this program unless you score 99.9 percent on the test. Let me repeat that—99.9 percent on the test. And, he’s making straight A’s. In this program. And what is more ironic, is that the woman she was talking to, is a teacher in the Los Angeles Unified School District. That…is the evil of racial preferences. That, is the real-life impact of racial preferences. Teachers, who lack faith in the academic abilities of their students, and children, who no matter how hard they work, no matter how…how broad their gifts… are stained with preference. With, uh, uh, uh, uh, uh, benefi—fishi—fishishence. That’s Greek.

And my child is not the only one, there are thousands, and thousands of students just like him, who cannot enter our nation’s college campuses boldly and confidently. They enter, again, dripping with the stigma of racial preferences. And I’m here to tell you tonight, that that is not good for America. Thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: And my child is not the only one, there are thousands, and thousands of students just like him, who cannot enter our nation’s college campuses boldly and confidently. They enter, again, dripping with the stigma of racial preferences. And I’m here to tell you tonight, that that is not good for America. Thank you.

### Moderator
Claim: Thank you, uh, Joseph Phillips, speaking in favor of the motion. Uh, now, to make an opening statement against the motion, “It’s time to end affirmative action,” Tim Wise.

### Scientific Advocate (SA)
Claim: Thank you. You know, it always amazes me, to hear critics of affirmative action speak about this subject, as if racial preference were something that were invented in the ‘60s, to benefit people of color. Because in fact whether we wish to acknowledge it or not and of course we don’t, the entire history of this country is the history of affirmative action for white folks like myself. And unless we begin by discussing that affirmative action, and the impact that it has had we engage in a discussion that is both ethically and practically irresponsible. Contrary to what Joseph tells you this debate is about the extent to which racism still exists because it in— is indeed the existence of that racism which necessitated affirmative action in the beginning, and continues to necessitate it today. Whether we wish to acknowledge it or not, enslavement, Indian genocide, segregation, did not only oppress people of color, they elevated white folks, and provided us with opportunities that we did not in fact earn. The Homestead Act allowed whites to claim over 270 million acres of land for virtually nothing down, at a time when folks of color could not, today there are 40 million white folks descended directly from those, who received that land giveaway, millions of them, still living on the property, they owe their lives to affirmative action. Then there was the FHA home-loan program which for the first 30 years of its existence, operated in a whites- only fashion, lending over $120 billion worth of government- backed housing equity to whites, thereby creating the white middle class. And in large measure because of those preferences, the typical black college couple, college-degreed couple starts out with less than one-fifth the net worth of a typical young white couple because the latter of those, has likely received the benefits of their family’s prior head start while the former, are likely to have accumulated far less having had less chance to do so. So against that backdrop, ending affirmative action would only further cement the systemic advantages for whites that have been in place for hundreds of years, it would be tantamount to favoring those three laps ahead in a five-lap race even though those are ahead gained their head start as the result of an unfair process, but even worse, to end affirmative action would ignore the ongoing reality, not past, but ongoing reality, of white racial preference, and not only in education, but also in employment, and let me clarify, we were not told that our remarks tonight had to focus only on higher education. That resolution doesn’t mention higher education, I will not speak of it only with regard to schools. Because it is not only there that it matters. According to the Office of Federal Contract Compliance, three out of four companies covered by affirmative action regulations violate them regularly, and not just that, but are also in violation of basic civil rights law. The problem is the OFCCP only has enough monitors to check up on the companies under their purview once every 46 years. So there’s no deterrent. But those who would end affirmative action never call for beefing up civil rights enforcement, indeed, though his teammates might not know it, Mr. Pell’s organization advocates abolishing anti- discrimination law altogether, as it regards the private sector, so, Joseph can sing the praises of the 1964 Civil Rights Act, but the man sitting next to him, would get rid of it as it regards private organizations, so to endorse the resolution would only intensify the problem of discrimination, those who would end affirmative action ignore the study, recent study, which found that job applicants with white-sounding names have a 50 percent greater chance of getting a call-back for an interview than those with black-sounding names even when qualifications are indistinguishable. They ignore, not only that, but the research which has found that eight in 10 jobs are never advertised, instead they’re filled by networking, a process that mostly excludes people of color and women of all colors and elevates whites and men not because we are better for certain jobs but because we know the right people, and if affirmative action none of that would change for the better…if anything it would get worse, the same is true for schooling. Our opponents will rail against so-called preferences of students of color while they ignore the preferences built in for whites. So they condemn the University of Michigan for giving 20 points on a 150-point scale to students of color but they ignored the points that were in practice, essentially for whites only. Like the 16 points you got, if you were from the Upper Peninsula of Michigan. The snow is not the only thing white there. The 10 points, just because you went to a top high school which means your parents live in the right zip code. The eight points for taking advanced- placement classes, which are three times more available in schools serving white kids than kids that serve mostly students of color or the four points you got if Daddy went to Michigan. They rally behind Jennifer Gratz, as the supposed victim of reverse discrimination because the year she was rejected, there were about 85 students of color who got into the Michigan despite having lower scores and grades but they say nothing about the 1400—let me repeat— 1400 white students with lower grades and lower scores than Jenny Gratz, who got in. You see, less-qualified white people are no problem, but less-qualified people of color, my goodness, we can’t have that. They say nothing about the study from six weeks ago which found that for every one student of color, who receives any benefit from affirmative action in college there are at least two whites, for every one person of color two whites, who also didn’t meet the requirements but got in because Daddy wrote a check, or Mama made a phone call, or somebody pulled strings and got them in, but affirmative action for rich white people is never a problem for the folks like our opponents. While they insist affirmative action is racist because it holds people of color to lower standards the fact is, it is whites who have held to lower standards, it is whites and only whites I would suggest who can get C’s all the way through school, brag about their mediocrity publicly, mangle the English language, and go on to become Presidents of the United States. So, when they lament the supposed damage done to student of color by affirmative action because it supposedly forces them to question their abilities, ask yourself, why no concern for the mental health and self-image of white Americans, who have being preferred for 400 years, and if their argument is correct, must be the most self-hating people on the face of Planet Earth. And no, affirmative action doesn’t place people of color in positions for which they’re unqualified, indeed, once we control for economic status comparing only whites and folks of color from families with both the same income and wealth profile, there is no difference in college graduation rates, and only an insignificant difference in college grades. And black students at the most selective schools, actually do better in relation to their white counterparts than those in less-selective schools. Furthermore according to 200 different studies on the subject—not just one that I’m pulling out of my ass but 200 different studies—employees who have benefited from affirmative action perform equal to or better than their white male counterparts once given a chance to improve themselves, so in closing, unless our opponents can show you that they have some alternative mechanism for addressing that legacy of white racial preference—

—and the ongoing advantages extended to whites in this country, unless they can demonstrate some alternative means, by which true equal opportunity to flourish to vote for them, and to vote for ending affirmative action is to engage in an act of irresponsible racial aggression. It is to ignore the wisdom of Dr. King who said quite clearly in 1963, quote, “Whenever this issue of compensatory or preferential treatment is raised, some of our friends recoil in horror. The Negro should be granted equality, they insist, but should ask for nothing more. While at first that seems unreasonable, in fact it is unrealistic, for it is obvious that if you take a man and put him at the starting line of a race, 300 years after another man, the first man would have to perform some incredible feat in order to catch up,” end of quote. And to end affirmative action even does violence to the logic displayed by Ronald Reagan, whose mention alongside the word logic, is rare, coming from me, but who said as governor of California, when signing into law that state’s affirmative action policy—

I didn’t get my one-minute warning, but if I could finish the quote from—

If I could finish the quote from—

—Reagan I’d appreciate it—

That’s fine—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: —and the ongoing advantages extended to whites in this country, unless they can demonstrate some alternative means, by which true equal opportunity to flourish to vote for them, and to vote for ending affirmative action is to engage in an act of irresponsible racial aggression. It is to ignore the wisdom of Dr. King who said quite clearly in 1963, quote, “Whenever this issue of compensatory or preferential treatment is raised, some of our friends recoil in horror. The Negro should be granted equality, they insist, but should ask for nothing more. While at first that seems unreasonable, in fact it is unrealistic, for it is obvious that if you take a man and put him at the starting line of a race, 300 years after another man, the first man would have to perform some incredible feat in order to catch up,” end of quote. And to end affirmative action even does violence to the logic displayed by Ronald Reagan, whose mention alongside the word logic, is rare, coming from me, but who said as governor of California, when signing into law that state’s affirmative action policy—

### Moderator
Claim: Thank you, Tim Wise, for that opening statement.

### Scientific Advocate (SA)
Claim: I didn’t get my one-minute warning, but if I could finish the quote from—

### Moderator
Claim: No, I think—

### Scientific Advocate (SA)
Claim: If I could finish the quote from—

### Moderator
Claim: No, I—

### Scientific Advocate (SA)
Claim: —Reagan I’d appreciate it—

### Moderator
Claim: —I—I think everyone else in the room heard it, uh, Tim, why don’t you take a seat, sorry, you’ll, you’ll have time later—

### Scientific Advocate (SA)
Claim: That’s fine—

### Moderator
Claim: Thank you, Tim Wise. Thank you, Tim Wise, for that statement, uh… against the motion. I’ll say “One” still louder, uh, throughout the evening. Uh, and now for a statement, uh, in favor of the motion “It’s time to end affirmative action,” uh, John McWhorter, please go to the podium.

### Conspiracy Advocate (CA)
Claim: I think that when we discuss, um, racial preferences and I am gonna largely restrict what I’m saying to racial preferences in universities although many of these things also apply to affirmative action as handled elsewhere…we often are under the impression that what we’re talking about is something as simple as a tie-breaking process, a thumb on the scale, the idea being that, if qualifications are equal or more less equal between a black and a white candidate, that, one gives the nod to the black person. I personally would find nothing problematic with that policy, I don’t think most people would. And to the extent that it is generally implied, generally via omission, that that’s what we’re talking about when we talk about racial preferences and that we’re not talking about qualifications or test scores, or things that we don’t wanna talk about— then it’s understandable that there reigns a sense that, to be opposed to these racial preference policies means that a person must be naïve or unfeeling or have a sinister agenda or something like that, all of that is, is perfectly, perfectly understandable. And then certain words are used, “inequality,” “resegregation,” “white privilege,” “societal racism,” et cetera, and all of those concepts are important, there is a great deal of injustice in the country now and there always has been and we should think about it. But, those words also have a kind of rhetorical power that I think distracts us from the actual logic of the case here, and what racial justice is, that is how we actually solve the problems that I think we’re all concerned with. And…from what I’ve seen over my years in discussing this question, there are certain basic facts about how racial preferences are played out, that were not often told, I don’t think that people who think differently than me are willfully ignoring these things, I think these things just don’t get out there very much but they are absolutely crucial, to evaluating this particular case, and in my remaining seven minutes and about 13 seconds I just wanna give you a few of those things, for one thing, affirmative action, racial preferences as we’re talking about, is not just a tie-breaker. If that’s really all this debate has been about, I never would’ve joined it. There are all sorts of things. In 1991, in terms of all of the students who were admitted to selective law schools, um, there were 420 black ones, 24 were admitted according to what the qualifications were considered to be appropriate for, for white and Asian students, all the rest of them just based on the numbers wouldn’t have gotten in. I respect what Tim Wise has said, we have very different data in terms of the qualifications, if it were true the qualifications were the same, this would be a rather vacuous and petty debate. But the fact is, that according to anything that I know, they’re not. For example, one argument that we might hear before we leave tonight is that SAT’s are meaningless. Now there are dueling studies on that, I’m not sure exactly where one is to stand as a good-thinking person at this point. But certainly, it bears mentioning, that if you looked at UC Berkeley undergraduates who were black and their graduation rates after 1988, they actually tracked in virtual lock-step with SAT scores.

The lower the score, the more likely the person was to graduate, that suggests to me something that I think all of us know deep down, which is that, no matter how you jigger the statistics, SAT scores do mean something, not everything, of course, but they do mean something. Or, for example, Richard Sandor has shown that, um…with, um, black students admitted to 163 law schools, that, because so very many of them were admitted not according to the qualifications that they submitted but out of a sense of a commitment to diversity and lowering standards, that over half of them were in the bottom 10 percent of their class and that wasn’t only in they first year, and that there was a truly alarming rate of failing the bar exam. Now, these are all difficult issues but things like this, and needless to say, I could go on for a very long time but I’ve only got eight minutes—they have to be brought into a debate like this, they cannot be ignored, they cannot be trivialized. These things are real. Also, to eliminate racial preferences at selective universities does not deny black people an education. At UC San Diego before the ban on racial preferences out in California, exactly one out of 3,268 freshmen who were black, were making honors. After the ban, 20 percent of black students were making honors, because the students who would have been admitted to Berkeley or UCLA were now admitted to UC-San Diego. I think that was a good thing. It certainly wasn’t a bad thing. And it’s something that needs to be talked about. Let’s talk a little bit about diversity, because I think that’s gonna come up. For one thing, I remember being in college, and this is purely anecdotal, but, the idea of someone calling on me in class to talk about, you know, my take on the black experience or what the black perspective on things was, was something that made me sweat bullets and I’ve heard this from countless black undergraduates, many of whom tell me when I’m doing a book tour that to them, that’s evidence that there’s racism at universities, that they’re expected to be diverse representatives. So we can talk about diversity, but, how does it actually feel to be a diverse person. More to the point. It’s often said that diversity has been proven to make for a better-quality education. Has it? How. Like if you’ve ever actually looked into that, the people who try to prove it with studies, and none of them are conservatives, find again and again, that, as I think we all knew, diversity does not really have anything to do with giving you a more beneficial experience in terms of how much knowledge you have in your head or how much moral wisdom you have in your head, after you come from college. There was a poll of University of Michigan minority, um, law-school grads from 1970 to 1996. To them, being called on as a diverse person in class was at the very bottom of what they valued most about their experience as was the diversity. What they most valued in their experience was how smart teachers and their fellow students were, remember this is minority students. Or, Mitchell J. Chang showed that in terms of diversity in your undergraduate experience, it did mean that you talked about race more on campus, but it didn’t mean that you had more friends of another race and it didn’t improve your GPA and it didn’t improve how you feel about going to college. Stephen Cole and Elinor Barber have shown that when black students are placed in schools where they actually would have been more appropriately placed in terms of qualifications and qualifications do matter, into schools like these, then, what happened is that they made lower grades which discouraged them from going to get Ph.D.’s. This was a study done by good liberal people, they did not expect it. But that means that we have fewer black academics because of these policies. Now based on the things that I’ve mentioned, and clear—

—clearly they belong at the table. I do wanna say one thing. The idea that all of these sorts of things that I’ve discussed, and the fact that there are other ways of addressing this problem, are there, and they’re worth talking about. The notion that anybody would say, that, a legacy student is something that black students should be proud to compare themselves to, or, that a legacy student is something that is okay, I— I—I don’t get it, I met legacy students when I was in school, it was not a pretty picture. I certainly do not agree with these legacy policies, however, because I’m black, I’m talking about this kind of policy as it is applied to people of my race because I think that it hurts them. I’m not gonna make some hoary argument about the Constitution, or something like that. I don’t think that it helps black students to be the best that they can be. And I think I’ll stop there. But there are issues in this debate that we simply don’t hear about. It’s not as simple as just being against resegregation—

—and calling for diversity, thank you—

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —clearly they belong at the table. I do wanna say one thing. The idea that all of these sorts of things that I’ve discussed, and the fact that there are other ways of addressing this problem, are there, and they’re worth talking about. The notion that anybody would say, that, a legacy student is something that black students should be proud to compare themselves to, or, that a legacy student is something that is okay, I— I—I don’t get it, I met legacy students when I was in school, it was not a pretty picture. I certainly do not agree with these legacy policies, however, because I’m black, I’m talking about this kind of policy as it is applied to people of my race because I think that it hurts them. I’m not gonna make some hoary argument about the Constitution, or something like that. I don’t think that it helps black students to be the best that they can be. And I think I’ll stop there. But there are issues in this debate that we simply don’t hear about. It’s not as simple as just being against resegregation—

### Moderator
Claim: John McWhorter—

### Conspiracy Advocate (CA)
Claim: —and calling for diversity, thank you—

### Moderator
Claim: You can stop right there, in fact. Thank you. Uh, John McWhorter, thank you for that statement, uh, supporting the motion, “It’s time to end affirmative action.” Uh, now a statement from Khin Mai Aung, against the motion.

### Scientific Advocate (SA)
Claim: Well, one thing that John McWhorter’s right about is that we are gonna talk about diversity today and, it’s not bec— I’m not advocating it because I believe that every black person has the same experience, and ‘cause I believe that black people should have to carry the mantle of the black experience for our educational benefit, any more than I represent the same perspective as any other Asian person. I wanna tell you a little story about, um, my own experience, very recently I, I bought a house, um, in the Ditmas Park area of Brooklyn. And it’s been, um, heralded as the most diverse census track in the country. And so when I moved there, I found that, you know, the adults, they were, they were a little bit more hesitant to mix. Um, but the—but the young people at the, at the, at the pizza place, hung out, uh, with people of all different backgrounds, and little kids at the, at the, uh, playground were willing to play with each other, from all different backgrounds. And, this is something that I value. It’s to something that I think is easy, it’s not something that I think comes naturally. But it’s something that’ll only happen when people go to school together, when people are exposed to each other. And, preferably at an earlier age, and also in, in, in higher education. And you— so you should vote with us, if you agree with that statement, if you agree that a racially diverse environment is beneficial. If you believe that diversity enhances the educational experience, and that diversity is good for business and the economy. You should also vote with us, if you want a level playing field, not a false meritocracy, that is actually full of hidden benefits for the children of donors and legacies. Now, some of you may be wondering why I, a lawyer at the Asian-American Legal Defense and Education Fund, is here speaking out in support of affirmative action. Foes of affirmative action often like to say that Asians are the ones that are most harmed by affirmative action, that’s simply not true. First of all, many Asian groups, Southeast Asians in particular who face numerous educational disadvantages, need and benefit from affirmative action in all contexts and in particular, higher education. And all Asian-Americans need and benefit from affirmative action employment. So, I wanna echo what Tim Wise said is that we’re talking not just about diversity, about, uh, affirmative action in education, we’re talking about affirmative action in a variety of different contexts, including education, public contracting and so forth. And we’re also not just talking about a black and white paradigm, we’re talking about how affirmative action benefits other people of color, as well as women. So you should vote for us. If you value a diverse and inclusive society, and want a broad variety of experiences and viewpoints represented at our most prestigious, uh, educational institutions and workplaces. Business leaders have long realized the value of diversity. When the University of Michigan’s affirmative action programs were challenged before the United States Supreme Court, 65 leading American businesses, and their CEO’s filed a brief in support of affirmative action. These included American Express, Chevron and Microsoft, Boeing, Nike, and the list goes on. They realized that the leaders of tomorrow needed exposure to diverse people, ideas and perspectives. These companies found that individuals educated in a diverse setting were more likely to succeed and they had very concrete, concrete examples of, of these benefits. They believed that—they realized that people who were educated in a diverse setting were more likely to facilitate creative problem-solving approaches, they would—they can develop progra—uh, uh, products that appeal to a diverse customer base. They are better able to work with diverse business partners, clients and employees, and they’re more likely to contribute to a positive work environment. These companies need, and I quote, “the talent and creativity of a workplace that is”— or workforce rather—“that is as diverse as the world around them.” Minority professionals are also more likely to provide needed services to underserved communities. And this has been found in studies about minority doctors. Um, incidentally I—I think that this point was acknowledged by my colleague John McWhorter on the other side. In a study by the New—that was published in the New England Journal of Medicine in 1996, it found that black and Latino communities were four times more likely to have a shortage of doctors, and, incidentally, black doctors tend to practice in communities with five times as many blacks as communities where other doctors practice. They also have more black patients, and more Medicaid patients. Latino doctors, similarly, tend to practice in communities with twice as many Latinos as communities where other doctors are, and they also have more Latino patients and more uninsured patients. You should also vote with us if you believe in leveling the playing field. Women and minorities still face obstacles gaining admissions to our most selective universities and workplaces. And the College Board’s own studies show that SAT’s are skewed in favor of whites and the wealthy. So, yeah, do I say the SAT’s meaningless, probably not. But, what is that meaning and who is it skewed in favor of, des—and despite these advantages that whites still have with standardized tests, there are still twice as many whites as minorities with below-average scores, in the top universities and this is because they’re legacies or the kids of donors. Legacies are three times more likely than general population to be admitted at Harvard and two and a half more times at Yale and over half of legacies are admitted at Dartmouth and Penn. Now turning to Asian-Americans, foes of affirmative action as I said love to use as a poster child for who would benefit if affirmative action ended and this is just not true. First of all, Asians have voted decisively in favor of affirmative action, in both California and Michigan when these policies were challenged. And, now, it’s true that some Asian-American students have done remarkably well in higher education, and these are disproportionately the children of highly-educated professionals, who immigrated here predominantly from, um, East Asia and South Asia starting with the change in immigration laws in the 1960s. But there are other Asian-American students that face considerable educational barriers. In particular Southeast Asians, who are the children of refugees who fled here after the Vietnam war, from Cambodia, Laos, and Vietnam. I do a lot of my work in Lowell, Massachusetts, which is the second-largest Cambodian enclave in the country. A third of Lowell’s schoolchildren are Asian, predominantly Cambodian. But, 45 percent, a disproportionate number of Lowell’s school—of Lowell’s dropouts and students who are dismissed for sev—severe truancy are Asian-American. Almost one in two Hmong, and the Hmong are, um, an ethnic group that hails from Laos, and over one in four Cambodians in the United States have had no formal schooling whatsoever. In the affirmative action plans endorsed by the United States Supreme Court and the University of Michigan cases, you can consider a broad array of, of diversity factors, of which being—coming from a family of Southeast Asian refugees, can count. Proposition 209 ended affirmative action in California in 1996. Coincidentally this was the same year that I graduated from Boalt Hall School of Law, and as an aside, it was the diversity at Boalt, which was—Boalt was very diverse at the time—that in part inspired me to be a civil-rights lawyer. And after—

—after affirmative action ended, diversity within the Asian- American population has suffered at—at most selective University of California schools. At Boalt Hall School of Law, there were more than four times as may Filipinos, and—with affirmative action than without, and overall the number of Asian-Americans has dropped by 1 percent at all UC law schools in the first three years without affirmative action. Whites on the other hand increased by 12 percent. At UC Berkeley undergrad, a study by the Southeast Asia Resource Action Center found less than 50 total Cambodian that’s far less than 1 percent, fif—less than 50 total Cambodian and Lao, at UC-Berkeley in 1993. And the case for affirmative action in employment is even clearer for Asian-Americans, there’s less than 1 percent of partners in major law firms are Asian-American and less than 1 percent of senior managers at Fortune 1000 and Fortune 500 firms. That’s very similar to the weights of representation for blacks and Latinos, but of white men are 97 percent of senior partners, of senior management, at Fortune 1000 and Fortune 100 firms, even though they’re only—

—43 percent of the workplace—

—of the workforce, thank you very much—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: —after affirmative action ended, diversity within the Asian- American population has suffered at—at most selective University of California schools. At Boalt Hall School of Law, there were more than four times as may Filipinos, and—with affirmative action than without, and overall the number of Asian-Americans has dropped by 1 percent at all UC law schools in the first three years without affirmative action. Whites on the other hand increased by 12 percent. At UC Berkeley undergrad, a study by the Southeast Asia Resource Action Center found less than 50 total Cambodian that’s far less than 1 percent, fif—less than 50 total Cambodian and Lao, at UC-Berkeley in 1993. And the case for affirmative action in employment is even clearer for Asian-Americans, there’s less than 1 percent of partners in major law firms are Asian-American and less than 1 percent of senior managers at Fortune 1000 and Fortune 500 firms. That’s very similar to the weights of representation for blacks and Latinos, but of white men are 97 percent of senior partners, of senior management, at Fortune 1000 and Fortune 100 firms, even though they’re only—

### Moderator
Claim: Khin Mai Aung—

### Scientific Advocate (SA)
Claim: —43 percent of the workplace—

### Moderator
Claim: Thank you very much—

### Scientific Advocate (SA)
Claim: —of the workforce, thank you very much—

### Moderator
Claim: —for that, opening statement. Thank you. Uh, before we—now before we hear from Terence Pell and later, uh, Kim Crenshaw, I have—I have a couple of quick questions, uh, for panelists who, who have spoken already or a couple of them, first I’d just like to ask, uh, uh, Joseph Phillips, I’ll ask you— How do you answer the argument that was made by, uh, among others General Norman Schwarzkopf in the amicus brief in the Michigan case, that the military needs, for reasons of, of morale and, uh, national security it needs black and Hispanic officers, and to have an professional number of senior black and Hispanic officers, one of the tools is affirmative action. Uh, is that a reason for which you would say…okay, I’d, I’d prefer that result than whatever other result might emerge from color-blindness in the process—

### Conspiracy Advocate (CA)
Claim: No, I would answer him, uh, with the words of Colin Powell. Who in talking about affirmative action, talked about color-blindness. Uh, and, and, um, I can’t remember the exact quote but what Colin Powell says, is that if you’re talking about, um…removing barriers, if you’re talking about non-discrimination…so that, uh, then, then he’s all for it, I’m all for it, everyone here is for it. If you’re talking about putting people, uh, in places of, of, uh…over, over the, uh…not the ruling of men, but, you know…office, officers over groups of men, who, uh, are not qualified, that is not what Colin Powell endorses and I’m positive, that that is not what, uh, Norman Schwarzkopf—

### Moderator
Claim: And so in being selected for some program that might lead one to advancement, that selection process should be absolutely color- blind, not, not look to make sure you’re sending up a couple of minority candidates up for the, with the group, regardless of, uh, of, of, of metrics.

### Conspiracy Advocate (CA)
Claim: No, of course not, I think that that, uh, that that clearly undermines the confidence that you need to have, uh, in a fighting unit.

### Moderator
Claim: Okay. Uh, Tim Wise, I have a—a brief question for you. If race- conscious…uh, policies of the government have created the, uh, the inequities…

### Scientific Advocate (SA)
Claim: Right—

### Moderator
Claim: —that you’ve cited, and you feel that race-conscious policies are justified in redressing them—

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: —uh, how far would you go, what about race-conscious tax policies, why don’t we have, uh, refundable tax credits for members of minorities and you and I can play, uh, the alternative male-whiteness tax, we pay the A—

### Scientific Advocate (SA)
Claim: Right—right—

### Moderator
Claim: —AMWT, and that way we can go right to the end result of the unfair competition and redress it.

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: Or—or do you draw the line at color-blindness—

### Scientific Advocate (SA)
Claim: No, I—I would—look, the example you give I wouldn’t endorse but I would endorse the government of the United States, and those corporations and their existing entities that stem from other entities in past generations—

### Moderator
Claim: Mmm.

### Scientific Advocate (SA)
Claim: —that profited from and made possible the institutionalizing of white and white preference—

### Moderator
Claim: But why not an extra exemption for minorities—

### Scientific Advocate (SA)
Claim: I would say—I wouldn’t do it in tax policy, I would, I believe, and we can come back and debate the issue of substantive repair and restoration and reparation some other time. We’re not here to debate it tonight, I would support the government doing that, I’m not saying, white folks should take our checkbook and have a line item for black people. You know, but, but I would suggest that the government, which made possible the institutionalization of this systemic inequality, has an obligation to rectify it by many means of which affirmative action is one. It’s not the only one, and it may very well not be the best one. But it’s one and it’s the one we’re here to discuss tonight—

### Moderator
Claim: All right—

### Scientific Advocate (SA)
Claim: —and to get rid of it won’t bring us to any of the other, possibly better options that we could discuss at a—at a later time—

### Moderator
Claim: Okay, more discussion to come, thank you, uh, Tim, and, and, uh, more opening statements, uh, first from Terence Pell speaking, uh, for the motion, “It’s time to end affirmative action.”

### Conspiracy Advocate (CA)
Claim: Uh, thank you. Uh, look, for the last 40 years America’s been engaged in a massive social experiment, to see whether the use of racial preferences could bring about the full integration of American soci—society. The question tonight is whether these preferential policies can deliver on that promise. And the question need not be abstract nor need it divide liberals and conservatives. That’s because in the last decade, a growing body of data has become available, that helps us get a handle on the trade-off between attending an elite institution, on the basis of different admissions standards, or attending a less prestigious institution. Let’s start with the effect of racial preferences, uh, in undergraduate colleges. I’m going to focus on one specific academic area, namely science. Not many minority students enter science, and many who do drop out along the way. Blacks receive about 5.3 percent of the bachelor’s degrees in science, despite making up about 9 percent of the college enrollment. Well research into these disparities by Dartmouth psychologist Rogers Elliot, provides a template of the kinds of questions we should be asking not just in the area of science, but in every area, where preferential policies are employed. Because it turns out that the preferences themselves, are part of the problem. The first thing that Elliot’s data does, is dispel the assumption that non-Asian minority students somehow aren’t interested in science. In fact, high-achieving black and Hispanic high school seniors, are more interested in majoring in science, than whites. The second thing the data tells us is that the really elite research universities, the schools that recruit the most promising students, black and white, use significant racial preferences to enroll the most gifted and talented black and—black and Hispanic undergraduates. Elliot’s nineteen ninety-sev—1997 study, fo—which focused on four Ivy League schools, found that the mean SAT math score for black students was 100 points below that of white students. That difference was about 1.6 times this—sorry, 1.6 standard deviations of the white scores. This means that the black mean was not only below the white mean, it was so far below the white mean that the majority of black students had scores in the bottom 10 percent of the distribution of scores of all students. Now right away this significant use of race preferences by the most elite schools is significant. The fact that the very top schools, that have their pick of the best students, are using preferences of this magnitude, suggests that the next tier of schools are likely using greater preferences, and in fact, second-tier schools do use greater preferences, about 15 percent larger than those used by the top schools. As a consequence, many black and Hispanic students up and down the line are attending schools where their credentials are significantly out of line with those of their, uh, classmates. Well one possible response at this point, and we may hear this later on tonight, is to say that the SAT math score doesn’t fairly measure black academic success. One could even deny that admitting black students with lower SAT math scores amounts to a preference. Well, we could debate this all night, but the research on this point is undisputed. If anything grades and SAT scores over-predict black performance. So admitting blacks and Hispanics with significantly lower test scores and grades make it all but certain that blacks and Hispanics as a group, will get lower grades as—in college, and that’s just what Elliot found. Blacks interested in science at these schools had grades almost a full GPA lower than whites. For many students, many minority students this made it difficult to continue in science, and Elliot found that only a third of the blacks who started in science, at elite schools, uh, completed a degree in science. The rest switched majors, or dropped out altogether. Uh, and this rate was twice the rate of white students at those schools. Second, uh, the lower grades of those who did finish disadvantaged them significantly both in going on to graduate school, and getting jobs. Well, if the story ended here you might think that test-score gaps make it highly unlikely that blacks will ever, or a significant number of blacks will ever succeed in science. Uh, this would be a very dreary conclusion if it were true but the fact is, it’s not true. This is where the data tells us something very interesting, it helps us get a handle on the real problem with preferential policies, because it turns out that the absolute value of a students math SAT score and high school grades, is less important, as the relative difference between one’s credentials, and those of his or her classmates. How do we know this. Well, it turns out that black students interested in science, who attend schools where their math SAT scores more closely match that of other students, persist in science at much higher rates, even though the average SAT scores at these schools is lower. So for example, Howard University, a historically black college, has average SAT math scores of about 450, well below the mean of the, at the, the, uh, SAT score, at the elite schools we’ve been discussing, yet Howard is the top producer of black undergraduate science and engineering degrees in the country. What’s more, a large percentage of undergraduate science majors at Howard and other historically black colleges, go on to get Ph.D.’s in science. Of the top 21 undergraduate producers of black Ph.D.’s in the country, 17 of them, 17 of the 21, are historically black colleges, and none are among the 30 or so most selective schools that routinely recruit the most talented black high school students. And so what we have is this perverse system. The institutions with the poorest track records for producing black Ph.D.’s in science, are getting the best minority students, and then, driving them out of science at twice the rate of white students. And the institutions with the best track record, are getting the middling students, and then, producing the overwhelming majority of black Ph.D.’s in science. Well what lessons can we draw from this. First, the existence of racial inequalities in society which nobody on this side of the table denies, is not a sufficient justification for preferential policies. It’s bad enough that African-Americans are so substantially underrepresented in science. It’s completely inexcusable that racial preferences end up frustrating and discouraging the gifted black high school seniors who say they want to study science. Second, it is misleading to evaluate racial preferences in the abstract, as if we’re talking about one—

—or two institutions that use preferences in a handful of deserving cases. What we’re dealing with, the problem that we’ve got, is the systematic use of racial preferences by every single institution of higher education in the country. I’ve used my time to focus on one specific problem in some detail, but a growing body of research shows similar effects in many other areas. Surely all of us can agree, that schools should be required to publish graduation rates and grade distributions, and yes, persistence in majors, broken down according to the different preferences granted, and that means all of them, including racial preferences, alumni preferences and athletic preferences, the problem is the same in all cases. But more fundamentally, we need to ask ourselves why we tolerate the systematic use of race preferences. Every Supreme Court precedent in this area’s held that racial preferences are a last resort. Yet schools continue to treat preferences—

—as a sacred cow—

—they must defend to the death. Thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —or two institutions that use preferences in a handful of deserving cases. What we’re dealing with, the problem that we’ve got, is the systematic use of racial preferences by every single institution of higher education in the country. I’ve used my time to focus on one specific problem in some detail, but a growing body of research shows similar effects in many other areas. Surely all of us can agree, that schools should be required to publish graduation rates and grade distributions, and yes, persistence in majors, broken down according to the different preferences granted, and that means all of them, including racial preferences, alumni preferences and athletic preferences, the problem is the same in all cases. But more fundamentally, we need to ask ourselves why we tolerate the systematic use of race preferences. Every Supreme Court precedent in this area’s held that racial preferences are a last resort. Yet schools continue to treat preferences—

### Moderator
Claim: Thank you—

### Conspiracy Advocate (CA)
Claim: —as a sacred cow—

### Moderator
Claim: —Terence Pell—

### Conspiracy Advocate (CA)
Claim: —they must defend to the death. Thank you.

### Moderator
Claim: Thank you…Terence Pell, uh, speaking in favor of the motion, now, uh, to give the last of the opening statements against the motion, “It’s time to end affirmative action,” Kimberlé Crenshaw.

### Scientific Advocate (SA)
Claim: Hi. I’m Kim, and I am a beneficiary of affirmative action. Despite what our opponents want you to think, Americans continue to support African-American for women and for people of color. When the precise question of eliminating affirmative action was put to voters in Houston, Texas, the majority repudiated this radical agenda. In supporting affirmative action Americans inherently know that while it is one thing to pull down those “No trespass” signs, it is another task altogether, to build pathways to and through our institutions, that are genuinely and visibly open to all. This continuing support of affirmative action is even more remarkable, given how the media, and lukewarm supporters, have acquiesced to the terms of the debate that have been set by well-funded, think tank-produced critics. Think for just a moment about what is missing in the way that affirmative action is usually framed. The debate is usually premised on the metaphor of an equal-opportunity race, where we all began at the starting line. The societal rewards go to the swiftest and the most talented. Now the problem with affirmative action as we are led to believe, is that it distorts the race by giving some people a head start, halfway around the track. So when the winner is a woman, or a person of color, or for goodness sakes, a woman of color, supposedly we all know that it isn’t because she was the swiftest runner, or thinker, or planner, but because of the head start that she happened to get. Now, some supporters of affirmative action will agree that the runner got a head start, but will justify the head start in terms of a diverse society. Now, don’t get me wrong, I’m all for diversity, it’s the language of inclusion used by the military, by corporate America, virtually all colleges and universities and yes, by the Supreme Court too. These are good allies to have on our side and on this one, they’re firmly with us. But while all sides of this debate focus on the disabilities of the runner, they wind up missing entirely the crippling conditions of the track. So what if instead of training our gaze at the runner, we looked instead at the conditions of the track. What if we really looked at the different lanes that America’s runners have to run in. If we looked at that we see that some of those lanes are nicely paved, even surfaces, beautifully well-lit with freshly painted lines. Other Americans though have to navigate lanes that are riddled with obstacles and debris, where to stay in the race they have to climb walls, scale barriers, cross over craters, avoid detours, and confront a host of conditions that others never face, just in order to even see the finish line. Affirmative action is quite simply a commitment to remove the effects of these obstacles that impede the race for some, using a wide variety of tactics and strategies, now, the other side will riddle us with language about, um, preferences— they’ll talk about racial preferences, they won’t talk about gender preferences—as a way to get you to forget what you know about the track, and to focus instead of what you think you know about the runners. Now, there’s a wealth of information that gives content to the obstacles, that run a full gamut from traditional discrimination employment, where blacks with a high school diploma, actually, actually lose out in the competition to whites with a criminal record. And where the same resume… receives 50 percent fewer white, uh, call-backs than black-sounding names do. To underfunded schools, school districts with the highest concentration of black students receive the lowest share of resources, and the prison to, uh, the school-to-prison pipeline where kids as young as six are handcuffed, and set on a fast track to prison, rather than a highway to college. To hyper- segregation that isolates minorities from key social networks through which most job-seekers actually find employment, to newer evidence about stereotype threat that makes gifted students unperfor—underperform on high-stakes tests, to implicit bias that unconsciously shapes people’s attitudes, and their behaviors towards minorities. That makes cops think they see a gun instead of a wallet. That makes teachers think they see an imbecile instead of a hungry child. That makes men think they see a ball-busting diva rather than a high-performing managerThat makes high-per—highway patrollers think that they see traffickers transporting drugs rather than a high school basketball team celebrating a nail-clinching victory. This evidence from disciplines as diverse as sociology, economics, law, com—cognitive science, reflects just the barest summary of the conditions that are out there. Modest efforts to build bridges and patches over these obstacles, are not preferences. They are corrections to ensure equal opportunity. Now, to be sure, there are preferences that are up there. And they are dangerous and obsolete, I’m talking about the preferences for wealth, for legacies, for power, for social networking, preferences that permit this privileged and lucky cohort to simply show up at the race to win, they don’t have to run, they don’t have to work hard, no one scolds them or their families or their communities about discipline, and they don’t have to break a sweat. Let’s take the guy up there on the people mover. Through his family’s money, his daddy’s connections, a bunch of good old boy backers, a society trained to look the other way, this guy can get a C average at Yale, enjoy a undistinguished record at Harvard B School and in due course simply lean over to the finish line, to receive the most coveted job in the country. If there is a poster boy against real preferences, who better than George Bush. But now, how is it that this colossal preference that attends to the privilege is overlooked, I call it, look, it’s a black-man strategy. Look at this, check this out. Now. This cover appeared on Newsweek during the controversy over affirmative action at the University of Michigan, “Affirmative Action—10 Ways to Think About it Now.” Now, let’s think about this picture for a minute, what are at least three ways that we’re told we’re supposed to think about affirmative action. It’s important for you to know that Newsweek was communicating a message here. This person wasn’t a student involved in Michigan, he was a model, he was photographed, many times with various attire, to arrive at the picture that showed the message that Newsweek wanted you to know. As Janine Jacks reported in her study of affirmative action, “Media coverage routinely focuses on race not gender, on blacks not other people of color, on elites not people of color from all classes and genders.” White women are the single largest group to benefit from these—

—programs, as recorded by the labor statistics, but you certainly wouldn’t know it, from the way the media covered it. What does this tell you about the nature of the debate when in fact the real picture of affirmative action, looks a little bit more like this. Well, what it’s supposed to tell you, is that affirmative action is in fact about people of color of all races, and it’s supposed to tell you that it’s actually about women as well. So I submit, that people of good will should recoil from the bait-and- switch tactic. They should recoil from any kind of argument that frames this solely in terms of racial preference, and solely in terms of one group. I would submit to you that the proposal to eliminate affirmative action repudiates King’s call, that day standing in front of the statue of Abe Lincoln to make good on its promises of fairness, freedom of equality It substitutes that soaring oratory for a simple three-monkey solution to our problems. We can make it all go away, if we—

—agree to see no evil, speak no evil, and hear no evil—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: —programs, as recorded by the labor statistics, but you certainly wouldn’t know it, from the way the media covered it. What does this tell you about the nature of the debate when in fact the real picture of affirmative action, looks a little bit more like this. Well, what it’s supposed to tell you, is that affirmative action is in fact about people of color of all races, and it’s supposed to tell you that it’s actually about women as well. So I submit, that people of good will should recoil from the bait-and- switch tactic. They should recoil from any kind of argument that frames this solely in terms of racial preference, and solely in terms of one group. I would submit to you that the proposal to eliminate affirmative action repudiates King’s call, that day standing in front of the statue of Abe Lincoln to make good on its promises of fairness, freedom of equality It substitutes that soaring oratory for a simple three-monkey solution to our problems. We can make it all go away, if we—

### Moderator
Claim: Thank you—

### Scientific Advocate (SA)
Claim: —agree to see no evil, speak no evil, and hear no evil—

## Round 2

### Moderator
Claim: Kimberlé Crenshaw. Thank you. Uh, a couple of quick questions, uh, for me, uh, before the next part, Terence Pell. Uh, the motion says “It’s time to end affirmative action,” that, that leaves open at least the possibility for people on your side that there was a time when it wasn’t time…to end affirmative action. Was there a period, when confronted with many American institutions, uh, that were, uh, overtly segregationist, that excluded people, was there a time when it was appropriate to have affirmative action or would you say never.

### Conspiracy Advocate (CA)
Claim: Uh—ooh.

### Moderator
Claim: No, this is for Terence Pell.

### Conspiracy Advocate (CA)
Claim: Uh, clearly, uh, institutions that operated in completely segregated systems had to do something more than, uh, remove the, uh, fact of segregation itself, they had to take affirmative steps to break down the barriers that they themselves had created. That was the original idea of affirmative action and it made sense then. But since then it’s grown into, uh, the systematic use of preferences all over the place and that’s just a completely—

### Moderator
Claim: But—

### Conspiracy Advocate (CA)
Claim: —different…use—

### Moderator
Claim: But you’re describing cases of de facto segregation, if there was a very small population of minorities there would be a case there…for—

### Conspiracy Advocate (CA)
Claim: No, I’m talking about particular institutions, for example—

### Moderator
Claim: One particular institutional—

### Conspiracy Advocate (CA)
Claim: Yes—

### Moderator
Claim: —segregators—

### Conspiracy Advocate (CA)
Claim: To remedy their own discrimination—

### Moderator
Claim: Otherwise there’s never been a case for affirmative action—

### Conspiracy Advocate (CA)
Claim: That’s what I think, that’s right—

### Moderator
Claim: Okay. Uh, and, uh, Kim Crenshaw, I have a question for you, uh, which is, uh, if it is, if it’s, if it makes good sense, uh, to admit a minority applicant to law school, for, for good reason, even though that candidate’s test scores and grades, uh, would not qualify for admission if, if it were a white applicant, does it equally make sense at the bar exam, where there’s a great disparity in success, to say let’s have a lower grade for passing, uh, for minority candidates. It’s different, we see a racial disparity, why not, what’s the difference between that, and qualifying with grades.

### Scientific Advocate (SA)
Claim: Well, I think there’s a case to be made that all standardized tests are deeply problematic and there’s plenty of cognitive social science to suggest that. So if we’re asking about whether there are alternative ways to measure merit, if there are alternative ways to measure the predictability of success, I’m all for it. The main point of this argument however is whether we should eliminate affirmative action in the admissions of col—in colleges and law schools and the reality is—

### Moderator
Claim: But—but your colleague Tim Wise—

### Scientific Advocate (SA)
Claim: Let—let me—let, let me—

### Moderator
Claim: —is not limiting himself to those subjects, yes—

### Scientific Advocate (SA)
Claim: —let me point this out. The reality is that, what the other side will refuse to tell you, is that those tests do not tell you anything about the success of minority students and lawyers in the profession. President Bok, President Bowen, guys who were president of Harvard and Princeton, proved that the level of success for people who were admitted through affirmative action to higher education and law school in particular, are as successful if—if not more.

### Moderator
Claim: But just define—

### Scientific Advocate (SA)
Claim: Notwithstanding the

### Moderator
Claim: —the contours of the argument, my, my, my bar exam question. That’s different?

### Scientific Advocate (SA)
Claim: I’m not saying it’s different, I’m saying that the proposal that you’re asking right now, is whether we should eliminate affirmative action. If we wanna talk about other ways to minimize the discrepancies and to minimize the other kinds of discriminatory effects on other standardized tests, I’m all for us—

### Moderator
Claim: You’re open—

### Scientific Advocate (SA)
Claim: —talking about that.

### Moderator
Claim: Okay. Well, uh, I’m now going to announce the, uh, the results of our pre-debate audience vote first of all. Uh, you voted before the debaters began, the panelists began debating, and the results were as follows. 34 percent of you, uh, voted in favor of the motion, “It’s time to end affirmative action.” 44 percent voted against, and 22 percent, uh, were undecided. And again, at the conclusion of the debate we’ll, we’ll poll you, uh…a second time. Uh, to begin the discussion portion of our evening, we’re gonna try something different, I’d like to ask each of our panelists, uh, to pose a question to someone on the opposing side. Joseph Phillips first, you’re in favor of the motion, a question from you for Tim Wise who’s against it. And you’ll have about one minute to answer that question, or you’ll have exactly one minute to answer that question—

### Conspiracy Advocate (CA)
Claim: Okay. Make the actor go first. Gonna be protesting outside of here. Um, I have two questions…

### Moderator
Claim: Well, let’s have one question, it’s, uh— It’s hard enough to answer one question—

### Conspiracy Advocate (CA)
Claim: I’m trying to choose—

### Moderator
Claim: —in 60 seconds—

### Conspiracy Advocate (CA)
Claim: —which one, we’ll, I’ll ask this one. I’d like to know, uh, I, I listened to Tim’s speech, and, um…I, I, I… I thought, um…and wanted to know why is it that, uh, that blacks, or that you seem to think that blacks can only achieve, when the playing field is level.

### Scientific Advocate (SA)
Claim: Well, I don’t say that black folks can only achieve when the playing field is level, I’m making a moral argument, that the playing field should be level because for it not to be, is an injustice, I’m talking about it from an ethical perspective. I happen to think people of—you know, Madame C.J. Walker was the first black millionaire, and she made it in 1911 when 67 black folks got lynched, but I don’t think we would say, well hey, if Madame C.J. could make it, you know, all y’all could’ve made it. Because she was selling beauty products to black women that white folks didn’t wanna make, good for her. But no one in their right mind would’ve said, see, everybody should go out there and work so I think folks can succeed, the question is what are our obligations as a society to create a level playing field, has nothing to do with what the outcome can or cannot be. It has to do with what is right and what is just and what is proper, and I would guess, just a guess, that when people have equal opportunity, they are indeed more likely to succeed. I’m pretty willing to stand on that this evening.

### Moderator
Claim: And, uh… Tim Wise, uh, opponent of the, of the resolution “It’s time to end affirmative action,” why don’t you pose a question to John McWhorter who supports that rotion that motion—

### Scientific Advocate (SA)
Claim: Sure thing, um, John, you suggest that, people of color are potentially less qualified as evidenced by their college performance, maybe should go less selective schools as a result. So given that what would—what should we conclude, the people in the audience and, and those of us up here… from the data which suggests that men, on average, also receive far lower college grades than women, of all races and ethnicities. Does that mean that men are unqualified for the slots that they receive in colleges and law schools, and that maybe they should lower their sights to second- and third-tier schools and leave the best slots and opportunities for all the women. And if it doesn’t mean that, why doesn’t it mean that, given your argument about race.

### Moderator
Claim: John McWhorter, your answer.

### Conspiracy Advocate (CA)
Claim: Tim, I’m not sure that you’re aware of the degree of the discrepancies that I’m talking about. I mean we’ve long known about those particular gender discrepancies, and if we’re gonna talk about a kind of mindless bean-counting, then no, I’m not in favor of that kind of address of racial preferences, but when you’re dealing with schools which before a ban on preferences have a stark, two-tiered system, where black students are crashing and burning at much faster rates, then I think that in terms of arguing about—

### Moderator
Claim: 30 seconds.

### Conspiracy Advocate (CA)
Claim: —morality, and how we address the past, and how we help people cope, with a nation where I don’t think that the playing field could ever possibly be perfectly level, that, there is an issue for talking about racial preferences rather than what you’re talking about.

### Moderator
Claim: And, uh, John McWhorter, why don’t you pose a question to, uh, Khin Mai Aung who is a su—uh, an opponent of the, of the motion.

### Conspiracy Advocate (CA)
Claim: Khin, I would just ask you this. If, um…when there are racial- preference policies, at least in universities, one unpleasant by- product can be a sense among a certain group that a certain level of performance is just the highest that one does because that’s just ethnically authentic, this is something that I saw when I taught at UC Berkeley. A very smart young woman during the ban on racial preferences told me that she—she was an undergraduate working in the recruiting office—was discouraging black applicants from coming to UC Berkeley if they made really high SAT scores and had really good grades. And I asked her why and she said, in all seriousness, we’re afraid that black students who perform at that high a level, aren’t going to have a social commitment to the black community at Berkeley. In other words—

### Moderator
Claim: Is there a question, to—

### Conspiracy Advocate (CA)
Claim: —high achievers—

### Moderator
Claim: —Khin Mai Aung—

### Conspiracy Advocate (CA)
Claim: —are not really black. How would you respond to that in terms of your support for racial preference policies—

### Scientific Advocate (SA)
Claim: I’m sorry, could you clarify the question, there was a long—

### Conspiracy Advocate (CA)
Claim: How do you— Okay, how would you respond to the point, that, if standards are lowered for a particular group over a long period of time, after a while that may be the best that that group ever does because they’ve never been asked to do better.

### Scientific Advocate (SA)
Claim: Well first of all, standards are not lowered. Diversity is a—a genuine benefit, that occurs at an institution, both for the beneficiary and for other students at that institution. Secondly, beneficiaries of affirmative action are qualified. Students with very low test scores are never gonna get in, unless they happen to be legacies or children of donors. All beneficiaries of affirmative action have test scores, and, and, and other criteria where they are, are able to succeed and they do succeed. In the— this 1998 study by the two—

### Moderator
Claim: 30 seconds.

### Scientific Advocate (SA)
Claim: —presidents of the university that, um, Kim Crenshaw mentioned, The, The, uh, Shape of the River, it found that, black students at the most prestigious institutions actually graduated at a higher rate than, than black students at less selective institutions. They had very similar career arcs once they graduated. They had the same rate of getting advanced degrees, and they were actually more likely than whites to get, um, uh, advanced degrees in law, medicine, and business, so I would say that, they are qualified and they are succeeding.

### Moderator
Claim: And your question now, uh, Khin Mai Aung, uh, who, uh, opposed the motion, put a question to Terence Pell who argues in favor of it.

### Scientific Advocate (SA)
Claim: All right, I too am trying to decide between two questions, so, the question I’m gonna ask, actually, it’s not, um, related to your part comments today. But, um, I understand that, um, the organization that you work for, the Center for Individual Rights, has a position that, um, civil rights laws should not apply to the private sector. And so, I’m wondering, is that—why—if you, if you’d like to explain that position, I mean, if— If we were back in the ‘60s where, when, uh, you know, we had, uh, black students trying to be served at lunch counters, um, in the South, would you, would you be standing behind the students or would you be standing behind the, um, the diners.

### Conspiracy Advocate (CA)
Claim: Well—

### Moderator
Claim: Terence Pell.

### Conspiracy Advocate (CA)
Claim: Yes, well, the simple answer is that’s not our position and it never has been our position, we routinely rely on these civil rights laws, like Section 1981, and Title 6 in our lawsuits. Those laws are primarily directed towards discrimination by private entities, uh, and private individuals, so, uh, our organization, uh, not only, uh, is not attacking those laws, we’re using those laws and we fully support the use of those laws and the various investigative agencies to go after, uh, identifiable acts of discrimination—

### Moderator
Claim: 30 seconds.

### Conspiracy Advocate (CA)
Claim: —by individuals and private entities, so, the premise of your question, uh, is false.

### Scientific Advocate (SA)
Claim: I—I take it I can’t respond to that?

### Moderator
Claim: You can a—well, there are 20 seconds left, uh— I—I think—I think you’ll be able to get to a little bit later, perhaps—

### Scientific Advocate (SA)
Claim: Well, I was just gonna say—

### Moderator
Claim: from the audience.

### Scientific Advocate (SA)
Claim: My understanding is it was on your website in 2004.

### Conspiracy Advocate (CA)
Claim: Uh, it’s—that’s false.

### Moderator
Claim: That is false, no?

Uh…in any case, uh, uh— Terence Pell, it’s now your opportunity to put a question to Kim Crenshaw.

### Conspiracy Advocate (CA)
Claim: Uh…Kimberlé, if it turned out, if the evidence developed and, uh, that, uh, race preferences or preferential policies, uh, turn out to pose barriers, uh, to minority success, similar to the barriers you identified in your talk, uh, would you reconsider your support for them.

### Scientific Advocate (SA)
Claim: I would certainly reconsider the actual form, in which affirmative action takes place, however I think that most affirmative action programs across the country, actually try to attenuate themselves to the actual conditions, so, you all are talking about affirmative action, racial preferences as though they are one program, they actually function in one kind of way. When in fact, there are hundreds of affirmative action programs, ranging from affirmative action in admissions, ranging from outreach programs, development programs, information programs—

### Moderator
Claim: 30 seconds.

### Scientific Advocate (SA)
Claim: All of these forms of affirmative action have been shown to be effective for the particular obstacles that they are meant to overcome. The issue that I see, is that for the most part when we see various failures to perform, we tend to focus on the individuals rather than saying this is a wake-up call to our institutions. Our institutions know how to integrate equally, do they know how to educate equally, that’s the question that is raised.

### Moderator
Claim: Thank you. Uh, Kimberlé Crenshaw, uh, speaking and answering of that question, she is one of our panelists opposed to the motion. We have lots of time for your questions, for members of the audience right now. And I’d like to call on you, uh, please, uh, I’d ask you—I’m sorry. Excuse me. I got away ahead of myself. I got one minute ahead of myself. Kimberlé Crenshaw, it’s your turn to put a question to Joseph Phillips.

### Scientific Advocate (SA)
Claim: So Joseph, I—I wanna clarify what I think is a confusion particularly in Colin Powell’s position but I also see it as a confusion that I’ve heard a lot, coming from the other side on Martin Luther King, about what is affirmative action and what is a preference. Is it your understanding that Colin Powell does not support affirmative action, to put it more specifically, that he believes that promotions the armed forces should be absolutely color-blind? Because that is decidedly not what he says.

### Moderator
Claim: Joseph Phillips?

### Conspiracy Advocate (CA)
Claim: It’s my position, that, uh…affirmative action, in the form of racial non-discrimination, is a good thing, it’s good for America, that’s what Colin Powell says. Racial preferences, uh, are not a good thing, and I don’t believe that that’s what Colin Powell says—

### Scientific Advocate (SA)
Claim: So are you saying affirmative action is a racial preference and Colin Powell agrees with you on that—

### Conspiracy Advocate (CA)
Claim: No, that’s—I said in my—

### Scientific Advocate (SA)
Claim: Okay. That’s what I wanna know—

### Moderator
Claim: We’re down to a factual question, when Powell spoke at the ’96 Republican convention, he didn’t defend affirmative action in that…in that speech?

### Conspiracy Advocate (CA)
Claim: You’re asking me to go back—

### Moderator
Claim: I—

### Conspiracy Advocate (CA)
Claim: —I’m go—but— You know, you, you take one speech that someone made and they may have said other things at, at other times during other, uh, conversations. So I don’t know what he said during that, uh, particular speech—

### Scientific Advocate (SA)
Claim: It’s in his book. It’s in his book.

### Moderator
Claim: Okay. Uh, well—

### Conspiracy Advocate (CA)
Claim: And I think that I, I…uh, accurately reflected his sentiments—

### Scientific Advocate (SA)
Claim: The—the only—the only point is if you’re gonna use people to support your position, you should be—

### Conspiracy Advocate (CA)
Claim: I think I accurately—

### Scientific Advocate (SA)
Claim: —you should be actually clear, that that’s their position—

### Conspiracy Advocate (CA)
Claim: Now wait a minute—

### Moderator
Claim: End of panelist question time—

### Conspiracy Advocate (CA)
Claim: —I haven’t heard from you exactly what he said—

### Moderator
Claim: End of panelist question time—

### Conspiracy Advocate (CA)
Claim: —I’ve heard you tell me that I was wrong, I didn’t hear the quote.

### Moderator
Claim: Read the book.

### Scientific Advocate (SA)
Claim: Read the book—

### Conspiracy Advocate (CA)
Claim: I did the read—

### Moderator
Claim: All right, let’s—

### Conspiracy Advocate (CA)
Claim: Do you have the quote? Or are you just yelling out from the audience—

### Scientific Advocate (SA)
Claim: The quote—the quote can be found at www.aapf.org—

### Conspiracy Advocate (CA)
Claim: In other words you don’t have the quote—

### Scientific Advocate (SA)
Claim: “13 Myths About Affirmative Action”—

### Conspiracy Advocate (CA)
Claim: —you’re just free to say I’m wrong—

### Scientific Advocate (SA)
Claim: That’s—

### Conspiracy Advocate (CA)
Claim: —without having—

### Moderator
Claim: Enough—enough on Colin Powell’s book.

### Scientific Advocate (SA)
Claim: Go read it.

### Moderator
Claim: And, uh, I’m sorry, uh, to have, uh, jumped the gun a moment ago, and for the benefit of my radio producer I’ll repeat what I said. We have lots of time left for your questions, uh, from the audience, uh, to your panelists, I’d like you to wait until, uh, I’d like you to, to raise your hand if you’d like to ask a question, someone with a microphone will find you. Uh, when that person does and I call on you, would you please, uh, stand up, and, uh, keep your question, if you can please keep your question brief and, uh, to the point, do, do as I say, not as I do. And, uh… and then we’ll take—we’ll start by taking a question at a time, here’s a gentleman here. Sir, you’re right there.

### Moderator
Claim: Thank you very much. Uh, Booker T. Washington if I’m correct opposed legislative mandates to address racism, as did Barry Goldwater who was anything but a racist contrary to popular belief. I’d like to ask any of the panelists on either side, to what extent from a philosophical and constitutional perspective, either of those two gentlemen were right or wrong and why.

### Moderator
Claim: Uh, Kimberlé Crenshaw, you’re the—you’re the law professor, I’ll turn to you first.

### Scientific Advocate (SA)
Claim: Well, it’s not surprising that there have been African-Americans throughout history who have disagreed, sometimes profoundly, um, with the positions of the majority of African-Americans as to what kind of intervention should be put forward to better their condition. It’s important to recognize in this context that every significant program that has ever been introduced to assist African-Americans to actually achieve freedom and equality has been denounced as a preference, from the Emancipation Proclamation, which was seen as giving them a preference, giving them something that they didn't deserve, which was basically the value of their labor; to anti-discrimination law that would protect them in their rights to, um, access to hotels and theaters, was seen as special treatment; to even the argument against segregation, which was seen as a preference. So, the point of the matter is, we have to always see these against the base line in society. If we consider the base line to be unfair, if we see the normal status quo as discriminatory, then these interventions are not seen as preferences, they're seen as equal opportunity. If, by contrast, we see society is basically benign, or we think it’s OK that there are these deep structural differences that won't go away by ignoring it, but we think that’s perfectly acceptable, then we’ll understand these interventions as being preferential. I happen to be on the former side of the case. I think having structured inequality over centuries is inconsistent with the deepest values of America, and therefore any kind of intervention that is intending to try to bring about real equality is not preferential, it’s in the deepest traditions of equality.

### Moderator
Claim: And does anybody on the side supporting the motion want to, want to respond, either to directly address that question, or to respond to—

### Conspiracy Advocate (CA)
Claim: Booker T. Washington—

### Moderator
Claim: John McWhorter.

### Conspiracy Advocate (CA)
Claim: …knew a very different world than ours, and I personally would not be in favor of his particular view that people really should just pick themselves up, and that’s all. Really, people do need help. He never knew the New Deal, he never knew the Great Society, he never knew Affirmative Action when it was first instituted, which I personally think was a very important thing given the situation in the country at the time. However, his basic insight that there does come a point when, in order to cope with an imperfect world, you have to do it yourself. There comes a point, is one that I think is valuable. One reads his writings now, and they're not nearly as reactionary and foreign as one would think. I think it’s an advance in our society that we do have a safety net, that we do have things to, for example, help the poor. For me, socio-economic preference makes perfect sense. The issue, simply, is that today there is not nearly as large an overlap between disadvantage and having black skin as there was in 1960 or even 1970—

### Moderator
Claim: So, so when you argue it’s time—

### Conspiracy Advocate (CA)
Claim: It’s time for a revision.

### Moderator
Claim: When you argue it’s time to end Affirmative Action, you would say, this time is different from an earlier time—

### Conspiracy Advocate (CA)
Claim: It was about fifteen years ago—

### Moderator
Claim: …became time to end Affirmative Action. Uh…

Oh, you have the microphone?

### Moderator
Claim: Yeah—

### Moderator
Claim: Can you, yes… And, and if, members of the press, if you're here asking questions, could you please identify yourselves.

### Moderator
Claim: Hi, I have a question on set, on this test, uh, I had my, uh, undergrad studies back in China, science major, I moved on to law and business, but a lot of my classmates went on pursuing Ph.D.’s, and they did, and actually I did that too, we did a GRE test preparation. And I remember the time, you know, didn't have money, could not afford, um, materials from the test center, so all we can prepare on is based on, you know, the past ten years old exams in the public. Or, you know, even those things are not always readily available. You know, I’d remember times I’d have to get oil prints of those So, but the funny thing is, these guys all went into very high level Ph.D. programs, and in GRE tests, uh, people out there didn't have so much preparation materials.

### Moderator
Claim: You have to come to the question now—

### Moderator
Claim: Actually beat, actually beat US people, you know, US test, become the best performing student body, the Chinese guys. And if a, if foreigners can do that, why people in the US cannot?

### Moderator
Claim: Uh, if foreigners can compete with American students on the tests that we require them to take for admission to our graduate schools, uh, why shouldn't we expect Americans to do so? Who, who wants to answer that, that question? Tim Wise?

### Scientific Advocate (SA)
Claim: I don’t think it’s a question of whether we ought to expect people to do well on tests. I think we ought to. And I think we ought to make it possible for folks to do so no matter who’s taking it, whether they are taking it from some other country, whether they're taking it from down the block. I think the real question, however, is whether or not we ought to be looking at that test, no matter how it’s done on, by anyone, be they a foreigner, or be they someone who is a citizen of the United States, as to whether that should be the criteria for admission. Now, the research on this is very clear, that the highest correlation you ever will get on an SAT, a GRE, an MCAT, an LSAT, or any of these tests, with actual performance in the first year after the test is taken is point four. That’s fairly pathetic in statistical terms, because what it means is that, at most, sixteen percent of the difference between any two students can be explained or predicted by that score, meaning eighty-four percent has nothing to do with it. Why are we using merit criteria that don’t really measure merit, but do typically, not always, but over-represent those that have those resources, and those who are affluent. Not only, there are folks who don't have the resources who sometimes do well, but that’s the highest correlation. It seems to me that we ought to be looking at alternative criteria, including things like testing, but not overemphasizing those, because we know that in fact when those students who scored lower, who maybe didn't score as well as those at the very pinnacle get in at places like the University of California, that only about five percent of their grade differences can be predicted by the test scores. So, they're not being mismatched, they're not unqualified, there are other things that recommend them for the spot. So, we ought to expect and try to make sure everyone does well. We also ought to have a criteria that is both more fair and representative, but also more accurate. It doesn’t serve anyone’s interests to use a criteria that does not, in fact, predict success, and those tests simply do not. In fact, one study of law schools, talking about law schools, University of Michigan study found that there was an inverse relationship between LSAT score and future professional success. Meaning that those who did better actually did worse and weren't as happy in their jobs when they got out of law school and started practicing. So by that criteria, we ought o let all the folks in who bombed the LSAT, because they're going to make the best lawyers.

### Moderator
Claim: Next question from the audience.

### Scientific Advocate (SA)
Claim: Can I just add something to that as well? I mean, part of it is also you said that these foreigners were able to prep, which I would imagine means that they speak English and perhaps are from a professional background, that they, they knew about these tests. And I think that that is, that is a big issue, that, that the access to the materials and access to information about the tests also isn't equally available.

### Moderator
Claim: Next question.

### Moderator
Claim: Uh, good, good evening. Each of the panelists against the motion insists that the beneficiaries of Affirmative Action have been as successful as any other students in school. If that’s the case, should the children of those beneficiaries, and the grandchildren of those beneficiaries, since it’s been forty years, should they continue to get the preferences, uh, afforded by affirmative action, and if, if it’s not time to end it now, when is the time to end it?

### Moderator
Claim: Kim Crenshaw?

### Scientific Advocate (SA)
Claim: You know, one of the fallacies in this argument is the assumption that socio-economic disadvantage has completely wiped out the ongoing reality of race disadvantage. Or, to put it another way, people think that when we’re talking about the black middle class, we’re talking about the same thing as the white middle class. People think that sons and daughters of people with a college diploma are going to have the same kind of life circumstances as sons and daughters of white people with, with diplomas. Nothing could be further from the truth. If anything, the most significant difference between African-Americans who are middle class and whites who are middle class, is the ten times wealth difference between one and the other. Let me put it another way. Whites who have basically the same income, still have between eight to ten times more wealth. Now, why is that important? Wealth is associated with everything that makes you competitive. It puts you in communities where you have the better schools. It puts you in health care situations where you have better care. It puts you in social networks where you hear more about what material you need to know, what opportunities are available for you. So the reality is that there is a lifetime of difference—

### Moderator
Claim: But, but return to the question—

### Scientific Advocate (SA)
Claim: …between being, between being—

### Moderator
Claim: Let’s narrow the question, doctors and lawyers, doctors and lawyers who have benefited from these programs, why should their children be beneficiaries of the same program—

### Scientific Advocate (SA)
Claim: And my, and my answer is, why shouldn't they be? What do we have to know about the lives of African-American middle class to come to the conclusion that perhaps one generation ago they were socio-economically disadvantaged, but this generation they're not? In every major statistical finding about the actual life circumstances of African-Americans, there are still a range of disadvantages that they face. Now, is it going to be the same level of Affirmative Action as someone who is, um, truly, uh, impoverished? Of course not. But most Affirmative Action programs don’t function that way. They give you benefits for both being socially, economically disadvantaged, and race as well. The point is, race still marks life of African-Americans.

### Moderator
Claim: Any comments on this from the—

### Conspiracy Advocate (CA)
Claim: Disadvantage—

### Moderator
Claim: Joseph Phillips.

### Conspiracy Advocate (CA)
Claim: Range of disadvantage, disadvantages, uh, do not come with a black face. Uh, and this is why earlier I said, we need to talk about people, because when we start talking in these broad terms, we’re talking about the black middle class, I happen to live in Los Angeles, down the street from Calabasas California, which is one of the wealthiest communities in America. I coach football, and I have black kids on my team with parents who make more money than most, half of everybody in here added up together. THE idea that, that these children are in need of preferences because they don’t have access, uh ,to, to the same, uh, benefits that their white counterparts, is just ridiculous. Because we’re not talking about individuals suddenly, we’re talking about people, um, generally, in term of their race. I also want to go back to, to address something else that was said, this idea of, of this testing. Look, right now, these are the tests that we’re using, and I want you to listen very closely, what we’re talking about, oh, the tests, uh, not the preparation, and on and on and this… The underlying message is that our kids can't compete, that my three sons cannot compete. And I don’t buy it.

### Conspiracy Advocate (CA)
Claim: Well, that’s—

### Conspiracy Advocate (CA)
Claim: If we want to get rid of these tests, then let’s get rid of them. Whatever standard we use, the standard should be applied equally to all kids—

### Conspiracy Advocate (CA)
Claim: Robert?

### Conspiracy Advocate (CA)
Claim: That's what we’re saying here.

### Conspiracy Advocate (CA)
Claim: Could I…?

### Moderator
Claim: Briefly from John McWhorter, and then a reply, perhaps, from the, uh… …the opponents. John McWhorter?

### Conspiracy Advocate (CA)
Claim: I think that one thing that we are leaving out of the discussion, and you have to bring it in, is that much of the reason that, uh, middle class black kids have trouble with submitting the same kind of file as a white kid would have, is a tendency among black teens to say that it is white to do well in school. There’s a myth nowadays, there is a myth nowadays that that has been disproven. And I’d like to try to be as pacific as possible here, pacific is the word I'm using, but here I can't, that’s a myth.

There are many studies, I’ve looked at all of them in detail, all of them show, even when they don’t think they're showing it, that there is a strong tendency for black kids to tease each other that way. There are reasons for it. But, the question is, how does, how do racial preference programs address that particular problem, which I think is addressable, and is being addressed by things that go on before kids go to college? We can't just leave that out of the discussion because the data is inconvenient, and I think it’s absolutely crucial to the things that we’re talking about.

### Scientific Advocate (SA)
Claim: Robert?

### Moderator
Claim: That’s John McWhorter, and we’ve heard several points made by the supporters of the motion, so to the opponents, and Tim Wise, yes?

### Scientific Advocate (SA)
Claim: I just, responding to the last thing John said, I think it’s interesting that he’s upset about, supposedly, ostensibly, middle class black kids saying that it’s white to be smart, and somehow that’s their pathology, and that’s the problem we should address. It’s an issue, we could discuss it at a different time. What I find interesting about it is that you, John, are affiliated with the Manhattan Institute, which has received money from the Bradley Foundation, hundreds of thousands of dollars. This is a foundation that paid Charles Murray to write The Bell Curve, which is a book that doesn’t imply that black people are inferior, it screams it from forty percent of its pages. So, when you say that black folks say being smart or doing well in school is acting white, the book, The Bell Curve, funded by the same people that fund the organization you work for, basically says the same thing, it says high IQ is white, or perhaps Asian, and black folks are genetically defective. I find it disingenuous for you to put the burden of that on black children, and not the very wealthy, well- heeled, well-funded white folks who actually print material that says black people are defective. And not one prominent conservative in this country, including the three of you, said anything public when The Bell Curve came out, not one word, not one prominent conservative. Let’s place our attention on those who actually say that white people are smarter, and black people are inferior, and you won't hear that from any of this.

### Moderator
Claim: John McWhorter?

John McWhorter, quick reply, then we’ll get another question. Yes?

### Conspiracy Advocate (CA)
Claim: Sir, when The Bell Curve came out, I was very young, I had no public presence, I was studying linguistics, and so I don’t know what I would have said. To the extent that Bradley funded that book, which I frankly did not know, and that they fund some work that the Manhattan Institute does, that’s certainly true. Charles Murray has nothing to do with the Manhattan Institute, and stopped, as a matter of fact, while he was writing that book. And what I'm funded for doing at the Manhattan Institute is things like working on prisoner re-entry programs, et cetera. But what’s important is that when I talk about the “acting white” phenomenon, I'm not saying that it’s a pathology, I'm not blaming the black kids for this, this is something that happened as the result of a sequence of socio-historical things that ultimately have their root in racism. Nevertheless, it is there today, and I don’t think that it can be denied. And the issue is to treat it, and to show black kids that there are different ways to think along those lines.

### Moderator
Claim: OK, well enough about those other institutions, and uh…

Back to questions from the audience. Sir?

### Moderator
Claim: Yes, thank you. Um, let’s say that it’s irrelevant what Harvard and Yale do as private institutions, and I don’t care if they're one, two-headed people, it doesn’t mean anything. We’re in New York City, the home of City University, a great publicly supported institution, supported by all the tax payers of New York City, the sons of cops and transit workers, teachers, retail people, garment salesmen, everybody. A publicly supported institution, so that when you have racial preferences, you are discriminating against taxpayers. You are discriminating not against George Bush, not against the legacy kids, not against that. Taxpayers either have a right to have equal opportunity for their tax money to be used for their own purposes, that is to get their kids in school, or taxpayers ought to be denied that in favor of race and ethnic preferences. Justify your position, those of you who are against the motion, to the taxpayers of New York City when they want to send their kids to higher education.

### Moderator
Claim: OK, a distinction between public, taxpayer-funded, and private institutions. Time Wise?

### Scientific Advocate (SA)
Claim: Sure. City College used to have open admissions, because it recognized that its purpose was to serve all the citizens of the city of New York, and it did that for a while. A lot of white folks who wouldn't have passed any test actually went to City College under the era of open admissions. And yet, when all the sudden people of color began to, quote, unquote, flood, being the metaphor we often use, uh, that hallowed institution of higher learning, then all the sudden we started talking about standards, and criteria, and remediation, and these people aren't really qualified. I think what taxpayers ought to expect is open access and ability to get into institutions they pay for. Because to get rid of Affirmative Action at City College or any public institution is to say that people of color who pay taxes should not expect representation for the taxes that they pay. And the same is true in contracting, and the same is true in public employment. I think City College ought to have open admissions, it worked really well for a lot of white folks for decades, and I think it’s a really good idea for students of color as well.

### Scientific Advocate (SA)
Claim: And let me just add a, a—

### Moderator
Claim: Kim Crenshaw.

### Scientific Advocate (SA)
Claim: …a one point to the way that this convenience has done exactly what I have suggested that it would. When this proposal was put on the table, it’s talking about eliminating all Affirmative Action. It's not talking about eliminating just Affirmative Action that benefits African-Americans. It’s not talking about eliminating Affirmative Action in higher education. It’s talking about eliminating Affirmative Action in contracting, in employment, in education, that applies not just to African-Americans, but white women, and people of color as well. Let me, let me point out what difference it makes to have this convenience focus on African-Americans. Would any of this make sense if we were talking about white women? Would we actually say, well, you know, it turns out that the, uh, scores for white women actually over-predict their performance in law schools, because when they actually get to law schools, even though they're equally qualified, if you take these test scores as meaning qualification, they end up not scoring nearly as well as white men. Would we even suggest that? No, we would think that there is something going on in law school that actually has the effect of suppressing their performance. Would we talk about women’s cultural values? Would we talk about their work ethic? Would we talk about any of these things if we were talking about white women? No. Would we talk about any of these things if we were talking about Asian-Americans, or even Latinos? So, the reality is that we’re actually trying to attack a wide variety of programs by having a debate that’s as old as this Republic about the intellectual inferiority of African-Americans. I would submit that you should repudiate this proposition just because it’s not talking about the full range of Affirmative Action and the beneficiaries who are stake in this conversation.

### Moderator
Claim: Another question from the audience.

### Moderator
Claim: Given, this is a question for the people who are, who are for the motion. My first question is whether or not you agree that integrated educational settings, whether it be in K through 12 or higher education, are important. And then secondly, given the pervasive and serious inequalities that we see in K through 12 education by race, what it is that you propose to do to try and open up the pathways to those institutions?

### Moderator
Claim: Which of the supporters of the, of the motion—

### Conspiracy Advocate (CA)
Claim: I mean, I, look, I agree.

### Moderator
Claim: Terence Pell.

### Conspiracy Advocate (CA)
Claim: I think that, uh, there’s real value to integrated education, there’s value to diversity, but that’s really not what this debate is about. This debate is about one’s means used to achieve integration, one means used to achieve diversity. And the way it’s been used to achieve diversity is highly mechanical, and imposes a lot of costs on, uh, African-American students in particular. And what we’re saying is, you’ve got to look at those costs, you can't just sweep them off the table with this, you know, with rhetoric about the value of diversity. We all agree diversity is important. What we disagree about is the means used to achieve the, that diversity—

### Moderator
Claim: But is it, is it so important, that, that, indeed, if you came into a class, if you were teaching, and saw that, uh, all but one student in, in the room, everyone else is white, would you say, we should be doing something? Is it so important that we should go revisit other values we’re pursuing here, given the results I’m seeing? Or not quite that important—

### Conspiracy Advocate (CA)
Claim: I, I'm… Go ahead.

### Conspiracy Advocate (CA)
Claim: I was going to say, I'm glad you put that up, because I'm not convinced that diversity is all that important, uh, diversity in terms of skin color. I think that when we go to school, the people that we befriend, the people in our neighborhoods that, uh, that we hang out with, are people that we share values with. When you talk to college students, and people have been to college, and what was most important about their college experience, it had to do not with the color of the person sitting next to them, but the values of, of the teachers, and those kinds of things. Um, of course, I, you know, integration is a great thing. Uh, I'm for that. I'm for it when people want to do it. Um, am I, am I for people manipulating and forcing people? I don’t think that that’s a good thing, I don’t think that that’s, uh, I don’t think that that’s good for America at all. And I also want to make this point: uh, we talk about how great diversity is, and yet, the schools, who great diversity is for the educational benefits for our students, and yet the schools that are routinely churning out the greatest number of black doctors, the greatest number of black lawyers, are HBCU’s, which are not racially integrated at all: Morehouse, Spellman, Howard, et cetera. Ninety-eight, ninety-nine percent black. That is not, in my opinion, a bad thing. And if it is, then Tim, maybe we should make sure that we get a critical mass of white girls down at Spellman, and uh, be, be on our way—

### Conspiracy Advocate (CA)
Claim: Robert, can I interject something quickly—

### Moderator
Claim: HBCU being Historically Black Colleges and Universities.

### Conspiracy Advocate (CA)
Claim: Just real quick.

### Moderator
Claim: One very brief statement, and then if somebody wants to make a very brief statement from the other side, and then on to closing statements.

### Conspiracy Advocate (CA)
Claim: I think we have to be very careful with the words integration and segregation, as they happen to have drifted into certain implications in our time. Because often the way we’re using the word segregation today implies something I'm very uncomfortable with, which is that the only way that black people can really excel is if white people are around, and I'm not comfortable with that. And so we talk about schools, and for me, a dominant image is, for example, Kip Academies, where all the kids are black or brown and poor, and they're being taught very well by dedicated teachers, and there are new Kip Academies every year. And somehow, on the other hand, especially in academia, it seems that we’re supposed to keep talking about increasing segregation, as if segregation now is always the same thing as it was forty years ago, when actually a whole lot of black kids, poor black kids in a room together can learn very well. That excites me. It is peculiar to me how unexciting that seems to be found by a lot of—

### Moderator
Claim: I agreed to, I agreed to a brief statement—

### Conspiracy Advocate (CA)
Claim: That, thank you, that was it, that was it.

### Moderator
Claim: And one rebuttal, if you want to make it, form the side opposing the resolution.

### Scientific Advocate (SA)
Claim: Well, I guess the only thing that I'm—

### Moderator
Claim: Kim Crenshaw.

### Scientific Advocate (SA)
Claim: I want to point out to people in, in listening to this, is that this anti-Affirmative Action argument is really a Trojan Horse for a whole range of anti-integration, anti-civil rights, anti-equality policies. You’ve heard it, the bottom line is, this whole Brown versus Board of Education experiment, this whole idea of forced integration was a bad idea when it started, and it’s a bad idea now. So what this is, is a roll back. It’s not just about racial preferences, whatever you define that to be. It’s about what kind of society we really want to have. And this other side is happy to have societies, to have institutions that are racially separated, to have communities that do not interact with each other, and have all white institutions, all black institutions, and all Asians. That’s a roll back on the basic—

### Conspiracy Advocate (CA)
Claim: That’s a distortion—

### Scientific Advocate (SA)
Claim: …promise of the civil rights movement.

### Conspiracy Advocate (CA)
Claim: That’s a distortion—

### Moderator
Claim: Well, you’ll all have closing arguments in which to address—

### Conspiracy Advocate (CA)
Claim: I don’t think that that’s what I said—

## Round 3

### Moderator
Claim: …some of what you believe are the misconceptions you’ve heard about the other side. Uh, the final remarks from the panelists, uh, are two minutes a piece. At one minute I’ll say one, as, I’ll be as loud as I can in saying that, and then, uh, after that we’ll get to vote on who won the debate. First of all, closing statement, two minutes against the motion, Tim Wise. You can do it from your, these we can give from the desks, yes.

### Scientific Advocate (SA)
Claim: Great. Um, couple things. First of all, just to address something I think that was frankly disingenuous that was said by Terence Pell earlier, he said that his organization does not advocate no, uh, discrimination laws applying to the private sector. In May of 2004 I got on their web site, I was writing my book on Affirmative Action, it’s footnoted in my book, their statement of principles included the following: the Center for Individual Rights believes in the limited application of civil rights law and the right of private individuals to deal with others as they see fit. I'm not sure what that’s supposed to mean other than Woolworth’s gets to say, black folks don’t sit here, and cab companies don’t have to give rides. That’s what it suggests, that’s what it suggests. And you don’t have to like that that’s what it suggests, but that was what it said. Secondly, everyone up here on that side has said that Affirmative Action was legitimate in the old days, because of the existence of persistent racial discrimination. They’ve all acknowledged it. Which means we’re not debating a principle here tonight of color blindness in all cases, what we’re debating is the issue of facts on the ground.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: If the facts on the ground say that discrimination is still a significant problem, then by definition, by their own admission, the debate is over, and you have to vote for us. That’s not a debate trick, that's basically what they're saying. The only side that has presented any information at all tonight, let alone analysis, as to the existence of ongoing discrimination, is this side of the aisle, which means all of the things I said at the outset, about employment, about contracting, about education, an ongoing white racial preference has been utterly dismissed. If that still exists, their own standard of evaluation says that they lose and that we win. So just make sure you remember that when you punch those little buttons. The bottom line, and I'm going to quote, since I didn't get to ready my Reagan quote, I'm going to do this. I promise, if you cut me off, it’s, it’s it, it’s the quote. Ronald Reagan, when he was Governor of California, 1974, last thing he did as he left office was sign into law the Affirmative Action programs, and here’s what he said. He said, time and experience have shown that laws of anti- discrimination are not enough, justice demands that each and every citizen consciously adopt a commitment—

Great. Um, couple things. First of all, just to address something I think that was frankly disingenuous that was said by Terence Pell earlier, he said that his organization does not advocate no, uh, discrimination laws applying to the private sector. In May of 2004 I got on their web site, I was writing my book on Affirmative Action, it’s footnoted in my book, their statement of principles included the following: the Center for Individual Rights believes in the limited application of civil rights law and the right of private individuals to deal with others as they see fit. I'm not sure what that’s supposed to mean other than Woolworth’s gets to say, black folks don’t sit here, and cab companies don’t have to give rides. That’s what it suggests, that’s what it suggests. And you don’t have to like that that’s what it suggests, but that was what it said. Secondly, everyone up here on that side has said that Affirmative Action was legitimate in the old days, because of the existence of persistent racial discrimination. They’ve all acknowledged it. Which means we’re not debating a principle here tonight of color blindness in all cases, what we’re debating is the issue of facts on the ground.

### Moderator
Claim: Time!

### Scientific Advocate (SA)
Claim: …to Affirmative action—

### Moderator
Claim: And again—

### Scientific Advocate (SA)
Claim: …so as to make equal opportunity a reality.

### Moderator
Claim: You’ve run out of time.

### Scientific Advocate (SA)
Claim: Reagan was right, and they're wrong.

### Moderator
Claim: Thank you, Tim Wise, uh, for those closing remarks. You got your citation of Ronald Reagan in.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Uh, now, as a closing statement, two minutes for the motion, “It’s Time to End Affirmative Action,” from Joseph Phillips.

### Conspiracy Advocate (CA)
Claim: If white folks are so racist, if they come out of the womb hating black folks, why on earth would we trust them to run Affirmative Action programs designed to bolster the education of black students? That's what I heard him say. So what kind of society do we want? I have a little more faith in the American people than I think some folks on the other side do, because I think that the American people, they’ve spoken loudly in California, they’ve spoken loudly in Michigan and Washington, they will speak loudly in Arizona, and Colorado, and other states in the upcoming election, that they are in favor of integrated societies.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: The American people are in favor of equal opportunity. What they want is fairness. I think it’s quite a compliment that more and more people are saying, listen, they're, they're taking the words of my mother, and they're saying, listen, there is no monopoly on brain power. Black folks can compete, we want to give them the opportunity, and I think it’s about time.

### Moderator
Claim: Thank you, uh, Joseph Phillips, for that closing statement. Now a closing statement against the motion from Khin Mai Aung.

### Scientific Advocate (SA)
Claim: So, in talking about diversity and the benefits of diversity, now let, the other side makes it seem like we’re saying, well, you know, we want racially diverse classes because if you're black you come, you have a certain perspective and you're, you're expected to carry the mantle of that experience, same if you're Asian or, or white, or so forth… That, that’s not what we’re saying. There has been mountains of evidence about the benefits of a diverse educational environment, and a diverse workplace that was produced. In the University of Michigan cases it was produced before the court, and I'm sure that, uh, Mr. Pell’s organization fought that with the best arguments that they had, and the Supreme Court voted in favor of diversity. Also, with regard to the process that, um, educational institutions use to accept students, it’s a very, it’s a very flexible, individualized process that, that the type of admissions plan that was endorsed by the Supreme Court in the University of Michigan case is individualized, there are no quotas, it’s not mechanical.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: Because Mr. Pell’s organization actually won the case at the undergrad institution which, which found that the undergrad, um, policy at the time was too mechanical, so it’s a very individualized consideration. And, you know, the, the last thing I want to leave you with is, it’s what we call “The Causation Fallacy.” Even if, even without Affirmative Action, whites’ chances of admission only gets in, at our most prestigious, it only rises at our most prestigious institutions by one to three percent, according to that Bowen and Bok study, the one by the, um, the University Presidents. It only rose by one point five percent for the average white student. That’s because there’s a whole lot more white students than minority students that are applying. So, even without Affirmative Action it’s not going to increase a lot of people, it’s not going to increase any, any visual applicant’s chances of getting in by a whole lot. So, this whole, um, you know, thing about how every white student hat has been, um, admitted, or even every Asian student who, you know, sometimes believes that that’s the case, thinks that I would have gotten in if it wasn’t about Affirmative Action. That’s simply not true.

So, in talking about diversity and the benefits of diversity, now let, the other side makes it seem like we’re saying, well, you know, we want racially diverse classes because if you're black you come, you have a certain perspective and you're, you're expected to carry the mantle of that experience, same if you're Asian or, or white, or so forth… That, that’s not what we’re saying. There has been mountains of evidence about the benefits of a diverse educational environment, and a diverse workplace that was produced. In the University of Michigan cases it was produced before the court, and I'm sure that, uh, Mr. Pell’s organization fought that with the best arguments that they had, and the Supreme Court voted in favor of diversity. Also, with regard to the process that, um, educational institutions use to accept students, it’s a very, it’s a very flexible, individualized process that, that the type of admissions plan that was endorsed by the Supreme Court in the University of Michigan case is individualized, there are no quotas, it’s not mechanical.

### Moderator
Claim: Thank you, Khin Mai Aung, uh, for that closing statement against the motion. And now a closing statement in favor of the motion “It’s Time to End Affirmative Action” from John McWhorter.

### Conspiracy Advocate (CA)
Claim: I think that when we’re evaluating this debate, a crucial thing to realize is that there is no denial on any of our part that there is inequality in our society. This is the crucial point: looking at the nation that we’re in, looking at the history of the world, looking at the nature of our species, it is logically unclear to me that there ever could be a human society where the playing field is completely level. Now, we can work on things, but it’s always going to be imperfect, and it’s going to be imperfect enough to matter. You can be committed to social justice while realizing that because society cannot be perfect, what our job is, is to teach people who didn't come out with as many chips as we would have liked, to cope and do the best that they can despite the imperfections of the system. Now, somebody is down on the bottom, of course, I personally am in favor of there being help, of there being relaxation’s of standards, if necessary. But when this is simply a matter of skin color—

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …I think that we have departed from what the original intentions of these policies were. The issue is not waiting for there to be no inequality or discrimination, the idea is, when do you let it go, because there’s never going to be a society that’s completely without it. And in closing I would like to say that there is evidence pro and con for this, and I don't see on the other side any engagement with the con. There is an understandable sense that their arguments are God’s arguments, the only ones worth mattering, and that anybody who has different ideas is funded by sinister people, or has a different agenda, et cetera., et cetera. It’s not true. To be honest, I’ve studied their stuff. I know the pro. There are other arguments written by cogent people, many of them not conservatives, these people don’t see those arguments as worthy of engagement. Their case, therefore, is incomplete. I think you should vote for us.

I think that when we’re evaluating this debate, a crucial thing to realize is that there is no denial on any of our part that there is inequality in our society. This is the crucial point: looking at the nation that we’re in, looking at the history of the world, looking at the nature of our species, it is logically unclear to me that there ever could be a human society where the playing field is completely level. Now, we can work on things, but it’s always going to be imperfect, and it’s going to be imperfect enough to matter. You can be committed to social justice while realizing that because society cannot be perfect, what our job is, is to teach people who didn't come out with as many chips as we would have liked, to cope and do the best that they can despite the imperfections of the system. Now, somebody is down on the bottom, of course, I personally am in favor of there being help, of there being relaxation’s of standards, if necessary. But when this is simply a matter of skin color—

### Moderator
Claim: Thank you, John McWhorter. Now, final remarks against the motion from Kimberlé Crenshaw.

### Scientific Advocate (SA)
Claim: When Affirmative Action was withdrawn at the University of California at Berkley, and at UCLA, the participation of African- Americans and Latinos fell to levels that we haven't seen since 1968. When you think about whether you want to vote for this proposal, you should think about whether you're satisfied with that. When you think about whether you want to vote for this proposal, you should think about whether you're satisfied with the fact that women contractors lost a thirty-five percent share of the contracts that they had had in California as the result of 209. When you think about voting for that you need to think about women as well as people of color. Now, the other side says we don’t talk about some of this evidence. Let me tell you something I will talk about. They tell you that students who graduate from Spellman, who go to Morehouse, who go to Howard miraculously end up doing better than going to the elite institutions that they might otherwise have gotten into, they want you to think that the reason they do better there is they’re over there where they should belong, with all the other black people.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: What they're not telling you is that these institutions have had a track record, knowing how to encourage students, educate students to create an environment where students feel confident to do their best. So, rather than taking that as an indictment of the institutions that have taken qualified students and not allowed them to do their best, they follow the track, and the proven, uh, tradition of focusing on stereotypes about African- Americans. So, my point is, if you're unhappy with the inferences that are drawn from this position, if you're not a color- blind fundamentalist, who is not, like Condoleezza Rice, who is not, then you know that there is still work to be done in this society. You know that this inequality is something that has to be addressed, and you know that just like any other social problem we care about, like asbestos, it would be silly to think we’re going to solve asbestos by being asbestos-blind. It’s silly to think we’re going to solve the problem of race by being color blind.

When Affirmative Action was withdrawn at the University of California at Berkley, and at UCLA, the participation of African- Americans and Latinos fell to levels that we haven't seen since 1968. When you think about whether you want to vote for this proposal, you should think about whether you're satisfied with that. When you think about whether you want to vote for this proposal, you should think about whether you're satisfied with the fact that women contractors lost a thirty-five percent share of the contracts that they had had in California as the result of 209. When you think about voting for that you need to think about women as well as people of color. Now, the other side says we don’t talk about some of this evidence. Let me tell you something I will talk about. They tell you that students who graduate from Spellman, who go to Morehouse, who go to Howard miraculously end up doing better than going to the elite institutions that they might otherwise have gotten into, they want you to think that the reason they do better there is they’re over there where they should belong, with all the other black people.

### Moderator
Claim: Kimberlé Crenshaw, thank you very much. Now final remarks from Terence Pell, for the motion, “It’s Time to End Affirmative Action.”

### Conspiracy Advocate (CA)
Claim: Well, tonight all of us are gathered here to defend the principle of equality, and I think we do that with a sense that equality is under siege as never before, and that’s because real equality is never achieved, it’s always coming into existence. As our opponents say, there’s a lot of work to be done, and that’s true. But today, the challenge to equality doesn’t come from the political extremes, it comes from really the political middle. Moderates have tried to eliminate differences in achievement among black and white eighteen year olds by essentially engineering an admissions system that makes them go away, and with characteristic efficiency those preferences have been extended to every institution after, uh, undergraduate college, including professional schools and public and private employment. Though they aren't intended to do so, these policies perpetuate racial differences, and they corrode social bonds. They make it difficult for minority high school students to attend schools where their credentials would make them academically competitive.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: And that’s the point about the, uh, historically black colleges. It’s not that blacks ought to go to the HBCU’s, it’s that the white schools, the elite schools ought to learn from the way the HBCU’s run their admissions programs, they admit on the basis of merit, and it makes a big difference. The most troubling aspect about tonight’s debate has been the reaction of our opponents to efforts to disclose the problems and end these policies. Our opponents essentially demand that we continue to wink at real differences in qualification, and demand also that we remain discreetly silent about the predictable consequences of this winking. It’s time to put an end to race preferences, it may have been a good idea at one point, but it no longer serves a useful purpose. There are too many other important issues that we need to be talking about if we’re going to achieve real equality in our lifetime.

Well, tonight all of us are gathered here to defend the principle of equality, and I think we do that with a sense that equality is under siege as never before, and that’s because real equality is never achieved, it’s always coming into existence. As our opponents say, there’s a lot of work to be done, and that’s true. But today, the challenge to equality doesn’t come from the political extremes, it comes from really the political middle. Moderates have tried to eliminate differences in achievement among black and white eighteen year olds by essentially engineering an admissions system that makes them go away, and with characteristic efficiency those preferences have been extended to every institution after, uh, undergraduate college, including professional schools and public and private employment. Though they aren't intended to do so, these policies perpetuate racial differences, and they corrode social bonds. They make it difficult for minority high school students to attend schools where their credentials would make them academically competitive.

### Moderator
Claim: Terence Pell, thank you very much. That concludes the final remarks. It’s now time for you to decide who carried the day. Once again, please pick up the keypad that’s attached to the left armrest of your seat, and after my prompt, press one if you are for the motion, “It’s Time to End Affirmative Action,” two if you're against the motion, and three if you are undecided. Please cast your vote now. Fine. I’d like to, uh, thank the debaters and all of you in the audience for your good work, uh, and before I announce the results of the audience vote I want to take care of a few things. First, the next Intelligence Squared US Debate will be on Tuesday December 4th here at Asia Society and Museum. The motion to be debated then is, “Aid to Africa is Doing More Harm than Good.” It will be moderated by WNYC New York public radio’s Brian Lehrer, and the panelists for that next debate will be, for the motion, economist and president of the Free Africa Foundation, George Ayittey, Professor of Economics at New York University William Easterly, and writer and policy analyst David Rieff. Against the motion, co-founder and former president of Africare, C. Payne Lucas, deputy director of the UN Millenium Project and associate director of the Earth Institute, John McArthur, and Gayle Smith of the Center for American Progress. An edited version of tonight’s Intelligence Squared US Debate can be heard locally on WNYC AM 820 on Sunday November 25th at 8pm. These debates are also heard on more than eighty NPR stations across the country, please check your local NPR member stations listings for the dates and times of broadcast outside of New York City. Uh, copies of books by John McWhorter and Joseph Phillips are on sale upstairs in the lobby, and you can also purchase DVD’s from previous debates here tonight, or from the Intelligence Squared US web site. And now the results. Uh, after the debate, thirty-nine percent of you, uh, favored, were for the motion, “It’s Time to End Affirmative Action.” Uh, against, fifty-five percent. Undecided, six percent. The team against the motion carries the day, with an absolute majority, and a stronger increase. Congratulations, to the team against the motion, well done. And good evening.
