# Debate Transcript

Topic: Containment Is Not Enough: ISIS Must Be Defeated
Motion: Containment Is Not Enough: ISIS Must Be Defeated

Debate ID: 080915%20ISIS


## Round 1

### Moderator
Claim: And I want to bring out to the stage the gentleman who brought Intelligence Squared U.S. to-- he is co‐founder with his wife, Alexandra Munroe. Robert Rosenkranz-- brought Intelligence Squared after seeing it in London to the U.S. back in 2006. We've recently passed 100 debates. And they're because of his vision. So, let's please welcome Bob Rosenkranz. Thanks, Bob. And what we normally do in New York prior to the debate is we just talk for a couple of minutes, in which I'll ask Bob why we're doing this debate now, why the timing. Since I think it's in this case it's pretty obvious why we're doing it now, I'll ask you a slightly different question. Since you've been here this week and participating in the sessions, ISIS has come up a lot. For you, what did you pick up about the situation that you feel informs you as you go into this debate?

### Moderator
Claim: Well, I think one thing that, to me, was very interesting-- I've been to three Aspen Strategy Group sessions.

And in this one, there was far more humility, I'd say, than in any of the others that I've been to. I mean, people really feel like this is an area that is not well‐understood at all and a phenomenon that is not well‐understood at all, and in a very complex context. One of the striking things for me was just the opening event was a lecture by Bernard Haykel, a professor at Princeton, who kind of gave something of the historic and intellectual roots of ISIS. And I-- if I could, I'd just maybe summarize a--

### Moderator
Claim: Sure.

### Moderator
Claim: --couple of his points. First of all, the term "Islamic State" is exactly right. This is Islamic. Make no mistake. The administration doesn't like to use that term, but this is rooted in Islam. And it's rooted in a very highly technical, very literalist reading of the Qur'an.

And it's an attempt to really go back to the most triumphant days of the Muslim faith, which is the 7th to 9th centuries, right after the founding by the Prophet. So they are very fundamentalist. They are very serious about the religion. And there are a couple of major tenets. One is Sharia law. Two is the use of armed conflict as a way of creating a full expression of a Muslim society. The third is a notion of a caliphate, i.e., a state which is-- where all of the religious power and all of the political power is concentrated in one individual. And IS is such a state.

And it-- part of its appeal to people and the recruits that it gets is because of this almost utopian sense of trying to restore the past glories of Islam, which, according to them, have been lost through centuries of Western domination, corrupt government, and a deviation from the austerity, and the purity, and the discipline of the early religion. And that has a lot of appeal to people. So--

### Moderator
Claim: And I find it interesting. You say that in the panels, you found that the people we think of as experts were actually rather humble about their grasp of the situation.

### Moderator
Claim: Yeah. I mean, I think this came out of a culture that people are not familiar with. The tactics took people by surprise, the fast-- the speed in which they put together a powerful military machine took people by surprise. The complexity in which we're operating, with Saudi Arabia, with Turkey, with Iran, with the collapse of Syria.

I mean, there's just so many moving pieces that vary--

### Moderator
Claim: We just don't want debaters to be too humble when they get on the stage and try to defeat each other.

### Moderator
Claim: I don't think that's going to be a problem.

### Moderator
Claim: All right. With that, let's thank Bob Rosenkranz again and welcome our debaters to the stage. I just wanted to ask you, if you're not Tweeting, we'd love to have you Tweet. But otherwise we'd appreciate it if you could shut down your phones. I forgot, so I'm doing mine now, just because we have so many sensitive mics in the room that too many signals will wreak havoc with our microphones.

But we're going to now officially begin our live stream. I believe we're up and we're going to begin the taping for the podcast and the-- and for the radio show. So I just want to ask you spontaneously to give us a round of applause. Thank you. ISIS is not losing and that is the hard truth. This Islamist movement that is stunning and revolting the world by enslaving men and women and children and cutting off the heads of hostages while gaining more followers all the time, has shocked U.S. leaders with the speed of its conquest of large portions of Syria and Iraq. And yes, the U.S. has been bombing from the air since 2014, but that is a far cry from going all in against ISIS. Rather, to borrow a term from the Cold War, the U.S. strategy comes closer to something that was known as containment, the attempt to hem in an enemy to prevent its power and influence from growing in the hope that someday it will collapse from within.

And how much sense does that strategy make in the case of ISIS? Well, that sounds like the makings of a debate, so let's have it. Yes or no to this statement. Containment is Not Enough: ISIS Must Be Defeated. A debate from Intelligence Squared U.S. I'm John Donvan. We are in Aspen, Colorado, in partnership with the Aspen Strategy Group. We have four superbly qualified debaters on the stage who will argue for and against this motion: Containment is Not Enough: ISIS Must Be Defeated. As always, our debates will go in three rounds and then our live audience here in Aspen will vote to choose the winner and only one side will win. Our motion again: Containment is Not Enough: ISIS Must Be Defeated. Let's meet the team arguing for the motion. Please, ladies and gentlemen, welcome Michèle Flournoy. And Michèle, you're co‐founder and CEO of the Center for a New American Security.

You served in the Department of Defense during the Clinton administration and then in the Obama administration as under‐secretary of defense for policy. Recently the economist was saying that a president Hillary Clinton would have a great first hundred days in part because your nomination as defense secretary would probably go through without much opposition. But, you recently coauthored an op‐ed that was critical of the Obama administration's efforts to fight ISIS and I'm wondering do you think the Obama administration has heard you?

### Conspiracy Advocate (CA)
Claim: Well, I certainly hope so, but to be fair, you know, the administration has a lot on its plate right now. This little thing called the Iran deal, getting that through Congress, concluding an historic trade deal in Asia, but I'm confident that once those two things are taken care of this will move to the top of the president's nightstand reading pile.

### Moderator
Claim: And keep him up all night.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Thank you very much, Michèle Flournoy. Can you tell us, Michèle, who is your partner?

### Conspiracy Advocate (CA)
Claim: My partner is the brilliant Philip Zelikow.

### Moderator
Claim: Philip Zelikow, ladies and gentlemen. And, Philip, you are also arguing for the motion that Containment is Not Enough: ISIS Must Be Defeated. You're a professor of history at the University of Virginia and you have served as a counselor to the State Department and as Director of the 9/11 Commission. You've also served on the president's intelligence advisory board for both Presidents Bush and Obama, which might strike some listeners as odd, because we really want to know, is it common for somebody to advise presidents of different parties?

### Conspiracy Advocate (CA)
Claim: I'm afraid, John, it's not common enough, which is a shame, because I think presidents need all the help that they can get.

### Moderator
Claim: Well, I think a lot of people in this room have helped some of them out, actually, along the way, so they'll be listening closely. Ladies and gentlemen, the team arguing for the motion that Containment is Not Enough: ISIS Must Be Defeated. And now let's meet the team arguing against the motion. Please, ladies and gentlemen, welcome Anne‐Marie Slaughter. Anne‐Marie, you are president and CEO of the think tank New America and professor emerita of politics and international affairs at Princeton.

You are the first woman to hold the position of director of policy planning for the U.S. State Department. You've also served as dean of Princeton's Woodrow Wilson School of Public and International Affairs and we're curious whether your affiliation with the school named for Woodrow Wilson gives us a hint to your brand of state craft.

### Scientific Advocate (SA)
Claim: Well, it does, but it is coincidental and that even before I was dean I've always stood for a values‐based foreign policy on the grounds that when the United States acts as consistently as possible with our values, it advances our national interest and it augments our power.

### Moderator
Claim: Which I'm sure will inform your arguments today. And please tell us who is your partner.

### Scientific Advocate (SA)
Claim: The foreign policy analyst extraordinaire, Dov… Zakheim.

### Moderator
Claim: Ladies and gentlemen, the unforgettable Dov Zakheim. Dov--

### Scientific Advocate (SA)
Claim: It shows you how well we prepared.

### Moderator
Claim: You are also arguing against the motion that Containment is Not Enough: ISIS Must Be Defeated.

### Scientific Advocate (SA)
Claim: Not anymore.

### Moderator
Claim: In our three against one debate tonight,-- you're senior advisor at the Center for Strategic and International Studies and a senior fellow at CNN-- CNA corporation. I said CNN, but I meant CNA Corporation. You've served the Department of Defense in different capacities. You were its coordinator for civilian programs in Afghanistan. You were the chief financial officer and an under‐ secretary of defense. You are also a Vulcan, which is not in the Star Trek sense. Can you explain what a Vulcan is?

### Scientific Advocate (SA)
Claim: Yeah, there were seven of us, not including Mr. Spock, who advised George W. Bush when he was running for president. Of course, some people would say it would've help if Spock advised him, but the group was actually set up by Condi Rice, who is no stranger to Aspen, and it was named after the statue of the God Vulcan in Birmingham.

And since we had no say in it, we became Vulcans.

### Moderator
Claim: It's better than a Star Trek story, actually. Thank you very much, Dov Zakheim. And welcome to the team arguing against the motion. Now, this is a debate. It's a contest. It's a contest of ideas and logic and persuasion, maybe a little wit and humor, but at bottom the debaters here are trying to get our live audience here in Aspen to vote with them. By the time the debate has ended this audience will have been asked to vote two times, once before the arguments and once again after the arguments, and the team whose numbers have moved the most in percentage point terms between the two votes will be declared our winner. So let's have our preliminary vote. If you go to those keypads at your seat, just pay attention to keys number one, two, and three. The others are not live. It works like this. If you're for the motion and I'm going to state it, and listen carefully, because there's a negative in it, but you really want to be listening probably to the back end of it.

Containment is Not Enough: ISIS Must Be Defeated. If you agree with that push number one. If you disagree push number two. If you're undecided push number three. And we'll give that about 15 seconds and then lock it out. At the end of the debate we'll do the same thing again and we get the results in about 45 seconds to a minute. All right. Let's begin. Let's move on to round one. Onto round one, opening statements from each debater in turn, uninterrupted. They will be six minutes each. Speaking first for the motion Containment is Not Enough: ISIS Must Be Defeated, Michèle Flournoy. She is co‐founder and CEO of the Center for a New American Security and former under‐secretary of defense for policy. Ladies and gentlemen, Michèle Flournoy.

### Conspiracy Advocate (CA)
Claim: So I'm arguing for the proposition that ISIS must be defeated.

ISIS is more than a terrorist organization. It is a proto‐state, an ideological movement that is committed to undertake Jihad against anyone who rejects its abhorrent ideology. Its ultimate aim is to establish a territorial caliphate that stretches across the Muslim world. ISIS is brutal in the extreme. It has beheaded innocent civilians. It has burned a captured Jordanian pilot alive in a cage. It rapes women and girls and sells them into sexual slavery. It crucifies Christians. It desecrates and destroys Holy sites and antiquities. Over the last year ISIS has established a very substantial safe haven in Iraq and Syria, and it has recruited more than 22,000 foreign fighters from more than 100 countries. The scale and scope of this mobilization is unprecedented.

Thousands of these fighters have Western passports that would allow them to travel back to Europe and to the United States without a visa. ISIS-- its geographic ambitions are not limited to the Middle East. This is a globalizing movement. In the last year ISIS has sought to establish footprints in places from Libya to Afghanistan, Nigeria, the Caucasus, even Southeast Asia. Holding territory is critical to its momentum and its legitimacy. It has also established a global presence on the internet using online means to disseminate its propaganda, recruit and radicalize followers, inspire lone‐wolf attacks. Again, the scale is eye‐watering. 90,000 social media messages each day. 90,000 a day. In some ways, ISIS could become more dangerous than Al‐Qaeda. Al‐ Qaeda used to assert very strict control over who became an affiliate.

ISIS says, "Let a thousand flowers bloom. If we can inspire individuals to conduct attacks around the world, that's great.” In fact, 10 of the 11 attacks conducted in the West since May of 2014 have been by lone wolves. ISIS has also conducted attacks not only in the Middle East, but in Canada, Australia, France, Denmark, and yes, here in the United States. In all 50 states today, there are active investigations or arrests of ISIS. If ever there was a terrorist group that we must defeat, it is ISIS. Now, defeating ISIS will require an intensive-- more intensive and fully resourced campaign on the part of the United States and our international partners. We need to intensify our diplomacy and our military support to Sunni and other partners so that they can be empowered to defeat ISIS on the ground. Politically, that means we need intensified diplomacy to press the Shi'a government in Baghdad, to address Sunni grievances, to devolve more authorities and resources to the provinces, to move towards a more federal and just Iraq.

In Syria, we need a more robust diplomatic effort to set the conditions for what should eventually become a negotiated settlement that removes Assad from power. We need increased international engagement to try to keep the civil war in Syria from destabilizing neighboring states, like Jordan, and Lebanon, and Turkey. Militarily, in Iraq we need to provide more support, trainers, combat advisers, equipment, close air support, to local partners on the ground who can take on ISIS and take back territory. To be clear, I am not-- we are not arguing for a large‐scale U.S. military invasion of Iraq. We are not calling for a repeat of the Iraq War.

We are calling for intensified support to partners. In Syria-- we need to shift our emphasis to producing more support to some of the groups that are already having success on the ground, like the Southern Front and the Syrian Free Army. We also need to refashion our Train and Equip program to try to get towards the goal of a more viable alternative to ISIS in a post‐Assad Syria. Thinking globally, we also need to combat ISIS using the full range of tools that we've developed for counterterrorism, disrupting their financing, targeting their leadership, building their capacity of partners in other countries to try to keep ISIS from moving in. We need to work with private sector and NGO partners to combat them online. And we need to address some more fundamental conditions that create fertile soil for ISIS, such as poor governance and community grievance.

This will not be without risk. But I would argue, the risk of inaction are even greater. The other team will argue that containment is a better option. I will tell you that containment won't work. Containment means allowing ISIS to hold on to sanctuary. It means ISIS will be able to continue to plan attacks, recruit followers, inspire lone wolves. Containment would be a recipe for endless terrorist attacks in the West and instability in the Middle East. Is that a future we really want? It's not a future I want my children to live in. If there's anything we should have learned from 9/11, it is that we must not allow a terrorist organization like this to have sanctuary in the heart of the Middle East or elsewhere. Now is the time to do more, to act with our partners, to defeat ISIS. Thank you.

### Moderator
Claim: Thank you, Michèle Flournoy. And the motion is: Containment is Not Enough: ISIS Must Be Defeated.

And our next debater will be speaking against that motion, Anne‐Marie Slaughter. She is president and CEO of New America and former director of policy planning for the U.S. Department of State. Ladies and gentlemen, Anne‐Marie Slaughter.

### Scientific Advocate (SA)
Claim: So, I want to see the end of ISIS as much as anyone does. No one can watch the horrible things they do and not think that this is a terrible, terrible scourge and threat. And we have to end it. The question on the table is, "What is the best strategy to achieve that goal for the United States?" That's what we're debating. What is the best strategy for us? Now, our opponents are already fudging that question. Because the debate here is, do you use military force to drive them out of the territory they hold or do you contain them where they are?

And so, what you're hearing is they can't have sanctuary. Michèle Flournoy said very clearly-- they cannot have a sanctuary. Okay? What they have to convince you of is they have a strategy for how the United States can deny them-- can deny ISIS-- that strategy. So, let's just be very clear about what's on the table here. They have to convince you they have a strategy for the United States to drive ISIS out of that sanctuary, and somehow magically, without boots on the ground. But I'll leave that to them. So, they have to tell you what defeat is and how the U.S. can achieve it. Here's what we mean by containment. We mean stopping ISIS where it is. We mean critically breaking their narrative of victory. We all heard from Professor Haykel, who Bob Rosenkranz mentioned. He said, "Look, what is essential is that every time ISIS wins, they convince their supporters God is on their side."All right. It is a kind of end‐of‐days, millenarian-- "This is it. We're going to restore the caliphate. We're going to spread it across the world. And see, God is on our side because we have just taken another city." So, containment says you break that. You do not let them expand their territory and you do everything you can to stop the flow of recruits. So you stop them where they are. So, that's containment. It's not a do‐nothing strategy.

In fact, it's doing everything possible, and certainly, diplomatically everything possible. Digitally everything possible. In-- and militarily, stopping them from expanding where they are. It may also mean supporting our allies and friends in the Middle East to the extent they take the lead in wanting to push ISIS back. So that's containment. We're going to stop them where they are.

We're going to let their internal contradictions show themselves. We're going to let ultimately, as we have done before, for the older members of this audience-- we're going to let the ideology crumble itself. The alternative is roll‐back. Right? The alternative, as I said, is going in there and actually pushing them out of that territory. And I'm going to leave it to my partner, Dov Zakheim-- the brilliant Dov Zakheim. He's going to talk about why that's so hard militarily. But what I want to do is talk about why that won't work, why roll‐back won't work politically. And the first thing to say is we've seen this movie before. General Petraeus was on the stage two days ago, talking about how he had pushed Al‐Qaeda in Iraq out of Mosul. Al‐Qaeda in Iraq is not there, but guess who's back in Mosul? ISIS is there. This is Round 2. We have done this militarily before. That didn't work. And here's why, because it isn't just an idea.

It is not just a military question. ISIS is an ideology. Professor Haykel said on the same stage that, of course, defeat is desirable. But how do you defeat a set of ideas? So, the way we've done this before, when we were up against an ideology-- for most of my life, that ideology was Communism. Containment was the most successful strategy the United States has ever pursued. And it didn't mean not doing anything. And we had to use our military. And we used our-- diplomatically. But we contained the Soviet Union and ultimately, we let its internal contradictions destroy it. So, it's happened before. And it'll come again. Equally-- or more troubling is that if we inject ourselves, we confirm their narrative. Right? ISIS's narrative is that they are fighting the crusaders-- that's us-- the Zionists-- that's the Israelis-- and the Shiites and the Sufis.

So, the minute we put ourselves in there, we are confirming to them and everyone they want to recruit that this is indeed the millennial battle between the crusaders and the true defenders of Islam. We don't want to do that. The last reason that we need to pursue a containment strategy is this is a very long game. So, General Petraeus said two days ago-- and he was quoting General Odierno-- that this was a fight at least of a decade, if not a decade or two decades. So, 10 to 20 years. That's what are our generals are telling us now. That actually, I think, could be on the short side. So, remember your history and remember stories of monotheistic faith in which clerics had both political and religious power and were deeply, deeply corrupt and spawned a revolt that said you had to purify the church and ultimately that was the only way to reclaim the true religion.

Obviously that's the Reformation. It was just decades, it was centuries. This is a deeply internal Muslim fight. It is a fight for the soul of Islam. It is not our fight. It is the Muslim's fight. In the end we have to protect ourselves. We have to contain it, but we cannot win it.

Thank you.

### Moderator
Claim: Thank you, Anne‐Marie Slaughter. Your time is up.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm Jon Donvan. We have four debaters, two teams of two arguing it out over this motion: Containment is Not Enough: ISIS Must Be Defeated. You've heard the first two opening statements and now onto the third. Debating for the motion Containment is Not Enough: ISIS Must Be Defeated, Philip Zelikow. He is the White Burkett Miller Professor of history at the University of Virginia and served as the Director of the 9/11 Commission. Ladies and gentlemen, Philip Zelikow.

### Conspiracy Advocate (CA)
Claim: Tough issue, but I want to start where Anne‐Marie Slaughter left off. She said injecting the United States into this conflict confirms their narrative. As if we're not injected already? As if we're not conducting air strikes against them every single day? As if we're not, as the Deputy Secretary of State has said, "We've already killed 10,000 of their members, but it has not declined." In other words, we're already injected. We're already fighting, we're just not beating them. That confirms their narrative. That confirms their narrative of victory. Their crusaders attack us every day. That's the way they put it. And here we are controlling 20 cities, ruling millions of people, and enslaving more. Let's talk about what failure looks like. Sure, failure looks like hundreds or thousands of Americans dead after an attack that could come next month, next year, or the year after that.

The 9/11 attack that I studied gestated for three years before they laid waste to southern Manhattan. The people who carried out that attack migrated from Germany to Afghanistan nearly two years before the attack. They went there, by the way, thinking that they were going to go fight Russians in Chechnya, but the leadership found other uses for them. So failure looks like hundreds or thousands of Americans dead with more violence in Europe, but failure also looks like the descent of the Middle East into the full war of extremes in which its all against all, in which its Shia extremists supported by Iran and Sunni extremists for whom ISIS is the terrifying sort of purity and Lebanon crumples and Jordan crumples and Turkey begins to crumple, all already awash with millions of displaced people.

All are already failing to cope. Their societies already sagging under the weight of the burdens. Saudi Arabia destabilized as more and more Sunnis find that that's really the extreme version of their own ideology that they want to follow. Don't you think that that's the point that the U.S. has to reinvade the Middle East? That's failure. U.S. reinvasion of the Middle East is failure. That's the failure Michèle Flournoy and I are against. That's why you need to adopt this resolution and defeat ISIS so that we don’t have to reinvade the Middle East. What then does success look like? Success looks like defeating their message. What's their message? It's a message about power. We empower the weak Sunni Muslims and we empower them through the exclusive divine mission they hold and the terrifying sword they wield in the territory we rule, ruling despite the crusader's attacks against us. So what does success look like? It's Sunni Muslims liberating their own lands.

It's Sunni Muslims recovering self‐determination. So what's the strategy to do that? It's a political strategy first and foremost, because the public debate in America is mostly about should we do more militarily. That's wrong. Michèle and I both believe, know the strategy leads politically and it needs to be a strategy that appeals to Sunni Muslims, because they're the ones we want to do most of the fighting to keep Americans from having to do most of the fighting later on. Why will they fight? They will fight to free themselves, to free themselves from the Assad tyranny in Syria where we also must join that fight and end the Syrian Civil War, which is destroying the region and bringing it close to the brink of apocalypse. That's the kind of message that appeals to Turkey and brings them in on our side and units Saudi Arabia and the Sunnis of Lebanon and the millions of Syrians in refugee camps who want to return to their homes.

Because, you see, ISIS is not homegrown. ISIS are foreigners. The ISIS rulers in Syria are led by Iraqis and veterans of Saddam Hussein's gestapo and they recruit Uzbeks and Chechens to run their shock troops in Mosul. Many of the Iraqi recruits that they enslave into their service don't even understand the command language that they're hearing on the radio. So the political strategy is a self‐determination of Sunni Muslims. And the military strategy, advise and support so they can do the job, but it's a tough job. They have to retake cities. To do that kind of urban warfare requires just the kind of assets that only the United States has.

Think about urban combat and what you need, armored vehicles that aren't going to be blown up by an IED as easily, jammers to diffuse the IEDs, snipers who can provide over watch, communication so that you know what's going on in the block two blocks away from you, medivac capabilities that give you the confidence your wounded can be treated and helicopters and fires that can be brought to bear on the targets you see in front of you. Those are assets only the United States can provide, which gives them the confidence and the sense that we're in this with them that allows you to build a coalition founded on Sunni Muslims doing the job to liberate their own lands, because containment doesn't keep the U.S. out. It guarantees the U.S. is likely to come in. Anne‐Marie said it at last. Let ideology crumble itself. Did the Khmer Rouge crumble itself? No, the Vietnamese had to invade Cambodia. Did the Taliban crumble itself? Did al‐Qaeda in Pakistan crumble itself? Has the North Korean tyranny crumbled itself?

No. You have to beat terror with something else and in this case the something else is defeating terror where it has taken root in ISIS. Support the resolution.

### Moderator
Claim: Thank you. Thank you, Philip Zelikow. And the motion is Containment is Not Enough: ISIS Must Be Defeated. And here to make his opening statement against the motion and our final speaker in the opening round, Dov Zakheim. He is the Senior Advisor at the Center for Strategic and International Studies and former under‐secretary of defense. Ladies and gentlemen, Dov Zakheim.

### Scientific Advocate (SA)
Claim: Thanks very much and I really want to thank Phil, because he just made my argument. We have armed ISIS. What do you think they're using? American personnel carriers. American tanks. American ammunition. Why? Because we've done such a fantastic job training the Iraqis and we've been doing it for over a decade, and we've done an equally good job training the Afghans.

That's why they're doing so well. And in fact, if you look at who we've trained in Syria, we have a $500 million program that thus far has spat out 60 fighters, 60. That's less than that side of the room. Of which, and I hope this doesn't happen to any of you all, a whole bunch have already been captured. So let's step back and look at what it really takes to beat these folks and to do something other than to contain them the way my brilliant colleague, Anne‐Marie Slaughter-- laid out for you. You know, this isn't the first outburst of Islamic extremism. For instance, in the 12th Century there was a fanatical group that actually had the same ideology as these guys called the Almohads.

And how were they defeated? By massive forces of Christian troops coming down from northern Spain. In the 18th Century, the original Wahhabis who had made a deal with the first basically same kind of ideology. They were defeated by Turkish forces, and then we had the same sort of thing again in the late 19th Century when Lord Kitchener, then General Kitchener, amassed a huge force to defeat the Mahdi in Sudan. What's the common denominator? Lots of troops. Not a few thousand. Not a bunch of spotters, because oh, by the way, when the Israelis couldn't beat Hezbollah in 2006, they didn't have a problem with spotters.

And when we tried to bomb Vietnam to the Stone Age in the 1960s, with Rolling Thunder, we didn't have a problem with spotters. Spotters aren't the issue. The issue is, can you and are you willing to send in hundreds of thousands of troops? Do you think this country wants to do that? Do you think we even want to spend the money to do that? We're living under a strange thing called a sequester. Somebody was asked on television, "What's a sequester?" And he answered, "It's the capital of Portugal." People don't even know what a sequester is. But what it's done is limit our spending. And you talk to Secretary of Defense Carter and he rightly says he's being constrained all over the place. The president says it. So, where are we going to find the money-- even if we had the will, which I don't think we have-- to go and fund all these troops, or even to do what Philip says.

All the things you want to give these folks-- let's assume they don't fall into ISIS's hands. Where are we going to find the money for it? Do we have the will? Do we have the money? Do we have the staying power for that kind of thing? The only way you're going to stop these guys is if, indeed, they rot from within. That's the only alternative if you're not going to send hundreds of thousands of troops in. And to get them to rot from within, you have to contain them. You've got to keep them cooped up. And there are ways to do that. But we're not even in one mind as to how to right now. Yes, we love the Kurds, but we don't arm them. Yes, we want to work with the Turks, except the Turks have a different agenda. They want to bomb the Kurds, who we like. I mean, you need a scorecard to figure out who exactly is on your side.

How do you beat these people that way? The bottom line is-- unless we have a coherent major military strategy, the real alternative-- when you parse out all the stuff about what we can do right now, the real alternative is to keep them cooped up, to arm our friends, to figure out how to train those who will fight. And yes, the Sunnis might fight. But guess what? They haven't fought until now. We've been begging them for years. Saudi Arabia is fighting, except not in Syria, not in Iraq. They're fighting in Yemen. And they're not doing that hot a job there either. So, we have to figure out how to motivate those we want to work with us. And that's going to take time. And what do we do in the meantime? We've got to contain ISIS for as long as possible. And if we could beat the Soviet Union, I wouldn't bet the family farm against our beating ISIS.

Thank you.

## Round 2

### Moderator
Claim: Thank you, Dov Zakheim. And that concludes Round 1 of this Intelligence Squared U.S. debate, where our motion is Containment is Not Enough: ISIS Must Be Defeated. Remember how you voted in the opening voting rounds, and we're going to have you vote again after the third round of the debate. And again, reminding you that the team whose numbers have changed the most between the two votes in percentage point terms will be declared our winner.

Now onto Round 2. Round 2 is where the debaters take questions from me, address one another directly, and take questions from you in our live audience here in Aspen. The motion is this: Containment is Not Enough: ISIS Must Be Defeated. We've heard one team arguing for the motion, Michèle Flournoy and Philip Zelikow, arguing that ISIS is not Al‐Qaeda. ISIS is no minor league organization-- that containment would be a recipe for endless terrorist attacks, that success would be supporting Muslim groups inside the ISIS realm, who would themselves take on the battle of defeating ISIS.

And success would be the furthering of that effort with U.S. support, but not, they emphasize, with hundreds of thousands of U.S. boots on the ground. The team arguing against the motion, Anne‐Marie Slaughter and Dov Zakheim, they are arguing that containment-- by that, they mean stopping ISIS where it is, but they don't mean a roll‐ back. They charge their opponents with needing to defend roll‐back. That's what this debate is actually about. They say that containment is not doing nothing. But at the same time, if the United States were to get involved, it would strengthen ISIS's recruiting efforts, that every time we kill somebody in ISIS, it brings somebody new, and that it is naïve to argue that defeat cannot happen without bringing hundreds of thousands of troops onto the ground, that you cannot count on local forces to do that. I'm actually seeing a confusing amount of overlap between the two sides, in terms of the means that you would use to put your particular visions into play.

You're both talking about-- you're both talking about small numbers of troops to support. Definitely you would contain and stop. You would contain and, to some degree, move on. But I am somewhat confused by the team arguing for the motion, saying, "We don't want to put troops on the ground." Your opponents say, "Well, how else are you going to roll‐back?" So, I want to take that to you. I like the roll‐back question. You want-- if you want to take away the territory that ISIS has, which is its main asset, really-- it's what gives it the basis for claiming a caliphate, and its best advertisement for being authentic and legitimate to its adherents. If you're not going to take away their territory, what is it that you are going to be doing? Take that to Michèle.

### Conspiracy Advocate (CA)
Claim: I think that it's something that-- it's important to understand-- is in order to break their narrative of victory, you have to roll‐back territory. You have to take territory away from ISIS. And the way in which we're arguing to do that is to look to the actors who do have the political will to fight, but have not been given the support or conditions.

So, for example, this is not about trying to retrain a largely Shi'a Iraqi security forces to go into Sunni areas. What we need to do is, first, with a political strategy, push the Iraqi government towards a policy of inclusion of the Sunnis. If the exclusion and the persecution of the Sunni populations-- that has created the fertile soil for a group like ISIS to come in. They are willing to fight because it's their home territories.

But they need two conditions. One is they need to know that after they fight and shed blood to kick ISIS out, they will be in a different Iraq, that they will have some prospect for self‐governance and support, and that re‐inclusion in the Iraqi society. And number two, they have to know that they're fully supported, that we have their back, that someone has their back.

And here, it's not a matter of U.S., you know, brigades and divisions. It's a matter of giving them not only trainers on a base, but combat advisers who will help advise them when they're in contact with ISIS.

### Moderator
Claim: All right. Let's let Anne‐Marie Slaughter--

### Moderator
Claim: Air support--

### Moderator
Claim: Anne‐Marie Slaughter-- okay. Dov Zakheim.

### Scientific Advocate (SA)
Claim: Yeah. A couple of things on that. First, we've been promising this to the Sunnis for a long time in Iraq. Why should they believe us? Number one. We haven't done it until now. And who knows if we can do it?

### Conspiracy Advocate (CA)
Claim: Dov, that's not true. We did it in 2007 and 2008.

### Scientific Advocate (SA)
Claim: Absolutely right.

### Conspiracy Advocate (CA)
Claim: I saw it.

### Scientific Advocate (SA)
Claim: You saw it. And where are we today?

### Scientific Advocate (SA)
Claim: We walked away from it and--

### Moderator
Claim: Wait--

### Scientific Advocate (SA)
Claim: --the problem is--

### Moderator
Claim: Wait. Let's-- Dov, you go and then--

### Scientific Advocate (SA)
Claim: --this is problem is-- and this is our problem in the Middle East-- you know, remember we backed the Shah 1,000 percent? Ask the Shah where he is these days. Pushing up daisies. The fact of the matter is we have made promise after promise. And let me tell you something else.

This whole fight we have with the Israelis? Do you think the Arabs look at that and say, "My God. They double‐crossed Mubarak. They double‐crossed the Shah. They're double‐ crossing the Israelis. Can we really trust them?" Yes. You were right. What you did in '07 and '08 was absolutely right. What has happened since then? And by the way, let's look at Syria. Who did the Syrians want to fight first? ISIS or Assad?

### Moderator
Claim: Dov--

### Scientific Advocate (SA)
Claim: We--

### Moderator
Claim: Dov, 15 more seconds to relate this to the motion.

### Scientific Advocate (SA)
Claim: Absolutely. The point is that if you're talking about bucking up people to fight against ISIS, you don't have the people to buck up because we don't have the credibility to buck them up. Does that come to the point?

### Moderator
Claim: And you're saying that the roll‐back that they proposed, by using those forces, will not happen?

### Scientific Advocate (SA)
Claim: Can't happen.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: I would--

### Moderator
Claim: All right. Let me bring it to the other side, and then I'll come back to you, Anne‐Marie. Philip. Philip Zelikow.

### Conspiracy Advocate (CA)
Claim: We're not saying the status quo works. The resolution is not supporting the status quo.

So that's a-- but what we're saying is to change the status quo you have to lead with a different political strategy. So, that promises the Sunnis the self‐government. Yes, many of them feel betrayed. They feel betrayed because the U.S. did not have their back after 2008, for various reasons. And so, you have to give them a situation in which they are the dominant population in Syria. That's majority rule in Syria. And then in Iraq, therefore, a protected minority, up in the north and in the south. And that's doable.

In fact, the Iraqi prime minister, for the first time, with the council of ministers, has moved forward, with U.S. pressure, and the laws that would actually put in place the devolution of power down to the provinces to an unprecedented level combined with a constitution that would give those provinces the money proportionately to their population out of the Iraqi budget. Combine that with the kind of military support Michèle refers to and then you have a strategy that's realistic. But think about the alternative.

### Moderator
Claim: Okay, but‐‐

### Conspiracy Advocate (CA)
Claim: Do you give up on them and let it go?

### Moderator
Claim: Anne‐Marie Slaughter.

### Scientific Advocate (SA)
Claim: Phil, I feel like I'm back in 1965, although I was very young in 1965, but I really-- I feel like you're saying I'm sure we can find these folks and I'm sure they can fight our fight just as long as we give them what they need to do. And if they don't, well, we'll give them a little more and then we'll give them some advisors on the ground. And then guess what, because we really got to get this done because we really do have to roll it back, we're going to send in the troops. It's not as if the Obama administration is not pushing as hard as it can on the Iraqis to be inclusive. That has been our strategy. They're working as hard as they can.

It's not as if they're not trying to find people in Syria who will fight ISIL. It's not as if they haven't been pushing Turkey to fight ISIL. Everybody wants to fight ISIL, but they want to fight someone else more and we can't do it for them. Tom Friedman said, "Any strategy in the Middle East that starts with I, we, or us, is doomed to fail."It's got to be a strategy that starts with them, they lead, we stop-- we don't let ISIS expand, but they have to do the fighting and we can back them if they want to, but we're not going to roll it back.

### Conspiracy Advocate (CA)
Claim: But the point was can they fight? Yeah, they can fight. If you give them the kind of support, they've proven it. What they want above all is to fight to control their own homes. Is that a realistic goal? Yeah. That's a realistic goal. That's the goal of national liberation. That's not what we were fighting in Vietnam--

### Moderator
Claim: I'm having difficulty understanding where you two disagree with each other. Unless they're saying that your vision of for a long time leaving ISIS with the pieces of territory it has now is crazy because it's such a terrific advertisement for recruitment. They get their legitimacy as a caliphate from having the territory and they're saying the patience you're willing to show the situation is a crazy idea, which will lead to disintegration and ultimately an invasion.

I’d like you to take on that point, because I think that's where I see some disagreement. Dov Zakheim.

### Scientific Advocate (SA)
Claim: Well, first of all we're not talking about patience here. I thought Anne‐Marie laid it out very well. We do want to keep pushing them. Nobody said to stop even the bombing. We continue with that. We arm the Kurds. We do train. The point is all of that is not going to defeat ISIS. It's going to contain ISIS. That's the point and it's going to take time. It's going to take time to recover from the fact that since 2008 when you were last there and doing what you did, we are now in 2015. Seven years and by your own statement in those seven years we have not progressed. It takes time and you have to contain and do the things we're talking about and that you're talking about. I'm still convinced that the reason we sound so similar is they're making the best case for us.

### Moderator
Claim: Michèle Flournoy.

### Conspiracy Advocate (CA)
Claim: No we aren't.

### Moderator
Claim: Tell me why you're not.

### Conspiracy Advocate (CA)
Claim: I mean, I think that-- because I think Anne‐Marie said, containment is really holding them where they are and we are saying holding them where we are is not enough, because as long as they have the territory they have they will continue to have momentum. They will continue to recruit. They will have a basis from which to launch operations and eventually there will be attacks of significance on the United States. The containment is a recipe for increasing risk and cost to the United States.

So yes, the containment may be an initial phase on the way to defeat, but we have to proactively roll-- keep-- prevent them from spreading elsewhere and roll them back where they do spread. Not by going in by ourselves, all by ourselves, but by empowering the local populations who have the political will, the legitimacy, but maybe not the means and support they need to be effective.

### Moderator
Claim: And, Michèle, with a U.S. brand on that effort? And I ask that because you're opponents are saying the minute we see--

### Conspiracy Advocate (CA)
Claim: I don't think we need to have a U.S. brand. I think the most legitimacy-- the people we should be supporting in the fight against ISIS are the Sunni-- the vast majority of Sunnis in the world who are just as appalled by them and find them just as abhorrent as we do except they're living with them.

### Moderator
Claim: Oh, Anne‐Marie Slaughter.

### Scientific Advocate (SA)
Claim: That is the crux of our disagreement, right, that we're saying you hold them. We all agree on that. You're saying you can only win if you roll it back, but what you won't do is actually adopt the only strategy that would roll them back, which is massive U.S. troops, because we have been trying to get Afghans and Iraqis--

### Conspiracy Advocate (CA)
Claim: We have not adequately resourced--

### Scientific Advocate (SA)
Claim: --and Syrians and everyone else to fight for us and they won't do it in part because they've got other enemies, other concerns. We can't fight it for them, but you won't adopt the strategy that will actually get you to where you want to go.

### Conspiracy Advocate (CA)
Claim: There are two key flaws in this argument. First, we have not adequately resourced or tried advise and support. So before you get to that argument the only thing that will work is a U.S. invasion. Can we at least just try a proper strategy of advice and support? And give it a try because the second flaw in their argument is this, they assume that this is a stable equilibrium, that a devastated Syria with half the population displaced and millions of people in refugee camps in all the surrounding states-- that can be stably maintained for who knows how long to come. They can just stand on that tightrope for hours and hours. We're saying they know they can't stay on that tightrope. Eventually they're going to fall off that tightrope and then you ask yourself which way do you think that goes as the Middle East descends into all out religious war.

### Scientific Advocate (SA)
Claim: Look. Look. Resources, $500 million bucks to train 60 people. That's a tremendous payout.

### Conspiracy Advocate (CA)
Claim: Because we wouldn't fight Assad. That's why we could attract new recruits.

### Scientific Advocate (SA)
Claim: Okay. So do you want to fight Assad? Now you want to fight a two‐front war.

### Conspiracy Advocate (CA)
Claim: --Syrian civil war.

### Scientific Advocate (SA)
Claim: You want to fight both sides. That's great. Well, I hope we figure out which side we shoot at first.

### Conspiracy Advocate (CA)
Claim: That's how you bring the Sunni coalition together.

### Scientific Advocate (SA)
Claim: Hang on. You want to put-- first of all, how much money should we fund the Saudis whom we want to fight for us? I mean, the last time I checked they weren't going around with a tin cup.

### Conspiracy Advocate (CA)
Claim: That's not what we're arguing, Dov.

### Scientific Advocate (SA)
Claim: So it's not the Saudis. It's not the Emirates. It's just these people themselves. Again, how did the Iraqi Army that we were training, and we poured billions into these guys, what a great job they did. So they weren't fighting for their homes, you say. Okay. What do you think would happen if we poured billions into the Sunnis in Iraq? Do you think the central government would let us? They won't even let us pour money into Kurdistan. So you really think they're going to let us pour money into the Sunnis?

And one other thing, you're making the assumption, and you've said it, the Sunnis are appalled. I don't know that the Sunnis are appalled. I know that English‐speaking Cambridge and Oxford educated Sunnis are appalled. Absolutely right. I will not quarrel with you, but how many people are funding these guys? This is just like the Canadian IRA--

### Moderator
Claim: Okay. You get to the argument--

### Conspiracy Advocate (CA)
Claim: Frankly you get to a tangle. It's just so hard. They're so mixed up. Let's just leave them be and it'll be okay.

### Scientific Advocate (SA)
Claim: We're not saying leave them be. And even if we we're still not saying leave them be.

### Moderator
Claim: Wait. Wait.

### Conspiracy Advocate (CA)
Claim: When this region disintegrates you don't think we will be called back in? Do you think the day after a thousand Americans are killed in a mass casualty attack that the president-- you're going to go to the president of the United States and just tell him doing more about it is too hard? I went through 9/11. I saw what happened after 9/11. saying Afghanistan was the least accessible place on earth for U.S. forces, but man, it was not too hard after 9/11.

### Moderator
Claim: Anne‐Marie Slaughter.

### Scientific Advocate (SA)
Claim: Wait a minute.

### Scientific Advocate (SA)
Claim: Can I just say--

### Moderator
Claim: Dov. Dov. Dov. Dov. Anne‐Marie Slaughter is talking now.

### Scientific Advocate (SA)
Claim: All right. So,-- all right. I'm not going to go back to 9/11. I want to go back to the Sunnis and what they want to do. We've heard over the past two days from Professor Haykel, again, somebody who spent his entire life studying Islam, studying Sunni Islam, studying the theology. He estimates that roughly half of the Saudis, half of the Saudis, actually are sympathetic to ISIS. He says that the Saudi government will not send its troops against ISIS because they are co‐tribes people and so that they are worried that the Saudi military will not fight against their co‐tribes people.

### Conspiracy Advocate (CA)
Claim: We're not asking for the Saudi military to come in and fight in Iraq and Syria.

### Scientific Advocate (SA)
Claim: Well then who are we asking to fight?

### Conspiracy Advocate (CA)
Claim: We're asking for the support to the Sunnis who live in Iraq, who want to be self‐ governing and to be included in the Iraqi society. Look at the number of Sunni groups on the ground who are fighting ISIS now in Syria without adequate support. No one's talking about bringing in the Saudi Arabian military or the UAE. We're talking about helping the people who live on the ground in Iraq and Syria to reclaim their own lives and communities and—

### Scientific Advocate (SA)
Claim: ‐‐so the very people that the Iraqi government--

### Conspiracy Advocate (CA)
Claim: Should we just let them go?

### Scientific Advocate (SA)
Claim: No, but--

### Conspiracy Advocate (CA)
Claim: Fifty percent of the Saudis now sympathize with ISIS. That's the product of the status quo and we should therefore say gee, this really is too hard. I guess Saudi Arabia is going to go down the tubes, too? Where do you stop this?

### Scientific Advocate (SA)
Claim: Phil, you said--

### Conspiracy Advocate (CA)
Claim: Dov Zakheim was talking about--

### Scientific Advocate (SA)
Claim: --the Saudi government was--

### Conspiracy Advocate (CA)
Claim: So--

### Scientific Advocate (SA)
Claim: --going to fight them.

### Moderator
Claim: Dov, take it.

### Scientific Advocate (SA)
Claim: You're letting me talk.

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: The--

### Moderator
Claim: I've let-- I think there's been a fair amount of Dov Zakheim letting talk and going on--

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: So--

### Scientific Advocate (SA)
Claim: Thank you very much, Mr. Moderator.

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: I happened--

### Moderator
Claim: Mister--

### Scientific Advocate (SA)
Claim: --to be in the Pentagon when they were picking up body parts in 9/11. So, I don't need to be lectured about 9/11. Look. Do you honestly think that even if we got rid of ISIS, we would get rid of a 9/11? There was no ISIS in 9/11. And Al‐Qaeda is still there. And there are all these franchise terrorist groups-- some of whom call themselves "ISIS," some of whom don't, who could-- who are just as intent on going after us. That is not the issue. To throw up the bugaboo of some individual bomber going after us, and therefore, we somehow defeat ISIS-- it just doesn't work.

### Conspiracy Advocate (CA)
Claim: But this is where I--

### Moderator
Claim: I'm going to let Michèle answer, and then--

### Conspiracy Advocate (CA)
Claim: --I am bothered by--

### Moderator
Claim: --I'm going to go to-- Michèle, can you hang on just one second?

### Conspiracy Advocate (CA)
Claim: I'm sorry.

### Moderator
Claim: I'm going to let you answer. I just want to go to questions from you after that. And when that comes, the lights will come up. The way it will work-- just raise your hand.

Stand up. A mic will be brought to you. Please wait for the mic before asking your question. Go ahead, Michèle Flournoy.

### Conspiracy Advocate (CA)
Claim: You know, you're right in the sense that there will always be violent extremists of one sort or another. What we need to focus on is trying to address the conditions that make whole communities vulnerable to being with them. And there, we have an approach that has not been tried and has not been fully resourced to do that in Iraq. And I think that's a much harder problem in Syria. But there are things that we have not tried that can also do that in Syria.

And so, I think getting wrapped around the axle about how much military intervention are we talking about is a very important question. But the fundamental issue is what can and should we do to address those fundamental conditions, because if we don't address them, this threat will reach out and touch America.

### Moderator
Claim: But do you really disagree with that statement?

### Scientific Advocate (SA)
Claim: No. I mean, no-- there is-- I don't think there's anyone in this entire audience who has fought as hard as I have, over the past three years, to try to use force to bring the civil war in Syria to a political conclusion.

So, we are-- you know, if it's a question of what do we do to end the civil war in Syria, I've got a whole another strategy. But what we're talking about here-- of course we're with you in terms of pushing the Iraqi government to be more inclusive. We're with you diplomatically. We're with you again on the digital strategy, which is a huge piece of ISIS. What we're saying, though, is-- what you're saying is we have to push them out of the territory they hold. And we are saying there is no way to actually do that that does not actually involve massive U.S. troops on the ground, and that we can talk about supporting others. We've been trying that for a long time. That's not going to get us there.

### Conspiracy Advocate (CA)
Claim: Did your Syria-- did your strategy to intervene aggressively--

### Moderator
Claim: Philip Zelikow.

### Conspiracy Advocate (CA)
Claim: --to end the Syrian civil war require lots of U.S. troops on the ground?

### Scientific Advocate (SA)
Claim: No. It did not. It required--

### Conspiracy Advocate (CA)
Claim: So, you ought to just come on over here now.

### Scientific Advocate (SA)
Claim: No. Nope. Nope. But we'll-- that's a separate debate.

### Moderator
Claim: Let's go to questions. Right down in front here. Please stand up and let the mic come to you. And if you could tell us your name as well. It's coming from-- it's coming down the aisle, behind you, to the right.

### Moderator
Claim: This is Peter Feaver. And I have a question for the nattering nabobs, the negativism, over here on this side. You've invoked the example of containment. But the only example of it working in history that you've mentioned is against a superpower, the Soviet Union. Can you tell me a time when containment of a terrorist organization worked? And if you're willing to do the Soviet Union containment model, are you willing to continue with, leader‐to‐ leader, summits between the-- Baghdadi and maybe even ping‐pong diplomacy with-- how far down the containment--

### Moderator
Claim: Okay.

### Moderator
Claim: --a‐la Soviet Union are you willing to go?

### Moderator
Claim: Thanks. Good question.

### Scientific Advocate (SA)
Claim: Yeah. Sure.

### Moderator
Claim: Anne‐Marie Slaughter.

### Scientific Advocate (SA)
Claim: So, you just-- you thought we were containing a superpower. We were not. We were containing an ideology.

And what is vital about understanding ISIL is it's just the latest manifestation of an extremist ideology that says, "The only way to purify Islam," just as once there were arguments about the only way to purify Christianity, "is to revert to an extreme version of the religion." So, the beginning round of this is 1979, with the attack on the great mosque in Mecca. And similarly, actually, the Iranian revolution. Then you see the Taliban. Then you see Al‐Qaeda.

Then, as you've heard, you see Boko Haram. You see manifestations of what is a decades‐long fight. The Arab Spring is another version of it, that says, "This religion is deeply, deeply corrupt. It is impossible to have a decent government. We want to purify the religion and we want decent governments. And it's just going to keep happening until Muslims fight it out. And our argument is we can contain it. We obviously have to protect ourselves. But we are not going to be the ones to actually win this fight.

### Moderator
Claim: I want to let the other side respond to the initial question, if you would like to. Michèle Flournoy.

### Conspiracy Advocate (CA)
Claim: I think the-- you know, the reason why-- one of the reasons why containment works, vis‐a‐vis a superpower in a state like the Soviet Union, was because it was coupled with a robust policy of deterrence and the threat of massive retaliation. These concepts are not operative when you're dealing with ISIS. What are we going to do to deter-- I mean, ISIS-- deterrence of the Cold War sort does not operate when--

### Scientific Advocate (SA)
Claim: Sure it does.

### Conspiracy Advocate (CA)
Claim: --you're dealing with a transnational terrorist organization.

### Conspiracy Advocate (CA)
Claim: What's an example of what's worked with a terror organization?

### Scientific Advocate (SA)
Claim: Quite the contrary. The example is, as we've also heard from the experts on ISIL, is that ISIL thinks that Al‐Qaeda's strategy was a failed strategy because they caused a catastrophic attack and precisely because we then went in and wiped them out.

And their strategy is not to do that. So, we of course are still going to protect ourselves. If there is such an attack, we are going to respond. And then the American people will support sending in troops. And we will do what we have to. But our point is that is not their strategy. Their strategy is to hold territory. We're going to contain them there and ultimately let the Muslims fight it out.

### Conspiracy Advocate (CA)
Claim: You know, it's interesting--

### Moderator
Claim: Philip Zelikow.

### Conspiracy Advocate (CA)
Claim: --when someone said today that, "Maybe we didn't need to worry so much about a catastrophic threat," it turned out that the recently retired head of the British Secret Service was at the table. And he said, "When I was listening to you say that, I was thinking that neither I nor any leader of any security service I know of would have understood what you are talking about." If the-- the threat picture that they are seeing, the threat picture that caused the director of the FBI to publicly say two weeks ago that ISIS is now the leading threat on his agenda, the reason the FBI has been picking up ISIS supporters in all 50 states of the United States during the last month-- that's because of the threat picture that they are seeing.

And that's this year. That's not 2016. That's 2017. You just think about the way this develops in time, because this is a much larger safe haven than Al‐Qaeda ever had.

### Moderator
Claim: A question down front here. And the mic is coming down this way.

### Moderator
Claim: My name is Ayaan Hirsi Ali. And Michèle and Philip, you made a fantastic moral case to defeat ISIS. And I completely agree with you. Last year this time, September, our president stood in front of the world and said, "We're going to degrade and defeat ISIS." Our vice president told the world, "We're going to chase them to the gates of hell."You made a fantastic case. And I'm with you. I voted for it and I think I'll vote for it again.

### Moderator
Claim: I need you to--

### Moderator
Claim: But there's a question--

### Moderator
Claim: I-- here's a question.

### Moderator
Claim: Yes. And here's the question. And the question that you have to answer and you have to deal is really, is this debate about ISIS or is it about American leadership? Is the United States of America prepared to take the lead in this? And for the two of you, what case would you make to the presidential candidates and to the American people to take that lead and keep that lead?

### Conspiracy Advocate (CA)
Claim: I think the –

### Moderator
Claim: Michèle Flournoy.

### Conspiracy Advocate (CA)
Claim: This is about both. I think we have to make the case that ISIS is a threat that will directly, touch-- threaten Americans, whether we want that to be true or not, and that the kind of political strategy, the kind of coalition, the kind of effort that is going to be needed to actually turn the president's and the vice president's words into actions-- which has not fully happened yet-- that will require U.S. leadership.

And nobody else but the United States can lead that coalition to beat this organization.

### Moderator
Claim: Okay. The other side does not need to respond. Right down in front there, sir. And the mic is going to come down-- you see.

### Moderator
Claim: Great debate. Graham Allison. If this is such an imminent threat, why is it that our Israeli allies are so relaxed about it? We have a track two conversation‐‐

### Moderator
Claim: You actually did ask a question. That was perfect. So I'm going to go with that-- because I think these people know the background on it. So I'll take it to Anne‐Marie Slaughter.

### Scientific Advocate (SA)
Claim: So, I would ask exactly the same question.

I mean, Israel's our closest ally in the Middle East. They are certainly every bit as much enemies of ISIS as we are. As I said, ISIS fights the crusaders, the Zionists, the Sufis and the Shiites and, yes, Israel looks at this, I think, and understands that to get in there to the extent that it would take to roll them back from their territory is immediately to strengthen them, because then they're fighting the Zionist enemy and so I-- I think Israel is very wise on this.

### Moderator
Claim: Response from this side? Phil Zelikow.

### Conspiracy Advocate (CA)
Claim: The presumption that Israel is relaxed about ISIS-- which would-- you know, any member of ISIS if he were to encounter an Israeli citizen in ISIS territory, there's going to be a really gruesome video the next week, okay? So the notion that‐‐put yourself in Israel's position. They have a lot of things going on in their world right now. Palestinians. They're attacking Hezbollah in Syria, which is also fighting on Assad's side.

So, the notion that gee, let's see if we can attack and bomb ISIS so that Jewish airplanes are bombing ISIS and that helps us recruit Sunni Muslims? So I think the Israeli's have kind of figured out that that's not the path to a successful coalition strategy to defeat ISIS.

### Moderator
Claim: Hang on just one second. I'm going to let you respond. Okay. Somebody needed I thought to tell me something. They want me to point to her. Anne‐Marie Slaughter.

### Scientific Advocate (SA)
Claim: Maybe the other reason the Israeli's are not quite so upset is that ISIS is actually attacking both Hezbollah and Hamas.

### Moderator
Claim: Let's go to another question. Down front here. Sir, if you could stand up. The mic's coming. Yeah.

### Moderator
Claim: Stefan Edlis Short statement.

### Moderator
Claim: Very short, please.

### Moderator
Claim: Very short.

When the Irish-- excuse the expression, not Irish, but the Arab Spring.

### Moderator
Claim: I want to know the free association that got you there.

### Moderator
Claim: They were secular. It turns out to be they're actually a religious revival. So, a religious revival. My question is very simple directed to you. Where would the money come from to undertake that gigantic effort that you propose?

### Scientific Advocate (SA)
Claim: Well, as I said, I don't think--

### Moderator
Claim: Dov Zakheim.

### Scientific Advocate (SA)
Claim: --I don’t think that right now we have the national will to do this and frankly even if we started spending the money and, you know, we do spend money on these sorts of things, this takes time. In effect what you're doing when you-- if we were to do what you suggest, we would be containing them.

We wouldn't be rolling them back at that point. They wouldn't lose an inch of territory because of that. It takes time. If you want to undermine them this is one of the ways to do it. What you're talking about is radio‐free Europe, voice of America updated to 2015.

### Moderator
Claim: Michèle Flournoy.

### Conspiracy Advocate (CA)
Claim: The administration, the Obama administration, has very successfully put together a 60‐ nation coalition, but what we haven't yet achieved is a coherent strategy where everybody's pulling in the right direction, the same direction. One of the things that our partners need to be convinced of is the degree of U.S. commitment. I think if the U.S. shows that commitment we have a lot of leverage to get others to be using the money they're already putting in to this theater in a much more productive and effective manner. So, we're not going to be funding this alone. We have 60 nations signed up to help. What we have to do is use our commitment to better leverage and focus-- to better focus the efforts of the whole coalition, and we have not done that.

### Scientific Advocate (SA)
Claim: With respect, you earlier said we don’t want to rely on the Saudis. We want to rely on the locals.

### Conspiracy Advocate (CA)
Claim: No, I said I don't want to have Saudi forces coming into Iraq and Syria.

### Scientific Advocate (SA)
Claim: Okay. Well, our--

### Conspiracy Advocate (CA)
Claim: That's different than asking the Saudis to help fund a proper strategy that we have helped to put together.

### Scientific Advocate (SA)
Claim: But part of our-- is our coalition only for funding? Is that what we're doing here?

### Conspiracy Advocate (CA)
Claim: No. Of course not. There are other things as well, but do you think--

### Scientific Advocate (SA)
Claim: Well, what are those other things?

### Conspiracy Advocate (CA)
Claim: --it's a smart idea to put Saudi forces in Iraq and Syria? I don't.

### Scientific Advocate (SA)
Claim: I'm not the one suggesting it. You're the one suggesting it.

### Conspiracy Advocate (CA)
Claim: No I didn't suggest it. You put words in my mouth.

### Scientific Advocate (SA)
Claim: All I'm saying is you said that it's the local forces and now you've got a 60‐nation--

### Conspiracy Advocate (CA)
Claim: Local Syrian and Iraqi forces fighting--

### Scientific Advocate (SA)
Claim: Right, and now you're talking about a coalition that's doing what?

### Moderator
Claim: I want to saying something. I want to remind you that we're in the question and answer section of this Intelligence Squared U.S. debate.

### Scientific Advocate (SA)
Claim: I answered the question.

### Moderator
Claim: I want to remind you that we're in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters.

Two teams of two debating this motion: Containment is Not Enough: ISIS Must Be Defeated. Let's go to another question, sir.

### Moderator
Claim: I am David Petraeus and I-- and I rise to take slight issue and ask a question of my friend, Anne‐Marie Slaughter. Anne‐Marie, you stated that the surge didn't work. With great respect, I was there and actually-- actually it worked pretty extraordinarily. I mean, driving violence down by 85 to 95 percent. Phil remembers. He was in the administration. We achieved all the objectives. By the way, Ambassador Crocker is back here, for whom I was privileged to be the wingman as he pursued the diplomatic efforts. The results were sustained, in fact, for three and a half years after the drawdown of the surge forces until Prime Minister Malaki undid them and all that we and Iraqi forces achieved, and he alienated the Sunnis.

So, the point here is that he undid the political bargain that was reached during the surge. The further point is that the center of gravity of the fight against ISIS is not in the frontlines it's in Baghdad in Iraqi politics and indeed in various Syrian locations--

### Moderator
Claim: Wait. I have to stop you. I'm giving you a lot of leeway because of your service, but ultimately democratically I need to ask you to ask a question.

### Moderator
Claim: Okay.

### Moderator
Claim: Pop it.

### Moderator
Claim: The question. Can you be confident, Anne‐Marie, that allowing ISIS to continue to control large areas of Syria, i.e., just containing them, and Iraq, can allow the new political discussions that are so important in ensuring multi‐sectarian and multi‐ethnic populations that they can enter into the new bargains in the shadow of areas from which contained, but undefeated ISIS extremists will continue to project violence seeking to spread the horrific humanitarian situation and geopolitical Chernobyl that is ‐ ‐ Syria.

### Scientific Advocate (SA)
Claim: Dave. So, General Petraeus, even-- so, General Petraeus, even though we are both proud graduates of the Woodrow Wilson School, I could not quite keep all of that in my head at one moment, but what I will say is I did not say that the surge was not successful. The surge was successful and-- no, I did not. I said it was--

### Moderator
Claim: I-- again, I don't want the audience debating with the debaters, so the floor is yours.

### Scientific Advocate (SA)
Claim: It was absolutely successful and then you left and then we left and then the Iraqis did not do what they should be doing to liberate their own country on their own and we are back here again. As you said from the stage, I was there. We liberated Mosul, but Mosul is now once again under ISIL control or under a violent extremist Islamic group.

So that's exactly what I'm saying. If we could keep David Petraeus on the ground in Iraq working with Chester Crocker advising the Iraqi government every step of the way, yes I think we would succeed. My point is we are not going to do that and because we're not going to do that trying to do it one more time we just do it round and round and round and we do not ultimately do what we need to do to let this fight play out as it's going to play out on its own. I'm sorry.

### Moderator
Claim: Michèle Flournoy.

### Scientific Advocate (SA)
Claim: Ryan Crocker I’m having terrible time today.

### Moderator
Claim: Michèle.

### Conspiracy Advocate (CA)
Claim: I think the question was in the face of still vibrant ISIS in Iraq and Syria, you can't-- how can you get to the political progress that will ultimately resolve these situations? You argued for diplomacy and political settlement on both sides of this border as part of your strategy as well, but you can't get there as long as ISIS is a vibrant force.

### Scientific Advocate (SA)
Claim: We agree that if you want to roll back ISIS and take them out, all right, then-- and you're willing to stay, you can get what did you say, General Petraeus, I think you said maturing multi‐sectarian populations.

### Moderator
Claim: There are no lifelines in the debate.

### Scientific Advocate (SA)
Claim: I haven't seen-- all right.

### Moderator
Claim: You can't call out. Sorry.

### Scientific Advocate (SA)
Claim: My point was I have not seen that, but if we were to get there it's going to take actually pushing them out and, once again, you don't have a strategy that can do that absent U.S. troops.

### Conspiracy Advocate (CA)
Claim: We believe that we do and we've explained it, but I think absent that, you are condemning this region to perpetual instability, civil war, violence, and the launching-- the incubation of terrorism against the West. And against us.

## Round 3

### Moderator
Claim: And that concludes Round 2 of this Intelligence Squared U.S. debate, where our motion is Containment is Not Enough: ISIS Must Be Defeated. Now, we move on to Round 3. Round 3 are where the debaters make closing statements from their seats. They will be two minutes each. Here to make his closing statement for the motion Containment is Not Enough: ISIS Must Be Defeated, Philip Zelikow, professor of history at the University of Virginia, former counselor for the Department of State.

### Conspiracy Advocate (CA)
Claim: One of the things I had the sad task of doing years ago was to be the Executive Director of the 9/11 commission. This is the commission that was called upon to investigate after the fact what had happened. And of course, for years before 9/11, we knew Al‐Qaeda was at war with us. Well, we weren't sure they were going to come to the homeland. And besides, if you looked at the problem-- and people did-- it was just so hard. Look at who we'd have to work with in Afghanistan-- the Northern Alliance. The politics of the Northern Alliance were nightmarish. There were thugs and warlords among them.

And besides, if you wanted to do something with some special forces, there'd be risks to Americans. And of course then came 9/11. And then here I am interviewing generals, and national security advisers, and even former presidents. And it's "Wish we coulda, wish we shoulda." All the things that-- all the options they thought of doing, they considered, and they were too costly, too risky. And the politics of Afghanistan was too hard. But was it really then better now to then have to occupy Afghanistan and we're still there 14‐and‐a‐half years later, because we didn't take the risks, the messy politics, the hard laboring with some effort? Instead, we ended up with catastrophe and a catastrophic commitment of the United States. If you want to avoid that kind of catastrophic commitment, vote for the resolution, because we need to nip this in the bud.

We need to deal with this infection now before the gangrene spreads and the surgeon brings out the hacksaw.

### Moderator
Claim: Thank you, Philip Zelikow. The motion: Containment is Not Enough: ISIS Must Be Defeated. And here to make her closing statement against the motion, Anne‐Marie Slaughter, president and CEO of New America and former director of policy planning for the Department of State.

### Scientific Advocate (SA)
Claim: So, the last time I was on this stage, I was talking about male/female equality. It's another hat that I wear. And from that perspective, ISIS does absolutely unspeakable things to women. In fact, ISIS-- IS-- should stand for "international sex trafficking," because that is what they do. In hideous ways. And I'm not hesitant about the use of force, and I'm definitely not hesitant about U.S. leadership in the world.

The reason I'm taking the position I'm taking is because when I read the proposition that said "Containment is not enough: ISIS must be defeated," I saw, once again, the United States making the mistake of believing that we could solve a problem that is a decades‐ long, maybe century‐long struggle, fight, war, but among Muslims. We should protect ourselves, absolutely. We should do everything we can diplomatically, digitally. And yes, if there is that coalition of other states or strong fighters that we can support, I would support them. But what's really at issue here-- the only thing we're disagreeing about is do you stop them where they are or do you roll them back? Do you take away their territory?

And my proposition is that if we, the United States, try to lead a coalition to take away their territory, we will once again find ourselves in the midst of someone else's fight in a way we do not understand, and we're often producing precisely the consequences we wish to avoid.

### Moderator
Claim: Thank you, Anne‐Marie Slaughter. The motion is Containment is Not Enough: ISIS Must Be Defeated. And here to make her closing statement in support of the motion, Michèle Flournoy, co‐founder and CEO of the Center for a New American Security and former Undersecretary of Defense.

### Conspiracy Advocate (CA)
Claim: One of the most searing memories of my time in the Pentagon was a visit to Dover Air Force Base. Dover Air Force Base is where the remains of fallen U.S. servicemen in Iraq, Afghanistan, wherever-- are brought back to the United States. It is the first place where the families of the fallen are able to receive their loved ones. On the night I was there, my first visit, it was bitterly cold.

We were waiting on the tarmac for what seemed like forever, for a large military transport plane to come in. Eventually, the plane came in, landed, and taxied to a stop on the tarmac. Off to the side, nearby, away from the press, was about-- were about a dozen grieving, grief‐stricken families who were there to receive a father, a husband, a brother, a daughter, a sister. And we waited for what seemed like an eternity. And eventually, the back of the plane opened to reveal a row of flag‐draped caskets. And one by one, each of those was lovingly carried by a group of soldiers off to an awaiting family. It was a just unbearable and devastating scene. This was the cost-- the human cost of war.

This was Americans who had sacrificed everything for their country and families who would never again be the same. When we think about how we're going to fight or how we deal with ISIS, we need to think about Dover, the human cost of the choices we make and the choices we fail to make. And I am here today firmly believing that if we do not adopt a more‐robust and well‐resourced strategy, where we're not doing it all by ourselves, but we are leading an international coalition to fight this horrific movement, we will spend more blood and treasure down the road.

### Moderator
Claim: Michèle Flournoy, I'm sorry. Your time is up. Thank you. The motion is Containment is Not Enough: ISIS Must Be Defeated. And here to make his closing statement, Dov Zakheim, a senior adviser at the Center for Strategic and International Studies, and former Undersecretary of Defense.

### Scientific Advocate (SA)
Claim: In 2002, I was asked to help get troops and funds for that coalition-- first the coalition in Afghanistan, then the coalition in Iraq. I got money. I didn't get any troops from Muslims. Not one Muslim country sent troops in, as I recall. Some helped with training in their own countries. To talk of coalitions is to talk, essentially-- if the Brits want to play again-- of a U.S.‐U.K, coalition with a lot of other flags. It's not going to work. General Petraeus is right. The surge worked. Phil, you’re right. With over 100,000 troops. And I remember sitting next to the Deputy Secretary of Defense and testifying, who then said that General Shinseki was wrong when he said we needed several hundred thousand troops to win in Iraq.

We did put six figures of troops in Iraq. Lots of troops in Afghanistan. But that's behind us. It's not 9/11 anymore. It's not 9/12. We have a history of being in there. They don't want us. So, we have this Hobbesian choice: put in loads of troops, beat ISIS back-- roll them back, as you would like-- and take the risk of alienating the Arabs. Or alternately, holding them in place, doing all the other things you talk about. But it'll take time. It'll take money. It'll take will. And it ain't going to happen overnight. And I go back to what I said earlier. You have made the best arguments for containment-- with the exception of my partner, of course-- that I've heard tonight. We cannot beat these people unless we are absolutely committed to more money, more troops, more will. It ain't going to happen. Thank you.

### Moderator
Claim: Thank you, Dov Zakheim. And that concludes closing statements in Round 3. And now it's time to learn which side you believe has argued the best. I'm going to ask you again to go to the keypads at your seat and vote as you did at the beginning. Take a look at the motion again. Pay careful attention to the phrasing, so you are clear which side you're voting on. But if it's for this team, it's Number 1. And if it's for this team, it's Number 2.

And if you became or remain undecided, it's Number 3. And we'll take about 15 to 20 seconds to let you complete the vote and lock it out. Okay. While that's happening, I would just like to say a few things. First of all, it's our goal at Intelligence Squared to have debates like the one we just had. Really passionate argument, brought with respect information, intelligence, civility I want to congratulate all of these debaters for what they did. It's really a pleasure for us also to be partnering again with the Aspen Strategy Group and we just need to thank a few people.

First of all, Joe Nye and Brent Scowcroft. Thank you very much for having us here again. Group director and also a member of our advisory board, Nick Burns. Thank you very much. And Deputy Director Jonathon Price. Thank you. And the Aspen Institute President and CEO Walter Isaacson. And again we want to thank the founders of Intelligence Squared U.S., Robert Rosenkranz and Alexandra Munroe. The other thing, as I said at the beginning, this is actually a philanthropic organization. We-- this podcast and radio broadcast we give out to the world for free and we're now at the point where millions of people are listening to them and we rely on the support of a lot of donors who are also in the group. So, without naming you I want to thank you all for your involvement and support. I also want to take this opportunity to say to General Petraeus I know that for a long time we've been trying to book you to be in one of our debates. And I think you're indicating now that you may be interested, that you're bookable, because we would love to have you in the future. So, we will be surrounding you for email later. Because from the audience you debate pretty well. We're putting the final touches on our upcoming fall season. I know a lot of you do get to New York, so we want to give you a little look ahead at the topics we'll be doing there. Broadly, we don't have the motions language framed yet, but the topics are sexual assault on campus, the Chinese political and economic model, the nation's infrastructure, central banks, and affirmative action. We're going to be at George Washington University debating the use of smart drugs and we're going to be at Northwestern Law School debating prosecutorial abuse. We will have the full lineup set by the end of the month and you can get it by visiting our website iq2US.org.

You can buy tickets there. You can also sign up for our e‐blast and, again, this debate and all of our debates, we're now at I think 107 since we started, are all available via our app, which you can download from the Apple store and from the Google Play store. Okay. The results are all in now. Again, the motion is this: Containment is Not Enough: ISIS Must Be Defeated. We had teams arguing for and against. You voted twice. Again, the team whose numbers changed the most between the first and the second vote will be declared our winner.

Let's look at the preliminary vote. On the motion Containment is Not Enough: ISIS Must Be Defeated before you hard the arguments 52 percent of you agreed, 27 percent were against, 21 percent were undecided. Those are the first results. Remember, again, it's going to be the difference. Let's look at the second vote. On Containment is Not Enough: ISIS Must Be Defeated the team arguing for the motion their second vote 32 percent.

They went from 52 percent to 32 percent. They lost 20 percentage points. Team arguing against their first vote was 27 percent, second 59 percent. They went up 32 percentage points. The team arguing against the motion declared our winner. Our congratulations to them. Thank you from me, Jon Donvan and Intelligence Squared U.S. We'll see you next time.
