# Debate Transcript

Topic: Break Up The Big Banks
Motion: Break Up The Big Banks

Debate ID: 101613%20big%20banks


## Round 1

### Moderator
Claim: And tonight we're delighted that this debate is taking place in partnership with the Richard Paul Richman Center for Business Law and Public Policy, which is a joint venture of the Columbia Law School and the Columbia Business School. And we really want to thank them for being partners with us tonight on this.

And we always begin these debates by having a brief conversation with the chairman of Intelligence Squared U.S. who brought this all to us. And what we do is we talk about the relevance of this debate right now. And the relevance is staring us in the face. So at this point I'd like to bring onto the stage, if you could please welcome Mr. Robert Rosenkranz.

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hi. So, as I said, Bob, timing is everything. We set this debate up months ago. And here we are. Just take us into the relevance of this debate right now.

### Moderator
Claim: Well, it's incredibly timely. And when you see-- and in every newspaper you pick up, the big trouble that JPMorgan has gotten themselves into, and they would have generally be considered the best managed of all of the big banks, you realize that tonight's debate is right on in terms of timeliness.

### Moderator
Claim: What we like to do in picking these debates is stack arguments where there really are potent arguments, valid arguments on both sides. So let's just talk through the side now arguing for the motion, the side that wants to break up the big banks, what do they have going for them?

### Moderator
Claim: Well, I think the first thing one needs to understand is that, what is the role of a bank? The important role of a bank in our economic system is to lend money to consumers who want to spend or to businesses who want to invest. And some of these banks are so large, about a dozen of them, that the government has designated them as “too big to fail”, which means that they have an implicit government guarantee. But those banks are doing so many things beyond that basic function that the argument would be that this is simply a step too far for the government to be guaranteeing all these other activities. These big banks are too complex to manage, as we see.

Run well, et cetera, et cetera. They may be too opaque to regulate. And also it's an unfair competitive advantage for them to have this implicit guarantee of the government because the banks that don't find it more expensive to fund their operations, and therefore more difficult to be competitors.

### Moderator
Claim: And what's the argument for the other side?

### Moderator
Claim: Well, the argument for the other side goes back to the financial crisis and said-- says, these big banks were not the cause of the financial crisis. That was Lehman Brothers. That was Bear Stearns. That was AIG. Big banks really had nothing to do with it.

Moreover, the big banks are better capitalized and in much better shape now than they were then. And U.S. banks are in better shape than banks anywhere else in the world. In a global economy, you need really big banks to serve global companies and to compete with the big banks in other countries.

And then finally, the question of what kind of regulation. I had a chance to ask Tim Geithner a question today about bank regulation. And he said, "You know, it's a bit like Afghanistan. You have all of these different tribes, all these uneasy exercises of power and conflict with each other." And, of course, he's talking about the incredible complexity of financial regulation in this country. And then if you think about, out of a process like that, if you're going to hand out a meat ax to whack these big banks, the odds of getting a result that you think is good seem almost infinitesimal.

### Moderator
Claim: Well, the great thing about the debate tonight is who our debaters are. You're about to meet them, but they've all really lived and worked this issue for years. So why don't we bring them out? And again, thanks very much, Bob Rosenkranz.

### Moderator
Claim: Well, thank you.

### Moderator
Claim: Everyone seated? All right. Terrific. I'd like to invite one more round of applause for Bob Rosenkranz for making this all possible.

Four letters of the alphabet: T.B.T.F.; acronymically, it's Washington and Wall Street shorthand for “too big to fail”." And it's the concept that justified taxpayers having to bail out banks in trouble in the financial crisis, because the thinking goes that if one of these really big banks goes down it could take everything else in the economic system with it. Solution, how about breaking up the big banks? Drastic, right? But would that actually solve the problem?

Would we be safe from the threat of TBTF if we broke up the big banks? Well, that sounds like the makings of a great debate, so let's have it. Yes or no to this statement, "Break up the big banks," a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufman Music Center in New York City, and we are in partnership with the Richard Paul Richman Center for Business, Law and Public Policy, a joint venture of Columbia Business School and Columbia Law School. As always, we have four superbly qualified debaters who have all lived and worked this issue, but they're coming at it from opposite sides. Two against two on the motion "Break up the big banks." And as always we go in three rounds and then the live audience here votes to pick the winner. And only one side wins. Our motion, again, "Break up the big banks." And now let's meet the team arguing for the motion, first, ladies and gentlemen, please welcome Richard Fisher. Richard, you are the president and CEO of the Federal Reserve Bank of Dallas, a bank that Texas Monthly profiled in which it described Dallas Fed's, quote, "long tradition of being a pain in the--" and a word beginning with "A"-- and how you are perhaps the most visible in a long line of dissidents from the bank. You have been often in disagreement with Fed policy. So our question to you is in the ranking of Fed policymakers, how much of a pain in the neck are you?

### Conspiracy Advocate (CA)
Claim: First, thanks for getting it anatomically correct. Of course, I'm a member of a team. We're just trying to get it right. We're trying to conduct monetary policy and regulatory policy in order to promote the greatest economic employment growth that possibly can be created without creating inflation. And this is an issue that's dear to our heart.

### Moderator
Claim: Ladies and gentlemen, Richard Fisher. And, Richard, your partner is?

### Conspiracy Advocate (CA)
Claim: My partner, Simon Johnson, is not only the former chief economist for the International Monetary Fund, he is also a brilliant professor at MIT of entrepreneurialism and has a great British accent.

### Moderator
Claim: Ladies and gentlemen, let's hear it from Simon Johnson. And, Simon, as former chief economist at the IMF, you spent a lot of your career working on crisis prevention and growth issues in emerging markets, after which you said that while each crisis is different, they all look depressingly similar, including the crisis in the U.S. So what is the common denominator?

### Conspiracy Advocate (CA)
Claim: Oligarchs, rich powerful people who get out of control and they want you to bail them out again.

### Moderator
Claim: And do you like them?

### Conspiracy Advocate (CA)
Claim: Well, we have to work with them, it seems.

### Moderator
Claim: Okay. Ladies and gentlemen-- Simon Johnson. motion is "Break up the big banks," and we have two debaters here to argue against this motion. First, ladies and gentlemen, welcome Douglas Elliott. Doug, you are a fellow in economic studies at the Brookings Institution. You were in investment banking for 20 years, most of it at JPMorgan. At one point you left banking and started up a nonprofit, which was called the Center on Federal Financial Institutions. After that you went back to banking, back to JPMorgan in 2006, just in time for the financial crisis, which says what about timing?

### Scientific Advocate (SA)
Claim: It says I was broke. I was a volunteer think tanker. I needed to go back to Wall Street so I could support my think tank habit.

### Moderator
Claim: Ladies and gentlemen, Doug Elliott. And, Doug, your partner is?

### Scientific Advocate (SA)
Claim: The brilliant Paul Saltzman. He runs the Clearinghouse Association, which analyzes these issues. And he has a very nice Brooklyn accent.

### Moderator
Claim: Ladies and gentlemen, Paul Saltzman. And, Paul, as Doug mentioned, you're president of the Clearinghouse Association where a while back you ran a sort of war game to test federal legislation that was put in place to manage banks called "Dodd-Frank." We'll be hearing a lot about it. And it simulated a bank meltdown, and you had people playing bankers and congressmen and journalists, et cetera, FDIC folks; so I really want to know… was your version of Congress more functional than the one that we have now?

### Scientific Advocate (SA)
Claim: Well, no our version of Congress functioned as well as the current Congress, so I think it was very realistic and we had a number of folks who are in that field playing that and they were as fractious as today's current Congress.

### Moderator
Claim: So was it a disaster?

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: Ladies and gentleman, Paul Saltzman. those are our four debaters. Now, the way this works is that they will debate in three rounds and you, our live audience here, will choose the winner of the debate. By the time the arguments have concluded you will have been asked to vote twice, once before the debate and once again after the debate your sentiment on this motion. And the teams-- the team whose numbers have moved the most in percentage point terms will be declared our winner. So, let's go to the preliminary vote. The first vote. If you go to the keypads at your seat, the way it works you push number one if you agree with the statement "Break up the Big Banks," the side that's being argued by this team. If you disagree with this statement and you're with this team arguing against the motion, push number two. And if you're undecided push number three. If you push the wrong key, just correct yourself. The system will lock in your last vote and you can ignore the other keys. We’ll repeat this at the end of the debate and the turnaround time from that vote to giving the results and telling you who the winner is is about two minutes.

Okay, so we're going to lock that out. So, our motion is this: "Break up the Big Banks." On to round one. Opening statements from each of our debaters in turn. They have a seven-minute time limit. Speaking first for the motion, "Break up the Big Banks," Richard Fisher. He is the president and chief executive officer of the Federal Reserve Bank of Dallas. Ladies and gentleman, Richard Fisher.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you very much. When Simon Johnson and I speak of breaking up the big banks, we're speaking of less than a dozen banks that are considered, as you mentioned, “too big to fail”. Let me just give you a statistic, 0.2 percent of all the banks in the United States of America control 70 percent of the banking assets of the country.

One of them mentioned earlier by Bob, JPMorgan, has assets that exceed the total assets of 5,400 community banks in this country. Our definition of a bank “too big to fail” is a bank whose bond holders and shareholders and managers and big customers, even their oligarchs, believe themselves exempt from the rules and the consequences that apply to all others. If they screw up they'll be bailed out by you, the people in this audience, the American taxpayers. It happened in 2008, 2010. You know that. And then a law called Dodd-Frank was passed by Congress to prevent it from ever happening again, and yet today these banks are bigger and the power more concentrated than ever. They are just as likely, they may even be more likely to take great risks in search of profits protected by the assumption that failure is an unlikely outcome and that taxpayers will once again come to their rescue. The mechanics to corral them are more politicized than ever.

And even worse, Dodd-Frank, the legislation we just referred to, shackled smaller banks with over 13,000 pages of rules and regulations that as of last year we estimated would take 24,180,156 hours every single year to comply with and to implement. This places the smaller banks that wish to compete with the big banks at a tremendous competitive disadvantage. They don't have the resources to hire lawyers and handsome, well- heeled, Brooklyn accented lobbyists like Paul Saltzman to work the regulators. Under the law, the big banks are now designated as systemically important financial institutions. The acronym for that is SIFIs. Now we, at the Dallas Fed and Simon and I would consider the SIFI an acronym for save if failure impending. And actually when you think about it, SIFI sounds like a communicable disease. Something that's transmitted by risky behavior and indeed-- Thank you. I was waiting for that response. Indeed it was the TBTF or the SIFIs who were, if not the cause of, they were the spreaders of the economic virus that nearly destroyed our economy in 2008-2010. That crisis, we estimate at the Dallas Fed, cost the United States over $15 trillion in output, output we have yet to regain. And if you do your numbers, you'll know that this is $120,000 per every American household. The SIFIs, the “too big to fail,” are a dagger pointed directly at the heart of the American economy. They threaten the well-being of everybody in in audience and everybody listening to this broadcast. So yes, Simon Johnson and I are advocates for breaking up the big banks that are considered “too big to fail”. Our proposal is simple.

We suggest that we limit any and all government guarantees to deposit-taking commercial banking operations of these large bank holding companies. We will let them operate their other businesses, but first prevent them by law from using your deposits and the governed guarantees for the safety of those guarantees from underwriting any of their other businesses. Secondly, require anybody who is counterparty to their other business, which contracts with them on a risk transaction to sign a simple declaration that if this declaration fails-- if this transaction fails, we will never, ever be bailed out by the taxpayers of the United States. And, C, subject all those businesses to the regulations that such businesses are subject to when they're not protected by the banking laws that we currently have, that these big bank holding companies enjoy. For example, on derivatives, make sure they're subject to margin requirements, just like individuals are when they borrow money to buy a stock or a bond.

And finally, insist on transparency. As Bob pointed out, there's not much transparency. There's a lot of opaqueness, as it's called. The CEOs of these businesses know where their risks are. If you're a sophisticated analyst, there's no way to determine that by looking at their balance sheet. And I would actually defy our noble opponents to tell me why what I've just suggested is an unworkable solution. And Mr. Saltzman and others are very fond of pointing out what they consider to be myths. One is that there is greater banking concentration in Canada than in the United States, greater concentration in France than in the United States. That's great if you like Gordon Lightfoot, or if you're French. Or they will point out that there are other industries that have a greater concentration, for example computers or telecoms, that's true. But these are companies that are not shielded from failure like banks are. They receive no subsidies from the implied guarantees that the government currently provides them, currently provides the bankers to shield them from failure.

Winston Churchill once said that in finance everything that is agreeable is unsound, and everything that is sound is disagreeable. I know that what Simon Johnson and I propose is disagreeable to the highly paid lobbyists and spokesmen of the “too big to fail” big banks. But it is the sound thing to do. The big banks, in summary, have taken what I call the immoral high ground. Government policy has led them there, and it has enshrined them. We need to correct this perversion of American capitalism. It may not be the French thing to do, but it's the American thing to do, and I think we should do so. So I ask you to vote yes to the proposition before this house. Let us break up the banks, the big banks that are considered “too big to fail”. Thank you.

### Moderator
Claim: Thank you, Richard Fisher. Our motion is "Break up the Big Banks." And here to speak against this motion, I'd like to introduce Paul Saltzman. He is president of the Clearing House Association, a trade group that represents 18 of the world's largest banks. Ladies and gentlemen, Paul Saltzman.

### Scientific Advocate (SA)
Claim: Thank you, John. Seven years after the subprime mortgage crisis, one thing is clear. Many people made serious mistakes; public officials, regulators and, yes, Simon and Richard, large banks. Mistakes that we now know with the benefit of hindsight helped bring about the crisis. But in the three years since the passage of the Dodd Frank Financial Reform Act, there has been an intense focus on strengthening our banking system. There are new rules and supervisory practices that are changing both the culture and the structure of large banks in permanent and transformational ways to ensure that a crisis like the one we experienced never happens again.

But my opponents ignore or understate these reforms. Instead, they propose a radical, untested, and practically unworkable experiment that would upend the progress we have made and create a whole host of new systemic crises. My opponents' proposal would forcibly break up the largest big banks by placing an arbitrary cap, a government imposed-- the same government that can't seem to get its act together with respect to the payment of our debt. This unprecedented abuse of government power attempts to address an ill-defined risk with little regard for its practical implications or its unintended consequences, simply because they think smaller banks are inherently safer. That is their underlying assumption. And they are selling you this solution as a risk-free proposition without any cost to society. Yes, we can have all the benefits of large banks, but we don't need the large banks.

I'm afraid, Simon and Richard, you just can't have it both ways. Their solution is naive and nostalgic. Yes, we all yearn for a simpler world. I get it. But when America and the world become less interconnected and simpler, when large and small companies become less global and stop being the mainstay of production, consumer innovation, and choice, then let's have this debate. Look, the strengths of our banking system is its diversity. We need banks of all sizes, shapes and functions. And yes, within that mosaic, some banks are large, quite large. But some of these banks are large for a simple reason. They mirror the size and the scope of the economy that they serve. They are scaled to serve the customers and the companies that voluntarily use their services. Large banks provide a unique set of services. Global distribution channels, innovative technologies that only they can produce because of the economies of size, scope and scale at cheaper prices for American consumers.

Some of these benefits are visible, like mobile payment technologies and reward points. Some are very much behind the scenes like fraud protection and massive investment for our global infrastructure, clearance, settlement and payment systems. And large banks spend tens of billions of dollars protecting this critical market infrastructure from dangerous cyber-attacks that small banks could not afford to pay. And some benefits are indeed difficult to quantify, but that doesn't make them any less valuable, like the breadth of services that they provide to smaller banks as correspondents as operational support and corporations large and small that allow for multicurrency channels, trade finance, global cash management and other risk management tools. Look, several realities will be debated tonight, realities which I submit can't reasonably be refuted, although my worthy opponents certainly will attempt to do so.

First, we do have to put things in perspective. Some of America's banks are indeed large. But we have to view them relative to the size of our economy and the world economy that we live in. The size of the American banking system is proportional to the economy that it serves. Our banking system as a percentage of our economy is basically the equivalent of South Africa's. In addition, as Richard mentioned-- I know he was appealing to isolationist tendencies there, but the fact of the matter is the degree of concentration in our banking system is in fact less than most developed countries. The largest banks, as a percentage of industry revenue, are in fact less than most other industries with fixed costs, including auto manufacturing computers, pharmaceuticals and wireless telecom. Second, the underlying premise of my opponents' theory is that smaller banks are somehow safer and less complex.

That is a faulty assumption that is simply belied by the facts of history. Banking crises are caused by one thing: when too many people buy an overinflated asset, you have what's called a common shock, a common shock associated with too many people buying the same overvalued asset. And when that asset bubble bursts, you have a systemic crisis. My point is, smaller institutions, whether they are banks or hedge funds, can be a source of systemic risk. They have been, and unfortunately, they will be. Breaking up the banks will not prevent a future crisis. And also, they would eliminate the stabilizing impact that large and well diversified banks have during times of inevitable crises. And third, and perhaps an area that we'd love to mix it up during the course of the debate, new laws are in place that weren't in place, including the law that prohibits taxpayer bailouts and eliminates “too big to fail”.

And there has been tremendous progress in the pace and substance of regulatory reforms to mitigate the risks to our banking system. To ignore or understate these transformational changes is disingenuous. There isn't a single aspect of a bank's business that hasn't undergone-- been untouched, undergone reform or been untouched by regulatory reform. Banks have twice as much capital as they had before the crisis. Liquidity gaps are closed even in advance of regulation. Bankruptcy road maps, through living wills are in place that make organizations simpler and less complex. And we have a new bankruptcy process that requires banks to be resolved without taxpayer support. To suggest that these changes are illusory is just simply wrong. They are in place. They are effectively limiting both the likelihood the large banks fail and the impact of that failure if and when it does occur.

The answer presented by these risks is not to ignore the benefits that large banks bring to our society, but to continue to focus on improving the macro-prudential regulatory framework, to periodically assess their effectiveness, and to think about where the next crisis is coming from.

Thank you.

### Moderator
Claim: Paul Saltzman, I'm sorry, your time is up, and thank you very much.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Ladies and gentlemen, Paul Saltzman. And here's where we are, we are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donovan. We have four debaters, two teams of two, fighting it out over this motion, "Break up the Big Banks." You have heard two of the opening statements, and now on to the third. Arguing for the motion, "Break up the big banks," Simon Johnson. He is the Ronald A. Kurtz professor of entrepreneurship at the MIT Sloan School of Management and former chief economist at the International Monetary Fund. Ladies and gentlemen, Simon Johnson.

### Conspiracy Advocate (CA)
Claim: Thank you very much. And thank you, Paul and Doug, for being willing to come out and argue the big banks' corner this evening. This debate is long overdue. Now, Richard Fisher has laid out for you the case, the economic case, the technical case for breaking up the big banks. And, now, you should take note of what he says. He's the president of the Dallas Fed. He's a man with a great deal of experience in financial markets. He's also a man who has to be, you understand, somewhat careful about certain statements he makes, wouldn't want to move the dollar or anything in a precipitous manner. My job today is to tell you the things that Richard Fisher can't tell you-- because he's too nice a guy and too much of a diplomat. And a lot of these things are about politics, and I want to cover these precisely by responding to what Paul Saltzman has just said on three main dimensions. I want to talk about the magic-- supposed magic of banking.

I want to talk about JPMorgan Chase, the biggest bank in the world. And I want to talk about Dodd-Frank, the legislation; the miracle that Mr. Saltzman says has fixed all our problems. Now, on the first one, on the magic of big banks, have you felt it? Have you seen around you as the banks became bigger the great improvement in customer service; the reduction in fees; the better access to credit for all Americans? No, no, you have not. You have not. And the really-- the really interesting point-- and I'm afraid the sleight of hand, and it's a masterful sleight of hand-- in what Mr. Saltzman said is the history. When did the banks in the United States become so big? It wasn't 50 years ago. It wasn't 30 years ago. It's mostly in the last 15 years.

Mid-1990s, the largest six banks in the United States had total assets around 15 percent, 1-5 percent of U.S. GDP. They're now over 60 percent of GDP, combined. They're bigger now than they were before the crisis. This is a recent development. All-- everyone in this room, everyone listening and watching at home should have felt the magic if there were any magic for you. There isn't. There's magic, all right, there's magic in compensation. If you run a bigger bank, you get a bigger paycheck. You understand what that's about. There is no magic of size for the consumer, for the broader economy, for the nonfinancial sector. Let's talk about numbers. Let's talk about-- let me talk about JPMorgan Chase. I don't see Jamie Dimon the room. He could speak for himself if he is here. We haven't-- nobody said anything about the numbers, the size. What is the balance sheet-- total balance sheet measured properly?

Include all the derivative exposure using international accounting standards. It's a $4 trillion bank. It's about a quarter the size of the U.S. economy. I'm comparing the balance sheet with our annual GDP. That's a big bank. If JPMorgan were on the verge of failure today, a Wednesday, it's an awkward day for banks, though-- I think one of the big lessons actually from the Clearing House simulation was "Don't fail on a Tuesday." It's a long way from Tuesday to the weekend. We need to get to the weekend. Do the bailout. Right? It's a Wednesday. It's Wednesday, it's an awkward day, I understand. It's an awkward day. JPMorgan, $4 trillion is going down. It's a hypothetical. Please don't rush to tweet that. It's hypothetical. JPMorgan is about to fail. Who here thinks that the president, secretary to the treasury, chairman of the Federal Reserve would let them go? Let them fail? Take the hit?

Go through bankruptcy? Does anyone think JPMorgan could fail just like every other business outside of big banks could fail in America? Could JPMorgan fail? Anyone want to raise their hand? Paul, you can raise your hand if you want. Anyway, Goldman Sachs. Goldman Sachs. Goldman Sachs was a $1.1 trillion bank when it failed. I'm sorry, was rescued by liquidity loans. I always get those two things mixed up. In September 2008, $1.1 trillion bank. That was up from $250 billion in the mid-1990s when it was one of the best banks in the world, when it provided really good service to individuals and corporate customers. One of the best banks in the world. It became a lot bigger. It became $1.1 trillion. Anyone think Goldman Sachs could fail. No. I see no hands. One hand. Good luck to you, sir. There is a short seller in every New York audience. Dodd-Frank, Mr. Saltzman says, Dodd-Frank has solved this problem. Now, I'm a supporter of Dodd-Frank. I think this is important legislation. We had to get some of those reforms done. I worked to help the FDIC, Federal Deposit Insurance Corporation, with their implementation of some of the plans for how you manage the collapse of these banks. Yes, I'm a member of the systemic advisory committee for the FDIC. It's a great, fun job. I can assure you. We have terrific parties. And, you know, maybe, maybe it'll work. Maybe the single point of entry, the recapitalization of the holding company, maybe they'll be enough capital. Maybe the Federal Reserve will insist on preparing these banks properly so when the day comes the damage is more to the management who are responsible and to the creditors who should be on the hook, and to their shareholders who took the risk rather than on the rest of us, rather than on the economy, rather than on the taxpayer, rather than on everyone who lost a job.

Eight million jobs lost, $15 trillion in output. Dennis Kelleher from Better Markets in the second row has the same numbers from his independent assessment. This is a calamity. Maybe we could avert that danger. Maybe Dodd-Frank will work and all these pieces will come together. I would not bet on that. I do not advise you to bet on it. I advise you not to take risk out of the world. You can't do that. We have no magic bullets. There are no panaceas, but as a matter of responsible action, as a matter of dealing with the problems that confront you, as a matter of reducing the risks that we will face, I urge you today support the motion put forward by Richard Fisher and me, "Break up the Big Banks." Thank you very much.

### Moderator
Claim: Thank you, Simon Johnson. And that's our motion: "Break up the Big Banks," and here is our final debater speaking against the motion, Douglas Elliott. Doug Elliott is a fellow in economic studies at the Brookings Institution and a former investment banker. Ladies and gentleman, Doug Elliott.

### Scientific Advocate (SA)
Claim: Thank you. Thank you, John, and thank you all for being here. I have to deviate slightly from my prepared notes here, from the sleight of hand comment. My-- the sleight of hand I noticed is they seem to either not be making the same proposal or they seem not to be clear on what the proposal is. My understanding was this was about breaking up the big banks, which I think most of us here, certainly Paul and I assumed, was to break them into pieces, many pieces, not-- to bring them down below a certain size level, not to do what sounds like a variant of Glass-Steagall.

Simon himself didn't describe what he thinks should be done. He described what he doesn't like about the current situation. I'm sure later they'll have a chance to explain what they actually mean and if they both mean the same thing. Taking this the way I think we were supposed to, I strongly believe it would be a big mistake to forcibly break up the largest American banks. I oppose breaking them up for three main reasons. First, as Paul has pointed out, we need some very large complex banks in America to cost effectively help our businesses and families deal with a large, complex world. Without them, loans and other services will be more expensive and harder to get. Second, breaking up the big banks is unlikely to make us safer, despite the assertions of Richard and Simon.

Third, the process of breaking the banks up would almost certainly cut bank lending for a number of years at a time when our economy needs more lending, not less. Starting with the role of big banks, I think Paul explained quite well. What we need in America is an ecosystem of finance in which there are many different types of organizations that are thriving; big banks, small banks, insurance companies, many other types of participants. Among those I submit that we do need some very large banks, primarily to serve our largest companies, and even middle sized companies, that need a very wide range of financial services, need them in many locations, including overseas, and need them to be provided at a scale that allows it to be cost effective so they're not excessively priced.

This means, when you add this up, we do need some that are quite large. And I would think if they have a criterion, would cross the criterion that they-- my opponents would feel-- meant they should be broken up. And this isn't just my opinion. The Business Roundtable did a survey of CEOs of major U.S. companies, and they very strongly supported the need for banks of this nature. Now, Richard has his Federal Reserve Bank in Dallas, which does some nice research for him. But I'm sorry, Richard, I happen to be more impressed by research papers from two other Federal Reserve banks in St. Louis and in Philadelphia, that have shown quite considerable benefits of this kind of size and scope to quite large levels, that these provide many benefits to society to allow the services to be provided at a reasonable cost without which loans and other services would become more expensive.

I also wouldn't want to see us tie our hands in international competition. Now, let me go to my point on no increase in safety, because I don't actually believe that what they're describing would make us safer, even though perhaps in that Churchillian approach, it sounds agreeable to do this, to break up the big banks-- we all seem to hate bankers-- but it's not actually the right way to go. Now, think about why it-- what would be different. Let's say ten years ago, if we had broken up the big banks into 20 pieces each, I don't think much would have been different in the crisis that we had. It would have been severe, it would have happened, and the character wouldn't have been that much different, because these smaller banks that they were broken up into would all have gone the same way, that is, they all would have overinvested in mortgages, both residential and commercial.

Now, why do I say that? One, because at the time, almost everybody thought this was smart business. So almost all the players in the financial sector were doing it. Secondly, you can look at what small and medium sized banks did. The ones who actually existed that are supposed by safer, they took on tremendous risk and got hurt quite badly. They were just smaller, so they didn't, each one of them, make the headlines. Smaller size was no protection from risky and ultimately stupid decisions. Richard and Simon imply that smaller banks will take less risk. I don't see it. I don't see it from the incentive structure, and I don't see it from how they actually operated. Put another way, breaking up the big banks would not have affected any of the principal factors that analysts tend to argue caused the financial crisis.

They wouldn't have affected excessive investment in all types of mortgages, reduced standards for those mortgages, government pressure and encouragement to make risky mortgage loans, lacks regulation, poor practices at the rating agencies, a bad bonus culture, excessive risk taking by some individuals and the incentives that existed to create dodgy securitizations. So I don't see why we'd expect it to be safer. Now, you might say, well, we wouldn't have to do a rescue as taxpayers if these were smaller banks. But we saw, in the savings and loan crisis---- that we had to do that. If I had more time, I would talk more about this. But you may be surprised that Paul Krugman, no friend of the banks, agrees with us. He said, "Breaking up big banks wouldn't really solve our problems, because it's perfectly possible to have a financial crisis that mainly takes the form of a run on smaller banks."In fact, that's precisely what happened in the 1930s. And if I had more time, I'd give you the rest of the quote. I can do that later if you want. But let me move on to the conclusion here. Keep in mind, Richard and Simon are selling you a theory. We have no actual experience of breaking up the big banks in this way in advanced economies. They cannot promise success. And I personally believe it will do considerable harm. The economy will be less efficient, credit more expensive. We'll be less competitive globally, and I don't see an increase in overall safety. Thank you.

### Moderator
Claim: Doug Elliott, thank you very much.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is "Break up the Big Banks." Keep in mind how you voted at the beginning of the evening, because as I said before, we're going to have you vote again at the end of the evening to tell us where you stand on this motion after hearing the arguments. And the team that has changed the most minds in percentage point terms will be declared our winner.

Now onto round two. And round two is where the debaters address each other directly and answer questions from you in the audience and from me. We have two teams of two arguing for and against the motion, "Break up the Big Banks." Arguing for breaking up the big banks, Richard Fisher and Simon Johnson who are arguing that we're in uncharted territory in terms of the size of the small number of banks that control the assets of an enormous amounts of money that they didn't have 15 years ago; that the government protections that allow them to operate without fear of failure, without bailout represents a moral hazard; the fact that they are shielded from failure is a moral hazard that needs to be remedied. The team arguing against the motion, Doug Elliott and Paul Saltzman argue that the bigness of the banks is not the key issue here, that in the financial crisis we all went through a few years ago, there were many, many factors involved.

And big banks, while they made mistakes, were only part of that problem, that breaking up the banks, these big banks would be a dangerous and unworkable experiment, and that basically big business needs big banks. And if we want to be global, we have to have banks that are global as well. I want to go to the team that's arguing against the motion to come back to this term, “too big to fail”," which your opponents embrace. That's, in fact, the core of their argument is that there are banks that are “too big to fail”, and failure would be catastrophic. I just want clarity from the side arguing against the motion. Do you believe that there are banks that are “too big to fail”, whose failure would indeed be catastrophic? Paul Saltzman.

### Scientific Advocate (SA)
Claim: Doug, let me take that. So let me just be very clear from the outset. No bank should be “too big to fail”. No company should be “too big to fail”. Companies, whether they be banks or other financial institutions, need to suffer the risks of their own risky behavior. It's as simple as that.

### Scientific Advocate (SA)
Claim: Here, here.

### Scientific Advocate (SA)
Claim: Okay. So I think we're not debating-- You know, and to characterize my position or the industry position as being supportive of moral hazard risk is just misleading.

So let's just-- let's just be perfectly clear.

### Moderator
Claim: But, Paul, to my question, does that mean that you do feel that there's a scale of a bank where its failure would indeed be catastrophic?

### Scientific Advocate (SA)
Claim: With Dodd Frank and the law as it is today, which prohibits bailouts, with banks getting smaller and less complex through the living wills process, through the new bankruptcy process that allows banks to be resolved in a way without taxpayers’ support. No bank is “too big to fail”.

### Moderator
Claim: I don't mean to harangue you on this question. I think maybe I'm not being quite clear. I'm actually asking for a hypothetical this way. And I understand you're saying that you don't think JPMorgan would go down the way things are set up now. My question is really different. Hypothetically, if JPMorgan went down, would that be catastrophic for the economy?

### Scientific Advocate (SA)
Claim: JPMorgan can be successfully resolved under the current law and would not need to be bailed out.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: Don't ask me. Ask Paul Tucker, deputy governor, ask Ben Bernanke, ask Mary Miller, ask many of the other public officials that have indicated large banks can be successfully resolved under the current law.

### Moderator
Claim: Let's go to the other side, Simon Johnson.

### Conspiracy Advocate (CA)
Claim: Well, I've asked Paul Tucker. Paul Tucker is the outgoing deputy governor of the Bank of England. And this is a key issue for the British, because it's a cross-border banking issue. It's incredibly complex. Ask Paul Tucker this question, can-- specifically this question: can JPMorgan Chase be resolved under some combination of Dodd-Frank and what the British have in place? And what he says is, “Well, we don't quite have the British piece in place yet.” I actually think that to American English the answer's no.

### Scientific Advocate (SA)
Claim: Simon, with all due respect, maybe I was at a different meeting. For the record, we'd like to get that quote. Paul Tucker said emphatically that large banks can be successfully resolved under the current law. Maybe I was in a different meeting.

### Conspiracy Advocate (CA)
Claim: Well, what's so interesting to me is the Bank of England is putting forward proposals right now to ring fence the commercial banking operations of complex bank holding companies exactly as I have just proposed.

That comes from Paul Tucker. That comes from Andrew Haldane That comes from the Bank of England. So there is a difference of view here, and--

### Moderator
Claim: Well, but besides the--

### Scientific Advocate (SA)
Claim: --the most--

### Conspiracy Advocate (CA)
Claim: --if we’re citing the Bank of England, Paul, then as authorities we should take the-- we should just take onboard their evidence. And, Doug, on your point today, are there economies of scale and scope in banking, Andy Haldane and his team say there are only such magic for banks if you ignore the subsidy the “too big to fail” banks receive, if you factor in that subsidy all those nice results that you mentioned go away. So let's decide where we are in the Bank of England. Are they an authority on this, or are they wrong on the evidence?

### Moderator
Claim: Doug Elliott.

### Scientific Advocate (SA)
Claim: First of all, I talk with Andy Haldane a lot, and what his actual view is, is a lot more subtle than you just described, but I'd like to go back also, you were invoking the Vickers Commission and what the British are doing. What the British are doing as I think you know is actually very similar to what we still have under the parts of Glass-Steagall that we never got rid of, which is there are protections under current U.S. law that mean that deposit taking banks have a number of transactions they cannot do with their non- bank-- their securities affiliates.

That's pretty much what they're talking about doing in the-- with the Vickers Commission, not talking about going dramatically further than that.

### Conspiracy Advocate (CA)
Claim: I think we--

### Moderator
Claim: Richard Fisher.

### Conspiracy Advocate (CA)
Claim: --losing our audience by talking about the Bank of England-- and the Vickers Commission. I do want--

### Moderator
Claim: It's amazing, the Vickers Commission, I mean--

### Conspiracy Advocate (CA)
Claim: Yeah, that's right.

### Moderator
Claim: --cough drops banking.

### Conspiracy Advocate (CA)
Claim: No, no, but-- well, we'll try to--

Can I just say one thing, if I may?

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: I mean, Paul, you know I love you. You're a good man.

### Scientific Advocate (SA)
Claim: Uh-oh, here it comes.

### Conspiracy Advocate (CA)
Claim: But, to make the claim, and I quote, "the big banks were stabilizing influences during a crisis." They were the spreaders of the crisis. They were not a stabilizing influence--

### Moderator
Claim: Richard, I'd have to disagree.

### Conspiracy Advocate (CA)
Claim: --and I know because they came to us to ask for protection. Goldman Sachs--

### Scientific Advocate (SA)
Claim: There were many banks--

### Conspiracy Advocate (CA)
Claim: --bank holding company.

### Scientific Advocate (SA)
Claim: --as you well know, Richard, there were many banks--

### Moderator
Claim: Paul Saltzman.

### Scientific Advocate (SA)
Claim: --that did not need funds. There were many banks that acquired failing institutions--

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: --at the request of the government to stabilize the market. And frankly no good deed goes unpunished, if you read the newspaper these days, you know. And if we can get back to the point earlier, are you suggesting that we now have only domestic banks--

### Conspiracy Advocate (CA)
Claim: Of course not.

### Scientific Advocate (SA)
Claim: --and that not only do we have small banks but we have only domestic banks because of cross border resolution issues? Is that your position, Simon?

### Conspiracy Advocate (CA)
Claim: Paul, on the crisis that happened, one word-- one word for Paul, one word for you, Citigroup, okay? Citigroup was at the center of the financial crisis. But why are we spending so much time, John, talking about the last crisis? We should be talking about the future. We should talk about the next crisis.

### Conspiracy Advocate (CA)
Claim: --“too big to fail” became a salient problem in the fall of 2008 because the banks said-- they argued, with some justification, "We've become so big, you cannot let us fail."That's when “too big to fail” really became the problem that we're now trying to confront. So what happened in the last crisis is interesting, no doubt, we can argue about it for a long time, but it's what happens going forward, and how do we deal with the “too big to fail” institutions--

### Moderator
Claim: Well, let me put the question back to you that I put to the other side which is that if JPMorgan went down would it bring the whole economy down with it?

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Conspiracy Advocate (CA)
Claim: It would jeopardize our--

### Moderator
Claim: Richard Fisher.

### Conspiracy Advocate (CA)
Claim: --security and financial security as well as our economy. And let me just explain how it works. I mentioned the so-called SIFIs, systemically important financial institutions. There's a declaration of who is a SIFI and who is not. That is made by a body chaired by the secretary of the Treasury. As you pointed out in your cogent argument, that body is inherently political. It is chaired by the secretary of the Treasury. Republican or Democrat, they report to the president of the United States. If a bank that has $4 trillion in assets-- and, by the way, a derivatives book of a nominal value or a notional value of 80 trillion, which is JPMorgan, 8-0 trillion in derivatives---- if that bank were to be on the verge of some type of failure, do you actually think the secretary of the Treasury and the body that he chairs, which includes the Federal Reserve chairman, would let that bank go under, that any president would allow that to happen in--

### Moderator
Claim: Okay, you've stated a great question, and I want to let this side--

### Conspiracy Advocate (CA)
Claim: --enormous--

### Moderator
Claim: --answer that question specifically, do you think that the Fed would let the bank go down?

### Scientific Advocate (SA)
Claim: Can I come back to a--

### Moderator
Claim: No, no, no, no.

### Scientific Advocate (SA)
Claim: No.

### Moderator
Claim: I will let you come back to it. It's a great question and I need to hear an answer. And then I will give you the floor.

### Scientific Advocate (SA)
Claim: Okay, thank you.

### Moderator
Claim: I will. Doug, question, Doug, did you want to--

### Conspiracy Advocate (CA)
Claim: Yes or no?

### Scientific Advocate (SA)
Claim: We are a couple years away from having the things in place. I'm willing to wait the couple of years while we get it done, but yes after Dodd-Frank is implemented in that manner, yes, I do believe it will have become possible.

### Conspiracy Advocate (CA)
Claim: Why wait a couple of years?

### Moderator
Claim: Okay, wait, but then I had a-- you had a follow-up point there? I promised.

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: What is it?

### Scientific Advocate (SA)
Claim: I don't actually know what Simon's proposal is, and I'm not crystal clear on what Richard's proposal is. Do you want to break up the banks based on size characteristics? Or do you want to go back to a kind of Glass-Steagall, or do you insist on both? What is it you're actually--

### Moderator
Claim: In other words, do you just want to shrink all of these bank's balance sheets or do you want to cut up their functions and separate the different kinds of things they do in the different institutions?

### Conspiracy Advocate (CA)
Claim: What I have proposed, which what Simon and I are suggesting, is that your exposure as taxpayers should be limited and all government guarantees purely limited to the commercial banking operation of a complex bank-holding company.

### Moderator
Claim: I have to go to this question. Richard, I have to go to their question. How does that represent breaking up the big banks?

### Conspiracy Advocate (CA)
Claim: Hold on. And that all other aspects of that business are subject to the same risk of anybody that conducts that kind of business, whatever that business may be. There are no guarantees and, you know, it doesn't take a meat axe, which is the term you used, the markets will downsize and restructure and reward those who are efficient rather than their having been protected by government guarantees.

### Scientific Advocate (SA)
Claim: With all due respect, I think I've heard a concession. Again, I'll go back to--

### Conspiracy Advocate (CA)
Claim: It's not a concession. You think in other words you agree with me?

### Scientific Advocate (SA)
Claim: Do you or do you not want the government to break up the big banks? That's what we're here debating, Richard.

### Conspiracy Advocate (CA)
Claim: Listen--

### Scientific Advocate (SA)
Claim: Answer the question. Answer the question.

### Conspiracy Advocate (CA)
Claim: Yeah, I want the government to set the rules and I want the market to enforce the breakup.

### Scientific Advocate (SA)
Claim: And I agree with that. Yes. Okay?

### Moderator
Claim: We won the debate. Thank you very much, ladies and gentleman.

### Scientific Advocate (SA)
Claim: The debate's over. Let's vote on whether or not I have a Brooklyn accent.

### Moderator
Claim: Simon Johnson. Simon Johnson, you have the floor.

### Conspiracy Advocate (CA)
Claim: Paul, what we want here is an end to the subsidies. The government subsides that are keeping this financial structure in--

### Scientific Advocate (SA)
Claim: Yeah, but that's not the language of the motion, I have to say.

### Conspiracy Advocate (CA)
Claim: So the subsidies and--

### Scientific Advocate (SA)
Claim: It wasn't pull the subsidies, it was break up the big banks.

### Conspiracy Advocate (CA)
Claim: We want to--

### Scientific Advocate (SA)
Claim: We won the motion, so let's go to the next question.

### Conspiracy Advocate (CA)
Claim: Strip out the subsidies of the banks and you are going to break up the banks. It is breaking up the banks. I want to go back to something Doug--

### Scientific Advocate (SA)
Claim: In other words, you're saying the process of stripping out the subsidies would ultimately result in the shrinking and the diversification of the banks?

### Conspiracy Advocate (CA)
Claim: Why--

### Scientific Advocate (SA)
Claim: Is that what you're saying?

### Conspiracy Advocate (CA)
Claim: Why do you have to--

### Scientific Advocate (SA)
Claim: Is that what you're saying? I just want clarity.

Please answer.

### Conspiracy Advocate (CA)
Claim: Please say your question again.

### Scientific Advocate (SA)
Claim: You're asking about pulling these guarantees-- that the process of pulling these guarantees would through market forces cause the banks to get smaller and perhaps to diversify, rather than the meat axe. Is that what you're saying?

### Conspiracy Advocate (CA)
Claim: They would certainly make them get smaller. People-- big banks--

### Scientific Advocate (SA)
Claim: I'm trying to help you guys connect your arguments in breaking up the big banks. Not because I want you to win or not, but I just want you to get on topic.

### Conspiracy Advocate (CA)
Claim: I want to go back to a very important--

### Moderator
Claim: Yeah, Simon Johnson.

### Conspiracy Advocate (CA)
Claim: which is we're a couple of years away from something magical happening. Why are we a couple of years away? Well, Dodd-Frank passed in 2010. Three years later, how much of it has been implemented?

Relatively little. Why? Because there's been a huge pushback from the industry. Now, Paul and his colleagues are completely within their constitutional rights. I'm not complaining about it. I'm merely pointing out that there is an enormously powerful lobby, particularly around these very large banks that has resisted Dodd-Frank. It's resisted the living wills that Paul mentioned. It's resisted implementing a lot of other measures that would curtail the range of activities and the power of these very large banks. That's why we haven't made progress and we’re not a couple of years away-- we're decades away--

### Moderator
Claim: Just one second, Paul. I need to take note of the fact that you guys have had a very long run at the microphone. So, this time-- side is going to get a little bit extra time before being interrupted unless you yield.

### Scientific Advocate (SA)
Claim: Simon, now it's my turn. I love you, okay?

### Conspiracy Advocate (CA)
Claim: It was Richard who loves you Paul, not me.

### Conspiracy Advocate (CA)
Claim: I love you both. Okay, Simon.

### Moderator
Claim: It’s unrequited.

### Scientific Advocate (SA)
Claim: But why do you insist on continuing to mischaracterize the industry position? I represent the Clearing House.

We have been nothing but constructive in the Dodd-Frank debate. We have supported living wills. We have supported higher capital charges. We have supported prescriptive liquidity rules. We have supported the vast array of macro-prudential rules. We have spent millions of dollars through simulations and otherwise to try and create a framework in which “too big to fail” ends. We are in agreement. We don't want subsidies. We don't want moral hazard risk. The disagreement is the proposition on the table is you guys are in favor of the proposition to break up the big banks. This is not about Glass-Steagall, and Richard, your proposal is very reasonable and tomorrow if you want to have a debate about your proposal, let's do that. But that's not what's here tonight. What's here tonight is a proposal on the table for the government, the same government that can't seem to get its act together with respect to anything in Washington. You want them to set arbitrary size limits and break up the big banks. I think that is preposterous.

### Moderator
Claim: I want to let you respond, and then I want to move on, Richard-- to Richard Fisher.

### Conspiracy Advocate (CA)
Claim: Well, the result is to break them up. The proposal that has been made achieves exactly that. So it does achieve the purpose of this debate. All these banks that you acknowledge are too big to fail, you believe that this massive legislation, over 13,000 pages of rules that have been promoted, some 24 plus million hours, for man and women hours, every year to try to discern, interpret and put in place solves the problem of too big to fail. I don't believe it does so. I think it enshrines too big to fail. And I believe, most importantly, it places the smaller banks, who wish to grow and wish to compete and provide services and have a fair chance to compete, on an un-level playing field. I think what we should all propose is that we go for any bank that is too big to fail, make it too small to save. Exactly what the small banks-- you were saying that the small banks take the same kinds of risks. You're right. You know what happens if they fail? They're shut on a Friday, and they re-open on Monday with a new ownership, and the management is gone, fired, gotten rid of. I just want the same thing for the large banks. That's all I ask.

### Moderator
Claim: Doug Elliot.

### Conspiracy Advocate (CA)
Claim: And that would be the outcome of our proposal.

### Moderator
Claim: Doug Elliot.

### Scientific Advocate (SA)
Claim: Just quickly, what you're describing is what's done with small banks when there's a few, when there's a lot of them like the savings and loan crisis, that isn't--

### Conspiracy Advocate (CA)
Claim: I lived through that crisis. The Federal Reserve Bank of Dallas played the key role in that crisis. And let me just tell you something, we--

### Moderator
Claim: We lost you midpoint, Richard, and I will let you say something-- I just want to let you finish your point, and I will come back to you.

You're a damn good interrupter. But I will come back to you. So am I. Go ahead, Doug.

### Scientific Advocate (SA)
Claim: It's good to be president.

### Moderator
Claim: Go ahead, please.

### Scientific Advocate (SA)
Claim: I really wasn't going to go much further than that, just--

### Moderator
Claim: Great.

### Scientific Advocate (SA)
Claim: No, no.

### Moderator
Claim: I fight for your right--

### Scientific Advocate (SA)
Claim: John, John-- John, I didn't say much further. I didn't say I was stopping.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: All I was going to say is there have been many instances here and elsewhere, where there's a systemic crisis of small banks and then we do end up having to rescue them. So just making all the big banks just small enough to meet your arbitrary criteria doesn't make the risk go away.

### Moderator
Claim: Richard Fisher.

### Conspiracy Advocate (CA)
Claim: --my comment in the epicenter of exactly what you speak about, Texas. We lost not only 600 plus small banks, but the sixth, seventh and eighth largest banks in America. They were closed quickly. They were shuttered. Isn't it interesting-- no offense to New York-- that Texas is now the most prosperous state in America? And we did it without too big to fail banks. And in fact, we closed the banks that then were considered too big to fail. And Paul Volcker was the master of that closure process.

### Moderator
Claim: I want to move on to audience questions in a minute. I have one more topic that I want to bring to the debaters. But I just want to remind you that you'll raise your hand. Folks, if you're upstairs, I can't see you, and there are no mics up there, so you'll have to come down and stand on the steps. If you raise your hand, a mic will come to you. I'll ask you to hold it about that distance from your mouth so that the radio broadcast can hear you clearly. We ask you to state your name. If you're with a news organization, we'd appreciate it if you would identify yourself as such. And as that's getting set up, I just want to take one more question to the side that's arguing for breaking up the big banks, an argument that your opponents made, that-- that global business demands global banks and that there are businesses that rely very much on the banks now that are massive in scope, that they serve a function, that they became big in part because of the needs of their clients. And I just want to ask Simon Johnson to take on that point, and then we'll hear a response from your opponents.

### Conspiracy Advocate (CA)
Claim: Well, I don't think anyone is proposing that you shrink all the banks down to some very tiny size. As I said, Goldman Sachs was a substantial international bank, one of the best international banks in the world in the mid-1990s. It was less than a quarter of the size that it became at the height of the financial crisis. So that's exactly what we mean when we say, take away the subsidies, break up the banks; the market will sort out the ones who should fail, the ones who should survive. Without those subsidies, John, they will be substantially smaller, and they'll be more competitive globally. You really want big, mega-crazy banks like the Europeans have? I don't think so.

### Moderator
Claim: Let's take it to the other side. Paul Saltzman.

### Scientific Advocate (SA)
Claim: Just-- I'd just like to read something from the Dallas Annual Report to clarify the point about size: mega-banks, those banks with assets in excess of 250 billion, under your proposal, you'd break up U.S. Bank, you'd break up Capital One, you'd break up PNC. That's the problem with the proposal. No one has a monopoly on understanding what the right size is.

Banks are appropriately sized for the needs of their customers. FedEx, Amazon, Apple, Google. Verizon just merged with Vodaphone, $130 billion merger. We need these global banks to service the community that they operate in, which for better or for worse is global and interconnected. So I think, which is it? If it's 250 billion, is it 500 billion? Is it 1 trillion? That's the problem. The size of these banks are determined by the marketplace.

### Moderator
Claim: Richard Fisher.

### Conspiracy Advocate (CA)
Claim: By the way, on the Verizon transaction, as you know, that was financed by issuing stock.

### Scientific Advocate (SA)
Claim: And a bridge loan with four banks pulling together $65 billion over a four-week period.

### Conspiracy Advocate (CA)
Claim: Yep. And if there hadn't been those four banks, you would have found other banks to do it.

### Moderator
Claim: Do you have an answer to the question of what’s the size--

### Conspiracy Advocate (CA)
Claim: Yeah. When we refer to mega-banks, we're just differentiating the size of the banks in the country. When we refer to breaking up the banks, we're talking about banks that are too big to fail.

And we're talking about basically 11 banks that are presently covered by that status. Systemically important financial institutions. Some have a simpler book, some have a more complex book. But I think it's kind of an artificial argument. Yes, determines a mega-bank, but it doesn't mean it may be too big to fail. The banks that are too big to fail, so complicated, so large, that even their own managers have trouble understanding the scale and scope of those operations. That's what we're addressing here this evening.

### Moderator
Claim: Let's go to some audience questions. Sir, right down here, front. And a mic's coming down, and then if you could tell us who you are and be terse and perfect. Mr. Terse?

### Moderator
Claim: Scott Shea. And a question for each side. For the opponents, you've mentioned the consolidation of the rest of American industry. And you said the banks are consolidating in the same way. Couldn't it be the causation goes the other way, that the immense over-consolidation of the banking industry has caused the rest of the economy to follow in its wake and it's raised the brittleness of the U.S. economy, decreased job formation, made middle market lending harder to achieve and harder to get because the big banks are indeed so big.

### Moderator
Claim: Okay. And--

### Moderator
Claim: My question--

### Moderator
Claim: We have a one-question-per-person rule. You can tell a friend and--

### Moderator
Claim: It's a harder question.

### Moderator
Claim: And-- I should have pointed that out, no two-part questions or-- let's let the side arguing against the motion to break up the banks answer that.

### Scientific Advocate (SA)
Claim: If I could just start very briefly; Paul may want to add something. Look, there's-- as far as I know, there's no economic evidence for the theory you just put out there. It doesn't sound right to me, but I've also never seen anyone-- anyone make that case.

### Moderator
Claim: Paul Saltzman.

### Scientific Advocate (SA)
Claim: Yeah, banks mirror society. Societies don't mirror banks. Banks serve customer needs. Google is not large. IBM doesn't have businesses in 170 countries because JPMorgan exists. So I would say it's exactly the other way.

Businesses becoming global-- small businesses are becoming global, and banks service their needs. The other concept I'd like to get on the table is economies of size, scope and scale. If you pay a million dollars for a computer, and you have one customer, you have to charge that person a million dollars. If you have a million customers, you get to charge that person a dollar. It's pretty simple. Over the past five years, you have enormous technology expenses that need to get spread out over a large customer base. That is in large part why banks are getting larger and larger, because of those global and technology needs.

### Moderator
Claim: Would this side like to respond? Yes. Simon Johnson.

### Conspiracy Advocate (CA)
Claim: When I talk to the CFOs of large international corporations, the people who run the financial side of those businesses, nonfinancial corporations, I ask them, do you need-- do you want to have one big global bank handling all your financial operations everywhere in the world? It's a fair question. And they say, no, we don't. What we want is different providers in different places.

The idea we would single-source all of our credit, all of our financial transactions, that's actually a bad idea. We want to have different people, and we want to be able to pick and choose depending on who has a good price-- who has better customer service in a particular market. So the idea that the big or international business somehow needs colossal at this scale international banks is a complete fallacy.

### Moderator
Claim: Douglas Elliott, Doug Elliott.

### Scientific Advocate (SA)
Claim: Two quick things, one, you just made a straw mat argument. Nobody that I know is making the argument that the big companies want to have one bank. I worked in the banks--

### Conspiracy Advocate (CA)
Claim: But Paul just made that argument.

### Scientific Advocate (SA)
Claim: No. The argument is that they want a small number of banks that they are close to and that each of those have to have the scale. They want some competition between--

### Conspiracy Advocate (CA)
Claim: So we want the world to be run by what? what's your number of banks, Doug? Four banks, five banks, what's your comfort spot here?

### Moderator
Claim: He’ll answer that when you answer that when you answer what the number of--size is.

### Scientific Advocate (SA)
Claim: I would love to have that answer first. I will answer that question if you do first answer the other one.

### Moderator
Claim: Let's go to another question.

### Conspiracy Advocate (CA)
Claim: Wait, wait, wait. Paul gave us an answer, by the way. His logic chain is if we had one bank that serviced 320 million customers, we'd be better off. That's the end of your logic chain--

### Scientific Advocate (SA)
Claim: No, that's not what I said.

### Conspiracy Advocate (CA)
Claim: Oh, come on. You were talking about economies of scale, economies--

### Scientific Advocate (SA)
Claim: Size, scope, and scale.

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: Regulators from the Federal Reserve Bank of Philadelphia, regulators from the Federal Reserve Bank of St. Louis, your colleagues in the Federal Reserve System have indicated through empirical studies, not ephemeral conversations with CFOs. I talk to CFOs as well. Look at the Business Roundtable Report instead of some ephemeral conversation with--

### Conspiracy Advocate (CA)
Claim: Business Roundtable is dominated by large banks and large--

### Moderator
Claim: All right, I want to go to this question here. Ma'am, do you mind-- because our-- of our camera placement, this is scary, but just go up three or four steps so that we can look-- see you? Thanks. Okay, that's great.

### Moderator
Claim: Okay. My name's Jessica Bloomgarten and the question is for the against side.

You guys have been very focused on making the debate around the size of things and asset size, and I thought Richard's proposal around the division of function and sort of a Glass-Steagall type proposal is really interesting, and I feel like you haven't addressed that, so I'd like to hear your opinion on that.

### Moderator
Claim: So--Can you come with that-- with like a one-sentence question?

### Moderator
Claim: What do you think--

### Moderator
Claim: No, I think I got it.

### Moderator
Claim: --what do you think about splitting up the big space on function as opposed to size?

### Scientific Advocate (SA)
Claim: Sure. I’d be happy--

### Moderator
Claim: Doug Elliott.

### Scientific Advocate (SA)
Claim: Be happy to give you some thoughts on it. And I will in one second. The only reason we've been so focused on the other point is that is the actual point of the debate. And it's kind of a sleight of hand to say, "We think that once you do this thing, it will change the whole economics so much that we know that it will achieve the same effect."I understand there's an argument for it that's far from proof. But coming back to your question, I happen to oppose re-imposing something like the full version of Glass- Steagall-- I know Paul does as well-- because the world has changed immensely. Glass- Steagall didn't even work 20-some years ago because already by that point the principal difference that Glass- Steagall focused on, the difference between a security and a loan had become extremely unclear and irrelevant because the bank-- the big companies that we're talking about here, all they wanted was to efficiently get credit. And they wanted to be able to do that through the markets, and they wanted to be able to do it through the banks. And banks are important parts of the market as well. So they sit in the middle where they can help with either side of this. To arbitrarily break it up-- first of all, it will be really arbitrary. I don't even know how you define a loan versus a security now. It just-- you can't do it in this world. If you do, it'll be a very arbitrary choice.

### Conspiracy Advocate (CA)
Claim: So let me ask the question, if I may--

### Scientific Advocate (SA)
Claim: Please.

### Moderator
Claim: Yes, Richard Fisher.

### Conspiracy Advocate (CA)
Claim: Should the taxpayer guarantee those loans?

### Conspiracy Advocate (CA)
Claim: Bad loan, should a taxpayer guarantee a bad loan made by a mega institution, a too big to fail bank, a SIFI?

### Scientific Advocate (SA)
Claim: No.

### Scientific Advocate (SA)
Claim: No, it's not what we’re proposing.

### Conspiracy Advocate (CA)
Claim: Well, all I've said is that the only thing I want the taxpayer exposed to is protecting the savings that are deposited in the commercial bank of a complex bank holding company. Do you disagree or do you agree?

### Scientific Advocate (SA)
Claim: That's actually a different thing from--

### Conspiracy Advocate (CA)
Claim: Doug, do you disagree or do you agree?

### Scientific Advocate (SA)
Claim: Say it again because I want to make sure I understand.

### Moderator
Claim: Have you done courtroom work? Or are you just watching a lot of shows?

### Conspiracy Advocate (CA)
Claim: --we guarantee the banking system. Taxpayers guarantee the banking system. Our proposal is to limit the guarantee strictly to the commercial banking operation that takes the savings of the people and then invests it in loans. Would you disagree with that or agree with it?

### Scientific Advocate (SA)
Claim: I think that is where the guarantee should be. It is where the--

### Conspiracy Advocate (CA)
Claim: Good.

### Scientific Advocate (SA)
Claim: --guarantee is now.

### Conspiracy Advocate (CA)
Claim: Good.

### Scientific Advocate (SA)
Claim: You-- you're arguing a different point.

### Conspiracy Advocate (CA)
Claim: No, because if JPMorgan were to fail because of a-- let's take JPMorgan as XYZ Bank were to fail and XYZ Bank was JPMorgan-- because of a rogue trader in London called "the whale" who took an enormous risk, should we bail them out?

### Scientific Advocate (SA)
Claim: No, and we didn't. Why are we looking at the London Whale as the--

### Moderator
Claim: Paul Saltzman.

### Scientific Advocate (SA)
Claim: --reason for how the system worked? Who was penalized? The shareholders.

### Moderator
Claim: Yeah, that's right.

### Scientific Advocate (SA)
Claim: Who was penalized? Management. Look at the newspaper. That's an example not of a system broken. That's a system working.

### Conspiracy Advocate (CA)
Claim: If Jamie Dimon--

### Moderator
Claim: Simon Johnson.

### Conspiracy Advocate (CA)
Claim: Jamie Dimon went to see the attorney general just now to discuss the London Whale. Jamie Dimon went to see--

### Scientific Advocate (SA)
Claim: Oh, you were there, Simon. You were there.

### Moderator
Claim: Simon, Simon, Simon, tell our radio listeners what the London Whale is.

### Conspiracy Advocate (CA)
Claim: The London Whale was a trading operation, an individual, a group of individuals in London, lost a lot of money on bad derivative bets and, according to a concession publically made by JPMorgan today, there was market manipulation involved in that transaction. But the point is, Jamie Dimon went to discuss his legal problems with Eric Holder, the attorney general. I can assure you, you will not get to see the attorney general should you get into any legal problems. That is-- there's only one company, according to public justice, there's only one company, as far as they can recall, that has been to see the attorney general.

### Moderator
Claim: I want to remind you--

I want to remind you that we're in the question and answer section.

### Conspiracy Advocate (CA)
Claim: Well, Paul said the system's working perfectly.

### Moderator
Claim: I want to remind you we're in the question and answer section. I'll do this in a second. I want to remind you that we're in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donovan, your moderator. We have floor debaters, two teams of two, arguing it out over this motion: "Break Up the Big Banks." Sir.

### Moderator
Claim: Hi. Jonathan Reese It's funny--

### Moderator
Claim: Do you mind standing?

### Moderator
Claim: Sure.

### Moderator
Claim: Thank you very much.

### Moderator
Claim: Jonathan Reese. It's funny that Eric Holders' name just came up, because he also said before Congress that the size of the banks was problematic in terms of prosecuting them. He then took it back because it had kind of slipped out and he didn't want to admit to that, but-- he did say that. Do you find that troubling?

### Moderator
Claim: Paul Saltzman.

### Scientific Advocate (SA)
Claim: Yes I did. Yes I do. No bank, no individual, no company should be too big to put in jail if they've violated the law, okay? That's point number one. Number two, have you read the newspapers lately? Okay? Do you think banks aren't being prosecuted every day and probably for political reasons? Eleven billion dollars of fines being suggested for activity that occurred prior to the acquisition of the companies that the government suggested they acquire?

So this notion that somehow banks are immune from prosecution is just simply not true. No bank should be too big to jail. No one who has violated the law should be immune. That's my position, and I would assume it's the position of the other debaters around this table.

### Conspiracy Advocate (CA)
Claim: If you remember there was the PBS documentary in which the deputy attorney general who is responsible for bringing prosecution actually said on camera that they've been reluctant to bring not just against JPMorgan Chase, other large financial institutions, they've been reluctant to bring the prosecutions. That gentleman left office very soon after that statement came out on television. Look, it's a very uncomfortable statement about American society and the American legal system, but honestly, that is where we are today. These banks are too big to prosecute effectively.

### Moderator
Claim: Sir, in the center. No, behind you. Gray jacket. And remember to stand up and tell us your name, please.

### Moderator
Claim: Hi. I’m a student at Blair.

### Moderator
Claim: So you're a student at Blair? Tell us about Blair for just a second. Is there a whole group of you here?

### Moderator
Claim: Yeah, there's a small group of us here right in the middle.

### Moderator
Claim: Are you the debating team?

### Moderator
Claim: Yeah. Well, a few of us are captains of a debating team, and--

### Moderator
Claim: Congratulations. Thanks for coming.

### Moderator
Claim: Well, this question is for-- this question is for the for side. In the scenario that you've proposed of the splitting of the big banks, how do you think the market will react to the splitting of these economic giants?

### Moderator
Claim: Richard Fisher.

### Conspiracy Advocate (CA)
Claim: I think the market would greet it with great applause, and I'll tell you why. Because the market would then gravitate to those with the most efficient delivery of services and all the services these gentlemen speak of rather than just assuming that they can conduct business with them because they're totally safe at all times. Only the most efficient would survive. That's what the American capitalist system is all about. If you're not efficient you should fail. If you're efficient you should succeed and grow. So, to me-- that's what we're talking about here. We're talking about taking away the fence of protection, that-- you don’t yet, but your parents as taxpayers, unless you're a very successful young debater-- provide, just taking away all those guarantees and just saying you have to stand up on your own legs just like anybody else to compete efficiently. And, by the way, it may be that XYZ Bank competes better than everybody else and has that business. That's fine with me, but I do not want to risk another penny of taxpayer money to bail them out when they make a big mistake, and I think that's exactly what will happen, and it will happen in bigger size and it will happen again and it may well, if things go poorly, happen before the waiting period that this gentleman mentioned.

### Moderator
Claim: Doug Elliot.

### Scientific Advocate (SA)
Claim: Yeah, just wanted to say we agree with you on the objective. We don't agree with you that what you're proposing will achieve that objective.

### Moderator
Claim: I want to go to another question. And I-- every now and then I have to do this, but I'd love to hear a female voice. And I'm not seeing any female. I see masculine hands. That other guy you could have told like your--

### Moderator
Claim: Female voice. Female hand.

### Moderator
Claim: Thanks.

### Moderator
Claim: Thank you. Hi. I'm Jen Pachichi I work at DPCC I have a question for Richard and Simon. So you're saying that these banks are all global in nature. And you're proposing to break up the U.S. banks. But how would you handle international banks like Barclays who have both commercial, retail, and investment banking divisions? How would they operate in America?

### Moderator
Claim: Richard Fisher.

### Conspiracy Advocate (CA)
Claim: One of the arguments you always hear is we have to be big because the others are big. And if not, they will dominate the world. You are a young woman. You probably are too young to remember. That was an argument made that the Japanese banks were to dominate the world, Nomura, et cetera. Or that French banks would dominate the world. It hasn't happened. It doesn't happen because they grow to such a size and scale that they're unmanageable. I don't fear international competition. I want to just be the best at what we do.

I want to make sure that our taxpayers are protected so that we don't get driven into the tank like we were before. And I do believe that we can be internationally competitive just by being outstanding. But we've had these fears before. These are protectionist fears. And by the way, they're nonsensical.

### Moderator
Claim: Another question? Sir, right in the center there. You thought I called on you before, and I called the guy behind you, but now it's you. If you can stand up when the mic reaches you, thanks.

### Moderator
Claim: Weston Onami I think I agree with Mr. Fisher's proposal. I don't know if the means you choose will achieve that end. I think the two biggest protections are the Dodd-Frank Act and the Federal Reserve. Shouldn't we be talking about breaking up the biggest public bank and their role in subsidizing the large banks that we have?

### Moderator
Claim: You mean the Fed.

### Moderator
Claim: Yes, the Fed.

What's the question?

### Moderator
Claim: Let's break up the Fed. Richard Elliot.

### Scientific Advocate (SA)
Claim: Richard, you want me to take that for you?

### Conspiracy Advocate (CA)
Claim: My opponents will give you a very good argument for why we should not break up the Fed.

### Moderator
Claim: Down in the front, there was somebody raising his hand before. Yeah. Mic's coming to you. If you don't mind also walking up a few steps to get into the camera light. Thanks.

### Moderator
Claim: I'm Mendel Lazarus. I'm a senior at Yeshiva University, an accounting student, just came to watch the debate. I had a question for Richard and Simon. And we've mentioned several times the complexities of these large banks, specifically JPMorgan, 4 trillion in assets, 80 trillion in these incredibly risky derivative swaps. In a sense, yeah, you're right, these are incredibly risky things that are so colossal. How would it-- I mean, somebody asked about the economy. But you're suggesting breaking all of this up? Who exactly do you think it is that's going to pick up the pieces and make this all function in a smoother way?

Take first shot?

### Moderator
Claim: Simon Johnson.

### Conspiracy Advocate (CA)
Claim: The problem is we’ve put huge subsidies behind these businesses. And particularly with the subsidies of-- behind the derivative book, for example, we are proposing to remove those subsidies. And we believe, because this is what we see around the rest of the American economy, that when you operate without the subsidies, you get efficiency, people who are not very good at running a business go out of business. Other people enter and take over. So that's the dynamic of American capitalism. All we want for banking and for the operation of these financial markets is what we have in the rest of the American economy. Why should JPMorgan and the people who run it be exempt from the way the rest of the American economy operates? What makes them so special, so different? Is it your point that they have become particularly dangerous because of the business they operate? You may be right that they are particularly dangerous. Then I think it's even more pressing issue of public policy.

### Moderator
Claim: Sir, can I ask you if you feel that your question was answered in the sense that you were-- I think you were looking for, tell me what this future looks like, what's going to happen.

### Moderator
Claim: Okay.

### Moderator
Claim: Richard Fisher.

### Conspiracy Advocate (CA)
Claim: A more efficient operator that doesn't need to be subsidized to operate will pick up that business. Let me give you an example. There are huge hedge funds that manage derivatives. With each increase in the risk position they take, they have to post greater margin. That does not occur at the XYZ banking institution you mentioned before. Why should they be different than-- why should they have different rules apply to them that are applied to everybody else in the industry? So, yes, it's a huge derivative book. And, by the way, it's also a question of how the derivatives are balanced in terms of risk. It could be 40-40.

They could offset each other or they could have their own capital at risk. When you place your own capital at risk and the number is less than 80 trillion-- I don't know what it is, "X"-- you should be subject to the same rules as anybody else who takes an at risk position. That's all we're advocating. And I'm sure and I know there are others that would take up those positions that were sound and replace the positions that that institution will have, but that's because they're better and more efficient operators and they don't operate with a subsidy.

### Moderator
Claim: All right. Let me bring in Paul Saltzman.

### Scientific Advocate (SA)
Claim: You know, look, it's-- been waiting for the moment to address this fictitious subsidy question, there's no subsidy, okay?

### Conspiracy Advocate (CA)
Claim: Oh.

### Scientific Advocate (SA)
Claim: There's no-- there's no transference of wealth--

### Conspiracy Advocate (CA)
Claim: I used love you. I don't love you anymore-- Richard, there is no subsidy. There is no empirical evidence to suggest that any taxpayer dollars are currently being transferred for the benefit of big banks. You're throwing out the term "subsidy" and creating this argument as if it's the agricultural industry that gets taxpayer dollars. What you're talking about, just to put it in the context, is allegations or assertions that banks-- somehow large banks borrow at funds cheaper than would otherwise be the case because of market perceptions that they will be bailed out—

### Moderator
Claim: Which seems like a quite reasonable and logical argument.

### Scientific Advocate (SA)
Claim: It's just not true.

### Moderator
Claim: Oh.

### Scientific Advocate (SA)
Claim: Okay? It's just not true, okay. Again, going back to your colleagues in the Federal Reserve System, okay, economists at the Federal Reserve Bank of Philadelphia--

### Conspiracy Advocate (CA)
Claim: There are lots of economists in the Federal Reserve, by the way.

### Scientific Advocate (SA)
Claim: I see, but only yours are right, Richard. But only yours are right

### Conspiracy Advocate (CA)
Claim: No, that's not--

### Scientific Advocate (SA)
Claim: A very well respected economist, okay, made it pretty clear, okay, that the growth of the large banks has everything to do with economies of size, scope, and scale, and not the subsidy. Secondly, evidence suggests that large institutions borrow at cheaper funds because they're larger, they issue more debt, they have liquidity premiums; more analysts cover them. Coca-Cola borrows more cheaply than RC Cola. Would you suggest breaking up Coca-Cola or calling that a subsidy? The fact of the matter is the deposit liability structure of banks is very complex and it's impossible to assess how and when cost of funds differentials are attributable to the too big to fail issue that you're--

### Moderator
Claim: Simon Johnson.

### Conspiracy Advocate (CA)
Claim: simply not true.

### Moderator
Claim: Simon Johnson.

### Conspiracy Advocate (CA)
Claim: You just summarized very nicely all the industry papers, the papers written by people who work for the big banks on this topic. If we look at the independent research, including a workshop at NYU that you helped to organize last week, as you know there were two very good--

### Conspiracy Advocate (CA)
Claim: --let me may I finish John?

### Moderator
Claim: Yes, you may.

### Scientific Advocate (SA)
Claim: But it's just not true.

### Moderator
Claim: Well, let him finish his point and then you can tell him

### Conspiracy Advocate (CA)
Claim: There were two very good papers by independent academics and groups of academics at that workshop just last week that showed there are substantial subsidies of the too big to fail kind that exactly we've been talking about. That was your own conference call. Why are you ignoring that evidence?

### Scientific Advocate (SA)
Claim: Why are you--

### Moderator
Claim: Paul Saltzman.

### Scientific Advocate (SA)
Claim: --ignoring Randy Kroszner’s paper, former governor of the Federal Reserve--

### Conspiracy Advocate (CA)
Claim: Randy Kroszner's paper--

### Scientific Advocate (SA)
Claim: --why are you ignoring Loretta Mester’s paper--

### Conspiracy Advocate (CA)
Claim: Randy Kroszner's--

### Scientific Advocate (SA)
Claim: --why are you ignoring all the papers that are against you? That's what you do, Simon.

### Conspiracy Advocate (CA)
Claim: Randy Kroszner simply--

### Scientific Advocate (SA)
Claim: You ignore everything that's against you and you--

### Moderator
Claim: By the way, everybody got the package of the papers. I want you to make your own judgments on this.

### Conspiracy Advocate (CA)
Claim: Randy Kroszner's paper was paid for by--

### Moderator
Claim: Wait, whoa, whoa, whoa. Dueling papers does not help us. And I realize that it's a serious point. I'm not making light of the fact, but it doesn't help us get anywhere because we can't evaluate them. So I-- I hope, Doug, you're not going to talk about a paper.

### Scientific Advocate (SA)
Claim: Just one very straightforward thing.

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: The papers you're talking about ended-- no, but it is straightforward-- the papers ended in 2010. That's three years ago. A lot has changed.

### Moderator
Claim: Okay. Let's go to-- thought that was pretty robust. Maybe I should have let it go. Sir, right down front. Seeing-- yes, there are fewer hands going up now. Questions have been great tonight, by the way.

### Moderator
Claim: My name is Joe Webber I'm a-- this question is a bit different I think than most of the others. I'm a veteran of the telecommunications wars of the 1980s when the government decided that AT&T was too big, effectively-- it was the world's largest corporation-- and broke it up into eight pieces. Well, now, some years later-- and that was not without cost or disruption either, it was a pretty complex operation to divest those companies-- and now here we are, 30 years, 25 years later, and we have two absolutely enormous companies, both of them bigger than AT&T was - -

### Moderator
Claim: So--

### Moderator
Claim: --back in 1984.

### Moderator
Claim: --so can you frame this as a question?

### Moderator
Claim: I'm sorry?

### Moderator
Claim: Can you frame your question as a question?

### Moderator
Claim: Oh, yeah, yeah, sure. So the question here is maybe we should take a lesson from that. And to my friends on my left, how are you going to make sure that the broken up pieces of all of these companies which are going to break up are not going to grow so large as to become threats to, you know, too big to fail again?

Are we going to play whack-a-mole with these people forever?

### Moderator
Claim: Richard, that's a question Richard Fisher.

### Conspiracy Advocate (CA)
Claim: For the first time I'm pleased to be called "somebody on the left." I have no problem with growth. I have no problem with size, per se. What I have a problem with is when it's subsidized by the American taxpayer. If AT&T were to fail today or if Verizon were to fail today we wouldn't bail them out with taxpayer money. We'd let them go. We'd say, "To hell with them." That's not what we do with too big to fail banks. In fact we have enshrined through Dodd-Frank in my opinion this infinite, constant, permanent subsidization of the protection using taxpayer money.

I don't care what the law says. I'm telling you how it works. And the way it works, and the way it has worked, and we've seen an example of it, so we had an implicit assumption they would be bailed out, and then we had an explicit confirmation they would be bailed out by the American taxpayer. All I want--

### Moderator
Claim: Richard--

### Conspiracy Advocate (CA)
Claim: --all I want is to make sure that, that never happens again.

### Moderator
Claim: Richard, you're--

### Conspiracy Advocate (CA)
Claim: And if someone can grow based on their efficiency, I'm all for them. But I will not protect them by putting your money at risk.

### Moderator
Claim: I'm not sure that you addressed this question. You may have, but you were returning to points that you made several times. And I think his question was, you know, you break up these or shrink these banks, what's to keep them from finding each other again and becoming big again? And he seemed to think that that was a concern. And it seems-- it's an interesting question, but I didn't think that I heard an answer to it.

### Conspiracy Advocate (CA)
Claim: Again, I want a level playing field. I want small banks to become big banks if they have the talent to do so and they do so without taking risks that will then come back to bite the American taxpayer on their--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --neck.

### Moderator
Claim: Oh, let me let the other side respond, sir, and then--

### Moderator
Claim: Sure.

### Moderator
Claim: Paul Saltzman.

### Scientific Advocate (SA)
Claim: Maybe this is a concession, maybe not, I will support legislation that ends subsidies. We have it already. I'm not exactly quite sure what you're looking for, Richard. The fact of the matter is the law prohibits taxpayer bailouts. No one wants a subsidy. No one wants firms to be artificially fueled by unfair advantage. We're in agreement as to the goal. The gentleman raised an excellent point. The fact of the matter is most companies with large fixed expenses like banks grow large for a reason. They can only be profitable because what they do requires size, scope, and scale.

### Conspiracy Advocate (CA)
Claim: Well, I'm glad to hear you support my proposition.

### Scientific Advocate (SA)
Claim: Goal.

### Moderator
Claim: My name is Fred Deutsch To the side opposed, if your position is that the scale and scope of JPMorgan allows it to be the most efficient compared to the smaller banks, why is it that JPMorgan is not the low cost mortgage provider in New York and can't execute international trade as efficiently as the smaller banks with whom we do business?

### Moderator
Claim: Doug Elliott.

### Scientific Advocate (SA)
Claim: Sure. First of all, here you're talking about one specific example. Every bank's going to have strengths and weaknesses. I don't think that the big strength of the banks we're talking about is their retail business, and it wouldn't surprise me if there are times when they don't have the great advantage there. Where I see the more compelling case is where you're talking about doing things that smaller banks just really can't do, period. The international trade, I'm not sure I could answer that. I'm sure there are people who would argue they do a nice job. I don't know enough about it.

### Conspiracy Advocate (CA)
Claim: So they're really good at managing big, complex derivative transactions in London. I think that was the answer.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate-- where our motion is "Break up the Big Banks." So here's where we are. We are about to move on to round three, round three, are brief closing statements by each debater in turn.

They will be two minutes each. Remember how you voted before the debate. Immediately after these closing statements you'll be asked to vote again. It's-- this is their last chance to change your minds before the second vote On to round three, closing statements. Our motion is this, "Break up the Big Banks." And here to summarize his position against this motion, Paul Saltzman, president of the Clearinghouse Association. Ladies and gentlemen, Paul Saltzman.

### Scientific Advocate (SA)
Claim: Thank you, John. And I'm going off script a little bit to basically say there's an awful lot we do agree with. There's an awful lot of the objectives that we do agree with. We just have different ways of getting there, but I know you've heard a lot of facts and figures and contradictory assertions, but let me ask you to just consider three simple practical facts. I ask you to remember that America needs global banks, and it reflects the global economy in which we live.

Unlike any era before, we live in a global economy. It's clear that our economy requires these international banks to support customers. The only question is whether America will sit on the sidelines or be part of that. Today, just four of the world's largest 25 banks are American banks. To break them up and reduce that number to zero jeopardizes America's leadership in the world and America's global leadership. We need solutions that move the financial system forward, not backward. I ask that you keep in mind that we can't roll back the clock. I know it's natural after the kind of disaster that we faced and the turmoil that we've all experienced to yearn for simpler, less complex times, but the American economy that was once served exclusively by small banks just no longer exists. The good old days weren't that good. The S&L crisis, the Great Depression, all were caused by systemic risks associated with smaller banks.

Rolling back the clock to restructure the banking system isn't realistic, and it simply wouldn't make us safer. I ask you to support Dodd-Frank, the macro-prudential reforms that are making it less likely for banks to fail. In closing, I know it feels good, but I submit that breaking up the big banks would create a host of new problems and solve almost none. We can do better and we should. Please vote no and oppose the proposition. Thank you.

### Moderator
Claim: Thank you, Paul Saltzman. Our motion is "Break up the Big Banks," and here to speak in summary in support of this motion, Richard Fisher, president of the Federal Reserve Bank of Dallas. Ladies and gentleman, Richard Fisher.

### Conspiracy Advocate (CA)
Claim: Thank you. I would submit that America needs competition. I would submit that America needs a level playing field. I would submit that America never again wants to expose its taxpayers to bailing out institutions that made bad decisions, because they were badly managed and they were encouraged basically to achieve a size and scale under the protection of the law.

I therefore strongly endorse taking action that would cordon off the guarantees we provide to these mega financial institutions and just make them subject to the same competitive rules that affect all other businesses. I ask you to support our motion to break up the too big to fail banks. Thank you.

### Moderator
Claim: Thank you, Richard Fisher. And that is our motion: "Break up the Big Banks," and here to speak against the motion in his closing statement, Doug Elliott, a fellow in economic studies at the Brookings Institution. Ladies and gentleman, Doug Elliott.

### Scientific Advocate (SA)
Claim: Thank you, John, and thank you everyone for the opportunity. This is an important question. Let me repeat what Paul said. The overall objectives you've described, Richard, and I think Simon, we would agree with. I focus on two points why I don't agree with your actual proposal.

First is I'm still a little unclear exactly what it is and how it relates to the actual thing we were supposed to debate, and for me that's an important point, but beyond that-- beyond that, I do believe that from the years of experience I had working in the industry that the customers really have seen major advantages. A lot of the growth has been customer driven, and I do want to say, Richard, early on you were describing bankers who were deliberately creating excessively large firms for the sake of being excessively large, opaque firms for the sake of maximizing the subsidies. I worked in M&A in finance working with financial institutions. I never once in the 20 years ever talked to anybody who, even in private conversations, had any of those things as their objectives.

Now I can understand if you want to make the argument that the incentive structure pushes things that way, but I would strongly urge backing away from language that both of you at times have used that argues that the bankers are deliberately trying to create their firms in such a way that they get these subsidies. I think I'll leave it there. I'd urge you to vote against the motion.

### Moderator
Claim: Thank you very much, Doug Elliott. And that is our motion: "Break up the Big Banks." And here to summarize his position in support of the motion to break up the big banks, Simon Johnson, former chief economist at the IMF, professor at MIT Sloan School of Management. Ladies and gentlemen, Simon Johnson.

### Conspiracy Advocate (CA)
Claim: In 1902, the administration of Teddy Roosevelt brought an antitrust action against Northern Securities. A very large railroad company in the northwest part of the United States.

It was one of the first actions of its kind. It was extremely controversial. A lot of people in the mainstream didn't know what Roosevelt was doing. There were plenty of arguments made that these monopolies were modern, they were efficient. They would benefit the American economy. J.P. Morgan, the original J.P. Morgan, the man, came to the White House in February 1902. And he said to Roosevelt and to his attorney general, "If we've done anything wrong, send your man to see my man, and we'll fix it up." And Roosevelt and his attorney general, thank goodness, said no. We don't want to fix it up. We want to stop it. This, in Roosevelt's mind, was an excessive concentration of power. It was dangerous to the democracy. They took that case all the way to the Supreme Court.

They won it 4 to 3. And out of that came a lot more precedents, antitrust cases, more legislation and, I would submit, the really important change was a shift in the consensus, people like you in New York in 1902 didn't know what Roosevelt was doing or why it made sense. They thought, many of them, it'd be bad for business. In 1911, when the government moved to break up Standard Oil, there were very few defenders of huge monopolies. People understood concentrated power can be very damaging in this democracy. Vote for the democracy. Vote to break up the big banks. Thank you.

### Moderator
Claim: Thank you, Simon Johnson. And that concludes our closing statements. And now it's time to learn which side do you feel has argued best. We're asking you again to go to the key pads at your seat that will register your vote.

We're going to get the readout on this almost instantaneously. Press number one if you are for the motion, press number two if you are against the motion, and press number three if remain or became undecided. And again, we're going to lock that out in a second, and then we are about two minutes away from having the results. A few things I want to take care of. First of all, some news headlines, as we've been debating, the Senate has passed a measure to end the shutdown and to raise the debt limit. President Obama began speaking on television five minutes ago, but nobody leaves. And the House is expected to follow suit tonight. I also want to say this about this debate. It was really terrific. These debaters obviously feel passionate about this.

They have a shared common ground, but they have very, very honest disagreements that were honestly argued. And I want to congratulate for the way they did this tonight. I also again want to thank the Richard Paul Richman Center for Business Law and Public Policy for being our partner in this. We love having them onboard, and they've been extremely helpful. So thank you to them as well. And the last thing I want to say is, sometimes I said at the beginning, the questions can be pretty dodgy. But tonight's questions were terrific. And I want to congratulate every-- we didn't throw one out. Everybody got in. And I want to congratulate everybody who has the guts to get up and do it because it's a scary thing to do. So thank you for that. We would love it if you would tweet about this debate. Our Twitter handle is @IQ2US. And the hash tag tonight is #BigBanks. Our next debate here at the Kaufman will be on Wednesday, October 30th.

Our motion is, "Let Anyone Take a Job Anywhere." arguing in support of this motion, Bryan Caplan. He's an economist. He's a leading proponent of open borders, which he describes as the efficient, egalitarian, libertarian, utilitarian way to double the world GDP. His partner is Vivek Wadhwa. He's an academic and entrepreneur who has debated with us before. He's been named one of the 40 most influential minds in tech by Time magazine. Arguing against this motion, Kathleen Newland. She is cofounder of the Migration Policy Institute where she studies the relationship between migration and development. Her partner is Ron Unz, a former businessman and political activist, publisher of the American Conservative for six years. Tickets to that debate are available at our website, www.iq2us.org. This Friday, in two days, October 18th, we're having an intelligent lunch. We'll be in California debating the motion which is, "For a Better Future, Live in a Red State." You can-- yeah. Where are we? You can watch the live stream of this debate at noon here on the East Coast. And it's 9:00 a.m. on the West Coast. And for those who can't get to that live audience, and if you want to get on the plane, you're welcome. There are a lot of other ways to catch these debates. You can watch the live stream on our site, iq2us.org or fora.tv. And as I said before, listen to these debates on NPR stations across the nation. And you can also download the podcast. And we're, of course, on Twitter and Facebook. And we welcome your feedback and topic ideas. And speaking of ideas, we had put out a little bit of a note to people on our website asking them to please reconfigure the letters TBTF. What else could it stand for? We said we would read a couple of them that were kind of nice. So the two that I like, a guy named John in Brooklyn, New York, said he has advice for the secret service, TBTF, "Trust but then frisk." Marcella Rosen, also of New York, I just like it too much, "Too beautiful to forget." All right. The results are in now. Our motion is this: Break up the Big Banks. We have had you vote twice, both before the debate and once again after the debate. Remember, the team whose numbers have changed the most in percentage point terms will be declared our winner. Here was the result of the preliminary vote on the motion, "Break up the Big Banks." Before the debate, 37 percent of you agreed with this motion. 19 percent were against. 44 percent were undecided. So those are the first results. Remember, the team that moves the numbers the most from first vote to second is declared our winner. Here is then the second vote. The team arguing for the motion, their second vote was 49 percent, from 37 percent to 49 percent. That is an increase of 12 percentage points. That is the number to beat. The team against the motion, and their first vote was 19 percent.

Their second vote, 39 percent. That's 20 percentage points above. They did it. The team arguing against the motion has won this debate, "Break up the big banks." They have defeated that motion, "Break up the big banks." Congratulations to them, and thank you from me, John Donovan and Intelligence Squared U.S. We'll see you next time.
