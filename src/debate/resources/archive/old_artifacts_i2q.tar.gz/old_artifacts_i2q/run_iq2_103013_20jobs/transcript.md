# Debate Transcript

Topic: Let Anyone Take A Job Anywhere
Motion: Let Anyone Take A Job Anywhere

Debate ID: 103013%20jobs


## Round 1

### Moderator
Claim: And I now want to bring to the stage the chairman of Intelligence Squared U.S. What we normally do before the debates, and we're going to do it now, is spend a couple of minutes framing this debate and why we picked it and what we're hoping for to come from the debate. So I'd like to bring to the stage now the gentleman who brought Intelligence Squared U.S. to New York City. Let's please welcome Robert Rosenkranz.

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hi, Bob. So we do various kinds of motions. Sometimes it's right out of the headlines. It's a policy choice. We've done "Repeal Obamacare" or "Abolish the Minimum Wage." And then we do others that are a judgment on the state of things like "science refutes God." Tonight we're doing one of our, "What if," kind of hypothetical debates. It's a different shape of an argument. Tell us about what we're doing tonight.

### Moderator
Claim: Well, of course, as I'm sure you've said, this is not a debate about immigration. It really is an experiment and a debate about pushing free market ideas to the limit. And we actually did an experiment like that a couple of years ago with a debate on the resolution, "Legalize a Market in Human Organs." And it proved to be one of the most successful debates we'd ever done.

### Moderator
Claim: Even though it's not going to happen probably in our lifetime. The point was to explore the pros and the cons and the ethical issues involved.

### Moderator
Claim: Exactly.

### Moderator
Claim: So tonight's debate, how radical a notion really is it to let anyone take a job anywhere?

### Moderator
Claim: Well, it is not that radical a notion. It's a notion that's been applied for decades in the European Union. And the result has been very good for people who employ migrant labor. It's been very good for the people who use their services and the customers. It has not been so good for people who have to compete. And in Britain they call this the Polish plumber problem.

### Moderator
Claim: And when you look at this motion language, “Let Anyone Take a Job Anywhere," how literally do you think that we should expect the debaters to be arguing "anyone anywhere"?

### Moderator
Claim: Well, the motion language is pretty extreme, I must admit, and not terribly nuanced, but a motion that said, let more people take more jobs in more places would hardly have been a good debate. But I would expect--

### Moderator
Claim: Everybody would be against that, right?

### Moderator
Claim: I would expect, though, that we're going to hear tonight ideas about how to take the free market further in the context of labor markets. So, for example, it would hardly be that radical to have a treaty between the United States and the EU and Canada providing for free market of labor in those areas. But I think we're going to learn a lot tonight about the various aspects of a complicated topic.

### Moderator
Claim: All right. Thanks, Bob. Very much. And I would like to now invite our debaters to the stage.

### Moderator
Claim: Thank you, John. Thanks.

### Moderator
Claim: The lights were a little soft on me up here, and I was just waiting for them to come up. It's not an ego thing. It's a camera thing. Before we start, though, again, I just want to thank Bob Rosenkranz for bringing these debates here, and just want to ask them for one more round of applause for that.

One of the oven overlooked assumptions about life in these United States is that built into that word "united," that we're all part of the same polity and that-- and we have the rights within our borders to go anywhere we want in pursuit of a job. You're from North Dakota, there is nothing in the law to stop you from going to get a job in North Carolina. And Europe has taken that idea a lot further with one shared open market for two dozen plus countries so that a chip maker in Dublin or an insurance company in Sophia can hire the best people affordable from Finland to France or from Estonia to Austria.

So what is the lesson? Or more to the point for us, what if the U.S. set out to make deals, partnership deals, with other open labor markets? Say the U.S. does a deal with Europe, the U.S. and Canada or the U.S. and India or the U.S. and China. When the barriers to labor fall, who would gain and who would lose? Now, this is a big what if but it sounds like there's a lot to debate in there. So let's have it, yes or no to this statement, “Let Anyone Take a Job Anywhere," a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kauffman Music Center in New York City. We have four superbly qualified debaters, two against two, who will take opposite sides on this motion, “Let Anyone Take a Job Anywhere." Our debate as always goes in three rounds, and then the audience votes to choose a winner, and only one side wins. Our motion, again, is “Let Anyone Take a Job Anywhere." And now let's meet the team first that is arguing for the motion. Ladies and gentlemen, please welcome Bryan Caplan. And, Bryan, you are a professor of economics at George Mason University. You are a well-known proponent of open borders. You wrote a book called, "The Myth of the Rational Voter," in which you puzzled over the question of why democracies so often make bad policy choices. You list price controls and protectionism and other populist policies that you say most economists would never vote for. So we're just wondering, tonight we have 400 people in the audience, if these were all economists in front of you, would your side have the advantage tonight?

### Conspiracy Advocate (CA)
Claim: Probably a slight advantage. Economists are definitely much more pro-immigration than most Americans, but economists also don't like to be extreme. I'm an exception.

### Moderator
Claim: All right, thank you. Thank you, Bryan Caplan, ladies and gentlemen. And, Bryan, your partner is?

### Conspiracy Advocate (CA)
Claim: Vivek Wadhwa, god of Twitter.

### Moderator
Claim: Ladies and gentlemen-- let's welcome Vivek Wadhwa. Vivek, you are also arguing for this motion, “Let Anyone Take a Job Anywhere." You are vice president of research and innovation at Singularity University. You are a fellow at Stanford Law School. Before joining academia you actually started two software companies. You were born in India. You went to NYU Business School, became a naturalized citizen in 1989. Just curious, if this were all happening in your life now, business school, 2013, 2014, would you go to India now or would you still want to stay here?

### Conspiracy Advocate (CA)
Claim: John, I wouldn't have had a choice. I couldn't get a visa. We will close the doors. We'd lock the borders. We're turning away brilliant people because of our flawed immigration policies. So I would have had to leave.

### Moderator
Claim: Well, you're here now.

### Conspiracy Advocate (CA)
Claim: I'm here now.

### Moderator
Claim: Ladies and gentlemen, let's welcome Vivek Wadhwa. Our motion is “Let Anyone Take a Job Anywhere," and now let's meet this team that is arguing against this motion. First, ladies and gentlemen, let's welcome Kathleen Newland. Kathleen, you are cofounder of the Migration Policy Institute. You study migration, development, refugee protection. You have advised the U.N. high commissioner on refugees and the International Labor Organization. And part of what inspired you to go into this field is something that you did at a very young age. You were 16 years old, and you were an exchange student where?

### Scientific Advocate (SA)
Claim: I went to Calcutta at the age of 16, very brave parents. It is an experience that utterly changed my life.

### Moderator
Claim: And that's how you ended up in a way here. Ladies and gentlemen, let's welcome Kathleen Newland. And, Kathleen, your partner is?

### Scientific Advocate (SA)
Claim: Ron Unz.

### Moderator
Claim: Ladies and gentlemen, Ron Unz. you have one of those very, very disparate resumes that Intelligence Squared loves. You're a physicist by training. But then you were a founder and chairman of Wall Street Analytics, which is a financial services software company. Then you ran for governor of California. Then you were a publisher of the American Conservative. You've been described, quote, unquote, as a "nerdy guy who lives and breathes policy and politics." And I hope you know that in the Intelligence Squared universe that makes you a sex symbol.

### Scientific Advocate (SA)
Claim: Well, I guess we'll find out when the vote takes place.

### Moderator
Claim: Ladies and gentlemen, our debaters. Now, I want to remind you that this is a debate. It's a contest. There will be a winner and a loser, and you, our live audience at the Kauffman Music Center here in New York City, will choose the winners by voting twice, once before the debate and once again after the debate. And the team whose numbers have moved the most in terms of your support for their side of the motion in percentage point terms will be declared our winner. So let's go to our preliminary vote. You go to those keypads at your seat, and look at numbers one, two, and three. You can ignore the other ones. But if you look at our motion: Let Anyone Take a Job Anywhere-- and if you agree with that at this point, you want to push number one. If you disagree with that, you want to push number two. And if you're undecided, you want to push number three. And if you push the wrong button, you can just correct yourself. The system will lock in your last vote. Then again, at the end of the debate, we'll repeat that exercise. Again, the team whose numbers have changed the most in percentage point terms from their opening positions will be declared our winner. And at the end of the debate, it takes us about 90 seconds to get that calculation taken care of. Jon, I just want to ask if I could get a pen at some point. But-- wait, don't you need that for-- oh, great, thank you. Okay. Perfect. Thank you. This has all these secret messages. There's been notes written on here. Crib notes. That's the wrong pen. All right. Onto Round 1-- opening statements from each of our debaters. They will be seven minutes each, uninterrupted. Our motion is this: Let Anyone Take a Job Anywhere. And speaking first for the motion, Bryan Caplan, a professor of Economics at George Mason University and Senior Scholar at the Mercatus Center. Ladies and gentlemen, Bryan Caplan.

### Conspiracy Advocate (CA)
Claim: Let Anyone Take a Job Anywhere. Given current policy, it does sound radical. But notice, the resolution does not say "Let Anyone Become a Citizen Anywhere.” The resolution does not say "Let Anyone Collect Government Benefits Anywhere.” The respondent does not say "Let Anyone Vote Anywhere.” The resolution only says that no matter where you're born, it should be legal for you to accept a job offer from a willing employer.

The resolution parallels-- let any woman take a job anywhere, or let any Jew take a job anywhere, or let any black take a job anywhere. The resolution is not a request for charity and it is not a demand for government help. It simply asks the world's governments to stop requiring discrimination against foreign workers. But most arguments focus on high-skilled, high-tech workers. I outsourced this topic to my partner, Vivek Wadhwa. I'm going to focus on the vast majority of would-be immigrations who aren't high-skilled or high-tech. Haitian shoe shines. Nigerian waiters. Mexican gardeners. Bangladeshi farmers. Now, why on earth shouldn't we require discrimination against such people? Who would want them? You know, the same reason that we shouldn't require discrimination against women, against Jews, or against blacks. They're fellow human beings.

And they count. Now, suppose the world's governments made it illegal for Ron to work anywhere but Haiti. Would that be morally acceptable, to trap Ron in Haiti for the rest of his life? Mandatory discrimination against foreigners is especially awful, because most of the world's workers earn vastly more in the first world than they ever could at home. Moving from Haiti to Miami increases your wages by about 20 times. That is not plus 20 percent. That is not plus 200 percent. That is plus 2,000 percent. Now, you could object that we're not obliged to help total strangers. You know, you'll say-- but the important point is, remember, allowing someone to take a job is not charity. Let me repeat that. Allowing someone to take a job is not charity. What is it? It's call minimal decency. So, suppose that Kathleen were to get a job. If I refrain from slashing her car tires on her first day of work, that does not make me a philanthropist. I am not starting the "Save Kathleen Newland Fund" when I don't vandalize her car.

I'm merely leaving Kathleen alone. Now, sometimes tragically, just leaving someone alone has enormous costs. For example, if someone has bubonic plague, a quarantine really is the lesser evil. If you leave the person with bubonic plague free to roam, he could kill millions of people. Would open borders wreck comparable harm on our economy? No. Every scholarly estimate of the economic effects of open borders finds enormous overall benefits. Economist Michael Clemens, the world's expert on this topic, finds that a free global labor market would roughly double global production. Now, this point he makes-- double, how is it possible to double global production? Well, consider this thought experiment. Imagine there were a billion farmers stuck in Antarctica farming the snow. All right. I don't know a lot about farming, but it sounds tough. All right. Now, suppose we were to let these billion farmers move from Antarctica to anywhere else. Anywhere with decent soil, decent weather, decent conditions.

Well, obviously, the billion Antarcticans would be way better off when they get to leave Antarctica. But they are hardly the only beneficiaries. The other beneficiaries of allowing them to leave Antarctica are everyone on earth who eats food, everyone on the-- everyone on earth who eats food benefits from that greater availability of food. Now, economically speaking, Haiti and Bangladesh really are like Antarctica. They're countries where workers realize only a small sliver of their full potential. Ask yourself this: What is the best job that you could get in Bangladesh? Not very good. Now, wouldn't open borders hurt American workers? Some. Take me. I am a native born college professor. Thanks to a massive immigration loophole, virtually any PhD in the world can legally compete with me in the U.S. labor market. As a result, about half of all U.S. research professors are foreign born. This has slashed my wages and my career prospects. Right now, there is probably an immigrant sitting at Harvard in the office that is supposed to be mine.

Now, is my sad, sad story a good argument for immigration restrictions? Sure, it's a great argument. Wait. No, it's a terrible argument. Professorial immigration is bad for me, but it's good for consumers of education. If you're glad that you didn't pay even more for your college education, thank an immigrant. The same goes for every occupation. Immigration of waiters is bad for native born waiters, but it's good for diners. Immigration of gardeners is bad for native born gardeners, but it's good for homeowners. So how on earth could we ever judge the overall effect? There is a very simple answer. Keep both eyes firmly on production. Keep both eyes firmly on production. When global production doubles, your standard of living is very likely to rise. This is not trickle-down economics. It is Niagara Falls economics.

Now, what about the endless, noneconomic complaints about immigration? I'm sure we'll get into an enormous number as we go on. So I will just give you a general rule for how I respond to all of them. Here is the rule: For any complaint you have, there is a cheaper and more human main remedy than mandatory discrimination against foreigners. Immigrants have used the welfare state. Let them work, but not collect benefits. Immigrants damage the environment. Let them work but tax their pollution. Immigrants vote the wrong way, let them work but not vote. Immigrants hurt well- skilled Americans. Let them work but charge immigrants an admission fee or a surtax. Then use those funds to compensate native workers who lose out. If you think these remedies are unfair, they are certainly less unfair than turning honest workers into criminals just because they were born in the wrong country.

To conclude, let--

Let anyone take a job anywhere. It is the right way to treat your fellow human beings. It will transform the world for the better, and it will cost us less than nothing. Thank you.

### Moderator
Claim: Thank you, Bryan Caplan. And our motion is, let anyone take a job anywhere. And here to speak against the motion, I'd like to introduce Ron Unz. He founded the financial services company Wall Street Analytics and is the former publisher of the American Conservative. Ladies and gentlemen, Ron Unz.

### Scientific Advocate (SA)
Claim: I'll admit, when I was first approached with this topic, the resolution being, “Let Anyone Take a Job Anywhere," I thought the idea was so crazy it would be very hard to get anybody lined up on the other side. But obviously we've found a couple of intelligent people to do that.

Let's think a little bit about what this means. Now, you know, I'm laboring under a disadvantage in this debate because not only am I not a trained economist, I've never even taken a class in economics.

I've never even opened an economics textbook. I personally don't claim to really understand most economics. I'm not convinced everybody else understands economics that well either. But one part of economics that is very well-established, a very simple issue, is the law of supply and demand. Think of what production means. The two main factors in production are labor and capital. Together, those factors produce everything we have in our society. Allowing an unlimited number of additional workers from everywhere in the world to come here and take jobs would massively, massively increase the supply of labor. The result would be tremendously disadvantaging labor at the expense of capital. In effect, order workers, ordinary citizens, people basically who work for a living would be tremendously economically disadvantaged by the fact that they would be competing against a billion, 2 billion, 3 billion, an unlimited supply of additional foreign workers who would take the job for whatever wage they could.

It's true, certainly, there would be a huge increase in economic production, productivity, GNP. But almost all of it, and possibly even more than all of it would be captured by capital, captured by the wealthy people on that side of the equation. In other words, what we're talking about is something that would be very beneficial for the top 1 percent, .1 percent, 2 percent, 5 percent, the wealthiest segment of American society. They would benefit, no doubt about it. Everybody else would suffer. I think that's very clear, because when you're talking about basically a hundred million or 150 million American workers, suddenly competing in an open labor market with a billion or 2 billion or 3 billion impoverished people from everywhere else in the world, they certainly would suffer.

Now, let's think of what really has happened in American society over the last 20, 30, 40 years. The late Daniel Patrick Moynihan, over 20 years ago, pointed out that for two decades there had been no increase in average wage income in the United States. The standard of living of ordinary American workers had been stagnant for two decades. He said that 20 years ago. It's now been 40 years. The income of the average American has been stagnant or declining for 40 years now, which is a shocking statistic that most people are not aware of. Clearly, there have been advances in technology so that in many ways people have a much better life than they did before with iPhones, with Google, with things like that. But in terms of real income, people are basically the same or poorer than they were decades ago.

And as Moynihan pointed out in the '90s, that's the longest period of economic stagnation that has happened in North America since European settlement began hundreds of years ago. Now, is it entirely coincidence that 40 years of economic stagnation for ordinary American workers is the same 40 years that has seen one of the highest rates of foreign immigration to the United States in our history? I think it's more than a coincidence. The point is, if you have a huge influx of willing workers from abroad, able to take any job they could because they come from poor countries, you're going to drive down the wages of ordinary American workers who are competing with them. Allowing anyone to take a job anywhere in effect would convert America's minimum wage into its maximum wage. And if you see the complaints right now over the 1 percent, over the wealthy elite who have tremendously benefited in the last few decades, while ordinary people, ordinary people in New York City or other places around the country have suffered, that would be tremendously exacerbated if you brought in tens or even hundreds of millions of impoverished workers from other countries to take their places.

Now, the point is, when you're talking about the result of economic stagnation in the United States that has now gone on for 40 years for ordinary workers, the end result at some point may be severe political backlash. And that sort of thing is inevitable. The reason America in its history, largely avoided the disastrous political results of many European countries is that every decade Americans were wealthier and better off than they were before. That's no longer true today. And it's no longer been true for 40 years now. Allowing an unlimited number of impoverished foreign workers to come to the United States would obviously make that situation incredibly much worse. And the result would be an economic disaster.

It's true that possibly 1 percent or 2 percent or even 5 percent of Americans would benefit tremendously from that change. But probably 90 percent of the American population would suffer economically. And they are the people who vote. They are the people who can protest. And their views would certainly be made known. And the result would be tremendous political backlash. We have to ask ourselves whether one reason for many of the problems we've had in the last few decades economically is because the glorification, the amplification of theoretical concepts that may look very good to pure economic theorists, people basically spend their time in the ivory tower, but don't understand that ordinary workers suffer when their incomes don't rise for 40 years. And I think, unfortunately, that's probably true today. One other aspect of the American political dynamic has been that there's an increasing centralization of politics in the hands of wealth; in other words, the people who fund the campaigns, the organizations that fund the campaigns.

And when you have the wealthy people benefiting tremendously from a proposal like this, and everybody else suffering. But when the wealthy people fund the politicians, they fund the think tanks, they fund the universities, they fund the journals; it's not too surprising that some of these ideas become very common in such circles even if the end result would be disastrous for the United States. The bottom line is that letting anyone take a job anywhere might sound good in theory but it would destroy the United States and destroy the lives of ordinary workers. Thank you very much.

### Moderator
Claim: Thank you, Ron Unz. And a reminder of what's going on, we are halfway through this opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two on opposite sides of this motion, "Let anyone take a job anywhere." You have heard the first two debaters, and now on to the third.

Let's welcome to the lectern Vivek Wadhwa. He is the vice president of research and innovation at Singularity University and a fellow at Stanford Law School. He is arguing for the motion, "Let anyone take a job anywhere." Ladies and gentlemen, Vivek Wadhwa.

### Conspiracy Advocate (CA)
Claim: You know, I've read Ron's writings. I've watched his videos. And that's not the Ron that I've read. The Ron that I've read about is not one of these Tea Party anti-immigrant people who goes around creating fear about the billions who are going to invade America and take away our jobs and so on. Those are the debates that are happening in Washington, D.C. by a small segment of Congress, which has been elected through a gerrymandered electorate. That is not the real world. That is not how Americans think. The fear we've had about Mexicans coming in and taking our jobs away, they're-- and then Indians coming in and taking our jobs away, they've not been founded.

Now, Bryan explained what's happening in the unskilled sector. I've been researching systematically what's happening in the skilled sector, because you have the same fear mongering happening in skilled immigration, that, "My God, these Indians, they're going to come and take our jobs away. If we expanded which one be the American workers, we all be unemployed." The exact opposite is happening. America is the most competitive land in the world. We have reinvented ourselves over and over again. Diversity rules over here. Look at New York City. It is diverse as could possibly be. The economy is thriving. People are doing much better.

Look at the benefits we've seen from technology, all of the advances that Ron talked about, our iPhones, our Googles. The fact is the world is connected right now. We have more knowledge than we've ever had. Knowledge has become free. It used to be that if you needed to get information about your health you had to go to your doctor. That's it. Now you just Google and download apps and you have medical information readily at your fingertips. That happened because of technology. And you know who's been building these technologies?

Immigrants, 52 percent of the startups in Silicon Valley during the most innovative period in recent economic history were founded by immigrants, people like me, people like this audience, people who came here because they saw opportunity, they were highly educated, and they decided to bring their knowledge and their intelligence with them over here and make America a competitive place. This is what's made this land what it is. In every generation there were people like-- I mean this is not Ron. I mean I could have-- I've heard his-- actually I've seen his writing. This was not-- I don't believe what he just said over here. Every generation-- in every generation there have been people who said that "If we let these Irish in, if we let these Poles in, if we let these Jews in, if we let these people in our jobs will go away." And guess what happened? These immigrants made Americans work harder, think smarter, compete, and this became the only innovative economy in the world. We lead the world because of innovation, because we open our borders, and because we allow people to come in here. Now, that's one perspective. The other perspective is that I hate to tell you this but the cat is already out of the bag. How many of you check email when you go home? All of you do. Right? Now, when you go on vacation, do you check email?

All of you do. Well, most of you do. Let’s say you decided to work for six months in South America and your job was highly-- a knowledge job, as are many jobs increasingly right now, you'd be working from anywhere. Therefore, anyone else could work from anywhere as well. You know, this is getting a little bit off topic, but the point I wanted to make was that already we are in a borderless economy when it comes to knowledge. We are in a knowledge economy. Knowledge jobs can be done anywhere. Boeing has engineers working in four or five different countries at the same time, designing aircraft systems, as do most companies. If you-- and maybe you work for large corporations. I'm sure you've had meetings with people in all corners of the world. You're working together because of what technology has made possible. We are already in a borderless economy. I live it. I have a job at Duke University, yet I live in Silicon Valley.

My dean over there allows me to work from anywhere I want to work. I also work for Stanford. I also work for Singularity University. I also have a role at Emory University. I'm able to be at many different places because I can go over the Internet and now teach lectures. I can do research. I can do the things I needed to do. One of the things I've been researching is the role of women in innovation or the lack of women in innovation, the fact that they're left out of the innovation economy. It's something I feel very passionate about. I did a research project. I had a team leader in Washington D.C. I had other researchers in New York City. We needed a website; we got it built at Stanford. And we needed a video. We got it done in Estonia. I want to crowd-create a book. I put the word out there, I'm looking for people to help me with social media. I had 300 women all over the world sign up to be my ambassadors. I wanted to now crowd-edit the book. I had 500 women all over the world telling their stories. I could do within six weeks the research that would have taken me years and years to do by using the power of the Web, by using the power of technology, and by letting people work from anywhere.

This is a new world. And I crowd-created a book on innovation. This would have been unconceivable even five years ago. So you talk about the damage that open borders are doing. I'm sorry. It's happening right now. The topic we're talking about is let the jobs do anywhere. No one said, "Let the migration be anywhere.” No one said that a billion Mexicans have to come to the USA and take our jobs away. Because we have the unskilled jobs, which Bryan will talk more about, and we've got the skilled jobs. The skilled jobs is what most of us in this room do. They can be done anywhere, because we're knowledge workers and we're in a knowledge economy. We're now connected to the Internet. Anything can be done anywhere. And it's happening. Over the last five years, we have not seen a decrease in productivity. We've seen an increase in productivity. I'm more capable right now-- I'm more connected right now. I go on Twitter and I tweet, "I need some information," and I have hundreds of people all over the world now doing my research for me and providing me back what I need. That's the power of connectivity, the Web.

That's the world we're in right now. And we have the free flow of information. We have open borders right now on the Internet. That didn't cause our productivity to decrease or our jobs to go away or the catastrophe that, you know, my opponents are saying. It's caused me to be more productive. It causes you to be more productive. It causes you to be smarter. Your children right now have access to the world knowledge. They just get on their iPads or their iPhones and they're connected to everyone else by social media, by Twitter. They're able to go into websites. They're able to gain knowledge from everywhere. They would hire in New Delhi or get video production done in Estonia, like I did. This is a new world we live in. It's all open. And it's not falling apart. We're moving up the ramp. This is the most productive, most innovative period in human history, when the world will come together and start solving problems. There's not going to be a mass migration to America, because as we see, from Mexico, the numbers have actually dropped. As the economy in Mexico rises, there's less incentive for them to come over here.

If they can do knowledge work for us where they are and contribute to our intellect and our knowledge, they will do that. They don't want to be here. They love being where they are. No one is fleeing to America because, you know, they want to. They do it because they have to. So, let's uplift the whole world. Let's make the world a smaller place and everyone wins. It's a better world. It's a better economy. And we solve major problems.

### Moderator
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: All of you do. Well, most of you do. Let’s say you decided to work for six months in South America and your job was highly-- a knowledge job, as are many jobs increasingly right now, you'd be working from anywhere. Therefore, anyone else could work from anywhere as well. You know, this is getting a little bit off topic, but the point I wanted to make was that already we are in a borderless economy when it comes to knowledge. We are in a knowledge economy. Knowledge jobs can be done anywhere. Boeing has engineers working in four or five different countries at the same time, designing aircraft systems, as do most companies. If you-- and maybe you work for large corporations. I'm sure you've had meetings with people in all corners of the world. You're working together because of what technology has made possible. We are already in a borderless economy. I live it. I have a job at Duke University, yet I live in Silicon Valley.

My dean over there allows me to work from anywhere I want to work. I also work for Stanford. I also work for Singularity University. I also have a role at Emory University. I'm able to be at many different places because I can go over the Internet and now teach lectures. I can do research. I can do the things I needed to do. One of the things I've been researching is the role of women in innovation or the lack of women in innovation, the fact that they're left out of the innovation economy. It's something I feel very passionate about. I did a research project. I had a team leader in Washington D.C. I had other researchers in New York City. We needed a website; we got it built at Stanford. And we needed a video. We got it done in Estonia. I want to crowd-create a book. I put the word out there, I'm looking for people to help me with social media. I had 300 women all over the world sign up to be my ambassadors. I wanted to now crowd-edit the book. I had 500 women all over the world telling their stories. I could do within six weeks the research that would have taken me years and years to do by using the power of the Web, by using the power of technology, and by letting people work from anywhere.

This is a new world. And I crowd-created a book on innovation. This would have been unconceivable even five years ago. So you talk about the damage that open borders are doing. I'm sorry. It's happening right now. The topic we're talking about is let the jobs do anywhere. No one said, "Let the migration be anywhere.” No one said that a billion Mexicans have to come to the USA and take our jobs away. Because we have the unskilled jobs, which Bryan will talk more about, and we've got the skilled jobs. The skilled jobs is what most of us in this room do. They can be done anywhere, because we're knowledge workers and we're in a knowledge economy. We're now connected to the Internet. Anything can be done anywhere. And it's happening. Over the last five years, we have not seen a decrease in productivity. We've seen an increase in productivity. I'm more capable right now-- I'm more connected right now. I go on Twitter and I tweet, "I need some information," and I have hundreds of people all over the world now doing my research for me and providing me back what I need. That's the power of connectivity, the Web.

That's the world we're in right now. And we have the free flow of information. We have open borders right now on the Internet. That didn't cause our productivity to decrease or our jobs to go away or the catastrophe that, you know, my opponents are saying. It's caused me to be more productive. It causes you to be more productive. It causes you to be smarter. Your children right now have access to the world knowledge. They just get on their iPads or their iPhones and they're connected to everyone else by social media, by Twitter. They're able to go into websites. They're able to gain knowledge from everywhere. They would hire in New Delhi or get video production done in Estonia, like I did. This is a new world we live in. It's all open. And it's not falling apart. We're moving up the ramp. This is the most productive, most innovative period in human history, when the world will come together and start solving problems. There's not going to be a mass migration to America, because as we see, from Mexico, the numbers have actually dropped. As the economy in Mexico rises, there's less incentive for them to come over here.

If they can do knowledge work for us where they are and contribute to our intellect and our knowledge, they will do that. They don't want to be here. They love being where they are. No one is fleeing to America because, you know, they want to. They do it because they have to. So, let's uplift the whole world. Let's make the world a smaller place and everyone wins. It's a better world. It's a better economy. And we solve major problems.

### Moderator
Claim: Thank you. Vivek Wadhwa. Our motion is, Let Anyone Take a Job Anywhere. And here to offer her opening statement against this motion, Kathleen Newland. She is co-founder and trustee of the Migration Policy Institute, where she directs policy programs on migrants, migration, and development, and refugee protection. Ladies and gentlemen, welcome, please, Kathleen Newland.

### Scientific Advocate (SA)
Claim: Thank you, John, and thanks to all of you. It's wonderful to be here in this extremely stimulating company. I'd like to remind Vivek, and the rest of the panel that our proposition tonight is let-- is not Let Anyone Take an Anywhere Job. It's Let Anyone Take a Job Anywhere. And I want to ask you to consider what the world would really be like if anyone could take a job anywhere. As a theoretical proposition, it's very attractive. Economic models where other things are always equal show that world GDP would go up. But I'd like us to think about those other things, which in the real world are never equal. As John Donvan and Mr. Rosenkranz said, this is not a debate about immigration. I think immigration is a very good thing for the United States. And almost always it's a very good thing for immigrants.

And most of the time, it's even a good thing for the countries that people are leaving, as they send back remittances, and transmit knowledge, and sometimes create companies and jobs in their home countries. But for a debate that's really not-- this debate is really not about immigration. It's about how our societies are organized. Do you think that we should expect our government to try to manage the numbers and the kinds of people who join our societies? I don't mean micromanage. I just mean setting a fair and reasonable framework for the labor market in which both immigrants who come here and people who are born here compete. We shouldn't outsource that very important function of deciding how our societies are organized to employers.

That's not to demonize employers. They're the engines of our economies. But it's not their job to pursue the public good, to pursue the best organization for the largest number of people who live in any given country. Labor markets are social institutions as well as economic institutions, and they have geography. Despite the fact that many jobs are mobile, not all jobs are mobile. And especially the jobs that are done by less skilled people into today's world are not mobile. Those jobs in the service sector, the gardeners, the food service workers, the childcare and elder care workers. Those jobs have geography. And we need immigrants to come and fill them. But we need to set a framework in which that's an orderly process, in which it is as much as possible, a legal process. We need to open channels so that the people we need to come and do those jobs can do them legally. But it doesn't mean anyone can take a job anywhere. Why? Well, as I mentioned, labor markets are social institutions.

They're the main channel in our society through which income is distributed. And we have a choice of whether we want to live in a low income, low productivity society with a vastly larger labor market or whether we want to live in a society where people earn higher incomes and have higher productivity and where we import and export and-- including through the web-- of the services that can be done more cheaply elsewhere. Having anyone do a job anywhere, having high levels of immigration to fulfill that vision carries a lot of externalities with it. We don't-- I don't think most people would want to live in a society where immigrants can't have their families join them over long periods of time.

We don't want to live in their society where we don't educate the children of immigrants, we don't provide healthcare to immigrants, we don't provide adequate shelter or allow people the means to acquire adequate shelter; so there are costs associated with immigration, not that those costs aren't worth it. I believe they are. But we have to face the fact that building adequate infrastructure, supplying adequate public services takes some planning, takes some funding, takes some upfront costs. And that's a good reason to regulate our-- the intake to our labor markets. I think there is also a question about values in here. I've mentioned some of them already about what kind of society we ought to live in. But it's also about who gets to decide. And I have great sympathy. I work on development issues. I work with refugees. I have great sympathy for Bryan's idea that, you know, it's a moral obligation to let people reach for the same good life that many-- most people have in the United States, at least in relative terms, or in other developed countries.

But the fact is that we live in sovereign states. And there's a good reason that we do. In 1648, the system was set up to end centuries of religious wars, to end external interference in the societies, in organized societies. And although we've evolved from the sovereignty of kings to popular sovereignty, I think there's still a question of who gets to decide. And I don't believe it's practical to have the-- to decide for the entire world that we will have the same standard of living. We live in a real world in which immigrants, in which workers are not just units of production.

They're members of our societies. And we have to make the kind of provision for people to live in the kind of societies that you want to live in. And, to my mind, is a good reason to vote no against the proposition that anyone should be able to take a job anywhere. Thank you.

## Round 2

### Moderator
Claim: Thank you, Kathleen Newland. And that concludes round one of this Intelligence Squared U.S. debate, where our motion is "Let anyone take a job anywhere." Remember how you voted at the beginning of the debate on this proposition. We're going to have you vote again after you've heard the arguments. And the team whose numbers have changed the most in percentage point terms, in terms of your support of this proposition, will be declared our winner. Now we move on to round two. And round two is where the debaters address each other in turn and take questions from me and from you in the audience. The motion is this: "Let anyone take a job anywhere." And arguing for the motion, we've heard Bryan Caplan and Vivek Wadhwa. And they have argued several points.

They've come at it several ways. They've argued that actually giving a job to anyone anywhere is common decency. Not to do so is a form of discrimination against foreign workers that in itself violates that decency; that opening borders globally, they cite a statistic that says it would actually double global production, which the other side did not refute. They also say that we're on this road already, that in one sector of the economy, the knowledge economy, that this is already happening. And to quote Vivek Wadhwa, "The world is not falling apart." Arguing against the motion, against the motion to let anyone take a job anywhere, we've heard from Kathleen Newland and Ron Unz. They have argued, while conceding the point that productivity, production would double globally, they also say that that would have terrible socially divisive effects because who would it benefit? They argue that that increase in production would benefit almost exclusively an economic elite, that the average person, the ordinary person would see their wages terribly depressed to be essentially in competition with 2 billion workers around the world.

And they argue also that employment and labor is a geographically based thing. You have to be in the place. It's social. There are real costs. Who's going to pay for the schooling of these moves of population? Who's going to pay for the healthcare costs? It's not just a matter of individuals being units of labor. Do you really want to give factory owners a decision about how society's organized, or do you want to give it-- I think they were saying-- to legislatures or maybe even kings. So that's where we are on hearing both sides of these arguments. And I want to take-- I want to go back and slice through some of what you were saying and have you interact on some of this. And I'm interested in Bryan Caplan's point when he was arguing for the motion to let anyone take a job anywhere, that not to do so is a form of discrimination against foreign workers. And I want to take that to your opponent, Kathleen Newland, because to a degree, it sounds as though you get what he's saying. And as somebody who works with refugees, you certainly have sympathy for foreign workers. You have an affinity obviously. But why is it not-- why is it not the kind of discrimination that Bryan Caplan was talking about?

### Scientific Advocate (SA)
Claim: Well, I think our governments are obliged to discriminate in our favor. That's part of the responsibility of government. That's part of the reason we have governments, to keep external forces from attacking us. That's why we have a national defense. And we have national labor market policies because we want to establish a certain level of living in this country. We don't want people to be paid $2 a day for their work in this country. We don't want workers' rights to be flouted at will, so we have rules, we have regulations, and we exert some control over who and what kind of people can come.

### Moderator
Claim: Let's hear Bryan Caplan's response.

### Conspiracy Advocate (CA)
Claim: I'm just trying to imagine Kathleen going to Haiti and telling them, look, we need to keep you out because if we let you in, we'd have to give you free healthcare, and I don't feel like doing that. So you have to stay here. And that way we can maintain our standard of living. It just seems like, to anyone that was not already inside of your in group, this argument would be totally unconvincing because it would be so obvious that you really just don't care about them, and you're willing to do almost anything to people outside of your group. Let me put it this way: When parents are judging a sporting event, they take extra effort to not show favoritism to their kids. Why? Because favoritism is in their hearts. What I'm saying is we need to be equally careful to not show favoritism of this kind to our fellow citizens. We need to make sure that we are treating people from other countries fairly. And this is not what you are doing.

### Conspiracy Advocate (CA)
Claim: You know, the solution is something that Ron--

### Moderator
Claim: Vivek Wadhwa.

### Conspiracy Advocate (CA)
Claim: --advocated, which is having a minimum wage. He has advocated 12 to 15 dollars. Let’s say we did that. We would now lock out the billions that they're worried about. – Ron...

### Scientific Advocate (SA)
Claim: Oh, I--

### Moderator
Claim: Ron Unz.

### Scientific Advocate (SA)
Claim: --agree entirely. In other words, if we had a very large rise in the minimum wage, maybe to $12 an hour, that by itself would alleviate a lot of the problems associated with immigration because, in a sense, if you have a situation where American workers can't be paid less than, say, $12 an hour, then even a huge amount of foreign competition would insure that ordinary American workers had a reasonable standard of living and maintained it.

### Conspiracy Advocate (CA)
Claim: So the problem is--

### Moderator
Claim: Vivek Wadhwa.

### Conspiracy Advocate (CA)
Claim: --the minimum wage allowing people to come in for working for $2 an hour, we didn't say that-- you know, nowhere in this resolution are we talking about bringing in people at 50 cents an hour, $2 an hour, we're talking about if an employer wants to hire them. If I want to hire someone in Chile and have them work for me, they should be allowed to work for me.

### Moderator
Claim: Wait.

### Conspiracy Advocate (CA)
Claim: But you have-- let me say--

### Moderator
Claim: anybody can work anywhere for a minimum wage?

### Conspiracy Advocate (CA)
Claim: Well, why not-- well, you-- no one's saying that you have unlimited open borders and anyone can do anything. You have laws, you have customs, you have processes, and you have regulations.

### Conspiracy Advocate (CA)
Claim: Have good regulations, that--

### Scientific Advocate (SA)
Claim: The current minimum wage is too low. In other words, right now if you have a janitor earning nine or 10 or $11 an hour, and if he's suddenly put in competition with two billion workers around the world who are willing to work for anything, his wage would immediately go down to the minimum wage. In other words, all American workers would see their wages drop to the absolute minimum. Labor unions would be destroyed. And the country would be impoverished. I mean if we had a much higher minimum wage, that problem would not be--

### Moderator
Claim: I want to just hear if-- the point that was just made, that in fact it would have a terribly depressing effect to be in competition with two billion workers sounds reasonable. I want to hear from Bryan Caplan. Do you think that, that's accurate?

### Conspiracy Advocate (CA)
Claim: No. So here's the important thing. While it's true--

### Moderator
Claim: Well, are you going to-- you're going to tell us why?

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: Good.

### Conspiracy Advocate (CA)
Claim: So if there are really only one kind of labor, then Ron's theory is right, you let in a ton of people and wages go down. However, Ron didn't get to the empirical part of economics, which is a really important part. Here's the thing, there are many different kinds of labor. There are high skilled labor, mid-skilled labor, low skilled labor; you can go and read the most respected critic of immigration in the entire economics profession, George Borjas, and all that he'll tell you is that immigration has been bad for high school dropouts. Everyone else, he says there have been gains. So when you consider the effect of immigration, it's not going to be in effect upon all workers, it's going to be effect upon these narrow segments of workers who I said you could take care of them by having taxes or admission fees for low skilled workers--

### Conspiracy Advocate (CA)
Claim: Or minimum wages.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Let me--

### Conspiracy Advocate (CA)
Claim: Ron's minimum wage idea is terrible, and Ron could tell you why. The whole point of Ron's minimum wage proposal is to keep out low skilled workers. He says it explicitly. I encourage you to read his piece. His goal is to make sure that anyone who is not worth $12 an hour, namely, most of the people on earth, are locked in their countries where they're earning a dollar a day. I think it'd be far better if they could come here and earn--

### Scientific Advocate (SA)
Claim: No, but I think we see--

### Moderator
Claim: Hold on. Hold on because I want to hear from the other side. Kathleen Newland.

### Scientific Advocate (SA)
Claim: Yeah, I think we see what happens in this kind of competition among low skilled laborers every day in the international labor markets where recruitment is handled by recruitment agents who arbitrage the difference between what people are willing to work for and what they're paid even at relatively low levels if you have the Filipino worker going to the Gulf, for example. A worker will pay $3,000, a third of his or her annual income, to get that job. So even if you have regulations, even if you have a minimum wage, you'll have people so eager to maybe not earn 20 times, maybe earn five times what they earn, that you will have--

### Conspiracy Advocate (CA)
Claim: I don't think you agree with that.

### Scientific Advocate (SA)
Claim: I think you have--

### Conspiracy Advocate (CA)
Claim: Let Ron--

### Moderator
Claim: Sure.

### Scientific Advocate (SA)
Claim: Again, it depends what--

### Moderator
Claim: Thank you, Vivek. Ron Unz.

### Scientific Advocate (SA)
Claim: It's a matter of specific. In other words, it depends what minimum wage we're talking about. The minimum wage right now in the United States is very low. It's much lower in real terms than it was 40 years ago when the country was much more prosperous. If the minimum wage were higher, that would simply insure that there were a floor below which ordinary Americans could not fall. Under those circumstances, that restriction on the labor market means that even if there are a billion foreigners willing to take a job at any wages, you still have a situation where no American worker can be paid less than $12 an hour, which is enough to insure a reasonable standard of living for ordinary American workers.

### Conspiracy Advocate (CA)
Claim: Let me--

### Moderator
Claim: Wait, wait, wait. Vivek, one second, I want to move off the minimum wage. We did a great minimum wage debate--

### Conspiracy Advocate (CA)
Claim: I'm sure.

### Moderator
Claim: a few months back. And I'm not saying that, that's not relevant because it obviously is. But I don't want us to just talk about that. I want to go a little bit to the point that Vivek was making, that you-- as you pointed out, it's already happening at-- in the knowledge industry, that design is happening on single projects that are shared around the world.

And you said, "And the world is not falling apart over that." But I want to take that argument to the other side. Let's just look at the higher end of this for a time being, and then, Vivek, I'll let you respond to their response to your argument, but the argument being it's kind of working out already at the higher end globally, that, you know, literally, the engineers who are designing for General Motors or Intel don't have to be in the United States, but they're certainly having an impact, I would think, on wages in the United States-- or are they? Let's take Kathleen Newland.

### Scientific Advocate (SA)
Claim: Anyone who has an electrical engineering degree from a good university can take a job anywhere, yes. It's already on your plate--

### Moderator
Claim: And you're good with that?

### Scientific Advocate (SA)
Claim: --at the higher end, and I'm absolutely good with that.

### Moderator
Claim: Why are you good with that in that it's going to have an impact on wages globally as well, will it not? Aren't there now hundreds of thousands more engineers in India competing with American engineers?

### Scientific Advocate (SA)
Claim: Well, we're not-- but they're not competing with them here. And, really, what I'm--

### Moderator
Claim: Well, but Vivek is saying--

### Scientific Advocate (SA)
Claim: --talking about--

### Moderator
Claim: --here doesn't matter, because the work--

### Scientific Advocate (SA)
Claim: --well--

### Moderator
Claim: --takes place across borders. So answer that. Yeah.

### Scientific Advocate (SA)
Claim: I think here does matter. The engineer in India, unless, you know, he is at the top level of management, is not getting paid the same as the engineer in the United States. There is an arbitrage going on between--

### Conspiracy Advocate (CA)
Claim: But they're equalizing-- salaries keep rising worldwide and if you have more people doing innovation, you solve more problems. The economy rises. This is what's happening worldwide right now. I told you how I became more productive, how I could now crowd-source a book on innovating women by getting women all over the world to help me with it. There's no way I could have done that project if I didn't have access to all these amazing women all over the world. That's the magic that happens when you stop worrying about, you know, restrictions and-- you know, we'd have to block off the Internet to stop the--

### Moderator
Claim: Right. Right.

### Moderator
Claim: But her point is that you can't do a book. And you're playing the woman card quite effectively. Her point--

### Conspiracy Advocate (CA)
Claim: Well, what I--

### Moderator
Claim: --her point-- her point, though-- and I--

### Conspiracy Advocate (CA)
Claim: Her--

### Moderator
Claim: Her point is that the Indian engineers are actually not making the same kind of money that engineers in Silicon Valley are making.

### Conspiracy Advocate (CA)
Claim: The standards are rising. This is what--

### Scientific Advocate (SA)
Claim: It's not-- but it's, you know, it's not only about their salaries. It's also about that-- if you are an electrical engineer in Haiti and you can make the same salary in Haiti that you would make in Los Angeles, you still would probably rather live in Los Angeles, where you have a reliable--

### Conspiracy Advocate (CA)
Claim: We're not talking about living--

### Scientific Advocate (SA)
Claim: --supply of electricity--

### Conspiracy Advocate (CA)
Claim: We're not talking about migration.

### Scientific Advocate (SA)
Claim: --good food--

### Conspiracy Advocate (CA)
Claim: The skilled workers don't have to migrate. The Boeing engineers that work in different places are not migrating. They're working together. They're collaborating.

### Scientific Advocate (SA)
Claim: You know-- but we're arguing about anywhere here. We're arguing--

### Conspiracy Advocate (CA)
Claim: But I'm talking about--

### Scientific Advocate (SA)
Claim: --about geography matters.

### Conspiracy Advocate (CA)
Claim: --the same thing. You're looking in the past. You're looking 50 years in the past, when people have to physically move to do jobs. The jobs that all the people in this room do are high-skilled jobs. I don't see any laborers in this room. They are able to do things over the Internet. They are able to do things over e-mail. They're productive over e- mail. They're

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: --you know, they're connecting with each other--

### Moderator
Claim: To my amazement, I thought Bryan Caplan was--

### Scientific Advocate (SA)
Claim: Sure. But that's not the debate we're having.

### Moderator
Claim: --going to be the problem here tonight. And-- and I haven't heard from him in a couple minutes. So, Bryan, jump in, please. And I'll come to you, Ron.

### Conspiracy Advocate (CA)
Claim: Ron mentioned the declining-- or the stagnant wages over the last 40 years and suggested that immigrant labor supply was the problem. There was a much larger change in labor market over the last 40 years. It's called women entering labor markets. My question for Ron-- so do you think that women entering the labor market was a bad thing for the economy? Was it bad-- did all the gains go to capital? Was it bad for men? I'd like to know.

### Scientific Advocate (SA)
Claim: Well, actually, the--

### Scientific Advocate (SA)
Claim: That's not why wages have declined.

### Scientific Advocate (SA)
Claim: That's an interesting point. But I mean, when you--

### Moderator
Claim: Well, it's not an interesting point-- but change the subject--

### Scientific Advocate (SA)
Claim: No-- no--

### Moderator
Claim: That's a pretty good question.

### Scientific Advocate (SA)
Claim: I want to respond. The sort of wage sectors that have seen sharp declines are not necessarily the ones where there's been large entrance of women. So I tend to doubt that the entrance of a large number of women in the labor force is really the main factor involved. It's a complicated issue, obviously.

### Conspiracy Advocate (CA)
Claim: Yes, very complicated.

### Scientific Advocate (SA)
Claim: But the bottom line is that-- incomes have declined. And it's simply due to job competition. Now, getting back, though, to the point that there was a lot of discussion about, regarding the Internet, I think it's absolutely true that it's impossible to prevent jobs from migrating over the Internet, technologically. You can't stop that type of economic competition from overseas workers. I think it's also true that the wages and benefits of the sort of workers in America who are electrical engineers or software developers has been negatively impacted by foreign job competition over the Internet. I think it's absolutely true. But those workers are among the best paid in the United States. So, the negative impact on them has been relatively mild in terms of society. In other words, electrical engineers right now are very well-paid. But if not for the Internet, if not for Indian job competition, they would even be much better paid. But they're not the people I think we have to worry about. We have to worry about the ordinary workers in the United States, the working class, which is, like, 60, 70, 80 percent of society. They are the ones whose jobs cannot be sent over the Internet. And to exacerbate that problem by having physical job competition as well as Internet job competition would, I think, make things much, much worse for that group.

### Moderator
Claim: Vivek Wadhwa, do you concede that point?

### Conspiracy Advocate (CA)
Claim: I conceded it. But the--

### Scientific Advocate (SA)
Claim: Oh, we do. We agree?

### Conspiracy Advocate (CA)
Claim: unskilled laborer is half of minimum wage. Have some regulations so that people can't abused, just like we have environmental regulations, we have other-- so fix those regulation problems, and now let people work wherever-- if an employer thinks that this Mexican gardener is more qualified to do this job than someone else they can hire locally, let them do it. Why should we try to stop--

### Scientific Advocate (SA)
Claim: It becomes a much less severe problem if you have something like a much higher minimum wage.

### Conspiracy Advocate (CA)
Claim: So let's fix regulations--

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: Let's now concede the fact--

### Moderator
Claim: We're back on minimum wage. And I--

### Scientific Advocate (SA)
Claim: Okay, sure.

### Moderator
Claim: Let me-- let me-- you know, we said that we wanted to play with some hypotheticals in this debate. We cited the European Union as not a hypothetical. They're doing it. What if the United States, hypothetically, partnered with the European Union, we joined them, or they joined us?

But essentially, the rules that now let an Irishman work in Bulgaria would let him also work here, and an American work anywhere in Europe. What would be your response to that, Kathleen Newland?

### Scientific Advocate (SA)
Claim: Curiously, you know, the immigration rate between European countries is about the same as the worldwide rate. And Europe has invested enormously before they admitted Spain to the European-- what then was the European Economic Community, before they admitted Greece. They invested enormously in these countries, and they have put strict requirements on the newer entrants like Bulgaria and Romania so that they've created a much more level playing field. Now, if you have-- a bigger labor market is a more efficient labor market, absolutely, no question about it. And if you fuse countries that are at pretty similar levels of income and infrastructure and human rights standards, then you probably won't have that much movement between them.

That's been the case in Europe. We have an agreement with Canada. There's not that much movement between the U.S. and Canada. But if you had an agreement between Europe and Morocco, or you had an agreement between the U.S. and Guatemala, you would have a lot more movement. And I think that is where social and political and infrastructural problems arise if there isn't some control exerted over that process.

### Moderator
Claim: So you're saying, yes, it could work, but you've got to pick your partners carefully.

### Scientific Advocate (SA)
Claim: You've got to pick your partners carefully, or you've just got to plan and do it slowly and consciously.

### Conspiracy Advocate (CA)
Claim: It sounds like we're agreeing.

### Moderator
Claim: Wait. Vivek--

### Conspiracy Advocate (CA)
Claim: --on the motion. I mean--

### Moderator
Claim: Vivek, I--

### Conspiracy Advocate (CA)
Claim: Isn't that great?

### Moderator
Claim: Sorry?

### Scientific Advocate (SA)
Claim: Not anyone anywhere.

### Conspiracy Advocate (CA)
Claim: It sounds like we're agreeing. We won already, so--

### Scientific Advocate (SA)
Claim: Anywhere anywhere.

### Moderator
Claim: Bryan Caplan. What about that?

### Conspiracy Advocate (CA)
Claim: Any movement towards more open immigration is good for me. But I will say the most gains come from immigration from poor countries. Those are where the gaps and earnings are largest. Those are the people whose productivity is only a tiny fraction of what they could accomplish if you'd just let them go to another country. Letting an engineer move from one country to another gives you a small gain in production. Letting an unskilled worker move gives you an enormous increase, because they're stuck in countries where they really just can't use their skills in more than a trivial way.

### Moderator
Claim: So you don't agree with the "pick your partner carefully" theory.

### Conspiracy Advocate (CA)
Claim: I would agree. I would actually-- I would take any partner. I will dance with anyone, any country that-- any country that we want to open our borders to, I would open our borders to, absolutely.

### Conspiracy Advocate (CA)
Claim: So we just have some regulations which prevent abuse of labor. We do things the American way, and we can now make the world a better place. We uplift the rest of humanity. Just like in Europe, you have a levelization happening, and you didn't have a mass migration of people between countries, as Kathleen just said. So the fact is the model can work. We just need to have the right regulations in effect.

### Scientific Advocate (SA)
Claim: But that's because the leveling happened before the opening happened.

### Conspiracy Advocate (CA)
Claim: Well, let's start leveling the world. Why do we have-- why do we tolerate--

### Scientific Advocate (SA)
Claim: Good idea.

### Moderator
Claim: Let me propose--

Let me propose-- I'm going to come to questions right after this, so I just want to remind you, raise your hand, I'll call on you. Stand up. Wait for the microphone, please. If you forget, I'll just remind you. Tell us your name, ask a question. Really make it terse, make it a question. And if there's a question mark at the end of whatever you say, it works. Let's move it away from Europe. Hypothetically, the U.S. and India make a deal. Are we ready for that? Is the time ready for that?

### Conspiracy Advocate (CA)
Claim: On the skills side, it's already happening.

### Moderator
Claim: Vivek Wadhwa.

### Conspiracy Advocate (CA)
Claim: Like I said, the free flow of knowledge is already happening. The fact is that they-- well, that, you know, I get my tax returns-- I have a tax accountant who really outsources the tax processes to India without telling me. It's happening. We have medical transcription happening over there. We have web development happening over there. So any happening in the world income apart, India uplifted, India became a most strategic part of the United States. We became more productive. It was win-win.

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: So all this fear about the world falling apart has not happened.

### Moderator
Claim: But slightly different question about letting a person move for a job. Is India-- are India and the United States ripe for that?

### Conspiracy Advocate (CA)
Claim: John, if we had the minimum salaries, there would not be a problem.

### Moderator
Claim: Here-- here or there?

### Conspiracy Advocate (CA)
Claim: If the United States-- India can have its own minimum salary. As long as you have minimum standards for people, you can let them do a job anywhere. The problem happens when you can have slave labor, cheap labor, when you have Haitian salaries in the United States, then everyone loses. So keep some decent regulations there. Keep our social values. Build a real middle class. This is the beauty of what Ron has been proposing, that under his scheme, we would have a stronger middle class. We've lost that middle class because we have a minimum wage, which is less than it has been for, what, two or three decades, whatever the numbers are.

### Scientific Advocate (SA)
Claim: Exactly.

### Moderator
Claim: But we all agree on the minimum wage. Okay.

### Moderator
Claim: I just want us to move to new ground.

### Moderator
Claim: So I

### Conspiracy Advocate (CA)
Claim: The reason why Ron is arguing about billions of people coming over here is because--

### Moderator
Claim: I know, but I-- but--

### Conspiracy Advocate (CA)
Claim: --he's worried that they-- that the salaries will go down to zero.

### Moderator
Claim: But you have made-- you have both made that round of points twice now. And I'm only saying that because I want us to try to get to other topics, not to disrespect the points because they

### Scientific Advocate (SA)
Claim: Well, I want--

### Moderator
Claim: Kathleen Newland.

### Scientific Advocate (SA)
Claim: I do want to respond to Vivek on that. And I-- and in a way, to agree, but it's not a question of anyone being able to take a job anywhere, because this can only work under two-- it can only work two ways. It can work anarchically, which is what I've been arguing against, because that's what's implied by the proposition, is anyone anywhere. Or it can work under highly regulated circumstances. Sweden has a labor market policy that is anyone who is offered a job in Sweden by a legitimate employer can come to Sweden, do that job, live in Sweden. Sweden has a very high tax, highly regulated and high benefit society, which I think actually sound pretty

### Conspiracy Advocate (CA)
Claim: everything, you don't have high taxes. You have relatively low taxes.

### Scientific Advocate (SA)
Claim: You can't--

### Conspiracy Advocate (CA)
Claim: And you have a high minimum wage. Problem fixed.

### Scientific Advocate (SA)
Claim: You can't-- you can't--

### Conspiracy Advocate (CA)
Claim: Yes, you can do that. And then Ron has demonstrated you can do that. If you your own partner here.

### Scientific Advocate (SA)
Claim: I think you-- I think you then get into the arbitrage problem, you know.

### Moderator
Claim: Can you explain the term "arbitrage" for folks who don't get it?

### Scientific Advocate (SA)
Claim: When somebody is basically taking the difference between a wage here and a wage there and creaming out part of it for their own benefit. This is what happens in international recruitment with these very high fees that are paid by--

### Conspiracy Advocate (CA)
Claim: Ron, you need to respond to your partner.

### Conspiracy Advocate (CA)
Claim: And the reason--

### Moderator
Claim: Bryan Caplan.

### Conspiracy Advocate (CA)
Claim: --why that's possible is precisely that it is not legal for them to go under most circumstances.

### Scientific Advocate (SA)
Claim: No, this is-- these are legal workers. These are legal workers.

### Conspiracy Advocate (CA)
Claim: Under most circumstances, most-- there are very few jobs in Sweden where someone would want to hire someone from another country if they're low skilled precisely because the regulations are so strict. Again, remember, the whole point of Ron's proposal is to price out most people on earth from the U.S. labor market.

He says this. So when you talk about the poor conditions of workers of other countries. Remember, Ron's proposal is designed to keep them poor at home.

### Moderator
Claim: Is that true, Ron?

### Scientific Advocate (SA)
Claim: That's not-- that's not true.

### Conspiracy Advocate (CA)
Claim: Well, not really.

### Scientific Advocate (SA)
Claim: In other words, again, it's a very simple issue. It's a very simple issue. When you have billions of workers legally able to come to the United States and take every-- any job they can that they're offered, you're really converting, again, the minimum wage into a maximum wage because basically very few people in the United States under those circumstances who do ordinary jobs would ever get paid more than the minimum wage.

### Moderator
Claim: No, no. But you've already said that. His question-- his point was that you want to lock out the poor.

### Conspiracy Advocate (CA)
Claim: That's right.

### Moderator
Claim: That's what he said. And I said, is that true?

### Scientific Advocate (SA)
Claim: Well, again, it depends what you mean. In other words, if you're talking about preventing tens of millions of people coming here and driving down wages, yeah, that's certainly true. I'm trying to prevent that.

### Conspiracy Advocate (CA)
Claim: Even though they are living in total misery back home, and they would be earning five to 10 times as much as they came here.

### Scientific Advocate (SA)
Claim: It's perfectly true. If you allow an unlimited number of foreign workers to come to the United States and take a job under any circumstances, those foreign workers would benefit. They would end up being much more prosperous than they are right now. But ordinary Americans would be hurt at the same time by a comparable amount.

### Moderator
Claim: All right. Stop there. Bryan, is that true?

### Conspiracy Advocate (CA)
Claim: No, it is not. So if you want to get an idea--

### Moderator
Claim: Well, no. I mean, it sounds extremely plausible.

### Conspiracy Advocate (CA)
Claim: Well--

So since we're in New York, let's talk about one of the greatest open borders experiments in history, Puerto Rico. Puerto Rico started out as a third world country. When the United States beat Spain. There was open borders. What has happened? Well, first of all, about half of Puerto Rico left over the course of a hundred years. Secondly, Puerto Rico is now one of the richest countries in the world. What happened? People in Puerto Rico, who otherwise would have been stuck in a third world country, not able to use their skills, many of them left and found that there was a better place for them to work. And those remaining found that their wages were higher. A lot of what happened was that Puerto Ricans went home and turned a third world country into a first world country. There's no reason that America cannot do for the world what it did for Puerto Rico.

### Scientific Advocate (SA)
Claim: The whole world? One difference--

### Conspiracy Advocate (CA)
Claim: For the world.

### Scientific Advocate (SA)
Claim: One difference is--

### Moderator
Claim: Really?

### Scientific Advocate (SA)
Claim: One difference is that Puerto Rico--

### Conspiracy Advocate (CA)
Claim: Give me-- give me a century, and I will give you prosperity over the surface of the earth.

### Moderator
Claim: You got it. We will-- we will meet you here-- Let's go to some questions from the audience. Right there in the center, sir, and if you can raise-- stand up when the mike comes from your left-hand side and tell us your name.

### Moderator
Claim: Thank you, this is terrific. My name is Gerry Ohrstrom , and my question is for the panelists opposing the resolution. Mr. Unz, you asserted that opening labor markets would not only be devastating to local labor but to the general economy itself. And yet economists often advise us that economies are not so much about producers and workers but about consumers.

And to the extent that foreign workers are hired at all, it's because it's deemed that they will produce goods and services with higher quality at cheaper prices than the local market that they-- the local labor market that they outcompete, which, in turn, is wonderful for the economy. Could you address that, please, and could the other panelists respond?

### Scientific Advocate (SA)
Claim: Well, it's certainly true.

### Moderator
Claim: Ron Unz.

### Scientific Advocate (SA)
Claim: The economy would grow, but the benefits-- the growth would be captured by the factors of production that are not based on labor. It would be captured by capital. In other words, it's the sort of thing where if you suddenly have a vast increase in America's population, population of workers, the economy will obviously be larger. In other words, there'll be more goods, more services, more people buying things; and it's also true that those 10s of millions or even maybe 100s of millions of foreign workers would be much wealthier in the United States than they were back home in China or India or Africa or wherever they were before. But ordinary Americans, the existing-- the current Americans would be dramatically hurt by it.

They would be much poorer. So what it really comes down to is whether it's important to safeguard the prosperity of ordinary Americans even at the expense of decreasing the impoverishment of tens or hundreds of millions of people from overseas. I mean, again, the numbers involved would be gigantic. If we had a policy right now that anybody could take a job anywhere, I think we'd be talking about 10, 20, 30 million people coming to the United States in the first few years of something like that. Again, people right now are earning a dollar an hour, 50 cents an hour, 10 cents an hour, and if suddenly they could earn $7 an hour in the United States, it would seem awfully good to them.

### Moderator
Claim: Bryan Caplan.

### Scientific Advocate (SA)
Claim: The people who employ them would drive down the wages, and ordinary workers would be tremendously damaged by it.

### Moderator
Claim: Bryan Caplan, I think he just described your fantasy, come true.

### Conspiracy Advocate (CA)
Claim: Yes. So the problem is that Ron keeps talking about labor like there's only one kind of labor. So everyone in America is identical to everyone else on earth, so you could be replaced in whatever job you're doing by anyone on earth, but that, of course, is not true. There are many different kinds of labor. Rich countries send out much more skilled workers. So you should expect that skilled workers would be among the beneficiaries of the increase in the supply of lower skilled workers. Now, does this mean that every American will gain? That is much less clear. That's where I said if it's only a minority of Americans who are losing, then it is very feasible to say, "We will charge you an admission fee or a surtax and give you some compensation." But what Ron is talking about is keeping out almost everyone on earth and losing all these benefits that we could otherwise have and, of course, trapping most of the world in poverty for no reason.

### Moderator
Claim: You know, and, Ron, I want to bring back to you something that Bryan said in his opening statement that we haven't got to, which he talked about the renewal of the society and the economy by virtue of having fresh blood, immigrant blood, both the energy and the creativity and the innovation that can come from that. And you haven't addressed that as a value that they place very highly-- both of your opponents do very highly.

### Scientific Advocate (SA)
Claim: I think there's certainly a lot of truth to that. And in other words, over history America has benefitted tremendously from, you know, its large scale immigration, and I think probably the immigration we've had over the last 20 or 30 years has been very beneficial in many ways also. But the numbers really are awfully large right now. America right now has one of the most rapidly growing populations anywhere in the first world, much more rapidly growing than most other countries. In fact, for example, that sometimes is distorted. When the New York Times or other people talk about America's growth in GDP and compare it to growth rates in Europe or other countries, they're not talking about per capita GDP, they're talking about total GDP. Right now America's population is growing at twice the rate of China's. So for example when you look at the growth of America's GDP, if it's 2 percent but if the population is growing by 1 percent, the per capita income growth is only 1 percent.

The problem is ordinary Americans care about per capita income, not the total GDP of the country. And even if the wealth of America increased by a lot, if we brought in 30 or 40 or 50 million foreign workers, but if the per capita income of ordinary Americans dropped dramatically, that would be disaster. If you basically triple this population of a country, but everybody in the country becomes half as wealthy as they were before, the GDP is much larger, but it is a disaster for ordinary Americans.

### Conspiracy Advocate (CA)
Claim: But that's not what we're talking about.

### Moderator
Claim: Vivek Wadhwa.

### Conspiracy Advocate (CA)
Claim: You keep going to this doomsday scenario where we'll have the Mexican hordes coming in here. That's not what we're talking about.

### Moderator
Claim: Let's go to another question. Right over there, ma'am. There's a mic coming down the aisle. Thanks. If you can tell us your name and--

### Moderator
Claim: My name is Bret Popper and I'm just curious-- we've been focusing on foreign workers coming to America. And I'm curious-- should Americans be able to take jobs anywhere in the world?

### Conspiracy Advocate (CA)
Claim: Why not?

### Conspiracy Advocate (CA)
Claim: Yes. That's a great idea. That's the same question that Bryan would ask. Seeing if we're going to now tell the other-- economies of other counties will rise. Things will get better in the rest of the world. There may well be a day when Mexico has a stronger economy than the United States. Now, imagine flipping it on its head, saying Americans can't take a job in Mexico because they happen to be north, west, or south. That's the same type of thinking we're doing right now. Other than trying to uplift anyone and make the world a more equal-- more fair place where everyone is well off, we're talking about restricting ourselves. We're talking about closing our borders. God knows, we'll have a thousand billion people coming to America and taking our jobs away, decimating our salary, that's not how it's ever been. That's not how it will ever be. And if you create a third world country next door to us, if we keep having these restrictive policies, we'll create problems for ourselves. The solution is to uplift Mexico and to have the same initiative as the U.S. and Canada, where we don't worry about people going across borders.

### Moderator
Claim: Kathleen, do you want to take the question--

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: --about Americans--

### Scientific Advocate (SA)
Claim: Of course.

### Moderator
Claim: --traveling or do you want to respond to where Vivek got to?

### Scientific Advocate (SA)
Claim: Well, I think they're related.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: I-- because I do think that the ability to travel for a job is something that is and needs to be a matter of public policy, you know? There needs to be a better consensus on that within countries. And I think that a polity, self-constituted under a sovereign people, have the right to decide what kind of relationship they want to have with other countries. And I would, indeed-- I wish that we knew how to uplift Mexico. I wish that we knew how to eliminate corruption and--

### Conspiracy Advocate (CA)
Claim: They're doing it on their own, thank you.

### Scientific Advocate (SA)
Claim: --gang warfare--

### Conspiracy Advocate (CA)
Claim: Mexico doesn't need American handouts.

### Scientific Advocate (SA)
Claim: And--

### Conspiracy Advocate (CA)
Claim: Mexico is rising

### Scientific Advocate (SA)
Claim: I'm not talking about handouts.

### Scientific Advocate (SA)
Claim: Well, let's talk about Haiti.

### Moderator
Claim: Right.

### Scientific Advocate (SA)
Claim: Much better example. I wish we knew how to do that. I wish we had the will and the willingness--

### Scientific Advocate (SA)
Claim: --to spend in Haiti. That would solve all the problems. I couldn't agree with you more. If we knew how and had the will and the resources to level the playing field worldwide, we wouldn't be having this debate, because there wouldn't be a problem.

### Conspiracy Advocate (CA)
Claim: There is--

### Moderator
Claim: Compare it to another--

### Conspiracy Advocate (CA)
Claim: --an easy solution to nation poverty, and that is, let Haitians in, right now.

### Moderator
Claim: If you can stand up, please. Thanks.

### Moderator
Claim: I'm Jibran Sheik I have a question towards the people arguing for the motion. Dr. Caplan mentioned a moral imperative. And in this country, we can't provide health care for our citizens as it currently stands. Education is terribly flawed. We have-- if we were to allow millions and even billions of people, theoretically, to come over here, wouldn't we have a moral obligation, then, to provide them if they were injured here, for example, or if their kids needed education?

And if we're not able to address that for our own citizens, how would we be expected to do that for other people? Wouldn't it be a little bit morally egregious to--

### Moderator
Claim: Thank you. Bryan Caplan.

### Conspiracy Advocate (CA)
Claim: It's a very strong question. So I ask you imagine going to Haiti and saying, "Look, we know that you would love to come here and get a job. We know that there's plenty of people who want to employ you, but unfortunately, if you came, we would feel obliged to give you some other free stuff. And we don't want to give you any free stuff, so you have to stay in Haiti earning $1 a day.” That is the kind of humanitarianism that America has right now. I think that is a very poor kind of humanitarianism. The Haitians would much prefer someone who would say, "I would-- I'm willing to let you come in and get a job. I'm not going to give you free stuff, but I'm not going to keep you away, because I don't want to look at poverty.” And that is really what our current system does. It creates an enormous amount of poverty and then it keeps it away from us so we don't have to look at it. Open borders is an incredible solution to poverty, but it is true. You have to look at poor people, if they were to come in. That is the price we pay for actually gravely producing the problem.

### Moderator
Claim: Kathleen Newland, I think that question also went to some of what you said in your opening statement. Would you like to take that?

### Scientific Advocate (SA)
Claim: Yeah. Well, I think that-- again, you know, I don't think we want to live in a country where poverty is tolerated. And I don't think we-- and in order not to have poverty in our midst, I think we have to have a framework whereby the immigrants that we do admit-- and we admit a lot, and I'm glad of it. And I would like to see us admit more. But I don't think that we can create the kind of framework for a good society, for the kind of society we want to live in. Our immigration policy is only as good as our integration policy. And our integration policy for immigrants that makes them part of our society on equal terms is not something we can do for the whole world.

### Conspiracy Advocate (CA)
Claim: And Kathleen--

### Moderator
Claim: Bryan Caplan.

### Conspiracy Advocate (CA)
Claim: So, Kathleen, you seem like a very nice person. You've been to Calcutta.

### Scientific Advocate (SA)
Claim: I am.

### Conspiracy Advocate (CA)
Claim: You know how horrible things there are. I find it very strange to say that it's so important that we not have to look at you, that we're going to keep you living here in horrible poverty because you might come to America and earn minimum wage. It seems crazy to me.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two arguing out this motion: Let anyone take a job anywhere. And tonight's debate is also being broadcast right now worldwide on our website, iq2us.org and on fora.tv. And I want to tell you that if you're watching the live stream right now, we'd love to hear from you too. If you send us your questions on Twitter or Facebook, we're watching. And if you have a good question with a hash tag ‘jobs debate,’ that'll get our attention. And if it's a good question, we'd love to bring it here to the lectern and to our debaters. Let's go back to some questions. Sir, yep. Thank you.

### Moderator
Claim: Dan Kim. I am addressing the motion for why should we replace the immigration system and the system for selecting foreign people from coming here and taking jobs and replace it with a radical-- let anyone take a job in the United States? The current system, albeit, it has certain flaws, it is not-- we're not isolationists. We already have a system that selects people to come into our United States and work in-- as Mr. Wadhwa said, there is already renaissance of innovative technology throughout the world that is going on.

### Moderator
Claim: Okay. Actually, you put your question first, and then you did your argument afterwards. If you had stopped at the question, it was bingo. It was just perfect. But it's a good question. Let's go to this side. Thank you for that question.

### Conspiracy Advocate (CA)
Claim: You know, the U.S. system is broken. Maybe it worked a long time ago. There was a time when there was no such thing as visas. There were no passports. You could easily come to the United States. And that's when the U.S. developed into the powerhouse that it is. Most recently, there has been lots of problems with the number of visas, all these restrictions. We now have a reverse brain drain going on. We have skilled talent leaving the country because we won't give them enough visas. We have this protectionist sentiment. Now we have a clogged Congress which can't even keep the government open, let alone do rational immigration reform. Because why? Because you have a small segment of American society which believes that if we open the doors, billions will come in. They'll take our jobs away, and this country will go to the dogs. I mean, this is the problem we have right now.

### Moderator
Claim: So your answer to his question, when he said we actually have a functioning system, not perfect, but--

### Conspiracy Advocate (CA)
Claim: System is not functioning.

### Moderator
Claim: sets priorities.

### Conspiracy Advocate (CA)
Claim: It's broken right now.

### Moderator
Claim: Okay. You do not agree with

### Conspiracy Advocate (CA)
Claim: Right now, as of the last two or three years, it's broken.

### Moderator
Claim: All right. Let me take the same question, if you want to respond, Ron Unz. And if you don't, I can move on to another question.

### Scientific Advocate (SA)
Claim: I-- can I just--

### Moderator
Claim: Kathleen, Newland, go ahead, sure.

### Scientific Advocate (SA)
Claim: --say one thing about that. I think the U.S. system leaves a lot to be desired. I think it does need fixing.

But I don't see why we should replace it with a system that's completely employer driven. And that is it, you know, let anyone take a job anywhere means- it means that employers set the terms of--

### Moderator
Claim: What are the implications of that?

### Scientific Advocate (SA)
Claim: --immigration.

### Moderator
Claim: When you say that the-- essentially you're saying the flow of labor would be completely under the influence of employers. What are the implications of that?

### Scientific Advocate (SA)
Claim: Well, currently, in the United States, our immigration system is overwhelmingly driven by family reunification. And that means that 70 percent of the people who get a green card, about 10 percent of them are refugees, about 14 percent are selected by employers. 14 percent, that's all we have now. And yet we still get the best and the brightest, a larger proportion of the best and the brightest than any other country. Now, we may not get them all. We may not get as many as we need. We may not get as many as we could, but we get a lot.

### Conspiracy Advocate (CA)
Claim: They're going back now. We're now in reverse.

### Scientific Advocate (SA)
Claim: Well, we're not in reverse.

### Conspiracy Advocate (CA)
Claim: And employers are not evil. Employers are-- as long as you have regulations and have minimum levels, employers are not going to bring in people from abroad when they can hire equally competent better people here. They don't want the cultural problems. They don't want to have the costs involved with it. They don't have to-- want to have to pay for the health insurance when they don't have to. They will do what's right for them. And there's nothing wrong with letting employers select the people they want to hire.

### Moderator
Claim: I just want to get back to Kathleen. You started answering my question, and maybe that is the answer. But the implications of-- what I think you-- what I thought I heard you saying is you're concerned about throwing out a system that essentially is under the control of a political process, giving it-- giving the control of the flow of labor to--

### Scientific Advocate (SA)
Claim: That's what I'm saying.

### Moderator
Claim: --employers. And I just want to get a clearer picture of what that means and why you are, I guess, frightened by it or--

### Scientific Advocate (SA)
Claim: Because it's not the job of employers to pursue the public good. It's the job of the employers to pursue the good of their companies. That's as it should be. That is part of what accounts for the dynamism of our economy.

But they don't have a responsibility for the integration of immigration. They don't have a responsibility for the families of immigrants. They don't-- and when you bring people in through a family channel-- and I think we probably overdo it on that. But when you bring them in, you have an integration machine that gets going there. People are coming into a community. They're coming into a family. They're coming into a social system.

### Moderator
Claim: Okay. I see with clarity what you're saying.

### Conspiracy Advocate (CA)
Claim: I've been an employer who has hired foreign workers. I hired lots of people from the UK in the '90s from Britain. And I took responsibility for making sure that their families came here and making sure they had health coverage.

### Scientific Advocate (SA)
Claim: You're unusual.

### Conspiracy Advocate (CA)
Claim: Making sure that they integrated, there weren't cultural issues. But that's what employers do. The employers aren't evil. They're not going to bring in slave labor just to cut some costs. They're going to do what makes sense for them and for their companies, where integration has to happen.

### Scientific Advocate (SA)
Claim: I suggest you go to the Central Valley in California, not just Silicon Valley.

### Conspiracy Advocate (CA)
Claim: We're talking about the rest of America.

You know, we keep coming back to farmworkers. Let's not just say because of some abuse in some segments of America we shut off-- we close the doors, and we start--

### Scientific Advocate (SA)
Claim: No, I'm not suggesting that.

### Conspiracy Advocate (CA)
Claim: are going to come in and take farm jobs away. If we have minimum wages, if we have regulations, if we now require them to have-- provide health insurance, these things will not happen.

### Moderator
Claim: Hi.

### Moderator
Claim: My name is Victoria, and I have a question for--

### Moderator
Claim: I think your mic's not turned on. Can we just double-check?

### Moderator
Claim: Hello.

### Moderator
Claim: There it is.

### Moderator
Claim: You said that one of your main concerns is looking at the poor and acknowledging the poor and being right--

### Moderator
Claim: Who are you addressing, which--

### Moderator
Claim: I-- team of the side for.

### Moderator
Claim: The side arguing for the motion.

### Moderator
Claim: Yeah, sorry.

### Moderator
Claim: Okay.

### Moderator
Claim: But it seems like there is a blind spot for the poverty that exists here now. So I'm wondering how the poverty population here would be uplifted by your plan. And also--

### Moderator
Claim: Wait, wait. I just-- I need a little more clarity on what you mean. And I want to make sure it relates to our motion.

### Moderator
Claim: Well, because part of the-- part of the proposal-- part of the reason for letting people in is altruism, because it's wrong not to. It's wrong to say to a poor person, “Hey, you know what? We know your poor, and your conditions suck, but we just don't want you in because we don't feel like it.”

### Moderator
Claim: Well, there goes the NPR broadcast.

### Moderator
Claim: So I'm wondering, what about the blind spot for the people who-- the Americans, the poverty here?

### Moderator
Claim: Okay. I'm going to respectfully pass on the question.

### Moderator
Claim: Okay. Then, but I have a second part.

### Moderator
Claim: Okay. But I need you to get to it.

### Moderator
Claim: If it-- if it uplifts the country, if it level-- if it’s a leveler for other countries, what about the brain drain, what about the--

### Moderator
Claim: The effect on the other countries?

### Moderator
Claim: Yeah, with all of those talented people leaving, how does that uplift their economy?

### Moderator
Claim: Fair question. Let's take that to Bryan Caplan. Thank you.

### Conspiracy Advocate (CA)
Claim: Sure. So first thing when you think about brain drain is, when people complain about it, they really are asking us to do to the people in the third world what the Soviet Union did to its own citizens.

It's a scary thought. However, you could say, well, it was very good for the Soviet Union to keep their smart people in. At least they didn't get to run away. But I would say, you know, more important-- the more fundamental plight is that the-- letting smart people go to other countries actually creates benefits for not only themselves, not only the world economy, but for people back home. So Kathleen mentioned remittances. And if you just want to get an idea about how it works, take a look at Puerto Rico; started out as a third world country.

### Moderator
Claim: Wait. You've done Puerto Rico.

Again, I just-- just for the use of time.

I just want to give Ron Unz a chance to respond to the brain drain question.

### Scientific Advocate (SA)
Claim: Well, I mean, that's certainly true. In other words, if we're talking about the brain drain, we're talking about relatively small numbers of highly educated, highly talented people. And that's very different than allowing anybody to take a job anywhere, where the numbers implied are from a population based on the billions rather than in the hundreds of thousands or maybe in the millions.

Now, you know, again, there are a lot of pluses and minusess with immigration flows in the United States. I think on balance it's been positive for the United States, but at reasonable levels. Hundreds of thousands a year, sometimes getting up to a million a year, that's very different than the proposition, which is talking about unlimited numbers, which I think would be disastrous--

### Conspiracy Advocate (CA)
Claim: do employers making job offers and then-- and people taking jobs. That's what we're talking about. We're not saying--

### Moderator
Claim: Well, that's part of the argument, but the motion doesn't say, "Let anyone take a job anywhere subject to employers minimum wage." But-- no, but--

### Conspiracy Advocate (CA)
Claim: come here--

### Moderator
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: --and then look for a job, I mean--

### Moderator
Claim: Yeah, but--

### Conspiracy Advocate (CA)
Claim: --we're not talking about removing all barriers. We're talking about if you have a job offer, if you find a skilled worker somewhere, you can hire them.

### Moderator
Claim: You need a mike, come through here.

### Moderator
Claim: Oh, sorry. Hi, my name is Tatiana, and I'm an immigrant. I was born in Soviet Union. Now it's Moldova, the poorest country on the continent I think in Europe.

### Moderator
Claim: Glad to have you.

### Moderator
Claim: So-- so-- two things I wanted to mention, so, number one--

### Moderator
Claim: I need you to ask a question and one--

### Moderator
Claim: Exactly.

### Moderator
Claim: Just one question, okay?

### Moderator
Claim: Yes.

### Moderator
Claim: Pick the best one.

### Moderator
Claim: Only one question.

### Moderator
Claim: Go for it.

### Moderator
Claim: Okay. So 10 years ago, I-- my salary was $30 a month. Five years ago I moved to America. If it took me only five years to get here and get a job and be successful, I think anybody can do it, so I don't think that the laws here limit people. People that are really motivated, that are driven to want to do things, they will.

### Moderator
Claim: I need a question from you.

### Moderator
Claim: So my question is--

### Moderator
Claim: --about the European Union. So my question is about European Union, there are countries in European Union that people that are part of European Union have no rights to work in, for example-- I mean they need a work permit-- Switzerland is one of them--

### Scientific Advocate (SA)
Claim: It's not a member of the European Union.

### Moderator
Claim: --so my question to you would be if we would take European Union as an example, I don't think that it economically they have done a really good job, so I wouldn't go by their example at all, and there are Austria, Germany, and--

### Moderator
Claim: Wait a minute. I have to stop you-- because you've been talking for two minutes, and I truly need a question.

### Moderator
Claim: Okay, my question is--

### Moderator
Claim: If you can do it.

### Moderator
Claim: --I'm a little nervous-- so my question is if European Union-- I mean if we are go by European Union platform, where would we go? Because I don't think they have been a good example--

### Moderator
Claim: So, can I rephrase your question this way, that-- "Is the European Union a good model for something that can work this way?" That would be it?

### Moderator
Claim: Absolutely.

### Moderator
Claim: Okay, let's take that to this side. Thank you. You know, I've been doing this a long time. I know how to compress. There's no shame in struggling through a question. I've done a lot of it a lot of times. I just get to edit it out of this broadcast, so--

### Scientific Advocate (SA)
Claim: I'm so glad to have a question from Moldova. I've been working there a lot in the last year. I've been there four times so I want to talk to you afterwards.

### Moderator
Claim: Kathleen Newland.

### Scientific Advocate (SA)
Claim: The-- it's really the other way around. The United States was a model for the European Union, and in a sort of fundamental sense of trying to reach the economies of scale, the continental economies of scale, that the European Union-- that the United States had by virtue of being one country, so the European Union has gradually eliminated first, you know, its tariff barriers, and tried to integrate into its coal and steel industries at the very beginning. And finally this is the last step to integrate its labor markets. So I think they are still struggling. There have been a lot of strains particularly with the broadening to-- at-- with the more shallow preparation efforts for new entrants like Croatia and Romania and Bulgaria compared to Italy, France, and-- Italy and Greece and Spain. So it's not with a lot of strain, but I think they are becoming-- striving to have markets more like ours rather than us looking to Europe as a model. We also have the huge advantage of having one language.

### Moderator
Claim: Would this side like to respond, no?

### Conspiracy Advocate (CA)
Claim: The migration policy--

### Moderator
Claim: Bryan Caplan.

### Conspiracy Advocate (CA)
Claim: --of the European Union has been fantastic. My only complaint is that they keep out most poor countries.

### Moderator
Claim: Okay. All the way in the back there. And a mic will come up to you. Do you mind standing out in-- would you actually-- because you're in shadow from my perspective which probably means you are for the camera-- just to come down about six steps until you're-- great, that's great, thank you.

### Moderator
Claim: Okay. So people want--

### Moderator
Claim: Okay, your name-- okay.

### Moderator
Claim: Tiffany Turantina so people want to come to America because they want to prosper, right? And I think three of you, all but Bryan, have mentioned that there needs to be a minimum wage but we don't have one. So if the politicians are not going to vote for one or if we don't know if they're going to vote for one, how can we today vote and say, "Yes," that we want everyone to be able to come in and work in here?

### Moderator
Claim: Okay, that's actually not a minimum wage question, that's the question-- what you're asking is "Why--" this side is arguing that "We'll work it out," and you're asking, "How can we trust--"

### Moderator
Claim: Correct.

### Moderator
Claim: "-- the system to work it out--"

### Moderator
Claim: And vote to--

### Moderator
Claim: --the system to work it out.

### Moderator
Claim: And though today--

### Moderator
Claim: A fair question. In this hypothetical, what-if world we're talking about, what is your confidence level that the kinds of protections that you're saying would need to be built in could actually be built in?

### Conspiracy Advocate (CA)
Claim: We already have those protections.

We have employer laws. We have the laws for sick leave. We have employer laws for maternity. We have laws for health care. We have a minimum wage. Let's just tweak it a little bit and now move on. It's not that-- it's not rocket science.

### Moderator
Claim: But-- you can applaud that. I don't want-- mean to suppress your-- this applause. I just-- I thought that this-- the flow of the argument was, though, that the cost of supplying those services to large numbers of people-- your opponents are arguing-- could be prohibitive.

### Conspiracy Advocate (CA)
Claim: We're talking about as many--

--employees as employers need. And we're not talking about billions of people. We're talking about reasonable numbers of people coming here, taking jobs when they're offered jobs. I don't-- you know, there's no-- I don't see why we keep talking about billions coming in. We-- no one is saying, "Just open the borders and let people come here, and live, and we have to give them health care.” We're saying that if there's a job here for them, let them take the job. That's-- it's as simple as that. I don't know why we even have to debate this. It's a simple argument. If an employer wants it--

### Moderator
Claim: Ron Unz.

### Scientific Advocate (SA)
Claim: Here's the problem. I mean, the practical world-- obviously, people are self-interested. And they try to game the system. Let's say, for example, we convert our immigration policy, our job labor policy entirely to the control of employers. Right now, for example, illegal immigrants pay thousands of dollars to be smuggled into the United States in a difficult and dangerous way.

Suppose instead they took that thousands of dollars and paid it to an American employer to hire them for one week or two weeks or three weeks. They could come here legally. They would work for one week or two weeks or three weeks. They would then be laid off. And they would melt into the larger society. In other words, basically, you'd have to set up a police state to then catch them and deport them afterwards. That is really--

### Moderator
Claim: Oh, come on.

### Scientific Advocate (SA)
Claim: That is really scheming. I mean-- that's really complicated.

### Conspiracy Advocate (CA)
Claim: With all these doomsday scenarios, to close off the borders? Come on. That's an extreme situation again.

### Moderator
Claim: I have to say--

### Conspiracy Advocate (CA)
Claim: This is the same as the Tea Party--

## Round 3

### Moderator
Claim: I have to say this concludes Round 2 of this Intelligence Squared U.S. Debate. Thank you. We're-- our motion is Let Anyone Take a Job Anywhere. And now we're going to go on to Round 3. Round 3 are closing statements from each debater in turn. They will be three minutes each. Immediately after their closing statements, we will have you vote a second time. And I want to remind you, you've already voted your position on this motion.

And after hearing the arguments, you vote a second time. And the team whose numbers change the most in percentage point terms will be declared our winner. So, our motion is this: Let Anyone Take a Job Anywhere. And here to summarize his position against this motion, Ron Unz. He's former publisher of The American Conservative Magazine. Ladies and gentlemen, Ron Unz.

### Scientific Advocate (SA)
Claim: Over the last 20, or 30, or 40 years, there's been a tremendous bifurcation of American society. The wealthier have gotten much wealthier. The rest of the people have not. We've reached the point right now where the top 1 percent of American society-- which has sometimes been in the headlines-- the top 1 percent has as much wealth as the bottom 95 percent. In the last few years, since the 2008 financial crisis, virtually all of the gains in wealth in income have gone to that wealthy elite and virtually none of it to the rest of the population.

Now, that's a bad situation. To make a bad situation like that much worse would be to cause the vast majority of ordinary American workers to suddenly have to compete for their jobs against everybody in the rest of the world. It would destroy their incomes. What we're talking about, again, is something that certainly would benefit the best educated, the wealthy elite, the affluent people in society, to be honest. The proposal that we're talking about probably would benefit many-- perhaps even the majority, perhaps even the vast majority of the people sitting here in this audience. I mean, we're talking about New York City, one of the wealthiest cities in the United States. We're talking about the sort of people who attend a debate like this. Many of you might not be wealthy right now, but you're young in your careers. You certainly have a lot of prospects. Probably many of you would benefit from something that would drive down the wages and income of 60, 70, 80 percent of the rest of the people in society, but it would make the political situation much worse than it is right now.

What we have to do is make changes and other proposals and other aspects of our society to alleviate the problems we've had over the last 20 or 30 years, in terms of this wealth gap. Not make them much worse. The proposal we're talking about would be devastating to the vast majority of Americans and should be voted against.

### Moderator
Claim: Thank you, Ron Unz.

Our motion is, "Let anyone take a job anywhere." And here to summarize his position supporting this motion, Vivek Wadhwa, vice president of research and innovation at Singularity University. Ladies and gentlemen, Vivek Wadhwa.

### Conspiracy Advocate (CA)
Claim: Right through American history, we've had these same debates, that foreigners will take American jobs away. We always blamed foreigners for all the ills. And now my friend over there is blaming foreigners for the income disparity between the rich and the poor.

Immigrants haven't done that. That's the evil Wall Street that's done that, my friend. That's a different problem in American society. We can have a balanced immigration policy, which allows people in that makes sense for America, that make it more competitive to come in here. It's happened with skilled immigration. Skilled immigration has made America the most fiercely competitive land in the world. We're seeing benefits from it. It's uplifting society. A lot of good has come from skilled immigration. We're moving into this knowledge economy in which we really tested what happens with open borders. The fact that we're communicating, connecting with people everywhere. Our children are now connected to children in the poorest parts of the world because of open borders, which is the internet. So closing off borders, saying that, no, you can't have people taking a job, you know, where they need to, is like closing off the internet. It doesn't make sense in this-- in this modern day era. It's good for America. It's made what is-- America what it is. Let's get beyond this protectionism. Let's get beyond this close mindedness and blaming foreigners.

There's billions of Mexicans that are going to come in and take our jobs away. They're going to decimate our standard of living. False. They have made this country fiercely competitive, made this country great. Let's do more of it, not less of it. We can control wages. We can have minimum wages so that we don't have them going down to zero, we don't have fierce competition for low-skilled jobs. American employers are not able. American employers are doing what's best for their employees and for themselves and for their investors. We can trust them to hire people that make sense for them. Let's not try to overregulate the employer. Let's open up so that we bring in the people that we need in this great country.

### Moderator
Claim: Thank you, Vivek Wadhwa.

Our motion is, "Let anyone take a job anywhere." And here to close her position against this motion, Kathleen Newland, cofounder of the Migration Policy Institute. Ladies and gentlemen, Kathleen Newland.

### Scientific Advocate (SA)
Claim: Thank you.

I think in order to decide how to vote on this proposition of "Let Anyone Take a Job Anywhere," we need to think about what the alternatives are. And the alternative, I think, is a better managed, a more thoughtful labor market policy, a more thoughtful immigration policy. As I said before, currently only 14 percent of our immigration intake, the number of permanent residency permits that are granted every year are granted to immigrants who are sponsored by an employer. So increase that. So increase our intake of skilled people, but not to the exclusion of poor-- many of the family members who come into our dominant family stream are not wealthy people. Their children do well. They become the bedrock of this society. And I couldn't agree more with Vivek's statement that immigration has been a tremendous benefit to America.

### Scientific Advocate (SA)
Claim: But what we need is a thoughtful, measured, targeted immigration and labor market policy. And I think that that needs to be a public policy framework that is set through public debate, like this one, and where people other than only employers have a say in who comes in to be our neighbors and who and how many people constitute and reconstitute and renew American society.

### Moderator
Claim: Thank you, Kathleen Newland.

Our motion, "Let anyone take a job anywhere," and here to summarize his possession supporting this motion, Bryan Caplan, professor of economics at George Mason University. Ladies and gentlemen, Bryan Caplan.

### Conspiracy Advocate (CA)
Claim: As Vivek said, it is hard to believe that we're actually even debating "let anyone take a job anywhere." If our opponents had told you that the laws prevent women from working, or the laws prevent Jews from working, or the laws prevent blacks from working, you wouldn't just disagree. You would be appalled. You would be horrified to hear such words coming out of their mouth. You should be equally appalled when someone says the laws prevent foreigners from working. Criminalizing the employment of women, Jews, blacks or foreigners is doubly evil. It denies workers' basic human rights. And it deprives the world of the full benefit of workers' talent and ambition. Open borders should be a bipartisan and bi-ideological cause. Conservatives should oppose immigration restrictions in the name of freedom, free markets, small government, the work ethic, meritocracy and to Horatio Alger himself.

Liberals should oppose immigration restrictions in the name of equality. Reducing poverty, equal opportunity, nondiscrimination, social justice and the global 99 percent. When the government forbids American farmers to hire Mexican farmworkers, how can a conservative not see the oppressive hand of big government crushing the entrepreneurial spirit? When the government forbids American restaurants to hire Haitian dishwashers, how can a liberal not see a heartless legal system, diabolically promoting poverty and discrimination? Please, let anyone take a job anywhere. It is the right way to treat your fellow human beings. It will transform the world for the better, and it will cost us less than nothing.

### Moderator
Claim: Thank you, Bryan Caplan. And that concludes closing statements. And now it is time to see which side you feel argued best. I want you to go again to the key pads at your seat and vote now the second time. Remember it's the difference between the two votes that determines our winner. And the way the vote works, if you look at this motion: Let anyone take a job anywhere, and if, after hearing the arguments, you agree with it, you're agreeing with this team, push number one.

If you do not agree with this motion, you agree with this team, push number two. And if you are or became undecided, push number three. If you push the wrong key, just correct yourself. The system will register your last vote before we lock it out. All right. Thank you. It looks like everybody's done. We're about 90 seconds away from having the results. The first thing I want to do is say that it's our goal at Intelligence Squared to raise the level of public discourse by bringing real argumentation and respect and robust ideas and logic and wit. And we had that tonight. These debating-- these two teams were just terrific.

And Vivek, when you say that we shouldn't even be debating this that chills me to the bone. But I'm sure it was just rhetorical.

### Conspiracy Advocate (CA)
Claim: No. I don't want to take your job away, my friend.

### Moderator
Claim: All right. And everybody who got up and asked a question tonight, they all got through. And thank you for working with me on reshaping the questions. I appreciate that you have the nerve to get up and do that in front of everybody. So thank you to everybody who asked a question.

We would love it if you tweeted about this debate. Twitter handle again is @IQ2US. The hash tag for this debate is jobs debate. Our next debate is in two weeks, a little over two weeks, Thursday, November 19th. The motion we'll be debating that night "The Constitutional right to bear arms has outlived its usefulness." And I'm sorry, that's on November-- did I say 14th? Did I say the 14th?

### Moderator
Claim: Yes.

### Moderator
Claim: And arguing for the motion that the Constitutional right to bear arms has outlived its usefulness, Alan Dershowitz.

He's the Harvard law professor who's been called one of the nation’s most distinguished defenders of individual rights, and not just by Alan Dershowitz. His partner--

His partner is Sanford Levinson. He's a political scientist and a law professor and author of the book, "Our Undemocratic Constitution." Against the motion, David Kopel, he's research director at the Independence Institute and one of the foremost second American scholars; and Eugene Volokh, who is a professor at UCLA's School of Law and founder of the Volokh Conspiracy, one of the most widely read legal blogs in the nation. On Wednesday, November 20th, we're going to be in Washington, D.C. in partnership with the McCain Institute debating this motion: Spy on me, I'd rather be safe. Tickets for all of our remaining debates are available through our website, www.iq2us.org. And for those who can't join, of course, we've been streaming on fora.tv and on iq2us.org. And this debate will be on NPR stations across the nation. Just check your local listings, and you can hear your own applause going out to the nation.

Okay. We have the results in. Remember, you have voted twice, before the debate and once again after the debate. The team whose numbers have moved the most in percentage point terms will be declared our winner. Here are the results. In the opening vote, 46 percent of you agreed with the motion, "Let anyone take a job anywhere." 21 percent were against the motion. 33 percent were divided. The second vote "Let anyone take a job anywhere," the team arguing for the motion, they went from 46 percent to 42 percent. That's a loss of four percentage points. The team arguing against the other side, I think we can see where this is going, their second vote was 49 percent. That's an increase of 28 percentage points. They are our winners, the team arguing against the motion, "Let anyone take a job anywhere," are our winners. Our congratulations to them. And thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
