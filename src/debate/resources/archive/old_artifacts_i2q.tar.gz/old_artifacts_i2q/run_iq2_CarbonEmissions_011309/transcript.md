# Debate Transcript

Topic: Major Reductions in Carbon Emissions are Not Worth the Money
Motion: Major Reductions in Carbon Emissions are Not Worth the Money

Debate ID: CarbonEmissions-011309


## Round 1

### Moderator
Claim: Welcome, and thank you all for coming. About a year ago, we did a debate, the resolution was that global warming is not a crisis. And the audience in that debate started voting 57 percent against the resolution, ended up only 42 percent were against the resolution. It was the biggest change in opinion that I think we’ve had in any debate that we’ve done, and it was perhaps the most newsworthy debate that we’ve ever presented. Well this debate takes off from where that one left off. It assumes that global warming is real. It assumes that human activity, particularly emissions of carbon, make a major contribution. The resolution today is about major cuts in carbon emissions and I in carbon emissions are not worth the money” (1/13/09) want to emphasize major. If firms or universities or governmental entities find a cost-effective way of reducing their carbon footprint, that’s a cause for applause and not debate. But the major issue, is really burning coal to generate electricity. In China and in India, there are going be 800 new coal-fired plants to generate electricity, in the next five years. Those plants alone will emit five times as much carbon as the entire savings from Kyoto I accords.

Well, there’s a Kyoto II framework under discussion, and it is far more ambitious. It proposes to tax the release of greenhouse gases, through a cap-and-trade mechanism, by $1.3 trillion annually. This is staggering, 10 percent of the US gross domestic product, 2 percent of world GNP. One can’t contemplate an intervention of this magnitude, without asking a couple of questions. First of all, what are the benefits that are associated with costs this large. And secondly, what alternative expenditures might enhance human welfare more. It’s these questions that our panelists tonight are going to address. And now it’s my pleasure to hand the evening back to John Donvan and the outstanding group of panelists that we’ve assembled this evening.

### Moderator
Claim: Thank you, Robert. And may I just invite in carbon emissions are not worth the money” (1/13/09) another round of applause for Robert Rosenkranz, for making all of these debates possible. Welcome to the Symphony Space in New York City, I’m John Donvan, your host and moderator for this Intelligence Squared US debate, another in a series of, we hope smart and scintillating programs, debating topics that matter. The motion before us, this time, “Major reductions in carbon emissions are not worth the money.” This is a contest, it’s a contest of logic and wit, and mostly persuasion, these panelists are here to change your minds, you the audience are the judges. Now, to introduce our panelists. First, Peter Huber, author of The Bottomless Well, and a columnist for Forbes. Bjorn Lomborg, founder of The Copenhagen Consensus. Philip Stott, emeritus professor and biogeographer from the University of London. This is the team arguing for the motion.

Arguing against the motion, Hunter Lovins, president of Natural Capitalism Solutions… Oliver Tickell, a journalist and author of the Kyoto II Climate Initiative… And Adam Werbach, global CEO of Sacchi and Sacchi S. The Intelligence Squared and Intelligence Squared US debate series are produced by the Rosenkranz Foundation. Shortly, you will hear from our six panelists, three for the motion and three in carbon emissions are not worth the money” (1/13/09) against the motion. The motion is, “Major reductions in carbon emissions are not worth the money.” Now we want to ask you at this point to register your views on this motion as you come in off the street, before hearing any of the argument, because as I say, they are here to persuade you and to change your minds.

You can reach now for those keypads, and I’ll remind you particularly if you came in late, the way to vote if you agree with the motion, that “Major reductions in carbon emissions are not worth the money,” push number 1. If you disagree push number 2, if you are undecided push number 3. If you regret your decision, you can correct it by pushing the correct button, and it will register the last entry. Does anybody need more time? All right, so what we’re going to do is tabulate those and a little bit later in the evening, I will share the results of that polling. The panelists will each be given seven minutes to speak. If they reach the seven-minute mark and are still going I’ll have to step in, after that, we’ll be hearing from you in the audience and following that section and that’s normally the longest section, each panelist will be given two minutes to summarize their views, and then, we will vote again, and find out who the winner is.

And I want to make clear… the way that we determine a winner, is to see, who was more persuasive in changing minds, in other in carbon emissions are not worth the money” (1/13/09) words if somebody starts with a 60 percent margin, and the other team obviously has 40 percent, whoever moves their percentage higher will actually be declared the, the winner of the evening. That’s clear to everybody? Yeah, okay. So, let’s let the debate begin. Our motion is, “Major reductions in carbon emissions are not worth the money,” and arguing first for the motion, Bjorn Lomborg, he is from Denmark, the land that has led the globe in the development of wind power, it is an environmentalist’s dreamland. But he is an environmentalist skeptic in many ways, and is first to argue for the motion. Bjorn Lomborg.

### Conspiracy Advocate (CA)
Claim: I’ll speak for the motion that “Major reductions in carbon emissions are not worth the money.” Perhaps a natural reaction to that would be, what, are there still people who think it’s more important to save money, than to save the world? That’s not our point. Our point is, that we should really save the world, not just feel like we’re saving it. Let’s be clear—global warming is real. Man-made, and increases by carbon emissions. And global warming will harm future generations, especially the world’s poor. But the brutal fact is, that even major carbon cuts at dramatic cost will make little impact on temperature, and do virtually nothing to help the world. Still, my honored opponents will spend hundreds or even thousands of billions of dollars, to in carbon emissions are not worth the money” (1/13/09) slightly reduce the impact of climate change 100 years from now, yet more than half the world’s population suffers from Medieval problems that we could fix right now, at much lower cost.

This is nothing less than a moral tragedy for the developed world. Knowingly squandering colossal sums of money, achieving almost nothing, while fractional sums could save millions of lives right now. Obvious as it may sound, our goal isn’t for those of us in wealthy western world to feel good about ourselves, presumably, it’s about making sure we do the most good. Today, 1 billion lack clean drinking water, 2 billion people lack sanitation, 3 billion people lack simple micronutrients, preventing physical and mental development. One quarter of all the world’s deaths, are due to easily curable infectious diseases. The equivalent of the population of Florida, wiped off the map, each year. As an example, 1 million people die from malaria each year, and up to 2 billion people get the debilitating disease. Yet, my esteemed opponents will focus on how global warming will cause a slight increase in malaria increase 100 years from now, and suggest that we should fix that through inefficient carbon cuts.

But we could eradicate malaria right now, if we wanted, and at a lot lower cost. That is the moral choice. This pattern of little good at high cost, we find repeated in the cases by opponents will in carbon emissions are not worth the money” (1/13/09) present to you. And this is why all peer-reviewed economic valises show that simply cutting carbon is a poor way to help the world. And that’s exactly the crux of tonight’s debate. That the best available economic evidence tells us that by focusing on cutting carbon emissions, we’re committing to an exceptionally inefficient way to tackle the symptoms of global warming, let alone global warming itself. And given how much of our resources will be squandered in the process, the consequences are nothing less than a moral tragedy.

Of course, my esteemed opponents will claim that without major carbon cuts, the world will be beyond saving. Oliver Tickell has written that unabated global warming by the end of the century will be a catastrophe, and the beginning of the extinction of the human race because all the ice will melt and we’ll see 200 feet of sea-level rise in the long term, wiping out pretty much everyone we hold dear, killing billions of people. This doom-mongering is simply wrong. It’s inconsistent with everything we know. And it’s important that people everywhere start to realize this. We’ve entrusted the UN Climate Panel, the so-called IPCC, with its thousands of scientists, to outline the most likely climate consequences. They do not support Tickell, or any of the other, more alarmist writings of recent times. What the IPCC does tell us is, yes, sea levels will rise, somewhere between six and 24 in carbon emissions are not worth the money” (1/13/09) inches over the coming century.

Such a rise is entirely manageable, and not dissimilar to the about 12 inches we barely noticed, have risen over the last 150 years. Dramatic, expensive carbon cuts would make sea-level rise just a few inches less in 100 years. Is this really the best we can do to help the world? Of course, the obvious and easy thing to say is, well, we should do all good things, we should both make major carbon reductions, and combat malaria. But this simply ignores the fact that we aren’t doing either very well. We avoid the hard truth that the rich world’s focus is shifting daily towards global warming, with proportional less support seen for the real, and more tractable problems. It’s simply untruthful to claim that the focus on climate change doesn’t mean there’s less money going elsewhere. The Global Fund to Fight AIDS, Tuberculosis and Malaria, is telling us that billions of dollars are being redirected to the fight, global warming, at the expense of the biggest killers of the poor countries.

Any company or organization today that wants to be responsible, even just cool, will not be spending their cash on fighting tuberculosis, but wants to go carbon-neutral. We must save the world, yes. And here’s how. At The Copenhagen Consensus Project last year, a panel of the world’s most distinguished in carbon emissions are not worth the money” (1/13/09) economists looked at a wealth of research of all the major problems in the world, and the possible solutions to them. And they showed us where we can do the most good. They agreed that global warming’s real, and they were unanimous that the best way to tackle it is by investing much more in research and development in low carbon energy technologies. The economists also found that carbon emission cuts, tonight’s motion, would be the poorest use of our money.

They confirmed that we can do so much more good elsewhere, that we need to ease our preoccupation with cutting carbon, and focusing much more on fixing the real problems of the here and now. This is about saving everyone’s world. Not through ineffective and hugely costly carbon cuts, but through effective research and development, and low carbon energy sources, that anyway, will be the only long-term solution to the CO2 problem. And then remembering the major problems and challenges of this world. Every single year and right now, a devastation is taking place in our world. A dumb, readily avoidable devastation. Continuing mindlessly, and spending hundreds of billions of dollars in carbon cuts, is simply disgraceful, when it takes so little to do something about this devastation. So, this is our chance. Our chance not just to feel good about helping the planet, but actually to do the right thing, the rational thing, and in carbon emissions are not worth the money” (1/13/09) the morally correct thing. I commend this motion to you, do what’s rational, not just what’s fashionable. Thank you.

### Moderator
Claim: Thank you, Bjorn Lomborg. And worth waiting for. Our next speaker, Oliver Tickell, has had actually something of an intellectual feud with Bjorn in the pages of The Guardian, in London, back and forth, but Oliver himself is from Britain…has come up with— if Kyoto was the treaty that was supposed to slow the growth of greenhouse gases, it has failed and Oliver Tickell has come up with Kyoto II, an environmental blueprint. Environment is his passion and he is next arguing against the motion, ladies and gentlemen, Oliver Tickell.

### Scientific Advocate (SA)
Claim: I would prefer not to see this as any kind of feud, I think it’s a debate and it’s a debate which I’m very pleased to be able to pursue here, with all of you. Bjorn did an excellent presentation, and he made very effective use of the particular rhetorical flourish which I would call the false choice, or the false dichotomy. Either we address the problem of global warming, or we address the problems of malaria, water provision, and malnutrition. But this is a false choice, no one’s saying that we’ve got to do one or other, we can do both. It is no more real a in carbon emissions are not worth the money” (1/13/09) choice than that between tackling global warming and eating pizza. You know, we can do both. In fact, if we tackle the problems of global warming in an effective way, it will directly help with the provision of water. One of the major problems of global warming is the loss of rainfall, shifting patterns of rainfall, melting of glaciers that feed hundreds of millions of people worldwide. So, failing to deal with global warming is a huge step back on that fight, likewise with malaria, and other insect-borne disease, as temperatures rise, so these diseases will spread and become more prevalent, and hold back development further.

Now. The core point though, Bjorn very kindly began to make it for me. It is that the consequences of not dealing with global warming are potentially catastrophic. And, he said this is inconsistent with everything we know. Well, that’s wrong. What we do know, is that 55 million years ago, at a time called the Paleocene-Eocene Thermal Maximum, temperatures were ten degrees warmer than they are now. Carbon dioxide levels were approximately one thousand parts a million-- very high levels. And sea levels were approximately two hundred and fifty feet higher. Now, we have been there before. We can go there again. There is no law that says that we cannot revert to that state of fifty-five million years ago. There is no certainty that that will happen. It might happen or it might not. Climate is extremely in carbon emissions are not worth the money” (1/13/09) complex. There are many, many feedbacks of frankly, breathtaking intricacy and complexity, which we haven’t even begun to fathom. And for that reason, I find Bjorn’s certainty that this will not take place completely incomprehensible. There is no certainty in this. The only certainty is once it’s already happened. And given those uncertainties, our overwhelming priority must be to make sure that it does not happen.

It is hard even to put a probability on it, but the facts are that climate, the climate system is characterized by feedbacks, including some very powerful positive feedbacks, even with the one degree. In fact, under one degree of temperature rise that we’ve had so far, these feedbacks are kicking into effect. These include the melting of arctic sea ice which causes the sun’s rays to be absorbed, raising temperatures at the poles. It includes the reduced absorption of carbon dioxide into oceans. There were results in the newspaper yesterday from the Sea of Japan where the absorption of carbon dioxide is halved. We see that the forests of Canada, which had been considered a major net carbon sink, are now becoming a net source of carbon as a result of insect depredations caused by higher temperatures.

So, positive feedback process are already taking place as temperatures continue to rise further. Further positive feedbacks in carbon emissions are not worth the money” (1/13/09) can swing into effect and we could indeed find ourselves propelled through the uncontrolled emissions of methane, from example, from peat bogs and swamps. We could find that we well and truly lose control of climate, that positive feedbacks take over from everything that we are doing ourselves. And that is where we must not go. And yes, there are costs. To avoid this you have to spend money. But there are many other cases in which we spend money to avoid potentially catastrophic risks, even if we perceive those risks as being improbable – such as insurance against a car crash or a house fire, where the costs are potentially huge, even if the probability is low.

In this particular case, of course, we have to be mindful of the cost. We don’t just want to throw unlimited amounts of money at this problem. But if we look at the amounts of money, I mean, my cost – and which includes not only mitigation but also substantial funding for adaptation, which is already taking place – is about one trillion dollars per year. And that is, roughly the same as what the world spends on weaponry and the military sector. So if we can afford to spend that on weapons, why can’t we afford to spend it to prevent this potentially ruinous catastrophe that could come upon us. But I will go a stage further. I will say that much of this isn’t really cost at all. It is investment. Because we need ultimately to in carbon emissions are not worth the money” (1/13/09) move away from fossil fuels anyway. If we move away from fossil fuels sooner, before we have to – because they run out – that actually saves enormous economic cost.

It saves the economic cost of a hundred and fifty dollar a barrel petrol, oil. And that is something that has caused America and other countries huge hardships. We can create new industries. We have huge idle work forces. We have huge idle productive capacity in industries that can be put back to work building us a future free of fossil fuels. The world at the moment is ravaged by conflict, much of that conflict over access to fossil fuels. If we move to a fossil fuel-free future, then much of that expenditure will vanish. But not only that expenditure, but all of the suffering, all of the tragedy that is associated with it. So in answer to the question, the motion, Is it worth the money to make these major reductions in carbon dioxide emissions?, the only possible answer is, Yes, and do it now.

### Moderator
Claim: Thank you, Oliver Tickell. Our motion is: Major reductions in carbon emissions are not worth the money. And now arguing for the motion, Peter Huber, an author who publishes here in the United States, books with titles like The Bottomless Well. But I like to look at the subtitles that tell us really what he thinks. One of his books was subtitled: Saving the Environment From the in carbon emissions are not worth the money” (1/13/09) Environmentalists; another, Why We Will Never Run Out of Energy. Ladies and gentlemen, Peter Huber.

### Conspiracy Advocate (CA)
Claim: Well, while he was running, Barack Obama was heard to say that he would bankrupt our coal industry. Now, I don’t doubt Washington’s ability to bankrupt almost anything in the United States. But, but China is currently adding a hundred gigs of coal electricity a year. That’s one entire United States worth of coal consumption every three years. There is no end in sight and there are other countries, all across the globe, following exactly in its footsteps. So let me say here quickly, where I end up and then try and tell you how I get there.

We rich people of the planet can’t stop the other five billion poor people from burning a couple of trillion tons of carbon that they have within easy reach. We can’t even make any real dent in global emissions because the emissions are growing too fast, they involve too much involvement by very poor people who can’t easily change their ways and because those poor people are part of the same global economy as us.And if we are foolish enough, which we could well be, we will let carbon worries send our jobs to their shores and they will grow even faster and carbon emissions will grow faster still. It should go without saying, we don’t control global supply of carbon. Ten countries ruled by in carbon emissions are not worth the money” (1/13/09) thoroughly nasty people control eighty per cent of the world’s oil, a trillion barrels currently worth fifty trillion dollars at current market prices.

Now, if I told you that there was that value in gold where it actually is, where the oil actually is, you would scoff at any suggestion that anything we could do, no matter what we spent, could force those people to keep that oil in the ground. It’s all they’ve got. They will drill it. They will pump it. They will find a market and somebody will burn it. Poor countries all around this planet are sitting on a trillion tons of readily accessible coal. It’s all they’ve got for energy beyond the other great carbon reservoir of the planet, which is the rain forests and the soils, which they also, by and large, control. They will squeeze the carbon they can out of cheap coal, cheap forests and cheap soil, because that’s what’s there, unless they can get something even cheaper than that.

And that, as I shall discuss shortly, is going to take some doing. We no longer control demand for carbon, either. The five billion poor people are already the main problem – not us. If you have heard otherwise, you have heard wrong. Collectively, the poor already emit twenty per cent more greenhouse gas than we do. We burn a lot more carbon individually, of course, but they have in carbon emissions are not worth the money” (1/13/09) a lot more children. Their fecundity has beaten out our gluttony and the gap is now widening very fast. China, not the United States, is now the largest emitter of greenhouse gas on the planet and it will soon be joined by others. It’s only a matter of time. And finally, the poor countries have made perfectly clear that they are not interested at all in spending what a low carb diet would cost. They have more pressing problems. So it really does come down to this. First, can we give the world something cheaper than carbon?

The moon shot law of economics says, Why, yes, we can. If we just really put our minds to it, it will happen-- atom bomb, moon landing, energy, you name it. No, not this time. Fossil fuels are very cheap because they concentrate a lot of energy in a small space. You find a mountain of coal and you can just shovel gargantuan amounts of energy into the boxcars. Renewable fuels like sun and wind are much harder. Windmills are now fifty story skyscrapers, yet one windmill generates a piddling two megawatts. A jumbo needs a hundred megawatts to get off the ground. Google is building hundred megawatt servers just to move bits around. Meeting New York City’s total energy demand would require something like thirteen thousand windmills spinning at full speed or more like fifty thousand windmills scattered all over the state because you’ve gotta have enough of in carbon emissions are not worth the money” (1/13/09) them to be sure enough of them are in the windy spots.

What was your Mayor thinking when he suggested that you might just tuck them into Manhattan? I mean, that kind of thinking betrays a very common view that, In fact, it betrays a profound ignorance about how difficult it is to get huge amounts of energy out of these very dilute, thin forms of fuel, like sun and wind. Renewable technologies are not moving down the same plummeting cost curves that we’ve seen in our laptops and our cell phones. When you replace conventional with renewable everything gets bigger, not smaller – much, much bigger – and costs get higher, not lower. China and India won’t trade three cent coal for fifteen cent wind or thirty cent solar.

And if we force those expensive technologies on ourselves, we will certainly end up doing more harm than good. Twenty percent of the planet buys much less carbon, the other eighty percent will be delighted to buy at a lower price. The real jobs will go where the energy is cheap, just as they go where the labor is cheap because manufacturing and heavy industry require so much energy. And in a global economy you can’t possibly compete if you’re paying two or three times as much as your competitors for an essential input. Green jobs means Americans paying other Americans to chase carbon while the rest of the world builds in carbon emissions are not worth the money” (1/13/09) power plants and factories. But the rest of the world is less efficient than us and less careful. A massive transfer of carbon and industry and jobs from us to them will raise carbon emissions. It will not lower them.

So, unless we are going to ask the Pentagon to take charge – and good luck with that-- we don’t have the power to deliver any lasting reduction in global carbon emissions at all. Whatever we might achieve in the very short term at home, we can’t control the global supply of carbon. We can’t control the five billion poor people who desperately want to burn it and who already control more of the demand than we do. And we can’t control the flight of jobs and industry to where the industry is cheap. Frantically chasing the impossible and falling flat on your face doesn’t make things better. It often makes things worse and it’s never worth the money.

### Moderator
Claim: Thank you. Thank you, Peter Huber. Arguing against the motion, Adam Werbach. And in the nineties, Adam Werbach was the whiz kid of the environmentalist movement. At twenty-three he was the President of the Sierra Club. His views have evolved since then and recently he has been consulting for Wal-Mart. Ladies and gentlemen, Adam Werbach. in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: Major carbon reductions are worth the money. Mr. Huber, I want to thank you for your novel argument, summed as, No, we can’t. You begin by saying you care about the world’s poor and then you start by saying, “The five billion poor people are the problem.” We’re going to send our jobs to their shores. They have too many children. This type of contempt will not lead us towards the world that we want to build for our kids, either here or across the world. The question at hand, and the question we face, is, Are major reductions in carbon worth the money? And I’ll very simply give examples at the level of the economy, at the level of a corporation and the level of the individual. Not is it all investments, every investment – it’s, Are major reductions worth the money?

Mr. Huber, I read that you wrote about enhancing America’s electric power grid. That’s a great way of having great reductions in carbon in a way that’s very much worth the money. We waste about six to ten percent of all energy through America’s very inefficient electricity grid. If we invested in a smart grid it could save up to twenty billion dollars a year that’s lost through line loss. Major carbon reductions can be worth the money. Americans spend about a week a year, if they commute a lot, in carbon emissions are not worth the money” (1/13/09) stuck in their cars. That costs the economy in terms of productivity and fuel costs about $78 billion a year. If we invested in new traffic software and signaling, public transportation to create those green jobs that you have such contempt for, um, we could in fact reduce that, greatly. Major carbon reductions are worth the money. At the level of a corporation, more and more corporations are not just doing it because it’s fashionable, they’re doing it because they’re building a strategy for sustainability to move them forward. I’ll give you a few examples. Xerox, that iconic American company, around the year 2000 was on the verge of bankruptcy, was, was at its knees, and the vultures were circling. And Ann Mulcahy, the CEO, when she took over she committed that by 2012 they would reduce their carbon output by 10 percent between 2002 and 2012, and they started investing in remanufacturing, and today 91 percent of all the parts in Xerox machines are remanufactured or recycled, which means you don’t need to get new stuff from the earth and much better from a carbon emissions standpoint.

Well by the year 2006, they reached that 2012 goal, they reached their 10 percent reduction and they actually committed to a 25 percent reduction, by the year 2012. Today, in 2009, they’re at about 21 percent and they’re well on their way. There’s a company that’s more productive, that’s making more money for in carbon emissions are not worth the money” (1/13/09) its shareholders, because of strict carbon restrictions. Sun Microsystems has about half of its workers telecommuting. This saves the worker a few hundred dollars, up to $1000 because they don’t have to commute anymore, and it saves the company money. Last year about $68 million in avoided costs because they didn’t have offices for all those people. People get to be more productive, they get to work in their pajamas, it’s a win-win all over the place, major reductions in their carbon use, about 30,000 metric tons saved by that, are good and worth the money.

Finally a company that I do work with, Wal-Mart. Wal-Mart made three commitments in its turn-around, one, to be powered 100 percent by renewable energy which would be a major reduction in carbon. Two, to produce zero waste, which would reduce their carbon emissions. And three, to only sell green products in their stores. Major commitments by a major manufacturer. They’ve pushed this down the supply chain, it pulled energy out, lowering the cost of the products, lowering the cost to the consumer. And one of the reasons a company like Wal-Mart is doing so well right now is that they’ve become more efficient, because of a focus on major reductions in carbon. And, one of the associates I was able to work with at Wal-Mart is named Chuck Bonnett, I want to give you as an example—at an individual level, how major reductions can actually make sense. in carbon emissions are not worth the money” (1/13/09) Chuck works the meat counter at Wal-Mart, and he made a personal sustainability practice commitment, to reduce the amount of carbon emissions that he had personally. A major reduction in his personal life, in carbon emissions.

And he tried to figure out what to do and he was actually in line at a fast food restaurant. And as he was in this line waiting for his burger, he watched all the cars idling and thought, oh, that’s carbon. And he thought about the hamburger which had been, been frozen and shipped across, maybe across the country, perhaps across the world, and he thought about the carbon that came from the cow and the thought about the plastic that was wrapping this hamburger. And he thought you know if I cut that out, it’s not gonna only be good for my health, and he had to lose about 100 pounds, maybe I can get a discount on my health care, and actually, maybe I can save some money ‘cause I’ll cook meals at home rather than going out so much which a lot of people across the world are doing, who have the opportunity to eat out.

In this case, major reductions in his own personal carbon emissions, were worth the money. Now… our opponents tend to focus on the fact that we can’t do everything. And that there are other problems and, yes, there are other problems and we need in carbon emissions are not worth the money” (1/13/09) to work on them. For example, I could tell you tonight, that there are exit signs at the back of the theater and, there’s one at the side of theater and that’s probably very important in case there were a fire, but, maybe I could instead tell you about influenza, because that’s the eighth-largest killer in America and I might tell you worry about the person next to you, ‘cause they might be a little sickly. And you might need to worry about them, or maybe I could check your purses, or check your dinner reservation for later tonight because maybe, you’ll decide to go out and have a dessert or a creamy special appetizer. Because you know that heart disease is the greatest killer in America.

These things are all true, but we can do two things at once, we can walk and chew gum at the same time. And the great thing about carbon, is that it’s one single thread, if you pull it, the entire sweater begins to unravel. It’s one single step that can help people save money and live better lives at their individual level, at a corporate level, and even at an economy-wide level. Major reductions in carbon are good for the economy, and are absolutely worth the money. Thank you.

### Moderator
Claim: Thank you, Adam Werbach. Arguing next for the motion, Philip Stott, professor emeritus from the University of London, his in carbon emissions are not worth the money” (1/13/09) specialty carries the distinct and revealing name of biogeographer, he is an expert in many things, from the nature of fire to the behavior of soil. And tonight he is arguing for the motion.

### Conspiracy Advocate (CA)
Claim: Thank you, John. Adam and colleagues, I really wish I could believe that we can manage the costs that would control climate. Very sadly, I have to quote Samuel Johnson, the great British lexicographer. “An obstinate stubbornness, a rationality, stops me believing it.” And with a twinkle in my eye, because we’re in New York and near Wall Street, what I want to show, very dangerously, is that, climate science and these costs are sub-prime science…sub-prime economics, and above all, sub-prime politics. And they will cost us dear, despite what Adam and Oliver and Hunter will be saying. And we’ve got to be very, very careful. And Bjorn used a very important phrase. Let’s not just follow what’s fashionable. In fact, Johnson again had a wonderful phrase for it. “Let’s not be befuddled, by the clamor of the times.” Let me therefore start, by science, I’m not going to say much on science because, I agree with what Robert said, right at the start in this. It’s actually not very much about the science, it’s always been about economic and political choice. Everything is when it in carbon emissions are not worth the money” (1/13/09) comes down to it, like it or not. But I just want you to have one image, and it’s a very serious scientific image, I want you to think of the world…I want you to think of the world from inner Siberia, to Greenland, then to Singapore, and then come to the Arab states and to Sahara. What, ladies and gentlemen, is the temperature range I have just covered. It is from minus 20 degrees C, to nearly 50 degrees C, a range of 70 degrees C, in which humanity has adapted and learnt to live. We are talking about, ignoring the extremes that Oliver said, a prediction of 2 to 3 degrees C, what a funk! I’m very serious, what a funk! Humanity lives successfully from Greenland to Singapore to Saudi Arabia. 70 degrees C. And what is more, the carbon reductions will not produce an outcome that is predictable. Climate is the most complex, coupled, non- linear, chaotic system known to man. Of course there are human influences in it, nobody denies that. But what outcome will they get, by fiddling with one variable at the margins. I’m sorry, it’s scientific nonsense. And a very serious nonsense. But it’s the economics above all, because that’s the motion, the costs. I come from the left wing politically. I am fed up with environmentalists putting regressive costs and taxes on the poor. It always costs more in the end, whatever in carbon emissions are not worth the money” (1/13/09) Adam and the other say, and it’s always fundamentally on the poor.

They’ve forgotten the famous Jevons Paradox, Professor Jevons from my own country, University College, London, that actually when you save on energy, you don’t really save, you simply transfer it to new energy costs, and actually probably issue more CO2. So when you save energy you take another holiday, you take another flight, your CO2 increases. And he demonstrated that in the 19th century. Have we forgotten this basic economics. But above all, it’s this. I’m going to be honest about this, I don’t trust the environmentalist agenda. For 30 to 40 years, what they have fundamentally been wanting to do, is place an infinity in cost-benefit. In other words, so that the rationality of economic choices is undermined by effectively a religious choice, not an economic choice. Under an infinity of course, choice is not made under the procedures that were put down by Peter, and by Bjorn. But it won’t work.

And that leads me, it becomes a closed system of thought, and that always worries me deeply. But it’s the politics then, finally, sub-prime politics. We are full of eco-poseurs and in the United States you have some gems. I don’t think I need to mention them. But what we’ve got to remember is that, this in carbon emissions are not worth the money” (1/13/09) motion is about the cost of artificially in a sense, forcing down the carbon. Energy security, efficiency, are of course they’re absolutely vital. Energy security will become of the major themes…of the Obama administration, and rightly so, but that isn’t artificially forcing down carbon. And exactly as Peter said, only this week, China announced a 30 percent increase by 2015, in its coal production. Actually announced that only this week. And in a sense, we are not being realistic. As I said I would love to be able to think we can control climate, when of course it is indeed going to have to be adaptation, flexibility put to an outcome that we don’t know ‘cause I actually don’t know what climate, they’re wanting to produce for us. And actually I don’t think they know either. But let me come back to Johnson again, ‘cause Johnson said everything—Bible, Shakespeare and Johnson, you’ve got it. And Johnson said virtually everything. In a very, very brilliant book that he wrote in the 18th century there called Rasselas, he talks of an astronomer who claims that he can control climate. This is what he says. “The sun has listened to my dictates, and passed from tropic to tropic by my direction. The clouds at my call, have poured their waters.” And what does Johnson say about this astronomer—astronomer? He was mad! And so are we, if we actually believe we can control climate in carbon emissions are not worth the money” (1/13/09) predictably, the costs in every sense will be enormous. Oh, mamma mia. We are the dancing queens. Let’s give this global warming nonsense, its Waterloo tonight. Thank you.

### Moderator
Claim: Thank you, Philip Stott. Finally, speaking against the motion I’d like to introduce L. Hunter Lovins. She is the founder of Natural Capitalism, an organization whose precepts are ecologically friendly development, and research tells us that Time magazine has named her a Hero of the Planet. Ladies and gentlemen, Hunter Lovins.

### Scientific Advocate (SA)
Claim: Wow. Philip, you ought to be a preacher. You ever heard a more religious proposition? Let’s bring it back to economics, I’m a professor of business at Presidio School of Management, and I teach my students to follow the money. Are major reductions in carbon worth the money. That’s what we’re debating, we’re not debating whether or not we can control the climate, we’re not even debating what the climate will be, we’re debating, are major reductions worth the money, and that’s the only question…for better or worse that we’re gonna talk about tonight. in carbon emissions are not worth the money” (1/13/09) My company walked into a company that has big warehouses, about a million square feet of warehouse, and boxes stacked floor to ceiling. Every 10 feet in the ceiling were 500-watt light bulbs shining down on the tops of boxes. The guys who worked down below had task-lighting so they could see where they were going. We said, y’all have a switch? $650,000 saved the first year, now that is not a cost, to deliver major carbon reductions. Similarly we worked with another company that has left its… 630,000 computers and monitors on 24-7 because they had an urban myth that you, uh, have to leave your computers on. And we pointed out to them that, actually, IT did not need them left on 24-7. And a simple company policy that when you turn your computer off you turn it all the way off, saved them $700,000 the first year. Again, zero cost, now this is what’s called low-hanging fruit, we could half the carbon in the country. Let’s look at what we’re actually spending on carbon, this country borrows somewhere between a billion and $2 billion a day to buy oil, we borrow the money from the Chinese, and we send it to the Saudis, as Jim Woolsey who used to run the CIA, we’re fighting both sides of the war on terror, we pay for our guys and we send money to the guys who pay for the other guys, now this is daft. We know how to eliminate, at least three quarters of that oil, just in carbon emissions are not worth the money” (1/13/09) through smarter technology, so now you and I and the rest of American taxpayers are gonna bail out Detroit because they failed to do this. How about we attach a little string to that money, if we’re gonna own the car companies now, let’s ask them to build the state of the art cars. Any of you ever seen a Tesla? You wanna go real fast? Yeah.

We can build safer, faster, peppier, sportier, better cars, that use no energy, now, electric car, okay, you go to Google. Google recently decided that they could make all of their parking lots carports with solar on ‘em…pay back within 10 years, oh, 10 years is a long time, no it’s not. A two-year payback which is what people say they demand, is a 70 percent return on investment. You guys on Wall Street, you tell me where you can get 70 percent return on investment in today’s market. So Google put in these solar--and they have little pull-down plugs, you bring your electric car, you plug it in. My next car’s gonna be a plug-in hybrid. My friend Jim Woolsey, the ex-head of the CIA, drives a plug-in hybrid he runs on solar on his roof. Has a little bumper sticker on it, “Osama bin Laden hates my car.” Major reductions in carbon are worth the money.

Chicago Climate Exchange, this is a voluntary group of now over in carbon emissions are not worth the money” (1/13/09) 400 businesses, my company is a member…who have pledged to cut their carbon. They have reduced carbon…collectively 8 percent. There’s no law that says they have to, you don’t need taxes, you don’t need Draconian regulation. We simply need to be smart about how we use energy. They represent companies, 20 percent of the Dow Jones industrials, and 17 percent of stationery emissions in this country. California, AB-32, new study out from the University of California, fully implementing the Republican Governor Schwarzenegger’s cap on carbon. And trading regime…would deliver to California $78 billion, in increased state gross product. $78 billion, and 400,000 new jobs. Florida, another Republican governor, Republican task force study, that cutting carbon emissions 51 percent below the business-as-usual projections, would add $28 billion to state gross product, several hundred thousand new jobs.

Arizona, even more, 60-some percent cut below now, $5 billion and 200,000 new jobs, there are now studies from 20 states, you add it up…if this country implemented aggressive climate protection measures, 500 billion in increased savings to the country, and 5 million green jobs. That’s where the 5 million green jobs number comes from. So let’s bring it home. 4 Times Square down the, down the road? Looks like a normal building, costs the same to build, uses half the energy, gets its energy from in carbon emissions are not worth the money” (1/13/09) photo-voltaics in the skin of the building, and a fuel cell in the basement. This building can never be turned off.

So in the 2003 northeast blackout, remember that? People came from blocks around to camp out underneath it. Genuine homeland security, if we want security, if we want an economy, we wanna have jobs in this country, we will invest in energy efficiency and renewable energy. Because it’s what gives us the greatest rate of return. Oh, and it also solves the climate problem, assuming there is one. But let’s assume the climate skeptics are right. Everything you would do if you were simply a profit-maximizing capitalist, is exactly what you would do if you were scared to death about climate change. A little company across the river, Voltaics. My friend Peter De Nuvila’s chair of this little company, they make the gas precursors for photo-voltaics. Because they’re selling a lotta their gases to China, they are now a net exporter—they’re making their county a net exporter to China. Again, if we want an economy, we can unleash the greatest…prosperity humanity has ever known. And Bjorn, I share your, your care for people in developing countries, where are we gonna get the money? We’re gonna get it because we’re going to invest in renewable energy, energy efficiency, and those investments are worth the money. Thank you. in carbon emissions are not worth the money” (1/13/09)

## Round 2

### Moderator
Claim: Very nice, thank you—thank you, Hunter Lovins. And may we just applaud all of our panelists for the presentations that they’ve gone through, thank you. So, where we are in the debate, the time period of uninterrupted speaking is over, we’re going to move into the portion of the evening now where the debaters debate one another, and we are going to call on you the audience shortly to help along that process with your questions but first, as you recall, when you came in this evening we polled you about your view on the motion and we will poll you again after the debate but I have the results that have come in now.

Reminding you, our motion is, major carbon emissions—major reductions in carbon emissions are not worth the money. The results are interesting. In support of this motion, 16 percent. Against the motion, 49 percent, and that leaves 35 percent undecided. And reminding you also that as we say this is a contest to change your mind so that “undecided” becomes very important, if that shrinks, the winner will most likely be determined by whom that goes on. So, I’d like to now come to your questions and what I’m going to do in the beginning is maybe collect two or three and get a sense of the room that way and then begin to put those questions to the panel, so if you in carbon emissions are not worth the money” (1/13/09) wanna just— If you’re ready to ask a question you can raise your hand and I’ll find you, and I see down—right down front…third row…

### Moderator
Claim: Thank you. Is the mic on?

### Moderator
Claim: Now, I think your mic is now on.

### Moderator
Claim: Okay.

### Moderator
Claim: Yes.

### Moderator
Claim: My question derives from my confusion about the definition of the term, “major.” Which two of the panelists for the motion— or against the motion rather, have defined as being individual cost- efficiency, it’s what used to be known as being Scottish and frugal. And, but, Mr. Rosenkranz in introducing the debate spoke about Kyoto II, and the cap-and-trade of effectively tax through auction, that would be imposed constituting he said 2 percent of the GNP of the global economy. That’s a huge amount of money and I was curious under that scheme, who would control those dollars, who would allocate them, and where would the accountability be. in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: All right. I’d like to go to—I’m gonna reserve that, and collect a couple more questions, anybody up the aisle here…? On the far side, woman in the green jacket?

### Moderator
Claim: I notice that the panelists who were in favor of the motion spoke a lot about other nations in the world that are not subject to our constraints or, simply aren’t interested in them, as far as we can tell, and the proponents for, mostly talked about what’s going on in the United States, so I’d like to see what the “for” proponents think about the global situation, taking into account China, et cetera.

### Moderator
Claim: Okay, one more? Uh, front row. White jacket?

### Moderator
Claim: Well, many environmental impacts such as carbon emissions are merely treated as externalities in terms of economic costs. Al Gore however suggests that these carbon emissions are treated as total economic costs. How greatly would American industries be affected if these environmental impacts were treated as costs rather than externalities.

### Moderator
Claim: And do you direct that question to anyone in particular? in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: Um…probably the people for the motion.

### Moderator
Claim: Okay, let’s start, let’s work in reverse order, and Bjorn, would you like to take that last question?

### Conspiracy Advocate (CA)
Claim: Yeah, and clearly I think any economist would say that we need to actually make sure that the externality, the thing that you don’t pay for, that you actually end up paying for it. But you also have to have a realistic sense of it, and that’s of course where we need to talk, not just about what works, and in particular, companies, but what actually works for the economy. If you look across all the different studies, and Professor Richard Tol has done so, and it’s the latest and the only global survey of all the costs of what is an extra ton of CO2 causing of damage in the world, the answer is that’s about $7 per ton of CO2. That translates pretty much into 6 cents per gallon of gasoline. So yes, we should have a carbon tax, that’s not what actually gonna do anything majorly for or against our emissions.

### Moderator
Claim: Oliver Tickell, what did you hear in that answer?

### Scientific Advocate (SA)
Claim: Well, I think that the—this whole question that, of paying for externalities associated with carbon emissions is absolutely in carbon emissions are not worth the money” (1/13/09) crucial. And then, you get to the point of if people do pay for externalities in the form perhaps of a carbon tax or an auction price of carbon permits under a cap-and-trade system, what then happens to those funds that are raised. And clearly, there are two ways to go, there is adaptation, there is mitigation, but the greatest of these is mitigation. Because the best way that we can serve the victims and potential victims of climate change, is by making sure that it does not happen.

### Moderator
Claim: Philip Stott, what’s this head-shake—

### Conspiracy Advocate (CA)
Claim: Oh—

### Moderator
Claim: —so you’re gonna—

### Conspiracy Advocate (CA)
Claim: You—you’re never going to stop climate change, can we just kill one thing off. Climate will change without us or with us. And that’s where Bjorn is right. Bjorn—Bjorn is right because always it’s going to have to aid adaptation. If in any way we impoverish ourselves so we cannot help the developing world, that would indeed be a moral mistake of mammoth proportions—

### Scientific Advocate (SA)
Claim: Whoa, nobody’s talking about impoverishing ourselves, we are talking about the generation of wealth through smart in carbon emissions are not worth the money” (1/13/09) investments. Now your question of, who’s gonna spend the money…most of the people that are proposed to spend the money, whether it be the UN or the US government or anybody’s government, I think they’re gonna spend it badly. How about we set incentives to enable the business community to do what it is already doing, which is decarbonizing, because it’s in their economic interest—

### Conspiracy Advocate (CA)
Claim: But—but, Hunter, I love the loucheness of saying, oh, this is gonna be free, we are gonna make money off of this. I love the fact that you want to reintroduce into the American public the idea of a profit-maximizing CEO. I think that’s a good idea. But honestly, I think you already have that. The point is, how are we gonna get beyond that, and that is gonna be costly and Europe has shown the way. It’s not costly—

### Moderator
Claim: But, Bjorn, costly, I mean the question went to the matter of a 2 percent of—

### Conspiracy Advocate (CA)
Claim: Yeah—

### Moderator
Claim: —GNP, that is enormously costly.

### Conspiracy Advocate (CA)
Claim: Yeah, and that is what the UN is telling us that the cost is in carbon emissions are not worth the money” (1/13/09) probably gonna be. I mean, you have a discussion about is it gonna be 1, is it gonna be 3 percent, but it’s definitely gonna be hugely costly, and simply making these stories that some companies can make money, hey, great. And presumably we don’t have to do anything to make them make money.

### Scientific Advocate (SA)
Claim: But—Bjorn—

### Conspiracy Advocate (CA)
Claim: But the real question is—

### Scientific Advocate (SA)
Claim: Please—

### Conspiracy Advocate (CA)
Claim: —where are we gonna get the rest of the cuts—

### Scientific Advocate (SA)
Claim: One of the absolute key things here is actually to address the very agenda that you’ve put forward of huge spending into research and development—

### Conspiracy Advocate (CA)
Claim: Yep—

### Scientific Advocate (SA)
Claim: —for renewable technology, and the strange things is that you put that forward as if it were some kind of an alternative to cutting carbon but in fact it’s a very important aspect of how you set about cutting carbon emissions. Where you’re wrong with in carbon emissions are not worth the money” (1/13/09) that, it is a necessary part but not sufficient because there are two components, there’s research-and-development, and then there is making sure that it happens on a sufficiently large scale to get the economies of mass production, which are real, and we know in the case of solar PV, that the cost falls 20 percent, for every doubling of production, we see in the New York Times today, that the cost to Americans of installing solar PV is half of what it used to be, as a result in part of these kind of cost savings—

### Conspiracy Advocate (CA)
Claim: Oliver, we’re not disagreeing with you on that—

### Scientific Advocate (SA)
Claim: We need—this is the situation that we need to bring about, and as the costs come down, through research, through development, through mass production, through large-scale deployment, we are bringing—

### Conspiracy Advocate (CA)
Claim: But Oliver—

### Conspiracy Advocate (CA)
Claim: Nobody on this panel, nobody on this panel is against increasing energy efficiency and energy security, it’s the most sensible thing of all. But if you’re making the marker of it, always what is in carbon emissions are not worth the money” (1/13/09) precisely happening to carbon, A, you’re not gonna do it, and I’m sorry to say you’re not actually going to do it for a reason I’ll just mention in a second, but also, you’re—the real issue is how are we going to have enough energy of all types, not just to keep the US going, but above all from my point of view, for the developing world. That is to me absolutely crucial—

### Scientific Advocate (SA)
Claim: Absolutely—

### Scientific Advocate (SA)
Claim: But let’s talk about the developing world and how you—

### Conspiracy Advocate (CA)
Claim: Yeah, but

### Scientific Advocate (SA)
Claim: —how you meet their energy needs. Frankly they—

### Conspiracy Advocate (CA)
Claim: How they meet energy needs—

### Conspiracy Advocate (CA)
Claim: With energy—

### Scientific Advocate (SA)
Claim: The developing world—the developing world—

### Moderator
Claim: Peter Huber, let’s hear from Peter Huber, please—

### Conspiracy Advocate (CA)
Claim: in carbon emissions are not worth the money” (1/13/09) We know how they’re meeting their energy needs, they are taking down the rainforest, they are soaking carbon out of their land, and they are burning coal, I mean we actually know this—you know, all this talk about externalities— If you don’t know this, the Kyoto system divides the world. I didn’t do this, they did it, they divide it into 20-80, okay? Everything on the 20, nothing on the 80. How can we even talk about externalities—if we said to you, folks, we’re getting an externality system worked out for this group just right here, but it’s only this group here, all the rest of you do what you like, what do you think would work with that system, nothing would work.

### Scientific Advocate (SA)
Claim: Interesting and totally off the point of are major cuts in carbon worth the money. Take Afghanistan where I work. You and I and the rest of American taxpayers this winter will spend something like $80 million, buying diesel to run the North Kabul power planet, that diesel trucked over the Khyber Pass, fat target. If instead, we enabled the Afghans by training, by technology transfer, to grow oil crops, like getropha, or sunflowers, or nut crops, take the oil and make it into biodeisel, they would have a viable industry, they would have jobs, and we would not be paying for the diesel—

### Conspiracy Advocate (CA)
Claim: Right. in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: —to pollute the air in Kabul. Now yes, this would be an expenditure of money. It would enhance national security for us, and if in fact we don’t deliver genuine development to the Afghans, we will get our heads handed to us—

### Conspiracy Advocate (CA)
Claim: But Hunter, what about the impact of biofuel development for this, on the need, even greater need to increase world food supply. You’re taking land now increasingly for biofuels to increase world food supply, it is a competitive choice—

### Scientific Advocate (SA)
Claim: Only because you’re doing it stupidly and because—

### Conspiracy Advocate (CA)
Claim: No—

### Scientific Advocate (SA)
Claim: —we are subsidizing it.

### Conspiracy Advocate (CA)
Claim: No. No—

### Scientific Advocate (SA)
Claim: Yeah. We are—

### Conspiracy Advocate (CA)
Claim: You are subsidizing it, but, in fact the seriousness all the way through from Malaysia for example to Indonesia et cetera, the impact is potential, in fact some people argue, it is now one of the in carbon emissions are not worth the money” (1/13/09) most serious pressures causing in fact reduction in world food supply.

### Scientific Advocate (SA)
Claim: But I’m not trying to defend—

### Conspiracy Advocate (CA)
Claim: —at a time, when we have to—

### Moderator
Claim: Bjorn—Bjorn Lomborg, let’s have—

### Conspiracy Advocate (CA)
Claim: Well—

### Moderator
Claim: —Bjorn—

### Conspiracy Advocate (CA)
Claim: —I just want us to bring us back to having a conversation and Hunter was actually very good at that. We need to get back to business, this is not about who can come up with the smartest story or the most endearing cute little tale. This is about how can we do this in the world. And the economists have done those studies, and they have shown that this has real and significant costs, on the of, you know, 1 to 3 or 4 percent of GDP.

### Scientific Advocate (SA)
Claim: But I think you miss the difference— in carbon emissions are not worth the money” (1/13/09)

### Conspiracy Advocate (CA)
Claim: The question is—

### Scientific Advocate (SA)
Claim: —between a cost and an investment—

### Conspiracy Advocate (CA)
Claim: —do you want to spend that much money— Well, but the problem is, it’s not an investment if it doesn’t actually pay back more and that’s of course the whole question. Are we doing a lot of good for the world—

### Moderator
Claim: Adam Werbach, against the motion—

### Conspiracy Advocate (CA)
Claim: I love the fact that we’re being—

### Moderator
Claim: —speaking against the motion.

### Scientific Advocate (SA)
Claim: I enjoy the conversation, I mean two, three years ago we were arguing about whether climate change was real. And now we’ve moved beyond that, now the question is should there be a carbon cap, that seems to be or should it just be investments in things that actually bring down the cost of energy for everyone. Okay, well I agree that we should be investing and bringing down the cost for everyone. Now, then the debate is, are major reductions in carbon necessary, do we actually need a cap in carbon emissions are not worth the money” (1/13/09) as well. Well for the companies I work with and for governments, they actually want the rules set. We know what happens when the rules aren’t set. But what’s happening when the rules are not set is we see companies…and like, we’ve just seen in Wall Street.

### Conspiracy Advocate (CA)
Claim: But Adam—

### Scientific Advocate (SA)
Claim: —we’ve seen, without an effective SEC, with an effective regulatory framework, people can invest and there’s no guarantee for the investment—

### Conspiracy Advocate (CA)
Claim: But—but Adam, your side itself is proposing no cap on 80 percent of the world that currently generates fifty—

### Scientific Advocate (SA)
Claim: But—no, I am saying—

### Conspiracy Advocate (CA)
Claim: —54 percent—

### Scientific Advocate (SA)
Claim: Wait—we are not proposing that—

### Conspiracy Advocate (CA)
Claim: 54 percent of, of the—

### Scientific Advocate (SA)
Claim: This is in carbon emissions are not worth the money” (1/13/09)

### Conspiracy Advocate (CA)
Claim: —the greenhouse gases.

### Scientific Advocate (SA)
Claim: This is the old Kyoto system and I don’t think any of us is supporting that.

### Conspiracy Advocate (CA)
Claim: John, could we just answer the word “major,” which seemed to be the really—

### Moderator
Claim: Yes, I was gonna come right to that—

### Conspiracy Advocate (CA)
Claim: —serious question that the lady here asked. If I’m being quite honest about major, to influence climate in any way, you fundamentally would have to throw 4 billion people out of work. You’d have to keep every ounce of coal in the ground, every ounce of oil in the ground, and let’s be absolutely frank, it isn’t going to happen. Because, the impact of anything less from changing your light bulbs to biofuels, is absolutely nonexistent on climate, and that’s my point. If it were truly worth doing, the costs would be right. But it won’t work on climate.

### Scientific Advocate (SA)
Claim: Now, Philip, I would really like to take you up on the point here because I think that what we’re seeing here, when in carbon emissions are not worth the money” (1/13/09) we began, the introduction that was given was that your side accepted the fundamental reality of climate change caused by greenhouse gases in the atmosphere but all you’ve done is to deny it.

### Conspiracy Advocate (CA)
Claim: No—

### Moderator
Claim: Panel, there—there has been a tendency to, I think almost accuse the other side of intellectual dishonesty. Philip, you used the term “junk science.” Adam—

### Conspiracy Advocate (CA)
Claim: I didn’t—

### Moderator
Claim: —you, you accused—

### Conspiracy Advocate (CA)
Claim: No, no, no, I didn’t—

### Moderator
Claim: —Peter Huber of contempt. Bjorn, you accused Oliver Tickell of doom-mongering—

### Scientific Advocate (SA)
Claim: That’s what I’ve been doing—

### Moderator
Claim: Do, do, do— Do you in fact— Adam, do you think in carbon emissions are not worth the money” (1/13/09) your other side, your opponents’ arguments are intellectually dishonest?

### Scientific Advocate (SA)
Claim: Well, that’s for them to decided in their consciences tonight. But, um—

### Moderator
Claim: No, no, actually—

### Scientific Advocate (SA)
Claim: But I do—but the ques—

### Moderator
Claim: —it’s a question to you.

### Scientific Advocate (SA)
Claim: But the question I guess—I accused my opponent of contempt. And when someone says 5 billion poor people are the problem, and that’s—that was a direct quote from what he said, that is a contemptuous statement. “Our jobs sent to their shores.” That is a contemptuous statement. I don’t—I think that is a fact.

### Conspiracy Advocate (CA)
Claim: Well, if anybody took—

### Moderator
Claim: Peter Huber—

### Conspiracy Advocate (CA)
Claim: —a discussion of jobs as contempt, I truly apologize, I feel no in carbon emissions are not worth the money” (1/13/09) contempt, I’m trying to talk about macro-economic effects in a global economy, you know, many people feel there is a global economy and things do move like that. As for saying, you know, their fecundity has beaten our gluttony, I don’t know which is ruder, to be, you know, gross and eat too much, or to have lots of children but I don’t mean any contempt by it, I’m just saying it is an actual fact.

### Moderator
Claim: Philip Stott—

### Conspiracy Advocate (CA)
Claim: It really is the truth—

### Moderator
Claim: Philip Stott speaking for the motion—

### Conspiracy Advocate (CA)
Claim: Yeah, John, one of the great things about the Rosenkranz Foundation debates is precisely that they assume that each side respects the position of the other, and one of the great things about this debate is that I’m hearing all these arguments, I actually am happy to respect the position, and in fact one of the terrible things that has happened recently, is the attempt to close down debate, and in fact to attack people, with the use of extremely un—not my colleagues here, extremely unpleasant language. It is absolutely that debate is vital on a topic like this, it’s vigorous of course, Hunter and I are gonna go in carbon emissions are not worth the money” (1/13/09) at each other. But I respect her position absolutely, and not one of us denies the influence of humans on climate change—

### Scientific Advocate (SA)
Claim: But, Philip, you yourself spoke earlier of “this global warming non”—“this global warming”—

### Conspiracy Advocate (CA)
Claim: Global warming costs—

### Scientific Advocate (SA)
Claim: “This global warming nonsense”—

### Conspiracy Advocate (CA)
Claim: Cost nonsense, very different—

### Scientific Advocate (SA)
Claim: “This global warming nonsense,” I wrote it down, you spoke of CO2—

### Conspiracy Advocate (CA)
Claim: No, global warming costs—

### Scientific Advocate (SA)
Claim: —as a single variable on the market—

### Conspiracy Advocate (CA)
Claim: Yes, absolutely.

### Scientific Advocate (SA)
Claim: Bjorn Lomborg said major carbon cuts will do little to change the temperature and nothing to save the world, this is in fact a denialism— in carbon emissions are not worth the money” (1/13/09)

### Conspiracy Advocate (CA)
Claim: No—

### Scientific Advocate (SA)
Claim: —of the realities—

### Conspiracy Advocate (CA)
Claim: Ab— You see, that is what I absolutely—

### Scientific Advocate (SA)
Claim: You are—

### Conspiracy Advocate (CA)
Claim: —am unhappy with. I—

### Scientific Advocate (SA)
Claim: No, no, you’re—

### Conspiracy Advocate (CA)
Claim: You are telling me I’m denying it—

### Scientific Advocate (SA)
Claim: Boys, boys—

### Conspiracy Advocate (CA)
Claim: I’m not—

### Scientific Advocate (SA)
Claim: —you’re not debating the topic.

### Scientific Advocate (SA)
Claim: No, I agree—

### Scientific Advocate (SA)
Claim: You’re not debating the topic— in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: I agree, I agree—

### Moderator
Claim: I’m gonna go for some more questions—

### Scientific Advocate (SA)
Claim: Which are—

### Moderator
Claim: —because I—we’re in a little bit of a circular loop on this one—

### Scientific Advocate (SA)
Claim: Yeah, I agree.

### Moderator
Claim: An impasse, I would say. Right in the middle, you might need to…would you be comfortable in walking out, thanks. That’s wise, the microphone’s coming in to you. There it is.

### Moderator
Claim: I just wanted to sort of start by saying that we seem to have come round, sort of…intellectual dishonesty and it’s all about economics versus science and so I wanna start out with just saying, I’m an economist and I have a question. Whether this is still about sort of economics or not, and I wanna sort of direct this question to Bjorn Lomborg.

### Conspiracy Advocate (CA)
Claim: Mm-hmm. in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: You stated that the Copenhagen Consensus favored technology, R-and-D investment. However, isn’t it true that the economists that you are so eagerly quoting as the great work that they’ve done, have basically publicly distanced themselves from your interpretation of their work, and I’m talking about Richard Tol and Gary Yohe. So basically, they say that they actually never looked at that, they looked at a climate-mix policy, which would have adaptation, mitigation, and R-and-D technology, which is the point that Oliver Tickell made. Thank you—

### Moderator
Claim: Bjorn, I’m not gonna leave that hanging out there, go right to it.

### Conspiracy Advocate (CA)
Claim: Sure. You’ve unfortunately read half of the discussion because it’s true, that they first made a comment in, in The Guardian and then later on, after we’d had a long discussion on a blog, we actually, Yohe and I wrote a joint column, where we pointed out what it was we said. Yes, Yohe, and to a certain extent Tol, believe that it’s also a good idea that we invest, and remember, it is mainly investing in research and development but also investing in carbon reductions right now. There was another party, Professor Green, who made the argument that we should be investing much more in research and development and then only much later invest in cutting carbon emissions. What came in carbon emissions are not worth the money” (1/13/09) out of the Copenhagen Consensus where we had eight of the world’s top economists, including five Nobel laureates, looking at all that stuff, they said, well, if you look just in carbon reductions which is what we talk about here tonight, that probably pays less than $1 back on the dollar. Whereas if we invest in research and development, it probably does $11 worth of good for every dollar. And that’s the main reason—

### Scientific Advocate (SA)
Claim: But Bjorn, this is a completely false choice—

### Conspiracy Advocate (CA)
Claim: —why we’re making this point—

### Scientific Advocate (SA)
Claim: —this is another one of your false choices, we—there is no choice here, we absolutely need—

### Conspiracy Advocate (CA)
Claim: No, no, that’s, and that—

### Scientific Advocate (SA)
Claim: —to invest in R-and-D in order to achieve these cuts in greenhouse emissions—

### Conspiracy Advocate (CA)
Claim: And this is the brilliant, and very, very good demonstration, that Oliver Tickell can’t see anything that we shouldn’t be spending money on and say let’s spend money on it. I would suggest that we should spend money— in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: I’m agreeing with you, Bjorn, we need to spend that—

### Conspiracy Advocate (CA)
Claim: —on things that give us $11 of good in the world, but we don’t spend a dollar for every time we just get 90 cents back on—

### Conspiracy Advocate (CA)
Claim: In The New Yorker last week—

### Moderator
Claim: Philip Stott.

### Conspiracy Advocate (CA)
Claim: In The New Yorker last week, your own magazine, a very liberal magazine and one I love, very interestingly, there was a fascinating statement, which that, you can’t effectively do dual or multi-instruments politically, to answer say both poverty and climate change, and the—I love the analogy that was given by the professor quoted, it was a very good one. I might wish to save energy and I’ve invited you all round for dinner, be very nice to meet you all for dinner, but in fact, I’m going to cook my pizzas and all the rest of it, in the shower so I’m going to save energy. Of course you’re going to end up with a very, very rotten dinner, and I think this is at the heart of what we’re discussing here, how far do— How far do dual instruments and multi-instruments actually work, and I think, it’s when I do passionately disagree with Oliver on this. Because, let’s be in carbon emissions are not worth the money” (1/13/09) honest, in our own households and everything, we have a given income, we have to make very, very difficult choices. If I know what I would put my choices by the way, very simply, and they would tie in, not because I’m supporting Bjorn particularly on this because they—I came to this decision a long— I am very worried indeed about the whole state of the development of new viruses in the world at the moment, they are all very serious problems. And if you look historically, the single biggest effects that have created deaths amongst humanity, have been the evolution of new viruses, new bacteria, and new forms. And that’s the crucial point. Across the—

### Moderator
Claim: Adam Werbach, are you—

### Scientific Advocate (SA)
Claim: Objection, your honor, irrelevant.

### Moderator
Claim: Yes—

### Conspiracy Advocate (CA)
Claim: No. No, it’s—

### Moderator
Claim: Dr. Lovins, take it—

### Conspiracy Advocate (CA)
Claim: It’s not irrelevant, not irrelevant— in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: Let me go to what you invest and what you get. Little company across the river, Ferrara Construction, put solar panels on the top of its building. It now has a net-zero building. Which means that it is sending back to the grid more energy than it is using. They are selling the energy for about $1.11 per square foot, as opposed to paying two bucks 30 a square foot, which they had previously been doing, to buy their electricity from the grid. Now, spread this across the country, Southern California Edison, recently built a 250-megawatt power plants on roofs, spread around the county, at a price point of $875 million. A coal plant was recently canceled in Montana at a price point of about $800 million. Very close—

### Conspiracy Advocate (CA)
Claim: But Hunter, Hunter, the—

### Scientific Advocate (SA)
Claim: We are very near what’s called, grid parity, where the solar technologies are actually cheaper—

### Conspiracy Advocate (CA)
Claim: But Hunter—

### Scientific Advocate (SA)
Claim: —than generating electricity through coal—

### Moderator
Claim: Bjorn, take this but take it briefly— in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: —which is why I don’t believe the numbers that China is going to build all these coal plants. You know who the world’s first green billionaire is? He’s a Chinese solar entrepreneur.

### Conspiracy Advocate (CA)
Claim: They have just announced that they’re going to increase—

### Conspiracy Advocate (CA)
Claim: Yeah—

### Conspiracy Advocate (CA)
Claim: —they’ve just announced—

### Moderator
Claim: Bjorn—Philip—

### Conspiracy Advocate (CA)
Claim: —their official spokesman—

### Moderator
Claim: —I wanna give Bjorn a chance ‘cause you—

### Conspiracy Advocate (CA)
Claim: Yes—

### Moderator
Claim: —had a—quite a chance so far—

### Conspiracy Advocate (CA)
Claim: Yeah I have, but just, it’s crucial this, that China has just announced a 30 percent increase. They’ve just announced it. in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Hmm.

### Moderator
Claim: Bjorn—

### Scientific Advocate (SA)
Claim: And has just announced—

### Moderator
Claim: —let me—I want Bjorn to speak and then I wanna go to questions—

### Conspiracy Advocate (CA)
Claim: Yes—

### Moderator
Claim: —the gentleman up there, you can be ready—

### Conspiracy Advocate (CA)
Claim: And the bottom line is, if Hunter is right, and everybody makes money off of this, cool, we can all go home, we don’t need to worry about it because it’ll happen.

### Conspiracy Advocate (CA)
Claim: Absolutely—

### Conspiracy Advocate (CA)
Claim: But the real question is— in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: No it won’t because—

### Conspiracy Advocate (CA)
Claim: —we know—

### Scientific Advocate (SA)
Claim: —we invest—

### Conspiracy Advocate (CA)
Claim: No, no, Hunter, please let me—

### Scientific Advocate (SA)
Claim: —240 million dollar—billion dollars a year in subsidies, to the conventional technologies.

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: And that’s what’s getting in the way of unleashing this new energy economy.

### Conspiracy Advocate (CA)
Claim: No. The real point here is to say, are we gonna go further than that, and we know, and this is of course also what you accept, we know that the emissions scenarios expect dramatic increases in CO2, and what you’re saying is, over and above all these great inventions that you describe and everybody else has been talking on the other side of the panel, over and above that, we have to cut dramatically. That’s what costs money. That’s the in carbon emissions are not worth the money” (1/13/09) discussion that we’re having money.

### Moderator
Claim: Gentleman in the middle of the hall, please—

### Conspiracy Advocate (CA)
Claim: Honestly, the real question is, is that worth it—

### Moderator
Claim: Yes, come on out—

### Conspiracy Advocate (CA)
Claim: And my question is still, are we spending trillions of dollars to do virtually no good a hundred years from now, I’m sorry, Oliver, that’s not actually—

### Moderator
Claim: We’re going to a question now with this gentleman—

### Conspiracy Advocate (CA)
Claim: —misrepresenting science.

### Moderator
Claim: Please.

### Moderator
Claim: You know, it’s clear that is a global problem, everybody agrees on that. But impacts and return on investment do matter. So in the face of 3 to 4 percent GDP, I’d like to ask the folks who are arguing against the motion. What in a legal context, or an enforceability stand—from an enforceability standpoint, would you expect that we can actually do about China, India and the in carbon emissions are not worth the money” (1/13/09) developing world.

### Moderator
Claim: Adam Werbach.

### Scientific Advocate (SA)
Claim: Well the first— The first false choice that is placed here, is deciding that China needs to be constrained first, I mean, the greatest challenge and I—Mr. Lomborg and I would agree here, the greatest challenge that’s facing the people of China is that too many of them don’t have enough energy. They need a lot more of it. And we have a moral, a just cause, to make sure that everyone can live on the planet and there’ll be 9 billion of us by 2040, with enough energy to be able to live. So, I actually far expect our carbon emissions to increase—recession-depression notwithstanding, right now, as we try to get those people to energy parity, they live in energy deficit. And our first priority, one of the reasons I believe so much in investing right now, is because we need to create technologies that can make the case. Now, what type of constraints would be put on China, well China obviously is interested in that as well. And China as it begins to invest and succeed as Hunter mentioned in one of their entrepreneurs, in building these sort of renewable technologies, is gonna be very interested in dealing with the air pollution because in Chinese cities they’re very concerned about air pollution right now and they know that comes from coal plants in carbon emissions are not worth the money” (1/13/09) and they’re concerned about dealing with that. So they’re highly motivated to, to reach the point of energy parity, a place where everyone has enough energy, and then to ratchet down both the CO2 emissions, the air particulate matter emissions, and all those sorts of negative consequences that come from it.

### Moderator
Claim: Peter Huber, do you—

### Conspiracy Advocate (CA)
Claim: You know, there is no field of policy you will ever find and I spent 25 years in Washington watching this, where you will find a greater gap between what people actually do, and what they say they’re gonna do, wanna do, should do, oughta do. The EU itself, the people who are most frantic about this and who signed this stuff, they’re not—none of them or possibly one of them will meet their Kyoto commitments. They issued tradable permits, and promptly depressed the value to virtually zero because they issued so many, they were all worried about job-export issues. I mean, you know, you just cannot talk about what people are gonna do for anything. China is, in fact, building coal plants like crazy. Okay? They say they’re gonna build more but I couldn’t care less what they say. They are actually doing it. They are the world’s biggest emitter today. How can you ignore the world’s biggest emitter? in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: Well, but I mean, there’s a few things

### Moderator
Claim: I’ll let you go.

### Scientific Advocate (SA)
Claim: And surely one key thing is that a very large part of this coal that’s being burnt in China is actually producing products for export to America and to the European countries.

### Conspiracy Advocate (CA)
Claim: And so you’ll tax our plants but not theirs, right?

### Scientific Advocate (SA)
Claim: And it’s important to recognize that. Another thing, let’s look at what China is actually doing. China is investing hugely in renewables. China has already got the world’s biggest solar tank industries. China is investing hugely in wind turbines. They are building more and more of the world’s turbines and bringing the cost of turbines down. And yes, they may indeed be mining more coal but much of that is surely displacing imports-- and from Indonesia and Australia.

### Moderator
Claim: Philip Stott, Philip Stott.

### Conspiracy Advocate (CA)
Claim: Well, I don't want to talk about – Let me just mention briefly in carbon emissions are not worth the money” (1/13/09) Europe. An absolute failure under the Kyoto Protocol. Talks a lot, have not

### Scientific Advocate (SA)
Claim: We’re not debating Kyoto.

### Conspiracy Advocate (CA)
Claim: No. What we’re debating is the effectiveness of major cost. Europe –

### Conspiracy Advocate (CA)
Claim: ...has failed utterly, for economic and political reasons, to cut. Some of the figures-- from Spain, from Italy, from Ireland-- are just mind blowing. And this is what I just, we’re in a cloud, cuckoo land here. And let me just make a point about this. We’re worried about China, yet worry about the E.U. now on this. Half the E.U. now is opposing the E.U.’s policy on cutting carbon. Listen to the Czech President, for example. That’s Vaclav Klaus, who is the current President of the E.U. Why do you think the recent E.U. policies have collapsed virtually? Don’t think Europe, don’t think it’s just China or India. Don’t take the, what Europe says. Europe talks but it’s not walking the walk.

### Moderator
Claim: So under in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: Hunter, Hunter Lovins, please. Hunter Lovins against the motion.

### Scientific Advocate (SA)
Claim: You know what’s gonna get China to cut its carbon emissions? It’s not gonna be you and me and it’s not gonna be the government. It’s gonna be Wal-Mart, which recently said to its Chinese suppliers, You will report your carbon footprint through a little group called The Carbon Disclosure Project. Who are they? It’s a little group, a little non-profit out of the U.K. that a few years back sent out a survey to The Financial Times 500-- the five hundred biggest companies on earth – saying, What’s your carbon footprint? And for a couple of years everybody ignored it, until three years ago, when sixty percent of the world’s largest companies answered the survey. Last year it was seventy- seven percent. Why? They represent institutional investors with over forty-one trillion dollars in assets. You’re gonna go to the capital marketplace, you better answer their survey. And under Sarbanes-Oxley, the new U.S. corporate ethics law, if as a manager you fail to disclose to shareholders information that can materially affect the value of stock, you can be personally criminally liable. What’s your carbon footprint? Watch China’s emissions start to come down – in carbon emissions are not worth the money” (1/13/09)

### Scientific Advocate (SA)
Claim: ...simply because that’s the way the best companies are doing business now.

### Conspiracy Advocate (CA)
Claim: Well, I love the way you think that Wal-Mart is actually gonna go and say, Oh, they produce a lot of carbon. Let’s call--let’s buy stuff that costs a lot more from someone who don’t produce as much carbon. Obviously, Wal-Mart can do that but I don’t think they’ll stay in business. Let me also just point out two things. I thought it was very rare to see that Adam was actually – I’m not sure to what extent it was conscious, but he was actually agreeing with us, which is really nice. You should come over here. He was basically saying, China is going to go and emit much, much more. Then they’re gonna be careful and they care a lot about air pollution. And that’s absolutely true.

Then he sort of slipped in, and they’re gonna cut carbon emissions. Uh, no, of course not. They’re gonna put scrubbers on their coal plants, which is really smart. But they’re not gonna care about their carbon emissions for a long term. And I would just like, the last point also – do you remember how Hunter told in carbon emissions are not worth the money” (1/13/09) us about the first Chinese billionaire is a guy who produces solar panels? Do you know who he sells those solar panels to? He sells them to Germany. They’ve actually bought a hundred and fifty-six billion dollars worth of solar panels. Do you know how much good that’s gonna do? By the end of this century that will postpone global warming by one hour.

### Scientific Advocate (SA)
Claim: No, this is complete rubbish.

### Conspiracy Advocate (CA)
Claim: I’m simply asking you, is that the way we want to help the world?

### Scientific Advocate (SA)
Claim: This is complete rubbish.

### Moderator
Claim: I’m going to go a question here

### Scientific Advocate (SA)
Claim: This is complete rubbish because Germany has been doing the most enormous favor to the world by buying these panels, by –

### Conspiracy Advocate (CA)
Claim: No.

### Scientific Advocate (SA)
Claim: ...getting them into mass production and by in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: Let him finish.

### Scientific Advocate (SA)
Claim: ...for everybody.

### Moderator
Claim: Question from the rear, please.

### Conspiracy Advocate (CA)
Claim: Germany has the biggest brown coal plants in the world.

### Moderator
Claim: Philip.

### Conspiracy Advocate (CA)
Claim: They’re the single most polluting coal plants.

### Moderator
Claim: Philip, I want to move on. Question from the rear, please.

### Moderator
Claim: To my ear those against the motion are not being, are not confronting the choices that are necessary. And, uh, and it’s been sort of a flagrantly anecdotal presentation. And I would in carbon emissions are not worth the money” (1/13/09) suppose that, first of all, I want to say that, um, Hunter, Hunter actually said, whether she realizes it or not, during her presentation, the initial presentation, that there were, it, that the, what they have in mind would require neither major chances in taxation or major changes in regulation. Now, if, if that’s it then why are we having the debate and let’s go on.

### Moderator
Claim: Is that your question?

### Moderator
Claim: I don’t think that’s – My question is, for anyone on that side, to honestly address the real tradeoffs that we’re talking about, if we’re talking about one or two or three percent of gross, gross international product or whatever the other major changes are. If there aren’t major tradeoffs then we shouldn’t be having the debate and I think they’ve been denying the tradeoffs all throughout the debate.

### Moderator
Claim: Oliver Tickell, please.

### Scientific Advocate (SA)
Claim: All you folks are agreed that there are tradeoffs and that there are some aspects of moving to a low carbon economy which actually produce a net gain. Your negative costs are low hanging fruit, but there are other areas where there are real costs – at least in the short term. The important thing is that as you in carbon emissions are not worth the money” (1/13/09) progress from the short term through to the medium term you find that the investments that you’re making in renewable energy technology, for example, and in mass production, developing the engineering expertise to bring costs down-- that actually over the medium term, these shift from being a cost to being a benefit. And the nature of that benefit is a lot more than just the carbon. There are many, many benefits, such as air pollution. What is the world’s biggest source of arsenic and mercury in the environment? It is burning coal.

What do you say to all, to the absolutely disgusting images that we see of mountaintop removal in Appalachia in order to reach coal seams? What do you think of the wars that are being waged in the Middle East where the thirst for fossil fuels and oil fundamentally underlies them? There are many benefits in moving away from that kind of world into a world which is actually characterized by cooperation on energy because if we move large scale to renewable energy it requires cooperation among countries with different kinds of intermittent renewables balancing out supplies over long distance grids. And that will actually fundamentally change the whole way in which countries interact with each other. It’ll produce not just a greener world, a cleaner world, but actually a safer world and a happier world. And these are values surely worth aspiring to. in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: Bjorn Lomborg.

### Scientific Advocate (SA)
Claim: Since I was –

### Conspiracy Advocate (CA)
Claim: The basic problem – Sorry.

### Scientific Advocate (SA)
Claim: Since I was directly attacked, can I have a bite at that one?

### Moderator
Claim: Yes, because –

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: ...you were directly attacked. And then Bjorn. And I’d like, in the meantime, to move the camera to the side because I’m going to take a question from the woman in the blue sweater.

### Scientific Advocate (SA)
Claim: Other tradeoffs – not if we do it intelligently. Markets work. Let’s use them. Study after study after study after study has shown that we can meet the needs of a world population of nine billion, meet the energy needs with efficiency and renewables. The Paley Commission of the U.S. government in the 1950s then urged an immediate in carbon emissions are not worth the money” (1/13/09) transition to energy efficiency in renewables as a matter of urgent national security. Had we done it then we would not be having this debate now because we would not be burning carbon. Can, how do we do it? Yeah, that definitely takes some exquisite economics, planning. I’m not a big fan of Kyoto and I am on record betting the Danish Energy Minister a bottle of whiskey that COP 15 will fail, that the effort by the world to come up with a Where-do-we-go-from-Kyoto? will fail. And then I think we’ll have the real debate, which is, How do we use the enormous power of markets to unleash innovation around the world to enable the poor people to meet their own energy needs with their own resources, their own intelligence and to enable us to have the prosperity that, again, study after study after study has shown that we can have, if we invest now in the smartest technologies.

### Moderator
Claim: Bjorn Lomborg.

### Scientific Advocate (SA)
Claim: Let’s go.

### Moderator
Claim: Bjorn Lomborg.

### Conspiracy Advocate (CA)
Claim: I find it a little bizarre to refer to a study in the 1950s that show that we could actually have done this cheaply but we in carbon emissions are not worth the money” (1/13/09) just failed to do so. Maybe that’s because it’s very, very hard and actually very costly. And that is, unfortunately-- I’m sorry, Hunter – what all the global cost benefit in...analyses show. But let me just point out to Oliver – because he very eloquently put how we should invest in all this and this is a great deal. Notice what Germany has done. It’s spent a hundred and fifty-six billion dollars on buying very inefficient solar technology. The thing I don’t understand is why didn’t they just invest one/tenth of that in actually making solar panels much better? That would have really made a difference and that would have made it easier for the Chinese and everybody else to get solar panels cheaper, faster.

### Conspiracy Advocate (CA)
Claim: And the other thing I want to point out is just, it’s terrible –

### Conspiracy Advocate (CA)
Claim: Let, let me just finish.

### Scientific Advocate (SA)
Claim: in carbon emissions are not worth the money” (1/13/09)

### Conspiracy Advocate (CA)
Claim: The other thing is that it’s terrible to say this is gonna help--

### Moderator
Claim: Bjorn, Bjorn and Oliver – when you’re speaking simultaneously no one can hear you.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: You had a shot at it. Let Oliver respond.

### Scientific Advocate (SA)
Claim: Yeah, Bjorn, you just asked me a question and I have an answer, which is that that’s what private investors are doing. This is what the solar power companies are doing because they see here is the demand from Germany. And therefore, they are investing. This is private investment. This is companies –

### Conspiracy Advocate (CA)
Claim: No, the – And –

### Scientific Advocate (SA)
Claim: --that are investing because they see a market. And that is why The New York Times reported today that the cost of solar panels is falling dramatically.

### Conspiracy Advocate (CA)
Claim: No, no. The International Energy Agency has actually shown that the investment in renewables have gone in carbon emissions are not worth the money” (1/13/09) down, not up, globally. And I’m sorry, that’s because we are so focused on cutting carbon emissions that everybody worries about how we can get through the next five years, not how we’re gonna get through the next fifty

### Scientific Advocate (SA)
Claim: Investment in everything has collapsed. It’s called the credit crunch, Bjorn.

### Moderator
Claim: Oliver, please. Question from the front left.

### Moderator
Claim: Yeah. made the point that he’s in favor of research and development for low carbon technologies. And you’ve just made a couple of, of comparisons of tradeoffs between what might be worth it and what else might not be worth it. So it seems to me that we’re not necessarily debating whether reducing carbon is worth is but really how much it’s worth. So my question for the whole, for your panel is, Where do you draw the line between major reductions that for you are not worth it and what is worth it?

### Moderator
Claim: Peter Huber.

### Conspiracy Advocate (CA)
Claim: Well, let me start by saying this: There is a very big difference between saying we ought to keep studying something and saying in carbon emissions are not worth the money” (1/13/09) we ought to put in place forcible mechanisms today that will force people to adopt technology today. All right? Because, you know, you can talk all you like about solar. The price point you’ve gotta beat is three cent coal. If you don’t beat three cent coal you’re not there. It is of no interest that you can beat, it’s of no interest that you can beat fourteen cent gas, okay?, or, it’s –

### Scientific Advocate (SA)
Claim: Excuse me, Peter, the coal industry itself says that new coal plants will cost thirteen or fifteen cents.

### Conspiracy Advocate (CA)
Claim: Well, the, the old ones – and not in China they don’t. Believe me, okay? The marginal cost of coal generation is miniscule and that’s your price point. Now, researching to see if you can beat it someday – I like that. I’m a techno utopian. Anybody who reads anything I say, I love technology. I’ve, in my book I say, Someday we’ll get there. But, you know, telling people today, You go ram it into twenty percent of the country – I don’t want to repeat myself. We will move these same industries over to China, as in fact it was just being suggested a moment ago, and they will make the products instead and make them dirtier. We will increase carbon emissions that way.

### Moderator
Claim: in carbon emissions are not worth the money” (1/13/09)

### Conspiracy Advocate (CA)
Claim: If we keep it at home at least we’ll have the scrubbers on the darn coal plants, even if we’re not taking the carbon out yet.

### Moderator
Claim: We have time for one more question. Gentleman, young man, yes. Can you stand so that they know that I’m speaking to you? Thank you. And a mic will travel to you.

### Moderator
Claim: Um, hi. I have one very brief question and then another thing that I kinda want to, I’ll see if I can lump them in. One thing that hasn’t been addressed yet at all is peak oil. And I just want to kind of get that out there and see what some general reactions are. I know we’re planning on approaching that, at least within the next century – probably more likely within the next forty or fifty years. And that’s going to obviously affect our economy and the demand and supply that we have right now.

### Moderator
Claim: And for people who don’t know what peak oil refers to--

### Moderator
Claim: Peak oil is when we’ve hit, we’ve used up half of the world’s oil supply and beyond that the rate of production slows in carbon emissions are not worth the money” (1/13/09) dramatically. It kind of falls off on a bell curve. And then also, I wanted to, I, I know this twenty/eighty has been brought up a lot, this percentage that, that’s mentioned – the Kyoto Protocol. And for me, I just kind of wonder how long are we going to keep using, uh, that as an excuse to not lead the way for developing countries, once they are developed and they’re looking to us for the next step and the only thing that we have to say is, Look back at other developing countries and stand still?

### Conspiracy Advocate (CA)
Claim: But, could I take a first, could I take a crack at peak oil?

### Moderator
Claim: Actually, I would like to go to Philip Stott. Sorry.

### Conspiracy Advocate (CA)
Claim: It’s a very fine question. Thank you for the peak oil question. Because, of course, we’re obsessed with oil, but of course, there's gas and above all, as Peter has emphasized, coal. And it all depends on price again. Just remember how the dreaded state, the apartheid state of South Africa, actually survived the European, um, uh, embargoes, for example. It was, of course, by turning coal into oil. And there are vast coal reserves. When we, we’re obsessed with the oil, but in fact, you have to take the whole of, of, of the group before you even question that. So look at the whole package, not just oil. in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: Yeah, Hunter.

### Scientific Advocate (SA)
Claim: If China had continued to grow economically at the rate that it was – and this recent collapse has affected China as well – by 2030 it would have wanted more oil than the world now lifts or probably can ever lift. Obviously, at that point the future is not possible. The International Energy Agency says, Expect serious constraints on the supply of oil within two years. The Germans think a year. Matt Simmons, the Houston oil banker, says we’ve already hit peak oil. And what has held it up, what held up the run-up in prices is the economic collapse. It really doesn’t matter. The investments that you would want to make if you were scared to death about peak oil are exactly the same investments you’d want to make if you simply want to make money, i.e., energy efficiency, and then renewable energy. So I think peak oil falls into the same problem as climate change. Yeah, it’s worth doing something about it because we can make money that way.

### Moderator
Claim: Bjorn Lomborg.

### Conspiracy Advocate (CA)
Claim: Again, we need to get a sense of proportion. A lot of people are trying to sell you, Oh, we can move to renewables. We can do a in carbon emissions are not worth the money” (1/13/09) lot of great things. Let’s just remember that the International Energy Agency, as you just mentioned, estimate that right now we use about half of one percent of our energy comes from real renewables like wind and solar and geo-thermal. If we don’t do anything by 2030 it’ll be up to one point seven percent. But if we really strive, if we really do everything that all those people, over here on this side wants us to do we might be able to – the International Energy Agency estimates – to squeeze it up to two point eight percent. I’m sorry, that’s just not gonna make a big difference in this world. And that’s, of course, the real crucial point.

### Scientific Advocate (SA)
Claim: Neither are those numbers correct. Bjorn...

### Conspiracy Advocate (CA)
Claim: But the point is...

### Scientific Advocate (SA)
Claim: ...we can meet, the U.S. National Energy Lab showed, by 2025 we could be meeting at least a quarter of U.S. energy through renewables if we simply made the intelligent investments.

### Conspiracy Advocate (CA)
Claim: But there was a report in 1950 that said we could do it now. I mean, how can you keep on making these sorts of comparisons? in carbon emissions are not worth the money” (1/13/09)

### Conspiracy Advocate (CA)
Claim: If you included nuclear in renewables the figures change.

### Scientific Advocate (SA)
Claim: Hey, I like nuclear. I really do.

### Conspiracy Advocate (CA)
Claim: There’s a lot of – Yes, you do. And a lot of environmentalists don’t.

### Scientific Advocate (SA)
Claim: Remotely sited, ninety-three million miles away will do just fine.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: The only way Britain will make its is very, very simple, as all the governments have known – and Tony Blair knew extremely well – is that if we do not have a new generation of nuclear there’s absolutely no way we shall meet anything like a renewable target.

## Round 3

### Moderator
Claim: This concludes round two of the debate. Thank you for all of your questions and thank you to our panel for quite seriously rising to the occasion. In a moment we’re going to do two things. Each panelist will have two minutes to make in carbon emissions are not worth the money” (1/13/09) summary remarks. I will tell them if their time is up. When their time is up, if they run over, and right after that we will be polling you to determine the winner of this debate. And I want to remind you once again of the results we received when we polled you coming in off of the street. The motion is: That major reductions in carbon omissions are not worth the money. Coming in off the streets, in your response to that, sixteen percent of you were in support of that motion, forty-nine percent of you were against the motion and thirty-five percent of you were undecided. We’ll poll you again right after the closing remarks, which will be quite brief. And we’ll begin summing up against the motion. Oliver Tickell, journalist and author of the Kyoto2 climate initiative. Oliver Tickell.

### Scientific Advocate (SA)
Claim: Someone asked the question, How far should we go? And you know, at what point have we made sufficient cuts in greenhouse gas emissions? And there is, in fact, quite a clear answer to that. What we’ve gotta do, Philip Stott is quite right when he says, We can’t stop climate change. What we’ve gotta do is to stop the runaway greenhouse effect in which positive feedback processes in the climate system lead to an inexorable extreme warming process, turning this planet into a very different place, a hothouse earth – one in which the limiting factor on humans isn’t so much whether we can survive the temperatures. in carbon emissions are not worth the money” (1/13/09) It’s whether the climate system can survive these temperatures. It’s whether ice caps can survive these temperatures. And the bottom line actually came from Jim Hanson of NASA, of Columbia University, just up the road – and that is, three fifty parts per million. If we manage to have long term stabilization at three hundred and fifty parts per million of CO2 accompanied by major reductions in other greenhouse gases, we actually have a chance of preventing that runaway greenhouse effect. Now, I think it’s worth spending almost any amount of money to stop that from happening. The fantastic news is we don’t have to. Actually, the costs are really quite modest in the context of the global economy and they bring benefits, which are greater, considerably greater than what we spend. And it’s spread over a far wider area than simply economic benefits. They bring quality of life benefits, ecological benefits, benefits in food security, benefits in bio-diversity. And so to come back to the point of this – is it worth making these investments in order to bring about major cuts in carbon dioxide, in the emissions? The answer is, yes, it is. And I’m very happy to know that this is actually on the verge of taking place here in the United States under the new President, Obama.

### Moderator
Claim: Oliver Tickell, thank you very much. Making, in carbon emissions are not worth the money” (1/13/09) making his summary remarks for the motion – Bjorn Lomborg, founder of the Copenhagen Consensus.

### Conspiracy Advocate (CA)
Claim: Thank you. It’s a little depressing to see that I started out telling you that we were gonna hear two arguments. And indeed we have heard them. One is that this is gonna be the end of the world and therefore we need to do whatever Oliver says. I’m not really sure that’s such a great argument. I would simply say we know from the U.N. Climate Panel that global warming will cause problems but it will not by any means be the end of the world. It is one of the many problems we need to tackle and that’s exactly why we’re having this debate-- exactly asking, Is this worth the money or should we indeed do other things? And that’s, of course, the other slightly sad thing, that it’s a false choice. We can do everything but we don’t. And so my question to you is really very, very simply, How do you want to be remembered? Al Gore actually points this out very well. He says, This is our generational mission. He asks you, How do you want to be remembered by your kids and your grandkids? I find it stunning that he would actually make that argument because the real question is, Do you want to be remembered for having spent hundreds of billions or even trillions of dollars to do virtually no good a hundred years from now? in carbon emissions are not worth the money” (1/13/09) Or do you want to be remembered for actually having solved all the major problems that half of this world’s population suffers-- these medieval, terrible tragedies that we are watching right now? This is really about how you want to be remembered. And I hope you want to be remembered by doing a lot of good rather than just a little bit. That’s what tonight’s decision is about. That’s the tradeoff. Thank you.

### Moderator
Claim: Thank you, Bjorn Lomborg. Arguing, summing – and Adam, can you see the clock? I just want to make sure that it’s obvious to you. Summing up against the motion, Adam Werbach, global CEO of Saatchi and Saatchi S.

### Scientific Advocate (SA)
Claim: John Muir, the founder of the Sierra Club – he founded it in 1892 – said that when you pick anything up by itself you find it hitched to everything else in the universe. And that hitchedness is what I refuse to let go. Mr. Lomborg, others say it’s a choice, that we can either create green jobs, that we can launch a new Apollo project, that we can’t do that and deal with poverty, global poverty, at the same time. In fact, we have to. And when you ask the question, How do you want to be remembered? – I don’t want to be remembered as a person who, to my three kids, as the one who saw a crisis facing us and who ignored it. We can do something about this. Mr. Stott says that, glibly, that people can in carbon emissions are not worth the money” (1/13/09) live in the Sahara, they can live to, in Greenland. It makes it sound like you just need to put shorts on and that will deal with climate change. It is more serious than that. Mr. Huber describes himself as a technical utopian, but doesn’t want a system to regulate that technology in the end and to guarantee the marketplace for that.

And that sounds to me quite familiar to marketing subprime loans but not having a strong enforcement mechanism, not having an SEC that could actually maintain the investment structures here in the United States. More reductions in carbon emissions are worth the money. And many of the anecdotes we shared tonight are examples of how they are worth the money. And the reason we used anecdotes is because we actually have examples of how it’s actually happening. Now, you can deny that. You can say those act...those aren’t real, and those don’t add up. Or you can actually look at them. And there is a reason why the world’s largest company went to China and told its thousand largest suppliers that it will pay more money if it has to build better products. They want quality socks, not socks that fall down. And those quality socks probably have less energy in them as well. Major reductions in carbon are worth the money. We’re not going to do unintelligent things. We’re going to spend it right. in carbon emissions are not worth the money” (1/13/09)

### Moderator
Claim: Thank you, Adam Werbach. Reminding you that the motion is: Major reductions in carbon emissions are not worth the money, and making his final summary for the motion – Peter Huber, author of The Bottomless Well and a columnist for Forbes.

### Conspiracy Advocate (CA)
Claim: Well, and now I am done, I am going to get personal and nasty. And I’m going to talk to you over there, and you. Yeah, you know who you are – and also you. And like a medieval priest, you know, there are carbon brokers out there today who will sell you an indulgence that will forgive all your carbon sins. It will run you about five hundred dollars for five tons of carbon, which is about what the typical American needs – or about two thousand dollars per typical household. Your broker will spend the money on something good – most likely cleaning up hog farms in Brazil. But if you really want to make a difference, you must send a check large enough to forgive four Brazilian households, too, because they can’t afford that. So to cover all five households – the rich one and the four poor – make it four thousand dollars. And you probably forgot to send a check last year and who knows?, some of you might even forget it for the next eight years. Let’s cover all the sins, you know, one backed, this year’s and in carbon emissions are not worth the money” (1/13/09) eight in advance. You’ll feel so much better if you’ve already paid for these future sins. Let’s make it ten years, forty thousand dollars. Now, if you honestly believe that substantial reductions in carbon emissions are worth the money, you will, sadly, vote against the proposition. But then you must, you absolutely must, scurry right back home and send your check in because if you don’t you will have burdened your already sooty soul with an extra five tons of self- righteous hypocrisy. And you can’t possibly, you can’t possibly afford what it will take to forgive that. Your other-- Your other option, your other option is to keep your money in the pocket and vote for the proposition. However desperately you may wish it were false, vote for because it is, in fact, a true statement of engineering and economic and geo-political fact. And vote “for” because acknowledging reality is the essential first step in trying to change anything for the better.

### Moderator
Claim: Thank you, Peter Huber. And with her two minutes to sum up, against the motion, Hunter Lovins, President and founder of Natural Capitalism Solutions.

### Scientific Advocate (SA)
Claim: Boys, you’ve done a pretty good job of arguing what is essentially an untenable proposition. Why is it in carbon emissions are not worth the money” (1/13/09) untenable? Because the numbers are in. Goldman Sachs, July two years ago, showed that the companies that are leading the way in cutting their emissions, in implementing energy efficiency have twenty-five percent higher stock value than their competitors. The Economist Intelligence Unit, last February – the companies that are leading in this have the highest, fastest growing stock value and, conversely, the worst performing companies in the economy are most likely to have nobody in charge of these issues. Deutsche Asset Management, Dr. Bruce Kahn: This is a historic opportunity for the administration to take a global leadership position in energy while addressing the current economic and financial crisis. He calls for a green national infrastructure bank investing in energy efficiency and renewables.

He said, Spend on the green sweet spot-- efficiency in buildings, the new electric grid, renewables and public tranist. He said, Credible scientific debate is over. As more dynamic models of climate change are developed, we expect to see estimates of the danger of global warming increasing. This is the business community, folks. This is simply a better way of doing business. Now, you hold in your hands the future. You can choose to vote for the finest thinking of the Twentieth Century or you can vote for the future. You can vote to unleash this new energy in carbon emissions are not worth the money” (1/13/09) prosperity. It matters what you vote now. We have argued – and I think we’ve proven-- that cutting carbon is worth the money. We have not tried to argue that these investments will solve everything. We have also argued – I have – that these are the investments that will deliver genuine development to the rest of the world. So if you care about Bjorn’s position you will invest in these low carbon technologies.

### Moderator
Claim: Thank you, Hunter Lovins. And finally, summing up for the motion, Philip Stott, Emeritus Professor and Bio- Geographer from the University of London.

### Conspiracy Advocate (CA)
Claim: Adam quoted a very great American. I’d like also to relate to a northeastern great American – in fact, the very founder of the American ecological movement – George Perkins Marsh of Vermont, who wrote Men and Nature in 1864, one of the greatest books ever written. And Professor David Lowenthal, also a great American author of the day, wrote something about him, which is extremely important for us to hear in the case of this debate. Environmental reformers who find nature’s inarticulate indifference unbearable impute their own aims to nature and then purport to speak on nature’s behalf. A rarified natural world is then worshiped as virtuous. And Marsh himself said, The equation of animal and vegetable life is too complicated a in carbon emissions are not worth the money” (1/13/09) problem for human intelligence to solve. I think there was a mighty humility in Marsh’s view of nature, which actually we’ve forgotten today, which is vital. ‘Cause what I am interested in is outcomes. Will it work? Remember the motion is major cuts. I’m really serious about this. We agree on the influence that climate change will have impacts on people. Of course it will. But what is really in the end going to work? It’s got to work. That’s why Peter’s realism is absolutely essential to all this. And back to Johnson to end. He said, Why, sir, most schemes of political improvement are very laughable things, he said – which I think is an important way of always looking at it. But finally, the limits of all that we’re doing here – also Johnson. How small of all that human hearts endure that part which laws or kings or senates or congresses – I’ve added those-- can cause or cure. In the end we want to solve this because we think it’s us. I’m afraid it’s nature, greater than us, and we can’t in the end manage it as we wish we would. Thank you.

### Moderator
Claim: Thank you, Philip Stott. And as their job is now done, I’d like to show some appreciation for our, our entire panel. And it’s clear, given, I would say, the unusual level of passion that we heard in this debate tonight, that these panelists very, very seriously are vying for your votes and want to win. And now comes the moment when you decide. in carbon emissions are not worth the money” (1/13/09) I want to remind you that before the debate sixteen percent were for the motion that: Major reductions in carbon emissions are not worth the money. Forty-nine were against, thirty-five percent were undecided. Please pick up your key pads. It’s time to vote again. If you support the motion, press number one. If you are against the motion, press number two. If you remain or became undecided, press number three. Does anybody need more time? Everybody’s good? Cause we’re gonna lock out the system. And we’ll have the results up to me in just a moment. In the meantime, I want to tell you while the vote is being tallied that our next debate will be back at the Caspary Auditorium at the Rockefeller University. That’s on the east side, if you don’t know. The motion to be debated on Tuesday, February 3rd, is this: The art market is less ethical than the stock market. Panelists for the motion are Richard Feigin, Michael Hugh Williams and Adam Lindemann. Against the motion we have Amy Cappellazzo, Chuck Close and Jerry Saltz. I hope that I’ll see many of you in a few weeks at the Caspary Auditorium. And how close are we to having the paper come up? Do you know, Joe? Bob? Okay, it’s on its way. This can be a very brief talk amongst yourselves moment. in carbon emissions are not worth the money” (1/13/09) And remember, the way that we measure victory in this is not where the room sits at the end but the dynamic of how the room moved. And so those undecided votes are critically important. Here we go. Well, it’s very interesting. Here are the final results from your poll on our motion that: Major reductions in carbon emissions are not worth the money. Before the debate sixteen percent of you were for the motion, forty-nine percent against and thirty-five percent were undecided. After the debate, forty-two percent of you are for the motion, forty-eight percent are against and ten percent are undecided. The side for the motion has moved more people, changed more minds. Congratulations to them. And thank you, debaters. And to the Rosenkranz Foundation and to you for joining us, wherever you are watching in the world. For more information on Intelligence Squared and Intelligence Squared U.S., visit our websites. It’s goodbye from me, John Donvan, and everyone here at Symphony Space in New York. Thank you.
