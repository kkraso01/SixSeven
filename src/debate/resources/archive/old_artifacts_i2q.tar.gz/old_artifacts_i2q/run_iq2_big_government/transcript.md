# Debate Transcript

Topic: Big Government Is Stifling The American Spirit
Motion: Big Government Is Stifling The American Spirit

Debate ID: big-government


## Round 1

### Moderator
Claim: And to introduce the gentleman who makes Intelligence Squared U.S. possible, Mr. Robert Rosenkranz.

### Moderator
Claim: Thank you very much, and welcome. It’s my role in these proceedings to frame the debate, and when we think about the language of tonight’s debate, we think of the American spirit as a pragmatic can-do optimism, the conviction that the future will be better than the past and that we have the power as individuals to create that future. Well, we don’t see that spirit shining very brightly in America today. University graduates are struggling to find jobs. Unemployed mid-career executives are accepting pay cuts, if they can get jobs at all. Corporate profits are at high levels, but very few companies can expect much growth. Investors are adjusting to sharply diminished returns from bonds and equities and hedge funds. Consumers are in no mood to spend. Instead, they are struggling to save, to offset the effects of declining real estate and stock market values.

Well, to what extent is this the fault of big government? If you’re in the finance sector, or part of the energy complex, or involved in healthcare or pharmaceuticals, it’s hard to think that big government is your friend. These sectors, by the way, account for more than half of all corporate profits. They are dealing with higher capital requirements, costly and intrusive regulation, restrictions on profit margins, and other new impediments to growth. If you create jobs for others you will almost surely fit President Obama’s definition of the rich, and if you are rich you are facing substantially higher federal and state income taxes, new healthcare taxes as well, not to mention a barrage of hostile rhetoric from Washington.

So, what is the counterargument? It’s that free market capitalism was on the verge of collapse when Barack Obama took office. Major financial institutions were on the edge of insolvency. The auto industry was close to bankruptcy. Economic output was in freefall. We didn’t have pessimism-- we had panic. Only big government could have restored confidence in these circumstances, and indeed it succeeded in pulling us back from the abyss. It did so by making money cheap and abundant, which restored order to stock and bond markets. It provided fiscal stimulus to maintain demand for goods and services. It kept the auto industry out of bankruptcy, saving hundreds of thousands of jobs. And it stabilized our financial institutions by requiring them to hold more capital and take less risk. There may well be a long-term price to pay for all of this, but when your house is on fire, the long run doesn’t matter.

You need to put the fire out and only big government could have done it. These two viewpoints are central to a deep political divide in America today. Which one has greater merit? We have some truly extraordinary panelists with us this evening to help us decide and it’s now my privilege to turn the evening over to John Donvan, our moderator. Thank you very much.

### Moderator
Claim: Thank you. And I would just like to invite one more round of applause for Robert Rosenkranz. True or false: big government is stifling the American spirit. Well let’s have it out right here and right now. Welcome, everyone, to another debate from Intelligence Squared U.S., a contest of ideas, a verbal joust which only one side can win.

I’m John Donvan of ABC News, welcoming you to the Skirball Center for the Performing Arts at New York University and to hundreds of NPR stations across the nation, as these two teams on either side of me, two teams of two try, to win you over. The motion we are debating: big government is stifling the American spirit. And comprising the team that is arguing for this motion, we have Phil Gramm and Art Laffer. And I’d like to begin by talking to Phil Gramm. You are now a banker but you were long ago a professor of economics and in the time in between, you spent two decades in Congress where your reputation was made as a senator and congressman who was fighting to release the American taxpayer and the American businessman from the shackles-- shackles the word? Shackles of government, you accept that with a nod? And I don’t think many people know this but you know, remember this, but you actually went into congress as a Democrat.

And it was at the time that you supported the Reagan tax cuts in 1981 that your fellow Democrats pushed you off of the House Budget Committee and you switched parties. Was that-- as you think back, was that a traumatic event or was your inner Republican screaming to get out all along?

### Conspiracy Advocate (CA)
Claim: Well, I did more than that. I resigned from Congress and I went back home and I ran again because I’d been elected as a Democrat and even though I’d been rated as the most conservative member of Congress, I wanted people to have a choice as to whether I stayed or not. And I had nine Democratic opponents and I beat all nine.

### Moderator
Claim: Art Laffer, your partner, is the only member of this panel who has an actual entry in an online dictionary. When you look up Laffer Curve, this is Laffer. Made famous in the 1980s as a symbolic representation of the concept that in certain situations, as you lower taxes, government revenue can actually go up.

And Art, the myth or the story about this is that you actually brought this to the Gerald Ford White House. You sat down with two young men named Dick Cheney and Don Rumsfeld and drew it on a napkin. Once and for all, is it true, was there a napkin?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: You bring any napkins tonight?

### Conspiracy Advocate (CA)
Claim: For a price.

### Moderator
Claim: Oh. Your opponents, who are arguing against the motion that big government is stifling the American spirit, I’d like to introduce Laura Tyson, an economist. Your resume has a fair sprinkling of the phrase “first female to,” first female to be dean of the London School of Economics, first female chairman of the President’s Council of Economic Advisors, that was in the Clinton administration. At MIT as a young student, you were the first female to write a 532-page thesis; we do do our research. A 532 page thesis titled Inflation in Yugoslavia in 1962, 1972, an empirical analysis.

### Scientific Advocate (SA)
Claim: Oh dear.

### Moderator
Claim: We all read it.

### Scientific Advocate (SA)
Claim: Yes, absolutely.

### Moderator
Claim: A terrific read but…

### Scientific Advocate (SA)
Claim: Mm-hmm. Fantastic.

### Moderator
Claim: In one sentence, why you’re on this side.

### Scientific Advocate (SA)
Claim: You know, I really do believe that there are paths that are appropriate for governments to carry out and that citizens wish them to carry them out and that we have to worry about doing them well, but we have to do them.

### Moderator
Claim: Thank you very much. And your partner, Nouriel Roubini, who famously predicted the housing bubble and then predicted the crisis that followed it, you were right, fortunately for you.

This is your second debate with us. You previously debated, where you took the side that the financial crisis should be blamed on Washington, not on Wall Street. You won, overwhelmingly, 60 percent. So you are risking your perfect record by being here tonight. Welcome, Nouriel Roubini. And to all of our debaters.

I want to ask you now to go to the keypads at your seats.

We want to know where you stand on this motion. If you agree with our motion, "Big government is stifling the American spirit," press number one. If you disagree, press number two. And if you are undecided, push number three. If you make a mistake on this, just correct your mistake and the system will lock in your last entry, and you can ignore the other numbers. Everybody good. So in this debate you, our live audience, are the judges. By the time the debate has concluded, you will have been asked to vote twice, once before the debate and once again at the end after all of the arguments have been made. And the team that has changed the most minds in the course of the debate shall be declared our winner. Now, we need to take a quick break because we have a slight television problem, and some stage guys are going to come out and make an adjustment, and then we'll move on.

Our motion is "Big government is stifling the American spirit." Onto round one of this Intelligence Squared U.S. debate, opening statements by each side in turn.

They are seven minutes each, and here to make the first argument for the motion, that "Big government is stifling the American spirit," Phil Gramm, a former Senator and Chairman of the Banking Committee, currently Vice Chairman of UBS Investment Bank. Ladies and gentlemen, Phil Gramm.

### Conspiracy Advocate (CA)
Claim: John, thank you very much, and thank you for coming tonight, and Bloomberg, thank you for hosting the debate on the issues. Ideas have consequences, and debating ideas is always important for a free society. Since the Enlightenment it has generally been accepted that limited government is the key to freedom and that freedom is the key to unleashing human potential. Freedom has allowed ordinary people to do extraordinary things, and America is proof that freedom works.

Across time and across nations the countries that were freest have tended to create more jobs, more growth, more opportunity, and more human happiness. Within our own country states that spend less, tax less, and do a better job of providing the rule of law have tended to grow fastest, to create the most jobs, and to have the most end migration where people vote with their feet for less government and more freedom. When economic freedom is imperiled, prosperity wanes. And our argument tonight is pretty simple. Our economic freedom is imperiled. Just two years ago the national debt of our country was 40 percent of our annual production.

Two years later our national debt is 60 percent of annual production and under the current budget that Congress is operating on by the end of the decade our national debt will be 90 cents out of every dollar of goods and services produced annually by America. Interest payments on our national debt will quadruple in the next decade, and even if every assumption of the Obama budget proves valid, within 10 years it will take 40 cents out of every dollar of income taxes collected in America just to pay interest on the federal debt. If the Obama assumptions prove invalid, it could take as much as half of all income taxes collected in America in the year 2020, just to pay interest on the debt.

If this is not a threat to our economic freedom, what is? What could be? This is big government stifling the American spirit. But the crisis is so much greater than these frightening numbers would lead you to believe. If you listen to Washington, this problem is easy to solve. All you’ve got to do is tax rich people. Well rich people already pay more of the taxes than at any time in American history. And the problem is there are just not enough of them. Our problem is if you every penny earned by every person or entity in the top one percent of the tax bracket, you couldn’t deal with our deficit, much less our debt. And it’s not reassuring to look at the fact that with tax rates as high as 70 percent we have never collected more than 19 percent of gross domestic product in taxes in peacetime in American history.

You often hear the discussion about the top one percent as if these were rich people. But the reality is that since 1980, when we lowered marginal tax rates, small and medium size businesses have changed the way they’re taxed from corporate entities to being taxed as individuals. The finance committee has estimated that as much as two-thirds of all the income of all the tax returns filed in the top one percent of income earners comes from partnerships, proprietorships, pass-through structures, and sub-chapter S. In short, from small businesses filing as individuals.

The policy that we’re told will tax John Q. Astor in reality will tax Joe Brown and Son Hardware Store, and here’s the rub: in recoveries, small businesses create two-thirds of the jobs. It is simply not feasible, given where we are in the economic cycle, to be raising taxes on small business. The solution to excess spending is not excess taxes; it’s less spending. If you’re in a hole and you can’t get out, the first thing you need to do is stop digging and stop digging now means stop spending. But if we can’t get our government to stop spending, how are we ever going to get them to reduce spending, to reform entitlements, to address Social Security, to address Medicare, to address Medicaid?

Well let me suggest that we not give up on America and that we not give up our own confidence in the system. It’s important to remember that we overcame 10 percent unemployment, double-digit inflation, double-digit interest rates, economic stagnation, malaise, self-doubt and the Soviet Union in the 1980s under Ronald Reagan. It seems like an eternity ago but remember, a Republican congress worked with Bill Clinton to reform welfare and to balance the budget and to put America to work.

We did it once. We can do it again. But we can’t do it with the same old programs and the same old politics as usual. Thank you all very much.

### Moderator
Claim: Thank you, Phil Graham. Our motion is “Big government is stifling the American spirit,” and now to speak first against this motion, Laura Tyson, a professor at Berkeley’s Haas Business School and a member of President Obama’s Economic Recovery Advisory Board.

### Scientific Advocate (SA)
Claim: Thank you, and I’m honored to be part of this debate. And I should say that I was inspired to a world of debate by my son, who’s in the audience, who has devoted much of his college and high school career to debate. So I hope I do a good job as a debater. How big should the government be, is my question.

And I think that depends. It depends upon the tasks and the challenges that government undertakes. It depends upon what its citizens want the government to do. The government in a democracy is us. We cannot blame the government. We have to look to ourselves. And one of the main points I want to make tonight is we don't do it. We refuse to do the arithmetic. We want the government to do a lot, and we don't want the government to pay for it. Now, let me start with the government and the tasks right now, because part of the introduction here was, is the government stifling the American spirit right now? I suggest we be students of history here. The U.S. has just gone through one of the world's largest financial crises in economic history. We know a lot about financial crises across our own economy over time and around the world. And we know that they are the result of a failure, a collapse, a mess created by the private sector, created by overleveraged banks, created by people who take on debt they cannot finance, created by people who engage in sophisticated trading, buy a credit default swap, don't even know what a credit default swap is.

Think I'll buy one; it's an innovation. When you have a major financial crisis and the recession which follows, the government has to help clean up the mess. And we know this over time from the tulip crisis of several hundred years ago to today's financial crisis. And we know-- you know what we know? That when government's clean up the mess, that is stabilize the banking system, that is make sure demand deposits are there when you go to the bank, make sure your money market funds don't fall below a dollar, the government has to supply capital to the financial institutions to do that. The government has to also deal with the slowdown in the economy, the recession, the loss of job, the bankruptcies, the closures of plants.

And that is what economic stimulus is meant to do. And does it work perfectly? No. Does it work? Yes. If you look at what government has done, and you look at the projections of any macro model in the U.S. economy, you will see that the stimulus was projected to produce about 3.5 million jobs. And that's exactly what it has done.

So one thing I will say is that we are dealing right at a moment in time where we have a mess that has to be cleaned up. It's a little bit-- I think of it more broadly as governments have to clean up messes occasionally. For example, let's take Katrina. Let's take Hurricane Katrina. There was a failure to clean up a mess that was a government responsibility to clean up. And by the way, one of the reasons Hurricane Katrina caused so much damage, there was another government failure. The government didn't spend enough on the levees. The American Civil Engineering Society warned, D minus, for U.S. infrastructure on the levees.

We failed to spend. We invited a natural disaster. We failed to clean up the mess.

Second area where the government, I think, has a role to play. Think about the innovative spirit of the United States. Think about technology. Think about higher education. Think about NYU. Think about the University of California. You will see that education, higher education, investments in technology, the things that build America's innovative spirit, these are big parts of what the federal government should and does do. You love social networking? Trace it back to DARPA. You love the latest biotech drug? Trace it back to the National Institute of Health. You like traveling on jet aircraft? Trace it back to the Department of Defense. There are many ways in which the U.S. government has spent over many years to build education infrastructure and technology which play into the spirit of America.

They are part of the innovative spirit of America.

Now, there is a problem. A problem is that the government has, over time, been spending less on that as a share of total government spending. And it's been spending less on that as a share of our economy. Our economy's gotten bigger. Those kinds of government investments have become less important as a share of the economy. Why? What's going on? Well, one-- let's look for a minute at defense, because when we're thinking about the size of government, think about defense in the U.S. The U.S. has 4.3 percent of the world's population and spends 43 percent of global defense spending, 43 percent, almost half of the world's defense spending is spent right here in the U.S. We are defending the U.S. And we're not just defending the U.S. We are defending much of the rest of the world.

We don't hear about that from the critics of the size of government. We need to talk about the government spending almost 20 percent of its total budget on defense, it spending much less on innovation, education, infrastructure, failing infrastructure.

Now, let me just get to a couple facts about the size of government comparatively speaking, because you might say, God, the U.S. government's so big. U.S. government as a share of GDP has really not changed very much in the last 20 years. Actually, I heard the applause for Ronald Reagan, President Reagan. Government spending under his term actually rose to about almost 24.5 percent of GDP. It fell under President Clinton and under President George W. Bush. So, presidents do have different ways of handling this. But the point is the U.S. has been spending in the past 20 years about 20 percent.

The government has not gotten bigger. And by the way, government spending as a share of GDP or government tax revenues as a share of GDP, if you look at the most competitive nations in the world, and you line up the U.S., you will see that the U.S. is one of the most competitive nations in the world. But-- there are many other nations that do as well as the U.S., but they do it with much higher levels of government spending and taxes as a share of their GDP. They're innovative, they have spirit. They're competitive. They're growing rapidly. Their governments are a whole lot bigger.

I see I'm running out of time, so let me say the final thing because I think this is very important to think about. I'll bring this up in my comments. I started with the view that the government is us. The biggest area of growth in the U.S. government is entitlement spending. Entitlement spending is Social Security and Medicare.

You ask Americans if they like it--

Yes. I will say they like it. They don't want to pay for it.

Thank you.

### Moderator
Claim: Laura, time is up.

### Scientific Advocate (SA)
Claim: You ask Americans if they like it--

### Moderator
Claim: I have to cut you off.

### Scientific Advocate (SA)
Claim: Yes. I will say they like it. They don't want to pay for it.

### Moderator
Claim: Thank you very much.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Thank you.

We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan of ABC News. We have four debaters, two teams of two fighting it out over this motion: Big government is stifling the American spirit. You have heard two of the opening statements. Now onto the third. For the motion, “Big government is stifling the American spirit,” Arthur Laffer who is known as the father of supply side economics. He is chairman of Laffer Associates and a former economic advisor to President Reagan. Ladies and gentlemen, Arthur Laffer.

### Conspiracy Advocate (CA)
Claim: The first thing I have to do is lower this microphone a little bit. You're pretty tall, Phil, but-- and in the other sense, I'll keep my comments short, if you know what I mean.

Now, you told me I had to start off with a little light something or other. And I was talking to my granddaughter, Maggie Rembert, about saying something light, and I didn't really know what to say. And she said, "Papa, you can always tell them about the invisible man who married the invisible woman. The kids weren't much to look at either." Let me, if I can-- I'm going to stick with-- sorry. Let me just start with-- I'm going to let Phil's facts speak for themselves. And I agree with them whole-heartedly on the road to prosperity. I want to just say-- and again I want to agree with Laura that it's not partisan. It's not Republican. It's not Democrat. It's not liberal. It's not conservative. It's not left wing, it's not right wing. It's economics. And that's where we really are. And it's really not partisan ideology. It's plain business. And if you look at today's economy - - and I do want to look at today's economy-- when you look at what the government has done and is doing, I think they truly are stifling the American spirit today. It reminds me very much of what happened in the 1930s when you got that, whenever people make decisions-- whenever people make decisions when they're either panicked or drunk the consequences are rarely attractive.

We have had a panic decision here in the United States, and I believe it was wrong. I believe the government intervened dramatically when they should not have. They should have had a brown paper bag and gotten the feelings out of them. They should not have moved. But they did. We had TARP. We had the interventions there, the stimulus packages. They don't work. Now, what Laura is correct about is that they sure worked for the beneficiaries of the stimulus programs. That's true. The transfer recipients were stimulated, and they did spend more. No question about it. But the people from whom the resources were taken, they spent less. And as we all know in economics, and if you go to the Slutsky Equations in an economy, the income effects always sum to zero, bingo.

While the transfer recipients are stimulated, the transfer payers are de-stimulated, and there is no net stimulus from these packages purely. Now, the substitution effects aggregate. And what has happened is we've led the huge deficits, huge tax rates, and output employment production. I mean, let me just take you through quickly what they did in the Great Depression. I mean, 1929, we passed Smoot-Hawley Tariff, the largest tax on traded products in the world. Then in 1930 it was signed into law, you got the crash in the markets. 1932, under a Republican president, they raised the highest marginal tax rate in the U.S., from 25 percent to 63 percent. Now, wasn't that smart? By the way, I'm not mentioning any of the others, inheritance tax, the gift taxes, you know, all these other taxes, excise, et cetera. 1936, under Franklin Delano Roosevelt, a Democrat this time, they raised the highest marginal tax rate from 63 percent to 79 percent and then on up the next year to 81 percent.

You wonder why it was the longest deepest depression in U.S. history, that's why. I mean, they raised the estate tax up to 90 percent. I mean, it's amazing what happened there. What you're seeing today in the United States is an exact pattern following that. When interventionist people get going, you can't stop it, and that is precisely what's happening in the U.S. In part it's because of the agency problem, and the agency problem is very simply that the people in government don't bear the consequences of their own actions. They are not compensated for their success or their failures. They're compensated. It's very different than what happens in the private sector. And that's why you get a misbehavior there. Just on the stimulus, let me just try it, if something doesn't work in a two-person economy, it's not good economics. Take two farmers, that's the whole world. If one of those farmers gets unemployment benefits, guess who pays for it? The other farmer. You know, it is-- there is no tooth fairy in government.

There is no-- you know, there is no Father Christmas working on the Treasury staff. My colleague, Milton Friedman, was correct when he said, "There ain't no such thing as a free lunch." If you look at tax rates on the upper income groups, anyone who looks at these data from the statistics of income, these people know how to get around taxes. If you raise their tax rates, they shift their income, they shift the location of their income, they shift the timing of their income, they shift the volume of their income, and they pay less in taxes. The only group that consistently pays less when you raise their tax rates and more when you lower them are the top one percent of income earners. That is literally what happens. Again, just to finish my comments, and I'm going to finish my comments early if I can, John, but I don't want to go way over your head on this, but if you tax people who work and you pay people who don't, do I need to say the next sentence to you? Help me, if you tax rich people, and you give the money to poor people, you're going to get lots and lots of poor people and no rich people.

The dream in America has always been to make the poor rich, not to make the rich-- the rich poor. I mean, if I can quote John F. Kennedy here, and I'm a Kennedy Democrat from the '60s, I've worked with Democrats as much or more-- I mean, I started with Phil Gramm, can you believe that? When he was a Democrat. But, you know, Kennedy put it beautifully when he said, "The best form of welfare is still a good high paying job." I mean, Benjamin Hooks I thought did it wonderfully when he said that “Blacks are hired last, and they're fired first. The only way we're ever going to get jobs and keep them is there's so darn many jobs around they got to hire us." I want to tell you very seriously, there is only one solution to the economic problem that we're facing, that's economic growth, and to get that economic growth you've got to realign incentives both in government and in the private sector to make sure that you produce the way you should in this country.

And with that I'd like to say thank you to the groups that are putting on this debate. You guys are all wonderful. Thank you.

### Moderator
Claim: Our motion is "Big government is stifling the America spirit," and finally our last opening statement against the motion comes from Nouriel Roubini, a professor at New York University's Stern School of Business, and Chairman of Roubini Global Economics, nicknamed "Dr. Doom."

### Scientific Advocate (SA)
Claim: Good evening, everyone. It's great being here on this NYU stage. I'm a professor at NYU, so great being here at home. Is big government stifling the American spirit? My answer is no. You heard the Gramm and Laffer bashing the government. They’re the two high priests of supply-side economics, what is also referred to as voodoo economics.

Actually the term voodoo economics was first used by George Bush when he was campaigning against Reagan during the 1980 presidential campaign. It’s a religion because it’s based not on facts or science but on faith. They have ten commandments. Big government and most government spending are always wasteful and stifles the American spirit, first. Second, free markets always know best, they never fail, they never experience a national crisis. Three, it’s best to have no regulation or supervision of markets, especially financial markets. Four, high taxes are bad especially for the rich and the very rich. Five, lowering tax rates increases revenues overall, the Laffer Curve doesn’t work. Even if lower taxes lead to higher deficits, higher deficits don’t matter. Seven, even if lower tax rates cause higher deficits, that’s good because you’ve got to starve the beast, you’ve got to force the government to cut back its own size. That doesn’t work either. Eight, government spending is always wasteful unless it’s for foreign wars that cost trillions of dollars. Nine, subsidies are bad but subsidies and tax breaks for big business are always good even if they bust the budget. Ten, income and wealth inequality are good; as Gordon Gekko said, greed is good. In capitalism it is the survival of the fittest or the richest. Big government should have nothing to do with income inequality. Now these are the principles, but with a bunch of experiments in the ’80s and the last ten years which means 2001 to 2008 during the Bush administration-- we had the system of free markets and laissez-faire economics, no regulation, supervision of the financial system, lower tax rates and supply-side voodoo economics and a rhetoric of bashing big government while increasingly spending on government spending, discretionary spending and on the military. What did we end up with?

We ended up with the worst financial and economic crisis since the Great Depression, two expensive foreign wars financed with two trillion dollars worth of debt, with budget deficits that were already over a trillion dollars when Obama became president. So who bailed out Bear Stearns, Fannie and Freddie, AIG, Citi, Goldman-Sachs, an entire financial system with 700 billion TARP money? Was it the Democrats? No, it was during the Bush administration. So who are the culprits of this economic, fiscal, and financial mess? Is it big government? No. The culprits are here, by the way, two of them are here, Mr. Laffer, Mr. Gramm. And I mean it literally. Paul Krugman listed Mr. Gramm as the number two person responsible for the economic crisis after Alan Greenspan. If you believe that Krugman is biased, both CNN and Time Magazine put them in the list of the top 20 people to blame for the financial crisis.

What his record is is he has been bashing big government forever, for decades, but he was a leading author by the Gramm-Leach-Bliley Act that essentially repealed the Glass- Steagall Act, that led to what is called the CitiGroup Relief Act, that led to the merger, the disastrous merger, of CitiCorp and the Travelers group. Now they’re under government control, these financial institutions. And as we know, the repeal of the Glass-Steagall Act was one of the many causes of the recent financial crisis.

Gramm was also one of the five co-sponsors of the Commodity Futures Modernization Act of 2000 that essentially limited any regulation of credit derivatives and other derivatives, with even an Enron loop hole in it that essentially limited any regulation of energy futures. You know what ended up happening with Enron. It went to a scandal and bankruptcy. Other parts of this act limited regulation and supervision of credit derivatives, of CDSs and other derivatives as well at the center of this financial crisis. Warren Buffet calls these derivatives weapons of mass destruction. So that’s the record.

Does he think he’s responsible for some of the financial crisis? Not only doesn’t he, but in a July 2008 interview, when he was advisor to McCain, he said that the nation was not even in a recession. He said, you’ve heard of mental depression. This is a mental recession. We’ve sort of become a nation of whiners. You just hear the constant whining, complaining about the loss of competitiveness, American decline. During this mental recession, 8.5 million people lost their jobs, unemployment went to 10 percent, 17 percent including discouraged workers or partially-employed workers. And of course Mr. Gramm and Mr. Laffer believe that giving unemployment benefits because of loss of jobs and income is bad because it reduces the incentive to find new work.

Now what’s the record instead of Mr. Laffer? He is the father of the Laffer Curve, the idea that if you lower tax rates, revenue is eventually going to be become higher. Now, there is zero, zero evidence that tax rates pay for themselves. I could cite hundreds of economic studies, but I will cite just one person, Greg Mankiw, who was the main economic advisor of George Bush, W.

He is also a professor at Harvard. He said the following thing about the idea of a Laffer Curve working, in a part of his textbook called Charlatans and Cranks. “When politicians rely on the advice of charlatans and cranks, they rarely get the desirable results they anticipate. After Reagan's election, Congress passed the cut in tax rates that Reagan advocated. But the tax cut did not cause tax revenue to rise.” And I could cite hundreds of other studies suggesting that there is absolutely no evidence that reducing tax rates increases revenues. David Stockman, who was the budget director for Reagan, most recently in an op-ed in the New York Times titled “How My Republican Party Destroyed the American Economy.” And he started his op-ed by saying, “If there was such a thing as a chapter 11 for politicians, the Republican push to extend unaffordable Bush tax cuts would amount to bankruptcy filing. That's the lesson.” Now, we realize that tax cuts do not reduce budget deficits.

They increase them sharply. So they change the argument in favor of tax cuts. They realize that tax cuts are to budget deficit. But they say, first of all, it doesn't matter. Or if does matter, it's going to starve the beast. To have low tax rates is going to force the government to cut government spending. That was the argument. The result was just the opposite. When Bush came to power in 2001, discretionary spending was 260 billion at that time. By the time he left the administration eight years later, it was 420 billion, twice as much.

Okay.

Could I make a final point?

### Moderator
Claim: Nouriel Roubini, your time is up.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: Thank you.

### Scientific Advocate (SA)
Claim: Could I make a final point?

## Round 2

### Moderator
Claim: I think-- can you save it? Thank you very much. And that concludes round one of this Intelligence Squared debate, where the motion being argued is “Big government is stifling the American spirit.” We'll be right back.

And now we are back. By the way, your instincts on when to applaud have been fantastic, so thank you. In terms of the atmospherics for the radio broadcast, so thank you for that.

Yes. I know what you want to do. And I would rather that this happen in the middle. See what you've started here. I realize that you were just the subject of a personal attack.

### Moderator
Claim: No. The first time. The first time.

### Conspiracy Advocate (CA)
Claim: When you can't debate issues, you attack people personally.

### Moderator
Claim: And what I would like to do because of that is to ask you to take just one minute, and then we can move on to the substance of the issue.

### Conspiracy Advocate (CA)
Claim: Okay. Let's--

### Moderator
Claim: --and leave it at that. So the minute starts now.

### Conspiracy Advocate (CA)
Claim: First of all, my confidence in freedom is not based on faith.

It's based on evidence. Two, it's true that Bill Clinton spent the whole campaign attacking me and attacking Gramm-Leach-Bliley. But when he became president, and he proposed reforming the banking system, how many changes do you think he made in Gramm- Leach-Bliley? None. In fact, he strengthened Gramm-Leach-Bliley to require systemically significant companies to become financial services holding companies under Gramm-Leach-Bliley. So the plain truth is Gramm-Leach-Bliley broad based organizations did better during the financial crisis. There would have been more failures without the law. Obama had a chance to change the law, and he didn't do it. Now, some people would say, well, maybe he wasn't telling the truth to begin with. I don't think that. I think he just learned something. Not everybody did.

### Moderator
Claim: Thank you, Phil Gramm. And you're straying into your real time now, so I'm going to move on to round two.

Big government is stifling the American spirit, that is our motion. And now we move on to round two where the debaters address each other directly. The side for the motion, Phil Gramm who fought to shrink government when he was in the Senate, and Art Laffer, the man behind the curve, arguing that government ties the hands of the truly creative and innovative, those who would otherwise help grow America and create jobs. The side against the motion “Big government is stifling the American spirit,” Laura Tyson and Nouriel Roubini, insisting that governments and laws are needed both to rescue those who are in trouble and to police those who, left to their own devices, particularly in the world of business, would do much more harm than good and have in the very recent past. We're now going to move to that part of the debate where I ask questions, you ask questions, and the debaters can talk with one another directly. And I want to go to the issue of substance.

To the side that's arguing against the motion, your opponents are proposing a thesis that when the rich are taxed, they stop producing growth. Can you go specifically to that issue, to that thesis which is really the core of their argument, Laura Tyson.

### Scientific Advocate (SA)
Claim: Well, I'm not sure I would agree it is the core of their argument, because I want to say that I think the issue that we need to discuss more is that as a country, we actually, as I said, want the government to spend money. But then we don't want to pay for it. And one of the words that was only used here once tonight, but needs to be brought back, is the word entitlement. And I think it's important to point out right now that according to the CBO, within 15 years entitlements plus net interest will absorb all of the tax revenues of the US government. We could not do anything else, no education, no technology, no infrastructure, no other government whatsoever.

So I think that as we debate what kind of tax system we're going to have, and I think that's a legitimate area of debate, we also have to address the fact that 78 percent of Americans will say growing costs of entitlements pose a major problem for the United States. But if you ask them what to do about it, 56 percent say no tax increases to solve the problem. 66 percent say no benefit cuts to solve the problem. A third of the people say no change whatsoever to solve the problem, a big problem, but not my problem. And I do think we have to ask ourselves the question of if we want to spend on programs, how are we going to finance them?

### Moderator
Claim: But how about the question I asked here?

### Scientific Advocate (SA)
Claim: But I think-- I'm happy to answer that question-- but I honestly think it's--

### Moderator
Claim: Your teammate would like to know

### Scientific Advocate (SA)
Claim: Yes, go ahead.

### Scientific Advocate (SA)
Claim: There is absolutely no evidence that increasing tax rates when they're at normal levels is going to reduce labor efforts. When Clinton came to power, he raised the marginal tax rate from 35 to 39 percent.

Everybody, including these gentlemen, said it's going to be a disaster, a recession. Guess what? We had eight years of the highest economic growth in the U.S. economy, and no effect on the tax burden of anybody. And then-- and then, when Bush came to power, he reduced these taxes. We lost $2 trillion of revenues. We had a huge budget deficit. We eventually ended up with the worst financial crisis and economic recession since The Great Depression. So where is the evidence?

### Moderator
Claim: Arthur Laffer.

### Conspiracy Advocate (CA)
Claim: Yeah. I'll try to get to the evidence. Let's take Bill Clinton. And Laura, I think you did a great job with Bill Clinton. And I voted for Bill Clinton twice, and God knows I didn't vote in that party's primary. So I voted for him twice, and I thought he was a great president. Little bit of a problem as a person. But he was a great president. But he pushed NAFTA through Congress against his own party, against the unions. I thought that was just wonderful. I took my hat off to him there.

As some of you know, he got rid of the retirement test on Social Security. If you were between the ages of 65 and 72, every dollar you earned in Social Security-- is earned, you lost 50 cents in Social Security benefits. Clinton got rid of that. If you look at it, Clinton reappointed Reagan's Fed chairman twice, brought the long-term bond yield way, way down. I thought that was spectacular. If you look at what Clinton did, he passed welfare reform, signed into law welfare reform, that you actually have to look for a job to get welfare. Now, there's a concept. Clinton also had the biggest capital gains tax cut in our nation's history. If you know, he exempted-- got rid of all capital gains taxes on owner-occupied homes, couples and-- I mean virtually all. If you look at Clinton, the one thing I really like most of all about Bill Clinton is he cut government spending as a share of GDP by the largest amount of any American president ever. In fact, it was he cut it by four times-- by as much as the next four best presidents combined. There is a supply side president, in my view. Yes, he did raise tax rates on the--

He did raise tax rates. That was the one mistake he made. But all the rest were great.

### Moderator
Claim: Nouriel Roubini.

### Scientific Advocate (SA)
Claim: Not only--

### Scientific Advocate (SA)
Claim: The first thing he did was to raise taxes because we had a huge budget deficit during the Reagan Bush years that was going to become a disaster. Everybody, including you guys, said it's going to lead to an economic recession. Then reducing the debt is-- reduced interest rates led to innovation, to private investment, rather than the government sucking resources, that led to growth. The reality is that every time the Republicans are in power, the budget deficit becomes much larger because you cut taxes in a way that's unsustainable. You raise military spending, and you raise discretionary spending as much or more than the Democrats. During the Bush years, discretionary spending doubled.

### Moderator
Claim: Phil Gramm.

### Conspiracy Advocate (CA)
Claim: When Ronald Reagan was president, we had a deficit of $100 billion as far as the eye could see. The deficit today is $1.5 trillion.

Government spending has risen by 20 percent in two years.

### Scientific Advocate (SA)
Claim: Obama

### Conspiracy Advocate (CA)
Claim: We are looking-- wait a minute, you had your time, let me have my time.

### Moderator
Claim: Let him speak, please, let him speak, okay? Phil Gramm speak.

### Conspiracy Advocate (CA)
Claim: Do you really think we can operate a country where 40 cents out of every dollar of income taxes has to go pay interest on the debt? Einstein was once asked, "What is the most powerful force in the universe?" He said, "The power of compound interest." And now we've got it working against every worker, and every taxpayer, and every consumer in America, every minute.

### Scientific Advocate (SA)
Claim: Can I ask a--

### Conspiracy Advocate (CA)
Claim: I don't see how you can sit there--

### Scientific Advocate (SA)
Claim: Can I ask a question?

### Conspiracy Advocate (CA)
Claim: --and not be alarmed about that

### Moderator
Claim: Laura Tyson.

### Scientific Advocate (SA)
Claim: I would like to ask Phil Gramm a question, because if you-- your point about interest payments on the debt is unnerving, frightening, it does have to do with the fact that we came into a crisis with a large level of federal debt to GDP and it has gone up.

I would like to ask the question of what you would like to cut, in very specific terms, very specific terms, and see whether those cuts conform with what the American people would like to cut.

### Conspiracy Advocate (CA)
Claim: Okay, first of all, Ronald Reagan eliminated three Social Security benefits in one vote.

### Scientific Advocate (SA)
Claim: Okay, so cutting Social Security, which the majority of Americans--

### Conspiracy Advocate (CA)
Claim: All right, let's just take Social Security.

### Scientific Advocate (SA)
Claim: --do not want to do, cutting--

### Conspiracy Advocate (CA)
Claim: I will answer your question.

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: First of all, we're currently phasing--

### Scientific Advocate (SA)
Claim: But the majority of Americans--

### Moderator
Claim: Laura, at least let him do this.

### Conspiracy Advocate (CA)
Claim: --we're currently phasing the retirement age up to 67. Given the lifespan changes in America, 22 years from now we're going to get to 67, we need to allow that to continue to rise to 70. It will affect nobody for the next 22 years, but it'll change America a lot.

We index Social Security by the wage rate, not the price level. That's a mistake and it needs to stop. And we pay benefits based on your high three years of earning, not what you pay in the whole system. If you change those three things, you eliminate the long- term actuarial problem in Social Security. And what would I do about Medicare?

### Scientific Advocate (SA)
Claim: Okay, can I-- yeah.

### Conspiracy Advocate (CA)
Claim: I think people ought to have co-payments and deductibles based on their income. And I think everybody ought to have a co-payment and a deductible no matter how low their income is. With somebody like Art, I think his deductible ought to be about $250,000 a year. And his co-payment after that ought to be 50 percent.

### Moderator
Claim: All right, change. Before the list gets too long, Laura Tyson.

### Scientific Advocate (SA)
Claim: I actually could probably have a discussion with Phil Gramm on these issues, and I suspect we would probably come to some agreement.

I think what's important about this debate is not the debate, sadly, that the country's really having. If you have a debate that says "Big government is stifling the American spirit," it basically suggests that the problem is the government, not us. And if you ask people, and I've already said this, "Are you willing to cut benefits or raise taxes to bring this cost situation under control?" the answer is no. So one of the things we actually have to do as public figures is to educate people. I think that Phil Gramm has put out some interesting ideas; I think that those are ideas which a lot of people would disagree with. I think that - - but nonetheless, those are the kinds of things we have to discuss, not some sort of fantasy about size of government, forget it-- about the particulars of the big programs that are driving the government debt. And on the issue of-- just on the issue of making Social Security solvent, the 75-year actuarial hole is basically the same size as the Bush tax cuts.

So there's a nice choice for people, all right? And remember, as Nouriel said, going back to the Clinton level tax rates would go back to levels of rates that coincided with the most prosperous peacetime period in U.S. economic history. So those are not tax rates that are going to stifle the American spirit. It is a way to pay for the actuarial shortfall of Social Security. You might not want to do it that way, but at least recognize, that's a choice.

### Moderator
Claim: Art Laffer.

### Conspiracy Advocate (CA)
Claim: Yeah, first I'd like to ask Nouriel not to quote me when it's incorrect. I never thought the Clinton tax increases would lead to a recession, depression. Never wrote it, never said it. I was a huge fan of Bill Clinton’s overall economic package. I didn’t think those rates were the right things to do but I didn’t. And I would agree with Laura. I mean, come on. Let’s go back to the Clinton era. If you could bring government spending down to the share of GDP to where it was under Clinton, I think I’d take that along with the other ones going there.

I’d love to see freer trade. I mean you really can’t have a prosperous economy, people. You can’t when the government’s way overspending, when it’s raising tax rates, when it’s printing too much money, when it’s over-regulating the private sector and when it’s restricting the free-flow of goods and services.

### Moderator
Claim: But what is the government here for, if you can put it in terms that we’ve heard tonight. Do we want meat inspectors? Do we want levees taken care of in New Orleans?

### Conspiracy Advocate (CA)
Claim: Of course.

### Moderator
Claim: Do we want the roads taken care of? Do we want the universities running?

### Conspiracy Advocate (CA)
Claim: Of course.

### Moderator
Claim: So what is the definition for? When is it big and when is it too big?

### Conspiracy Advocate (CA)
Claim: Let me go first with this. When we talk-- you know, the question you asked Laura which I think is the right question about taxes. I mean, what I’d do is what Jerry Brown did about taxes when he ran for president in 1992. I’d get rid of all federal taxes except for sin taxes, and have two flat-rate taxes, one on business net sales and one on personal and adjusted gross income. If you did that, you could have Jerry Brown flat tax of 13 percent.

Now if I remember correctly Jerry was not a right-wing Republican. Did I miss that somewhere?

### Scientific Advocate (SA)
Claim: No.

### Conspiracy Advocate (CA)
Claim: But I did all of Jerry’s tax-- first place, make the tax codes efficient so you don’t have all the loop holes and everything to get around them. Don’t make it so that Warren Buffet-- Don’t make it so that Warren Buffet never pays taxes.

### Scientific Advocate (SA)
Claim: But I think recognizing--

### Conspiracy Advocate (CA)
Claim: Unrealized capital gains is taxed at a zero rate. I mean, that’s why these things-- make it so it’s a flat tax on all income period. Then you get the growth or you will get the revenue gains, Nouriel. Frankly, you really will get them.

### Moderator
Claim: Well, what is your definition of where the spending stops? Where does a person--

### Conspiracy Advocate (CA)
Claim: Well then you go to the spending side and I would put it on a balanced budget and vote for if you’re going to have more spending, you’ve got to vote to debit tax rates, go step in step. You can’t do it separately. And if people want more taxes and more government, once you get an efficient system, god bless them, it’s their country. But my view is I’d rather see it go the other way. I think the other way would be better but it’s their country and they deserve it.

I mean, people deserve the governments they get and that’s for sure. But it isn’t just let it go at all times and Nouriel, I thought, in the debate at least when you were introduced, was that you won the debate last time you were here, Nouriel, by saying it was Washington’s fault, not Wall Street’s fault.

### Moderator
Claim: Nouriel, response?

### Scientific Advocate (SA)
Claim: First of all it wasn’t Wall Street’s fault as much as government. The point is that we have a huge budget deficit that everybody knows is unsustainable. It’s trillion dollars. But the question is how did we get here, and by the time Obama came to power, the deficit was already a trillion dollars. First of all, it happened because we had totally unsustainable tax cuts in 2001, 2003. Two, we had these laissez-faire policies that led to the worst economic and financial crisis and we had to bail out the banks. The collapse of income led to the collapse of revenues. And that’s the situation we started from. Now we have a budget deficit that’s 10 percent of GDP. Do we really think that we are going to be able to reduce spending by 10 percent of GDP?

Everybody agrees we need entitlement spending reform. We have to restructure social security, Medicare. We have to cut entitlement spending. But how are you going to fix this gap? How are you going to go to a zero budget balance? When Bush left the administration, the tax rate in the United States as a share of GDP, revenues of the federal government were 15 percent, the lowest in the last 60 years. The average has been 20 percent because of his reckless tax cuts. So we need to reduce the budget deficit. We have to cut spending, but we also have to raise gradually over time revenues. There’s not going to be any way in which the American people are going to decide to slash Social Security, to slash Medicare, to slash military spending and not to have any revenue increase. So we have to find way in the middle, but you guys are always on the side of lower taxes that every time they’re implemented during the Reagan years, was in the Bush years, led to bigger budget deficits and lead to economic and financial disasters.

### Moderator
Claim: Phil Gramm.

### Conspiracy Advocate (CA)
Claim: Well, first of all, I don’t defend spending under George Bush.

### Conspiracy Advocate (CA)
Claim: Neither do I.

### Conspiracy Advocate (CA)
Claim: I thought we had an unnecessary deficit. I thought we let spending get out of control, especially after the House became Democrat and you had Pelosi as Speaker. No, it’s just a plain fact. In seeking consensus, George W. Bush spent money. We should have forced the defense build up as we fought wars to be offset against weapons procurement. But the plain truth is Obama has proposed to expand or to extend the Bush tax cut except for $30 billion. Nobody is proposing to take that tax cut back. And look, let me tell you, having looked a long time at Social Security and Medicare, you can't deal with these problems by raising taxes. You have got to be willing to change these systems and make them more actuarially balanced.

When people started getting Social Security, the average American didn't live to be 65. The world is changed. The system didn't chan67ge. There was never a trust fund. It's a financial Ponzi scheme of the worst sort.

### Scientific Advocate (SA)
Claim: It was--

### Conspiracy Advocate (CA)
Claim: We've got to go back and fix these things. And doing polls, Americans will always say they don't want to fight a battle intellectually as long as it's a choice. But when you give them effective leadership, they're willing to fight those battles.

### Moderator
Claim: Laura Tyson.

### Conspiracy Advocate (CA)
Claim: And what both parties need to do is give people a way of solving the problem instead of just simply saying, well, the people don't want to solve the problem.

### Moderator
Claim: Okay, let's bring in Laura Tyson to respond briefly because we have to take a break.

### Scientific Advocate (SA)
Claim: My response would be that I do agree that we need to give the American people a choice.

But I do want to say the American people, through poll after poll, are not willing to do basic arithmetic. This is not a size of government problem. It's an arithmetic problem. If we never had the great financial crisis of 2008 and ’9, we didn't have it at all, we would still face unsustainable deficits and debt driven by our programs that are the most popular programs with Americans. We haven't talked about healthcare reform tonight. I try sometimes to link what we're talking about to the experience of other countries. I mentioned that we have a relatively small government by other countries' standards, that are very, very competitive growing economies with satisfied people who have suffered less from the great recession.

Most of these countries have very different healthcare systems than we do. And let's be clear about this. Medicare itself as an entitlement problem is because of healthcare cost growth. But it's not because Medicare grows faster than private healthcare. It's because we have a private healthcare cost problem in this country. We spend three times as much as any other country on a per capita basis on health. Our healthcare costs grow most rapidly. And we do not have better quality. We do not have better outcomes. We do not have more choice. Americans don't want to hear this, but they need to hear it because you cannot solve the deficit and debt problem, which would exist independent of the crisis, as I said, if we don't-- if we're not serious about healthcare reform. And you know how this was discussed by the critics of big government in the debate about healthcare reform? Controlling costs was described as death panels, death panels. That's how you take a serious issue and you make it an ideological debate, which precludes making tough choices.

### Moderator
Claim: All right. Thank you, Laura Tyson. We're going to take a brief break. And when we come back, we're going to talk the audience's temperature on what they are hearing.

So I mentioned before the debate that we want to try something tonight where we want to very briefly ask a few of you to raise your hands and in two or three sentences, answer a question that I am going to put to you about what you are hearing tonight. And then after that, we're going to come to you for questions. Do you understand? So I'm going to ask you actually to tell us what you're hearing. And the question I'm going to put to you, when we come back, is what are you hearing from either side that you're just not buying, that you-- it's just not making sense. So do you want to-- anybody want to take a crack at that? If you just raise your hand, we'll bring a mic to you.

Okay, this gentleman in the green shirt here and a woman up-- woman necklace and-- if you can come down the steps. Yes. You can stand up. And on the right side, okay, the gentleman in the black shirt. I think it's black. Yes, stand up. So I'd like you to just tell us, when we come back to this, just very briefly two to three sentences what you're hearing, why it doesn't work for you. All right? Does everybody have a microphone? And I'd like-- no, gentleman in the green shirt has a microphone. Can the three of you stand up? And I'm going to go this-- in that order, okay? So we come back.

Our motion is “Big government is stifling the American spirit.” And now at this point in the debate we'd like to hear from you in the audience, just take your temperature on what you're hearing. And the question I want to put to you, as you listen to this debate, and you listen to these panelists debate, what are you hearing that you are just not buying? Let's start with you, please.

### Moderator
Claim: It's not so much a question of what are you--

### Moderator
Claim: I think your-- can you start again? Your mic is on now.

### Moderator
Claim: Hello? Okay. What I'm not hearing is the issue of jobs creation. Is it possible that lower taxes, although they would probably increase the deficit, might also stimulate jobs creation which will result in more tax paying. And also what hasn't been mentioned is more consumption and greater confidence on the part of the consumer to spend money and stimulate the economy.

### Moderator
Claim: Thank you. That was a perfect-- perfectly timed. Sir, you saw the model.

### Moderator
Claim: What I'm not hearing is that there's evidence that the Laffer Curve is maximized at 70 percent income tax. I'd like to hear more about that.

### Moderator
Claim: Okay. And sir?

### Moderator
Claim: And in my case, what I'm not hearing is what's going to happen for the next generation. For us, we're graduating from school, in my case at least.

I don't want to go back to Kennedy, Reagan, what they did, what they did. I want to know what we're going to do now to solve the crisis that we are-- we have at hand.

### Moderator
Claim: Okay. Thank you. So what we're hearing is a little bit of concern about the future. And Phil Gramm, you actually discussed this being a very bad time to be young. Can you take on that topic?

### Conspiracy Advocate (CA)
Claim: I don't know. Any time is a good time to be young.

### Moderator
Claim: True, true, true. Well done.

### Conspiracy Advocate (CA)
Claim: I think the link between marginal tax rates and the exertion of human energy is one of the best documented links of any economic observation in history. Secondly, we do need to create more jobs. And that's what this debate is really about, even though, quite frankly, I didn't realize till you said it, that we hadn't been talking about it. And what does your future depend on? Does it depend on government getting bigger? Does it depend on half of all income taxes going just to service the debt on government?

Or does it depend on more opportunity and more freedom, where ordinary people are empowered to do extraordinary things? America is not a great and powerful country because the most brilliant people in the world came to live here. It's a great and powerful country because ordinary people like us have been able to do extraordinary things with our freedom. And that's what I believe is in peril. That's why these numbers scare me.

### Moderator
Claim: All right. Let's go to questions now. And these are questions. And again, questions are terse, and they are questions. And please don't read statements. Please don't do two-part questions. One part. Choose your part, and try to keep it on our topic. And this gentleman, red suspenders. Sir, if you can stand up, the camera will find you. You're on the left side. And if you can just take a second, I want to make sure the camera has you. Okay. Go ahead and ask your question.

### Moderator
Claim: I was hoping to hear something about the stiflage of the American spirit. I heard a lot about--

### Moderator
Claim: Sir, can you hold the mic closer to you and repeat the question because they can't hear you.

### Moderator
Claim: I was hoping to hear more about the stiflage of the American spirit. I'm not sure that I heard exactly what the American spirit is. How many people-- what percentage of the population has this American spirit now and what-- in what way is this stiflage going to have any effect on the rest of us who go about our quotidian daily lives.

### Moderator
Claim: Laura Tyson.

### Scientific Advocate (SA)
Claim: Yes. Let me say a little bit about that because I think we can also relate it to jobs. I mean, I think-- when I think about the American spirit, and I think about the current situation, I do worry most about young people. We haven't-- we've talked about the government tonight. We haven't talked about state government. State governments do have balanced budgets.

One of the reasons that you don't feel so much of the federal stimulus effect is because states have had to contract a lot. And do you know where they contract? They contract in education. That's where they have to contract. So if you think of the American spirit as art programs, if you think of it as music programs, if you think of it as athletic programs, if you think of it as foreign language programs, if you think of it as your child going to school in a safe building structure that's energy efficient, all of those things are being stifled, because the state revenues have collapsed because we are in a major recession. And the major recession was caused by a major financial shock. And frankly, again, there is no easy way out of this. And I for one think because the federal government can afford to borrow at very attractive very low interest rates near record low interest rates, we should be helping those who are unemployed get training, we should be helping teachers stay in school, we should be providing aid so that every single kid who wants to go to college right now can afford to go to college.

What better time to go to college than right now? So those are the ways in which I think the debt we inherited, the concern about deficits, the unwillingness to let the government help as it does-- as it's helped throughout history in this kind of crisis, to help ordinary Americans achieve their spirit, that this is a real problem.

### Moderator
Claim: Do you think, Laura, that-- do you think this-- the American spirit is presently stifled?

### Scientific Advocate (SA)
Claim: I think the American spirit has been-- the confidence in the U.S. has been shaken by the depth of the crisis we are in, and I think the way we are forcing cuts on basic services like education is certainly stifling the spirit and perhaps the life prospects of kids who are five, six, seven years old. Remember, we have 25 percent now-- almost 25 percent of children in poverty in the United States.

### Moderator
Claim: You've had a run, Laura, so let me bring in Phil Gramm, please. Phil.

### Conspiracy Advocate (CA)
Claim: Well, let me first say I agree with you, you asked about how many people had it, the answer is "not enough." To me the American spirit is a belief that based on your own merit, based on your own hard work, no matter who your daddy was or who he wasn't, or who your mama was, that people are going to judge you on your ability, and that you have it within your power to succeed. Now, obviously it's better to be-- it's better to be clever, and pretty, and rich. But being plain, and ordinary, and poor, those things are not insurmountable obstacles in America.

And it's that belief of what we can do, but you can't have unlimited government and unlimited opportunity. You have to make a choice. Art and I aren't against government, but we believe that it has got to be limited if we're going to have that kind of opportunity. And Americans are optimistic people because of who we are and what our history has been. We can't have France's government and be Americans.

### Scientific Advocate (SA)
Claim: Great.

### Moderator
Claim: Could you rise, sir?

### Moderator
Claim: And I just-- Okay, they've got you.

### Moderator
Claim: To Mr. Roubini, I think we're all agreed that one thing that is stifling to the American spirit is the financial crisis, as you noted in your remarks.

Now, so whatever caused the financial crisis is presumably stifling to the American spirit, and has been noted, when you were last here, you successfully argued that government is the primary cause of the financial crisis, not the private sector, ergo, it is government that is stifling to the American spirit. So I ask you-- why aren't you sitting over there?

### Moderator
Claim: Now, I realize you've just been the target of a personal attack.

### Scientific Advocate (SA)
Claim: You know, when I was last here I argued that both the government and the private sector was to be blamed for the crisis and it was a crisis caused by many policy mistakes by those who-- by reckless risk taking, leverage, and debt of the private sector-- so it's always a complicated story. But if the American spirit is stifled today, it is because this is not a mental recession, this is a real recession, this is the worst recession we have had since the Great Depression with unemployment rate now at 17 percent.

We have nine million people out of work that have lost their jobs, and unless we address this problem, we're not going to resolve this mental, and physical, and economic, and financial depression. Now, what can we do about jobs? The CBO, Congressional Budget Office, did a study that suggested that of all the types of stimulus, the one that has the least effect on economic growth and job creation is reducing taxes for the rich. And the one that has the strongest effect on raising the demand for labor is to reduce the payroll tax both for employers and employees. And I proposed in an article recently a reduction temporarily in the payroll tax for employers and employees to be paid by the expiration of the tax cuts for the rich. They are expiring at the end of the year, so it’s not a budget busting reduction in taxes, it’s revenue neutral. We’re not going to increase the budget deficit that’s already one trillion and a half and stimulate economic growth. We have to stop subsidizing the rich. We have to start stimulating demand for labor for workers. That’s what we need to do.

### Moderator
Claim: Art Laffer.

### Conspiracy Advocate (CA)
Claim: Let me just carry Nouriel’s comments a little further and I do agree with him on that. Is when you look at a firm’s decision to hire a worker, that firm that makes its decision based upon the gross wages paid to the worker. The marginal product they have to get out of that worker has to cover the gross wages paid, inclusive of all costs. When you look at a worker’s decision to work, they look at net wages received. They couldn’t care less how much the firm pays. They care how much they get net. And there’s a wedge driven between wages paid and wages received, one on the demand curve and one on the supply curve of labor. What you’ve got to do is reduce that wedge to make it more attractive for firms to hire workers and more attractive for workers to work. One way of doing that is Nouriel’s comment here to lower the payroll taxes. That would work very well. Where I do disagree with him totally is on raising tax rates on the rich who are the people who do the employment.

Let me tell you, these guys don’t employ workers for altruistic reasons. They employ the workers to get an after-tax profit of their own. And if you make it discouraging for them to employ workers, they’re not going to employ them. These people are the decision makers and that’s what you’ve really got to worry about. It’s not an equity argument of whether the rich can afford it or not. It’s whether they’ll disemploy people or not. Just look at their behavior. That’s what you’ve got to do. But he’s right. It’s the wedge between the wages paid and wages received and that is the key to bringing employment back. Everything we’re not doing today.

### Scientific Advocate (SA)
Claim: Can I ask Art a question that actually combines something? So Nouriel is suggesting, and it’s something I also support, thinking about bringing the top two Bush tax cuts for the top two percent down back to the Clinton era and using the money which is 30 to 40 billion dollars next year either for a payroll tax deduction or for more aid to the states or for a number of other things.

Now you suggested that, Art, that you were concerned about raising taxes on the rich. This would basically be bringing them back to the Clinton level, which you thought was fine. It actually worked really well.

### Conspiracy Advocate (CA)
Claim: No. I thought the program was fine.

### Scientific Advocate (SA)
Claim: So we need the revenue-- no but that was a key part of his program. Give me-- that was the first-- as Nouriel has already said, that was the first thing that he did. The reason that the Democrats lost control of the Congress in 1994 is because the Republicans claimed that the Democrats were responsible for the largest middle class tax increase in history. Do you know what that was? A four and a half cent gasoline tax, okay? So I say you think those taxes of the Clinton administration were fine, let’s go back to them, take the money which is 40 billion dollars next year and my goodness we could find several ways, the CBO listed about 10 different ways of using that money to create more jobs.

### Moderator
Claim: Alright, I have to do a quick piece of radio for radio right now. Our motion is “Big government is stifling the American Spirit.” This is a debate from Intelligence Squared U.S. I’m John Donvan of ABC News. We are in the question and answer section of this debate. We have four debaters, two teams of two, debating this motion, “Big government is stifling the American spirit.” And I want to take to this side a specific recommendation that Nouriel makes in his new book about Wall Street compensation. He talks about the need to cure compensation and he’s not talking about the amounts. He’s talking about the way in which it is structured, which he said helped encourage practices that led to the financial crisis. Moreover, he says government needs to be involved in this process of curing compensation on Wall Street. Your response to that concept.

### Conspiracy Advocate (CA)
Claim: Well look, I want to say one thing about rich people. How many people poorer than you--

### Moderator
Claim: So Phil, can you answer my question?

### Conspiracy Advocate (CA)
Claim: --have ever hired you?

### Moderator
Claim: Mr. Gramm, can you answer my question?

### Conspiracy Advocate (CA)
Claim: I’ll be glad to.

### Moderator
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: The last thing in the world we need is the government setting peoples’ compensation in the private sector. I work for a big investment bank. Some people we pay a lot of money to. Do we want to pay it? No. The problem is they’ll go to work for somebody else. That's what's called competition. And when we start setting our value judgment as the standard by which we're going to gauge value, we start making a mistake. Now, I don't have any problem with deferred comp that tie people's objectives to long-term earning. But the idea that government ought to be involved in setting compensation is as alien to the American spirit as any idea can be.

### Moderator
Claim: Nouriel Roubini.

### Scientific Advocate (SA)
Claim: The problem was that we-- the problem was we privatized the gains, the bonuses, the profits in good times. And then those guys led to a reckless financial crisis. And now we socialize the losses, and everybody here has to pay for those compensations. That's why the government has to interfere, I’m sorry to say, because a $2 trillion bailout of Wall Street, who is paying for it? We are paying for it.

### Conspiracy Advocate (CA)
Claim: the government doing that.

### Scientific Advocate (SA)
Claim: And you don't want any control on compensation either.

### Moderator
Claim: Art Laffer, repeat. Repeat.

### Conspiracy Advocate (CA)
Claim: That is the problem with government. Nouriel just said it right. Nouriel, let me just so-- you said it right. The government shouldn't bail these guys out. They shouldn't bail out the housing industry. They shouldn't bail out any of these guys. The only bail outs you should do are for individuals--

### Scientific Advocate (SA)
Claim: We privatized the gains. We socialized the losses.

### Conspiracy Advocate (CA)
Claim: --who are unemployed or can't help themselves for a time period. But it shouldn't be 99 weeks. That doesn't make any sense.

It just makes it so it's not worth the working. And by the way, Laura, one factual thing. I did support Bill Clinton, and I thought he was a great president from that standpoint. I did not agree with that tax increase. Please don't put that on me. I thought he did lots of other things that way overwhelmed that.

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: But that was one thing I did not support.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: Sir, you have a neck tie, and if you stand up, a mic will come to you. That's everybody, I know. Okay. Go ahead, please.

### Moderator
Claim: Pardon me if I get my facts wrong, Senator Gramm. But it is my understanding that the bank that you served as chairman, UBS, received a bailout from the government of Switzerland. Do you feel as though that is incongruous with the position you are taking in this debate?

### Moderator
Claim: What-- can you-- can you tell me what-- how you are relating that to our motion?

### Moderator
Claim: Well, it's the role of government in the private sector.

### Scientific Advocate (SA)
Claim: Yeah, the bailout.

### Moderator
Claim: It may not be the American government.

### Moderator
Claim: All right. Fair enough. I just wanted to get that clarified.

### Conspiracy Advocate (CA)
Claim: Well, let me say-- I guess you can tell by my accent I'm not from Zurich. I been in Swiss politics, I would not have been for the bailout. It is clear to me we would have survived and prospered without it. I do believe, however, that it is important to note that it was government, through CRA, pressuring banks to make subprime loans.

It was federal quotas on Freddie and Fannie where they had to hold more and more subprime paper. As our dear colleague argued when he was last here, this was a crisis made in Washington. I also think it's important to note-- and I'm not here to defend a bank bailout. But I think it's pretty clear Freddie and Fannie have not paid their money back and probably never will. Almost all the banks have paid it back with a profit.

### Moderator
Claim: Laura Tyson.

### Conspiracy Advocate (CA)
Claim: Who owns Fannie and Freddie?

### Scientific Advocate (SA)
Claim: I'd like to say two things about this financial crisis, one is just to recommend a book, because I have used history a lot tonight, and I haven't cited the book. The book is called This Time It's Different. It's a great book. Everyone should read it. It's based on an analysis of financial crises over a time and across countries. You don't have to mention-- there's no Fannie Mae or Freddie Mac in that book. There's no particular piece of legislation. There are some basic things that are true in financial crises. They have to do with overleverage. They have to do with interest rates which are too low. Credit was too cheap. People get overleveraged. They have to do with overconfidence. People basically are overconfident. We know this from more and more studies of how people make economic decisions. So the first point is we should just-- we shouldn't debate the cause of the crisis in terms of a particular piece of legislation or a particular institution. We should go and look at history. And--

### Moderator
Claim: Laura, how does your point relate against our motion?

### Scientific Advocate (SA)
Claim: My point is about the bailout. My point is about right now we are looking at the size of government at a crisis moment that we have not lived through before, anyone in this room, that occasionally societies go through, that when that happens, governments tend to increase in size. They double, they triple. The government debt as a share of GDP rises by 85 percent. There are huge mop-up operations. And to say a bailout, why did the government step in? You know, frankly, it was not for tears for Lehman Brothers or Bear Stearns or any of the banks that received federal money. It was because credit markets had closed down. It is because money market funds were about to go under. It was because things that you relied upon as you put your money in the money market, and it was worth-- put in $500, when you went, there was $500. There wasn't going to be $500.

So this was a bailout of the financial system. There was a run on the financial system. Capitalist economies cannot run without finance. There was no solution--

### Moderator
Claim: So you're saying it was time for the government to act.

### Scientific Advocate (SA)
Claim: I'm saying the government had to act. It had to get bigger. We can debate the cause, but we may as well deal with the reality. That was the reality.

### Moderator
Claim: I have a-- question in the second row. Go to a question here. And if you could stand, please, and remember with the microphone.

### Moderator
Claim: I think it's very interesting that this debate has really revolved around whether tax cuts should happen in the fall or not. But I actually think you really missed the whole question. And that is where should investment whether-- regardless of the size of the government, what areas should our government or-- actually invest in directly or incentivize, whether it's science, technology, is it education, is it oil, is it energy?

This is what we're not talking about. If the American spirit is defined as innovation and creativity, you guys haven't discussed it, none of you. So I'm very curious as to what your top three investments would be and how it would happen?

### Scientific Advocate (SA)
Claim: Can I-- can I say that I thought--

### Moderator
Claim: Laura, I want to let Phil Gramm because, see, you had a run.

### Conspiracy Advocate (CA)
Claim: Well, first of all, it is hard for me to see government as a driver of creativity and innovation. It is generally an impeder of those things.

### Scientific Advocate (SA)
Claim: It's just not true.

### Conspiracy Advocate (CA)
Claim: Now look. There are always areas of government you could do more in. Everybody talks about education. We have dramatically increased spending in education, and quality has fallen because we let education be dominated by a monopoly, the teacher's union. So we need to make some dramatic reforms. But look, here is the problem, and I agree with Laura, we do have a special circumstance. We have a crisis.

But when you're looking at the debt burden that we're piling up now, that's not going to go away when the crisis goes away, the problem with saying let's do this later--

### Moderator
Claim: Phil, I have to interrupt because I thought this question was one that everybody was going to hear the answer to. Her question is what areas would you invest in. What would be the three areas where you put direct investment?

### Conspiracy Advocate (CA)
Claim: Through government.

### Moderator
Claim: Through government.

### Conspiracy Advocate (CA)
Claim: Well, first of all, I think the best investment government can make is to put its financial house in order so that we can have a functioning private system so that we can have more private investment and more job creation. So the first thing I'd invest in is deficit reduction. The second thing that I would invest in is science. Science-- basic science, not taking an idea and commercializing it, something government knows absolutely nothing about, and where every day somewhere in the world we see some huge program where the Japanese invested in high definition television, invested huge amounts of money, and it ended up the market went the other direction, it was all lost.

So basic science, basic knowledge, basic ability to do things-- not just to cure people quicker and better, but to do it cheaper. We have virtually no investment in healthcare in economy. If I bought groceries the way I buy healthcare, where somebody else pays 95 cents out of every dollar, I'd eat different, and so would my dog. And that--

### Moderator
Claim: Okay, so--

### Conspiracy Advocate (CA)
Claim: That's the problem in healthcare.

### Moderator
Claim: So you've got two answers to your question. I want to see if Laura Tyson has another.

### Scientific Advocate (SA)
Claim: I just feel like I need to repeat, and maybe I have indeed failed as a debater--

### Moderator
Claim: If you're repeating too much, I'll stop you.

### Scientific Advocate (SA)
Claim: My comment in my opening statement was precisely that. I identified exactly where I thought the government should invest.

The government used to spend much more on basic science and research. It used to spend much more on infrastructure. Those are areas. And it used-- and it must spend much more on higher education. This is not-- federal government doesn't spend much on K through 12. Higher education. So I look at the research. 90 percent of the growth in labor productivity, which is the driving force of how productive the nation is and what we can afford to pay ourselves, 90 percent comes from investments in those three areas, higher education, research and science, and infrastructure, and the U.S. government used to spend 69 percent of its budget on it, and now it only spends 32 percent. And what is squeezing that out? What's squeezing that out is entitlements and interest on the debt, because we are unwilling to pay for the things we need to pay for. So that's the tradeoff, yes, the U.S. government is not investing enough in your future, in our future. But it's very clear where it should be making those investments.

### Moderator
Claim: There's a gentleman in an orange jacket, and if you could come around, I'll come to you as the next question, I just wanted to ask you to get into a position for that. And the woman-- yes, you just did if you could rise, the mic will come up to you.

And again, short questions are working very well tonight.

### Moderator
Claim: Yes, we-- tonight we heard a lot about this "Irresponsible Bush tax cut,” quite a bit from Nouriel and Laura. I just wanted to hear what they think about the recent one trillion dollar entitlement packages the Obama administration just passed at the depth of the crisis. And I would think that is a perfect example of big government stifling the American spirit, and I would like to hear what they think about that.

### Moderator
Claim: Why do you think it's a-- let me ask her for clarification, please-- why do you think that that's an example?

### Moderator
Claim: Because I think it changed people's expectation about the government's role in the society. taking much more role and must be much more invasive, and also basically increased people's expectation that it takes-- taxes are bound to go up.

### Moderator
Claim: Okay, thank you. Laura Tyson.

### Scientific Advocate (SA)
Claim: I just need a clarification. The one trillion dollars-- are you referring to healthcare reform? Okay, so what we know about this is that again the nonpartisan Congressional Budget Office has basically determined that that package if put in place will actually reduce the deficit. It will reduce the deficit. Now-- all right. The reason you don't-- No. The reason you don't believe that if you're laughing-- the reason you don't believe that if you're laughing is because you don't believe that healthcare costs in the United States in the private sector are going to slow down, because the only way, the only way we can get control over the federal government's healthcare spending, which is now more than half of all healthcare spending in the United States, is if private healthcare costs slow down. Remember, we're spending three times as much as any other advanced industrial country.

There are lots of other models out there. They're not all socialized medicine. We are doing a lousy job in the healthcare sector.

### Moderator
Claim: Sir, can you come down into the-- where the lights-- we'll be able to see you? About five more steps.

### Scientific Advocate (SA)
Claim: So I think that the one trillion dollars has basically been credited as something that will pay for itself if we get healthcare costs down. And if you laugh it's because you don't think that will happen to our society, and then we're not going to be better off.

### Moderator
Claim: Sir.

### Moderator
Claim: As a lonely citizen--

### Moderator
Claim: Can you bring the mic and start again closer?

### Moderator
Claim: Sure.

### Moderator
Claim: That's great, thanks.

### Moderator
Claim: As just one citizen, is it fair that I have a right to keep more of what I earn or should I be required to give more?

Yeah.

### Moderator
Claim: Well, that's red meat to you guys

### Conspiracy Advocate (CA)
Claim: Well, first of all--

### Moderator
Claim: Enjoy.

### Conspiracy Advocate (CA)
Claim: I think--

### Moderator
Claim: I'll come back to you.

### Conspiracy Advocate (CA)
Claim: --that we define freedom far too narrowly. The question we've been asked is a question about freedom. To what degree should the people be able to keep what they earn? To what degree does a person own and therefore have the right to keep the product of the sweat of their brow? I was always amazed when I was in government at all of the empathy that went to people who were riding in the wagon that were benefiting from government, but no empathy for people that were pulling the wagon. On welfare you can get $17,500 of benefits per child, and under the federal tax code, if you work for a living, you get $1,000 tax credit per child. Shouldn't we give people pulling the wagon the same benefits we give people riding in the wagon?

### Scientific Advocate (SA)
Claim: This is going to be the end of this section, so it's time for your flourish.

End of this section-- this is not the two-minute

### Moderator
Claim: No, no, no, no. But your response is going to conclude our second round--

### Scientific Advocate (SA)
Claim: The one point we haven't raised tonight because we've talked a lot about taxing the rich and we've talked a lot about the past, so I think it's important to know that the last time the income distribution was as unequal in the United States as it was in 2008 was 1928. That the share of income going to the top one percent the top 0.01 percent is larger than it’s ever been in our country and we need to just think about that. Now that goes to the issue and I ended a comment I made before about we need to also think about the fact that now about a quarter of our children live in poverty. This is about the kind of society one wants. It’s not actually about freedom or lack of freedom. It’s about what kind of society one wants.

And I think that if you take the idea if you own your own self, the sort of logical conclusion of that is that nobody makes any contribution to the common good unless they feel like it, unless they feel like it. So that means we’d have no justice department. We’d have no defense. We’d have no education. It would basically be what’s mine is mine and I’m going back to my house and taking it with me. I don’t think that is the notion of what most Americans think is the fair society they want to live in.

## Round 3

### Moderator
Claim: Thank you, Laura Tyson and that concludes round two of our debate and here we are. We are about to hear closing statement from each debater. We are about to hear closing statements from each debater. They will be two minutes each and it’s their last chance to change your minds and after they speak you’re going to be asked to vote once again and to pick the winner, just a few minutes from now. But first, round three, closing statements. Our motion is “Big government is stifling the American spirit,” and here to make her closing statement against this motion, Laura Tyson, a professor at the Haas School of Business at Berkeley and a member of President Obama’s Economic Recovery Advisory Board.

### Scientific Advocate (SA)
Claim: Well I think to a certain extent you’ve heard part of my closing statement. I will just reiterate my main points. I think that citizens look to government to do things. Right now the government has been forced to do more than it normally does because of the crisis. I believe the government will get smaller once the crisis-- we’ve gotten through the crisis but I think it’s important to do that. I think it is important for the government to invest in our future and I’ve made that clear how the government should do that. I’ve noted that we haven’t talked at all tonight about, amazingly enough, defense. Defense. If we really want to make the U.S. government smaller, do we really want to spend 20 percent of the government’s budget on defense and 43 percent of the world’s spending on weapons? Do we really want-- do we think that’s fair? And finally I would say that I do think that we need to, as a society, ask ourselves the question about what kinds of benefits we want, what are we willing to pay for. Because what has happened in the starving the beast mentality is we actually have made the tax base smaller. We don’t tax even at the levels of the Clinton administration, but we’ve made the government bigger. You know, not only did we fight two wars without financing them under President George W. Bush, but we also passed the Medicare prescription drug benefit program. That was more than a trillion dollars. No funding. None. The CBO said that would cost a trillion dollars with no funding. The CBO in the trillion-dollar bill that was just passed said it paid for itself. So where was the big entitlement with no funding? It came under George W. Bush. My point is if we want that kind of benefit, we’d better be serious about how to pay for it because right now, our government is not that big.

It’s not that big. of GDP but we’re funding it--

### Moderator
Claim: Laura Tyson, your time is up and thank you very much.

### Scientific Advocate (SA)
Claim: help from the rest of the world. We don’t want to do that.

### Moderator
Claim: Thank you, Laura Tyson. Our motion is “Big government is stifling the American spirit” and here to summarize his position for this motion is Phil Gramm, a former Senator and chairman of the banking committee, currently vice-chairman at UBS Investment Bank.

### Conspiracy Advocate (CA)
Claim: I believe that government is stifling the American spirit and I believe that we’ve reached a crisis point. When we look ten years into the future and we see government taking almost half of all income taxes simply to pay interest on the debt, this is a future that I don’t want for America. Now we can avoid this future but we can’t avoid it by waiting for somebody else to fix this problem.

We can’t avoid it by taking a poll. We’ve got to have leadership. We’ve got to explain to America what is at stake. And I don’t want to dwell on the past. I was asked about the past versus the future but the past is the only thing we know about the future. When Ronald Reagan became president, people sensed that we had a crisis. We had wasted ten years of economic growth with stagnation, double digit inflation, high unemployment. And we had to make hard decisions. America made those decisions because they believed there was a crisis. I believe there's a crisis today. And more importantly, I believe that Americans believe it. But what they're waiting on is leadership to show them the alternative.

It's just like at the end with the medical analogy, you get sick, you go to the doctor. The options he gives you are often not very palatable, especially if you're very sick. But you do it because you believe that you will get better if you do those things. I believe Americans can show courage and can show sacrifice if they believe that America will be benefited in the end. And that's what this crisis is about.

### Moderator
Claim: Phil Gramm, your time is up. Thank you very much. The motion is “Big government is stifling the American spirit.” And here to summarize his position against the motion, Nouriel Roubini, a professor at New York university Stern School of Business and chairman of Roubini Global Economics.

### Scientific Advocate (SA)
Claim: Is American spirit stifled because of big government? Not at all, because tax revenues today are the lowest level they have been in the last 50 years. 15 percent of GDP. It used to be an average of 20. In Europe, they're around 40, 50 percent. So the problem is not with too much taxes. Is the American spirit stifled because we have a mental recession today? No. We have the worst economic and financial crisis, recession and depression, we've had in the last few decades. And why do we have it? Because we tried twice in the ’80s and again in the last decade an experiment in voodoo economics. Every time they're in power, they pretend that they want to starve the beast, but increase-- instead recklessly reduce tax rates in a way that's unsustainable. They increase massively discretionary spending and military spending. And then because economic and financial crisis, and then they leave a trillion dollar budget deficit to the next administration. It's just a train wreck for somebody else to take care of it. It happened during the Bush-Reagan years of the 1980s. And it took Clinton to raise taxes and reduce the budget deficit and turn it into a surplus.

It happened again with the Bush tax cuts of the last decade that led to the worst economic and financial crisis since the Great Depression. Every time they talk, they blame everything on big government. But the true agenda is different. Every time they pass reckless and unsustainable tax cuts, mostly for the rich, they privatize in good times, that gains them the profits. And after they cause a massive economic and financial crisis, they socialize all the losses and bail out Wall Street. They privatize the gains. They socialize the losses. They don't believe in capitalism. They don't believe in small government. They don't believe in the American spirit. They believe in big government, socialist and welfare for the rich, the well connected and for Wall Street. That's what they do.

### Moderator
Claim: Thank you, Nouriel Roubini. The motion is “Big government is stifling the American spirit.” And our final speaker to summarize his position in support of this motion, Arthur Laffer, chairman of Laffer Associates and a former economic advisor to President Reagan.

### Conspiracy Advocate (CA)
Claim: If I can just start off by looking at the issue at hand here today, is big government stifling the American spirit? I think that at least three if not all four of us agree that that is the case. I mean, I look at Nouriel Roubini, what he's been saying, and it's been exactly what we've been saying. Laura has been talking about the defense budgets and all of that. That is big government. Should we be in Iraq? Should we be in Afghanistan? That's a big government intervention, which doesn't make a lot of sense to me. Should we socialize all the-- no, but I-- hold that. Should we socialize all the losses for these companies? Absolutely not. But you can't have a profit and loss system without losses. For people who overborrowed on their income, for banks that were undercapitalized, if they made a play, and it's wrong, let them lose. Just let it go and let the system work and go.

Government is way too big. Should we invest in a flat rate tax where the government's not meddling in every single person? Yes, we should. We should do all of that. Government is way too big, and it is stifling the American spirit as these two and the two of us all agree. If I can-- You know, I think Phil Gramm, a little story is the correct story. I think his facts are great, but I think you can't have more people sitting in the wagon than you have pulling it. I used to tell my students that if I ran this class like your government runs your country, what I'd do is I'd flunk all the A students out, and I'd give all the F students scholarships. So before you laugh, think about it for a second before you laugh. My A students are a little bit smarter than my F students. So once I changed the rules, my A students are able to get lower grades than my F students because they don't randomly make the mistake of ever guessing a correct answer. The distribution of grades is unchanged, period. There's not one change. But what have I done? I've destroyed the entire quality of the educational process.

You cannot change the distribution of income with taxes. But you can change the volume. Government is too big, and it's stifling the American spirit, as we all agree up here. Thank you.

### Moderator
Claim: Thank you, Art Laffer. And that concludes our opening statements. And now-- now it is time to learn which side has argued best, because you in our audience will make that decision. We are asking you again to push the keypad at your seat that will register your vote. And we'll get the readout on this almost instantaneously. You were asked to vote when you came in, to tell us where you stand on the motion. We're asking you again. And the team that changes the most minds will be declared our winner. The motion is big government is stifling the American spirit. Press one if you are for the motion, two if you are against, and three if you are undecided. And we'll have the results in just a minute. So while that's being tabulated, the first thing I want to do is I want to thank all the questioners and the folks who stood up and gave their opinions.

The questions were terrific, sometime a little tricky to get the questions answered, but I think we worked that out. So thank you to all of you for your questions. Tell me again. Oh, I made a mistake in a line-- just now when the debate ended, and I wanted to say that concludes our closing statements, I said that concludes our opening statements, which was a mistake because it was at the wrong end. And it would help me a great deal if you could do one more round of applause, and I'll get the line right. But-- but--

No, but I need this to be so spontaneous. And that concludes our closing statements. And now it is time to learn which side of the argument fell. Thank you. Thank you to all of you. And I also want to thank our panel. You know, when it suddenly dawned on me that we had four PhD economists, I kind of thought, oh boy.

But no, this was robust and engaged and spirited. And I thank all of you for really bringing your A games to this. So before we announce the votes which are being tabulated, a few things that I want to talk about coming up for us. Our next debate will be very soon. Wednesday, November 10th, the motion is “Afghanistan is a lost cause.” Panelists for the motion are Matthew Hoh. He's a former State Department official. He resigned in protest over U.S. strategic policy in Afghanistan. Also, his partner will be Nir Rosen, a freelance journalist and author of Aftermath, Following the Bloodshed of America's Wars in the Muslim World. Against the motion, we'll have Peter Bergen, who he is the gentleman who filmed Osama Bin Laden's first television interview for CNN 13 years ago. And his debating partner will be Max Boot, a Council on Foreign Relations military historian and a foreign policy analyst and the author of a fascinating book which I have read, called War Made New.

Individual tickets are still available by visiting our website and at the Skirball box office. You can follow Intelligence Squared U.S. on Twitter at twitter.com/iq2us for announcements and for interesting links on our debate topics, and for realtime counterpoint tweets during future live debates. Use @iq2us and tweet what you thought about tonight's results. Make sure to become a fan of Intelligence Squared U.S. on Facebook. And if you do, you get a discount on our upcoming debates. All of our debates, we've said this before, and we're very pleased about it, can be now heard on more than 220 NPR stations across the country. You can also watch these debates on the Bloomberg television network starting next Monday at 9:00 p.m. Visit Bloomberg.com to find your local channel. Intelligence Squared is now one of the most popular affairs podcast on iTunes. And again our congratulations to Robert Rosenkranz for that achievement, crossing that line. Download and listen to past debates at IQ2US. All right. Now it's all in. I've been given the results. Remember, the team that has changed the most minds here is declared the victor. And here it is. Before the debate, 29 percent of you were for the motion, 44 percent against, and 27 percent undecided. After the debate, 49 percent are for the motion, that's up 20 percent, 43 percent against, that's down one percent, we have eight percent undecided. The side arguing for the debate has carried this debate. Our congratulations to them. Thank you from me, John Donvan, from Intelligence Squared U.S. We'll see you next time.
