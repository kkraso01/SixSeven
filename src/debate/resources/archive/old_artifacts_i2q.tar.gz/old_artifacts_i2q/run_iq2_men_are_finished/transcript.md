# Debate Transcript

Topic: Men Are Finished
Motion: Men Are Finished

Debate ID: men-are-finished


## Round 1

### Moderator
Claim: And to launch, with opening remarks that help frame the issue for us, I'd like to introduce the chairman of Intelligence Squared U.S., Mr. Robert Rosenkranz.

### Moderator
Claim: Welcome. Well, "Men are finished," mmm. I for one hope not. But there does seem to be a lot of evidence that we are. Traditional male attributes like competitiveness, aggression and risk taking are discouraged in-- in classrooms and derided in popular culture. As a society, our values seem to be shifting toward the traditional feminine virtues of empathy, cooperation, emotional intelligence. Increasingly, men are not taking the responsibility for parenting, and women are proceeding on their own.

At the top of the cognitive pyramid, women are now a majority in our universities, graduate schools of law, business and medicine. And at the bottom, the high-paid jobs men used to hold in construction have vanished with the financial crisis and those in factories have fallen victim to globalization. Men are overrepresented in prisons and in the ranks of the unemployed. And underrepresented in higher education. Project these trends forward for a couple of decade, and the future looks pretty bleak for men.

On the other hand, and there always is another hand in our debates, men still hold positions of overwhelming dominance as CEOs of our largest companies and financial institutions, as creators of large-scale entrepreneurial successes, the Microsofts, Oracles, Googles, Facebooks, as top elected officials in both the federal and state governments, as the most influential artists and writers, as scientists with breakthroughs worthy of Nobel prizes and on and on.

So where do you come out tonight on this question, are men finished? The answer may depend on how you interpret the question. What we meant but couldn't say in three provocative words, is whether we're at a tipping point where women are likely to achieve in the future the same sort of dominance that men have had in the past, or whether the changes in the relative position of men and women are significant, perhaps, but hardly fundamental. Well, we have an extraordinary group of panelists to help you make that decision, and it's now my privilege to turn the evening over to them, and to our moderator, John Donvan.

### Moderator
Claim: And I'm going to introduce our debaters in turn. And when I say their names, I'd appreciate it if you could applaud for their names. But first I'd like to ask for one more round of applause for Mr. Robert Rosenkranz for making this possible. True or false, men are finished? That's what we are here to debate, another verbal matchup from Intelligence Squared U.S. I'm John Donvan of ABC News. We are at the Skirball Center for the Performing Arts at New York University. Men are finished. Two teams will be arguing that proposition from opposite sides, one for it and one against it. These teams include Dan Abrams, my colleague at ABC News, where he is chief legal analyst and author of "Man Down," which gives proof that women are unequivocally better than men. His debating partner is Hanna Rosin. She is a senior editor at the Atlantic and founding editor of XX, a woman-focused section of the online magazine, Slate. Nothing like a packed house. Opposing them at the facing table, Christina Hoff Sommers. She is a philosophy professor and author of Who Stole Feminism? and The War Against Boys. Her partner, David Zinczenko, executive vice president and editor in chief of Men's Health magazine. Now, this is the debate. It is a contest. One team will win, and one team will lose in this joust of ideas. And you, our live audience here at the Skirball Center will be functioning as our judges. By the time the debate has ended, you will have been asked to vote twice, once before the debate and once again afterwards to register where you stand on this motion, "Men are finished." And the team that has changed the most of your minds in the course of the debate will be declared our winner. So let's go to your preliminary vote.

If you go to these key pads at your seat, they have numbers one through three along the top row. If you agree with the motion, "Men are finished," push number one. If you disagree, push number two. And if you are undecided, push number three. And if you feel that you've made an error, just correct it, and the system will lock in your last vote. And what we're going to do is tabulate those. And at the end of the debate after the second vote, I'll present both numbers. And reminding you again the team that has changed the most minds in the course of the debate will be declared our winner. So our motion is, "Men are finished." And now onto round one, opening statements by each debater in turn. They will be seven minutes each.

And I'd like to introduce first for the motion, Hanna Rosin. She is an award-winning journalist for Slate and the Atlantic. Her 2010 cover story, which was titled, "The End of Men," provoked a fire storm of responses. She is now writing a book expanding on her theory that men are losing their dominance. And as a matter of fact, she went to high school, Stuyvesant, a few blocks away from here where I understand you were a debater?

### Conspiracy Advocate (CA)
Claim: I was a debater, and I'm hoping I can channel that inner nerd tonight and bring it right back again.

### Moderator
Claim: Did-- did you beat the boys a lot?

### Conspiracy Advocate (CA)
Claim: We beat everybody. But my partner was a boy, so I don't know if that counts.

### Moderator
Claim: Ladies and gentlemen, Hanna Rosin.

### Conspiracy Advocate (CA)
Claim: I'd like to welcome you all to this debate tonight. I'd even like to welcome the men to the debate tonight although of course I pity you. Just kidding. Before I dive in, I just want to say-- I just want to start with a definition. What do we mean by men are finished?

We'd like you to think of this as the writing on the wall, as the sign that points to an inevitable future. What I mean by that is that in order to win this debate, we don't have to prove that there are no male geniuses, that there's no more male CEOs, that Bill Gates and Steve Jobs are figments of your imagination or that all the men are any minute going to be rounded up and locked up as-- only to be released every once in a while as sex slaves. That would be-- that would be a preposterous standard. Maybe it sounds good to you guys.

But what we do have to prove, and what we will prove is that the world where men dominate the public sphere and where the male traits are the ones that lead to success is the world that we are currently saying goodbye to.

We are living through an unprecedented moment in history where the power dynamics between men and women are shifting very radically. I'll start with the fundamentals. In 2010, for the first time ever, women became the majority of the work force. This is kind of an amazing fact.

As recently as the 1980s, the working woman was such a cool new sociological phenomenon that there were several sitcoms dedicated to her existence, which many of you might remember. Now she is the majority of the work force. If you look back at your professional schools that you guys went to, law school, medical school, accounting, even business schools, you are likely to find that women are the majority of all of those schools. And last year for the first time, women became 54 percent of all American managers.

Now, how are men doing these days? They're doing very, very badly. The annual income of men peaked around 1973, which is just when women started to get going. Right now, one in five men are out of work, which is the highest percentage that's ever existed.

When Larry Summers was recently asked by the New York Times what keeps him up at night, you would think he would have mentioned the healthcare crisis or maybe the many, many gaps he has made over his long career, but he did not mention either of those things. What he mentioned was this one in five ratio which he described as having vast social consequences.

Now, why is this happening? The very simple answer is college. Most economists agree that what you need to get ahead these days is pretty simple. It's just a college degree. But women, for some reason, are much better these days at getting college degrees than men. For every two men who get a college degree, three women will do the same.

So why are women getting more college degrees? It's not that women are smarter because they're not smarter. These days, men and women test about the same on standardized tests for both math and English. But women have something. Some sociologists call it grit, some call it engagement, some call it focus, some call it social intelligence. It's some special formula that's required for success these days, which women just seem to have in greater abundance than men. And this is a very new thing.

Now, I imagine that our opponents are going to concede that women do better in college. But then they're going to say so what? Women are goody goodies, then they go to work, and they just flame out, and they never get anywhere else. But this is, of course, completely preposterous.

For one thing, it's only been happening for about a generation and a half, and you already see the results in the economy. You already see that for women under 30 these days are making more money than men under 30. And that's really, really new. Also women are getting much more aggressive than they ever were, which is something that's brand new. And also the qualities that we think of as making a great leader are starting to be defined as more feminine than masculine which is something that my partner is going to talk about later.

So now you really have to be blind not to see the effects of this all around us in the culture. We've all gotten used to the new guy antihero or what my friend at Slate calls the omega male who's two rungs below the alpha in the wolf pack. And so we see him in the Judd Apatow movies, we see him in the Bud Light commercials. He's sitting around, putting his feet up, drinking beers, basically not working and not sure what to do with his life, he's still wearing Keds and a band T-shirt even though he's well into his 40s and at an age where men in generations before were already picking their kids up from college.

I just spent the last couple of weeks watching the new sitcoms for the new TV season. The theme for this TV season was called by TV Guide the emasculation of men, and here again you have lots and lots of guys playing videogames while their wives work, sometimes they work double shifts, their wives are working powerhouse jobs, and they're coming home to see their husbands play videogames. One of the guys in the sitcoms, one of the characters decided that he was going to bestow his business upon his granddaughter and not his grandson because his granddaughter had an MBA from Purdue and his grandson as he put it was a jet skiing idiot. So this is the middle class's reflection of itself these days. Now we're on to my favorite subject which is male vanity, the new male vanity. Lose your guts, 30 red hot sex secrets. Dave Zinczenko will recognize these phrases because they come from the cover of his magazine, Men's Health. upon a time men's magazines used to actively flaunt their dominance and aggression. The very first issue of Playboy called women people who crush man's adventurous free loving spirit. These days they seem to flaunt male insecurity. Men are fueling the rise in plastic surgery, hair products, and waxes. If you look at the back at the 1986 Sexiest Man Alive, you'll see Mark Harmon who basically looks like an orangutan by the standards of the day, he's got hair coming out of his shoulders, coming out of his thighs, he's a really big hairy man. These days the men are waxing and primping more than I have ever done in my entire life, as we all became deeply familiar with, unfortunately, when we have the close-up of Anthony Weiner. Now, from my opponents, you'll likely hear a lot of talk about the new generation about how men are still geniuses, men are still inventors, how they drive the technology industry.

I have a few things to say to that. First of all, we're talking about a tiny percentage of men, and they're more than balanced out by the men at the other end who are incarcerated or having trouble in school. It's perfectly possible that we'll have a handful of great inventors and that still broadly speaking men are finished. You're also likely to hear about the Fortune 500 list and at the echelons of Hollywood and how few women there are out there at the top. I hear this argument on nearly every panel that I'm on and my answer is always the same, duh, men have been at this for 40,000 years and women have only been at this for 40 years, so of course the world doesn't flip upside- down overnight. But the writing on the wall is still clear, men are finished, which is why you should vote for us.

### Moderator
Claim: Thank you, Hanna Rosin. "Men are finished" is our motion and now here to speak against the motion I'd like to introduce Christina Hoff Sommers.

She's a resident scholar at the American Enterprise Institute. She is a critic of radical feminism and the author of The War Against Boys and also Who Stole Feminism? Does the answer to that question figure in to the argument you're going to make here tonight?

### Scientific Advocate (SA)
Claim: Oh, actually it does, in Who Stole Feminism I argued against a very ferocious form of male bashing feminism and in favor of a feminism that affirmed friendship and equality and mutual respect between the sexes and I'm going to talk a lot about that tonight.

### Moderator
Claim: All right. Here we go. Ladies and gentlemen, Christina Hoff Sommers.

### Scientific Advocate (SA)
Claim: First of all, men are not finished. Yes, yes, indeed, women are joining men as partners in running the world but they're not replacing them. Women are flourishing in ways which are unprecedented, exciting, glorious. But men have hardly vanished from the limelight.

I mean, after almost 40 years of gender neutral pronouns, men are still more likely than women to run for political office, start businesses, file patents, write editorials, tell jokes. They conduct the orchestras. They direct the great movies. They blow up things. Now, I admit blowing up things is problematic. I wish they would do less of it. Men commit most acts of wanton violence. But, at the same time, it usually takes other men to stop them.

The “males are in decline” crowd seem to imagine a world of consensus-building women, happily and confidently interacting and managing the new economy. They point to an explosion of jobs for nurturers and communicators, more social workers, veterinarians, dance therapists, teachers.

The problem is that you can’t sustain a network of nurturers and communicators without someone paying for it. You’re still going to need ambitious, hard-driven innovators, manufacturers, engineers, construction workers, along with police officers, firefighters and the military. Now, we’re told that toughness and assertiveness, those are obsolete, fit for another age, not the 21st century. That’s absurd. It’s worse than absurd. It borders on being ungrateful and even elitist. It ignores the actions and virtues of the very people that make it possible for us to assemble here tonight and debate whether men are in decline. It reminds me of a quote by-- well, attributed to George Orwell. Orwell allegedly said, “We sleep peaceably in our beds at night only because rough men stand ready to do violence on our behalf.” Well, the world is still dangerous, and our civilization still depends on the protection of brave men and some women who are willing to fight and die to protect us.

Now, Hanna concedes that men are still at the top of the pyramid, but she says, quote, “Men’s hold on power in elite circles is loosening.” Loosening? Yes, of course. I agree. And I welcome it. But it’s not evidence of a female takeover. I mean, just think about it. Women have amazing talents. They can be as dazzling as men when they set their minds to it. But the sexes are equal. But they exercise their equality in different ways. Consider science and technology. Women now hold a majority of college degrees, and they hold most of the jobs in fields like psychology, veterinary medicine, biology. It’s quite likely women are not only going to compete with men but surpass them in these fields and, indeed, very exciting to behold.

They’re just as competitive as men in those fields, if not more. But those numbers don’t hold in other fields. Math, technology, engineering-- those are fields where men prevail by huge numbers. “And give them time,” says Hanna. “Women have only just begun, and that women are in ascendancy. They’re going to gain momentum.” Where is it? I see no sign of it. According to a recent study by the Commerce Department, women’s numbers in computer science and mathematics have actually gone down in the last 10 years. I mean, if Hanna were right, these trends-- we would begin to see women taking over, or at least showing some progress. We see no progress, very little progress in those fields.

Now, ask yourself, is technology finished? Is engineering finished? Is the military finished? Are dangerous jobs like working on an oil rig or being a police officer or a roofer, a logger-- are those finished?

Now, it’s true that minimally educated men are in serious trouble. And I agree very much with Hanna that this is a matter of grave concern. Girls do better than boys in school. They get better grades. They score higher on reading and writing tests. They’re more likely to go to college. The reason for girls’ educational success, they’re complicated and surely have something to do with a complex combination of innate and cultural differences. Teenage girls, for example, tend to pay attention better than teenage boys. But instead of declaring men finished because of their educational deficits, we should be looking for ways to make our classrooms friendlier places for boys and young men, and more conducive to their success.

Why are we even having this debate about men’s demise? The reason is we are living in an era you could call “WAW,” women are wonderful.

It’s a phenomenon that’s been identified by some psychologists. And it used to be fashionable to celebrate men’s superiority over women when women were truly the second sex. Fortunately, those chauvinist days are long gone. Today, a new kind of reverse chauvinism is in ascendancy, female chauvinism. Magazines, TV shows, yes, sitcoms claim, you know, the endless heroics about girl power, "You go, girl," claiming that women are better at everything. Women are better leaders, women are better communicators, all around better human beings. I saw one-story that said women have better orgasms than men. The rules of the WAW game make it impossible for them to-- to win, because if women do something better than men, that's evidence of their superiority. If men outperform women, that's proof of discrimination and the continuing male culture.

What you see tonight on the other side of the stage is an extreme form of the WAW phenomenon. The idea that men are finished is crazy.

Men and women complement each other. We are not separate teams competing for a trophy. This is not a zero sum competition. We're dance partners like Fred Astaire and Ginger Rogers. Our fates are inextricably tied together. If one is in trouble, so is the other. Several years ago the Hasbro toy company manufactured a toy house. They wanted to manufacture-- they wanted to sell it to both boys and girls. The girls came in, and the boys. The girls played constructively with the dolls. The kids took the dolls and played house. The boys catapulted the baby carriage from the roof. And the Hasbro general manager had a brilliant explanation: Boys and girls are different.

I'm almost finished.

I'm almost finished.

Thank you.

### Moderator
Claim: Christina the sum of your time is up.

### Scientific Advocate (SA)
Claim: I'm almost finished.

### Moderator
Claim: I've got to-- I've got to--

### Scientific Advocate (SA)
Claim: I'm almost finished.

### Moderator
Claim: I-- I---- I can't let you. I'm sorry. Thank you very much.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Pleasure. A reminder of what's going on. We are halfway through the opening statements of this Intelligence Squared U.S. debate. I'm John Donvan of ABC News. We have four debaters, two teams of two, who are fighting it out over this motion, men are finished. We have heard two of the opening statements and now onto the third. I'd like to introduce Dan Abrams. He is chief legal analyst for ABC News. He is also the author of a book whose title is a lot of fun to read. It's called "Man Down: Proof Beyond a Reasonable Doubt that Women are Better Cops, Drivers, Gamblers, Spies, World Leaders, Beer Tasters, Hedge Fund Managers and Just About Everything Else." I notice that you don't say women are better legal analysts. Have you raised the bar for men with your performance?

### Conspiracy Advocate (CA)
Claim: No, no, no. There's just the-- the obvious example of the woman who is a better legal analyst. Of course, there's Nancy Grace who's--

### Moderator
Claim: Ladies and gentlemen, Dan Abrams.

### Conspiracy Advocate (CA)
Claim: --my frequent opponent. the heck did Dan Abrams, a far too old to still be single guy, not particularly known as a feminist end up writing a book about female superiority? Did he do it to meet women? Did he-- did he do it to pander? You know, it's always frustrating for me when I'm asked about a single reason why I wrote the book. I did it for both reasons, and it's worked incredibly well. Now, it has not had any substantial impact on my social life, and there is no question that that sort of silliness is what has gotten my book, "Man Down," far more attention than it ever would have received. I made a case based on evidence and men's rights groups and others have attacked me, saying, "He didn't use the scientific method in this book." Look, this book was, at times, a fun, tongue-in-cheek effort. So I separate it into two broad themes, chapters that at least get people reevaluating their preconceived notions and others which I think truly prove female superiority.

Can I definitively prove that women are really better spies or competitive eaters or even they tolerate pain better than men for certain, or even my beloved chapter on women handling breakups better than men? I presented evidence. I presented studies, research. But certainly someone on the other side could attack those chapters. So let's put the frivolous aside and talk about the evidence that examines issues that are important. Hanna talked about women as students. They'll be better educated. They'll navigate tough economies better. They'll be better equipped for the workplace of the next generation. But I don't know. What about politics, finance, taking care of the planet? These are areas where the evidence is crystal clear and maybe just as important the trends for the future support women and also help explain why women lag in certain areas.

Let's start with politics. Women vote more, period, both in number of votes and the percentage of the population. In terms of registered voters in the year 2000, 61 percent of women voted. 58 percent of men. In 2004, 65-62; 2008, with more women on the ballots, by the way, 66-62. Same thing in midterm elections in 2010. 53 percent of those who voted were female.

But wait, they, we are still tending to elect more women-- sorry, more men. Four out of five being elected are men. In fact, in 2010, women gained no Senate seats. And for the first time in 30 years, lost House seats. This is true for now. But once the women voters and the men realize how much more effective female leaders are, it will not-- it cannot continue. Men will be if not finished, certainly marginalized, the very first research has come out this year evaluating men and women in Congress.

The American journal for political science reported this year that from 1984 to 2004 women won their home districts an average of $49 million more per year than their male counterparts. Women sponsored more bills. They cosponsored many more bills. They attracted a greater number of cosponsors than their male colleagues. In addition, two Ohio State political science professors tracked every bill passed between 1981 and 2009 and found that those sponsored by women survived further into the legislative process, received more attention and were more likely to be deemed important overall. And as political leaders and police officers, for that matter-- you mentioned police officers-- women are less corruptible. Two major international studies, one at the World Bank development research group, one from Williams College analyzed data from dozens of countries' parliaments, plus a 93-country survey. They took a count of corruption levels within the countries. They took a count of culture, religion, education. The results were clear.

The more women legislators, the less corruption in a legislature. So what the heck's going on? Why aren't there more women? I think a 2008 Pew research study explains it all. They surveyed 2,250 people, asked them about eight traits key to political leaders and whether they thought men or women were superior. Honesty, overwhelmingly women; intelligence, women; hard working tied; compassionate, outgoing, creative, overwhelmingly women, women, women; ambition, tied. The only one of the eight relevant traits where men were deemed superior, decisiveness. In that same study, though, only six percent of the respondents felt women made better political leaders. Similar results when it came to newscasters. A rigorous study done, male and female news casters reading the exact same message. The participants agreed that when it came from a woman, they viewed it adds more credible. And yet when those same people were asked, are men or women news casters more credible, they said men.

There is only so long men will be able to thrive, much less survive on the fumes of past sexism and assumptions. Now, finance. You don't need to survey the attitude of the people in finance. 2009 and 2010, Wall Street Journal and New York Times published articles entitled, "For Mother's Day, give her the reins to the portfolio" and "How men's overconfidence hurts them as investors." Both presented multiple statistics that men were taking more risks based on less information, buying and selling more often and losing more money. Female hedge fund managers outperformed their male counterparts from 2000 to 2009 according to hedge fund research by a whopping three percent. Business Week reported that when the downturn began, funds run by women lost 9.6 percent compared to 19 percent for men. Yes, women are only a fraction of the hedge fund managers. Maybe they have to work harder to get there. Maybe these are the females who are at the top of the game.

But in the world of finance, numbers should speak for themselves. And all other things equal, anyone who wants to make money out to go with a woman. Finally, new studies show that women are more committed to protecting the planet. They recycle more. They're more likely to be green. They eat less meat. They take shorter trips. In part because they give and follow better directions than men. They take public transportation more. They are also better and safer bus drivers. They save gas by speeding less. They make more eco purchases. Heck, God has decided that men are finished. Between 1995 and 2008, 82 percent of lightning strikes were on men. So bottom line, why are women still lagging in so many areas? Three reasons: Married or unmarried, they're still primarily responsible for childcare; two, they often lack the overconfidence of men; and three, sexism. When number one may not ever change for certain, number two and three will.

They must. And then us men are in big trouble.

### Moderator
Claim: Thank you, Dan Abrams. "Men are finished," that is our motion and now here to speak against the motion, David Zinczenko, who is executive vice president and editor in chief of Men's Health Magazine. He is editorial director of both Women's Health and Prevention Magazine and he's a bestselling author. And Men's Health-- it's about fitness, it's about technology, it's about handling your finances, so if men were going down the tubes, you would have your finger on the pulse of all of these--

### Scientific Advocate (SA)
Claim: We would know, John. Men aren't finished. Dan may be finished. But men aren't finished.

### Moderator
Claim: Ladies and gentlemen, David Zinczenko.

### Scientific Advocate (SA)
Claim: Thank you. Thank you, John, and thank you, Dan. I want you to vote against this proposition, against this misguided motion because it's preposterous.

Men can't possibly be finished because as all of you know, when men are finished, they roll over immediately and go to sleep. That's not happening. Clearly men are not rolling over. Now, they will have you believe that, that is the case. It's not, if anything they continue to do what they have always done, invent new technology-- makes them smarter-- lead nations, build bridges, drive corporations, yes, win elections, and to your point quite sadly, tweet pics of their genitalia to complete strangers. That's true. Nothing's changed.

Now, our opponents are arguing that men have lost their edge, that women now outpace men in both graduate and undergraduate degrees while the world's economy continues to place greater and greater importance on education. And men are certainly falling behind in this regard as you know through the mancession or great he-cession, nearly 78 percent initially of the job losses belong to men, yes. Men make up the largest sector of the unemployed, they are the majority of people in prison, in rehab, the majority of people who ought to be in rehab. And as Jeff Foxworthy might have put it, very few women say as their last words, "Hey, watch this." It's a fact. Testosterone fueled accidents and testosterone fueled illnesses fell men seven years sooner than women.

So how can I concede these points right at the top of this debate and still say you must vote against this measure? It's simple. All of the statistics that my opponents will be citing tonight are indicative of a trend. Women are beginning to catch up to men. But the pace of that progress is inexorably slow. According to the United Nations women perform two-thirds of the world's work, but only earn a fraction of the world's income. Men own 99 percent of the world's property and rule 92 percent of its sovereign nations. Now, I didn't get through all of Freakonomics, admittedly, but these do not seem like winning statistics for that side.

Obviously, the other 150 million American males out there aren't particularly alarmed either. I don't think anybody came through a gauntlet of men protesting the topic of this debate out there burning their jockstraps. Men aren't finished. You have to vote against this motion. Now, what's going on? In part it's the biological drive. There is a women's movement for the simple reason that women are willing to move together more as a unit. Men are rugged individualists. They want to move together probably but they-- none is willing to stop and ask for directions. So that's the way that men are, and we need to move beyond our opponents' assertions that there's something wrong with that.

It may not be true that the male of the species is in fact stronger, braver, or more action oriented in times of crisis, but we are certainly still asked to play an outsize role. It was still men who spent those long weeks in the Chilean mine. It’s still men who make up 90 percent of the on-the-job deaths, performing dangerous tasks at dangerous hours. It was still 343 firemen who lost their lives 10 years ago in the World Trade Center. And while women are clearly capable of heroic actions in desperate circumstances, I personally am in awe of Rupert Murdoch’s wife. We are hard-wired as a species to count on the comforts of masculine leadership. Even women who aspire to become leaders often seem to take on the trappings of masculinity. Consider Sarah Palin who dobbed such masculine traits as wearing black leather jackets, carrying a gun, bragging about how hot her spouse is.

Or Michele Bachmann whose tribute to traditional masculinity includes putting down gays and trying to pretend our daughters are still virgins. Yes, women are making enormous gains in education. They now earn the majority of graduate and undergraduate degrees. And I feel terrible, just terrible, for Bill Gates and Barry Diller and Sergey Brin and Mark Zuckerberg and Tyler Perry and Larry Ellison and Steve Jobs and all the other poor non-degree-holding men who were too busy becoming billionaires to finish their homework. Awful. It’s so tough. It would have been much better-- It would have been much better if they had just stayed at home, stayed in school, taken on their share of the more than $1 trillion in student loan debt, the majority of which now belongs to-- you guessed it-- the fairer sex.

Of course, there’s self-made women billionaires-- Oprah, Martha, J.K. Rowling, imaginative visions shared worldwide. But it’s men who flood the patent offices with their big ideas. And until a woman invents the next Google or Facebook or iPad or bass- o-matic-- the economic inequality between men and women will not be righted in our lifetimes. So, men are driven to achieve power and influence. Men aren’t worried about losing out to women. They’re still too focused on not losing out to other men. That’s why men are not finished. And it’s why you have to vote against this ridiculous proposition.

## Round 2

### Moderator
Claim: Thank you, David Zinczenko. that concludes round one of this U.S. Intelligence Squared U.S. debate where the motion being debated is "Men are finished." All right, so we’re going to move on to round two, and this is one of those times when I would solicit your highly spontaneous applause. Welcome back to this Intelligence Squared U.S. debate. I’m John Donvan of ABC News. We’re at the Skirball Center for the Performing Arts at New York University. Our motion is "Men are finished," and we have two teams debating this motion. We have Hanna Rosin and Dan Abrams arguing for the motion that "Men are finished." They’re saying that as a result of a changing economy and shifting cultural values, men who once, like it or not, were seen as the dominant sex, the bosses and the breadwinners, are now already in a deep slide to number two status. Arguing against them, saying that men are not finished, Christina Hoff Sommers and David Zinczenko. They’re saying that men are doing just fine, thank you, that they still hold most of the power. And besides, just because women are doing better, that does not mean that men have to be doing worse.

We’re in round two where the debaters are going to be able to talk directly to each other and take questions from you and from myself and from readers of Slate who are watching this debate online. And I’d like to start with initially with a question to the side that’s arguing for the motion, and I think perhaps to you, Hanna Rosin. Your opponents are making the case that part of the reason that the notion is afloat, that "Men are finished," is because there’s an attitude about, there’s a sense that women can only be doing better if men are doing worse, that this is a zero-sum game. So is it? Is it not possible for both sides to do well without this imbalance resulting?

### Conspiracy Advocate (CA)
Claim: It is possible, but it just doesn’t work that way. I mean, if we can all agree that there was male dominance for a long time and that male dominance is over, then I think we agree that men are finished. So the resolution is about male dominance which we’ve taken for granted for so many tens of thousands of years.

And so, even if you have parity, you have the end of male dominance. I mean, if you have women rising and catching up to men, then you no longer have male dominance. And so that's what I meant when I, early on, tried to define the resolution as men are finished, the era of male dominance, it's finished, which we've taken for granted for all this time.

### Moderator
Claim: Christina Hoff Sommers.

### Scientific Advocate (SA)
Claim: But the opposite of male dominance is not female dominance. It's mutuality.

### Conspiracy Advocate (CA)
Claim: That's fine. Men are still finished. I mean, men are finished as the dominant sex. I'm not--

### Scientific Advocate (SA)
Claim: They are not finished. That's absurd. You agreed to it in your opening that you didn't want to say men are finished. You thought there might be inklings of a suggestion that it may be happening. But what you're defending now is that men are finished. I'm saying it's absurd. I'm saying that some men are in trouble. But rather than declare their extinction, we should be doing what we can to help them. And that is--

### Conspiracy Advocate (CA)
Claim: Totally.

### Scientific Advocate (SA)
Claim: --not happening in our schools. Our schools are--

### Conspiracy Advocate (CA)
Claim: I'm not saying we should crush them further. I mean--

### Moderator
Claim: Well, let's talk about-- Dan Abrams.

### Conspiracy Advocate (CA)
Claim: You say we need to-- we need to do that in our schools, and yet that's exactly what universities have tried, which is to have affirmative action for men.

It's gotten that bad. And the problem is that the civil rights--

### Conspiracy Advocate (CA)
Claim: Wait. Why are they laughing? This is true.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Schools have affirmative action for men.

### Conspiracy Advocate (CA)
Claim: No, and the civil rights commission actually investigated this, and may investigate it again because the situation has gotten so dire at our universities that we feel the need to discriminate against women. Is that the solution? That's frightening.

### Moderator
Claim: Christina.

### Scientific Advocate (SA)
Claim: The civil rights commission chose not to investigate it. It never happened, but--

### Conspiracy Advocate (CA)
Claim: No, they did investigate it.

### Scientific Advocate (SA)
Claim: They-- they did not. They did not.

### Conspiracy Advocate (CA)
Claim: They-- I know--

### Scientific Advocate (SA)
Claim: However, they--

### Conspiracy Advocate (CA)
Claim: as to why they shut down the investigation and--

### Scientific Advocate (SA)
Claim: It doesn't matter.

### Conspiracy Advocate (CA)
Claim: --believe me--

### Scientific Advocate (SA)
Claim: They shut it down.

### Conspiracy Advocate (CA)
Claim: --you don't want to get into why they shut

### Scientific Advocate (SA)
Claim: Because they did not want to get into it and--

### Moderator
Claim: All right. Let's move forward on the impasse. Let's move forward.

### Scientific Advocate (SA)
Claim: Let's not have an impasse. But if you look at the early grades as how young men are treated in our schools, it's a very girl friendly environment. And boys are not keeping up with-- with the girls.

### Moderator
Claim: But does that mean boys are finished?

### Scientific Advocate (SA)
Claim: We had massive effort-- well--

### Moderator
Claim: But seriously, is that-- is that not-- Christina, is that not indicative of-- of their argument that the system is set up in such a way that males, let's say, are on a bad track?

### Scientific Advocate (SA)
Claim: Males aren't on a bad track.

But our system is rigged against them. And if you look into the average classroom, it's a male averse environment. Schools, for example, now don't allow rough and tumble play. There is zero tolerance for male rambunctiousness. You have schools where they don't allow them to play tag where anyone is out. They have to replace it with games like circle of friends, tug-of-war. Tug-of-war has become tug of peace. This is not-- this is hostile to the interests of young men. And it gets more serious if you look at the readings. A friend of mine at Harvard graduate school of education did a content analysis of textbooks, readers for eighth and-- seventh and eighth grade social studies class. She said you'd think the American West was settled by teenage girls traveling with parents. So male heroes have been taken out. Boys are badly neglected.

### Moderator
Claim: Well--

### Scientific Advocate (SA)
Claim: Now-- just one last point.

We did a lot to help girls and to strengthen them in math and science. At the same time, we did nothing to help boys with their reading and writing skills and their college matriculation--

### Conspiracy Advocate (CA)
Claim: But it seems like you're--

### Moderator
Claim: Dan Abrams.

### Conspiracy Advocate (CA)
Claim: --conceding that men are finished. I mean, what you're doing is you're saying, yes, men are finished, and here's why we need to change it.

### Scientific Advocate (SA)
Claim: I said men are in trouble. That's not the same as saying they are finished.

### Moderator
Claim: David-- David Zinczenko.

### Scientific Advocate (SA)
Claim: I mean, I would just say that--

### Moderator
Claim: David, could you move just a tiny bit to--

### Scientific Advocate (SA)
Claim: I mean, what's happening here is what needs to happen. They are on the ridiculous side of this issue. So they have to attempt to redefine it. If the issue is that the stranglehold on men is coming to the end or men omnipotence is finished, well, two things would be happening. We would be conceding right off the bat that men's omnipotence is finished, and this debate would be taking place in 1962, okay. The fact is that, at this point, we have come to accept a shared power structure between men and women.

And it really doesn't matter. It's not the issue that we're really discussing here, which is why you have to vote against this motion.

### Conspiracy Advocate (CA)
Claim: Wait. What was that phrase you used, surviving off the fumes of sexism? I think we are our finest example there.

### Scientific Advocate (SA)
Claim: Well, I'm--

### Moderator
Claim: David Zinczenko. Oh, you want to concede to Hanna Rosin. I think you scored on that one.

### Conspiracy Advocate (CA)
Claim: I want to make another point about police officers which Christina made a reference to consistently, and I think it's indicative, actually, of the larger issue, which is people like to think, oh, you know, men will be the better police officers because they're bigger and stronger. And if I was out there, and I needed someone, I'd want a big, strong police officer. Well, okay in certain cases. But what if I told you that there is solid evidence to demonstrate that women can defuse a violent situation better than men can? Hmm. Okay. Now instead of having to tackle the guy, you can get the guy to a-- you can avoid a conflict altogether and then avoid taxpayer lawsuits and have less corruption within your police force.

Hmm. Suddenly we're looking at police officers in a totally different way. Does that mean that there's no advantage to being faster or bigger? No. But the number of times in real life as opposed to the movies where people are actually sort of running down across the street to catch the guy jumping over the fence is actually pretty far-- you know, it's pretty rare.

### Scientific Advocate (SA)
Claim: All right, well--

### Moderator
Claim: Christina Hoff Sommers.

### Scientific Advocate (SA)
Claim: First of all, don't trust Dan and-- and his statistics. He is-- he has a fairly serious case of--

### Scientific Advocate (SA)
Claim: And he's a columnist for Men's Health magazine. He has the hardest time getting his pieces through our fact-checking department.

### Scientific Advocate (SA)
Claim: Dan--

### Scientific Advocate (SA)
Claim: He is so fired, yeah, yeah. It's ridiculous.

### Scientific Advocate (SA)
Claim: Did you not say-- didn't you not claim in your book that women have better physical endurance? Did you not claim that women could take pain better than men?

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: Both of these things are false. There is a vast library of literature--

### Conspiracy Advocate (CA)
Claim: Childbirth. Childbirth. Childbirth.

### Scientific Advocate (SA)
Claim: Epidural, epidural, invented by men.

### Conspiracy Advocate (CA)
Claim: Yes. Sorry. What's the question?

### Scientific Advocate (SA)
Claim: Endurance, physical endurance.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: You think that women have better physical endurance.

### Conspiracy Advocate (CA)
Claim: That's that there is an advantage that women have with estrogen and fat that provides them an advantage--

### Scientific Advocate (SA)
Claim: Fat?

### Conspiracy Advocate (CA)
Claim: It's true, yes. It's true.

### Scientific Advocate (SA)
Claim: I rest my case.

### Conspiracy Advocate (CA)
Claim: It allows--

### Scientific Advocate (SA)
Claim: I rest my case.

### Conspiracy Advocate (CA)
Claim: It allows women to engage certain endurance activities better and longer than men. That does not mean they're faster.

### Scientific Advocate (SA)
Claim: Name one activity.

### Conspiracy Advocate (CA)
Claim: I'll tell you one. In the-- in the ultra marathons is the only race where women can beat men, okay? This is--

### Scientific Advocate (SA)
Claim: Don't clap. He's just wrong. He's got to be--

### Conspiracy Advocate (CA)
Claim: It's not true? Am I making it up?

### Scientific Advocate (SA)
Claim: You are making it up.

### Conspiracy Advocate (CA)
Claim: --that a woman won the ultra marathon. It's the only sport where men versus women, that women-- I didn't say always win. Women can win.

### Scientific Advocate (SA)
Claim: Oh, one woman won in the Mojave Desert a couple of years ago.

### Conspiracy Advocate (CA)
Claim: But wait a sec. Wait a sec. There's a--

### Scientific Advocate (SA)
Claim: There's a huge record--

### Conspiracy Advocate (CA)
Claim: --fact that a woman beat a man in an athletic competition is unheard of.

The bottom line is men are still better athletes than women. Men are stronger than women, and they're faster than women. But the one area where women can compete is in areas where it requires excessive endurance. And these ultra marathons are 135 miles plus.

### Scientific Advocate (SA)
Claim: Just to stop this discussion, there's some very good articles that have come out in recent years. Just look at Richard Coast at Northern Arizona University who did a definitive study to undue this myth that was born in the '90s where they predicted women-- it came in Nature magazine. They predicted women were going to win the marathon in 1998. It came and went. Women didn't win.

### Conspiracy Advocate (CA)
Claim: They're not going to win the marathon. They're not. The bottom line is men are--

### Scientific Advocate (SA)
Claim: And they're not winning the ultra marathon.

### Conspiracy Advocate (CA)
Claim: No, it's not true.

### Scientific Advocate (SA)
Claim: And what Coast and other experts say is the longer and the-- the test of endurance, the greater the gap favoring males. You've just got it wrong. You've got your facts wrong.

### Conspiracy Advocate (CA)
Claim: It's not wrong. The reality--

### Moderator
Claim: All right. We're going to move past on that one. Okay. What about billiards?

### Conspiracy Advocate (CA)
Claim: Sorry?

### Moderator
Claim: Billiards.

### Conspiracy Advocate (CA)
Claim: Oh, billiards. Billiards, yes.

### Moderator
Claim: Christina, I want to put a question to you-- a question to you.

You-- you talked about fields where men's, I would say, brawn is relevant; firefighters, the people who protect us, soldiers. You mentioned loggers. And-- and they're kind of creating a world where they're saying it's-- it's more important now to be a blogger than to be a logger, that-- that there is-- that it's a Facebook world, and the Facebook world works better for women in many different ways, the social skills, et cetera. So I just wanted you to take on that notion that structurally we're changing so that the relevance of female characteristics to the economy, their economic value has become enhanced, while male so-called characteristics, brawn, for example--

### Scientific Advocate (SA)
Claim: I don't disagree with Dan or Hanna that there-- there's a female ascendancy which I find as exciting as-- both as a woman and grandmother of Eliza.

I like to see these opportunities for women and women moving into centers of power. But again, I insist that what they're doing is forging a partnership with men in running the world. They're not taking over. And-- and women are men are equal but different. And I think women are dazzling but in different ways. And so if I had been allowed to finish when I was up there instead of--

### Moderator
Claim: Now-- now you--

### Scientific Advocate (SA)
Claim: --only a woman was not allowed

### Moderator
Claim: No, no, now you've got that moment, so I would take it.

### Scientific Advocate (SA)
Claim: When I talked about the boys and girls with the doll house, and the boys catapulted the baby carriage from the roof, even when-- when men and women get older, there's this complementarity. We still need the catapulters. We still need the nurturers. Typically if a parent-- you know, a father and mother go to a park with a child and there's a jungle gym, the mother will say, "Be careful." The father will say, "Can you get to the top?" I think that we need both the nurturers and the catapulters and that the idea that we're going to have one over the other is unknown and can--

### Moderator
Claim: But the notion that the-- that so-called feminism qualities which would include what, Hanna, become more relevant economically?

### Conspiracy Advocate (CA)
Claim: You know, I'm so reluctant to enter this WAW women are wonderful-- how do we say it-- debate? I mean, I don't know that women are particularly awesome, like when I enter this bloggers versus loggers conversation, this isn't a value judgment like loggers are losers, it's not the-- that's not the motto--

### Moderator
Claim: The loggers are going to be so relieved to hear you.

### Conspiracy Advocate (CA)
Claim: Loggers are not losers, we'll make the T-shirt after this debate, that's not what our side represents, it's just that they're an incredibly shrinking part of the American economy. It just is. It's really not a value judgment; it's like whatever it is that women have-- you know, people have called it so many things. They've called it grit. They've called it emotional intelligence. They've called it focus. Nobody really knows what it is. Some people try to say, like, oh, it's in the hardwiring of the brains of women. I'm not sure it's in the-- it might be that women have been behind all these years and now they're catching up the way immigrants do, it might be that, but it's just an economic fact that whatever it is

I just have a question for Hanna--

### Moderator
Claim: David, and then go--

### Scientific Advocate (SA)
Claim: Well, if you look at all of the relevant stats, what you see is this is not the case, that when you look at concentrations of wealth, when you look at poverty in the United States and elsewhere, the deck has been stacked against women. That is not good. We need more gender equality. But in their world they have to twist what this debate means. And the fact is if men adjust to the work life realities, they are emasculated and feminized and therefore they lose. If they don't adapt to the new reality, men are emasculated and unnecessary and irrelevant and antiquated, and they lose.

So I think women can become CEOs, they can become stay at home moms, they can be considered masters of the new universe, and it is easy to structure in your mind the decline and fall of men when in your own mind when all the rules are stacked against your opponents, but here in the real world there is no truth to the facts.

### Moderator
Claim: Well, let me put the questions here aside then, in this-- we're talking about a process and we're talking about possibly being in the early stages of the process of male loss of dominance to women, so what is the endgame? Thirty years from now if this process continues and accelerates, where are men as you imagine it, I mean, are we all wearing diapers in a closet somewhere or-- where are we in the picture if this continues?

### Conspiracy Advocate (CA)
Claim: Where did the diapers come from?

### Moderator
Claim: Infantilization.

### Conspiracy Advocate (CA)
Claim: I get it, infantilization, well, I mean, you want to talk about the saddest part of this? When you guys say something like "logger," you make it sound like it's a very tiny minute percentage of the population.

We're actually talking about 60 percent of the population that's not college educated, okay? So you keep mentioning Bill Gates. This is the American middle class, okay? You tap into the American middle class, I've done a lot of reporting on this issue, it is actually sad. I mean, you see that women are holding up these families, they're in community colleges, the men are struggling, and for some reason they're not getting the message that they have to go to school. So I think we can be in one of two different places. The men could start getting the message that they have to retool themselves, that the factories that their fathers worked for are not going to be there anymore and that they have to do something different, and then we'll end up in a situation that's closer to parity.

Or you could end up in a situation where it gets worse and worse and worse and the income-- you know, you have a sort of little upper class of people that these guys are talking about that consists of Bill Gates and maybe the people in this audience and not very many more people and everybody else is sort of struggling with the women holding the bag, it's called the last bag theory where the woman because she's raising the child is also going to school and making the money and the men are just sort of struggling and out of work.

### Conspiracy Advocate (CA)
Claim: I would just add to that, the bigger problem I think for men is the unwillingness to take what have been viewed as classically female jobs, teachers, nurses, or healthcare professionals, et cetera, and that's the area where if you want to talk about how do we make this better, how do we end-- how do we reverse men being finished, which they are-- how do we reverse that? Well, part of it has got to be that men are going to have to start accepting some of these jobs that have not been classically viewed as male. And I mean think about--

### Scientific Advocate (SA)
Claim: Oh, may I say something that I--

### Conspiracy Advocate (CA)
Claim: --think about the Ben Stiller movie where he plays a male nurse, right, and everyone's like well he's a male nurse, ha, ha.

### Scientific Advocate (SA)
Claim: About six miles, seven miles from here is a high school called Aviation High School, and it's got 2,000 students approximately, you go into that school, whereas at most schools, kids are detached and not paying attention, at Aviation they are enthralled.

You walk into that high school and you think all the kids are gone because it's so quiet. It's the quietest place in New York City. It's there the kids have to do academic courses, but they can spend half the day working on airplanes. They build mainframes and so forth. Now it has one defect. It’s 87 percent male. And so the women’s lobby in Washington has put it on a hit list. Aviation High School has one of the best graduation rates. Most of the kids going there are from-- their African American and Hispanic kids living under the poverty line, and their chances of graduating are vastly higher than in any other school, very high college matriculation rate. That is a school that is working, but it now more likely to be investigated rather than replicated. People come to study this school from Finland and Ireland, but in the United States they’re more likely to be visited with a Title 9 lawsuit because we’re not helping young men find jobs that they might find interesting and be suited for.

The-- and I’m not talking about feminists. Feminists are-- in my book, I talked about lots of different styles of feminism, and they’re not in favor of this. This is the Women’s Lobby in Washington, which is carried away with a very hostile agenda and working against helping young men. That’s the problem. Young men aren’t getting the help.

### Moderator
Claim: But how does that not help their argument?

### Conspiracy Advocate (CA)
Claim: Yes, yes, because what Christina is saying is proof--

### Scientific Advocate (SA)
Claim: --the system is rigged against them. They haven’t been defeated.

### Conspiracy Advocate (CA)
Claim: Yes, because they’re finished.

### Moderator
Claim: No, no, no. Christina, finish-- let Christina finish the point.

### Scientific Advocate (SA)
Claim: No, to say that the system is rigged against them is not to say they’re finished. It’s saying they’re operating under a very severe handicap. And instead of using all of your creativity and energy to argue for this absurd proposition that men are finished, you should be doing something to alleviate the problem that’s leading to their struggle.

### Conspiracy Advocate (CA)
Claim: Well, acknowledging that this true would be the first step to helping them.

It wouldn’t be that, you know, we would want them to be down--

### Scientific Advocate (SA)
Claim: Look, if men are finished, we’re all finished, so let’s not go there.

### Moderator
Claim: David Zinczenko.

### Scientific Advocate (SA)
Claim: Well, I-- you know, I was just going to add that it’s kind of silly too to say that men will need to learn how to adopt female characteristics to survive, whether it’s moving into jobs like interior decorating or health care providing or these counselors. I mean, I think that Sigmund Freud and Nate Berkus and Dr. Christian Bernard would disagree with the assertion. The guys are moving too--

### Conspiracy Advocate (CA)
Claim: The men will be unemployed. I mean, it’s a simple choice. They will remain then unemployed.

### Moderator
Claim: In a world where men do, say, fill the positions of school teachers and nurses such as they don’t now, in the vision that you’re saying would be the solution, would they still be dominant?

### Conspiracy Advocate (CA)
Claim: Well, look, the bottom line is dominance. How do we define that? I will tell you that health care will become a dominant industry. It’s becoming-- it already is-- but it’s becoming an even more dominant industry in our country and in our world.

If men are simply saying “I’m not playing in that industry,” and women are saying “I’ll play in any industry, I don’t care what it is. I’m going to do what it takes to make it work,” then men are going to be at a distinct advantage and are going to remain finished.

### Conspiracy Advocate (CA)
Claim: But this also gets to the heart of the problem. I mean, historically what’s happened is that women have operated pretty flexibly. They’ve gone in a very short period of time from not being able to work when they were married to not being able to work when they had little kids, to being able to work whenever they wanted in a vast number of professions. I can name a number of professions that have gone from entirely male to entirely female. And you can’t name any that have gone the other way around. Why? Because men operate in a narrower range at this point in time. That doesn’t mean that they always will, but at this point in time, they’re just not that flexible about their identities.

### Moderator
Claim: Okay. I want to come to the audience for questions shortly, but first I want to mention this, as I mentioned before.

We’re very pleased to have Slate as our media partner, and they’re streaming this debate-- thank you. And they’re live streaming this debate on their site, and we have a question from a William Nitrous of New York City who I’m going to slightly paraphrase. He’s saying is this just a natural consequence-- I’m thinking what he means to say is this perception that perhaps men are finished, is it just a natural consequence of the assumption of superiority among men who, unlike females, didn’t have the pressure of needing a college degree to succeed? And the more interesting part of his question, he says, “Does this apply outside of America?” So I want to put to both sides the cultural aspect of that question. To what degree are we talking about an American phenomenon here and to what degree is it more global?

### Scientific Advocate (SA)
Claim: Well, men are languishing academically throughout the world. In most countries in Europe, far more women go to college-- I mean, more women go to college than men in Iran, so it’s not only the United States.

But what’s true is that the United States, we’re having a hard time finding ways to help young men.

### Moderator
Claim: Hanna Rosin.

### Conspiracy Advocate (CA)
Claim: Men are languishing in all countries of the world.

### Scientific Advocate (SA)
Claim: Academically.

### Conspiracy Advocate (CA)
Claim: Academically, their language--

### Scientific Advocate (SA)
Claim: Oh, no, no, not politically, no way.

### Conspiracy Advocate (CA)
Claim: Well, what-- you know, so here's an interesting statistic. So we always think-- male preference is something that comes up a lot. You know, preference for the first born son. One of the first things I did when I started this research was, on a lark and a tip, I went to go visit fertility clinics because, you know, we all understand that people prefer sons. And it turns out that, no, 75 percent of couples are actually requesting girls. So then I started to ask, well, is this true in these very patriarchal places like South Korea, China and India? Well, you look at the charts, and here's what happened. At some point, technology allowed them, you know, to easily choose a son. And then by the mid '90s, this plummeted. Women started to go to school. Women started to get jobs that they could never have before. And all these strict patriarchal structures started to break down. So you can see all over the world that different things are happening.

I mean, China, for example, has a higher percentage of female CEOs than the U.S. does. Why? I think it's because childcare is easier. I think it's because families take care of children. There's all sorts of reasons why culturally that's true.

### Moderator
Claim: Chinese men finished?

### Conspiracy Advocate (CA)
Claim: Eventually.

### Moderator
Claim: Okay, let's go-- no, take it, Christina, go ahead.

### Scientific Advocate (SA)
Claim: I’m sorry, do you think that Americans prefer to have female children?

### Conspiracy Advocate (CA)
Claim: Well, the difference is when you poll them and ask them what they want, they say we want a son. When they actually choose, they choose girls.

### Scientific Advocate (SA)
Claim: It's amazing. This is the consistent theme again--

### Scientific Advocate (SA)
Claim: No, no. Wrong, wrong, wrong, because she's overlooking something. When they actually choose, you're talking about women who go to fertility clinics.

### Conspiracy Advocate (CA)
Claim: But that's the only place that keeps statistics.

### Scientific Advocate (SA)
Claim: But-- but--

### Conspiracy Advocate (CA)
Claim: Fertility clinics have to write down for the FDA exactly what everybody else-- exactly what everybody does. And they keep the only reliable statistics. I mean, you can ask them, well, what do people want, and they'll say a certain thing. But--

### Scientific Advocate (SA)
Claim: But it's mostly--

### Conspiracy Advocate (CA)
Claim: --it's not recorded.

### Scientific Advocate (SA)
Claim: That's kind of-- that's led by women and slightly older women and the Gallup Poll kept records for-- since 1941, and you found a distinct preference for males.

It hasn't changed since 1941.

### Conspiracy Advocate (CA)
Claim: That's what people say. It's just not what they do.

### Moderator
Claim: Okay. But let's go to the audience for some questions now. What you do is, if you raise your hand, I'll find you. Wait until-- please stand up. A microphone will be brought to you. Hold the microphone about a fist's distance away from your mouth so that the radio can hear you. And identify yourself. And if you're part of a relevant organization, you know what I mean by that, or news organization, please let us know. We'd just like to know that. And please make it a question that's terse, focused and on topic and that has a question mark at the end. You didn't have to sit down because I was making that long speech.

### Moderator
Claim: Hello. My name Alicia Bonner, and I am a graduate of a girl's high school, a women's college. And I earn a percent more than my fiancé. I am interested in a couple of the things that David and Christina posed and hearing, Dan and Hanna, your responses.

David, you spoke about financial inequality and how-- whatever, 92 percent of the world's resources are in the hands of men and X percent of the countries in the world are governed by men. Christina, you seem to allude to the fact that anything that women are able to do, it's because men are there to earn money to fund it, which I think might be a little bit more problematic. But Dan, you also mentioned that people on the whole--

### Moderator
Claim: Could--

### Moderator
Claim: I'm getting there.

### Moderator
Claim: --focus it to a question shortly.

### Moderator
Claim: The-- the-- they say that, um, you know, they say, yes, I like the way women sound, but I like male news casters better. How do we overcome this, yes in the middle class, you know, women-- women are holding the bag, as you say. But at the upper level, at the most visible levels, and if money talks, when is that power going to lie with women?

### Moderator
Claim: Yeah, take it, Dan Abrams, first.

### Conspiracy Advocate (CA)
Claim: I think that eventually the results are going to speak for themselves.

When people start thinking about and hearing about and learning about how much more effective female political leaders are, for example, I think that there will be a change. People will vote differently. Remember, when people say to me, well, why are there so many-- look, women should be blaming themselves with regard to voting because women are the majority of the voters out there. But what's interesting is, when you get more female candidates, you don't necessarily get a change with regard to the voting habits of women. So the answer to your question, is I think when it comes to newscasters, when it comes to political leaders, and I think in a lot of these other areas, in finance, I think that ultimately the results will speak for themselves. And that's part of the reason why I think this proposition of men are finished-- you know, while certainly hyperbole, if you look at the results, it's a dangerous world upcoming, not today, a dangerous world coming for men.

### Moderator
Claim: Other side?

David?

### Scientific Advocate (SA)
Claim: I mean, I think buildings are always going to fall down. Things are going to burn. You're always going to need men to get in there and do the dirty jobs, do the dangerous jobs. The world is becoming more dangerous than ever. I think that a lot of the leaders of the world as we discussed are men. And I think the-- you have to get the country running right here first. You have to focus on health and wellness. I think that universal healthcare is a step in the right direction. Men and women are partners. And once that happens, but it's a long ways away right now, you're right, it's 16 percent of women are in Congress. 16 percent of women are serving on the board of corporations. So there's a lot of work that needs to be done.

But we have to do it together. And that's-- and we have to do it here first.

### Moderator
Claim: Okay. Sir? You're holding two fingers up. Yep.

### Moderator
Claim: To Dan and Hanna, even as women take over, if you will-- and I agree the trends are there. There's no question about it-- wouldn't there be inevitably a sort of market adjustment whereby men will learn from women how to be better CEOs, how to be better political leaders, better administrators, better members of society and that ultimately, it won't mean that anybody's finished, but that there will be a balancing and an improvement.

### Moderator
Claim: Christina, why don't you take that first, and then we'll come to the other side. Christina Hoff Sommers.

### Scientific Advocate (SA)
Claim: Yes, I don't disagree that there is going to be transformation. This debate is not about whether or not we're in a period of transformation and men's and women's roles are changing. Of course they are.

So I'm not contesting that. What I'm contesting is this very aggressive, dramatic resolution, defended by my colleagues that men are finished. So I pose that. But as far as men improving, I think they will. I think--

### Moderator
Claim: Hanna Rosin.

### Scientific Advocate (SA)
Claim: --they always have had-- face challenges and-- and hard times and overcome them, and they will do the same now.

### Moderator
Claim: Hanna Rosin.

### Conspiracy Advocate (CA)
Claim: That's the best-case scenario, and that's what I wish would happen. However, like I said, there's just all this evidence that men don't respond that well and are not that flexible. People, like she says, people have measured things for many, many years about male preference. People have measured male feelings about male identity. Now, female feelings about what's okay as a woman, and people have measured this for college students and adults have changed radically. Women now think it's much more okay to be aggressive in the workplace. It's much more okay to win. They ask a series of questions. The male identification hasn't-- self-identification hasn't changed basically in 60 years.

Men always think it's only acceptable to be a guy in this tiny, narrow range. And they're always defining themselves against women, not towards women, where women are always doing the opposite, which is they're defining themselves as more aggressive, competitive, et cetera. Why? I don't know why. I don't know if that's biology or what. But that's just how it is. So we would hope so, but we don't know.

### Moderator
Claim: Sir, right in the aisle there. And I just want to mention that if you're in an area where you can't see the numbers on your wristwatch, I can't see you because you're-- the lights aren't bright enough. So that if you are in that area where it's darker, and you want to ask a question, if you could move down, I might have a chance to find you. Sir, go ahead. Can you identify yourself?

### Moderator
Claim: My name is Aaron, and the group that I am a part of is men with a bachelor's degree. That's the relevant group that I'm a part of. Bachelor's degree, by the way, may be overdue for a name change. But--

### Moderator
Claim: I can't believe we never thought of that before.

### Moderator
Claim: I think you deserve a round of applause for that.

### Moderator
Claim: Wow. I wasn't planning to start the standup comedy till next week. I look at this, I see a man and a woman-- a man and a woman, but one style of debate here, one style of debate here. And I'm-- and it just seems that men are finished is just an unfortunate title since both groups seem to be saying it's more about traits. And so my question is, is it-- could it be more men who have more feminine traits, who-- or traditionally feminine traits, who are succeeding. And I'm thinking of people like Bill Gates or Mark Zuckerberg, and are succeeding for that reason. Could they then potentially reverse the trend and be more successful than women because there are the--

### Moderator
Claim: What are the feminine traits, though, that you would have in mind?

### Moderator
Claim: Well, I'm just-- what they've been saying, that women pay attention more, they're more patient, they're better at certain things.

### Moderator
Claim: Okay. All right. I hear your question then.

Why don't we take it first to Dan Abrams.

### Conspiracy Advocate (CA)
Claim: Just so I understand, what-- do I--

### Moderator
Claim: I think your question is, if more men could be more like women--

### Conspiracy Advocate (CA)
Claim: Yeah, look. There's-- no, no, no, no.

That's actually a fair point.

Look, I'll take that serious. I don't mean You want to ask anything else?

### Moderator
Claim: Well, I--

### Moderator
Claim: No, no, go ahead, just take it then because--

### Moderator
Claim: It's not men acting more like women just because they want to act like women or learning to act like women, it's men who do by nature-- like I feel like people told me that I have traits that are more like a woman personality-wise, not physically and my voice--

### Conspiracy Advocate (CA)
Claim: Not your hair, it's not your hair they're talking about.

### Moderator
Claim: --but just a matter of-- and men are already in the positions of power and then men in positions of power who want to keep men in power change the rules of the game or in some way-- but ultimately yes, men with more feminine traits succeeding because people are embracing more feminine traits, okay.

### Conspiracy Advocate (CA)
Claim: I'll say this, that in the world of finance there is a clear recognition that the traders need to behave more classically female, meaning that they are now being trained at many classically male financial firms to engage in behavior, consensus building, less of the sort of typically male buying and trading like crazy, taking risks, and becoming a bit more risk averse, et cetera, to improve long term performance. Again, getting back to some of the statistics that I laid out, that's as a result of risk aversion, now, that doesn't-- that means if you're going to swing for the homerun every time, you're going to hit that homerun more often and you're also going to strike out more often.

And yet if you behave more in what is viewed as classically female, more risk averse, you're going to end up with more-- and to use the sports analogy-- singles, doubles, and triples, and as a result have better returns, so just--

### Moderator
Claim: David, do you want to respond to that?

### Scientific Advocate (SA)
Claim: I think you're a superior human being who is adapting, that's exactly what's going on. You are adopting certain traits that will help you survive and excel. There is nothing wrong with that. What is unfortunate is the argument cannot-- of women gaining traction, which they're trying to make this about, is not what in fact the debate is about, which is men aren't finished. And--

### Conspiracy Advocate (CA)
Claim: Right, I was talking about surpassing them, not equaling them, surpassing them.

### Scientific Advocate (SA)
Claim: Yes, and maybe-- look, I can sit here and talk about the ratio of college-educated men to women in Birmingham being 13 to 17 and in Oakland 11 to eight, we can talk about stats all day long.

But if you come back to the facts, the main facts when it comes to how wealth is distributed, the fact that men are still earning more than women, that they're still running boards, running countries, inventing new technologies, you are in a situation where men aren't finished, and that's why you have to vote against this motion.

### Moderator
Claim: Yeah, right there with this-- yeah, I'm looking right at you. And just wait for the mic.

### Moderator
Claim: Something for Dave and then one question for the panel, but you mentioned that men still hold the majority of resources, 99 percent and they run 92 percent of the countries, do you honestly think that's because they're more competent? I mean, why do you think that is? Do you think it has something to do with deeply rooted structural patriarchy that's been enforced through violence over the past 40,000 years, like-- and then one more question for the whole panel--

### Moderator
Claim: Wait on that one because--

### Moderator
Claim: I'm sorry

### Moderator
Claim: --because nobody will remember the two, and that was a pretty good one.

### Moderator
Claim: It's a quick one, it's just--

### Moderator
Claim: No, hold off, I'll come back to you for the second one and-- but let this one go and then-- but I'll come back. Go ahead, David.

### Scientific Advocate (SA)
Claim: Yeah, look, I think that men have had an enormous head start. That's what I'm arguing. I am for gender equality. I am just saying men aren't finished. You know, and I--

### Moderator
Claim: And that's why you have to vote against the motion.

### Scientific Advocate (SA)
Claim: And that's why you have to vote against the motion. We have to stay very focused here. And look, I think one of the things-- so men have had a tremendous head start, that's worldwide, the gains they've made, certainly women have made enormous gains and will continue to make them, and we should support all of them, but it's not what we're debating here tonight. And it's funny the point that Hanna made about Men's Health as a lose your gut type magazine.

Well, let's get back to that for one second, okay? This right here is the world's leading women's magazine, okay, right here.

### Moderator
Claim: For the radio audience, tell us what you're holding up right now.

### Scientific Advocate (SA)
Claim: This is “Cosmopolitan,” okay, which just happens to be the world’s leading women’s magazine. I think they’re in like 97 countries or something. Left side, naughty-- 21 naughty sex tips, bold breathless moves.

### Conspiracy Advocate (CA)
Claim: Wait, so why do you want to be like that?

### Scientific Advocate (SA)
Claim: Shrink your inner thighs in six minutes a day. Times he wants you to be jealous. Four words that seduce any man any time. This magazine is concerned-- it seems like women are concerned a lot with men, okay. Then we go over to a magazine like “Men’s Health,”-- also happens to be the world’s largest men’s magazine.

And now, here you have gym-free abs--

### Moderator
Claim: You know this is a non-profit organization.

### Scientific Advocate (SA)
Claim: Get ripped workout, you know, Torn to Shreds: The Untold Story of the Afghanistan War.

### Conspiracy Advocate (CA)
Claim: So why don’t we-- we’ve just proved that men are obsessed with themselves, and women are obsessed with men.

### Moderator
Claim: I’m sorry, women--

### Moderator
Claim: Let me come back to your second question and make it very short because I’d like to move on to--

### Moderator
Claim: go back, this whole conversation also has been very binary between men and women. And I was curious, for everyone and maybe for Hanna who’s done so much on-the-ground reporting, also, where like gender non-conforming people and trans people fit into this conversation?

### Conspiracy Advocate (CA)
Claim: Well, they-- you know, I mean, one thing that we all wish for is for men to accept a broader range of self identities. So in the sense that, you know, it’s much more acceptable to be gay now, no, there’s no problem with being gay. You know, gay people can get married, they cannot get married, that maybe holds up a world in which it’s okay for a wide range, like it’s okay for a guy to be a stay-at-home dad.

There’s a new sitcom about a guy who’s a stay-at-home dad and maybe you should watch it, you know. Maybe more guys will become stay-at-home dads. So you don’t have to feel like super self-conscious if you’re a guy whose wife, for example, makes more money than you do, which is a-- which is now almost 30 percent of the population, which, again, was unheard of only, you know, 20 years ago is now fairly common. And you don’t have to like slink away in shame if that is you.

### Moderator
Claim: Okay, I need to do another radio break, so I’d just like to ask you to applaud again, and I’ll come back and-- So we are in the middle of a question and answer section of this Intelligence Squared U.S. debate. I’m John Donvan, your moderator. We have four debaters, two teams of two. And they are debating this motion, "Men are finished." And I want to do one more time without the applause to give them that option.

So we’re in the middle of the Q and A section of this Intelligence Squared U.S. debate. I’m John Donvan of ABC News, your moderator. We have four debaters, two teams of two, debating this motion, "Men are finished." So let’s go to another question. Sir, you’ve got a white card in your hand.

### Moderator
Claim: Thank you.

### Moderator
Claim: But one thing I want to say.

The two-part questions are driving me nuts and long, long premises are driving me nuts, so just write out the question. Thanks.

### Moderator
Claim: It’s very brief.

### Moderator
Claim: Okay.

### Moderator
Claim: My name is Jay Searson I’m one of the few men in that own- your-own-company, entrepreneurial category, so I’m not finished, I think. So I’d like to point out, Ms. Rosin, your whole point seems to be, you know, you’re arguing that what we have now is the beginning of a trend. So, suppose that just before Tom Edison invents the light bulb, all the candlestick makers are Irishmen. After Edison invents the light bulb, all those candlestick-making jobs go away, and things look pretty bad for the Irish. But nobody would say that it’s the end of Irishmen. It’s the end of candlestick makers.

And we’ve just had a housing bubble that eliminated a ton of construction jobs. And those construction jobs were overwhelmingly male because men actually had a genetic advantage doing construction. It requires heavy lifting.

### Moderator
Claim: Okay, okay, okay.

### Moderator
Claim: So why is it a trend--

### Moderator
Claim: One more sentence from your mouth and have a question mark at the end. Because you’ve got a good point, but focus it.

### Moderator
Claim: That’s the question. Why is it a trend?

### Conspiracy Advocate (CA)
Claim: I think I got it. I got it, I got it.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Okay, so in the first recession, that’s what we thought. We thought, “Oh, it’s just the end of construction jobs.” And then in the second recession, we thought, “Oh, it’s just the end of, you know, pipeline fitter jobs,” and then we thought it’s just the end of this and the end of that. And then suddenly we realized, no, it’s actually the end of the manufacturing era. So you realize that this was a trend that was not going to go away or reverse itself and that all these jobs that men happened to do were sort of shrinking and shrinking and shrinking. And they were never going to come back.

So, you know, I don’t know-- you want me to say it’s like the end of manufacturing--

### Moderator
Claim: Let’s hear from your opponents. Christina?

### Scientific Advocate (SA)
Claim: First of all, I just don’t accept the idea that men, the jobs that men will hold in the future are going to be-- they’re going to have to be dance therapists or executive producers. If you look at the projections from the labor department, we're going to need vast-- millions and millions of engineers and people that are experts in information technology. And there are still going to have to be people constructing and manufacturing. So it's naive to suggest that we're moving away entirely from jobs that were conventionally done by men. And I just want to go back to one question that was raised before about where do transgendered people and gay people fit in. It was actually-- a lot of my positions about men and women came from sympathy that I had for transgendered and gay people, people that didn't fit into their gender role, because one of the things they tell us is that your gender role is very powerful. And it's not socially constructed. It's something you are born with.

And what I urge in my writing is to be respectful, yes, of people who defy the stereotypes of their gender, but also to be respectful of those of us who embody the stereotypes. There are many people who are--

### Scientific Advocate (SA)
Claim: --conventionally fem--

### Moderator
Claim: Yep.

### Scientific Advocate (SA)
Claim: He wants--

### Moderator
Claim: Did you want to--

### Scientific Advocate (SA)
Claim: I would just say I completely agree with the point about trends. They're called trends for a reason. They don't last forever. That's why we're not all walking around--

### Conspiracy Advocate (CA)
Claim: No, they're called trends because they're true.

### Conspiracy Advocate (CA)
Claim: But it misses the point, which is that the more important point, directly responding to your question about the candlesticks, is that what we're seeing in society today, and Hanna has studied a lot more than have I, is the idea that the people who are making candles and engaging in jobs that are becoming outdated or whatever the case may be, women have figured out a way to navigate the tough economy better than men. And they are simply adapting better than are men. And that's the really important point here. It's not just that the male jobs are being eliminated.

### Moderator
Claim: Yes. Thank you.

### Moderator
Claim: Yes, hi. Hello. Diane Salvatore, editor of Prevention magazine.

Is it true that-- that men with power and money tend to self-destruct more than women do? And I think here of Oprah versus Charlie Sheen.

### Conspiracy Advocate (CA)
Claim: Or how about anybody versus Charlie Sheen?

### Scientific Advocate (SA)
Claim: That's why I said before that Dan is probably finished, but not others.

### Conspiracy Advocate (CA)
Claim: I'm just thankful to you for mentioning Charlie Sheen because I feel like you just say "Charlie Sheen" enough times, and everybody will vote for us.

### Moderator
Claim: Sir, I'm looking right at you. If you stand up-- yep. Michael, come in, please. Thank you. That was a question. That was a focused question. That's the model.

### Conspiracy Advocate (CA)
Claim: By a woman.

### Moderator
Claim: All right. I'm going to try and redeem the men's side with this question. You spoke earlier about bloggers versus loggers.

I guess everybody would agree that technology is the new frontier. And if you look at Silicon Valley, it's dominated by young men. What do you say to that?

### Conspiracy Advocate (CA)
Claim: Well, whenever I look at these--

### Moderator
Claim: Hanna Rosin.

### Conspiracy Advocate (CA)
Claim: --questions, because we always think, oh, men are better at technology. They're better engineers. I do, in my head what I call the cross-border biology check. Now, what is a cross-border biology check? I try and think, okay, is this just something we think is true because we look at it, and we assume it ever has to be true, while in India, half of engineering students are women. Now, why is that? Because it's encouraged in India, and because that's something everybody has to do. It's not something that men are necessarily better than women at. So I just feel like eventually that will be true here too. We put an emphasis on it, and women will do it.

### Scientific Advocate (SA)
Claim: Correction about India? In countries like-- people often say, Look at India, look at Malaysia. Women are the engineers, and far more women are becoming physicists. In those countries, women don't have as much choice of what they do. Because of economic pressures, they are forced to do careers in a society where there's more prosperity, women have more choice, and they go into other fields.

And that's why if you look at what American women are majoring in it's art history and education, all sorts of things. They're not forced to do something they don't want to do. Men do. That is their number one choice in college majors, or it's-- of all the majors, that's the one men choose, I guess, after business. Whereas women, it's teaching. So there are-- there are differences in that, again, I am insisting that we need both in the new economy.

### Moderator
Claim: Right here, second row. A mic's going to come for you. Second-- third stand. I'm sorry. I meant-- sorry.

### Moderator
Claim: All right. I just wanted to clarify some things. The debate's title is called "Men are finished." And it seems that all four of you agree and disagree on different points on how to interpret that. So can you-- can each panelist give some examples on the representative man and the representative woman that they think is defining these new trends?

### Moderator
Claim: It's a good question. It will take a half an hour. I'm going to respectfully pass, but not to disrespect the question. I just think it would chew up too much time and maybe not get us to a new place. So if you could pass to your-- see, by being persistent--

### Moderator
Claim: Yes. Hello. My name is David, and I am a student here at NYU. And I'm male. But I just wanted to ask, because I've seen that a lot of the debate has been going on about what is considered traditionally male or traditionally female. And I was wondering if it was really possible to determine whether or not men are, quote, unquote, "finished," based on these traditional sort of stereotypical characteristics, because if you look at it, what is considered traditionally female is not what they're right now. Like the female workers in business or economics or whatever tend to have more what we consider traditionally male traits.

### Moderator
Claim: So a man going into nursing you feel would be going into a female profession?

### Moderator
Claim: Well, I would say that it's what’s considered traditionally female. But I think what we consider traditionally male or female--

### Moderator
Claim: So--

### Moderator
Claim: --so iss not really whole.

### Moderator
Claim: So if you focus your question down to one sentence, what, what is it?

### Moderator
Claim: All right. Is it-- is it really possible to say that men are finished based on what we consider to be traditionally male and female-- considering the fact that in modern times the definitions of said genders--

### Moderator
Claim: That the world is changing. I think I see what he's saying.

### Scientific Advocate (SA)
Claim: Can the lady from Prevention magazine reformulate that?

### Moderator
Claim: Hanna Rosin, do you want to take it?

### Conspiracy Advocate (CA)
Claim: --formulate that?

### Moderator
Claim: Who would like to take that?

### Conspiracy Advocate (CA)
Claim: Well, there is some evidence--

### Moderator
Claim: Hanna Rosin.

### Conspiracy Advocate (CA)
Claim: --that as women become more dominant, they take on more traits that we think of as traditionally masculine. So I think that a lot of these things are much more fluid than we think they are. That's why I'm always reluctant to enter into this gender biology question: Women are like this, and men are like this. Women have gotten vastly more aggressive. They are-- they're much, much more likely to get arrested, especially juvenile females than they were 20 years ago.

You know, so this is a sort of scale that moves along a continuum.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Though, as I said--

### Moderator
Claim: I'm guessing you will agree with that. So, sir--

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: No?

### Scientific Advocate (SA)
Claim: One thing she's left out. Okay. Go on.

### Moderator
Claim: Okay, no, no, no. Christina, if you're serious, go ahead.

### Scientific Advocate (SA)
Claim: Well, it's one thing that does not change in human nature is that men tend to succeed and fail more spectacularly than females. So you find more males who are, in any economy, any situation, there are going to be males that are going to find their way to the top. And there will be males that will find their way to the bottom.

### Moderator
Claim: Right.

### Scientific Advocate (SA)
Claim: Men have that-- that capacity.

### Moderator
Claim: That was Dan Abrams homerun-- swinging for the fence point. Sir, you're standing in the aisle? Yes. You just pointed to yourself. Yeah, that's-- No, that's not-- that's me being confused, not him, all right?

### Moderator
Claim: Thank you. This is a point first made by Slate magazine's Emily Bazelon who I think it was-- or what I heard is I think it's appropriate to do it here where you're a cosponsor.

But the company Wal-Mart recently faced a lawsuit about systematically discriminating against women and whatever you think about the outcome of that. The point was, clearly Wal-Mart wasn't utilizing their-- or empowering their female work force. And all the economic evidence which Wal-Mart would have definitely had at its disposal would suggest that that would be the profit maximizing thing to do. And we all know Wal-Mart loves profit. So I guess my question for the panel is, why is that, and what does that mean for our motion?

### Moderator
Claim: You know, I think it's a little-- I think it's a little bit off point on getting us to the question of whether we think men are finished or not, so respectfully, I'm going to pass on that.

### Scientific Advocate (SA)
Claim: But I could just reformulate it.

### Moderator
Claim: But I-- I--

### Scientific Advocate (SA)
Claim: I would just like to ask, why don't all of our leading companies, if they were really smart, fire all their males who are useless and hire females?

Well, they don't--

### Moderator
Claim: Well, they're not saying that they're useless. They haven't gone that far.

### Scientific Advocate (SA)
Claim: They're not useless, but they're on their way out.

### Moderator
Claim: Okay. So you want to answer that?

### Conspiracy Advocate (CA)
Claim: Yeah. I mean, they don't have to fire all of their males, but they certainly have to-- fire most of them.

### Moderator
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: No, that's not where I was going with that.

### Moderator
Claim: Right there in the aisle, to your right, right, yes. Could you please rise. Thanks.

### Moderator
Claim: The moderator started out by saying that increasing-- Leslie Bennetts, Newsweek Daily Beast. The moderator started out by saying that increasingly men are not assuming the responsibilities of parenthood. Both the men on the panel who are middle aged, single and childless would be examples of this. And I'd like to know why they think that this is so often the case these days, men are marrying less and less. Men are not supporting their families. The statistics on the nonpayment of things like child support are astronomical. And that's always been one of the hallmarks of adulthood.

I'd like to know what the panel has to say about that.

### Conspiracy Advocate (CA)
Claim: Since I'm being lumped in with dead beat dads, I think I'll probably pass on this one.

### Conspiracy Advocate (CA)
Claim: I'm not touching that. I have three children. I just like to brag about that. I'm not going near that one. Dave and Dan, you can take that one.

### Moderator
Claim: David Zinczenko.

### Scientific Advocate (SA)
Claim: Well, I mean, I-- you know, obviously you're well-read and you've probably read the Times today and the piece about how single men or unmarried men are sometimes the biggest contributors to their family and in their community, so--

### Moderator
Claim: --statistically there's a lot of evidence--

### Moderator
Claim: If you're going to come back, it's okay to do so, but could you stand up again?

### Moderator
Claim: Yeah.

### Moderator
Claim: Sure.

### Moderator
Claim: Statistically there's a lot of evidence and I'm really curious about why you guys think that men are turning away from-- you know, I mean, a generation or two ago by the time men were in their late 20s they often had three or four kids. That's not the model today. I'm interested in what the men have to say about

### Conspiracy Advocate (CA)
Claim: But women are also having-- but women are also having children later, I mean, it's not a male-female

### Moderator
Claim: Yeah, but a lot of women are having children alone because men don't want to participate.

### Conspiracy Advocate (CA)
Claim: Yeah, no, if we look at--

### Conspiracy Advocate (CA)
Claim: Okay. Or because--

### Conspiracy Advocate (CA)
Claim: --if we look at this from the children's perspective and the children in this sort of 59 percent that I was talking about, we would definitely win and you would definitely have to vote for men are finished. It's like a shocking phenomenon, 40 percent of American children are now born to single parent households. You could say that's because the women have decided that the men are finished, they don't need them, they don't contribute to the household, the women are the ones doing all the work and going to school and the men are just sort of another child in the house to feed and that's what all the women tell me. I wish that it was funny but it's not funny. That's the part of this that's the tragedy about men are finished.

### Moderator
Claim: One last question, sir.

### Moderator
Claim: Well, my background is in the apparel industry. I was the largest employer in the State of Tennessee, and the largest employer in the State of Maryland, and the largest employer in Alabama, all women sewing apparel. And we had to train women managers, and we made a major effort to do that.

### Moderator
Claim: So what's your question then?

### Moderator
Claim: My education is business school where there was one woman in a class of 800 when I went--

### Moderator
Claim: Right, but I'd like you to get to a question, sir.

### Moderator
Claim: What we need to do is be sure that women are taught how to manage large groups of people and then they will get the important jobs, not just do the work, and we haven't done that, now how can we make more women managers, not just family managers, but managers of businesses, service businesses, and manufacturing businesses, most of which in my industry worked overseas?

### Moderator
Claim: Okay, I'm not sure that, that's getting to our question of what do we do for the men, which I think is a little bit more on point.

### Conspiracy Advocate (CA)
Claim: There are women managers-- there-- 54 percent of American managers are now women, they don't need that much help on that.

### Moderator
Claim: I'm going to take one more question, right down in front with

### Moderator
Claim: I just have a quick question. Does anybody have the statistics on how many men become women and how many women become men?

### Moderator
Claim: It's-- that's a whole ‘nother debate which we're going to have shortly. All right. Folks, really, really, I think it has been so clear and all instances about how to do this. Sir, can you stand up? That's one of the parts--

### Moderator
Claim: My question is, can you imagine being a cofounder or founder of an island where only women live on this island?

### Moderator
Claim: Okay, I'm going to go to another-- Yes, I can, but--

### Moderator
Claim: I have an answer.

### Moderator
Claim: I sometimes do, but-- right down front.

### Scientific Advocate (SA)
Claim: Someone did ask the question, what would it be like if women ran the world and the reply was there would be no more war, just lots of jealous countries refusing to speak to one another.

### Moderator
Claim: Okay, can you rise? And make this a-- give us a finish here. Because you might be our last question.

### Moderator
Claim: Although it's true that women have been earning more bachelor's degrees, how significant of a point is that when women are still doing two thirds of the work in the world and earning 10 percent of the income and owning less than one percent of the property? And that's directed towards Hanna and Dan.

### Moderator
Claim: Okay, again, it's not on our topic about men. Somebody, hear me, hear me. You got it?

### Moderator
Claim: Men are not finished.

### Moderator
Claim: You got it?

### Moderator
Claim: Hello?

### Moderator
Claim: Front row, sorry, please, don't make me regret choosing you.

### Moderator
Claim: I'm a do you proud, I'm a do you proud. My question is for Christina. You were speaking earlier about how in elementary school it's designed against boys.

### Scientific Advocate (SA)
Claim: Sometimes, yes, very often.

### Moderator
Claim: Well, you were emphasizing how dire it was that we have to change that and we have to help boys.

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: In doing so, are you conceding that if something doesn't change, then men are finished?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Christina, take that question.

### Scientific Advocate (SA)
Claim: First of all, men-- that's ridiculous, men are not finished. And that’s why you should vote against the proposition. No, but-- No, what I’m saying is we have set up an obstacle course for young men that makes it-- and we’re doing a much better job educating young women, supporting young women, encouraging young women. There is-- every scintilla of evidence suggests it. So what we have to do is find a way and, yes, it goes back to the elementary school classroom where we have to support boys. Now am I saying that means men are finished? No, I don’t see how you hear that. I’m saying we’ve set up handicaps. We’ve set up obstacles.

### Moderator
Claim: Yes, and unless we change and get rid of those handicaps, men are finished.

### Scientific Advocate (SA)
Claim: No, false. Wrong, illogical.

I’ll give you one statistic, patents.

### Conspiracy Advocate (CA)
Claim: I’ve got to get my brother to sit down.

## Round 3

### Moderator
Claim: Ladies and gentlemen, ladies and gentlemen, that concludes round two of this Intelligence Squared U.S. debate. And here’s where we are. We are about to hear closing statements from each debater in turn. They will be two minute each. And remember how you voted before the debate. Right after these closing statements, we’re going to ask you once again to vote. And the team that has changed your minds-- most of your minds in the course of this debate-- I’m going to say that again. And the team that has most of your minds in the course of the debate will be declared our winner. So, onto round three, closing statements. Our motion is this, "Men are finished." And here to summarize his position again, her position-- and here to summarize her position against the motion, Christina Hoff Sommers, resident scholar at the American Enterprise Institute and author of “The War Against Boys.”

### Scientific Advocate (SA)
Claim: I urge you to vote against this proposition for three reasons.

Number one, it’s false. Okay, women are not replacing men. Women are not becoming the first sex. Women are becoming partners with men. Men continue to do most of the arduous and dangerous work, and they are the primary risk-takers and innovators. Society is driven by what the classical economist Joseph Schumpeter called “the gale of creative destruction.” Women can cause such gales, but it has always been a masculine specialty, and there is zero evidence that that is changing.

Now as I said in my earlier remarks, men have been doing less well in the classroom, but this does not herald the end of men. Rather, it means that we have to find ways of making our schools more effective for male students. Reason two you should oppose this proposition: It’s chauvinistic. As I said, in the old days, we had female supremacy. It’s been replaced by this variety of “women are wonderful” phenomenon.

The battle days of male supremacy are now followed by this female chauvinism. So, I believe that an act in favor of this proposition is a vote for chauvinism. Third and most important, the sexes need each other. They complement each other. They have been known to love one another. As Henry Kissinger once said, “No one will ever win the war between the sexes. There’s just too much fraternizing with the enemy.” Now women and men do not succeed at one another’s expense. We’re on the same team. We’re co-dependent. That was true on the African Savanna 100,000 years ago. It has been true ever since. It’s true in 21st century America. You can certainly find times when one sex has acquitted itself better than the other, but you will never find examples of one sex becoming irrelevant. Such a development is beyond anything in human experience. I urge you to vote in favor of reality. Thank you.

### Moderator
Claim: Thank you, Christina Hoff Sommers. Our motion is "Men are finished," and here to summarize her position in support of this motion, Hanna Rosin, an award-winning journalist for Slate and The Atlantic.

### Conspiracy Advocate (CA)
Claim: I’m going to start out by reading you a couple of quotes. One is from a story called, “The Decline of the American Male.” “Men,” this writer says, “are endangered species. They are expendable.” Another quote: “Women have gained in the past century while men have fallen behind.” Who is this mystery author? Dave Zinczenko is the mystery author who wrote this story at USA Today in 2009. He keeps saying this is preposterous, this is preposterous. Merely two years ago, he thought that it was true. Now I’m going to read you another series of quotes. “It is boys who are the second sex. It’s a bad time to be a boy in America. The research”-- listen to this closely-- “commonly cited to support claims of male privilege and male sinfulness is riddled with errors.”Who is the mystery author of this article? Christina Hoff Sommers, who’s also saying that this is all very preposterous. So, as you can see, it’s not that preposterous. We can all see the writing on the walls. They keep talking about how men are still running the country. Men are still doing this, men are still doing that. But that's not interesting. That just shows a lack of imagination. As we said, this "Men are finished" proposition, you literally have to think of it as graffiti, as the writing on the wall pointing to an inevitable future. All the signs are there.

So-- and then the final thing I want to say is, Christina says this is a vote for chauvinism, that "Men are finished" is a vote for chauvinism. Don't think of it that way. You're actually doing a public service to men if you vote for our team because I think if we finally acknowledge that this is a problem and that men are finished and that they need our help, and they might even need some affirmative action, then maybe we would behave the right way, and we would help the men who desperately need our help. So remember, vote for men are finished."

### Moderator
Claim: Thank you, Hanna Rosin. Our motion is "Men are finished." And here to summarize his position against the motion, David Zinczenko, executive vice president and editor in chief of Men's Health magazine.

### Scientific Advocate (SA)
Claim: Well, thank you. Thank you, John. Thank you. Hats off to Dan and Hanna. That article, by the way, was arguing for better healthcare for men. There are five offices of women's health in the federal government, zero for men. That was really the context. Now, my opponents tonight have outlined some trends that seem to herald the final decent of the American male into a metaphorical trash heap of irrelevance and impotence. They are trying to bury legions of men alive, okay? You have to vote against this measure. Sure, there are some worrisome trends.

They went through them, okay? And as we all know once a trend starts, it keeps going on forever. That's why all of our houses are worth so much more today than they were in 2007. Now, in the end, there are two reasons why you must vote against this motion, because they might be wrong, but they might be right. Now, the first point, consider this: Gender equality is something, we can all agree on, as an ideal. But if we are approaching gender equality, why are there fewer women in government today than there were ten years ago? Why is it so much easier for men to hold onto their gun rights than it is for women to hold onto their reproductive rights? Not only aren't men finished, but women haven't even begun. Let's at least get to the point where the game is tied before we start writing all the men off. Let's imagine, though, that the trend toward greater female political social and economic power continues unabated.

Highly unlikely because the great recession started with men and now it's starting to hit predominantly female jobs more than before. And the scales are tilting. So the more educated independent single women there are the more wonderful the world will actually get for men, okay? So regardless of whether we one day achieve gender equality, men are not finished. And by the way, women are not either. You have to vote against this measure.

### Moderator
Claim: Thank you, David Zinczenko. Our motion is "Men are finished." And here to summarize his position in support of the motion, Dan Abrams, chief legal analyst for ABC News, author of "Man Down."

### Conspiracy Advocate (CA)
Claim: It seemed at times that our opponents were pleading to you as a moral matter to vote against this. It would be wrong, be horrible. Look what would happen? You would make the guys feel bad. Look, the reality is that we're not just talking about women catching up.

We're talking about women surpassing men. Both Hanna and I have talked to you in depth and at length about how significantly women have not caught up but surpassed men in very significant areas in our society. David mentioned before that you're not going to see jock strap protests outside. That's right. That's part of the problem is that men are not alarmed by the situation. And that's one of the main reasons that men are finished, is they don't seem to care. They think-- they think it's cool to be a slacker. It's not. Dave mentioned the Chilean mines and the miners there as an effort to sort of pull at your heartstrings. There's no question that that was a heartfelt moment.

But what if a woman had designed that mine? I'm guessing that we might not have ever had that sort of problem. I will end with one note from my book which is that there was a study done on how long it takes men and women to get ready to leave the house. And this study, in England, of 2,000 people showed that men take, on average, four minutes longer. When you think about a Saturday night, no question women will take longer to get ready to leave the house. But when you think about the realities that women face every day of bringing up children, of working a job very often, of doing all the hard work and trying to get ready to leave the house, it starts to make sense. And if that study's true, then men really are finished.

### Moderator
Claim: Thank you, Dan Abrams. And that concludes our closing statements. And now it's time to learn which side you feel has argued the best. Remember, we've asked you to vote before the debate began.

We're going to ask you to vote "against" now judging the qualities of these arguments. You go to the keypad at your seat. Our motion is this: "Men are finished." If you agree with the motion or feel that the argument was presented best on that side, you push number one. If you disagree, you push number two. If you remain or became undecided, you push number three.

### Moderator
Claim: Yes. Seriously? One, if you're for the motion. Two if you're against. They're number one.

### Conspiracy Advocate (CA)
Claim: We’re number 1, they’re number 2.

### Moderator
Claim: That's a very good way to put it. We've never done that. And a woman came up with that idea. Number one, number two, undecided is number three. All right. We're going to have the results very, very quickly. I want to just talk a little bit about a couple of things that are coming up. But first I want to thank the debaters for the quality of the arguments that they brought here. for the unique and difficult to achieve combination of being serious and intelligent while also a lot of fun at the same time. This is also normally the point in the evening in which I thank the audience for its great questions. And I-- I want to say that it really pleased me to see those neurons firing rapidly, and in some cases randomly. But-- but all of you for having the guts to get up and face this and face what I was doing. In any case, I really appreciate it. And as an audience, you actually have been spectacular, wonderful and very vocal. So thank you very much for this evening. We'd like to thank Slate for being our media partner for live streaming this debate and for bringing questions to us and for being part of this in the future as well. So-- we're back here again on Tuesday, October 4th. Our next debate has this motion: "Grandma's Benefits Imperil Junior's Future."Arguing in support of this motion, we'll have Margaret Hoover. She is author of "American Individualism." It's a political manifesto that evokes her great-grandfather, Herbert Hoover's, emphasis on the values of civic responsibility. Joining her as her teammate is Mort Zuckerman, chairman and editor in chief of U.S. News and World Report who wondered, in a recent op ed, how, quote, "a country of pioneers and self- made men could evolve into a culture of entitlement." Arguing against this motion, we're going to have Howard Dean, former chairman of the Democratic National Committee, six-term governor of Vermont, a physician and one-time candidate for president in 2004. And his partner will be Jeff Madrick editor of Challenge magazine and author of "The Case for Big Government." And that argues-- that says that engaged government, a big government of high taxes and wise regulations is necessary to ensure America's social and economic security. You can find a full listing of all of our fall debates in tonight's program and also on our website where tickets are available for purchase.

All of our debates, as we've said already, can be heard on NPR stations across the country, including WNYC here in New York and also watched on WNET's 13, WLIW and NJTV. And don't forget to follow Intelligence Squared U.S. on Twitter and make sure to become a fan of Facebook. And if you do, you will get a discount on future debates.

Okay. I'm going to announce the results. And I want to do it this way. So these debaters have spent the last hour plus trying to win you over to their point of view on our motion, "Men are finished." We had you vote once before the debate and once again at the end of the debate. Both of those votes are now in. And here are the results. Before the debate, with the motion being, "Men are finished," 20 percent were for the motion, 54 percent were against, and 26 percent undecided. After the debate, 66 percent are for the motion.

That's up 46 percent. 29 percent are against. That is down 25 percent. 5 percent undecided. That's down 21 percent. The side arguing for the motion, "Men are finished," has carried our debate. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S., we'll see you next time.
