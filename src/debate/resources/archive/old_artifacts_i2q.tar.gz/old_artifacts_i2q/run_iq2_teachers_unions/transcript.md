# Debate Transcript

Topic: Don't Blame Teachers Unions For Our Failing Schools
Motion: Don't Blame Teachers Unions For Our Failing Schools

Debate ID: teachers-unions


## Round 1

### Moderator
Claim: Thank you. Normally, Robert, you introduce me but I'll do it myself.

### Moderator
Claim: I'm really sorry.

### Moderator
Claim: I was waiting for my cue.

### Moderator
Claim: I was waiting for that too, I'm sorry. Well, now John, over to you.

### Moderator
Claim: That worked so perfectly.

Thank you. Thank you. One more round of applause for Robert Rosenkranz to make this all possible.

Welcome everyone to another debate from Intelligence Squared U.S. I'm John Donvan of ABC News and, once again, I have the honor of moderating as the six debaters you see sharing the stage with me here at the Skirball Center for the performing arts of New York University; six debaters, three against three will be debating this motion, don't blame teachers unions for our failing schools. Parse out that language that means that if you vote for the motion, you’re voting for exonerating teachers unions. If you vote against the motion, you’re voting for-- you blame teachers unions. I'll rephrase that. You blame teachers' unions if you’re voting against the motion. Now, this is a debate and I'm the referee but you, the audience, are actually the judges. You will have been asked by the time this debate ends to vote twice, once before and once after debate to tell us where you stand on this motion. And after hearing the arguments and the second vote, the team that has changed the most minds will be declared our winner. So let's go now to the vote and the right-hand side of your seat there is a key pad. Read this motion closely because the language is a little bit challenging. If you are for the motion, push number one. And for the motion means you exonerate teachers unions. If you are against the motion, push number two. This means that you blame teachers unions for the failure of the schools. If you are undecided, push number three. And if you feel that you've made an error in your selection, just push the correct number and it will lock into the most recent-- your last vote will actually be the one that is recorded. So we'll tally those votes in a few minutes. And somewhat into our opening round I will tell you what the first results. I also wanted to share a very brief personal note that I'm going to declare irrelevant, that my grandfather was a New York City public school teacher. So was my father. So was my mother.

And so was my 93 year old Aunt Grace who even now is living in the Bronx. I will make all of this irrelevant.

Because that is my job, to be neutral and to moderate. So let's get on with round one of our debate, opening statements by each debater. In turn, they will be seven minutes each, uninterrupted and speaking first for the motion I'd like to introduce Randi Weingarten who is the president of the American Federation of Teachers, the country's second largest teachers union and I believe also you have New York city school teachers in your heritage.

### Conspiracy Advocate (CA)
Claim: Absolutely. Many, many of them.

### Moderator
Claim: Ladies and gentlemen, Randi Weingarten. Ladies and gentlemen.

### Conspiracy Advocate (CA)
Claim: Thank you, John. Thank you, Bloomberg. Thank you, NPR and thank you, Mr. Rosenkranz. Look, we have a double challenge today in America. One is the need to compete in a global economy, an economy that has changed hugely even as many of us have been wrestling with it. Number two, we have the effects of the global recession: state and local budgets that are totally and completely decimated right now. And so when the investment is very, very bleak, as it is right now, and the need is very, very great, it's no wonder that people are looking to find one entity to blame. But my friends, blaming unions for school failure is like blaming the middle class for the recession. Ultimately what humans do-- what our union does proudly is have a mantra. What is good for kids and what is fair for teachers. Now, am I saying that everything we've ever done is the right thing? Absolutely not. Am I saying that we are perfect? Absolutely not. But what we are trying to do in this very, very turbulent time is search for what works. Search for what works for kids. Let me ask-- let me suggest this. If teachers unions were to be blamed for failing schools, then we would assume that schools in less unionized states would outperform schools in more densely unionized states. So you'd assume that places like Mississippi, Alabama, Louisiana, who have relatively few unionized teachers would do much, much better. But that's not the case. The states with the most densely unionized teachers, Massachusetts, New York, Maryland; they do the best. And the countries with the most densely unionized populations: Finland, Japan, they do the best. So what do we learn from that? What we know is that there are problems like Mr. Rosenkranz said. There are problems we have to solve. One of which is poverty. States like Alabama, Louisiana, Mississippi; they have and had been plagued by tremendous poverty. We have to compete with poverty. That's what public education is and that is what the search we have for, that's what our search is, to find what works. So you felt, I hope tonight we can move from scapegoating to solutions, to problem solving. And I would argue to all of you that having a strong union, someone in an entity that will look at what it's done right and what it's done wrong, and solve things and change things, is the way to go. So what works? What can we learn from places like Maryland, Massachusetts, New York State, Finland, and Japan? This is what we can learn. This is what works. What works in places where we don't as Terry Moe will probably argue, where we don't have niche markets, where we can't marketize our schools, where we have to help all kids. So we need well-prepared and supported teachers. We need well- rounded rigorous curriculum that engages kids and we can get our arms around. We need to invest in the tools and the time to differentiate instruction. We also need things like early childhood education and a focus and fixation on graduation in terms of high school. And finally, we need good services to help level the playing field for kids. Now, is this a panacea? Is this something that has never happened and it's a search for something we don't know how to find? No. We find these elements in lots of different places. And the glue that binds us together, the difference between the places that work and the places that don't are good labor management relationships. Like we see in one of my other panelists here, in the ABC school district in California which has lifted its scores, which has changed its relationships from competitive to ones that are collaborative. Does that mean as I said before that we've done everything. Of course not. Everyone has to take more responsibility in this day and age. If we're going to ensure that all kids are ready for life, for college, for career, that means that-- that means we all have to take collective responsibility. And we, at the A.F.T., attempted to do that in any number of ways: first, in pushing for common standards, including the new common core curriculum or the common core standards in pushing for better aligned assessments, in pushing for better curriculum. And in looking at ourselves and saying look, we have to have a new approach to due process. We can't have rubber rooms anymore. We can't have a choice between off with your heads and warehousing. We can't have situations where if there is incompetence in the classroom we allow that to happen. We have to have more evaluation systems that are fair, that are meaningful, that are competent, and that actually help teachers teach in a more robust way than they may be doing now. But we also have to give teachers the tools and the time and the conditions that they need to do a good job with kids. Because at the end of the day, to compete with poverty, to drift all boats, to make sure that kids get that chance to dream their dreams and to achieve it, it comes with initially that connection between teacher and kid. That connection we made every day that we teach. That connection I made with my kids at Clara Barton High School that I know Gary made when he taught. I know Kate made when she teaches. We need teachers to have the support of the people around us and the unions. The unions-- all of us. The unions will do everything in their power to help fight for the tools and the conditions that teachers need and to fight to ensure that every kid, every kid gets a well prepared and well supported teacher. Thank you very much.

### Moderator
Claim: Thank you, Randi Weingarten. The motion is don't blame teachers unions for our failing schools. And now to argue against the motion because he does blame teachers unions for the failure of the schools, I'd like to introduce Terry Moe of the Hoover Institution whose book almost 20 years ago titled "Politics, Markets and America's Schools," was full of ideas it seemed radical at the time, and that since then have become actually part of school systems, experimental school systems throughout the country. I don't know whether it's been the pace you would like, Terry. It's been 20 years.

### Scientific Advocate (SA)
Claim: Only 20 years.

### Moderator
Claim: Okay, ladies and gentlemen, Terry Moe.

### Scientific Advocate (SA)
Claim: Thank you very much. It's great to be here. I want to thank Intelligence Squared for arranging this event and for putting the spotlight on what, in my view, is the most important issue in American education today, the power of the teachers unions. I should be clear that our team is not saying that the teachers unions are responsible for every problem of the public schools. What we are saying is that the unions are and have long been major obstacles to real reform in the system. And we're hardly alone in saying this. If you read “Newsweek,” “Time Magazine,” the “Washington Post,” lots of other well- respected publications, they're all saying the same thing: that the teachers unions are standing in the way of progress. So look. Let me start with an obvious example. The teachers unions have fought for all sorts of protections in labor contracts and in state laws that make it virtually impossible to get bad teachers out of the classroom. On average, it takes two years, $200,000, and 15% of the principal's total time to get one bad teacher out of the classroom. As a result, principals don't even try. They give 99% of teachers-- no joke-- satisfactory evaluations. The bad teachers just stay in the classroom. Well, if we figure that maybe 5% of the teachers, that's a conservative estimate, are bad teachers nationwide, that means that 2.5 million kids are stuck in classrooms with teachers who aren't teaching them anything. This is devastating. And the unions are largely responsible for that. They're also responsible for seniority provisions in these labor contracts that among other things often allow senior teachers to stake a claim to desirable jobs, even if they're not good teachers and even if they're a bad fit for that school. The seniority rules often require districts to lay off junior people before senior people. It's happening all around the country now. And some of these junior people are some of the best teachers in the district. And some of the senior people that are being saved are the worst. Okay. So just ask yourself, would anyone in his right mind organize schools in this way, if all they cared about was what's best for kids? And the answer is no. But this is the way our schools are actually organized. And it's due largely to the power of the unions. Now, these organizational issues are really important, but they're just part of a larger set of problems. Our nation has been trying to reform the schools since the early 1980s. And the whole time the teachers' unions have used their extraordinary power in the political process to try to block reform and make sure that real reform just never happens. Consider charter schools. There are many kids around this country who are stuck in schools that just aren't teaching them. They need new options. Well, charter schools can provide them with those options. But charter schools are a threat to teachers' unions. If you give kids choice and they can leave regular public schools, then they take money and they take jobs with them. And that's what the teachers' unions want to stop. So what they've done is they've used their power in the political process to put a ceiling on the numbers of charter schools. As a result in this country today, we have 4,600 charter schools. There are like well over 90,000 public schools. So this is a drop in the bucket. And mean time charter schools have huge waiting lists of people who are desperate to get in. In Harlem, for example, the charter schools there got 11,000 applications for 2,000 slots recently. So just to give you an idea of about how the politics of this works out, in Detroit a few years ago, a benefactor came forth and said he was willing to donate $200 million to set up additional charter schools for the kids in Detroit who obviously need it. What did the union do? The union went ballistic. They shut down the schools, went to Lansing, demonstrated in the state capitol and got the politicians to turn down the $200 million for those kids. This is good for kids? I don't think so. This is about protecting jobs. The same kind of logic applies with accountability. Accountability is just common sense. We obviously need to hold schools and teachers accountability for teaching kids what they're supposed to know. But the teachers' unions find this threatening. They say they support accountability but they don't want teachers held accountable. Any sensible effort to hold teachers accountable, they brand as scapegoating teachers. They don't even want teachers performance to be measured. Right here in New York City, Joel Klein indicated a while ago that he was going to use student test scores as one factor in evaluating teachers for tenure. What did the union do? Now, this is something that Obama supports, that Arne Duncan supports. It's unbelievable. What the union did is they went to Albany and they got their friends in the legislature to pass a law making it illegal to use student test scores in evaluating teachers for tenure anywhere in the state of New York. It's just outrageous. And makes no sense from the standpoint of what's best for kids. The “New York Times” called it absurd. This is how the unions approach accountability. Okay, well, I don't have a whole lot of time left here. So let me just quickly say our opponents are going to say tonight, and Randi has already said, there is really no conflict between standing up for the jobs of teachers and doing what's best for kids. But the thing is there is a conflict. And that's why we can't get bad teachers out of the classroom, because they protect them. That's why the schools have totally perverse organizations imposed on them, and that's why totally sensible reforms are seriously resisted in the political process. Now, what you're going to hear, I'm sure, throughout the evening is that union leaders and unions around the country, they're actually reformers too. They want to get bad teachers out of the classroom. They say they're for charter schools; they're all in favor of accountability. Well, not really. Talk is cheap. What counts is what they actually do. And what they do is to oppose reform. This is the reality. Thank you.

### Moderator
Claim: Thank you, Terry Moe. Our motion is don't blame teachers unions for our failing schools. I'd like to introduce our second debater speaking for the motion, not to blame teachers. Kate McLaughlin is an elementary school teacher in Lowell, Massachusetts, at the moment our only active teacher in the debate tonight. Kate, I understand you've moved on to being a math coach for kids?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Do you teach--

### Conspiracy Advocate (CA)
Claim: I teach children and teachers, kindergarten through fourth grade.

### Moderator
Claim: Thanks very much for joining us tonight. Ladies and gentlemen, Kate McLaughlin.

### Conspiracy Advocate (CA)
Claim: Good evening, everyone. I too, would like to thank the Rosenkranz Foundation especially for having a teacher come and speak because it is a rare occasion for a teacher to actually be able to talk about education. It's usually think tanks and professors and others. So I'm really privileged to be here tonight. Thank you. The first time I heard about this, don't blame teachers' unions, I, too, thought like Randi. I'm from the common wealth of Massachusetts. Which I'm very proud to say is number one in the country. Our students perform higher than anybody else in this country academically. Yet we have the strongest collective bargaining rights in the country. So do me it just doesn't add up. And then I started thinking I'm also a doctoral student so I'm trying to learn as much as I can about research and so the next thing I did is I went straight to the literature. Even Professor Moe said publications are all saying the same thing. There is no research to support what he is saying. There is no research out there that correlates student achievement to collective bargaining rights to teach unionism, either for or against.

There is no conclusive evidence so people can say what they want. And publicize. It doesn't mean that it's research-based. So with that, what do collective bargaining rates do to improve schools? And I have a lot to say. Not only am I a teacher, I'm the executive vice-president of the United Teachers of Lowell, and I deal with this firsthand as a union leader. And for me, what bargaining rights do is they provide dignity a way to provide dignity for a profession that frankly gets beat up on a lot. And the way that we can do that is we can ensure language that improves working conditions for teachers, but also for children. So one example of that, which unfortunately in my district-- my union has not been able to negotiate yet; is something like we could have language for class sizes. So early childhood children would be in smaller classes which the research shows is good for them, but that's a way we can ensure it, by having it in the teachers' contract. That's just one example. The other thing that collective bargaining rights help us with at a local level is it ensures academic freedom. What that means is there are times as a teacher that I need to advocate for the child. And that means I have to say something unpopular, something that an administrator might not appreciate me saying in front of a parent, and I need to be able to do that, to be the best teacher that I can be. And I need to be able to do that without fear. And that is why collective bargaining rights are very important when you are in a classroom, you need to be able to do what you know is best for children. And that is why it's important. Besides families, no one cares more about students and their learning, especially students living in poverty, than their teachers. And what the teachers' unions do at the local level is we serve as a conduit for the teachers. So while my opponents on the motion might say that I have my own agenda, I would argue that is absolutely not true. My agenda is the agenda of the teachers. What the teachers need. So the way that we find that out at a local level, the president of our union and the superintendent, along with other members of the executive board go to the schools and meet with the teachers and find out what they need to get their jobs done. We survey our members. And what they need in their classrooms is our agenda. So for example one thing that we've done is we've created what's been called-- the Department of Education in Massachusetts has been called the Cadillac teacher induction program. So the union and management sat down together, that's the union-initiated protocol, to make sure that every teacher in their first three years of teaching had a qualified and trained mentor. They have access to district designed graduate level courses specifically designed so that they can best meet our students in Lowell who often come with second language issues, they have full training in what they need. Also with that, the mentors are trained to talk to their mentees about whether they're in the right place or not. And to counsel them perhaps out of urban education, if that's not what's meeting their need or meeting the children's need. And also, to help them make better choices. Another thing that was union initiated that is in our contract, we call the Lowell program. It's an in-house graduate program where teachers can get their master's degree. Again, the superintendent and her colleagues have decided what the content of the course is, and we work together so that teachers are given the tools that they need. In terms of evaluations, our evaluation procedures in Lowell as negotiated are actually more stringent than what's required by state standard. So our new teachers are evaluated twice every year, whereas the state only mandates once. So in terms of unions advocating for poor evaluation measures, it's just not true. The most important thing in my opinion about what we've done-- and I can't speak to 20 years ago because unfortunately, I was only in high school, but I can speak to what's happening in schools now. And what we are doing is this labor management union. Because with all due respect, we have been-- the teachers have been told what to do. We've been given scripted curricula from under reading first grants and under these grants, and we found-- the teachers found they were not working for children. We've told what to do. Now what we need to do is have a seat at the table to be part of the decision making. And so in Lowell we have begun this journey to build collaborative structures in our district between labor and management so the people at the ground floor, the teachers, can inform the decisions that are made for children. So it is, indeed, what is best for them. Thank you.

### Moderator
Claim: Thank you, Kate McLaughlin. Here is where we are on the debate. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. Acting as moderator, we have six debaters: three against three fighting it out over this motion. Don't blame teachers' unions for our failing schools. We've heard from three debaters three opening statements. And now on to our fourth to speak against the motion I'd like to introduce Rod Paige who is famously the U.S. Secretary of Education under the Bush administration, even more famously once called teachers unions terrorist groups.

### Scientific Advocate (SA)
Claim: I knew that was going to come up.

### Moderator
Claim: It has to come up. And also his own background in education, he is the son of a school principal in rural Mississippi who, to make ends meet, also worked as a barber, I believe, is that correct, Rod?

### Scientific Advocate (SA)
Claim: That's correct.

### Moderator
Claim: And how times have changed. Or perhaps they have not. Ladies and gentlemen, Rod Paige.

### Scientific Advocate (SA)
Claim: Good evening, ladies and gentlemen. I'm here to convince you to vote against this proposition. All of us know that teachers are not solely to blame for our failing schools. But they bear significant responsibility and the way this is framed, the only way to express that is to vote against this proposition. Now, to understand my point of view, you have to realize how powerful these organizations are. To be blunt, teachers unions represent the most dominant political force in American education. We're not talking about little wimpy organizations. We're talking about mammoth highly financed, highly organized, highly peopled organizations. And political dominance is not something that they got unintentionally. They intended to be politically dominant. Here is a quote from Sam Lambert in 1967 about NEA. NEA would become the political-- become a political power second to no other special interest group. Listen to those words. People could argue now that they've already reached that goal. Teacher unions represent the number one political spender in the United States of America. In the state of California, the NEA spent more in the last decades than any other political spender and the second political spender spent less by a little bitter than 1/2 of what the NEA spent. These are powerful, dominant organizations. The NEA has 3.2 million members, 14,000 locals across the United States, and last year-- in 2007 they collected about $400 million from their members to supplement the other revenue streams that they had. The AFT is not a slouch either. They have 1.4 million members, 300 locals across the United States. And they're active in 43 states. NEA has state offices in every state in the United States. And that's not all. They can call on their political partners when they get in trouble. They can call on the AFL-CIO. They can call on Acorn. They can call on People for the American Way. They can call on the Center for Community Change. These are mammoth organizations and I need for you to understand that in order to understand why we take this position. Now, the American workforce, about 12% of the workforce is unionized. But in the education profession, it's 38%. Teachers' unions literally have our schools in a chokehold. This is completely dangerous. Now, power corrupts. Total power corrupts totally. You need to be clear about how they use this power. To try to convince people-- you heard a lot tonight about children and their members. Don't be fooled. Organizations have one primary interest. They may have some other interests but they have one main interest. Teachers' unions’ main interest is the welfare of their members. Another quote from NEA operative, “The main purpose of our association”-- note the word association. They don't even call themselves unions. It’s not the education of children, but rather it is all to be the extension and preservation of our members' rights. Now, that's just a statement of fact. Organizations can't serve 2 gods, little “g.” They serve one. And in the case of teachers' unions, it is the interests of their members. Now, let me tell you a live story. In 2000, a Buffalo school district had about 7,000 members and they were the most unionized public school system in the United States of America. And 7:00 a.m., on a school day, the leaders of the teachers' unions still on the Buffalo headquarters step called a strike at 7:00 a.m. on a school day. Now, many children already are on buses on the way to school. Many parents have already dropped kids off at school leaving their kids in the love care of teachers. Mistakenly. Does that sound like an organization that cares about kids? They were arguing for employee rights. Two more major points that really tick me off to some extent.

Teachers unions are sitting on both sides of the negotiating table in many cases. They-- teachers unions work with school boards so that they have representatives on the school boards. When I served as superintendent of Houston, one of my nine school board employees, actually an employee of the teachers unions, fortunately for me, both were reasonable people and we got along rather well. But many school district superintendents don't have that luxury. They have school-- they have school boards that have teachers unions representatives sitting on that side of the table; the unions sitting on this side of the table. They're negotiating with themselves. They're sitting on both sides of the negotiating table. Here is the worst thing, I think, that really fires me up. Teachers unions have awesome power to cause action in schools. They have zero responsibility for their student performance. That's just not fair. That's not fair. It handicaps the principals and the superintendents who are operating with both hands tied behind their back. The teachers unions are calling the rules. They're responsible for student achievement. That's no way to run a ship. And it simply will not work that way. Now, here again, I want to be honest and I want to be fair. We can't solely blame teachers unions for these complex issues we have in our school situation but they do bear significant responsibility. And the only way you can express that is to vote against this motion to indicate that we are the nation. If we're going to really reform our schools, we're going to have to wind back from the power of teachers unions. We can still have teachers unions. We're not arguing that we shouldn't have teachers unions. Our schools are over unionized and consequently reform has run into a road block. Thank you very much.

### Moderator
Claim: Thank you, Rod Paige. The motion is don't blame teachers unions for our failing schools and now to speak for the motion-- and we just heard Rod Paige say that superintendents have their hands tied by the unions. Well, Gary Smuts is a school superintendent of the ABC unified district in California, considered a district where the schools work and Gary, you have said in the past you do work effectively and successfully with unions. Ladies and gentlemen, Larry Smuts. Excuse me. I need to correct that for the record. Because it's not Larry, it's Gary. Ladies and gentlemen, Gary Smuts.

### Conspiracy Advocate (CA)
Claim: Both of us are here tonight. Secretary Paige, in a wonderful book he wrote with his sister, Dr. Elaine Witty, it was entitled "The Black/White Achievement Gap: Why Closing it is the Greatest Civil Rights Issue of Our Time." He says in the book, "Being taught to higher levels means educational support from factors outside of school. It involves the support and commitment from the entire education triage: home, school, and community." And Secretary Paige's call to improve the effectiveness of our schools recalls an article co-written by Professor Moe entitled, "Letting Schools Work." In that article, Professor Moe reports, "Effective schools treat teachers professionally. The teachers share in the school's goals and effective teaching in the pursuit of those goals. They participate extensively in school decisions within their classrooms. They are free to tailor their practices to the needs of their students, that effective schools are organized like teams held together by consensus, cooperation, and shared goals." It sounds like a teacher's union to me. Thank you, Professor Moe. Now, I must clearly delineate my prejudice, my frame of reference. I am from the ABC Unified School District, southern California, about 21,000 students. We're about 89% diverse, 38 different languages spoken in my school district. We have a remarkable relationship with our affiliate, the ABC-AFT. We're affiliated with the national American Federation of Teachers, second largest teachers union in the United States. We've formed our own charter and ABC is not a charter school. We have a charter partnership agreement with the ABC/AFT where the main work of the teachers' union in my district is student achievement and the conditions that support that. Student achievement is the main work of our teachers' union. In fact, last year, Laura Rico, the president of my teachers' union had a workshop where all the union reps came in and they changed their name from union rep to learning rep. And they were told by the teachers' union president the number one job that you have in this union is student achievement. Now, that doesn't sound like a teacher's union that has anything other than their main goal, the main idea that Secretary Paige talked about-- in my district, our union, and student achievement. Here are some examples of staff development in my district that's jointly sponsored by myself and our colleagues, American Federation of Teachers. It doesn't-- what I'm going to describe to you actually comes from the national AFT, from their educational research and dissemination program. These are some of the courses that are caught by our teacher's union: instructional strategies that work; reading comprehension; school, family, and community partnerships supporting student learning, which is actually almost exactly what Secretary Paige points out in his book that we need to improve schools. We spend-- actually my teacher's union spends 10s of thousands of dollars in direct staff development with our community and our teachers to improve learning. Now, don't blame my district's union for failing schools. They're one of the reasons my district is successful. Now, we have our challenges. We're a program improvement district. Last year, despite $34 million in budget cuts, we doubled the greatest gains in the history of the district. We passed the magic benchmark of 814-- 800, actually in California, went to 814. We didn't do that despite the teacher's union. We did that because of the teacher's union. Let me give you an example. In my district, 10 of my schools-- these are struggling schools that have just received an innovation grant where each of these schools has a separate program to innovate and improve that school specifically tailored to the needs of that individual school. That innovation grant came from the American Federation of Teachers National Organization. $3.3 million in innovation grants funded the ABC Unified School district, 10 of our 30 schools. That's not just in California or ABC. Actually, the grant funded programs and districts in 8 different states. The American Federation of Teachers National Organization is one of the most innovative programs in the United States. Now, some of the things that those innovation grants are funding in my district, I said partnership efforts in 10 schools. In other districts throughout the United States, they're working on community partnerships, working on using student assessment data to evaluate teachers. They're also working on creating charter schools. So if you're for charters, if you're for holding teachers accountable, using student assessment data, listen to the American Federation of Teachers. Now, Secretary Paige, Randi Weingarten agrees with you. That great teachers make the real difference in closing the achievement gap. In fact, the “Washington Post” reported in January that Randi said, "Fair, transparent, and expedient processes to identify and deal with ineffective teachers need to be developed." And she specifically pointed to student assessment data. Now, her direction was put in action most recently in the New Haven Federation of Teachers district by a vote of 842 to 39. That district agreed to use student assessment data to evaluate teachers. In addition, they agreed that the city could close schools if they didn't work and change the employees. Now, twice each year American Federation of Teachers hosts the Shanker Institute. I have been proud to be part of that since 2005. Let me tell you what we learned at the Shanker Institute. These are different workshops: state standards curriculum bridging the gap, partnering for a reform in troubled times, improving the quality and the use of student assessment data. The unions’ role in assuring that teacher quality matters-- teacher quality meets student needs. In every seminar I have been to, there has never been a session on how to keep crummy teachers. They don't do that. And in fact, in most cases, the superintendents I know that work closely with teachers unions find that we release more teachers to other industries than we do keeping them. In fact, in nearby Brooklyn, there is the United Federation of Teacher Institute. They do much the same thing. They use data, talk about communication, team building, professional development and action plans. States with teachers unions set the highest standards, according to “Education Week.” “U.S. News and World Report” reported on the most-- 25 most successful schools. Six out of 10 of those schools come from states with strong teacher's unions. Success, high standards, accountability. If you want that, support teacher's unions in schools where that works.

### Moderator
Claim: Thank you, Gary Smuts. Now we have our Larry. That's where I got mixed up. I'd like to introduce to speak against the motion-- and our motion is don't blame teachers unions for our failing schools-- our next debater does blame teachers unions for our failing schools. Larry Sand is a retired teacher and former teachers union member who grew disillusioned with the operation. He founded the California Teacher's Empowerment Network, and I've seen you described, Larry, in print as a pain in the union's back side.

I assume we'll see why. Ladies and gentlemen, Larry Sand.

### Scientific Advocate (SA)
Claim: I'm glad Gary brought up Mr. Shanker, because he is alleged to have said when school children start paying dues, that's when I'll start representing them. Now, I don't know if he did say that. Some people think he did, some say no. But that has been the teacher's union attitude ever since I began my teaching career here in New York City in 1971. In educating children, there is nothing more valuable than a dedicated and gifted teacher and nothing more harmful and destructive than a bad one. And it's those teachers, the mediocre and the incompetent ones that the unions typically represent. In fact, they punish good teachers in numerous ways. Unions insist that school districts not pay good teachers what they're worth. They insist on an archaic factory model of payment whereby teachers make more money by years on the job-- not productive years, just by calendar progression. Consider the greatest teacher of our time, Jaime Escalante, subject of the film “Stand and Deliver,” now unfortunately near death in his native Bolivia; attracted national attention at Garfield high school in Los Angeles with his spectacular success teaching college level calculus to gang members and other unteachables. Talk about poor students. What was the problem? Because he was willing to have more students in his class than the United Teachers of Los Angeles contract allowed for, he was basically run out of town by that union. When there are layoffs due to budget cuts, do the worst teachers get laid off? No. Do the permanents or tenure, a union must in every contract, the newest hires are let go. You're a teacher of the year? Too bad. You're double test scores? Too bad. But the unions will go to any length, any length to save the job of a bad tenured teacher. If you think I'm exaggerating, here is a quote from an LA union rep. If I'm representing them it's impossible to get them out. It's impossible unless they commit a lewd act. End quote. And maybe not even then.

You're laughing. This is a true story and this didn't happen very long ago. Was a former colleague, he's alleged to have touched a female student inappropriately. There are witnesses. The female student would not press charges. So they put X into the district office for a while, the so-called rubber room, which probably most of you know of. They decided to put him, by the union lore, they put him in another school. He apparently did the same thing. Back to the rubber room: sitting, sitting. Finally, one day, I guess he got bored. He decided to bring porn to the district office, the rubber room. He got caught. With the union lawyers’ help, he got put back into a school, another school, the third school now. And in short order, he got caught showing his female students some of his pornography collection. The last I heard he's back in a district office waiting for his union lawyer to make the next move. This is the kind of guy that really needs the union. Not a dedicated teacher. Not an honest teacher here. This is the kind of guy who really needs the union. By the way, the guy I'm talking about, Mr. X. is really a pussy cat compared to some of the teachers you have in New York. Just reading some things about a-- I'm only saying his name because it's in the newspapers, Francisco Olivares, who impregnated one of his students and his still on the payroll. Another instance of my middle school involved a teacher who decided to sunbathe topless on the athletic field at lunch.

It was a nice spring day. What happened? With the union's help, she was put back into school in an elementary school this time. Once again, a union rep in his own words, “I've gone in and defended teachers who shouldn't even be pumping gas.” Not my quote. This is a union rep. That's the mentality. Unions today function more like criminal lawyers than partners in education reform. Very importantly, too, the unions love the status quo and will fight to keep it. In California recently, education reformer, Bill Evers was attacked by a local union for trying to get Singapore math a new and innovative way of teaching a subject, but because learning all the different things you had to do to teach this was a little bit too much for some of the teachers, the unions decide to kill it. Very importantly, the unions are constantly trying to limit the number of charter schools. “The Cartel,” an excellent film by Bob Bowden, about public education has one of the most affecting scenes I've ever seen on film. It shows parents and children waiting to see if they won the lottery. That is if they got into the charter school. If charter schools have more children than seats available, very simply they'll hold a lottery. And in this scene the camera goes into-- close on the faces of the children and the parents who are winning the lottery and getting to the charter school and they're thrilled and you feel happy for them. And then they go into the people who didn't win, and these people are crying and sad and you feel horrible for them: very affecting scene. But these tears of joy and anger-- tears of joy and sadness turn to anger because you realize the unions are constantly fighting the establishment of charter schools as the UTLA did just about two weeks ago in Los Angeles. They were very successful at killing charter schools. Another abominable example, I'm going to speak a little quickly because I'm running out of time. The DC Opportunity Scholarship Program, it was created to rescue at least some children from the horrible school district, Washington D.C. We spent $27,000 per student. Probably the worst school system in the country. 1,700 kids, mostly poor, mostly black, won the lottery which gave them a $7,500 scholarship to get into the best schools they could, private or parochial. The program was a great success. The kids looked forward to going to school for the first time. They thrived. The parents were happy. The taxpayers saved money. The only ones not happy were the unions who cannot abide any competition for the government run monopolies, even though it has been shown that when school choice exists, public schools improve. I will close with a quote from Ron Williams who said about this situation, “The NEA seems far more devoted to its members than they are of the children they teach. It doesn't seem to bother them that they continue to fail the nation's most vulnerable children.” Amen to that, Mr. Williams. Thank you.

### Moderator
Claim: Thank you, Larry Sand. And that concludes round one of this Intelligence Squared debate.

## Round 2

### Moderator
Claim: We now have the results of our initial vote where we asked you, the live audience, to tell us where you stand on the motion. Our motion is don't blame teacher's union for our failing schools. Before the debate, the vote went like this. Those for the motion, those who say it's not the teacher's fault: 24%. Those who blame teacher's unions for our failing schools, against the motion: 43%. And we have 33% undecided. We'll ask you to vote once again at the end of the debate, and the team that changes the most minds during the course of the debate will be declared our winner. Now, on to round two. This is our middle round in which the debaters talk directly to one another, and take questions from me and also from you in the audience. And I want to begin with a couple of specifics-- specific charges that were laid out there without responded to. Terry Moe specifically saying that teachers unions operate against the whole notion of charter schools, that they try to stop them wherever they find them. I want to hear from the other side, true or not true. Let’s start with Randi Weingarten.

### Conspiracy Advocate (CA)
Claim: Well, given that the United Federation of Teachers under my watch, started two charter schools in Eastern York, it’s totally and completely untrue. What we want to do is we want charters to be held to the same accountability standards including the ones that we started, as any other school and what the evidence has been in New York, like the evidence around the country, is that charter schools instead of, as Diane Ravitch said, should take more of the most at-risk kids are actually taking fewer special needs kids and fewer kids with limited English proficiency. So we’ve open to, we think charters could be a great incubator for instructional practice and could be a great incubator for labor relations practice. But Terry, I don’t want New York to be as much as an evidentiary zone as Washington D.C. seems to be, which means let’s look at the Credo story which were done with a pro-charter advocate. What they said was, where 17 percent of the charters are better than public schools, 34 percent are worse, and the rest are the same. The idea is to actually find what works, make it sustainable and make it replicable. That’s what we’re trying to do and that’s what I’m trying to do.

### Moderator
Claim: Terry Moe, Randi Weingarten is saying no, it’s not true that they are against all charter schools.

### Scientific Advocate (SA)
Claim: Well let me first point out that New York State has a cap on the number of charter schools. It has a cap because this union put it there.

And even under the pressure of race to the top, they wouldn’t lift the cap. Right, so this is not an organization that’s in favor of charter schools. They’ve done everything they can to keep charter schools down. What they’re doing now in New York City is they’re running three charter schools to show if they can, that unionized charter schools can work, because what they want to do, is to unionize all the charter schools. That’s the only reason they’re doing it.

### Moderator
Claim: Randi.

### Conspiracy Advocate (CA)
Claim: I mean, what’s interesting Terry is that I didn’t know you were in my head so much. We are not running charter schools to unionize all charter schools.

### Scientific Advocate (SA)
Claim: Where’d the cap come from?

### Conspiracy Advocate (CA)
Claim: What we wanted to do, what we wanted to do was actually the New York City and State Union were in favor of lifting the cap and in favor of creating a level playing field to make sure that all kids could equally get into all schools. And if you recall, New York State became one of the finalists for Race to the Top so obviously whatever happened in the state legislature didn’t disqualify us from Race to the Top. The bottom line is, we need schools-- all schools: charter, public, private to be places where parents want to send their kids and where educators want to work. That’s the bottom line. How do we help all kids, not just some kids, but all kids.

### Moderator
Claim: Do you want to respond because I want to move on to another question, but if you’d like to respond.

### Scientific Advocate (SA)
Claim: I’ll just make one point. I mean, this is the standard response that it’s really all about kids? But the fact of the matter is, they’re trying to keep the number of charter schools down. They’re responsible for this cap in New York State and everything else is just a rationalization.

### Conspiracy Advocate (CA)
Claim: Terry, I wish we had the kind of--

### Moderator
Claim: Randi, I’m going to go on. Kate McLaughlin, who is arguing.

### Conspiracy Advocate (CA)
Claim: Charter schools in L.A.

### Moderator
Claim: Gary Smuts, I’m going to let you go. Gary Smuts, I just want to get to the--

### Conspiracy Advocate (CA)
Claim: Charter schools in L.A. and there’s magnet schools in L.A. “L.A. Times” article about two months ago by Howard Bloom pointed out that the most successful schools in the L.A. Unified School District are magnet schools. Now these aren’t schools that shut down, get rid of kids, get rid of teachers; these are schools that have a special focus, that keep their faculty. If you want the most successful schools in the L.A. area, it’s not charters. It’s not traditional schools. It’s magnet schools that have the same configuration, the same union. If you want success, go with magnets. Don’t go with charters, and don’t even go with traditional schools.

### Moderator
Claim: One more response from this side.

### Scientific Advocate (SA)
Claim: Are these magnet schools, schools of choice?

### Conspiracy Advocate (CA)
Claim: Most of the magnet-- all of the magnet schools,

I’ll answer this in my district. I have 10 magnet schools in my district. Students can-- no student leaves those schools, no teachers leave those school. We invite other students substantially though, better than 95 percent of the students are the same students that have always been there. And those schools are successful.

### Moderator
Claim: Larry Sand.

### Scientific Advocate (SA)
Claim: Yeah, just here in New York City, in Harlem, we have very successful charter schools like KIPP, Democracy Prep, and Harlem Success. The parents, as far as I know, there aren't enough to keep up with the demand, yet Randi is saying that-- seems to have a problem with charters. So she wants to go very slowly. It seems that the parents want these things because most of their kids are in hell holes. Now, this is not the-- this is not the union's fault that they're in hell holes necessarily, but it's the union's fault because they keep them in hell holes.

### Conspiracy Advocate (CA)
Claim: The best from a local standpoint-- in Lowell, Massachusetts, it's quite the opposite. They are actually closing the-- they actually force-- they wanted to close the charter school. And we actually appealed on their behalf, so they have to cut the school in half and stop teaching middle schoolers, and we will absorb those students back in the local--

### Scientific Advocate (SA)
Claim: You're saying that the union stood up for the charter school?

### Conspiracy Advocate (CA)
Claim: And the-- the school system. But what you don't know-- again, you say, oh, teachers are against charter schools. You're making up the story why--

--I am. Let me tell you why I am.

### Scientific Advocate (SA)
Claim: They-- actually, they're not saying that. They are saying teachers unions use political power--

--use political power to stop the proliferation of--

### Conspiracy Advocate (CA)
Claim: No, listen to--

### Scientific Advocate (SA)
Claim: With a teacher's--

### Conspiracy Advocate (CA)
Claim: From a--

### Scientific Advocate (SA)
Claim: With a teacher union.

### Moderator
Claim: Rod Paige, I want to let Kate finish.

### Conspiracy Advocate (CA)
Claim: From a local standpoint, we--from this charter school that was going to be announced-- got students back from this charter school which we welcomed. We don't get the funding for them for another year. So when the teachers unions bring up this issue, we're somehow against charter schools. There are major issues about the funding that comes with it. But when we speak it up, we're somehow obstructionist. That is not the case. The other issue about charter schools for me and for my type offers union is it's an equity issue. And my teachers union president has gone even to the governor and suggested that if charter schools are truly innovative, they should be a draft and not a cream of the crop selection.

### Scientific Advocate (SA)
Claim: They are not the cream of the crop--

### Conspiracy Advocate (CA)
Claim: And that-- and it is a total equity issue because we've all agreed that achievement gaps come from school-based issues. They come from social issues, and they come from economic issues. And if you alone base a lottery on which parents have gone to sign up, you have already changed some of those issues. So it is an equity issue.

### Moderator
Claim: To the other side, Larry Sand.

### Scientific Advocate (SA)
Claim: Go see Bob Bowden’s film. You tell me those parents and those kids are the cream. These are poor people. Maybe they're the cream of the poor people. I don't know.

### Moderator
Claim: Let's bring this back to the issue of unions. And I want to go to the side that is arguing that teachers unions are to be blamed for the failure of the schools. And the other side, your opponents are arguing-- two of your opponents used in their arguments the point that there is no real correlation between states that have strong teachers unions and poor academic achievement. Kate McLaughlin, your opponent said there is absolutely no research on that. And Randi Weingarten pointed to the numbers of states where actually there were strong unions and strong school results. I'd like one of you to respond to that.

### Scientific Advocate (SA)
Claim: I'd be happy to respond, but I don't know where this stuff comes from, really. Look, many, many, many, many factors influence student achievement. And to say basically that schools in the South don't do as well as schools in the North, which is true, and that schools in the South don't have unions and the schools in the North do, and to say, gee whiz, it must be because unions are good for schools. I-- don't try that at a university. It doesn't wash.

So, look, as far as the research goes, I don't know where Kate's getting this. I mean, there is a research literature. Actually, it's pretty big on the impact of collective bargaining on student achievement. She says there's nothing. There is, plenty. It started sort of back in the 1980s. Most of the literature I think is not good. But that's typical of most of social science. A lot of this stuff is bad. And part of the reason is that things are complicated. It's very hard to do good studies. So you can't just like count up studies. The results in this literature are pretty mixed. And I think it's partly because, A, it's complicated, and B, a lot of the studies don't do it very well. But there are two studies that are actually in very top-level journals, they have been through very rigorous peer review process. They are one by Caroline Hoxby in the “Quarterly Journal of Economics,” 1996. Another one is by me in--

### Moderator
Claim: But that one's really good.

### Scientific Advocate (SA)
Claim: Yeah, this-- it's a lot better than Caroline's. And it is in the “American Journal of Political Science,” 2009. Both these studies show, through a quantitative analysis, both of them very extensive, that the impact of collective bargaining on student achievement is negative.

### Moderator
Claim: Okay. Randi Weingarten, teachers union president.

### Conspiracy Advocate (CA)
Claim: So, Terry, you've actually just made the point that I think many of us are trying to make on this side, which is it is complicated. There is not one factor that either causes student success or-- or is an obstacle to it. And that's exactly what we are trying to say. So ultimately, just like we did not say that teacher unions were the reason why Maryland or Massachusetts or New York were so successful-- and by the way, that was just in quality counts from education week. We were not the ones that said that Finland or Japan were most successful. We're just saying that those are the correlations. Now, there is one person who used to actually agree with you hugely Diane Ravitch who, in looking at much of the evidence over the course of time, whether it was on charters or whether it was on vouchers has thrill just written a book saying slow down. The evidence of these kinds of market strategies just doesn't work. My point is this: Whether you look at-- everyone is going to find anecdotes to fit into their case. That's not going to help one more child learn. We are searching for what actually works. So regardless of the quotes when they hurl at me from the NEA or from other places, I stand by the record that we have in turning around schools in New York City. Mr. Rudy Crew, who is sitting there, and I, together did probably the most important reform strategy in New York in the late 1990s, early 2000, where we actually turned around schools in Harlem. We turned around schools in New York City. We want to make sure every single child has a choice. Once they have a choice for a charter, so be it. But every child should have a choice for a neighborhood high school or a neighborhood school. And Larry, last point to you, which is this: Just recently, unlike what you said about LA, in LA, there were 36 schools that were put up for grabs by the LA school board. The charters love this. They wanted this competition. And in that competition, regular school teachers, supported by their union, won 29 of the 36 schools because of their plans. The bottom line is we need to do the things that Gary and Kate talked about in terms of helping all kids, well prepared and supported teachers, real engaged curriculum, safe and orderly environments which is what we see in charter schools all the time, good, good management that works together. And at the end of the day, if we have to find ways, as I said in 2004, to police our own profession, fire teachers that are not making the grade, we want to do that. That's who this teachers union is.

### Moderator
Claim: Okay, I want--

### Conspiracy Advocate (CA)
Claim: We want the best and the brightest for all of our young people in this country.

### Moderator
Claim: All right, Randi, I gave you quite a long run with that.

### Conspiracy Advocate (CA)
Claim: Sorry.

### Moderator
Claim: And I want--

### Conspiracy Advocate (CA)
Claim: Sorry.

### Moderator
Claim: That's all right, but I do want to urge us to stay as close as possible to our motions. And I think all of us probably share a sense that we want things to improve. But I want to discourage too much grand-standing on the point because we really want to get to the issue at hand.

I want to go to the audience. That's not to say that any of us disagree with that. Just the nature of the debate. I want to go to the audience for questions now. And what we will do is have microphones circulate in the aisles. And if you raise your hands and identify you, please stand, and I'll bring a microphone to you. Hold it about a fist's distance away from your mouth so that the radio audience can hear you. And I want to urge to you actually ask questions and to try to move this debate along in the area in which we are talking and not to make grand-standing speeches or to debate the debaters. They are here to debate each other, I hope prompted by you. And there's a gentleman, a person with eyeglasses there getting the microphone now. If you could just rise, sir, and identify yourself.

### Moderator
Claim: Well, I make two-- two sentences.

### Moderator
Claim: I would rather that you just make one statement and go to a question.

### Moderator
Claim: Yes, okay. You don't have problem with having a good car. You know which cars are good and you can choose. You know this debate there was parents who have basically forgotten and the question is, in the last two, three decades, have teachers unions helped parents to know which teachers are good and which teachers are bad, and second, have they helped parents during the last two, three decades, not last two, three years, helped parents to be able to choose good teachers?

### Moderator
Claim: All right, I'm going to take this-- thank you, sir, we get the point, and we need to move on. So I think the question probably, both sides can respond, but probably is primarily directed to this side. And I also think it's a rephrasing of the question or a statement that's been put forward by your opponents who argue that the interests of teachers' unions are not the interests of the children, and none of you have actually addressed that particular point directly, that point being, as has been stated, that teachers' unions are there to grow their numbers, to protect their salaries, to protect seniority. And in terms of those specifics, if you can connect that to the gentleman's question, is it good for our kids and is it good for the parents in knowing what teachers are good and what teachers are bad.

### Conspiracy Advocate (CA)
Claim: I taught for 14 years--

### Moderator
Claim: Gary Smuts.

### Conspiracy Advocate (CA)
Claim: --and never did I grade a test or work with my class thinking that-- about my standing in the teachers' union. That doesn't even go through your mind. I would agree that teachers unions don't rank teachers, but neither do administrators. There's no ranking of teachers in any school by anybody. I don't even know if it's possible. I don't even know if it's desirable. It wouldn't be something I would recommend that management do or teachers unions do. I don't think it can be done. I don't think it necessarily should be done. There are a variety of factors. We've all had teachers that have been enormously successful with some folks and not very successful with others. You can't blame teachers unions for not ranking teachers because nobody ranks teachers like that.

### Moderator
Claim: And what about the part of the question I brought, too, because this is an itch I need scratched the whole issue that the objectives of a union is not the same thing as the objective of taking care of the kids in the best possible way in the educational system.

### Conspiracy Advocate (CA)
Claim: That's not true in my district. The changed their name from union rep to learning rep.

### Conspiracy Advocate (CA)
Claim: And it's not--

### Moderator
Claim: Let's hear this out because--

### Conspiracy Advocate (CA)
Claim: The number one focus of the teachers' union and in the workshop where that was done, what they worked on, were all of the strategies and techniques to produce successful students. The number one job according to my union president of the union reps, the reps in my district, is student achievement. And we work together to do that. It's one of the most powerful forces in our district. I've had great administrators and they work with teachers to produce successful students. Why would you want it any other way? Fighting each other doesn't work. It's a dumb plan to fight each other and say, "One side's going to win, and one side's going to lose." I don't believe in that. You know you got to work together, and if you don't, it is never going to work. That side said that you never-- Secretary Paige said, "You're never going to do away with teachers' unions." He doesn't want to do that. If that's the truth, then we'd better start working together or we're going to die together.

### Conspiracy Advocate (CA)
Claim: I think if you look at the-- rather than--

### Moderator
Claim: Randi, can you hold a minute--

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: --because we've had quite a bit from this side, and I will come back to you. Terry Moe, I had indicated you could respond to this. Terry Moe.

### Scientific Advocate (SA)
Claim: Yeah, I just wanted to say that basically the teachers' unions don't want teacher performance to be measured, and they especially don't want any information to get out about how well teachers do. Actually the testing technology is quite sophisticated now. And it's possible, not just to do value added calculations for how much kids learn during a year but also to take into account, through statistical controls, student background characteristics, how much students know at the beginning of the year so that you can control for that, and so on. And so it is certainly possible to do these things in a very systematic and rigorous and fair way. And I think what we're going to be leading toward eventually, unless the teachers' unions are able to block it, is a system where we have information on teacher performance under a variety of conditions and we move towards transparency, where it is possible to let people know what teachers are good and what teachers are not good, because if teachers are not good, people should know that so that they don't put their kids in those classrooms. It's very important.

### Moderator
Claim: Randi Weingarten.

### Conspiracy Advocate (CA)
Claim: Well, well--

### Moderator
Claim: Well, let me just bring in Randi Weingarten, please.

### Conspiracy Advocate (CA)
Claim: Well--

### Scientific Advocate (SA)
Claim: There's no--

### Moderator
Claim: I'd like to bring in Randi Weingarten, and then I'll come back to you.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: I will.

### Conspiracy Advocate (CA)
Claim: So the question is-- the question, I think, John, you keep on asking is, what’s the teacher union job? And if you look at the three of us, and you actually listen to our members, you’re actually right. We are paid to listen to our members because very few other people actually do listen to the voices of teachers. There was a Gates study recently that said that of 40,000 teachers, that said that overwhelmingly what they wanted; number one issue is they wanted to be supported; they wanted to be respected. That is very similar to polling that we have taken of our members and very similar to what I see when I was a local union president, where we had the most extraordinary people in New York City teaching in our classrooms. What we see is that members by a four to one and five to one margin have said to us, they want us to fight for the tools and conditions they need to do their jobs. And ultimately, when we try to fight for budgets for schools, when we try to fight for equity; when we try to fight to ensure that class sizes are low and that they’re safe and reasonable environments for kids so that kids don’t get bullied, when in some ways we try to fight for the things that I know the Harlem parents have tried to fight for in the schools that they have. That’s the integration between teacher unions and kids.

### Moderator
Claim: Okay, Rod Page.

### Scientific Advocate (SA)
Claim: I’m going to go back to the ranking of teachers. And I’ll admit that I can agree that there’s no formal ranking of teachers. But let me tell you, there is a ranking of teachers, while I served as superintendent of schools in Houston, it was very clear to me that the kids know who the best teachers are. They know who the poor teachers are.

The other teachers know who the poor teachers are. Absolutely; they know who the bad teachers are too, there’s very much clear ranking. And this is not ambiguous at all. The rankings are there; we don’t use in a formal way or to make policy, but they’re ranked.

### Moderator
Claim: I’d like to go to another question, before I do that, just for radio, I want to say the following. We are in the question and answer section of the Intelligence Squared U.S. Debate. I’m John Donvan, your moderator. We have six debaters, two teams of three debating this motion: don’t blame the teachers’ unions for our failing schools. To another question right in front-- and then I’ll start moving to this side. Please rise, thank you.

### Moderator
Claim: Hi my name is Alexis Moore and I’m a sophomore at Princeton University and the vice president of Students for Education Reform. And this week, I’m here with a group of 15 undergraduates who are studying education reform here in New York City.

### Moderator
Claim: Can you get to your question please?

### Moderator
Claim: Yeah. Half of us are tutoring at Paul Robison High School, which is slated for closure and last year Robison’s four year graduation was 40 percent.

### Moderator
Claim: I really need you to get to your question. Please get to your question okay.

### Moderator
Claim: And the UST has come out in opposition to the closure of the school which would open up new options for people in that neighborhood and those students. The question goes to the side for the motion. Why come out against the closure of a poor school? Thank you.

### Moderator
Claim: Thank you. Do you feel you had information or did I suppress too much?

### Conspiracy Advocate (CA)
Claim: I think none of have enough information about the specifics about this. I probably have more than the rest of us. But I don’t-- let me tell you about two other schools that I know about well. Meaning, I don’t know about Robison but I do know--

### Moderator
Claim: Let’s move on. With respect to your question and I did push you to cut to the chase; I think there was information and I don’t think the panel’s familiar enough with it so I’m going to move on, but thank you very much. To this side, right down front: if you could stand please. And could you wait for just one second; I want to make sure the camera’s on you. Okay, thank you.

### Moderator
Claim: My name is Denise Saul and I too am a teacher. I taught in public, in private. I’d like to know how many teachers there are in New York State and how many teachers were fired this year.

### Moderator
Claim: Randi Weingarten.

### Conspiracy Advocate (CA)
Claim: How many union people-- teachers union people are in this audience?

### Moderator
Claim: First answer the first question; I’m going to ponder the second one.

### Conspiracy Advocate (CA)
Claim: I mean I wish I was actually, so-- you want to ask.

### Moderator
Claim: The problem I have with asking how many unionized teachers are the audience, because I’m not sure how to ask the other side of the question. And we’re open to everybody and if there’s a notion that the audience is packed, that’s not something we can control. So I’d rather not have an identification.

### Conspiracy Advocate (CA)
Claim: Let me just say. Let me just say there was no attempt on any of our parts to either pack the audience or to give people invitations other than the six or ten that-- invitations that I received. So there's no-- there was no attempt to do any of that. Now, having said that--

### Moderator
Claim: But there's a suspicion, which is interesting.

### Conspiracy Advocate (CA)
Claim: Well-- it's not--

### Moderator
Claim: Which I think goes to the tone of where the lack of trust is.

### Conspiracy Advocate (CA)
Claim: Well, but I think that the tone-- what I have experienced in terms of New York City is that in a-- most teachers right now, as we are speaking, are at home actually grading papers and marking lessons. And frankly, from my perspective when I was the teachers union president here, I never actually asked people to come or pack an audience or do these things, from my perspective. I can't talk for other than myself. In terms of the question about firing, what tends to happen in the teaching ranks is that there is a huge attrition rate of teachers. And so you have essentially half the new teachers within the first five to seven years actually leave the profession because it is such a tough, tough, tough place to work. And whether it's because they don't get the support that they need or a variety of other things, whether it's salaries or other things, what you see is that you use both the statistics of how many people have attrited out. And in New York City last year, my understanding was that about 30 to 40 percent of the teachers, or about 30 percent of the new teachers attrited out within the first five years in terms of firing on what the statistic is. But I will tell you, in terms of the peer intervention process and program that we started in 1987, first under my predecessor, Sandy Feldman and then myself, we actually counseled hundreds of teachers out of the profession who we thought, after we tried to help them, were not up to snuff.

### Moderator
Claim: Let me come to Larry Sand.

### Scientific Advocate (SA)
Claim: Yeah. If you send me an email Thursday morning, I will get you an answer to your question. I'll give you an answer to a question, though, that you didn't ask, which is how many teachers got fired in New York state-- excuse me, New York City. And in 2008, it was 10 out of 55,000. Does that mean that there are 54,990 competent teachers in New York?

### Conspiracy Advocate (CA)
Claim: Actually, it's not-- Larry, that's actually not true. There were in 19-- in 2008, the last year I was here, there were over a thousand teachers that were terminated for lots of different reasons.

### Moderator
Claim: Okay, Larry, did you want to continue your point? I want to ask you whether that question was a plant or not. I'm joking. Do you want to continue your point?

### Scientific Advocate (SA)
Claim: I have very different statistics than--

### Moderator
Claim: I think you made it. I'd like to go a little farther up-- black T-shirt. Can you rise and wait just a second? You're in a little bit of darkness, so it will take the camera a second to adjust. And they found you. Thank you. Go ahead, sir.

### Moderator
Claim: First of all, Mr. Sputs, thanks-- Smuts, I'm sorry. Thanks for sharing your ideas about the union in your area. I'm thinking of changing my name to handsome genius and see if that works as well for me as it did for you.

But my question is for-- for the union representatives here is, you keep making the case that we should be listening to teachers and everyone's thinking about the best interests of the children. But shouldn't we be listening to parents first and not--

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: So why are you standing in the school house door and stopping parents from having the choice of where to send their children to school?

### Moderator
Claim: Kate McLaughlin, could you take that one?

### Conspiracy Advocate (CA)
Claim: Well, and again, I firmly admit this. I am a Lowell girl, and I don't know everything that goes on in the big wide world. But our public schools in Lowell are all choice schools. There are no neighborhood schools. We're a city of a little over a hundred thousand people. We have 23 schools, and parents choose. It used to be based on themes, much like the magnet schools. But unfortunately with the high-stakes testing, the themes have gone to the wayside, and all of the well-meaning grants with mandates attached. So I can't speak to that. But the parents do have the choice. So I actually am a parent of a Lowell public school child. And I went to the central office and registered him. I put down my top three choices for schools, very much like what you're all advocating for. And that's our public school system, and that's all something our union supports.

### Conspiracy Advocate (CA)
Claim: My district has--

### Moderator
Claim: Gary Smuts.

### Conspiracy Advocate (CA)
Claim: --29 regular K-12, kindergarten, middle-- I mean elementary, middle and high school, one adult school. We're schools of choice. We have one-third of our schools are magnet schools. Parents can make choices. Every school in our district has a school site council where parents are represented. The school board, parents from the district, it's a very powerful influence in our school district, as it should be. And we-- we have board advisory committees that are made up of all parents in the district that report regularly--

### Moderator
Claim: Let me ask Rod Paige, what do you make of what he's just saying now?

### Scientific Advocate (SA)
Claim: Well, I'm not sure how to-- what to make of that, actually. You're saying that choice is good.

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: Yes. I want to hear plenty of that.

### Conspiracy Advocate (CA)
Claim: And we've had choice since I was in elementary school. We all went to public schools.

### Conspiracy Advocate (CA)
Claim: We also believe that public choice is good, and we have never-- I know there's an issue here in terms of what must be going on in New York City right now because obviously feel the heat in this room about that. But ultimately, we believe in far broader choice and that every parent should have a public neighborhood school in which to send his or her kids and then ultimately have the broadest possible choices. New York City has actually the broadest high school choice program of any school district in the nation.

### Moderator
Claim: Terry Moe.

### Scientific Advocate (SA)
Claim: Look, this is all in code. So basically the unions are in favor of choice as long as the schools that kids can choose to move into are unionized. And so they are all in favor--

This is just true. They're all in favor of public school choice. And that means-- what she really means is moving from one regular public school to another regular public school. They're all unionized. They're all under the contract. Charter schools are public schools.

But the unions have done everything they can to keep the number of charter schools down everywhere.

### Moderator
Claim: Gary Smuts, respond to that.

### Conspiracy Advocate (CA)
Claim: Well, we don't have any charters in our school district. Nobody is-- anybody that's applied, trouble is they hadn't-- the couple that did, didn't adopt the California state curriculum, and that's a requirement in California. There's charter schools that just started, a whole bunch up in Los Angeles. Charters in Southern California aren't that particularly--

### Moderator
Claim: Terry's bottom-line point was that when teachers are talking about charter schools and schools in general, they're all for change and choice but not if the school is not unionized. Do you think that that's a fair point?

### Conspiracy Advocate (CA)
Claim: It's a little hard in California because we're teacher union state. So other than Catholic schools--

Second largest system in the country.

### Conspiracy Advocate (CA)
Claim: I take total exception because my issue as a union leader about charter schools, if they are public schools, and this is my experience as a teacher, and hearing from the other teachers, why is it when a child needs an outside placement that costs over a hundred thousand dollars, the charter school sends them back to the public schools to pay for.

If they are a public school, that is their student. They should support him.

### Moderator
Claim: But, Kate, to the point; do you unions only want unionized schools?

### Conspiracy Advocate (CA)
Claim: Unions--

### Moderator
Claim: No, let me ask Kate because she's in--

### Conspiracy Advocate (CA)
Claim: Sorry.

### Moderator
Claim: --mid flow here.

### Conspiracy Advocate (CA)
Claim: As a union leader, I see what collective bargaining does for a school in a school system.

### Moderator
Claim: Is that a "yes"?

### Conspiracy Advocate (CA)
Claim: I-- no, it's-- I think it's a complicated question to answer honestly. No, to answer honestly. I believe in unionism. And I believe that--

--a lot of the charter schools are for profit. And I think that unions help keep the ideals of American values in our schools. That is my honest answer.

### Scientific Advocate (SA)
Claim: What is an American value?

### Moderator
Claim: Actually, I want to come to you, Randi, but I want to give Larry a chance just to keep this evenhanded. Now we'll come--

### Scientific Advocate (SA)
Claim: In addition, you're talking about choice. It's very interesting. In the big cities, 40 percent of public school teachers send their own children to private schools which are not unionized. What does that tell you?

### Moderator
Claim: Randi Weingarten.

### Scientific Advocate (SA)
Claim: In the United States Congress about 35 percent of United States Congress sent their children to private schools also.

### Moderator
Claim: Randi Weingarten.

### Conspiracy Advocate (CA)
Claim: I don't.

### Conspiracy Advocate (CA)
Claim: The overwhelming number of teachers opt to join a union because whether it's in New York state or other places, everyone has a choice as to whether or not to join a union, and ultimately--

--people-- they do.

### Scientific Advocate (SA)
Claim: Randi, Randi, Randi, Randi.

### Conspiracy Advocate (CA)
Claim: Excuse me.

### Moderator
Claim: Let's let Randi finish her point, and I'll come to you, Rod.

### Conspiracy Advocate (CA)
Claim: Legally everyone has the choice. In New York City they have the choice. All over the country they have the choice. They may not have the choice about whether or not to pay for the services the union renders but they have the choice to join the union. And in New York City 96 percent of the people who teach in New York City opt to join the union. Now, the issue around the country-- and I believe the same way as Kate, I had lots of opportunities in my life to do lots of different things, I chose not only to be a teacher but I chose to be a union representative. I chose to do this because I believe in my heart and in my soul that what unions do for kids and for teachers as well as for working people is to lift all boats. I said this initially. I said, "We are not perfect, just like superintendents aren't perfect, secretaries of education aren't perfect-- " "-- presidents of the United States of America aren't perfect, but at the end of the day, if you look at the historic record, when the unions had the kind of clout they used to have in this country, we had a vibrant middle class." What we are trying to do as a trade union movement is to insure that kids get the services that they need and to insure that teachers get what they need to do a good job.

### Moderator
Claim: Terry Moe.

### Scientific Advocate (SA)
Claim: The last part of that, can that not be true, in fact? Because that--

### Moderator
Claim: But respond to her point.

### Scientific Advocate (SA)
Claim: Well, what was the point that you want me to respond to?

### Moderator
Claim: Which point--

### Scientific Advocate (SA)
Claim: Because she made a lot of points.

### Moderator
Claim: Her last point was that creating a situation where teachers are protected and comfortable, safe, and Kate had also earlier made the point, safe from various kinds of vicissitudes of administration, that they can take chances in the classroom, that they can do all of those things, that they have some sort of protection. And there's a logic to that, and I'd like you to respond to it.

### Scientific Advocate (SA)
Claim: I think that-- first of all there are laws against arbitrary treatment, against discrimination, and so on, that just apply to workers generally. And so what I would like to hear is why it is that teachers are so vulnerable to these things that they're a special category of people in the United States, that they of all these people deserve to have a job for life, so that they can't be fired for incompetence.

### Conspiracy Advocate (CA)
Claim: Well, teachers shouldn't have a job for life. And they should be fired for incompetence. The issue, and I said this a couple of months ago in a speech that neither you, nor Larry, nor Rod have actually acknowledged in the work that you've-- or the statements you've made today, we want to have valid and reliable evaluation systems. Teachers do not like when they are just simply thrown the keys and told, "Do it." There are many of us when we first started teaching who had real frustrations in terms of not being able to connect to kids, not knowing how to do the things we needed to do. And ultimately what we've yearned for is to have real development and evaluation programs. And, in fact, Larry, I said just two months ago, student learning must count as part of teacher evaluation, and ultimately what the ABC School District is doing, what actually the Central Falls School District was doing before the teachers were fired en masse was to try and create these evaluation systems that Arne Duncan and I have both said are really required.

### Moderator
Claim: Terry Moe, or do you-- Terry, do you want to cede to your partner, Larry, because, Larry, I thought you had your hand up-- if I'm wrong--

### Scientific Advocate (SA)
Claim: Well, I was actually--

### Moderator
Claim: Larry Sand.

### Scientific Advocate (SA)
Claim: --I was going to address another issue of Randi's that she made earlier or--

### Moderator
Claim: Sure.

### Scientific Advocate (SA)
Claim: Okay--

### Moderator
Claim: --just briefly what it was?

### Scientific Advocate (SA)
Claim: Well, she said 96 percent of teachers, I believe, choose to be in the union in New York, is that--

### Conspiracy Advocate (CA)
Claim: I'm saying in New York City.

### Scientific Advocate (SA)
Claim: Right-- okay. If you are interested in a real choice-- for people who don't know, New York is a non-right to work state, which essentially means you have to join the union, as is California.

### Conspiracy Advocate (CA)
Claim: That's actually not true, Larry.

### Scientific Advocate (SA)
Claim: Okay, let me finish, Randi, please. In California you pay $1,000 a year to the union. It's actually even a little more than that. If you opt out of the union you don't get a choice to opt in, if you opt out you get back about $300 dollars. $700 dollars still goes to the union whether you want it or not. It’s like getting a divorce from your wife that you never wanted to marry the first place and you’re still paying alimony.

### Moderator
Claim: Let’s go to one more question. On this side, yellow shirt. And I really hope it’s good because you may be our last question. And make it a question.

### Moderator
Claim: As everyone stated on this side of the table that the real meaning or purpose behind the unions is to look out for the kids, if something were to benefit the kids in any of your school districts, but it meant approving a salary reduction, would you vote for that salary reduction?

### Conspiracy Advocate (CA)
Claim: A lot of unions have done that. And what we’re seeing is-- what we’ve seen is, I know I’ve negotiated when I was in New York City, as did my predecessor Sandy Feldman; we negotiated deferral agreements; we negotiated-- we just negotiated changes in pensions in order to save money for kids. I know.

### Moderator
Claim: Okay Randi, I want to move so please state your point that the answer is yes, it does happen. Purple sweater?

### Moderator
Claim: I’d like to address all three, to the panel again.

### Moderator
Claim: On which side? Ma’am, which side?

### Moderator
Claim: To the side against unions.

### Moderator
Claim: Okay.

### Moderator
Claim: If you could discuss who are the gatekeepers to who becomes teachers, because it is not the unions. And how do you feel about charter schools using public spaces? And Larry, Bob’s movie “The Cartel” also implicates state government, but Mr. Page, I would dare say, Mr. Bush’s friends the CTB, McGraw-Hill testing company,

### Moderator
Claim: Okay unions. Can you rephrase your first question please? The first on your list, can you rephrase that?

### Moderator
Claim: How do you feel about who are the gatekeepers to who becomes teachers; it is not the unions.

### Moderator
Claim: Okay, I think that’s the most relevant to our topic. Does anybody want to--

### Scientific Advocate (SA)
Claim: Who will be-- if you have a problem, who do you go to, is that your question?

### Moderator
Claim: No.

### Scientific Advocate (SA)
Claim: What’s the gatekeeper-- I don’t understand--

### Moderator
Claim: How do they become-- does Board of Ed let them in? The people who are bad teachers; some of them apparent when they go for interviews. Some of them are apparent on paper. I see--

### Moderator
Claim: Okay we have the question, who gets to choose who gets hired as a teacher. Are you saying if not the union or it’s not the union.

### Moderator
Claim: It’s not the union.

### Moderator
Claim: It’s not the union. All right I think her point is that the bad teachers aren’t because the unions are there; the bad teachers are in the system because the school administration hired them in the first place, therefore bad teachers are not the union’s fault. Rod Page.

### Scientific Advocate (SA)
Claim: Yes, making these decisions are really difficult decisions and we want the universities to do better. We want the administrators to do better. But once the situation has been proven, that this is a sub-par teacher, then we want to have some system to remove the teacher from the environment because we know that it’s not a good idea to have a teacher who’s not competent in front of children. That’s the only reason for that.

### Moderator
Claim: Another question, I think we have time for one more. Green sweater.

### Moderator
Claim: So I guess, one of them is a very quick question.

### Moderator
Claim: Only one question.

### Moderator
Claim: Okay.

### Moderator
Claim: Choose.

### Moderator
Claim: So we talked a lot about unions defending teachers who we thought were less than competent. Is it the fault of the union that they’re defending them and availing them of their rights or that there’s a system that means that they’re actually successful at doing so?

### Moderator
Claim: I actually didn’t understand the question.

But I think there’s something there and I want to make sure our audience--

### Moderator
Claim: I guess the question would be, we don’t blame defense lawyers for defending their clients because we have a judicial system that allows for prosecutors and defense lawyers. Similarly, should we blame unions for defend-- for availing themselves of their rights to defend their constituents and not--

### Moderator
Claim: Let me that.

### Conspiracy Advocate (CA)
Claim: And I thank you for that question because that was the biggest myth for me as a new teacher. I too thought oh, teachers unions keep bad teachers around them. As I became a building rep and now the vice president, I’ve seen these cases actually pan out. And it’s exactly what you said; due process is not an easy thing to defend to people. And it’s like you said, I mean the defense lawyer didn’t murder the person. But somehow it seems that unions are taking the rap for the actions of someone else when they’re actually defending the due process. And in the actual case, I’ll give you an example, this is what floored me when I learned about this. Can I just say one thing? You can’t grieve opinion. So in the case of a principal writing something, and giving a teacher an unsatisfactory-- teachers unions can only talk about the procedures that happened. We actually can't defend the work of a bad teacher.

### Moderator
Claim: Larry Sand.

### Conspiracy Advocate (CA)
Claim: We defend procedure which is exactly--

### Moderator
Claim: Point made. And Larry Sand.

### Scientific Advocate (SA)
Claim: Okay. Very quickly, to answer your question, sir, yeah, they act as defense lawyers. I agree with you. But they also make the rules. They make the laws. So it seems to me to be a conflict of interest.

### Moderator
Claim: And that concludes round two of our debate.

## Round 3

### Moderator
Claim: Okay. Here's where we are. We are about to hear brief closing statements from each of our debaters. They will get two minutes each. After that, you will be asked to vote on where you stand on the motion. This will be your last chance. This will be their last chance to change your minds on our motion, which is don't blame teachers unions for our failing schools. We asked you to vote before the debate began, and reminding you of the results we got, the motion, don't blame teachers unions for our failing schools. Those for the motion who stand by teachers unions: 24 percent. Those against the motion, who blame teachers unions: 43 percent. Those undecided were 33 percent. We will ask you to vote once again and pick the winner right after the closing statements which will begin now as we start round three, closing statements, two minutes each. And to lead off against the motion: Larry Sand, retired teacher and president of the California Teachers Empowerment Network.

### Scientific Advocate (SA)
Claim: Okay, thank you, John. And thank you, Mr. Rosenkranz, I think this is a wonderful forum, and I'm very appreciative to be a part of it. Yesterday, March 15th was a day of reckoning for many teachers across the country. In a bad economy, that's when the letters of possible layoffs also known as RIFs, reduction in force notices, go out to all teachers-- go out to teachers who might be losing their job. In my school's retirement lunch last June-- there were more than retirees saying goodbye. We lost several of the hardest working, most effective and popular young teachers on campus. Several teachers-- we all know who they are. The kids know, the parents know, the teachers know-- should have been the ones saying goodbye. But because of the union mandated seniority rules, they weren't. As a parent, a grandparent or just a fair-minded person, don't you want your child, any child, to be taught by the best teacher, not the longest employed teacher? Of course you do. But that is not what happened in my school and other schools around the country. Yes, the teachers unions are not the only problems with public education today, but the extent of the damage they have caused cannot be exaggerated. In closing, to show you how the twisted the situation really is, what could be more preposterous than this: They go to great lengths to keep the misdirected and other sexual predators in the classroom. The union hounded Jaime Escalante, one of the greatest teachers of our time, out of the classroom and more recently destroyed the hopes and dreams of thousands of poor children in Washington, D.C. Please join us in sending the teachers unions a resounding message and vote no on your ballot. Thank you.

### Moderator
Claim: Thank you, Larry Sand. Our motion is don't blame teachers unions for our failing schools. And summarizing his position for the possession motion standing by teachers unions is Gary Smuts who is superintendent of the ABC United school district in California.

### Conspiracy Advocate (CA)
Claim: ABC Unified.

### Moderator
Claim: Pardon me. Let me reintroduce it so I have it correct. Did I say ABC news? It comes out sometimes. Gary Smuts, superintendent of the ABC united school district in California. Did I get it wrong again?

### Conspiracy Advocate (CA)
Claim: You got it wrong again, but that's okay.

### Moderator
Claim: You know why, because I'm reading incorrect copy.

### Conspiracy Advocate (CA)
Claim: ABC Unified School District. We were separate school districts. We all came together.

### Moderator
Claim: All right. Superintendent of the ABC Unified School District in California.

### Conspiracy Advocate (CA)
Claim: Thank you. Thanks for the correction. Accountability, innovation, standards, high achievement, teacher training, teacher performance measured by student achievement, these are hallmarks of the modern teachers union. Now some teachers unions aren't modern. But those that are do these things. It is implied that the teachers union or non- unionon is the only veritable here. And they've tried to use weasel words to get out of that. Oh, not all of them or some of them. But the case is if you look at the proposition, you have to blame teachers unions, I guess in each and every case. You have to deny poverty, poor budgets, lack of parental support, poor boards, poor state leadership, poor superintendent. You have to say none of those things count and only teachers union counts. They know that's not true, and they've said so. So you can't blame-- just blame teachers unions. And you know that. There's a lot reasons schools don't work. And it's not just teachers unions. Professor Moe said that teachers unions are major obstacles to school improvement. Everywhere? Not in my district. So the proposition isn't true in my district. It isn't true in Kate's district. It isn't true in a lot of districts. And you've got to be fair about that. It's not true in a lot of school districts. Professor Moe pointed out that principals, 90 percent of them said they can't get rid of bad teachers. That's not a very good system. Why not work with teachers unions to get rid of bad teachers? That's what Randi Weingarten wants to do. Magnet schools work better than charters. I'm all for magnet schools. But the AFT's not against magnet-- charter schools, either. Larry Sand told us a lot of stories from band camp. I don't think that that's a good reason to say teachers unions are bad, by sharing horror stories from individual places throughout the United States. Being a superintendent is a hot, sweaty business. And it's hard enough doing it by yourself. But I'd much rather work as a superintendent with my colleagues from the American Federation of Teachers to increase student achievement.

ABC Unified School District. We were separate school districts. We all came together.

You got it wrong again, but that's okay.

ABC Unified.

### Moderator
Claim: Thank you, Gary Smuts.

Our motion is don't blame teachers unions for our failing schools. Here to argue against the motion, blaming teachers unions is Rod Paige, former US secretary of education and cofounder of the Chartwell Education Group.

### Scientific Advocate (SA)
Claim: Well, I think I want to be clear. We all know that teachers unions are not solely to blame for our failing schools. We would never argue that. What we are arguing is the way the motion is put, that the only option that you have in order to express the idea that teachers unions bear significant responsibility for the inability to reform our schools now. And so we are encouraging you to vote no. Teacher unions draw the ability to serve, to protect the interest of their members from their ability to convince the public that they are really about the kids. They are very good at hiding their real intent. They draw their power and ability to get the public to believe that there are some persons in some groups that they are not. They are not who they say they are. Who they say they are is not who they really are. Who they really are are mammoth organizations, highly financed, the most powerful political organizations in the United States of America. So you need to see them in that way. And we think they deserve your vote against the motion because they do bear significant responsibility for the condition of our schools.

### Moderator
Claim: Thank you, Rod Paige. Summarizing for the motion standing up for teachers unions and arguing against our motion, don't blame teachers unions for-- I'm sorry, arguing for our motion, don't blame teachers unions for our failing schools, Kate McLaughlin, an elementary teacher in Lowell, Massachusetts, who is executive vice president of the United Teachers of Lowell, No. 495, which is a local of the AFT.

### Conspiracy Advocate (CA)
Claim: Thank you. It's interesting because I can't help but take this personally because I am a union leader, and I am a proud union member. And I'm telling that you I'm speaking with the utmost candor that the kids come first to me and to my union president. The unions are the members, the people in the union, they are not these powerful organizations that secretary Paige will have you believe. Yes, there are-- there are political implications to what we do because we are advocating for the things that our children need; stable housing, healthcare and access to great and wonderful schools. So I would ask that you see the people on this panel as people who are actually doing this work on the ground level and working with our administrations to make our school systems better. We are the conduit for our teachers. Our teachers tell us what they need in their classrooms, and we collect this information, and we work together with our superintendent and other central office personnel to make it happen. That is the purpose of the United Teachers of Lowell. There are other aspects to what we do, yes. We protect due process rights, yes. That is one area. But what we do is maintain an attractive profession so that we can get the very best teachers teaching in our schools for the benefit of the students. Thank you.

### Moderator
Claim: Thank you, Kate McLaughlin. Arguing against the motion; arguing that teachers unions are at fault: Terry Moe, the William Bennett Monroe professor of political science at Stanford University and senior fellow at the Hoover Institution.

### Scientific Advocate (SA)
Claim: Well, I think it's important here at the end to just focus on the big picture. And the big picture is very simple, and it's very devastating. Here is what it comes down to. The teachers unions are by far the most powerful groups in American education. And they use their power mainly to protect jobs. And what they say is that there is really no conflict between protecting jobs and doing what's best for kids. But there are conflicts, lots of them, and as a result we can't get bad teachers out of the classroom, the schools are burdened with truly perverse organizations, and fundamental reforms, good reforms that make sense for kids, are resisted and undermined and weakened. So these are just basic facts. Our opponents say that they want reforms too, that they want to get bad teachers out of the classroom. We've heard that several times that they want choice, that they want accountability, and my response is, "Hey, it's 2010. Where’ve you been? If you wanted to get bad teachers out of the classroom, why didn't you do it 30 years ago? Why do we have all these protections and state laws? Why weren't they aggressive about it 30 years ago? Why are we even talking about it now?" Same thing with choice and accountability, they could have been aggressive in supporting these things, pushing for more choice, pushing for accountability. The reason we don't have them is that they've been opposing them. So again, what counts is not what you say, it's what you do. So here's the bottom line. You have an opportunity to show tonight where you stand, and so you can send a message about this issue to the unions and you can send a message to the nation as a whole. So please do that. Please vote, "No," on this proposal. It's important.

### Moderator
Claim: Thank you, Terry Moe.

Our motion is, “Don't blame teachers unions for our failing schools," and finally, to argue for that motion, standing by the teachers, Randi Weingarten, President of the American Federation of Teachers, the country's second largest teachers' union.

### Conspiracy Advocate (CA)
Claim: When I think about what we're doing here tonight, I don't think about it as a debate on this motion and who wins or loses this motion. I think about the kids that I taught at Clara Barton High School. I think about the millions of kids in this country who, but for public education, will not have a chance at life. I think about the thousands and thousands of teachers who are isolated in individual classrooms and who, frankly, have no interest in the status quo and who join a union or stay in a union because they want voice in how their kids get a decent education. I have been in three schools a week when I was the president of the United Teachers in New York City. And I have been in over 50 places in the United States in the last year and a half since I've been the President of the American Federation of Teachers. I wish I had that magic wand that would magically help all of our students achieve to the global standards we wish right now. But I can tell you, the folks who are on the other side of the stage and the folks in the audience, that this union, under our watch, and you see the examples from both what Gary said, who happens to be the Superintendent of the Year in California, as well as what Kate says, who every single day is teaching children as well as doing her union work, we want what children need, we want to make every single school a school where parents want to send their kids and educators want to work, and we've learned a heck of a lot in the last few years about what works for kids, how to insure that we have well supported and well prepared teachers even if we have to do the hard work of saying to people, "You don't belong in this profession," how to have an engaged curriculum, how to work with parents better, and how to make sure that kids have the decent services that they need.

### Moderator
Claim: Randi Weingarten, your time is up.

### Conspiracy Advocate (CA)
Claim: What we're asking--

### Moderator
Claim: Thank you very much. And that concludes this symposium.

And now it's time to learn which side has argued best. We're going to ask you right now to go to the keypads at your seat. It will register your vote. And we're going to get the readout almost instantaneously. Our motion is, "Don't blame teachers unions for our failing schools." If you are for the motion, if you stand with teachers' unions or at least don't blame them, push number one. If you are against the motion, you do blame teachers' unions, press number two. And if you are undecided, remain undecided, or became undecided, push number three. And while that's happening, and while the votes are being locked in and tabulated, the first thing I want to do is thank our panel for an amazingly impassioned and informed debate. You all are terrific. Thank you.

I'd also like to thank those in the audience who came up with questions, even those that we didn't use or that got chopped. We seriously appreciate your willingness to be involved in this and for all of you for voting and for being part of the evening, very vocally in fact. So we’ll hear of the vote result shortly. A few things I want to announce about what’s upcoming. Our next debate will be on Tuesday, the 13th of April. Our motion is: organic food is marketing hype. Panelists for the motion are the director of the center for global food issues, Dennis Avery; Missouri farmer Blake Hurst and former chairman of the U.K.’s food standards agency, Lord John Krebs. Against the motion are executive chef and co-owner of Blue Hill and Blue Hill at Stone Barnes, Dan Barber, consumerist union senior scientist for policy initiatives, Urvashi Rangan, and Vogue food critic, Jeffrey Steingarten. The motion for our May 11th debate is: Obama’s foreign policy spells America’s decline. And debaters for that are being booked and will be announced soon. Individual tickets for all of our events can be found at our website and at the Skirball box office make sure to become a fan of Intelligence Squared U.S. on Facebook and you can receive a discount on upcoming debates. All of our debates can be heard on more than 200 NPR stations across the station and you can also watch all of our sp ring debates on Bloomberg television. Airdates and times can be found in your program. And don’t forget to read about tonight’s debate in the next edition of “Newsweek” and to pick up a current copy of “Newsweek” on your way out.

All right, it’s all in now; our motion is: don’t blame teachers unions for our failing schools. If you’re voting for this motion, you’re standing with teachers unions or at least not blaming them. If you are against the motion, you do blame teachers unions for the failure of our schools. Remember we had you vote once before and once after. Before the debate, 24 percent of you were for the motion; 43 percent were against, and 33 percent were undecided. After the debate, 25 percent are for, 68 percent against, and 7 percent undecided. The side against the motion wins. Congratulations to them; thank you to all of you from me, John Donvan, and Intelligence Squared U.S.
