# Debate Transcript

Topic: Blame Washington More Than Wall Street for the Financial Crisis
Motion: Blame Washington More Than Wall Street for the Financial Crisis

Debate ID: Financial-Crisis-031709


## Round 1

### Moderator
Claim: Thank you, thank you very much, it’s a pleasure to welcome you. It’s my role in these evening’s to try to frame the debate, give the reasons why we thought this was a worthwhile topic. Let me start out by saying—just giving you a fact—in 2006, which was the last year before the financial crisis started to unfold, financial companies earned about 43% of all the profits earned by the Standard & Poor’s 500. Well that seems extraordinary when you think about the size of the financial sector. And how is that possible? Well it turns out that those profits were to a large degree illusory. It was almost like there was a giant Ponzi scheme going on, where financial institutions were selling assets to each other at ever ever higher prices, ever “Blame Washington More Than Wall Street” (3/17/09) ever greater degrees of leverage. And among those assets were about 6 trillion dollars in structured securities. Structured securities business is a construct of the ratings agencies, who through the alchemy of their own logic have turned the dross of subprime mortgages and other dodgy credits into the gold of Triple A securities. The big 5 investment banking firms at the beginning of 2007 had total assets of 4.3 trillion dollars. To put that into perspective, the national budget of the United States in those years was about 3 trillion dollars. They were leveraged greater than 30 to 1. Their assets were long-term in nature, frequently quite risky, frequently illiquid, and they were financed with mostly liabilities payable on demand. Most of the managements of these institutions were completely incapable of managing the risks that their firms were assuming.

Now turning to the commercial banks, think about Chuck Prince, the CEO of Citicorp. He ignored the storm warnings as he steered Citicorp onto the rocks with his infamous quote, “As long as the music is playing, you’ve got to get up and dance.” Okay, so why blame Washington for this mess? Well, there are a number of plausible reasons. First, the Fed supplied way to much credit and way too little supervision. It allowed banks to assume off-balance sheet liabilities, and contingent obligations “Blame Washington More Than Wall Street” (3/17/09) with no disclosure and with no capital requirements. Fannie Mae, Freddie Mac led a headlong push to extend home ownership to Americans who were clearly unqualified financially to own their own homes. The SEC allowed the investment firms to triple their leverage, and this was only about five years ago. And the regulators put the force of law behind rating agency judgments so that their mistakes were not just private-sector actors making mistakes, but had huge systematic consequences.

And finally, nobody stepped up to provide the most elementary safeguards for credit default swaps. And that is the mechanism by which so many financial institutions are tied to each other, and it’s the mechanism that has created so much of a domino effect in our financial system. So, there is a lot of blame to go around. And to help sort out who deserves more blame, we have an outstanding panel tonight, and I think we’re in for a very, very exciting and elucidating evening. Thank you.

### Moderator
Claim: I would just like to invite one more round of applause for our chairman who makes this possible, Robert Rosenkranz. Ladies and gentlemen, welcome to another Intelligence Squared US debate, I’m John Donvan, your host, and I will also be moderating as the debaters you see sharing the “Blame Washington More Than Wall Street” (3/17/09) stage here with me at the Casparyy Auditorium at the Rockefeller University in New York City. Two tables, three against three, will be debating this motion, “Blame Washington More Than Wall Street for the Financial Crisis.” Now, this debate is not a panel discussion or a seminar, it is a contest, a contest of ideas and logic and wit, and perhaps charisma and humor. But most of all persuasion, because by the time this debate concludes, you the audience will have voted twice, both before the debate, and again afterward, your vote is to side with or against our teams on the stage and their position. At the end of the debate the team that has changed most minds over the course of the debate, will be declared the winner. At this point then let’s do our first vote, you go to the keypads by your side, and I’ll give you about 30 seconds to register your position. The motion is, “Blame Washington More Than Wall Street for the Financial Crisis.” Press number 1 if you agree with the motion, number 2 if you disagree, number 3 if you are undecided. Does anyone need more time? Everyone figured that out, okay. All right, thank you, we’re gonna lock in the votes and we’ll begin the debate. Now you have already completed the first vote and I will have the results from that first vote shortly. But now, Round 1, opening statements, uninterrupted, “Blame Washington More Than Wall Street” (3/17/09) seven minutes, each debater from each side, speaking in alternate turns, beginning with the side for the motion, “Blame Washington More Than Wall Street for the Financial Crisis.” Our first debater, Niall Ferguson of Harvard University, he is an economic historian which means he is an explainer. And his most recent book, The Ascent of Money, begins in its early chapters explaining with such eloquence that a third-grader could understand it. By the end of the book, Niall, you’ve taken on the mess that we’re in now. And I don’t know if anyone really understands that. Niall Ferguson.

### Conspiracy Advocate (CA)
Claim: Well thank you very much indeed, ladies and gentlemen, it’s a great pleasure to be here with you tonight, nothing would be easier, than to blame everything on the bankers. Think of Richard Fuld…of Lehman Brothers. In 2007 his compensation, for the year, was $72 million. The year before his firm collapsed. Never to be seen again. Or James Cayne of Bear Stearns who made $290 million, in the nine years before his firm vanished without trace. Not only were the bankers greedy, we would agree. They were also, in many cases, incompetent. But I and my colleagues are not here to praise them, or to defend them. We blame them for much of what has gone wrong. It’s just that we blame the politicians…more. “Blame Washington More Than Wall Street” (3/17/09) We’ve already heard quoted tonight that wonderful saying of Chuck Prince, as long as the music is playing you have to get up and dance but you have to ask yourselves, ladies and gentlemen, who was playing the music. You know, it’s so easy, to heap opprobrium on Wall Street right now. It’s just too easy. And if you noticed, that’s exactly what the politicians do. I couldn’t help but notice, in President Obama’s inaugural address, an allusion to greed, and irresponsibility. And only yesterday, he was denouncing, and I quote, “The recklessness and greed of the bonuses paid to executives at the insurance company AIG.” It was just the same in the last Great Depression, I think of this as the Slight Depression. FDR in his inaugural address, heaped scorn on the rulers of the exchange and the unscrupulous money-changers. Ladies and gentlemen, you have to ask yourselves…why do the politicians always wax so indignant about finance at times like these? Could it just possibly be that they’re trying to divert our attention away from Washington’s own responsibility for the debacle?

What I want to do in the brief time I have available is to invite you to consider the roles played by four institutions, in bringing about this financial crisis, and I also want you to reflect on the “Blame Washington More Than Wall Street” (3/17/09) location of those institutions. The first is the Federal Reserve Board. Its role has been to allow a housing bubble to inflate, and burst, between January of 2001 and June of 2003, the Fed cut its federal funds rate from 6.5 percent to 1 percent. Then over three years it very gradually, by quarter- points, raised rates up to 5.25 percent. In that time, ladies and gentlemen, house price inflation in this country, rose from 7 percent, to 17 percent a year, and it stayed above 15 percent a year, right until January of 2006.

This was the period when Ben Bernanke, chairman of the Fed, proclaimed the advent of a great moderation, in economic life, yes, that was the title of his lecture in 2004. “Some moderation.” The location of the Federal Reserve Board, is the Eccles Building, Constitution Avenue, Washington D.C. The second institution, that I’d like to draw your attention to is the Securities and Exchange Commission, which under Christopher Cox, allowed the leverage in the banking system to spiral out of all control, from some 12 to 1, to as we’ve already heard this evening somewhere in the region of 20 to 30 to 1, in the case of the big investment banks. And that was a conscious decision by the SEC. The location of the SEC, ladies and gentlemen, 100 F Street Northwest, Washington, D.C. My third prime suspect is Congress, ladies and gentlemen. Yes, Congress because it was “Blame Washington More Than Wall Street” (3/17/09) Congress that wholly failed to supervise Fannie Mae, and Freddie Mac. Those two essential institutions, which underpin the United States mortgage market.

On the eve of their destruction, Fannie and Freddie had core capital, as defined by their regulator, of $83 billion, and supported around $5.2 trillion of debt and guarantees. In other words they were leveraged 65-to-1. The location of the Congress, I’m sure you’re aware of this but I can’t help but point it out is Capitol Hill, Washington D.C. And that brings me to another nearby location—the location of the White House. You know the White House played an extremely important role in creating the sub-prime mortgage disaster. “We want everybody in America to own their own home,” declared President George W. Bush, in October in 2002. Everybody, in America.

He challenged lenders to create 5.5 million new minority homeowners, by the end of the decade. He signed the American Dream Down Payment Act, in 2003. No Presidential pressure, no sub-prime debacle. The address of the White House, ladies and gentlemen, as you know, 1600 Pennsylvania Avenue Northwest, Washington D.C. Well, ladies and gentlemen, bankers are nearly always actuated by greed, so, I’m sad to say, are many ordinary “Blame Washington More Than Wall Street” (3/17/09) people too. But it’s the role of government to strike a balance, between market forces, and stability. And I move in conclusion, that we should blame Washington more than Wall Street, for this crisis. Not least because in my view, Washington sold itself to Wall Street. And I very much fear, is still in hock to it. I beg to propose this motion.

### Moderator
Claim: Thank you, Niall Ferguson, arguing for the motion. Now to argue against the motion, I’d like to introduce Alex Berenson. Alex Berenson is a reporter for the New York Times who has covered a wide range of stories and issues, he’s been to Iraq, he has been to New Orleans to report on the effects of Hurricane Katrina, but he—

### Moderator
Claim: Sorry?

### Moderator
Claim: Louder?

### Moderator
Claim: Shall I start again, could you not hear anything? Sorry?

### Moderator
Claim: The speaker The speaker we can’t hear the speaker.

### Scientific Advocate (SA)
Claim: “Blame Washington More Than Wall Street” (3/17/09) I haven’t said anything yet.

### Moderator
Claim: Oh— He wasn’t talking yet. But how did that happen? My mouth was moving. Alex Berenson is a journalist for the New York Times who has covered the aftermath of Hurricane Katrina and Iraq, but he’s most known and most relevant in this debate for his investigative work on Wall Street and, Alex, you are a novelist as well, I should point out, I don’t know if you could make up the situation we’re in now. But here’s Alex Berenson to argue against the motion, “Blame Washington More Than Wall Street for the Financial Crisis.”

### Scientific Advocate (SA)
Claim: Thank you, I hope you can all hear me,— I see a lot of green out there tonight, which is fitting on two levels. It’s also St. Patrick’s Day, another festival of wretched excess that will lead to some hangovers tomorrow. And I have to say I’m at a great disadvantage because, Niall Ferguson has that accent, he could read the phone book to you and it would sound a lot smarter than I do. But before I get “Blame Washington More Than Wall Street” (3/17/09) going I want to quickly address something that Niall said— Niall was talking a lot about institutions that were involved with residential home finance. And there’s no doubt that mortgages, residential mortgages are a huge part of this crisis. But the two banks that have collapsed in the last year, the two Wall Street banks that have effectively collapsed in the last year, Lehman and Bear, really weren’t all that involved in the residential mortgage finance business, they— Not to say they weren’t involved but they weren’t as involved as a lot of other people. And the reason I point that out is because, the issues here, are a lot larger than Fannie and Freddie or the home price bubble, as significant as that is.

So let me, let me start by going back to the resolution which, the resolution doesn’t say, we need more regulation going forward, I don’t think anyone on this panel, anyone in this room would disagree with that. And the resolution doesn’t say that bankers should all be put on a desert island and forced to make their own society. You know, I guess that’s the Hamptons but— Sorry, Jim. But— But what the resolution says is, “Blame Washington More Than Wall Street for the Financial Crisis.” And that is flat wrong. And to understand why, like Niall, I wanna take you back to the Depression, and to the creation of the SEC. Now, the Depression was the last time “Blame Washington More Than Wall Street” (3/17/09) that there was this kind of public anger at Wall Street and at big business in the United States, and understandably so.

And when the Roosevelt administration created the SEC, one of the things that they considered doing, briefly, was having the SEC have the power to prevent companies from selling shares, not because they were committing fraud or misrepresenting their financial statements, but simply because the SEC’s economic experts would find, well, this company doesn’t have very good prospects. This company has too much competition. We’re not gonna let them sell shares. And that idea didn’t go very far, it was very rapidly rejected, but it was considered. But what—why I think this is so important and interesting is it shows that even during the Depression, even during a time when unemployment was 25 percent and there were breadlines and there was really a question about whether capitalism could work, and there—you know, there was an alternative model that seemed to be working in the Soviet Union— Even then the United States went with a relatively permissive, regulatory regime. And that’s always been our history.

And to me, that makes sense, and if you think about your own life, if you think about your own business as you know, whether you’re a lawyer or a doctor or whether you work in retail, whether “Blame Washington More Than Wall Street” (3/17/09) you—a landlord, whatever it is that you may do, you probably have a better idea where the opportunities are, but also where the problems are, where you can take advantage of your customers, where you can cut corners, than any regulator could no matter closely they monitored you. It’s your business, it’s your life. And so the regulator needs to set the rules, but in the end—you succeed or fail on your own. And think about the commercial airline industry in the United States, which is really a great success story in the most important way which is that it’s extremely safe. You can count the number of jet crashes this decade on one hand, in the United States. And, you know, we’re going towards zero.

And I don’t think that’s because the FAA is a better regulator than the FDA or the SEC, or anyone else, I think it’s because there’s a commitment in the airline industry to safety. Now whether they define that as a moral issue, we need to protect our passengers and our workers, or whether it’s a practical issue where they believe there might not be economic repercussions, people might not wanna fly if there were too many crashes, I don’t know. But there’s no question that the airline industry in the United States is extremely safe. And I think it’s not a result of the FAA, I think it’s a result of a commitment within the industry. “Blame Washington More Than Wall Street” (3/17/09) Compare that to Wall Street, which appears to have been run by a bunch of greedy children, for the last 10 years. And greed is a crucial word there, because although Niall sort of—you know, he mentioned the compensation and then skated past it. Compensation is a crucial, crucial part of understanding what went wrong on Wall Street in the last 10 years. When you can make a million or 10 million or in some cases $100 million for a year’s work, you don’t have very much incentive to run your business for the long term. If you can…if theoretically, you’re being paid in stock, and your compensation is gonna be restricted over a long time, you have more incentive. But even so if the numbers are really, really large, it’s unlikely that you’re going to think long-term. And so I think Jim now will talk to you about some of the specifics of what went wrong on Wall Street in the last 10 years. But, at its core, the issue is relatively simple, there was a huge amount of leverage taken, there was inadequate capital to support the risks that the banks were taking.

When you make loans, some of them are gonna go bad, and you need to have enough money in capital, in equity, to handle those losses, and the banks simply didn’t have that. Now, did Washington create the conditions that allowed that to happen, sure. Could we and should we have had a much more robust “Blame Washington More Than Wall Street” (3/17/09) regulatory system? Absolutely. Regulation is vital, regulation sets the playing field, it sets the rules. But in the end, you have to put blame where blame is due. And, blame is due on the firms. It’s due on the owners, it’s due on the managers, it’s due on the executives, it’s due on the employees. To some extent, although to a lesser extent it’s due on shareholders because the shareholders didn’t properly manage the boards of directors but that’s something Nell can talk about. But in the end, blame accrues to Wall Street, not Washington, please keep that in mind, and vote against this resolution. Thank you.

### Moderator
Claim: Thank you, Alex Berenson, speaking against the motion, Now to speak for the motion, “Blame Washington More Than Wall Street for the Financial Crisis,” I’d like to introduce John Gordon Steele, a man who’s a little bit difficult to pin down, he is an adventurer, he has spent time in politics, he’s been a filmmaker, he has been an NPR commentator and still is, but it’s as an author of books focusing on critical periods in financial history that he comes to us today with expertise to argue for the motion, “Blame Washington More Than Wall Street for the Financial Crisis.” Ladies and gentlemen, John Gordon Steele. I’m sorry… I’m gonna correct that, ladies and gentlemen, John Steele Gordon. “Blame Washington More Than Wall Street” (3/17/09)

### Conspiracy Advocate (CA)
Claim: The British always wanna file me under Steele-Gordon, with a hyphen. I only use my middle name because John Gordon is about as blah a name as you can find. I’m here to argue that Washington is more at fault than Wall Street, although as everybody has admitted, Wall Street has plenty of blame to take here. But…Wall Street is not unitary. Wall Street is nothing but a metonym for the American financial market, and it operates around the globe and…nowadays, deep down into the socioeconomic spectrum. Now some of the people who are encompassed by the term “Wall Street” have fiduciary obligations to their stockholders or to their depositors. But the majority of, of Wall Streeters do not. They are operating entirely for themselves in their self-interest.

Washington on the other hand, has nothing but fiduciaries, I mean that’s why governments are instituted among men, no other reason. Now, Wall Street because it is entirely inhabited by people who are pursuing their self-interest, it’s notorious that there are only two emotions to be found on Wall Street, fear and greed. Right now I think it’s perhaps time to put in a good word for greed. As a result, we have had panics on Wall Street roughly every 20 years. Now “Blame Washington More Than Wall Street” (3/17/09) the Constitution came into effect in April of 1789, we had the first crash on Wall Street in April of 1792. Then we had another one 1819, 1837, 1857, 1873, 1893, 1907, 1929, 1987, and now 2008. It seems to be just part of the beast, I mean could any of these panics have been prevented by Wall Street? I doubt it. Being individuals, and Wall Street is nothing but a collection of individuals, not an institution, it is inherently susceptible to the madness of crowds.

So, blaming Wall Street is like blaming the atmosphere for thunderstorms, it’s the nature of the beast, it’s going to happen. Washington on the other hand is supposed to be the guys with the striped shirts and the whistles on the playing field. They make up the rules, and then they enforce them. And then they sometimes change the rules in order to accommodate some of their friends. Also Alan Greenspan famously said, that it is—part of the Federal Reserve’s job is to take away the punchbowl when the party really gets going. In other words it’s Washington’s job to prevent the crowd from going mad. They’ve just done an incredibly lousy job of regulating Wall Street or preventing the madness of crowds. I mean for one thing the regulatory apparatus is a total shambles.

I mean we have the Federal Reserve, we have the Controller of “Blame Washington More Than Wall Street” (3/17/09) the Currency, we have the SEC, we have the Office of Thrift Supervision. We have the FDIC. We have the banking regulatory authorities of the 50 states. All of them bureaucracies, all of them devoted as all bureaucrats are to protecting turf, far and head of, of actually regulating anything. Now, also, politicians are subject to human nature, the same as Wall Streets are. If Wall Streeters are in the business of making money, politicians are in the reelection business. That means that they’re gonna be short term-oriented, they’re gonna—what they want is the good headline tomorrow morning, and if that produces dreadful policy two or three or five years out, that’s after the election, we’ll worry about it then. Everybody knows that publicly-traded corporations have to submit annual reports, that these reports have to be according to standardized accounting rules, and that they have to be certified as being honest and complete by independent accountants. This is a great idea. It’s now so obvious that nobody even thinks about it anymore, but it was invented by Wall Street. Because the great Wall Street banks in the late 19th century, they wanted to know what the corporations were really up to, and so did the members of the New York Stock Exchange. So the corporation screamed bloody murder at first, but the Wall Street banks said sorry, if you want us to underwrite your securities, you’re gonna “Blame Washington More Than Wall Street” (3/17/09) have to do this, and the New York Stock Exchange says if you want your securities listed with us, you’re gonna have to do it, so they finally did it. There’s still one great big player in the financial world in the United States, that is not subject to these commonsense rules. It’s called the government.

For instance, you remember those budget surpluses in the later years of the Clinton administration between 1998 and 2001? They amounted to $558 billion. So the national debt went down by $558 billion, right? Uh, no, it went up by $400 billion. The reason is that Social Security was put on budget. And that means that the revenues that flow into Social Security over and above what is paid out to recipients of Social Security becomes part of the government revenue, it’s called an intra-governmental transfer. Of course the money that’s taken out of the Social Security trust fund is replaced with newly minted federal bonds. Which is why the debt went up. Now, if a private company or publicly-traded company, tried to take employee contributions to the company pension fund, and call it revenue in order to perk up the bottom line, the managers of that corporation would all this very minute be playing volleyball in Club Fed. Or, consider Fannie and Freddie. It was a great—Fannie was a great idea, it sounded, in 1938--and it really, it liquefied the mortgage market, it helped, along with the GI Bill tremendously, “Blame Washington More Than Wall Street” (3/17/09) to increase home ownership, and I’m gonna have to quit here I’m afraid.

### Moderator
Claim: I have to interrupt you. Thank you very much. But for the introduction I’d like to—I’d like to give you the shot at being applauded twice because, for the radio broadcast since I made the error on your name I’d like to reintroduce you and have everybody applaud for you again, and you can enjoy that. Ladies and gentlemen, let’s welcome John Steele Gordon. I’m really sorry for that, let’s look at where we are. We are halfway through our opening remarks, I’m your moderator, John Donvan, we are hearing from two teams of three debaters each, arguing this motion, “Blame Washington More Than Wall Street for the Financial Crisis.” We are now going to hear from the next debater against the motion. Jim Chanos is the founder and managing partner of Kynikos Associates. He has had a successful period let us say because, he is a man who bets against the market. Recently a very successful period, I don’t know, Jim, in this situation, are congratulations in order— But, I welcome you to our debate, ladies and gentlemen, Jim Chanos.

### Scientific Advocate (SA)
Claim: “Blame Washington More Than Wall Street” (3/17/09) Thank you, John, and thank you to Robert and to Intelligence Squared for putting on this great series and heightening the public debate on these important issues. I think you’re doing great, great work, thank you. Now, we’ve heard from two-thirds of the “for” team’s members, and from my august teammate, Mr. Berenson. And, we all seem to be missing sight of the resolution. Again, no one seems to disagree that more regulation is needed. No one seems to disagree, that crimes, malfeasance, and incompetence, were at work. The question is who’s more to blame. And I hope to be able to make my point, that in fact that’s gonna be pretty easy to point out.

Before I got here I was searching the web for instances of Irish wit when it comes to financial markets and money. Now my mother was Mary Catherine Sullivan, and as much as I— I tried hard to find examples of that wit, I came a cropper. So I had to turn to another great philosopher, in all matters economic. Tony Soprano. Who went imploring his gang to work harder, ‘cause not enough money was coming in to keep everybody happy, said “Look, we don’t got one of them Enron things here.” This is important. Because, I would like to go on to “Blame Washington More Than Wall Street” (3/17/09) tell you that agency risk as it exists in corporate America is legion. It is endemic, and it is pervasive. In 1998 Business Week put out a survey, after, canvassing 500 of the S&P 500 Chief Financial Officers anonymously. And they were asked in the celebrated question, “How many of you have ever been asked by your superior to materially falsify financial results.” And the answer was stunning. 45 percent said they were asked to do so but didn’t, 12 percent said they were asked to do, and did, and 33 percent said they were never asked. So at the time, 10 years ago, two thirds of our nation’s largest CFO’s had basically been asked to cook the books. And luckily, only a minority did so. And lest you think this was an outlier, the same survey roughly, was repeated by CFO magazine six months later, and had very, very similar results.

It’s the main reason I have a business that I feel will continue to prosper no matter what the markets do. Because quite frankly out there, there’s a lotta people in the public markets that wanna take your money. And that, ladies and gentleman, is a point I think that we are going to carry tonight. How did we get, in the last five years, when things seemed to escalate so much, so much worse on the fraud side, from Enron, Tyco and rogue analysts, to the world of Bear Sterns, Lehman Brothers, AIG, Bernie Madoff, and Stanford Financial. Well…I think the “Blame Washington More Than Wall Street” (3/17/09) reason we have, is that those in charge, yes, they may have fallen asleep. Yes, they may have done dereliction of duty. But we saw a level of compensation, and a new structure of structured finance that allowed, as Alex pointed out, undreamed-of amounts of leverage, and skewed incentives for compensation. It was heads I win, tails, my shareholders lose.

Every trading desk had a mantra of making their numbers in one way, shape, form or another, and did so quite easily in all kinds of markets in the last five to 10 years, up, down, whatever. It was not just Madoff who produced stunning consistent and profitable results. If you look at the profits as Bob Rosenkranz alluded to in his opening statement, of our largest banks and brokers, no matter what the markets did, many of these firms returned 20 to 30 percent on equity, quarter in, quarter out, with very little variability of operations. How did that happen. Well, they were gaming the system. Remember Sarbanes-Oxley? I do, I got all kinds of phone calls from the press after Sarbanes-Oxley saying well you don’t have a job anymore. Short selling will never be profitable. Yes, corporate malfeasance will be a thing of the past. Because CEO’s and CFO’s now have to sign the financial statements. And if something goes wrong, they could go to jail.

And when I pointed out to those same journalists that falsifying “Blame Washington More Than Wall Street” (3/17/09) financial statements has always been a crime, and this just simply codified it a little tighter. Well, this is post- Enron, people are going to be vigilant, and accountants and lawyers will not let this happen. Ladies and gentlemen, I will pose to you that there has not been one major financial fraud in the past 25 years, uncovered by the government, outside auditors, or outside counsel. It’s always been journalists, whistle-blowers, or short sellers, or some combination thereof. Daresay, that if Bernie Madoff had been public, the shorts would’ve found him out a long time ago. Now, post- Sarbanes-Oxley, post-Enron, we had to move to tougher accounting standards. We saw FAZ 46 get brought in, and I’m not gonna bog you down in arcane but it basically said, keeping things off the balance sheet is no longer kosher. Part of the problem with Enron as you recall were the funds that were offshore that an Enron CFO was general partner of while he was still undertaking his duties as Enron CFO.

Well, guess who lobbied for a big exemption, of those rules. The banks and brokers, who got FIN 46-R enacted which was, financial institutions were exempt, from the consolidation of offshore entities and unconsolidated entities, hiding large amounts of assets and liabilities. Imagine that. And while we’re at it let’s talk about Professor Ferguson’s locus of problems. “Blame Washington More Than Wall Street” (3/17/09) Well the Fed, yeah, the Fed’s located in Washington, there’s no doubt about that. But the part of the Fed that is instructed to be the market cop, is the New York Fed. Now the New York Fed for the past few years was run by the current Treasury secretary. But do you know who sits on the board of the New York Fed and do you know who it answers to. Bet very few of you do. The largest commercial banks in the United States.

### Moderator
Claim: Jim Chanos, I have to cut you off, your time is up. Thank you very much, ladies and gentlemen, Jim Chanos. Now to argue for the motion, “Blame Washington More Than Wall Street for the Financial Crisis,” I’d like to introduce Nouriel Roubini…known, I think we all know, as Dr. Doom. Having predicted much of what has happened a few years back, having a name like that only really works out if you turn out to be correct. So far so good, Dr. Doom, ladies and gentlemen, Nouriel Roubini.

### Conspiracy Advocate (CA)
Claim: Thank you, ladies and gentlemen. I say the beginning I support the proposition, I blame more Washington, than Wall Street for this financial crisis, but I should say the beginning, that I do agree that Wall Streeters, bankers, traders, investors, are greedy. Sometimes they are stupid, they are arrogant, “Blame Washington More Than Wall Street” (3/17/09) they’re incompetent. They take too much risk, they take too much leverage, they are over compensated, all that’s true. But we’ve had the worst financial crisis since the Great Depression, we have to ask ourselves, are bankers and investors more greedy and more immoral than they were 20 years ago. 20 years ago, Gordon Gekko in Wall Street said that greed is good. I don’t think that has changed, you know, we know there is always greed, actually greed in some sense is good, is one of the drivers of capitalism. But we know that greed has to be controlled by three things. By fear of losses, by the fact they should not expect to be bailed out, and by a system of prudential regulation and supervision of the financial system because financial markets without ruling institutions are like the law of the jungle.

And that’s to me the failure, I expect Wall Street to be greedy but I expect good policy-making, trying to control the behavior, and that did not happen. In many dimensions. The Fed and Greenspan, after the last tech bubble went bust, cut interest rates almost to zero, and created the asset bubble, kept interest rates too low for too long. Was most at that time, people talked about the Greenspan put in financial markets, it was the expectation whenever trouble occurs, Greenspan’s gonna ease things and get you out of your losses and problems. It happened after the 1987 stock market crash and the S&L crisis easing, “Blame Washington More Than Wall Street” (3/17/09) then in the ‘90s with the tech bubble, Greenspan warned about irrational exuberance and did nothing about it. And after the tech bubble went bust, he cut interest rates from 6.5 down to 1 percent, and he created the latest bubble.

So, he has been a creator of serial bubbles one after the other and when people expect to be bailed out then they behave accordingly, that’s the Greenspan truth. We created a system which people expect, that the gains are going to be privatized, and the losses are going to be socialized; this is a welfare state for the rich, for the well-connected and for Wall Street. That’s what happened, that’s public policy. The action of the Fed regarding the asset bubble, was, you don’t do anything on the way up, that was the official rule of Greenspan, Don Kohn, and Ben Bernanke, and when the asset bubble collapses, to avoid the collateral damage to the real economy, you ease aggressively. Again, that’s a buyer’s behavior that creates more and more bubbles. We’re running out of bubbles actually to create, with the real estate bubble, the tech bubble, the hedge fund bubble, the private equity bubble, you know, even the commodity bubble, the art bubble, we’re running out of bubbles to create but we’re easing again down to zero so, what’s gonna happen this time around.

As was pointed out, the job of the Fed is to take away the “Blame Washington More Than Wall Street” (3/17/09) punchbowl when the party gets going but unfortunately not only the Fed did not take away the punchbowl, it added vodka, whiskey, gin, and every toxic stuff to it. And it made the bubble even bigger. Take the role of the Fed and the regulators, with sub-prime mortgages…Greenspan was the biggest cheerleader of this kind of financial innovation. Zero down payment, no verification of income, assets and jobs, they called them ninja loans or liar loans. Interest-only mortgages, negative amortization, teaser rates, all this toxic stuff or sub- prime, near-prime, prime. The Fed and Greenspan actively said was the best thing that have happened to mortgages. Free market, they could control it, they had the law, the power to do it, they didn’t do it.

Think about our public policy towards housing and mortgages. The Community Reinvestment Act, creation of Fannie and Freddie-subsidized housing. The 20 ways in which we have subsidized, through tax policy, interested community of mortgages. The worst, and the most unproductive form of investment, investment in housing. Big McMansion can give you utility but doesn’t increase the stock of capital in the real way of productivity of capital and labor, like, physical capital does. We have subsidized housing in 20 different ways. That has led to the bubble as well. There was an ideology for the last decade in “Blame Washington More Than Wall Street” (3/17/09) Washington, that was critical to this financial crisis. Was an ideology of laissez-faire, Wild West unregulated capitalists. The base of this ideology was the idea that banks and financial institutions will self-regulate. And as we know, self-regulation means no regulation. It was the ideology of relying on market discipline, and we know when there is irrational exuberance, there is zero market discipline.

There was an ideology, and policies of relying on an internal risk- management model and as was pointed out, Chuck Prince said, when the music is playing you gotta stand up and dance, nobody listens in good times to the risk managers, they’re the party poopers, only the risk takers have the advantage in the banks, and therefore, relying on internal risk management doesn’t work. Was relying on rating agencies that had massive conflicts of interest because of being paid by those they are supposed to be rating. And this rating agency had a quasi-governmental role. They had monopoly or oligopoly power, and power to decide whose assets you can buy or not buy, that was policy that led them to have that power, and those kind of distortions.

So every element of our regulatory system, has failed, you know, this Basel accord that relied on this principle, has failed even before it was implemented. Relying on principle rather than “Blame Washington More Than Wall Street” (3/17/09) rules, relying on light touch, rather than tough rules, a light touch means no touch at all. The ideology of Greenspan was, every financial innovation is great, markets self-regulate. Shareholders are gonna be able to control the behavior of bankers and so on. This was the belief in deregulation. Elements of it, actions were taken. The repeal of Glass-Steagall that separated investment banking from commercial banking. Now we let them essentially, use deposit insurance and deposits to do 30 times leverage prop trading, that’s what was allowed. Essentially deregulation of credit derivatives and derivatives, over the counter with systemic risk.

Things of that sort were going on. The SEC deciding the level ratios, 30 to 1 was okay. Those were the policy that led then to those excesses. There is greed, it is up to public policy to make sure that greed is controlled because otherwise if you don’t have rules, institutions, and balance and prudential regulation supervision, is the law of the jungle, and unfortunately the last element of it was regulatory capture. It was an ideology in which, the government power taken over and controlled by lobbies where those were pushing for this kind of deregulation. So it was a massive failure of public policy, thank you.

### Moderator
Claim: “Blame Washington More Than Wall Street” (3/17/09) Thank you, Nouriel Roubini. Finally to speak against the motion, Nell Minow who is an attorney who has held positions in various government agencies but she’s best known and again most relevant in this debate, for having run a firm which held corporate CEO’s to strict accountability, she was described by Fortune magazine as “the CEO killer.” And I know we have some CEO’s in the room, Nell, so this is not literal, is it. Ladies and gentlemen, Nell Minow.

### Scientific Advocate (SA)
Claim: Only when they deserve it. You’ve got to vote for our side. I have to tell you, you know, there’s plenty of blame to go around, we all agree, there’s plenty of blame to go around. You know, there’s Washington, there’s Wall Street, but all of us know who really is to blame here, it’s gotta be Jim Cramer. Listen, I’m willing to blame everybody, I’m even willing to blame that Bachelor guy, I— everybody, everybody deserves— it takes a village to create this problem. Or put it another way I’m gonna quote Pogo, who said, “We have met the enemy and he is us,” every one of us bears some responsibility for what went on here but I’m gonna tell you today, why it’s Wall Street that is primarily responsible.

First of all, it’s a bit of a false distinction, between Wall Street and “Blame Washington More Than Wall Street” (3/17/09) Washington. And one of the things I’m going to talk about today is how inextricably they are linked. We talk about Fannie and Freddie. Those were public corporations, after all. They were a little bit the better, the worst of both worlds, a little bit of a duck billed platypus because they had a little government edge there. But those were public corporations with Boards of Directors and they behaved like public corporations. They behaved badly. And that is what is wrong with Wall Street. So you may noticed already, even in this few minutes that I’ve been up here, I’m different. I’m not like anybody else on this panel and that is why, and the primary difference, as I’m sure you’ve noticed, is I’m the only one on the panel who is from Washington. I have to say, none of these people know anything about Washington except some addresses. That’s all we know. I see he’s got a GPS, is all he’s got. And you know, and the other thing is, I’m not an economist. I am a capitalist. I, uniquely on this panel, I have created businesses. I have created businesses, had them grow and sold them. I have worried about making a payroll. So I know something. I’m not like an economist who, it works in theory, it doesn’t work in practice. So I know what it is to be a capitalist. And I know what it is to be a bureaucrat. I worked in the government. In the Reagan administration I was at OMB. And let me tell you, one of “Blame Washington More Than Wall Street” (3/17/09) the big shocks in my life was all these people who espouse and rhapsodize about the free market kept trooping over to me to get me to give them limits on liability and erect barriers to entry.

Everybody is all about the free market except when it benefits them not to be. So I’m going to tell you the three things that Wall Street did that are unforgivable and that really weigh the balance in favor of their responsibility. What is the one thing we want from Wall Street? We want just one thing. We want them to be able to do math, right? The math was wrong. Their math was bad. They put too much reliance on something called the Gaussian copula formula. Yes, the Gaussian copula formula is at the heart of what created the derivative securities, the credit default swaps. They all relied on it. They all got on one leaky little boat. They didn’t take out their slide rules. They didn’t do the math. So they relied on bad statistics. They left out one big variable. Yes, they heard music, but what dance were they doing? They heard music for the minuet. They were doing the boogie, okay? And what is the address of all of those forms? I believe it’s on Wall Street.

Second thing, bad incentives. They were getting paid based on the quantity of transactions, not the quality of transactions. Now, it doesn’t take a rocket scientist to figure out that’s going to “Blame Washington More Than Wall Street” (3/17/09) have a very bad result. Look at what we’ve seen about the pay just in the last couple of days. Look at The New York Post with its headline today: AIG Is a P-I-G. These people were getting paid regardless of what happened. You heard about Anthony Mozilo? Six hundred million dollars as he took the stock down seventy-eight per cent and took the economy down with it. Fuld didn’t have to give any of it back. I testified with Fuld before Congress in Washington when they called him in to account. And he said, up until last year the performance was pretty good. So he should be allowed to keep all that money. Only thirteen percent of companies on Wall Street have claw backs, meaning they have to give back the money when the numbers that were reported, that they got their bonuses on, turn out to be wrong.

That is on Wall Street. What are they doing now? Watch them carefully. They are repricing their options. That is disgusting. And that is Wall Street. Okay, next. Terrible oversight as shareholders. Yes, the shareholders should have done more. Guess who the big shareholders are? Yeah, they’re on Wall Street. Who was it that was voting in favor of these insane pay packages? Well, look at the firms on Wall Street. They’re the big shareholders. They’re managing all that money. They are enablers for the addiction of bad pay packages on Wall Street. “Blame Washington More Than Wall Street” (3/17/09) And yeah, Washington behaved badly. Washington behaved very badly. Do you think the fact that from 1998 to 2008 over six hundred million dollars was spent on lobbying to get rid of regulations, like Glass-Steagall, to get rid of capital requirements on banks – do you think maybe that might have had an effect on it?

Yeah, Washington is nice to its friends. Who is responsible for that? Who are its friends? I would like Wall Street to make the same disclaimer that is required of mutual funds. Past performance is no guarantee of future performance. And who is it that requires them to say that? That is Washington. Wall Street has expected us to bet on them for a long time. They have not lived up to our trust in them and they are more responsible than Washington for this mess. Thank you.

## Round 2

### Moderator
Claim: Thank you, Nell. You know, and that concludes round one, opening remarks of this debate. We had you vote when you came in, vote on whether you side with the motion, against the motion or are undecided. And we have the first results from that first vote. Restating the motion: Blame Washington More Than Wall Street for the Financial Crisis, forty-two percent of you vote for this motion, thirty percent vote against and twenty-eight percent remain undecided. We’ll poll you again at the end of the evening “Blame Washington More Than Wall Street” (3/17/09) and the team that moves most votes, the team that changes most minds will be declared our winner. So we’re now going to move on to round two and in round two the debaters talk to each other directly and they also take questions from us. So on to round two. And I just want to ask Niall Ferguson, since your side is arguing that Wall Street should be blamed for the economic crisis and we heard your ca...I’m sorry, Washington should be blamed for the economic crisis. And we heard your teammates say that Washington did not do its job well. My question really is, if Washington had performed its job well, would we have an economic crisis?

### Conspiracy Advocate (CA)
Claim: Well, I think one way of answering that question is to ask whether every country in the world is having a financial crisis comparable to the one that’s being experienced in the United States. Now, most countries in the world are experiencing an economic crisis, largely as a consequence of what is happening here. But they’re not all experiencing a financial crisis. You don’t have to travel terribly far, actually, to get to a country where banks are and have been adequately regulated. That country is called Canada. So if you simply look at what’s happened there it becomes obvious that something was egregiously wrong with the regulatory environment in the United States. And that is our central point. It’s not difficult to see that “Blame Washington More Than Wall Street” (3/17/09) there was a grotesque failure on the part of regulators and politicians here. You only have to look north of the border.

### Moderator
Claim: Nell Minow, you’re on the opposite side of the, of the argument but I see you nodding.

### Scientific Advocate (SA)
Claim: Well...

### Conspiracy Advocate (CA)
Claim: That’s always a good sign.

### Scientific Advocate (SA)
Claim: You know, the fact is that the banks are supposed to be able to respond to whatever is provided for them in some kind of a rational way. And they didn’t do. As I said, they all relied too heavily on the same set of numbers. But I’m not sure that I think that more regulation is the answer. Is that what you’re arguing for?

### Conspiracy Advocate (CA)
Claim: On the contrary. I’ve never said I’m in favor of more regulation, simply better regulation.

### Scientific Advocate (SA)
Claim: Well, in what way is it better?

### Conspiracy Advocate (CA)
Claim: Can I conclude my point? If you think back to the highly regulated financial markets of the 1970s, it’s not as if that “Blame Washington More Than Wall Street” (3/17/09) was a period without financial crisis. I’m old enough to remember stagflation and the secondary banking crisis in the U.K. and the problems of that period were in many ways as serious. Certainly the recession of the early 1970s was as serious as anything we’ve experienced so far, though I don’t rule out that this is going to get worse. So, no, I’m not in favor of more regulation. The heavy regulations that were imposed during and after the Great Depression didn’t actually prove to be that benign. The trouble is that the deregulation, much of which was justifiable, was taken to excess. This, I think, is the point that John Steele Gordon, Nouriel Roubini and I want to stress. And it’s not difficult, if one compares different regulatory frameworks around the world, to see why the U.S. was so bad.

### Scientific Advocate (SA)
Claim: But don’t you think the fact, the point that I made about six hundred million dollars being poured into Washington, they don’t have that system in Canada, either, for lobbying and for political campaign fundraising.

### Conspiracy Advocate (CA)
Claim: But you understate the case.

### Moderator
Claim: Nouriel Roubini, let’s let Nouriel Roubini come in and respond.

### Conspiracy Advocate (CA)
Claim: “Blame Washington More Than Wall Street” (3/17/09) I think there is a strong correlation that goes to history between degree of proper regulation and financial crisis. You know, after the Great Depression we imposed a system of strong regulations of the financial system, capital controls and for a few decades there were not that many financial crises and banking crises. It’s not just the U.S. If you look around, for the last twenty years, you have had financial crises and banking crises and so on in a number of countries. And what has been changing over the last twenty years, starting with Ronald Reagan and then Margaret Thatcher, the ideology became of deregulation at any cost, first in advanced economies and then in emerging markets.

Now, some deregulation was good. Nobody is in favor of excess. Even probably we swang the balance too much in the direction of too much regulation after the Great Depression and that led to not enough financial innovation. But deregulation without a proper institution and so on has been known to lead to financial crises, like in East Asia, like in Mexico, like in Argentina and so on. And therefore, there is a strong correlation between the quality of the regulatory and supervisory regime and whether financial crisis occurs. There’s a trade off between the two, but that’s what’s really the fact that now in spite of the great moderation, low inflation and growth, these financial crises are “Blame Washington More Than Wall Street” (3/17/09) occurring now more frequently. These should occur once every thousand years. Now occur every other year – more frequently, more virulent and more costly in every way.

### Moderator
Claim: Alex Berenson, from the other side.

### Scientific Advocate (SA)
Claim: Certainly there has been a huge amount of deregulation in the last twenty years. There’s also been major changes in the structure of Wall Street. Firms, you know, Wall Street was essentially a set of partnerships, largely, until the Seventies and by the Nineties, I think, Goldman was the last big firm to give up the partnership model. So, again, it’s not your capital at risk anymore. It’s your shareholders’ capital at risk. You don’t own your firm anymore, you own a portion of it. I don’t think it’s an accident that there are some small partnerships out there that have essentially thri-- Well, thrive may be too strong a word. But they have survived this crisis.

The other very, very important change, really the most important change, is the egregious increase in compensation. It’s one thing if you’re making five hundred thousand dollars a year. Let’s say you’re making some multiple of an average American’s salary, where if you do that for ten years, you’re, you know, you’re very well off. It’s another thing if one good year makes your life and “Blame Washington More Than Wall Street” (3/17/09) makes your children’s lives. It really skews your incentives.

### Moderator
Claim: John Steele Gordon.

### Conspiracy Advocate (CA)
Claim: I just want to point out that Nell has said that Wall Street spent six hundred million dollars lobbying Washington for regulations that Wall Street liked. I’m sure that’s perfectly true. On the other hand, Washington took the money and produced the regulation.

### Moderator
Claim: Nell?

### Scientific Advocate (SA)
Claim: You know what? Washington has its own market system. And, people have got to get re-elected. That’s what accountability is. Yeah, they took the money. But, you know, you’re blaming the victim there.

### Moderator
Claim: Nell, do you want to respond to the audience response?

### Scientific Advocate (SA)
Claim: Yeah, sure. If, look, if--

### Moderator
Claim: The victims are the people who pay taxes here.

### Scientific Advocate (SA)
Claim: “Blame Washington More Than Wall Street” (3/17/09) If you want to, if you want to make this about campaign finance reform, I’d be happy to turn this into that debate and I’d be happy to come back and have that debate. I’m totally in favor of that. But the United States is the only country in the world that has this level of corruption coming into politics from money because this is the only country in the world that doesn’t free television time and forces politicians to buy the time. So you want to take money out of politics, I think that would be a great thing. I think it would be hugely beneficial in Washington, believe me. But you cannot blame, you cannot blame Washington for the fact that all this money comes in from Wall Street. .

### Conspiracy Advocate (CA)
Claim: You know, Washington might be corrupt but you have to think about the international dimension of this phenomenon. There are many countries with totally different laws about lobbying and so on and there have been about fifty banking crises in the last twenty years and have occurred in very different political regimes. And if there is something in common among all of them, it’s that in most of these cases you had a controlled financial system and then deregulation occurred too fast and in ways that did not provide prudent regulations provision of the financial system. As I said, you know, capitalism is based on greed. Greed is just “Blame Washington More Than Wall Street” (3/17/09) about incentive, about maximizing returns. We’re all greedy, you know. First of all, you said you are the only one from Washington. I spent two years at the White House in Treasury and also ran a successful business. So I know about policy. I also know about business. I tell you, in my business I’m greedy and I react to incentives but I want public policy to be setting rules and regulations so that I don’t misbehave and I don’t cheat and I don’t lie –

### Moderator
Claim: Please, let me bring, –

### Conspiracy Advocate (CA)
Claim: ...and I don’t take excessive risks with taxpayers’ money because—

### Moderator
Claim: Niall, Niall Ferguson. Your teammate, Niall.

### Conspiracy Advocate (CA)
Claim: Nell, I’m still struggling to understand how the recipients of bribes are victims. I’m sorry.

### Conspiracy Advocate (CA)
Claim: I have to tell you, you’re, I’m afraid your moral GPS just broke down on you there. Let me just say, let me just say that this is abso--

### Scientific Advocate (SA)
Claim: “Blame Washington More Than Wall Street” (3/17/09) It is not a ...and in fact, if you look at the lobbying statistics you’ll see that half of the people that took the money voted against them anyway, which is part of politics, too. But the point is, as you well know, people ran...

### Conspiracy Advocate (CA)
Claim: Well, hang on.

### Scientific Advocate (SA)
Claim: People ran for office and were elected on policies of deregulation. And –

### Conspiracy Advocate (CA)
Claim: Hang on one moment.

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: You’ve hit the nail on the head here. AIG, P-I-G, AIG spent 9.7 million dollars on federal lobbying last year, in one year. And that was down on the previous year. It’s contributed directly to candidates, to elected officials and parties, 9.3 million dollars since 1989. It would have been much more but for campaign finance limits. And the top recipients of the money include the Chair of the Senate Finance Committee and the Chair of the Senate Banking Committee. Now, if that doesn’t tell you that “Blame Washington More Than Wall Street” (3/17/09) something is morally rotten at the heart of Washington, I don’t know what we have to show you.

### Scientific Advocate (SA)
Claim: If it doesn’t tell you that something is--

### Moderator
Claim: Jim, Jim, I want to – Jim Chanos, you contrarian you have been sitting there silently on the side against the motion.

### Scientific Advocate (SA)
Claim: Well, just because the Keystone Kops couldn’t catch the gang that couldn’t shoot straight, doesn’t absolve that gang from its guilt. In-- in not only looting the system with material intent but materially abrogating their fiduciary responsibility to their clients and the nation.

### Moderator
Claim: I want to, look, I want to bring the audience, you the audience into it at this point. And it’ll take us about twenty-five seconds to get a sense of how many hands are up and we’ll come to you with microphones. But we would love to bring you into this conversation now and by your responses already you are a terrific, a terrific audience. So where is a, let’s bring one down to the center, to the gentleman in the blue tie.

### Moderator
Claim: I have a question for Mr. Ferguson. I believe you said that you “Blame Washington More Than Wall Street” (3/17/09) don’t believe in more regulation, only in smarter regulation. But eliminating lobbying is that part of smarter regulation and if so, do you know a constitutional way to do it?

### Conspiracy Advocate (CA)
Claim: Well, the regulation that seems to be more important than that, actually, has to do with bank capital adequacy. I don’t think one can simply say that this financial crisis is a result of lobbying. That would be a stretch. This crisis is much more to do with excessive leverage. And if one simply regulates bank capital adequacy better, moves away from the self-regulation of Basel I and Basel II, I think many of the problems will be resolved. I’ve written on this--

### Conspiracy Advocate (CA)
Claim: Can I finish now? I mean, I know you’re eager to have at me and I always welcome interruptions. I just want to remind you that the victims in the crime that we’re discussing here are the taxpayers and voters of the United States who are now on the hoop for, what?, nine trillion dollars? Now, I’ve written actually on the subject--

### Conspiracy Advocate (CA)
Claim: “Blame Washington More Than Wall Street” (3/17/09) ...of campaign finance reform. And it seems to me extremely problematic. You know, it’s been cited, I don’t know where you got this evidence from, Nell, that most other countries in the world don’t have this problem. This is completely untrue. The problem of corruption is endemic in most countries and the United States is very far from being the worst. People talk about the BRICS – Brazil, Russia, India, China – all vastly more corrupt than the United States. The exceptions are a tiny number of countries in Europe, which for cultural reasons, seem not to suffer from chronic corruption. Those countries do not suffer from chronic corruption – not because of regulation. There are many, many regulations that restricts lobbying and campaign finance in Europe. And in some European countries they work and in others they don’t at all and they’re simply circumvented. So don’t delude yourself. You can’t simply fix the problem of financial crises by eliminating political finance.

### Scientific Advocate (SA)
Claim: You don’t mean, are you saying that there was no lobbying involved in reducing the capital requirements? There was tremendous lobbying involved.

### Conspiracy Advocate (CA)
Claim: On the contrary. I couldn’t agree more.

### Moderator
Claim: “Blame Washington More Than Wall Street” (3/17/09) I’d like to see Alex Berenson, who has been patient, now.

### Scientific Advocate (SA)
Claim: No, I think what we all would agree on is that in a very real way, Wall Street has set the conditions of its own regulation in the last fifteen years. And clearly, that has gone too far. And Washington, I mean, to me, seems to work best when there are two strong sides debating an issue. When it came to deregulating the banks there really wasn’t anybody saying, Don’t do it. I mean, there were a few people who didn’t have any money. But the commercial banks wanted it and the investment banks went along with it and nobody really disagreed. So when you have a condition where the industry is essentially creating its own regulation, that’s no regulation. And then it falls even more on the people, the executives, the managers in that industry to act like adults, which they did not do.

### Moderator
Claim: Niall Ferguson.

### Conspiracy Advocate (CA)
Claim: One, one question’s for you, Alex. You represent the fourth estate here, the press. What, where was the press when these things were being done? I don’t remember extensive coverage of the relaxation of bank capital adequacy “Blame Washington More Than Wall Street” (3/17/09) rules in 2004 in The New York Times. But perhaps I missed that Krugman column.

### Moderator
Claim: Let’s go back to some questions and I just want to point out the last question was a perfect example of a question. Let’s follow that model toward the top. A gentleman who caught my eye, and that’s you reaching for the microphone.

### Moderator
Claim: Yes, thank you. To go quickly from euphemisms, Washington being one, Wall Street being another – and to just not single out poor old Bernie Madoff as being the villain of the moment, can we have from the panel some of the names of the human beings who were me...behind the mechanisms that created this problem-- such people as likely as Chuck Schumer, Barney Frank, Chris Dodd and others of that ilk.

### Scientific Advocate (SA)
Claim: I mean on the—you can also name Stan O’Neal and Chuck Prince, and Frank Raines, and Dick Fuld, I mean, you know, you can name the guys who took home, collectively, billions of dollars in the last five years.

### Moderator
Claim: John Steele Gordon just because you haven’t spoke in a while, would you like an in on this? “Blame Washington More Than Wall Street” (3/17/09)

### Conspiracy Advocate (CA)
Claim: Frank Raines of course was a Washingtonian to his fingertips. And—

### Scientific Advocate (SA)
Claim: He’s the CEO of a public corporation.

### Conspiracy Advocate (CA)
Claim: A public corporation that had unique tax advantages, and had an implicit government guarantee, even though legally there was no guarantee but it was implicit, and of course when they did collapse, the government came up and bailed them out. Which is why they were able to borrow money at below-market rates, I mean so it was a—you know, Fannie and Freddie were economic chimeras created in Washington by the government, for purposes of making the government books look better. And then they ended up with this beast.

### Moderator
Claim: Question from the far top.

### Moderator
Claim: Um…there, in the impetus for what happened, there’s been a lotta talk about greed, on the side of the… folks arguing for the resolution, um, as an excuse. I’d like to hear you address the question though of incompetence. There—

### Moderator
Claim: “Blame Washington More Than Wall Street” (3/17/09) You said incompetence—?

### Moderator
Claim: Incompetence. A lot of these companies, they didn’t just take risks, they weren’t just greedy, the leadership was incompetent, they ran their companies into the ground. They’re bankrupt. And also because of the risk to the rest of the country and the world economy, taxpayers have bailed them out. What about this question of incompetence.

### Moderator
Claim: Thank you. To which side are you addressing your question—

### Moderator
Claim: Oh, the—for the motion.

### Moderator
Claim: For the motion.

### Conspiracy Advocate (CA)
Claim: Wait—

### Moderator
Claim: Nouriel—

### Conspiracy Advocate (CA)
Claim: —I would not, you know, we know there are these issues in corporate governance because in any corporation, the shareholders cannot control the actions of the managers, there is information the manager might want to maximize the “Blame Washington More Than Wall Street” (3/17/09) rents and that leads to distortions, you know, the manager might short of compensation and benefits, at the expense of the shareholders, but again, you know, Alan Greenspan, and he—when he made his testimony, he made the admission, he said—he admitted that one big mistake he thought that he made was that he thought the shareholders of companies could control the behavior of bankers and managers and because of that he didn’t think it was necessary to further regulate this financial institution. For 30 years of corporate finance literature, that talk about these agents’ problem between principle and agents when there is information. It’s well-known for Chicago, to MIT, to anywhere else. And he was clueless about it, how could he be clueless. If he’d known about it, there were regulation that could have minimized those distortions of compensation, of information, of taking excessive risk through leverage, controls through more liquidity, to reducing certain type of incentive. They were clueless about it.

### Moderator
Claim: Nell Minow, do I see you again agreeing with your opponents?

### Scientific Advocate (SA)
Claim: I think, listen, as I said there’s a lotta blame to go around, there’s a lot of incompetence to go around but when Paul Volcker says that he does not understand the derivative securities it seems to “Blame Washington More Than Wall Street” (3/17/09) me we should have a Paul Volcker rule that if Paul Volcker does not understand it you should not be able to sell it.

### Moderator
Claim: And a question from the center.

### Conspiracy Advocate (CA)
Claim: And in 2000 we decided to completely deregulate any credit derivatives. They should be over the counter, not on exchange, no settlement rules, no clearing rules, no counterpart rules, nothing. That was a mistake of policy, there were people in policy, the CFDC were against it and SEC, the Fed, everybody else said no. Should be a free market not regulated and that led to the disaster—

### Scientific Advocate (SA)
Claim: But—

### Conspiracy Advocate (CA)
Claim: —of credit derivatives

### Scientific Advocate (SA)
Claim: But Dr. Doom—

### Moderator
Claim: Alex Berenson—

### Scientific Advocate (SA)
Claim: —wouldn’t that have—wouldn’t that have just driven—

### Conspiracy Advocate (CA)
Claim: “Blame Washington More Than Wall Street” (3/17/09)—policy procedure, we could have put them on an exchange—

### Scientific Advocate (SA)
Claim: But if we had done that, wouldn’t the firms have just traded those overseas.

### Conspiracy Advocate (CA)
Claim: No, because, that’s why you have international rules and we have rules about avoiding—

### Scientific Advocate (SA)
Claim: So it’s—

### Conspiracy Advocate (CA)
Claim: —that jurisdictional you do—

### Scientific Advocate (SA)
Claim: So it’s now Brussels—

### Conspiracy Advocate (CA)
Claim: —we do

### Scientific Advocate (SA)
Claim: —is the problem?

### Conspiracy Advocate (CA)
Claim: Huh?

### Scientific Advocate (SA)
Claim: It’s now Brussels that we’re debating—

### Conspiracy Advocate (CA)
Claim: Listen, capital, we have international rules, there is a “Blame Washington More Than Wall Street” (3/17/09) agreement, there has to be coordination of international regulatory policy, ‘cause otherwise things are gonna go offshore. But instead of cracking down on offshore centers, we’re stimulating them, that was again a mistake of policy—

### Moderator
Claim: Jim Chanos.

### Scientific Advocate (SA)
Claim: Well, actually after LTCM in 1998, Jerry Corrigan and others were charged with the effect of looking at credit derivatives, and basically went to the industry, who went down the self-regulatory route for clearing and other mechanisms. So again we have a case of Washington going to the industry and the industry doing what it could, to drag its feet or skirt—skirt what was probably good policy all along.

### Moderator
Claim: Okay, we are halfway through the head-to-head par—round of the debate. The motion is “Blame Washington More Than Wall Street for the Financial Crisis,” I’m your moderator, John Donvan, and we are now going to the center for a question.

### Moderator
Claim: That’s for the against-the-motion side…it seems that incentives is like one of the main issues here. Compensation’s been crazy, and incentive—incentive’s misplaced, it’s been all over the place, how do you change that, if not by better regulation, how do you “Blame Washington More Than Wall Street” (3/17/09) change human nature, which is basically like, they’ve been bending the rules, they’ve been swinging, as Roubini mentioned, he’s gonna be greedy in his business, I would be greedy in my business, I would do whatever it takes to maximize my profits and that’s what they’ve been doing, if it’s not about better regulation how do you, how do you really like, how do you change it?

### Moderator
Claim: Are you—are you literally asking how do you change human nature?

### Scientific Advocate (SA)
Claim: No, no—

### Moderator
Claim: I—that seems to be—

### Moderator
Claim: In a way you are—

### Moderator
Claim: —how to change the incentive—

### Moderator
Claim: And I think maybe it’s a rel—quite relevant question—

### Moderator
Claim: How to change, how do you change like how people are, the models and how people are doing—

### Moderator
Claim: “Blame Washington More Than Wall Street” (3/17/09) I see heads being put together on this one.

### Scientific Advocate (SA)
Claim: Aside from—

### Moderator
Claim: Alex Berenson—

### Scientific Advocate (SA)
Claim: Aside from alcohol I don’t know— No…I, no, I think that’s a really good question. As I said at the very beginning of my statement, that is not the question we’re debating, tonight. We’re debating whether or not these firms should have behaved better, under the regime that they had. That said, I do think—I mean I think that what Niall says about increasing capital requirements is at the core, it’s a very, very good idea. I can imagine, and I don’t know whether this could work in reality, there’d have to be some very, very smart people to figure out if it could work— Sort of a dual system where there’s one group of very, very heavily regulated, essentially postal banks, that have, that have explicit government guarantees of insurance, that offer sort of plain vanilla products, that are, you know, essentially national, quasi-national institutions. And then there’s another group where, anything goes. And you can make or lose whatever you want, you can pay your employees whatever you want, but if you go under, you are not getting one dime and “Blame Washington More Than Wall Street” (3/17/09) that is the explicit charter that you’re operating under. And the difficulty is figuring out how those two systems would interface. But if you could do that, then, hopefully we could avoid this problem in the future.

### Moderator
Claim: John Steele Gordon.

### Conspiracy Advocate (CA)
Claim: I don’t know about human nature, I don’t—you can’t change it. I mean that’s virtually by definition. But I think it was Frances Bacon who said that to rule nature you must first obey it. And what we have to do is simply understand human nature and take it into account when we set up our rules. One thing about compensation, is that it’s been very fashionable in the United States for years now to have the CEO also be the chairman of the board. Which makes him his own boss. And whenever you are your own boss, you are going to overpay yourself. They—yeah, the CEO stuffs the board with people who are dependent upon him, other high-level management, I mean it seems to me that a corporation, unless you have enough stock to justify a seat on the board, if you work for that corporation you shouldn’t sit on the board.

### Moderator
Claim: Nouriel.

### Conspiracy Advocate (CA)
Claim: “Blame Washington More Than Wall Street” (3/17/09) There is a regulatory capture in almost every industry, the lobbyists take over the regulators and change things into their own interest. But there’s only one industry, the financial industry, in which this thing leads, over and over again, to financial crisis, banking crisis. They’re a disaster, they cost trillions of dollars. And ask yourself what happens, and why that happens. It happens for two reasons. One because banks have deposit insurance and deposit guarantees. Should we take some of the asset people money, you leverage like crazy, do crazy things. If you gain it’s your money, otherwise it’s the taxpayer. Two, we have lender of last resort support. When banks get in trouble the Fed comes to the rescue, and it’s a variant of this moral hazard of the bailout. And that’s why these banking crises occur over and over and over again, and they’re becoming more disrupting, more expensive and so on. That has to do key, with exactly our regulatory system, there is something wrong about it and if we don’t fix it these things are gonna happen, and the costs are gonna come even bigger, again, people are greedy in every industry, people in every industry try to avoid regulation sometimes with lies, sometimes by cheating or avoiding, whatever. That’s human nature, why it leads to disaster in financial industry, because we have the system.

### Moderator
Claim: “Blame Washington More Than Wall Street” (3/17/09) Sir, you have, you have the microphone in your hand, go ahead, please.

### Moderator
Claim: Thank you. This is addressed to both groups. So it seems to me to reflect on which group deserves more blame, we have to make some assumptions and I think the participants are making assumptions, about what is behavior that’s reasonable to expect from one group or another group. And then the one—the group that departs further from those reasonable expectations, gets more of the blame. But I don’t think everybody agrees on what can reasonably be expected from each of the groups. So, it’s assumed that, by some people, that you can reasonably expect greedy behavior, uh, from, uh, Wall Street types or from the people in that business, but not that it’s reasonable for Congress people in the political game to try to do things to keep—this is Nell Minow’s point of course—

### Moderator
Claim: Niall Ferguson who’s—

### Moderator
Claim: So—

### Moderator
Claim: —arguing for the motion— “Blame Washington More Than Wall Street” (3/17/09)

### Moderator
Claim: —so how do you decide which are the reasonable expectations from the different groups, and won’t that tilt very strongly what blame you assign.

### Moderator
Claim: Niall Ferguson—

### Conspiracy Advocate (CA)
Claim: This isn’t— This isn’t rocket science. One set of people under discussion, owes a duty to the public interest. Those are the politicians and regulators. That is why we call them public servants. And the other group, let us take the investment bankers, because of course, Wall Street is composed of many different institutions, but let’s take the investment bankers. They owe a duty, to their shareholders, and also to bondholders. Now it’s quite interesting though the point hasn’t been made yet, that to all of these investment banks performed equally badly. The fate of Bear Sterns and Lehman Brothers illustrates that egregious bad management can achieve. But the performance of Goldman Sachs was really significantly different. Goldman actually didn’t lose substantial amounts of money, though its shareholders have certainly taken some punishment. And the punishment has been meted out by the market, to the people who invested in those banks. They will almost certainly end up with nothing, I’m fairly clear, that those people who invested in “Blame Washington More Than Wall Street” (3/17/09) financial securities will end up with very little indeed. And I think that’s particularly true in the case of the big commercial banks.

### Scientific Advocate (SA)
Claim: But, Niall—

### Conspiracy Advocate (CA)
Claim: And can—can I finish—

### Scientific Advocate (SA)
Claim: —that is exactly the point—

### Conspiracy Advocate (CA)
Claim: —‘cause this is a really important point, Bank of America, and and of course Citigroup. But the interests of the public are to be defended by people in Washington. That is the big difference between these two groups, and that is absolutely clear, that we have to lay the blame on Washington. The failure of Bear Stearns, was a disaster from the point of view of people who invested in it. But it became a disaster for the entire US economy, and indeed the world economy, because of failures of regulation. And those seem to me to lie very squarely in Washington D.C.

### Moderator
Claim: A question from the—

### Scientific Advocate (SA)
Claim: I think you’ve just proven the point—

### Moderator
Claim: “Blame Washington More Than Wall Street” (3/17/09)—woman in the center, please—

### Scientific Advocate (SA)
Claim: —that not every bank, failed, not every bank behaved equally badly—

### Moderator
Claim: This is Alex Berenson speaking. Go ahead, Alex.

### Scientific Advocate (SA)
Claim: Not every bank is as responsible as every other bank for this crisis, Goldman is gonna get by a—you know, Goldman’s gonna get along fine, there are gonna be commercial banks that get along fine.

### Conspiracy Advocate (CA)
Claim: It helps that AIG has been bailed out of course—

### Scientific Advocate (SA)
Claim: Well, that’s true, that’s true—

### Conspiracy Advocate (CA)
Claim: —let’s not lose sight of that.

### Scientific Advocate (SA)
Claim: But—

### Conspiracy Advocate (CA)
Claim: The twist in the tale.

### Scientific Advocate (SA)
Claim: But wouldn’t you agree that that shows that there were “Blame Washington More Than Wall Street” (3/17/09) distinctions made on the street?

### Moderator
Claim: Ma’am, I encourage you to break in to this exchange—

### Moderator
Claim: Okay—

### Moderator
Claim: —with your question.

### Moderator
Claim: I—I know that given all the discussion about greed at financial institutions many of us would assume that there were many good people at these companies who were simply afraid to say something about what they saw. And my question is for anyone on the panel, can you envision a way to effectively institutionalize a financial company employee’s ability to report irregularities or essentially poor practices—

### Scientific Advocate (SA)
Claim: I think there’s a—

### Moderator
Claim: — in ways that couldn’t be, that, that you can’t, simply avoid—

### Scientific Advocate (SA)
Claim: I’m not really sure I agree with that, I mean there were not whistle-blowers jumping up and calling the New York Times to tell us about things, and even Enron, and Jim knows, you know, Jim certainly knows more about Enron than anybody— The “Blame Washington More Than Wall Street” (3/17/09) whistle-blowers really were a—

### Scientific Advocate (SA)
Claim: Yeah, very, very late in the game—

### Scientific Advocate (SA)
Claim: Also Sarbanes-Oxley gives huge, huge protections to whistle- blowers and incentives to whistle-blowers. So I really don’t think that’s the problem.

### Moderator
Claim: Ma’am, you can follow up.

### Moderator
Claim: Take the microphone to follow up just so we hear you.

### Moderator
Claim: That’s a very risky thing to do to be a whistle-blower to the New York Times, if there are—there could be other ways in which confidentiality for employees is protected.

### Scientific Advocate (SA)
Claim: And there is under Sarbanes-Oxley. “Blame Washington More Than Wall Street” (3/17/09)

### Moderator
Claim: Okay, but not…okay, but, there probably are still—

### Moderator
Claim: Okay, I—I—I—

### Moderator
Claim: —better ways to do it—

### Moderator
Claim: —I can’t let you get into the debate but thank you for the point, I wanna go to the young man in the front row, please.

### Moderator
Claim: I have a question for Mr. Chanos? You said earlier that, the government has never uncovered corruption, uh, I believe for the past 20 years which is it’s all done by journalists, and short firms. But does it—would that mean that Washington is at fault and granted, these companies shouldn’t have been corrupted in the first place. But… wouldn’t—if they’re given the opportunity, wouldn’t it make sense they would, they would abuse, wouldn’t it be foolish to assume that they wouldn’t abuse this power that they have?

### Moderator
Claim: Question mark, thank you. That’s a good question.

### Scientific Advocate (SA)
Claim: Well…let’s just look at the response of this crisis. In following, immediately following what Bear—the demise of Bear Sterns, you “Blame Washington More Than Wall Street” (3/17/09) had the CEO’s of our major banks and brokerage troop down to Washington. What are the two things they requested, from Washington, following this stunning collapse almost out of the blue of one of our major brokerage firms. Was it tightened regulatory surveillance, was it more regulators on the trading desk, was it something like that, no. They asked for two things. They asked for short selling to be stopped, or curtailed, and they asked for a loosening in the accounting rules. And on both cases, one was done, and changed, the other’s under consideration now. So rather than tightening up things and making things more transparent, and giving incentives to market forces like short sellers, to ferret out fraud, and malfeasance, what has Wall Street done? It’s come running to Washington to ask for more help, and more obfuscation and more opacity. And that’s about as telling as you get.

### Moderator
Claim: Does the side for the motion wanna respond to that? John Steele Gordon.

### Conspiracy Advocate (CA)
Claim: Washington could say no.

### Moderator
Claim: All right, short and sweet. Gentleman at the top?

### Moderator
Claim: Both sides acknowledged I think that one of the major questions “Blame Washington More Than Wall Street” (3/17/09) here is who’s more to blame. So I wanna try to make it, maybe philosophical, and go back to the Keystone Kop examples, my question’s for against the motion. So let’s take the Keystone Kops, couldn’t catch the gang, doesn’t make the gang less culpable. Obviously everyone’s gonna agree. But given that the job of the Keystone Kops in the first place, given the job they’ve taken on, is to keep order, if they’re asleep or corrupt, maybe drunk, aren’t they therefore even more wrong than the people who in the first place committed the action who had no responsibility, fiduciary duty, whatever you wanna call it, who had no responsibility beyond what they’ve signed to but whom— are not nearly in the same position…

### Moderator
Claim: Thank you—

### Moderator
Claim: —of authority.

### Moderator
Claim: Thank you. Nell?

### Scientific Advocate (SA)
Claim: Well, the idea of the SEC when it was created in the 1930s, was that it would be about putting information into the market and letting the market sort everything out, the SEC, his authority is very limited, so they’re a Keystone Kop without a billy club. And, it’s a good idea to consider that, again, and it’s a good idea to “Blame Washington More Than Wall Street” (3/17/09) consider rewrapping some of that unwrapped regulation that we talked about, but right now Washington doesn’t have the tools, and doesn’t have the authority necessary, I think, to provide that kind of oversight.

### Moderator
Claim: And your opponent, Nouriel Roubini?

### Conspiracy Advocate (CA)
Claim: Well, you know, I go back again to the issue of incentives on international scales, financial crises do not occur everywhere, there are countries like Canada and many others that have better regulators and supervised financial system, and these things don’t occur. It’s not that Canadians are more moral or less greedy or less incompetent or more competent or more arrogant than anybody else and, same thing for Europeans and Asians and you name it. Human nature is similar. And by the way they are not crooks, you know, everybody responded to incentives, everybody wanted to maximize profit returns and whatever, that’s what market economies are all about, but we know that human behavior can lead to excesses in society, that’s why we have institution in society, otherwise the law of the jungle. And in this case of financial market you know that greed and excesses can lead to damaging effects, that’s why prudential regulation, supervision of financial institution, is so much more important so at the end of the day, it’s good public policy, it makes a difference “Blame Washington More Than Wall Street” (3/17/09) between crisis occurring or not occurring, that’s the lesson of the last 50 years, it’s not about human nature, or greed or being criminal—

### Moderator
Claim: We have time for one more question.

### Moderator
Claim: This is for, against the motion, it seems like this is a, uh, chicken, which came first, chicken or the egg.

### Moderator
Claim: Do you mind if I tell the panel that actually both sides can address your question, we’ll be—

### Moderator
Claim: Sure, absolutely—

### Moderator
Claim: the motion, but please, everyone consider this your final question—

### Moderator
Claim: It may be so appropriately chicken versus the egg, chicken being Washington, being afraid to do what’s right, and Wall Street who’s laid a ginormous egg. If it is a chicken- versus-egg scenario, and, as Mr. Gordon pointed out that we have a history of financial crises every 20 years for the most part, uh, wouldn’t it seem to be that Wall Street since our country was founded first and foremost by entrepreneurs and businessmen, “Blame Washington More Than Wall Street” (3/17/09) uh, that set out to form their own government, that it would actually be driven more so by Wall Street than the government that they formed?

### Moderator
Claim: Alex Berenson.

### Scientific Advocate (SA)
Claim: I think, just to address that and to address the previous question ‘cause I think the previous question is a very good one, do you blame the cops or do you blame the robbers, if it—you know, the robbers are gonna steal isn’t it the cops’ job to stop them. I think you can take the Keystone Kops analogy too far. We want to have a banking system that makes loans. We want credit to be available to people, you know, the invention of the credit card, is actually one of the great inventions in American soc—you know, in the world in the 20th century, it really is, it’s the democratization of credit, where you didn’t have to go in and get down on one knee before a banker, to get a loan, was meaningful to people. Being able to get a house and a mortgage is meaningful to people. So what we don’t want—so, you know, they’re robbers, but they’re not robbers, they’re people serving a useful societal function. And it’s up to… So— So that makes— I know, I know, I can’t believe I just said that either.

### Moderator
Claim: “Blame Washington More Than Wall Street” (3/17/09) I think Niall Ferguson is trying to get in here—

### Scientific Advocate (SA)
Claim: But wait, let me just quickly fin—

### Conspiracy Advocate (CA)
Claim: As your attorney I would advise you to stop speaking immediately—

### Scientific Advocate (SA)
Claim: Let me just quickly finish. Quickly finish. That makes the job—

### Conspiracy Advocate (CA)
Claim: —bad guys, I’m getting there.

### Scientific Advocate (SA)
Claim: That— So, that means that the regulators, are not strictly out to arrest them or bust them, we have to set up a somewhat permissive regulatory system to allow them to operate, and then hope-slash-insist, that they actually don’t run the system into the ground, which, we didn’t do that—

### Conspiracy Advocate (CA)
Claim: Can we do chickens and eggs now, because I’m getting bored of cops and robbers. The— Far be it from me to lecture an audience like this about American history but it seems to me that, the question wasn’t really framed quite correctly. From—

### Moderator
Claim: “Blame Washington More Than Wall Street” (3/17/09) I think you’re handling it okay, actually—

### Conspiracy Advocate (CA)
Claim: That—thanks. The—from the very inception of the United States there was a profound tension, between Washington and New York. Alexander Hamilton’s vision of the United States as a financial power was not shared by all the founding fathers and indeed James Madison was extremely skeptical about it. That’s why there was consistent resistance to the creation of a central bank in the United States, that lasted right up until 1913 with the Bank of the United States being chartered and then gotten rid of twice, in the course of the 19th century, so— I think we need to see this as part of a long argument, within American political culture. How powerful should New York be. And should those other parts of the United States, let’s call it Main Street, should they in fact dominate. And I think what’s happened in the last 10 years, is that New York did get the upper hand. And I think the rest of the country, is ready for a backlash.

## Round 3

### Moderator
Claim: Ladies and gentlemen, that concludes Round 2 of our debate. So we are in the final stretch, in a very short time you the audience will decide who is the winner. Recall that at the start of the debate we asked you whether you agreed or disagreed with the motion before us, “Blame Washington More Than Wall “Blame Washington More Than Wall Street” (3/17/09) Street for the Financial Crisis,” before the debate, 42 percent of you were for the motion, 30 percent against, and 28 percent undecided, we will now have summarizing comments by each side of two minutes each. And I wanna ask you at the very end, I will make an announcement of the winner, and at that point I would ask for your forbearance, give us 30 seconds to end the NPR broadcast, it oh so pleasant to have the sound of applause. And I will at a certain point raise my hand, I would ask you to applaud and then I’ll bring it down and everyone can go home. So just— It’ll be this. That’s clear? We’re not gonna do the rehearsal, it’s not kindergarten, you know— okay. Round 3, summarizing comments from each side, first summarizing…against the motion, “Blame Washington More Than Wall Street for the Financial Crisis,” Alex Berenson, investigative reporter for the New York Times.

### Scientific Advocate (SA)
Claim: I wanna thank Niall, for sort of making our point with his very last remark where he said that New York became more powerful than the rest of the country I do think that to some extent all six of us forgot something when we were presented with this question that only came out in the debate in the discussion in the last 20 minutes, and that is, the internationalization of the— of the financial system. That when in 2000 the banks said to Washington, if we don’t want these regulations on credit “Blame Washington More Than Wall Street” (3/17/09) derivatives, what they also said was, if you force this on us, we are going to go elsewhere. And, you know, it was only a few months ago that we were hearing that London was gonna be the primary financial center in the world, followed possibly by Shanghai and Hong Kong within about five to 10 years, now, I think the city in London is getting even more badly hurt right now than New York.

But the point is, actually that Washington-versus-Wall Street is a false dichotomy because the banks became so powerful within the sphere of the financial world, that they essentially told Washington, if you try to regulate us strictly, you are going to lose our business, jobs are gonna go overseas, and there will be no regulation at all. So you can have the SEC, and the Fed, and weak regulation, or you can have no regulation, those are the choices that you face. And they meant it. There were jobs shifted to London, a lot of jobs shifted to London, jobs shifted to Hong Kong. And I think that when you forget that, it becomes easier to blame Washington, if you remember that, you will vote against this resolution, you will put the blame where it belongs, on Wall Street. Thank you.

### Moderator
Claim: Summing up for the motion, “Blame Washington More Than Wall “Blame Washington More Than Wall Street” (3/17/09) Street for the Financial Crisis,” John Steele Gordon, author of An Empire of Wealth.

### Conspiracy Advocate (CA)
Claim: Well, I just wanna say that while Wall Street certainly needs reform, it always needs reforms and it’s constantly being reformed, it has been for 200 years. But it doesn’t need reform as badly as Washington, specifically Congress. Which is a profoundly sick institution. Institutions tend to evolve in ways that benefit their elites, and if you want the poster child for that, it is the United States Congress. I also wanna just add one thing on the… People on the other side have been saying that Wall Street took all this—took their checkbooks down to Washington and lobbied to get the regulation they wanted rather than stricter regulation. And actually said, therefore, Congressmen were the victims of this. I’m sorry, but Wall Street was not debauching a virgin, it was paying a harlot. Thank you very much.

### Moderator
Claim: Thank you, John Steele Gordon. Summarizing against the motion, Jim Chanos, founder of short- selling investment firm, Kynikos Associates.

### Scientific Advocate (SA)
Claim: Boy, how do I follow that one. Well, again, we’ve had a lot of lofty philosophical questions batted back and forth, “Blame Washington More Than Wall Street” (3/17/09) but there have been very, very few facts put forth tonight. And I wanna stay with the facts. So we’ll just consider one instance, Lehman Brothers. Which when it failed, had adequate regulatory capital, and was still profitable in its trailing 12 quarters. Yet when the credit default swaps were settled for Lehman Brothers, a month later, its debts were marked down 90 cents on the dollar. Now its debts at the time in terms of funded debt were $150 billion, stay with me on this, numbers are important when it comes to Wall Street. So, 90 cents off on that dollar bill means the debt was impaired by $135 billion. Lehman bonds still trade around 10 to 15 cents on the dollar, six months later. There’s $20 billion in equity at the time, that tells us that the hole in Lehman’s balance sheet was roughly $150 to $160 billion. To put that in perspective the hole in Enron when the dust cleared, roughly was $60 to $70 billion. Lehman was twice as bad as Enron. We haven’t gotten to AIG yet, or Bear Stearns, or God knows what else. Ladies and gentlemen, malfeasance trumps incompetence for the purpose of this resolution, and I urge you to remember that when you vote.

### Moderator
Claim: Thank you, Jim Chanos, Kynikos Associates. Nouriel Roubini, Professor of Economics and International Business at New York University’s Stern School of Business will summarize for the motion.

### Conspiracy Advocate (CA)
Claim: “Blame Washington More Than Wall Street” (3/17/09) Well, you know, it’s not a debate about robbers and cops because there is a huge amount of evidence that actually, financial development is very beneficial for economic activity. Companies are more financially developed, provide lots of services, you know. Credit cards, mortgages, commercial real estates, insurance, risk hedging, you name it, it’s very important and beneficial but we know that when there is financial innovation sometimes becomes excessive, there is asset bubble, there are credit bubble, excessive restaking.

People become greedy and all the rest, and you can have a system that is so regulated like some countries, like India, whenever there’s a bank that is ever failing, but you won’t actually, the market economy where sometimes, some banks fail. But you don’t want a system which everybody’s collapsing, you have systemic risk. And the distinction there is you want innovation, like in any country because it’s gonna be beneficial, but you want to avoid crisis, and to avoid crisis, you need appropriate rules, institution, prudential regulation of the financial system. Not too much, not too little, it’s a trade-off, it’s not a black-and-white. And the difference between a system that works, that has innovation and provides benefits, and avoids a “Blame Washington More Than Wall Street” (3/17/09) crisis and one which crisis occur over and over again, has nothing to do with Wall Street or the greedy bank as you name it. Has to do with the quality of public policy. Proper supervision and regulation. That’s the distinction, has been always the case across countries, across history, so let’s look at the big picture.

### Moderator
Claim: Thank you, Nouriel Roubini. The motion is “Blame Washington More Than Wall Street for the Financial Crisis,” and summarizing her position against the motion, Nell Minow, editor and co-founder of The Corporate Library.

### Scientific Advocate (SA)
Claim: Politicians are accountable through the political system, you don’t like ‘em, don’t vote for them. You wanna vote for candidates who don’t take money from lobbyists, be my guest, that was a policy that got Barack Obama in part elected. That’s great. But the people who stole money, to send it to Washington, are the people on Wall Street. Is there one shareholder of Bear Stearns or Lehman, who wanted that money to be used to weaken regulation? No it wasn’t, there’s a huge moral hazard involved there. The same moral hazard that involved them paying themselves hundreds of millions of dollars. The return on investment for CEO pay is less than a piggy bank. And that’s because they’ve corrupted the system. They didn’t need any help from Washington for that. They did it themselves. “Blame Washington More Than Wall Street” (3/17/09) So please, vote against the resolution.

### Moderator
Claim: Thank you, Nell Minow, and finally, summarizing for the motion, Niall Ferguson, Professor of History at Harvard.

### Conspiracy Advocate (CA)
Claim: Well ladies and gentlemen, it’s not very often that you hear Washington D.C. defended, by a journalist, a former government attorney, and a short seller. The journalist told us it would all have been absolutely fine if the banks had been as run as—had been run as well as the airlines, when did you last fly Continental, Alex? Jim Chanos told us that corporate fraud is endemic in corporate America, and this goes from Enron to Madoff. What they agree about, and here they do agree with us, is that, in many ways, Washington is in hock to Wall Street. The difference is that Nell Minow thinks that Washington, the legislators, poor things, are the victims, in this strange case. Now, that is where we part company. On our side we see them anything as the victims, we see them as the key perpetrators. And let us not forget just how far this has gone. Who was, Nell, the second biggest recipient of donations from Fannie and Freddie? Yes, it was the President of the United States, Barack Obama. And let’s not forget that among the firms that contributed most generously to his campaign were Goldman “Blame Washington More Than Wall Street” (3/17/09) Sachs, Citigroup, J.P. Morgan, UBS, and Morgan Stanley. What we need to contemplate, ladies and gentlemen, is the Latin Americanization of the American political system. This symbiotic and indeed corrupt relationship between Wall Street and Washington is the thing that is rotten at the heart of the United States, it is the principal explanation for this crisis, and that brings me to the key question you have to ask yourselves. Who has to defend the public interest. Is it the investment bankers, the hedge fund managers, or is it your elected representatives. Ladies and gentlemen, it is perfectly clear, that it is Washington that has failed to defend the public interest, and I fear, it is continuing to fail to do so. Please do vote for the motion.

### Moderator
Claim: Thank you, Niall Ferguson, and that concludes the argumentation portion of the evening, it is now time for the moment of truth, in which you the audience pick the winner. Now you voted earlier when you came in, on the motion which is “Blame Washington More Than Wall Street for the Financial Crisis.” We’re asking you to vote a second time. Does anyone need any further instruction in the voting process, everyone understands. Right. “Blame Washington More Than Wall Street” (3/17/09) All right, we’re gonna lock the keypads, and the results are being tabulated, we’re about…55 seconds away from knowing the outcome of this debate and while we are waiting, I think you are going to wanna hear this… Next month’s topic…is rather salty. First I wanna thank the audience and the panelists for a terrific evening and you were actually a spectacularly good audience with great questions, and a great sense of presence. Our next debate will be Tuesday, April 21st, the motion is, “It is Wrong to Pay for Sex.” Panelists for the motion are Melissa Farley, a psychologist for Prostitution Research and Education, Catharine MacKinnon, a professor at the University of Michigan Law School, Wendy Shalit, author of A Return to Modesty.

Panelists against the motion are Sidney Biddle Barrows, better known as the Mayflower Madame, Tyler Cowen, a Professor of Economics at George Mason University, and Lionel Tiger, professor of Anthropology at Rutgers University, this debate will take place here at Rockefeller University’s Caspary Auditorium. And all of our debates can be heard on more than 170 NPR stations across the country. Please check your local NPR member station listings for the dates, and the times of the “Blame Washington More Than Wall Street” (3/17/09) broadcasts and finally, copies of books by our panelists, as well as past DVD’s, are on sale in the lobby and I read some of these books in preparation for this debate, and they are well worth picking up and taking a look at.

So you have heard the arguments, you have voted twice now— Our winner will be determined by the team that changed most minds. To remind you, when you came in…42 percent of you sided with the motion, “Blame Washington More Than Wall Street for the Financial Crisis,” 30 percent of you were against the motion, 28 percent of you were undecided, and now the results of the final vote, 60 percent of you are for the motion, 31 percent against… 9 percent undecided, the side for the motion wins… congratulations to them, I’m John Donvan… thank you to Intelligence Squared US.
