# Debate Transcript

Topic: Courts, Not Campuses, Should Decide Sexual Assault Cases
Motion: Courts, Not Campuses, Should Decide Sexual Assault Cases

Debate ID: 091615%20Sexual%20Assault


## Round 1

### Moderator
Claim: So please welcome to the stage Bob Rosenkranz.

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hey, Bob. Hey, Bob.

So in terms of topicality, well, it looks like-- it looks like since we started thinking about this one, it's becoming even more topical. I mean, what was our thinking in beginning-- deciding to get this one-- this one on to our stage.

### Moderator
Claim: Well, we felt that this was kind of coinciding with the start of school. It was something that was going to be top of mind for a generation of students going to college for the first time, or going back to college. It was going to be of concern to their parents. And it was timely. But I didn't realize quite how timely the particular date was. And now that I do, I think it's just so important that on this day, of all days, we offer the public a debate where they might actually learn something, a debate where people might actually deal with nuanced issues in a respectful manner, where there could be enough discussion about a topic to leave people with an informed view about it.

### Moderator
Claim: Hearing the other side of the story.

### Moderator
Claim: Perhaps.

### Moderator
Claim: Possibly, it's a possibility. We were chatting beforehand about this motion language and that the curiosity of the fact that we're talking about an adjudication process that involves courts and that also involves campuses, which you are saying to me kind of goes to the point of why this is a tough issue.

### Moderator
Claim: Well, this is a very difficult issue. And I'm going to pull some notes out of my pocket, which I don't normally do, but I want to be sure that I'm sort of quoting law accurately.

### Moderator
Claim: That's not 30 pages of notes, is it?

### Moderator
Claim: This is not. So, the resolution language, "courts not campuses show decide sexual assault cases," so sexual assault is obviously a legal term. "Cases" implies that it's a law case.

And the natural thing in our world is that cases are decided by courts and not campuses. So, that would be a kind of a natural supposition. But in fact, the way this topic arises is much broader than the question of legal sexual assault, there’s a much, much broader concept at stake in the kind of conduct that college campuses are trying to regulate. And let me just-- if you'll indulge me for a minute-- let me just explain a little bit the differences between what the law is trying to regulate and what college campuses are trying to regulate. So the New York penal law, when it's dealing with sexual assault, uses words like "penetration," "physical force," "fear of immediate death or physical injury."It's an element of every offense that the act was committed without the consent of the victim. "Inability to consent occurs if the victim is mentally incapacitated owing to the influence of a narcotic or intoxicating substance, but only if it was administered to him without his consent and only if the defendant did not know the facts around that, the way the narcotic was administered." So, very tough to prove. Corroboration is required so that a person shall not be convicted of any offense solely on the testimony of the victim, unsupported by other evidence. And, all of this has to be proved beyond a reasonable doubt. And if it’s proved, people are liable for jail sentences of five to 25 years. So this is a very, very serious crime, but it is defined in a very precise way, and it's very hard to prove.

In contrast, what the colleges are trying to do in this area is comply with something called Title IX, which is a provision of the Education Act. And it's not a statute. It's not a regulations. It's something called a "dear colleague" letter, which is written by somebody in the-- in the office of the secretary of-- of the Department of Education, telling schools that they're going to lose their federal funding if they don't comply with this letter. And it sets up some incredibly vague ideas about what's objectionable. "Sexual harassment," and I'm quoting, "is unwelcome conduct of a sexual nature, including unwelcome sexual advances, requests for sexual favors, and other verbal, nonverbal, or physical contact of a sexual nature."So it requires all colleges-- I mean, just reading those words should give you a sense of how vague and general and hard it is to know whether they apply or not to any particular kind of conduct. And they-- it requires all recipients, that is, all people getting federal aid to their universities, public and adopt grievance proceedings for the prompt and equitable resolution of sex discrimination complaints. So they've lumped together sex discrimination, sexual harassment, and sexual assault all in one package.

### Moderator
Claim: Well, it sounds pretty tangled.

### Moderator
Claim: It is pretty tangled.

### Moderator
Claim: But that's why we have these debaters here.

### Moderator
Claim: Yeah. That's true.

### Moderator
Claim: To untangle it for us.

### Moderator
Claim: They’re going to untangle it, but let me just make one further quick point, which is that the standards are incredibly different, the standards that the universities are supposed to apply is just that it's more likely than not that an offense has occurred, they are not required to have counsel as part of these proceedings, they're not required to have an appeal as part of the proceedings, so it's a very different set of standards of what constitutes an offense, a very different kind of standard about what constitutes proof, and very different kinds of conduct covered under these. So it is a very, very tricky area, and I think we are lucky to have four law professors tonight to help us unravel it.

### Moderator
Claim: Let's bring them to the stage. Thanks, everybody. Bob Rosenkranz. So throughout the evening, as I mentioned, we're a podcast, and we exist as a radio broadcast.

As I said, I would love to have the audience that hears this to know that you're here, in part because you're going to be asking questions and you act as our judges also. So as I said, you feel free to applaud points and make your views known. But from time to time, I'm just going to ask you to spontaneously applaud to help with the atmospherics, and this is one of those times. I want to ask you-- so for generations, colleges and universities have known how to handle violations like student plagiarism. They hold a sort of court, a tribunal, and they hand out penalties if warranted, suspension or expulsion. But what if the violation is something like sexual assault on campus?

In that case, should it again be the school who is deciding who did what and handing out the punishment, which might be expulsion or suspension, or should the victims-- is it preferable for the victims, advisable for the victims to be going to the police and reporting a crime and seeking prosecution of their assailants, possibly for rape, especially, however, knowing that, that route so often results in justice denied? Well, because of what's happening right now on college campuses across the United States, this is a topical and lively debate. So let's have it right here, "Yes," or, "No," to this statement, "Courts, Not Campuses, Should Decide Sexual Assault Cases," a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufman Music Center in New York City. We have four superbly qualified debaters on our stage who will argue for and against this motion, which once again is, "Courts, Not Campuses, Should Decide Sexual Assault Cases."As always, our debate goes in three rounds, and then our live audience here in New York votes to choose the winner. And only one side wins. Let's meet our debaters. Again, the motion, "Courts, Not Campuses, Should Be Deciding Sexual Assault Cases." Please welcoming-- please welcome to the team arguing for the motion, Jed Rubenfeld. And, Jed, you are a professor at Yale Law School. You publish and write on constitutional and criminal law. You had a piece in the New York Times op-ed page that said that this should be a courtroom issue. At that time, you were rebutted in a statement by-- signed by 80 Yale Law students. Does that honestly represent to you-- do you feel, the majority of you among students on this issue?

### Conspiracy Advocate (CA)
Claim: Well, I actually don't think so. No. But look, this is an issue that everybody feels very strongly and personally about.

I'm the father of two girls on college campuses. I feel strongly about it too. That's why it's so important to have debates like this one.

### Moderator
Claim: And we will. And tell us who your partner is, please.

### Conspiracy Advocate (CA)
Claim: My partner is professor of law at Harvard University, Jeannie Suk.

### Moderator
Claim: Ladies and gentlemen, Jeannie Suk. So, Jeannie, as Jed said-- Jed says you're a professor at Harvard Law, which is also having-- you know, wrestling with this issue right now. Harvard has its division on the issue. And you are among 28 Harvard Law professors who issued a statement opposing the university's new policy and procedures on sexual violence. Now, without getting into your argument yet, just share with us why this is an issue, do you think, on which smart people can disagree so passionately?

### Conspiracy Advocate (CA)
Claim: They feel very personally about it. It's also very political for them. And it's also about the institutions that they inhabit, so that's a recipe for very strong feelings and very strong disagreements.

### Moderator
Claim: Some of which I think will come out tonight. Ladies and gentlemen, Jeannie Suk, and the team arguing for the motion. And that motion, again, is Courts, Not Campuses, Should Decide Sexual Assault Cases. We have two debaters arguing against it. Please welcome first Michelle Anderson. Michelle Anderson, you are Dean at CUNY School of Law and a leading scholar on rape law. Right now you are working with the Department of Defense, trying, actually, to help the Department of Defense define rape-- which, it might be a surprise to some people to know that rape needs a definition. But does that reveal how complex this issue is?

### Scientific Advocate (SA)
Claim: I think it does. Over the past decade, the uniform code of military justice has had three versions of a definition of rape and sexual assault. So, this is a very complex issue.

### Moderator
Claim: And your partner is?

### Scientific Advocate (SA)
Claim: The brilliant Stephen Schulhofer.

### Moderator
Claim: Ladies and gentlemen, Stephen Schulhofer. Stephen, you're a professor at the New York University School of Law. You're the author of "Unwanted Sex," considered one of the most important books on rape law in the last 20 years. We're going to be hearing this term "Title IX" a lot tonight. It's important to the debate. So, do us the favor, taking us-- to two sentences to explain why Title IX is relevant to this debate.

### Scientific Advocate (SA)
Claim: Sure, Title IX is the federal law that requires colleges and universities that receive federal funds to prevent racial and sexual harassment of their students. And that's why colleges have an obligation to address racial and sexual violence against students on their campuses.

### Moderator
Claim: So, Title IX is-- and I just want to ask you to face towards the mic just for the radio broadcast--

### Scientific Advocate (SA)
Claim: Sorry.

### Moderator
Claim: --you're a little bit off. No problem. So, Title IX is the reason, really, that this issue has become a campus issue.

### Scientific Advocate (SA)
Claim: It's a part of it. Yes.

### Moderator
Claim: A big part of it. Well, ladies and gentlemen, the team arguing against the motion, which is Courts, Not Campuses, Should Decide Sexual Assault Cases. And I remind you, this is a debate. There will be a winner and a loser as these teams try to argue in such a way that they persuade you to vote for their side. By the time the debate has ended, you will have been asked to vote twice-- once before the debate and once again after the debate. And the team whose numbers have moved the most between the two results in percentage point terms will be declared our winner. It's the difference between the two votes. Let's register the first vote. If you can go to those keypads at your seat-- just pay attention to numbers 1, 2, and 3. And here's how it works. If you agree with the motion as you see it on the screen, push number 1. That means you're with this team. Push number 1. If you disagree, push number 2. And if you're undecided, which is a perfectly reasonable position to be in, push number 3. You hold down the key for a few seconds until you see the number register on the top. If you made an incorrect vote, just correct yourself. You'll see the number will correct, and we'll lock it out in a few seconds.

I may-- we're on new technology tonight, so I may need to note that we're good. We're locked out? Okay. Good. Let's move on. So, I said we'd go in three rounds. And we're going to start with Round 1. Starting Round 1-- our motion is this: Courts, Not Campuses, Should Decide Sexual Assault Cases. In Round 1, the debaters have uninterrupted addresses from the lectern. They will be seven minutes each. And first to go up to the lectern, I'd like to welcome Jed Rubenfeld. He is the Robert R. Slaughter Professor of Law at Yale Law School. He is arguing for the motion, Courts, Not Campuses, Should Decide Sexual Assault Cases. Ladies and gentlemen, Jed Rubenfeld.

### Conspiracy Advocate (CA)
Claim: Thank you. And welcome to the second most important debate happening in America tonight. It's a-- it's a deep honor to be here, and I want to thank the organizers and also you, the audience, for coming. So, yes, one of my daughters is a college sophomore.

The other just started law school. I'm very concerned about keeping our campuses safe from sexual assault. That's a goal that everyone on this stage shares. But the way to achieve that goal is not by having colleges conduct rape trials when they're incompetent to do it. I'm about to use some strong words. I wouldn't do it except that this is the reality, and we need to face it. As the result of campus sexual assault trials, actual rapists all over the country are going free to rape again, while innocent people-- it's impossible to know how many. But I'm talking about people who haven't committed any sexual assault at all-- are being found guilty and having their lives wrecked by an error ridden, unreliable process that's filled with conflicts of interest and violations of due process, all of it covered by a thick layer of non-transparency. Now, my partner, Jeannie, is going to cover the serious due process violations, so I'm going to talk to you about the basic competency and neutrality and transparency issues. But there's something extremely important to both Jeannie and me.

I want to say it first, that this is not, for us, a debate between the rights of the accused versus the rights of the victim. An incompetent process produces errors on both sides. It's unfair to both victims and the accused. The errors run in both directions, and I will give you examples of those in a moment. But first, just some quick background on how we got to where we are today. In 2011, the federal government sent a letter to every college and university in the country telling them that if they didn't start trying rape cases they would lose hundreds of millions of dollars in defunding penalties, and forcing us to comply with a set of procedures dictated by the government, including, for example, lowering the standard of proof. Now, I'm sure this letter was well intentioned. But the problem is that college trials totally lack the necessary expertise, neutrality and transparency. Let me start with competence. The primary forensic tool in a rape case-- you've probably heard of it-- it's a rape kit. It's basically a medical forensic examination of the victim.

Now, most college personnel don't even know what a rape kit is. Or say a woman believes she was the victim of a date rape drug. Say she was the victim. That kind of case requires a laboratory toxicology result. That's how you make that case. Most colleges do not run such laboratories and can't do that. A recent college rape case was decided by a panel of three judges, one person from engineering, one from food services, and one foreign exchange student. In another case, an accused male student was essentially acquitted not because he was found innocent, but because he broke down at the hearing and admitted his alcoholism problem. The woman accuser was stunned to see her rapist sitting in class with her the next week. At Stanford, the teaching manual for rape judges includes an article saying that if the accused act-- if the accused acts as if he's the victim, that's an indicator of guilt. Another indicator of guilt is if he, quote, "Acts logical and persuasive." This kind of-- I'm not kidding.

This kind of incompetent decision making is leading to miscarriages of justice of a kind you wouldn't imagine in America. And how about impartiality? In our courts, we have a process we've worked out for centuries to ensure that our judges and juries are disinterested, that they don't know the parties, don't know anybody who does know the parties, that they're not subject to rumors and pressures. In college rape trials, it's the opposite. These are people from the same community. They are subject to pressures. They sometimes know the parties. They sometimes know people who do know the parties. Athlete-- athletic coaches decide if athletes committed rape. Students decide cases involving students. Now, again, these conflicts, they hurt victims and accused alike. In some cases, colleges have a huge incentive to sweep rape cases under the rug, to cover them up. And that can lead to guilty people being found innocent. In other cases, it's the opposite. Especially today, colleges are feeling a lot of pressure under threat from the federal government to show how seriously they take these cases and to make an example.

And that can lead to innocent people being found guilty, to be expelled, and if their names leak out, to be branded with a stigma that they have no way to ever clear themselves of. Compare this to what happens when a murder takes place on a college campus. We don't hold campus homicide trials. We all expect the police, the DA, the FBI and the courts to take charge. Rape is a crime as serious as homicide. It's not like plagiarism or cheating on an exam. That's the kind of thing college disciplinary panels are good at. We should treat rape with the same seriousness as we do other major crimes. But worst of all, I haven't even gotten to the worst thing of all. What happens when the college rape trial works just the way it's supposed to work; when an actual rapist is found guilty? What happens next? Let me ask you a question. If you had proof that somebody in your neighborhood had committed an act of rape, what was the-- what's the worst possible thing you could do? Here's the worst thing: Push that person out of your neighborhood, but never tell anybody else what happened.

Keep his name confidential. That literally is what colleges do in these cases. They expel the student but keep his identity a total secret because the college process, unlike a court, has no transparency. It's all covered with confidentiality. And I can't stress how important this is. Some empirical studies out there have suggested that up to 90 percent of college rapes are being committed by fewer than 5 percent of college men, a relative handful of serial rapists, averaging over six rapes each. Yet colleges, when they catch these serial rapists, simply push them out of their neighborhood, leaving them free to commit sexual assault elsewhere, their secret kept safe within the college bureaucracy. That's why we need courts to handle these cases. Now finally, it's critical to acknowledge that the courts are far from perfect, the police are far from perfect. Too often in the past they have failed victims of sexual assault.

We can do better. We have to do better. And in the end, it's not courts or colleges, one or the other. That's a kind of debating artificiality. We all know that both have a role to play. There's a huge amount colleges can do, but they should be focused on education and prevention, which they can do well, not on adjudication which they can't. Ideally, we bridge the gap. Get colleges and police working together. That's what I've advocated, and it's happening. Here in New York, there's just been the creation of a special sexual assault enforcement unit, first of its kind in the country. It's specifically designed to go out and work with both colleges and local police to help them get together and do their jobs better. But the primary responsibility for investigating and trying rape cases has to be with police and courts. That's what we're asking you to vote for. A vote for our side of this debate is a vote that not campuses, but courts should be the primary place where rape trials are conducted. And we urge you--

--to vote that way.

### Moderator
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: --to vote that way.

### Moderator
Claim: Thank you, Jed. I'm sorry, your time is up. I gave you-- gave you a little bit over, but--

Thank you. The motion is "courts not campuses should decide sexual assault cases." And our next debater will be speaking against this motion. Please welcome Michelle Anderson. She is dean at CUNY School of Law. Ladies and gentlemen, Michelle Anderson.

### Scientific Advocate (SA)
Claim: Courts should decide sexual assault cases when a victim reports to the police, when the police take it seriously and investigate, when a prosecutor takes it seriously and pursues it, and the case finally lands in a court of law. In these circumstances, courts should decide sexual assault cases. No one disagrees. The only thing this debate is about is between two commas, "Not campuses." The resolution strips jurisdiction from campuses to also decide sexual assault cases.

That's what we're talking about tonight. Now, colleges and universities exist to generate and transmit knowledge. And they cannot do that job unless they have a safe learning environment in which to do it. They also cannot single out sexual assault cases and push them to the criminal courts, unlike all the other cases they deal with, without harming the learning environment and without violating the civil rights of students. My colleague, Stephen Schulhofer will talk about the problems that happen when cases are pushed to the criminal law involuntarily. For now, I'll just note that there's a reason why 95 percent of sexual assault victims on campus never report to the police. They do not believe that justice will be served. A college student reported having been raped to the New York City police department. The officer scoffed. "You invited him into your dorm room. That's not the legal definition of rape." Another officer chimed in. "For every single rape I've had, I've had 20 reports that are total bullshit."That's not from 1970. That story is from 2014. The fact is that bias against victims of sexual assault has a well-documented, 200 year history in the criminal justice system. But even when the system harbors no bias whatsoever, campuses must be able to decide sexual assault cases. Courts and campuses have different interests in these cases and different remedies. Let me explain. When a campus sexual assault happens, a victim needs immediate safety and protection. Campuses can take protective measures to ensure a safe educational environment; stagger classes, move someone from a dorm, issue reprimands, suspend students. These remedies are not available in the court. The university's role is unavoidable because campuses must preserve students' ability to learn. Since the early part of the 19th century, colleges and universities have always disciplined students independent of the criminal law.

They've had to. Throughout time, students incite riots, they assault, they plagiarize, they harass. Some of these acts are criminal, some are not. But just to clarify, campuses are not prosecuting criminal charges in trials. They're pursuing violations of their own disciplinary codes, which do not lead to criminal convictions or imprisonment. And colleges cannot wait around to see if the police are interested in the case. Let me give you an example. In 2013 a college fraternity hazing ritual in Pennsylvania ended in the death of a pledge by blunt force trauma to the head. The coroner ruled the death a homicide, but the prosecutor did not pursue charges until Monday, almost two years later. Now, the university had an independent interest in the case. It pursued immediate disciplinary action against the students who hazed and killed the other student. And it suspended them.

Now, fraternity hazing and homicide are serious crimes, just like rape is a serious crime, but no one in that case said, "Oh, the courts should be the only one to handle the case. The colleges should get out of the way." Whether or not criminal charges ever emerge in a case, colleges must decide cases to maintain a safe learning environment, even more so with sexual assault. Title IX is a federal civil rights statute that prohibits gender discrimination in educational institutions. And campus sexual assault is a form of discrimination that denies a victim an equal education. Many sexual assault victims suffer serious consequences, depression, eating disorders, suicidal ideation, social withdrawal. These reactions impair their ability to attend class and focus, to pass their classes, to maintain their time in school, to remain in school. As a result, the United States Department of Education's Office for Civil Rights requires schools to take immediate and effective steps to end sexual violence.

It requires equal treatment of accuser and accused and demands adequate, reliable, and impartial investigation of complaints. Since 2011, campuses have begun pursuing these cases in earnest. Most colleges are working to implement Title IX in a fair and equitable way. You don't hear about them. Some campuses are failing, however. They're either denying victims their rights under Title IX to an equitable education or they're actually violating students' due process during the disciplinary proceedings in ways that Title IX does not require and the Constitution will not stand. In these later cases, students are suing, as you heard. Where colleges have gone wrong, these young men are winning. And these process issues can be worked out intelligently through the courts without taking a meat cleaver to the problem and abolishing or cutting off campus jurisdiction entirely.

Let's circle back to the differences between the criminal justice system and Title IX quickly. The criminal justice system is focused on punishment, incarceration, retribution. Title IX by contrast is a civil rights statute. And like most civil rights statutes, it's focused on equality, in this case, educational equality. The criminal justice system cannot insure equality, and it cannot remedy inequality. Campuses have to insure equality. They must provide a safe learning environment to generate and transmit knowledge. Now, I want to end by noting that this debate resolution is actually worse than the House Republican bill that is pending right now in Congress with the Orwellian title, "The Safe Campus Act." That bill would prohibit campuses from investigating sexual assault unless the victim reports to the police, and it's being heavily promoted by fraternities. The bill has received near universal opposition from groups that work with actual sexual assault victims as well as opposition from many groups that represent colleges and universities, like the Association of American Universities.

The American Council on Education has expressed grave reservation about any legislation that would limit our ability to insure a safe campus. The effect of this resolution is to eviscerate colleges' ability to insure a safe campus. It would also violate students' civil rights, and it has to be wrong. Please vote, "No." Thank you.

### Moderator
Claim: Thank you, Michelle Anderson. And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two against two, fighting it out over this motion, "Courts, Not Campuses, Should Decide Sexual Assault Cases." You've heard the first two opening statements, and now on to the third. Debating for this motion, we're welcoming Jeannie Suk, professor of law at Harvard Law School. Ladies and gentlemen, Jeannie Suk.

### Conspiracy Advocate (CA)
Claim: I think it's important for us to see that tonight's debate is not just about courts versus campuses.

And it's not just about sexual assault. It is a debate about the equality of men and women in our society. In college, I was a rape counselor and an activist, and I've spent my entire life as a feminist on campuses. I have a daughter and a son. And I was optimistic to see colleges take sexual assault more seriously than they had in the past. But the disaster we have seen unfolding around us has made me lose faith. My points tonight will focus on fairness, process, and the connection to equality. What campuses are doing under pressure from the Department of Education is hurting the cause of gender equality. Campus tribunals use procedures that lack basic fairness and often reach inaccurate outcomes. What happens? You're told there's a sexual misconduct complaint against you. But they don't say what it's about or show you the complaint.

They don't tell you the evidence or the facts that they're gathering, who the witnesses are, or what they've said. If you're allowed to bring an attorney, which you might not be, your lawyer is barred from speaking. If they give you a live hearing, which they may not, you can't question the accuser or witnesses. People who weren't even there are asked to give opinions on what happened. Terribly leading questions are asked. And when your attorney objects, she is told that if she speaks again, she'll be ejected. After you're found responsible and suspended, they don't give you a copy of the investigative report, saying that they can't because of student privacy. The investigation and the adjudication may be handled by the same person, and the appeal is to that person's boss. So, everyone is invested in defending the previous actions of the school. When you appeal, you're told you can't challenge the panel's factual findings.

And all this is happening because if you're not found guilty, the school fears that the Department of Education will open an investigation that would cost a lot of money to deal with and jeopardize its federal funding. In just the past three months, no fewer than five different courts have ruled for students on claims that their school used unfair procedures, including things that I've just described. The shocking disregard for what Americans know are essentials of fair process deeply harms the cause of taking sexual violence seriously. It reinforces society's skepticism toward rape victims. It causes everyone to doubt that men disciplined for sexual assault are actually guilty. That aggravates the serious problem that we all want to address. And it harms the fight for gender equality. To make matters worse, many schools are now stretching the concept of what sexual assault is far beyond reasonable recognition.

If you have sexual contact without an explicit agreement for every stage of a sexual interaction, that might be considered non-consensual. It's a great idea to make sure that each partner is excited about going forward, but move from kissing to touching without pausing for an explicit agreement-- and it can be sexual assault, even if the other person is equally participating in it. Some schools even define consent to mean not only affirmative, but enthusiastic-- even "creative" and "imaginative" agreement. It may be funny, but anything else is sexual assault. It's obvious that sex with a person incapacitated by alcohol is rape. That is obvious. But schools are now disciplining students when the sexual contact is under the influence of alcohol. All this means that most sexual encounters are violating the rules.

So, when one person is kicked out for this and branded a rapist, it feels arbitrary to both men and to women. It is truly bizarre to lump these cases together with rapes and treat them as sexual assaults. Yet, these are most of the cases that colleges are adjudicating today. This came about because of a desire to protect women from coercion. The idea was that men should seek permission, not just wait for women to object to sex. But schools are sending all the wrong messages about women's capacity to be equal, mature, and independent. We can date these ideas to about 1880. Women are timid; women are fragile. In the name of protecting college women and making campuses safe, schools are signaling loudly that they do not see women as capable. I don't want my daughter educated to think of herself that way. We need to refocus on what's wrong with sexual violence and refuse these ancient ideas of women's incapacity.

Watered-down procedures and overly broad definitions of non-consent make a mockery of a very serious problem and dishonor victims. Our opponents must convince you that a rape on campus is different from a rape anywhere else. It is not. Criminal sexual conduct anywhere deserves criminal response. And our opponents want you to accept that a civil rights option means that it's okay to have lesser procedures. Even if the stakes were civil, the process must be fair, and the stakes are effectively criminal. There is, in fact, so much that campuses should do. It's disturbing to see the bulk of resources going to pseudo investigations and trials. Schools should direct those resources to working with law enforcement. The safety measures that Michelle was talking about, those do not necessarily go hand in hand with an investigation and adjudication, a decision about the responsibility and guilt of a party for committing a crime.

You can take safety measures, and campuses do all the time, without having pseudo criminal trials. Schools can engage in rape education, they can address alcohol consumption, and they can work hard to support victims. The answer to shame or stigma about sexual assault is not a campus tribunal mired in secrecy and severe conflicts of interest that is the confidence of nobody. We're going to look back on this period as a mass panic when many people together lost their ability to think clearly about sexual assault and squandered opportunities for promoting gender equality. Campuses should not do shoddily what our courts have been designed over generations to do; decide questions of responsibility and guilt for a crime based on evidence.

You should not accept it. You should vote for the motion. Courts, not campuses should decide sexual assault cases.

### Moderator
Claim: Thank you, Jeannie Suk.

And that is the motion, "Courts, not campuses, should decide sexual assault cases." And here, making his statement against the motion, is Stephen Schulhofer. He is the Robert B. McKay professor of law at New York University School of Law. Ladies and gentlemen, Stephen Schulhofer.

### Scientific Advocate (SA)
Claim: Thank you very much. Courts are certainly finding due process violations all over the place. A lot of colleges have really botched this problem. But I'm very surprised to hear professor Suk cite that as a reason for precluding campus discipline in all these cases. We don't shut down the criminal courts just because appellate courts are finding due process violations in criminal trials. And that happens a lot. So, these decisions show that the system is working.

The Department of Education has overreached. Many colleges have overreached, and courts are pushing back. The question we have to decide-- and we all agree that many colleges have done a very poor job. The question that we're debating is whether to fix the problem by requiring the colleges to do better or whether to prevent all campuses from deciding these cases no matter how careful they are. The resolution would make a criminal complaint the victim's only option, even when she doesn't want to go through the stress of the criminal process herself and even when she doesn't want to impose that on a classmate who may have mistreated her, but she doesn't want to see that classmate convicted of a crime. Taking away the option of a campus remedy is obviously bad for sexual assault victims. I don't think there's any possible question about that. And what people are missing here is that sending all these cases to the criminal courts is going to work out very badly for the accused students as well.

Suppose a student claims that one of her classmates pushed her onto a sofa, ignored her protests and penetrated her? If a campus panel accepts her story, her classmate might be suspended or even expelled. That could have life-altering consequences. But expulsion is nothing compared to the impact of a criminal conviction for a sex offense. The resolution seems to assume that a criminal conviction requires very clear proof. The reality is actually not so reassuring. Trial lawyers know that proof beyond a reasonable doubt isn't all it's cracked up to be. Victim testimony no longer requires any corroboration or any proof of physical coercion. If the complainant testifies that she said no, and the jury believes her, that's enough. That is proof beyond a reasonable doubt. Of course, the jury has to be unanimous to convict. But it also has to be unanimous to acquit.

That's one reason why prosecutors typically file multiple charges, from rape down to sexual contact, attempted contact and maybe a few more. So some jurors may have doubts, others don't. And you typically see a compromised verdict. Jurors convict on a minor charge, not even realizing that their verdict can still trigger a harsh sentence. But it gets worse. Most criminal cases end in a plea bargain. And one reason is that a rape conviction can mean more than 15 years in prison. If the prosecutor will accept a plea to attempted rape or sexual contact, the sentence drops to only a year or two in jail. That's a hard offer to refuse, even if the chance of conviction on that top count is only 20 or 30 percent. So technically, you can't get a criminal conviction on a mere preponderance of the evidence. But if the odds of a 15-year sentence are 50/50, that becomes a pretty strong reason to plead guilty to the lesser offense.

And bingo, the student who might have faced discipline in a college proceeding, might have been required to change his dorm or even leave school for a semester. That student is now getting jail time and a criminal record without having any court hear any evidence at all. That's the reality for the great majority of cases in our criminal courts. What about less serious cases? Suppose a young man stares at a sophomore in his calculus class, and he keeps making comments about her body? One day, he grabs her butt in the hallway outside of class. That is sexual assault. But sending a contact case like that to the police normally means complete inaction. I hope that's not the resolution's hidden agenda, a world where a lesser sexual assault allegations aren't pursued. But anyone supporting the allegation for that reason is going to get a rude surprise if it were adopted, because if DAs didn't pursue these cases, which is what usually happens now, how can colleges respond to disruption and sexual harassment?

It's not clear to me what the supporters of this resolution have in mind. When you put thousands of adolescents together with raging hormones, poor judgment and easy access to alcohol, some of them are going to be rude and aggressive. You can talk about prevention programs, and I'm in favor of them too. But misconduct in that environment is going to happen. And how exactly is a college supposed to respond to stupid, boorish behavior, which is going to happen? Could the college suspend the student for his rude comments because that's not a crime, but not be allowed to suspend him for actually groping her? It doesn't make any sense. But otherwise, unless the DA pursues the case, there couldn't be any sanction at all.

And if the college can't discipline its students directly, it will have to pressure police and local prosecutors to press criminal charges. So students who would never face the criminal courts today, adolescents guilty of immaturity and poor judgment would find themselves with a criminal record. No one should want that. But colleges will have to insist on prosecution because they'd have no other basis for imposing sanctions. I think professor Suk said, well, of course, the college can take some action. But does that mean the college is going to be taking action without deciding what happened? That's a kind of odd situation if you're opposing-- if you're supporting the resolution that colleges can't decide these cases, but they can take action without deciding the case, that's even worse than the situation we have now. And I haven't even mentioned sex offender registration. Federal statute called SORNA establishes a national registry with a current address, place of employment and photograph of every convicted sex offender.

And it's readily available on the internet, and it's a federal felony for a sex offender to fail to notify local police within three days of every change in residence. People assume these laws only apply to predators who abuse little children, but they cover all sex offenses, even low-level misdemeanors. So this resolution would be a disaster, not only for colleges, but for accused students. They would get less due process in the criminal courts, and we'd see more convictions with consequences far more severe than a college disciplinary record. So that's why it's very important to vote against this resolution. Thank you.

### Moderator
Claim: Thank you, Stephen Schulhofer.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is "Courts, Not Campuses, Should Decide Sexual Assault Cases." Now we move on to round two. Round two is where the debaters address one another directly and take questions from me and from you, the members of our live audience here in New York City.

Our motion is this, "Courts, Not Campuses, Should Decide Sexual Assault Cases." The team arguing for the motion, Jed Rubenfeld and Jeannie Suk, have argued that campuses just are not up to the task, they are not competent, they are not transparent, they are not impartial, they tend to want to sweep these issues under the rug, that they water down procedures, and that sexual assault is essentially losing its meanings as under college juridical processes the definition of sexual assault moves further and further away from the conventional sense of rape. The team arguing against the motion, Michelle Anderson and Stephen Schulhofer, have told us that, first of all, the courts have been terrible historically in adjudicating cases of rape, regardless of whether the victim is a college student or not, that women do not believe that they will get justice by going towards that system, also, however, that colleges have responsibility for the safety of their students, and that legally under Title IX they have a responsibility to guarantee equality of education for their students, and that sexual assault is a form of discrimination.

It, therefore, is illegal, therefore, is the college's business. I want to go to the team arguing against the motion. And I found one part of the arguments that you made-- I found there was something missing that I expected your argument to include, which was tell us if in any way a college adjudication process actually has advantages for the victim over the court system. Is-- in what way is it more victim focused or more victim friendly, if you will? What's the advantage? What are the advantages for the victim if it's a college tribunal situation? Either of you can take it. Michelle Anderson.

### Scientific Advocate (SA)
Claim: Well, the college system has the advantage that it's not the police, and the public record of the--

### Moderator
Claim: Well, I got that because you--

### Scientific Advocate (SA)
Claim: --yeah, yeah.

### Moderator
Claim: --you made it clear that--

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: --you-- it's-- the alternative is terrible. Is that the only advantage?

### Scientific Advocate (SA)
Claim: Well, it's an important advantage. And campus systems vary quite a bit across the country. So some campuses will provide-- the main advantage for victims for the campus process is immediate process or fairly rapid, prompt process, and also a variety of remedies that are otherwise not available in court. So I emphasize that they can immediately change class schedules or move someone out of a dorm, essentially separating people who-- where there's an allegation of sexual assault, and they can do the kind of remedies that campuses can't engage-- or that courts can't engage in.

### Moderator
Claim: Okay, so those sound like real things. Jeannie Suk?

### Conspiracy Advocate (CA)
Claim: Yes, those are real things in terms of moving class schedules and dorm arrangements. Actually, colleges are doing that even before the adjudication investigations are completed.

That shows you that colleges feel empowered to just do that for the sake of student safety or just to preserve good relations in the dorm or for the-- just in the best interests of the students who are involved. They have all kinds of reasons to do things, like, say, you can't go to this dorm, you have to move, and I think that, that shows you it's not connected to whether the college is then going to have a-- an investigation, a trial, a tribunal, and go through that whole--

### Scientific Advocate (SA)
Claim: I have to say, Jeannie-- I'm sorry to jump in here--

### Moderator
Claim: Stephen Schulhofer.

### Scientific Advocate (SA)
Claim: --but I have to say I'm very confused about this. If I'm living in a dorm and I don't like my roommate, I can't go to the college and say, "I want this person kicked out of the dorm." You have to have a reason for that, and colleges can't be requiring a student to drop a chemistry class or move out of his dorm or leave campus for a semester unless they decide that there is a reason. So if--

### Scientific Advocate (SA)
Claim: And that, that reason is credible.

### Scientific Advocate (SA)
Claim: --exactly, that it's credible-- so they had-- if you're saying campuses should not decide these cases but they should take action against the accused without making any decision and without having any process at all, that seems rather an odd idea to me.

### Conspiracy Advocate (CA)
Claim: I think there are lots of different ways to make decisions. I think there are decisions made for all kinds of reasons. One-- the decision that we're talking about in this debate, decide sexual assault cases, is a determination of responsibility and guilt for what could be a crime. People do have disputes, like you're talking about, in their dorms. They do go to their resident advisor and say, "I'm having a problem," and sometimes they're brought in to have a mediation, to have a talk, to resolve, and they could-- colleges can advise and guide. And actually the Department of Education says, when it comes to the sexual misconduct matters, that's not even allowed. You have to go through some kind adjudicative process to decide the guilt of the party.

### Moderator
Claim: Let's let Michelle Anderson come in.

### Scientific Advocate (SA)
Claim: Sure. Well, I guess I'm just wondering, why is sexual assault different than any other offense that's committed on campus? In other words, these kinds of offenses routinely go through adjudicative processes. And there's no reason to pull sexual assault as opposed to any number of other kinds of cases, and say, "Well, that particular one has to go to the criminal courts, but the hazing case that led to the death of a student, or the plagiarism case, or an assault case, those can be adjudicated through a disciplinary process that is routine?"

### Moderator
Claim: Jed Rubenfeld.

### Conspiracy Advocate (CA)
Claim: Well, I don't think that's a fair characterization, Michelle. Look, it's really rare-- really rare to have colleges adjudicate a homicide. That almost never happens. It's really rare - - almost never happens for colleges to try and adjudicate an act of arson. Rape is as serious a crime as homicide and arson. We do not typically-- we have never typically adjudicated major serious crimes like that.

Plagiarism, yes, of course. Colleges are good at that. They know about that. Hazing? Hazing, fraternity stuff, that's a college problem. It makes sense for colleges to deal with hazing. But we are talking about treating rape very differently through this Title IX process, not treating it the same. Treating it the same would be an expectation that the police, and the courts, and the Das, and the FBI come in an investigate this. And I do-- I need to say one more thing about our resolution. It's very important. For some reason, the other side is trying to characterize the resolution before you as barring colleges from doing anything about this, barring them from hearing these kind of claims. That's not true. That's not what the resolution does. The resolution says, "Courts, not campuses, should decide." Not barring them. The question is for you all to send a message that the body that should decide these cases are courts, not campuses, for all the reasons we have said.

It's-- as John said at the beginning of this debate, the question before you, "Is it preferable for courts to be deciding?" And in an ideal world, if colleges could do it just as well, fine. But unfortunately, it's been a disaster. And the right answer is that courts should be the ones deciding.

### Moderator
Claim: Michelle Anderson to respond?

### Scientific Advocate (SA)
Claim: Yeah. I think that we read the resolution slightly differently. And I think that as a normative matter, the victim should decide whether or not she or he wishes to pursue a criminal claim with the police. And that is what should happen. And when the victim feels that she will be received or he will be received appropriately, and the justice can be served through the criminal justice system, that's the appropriate route for it to go. But there should also be an option for the victim to receive different kinds of redress through the campus justice system and through a process that provides different remedies and allows for immediate safety on campus.

### Scientific Advocate (SA)
Claim: If I might add, there also-- I-- Professor Rubenfeld really lost me there completely, because if all the-- all that you're arguing in favor of is that courts should do it, but you're not opposed to campuses doing it, I don't understand your opening remarks with all the criticism of the lack of due process, and the conflicts of interest, and everything else. We acknowledge that that happens. And we think it should be fixed. But I think the thrust of your arguments is that campuses have no business deciding these cases. And we think that they-- not only they do have a business. They must deal with the situation where, for example, a student in our chemistry lab keeps getting groped by someone at the next lab table. They have to deal with that. And it's not desirable to send that case to a criminal court, where some immature adolescent is going to wind up on a sex offender registry--

### Conspiracy Advocate (CA)
Claim: Well, Stephen, if I might, you know, I was really-- no, the resolution is that courts should be doing it, because they're the ones that have the competence--

### Scientific Advocate (SA)
Claim: I think-- but if I could respond to the--

### Moderator
Claim: Well--

### Moderator
Claim: --groping point--

### Moderator
Claim: --no. Let me--

### Moderator
Claim: Just on the groping point.

### Moderator
Claim: Not yet. Not yet. I want to say this, moderator-wise. It's going to become a sterile debate if we sit here arguing about what exactly the motion says. I think I can get all of us to agree that, more or less, we're understanding the sense that, yes, they believe that sometimes people should have the right to go to the police. You are not saying, "No, campuses should have no involvement." I think we're talking about-- I think, as Michelle put it, that students should have the option of a functioning sort of tribunal process system in the campus situation, that it should be there, active, and running if a victim doesn't want to go to the police. And your argument is, "Well, you can try that. But the record shows that those systems are full of problems." So, I think that that's where we're debating. And we can move forward, forward on that rather than be parsing the motion.

### Conspiracy Advocate (CA)
Claim: If I could add about the groping problem.

### Moderator
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: This is the problem of mixing together-- look, by sexual assault, this term, I understand to mean rape, okay?

What I have said throughout all my arguments, and this is what Jeannie was saying, too, is those are the cases the courts should be trying, not campuses. Now, what's happening is that this term is getting expanded, as Jeannie was saying to mean-- cover a whole lot of other things. And Stephen's argument about this groping thing is, you wouldn't want that in a criminal court. Police aren't going to prosecute. If courts-- if campuses want to have a code against offensive touching, sexual misconduct, sexual harassment, sure, those are things that campuses could do well. And they should be able to do that. We are talking about sexual assault here. Let's not expand that term so that it means all kinds of things-- other things and confuse the issue.

### Moderator
Claim: Well, that's a good point I want to take to your opponents because Jeannie Suk made the case that the definition of sexual assault is being trivialized almost to the point of meaningless by making it so broad.

And part of their argument is that there's a mushing together in all of this process and that that's the culture of this conversation. And it's-- it's an interesting an intriguing point. I want to see if either of you would like to take it on.

### Scientific Advocate (SA)
Claim: Well, sure. I think, first, I don't want to quibble about terminology or cite a statute. But any criminal lawyer will tell you that if a young woman on the subway is groped in the butt or in the breasts, any unwanted touching like that is a sexual assault. There is no question about that.

### Moderator
Claim: And it's a crime.

### Scientific Advocate (SA)
Claim: That is a crime.

### Moderator
Claim: She could go to the cops.

### Scientific Advocate (SA)
Claim: She could go to the cops.

### Moderator
Claim: So why not go to-- why do you think that the campus is better at adjudicate-- why do you think the campus should be set up with the option of adjudicating that rather than having that victim go to the police?

### Scientific Advocate (SA)
Claim: That is a terrific question, John. It's a terrific question, and it's crucial to all of this, because on campus, you're talking about the victim's ability to pursue her education in a safe environment. And if the person who's-- on the subway, you can get off the subway and hopefully in a city of 8 million people, you won't see the person again.

### Moderator
Claim: All right, but your opponent--

### Scientific Advocate (SA)
Claim: But when he's in your chemistry class--

### Moderator
Claim: Right. But your opponents are saying that campuses are just not equipped to actually adjudicate what, in that setting, would be a crime. That they-- that the-- they don't have the professionalism to hear a case, they don't have the legal safeguards, they don't have the due process, they don't have transparency. They have conflicts of interest. That having a sort of campus type of tribunal for that crime is a mess.

### Scientific Advocate (SA)
Claim: Yes. I think you summarized their argument accurately, and I think it's a straw man, complete--

### Moderator
Claim: Why? Why?

### Scientific Advocate (SA)
Claim: --straw man. Because conflicts of interest are intolerable. They should never be permitted. And the courts are striking them down. Professor Suk mentioned a whole series of cases which are striking these things down, as they should. They're fixing it. But we shouldn't, because of a few colleges, or many colleges mishandling these cases, we shouldn't say that no colleges should ever do it.

### Moderator
Claim: So they're saying it's-- it's the exception or, at a minimum, the problems that are there, okay, they're real, but they're addressable. Jeannie Suk.

### Conspiracy Advocate (CA)
Claim: It is not in any way the exception. The-- if you talk to people who are involved in this field-- and I myself have participated in and witnessed some of these things that I was talking about-- it is not in any way the exception. And it is-- and it's good. I agree with Stephen that the courts have noticed and said, this is not okay. The conflicts of interest, though, that we're talking about are not just one-off conflicts of interest. We're talking about structural conflict of interest, where we're talking about a Title IX officer who is charged with compliance with the Department of Education's dictates. And they are terrified about what's going to happen if they don't find a certain way, they don't do things a certain way. And how can that really lead to a neutral decision about the guilt or innocence of the party before them when they're thinking, oh, my God, am I going to have-- my school have funding taken away?

Or even if they're not ultimately going to have funding taken away, if, say--

### Scientific Advocate (SA)
Claim: Can I-- can I just--

### Conspiracy Advocate (CA)
Claim: --if their is an investigation against the school, then that's going to cost a hundred-- several hundred thousand dollars to even just deal with, even if at the end of the day. So when you're thinking like that, how can you be neutral about the guilt or innocence or about the facts of what happened?

### Scientific Advocate (SA)
Claim: Can I just ask whether Jeannie and--

### Moderator
Claim: We haven't heard from Michelle in a bit. Michelle, please. Michelle Anderson.

### Scientific Advocate (SA)
Claim: So the question of the incentive structure that-- that campuses face right now I think is an important one. Historically, before the Department of Education strongly encouraged mandated that courts get-- that campuses get involved in these cases, the incentives for campuses were to sweep these cases under the rug. Let's not-- we don't want the bad publicity. Let's put it under the rug. Today, however, the incentive structure is very different. The Department of Education mandates that campuses get involved and equitably and promptly adjudicate these cases. On the-- so that's powerful incentive to pursue these cases.

However, on the other side, you've got all of these claims brought by accused students, indicate-- claiming that their due process rights were violated. That's powerful incentive the other way to provide due process. So you have two kinds of incentives on both sides. And that will lead to more equitable and fair outcomes. If there were no incentives to pursue these cases, campuses would not pursue them, and they would sweep them under the rug in the way that they have historically. If there were only pressure one way and no pushback by the accused students when their rights have been violated, you'd have a problem. But you have pressure on both sides. And campuses are responding, as they must, to these federal cases that are--

### Moderator
Claim: Let's--

### Scientific Advocate (SA)
Claim: --coming down.

### Moderator
Claim: Let's bring in Jed Rubenfeld.

### Conspiracy Advocate (CA)
Claim: Well, I think Michelle's exactly right. We've seen an era when colleges, the big incentive was to sweep them under the rugs-- under the rug now. The incentive has changed. That is not the way, as Jeannie is saying, to get conflicts of interest out of a process.

That's the way to inject conflict of interest into a process. You don't want to give colleges an incentive to find a certain way, either way. And today, now they have this incentive to make examples, to show how seriously they're taking these things. And you can't say, well, now they've got pressures on both sides and it'll come out fine. No. Two conflicts of interest don't equal impartiality.

### Scientific Advocate (SA)
Claim: So what's the alternative, Jed?

So-- so the alternative-- so the alternative is the era before, where campuses swept these cases under the rug. What's the alternative? Sending these cases, pulling these cases out alone and saying, if it were sexual assault, you want a difference between sexual assault and rape. If it were rape, that needs to go to the criminal court. But if it were sexual misconduct or groping or sexual assault, then campuses can adjudicate that. How does that make even sense?

### Moderator
Claim: Jed Rubenfeld.

### Conspiracy Advocate (CA)
Claim: The alternative is just to do with rape what we do with murder and arson. The alternative is you call the police, you expect them to do a professional, proper investigation, and you encourage students to report to the police.

We heard earlier tonight that only about 5 percent of college women students who are victims are reporting. That's a huge problem. The alternative is to work better between colleges and the police to encourage reporting, to get these cases into the criminal justice system where rapists can get the punishment that they should get, and we can make our campuses and communities safer.

### Scientific Advocate (SA)
Claim: John--

### Moderator
Claim: Stephen, hang on one second. I will get-- come to you soon. I just want to say, after Stephen's comment, I'd like to go to audience questions. And I'll remind you the way it will work. Raise your hand. I'll call on you. You need to wait for the microphone to be brought to you. Hold the mic about this far away from your mouth so that the podcast can hear you and the live stream. And tell us your name, ask your question. Please make it a question. I would ask you not to debate with the debaters. Make it a question, really terse. And if a question mark comes naturally at the end of whatever you say, that is a question.

### Scientific Advocate (SA)
Claim: Yes, thanks.

I just was hoping to get some clarification about whether Professor Rubenfeld and Professor Suk are really in agreement, because as I heard Professor Rubenfeld, he was saying, well, what sexual assault means for purposes of this resolution is not what it means in the criminal law. What it means is rape. And rape should go to the criminal courts because that's a very serious crime. But if it's groping, some woman who can't do her lab work because the guy next to her is just some immature jerk, if that's all it is, then the campus can adjudicate that. As I understood Professor Suk, she was saying that the conflicts of interest are endemic and insoluble. And Professor Rubenfeld actually said that you can't solve one conflict-- offset one conflict with another. So to-- you know, I think got great responsiveness from the audience. But what are we saying about-- I mean, is it the case that campuses are just completely unable to fix the problems, and therefore they can't decide any of these cases, and that woman just has to tough it out?

### Moderator
Claim: All right. I-- stop right there, because I think it's a valid question. I want to hear the opponent's side. Maybe Jeannie Suk will take this. The groping-- the groping case, which maybe isn't going to be prosecuted by the police. What happens to that student? And if there is an adjudication process, should she use it?

### Conspiracy Advocate (CA)
Claim: So I have prosecuted that case here in Manhattan. There were people being groped every day in Times Square. And it is incorrect, as was suggested earlier--

### Moderator
Claim: Let's say a chemistry lab.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: It's a chemistry lab, not Times Square.

### Conspiracy Advocate (CA)
Claim: Yes, exactly. So that-- that's a crime just like it was in-- if it was in Times Square, it's a crime. And if it happens in a chemistry lab, it's also a crime. At that point, like any victim, this victim has the discretion whether to report to the police or not to the police. Many of us have been victims of crimes. Many of us have made a decision whether what-- whatever kind of crime it was, whether it was worth it to us to pursue the crime or not.

I think that would be the situation for that victim. And she-- in my opinion, if I were her advisor, I would say, "Go to the police because this is a crime, and a crime has been committed against you, the person will be arrested."

### Moderator
Claim: Well, I think your opponent's point is if she doesn't want to go to the police, should there be a tribunal set up at the-- on campus that she could go to?

### Conspiracy Advocate (CA)
Claim: Well, if we were living in a reasonable world with a reasonable department of education, what would actually happen, what could happen is the possibility that short of an-- a police-like investigation and a law-like court type of tribunal, you would have some reasonable parties get involved, talk to the people, and say, you know, "What's going on here? This is not acceptable. Bad, bad, bad person. Don't do that. Don't do it anymore." And, you know, as Stephen suggested, these are adolescents with raging hormones and exercising bad judgment. There are some cases like that. But what Jed was talking about was serious cases of rape and sexual assault.

Now, "sexual assault" is an ambiguous term because it includes rape and in some jurisdictions it includes other things. In other jurisdictions, sexual assault is separate from rape. So there's a little bit of an ambiguity about what we're talking about. But what we are talking about essentially is serious crimes involving sex such as rape.

### Moderator
Claim: I want to go to the audience, but I will give either of you 15 seconds to respond to that if you want to or we can move on.

### Scientific Advocate (SA)
Claim: Well, I think that we still need to know how to deal with this groping case, and we still need to know-- Professor Rubenfeld said, "Let's encourage women to take all this to the criminal courts." I do not want to do that. I do not want to see this immature adolescent put on a sex offender registry for the rest of his life.

### Moderator
Claim: Okay, let's go to some questions. Right there. Remember, again, the mic will come to you from down the right side. And if you could stand up and tell us your name and then ask your question.

### Moderator
Claim: Hi, I'm Alex.

So about the groping question, I'm just curious-- so we've all watched "Mad Men" I'm sure, and we know that in the 1950s and '60s women didn't have a lot of outlets within the organizations within they worked for groping, things like that, sexual assault, that in reality most women are not going to go to the criminal system. Most women have been sexually harassed, sexually assaulted in smaller ways like that. So I was just wondering, I think that from my perspective the workplace is a better comparison to school than the subway because the subway you can walk away, you're not going to see that person again, et cetera. So I was just wondering if there was anything that we could learn from what's happened from the "Mad Men" era to now with sexual harassment cases in the workplace that we could apply to this.

### Conspiracy Advocate (CA)
Claim: I think there's a ton to learn.

### Moderator
Claim: Jeannie Suk.

### Conspiracy Advocate (CA)
Claim: So in-- if this happened in the workplace, the federal law called Title VII would provide a way for that person to sue their employer for failing to prevent or to address a hostile work environment. Now, Title IX also is a law that one could use to sue one’s school for failing to address a hostile environment.

Now, there are many ways to address a hostile environment. Do they all involve an investigation and an adjudication and a kind of tribunal like that? No. There are many ways to do the work that an educational institution, consistent with this pedagogical mission, to educate its students, to nurture them, to promote a kind of culture where sexual harassment is not considered acceptable.

### Scientific Advocate (SA)
Claim: Well, I must say-- and I appreciate the response, that resonates with the audience-- but I must say that in the workplace we don't just say, "Well, the employer has to hold sensitivity training for his employees." If the-- if, in fact, there was groping, then the employee has to be-- the employee who did it has to be disciplined and know if an employer can't get away with his responsibility by just saying, "I'm going to ramp up my sensitivity training."And I think your question is excellent because it is exactly analogous, unlike the subway situation, the woman who's trying to pursue a career in the workplace cannot do that in a safe environment if she's subject to that kind of misbehavior. And there has to be a remedy. And there can't be a remedy without deciding what happened. We can't allow a woman or a man to say, "This person's sexually harassing me, so get rid of him." We can't just-- and this is where I part company with our opponents. I totally am unable to understand how they can say that schools can take action and impose remedies without deciding whether the allegations ever happened or not.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, arguing it out over this motion: Courts, Not Campuses, Should Decide Sexual Assault Cases. Another question. Sir?

### Moderator
Claim: Hi, my name is Charlie, and I'm actually the vice chair of a board of trustees at a local college. So, I've got a million questions. But I'll just stick to one.

### Moderator
Claim: Thank you.

### Moderator
Claim: The crux – maybe later. The crux of the issue seems to be the criminal law versus Title IX. That seems to be the crux of the issue, which clearly have different definitions of sexual assault and methods of adjudication-- basically, very specific versus purposely vague, if you will. This is toward the team that's voting-- or arguing against the motion. How do you justify and reconcile setting up basically two separate and distinct methodologies of determining and adjudicating the process, and then holding the colleges responsible for both?

### Scientific Advocate (SA)
Claim: I think it's crucial to remember that the objectives of these two different systems are different. First of all, the colleges are responsible, unless you want to say that-- repeal Title IX.

Colleges are responsible for protecting racial minorities and women from sexual and racial harassment. And that includes not only things that are crimes. You could have a student who's receiving hateful email with the "n" word. And the colleges have to find out who did that and take some measures. It's not a crime. But they do have a responsibility to preserve an equal educational opportunity for all their women and minorities on campus. So, that's the objective. And the system is remedial. It's not punitive. The colleges' responsibility is to decide, by a preponderance of the evidence-- which is the standard that we use throughout the legal system for anything other than incarceration. Decide whether the person did what's alleged and then take remedial action to protect the victim. Usually involves some sort of separation. That is not criminal punishment.

It's not incarceration. It's not a lifetime public record. It's not sex offender registration and so on. So, those things need to be taken to protect the woman's opportunity to get her-- to major in chemistry, to complete her class, and to get her degree. It's-- that's how we reconcile the fact. And it's the same reason why someone who sues for damages is heard in a different environment from somebody who's claiming to be the victim of a crime.

### Moderator
Claim: All right. I'm going to go to another question. Right there. If you can-- sir-- I'm sorry. The person behind you I'm sorry. I'm sorry. I hate doing that, but I have an ambiguous point.

### Moderator
Claim: Hi. Thanks for doing such a good job. My name is Rachel, and I was wondering, which adjudicatory process do you believe would have more-- have a more successful rate of deterrence against sexual assault?

### Moderator
Claim: Wow. What a great question. That's a great question. Let's go to this side first. Take it to Jed Rubenfeld.

### Conspiracy Advocate (CA)
Claim: Well, thanks for that great question. As you can guess, my answer is going to be the courts. Because it is very hard to deter people from serious crimes if you slap them on the wrist for doing it. And being told to write a paper or even a suspension, that's a slap on the wrist. Now, expulsion is a serious penalty. But if you keep that a secret, and it's non- transparent, that is not the way you deter sexual assault. I got to add one little point about a previous statement. The burden of proof that the government has forced us to use-- us colleges to use-- preponderance of the evidence-- look, at Yale, what's our standard of proof for a plagiarism case? It's clear and convincing evidence. That, legally - - for those of you who know, that's a standard up from preponderance of the evidence. That's what we do with all our cases. Now, with rape, we're forced to use a lower one. I got to say one more thing-- mediation. You have to understand-- this goes to the work- related question before. Title IX has forced us to not do-- we're barred from doing mediation.

What would grown-ups do with a groping allegation, grown-ups at a school? They bring the parties in, get them to agree. "You're not going to do this anymore. You agree. Right? If you break this agreement, you will be subject to penalties." They agree. That's called mediation. No. We can't do that anymore because Title IX--

### Moderator
Claim: Jed, I think--

### Moderator
Claim: --I'm going to stop you because I want to keep-- just give the other chance-- side a chance to focus on the question that was asked. And you had moved on a little bit. So, what about the question, Michelle Anderson?

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: Which system would actually result in more justice, I think, essentially, is what you meant.

### Scientific Advocate (SA)
Claim: Actually, that's a different question than the one raised--

### Moderator
Claim: Okay. So, if I moved it--

### Scientific Advocate (SA)
Claim: But that's an important--

### Moderator
Claim: --then let's go--

### Scientific Advocate (SA)
Claim: --one too.

### Moderator
Claim: Well, let's go with Rachel's question.

### Scientific Advocate (SA)
Claim: Rachel asked, "Which system leads to more deterrence?" And deterrence--

### Moderator
Claim: Oh, deterrence. Sorry.

### Scientific Advocate (SA)
Claim: Deterrence is one of the goals of the criminal justice system-- deterrence, incapacitation, retribution. We're all criminal law professors up here, so you could-- we could all talk about that. So the criminal justice system is designed to deter, generally. I think the goals of the campus adjudicatory system are very different.

And I don't think they have the goal of large, general deterrents. I think they have the goal of individual assessment of the facts and trying to match a remedy that fits whatever happened. And I also think that the criminal justice system wildly overplays its hand in its-- and it's far too incarcerative and punitive in general, which is what Stephen talked about in his remarks. I think your question about which leads to more justice--

### Moderator
Claim: Can I save that for a few minutes from now?

### Scientific Advocate (SA)
Claim: You can.

### Moderator
Claim: Thank you. Down here, please. I'm going to come back to it.

### Moderator
Claim: Thank you so much. What a great debate. My name is Dorchen Leidholdt. And I direct the legal center at Sanctuary for Families. We're a large provider of services to victims of domestic violence. And increasingly, we're representing campus sexual assault victims in campus proceedings. So I'd like to just bring that experience to the table and ask a question. And I want to tell you what we're seeing in the campus cases we're handling.

### Moderator
Claim: I-- I need you to just ask--

### Moderator
Claim: I'll sum it up super quickly.

### Moderator
Claim: I--

### Moderator
Claim: First of all, we're--

### Moderator
Claim: I really-- I need you to get to the question.

### Moderator
Claim: I'm getting to the question right now.

### Moderator
Claim: I need right now.

### Moderator
Claim: Yeah. So the--

### Moderator
Claim: Colon question. Thank you.

### Moderator
Claim: We're seeing sexual assault, real rape, but we're also seeing time lags before the report. No rape kits. We're seeing alcohol use, and we're seeing the victim not wanting to see the perpetrator jailed, and that makes it very, very problematic for a criminal proceeding that requires all of--

### Moderator
Claim: Ma'am, I need you to ask the question.

### Moderator
Claim: So my question is, if student victims in these situations don't have the option of campus tribunals, how will they get protection? How will they get safety?

### Conspiracy Advocate (CA)
Claim: I think that they can get safety through-- if we didn't have these tribunals, they would have safety through the school's reasonable measures that they could take, that they take all the time.

They take them even without going through the tribunals. They just impose them, depending on their individualized assessment of what the safety of the campus requires. That does not mean what we need is a system, a shadow justice system that is operating in schools. And so there are many options for schools to undertake to provide for victim support. And they could be even doing a better job if they weren't so focused on this quasi punitive system.

### Moderator
Claim: Stephen.

### Scientific Advocate (SA)
Claim: Yes, I think that question really goes to the heart of one major difficulty with the proponent's position. Many, many victims do not want to force the case into the criminal process. It's not that they-- they think a slap on the wrist is better. But, you know, they have a classmate who's immature, who's just kind of boorish. They don't want to ruin that person's life, but they want protection.

And the criminal justice system is a sledgehammer. Let's not kid ourselves. This is no joke. We're not talking about going from a slap on the wrist to, I don't know, a pinch on the cheek or something like that. We're talking about going from a slap on the wrist to a sledgehammer. We're talking about ruining-- literally, not just expulsion, but sex offender registration the rest of the person's life. And many victims, not only do they not want to put themselves through that process, which is one reason why they wouldn't report, but they also don't want to put their classmate through that process, so they won't report. And it comes back to the question that the other person asked a few minutes ago. How will you get the best prevention. If you have a system with tremendous disincentives for a victim to report, then nothing will be done. And that doesn't serve anybody's interests.

### Moderator
Claim: Up front here?

Front row on this side.

Thanks very much. Thank you.

### Moderator
Claim: Michael Kalupjon If the education department is in fact pressuring schools to achieve certain results in these cases, obviously the school can't be an impartial adjudicator. Do we have specific examples of pressure being brought to bear on the schools in these sexual assault cases?

### Moderator
Claim: Jed Rubenfeld.

### Conspiracy Advocate (CA)
Claim: Sure, we do. I mean, 50 schools are under investigation. They've been charged by the federal government with not enforcing and finding sexual assaults to be happening sufficiently. And the threat is hundreds of millions of dollars in defunding. So you have the threat which applies to all of them. You have 50 schools under investigation. And I can tell you from personal experience that the administrators, the deans, the Title IX coordinators are very, very afraid of being found liable by the Department of Education, by the Office of Civil Rights. And if you talk to them, you will hear this fear expressed all the time.

### Moderator
Claim: We're going to sum up this round with what we are calling our two-minute volley round. This is a special exercise in which the debaters are asked to compress their comments to 30 seconds in the answer to one question. The question is going to start on this side, go to that side for 30 seconds, that side for 30 seconds, that side for 30 seconds. And at the end of the 30 seconds, you will hear that. And the question is to go back to the one that we left aside before, which is the issue of, which system ultimately will result-- or is resulting in the greatest amount of justice done, a system in which victims primarily would be-- or where will-- the question really should be, where will victims be most likely to find justice, by going through the court system or by going through, generally speaking, the tribunals that we're talking about coming up on campuses under Title IX. So everybody understands the distinction between the question? I want to go to this side first. Which of you would like to go first?

Stephen? Okay. Your 30 seconds starts now.

### Scientific Advocate (SA)
Claim: I'll start. I think there's absolutely no question that you get more justice and better results if victims have options and if society itself has a mix of remedies and a mix of ways to responding more moderately or more severely, depending on all the circumstances. And it doesn't serve anybody's interest to have an either/or situation where either nothing happens or a ton of bricks comes down on somebody's head.

### Moderator
Claim: Your time is up. Over to this side.

### Conspiracy Advocate (CA)
Claim: The courts have the competence, the impartiality, the neutrality to do this properly. That's where you get justice. Nobody's talking about barring the schools from doing anything. The question is-- I'd like you to send this message-- that courts should be the ones deciding these cases because that's where-- that's the institution we've built up for 200 years to do justice. And it's not happening in a conflict of interest ridden and error ridden process.

### Scientific Advocate (SA)
Claim: We've had 200 years of history where the courts and the police have not taken sexual assault seriously.

And the notion-- and the notion that closing off an option for victims and forcing them to go to a system that is beholden to different interests and disinterested in equality, disinterested in their civil rights and disinterested in their ability to maintain their schooling, it's not a recipe for justice. Today, if you have an acquaintance rape situation, and you don't have some physical evidence of harm you get nowhere--

### Moderator
Claim: Jeannie Suk.

### Scientific Advocate (SA)
Claim: --you get nowhere.

### Conspiracy Advocate (CA)
Claim: I think that it is clear that the idea that schools are more interested in justice for victims, that they're more interested in their well-being, that they're more interested in the correct outcomes, that is absurd. Schools are entrenched in conflicts of interest, in all kinds of problems, in different loyalties to different entities, to alumni, to their current students, different political forces.

And our court system, hey, it's really flawed. We know that. But that is what it's designed to do, to try to sort--

--these out.

### Moderator
Claim: And that concludes round 2 of this Intelligence Squared U.S. debate--

## Round 3

### Moderator
Claim: --where our motion is, "Courts, not campuses, should decide sexual assault cases." And now we move on to round 3. Round 3, closing statements from each debater in turn. They will be two minutes each. Our motion again, "Courts, not campuses, should decide sexual assault cases." And here to make his closing statement, Jed Rubenfeld. We sit for all of this. Jed Rubenfeld, professor at Yale Law School.

### Conspiracy Advocate (CA)
Claim: Thank you. Many of you probably remember the case I'm about to mention to you, the Duke Lacrosse case. That was when a woman accused three lacrosse players falsely, it turned out, of raping her at a house party. What was the university reaction to those false rape accusations? It was panic. The coach was immediately fired. Suspensions. Everyone called for the expulsion of the accused students. 88 Duke professors placed an ad calling that rape a disaster. All around the country there was a rush to judgment, a presumption of guilt. Television legal commentator, Nancy Grace, vilified those who even considered the possibility that a woman might lie about being a victim of gang rape. The local prosecutor, too, was taken in. It took the police and the courts and due process to prove that the rape accusation was a fabrication. How did we find out it was false? We found out because the toxicology and forensic evidence disproved the accuser's claims. We found out because there was transparency and professional evidence gathering and procedural fairness. Had the accuser reported only to school authorities, and had that case been tried on campus behind closed doors, it's a good bet that those lacrosse players would have been promptly expelled and had their lives ruined with no way to vindicate themselves.

But that case happened in 2007 before all this stuff got going, so that's not what happened. Students were lucky. Their case went to court. Now, I'm not saying that such cases happen every day. And I'm not saying our courts are perfect or our police are perfect. We've got to do better. We have to encourage these cases to go to court through the police to get justice. I would just ask you to bear that kind of case in mind tonight when you vote on the resolution that courts should be the place where rape cases are tried.

### Moderator
Claim: Thank you, Jed Rubenfeld. And that's the motion, "Courts, Not Campuses, Should Decide Sexual Assault Cases," and here to make his closing statement against the motion, Stephen Schulhofer, professor of New York University Law School.

### Scientific Advocate (SA)
Claim: The trouble with that Duke example is the claim that if they had been expelled, they would have had no way to vindicate themselves. We've just heard from Professor Rubenfeld's partner that there are cases all over the country that are overturning expulsions that are based on botched procedures.

So there are remedies, and there will be remedies, but one of the worst tendencies in American society today is to turn to the criminal justice system as the all purpose solution for every social problem. Almost everybody who works in that system, no matter which side they're on, agrees that we have to reduce the reach of the criminal law. We have to be diverting cases away from the criminal law. And that's especially true of sex offenses because even a misdemeanor contact offense means sanctions that are much, much too harsh and much too inflexible. So I remember vividly my children aren't in college anymore but I remember the feelings that I had as a parent when they were. Nobody wants to get a call from a daughter saying she's been sexually assaulted. Nobody wants to get a call from a son saying he's been accused of sexual assault. But, God forbid, if you did get a call like that from your daughter, wouldn't you want her to have options for redress on campus?

Would you really prefer her to say that her only option was either to go to the police or drop out of school? That's not even a close question. Limiting her to the criminal courts makes a terrible situation many times worse. And what if your son called to say he'd been unfairly accused? Any parent would dread getting that call, but if it happens, which call would be more horrible? Your son might say, "Mom, I've been accused of sexual assault, and I might even get expelled or suspended from school." That's a nightmare. But would you prefer to hear your son say, "Mom, the DA down here is prosecuting me for rape"? If that's what you would prefer, you should vote for this resolution, but any parent who knows the criminal justice system knows that they-- taking a campus tribunal and the risk of possible campus sanctions, they would take that in a heartbeat. So we desperately need to reign in the criminal justice system--

### Moderator
Claim: Okay, Stephen Schulhofer, I'm sorry, your time is up. Thank you very much. And the motion is, "Courts, Not Campuses, Should Decide Sexual Assault Cases." And here to summarize her position supporting this motion, Jeannie Suk, professor at Harvard Law School.

### Conspiracy Advocate (CA)
Claim: Let me close by sharing with you a worry that we haven't really talked about yet tonight. The trampling of fair process, which we see all over on campuses, should give us concern about the disproportionate impact on students of color. I have personally seen time and again allegations arising from the kinds of cases I was talking about, the ambivalence, the ambiguity, or misunderstanding about consent. They fall on minorities and poor students. And many others working on these cases have told me that this is a campus secret nobody wants to talk about. Think about a nontransparent campus process as opposed to a transparent public hearing, without procedural safeguard, behind closed doors where unconscious bias can flourish.

These are perfect conditions for biases and fears to reach inaccurate outcomes. One college administrator told me that what keeps him up at night is panic that his school could be one Department of Education investigation away from institutional death. That makes it impossible for him to consider what's fair and what's right. Campuses must respond to sexual assault. The vote tonight though asks you to say whether shadow campus rape tribunals to decide responsibility and guilt are a solution. Colleges have lost their way because of the impossible position-- and we covered that tonight-- the impossible position that the federal government has put schools in. I am sure officials from the Department of Education know about tonight's debate.

And school administrators are watching too. You have the chance to send a message about how you feel about these tribunals that have been generated under this kind of fear. Vote for the motion, not just because you care about fairness and process, but because you care about victims and about safety, and about effective responses to sexual assault.

### Moderator
Claim: Jeannie Suk, I'm sorry. Your time is up. Thank you very much. Our motion is Courts, Not Campuses, Should Decide Sexual Assault Cases. And here to make her closing statement against the motion, Michelle Anderson, Dean at CUNY School of Law.

### Scientific Advocate (SA)
Claim: Two quick responses. One, if you're concerned about racial justice and racial disparity, it flourishes in the criminal justice system. Do you really want to send these cases there? Two, if you're concerned about transparency, the plea bargaining system-- which, 60 to 90 percent, depending on which percentages you look at in the studies-- an overwhelming majority of cases end up plea bargained. And they are entirely non- transparent. Those processes are non-transparent.

I am the dean of a law school, so I spend a lot of time thinking about how to lead a complex institution and how to provide students with a save environment. Put yourself in the shoes of a campus administrator. A shaken student comes to you and explains that she's failing chemistry because a student gropes her breasts after weekly labs. She's deeply distraught and she tells us she doesn't want to go to the police. Now, under this resolution, you have to tell her, "I'm sorry. If he stole your lab homework or if he punched you in your-- in the face, I could investigate. I could switch him to a different lab section, or I could have him suspended, or send him to a different dorm, or have him expelled. But since he sexually assaulted you, our hands are tied. You have to report to the police. Good luck." No. You want to tell that student, "I'm sorry this happened to you. If you change your mind and decide you want to report to the police, we will support you every step of the way. But in any case, we will investigate. And if we have enough evidence, we will take remedial steps to protect you.

And we'll try everything in our power to get this resolved this semester." This debate is about equality. It's about what it means to have equal access to education when one student harms another. The only way to protect students' civil rights to an equal education is to allow the campus to act, to stop sexual assault, and protect students' safety. Vote no on this resolution. Thank you.

### Moderator
Claim: Thank you, Michelle Anderson. And that concludes our closing statements. And now it's time to learn which side of the audience feels has argued the best. We're going to ask you again to go to the keypads at your seat. And it works the same way. Take a look at the motion. "Courts, Not Campuses, Should Decide Sexual Assault Cases." If, after hearing the arguments, you support this side, push number 1, the for-side. Push number 2 for the against side. And push number 3 if you became or remain undecided on the issue.

And again, we will-- we'll lock out those votes. And we'll have the results in just about a minute. But in the meantime, I wanted to say this. We've done 110 debates now and we sort of see patterns. And one of our patterns tends to be that when we have law professors as our debaters, it turns out they're not just good at teaching law, but they really provide excellent debates, I think, because they respect one another. There's a common language. And they're just in the spirit of litigious interchange. They bring such game to it and such intelligence. And I think we all learn from all of them in the way that they conducted this today. So, I wanted to thank them all. Also, tonight, I hate rejecting questions and it was a pleasure to not have to reject a single question tonight.

They were all excellent, even the ones that traveled on for a little while. They were all excellent, and they moved the debate forward. So, thank you to everybody who got up and asked a question. I'd also like to take a moment and thank our generous supporters, some of whom are here tonight, who make the debates possible. The ticket prices-- I said this before-- don't come close to covering what it does-- what it costs to put on one of these debates. So, everybody who has helped us out by making a donation, we're extremely grateful for those. And for those who haven't, we will be extremely grateful when, shortly, you go online and – donate to our website. It's at IQ2US.org. And we'll take even small donations-- anything, because every-- all of it really counts for us and lets us keep doing this. And in that vein, I just want to tell you that the rest of the season gets moving. This is our inaugural debate of the season, obviously.

But we're back next month on October 14th, we'll be here. And the topic we're-- we're looking at U.S.-China relations. And among the debaters, we have the former prime minister of Australia, Kevin Rudd who actually is a China scholar. Our New York season is also going to be featuring debates on topics such as infrastructure and the federal gas tax, which is actually how the highway fund is funded. It hasn't been raised for over two decades. So we're asking, is it finally time to raise the federal gas tax. Now, if you've never heard of the federal gas tax, this is one of those debates where you'll learn a lot, and you'll find it actually a heck of a lot more interesting than you think it sounds when somebody says, "The federal gas tax." Because that's-- that's what happens in all of our debates. You end up learning stuff you never knew before, and light bulbs go off. And if you've gone through the Lincoln Tunnel, or crossed the George Washington Bridge, maybe you're thinking maybe it's time to raise the federal gas tax.

We're looking at central banks and their role. We've touched on this topic indirectly before, but we want to go at it more directly. And after what's come through the quantitative easing process of the last several years, it looks as though they are printing money around the world. In fact, they are printing money around the world. It's happening now. The question is that we want to debate is, is that a problem? Is that a good thing? There are very passionate arguments on both side, that it's an emergency or that it's a "Chicken Little" situation. So we'll be looking at that. Affirmative action, we've looked at that before as a-- strictly as a Constitutional issue. We did that debate up at Harvard. We are looking at it again because the Supreme Court is going to be taking another look at affirmative action, so we will be doing the same. We're going to be traveling in November. On the 2nd, we'll be debating the use of smart drugs at George Washington University, where the issue is whether it's a fair-- whether students who have access legally to pharmaceuticals that assist them in-- in, let's say, focus and concentration, whether that's playing fair or not, or whether that should be regulated.

On November 10th, we'll be in Chicago at Northwestern Law School, and we will be debating prosecutorial abuse. You're all invited to that one, to watch, I mean. And tickets-- tickets for all of our debates are available through our website, IQ2US.org. And I said earlier, we're live-streaming even now, so those who can't get to our debates live, there are a lot of other ways to catch them. There is the live stream at our website and on Fora.TV. You can download the IQ2US app on Apple and Android mobile devices. And just look for IQ2US in iTunes or in the Google Play store, and you'll find us. It's actually a very-- it's a very gorgeous app. And all of our debates there are both this podcast, and as video. Transcripts are there. You can also see, debate by debate, the research that we post; a lot of reading on the topics that we debate.

So it's like a little classroom in your phone. And we just want to, again, say, go to our website to get up-to-date information on everything that we do. It's updated frequently. And follow us on Twitter and on Facebook. So, with perfect timing, I run out of things to say just as the results come in. So I have the results now. Once again, the motion is this: "Courts, not campuses, should decide sexual assault cases. Again, it's the difference between the first and the second vote that determines who is our winner. Let's take a look at the first vote, on the motion that "Courts, not campuses, should decide sexual assault cases," before the debate, 56 percent of you agreed with this motion. 12 percent were against. 32 percent were undecided. That's the first vote. Let's look at the second vote. The team arguing for the motion, their second vote was 56 percent. They did not move up or down in their position. So zero percentage point move is the number to beat.

So it comes down--

Well, it's going to come down to what the undecided decided to do. Did they stay undecided or not? Let's look at the second vote. The team against the motion, their first vote was 56-- I'm sorry, their first vote was 12 percent. Their second vote was 31 percent. They pulled up 19 percentage points. The team against the motion is declared our winner. Our congratulations to them.

Thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
