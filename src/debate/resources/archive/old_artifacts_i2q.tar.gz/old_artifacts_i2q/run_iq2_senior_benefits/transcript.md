# Debate Transcript

Topic: Grandma's Benefits Imperil Junior's Future
Motion: Grandma's Benefits Imperil Junior's Future

Debate ID: senior-benefits


## Round 1

### Moderator
Claim: There would be no Intelligence Squared U.S. if not for the beneficence of our founder, the chairman of the Rosenkranz Foundation, Mr. Robert Rosenkranz.

### Moderator
Claim: Well, welcome to all of you. As the regulars in this series know, typically I use the first few minutes before each debate to outline the arguments on both sides. Tonight I'm going to do something a little different and share with you the reasons we thought that framing a debate on entitlements in intergenerational terms could shed some new light on a familiar topic. American politics has focused endlessly, if inconclusively on health care, on the uninsured, on jobs, on entitlements and on the deficit.

Fault lines have been drawn between liberals and conservatives, between rich and poor. But the intergenerational aspects of these issues have barely figured in the debate.

One shocking statistic is that 37 percent of those who came of age in this millennium are unemployed. When consumers lack the confidence to spend, when businessmen lack the confidence to invest and to higher, it is the young that suffer most. The health insurance debate focused on the uninsured. But think for a moment about how health insurance is priced. Almost everywhere the young pay the same premium as their more illness prone elders. A massive subsidy for the old paid for by the young. Tens of millions of young people quite reasonably said no thanks to health insurance until the government mandated that they say yes.

Medicare and Social Security, Granny's benefits are some 35 percent of the federal government-- federal government budget and are projected to increase to 40 percent in the next decade as the baby boomers retire. Health care costs are running around 16 percent of GNP compared to nine percent in other developed countries. And we have no better health outcomes to show for it. End of life care, the heroic measures taken in the final three months before a predictable end are around 25 percent of total health expenditures. We simply don't have the money to afford the health care system we've got.

When households want to consume something today that it can't pay for or doesn't choose to pay for, it can borrow money and pay it back with interest in the future, or it can borrow money and stiff its creditors through default, repaying debt with pennies on the dollar. It's no different for governments. If they won't cut spending, and they won't raise taxes, they can incur debt which the young will pay for with higher taxes later, or they can stiff their creditors through inflation, repaying the debt with devalued currency.

Young people are paying the costs of sluggish growth today, and they'll be paying the costs of profligate government tomorrow. And neither political party has anything constructive to say. The Democrats don't want to cut entitlements, and the Republicans don't want to raise taxes to pay for them. Perhaps that's why young people vote less than their elders.

Tonight they can make up for that lapse by voting twice, before the debate and after, after they've heard tonight's stellar panelists address the little noticed issues of America's intergenerational divide.

And with that, it's my privilege to turn the evening over to John Donvan and our outstanding group of panelists.

### Moderator
Claim: Thank you. And I'd just like to invite one more round of applause for Robert Rosenkranz, please. True or false, Grandma's benefits imperil Junior's future? That's what we're here to debate, another verbal joust for Intelligence Squared U.S. I'm John Donvan of ABC News. We're at the Skirball Center for the Performing Arts at New York University where our motion is this: "Grandma's benefits imperil junior's future." Two teams will argue that proposition from opposite sides, for it and against it.

Only one team wins, and you, our live audience, will be choosing the winner. They will be playing for your votes. So let's meet our panel. First, a life-long Republican who is encouraging her party to get back to basics, FOX News commentator, Margaret Hoover. Her debating partner is a real estate investor and media mogul, a chairman of U.S. News and World Report, Mort Zuckerman. Opposing them at the facing table, a doctor who went on to become chairman of the Democratic National Committee, the former governor of Vermont, Howard Dean. And joining him, an economic analyst and author of the book Age of Greed and editor of Challenge Magazine, Jeff Madrick. So this is a debate. It's a contest. There will be winners, and there will be losers. And you, our live audience here at the Skirball Center will be making the choice who wins and loses.

By the time the debate has ended, you will have been asked to vote twice, once before and once again after the debate. And the team that has changed the most minds in the course of the debate will be declared our winner. So let's go to the preliminary vote. You all have key pads at your seat. Our motion is this: "Grandma's benefits imperil Junior's future." If you agree with the motion, if you are with this team, push number one. If you disagree, you're with this team, push number two. And if you are undecided, push number three. And what will happen is the system will lock in the votes. If you feel that you made an error, just correct it, and the system will lock in your last vote. And remember again at the end of the debate, we're going to ask you to vote a second time. And the team that has changed the most minds, has moved their numbers the most in the course of the debate will be declared our winner.

So onto round one. Round one, opening statements by each debater in turn uninterrupted.

They will last seven minutes each. And first speaking for our motion, "Grandma's benefits imperil Junior's future," I'd like to welcome to the lectern, Mort Zuckerman. Mort Zuckerman is a man-- you can make your way to the lectern. And Mort, as you go there, I just want to explain to our audience, I'm sure they all know who you are, but you are a man who started in academia and then began to build things. You build buildings, and from those buildings, you built a fortune. And from that fortune, you became a media mogul. You are the owner of the U.S. Daily News. You are the editor in chief of U.S. News and World Report, on the Forbes list of wealthiest Americans. You do not own Forbes. But on that magazine list, you are number 188. And I'm just wondering if you did own it, would you get to tweak the numbers a little bit?

### Conspiracy Advocate (CA)
Claim: They were referring to my age, not my rank.

### Moderator
Claim: Ah. Ladies and gentlemen, arguing for the motion first, Mort Zuckerman.

### Conspiracy Advocate (CA)
Claim: Well, as you've just heard, America's in very difficult shape. And the difficult truth that we must face is that we are on the verge of an exploding public sector debt that can have a very, very negative effect on our economic future. As one cynic put it, our future isn't what it used to be. Social Security was born amid harsh times of the Great Depression, marked by unemployment, homelessness and even starvation. We then made a deal with the American workers, to wit, that nobody who paid into the system would be left empty handed. To this was added Medicare, health insurance in the mid 1960s and the protection against inflation in the 1970s. These initiatives changed the economics of old age. In a mere four decades, poverty rates among the elderly, which had been three or four times that of the general population, fell below the rates for younger Americans.

To this day, social security still means the difference between poverty and economic security for millions of retirees, children and many American workers. It is the primary source of income for two-thirds of older Americans and the single most important antipoverty program for children, millions of whom live in households supported by disability, survivor or retiree beneficiaries. It creates intergenerational benefits as parents and grandparents can live independently of their working children and often become the childcare providers for children while the parents work. When Social Security began making monthly distributions in 1940, there were 160 workers for every senior receiving benefits. Today, there are about three workers. And within two decades, there will be two. Demographic are destiny. The message could not be clearer. Social Security needs fixing.

It has been fixed before. Social Security taxes have been raised 40 times since the program began, most recently in 1983. The initial Social Security tax was two percent, split between the employer and the employee, capped at $3,000 of earnings, which made for a maximum tax of $60. Today the tax is approximately 13 percent, capped at $106,800 for a maximum of tax of $13,234, a multiple of 80 times the original tax. So what is to be done? Despite the natural sympathy for those looking forward to their retirement, we cannot avoid the issue of Social Security insolvency. Here are some options to deal with this problem, one, gradually raising the retirement age to reflect the longevity increases that have already taken place. In the future, retirement age should be indexed automatically to rise with longevity. Two, raising employer and employee payroll taxes by up to one percent each.

Three, eliminating or gradually raising the cap on taxable payroll income, reflecting the fact that higher incomes are rising faster than the Social Security taxable earnings. Four, increasing the earliest eligible age, EEA, as it's called, from 62 to 65, which alone would extend the trust fund solvency by about five years. Current retirees would be unaffected. And exceptions would be made for Americans who cannot work longer due to injury, ill health, or other causes. Modest reductions in benefits for wealthier recipients should also be considered. We must address these challenges soon or Grandma's welfare will in fact undermine the quality of life for her grandchildren and give meaning to the phrase which my partner and I have found out, we'll both, quote, "Blessed are the young for they shall inherit the national debt." I might add-- that was originally stated by my partner's grandfather. The greatest risk facing America's fiscal future comes from the projected increases in Medicaid and Medicare spending that could raise the deficits dramatically in the next couple of decades.

Arithmetic still matters. Medicaid now pays for both health and long term care for roughly 55 million Americans. It finances more than one third of all births in the United States, and pays the cost of almost two thirds of the people in nursing homes. The federal government underwrites 50 to 77 percent of the cost, depending on the income level of each state. Even so, Medicaid is the second biggest and fastest growing category of state spending. Costs are up more than 60 percent in the last five years and are expected to exceed $450 billion this year and to keep growing by about eight percent annually for the next decade. In the next-- by the mid-1930s-- 2030s, the 65 and over population will nearly double, and health care costs, which have been rising far faster than worker productivity since the end of World War II, may be completely out of control, resulting in a tidal wave of federal spending.

The basic fact is that the first baby boomer statistically retired on January 1 of this year, but there are 79 million more of them. Multiply that by estimated annual benefits of $40,000 that they will be receiving, and you're looking at $3 trillion a year just for that portion of the population. Erskine Bowles, the co-chair of the bipartisan Simpson- Bowles Commission, put it well, "This is a fiscal crisis that is completely predictable and from which there is no escape. This concern has been shared by many, many institutions, the Post, the Washington Post, the Fed chairman, Bernanke, and countless others. Now, the only way to cut entitlement costs is to cut entitlement costs. The current programs as they play out will be unsustainable without giant tax increases or huge cuts in other government programs. We should remember as we address this problem that less is enough if it comes earlier, so the sooner the better.

Now, this is a nation founded on opportunity, not entitlement, on thrift, not conspicuous consumption, on stewardship and not living for today, but taking steps to make sure that we are creating a better tomorrow, such that future generations would have as much or more opportunity and a better standard of living. To keep these entitlements under fiscal control is about keeping the American dream alive. I know the American dream because I'm one of the people who was attracted to this country many years ago from Canada where 50 percent of the graduating class of American universities moved to the United States, attracted as we were by the remarkable energy and optimism and mobility and upward mobility of this country, not to mention the president, John Kennedy. Today it is Canada's government that has shown best how to manage these kinds of problems as they work their way through perilous economic times without threatening its future.

But much as I like Canada, I don't want my children moving there because of the narrowing of opportunity at home.

### Moderator
Claim: Mort Zuckerman, I’m sorry. Your time is up. Thank you. Ladies and gentlemen, Mort Zuckerman. Our motion is "Grandma's benefits imperil Junior's future.” And here now to speak against the motion, Jeff Madrick. He is the editor of Challenge Magazine. He is a thinker and a writer who comes to the topic of economics from the left. His most recent great pithy statement to be attributed to him is “The last thing we need right now is a tax cut.” He wrote a book called “The Age of Greed,” which turns on its head the fictional Gordon Gecko’s notion that greed is good because greed is--

### Scientific Advocate (SA)
Claim: Greed is not good. Self-interest is okay.

### Moderator
Claim: All right, ladies and gentlemen, Jeff Madrick.

### Scientific Advocate (SA)
Claim: Now I have a lot to correct in what Mort said, not least of which is why he came to the U.S. Canada is very cold. I’m delighted to be here with Mort Zuckerman, Margaret Hoover, and, of course, doctor, governor, and chairman, Howard Dean. I’m especially delighted to be here to defend Social Security and Medicare. They are two of the greatest achievements of any kind made in America. Mort’s listed-- Please. Mort’s listed why Social Security is so important, how many elderly it keeps out of poverty. It accounts for 80 percent of 40 percent of those who are elderly. It can account for well more than half of half of those who are elderly’s income. Medicare-- think of what the elderly would be doing without Medicare. How could they possibly be paying $12,000 and $15,000 a year for health insurance? But you know some of this.

And you’re going to say, well, let’s cut them back a little bit for the sake of fiscal responsibility. I’m going to go into that in some detail. But let me remind you and let me make this very clear. Social Security and Medicare are not outrageously generous programs. The average Social Security payment is $14,000. Poverty for two-- a poverty line for two is $13,000. Medicare-- a typical employer-sponsored health plan will cover 88 percent of health needs. Medicare, according to independent actuarial studies, will cover 76 percent of Medicare. Big deductibles, big co-payments, not a gift. The elderly are not living wonderful lives because of Social Security and Medicare.

If they’re living wonderful lives, it’s because they made a fortune, coming from Canada to America. Let me get to the point. Let me cut to the chase, because I had a lot to precede this. Let’s be very clear about what Social Security adds to our future debt. In fact, let me step back a moment. Social Security and Medicare have nothing to do with the current levels of debt-- nothing to do with it. The current levels of debt are a function of the great recession brought on, in my view, mostly due to the excesses of Wall Street, the Bush tax cuts in the early 2000s and the spending on the Iraq and Afghanistan War. Medicare Part D contributed some but less than any one of those three factors. We don’t have debt because of Social Security and Medicare.

But what about the future? You would think, given what Mort says, that Social Security accounts for about half of what’s going to happen to us. What do you think the benefits of Social Security as a proportion of GDP are going to rise to, as a proportion of our total income? They’re now about five percent of our total income. They’re going to rise to a maximum of six percent of our total income, one percent of GDP. You think we can’t afford that? You think Social Security is going insolvent on the basis of that? And you know what? Even if we don’t raise taxes to cover Social Security, Social Security is not going insolvent. The Social Security Administration and the CBO make a forecast. It is a conservative forecast of economic growth. Even if we do nothing-- and if I leave one message with you, it should be this one-- if we do nothing, we will still have 78 percent of our benefits paid by the current system.

Medicare is a different story. But Medicare spending is not going up in the next 10 years significantly as a proportion of GDP. It's going up after that. And why we hear a lot of alarmist talk about the aging of the population, true, there will be more aging compared to workers. Workers will have a harder time paying for the aged. But that's not what's driving Medicare costs up. That's not what's going to drive it sky high. It's the health care system, an inefficient health care system. And I'm going to leave that to my partner, Dr. Dean to discuss, how inefficient it is. Summarizing quickly on those two issues, we can handle Social Security easily. It is not going insolvent. That is inflammatory, misleading and incorrect rhetoric.

Yes, I'm getting a little upset. I think I have cause. We still pay 78 percent of liabilities. Even if we do nothing, what can we do? We can raise the cap, as Mort suggested. We can raise the payroll taxes somewhat, 0.1 percent a year to 7.2 percent. And you know what? All the studies, all the surveys say people want to do that. Medicare, we have to reform health care. And I hope Mort, Margaret and Governor Dean put all their effort into reforming health care because is what can undo America, not these entitlement programs. One last major point. We are a low taxed nation. We are almost the lowest taxed nation in the OECD of all rich nations. Federal income tax comes to only 15 percent of GDP these days.

Used to come to 20 percent when George W. Bush took office. Can we raise taxes? You bet we can. Ah, somebody's going to say from the other side. But that will slow economic growth. I leave you with one fact in my last 39 seconds. George W. Bush cut taxes sharply in 2001 and 2003. He promised growth, and he promised jobs. And all those people who talk about the poor job creators whose taxes we have to cut, consider this: We have the slowest rate of GDP growth after the Bush tax cuts from trough to peak. I mean before the devastation of late 2007 and the great recession, the slowest rate of GDP growth, 2001 to 2007 in any comparable period in post-World War II history. And job growth was even worse, almost no jobs were created after the Bush tax cuts.

Thank you.

### Moderator
Claim: Jeff Madrick, your time is up.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: So we are halfway through the opening round of this intelligence scared U.S. debate. I'm John Donvan of ABC News. We have four debaters, two teams of two fighting it out over this motion: "Grandma's benefits imperil Junior's future." You've heard two of the statements, and now onto the third. I'd like to introduce Margaret Hoover, a FOX News political commentator. She is the author of a book called "American Individualism," which spells out her vision for a Republican party that gets back to its roots. The title, I understand, you lifted from an author in the past, who would be whom?

### Conspiracy Advocate (CA)
Claim: I punked it from Herbert Hoover.

### Moderator
Claim: And your relationship to Herbert Hoover?

### Conspiracy Advocate (CA)
Claim: He was my great grandfather, though I never knew him. He passed away 13 years before I was born.

### Moderator
Claim: But you're bringing us the past and the future tonight.

### Conspiracy Advocate (CA)
Claim: I found surprisingly Hoover channels the millennial ethos.

### Moderator
Claim: Ladies and gentlemen, Margaret Hoover.

### Conspiracy Advocate (CA)
Claim: Thank you, John, and thanks to Bob Rosenkranz for the opportunity to participate here tonight on a stage with such distinguished public figures. I am well aware that I am the junior on this stage. And as such, I will argue in favor of this motion from the perspective of Junior whose future is imperiled by Grandma's benefits. The juniors in this argument are the millennials. This is the rising generation in America, 30 and unders, born at beginning of the Reagan era to the end of the Clinton presidency. At 33 years of age, I am on the cusp of this rising generation and have been paying into Social Security and Medicare for eight years. I am told that as long as I pay into the system, this system will be there for me. By the time I reach my full retirement age of 67, 34 years from now in 2045, I'll expect to receive the same benefits equal to that which I paid into the system.

And if I have planned on this, I will find my future severely imperiled. Because eight years before I retire, the Social Security trust fund will have been depleted. I will be surprised to discover that this trust fund was actually a myth, that it was in fact just a surplus of IOUs that had been lent out to other agencies of government to pay for their expanding programs. Beginning in 2037, Social Security will have to rely solely on the revenues from payroll taxes, which will be insufficient to cover the benefits promised to me and my generation.

In addition, under current law, because of program insolvency, benefits will have to be cut by 23 percent or payroll taxes raised 30 percent.

This sudden adjustment imperils the millennials economic future, affecting the poorest of those who are already dependent upon benefits. The rude awakening is that Social Security, Medicare and Medicaid were set up as pay as you go-- they were never set up as trust funds. They are pay as you go programs. The federal government does not and never has saved payroll tax revenues. These have always been generational transfer programs from workers to retirees, such that the benefits for Grandma come directly out of the pockets of Junior. By the time the first millennials reach their 40s in 2021, the cost of Medicare alone will be greater than our country's total defense spending. Put all together with baby boomers hitting retirement, grandmas living longer, medical costs spiraling upwards, Social Security, Medicare expenses will consume about 12 percent of the nation's economic output in 2035, triple what it was in 1971.

I would be remiss also if I didn't mention what we all know, which is that large parts of the federal budget are being financed by debt, 42 cents on every dollar. And this debt, too, must be paid back. By 2021, interest payments on the debt will be a bigger portion of the budget than our discretionary funding, which will contribute to a crowding out of spending in education, infrastructure, national defense and everything else that might be considered investment in our future.

We all know this is unsustainable. And the need for reform is obvious.

This is not an appropriate legacy for Grandma to leave to Junior because it defies the social contract in which each generation strives to leave the country better off than it inherited it from its parents. We need to revise the social contract to reflect the changes in our society in a way that keeps the faith with Grandma, does not cut her benefits on which she is now relying, but stops making promises to Junior that we simply cannot keep. We can have a generous, compassionate social welfare program for the elderly which is consistent with a dynamic economy in which workers have multiple employers over their careers, stay active and healthy in the work force into their 70s. This will require removing disincentives to longer careers, asking the more successful to shoulder more of their own retirement costs and health costs, and building stronger incentives for innovation and efficiency into our health system.

Change is coming one way or the other, and it will either be deliberate, careful and well thought out, or it will be imposed by a chaotic and indiscriminate way. If we take it upon ourselves to correct the-- America's social contract and be proactive, there will be nothing to fear from these changes. This is the normal process of each generation of Americans, improving upon the strong institutions built by earlier generations. And the millennial generations, the juniors of tonight's motion, want to be part of that solution.

You are likely to hear from our opponents an unwavering commitment to early 20th century social insurance models and an inability to adapt them and their spirit to the 21st century economy and population. They may accuse us of trying to take Grandma's benefits away from her or suggest that we believe that the federal safety net with a mistake in the first place.

This is not true. The only people who are talking about taking away Grandma's benefits are those who want to scare seniors for political reasons. They may argue as well that entitlements, the benefits about which we are debating tonight, Social Security, Medicare, and Medicaid, are not the problem at all, that the real problem for Junior is skyrocketing health care costs. This is a tricky tactic intended to shift the focus of the debate. Health care reforms are an important subject, just not the subject of tonight's debate. The system that pays Grandma's benefits is imperiling Junior's future by making promises to Junior that it cannot keep, by paying for these benefits through borrowing that contributes to mounting national debt, 14 trillion and counting, thus imperiling Junior's fiscal and economic future.

We encourage you to vote in favor of the motion.

### Moderator
Claim: Thank you, Margaret Hoover. Our motion is "Grandma's benefits imperil Junior's future," and here to speak against the motion, Howard Dean, he's a doctor who left medicine to enter politics. He ran for president in 2004. He has served as a chairman of the Democratic National Committee, and you were governor of Vermont for 12 years, and I want to talk to you about, very briefly, about your 12 years as governor of Vermont. You came into office with a $62 million deficit. While there, you instituted a program that extended health care coverage to most of the kids in the state and you cut taxes. Does that mean it's all easy because you--

### Scientific Advocate (SA)
Claim: Should I be on the other side of this debate?

### Moderator
Claim: Ladies and gentlemen, Howard Dean.

### Scientific Advocate (SA)
Claim: Thank you. First of all, I hope to be able to match Margaret. She actually stuck to the time and that's not so easy. She also did something else that is-- that you all have been victimized by for some time and that is frame the debate in such a way that we're focused on giving people big tax cuts at the same time we're focused on cutting benefits.

The truth is that we do not have a Medicare and Social Security problem in terms of what it is costing us. What we have is bad management, politicians who won't talk to each other and work with each other, lousy tax policy, selfishness as a public policy, and growing inequality in America. This is not an issue about taxes. So a few facts, Social Security is in fact a trust fund. There are $2.6 trillion in the tax fund. They are invested in treasuries in the Social Security fund. By 2020 there will be $3.5 trillion in the Social Security trust fund set aside, put aside by you for spending by you. Is there a shortfall in Social Security? Yes. Is that the single biggest problem of our deficit? No. You know the single largest factor in our national debt is?

This is the CBO, this is not some leftwing democratic think tank like MSNBC. Sixty percent of the deficit in 2019 is due solely to the Bush tax cuts, 60 percent. Now, that's a fact, I'm not-- if you don't want to raise taxes, be my guest, but if this is a debate between raising taxes and dealing with Social Security, you should know that because these neither of these problems is the big problem, the problem is not Social Security. I agree with Mort, there are a lot of things you can do about this. Margaret mentioned some good things you can do about Social Security. We have to tweak Social Security, yes, it's not a big problem. Medicare, Medicare is not the problem. Its costs are out of control. There's a reason for that. The costs of the entire health care system in the United States of America are out of control. There's no way you're going to control Medicare costs without doing something about the rest of the health care costs, and that means we have to have real health care reform, which we have not had. the real health care reform has not taken place either under Romney Care/Obama Care or whatever the Republicans want to call it these days, it has not taken place because the entire reimbursement system of the health care, Medicare, or private sector, encourages me to do as much as I can to you whether it works or not, and the more I do, the more I get paid. We need to fundamentally get rid of the fee for service system, capitated care, some of the things in the health care bill such as accountable care organizations, vertically integrated care, will solve the Medicare problem, period. We do not need to privatize either one of those programs. And for those of you on Social Security, could you imagine if President Bush had has his way and we'd privatized Social Security shortly before 2008, I don't think many of you would have been able to afford the $40 ticket that you paid to get in here. So let us not allow the right wing to focus on these two programs or the idea that we ought to reform them. Let's reform our tax system so we have a more equal more fair society and then we can talk about how to deal with these systems.

Now, what can, in fact, we do? We talked a little bit about how to fix Medicare. We do need to start paying people in a global budget, pay the hospitals and the doctors a flat fee for taking care of people. Then, all of a sudden, guess what? Prevention will pay. Nobody invests in prevention today except for Kaiser or self-insured major corporations. We can change all of that. There need to be some reforms, but we do not need to make this a private system, and we do not need to withdraw government support from this system. We don’t even need to reduce benefits. We do need to change the way we pay for health care, not just to save Medicare and older people. We need to save business by doing this. We need to save individuals by doing this. We fundamentally have to reform health care. Let’s not use Medicare and Social Security as the victim. The fact of the matter is that young people inevitably are going to end up as my age.

And when they do, they’re not going to want these programs to disappear. The elderly used to be the poorest group in American until in 1926 the farm states where the Depression started began Social Security, which has then spread to a national program by Roosevelt in 1933. So this is a core program. We just need to make it work and we just need some mild tweaks. Health care needs a lot of tweaks, but the whole system needs tweaks, not simply Medicare. And we should stop victimizing Medicare for the sake of keeping our taxes absurdly low. The fact is people need to pay their fair share in America, and the Bush tax cuts need to sunset. You know, when the taxes were at Bill Clinton’s rate, the economy was a whole lot better than it is now. And I wouldn’t mind going back to those taxes and paying my fair share at all. conclusion, the solution to this problem is not to return the elderly to poverty. The elderly programs do not harm young people in this country, because if we did not have them, you would be living with them so you could take care of them at the same time as you tried to make your own lives. These programs were put in for a reason. It is a social compact. And I’ll close with the words of Oliver Wendell Holmes. Taxes are the price we pay for civilization. And for those who continue to want to avoid them more and more, seeking tax cuts when we already have enormous deficits, you will end up paying the price, because-- and I say this not as somebody who’s a liberal or on the left. I say this as a social observer. There is no society on the face of the earth now or in the past which has not collapsed when the gap between the wealthiest and the poorest in that society has become too big. We are going down a very dangerous road.

And cutting Medicare and Social Security are the last things we should be doing, not the first.

## Round 2

### Moderator
Claim: Thank you, Howard Dean. And that concludes opening statements and round one of this Intelligence Squared U.S. debate where the motion being argued is "Grandma's benefits imperil Junior's futures.” Now, remember, keep in mind how you voted at the top of the evening because, once again, at the end of the debate, we’ll ask you to vote again on the quality of the arguments. And the team that has moved its numbers the most will be declared our winner.

Now, onto round two. This is where the debaters address each other directly and they answer questions from the audience and from me. We’re at the Skirball Center for the Performing Arts at New York University. We have two teams of two debating this motion: "Grandma's benefits imperil Junior's future.” You’ve heard the side arguing for this motion, saying that basically we’re looking at a mathematical inevitability. The money is simply going to run out and that at the rate we’re going, Social Security and Medicare are either going to break or they’re going to break us and that changes, significant changes are needed to avoid that outcome.

The side arguing against them is saying that that doomsday scenario is greatly exaggerated, that in fact these programs are good programs, that they are generally well-managed, and that the problem is essentially at the core of medical expenses in the system, and that Social Security itself is, as structured, not really in fiscal danger.

So I want to go first to the side that’s arguing against the motion and bring up the number that your opponent Margaret Hoover brought up, which is 2037, the year 2037, at which point, as she says, it is projected that the trust fund that was set up for Social Security is going to run dry. And this is not a number she’s pulled out of thin air. This is 2036, 2037, ’38, around there. It’s generally thought that that actuarial prediction is pretty good, pretty on. So I want to put to your side, what about that? What about the stark fact that that money will be gone? Jeff Madrick.

### Scientific Advocate (SA)
Claim: Let me take that. At that point, Social Security-- remember, Social Security is a pay-as- you-go system. And, Margaret, it's not a rude awakening. It was always known to be a pay-as-you-go system. It was never said to be a trust fund. When that money runs out, money will still be coming in from workers. Enough money will be coming in, as I said earlier, to pay according to the same estimates that said the trust fund wouldn't run out in 2037, to pay 78 percent of current benefits. So when people say, and you hear it all the time, and I'd like to ask Mort what he means by insolvency and Social Security. When people say Social Security is going insolvent, and then they tell us, as we better cut the benefits now in order to save it, well, the benefits are going to be cut. And they may even be cut less without doing anything than you would like to do now. That's what's happened.

That's what happened--

### Moderator
Claim: All right. Margaret Hoover.

### Conspiracy Advocate (CA)
Claim: So no one is saying we should cut benefits now, especially to the seniors to whom we have promised. There's no one out there saying that except the AARP who is trying to scare Grandma into continuing to not vote for entitlement reform, which is imperiling Junior's future. I want to go back to this notion that 78 percent of benefits will be paid out because when you think about it, that's not a good deal. I put in money my entire lifetime, and then, presuming that the benefits are going to be there, I can only expect to get 78 percent out? That's just not a good deal for the worker. So-- did I answer the question that was--

### Moderator
Claim: Yeah, I think so. Do you want to go back to--

### Scientific Advocate (SA)
Claim: Well, let me very quickly respond. You say nobody's calling for reductions in benefits, but of course all kinds of people are currently calling for reductions in benefits.

### Conspiracy Advocate (CA)
Claim: Who?

### Scientific Advocate (SA)
Claim: Simpson Bowles. When you raise the--

### Conspiracy Advocate (CA)
Claim: They're talking about reduction on future benefits, but no one

### Scientific Advocate (SA)
Claim: When you raise the retirement age, it's a cut in benefits. If you raise the eligibility retirement age from 65 to 67, that's a cut in benefits of 13 percent. Some of the proposals out there cut benefits, in fact on 40 percent of men, some of the proposals cut benefits by 20 percent. These are proposals that are already out there. This is not a fiction.

### Moderator
Claim: Mort Zuckerman.

### Scientific Advocate (SA)
Claim: People are proposing that.

### Moderator
Claim: Mort Zuckerman.

### Conspiracy Advocate (CA)
Claim: That's not the only proposals that are out there. And we're basically talking about people just coming into the system having to deal with it. I mean, the fact is when FDR introduced Social Security, the average life expectancy was 62. It's now 80. You don't have a system that doesn't take that into account unless you just want the system to go bust. So you've got to find some way to correlate revenues and ultimately payouts.

So I don't think these are unreasonable things to have some way of-- and we've done it. We've done it many, many times, okay? We did it in 1983 when Tip O'Neill as the speaker of the House, and President Reagan got together and did that, okay? They improved the fiscal stability of that thing. We want these things to work. If you can guarantee that this thing is going to work by one magical system or another, great. But you can't.

### Moderator
Claim: Howard Dean.

### Conspiracy Advocate (CA)
Claim: Not with all the people who are going to be retiring, the 79 million people who--

### Moderator
Claim: Howard Dean.

### Conspiracy Advocate (CA)
Claim: --are baby boomers.

### Scientific Advocate (SA)
Claim: Let me just remind everybody that the question is, do Grandma's benefits imperil Junior's future. The answer is no, they clearly don't. So we're talking here about making some adjustments. Let me tell you what adjustments. I object to Mort's view, even phraseology that the system will go bust. Jeff has said it will not, and Margaret's actually said 78 percent of the benefits is a bad deal. But that is not the same as going bust. Secondly, here's what needs to be done. Number one, wealthy pay taxes on their benefits. I think that's a good thing.

It's a better way than means testing. I think it's a good thing. Those taxes should go back into the social security trust fund, not go into the general fund. Number two, no matter how attractive they may be politically, do not give payroll tax cuts. That money goes into Social Security. Right now we're simply adding it to the national debt and then putting it back in the Social Security trust fund. That is not going to help. Just let people pay into it. This is an actuarial fund, and it ought to be fully funded. Next, we need to have a different immigration policy. For all those people who are screaming and yelling about all the immigrants coming in here and screwing up the economy, look at Alabama right now where the Hispanic population is fleeing, crops are rotting in the field.

### Moderator
Claim: Howard, can you bring this back to--

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: --to the benefits.

### Scientific Advocate (SA)
Claim: Immigrants contribute greatly to Social Security, and the illegal immigrants contribute greatly to Social Security because they have fake social security numbers, and they never get any of that money back, so they actually boost the fund up. true. And secondly, immigration built this country because if we have-- if we only have two workers paying for-- or three workers paying for what 168 used to pay for because we're not keeping up with our birth rate, then let's have some more talented, hard-working people come into this country and stop beating up on immigrants. If anybody in here has Native American blood in them, they're not an immigrant. The rest of you are all immigrants, and it built this country. Let them keep building this country and keep coming. That will solve the Social Security trust fund problem.

### Moderator
Claim: Margaret. Will it?

### Conspiracy Advocate (CA)
Claim: So you just admitted that there is a Social Security trust fund problem.

### Moderator
Claim: Ah.

### Conspiracy Advocate (CA)
Claim: And I--

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: There is a Social Security trust fund problem. It is not imperiling Junior's future. It is good for junior's future to have Social Security.

### Conspiracy Advocate (CA)
Claim: Even if the trust fund is imperiled.

### Moderator
Claim: We had a--

### Scientific Advocate (SA)
Claim: We're going to fix the trust fund if only the Republicans would get out of the way.

### Conspiracy Advocate (CA)
Claim: So we need to fix it. No, no, no. But hold on. But what Governor Dean has just said that it needs to be fixed. And that is an implicit--

### Scientific Advocate (SA)
Claim: But it--

### Conspiracy Advocate (CA)
Claim: --agreement with the motion.

### Moderator
Claim: I have somewhat of the same question because-- because they put forward a series of - - the word "tweaks" was used. And this team stood up and used the word "tweaks" also. And I'm wondering where is the daylight between your "tweak" sets.

### Scientific Advocate (SA)
Claim: I was wondering that myself. I thought they were arguing our side when they started this because--

### Conspiracy Advocate (CA)
Claim: I can tell you three things I agree with Howard Dean. I agree with we need to get fee for service.

### Scientific Advocate (SA)
Claim: Let's just get very clear about this.

### Moderator
Claim: All right, Jeff. Let me let Jeff Madrick--

### Scientific Advocate (SA)
Claim: When you start talking about the insolvency of the system, to most people out there that means you will have zero benefits when the trust fund runs out. That's what insolvency means. When you use language like, it's going to go bust, that means benefits are going to go down a lot. They're not going to go down 20 percent. I see some people shaking their head. It doesn't mean that. They're not-- when you say "bust," you're talking about at least 50 percent, 60 percent. It's an extreme exaggeration, number one. Number two, when we say "tweaks," small increases in taxes can bring that benefit back up to a hundred percent.

### Moderator
Claim: Is that a tweak that you're good with?

### Conspiracy Advocate (CA)
Claim: Call it what you will. We have a Democratic president, Democratic control of the Senate and Democratic control of the House, and we did nothing about these issues. When you can get any kind of mix of politics-- I don't care whether they're the Republicans or the Democrats-- who can really change what you're talking about changing, the tax rates, the immigration codes, you name it, I'll agree with everything you want to say. But in the meantime, these programs are in jeopardy. And everybody who has looked at it has agreed that they are in jeopardy in one form or another. And I would therefore say to you, as long as you can sort of hypothesize these unavailable, impossible programs, sure, you can find other ways to solve it. But in the meantime, we're living with these programs. We haven't been able to solve it, and nobody's been able to do it since 1983.

### Moderator
Claim: Howard Dean.

### Scientific Advocate (SA)
Claim: Here's the problem with that argument. I agree. The programs are in some jeopardy. Why? Because one side of the political aisle wants them to be in jeopardy. They've never liked Social Security.

They think the federal government should be drowned in a bathtub-- I do not think it's fair to take away social security because there is an intransigent group of people in the House who refuse to do anything about it at all.

### Moderator
Claim: All right. But I just want-- I want to point out that your debate opponents tonight did not take that position.

### Scientific Advocate (SA)
Claim: That's true, they didn't. But Mort just defended them.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Margaret Hoover.

### Conspiracy Advocate (CA)
Claim: straw man. To answer Jeff's question, insolvency, this inflammatory rhetoric is not rhetoric that Mort and I made up. In insolvency is the word used by CBO, by actuaries of Social Security. And it refers to the fact that these programs will not be able to deliver on their promises by that year 2037. Not my inflammatory rhetoric, the rhetoric of Social Security actuaries. Now, with Governor Dean, you've agreed that these programs are in jeopardy. To the extent that these programs are in jeopardy, you are then agreeing implicitly with the motion that those promises that have been delivered-- or that have been promised to Junior will not be able to be delivered upon, and therefore, his future is imperiled.

### Moderator
Claim: Did she get you on that?

### Scientific Advocate (SA)
Claim: No. What I-- no. My opening statement was that we don't have a Medicare and social security problem in this country. We have a political and an economic problem in this country because of bad leadership in both the business sphere and the government. So if the argument here is Social Security and Medicare, Grandma's benefits are imperiling Junior's future, no. The political class is imperiling Junior's future because we have a lousy group of politicians that can't get their act together. I don't think we should take that out of Grandma's hide. What we need is new politicians, not new grandmas.

### Moderator
Claim: Howard, I thought, though, that what I heard the other side saying is not-- they're not talking-- they're not talking about wanting to-- they're not talking about wanting to cut Grandma's benefits now.

But they're talking about wanting to cut Junior's benefits when Junior is a grandpa, later on, they're talking about the future, are they not?

### Scientific Advocate (SA)
Claim: All reforms you're talking about cutting-- all reforms are talking in some way or other about cutting benefits now. We've already raised the eligibility age to 67. That's going to be a 13 percent benefit cut. That's not somebody way down the road. That's a 13 percent benefit cut. Let us be honest about this. I watch television and people, supposedly forthright people, get up there and say, "Why don't politicians tell us there won't be any Social Security for us?" They don't get up there and say, "Why don't they be honest and say we're only going to get about 80 percent of our Social Security?" The words are inflammatory and sadly misleading. We can solve the problem with modest Social Security tax increases, by raising the cap, and let me talk a little bit about Medicare, Howard's forte, because Margaret brought up the fact that this is some kind of side issue.

Why do we think Medicare is going to go off the rails? It's not the aging issue because if it were the aging issue they would by and large rise to the same proportion of GDP as Social Security did. It's that health care costs are rising very rapidly, and I guess we have to repeat this over and over again, rising health care costs can undue Medicare and Medicaid, down the road, not the next 10 years, but well down the road, unless we have very, very serious reform--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --and that is not a side issue.

### Moderator
Claim: Let's bring Margaret in. Margaret Hoover.

### Conspiracy Advocate (CA)
Claim: I agree with you. I believe we agree with you, that rising health care costs are very, very important and one of the driving predictors in long term spending of these problems. The issue here though is about benefits.

And Medicare and Medicaid are health care benefits. And to the extent that health care costs are careening out of control and must be reformed, this is again an implicit affirmation of the motion that benefits are imperiling Junior's future.

### Scientific Advocate (SA)
Claim: I would disagree.

### Moderator
Claim: Howard Dean.

### Scientific Advocate (SA)
Claim: I think in fact you just affirmed our side of the motion-- which is the negative side. The fact is it isn't the benefits, it's the system. If you capitated everybody's--

### Conspiracy Advocate (CA)
Claim: It's the same thing.

### Scientific Advocate (SA)
Claim: No, it is certainly not the same thing. What I get in benefits has nothing to do with how I pay for those benefits. The problem is not the benefits that Grandma's getting, the problem is the way we pay for health care in this country. You couldn't be in the automobile industry-- here's what would happen if the automobile industry were funded the way health care was, I would-- if I were Ford Motor, I would make 10 million cars a minute if I could because I'd get paid for every single one of them. This is an insane system.

There's no-- the economic system doesn't work. You have to get rid of the fee for service system. And you have to have a global budget capitated care system which-- and actually in Obama's plan, it's possible to do this because he's created these integrated networks, and if you pay them a fixed amount of money, let the professionals and-- get the insurance companies out of it, let the professionals and the patients figure out how they want to save those dollars, but they don't get additional dollars.

### Moderator
Claim: So, Margaret, Howard's made the case that paying and the benefits are not the same thing. So let me go to the question of Medicare benefits, do you see the need to actually reduce the level of benefit that--

### Conspiracy Advocate (CA)
Claim: I share the view just expressed that I want to completely redo the health care system, the medical profession, how they get paid, end fee for services-- change the whole hospital system, revolutionize the whole thing, and I'm ready as soon as that is done to take the same approach that you're talking about with respect to health care and Social Security. However, until then and in the slight possibility even when you were chairman of the Democratic Party that you weren't able to institute this in this country, in the slight possibility that that will not happen, let's find something to have a fallback position just in case we can't revolutionize the country.

### Moderator
Claim: Margaret, can you take on that question of whether you're actually advocating a reduction in the benefits, the stuff you get from the doctor, the care.

### Conspiracy Advocate (CA)
Claim: I actually in one sense agree with Governor Dean. I agree that the health care system needs to be reformed so that medical costs come down because I agree with the premise that it is medical costs that are careening out of control. I think Governor Dean and I have dramatically different ideas about how we would contain costs.

### Moderator
Claim: Right, but I think they're saying that what's-- I think what they're-- the words they're putting in your mouth is saying what I'm putting into the question is that you're actually suggesting that people have-- there's too much care, they're getting too much great medical stuff, and that, that needs to be reduced as well as the cost.

### Conspiracy Advocate (CA)
Claim: Well, in some sense in the medical profession there is too much care because it's fee for service, you have-- Mort has written about tort reform, you have moved patients away from the marginal cost of their health care.

And as a result, because they don’t know-- there’s no transparency. They don’t know how much they’re buying, paying for services. In addition, doctors are constantly checking boxes to cover their CYA sort of movement so that they don’t get sued. You have an enormous amount of spending in health care that is unnecessary.

### Moderator
Claim: Howard Dean.

### Scientific Advocate (SA)
Claim: I have to disagree with that. The fact is that incentives work. We just have bad incentives. The reason that health care costs are going up at three times the rate of inflation is not because of tort reform and all these other problems. It’s because we get paid to spend more money. Let’s say you’re a hospital executive. Right now, under the present system, you’re going to hire as many cardiologists who do catheterization, get as many MRI machines as you can because they’re huge profit centers. And you’re going to hire as few nurse practitioners and internists as you can because they don’t make you any money. We need exactly the opposite.

We have an illness system here, not a wellness system. That’s the problem with our health care system. And so it actually encour-- I don’t think most doctors do this but I-- some hospital executives-- I know people who work in ERs where the CEO goes through once a month to boost up morale and says, “By the way, we’re a little short upstairs. You got to admit a few more people.” This is insane. You do not have to reduce even the quality of care. We’ve got to start keeping people well and have the money go to people who are trying to stay well and doctors and hospitals who are trying to keep people well. We’re not talking about cutting benefits because benefits are not the problem. It’s the way we pay for health care.

### Moderator
Claim: Mort Zuckerman.

### Conspiracy Advocate (CA)
Claim: No, but what you are saying, if the current system-- and I couldn’t agree with you more about the fee for services, because it’s counter to everything and more. You pay for more, not for better in that system. And I agree with that, okay. All I’m saying to you is that it is almost impossible for me to imagine that you’re going to change that, at least within my lifetime, and maybe within the lifetime of Junior. And I have a couple of young juniors.

I just don’t see that happening. I hope it does. But I don’t know what it’s going to take. All I can say is I’ll give you an example. Tort reform in New York State-- a whole group of us tried to get a cap on damages of $250,000 as a maximum for tort liability medical issues. We couldn’t get it. But if we had gotten it, we would have saved $600 million a year in New York State alone, just for the hospitals. Now, it’s almost impossible to get these things done. In the meantime, I want to make sure that the health care system or the Medicare and Medicaid and the Social Security system do not break the bank, do not destroy the future of this country. When we are able to change those other things, I’ll agree with you.

### Moderator
Claim: Jeff Madrick.

### Scientific Advocate (SA)
Claim: We have to-- I have to make one point very clear. When you reduce Medicare benefits, you tend, except in rather narrow ways, you tend to raise health care expenditures for the rest of the country. One example, President Obama considered agreeing to raise the eligibility age of Medicare from 65 to 67, from my point of view an outrageous move.

Kaiser Family Foundation did a study about that. What happens? Those 66- and 67- year-olds need insurance somewhere else. On average, to simplify the insurance they will pay for or their employers will pay for or the new health exchanges will pay, the price will go up. America will pay more in health care with those kinds of reforms unless we believe in triage, unless we simply say 66- and 67-year-olds, which is probably what the insurance companies would like to hear, let’s not bother getting health insurance for them. And that includes the Ryan plan. It raises health care expenditures. So this is a difficult issue. To cut back Medicare benefits significantly affects the entire health care system. Keep that in mind.

### Moderator
Claim: Margaret, I’m a little confused about something.

In the same way that you feel that you got Howard to admit that the system is in peril, that things don’t change, I think they’re getting you to admit that it’s pretty fixable, that there’s stuff you can do and you fix it and it’ll be okay again.

### Conspiracy Advocate (CA)
Claim: I actually agree with that. I just have a difference-- so--

### Moderator
Claim: So where do you-- where’s the dividing line between these two teams?

### Conspiracy Advocate (CA)
Claim: I mean, I just think that we’re arguing this notion of benefits, and Medicaid and Medicare are benefits. And the way these benefits are structured are imperiling Junior’s future. And I think they’re saying the same thing, but they’re trying to say it’s not the benefits. It’s the health care. But the benefits are the health care.

### Moderator
Claim: Jeff Madrick.

### Scientific Advocate (SA)
Claim: You cannot cut the benefits without raising health care-- Medicare-- health care expenditures overall. I just gave the Kaiser Family Foundation example. They said it would raise health care spending in America by twice as much as it would save Medicare.

That imperils Junior’s future. If you had--

### Moderator
Claim: All right. I’d like to go to some questions from the audience now, and remember, when the mic comes to you, please stand up and state your name and please ask a question, and try to keep it on topic to move along discussion towards conclusion of our motion. And right down in front, yeah. The closest person to you. Yeah. If you could stand up and state your name, and we just want to give the camera a moment to find you, and it has.

### Moderator
Claim: Yes. My name is Reba Shimanski, and I have two quick solutions to the problem. You get rid of the--

### Moderator
Claim: I really would like to ask you to ask a question.

### Moderator
Claim: I'd like them to comment. That is my question.

### Moderator
Claim: Okay. Phrase it so that it's a question.

### Moderator
Claim: You remove the wage cap which now stands at 106, 7, $800 on the FICA tax and have wealthy people pay the same percentage as everyone else. Social Security would be overflowing with revenue for the next hundred years.

Two, if-- you don't take into consideration the fact that if the unemployment rate ever went down again there would be a big surge in revenue. For Medicare, the one easy solution would be for the federal government to negotiate with drug companies. And that would bring down drug prices. And that also would save Medicare costs.

### Moderator
Claim: Okay.

### Moderator
Claim: Also--

### Moderator
Claim: No, no, no. I-- I'm going to stop you there. I'm going to stop you there because I asked for 30 second. Thank you. Thank you. And then at the end of that, you can say, isn't that right? Mort Zuckerman.

### Conspiracy Advocate (CA)
Claim: No, I mean, look, there are all kinds of different programs, including some of them that are implicit in your question or comments. And the real problem is you have to weigh the probability of getting some of those things done. I wish we could get them done, frankly. I wish we could get toward liability. I wish we could change fee for services. I wish we could change the whole system. I have here a little cartoon from the New Yorker, just to show you. This is two-- two policemen interrogating Bernie Madoff.

The lights are shining on him, and the cop says, "All right, Madoff, where did you get the idea of paying early investors with money from late investors?" he says, "From the Social Security system." Now, all I'm saying is--

### Scientific Advocate (SA)
Claim: Wow, are you running for president from Texas, Mort?

### Conspiracy Advocate (CA)
Claim: We have to look at these things-- we have to look at these things and make them as self-sustaining financially as possible. You can't revolutionize the whole country to solve this problem because it'll never get done. And we will not necessarily go broke in a total sense. But we will-- as a country, we will end up in a very, very different kind of place.

### Moderator
Claim: Howard Dean.

### Scientific Advocate (SA)
Claim: You know, it will get done, and it is getting done. And of course these folks on the right are going to be horrified to hear me say this, but in fact it's happening in the private sector. Government never leads. The private sector is already-- you have Kaiser. You have Geisinger which is going to be the model for the Vermont single payer that we're trying to put in. The private sector today is figuring out how to do capitated care and how to pay hospitals and doctors differently because the current system doesn't work.

Again, let me emphasize, the title of this debate is, resolved, Grandma's benefits endanger Junior's future. They do not. It is political bad management. It is political intransigence. It is bad economic management, but it's not grandma's benefits. And the private sector is doing something about it right now. Eventually, the government will figure it out.

### Moderator
Claim: Gentleman on the aisle in the argyle sweater. And-- I encourage you to improve upon the question model.

### Moderator
Claim: I'll do my best, with all due respect. My-- to the person who spoke earlier. My name is Mark Turner.

### Moderator
Claim: Okay.

### Moderator
Claim: I think tonight and every night when you turn on the tube you can see that we have the intelligence to have this debate, but I believe our politics dummy us down. So my question is, is there a play on history going on here? In 1980, during the Reagan revolution, after there was a discussion about Social Security-- by 1982, the public had spoken.

Many grandmas and grandpas voted, and it got Reagan and Tip O'Neill to sit down. So maybe we should expand the table and have more juniors at the table so that their voice is going to be part of this democratic process. And--

### Moderator
Claim: Margaret Hoover is our junior representative.

### Moderator
Claim: --more juniors here to see if in fact you'll channel the past and go for politicians who promise us a chicken in every pot and a car in every garage. I don't think they'll go for that.

### Moderator
Claim: Okay. All right. You were good at the question, Mark.

### Conspiracy Advocate (CA)
Claim: Thanks for the Hoover reference, too, there. You know, I couldn't agree with you more. Juniors do need to be part of this debate. And the one thing that really characterizes the millennial generation is a desire to be part of the solution. But I will say when we talk about this compromise that happened with Tip O'Neill and Ronald Reagan in 1983, we have to remember too, they were months away from seniors not getting their benefit checks. So one of the things I worry about is that politicians need their next election to be hanging in the balance before they can actually be mobilized to do anything.

### Moderator
Claim: Howard, would you like to comment on that as well?

### Scientific Advocate (SA)
Claim: Yeah. I actually think that's exactly right. But again, that's a systemic problem, not a benefit problem. And I'm really in favor of getting millennials to have their place at the table. And I'm incredibly glad that they're dancing on Wall Street right now.

### Moderator
Claim: Woman in the green sweater, standing up. Yeah.

### Moderator
Claim: Hi. My name is Chloe Hines, and I was just wondering if we could elaborate a little bit on what it would look like if we were creating healthier seniors, if the people who are my age and Margaret's age and under the age of the beneficiary line, what that-- what those benefits would look like, because I feel like the pool would be depleted at a much slower rate. And I see that point being made. So I'm wondering if we can clarify a little bit on the distinction between the health care and the benefits, because I see that happening, but it seems like it's getting muddled up in rhetoric.

### Moderator
Claim: If you--

### Moderator
Claim: Let-- let me let Mort Zuckerman go.

### Conspiracy Advocate (CA)
Claim: The fact is health care has improved dramatically.

That's why longevity has improved so dramatically. So we are in fact seeing a totally different aging of the population. We had something really unique which is that there were baby boomers. We have 79 million of them coming into this system over the next several years, without going into the exact number. Their benefits alone will add $3 trillion a year to this thing. We've got to find some way to make that still viable. I don't disagree with anything you're saying in one sense, which is that we can improve the health care system, without question. And we are improving it. And all kinds of benefits are coming from it, longevity being the first one. When we-- the original idea of health care was not necessarily to-- I mean of Social Security, was not necessarily to provide retirement income for people to the ages of 90, whatever that new longevity will take us to. When that was passed-- as I said, the median age was 62. That was the median longevity. We're now at 80.

There's nothing wrong with taking that into account.

### Moderator
Claim: Howard.

### Scientific Advocate (SA)
Claim: I'll just be very quick about this. What your health care would look like is people would begin investing in your wellness at your age so that you wouldn't be diabetic, having dialysis, advanced atherosclerotic heart disease when you got to be my age. And so the whole-- capitated care gives a financial impetus and incentive to take care of all the people in the system when they're young so they don't use up more money when they're older. Now, I am not going to get into this. End of life care is another area. And I'm not going to get into this in a big way because it takes a lot of time. But the truth is, most seniors will make the right end of life decisions. But right now, hospitals and doctors are incentivized to stick as many tubes as they possibly can in them and you're going out the door. All you've got to do for that-- to fix that is not have death panels like Sarah Palin was talking about. Just turn the decisions back to the seniors by living wills and durable power of attorneys. And I hope everybody in this room has one.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: Can I say something?

### Moderator
Claim: Yeah, Jeff.

### Scientific Advocate (SA)
Claim: I really hope the debate and what you take away from it can stick to the facts. Yes, there is greater longevity. As big a problem for the Social Security system has been the fact that wages haven't grown and that there's inequality in America. When wages don't grow, people put in less money into the Social Security system. When there's inequality, a lot more people are above the cap that woman was correctly talking about. Even saying that, however, let me repeat what I said at the outset. Here were the simple numbers. For all the inflammatory language about the number of people who are getting old and longevity and the trillions of dollars and so forth, Social Security is going up from five percent to six percent of GDP. And ma'am, you are correct, we could solve that problem merely by eliminating the cap.

### Moderator
Claim: Margaret Hoover has a look on her face that-- that I--

### Scientific Advocate (SA)
Claim: --merely by eliminating the cap we would not have any deficit in the future.

### Moderator
Claim: Margaret.

### Conspiracy Advocate (CA)
Claim: I just-- it seems to me as though you're setting up this false choice, in saying, we don't need to save Social Security. Six percent of GDP is nothing. You know, 6 percent of GDP is more than $800 billion less than $900 billion. That's not nothing. And for an economy that is $14 trillion in debt, it's the Ben Franklin saying, if you mind your pennies, the dollars will take care of themselves. So this notion that we can just sort of ignore one and just take it is just fiscally irresponsible.

### Scientific Advocate (SA)
Claim: Neither Howard, nor I, nor I think Mort, nor even you suggest that we should ignore the problem. We are saying the fix is not dramatic for Social Security.

I don't think I'm even-- I think I've said enough on that.

### Moderator
Claim: Okay. Let me go to another question. Sir, you're wearing a black turtleneck and you're in the dark, if you could come down a few steps just so the cameras can see you and light up, few more steps so that I can see you though, that's great, thanks.

### Moderator
Claim: My name is Dan Tighe and I heard Governor Dean say that there was more than $2 trillion in the trust fund for Social Security, and Mr. Madrick say that there never was a trust fund, that it was always pay as you go. It seems that there's a fundamental disagreement between the two of you. Could you clarify which of the two statements is correct?

### Scientific Advocate (SA)
Claim: Yeah, it's basically a technical issue. We've been collecting a lot more payroll taxes than we've had to pay out. That should be a surplus in the system, a trust fund, it's become IOUs from the federal government. People thought there should be a locked box, the federal government should never be able to spend that money. The federal government did spend that money and gave this trust fund debt. Is the federal government ever going to renege on that debt?

If it reneges on that debt, it's going to renege on a whole lot of debt, and we have a much bigger problem-- we would have much bigger problems. So it's really just a technical issue.

### Moderator
Claim: A rejoinder from this side?

### Conspiracy Advocate (CA)
Claim: Well, let me just say--

### Moderator
Claim: Mort Zuckerman.

### Moderator
Claim: --when Reagan and Tip O'Neill and-- got together and restructured Social Security, we had something like $25 million in that trust fund. It's now up to about $2.6 trillion and it'll be about $3.1 trillion before we have so many more people receiving it than paying into it, that that money is basically going to disappear, and it disappears according to the best actuarial judgments at this point, in 2036 and 2037. The whole idea is to find some way to keep that in a sense viable and liquid and not insolvent, so I think that's basically what we're talking about. If you don't do anything about it now, it's very nice to say let's find some other way to deal with it, but frankly we've done it 40 times, okay?

So I don't see that this is a great issue here, and I agree, let's lift the cap so that the wealthy pay more, et cetera, et cetera, but we've got to keep it solvent, and we've got to keep it solvent for a long period of time for a lot of elderly people.

### Moderator
Claim: Ma'am, yeah, no, I'm sorry, go back two rows, thanks, that's right.

### Moderator
Claim: Hi, my name is Barbara Title

### Moderator
Claim: Can you hold the mic a little closer to you?

### Moderator
Claim: Yes, my name is Barbara Title. Up until 10 years ago, the age where you could have earned unlimited earnings and still collect unemployment was 70. Ten years ago they reduced that. Why? I think 10 years ago at 65 or 66 you can earn unlimited money and still collect your Social Security.

### Moderator
Claim: I think that probably it's a technical question that's off the topic that we're trying to get to at the moment, unless, Jeff, you want to take this?

### Scientific Advocate (SA)
Claim: It was just one of many reforms that have reduced Social Security benefits. People keep talking about the Reagan-O'Neill Agreement. The Reagan-O'Neill Agreement cut benefits.

It used to be that-- in that period 52 percent-- Social Security replaced 52 percent of preretirement income.

### Moderator
Claim: So you're saying it now replaces--

### Scientific Advocate (SA)
Claim: This is an average--

### Moderator
Claim: Jeff, you're saying it's a little dose of what this side is recommending be done.

### Scientific Advocate (SA)
Claim: It's a little dose-- yes, it's a little does of what that side's recommending. They also raised-- they also raised payroll taxes significantly.

### Moderator
Claim: All right, so since we have a good example, and thanks for that question, ma'am, is that brought to your side fairly?

### Conspiracy Advocate (CA)
Claim: Well, I-- we had not frankly addressed that particular issue. What we are saying is there's got to be some combination of factors that has to make the system viable for a much longer time than it currently is. And we think that's important. We've done it many times in the past. There is no problem in my judgment, no overwhelming problem in doing it now. It is true on the health care side that you have a real problem of the health care system. That is so difficult to do in the meantime, it seems to me.

We've got to make sure that these various programs do not go bust or in fact put such a burden of debt on this country that we'll simply not be able to spend the money on so many other things whether it's education or infrastructure or police or whatever you have to do, and that-- it's just going to drain it. And in fact if you go from five percent of GDP to 13 percent of GDP which is where our health care costs are driving us, you're going to take a huge amount out of what we otherwise need for the kind of country that we'd like to think we want to have in the future.

### Moderator
Claim: Margaret, do you want to add to that?

### Conspiracy Advocate (CA)
Claim: Yeah. What seems to be agreed upon here, and what Jeff just said, too, was that the fix is easy. We know what the fix is. And it's true, CBO has scored 30 different fixes for Social Security. But then if we agree that there needs to be a fix, we agree that there's a problem, and we agree that Grandma's benefits are imperiling Junior's future.

### Scientific Advocate (SA)
Claim: Well, let me, if I may, we agree that there needs to be a fix and we agree that there is a problem, but the problem is not Grandma's benefits, it's the idiots in Washington that won't fix it. we should not cut Grandma’s benefits because we have an incompetent political class. That’s what we need-- let’s not reframe this thing. This is not about Grandma’s benefits. It’s about getting people who will get stuff done in Washington and cut out the nonsense.

### Moderator
Claim: Actually the motion does say “Grandma’s benefits.”

### Scientific Advocate (SA)
Claim: Our fix-- you framed it wrong.

### Moderator
Claim: Okay, go ahead, Jeff.

### Scientific Advocate (SA)
Claim: Our fix, Margaret, is increasing taxes because we think it’s a low tax nation. The earlier fixes were reducing benefits with significant increases in taxes as well. So we have a difference. We’re not saying that Social Security will not have a shortfall. We are avoiding this inflammatory rhetoric about it’s going bust and longevity is doing it all and all that kind of thing.

### Moderator
Claim: I have to do something for radio, which is one of those times when I want-- I need to read something twice, once with your enthusiastic and spontaneous applause at the beginning.

So if you could do a round of applause, I’m going to do my line and then-- not yet. And then I’ll do the line again without your applause, so if you could give a round of applause, that would be great. Thank you. This is a debate from Intelligence Squared U.S. I’m John Donvan of ABC News. We have four debaters, two teams of two, arguing out this motion: "Grandma's benefits imperil Junior's future.” Thank you. Now I’m going to do it again.

This is a debate from Intelligence Squared U.S. I’m John Donvan of ABC News. We’re at the Skirball Center for the Performing Arts at New York University. Two teams, two members-- two against two, arguing out this motion: "Grandma's benefits imperil Junior's future.” Okay, back to questions. Thank you for that. That was great applause. Sir, right-- I’m looking right at you. And just wait for the mic to come.

### Moderator
Claim: I think Mr. Zuckerman began to touch on this, but the debate has largely centered on fairness and solvency.

But I was wondering if somebody could speak a bit more about the long-term economic impact in terms of if you spend money on these entitlement programs, that’s money that’s not going to be spent somewhere else and, for example, the Fermi Lab just had the plug pulled on it last week, and President Obama is trying desperately to get more infrastructure spending. So I guess my question is--

### Moderator
Claim: Well, your question is--

### Moderator
Claim: Or real quick, can we discuss the long-term economic impact of not having that spending.

### Moderator
Claim: Would it be fair to say you’re asking whether the programs are going to be a drag on the economy, on growth, on productivity--

### Moderator
Claim: And thus imperiling Junior’s future.

### Moderator
Claim: Okay, I’ll just put to the side arguing against.

### Scientific Advocate (SA)
Claim: Absolutely not. In fact--

### Moderator
Claim: Howard Dean.

### Scientific Advocate (SA)
Claim: In fact, it’s a huge boost. Florida, as an example, its economy is essentially built on Social Security. This is-- no, this is true. This is the multiplier effect. What these are is transfer payments. They are transfer payments to people who otherwise wouldn’t be spending money.

Every dime that goes into Social Security gets spent because these folks who were depending on Social Security have to spend everything in order to survive and to live. And so, this-- it creates all kinds of multiplier affects wherever they are. That’s why people like retirees living in their state. They don’t use much in the way of services other than health care which is mostly paid for by the Fed, and they don’t have any kids in the schools and so forth and so on. So in fact, these so-called transfer entitlement programs are big boosts to the economy and not drags at all.

### Moderator
Claim: Let’s hear the other side respond to that. Interesting point.

### Conspiracy Advocate (CA)
Claim: Well, I think that is true. The point that I would make, though, is that when people are paying the Social Security taxes, it’s when they’re working. We’re trying to protect that system for the people when they retire. It is certainly true that when they retire, this being in most cases their only source of income, they’re going to spend it. And I’m just as happy to have people, when they’re working, contribute more to this system to make sure that it is viable.

### Moderator
Claim: Okay. Down front, you’ve been very patient.

If you can stand up, and the mic’s coming to you. No, no-- I’m sorry. You’re going to have to be even more patient. I meant in the third row. Sorry, sir, but if you could stand up. Thanks.

### Moderator
Claim: Hi there. My name is-- oops. My name is Alice Silverman and I am a grandma who is very concerned about my juniors and my junior’s juniors, some of whom live in Burlington, Vermont, by the way. So my question--

### Moderator
Claim: And therefore they have health care.

### Moderator
Claim: My question for the evening is how you all get to speak with your respective team members, so to speak, and continue to have them as reasonable and cooperative as the four of you seem to be tonight, so that we can really get some things done here.

### Moderator
Claim: How can we love each other more?

### Conspiracy Advocate (CA)
Claim: I-- look, there’s only one way to do that.

### Moderator
Claim: I’m going to take that as more of an aspirational statement than a question, because I think we take your point. Right next to you, yeah.

### Moderator
Claim: Hillary Sisel Jordan. My question is, you seem to all agree that what's germane to the debate is politics not working. And I'm just wondering, this isn't going, I don't think too far from the debate, is our politics as intransigent as the health care system? And what do you suggest be done? Everybody blames everything on politics. Does it--

### Moderator
Claim: Well, the reason I think that's a relevant question is because, Howard, you have made the case repeatedly, and you also, Jeff, that there need to be basic changes in the way we do things. And Mort keeps coming back saying that would be great if we could do that, but he's saying it's politically impossible. So that's kind of a little bit of a strike against your position if Mort is right that the things you're talking about just can't be done politically. So can you take that on?

### Scientific Advocate (SA)
Claim: You know, the things Mort is talking-- I mean, is Mort just throwing up his hands and going to go back to Canada? The thing that Mort is suggesting be done can't be done politically either as far as I can hear.

If he has any solutions for this that are politically viable now, more politically viable than our side, please speak up, Mort.

### Moderator
Claim: Here's your chance.

### Conspiracy Advocate (CA)
Claim: Well, I do think that the notion of changing fee for services, which I am totally in favor of, or trying to get a cap on medical tort liability, which I'm totally in favor of, I can't imagine how that's going to happen for a very long time. I do think we still, in the interim, can introduce some modest changes to the Social Security system which we've been doing since the initiation of that program. And they did it, as I said, in 1983. What it will take, to answer the question, is political leadership. And that's what we don't have and haven't had for years, who really-- people who really want to address this because they feel they're going to lose votes in one place or another. And that's the sad part if we have a system. In Canada, for example, they're doing it very differently.

### Moderator
Claim: Margaret Hoover.

### Conspiracy Advocate (CA)
Claim: And-- and it's really working, with a different kind of political leadership, with a different kind of politicalism. We don't have that.

### Moderator
Claim: Margaret. Margaret.

### Conspiracy Advocate (CA)
Claim: So-- and we agree in many ways on what the problems are: Fee for service. Governor Dean agreed with us that fee for service is a problem, though we have dramatically different ideas about how to address that. And I think you're right that our politics have become so polarized that you cannot simply come to the table admitting that there are going to be principal differences and figure out how to-- how to work it out. And the political game and the bomb throwing has made touching Medicare or social security a third rail for anyone who tries to take it on. Look what's happened to Paul Ryan who puts forth a plan that you might not like. But he puts down a plan that goes through the trouble of getting it scored by CVO. And the next thing we know, there's a commercial of him throwing Grandma off a cliff.

### Moderator
Claim: Howard Dean.

### Conspiracy Advocate (CA)
Claim: That's nuts.

### Scientific Advocate (SA)
Claim: Well, actually, I thought that that was fairly accurate.

No. I'm sorry.

### Conspiracy Advocate (CA)
Claim: That's part of the problem.

### Scientific Advocate (SA)
Claim: Trying to stifle my partisan side here. Look, I'm by nature, optimistic. And I agree that we can discuss for a long time what's the matter with the political leadership. I do think elections have a way of eventually fixing that problem. I think the private sector's going to do it, and I'll tell you why. Because of the Obama health care plan, which I was not a big supporter of, but which does have some good things in it, there is a real opportunity in the private sector. And I'll tell you what it is. If you have a totally vertically integrated system like Kaiser, for example, or Geisinger, they can now sell their product outside an insurance agency. When they go on the exchanges, which are going to be in place in 2014, you are now going to have people competing with insurance companies to keep prices low. The other great thing about this bill is the exchange is basically a transparent way of buying insurance. Private-- Democrats go crazy when I say this, but the truth is, small business is going to dump all their people into the exchanges.

That is a great thing because now individuals are going to go into the marketplace and choose their own insurance with some government subsidy. And that is market forces at work.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: And an integrated system will beat an insurance company every single time.

### Moderator
Claim: Let me go to the front row for this gentleman I passed over before.

### Moderator
Claim: Hello. My name is David, and I believe I fit into the junior generation. And I was just really worried about a statistic that Mr. Madrick brought up. He said that when I retire, so like when I'm 75 or whatever, when I qualify for Social Security, I will--

### Scientific Advocate (SA)
Claim: If Mort and-- if Mort and Margaret get their way, you probably won't get Social Security when you're 75.

### Moderator
Claim: All right. Well, when I do get my Social Security payments, I was told that I would only get 78 percent, I believe it was, of my benefits. But when you subtract-- when you deduct basically all the expenses I would normally be paying when I'm receiving a hundred percent of my benefits, how much would I have left of that 78 percent.

### Scientific Advocate (SA)
Claim: I agree with that. And that's why I think we do have to raise taxes and get up-- get it up to a hundred percent. I'm not sure our opponents are talking about maintaining the same level of benefits. I think they are talking about reducing those benefits.

### Moderator
Claim: But that sort of does get to the bone of my-- are you talking about maintaining the same level of benefits that we have today?

### Conspiracy Advocate (CA)
Claim: Absolutely, without a question. Nobody suggested cutting the benefits. Frankly, if there would be any benefits cut, I would cut them for the well-to-do. So I would put in an income standard for that. But on all the other benefits, absolutely not. What we're trying to do is to make it possible for us to afford to continue to pay those benefits. And so I'm just going to go to one issue because this is a chance for me to say, even though it's not relevant. If Bill Clinton has a wonderful idea for how you deal with health insurance, private health insurance, where in most states one or two companies really dominate the entire health insurance med space

He said, you just put in one line into their policies, mandate it, that 85 percent of the premiums they receive go to health care benefits, and the rest of it, only the rest of it can go to promotion and profits. And he said you would have a major improvement in that. Well, fine. I'm ready to sign onto that. Any time you-- when I'm president, the first appointed, Canadian Jewish president, I'm willing-- I'm willing to sign that legislation.

### Moderator
Claim: Just a minute. I want to ask-- you-- you've been shaking your head dramatically--

### Moderator
Claim: That's in the law. That is the law. It's in Obama's law.

### Moderator
Claim: You look very, very frustrated by things you're hearing.

### Moderator
Claim: The 80 percent, not 85 percent.

### Moderator
Claim: And I-- I want to see that unleashed in the form of a 30-second question.

### Moderator
Claim: My name is Roger Karlback and I heard Mr. Zuckerman say he's willing to have increases in taxes, maybe doing it through the caps rather than the rates. And he's willing to do other things.

But I don't know if the Republican national broadcasting representative is willing to raise revenue at all So let me put it to her.

### Moderator
Claim: Okay. Can you-- can you correct your approach to Margaret Hoover?

### Moderator
Claim: Yes.

### Moderator
Claim: We-- we like to keep it pretty civil. Thank you.

### Moderator
Claim: It seems to me that this intergenerational thing with the sponsor of the thing, his introduction was less impartial than it has been in the past. He kind of was shilling for this side. And I thought that wasn't right.

### Moderator
Claim: Okay. Not a question. We're going to take one more. Do we have time for one more? Yeah, right behind-- right behind our executive producer.

### Moderator
Claim: Hi. My name is Deanna Oliver, I'm a student at NYU. I have a question for you, Governor Dean. In the introduction of your opening statement, you claimed that there isn't in fact a Social Security trust fund problem.

However, there's a problem with political collaboration and our economical stance right now. So if we are to lack progress in either of those areas which both sides have agreed to, and private sectors don't act on the opportunity which you claimed in your last response, does that mean that the future of the millennials will in fact be at risk?

### Scientific Advocate (SA)
Claim: I don't think so. And I'll tell you why.

### Moderator
Claim: Howard Dean.

### Scientific Advocate (SA)
Claim: I think the millennials are-- people have often asked should we have term limits in the United States Senate. I said no, but we shouldn't allow anybody over 50 to serve in the United States Senate. That would solve the problem. You guys are-- you've elected your first president. And now you're going to eventually take the reins of power. You are not a confrontational generation. You focus-- there's much less ideological bandwidth among your generation than there is in mine. And I actually think you are going to get to some solutions, which as soon as us older-- the political class is always the last to get it. And as soon as these guys pass onto someplace else with their deserved reward, you guys are going to be running the Senate, and you guys are actually going to sit down across what minimal ideological lines you have and get something done.

So this is going to get fixed. I'd just like to see our generation own up to it and fix it and stop yapping at each other so we'll not have to leave it up to you.

### Moderator
Claim: And Margaret Hoover.

### Conspiracy Advocate (CA)
Claim: I would just say, I-- on the one hand, I completely agree with Governor Dean. On the other hand, you're the one who just said, Paul Ryan pushed Grandma over the cliff.

### Scientific Advocate (SA)
Claim: He did.

### Conspiracy Advocate (CA)
Claim: So you resembled-- but you're resembling this partisanship that is polarizing the debate and not letting us get to the solution the millennials are trying to get to.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate. And here's where we are. We're about to hear closing statements from each debater in turn. The closing statements will be two minutes each. And remember how you voted before the debate because immediately afterwards, you will vote again. So this is their last chance to change your mind. So onto round three, closing statements.

And the first to speak against our motion, which is "Grandma's benefits imperil Junior's future," Jeff Madrick, author of "The Age of Greed: The Triumph of Finance and the Decline of America from 1970 to the Present."

### Scientific Advocate (SA)
Claim: Grandma's benefits do not imperil Junior's future. The main reason is we have so much room to raise taxes without impeding economic growth that we can handle the so- called-- not the so-called-- the Social Security debt-- what I meant was the so-called Social Security insolvency-- relatively easily. Medicare is not a problem for 10 or 12 more years, and we do as Governor Dean and I think, Mort Zuckerman and maybe Margaret agree, we have to reform that system. I am obliged to say something about Paul Ryan's plan, just because he had it scored by CBO and won some plaudits in the media does not mean it was not an extremist plan. meant triage. It meant literally triage for Medicare recipients down the road. It meant they wouldn't get covered. Keep one fact in mind because in the end I think what's generating our opposition's ire is that we have big deficits in America. If we reversed the Bush tax cuts, not only on the top 250 but for everybody, we would solve the deficit problem for the next 10 years. The deficit, the debt in America would not rise above approximately 70 percent of GDP, these are CBO numbers, not my numbers. We would be in what's called primary surplus so you see how much latitude we have to take care of these problems without jeopardizing the economic growth.

And it's economic growth that the young need because that's what creates jobs for the young, and we--

### Moderator
Claim: Thank you, Jeff Madrick.

### Scientific Advocate (SA)
Claim: --fouled that up badly so far.

### Moderator
Claim: Thank you, your time is up. Jeff Madrick. Our motion is "Grandma's benefits imperil Junior's future," and here to summarize his position for the motion, Mort Zuckerman, chairman and editor in chief of U.S. News and World Report.

### Conspiracy Advocate (CA)
Claim: Well, just about every serious review of the benefits in broad term of entitlement programs in part because of the problems that the governor mentions which is the problems in our health care system which are much more intractable than dealing with the entitlement programs' financial problems. Virtually everybody says "We've got to do somebody about that. Now, the question is, if you had to make a pragmatic judgment as to what you could do about it, I have to say to you that some of the proposals that are put forth by the other side are about as likely as-- well, you name it, as Governor Dean becoming president. I-- believe me, I've been a Democrat all my life. I would have supported him, had he got the nomination, but he did not get the nomination, and at this stage of the game he's not in that political mood But I would just say to you that these are very, very serious, serious times for us. This country is on the verge of losing a great deal of the economic energy that it has had, in part because of the failures of our political system. But we have to deal at least with those programs it seems to me that protect the elderly. And this is something I'm totally in favor of. I opposed the Bush tax cuts when they came about. I supported reinstating the tax levels when other democratic presidents reintroduced some of the Bush tax cuts. I didn't support that.

But whatever it is, we've got to do something about these programs or else in fact the burdens that they are going to imply in terms of the deficit that this country is going to have to undertake in order to deal with these programs, is going to do immense damage to the very future of the people that we're talking about. We call him Junior but I'll tell you what, whoever they are, they, their cohorts, their younger siblings, their older siblings, they're all going to pay the price and it's going to be a huge price in terms of what their future is. So my view is take the most, in a sense, the simplest way to solve it, even though there are other solutions, I don't disagree with that, that's much more difficult to do. I hope we can reform the medical system. We have to do that.

### Moderator
Claim: Thank you. Mort Zuckerman. Your time's up. Thank you. Our motion is "Grandma's benefits imperil Junior's future." And here to summarize his position against this motion, Howard Dean, former chairman of the Democratic National Committee and longest serving governor of Vermont.

### Scientific Advocate (SA)
Claim: Well, first of all, let me say we're going to take this fight to North Carolina, and then we're going to Michigan, and then we're going to South Carolina-- and then we're going to-- oh, pardon me, excuse me. of all, I’m heartened by the agreement among us. We’ve really put up a lot of the positions that I think the four of us could sit down for four and a half hours, I bet we could solve all these problems as long as we didn’t have any problems like the Senate and the presidency and the House to interfere with us, which actually means that we agree on the substance that this is a solvable problem. And what is standing in the way of the problem? Is it Grandma’s benefits or is it a political problem? The framing of the opposition who doesn’t like any kind of government is that this is a benefit problem. This is not a benefit problem. This is a governmental failure problem and an economic failure problem. So we have a broad agreement and some disagreement about how we can fix these problems. But we don’t have to go through those because there’s so much agreement here.

The question is how are we going to fix this. Is Mort right when he says, “Well, we can’t do this tomorrow”? We can’t do it if we rely on politicians to do it tomorrow, but the hallmark of this millennial generation is to cast aside the political process and just do it, do it locally, do it in the private sector, do it any way you can. So I conclude that Grandma’s benefits do not endanger Junior’s future. What endangers Junior’s future is a failure of our political system to work properly, a failure of people at the top of both the economic and government field to take full responsibility for a great country. I have no doubt that the millennial generation will restore that greatness, but in the meantime, I think it is very important for us not to scapegoat particular groups, whether its seniors or immigrants or Muslims or gays, whoever it is. We ought to put an end to scapegoating politics and focus on the real problem, which is how we treat each other and not Grandma’s benefits.

### Moderator
Claim: Thank you, Howard Dean. Our motion is "Grandma's benefits imperil Junior's future.” And here to summarize her position in support of the motion, Margaret Hoover, author of “American Individualism: How a New Generation of Conservatives Can Save the Republican Party.”

### Conspiracy Advocate (CA)
Claim: So throughout our country’s history, Americans have found the courage to do right by our children’s future. Deep down, every American knows that we face a moment of truth again. We cannot play games or put off hard choices any longer. Without regard to party, we have a patriotic duty to keep the promise of America, to give our children and grandchildren a better life. Our challenge is clear and inescapable. America cannot be great if we go broke. These are not my words, but the words from the preamble of President Obama’s National Commission on Fiscal Responsibility and Reform. This is not inflammatory language from the far right. This was a bipartisan commission by Democrat Erskine Bowles, Republican Alan Simpson, appointed by Democratic President Obama.

There is broad consensus that we are on a course of fiscal disaster. Again, not inflammatory language but language that is used broadly by Democrats and Republicans alike, embodied by this panel, Mort as a Democrat and myself as a Republican. I think Governor Dean has done fancy footwork by trying to make this about politicians and not about what the motion is about, which is that Grandma’s benefits, which we all agree-- everyone on this panel agrees-- need to be fixed. And everybody has their own solutions for fixing it. That notion that they all need to be fixed is-- it confirms the motion that there is a problem with the system, that Junior’s benefits are imperiled.

So I would just say for everyone in the audience who is in their 30s or younger, we should feel real urgency to address these problems and take on these reforms because it’s about our economic future and our economic prosperity. So please vote with us.

### Moderator
Claim: Thank you, Margaret Hoover. And that concludes our closing statements. And now it’s time to find out which side you, our live audience here at the Skirball Center, feel argued best. Our motion is "Grandma's benefits imperil Junior's future.” If you go to those keypads at your seat, it’s your chance to vote now. If you agree with the motion, "Grandma's benefits imperil-- do imperil Junior's future,” if you feel that was the better argued side, press number one, this side. If you feel the other side, the side arguing against the motion, argued better, push number two. And if you remain or became undecided, push number three. And we will lock the votes in. And I’ll have the results actually in about 1 minute and 18 seconds from now.

They come very quickly. So that concludes the argumentation portion of the evening. And because I feel that all of these sides came and argued with each other so respectfully, finding common ground even as they disagreed, I think they did a terrific job. And I just want to congratulate them all for doing that. I want to acknowledge that Slate magazine is our media partner, and this debate was being streamed live on Slate. And to everybody out in Slate land, thank you very much for watching and for participating in this. And I also want to thank the many people who got up and asked questions because I know that I set a tough standard, and it takes some guts to get up and do that. The questions actually were pretty good tonight and on topic. So congratulations to everybody who asked questions. So as you know, we do a series every fall and every winter and spring.

And this year we're trying something new. Normally we will set up these debates and the panels well in advance. But we left one blank spot deliberately this year, October 25th, almost to the last minute to put together a debate on a topic that was very, very much in the news and relevant. And we have chosen the topic. And it's going to be this: Congress should approve Obama's jobs plan. Arguing for the motion we have Cecilia Rouse. She is a labor economist who served on the president's Council of Economic Advisors, and her partner supporting the motion for the jobs plan is Mark Zandy, Moody's analytics chief economist who predicts, actually, that the president's plan will add two percentage points to GDP growth and will add 1.9 million jobs. Arguing against the plan, Dan Mitchell. He is an advocate of a flat tax and a senior fellow at the Cato Institute. And Richard Epstein, he's a law professor here at NYU.

And he describes the president's plan as, "a mishmash of taxes, subsidies and regulations." And he also describes it as, "A turgid 155-page bill." So that's going to be here and have some NYU influence. And we hope that you'll all take part, come down for that debate on October 25th. If you happen to be in Chicago on October 12th, we're also putting on a debate, the first time we're going to Chicago for the Chicago Ideas Week Festival. Peter Thiel, the controversial cofounder of PayPal who has been paying students $100,000 to drop out of college on the theory that they are wasting their time in college when they could be out building businesses as entrepreneurs. He's going to be headlining the debate in which the motion language actually is "Too many kids go to college." So everybody get on a plane to Chicago for next week. You have a full listing of this fall's debates in tonight's program and on our website.

And tickets are also available for purchase. All of our debates, as we said before, can be heard on NPR stations across the nation, including WNYC here in New York, and also it can be watched on WNET's channel 13, WLIW and NJTV. And you can also follow Intelligence Squared on Twitter and make sure to become a fan on Facebook. And you will receive a discount on future debates.

Okay. You have heard all of the arguments. You have been asked to vote twice. The motion we were listening to: "Grandma's benefits imperil Junior's futures." We've asked you to vote twice, once before the debate on where you stood and again afterwards to tell us which side you feel argued best, presented the better arguments. And so here now are the final results of the two votes. Before the debate, 40 percent were for the motion, 24 percent were against, and 36 percent undecided. After the debate, 38 percent are for the motion, that's down two percent. 56 percent were against. That is up 32 percent. And 6 percent are undecided.

That's down 30 percent. The side arguing against the motion that Grandma's benefits imperil Junior's future carries the day. Our congratulations to them. And thank you for me, John Donvan. We'll see you next time.
