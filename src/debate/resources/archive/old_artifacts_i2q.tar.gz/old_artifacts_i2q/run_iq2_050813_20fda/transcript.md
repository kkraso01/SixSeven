# Debate Transcript

Topic: The FDA'S Caution Is Hazardous To Our Health
Motion: The FDA'S Caution Is Hazardous To Our Health

Debate ID: 050813%20fda


## Round 1

### Moderator
Claim: I want to welcome to the stage the chairman of Intelligence Squared U.S., Robert Rosenkranz.

Hi, Bob.

### Moderator
Claim: Hi.

### Moderator
Claim: So, Bob, in all of the debates we put on, we try to-- we try to pick issues where there's some kind of real tradeoff. And in this debate, what are the tradeoffs that we're talking about?

### Moderator
Claim: Well, the major one here: of course, the FDA's job is to see that drugs that come on the market are both effective and safe. And that's a worthy goal. But the longer it takes to get a drug approved, the more arduous that process, the more people don't get the drug who might need it, in some cases, with absolutely dire or fatal consequences. So there are huge costs to delay, just as there are huge benefits to protecting the market from unsafe drugs.

### Moderator
Claim: This agency that we're talking about, the federal-- Food and Drug Administration, has roots that go back to 1906, Teddy Roosevelt era. Science was at a different place then. How much is the advancement of science actually part of what this debate is about?

### Moderator
Claim: Well, I think the advance of science is a very key part of the debate because so many of the drug therapies operate-- today operate on a molecular level, where our genetic composition is an important determinant of how the drug is going to affect our bodies. And that means that the old paradigm of trying to figure out a drug that does good for everybody and harm to very few people is really kind of outmoded. The better paradigm today is the really custom-tailored drug that takes one's own individual genetic composition into effect. And the pro the motion side is probably going to say that the FDA simply hasn't adapted to that degree of scientific advance.

### Moderator
Claim: What about the other side?

### Moderator
Claim: Well, the other side is going to say this requires larger tasks, bigger sample groups, more amount of time to really winnow out these individual differences in response.

### Moderator
Claim: Well, we have four debaters who have not only been arguing this debate, but some of them have actually been involved with the FDA directly. So they're going to know what they're talking about. And let's welcome them to the stage. Ladies and gentlemen, our debaters.

You're all doing great with the applause requirement. And because of that, I just want to ask you one more time to give a round of applause to Bob Rosenkranz. Thank you. So you open up a bottle of a prescription drug that your doctor told you you need to take to get better, that little brown bottle. You've got the pill in your hand, and you're putting it on your tongue, and you're about to swallow it when you hear a disturbingly familiar voice in your head. And that voice says this: "You should not take this drug if you're not able to stand up or sit upright for 30 minutes, have severe kidney disease, low blood calcium or are allergic. Call your doctor right away if you develop new or worsening heartburn, difficult or painful swallowing or chest pain. If you develop severe bone, joint and/or muscle pain. Side effects in studies were generally mild and include stomach pain, indigestion, heart burn, or nausea." And what is that? That is FDA speak. That is the voice of Uncle Sam, Uncle Sam actually in the form of the Food and Drug Administration telling you to be careful to exercise caution because that is the mission of the Food and Drug Administration going back more than 70 years. But what if, as some say, the FDA is actually going too far, is overdoing it, is actually causing harm? Well, that sounds like a debate. So let's have it. Yes or no to this statement: The FDA's caution is hazardous to our health. A debate from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters, two against two, who will be arguing for and against the motion, the FDA's caution is hazardous to our health. Our debate, as always, goes in three rounds. And then the audience votes to choose the winner. And only one side wins. Let's meet our debaters. First, Scott Gottlieb. He's a physician and former FDA deputy commissioner. His partner is Peter Huber. He is a senior fellow at the Manhattan Institute. On the side arguing against the motion, that-- arguing the FDA's caution is not hazardous to our health, we'd like to introduce Jerry Avorn. He is a professor of medicine at Harvard Medical School. And his partner is David Challoner, vice president for health affairs emeritus at the University of Florida. Our motion is the FDA's caution is hazardous to our health. Let's meet the team arguing for the motion first. Let's welcome, again, Scott Gottlieb. And Scott, you are a physician. You are a former FDA deputy commissioner. You've worn a lot of your hats in career-- the jobs at the FDA. You're a doctor. You've also been an analyst on Wall Street at one point. I'm curious. What about medical school prepared you for Wall Street? Anatomy class?

### Conspiracy Advocate (CA)
Claim: I had to make important decisions based on imperfect information.

### Moderator
Claim: Ah. That is a very, very clever answer. Ladies and gentlemen, Scott Gottlieb. And Scott, your partner is?

### Conspiracy Advocate (CA)
Claim: The always provocative Peter Huber.

### Moderator
Claim: Ladies and Gentlemen, Peter Huber. Peter, you are also arguing for the motion, the FDA's caution is hazardous to our health. You're a senior fellow at the Manhattan Institute. Speaking of people doing a lot of different things, you have a doctorate in mechanical engineering from MIT. You have clerked for Ruth Bader Ginsburg and Sandra Day O'Connor. You write about energy and technology. Your forthcoming book, “The Cure in the Code,” is about drug policy. What have you not that you still need to get to in life?

### Conspiracy Advocate (CA)
Claim: Well, mostly, I'm just hoping to overcome my intellectual attention deficit disorder.

### Moderator
Claim: Ladies and gentlemen, Peter Huber-- who claims to have attention deficit disorder. I think not. Our motion is the FDA's caution is hazardous to our health. And here to argue against the motion-- first, let's welcome Jerry Avorn. Jerry, you hold the position at the Department of Medicine at Brigham & Women's Hospital as chief of the Division of Pharmacoepidemiology and Pharmacoeconomics. Would it take you an hour to explain to us what those things mean?

### Scientific Advocate (SA)
Claim: No. It is the study of balancing the risks and benefits and cost of medications as they're used in routine care of patients.

### Moderator
Claim: Nine seconds. Ladies and gentlemen, Jerry Avorn. And Jerry, your partner is?

### Scientific Advocate (SA)
Claim: Oh, David Challoner.

### Moderator
Claim: Ladies and gentlemen, David Challoner. David Challoner is vice president emeritus for health affairs at the University of Florida. David, you did medical school. You got your MD. But then you decided to spend your career not seeing patients day in and day out, but to go into the research side. Why did research pull you?

### Scientific Advocate (SA)
Claim: I went to Harvard. My faculty told me I had to.

### Moderator
Claim: And in those days, you did what the faculty told you to do. Ladies and gentlemen, David Challoner. Our motion is the FDA's caution is hazardous to our health. As always, we have you, the audience, choose our winner by your vote. And we have you vote twice: before the debate and once again afterwards. And the team whose percentage numbers have moved the most will be declared our winner. So, let's go to our first vote. If you go to those keypads at your seat-- I'll restate the motion. And if I-- as I restate it, you say, “I agree with that,” you push #1. And if you disagree, you push #2. And if you're undecided, which is a perfectly honorable position, by the way, you push #3. You can ignore the other keys. The FDA's caution is hazardous to our health. So, I'll wait 10 or 15 seconds while everybody does that vote. Okay. It looks like it was handled well. So let's move on to the actual debate. And again, I'll remind you, we'll have you vote at the very end. And in terms of how long it takes to get the results, it's under a minute. So it'll be very quick turnaround at the end. Onto Round 1. Opening statements from each debater in turn. They will be seven minutes each. The motion is the FDA's caution is hazardous to our health. And here, speaking first for this motion, Scott Gottlieb. He is a practicing physician, a resident fellow at the American Enterprise Institute, and former FDA deputy commissioner. Ladies and gentlemen, Scott Gottlieb.

### Conspiracy Advocate (CA)
Claim: Thank you. To understand why FDA's caution is hazardous to our health, you have to appreciate FDA's growing focus on statistical outcomes over results for patients. Fading at FDA is a mindset of clinical medicine and patient care. And in it is a growing fixation on the statistical results, clinical trials, and a growing rule by math over medicine. This mindset can be seen in the triage that now hamper clinical trials and drug development. FDA imposes increasingly onerous experiments to try to ferret out benefits from new drugs. And FDA reviewers want the results of clinical trials to insulate them from critics; critics who say they're not doing enough about drug safety. But the laborious trials that result come at a very big, human cost. Higher degrees of statistical certainty under FDA's outdated way of designing drug trials require longer, larger, and increasingly impractical studies, especially when it comes to drugs targeted to unmet medical needs. Some promising therapies simply aren't being developed. Let me tell you one story of how this mindset impacts patients. Hunter's Syndrome is part of a family of related and extremely rare disorders. All are inherited. Each robs children of the ability to produce a crucial enzyme that's used by the body to break down certain sugar molecules found in the blood. Missing these enzymes, these molecules end up accumulating in places like the liver, and the spleen, and the joints, with often painful and debilitating consequences. Before treatment came along, parents had to literally sit idly by and watch as these diseases destroyed their children. But by the 1990s, drugs were developed that could function as replacements for the enzymes that were missing in these related disorders. These disorders were so bad and the drugs were so promising that the first of these medicines, a drug for Gaucher’s Disease called Ceredase, was approved on the basis of a very simple clinical trial that involved only a dozen patients. By 2004, FDA had approved enzyme replacements for four other conditions that were each very similar to Hunter's Syndrome. All were lysosomal storage diseases, where kids were born missing one of these crucial and related enzymes. It was understood that if you could replace the enzyme, these children were likely to derive a therapeutic benefit. But when an experimental enzyme for Hunter's Syndrome finally came along, a decade after that original drug was approved for Gaucher’s Disease, FDA's regulatory norms and FDA's regulatory culture had changed dramatically. In an effort to satisfy an increasingly demanding desire for statistical certainty, the FDA trial imposed extraordinary hardships on the children and their families. In order to approve the Hunter's drug, called Elaprase, FDA required that the trial enroll 96 patients. This was fully 20 percent of all the Americans afflicted with the disorder. And instead of testing the drug for six months, as had been done for every other drug, all of these enzyme replacements, FDA wanted a full year of clinical data, 52 weekly infusions in these kids. FDA also insisted that the kids be randomly assigned to receive either a drug or a placebo. There was no need to have a placebo in this clinical trial. The disease follows a very predictable pattern. And doctors already knew the normal decline these kids would have if they were left untreated. But leaving some kids untreated was basically leaving them to become disabled. Yet, including the placebo helped give the trial itself more statistical rigor for FDA.

Finally, in past trials, with all these lysosomal storage drugs, these enzyme replacements, drugs targeted to similar diseases, FDA asked companies to measure surrogate markers that the-- the drug was having an impact on disease. Like the ability to shrink organs, like the liver and the spleen. That was interpreted as proof that the drug was breaking down the sugar molecules and they weren't becoming deposited there. And this would mean that the enzyme replacement was working. By looking at these surrogate measures, which you could measure over a shorter period of time, it was a way to accelerate the development of the drug. But in the case of the Hunter's drug, Elaprase, FDA decided to test the ability of the children to walk and to breathe as the clinical outcome it wanted. FDA saw this as a more rigorous way to see if the drug was working, but it came with hard trade-offs. It made the trial much longer than it needed to be. You had to wait years for the kids to become disabled to see if the drug was having its impact and to measure the result. And it tested the boundaries of what was ethical. Yet, this story is increasingly the norm when it comes to FDA review culture and it's played out multiple times in recent years, so much so that observers who follow the FDA now believe that the Europeans have become more flexible when it comes to drugs targeted to unmet medical needs than the Americans. The drug for bone cancer, the drug Pirfenidone for ideopathic pulmonary fibrosis, the drug Tafamidis for familial amyloidosis, all rejected by FDA in recent years because the statistical results didn't meet the agency's requirements, all approved in Europe, all embraced by European regulators. To understand why FDA's caution is, at times, hazardous, you have to recognize FDA's growing resolve to make sure the trials supporting drug approval meet an arduous but increasingly outdated standard for proving efficacy. As my debate partner, Peter Huber will show, this outdated model that FDA uses exacerbates these problems by making trials much more inefficient than they should be and allowing us to learn far less from the results than we otherwise can. Yet surveys of people with life-threatening disorders continue to show that patients want access to promising drugs sooner. They're willing to tolerate some risk. They're willing to tolerate the uncertainty. For patients with unmet medical needs, what kind of FDA do we want; an FDA that advances care, an FDA that gets new science to the patient more quickly? What we can't have is an FDA that's ruled by statistics over medicine. We can't have an FDA that focuses on its process rather than advancing patient care.

Americans deserve a less cautious FDA and an FDA that actively embraces advances in science. Thank you.

### Moderator
Claim: Thank you, Scott Gottlieb.

Our motion is “The FDA's Caution is hazardous to our health.” Our next debater is going to speak against this motion. Ladies and gentlemen, Jerry Avorn is a professor of medicine at Harvard medical school and chief of the division of pharmacoepidemiology and pharmacoeconomics at Brigham and women's Hospital. Ladies and gentlemen, Jerry Avorn.

### Scientific Advocate (SA)
Claim: Thank you very much. It is certainly the case that FDA, like any big organization, will occasionally not get things right. And I don't know the rare disease that Dr. Gottlieb mentioned, but I think we can all agree that in this very difficult balancing act of, “Is this drug going to help patients, is it going to perhaps make them sicker?” it is not an easy call. But I think the most important aspect of the question before us is, in general, do we want to have an FDA that is thinking very hard about risks and benefits and is requiring that the manufacturers who bring drugs to the FDA demonstrate that, in sum, the drug is going to be better for patients and not run the risk that we have all seen in recent years of a Vioxx or an Avandia that actually caused heart attacks and strokes because those problems were not detected. Now, there are a number of myths that underlie the proposition that I think it's important to just dismiss early on. One is that somehow FDA is the reason that we don't have more new drugs and that FDA is slower than other regulatory agencies. And in fact, these are questions that one can look at with real data. And the real data do not bear out the assertion that Dr. Gottlieb is defending. There is a very high acceptance rate by FDA of new drugs. In an article in Forbes from last December, it documented that 77 percent of drugs are approved the first time around, and a very high proportion of the ones where FDA says, “Please go back and find some more information out for us,” are then approved the second time around. In 2012, the FDA approved 39 new drugs, which was way higher than it has approved in any number of years for the last 16. It was a 16-year high. So FDA is indeed saying yes to drugs, and it is doing so at a rapid clip. That's the other myth that we need to disabuse ourselves of. In fact, the salaries of the FDA staff that review drugs are, for better or worse, half paid by the drug industry, which creates with it some deadlines that, as a result of the so-called user fees, the FDA must have its deadlines met. And for a priority drug, which is an important new drug that brings something to the table that we don't already have, that is needed by patients, that deadline is six months. And in the last year, 33 out of the 35 drugs that were brought to FDA met their standard, whether it was six months for a priority review or ten months for a standard review. You need a lot of time to be able to look at all of the adverse effects that happen, what is the degree of benefit. And again, I'm sure that there are instances where it could have been done better. And there certainly are ways that, as was mentioned in the early presentation by Mr. Rosenkranz, where we would like to be bring in genetics and bring in new molecular theories to approve drugs. And that's great, and FDA is trying very hard to move in that direction. But in fact, FDA is saying yes most of the time. It is approving drugs quickly, as per its requirements. And in a paper last year in the "New England Journal of Medicine" by Dr. Ross and colleagues from Yale, reasonable university, reasonable journal, they look at whether or not the FDA was in fact slower than other regulatory agencies. And so they looked at the European medicines agency, which is the pan-European FDA equivalent, and Health Canada which is the Canadian version of FDA. And it found that, in fact, review times in the U.S. were shorter for FDA than they were for the Europeans and for the Canadians. And in fact for drugs that were approved in both places, 64 percent of the time they were approved first in the U.S. before in Europe, and 86 percent of the time, they were approved in the U.S. before Canada. So the myth that somehow FDA is slowing things down is not borne out by the facts. The reason we don't have as many new drugs as all of us on this stage and the audience would like to have is because the pharmaceutical industry is not bringing a lot of new drugs to FDA to approve. And they can't approve a drug that is not submitted to them. And yet they have this tension because they need to be able to have a drug brought to them, and yet they know, and we know, that manufacturers' enthusiasm, to put it as kindly as we can, about a product that they're trying to market, is perhaps not always going to catch all the down sides. And we've all seen examples of that. So there needs to be an agency that represents the best interests of the American public and can say to the manufacturer, “That does sound promising, but there are some things that you really need to look at, and if it's an important new drug, we'll get you an answer in six months.” I don't think that's too much to expect of a company to do, especially since we know that any drug that is powerful enough to make a difference in patients' lives is also powerful enough to do something that we don't want it to do and didn't expect it to do. And one cannot know that because of enthusiasm or because of medical need. There does need to be a cautious agency out there looking at drugs. And Dr. Challoner later will talk about devices, which is the other piece of FDA's responsibility besides food, which we're not going to get into. And we need to have something interposed between an enthusiastic company, which has billions of dollars riding on the success of its product, and the public health of the American people. And there needs to be a rigorous review. That rigorous review can be done quickly, it can-- and it is being done quickly. It is generally favorable. And just because we can make it better by informing it with genetic and other kinds of biological discoveries doesn't mean that we don't still need to have a traffic cop, kind of like an air traffic controller. We all saw a couple of weeks ago what happens when we have big government back away from having enough air traffic controllers. The FDA is the air traffic controller for our drugs, and that is why we need their caution. It is not the case that it's causing public health problems. In fact, they have gotten faster and faster over the past decade. And as a result, they are proving that they can help the American people be protected from drugs that have bad effects. And that's exactly what we need them to do. And that's why I think that it is important to vote against the proposition that FDA's caution is hazardous to our health. Thank you.

### Moderator
Claim: Thank you, Jerry Avorn.

And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion: The FDA's caution is hazardous to our health. You've heard the first two opening statements, and now onto the third. Debating for this motion that the FDA's caution is hazardous to our health, I want to introduce Peter Huber, a senior fellow at the Manhattan Institute and author of the forthcoming book, "The Cure in the Code: How 20th Century Law is Undermining 21st Century Medicine." Ladies and gentlemen, Peter Huber.

### Conspiracy Advocate (CA)
Claim: Well, in case you didn't know, our side actually won the first round of this debate in 19-- no, in 1992, when we persuaded the FDA to adopt what is called the accelerated approval rule. Now, I must confess that the rule has been applied not very widely, but in two particular areas and not with whole-hearted enthusiasm, especially of late. But I intend to persuade you that this rule is, in fact, the only place that FDA today for we are actually making use of the very best, modern pharmacological science that we have. It is in fact the protocols that the FDA uses much more often, the un-accelerated approval, if you will, where we are actively obstructing the use of those technologies and is, therefore, in the standard protocols that the FDA has been using for a very long time that the FDA is actually hazardous to your health.

Let me begin by giving you some brief context and a description of where this rule has been applied. Go back to 1988, a couple of biochemists from the United States and one British win a Nobel prize for their mastering of what is called a structure-based design. And this is one of the two processes that they've been using ever since to design, precisely, targeted drugs that can hone in on a molecule that is associated with some disease. This is some years after HIV arrived in town. And they quickly developed several drugs that can target different parts of HIV's chemistry, which, until very close to that time, had been completely incurable. The FDA licenses these drugs at absolutely record speed, applying its accelerated approval rule. And it soon becomes apparent that not one of them is going to be any good; not for long, not on its own. Because the virus mutates so fast that you throw any single drug at it and it very quickly develops a resistance to it. You just can't beat it with one drug. But doctors at this point, because the drug's been licensed, are now free to work things out on their own. And they very quickly began assembling these drugs in cocktails and that does the trick.

The other-- the second area where the rule has actually been applied quite aggressively for the last 20 years, is oncology. And it's-- here's a brief picture of the kind of medicine that has emerged in that area. There are at least 10 biochemically distinct breast cancers out there. It's not one disease. We treat some of them with estrogen blockers. We treat others with estrogen itself. Okay. One of the estrogen blockers performs well only if you have the right liver. It depends-- it has to be metabolized by your liver. You know, some patients have the right liver, others don't. There are at least two other major receptors and two classes of drugs in breast cancers. And you mix them all up in various ways to try and beat the disease in the individual patient. We're finding similar levels of complexity and diversity in almost all of the major intractable diseases we're facing now: the neurological, the autoimmune diseases, and indeed, in many very common diseases like diabetes; they just aren't going to be beaten with one size fits all drugs. The underlying chemistry isn't going to allow it, which is bad news for the FDA, because the FDA's standard protocols are actually pretty good at getting licensing one size fits all drugs. But they are worse than useless, it turns out, when they encounter complexity. Using accelerated approval, the FDA can, in fact, handle complexity reasonably well. And it's going to do it even better.

In your book, Dr.-- I'd surmise you'd not like this rule at all. You attribute its origins to AIDS activists who terrified the agency with a massive sit-in. Here's another view. The rule has allowed for the development of pioneering and lifesaving HIV and cancer drugs over the past two decades. That quote’s from President Obama's Council of Scientific Advisers in a report issued last September; and the report recommends that the FDA use accelerated approval much more systematically and broadly for all drugs that address an unmet need in treating a serious illness. Notice-- this is why we have one lawyer for three doctors. Notice that the report did not endorse accelerated approval because it got drugs to patients sooner. It said that the rule allowed for the development of those pioneering drugs. But for the rule, we probably wouldn't have many of those drugs at all, which means that the benefits of that rule have absolutely dwarfed anything that our opponents here can possibly tell you about the rare side effects that might have been missed when that rule was applied. HIV has killed an average of about 20,000 Americans a year in the 30 years since it's surfaced in the United States. The numbers would have been horrendously worse if for the last 20 years we didn't have some good treatments for the disease in the place. We owe 40 cancer drugs and 15 new treatments to accelerated approval. They have given years of additional life to many patients. There is no story about safety and side effects that can possibly approach those numbers.

So this magic rule doesn't just get us the drugs we need licensed faster. It gets them licensed when the other-- the FDA's other rules, the slow rules, just won't license them at all. How? In brief, it-- what it does is it loosens the FDA's grip on-- throttling grip on the process just enough to let doctors get involved and work out the really good drug science using the very best tools available. I want to briefly take the time to tell you how this is working, because, you know, it's not really that complicated and you can make your own judgments about how whether it makes sense. First of all, ordinarily, the FDA won't license a drug until it sees clinical symptoms. Accelerated approval will let you license a drug based on, say, its ability to lower HIV loads in the patients' blood.

And by the way, it works in only one in 10 patients. The FDA can still license it. It'll make an ad hoc: “Oh, gee, that looks promising. We want it.” Okay? Under accelerated approval, therefore, the drug gets licensed much sooner. But it also gets licensed on a very different kind of evidence. The White House report makes clear that this is exactly what we should do. We should start with the premise that when we have a new drug, it may well be only one piece of a solution that's giving only partial benefits to a minority of patients involved in the-- you're sort of enlisted in the drug trial.

The FDA standard protocols allow nothing of the sort. Under the current application of the rule, the FDA, again, in a very ad hoc way, says the drug company-- says to the drug company implicitly and doctors explicitly, “Look, work out the stuff-- the rest, you know, once you got the drug out there,” as they did with HIV. The White House report would systematize it. You know, you would gather torrents of information during the trials. And you would-- and you would use those to work out a drug-- molecular information. You'd use those to work out how the patients are doing and why some are faring well on the drug and others aren't. That kind of screening of patients and active rearranging the trial as it progresses is anathema under the standard FDA protocols. You're not allowed to do it at all.

When you do it, you actually get to precision molecular medicine. You work out how a drug can be precisely prescribed to patients and used just right. The FDA is frozen in the headlights. It can't deal with these torrents. It has no experience with them. You need big computers to do it. It is hazardous to your health because it can't use the science. Thank you.

### Moderator
Claim: Thank you, Peter Huber. You know, I think you could actually do one of those FDA commercial things, where you read the-- where you read the side effects really fast. That was really well-- that was pretty quick paced. Well done. Our final debater against this motion, the FDA's caution is hazardous to our health, is David Challoner.

He is vice president emeritus for health affairs at the University of Florida. He chaired the Institute of Medicine's committee on the public health effectiveness of the FDA 510(k) clearance process. Ladies and gentlemen, David Challoner.

### Scientific Advocate (SA)
Claim: Thank you, John, and members of the audience. I will be speaking, as was said, against the motion that the FDA's caution is hazardous to your health, in particular, as it relates to the device side of the equation.

The FDA is a public health agency. It is responsible for the safety and efficacy of the devices that are used by you, on you, and put in you. If anything, the anecdotes of the last decade would indicate that we need more caution in our systems. The evidence-- I think this will reverberate with most of you. The Shiley heart valve, implanted in patients, many patients, begins after several years shattering and embolizing to your brain and to your peripheral body and killing some patients before they could be replaced. The Dalkon Shield IUD: put in women, causing perforation of the uterus, pelvic infections, some deaths, much trauma. Chemotherapy infusion pumps, which were poorly calibrated so that the operators could make mistakes and would infuse drugs, toxic drugs, at ten times the rate that they should have because the wrong button was pushed, killing patients. Surgical mesh, vaginal mess. You've all seen these ads from the legal firms, I'm sure, soliciting your business. This was a surgical mesh that was used for hernia surgery and then was transformed to be used and promoted to be used in pelvic surgery for women with disastrous infection, and prolapse, and a variety of other results. Radiotherapy machines-- a liner accelerator. Again, without maximum controls, 10 to 20 times the dose is given to a patient for a pulmonary tumor and drills a hole through them. Pacemaker leads: put into you to manage your cardiac rhythm. And then after two or three years, widely distributed, many people not knowing they have them, breaking, and arrhythmias and other cardiac rhythm disasters were occurring. Metal on metal artificial hips. None of you could have missed that. Removed poorly, monitored in this country, used widely. Now, giving medical-- a metal embolism into patients and causing resurgeries and removals. Biliary stents that were approved for use in a very low pressure environment began to be used widely, and promoted widely by industry, for use in veins and arteries elsewhere in the body, in which they collapsed or did not work.

So I'd say, with this kind of evidence, that the case is almost closed, and we could vote now. But I think the audience needs to understand exactly how we got to the point we're in. What is the process that has produced these problematic results? Well, the vast majority of medical devices used in healthcare in the United States are reviewed by the FDA before entering the marketplace, and are cleared. That's a very important word. They are not approved for human use in a process called premarket notification, or the 510 clearance process, which is named after the section of the authorizing legislation in 1976. And the FDA has to comply with this because it's legislated that they do so. And this was done 35 years ago in the face of rapidly evolving technologies. Then, stimulated by reports of problems, the public, legislators, the general accounting office, the DHHS inspector general and the courts, including the Supreme Court of the United States, have all questioned the value and logic of this clearance process which is being used by a federal agency charged with protecting and promoting the public's health. What are the major elements of this process? Well, premarket, before a device goes out and is sold to you or your doctor or your hospital, for no-risk devices such as tongue depressors or manual wheelchairs, for instance, there are about two-thirds of those that are considered by the FDA and go to market directly and are considered basically of no- or low-risk. The high-risk devices comprise about 1 percent of what the FDA device regulatory folks must deal with. And they do have to have costly and time-consuming premarket trials before approval. There's some question whether, in the device case, they are as powerful as those which already exist for drugs.

The moderate risk 510(k) is the large middle ground. That's about 4,000 applications a year, and it's about a $3 billion a year industry, a very significant business. The 510(k) process was put in place by Congress and is not intended to evaluate the safety and effectiveness of devices. It cannot be transformed into a premarket evaluation of safety and effectiveness as long as the standard for clearance is substantial equivalence to a previously cleared device perhaps as early as 1976 or prior. So these are called predicates. And there's no assurance that a predicate is safe and effective. There's no practical way to remove these undesirable predicates, and you therefore have a daisy chain of approval requirements in the process.

## Round 2

### Moderator
Claim: Thank you, David Challoner. And that concludes Round 1 of this Intelligence Squared U.S. debate where our motion is the FDA's caution is hazardous to our health.

Now we move on to Round 2. And Round 2 is where the debaters address one another directly and take questions from myself and from you in the audience. Again, stating the motion, the FDA's caution is hazardous to our health. And as we begin Round 2, we have heard from Scott Gottlieb and Peter Huber arguing for this motion. They're arguing basically, as Scott Gottlieb put it, that statistics are taking precedence over medicine at the FDA, that they're falling into the trap of statistical certainty, needing a level of certainty that is just out of control to the point where it's slowing down process, discouraging innovation, and therefore denying access to devices and products, pharmaceutical products that could actually save lives. They point out that Europe is approving drugs that the FDA is actually denying. And they say that the fact that some drugs actually get a special fast track suggests that there's something wrong with the slow track.

The side arguing against the motion, David Challoner and Jerry Avorn. Vioxx. They point out the case of Vioxx and other instance-- instances of pharmaceuticals that made it to the market and killed hundreds of people. They've talked about devices that have poisoned and lacerated the insides of women. They also deny the argument that the FDA is slow to approve. They point out that 70 percent of pharmaceuticals are approved the first time around, and if anything, they say, what’s needed in the FDA is not less caution, but more of it. The question I want to put to this side-- it's not really a debate point. I'm looking for some clarification, and I just want to see if you will agree to their clarification, because I think we in the audience-- myself and you in the audience, need a little bit of a picture first of what it is we're talking about when we talk about a classic FDA drug trial. You've referred to it; I don't see it.

So Scott Gottlieb, if you could take 45 seconds outside of your debate time to tell us what is Phase I, Phase II, Phase III? Who's involved? How long does it take? What does it cost? And with the understanding that this is that system that you're talking about that-- that you're challenging.

### Conspiracy Advocate (CA)
Claim: Right. Well, I think that the issue really is development times, not review times, as Dr. Avorn talked about. He was focusing on review times, how long does it take FDA to look at the applications? Really the issue is how long does it take to develop the drugs. On average, it takes about nine years to develop a drug for endocrine disorders, about six years to develop a drug for cancer. It has to go through typically three phases of clinical trials. The first phase is looking for proof of activity; second phase is looking for - -

### Moderator
Claim: And what you do is you go, and you get a group of patients, maybe 25 patients?

### Conspiracy Advocate (CA)
Claim: Depending on the disease, you're either doing it in healthy volunteers or in sick patients in you have a drug targeted to a-- you know, a rare cancer or something that's fatal. You're going to put the drug in Phase I in patients who are already sick. But typically if it's a drug targeted at, let's say, hypertension, you're going to put it in healthy volunteers. And in Phase I, you're looking mostly at safety, although they're starting to look at issues of efficacy, and you're starting to look at issues of dose.

### Moderator
Claim: Phase II, you're looking at?

### Conspiracy Advocate (CA)
Claim: Phase II, you're looking at proof of concept. You want to see if the drug works. You're not necessarily assessing the clinical outcomes in the clinical trial, but you're looking at indication that's the drug is having the activity that you anticipated.

### Moderator
Claim: And that's more people.

### Conspiracy Advocate (CA)
Claim: And that's more people. And depending on the disease you're looking at, it's anywhere from-- it could be a couple of hundred in a cancer trial to, you know, 5,000 in a primary care drug.

### Moderator
Claim: Phase III?

### Conspiracy Advocate (CA)
Claim: Phase III is the pivotal trial. It's the registration trial. Depending on the disease you're looking at, it could be a couple of thousand patients in a cancer trial at a cost of about $100,000 per patient enrolled in the trial. And in some cardiovascular trials, you're looking at trials that enroll 40- or 50,000 patients. And there, you're looking for statistically rigorous evidence that the drug has a clinical effect on the desired outcome.

### Moderator
Claim: Okay. Does this side agree that that's essentially the structure of the classic trial since 1962?

### Scientific Advocate (SA)
Claim: Yes, with the proviso that Dr. Gottlieb said, something very important, which is how much time does the company take to develop a drug as opposed to the matter at hand - -

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --which is how long does FDA take to review it, which is really what we're concerned with.

### Conspiracy Advocate (CA)
Claim: But you can't--

### Moderator
Claim: Whoa, whoa, whoa.

Just-- I'm going to let this unleash in just a second. I-- so I just-- I-- I personally felt I needed to hear that to understand what the heck it is we're talking about.

### Moderator
Claim: Well, you don't yet.

### Moderator
Claim: So thank you for that. And I'm glad that you mostly agree with it. But before we debate the specifics, because I think debating the specifics is what we're going to be doing, I just want to take the large question to this side, that this side put to you, which is that that system that they described, they are arguing-- I'm going to call it the slow track. You can object to that language. I just want to distinguish it from the fast track. They're saying the fact that the fast track had to be developed-- and I think this does date to the-- to the midst of the AIDS crisis and was accepted, and it worked, and drugs got out there, and they saved lives, establishes that that regime, that one, two, three trial thing since 1962, is a problem. It's slow. It's not saving lives. And I want to-- I want to take that point that the existence of a fast track actually wins the debate for them. Jerry Avorn.

### Scientific Advocate (SA)
Claim: I think it was helpful that Mr. Huber gave us his views about the FDA approval process in that regard. I think it was less helpful when he gave the audience my views about that because he got it wrong. In my book, I indicated that, yes, the fast track did come from AIDS activists scaring the hell out of the FDA because they were so horribly slow. And that was a good thing. And that happened in the late '80s and early '90s, and FDA got better because of that excellent pressure from the AIDS community. And in the presidential panel's report that you mentioned that advocates that FDA needs to figure out more creative ways to move forward in that direction, that's also something I approve of because I was on the panel that helped write that report. So indeed, this is something good, and we’ve got to not fight the last war and say it was terrible in 1989. And now we have a fast track and keep complaining about how things were in 1989. The fact that there's a fast track makes sense, because some drugs are really breakthroughs. And you want to use the limited resources that FDA has to move things forward.

### Moderator
Claim: Fast-tracking the entire array of drugs make-- be an incautious--

### Scientific Advocate (SA)
Claim: No.

### Moderator
Claim: --thing to do?

### Scientific Advocate (SA)
Claim: It would be an unwise use of limited resources, because we don't need to fast-track the next statin of which we already have plenty.

### Conspiracy Advocate (CA)
Claim: I-- forgive me, but--

### Moderator
Claim: Peter Huber.

### Conspiracy Advocate (CA)
Claim: --this just isn't an accurate description. And first of all, fast-track is a quite different term used by FDA. It is not the accelerated approval. You know, call it whatever you like, but they are different things.

### Moderator
Claim: Okay--

### Conspiracy Advocate (CA)
Claim: On the accelerated-- look, but this is absolutely unequivocal. Under the accelerated approval rule, you cut off a big chunk of what the FDA's normal rules do. You actually cut off in the middle of Phase III or Phase II. Or-- and some people are pushing to cut off after Phase I, because the results are so dramatic there, okay? You are actually not doing what is normally required

### Scientific Advocate (SA)
Claim: And Peter's--

### Conspiracy Advocate (CA)
Claim: As-- wait just as second. And who does it, then? Because you still have to finish. And the answer is, you do it-- by and large, you do it in Phase IV. And a lot of doctors out there are now also using the drug. And they are working completely independently and they are the ones who are using the modern tools to work out how to fit these rather simple drugs to our extremely complex bodies. They're finding the biomarkers on efficacy and safety. These are all emerging later. They are getting the precision medicine. And nowhere else in the FDA protocols you get that. It never emerges during the standardized conventional protocols. You are blinded all the way through. There is no Bayesian adaption during the trials. There's--

### Moderator
Claim: There's what? Just wait-- I don't know-- I don't know--

### Conspiracy Advocate (CA)
Claim: --you just don't get the information, okay?

### Moderator
Claim: No. No. I'm not saying it to mock you at all. I'm saying it because I don't understand in using terms of art, which, if you took a minute to explain actually would help us all.

### Conspiracy Advocate (CA)
Claim: I put in one word, Bayesian. That means that you're actually--

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: --that you're--

### Moderator
Claim: I was lost.

### Conspiracy Advocate (CA)
Claim: It means you're actually looking at the data as you go and learning from it as you go and adapting to it. And the FDA--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --is so concerned about something called selection bias, they don't allow it all.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: I would just add to that the FDA has actually been backing away from the accelerated approval rule in recent years, so much that the Congress had to re-codify it and reach a legislation to say, “We really meant it. We want you to use this try to”--

### Moderator
Claim: Okay, so just so-- to understand, because I'm getting the gist of it. You think that's a good thing. This is a good development. I-- because I want to--

### Conspiracy Advocate (CA)
Claim: It--

### Moderator
Claim: --these guys-- what do you think about it?

### Conspiracy Advocate (CA)
Claim: It is. The only place we are actually developing modern drugs--

### Moderator
Claim: Okay. All right.

### Conspiracy Advocate (CA)
Claim: --are-- start at the molecular level.

### Moderator
Claim: What about--

### Conspiracy Advocate (CA)
Claim: Nowhere else FDA.

### Moderator
Claim: What about their argument for accelerated approval?

### Scientific Advocate (SA)
Claim: Well, I have trouble with that. Unless it's linked on the other end with post-market surveillance. I mean, if you're going to short circuit the safety of the public on the front end of these approval processes, whether for devices or for drugs, then you've got to make sure that you have a credible early warning system on-- you know, to prevent the Russians from coming in over the-- from the Arctic Circle. But an early warning system that will allow the immediate understanding of the various communities involved here to feed back, to get that drug or get that device--

### Moderator
Claim: Why do you call it--

### Scientific Advocate (SA)
Claim: --off the market.

### Moderator
Claim: Why do you call it “short circuit the safety of the American public”? It's very pejorative.

### Scientific Advocate (SA)
Claim: That is-- well, if you're going to short circuit on the front end, sure--

### Moderator
Claim: But why short-- why-- the-- I think their term would be make it more efficient, save time, save lives. You say “short circuit safety.”

### Scientific Advocate (SA)
Claim: I think--

### Moderator
Claim: Why do you think it's-- you're saying it's dangerous. Why?

### Scientific Advocate (SA)
Claim: I think it's dangerous because unless you can have early detection of problems on the-- on the post-market side, you are endangering the public.

### Conspiracy Advocate (CA)
Claim: Look-- and I couldn't agree more, but let me tell you something. The whole notion that you convene a group of patients of a certain size, and you test them for a certain time, and then you make a declaration of a drug is a pure artifice of the kinds of the statistics that the FDA uses in its conventional protocols. It's the frequentest trial. If you-- forgive the jargon-- the alternative I've been discussing is typically called Bayesian trials. And those are completely open-ended. No serious Bayesian says we will stop after certain time and a certain number of patients. You keep feeding the data into the system forever and you keep refining forever. And you put it in massive computer-- the databases, which people are already doing. And that's the process. And you can have separate calls on when people convene and charging-- they're using the drugs, but that's how you do the side.

### Moderator
Claim: Well, let me go to Jerry Avorn. Jerry Avorn, are you a Bayesian--

### Scientific Advocate (SA)
Claim: It is my--

### Moderator
Claim: --or anti-Bayesian?

### Scientific Advocate (SA)
Claim: Actually, I think there's a lot to be said for Bayesian analyses. And I know that FDA is interested in learning more about it. But that's a little arcane--

### Moderator
Claim: Yeah, let’s not do that.

### Scientific Advocate (SA)
Claim: Maybe to give a concrete example of how-- I mean, who could be against rapid assessment of drugs? And I can give you an example of why we can sometimes think that that's not a great idea.

There was a drug approved at the very-- in the last couple of days of 2012 for tuberculosis. And the FDA approved it based on an accelerated review in which it looked at what we called a surrogate marker. That is, not “Did it make your tuberculosis better” but “Did it change some lab tests?” In this case, it was about how much TB bug was growing into your sputum. And that seems like a good idea, because the law requires that FDAs then have to follow that up with a real clinical trial, where you actually follow patients and ask did their TB get better, besides did their sputum get better. The problem that-- I have a longer article about it in the Journal of the American Medical Association a couple weeks ago. The problem is that the FDA sped through that, approved the drug because it made the sputum get more sterile of TB drugs a couple of weeks sooner than placebo did. The only problem was that there was a five- time greater rate of death rate in the people given this new drug than the people given placebo. And most of those deaths were from tuberculosis. What about the follow-up studies that the law requires the FDA to do? They told the company, “We want you to come back with a real clinical trial about this drug. And we want it on our desk by 2022.” I think that suggests--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --that the FDA can sometimes go too far in that direction.

### Moderator
Claim: That's only the scenario-- a scenario laid out that was very compelling. It's very concerning. Can you respond to that?

### Conspiracy Advocate (CA)
Claim: There is no question that FDA should have authority after these drugs are approved through trials that try to accelerate the development to continue the studies and then collect information. But when we're dealing with unmet medical needs, life-threatening disorders, patient want access to these drugs sooner. And you talked just about review times. But the real issue here is development times. And they've been going up. And they've been going up because the trials that FDA's mandating on drug developers are more and more rigorous. They're larger and larger trials. You're talking about trials that used to be two or 3,000 patients-- now are 10- or 20,000 patients.

### Moderator
Claim: Why is that?

### Conspiracy Advocate (CA)
Claim: Because the FDA is wedded to an old model of statistics. I know we don't want to talk about it--

### Moderator
Claim: No, it's okay to talk about statistics. But why are they seeking more statistics today than they did 10 years ago?

### Conspiracy Advocate (CA)
Claim: More certainty. The more patients you can enroll in a clinical trial, the better the--

### Moderator
Claim: But why weren't they--

### Conspiracy Advocate (CA)
Claim: --potential or value.

### Moderator
Claim: Why weren't they interested in more certainty 50 years ago?

### Conspiracy Advocate (CA)
Claim: I--

### Moderator
Claim: Well, let me just-- I just want-- because I get quite a run, Peter. I want to let your--

### Conspiracy Advocate (CA)
Claim: All right.

### Moderator
Claim: speak.

### Conspiracy Advocate (CA)
Claim: Because they were willing to embrace uncertainty years ago--

### Moderator
Claim: Why?

### Conspiracy Advocate (CA)
Claim: --when it came these drugs. It was a different culture. There was a sense that there weren't a lot of drugs for a lot of these diseases. And now, they have the sense that there is sort of abundance of riches, which there really isn't, when it comes to unmet medical needs. The problem is that the mindset that guides the development of new drug for hypertension, which we might all agree should be fairly rigorous, because we have good drugs for those diseases, infects every other corner of the FDA. They don't make distinctions between drugs for very rare, very--

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: --difficult disorders. Not enough. They do it in the oncology division, to a point.

### Moderator
Claim: Is this a cover your backside thing?

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: All right. Is the FDA covering its backside? David Challoner? Is that-- no-- if that-- but that is what-- the-- to make this question actually more serious and legitimate to what Scott was saying-- he's basically saying that the need for caution has just gotten out of control. That because more tests can be done, more tests are being-- more patients can be tested, more patients are being enrolled. And that the tolerance of being a little bit uncertain was greater in the past than it is now. And that that's a problem.

### Scientific Advocate (SA)
Claim: I have trouble with that. You know, I-- you know, the FDA is a public health agency. And the public health is a broadly considered status of the general health of the public, some of which are at risk, many of which are not, and are treated with either drugs or devices. And I think that the FDA is required to look to the public health, broadly, in all of its decision-making. Now, has it become bureaucratic? Has there been slowdowns? I mean, I think my partner Jerry mentioned that 50 percent of the salaries of the staff at the FDA who are looking at, quote, “our public health,” yours and mine, are now salaried by the industries that they're regulating. Now, somehow that doesn't smell right to me. I think there's a built-in conflict there-- structural conflict that the Congress has allowed, that we need to look at. But--

### Conspiracy Advocate (CA)
Claim: We should-- I mean, we should talk a little about medical devices as well here. A lot of the problems that you talked about medical devices are engineering problems. But your solution is more credible data. And you're not going to be able to solve engineering problems with clinical data. You're going to need better engineering, folks at FDA--

### Moderator
Claim: Can you--

### Conspiracy Advocate (CA)
Claim: --to look at these problems.

### Moderator
Claim: --give a concrete example?

### Conspiracy Advocate (CA)
Claim: Something like a-- the lead for an implantable defibrillator snapping off. That's an engineering problem and you need to understand the biomechanics of that lead and when it's going to--

### Moderator
Claim: In other words, you need to see if the device works--

### Conspiracy Advocate (CA)
Claim: Exactly. And literally, a company will sit with a tester and go like this with it 10,000 million times to see what it looks like.

### Moderator
Claim: And are you saying the FDA would not test it that way?

### Conspiracy Advocate (CA)
Claim: FDA would test it that way, but the solution that you're proposing and the solution you proposed with the IOM panel was more clinical data for those devices. And I'm saying you're not going to ferret out those kinds of challenges. I mean, some of the challenges you're talking, maybe you would. But many of them, you wouldn't.

I'll give you another anecdote. The minimally invasive aortic valve, right now, before a year ago, to have your aortic valve repaired when it became brittle, you had to have open heart surgery. If you went to Europe, you could get a catheter to insert a new valve through a minimally invasive procedure, much like a cardiac catheterization. 30,000 Europeans had that valve implanted in them before it was approved here in the United States. It took us four years since it was approved in Europe to finally approve it here. And FDA was requiring companies to put it in pigs and sheep when there were thousands of Europeans walking around with it in their chest. Now, you explain to me why we couldn't learn more from those Europeans and the clinical data that was generated there than we're going to learn from pigs and sheep. And another answer--

### Moderator
Claim: Wait, wait. It's a great question. It's a great question. So less is more. Stop when you're ahead because I want to hear from the other-- I want to hear from the other side. It's a great question.

### Scientific Advocate (SA)
Claim: I think--

### Moderator
Claim: Jerry Avorn.

### Scientific Advocate (SA)
Claim: --sometimes the Europeans get it right, and we get it wrong. Sometimes we get it right, and the Europeans get it wrong. There are examples in both directions. It is not the case, as the other side would have you believe, that the Europeans or the Canadians or the Japanese are always getting access to these wonderful new drugs years before Americans. We also have drugs that are approved here before they are approved in Europe and devices.

### Conspiracy Advocate (CA)
Claim: But on devices, they are. I mean, devices are different. They are getting access to devices before the United States. And medical device companies in the U.S. are moving to Europe right now because they can get approved there much faster than they can here.

### Moderator
Claim: Let me-- let me-- I want to move in two different directions. I'll tell you what they are now, and we'll work through them. One is to the side that's arguing against the motion that the FDA is overall cautious, your opponents have talked about the fact that people will die waiting for drugs because of this process. And I want to put that to you. And then to the other side, they've gone through a list of horror stories that are real. And I want to-- I want to hear your response to that.

First, to the side that's arguing against the motion that the FDA is overall cautious, they - - they've laid out a pretty good argument that in fact the slowness of the approval process, which they say is getting worse and worse, means that people are dying when they could-- if they could get into the trials, if they could get the drug released, put on the market. And whatever it is, the way that they could get access to it around the testing process, the more people would be alive today. There's a logic to it, and I'd like to hear your response to it.

### Scientific Advocate (SA)
Claim: There's a logic to it, but there's not facts to it.

### Moderator
Claim: Why not?

### Scientific Advocate (SA)
Claim: I think laying out a pretty good argument would require that there be data to substantiate it, and I think the data are pretty clear that we are not slower than other countries on earth. On average, we are faster, and we have access to drugs granted in the United States faster than they are in other countries. And so while the concept of a bunch of pointy-headed bureaucrats waking up in the morning in Washington saying, "How can I hurt people who are sick?" that's not the way the FDA operates. In fact, they are every bit as fast, at least on the drug side, which I'm more familiar with--

### Moderator
Claim: All right. Let's let the other side respond to your claim that in fact the facts support their argument that the--

### Conspiracy Advocate (CA)
Claim: It's not a question-- again, we can't talk about review times and who's faster at reviewing applications. It's a question of development times. And you can't say that it - -

### Moderator
Claim: Make the distinction, please.

### Conspiracy Advocate (CA)
Claim: Development times are the years it takes to go through those three phases of clinical trials you asked about. And development times are guided by the clinical trials that companies are forced to do. And the clinical trials that companies are forced to do are determined by what the FDA asks for because this is the biggest market. You can't develop a drug just for the European market. So if the FDA says that they want that outrageous Phase III clinical trial that's going to take five years, the companies do it. And so the drug isn't available here or Europe.

### Moderator
Claim: Scott, what is review time, then?

### Conspiracy Advocate (CA)
Claim: Review time is the amount of time that it takes FDA to actually review the application once it's submitted to the agency. So it could be six-- as short as six months and 12 months--

### Moderator
Claim: All right, now I'm following your point. Now I'm following your point about this distinction between development time and review time. So I want to bring that question back to you. They're not talking about how long it takes for the paperwork to get done. They're talking about how long the company has to spend getting the drug to the point where they can actually present the paperwork. That process is the one that is bogged down in increasing-- increasingly arduous demands to improve safety statistically. And that's getting worse, and that as a result of that, people are dying.

### Scientific Advocate (SA)
Claim: I think it is fair to say--

### Moderator
Claim: David Challoner.

### Scientific Advocate (SA)
Claim: No, go ahead, David.

### Moderator
Claim: All right. Jerry Avorn.

### Scientific Advocate (SA)
Claim: Jerry's better--

### Moderator
Claim: Okay, sure.

### Scientific Advocate (SA)
Claim: I'll do the drugs; I've been doing it for a long time. And David can do the devices.

### Moderator
Claim: Jerry Avorn.

### Scientific Advocate (SA)
Claim: I think we need to, first of all, ask, what are we keeping from patients. If-- to speak about this new TB drug, if I were a patient with tuberculosis, I don't think I would want to have accelerated access to a drug that quintuples my risk of death, doesn't treat tuberculosis, and then have to wait ten years to find out if it really works. So a drug that is--

### Moderator
Claim: What if-- what if you're in a truly acute situation? You're going to die, and you're willing to try anything.

### Scientific Advocate (SA)
Claim: That's a really interesting ethical issue that brings up the issue of Laetrile, which many people will have remembered. That was an extract of apricot pits. And a lot of patients wanted to get it because they had cancer. And back in, what, the 1960s or '70s, people thought that cured cancer. I don't think we should give access to treatments that haven't been shown to work to people, however much they want it. Now, that may make me a paternalistic person, but if we go back to an era where anyone who wants access to a drug that has not been shown to work can get it, then we're back into the thalidomide era.

### Moderator
Claim: I don't think they're arguing a drug-- Peter Huber, I want to bring in because you've been very silent for the last few minutes, and it's your turn. I'm not sure that you're arguing that you want people to have access to a drug that has been shown not to work, right?

### Conspiracy Advocate (CA)
Claim: No, actually--

### Moderator
Claim: Not shown to work, sorry. My fault.

### Conspiracy Advocate (CA)
Claim: No, I want people to have access to a drug we've developed the science so well that we know it will work in that patient, not in the crowd that exists somewhere in the FDA's computers. And that requires the use of the very best tools of modern molecular medicine. And I ask you to think very carefully, where are they being used systematically, okay? They're being used after a drug gets licensed, okay? Under the FDA's standard protocols, we are not developing that science. We should be. It's the-- the-- I think it's almost required by law. The FDA doesn't license a drug. It licenses a drug plus a label. The label is saying, is it safe and effective in these circumstances of use? And the FDA is not developing any of that science. During the trial, it scripts every step of the way. The one exception is under the accelerated approval rule where--

### Moderator
Claim: David--

### Conspiracy Advocate (CA)
Claim: --it cuts it out and lets the process--

### Moderator
Claim: David Challoner.

### Scientific Advocate (SA)
Claim: Let me step in on the drug side, even though I'm not as expert. When you-- with some of these new highly focused therapies that are designed-- specifically molecularly designed for a very small group of identifiable patients because of something we know about their genes, those can be given on a humanitarian exemption. And the patients who are idiosyncratic and small in number can be dealt with by exceptions from the old, large population processes that we've been talking about. So it's not as if the FDA is standing in the way of the progress of modern American medical science because of allowing some of these new and highly refined molecular therapies to be used, they can't--

### Conspiracy Advocate (CA)
Claim: Well, that's not-- I mean--

### Moderator
Claim: Scott Gottlieb.

### Conspiracy Advocate (CA)
Claim: There's another elephant in the room here, which is, there is a lessening of a trust in physicians' ability to prescribe drugs appropriately based on the label. And I don't want to misquote your book, but I think you expressed that, too, in your book, that you don't fully trust doctors. And so the problem is that Dr. Avorn and the FDA is unwilling to approve drugs for narrow circumstances because they don't trust that physicians are just going to use that drug based on where the data indicates that it's going to have its most beneficial impact. That's a very difficult problem to try to solve from a central agency in Washington. And that is at the root of a lot of these issues that we're talking about here. I think we should put it on the table.

### Conspiracy Advocate (CA)
Claim: But wait, I have to-- I simply have to-- your description that the targeted drugs are a rarity is just disconnected from reality. All of the HIV drugs were structure-based design. Most all of the are targeted drugs, all monoclonal antibodies are precisely targeted drugs. You know, most of our cancer therapies are on this. They can now go from a genetic identification to a mab or a structure-based drug in four years, licensed, okay? They're doing it here in New York. They just got Xalkori out in four years, gene to active drug, targeted. This is not a rarity. And this is where all of medicine is headed.

### Scientific Advocate (SA)
Claim: This is not a problem. If a company knows that a drug is going to work for a patient with a particular genetic makeup, and they say, let us do a study only in people with that genetic makeup, Herceptin is an example of that in relation to breast cancer. They can bring that to the FDA and say, “This is the people we want to test it in. It's a subgroup.” The FDA will say, fine. Test it in those people. If it works in them, the drug gets approved. The idea that there are these--

### Conspiracy Advocate (CA)
Claim: If only that were true.

### Scientific Advocate (SA)
Claim: The subgroups that are out there that are not well defined, and nobody knows quite who they are, but maybe it'll benefit somebody, so let's let anyone have access to it doesn't make sense because it does open the door. Some of my best friends are doctors. But it does open the door to the idea that any doctor and any patient can take any chemical that they think might be helpful and say, let's start using it. And that is the pre-thalidomide, pre-1906 era that I don't think we want to go back to.

### Moderator
Claim: Okay. I want to put now to this side the subtext of what was-- your opponents have been arguing all along, is that there have been numbers of cases where an agency which, as they have indicated, may be overly influenced by the industry that they're supposed to regulate, has approved products that have caused exceedingly harmful in very public ways. Vioxx, for example. The IUD shield. So they're making the case that if you don't watch very tightly-- if you don't test very, very rigorously, people are going to get killed. Can you take that side?

### Conspiracy Advocate (CA)
Claim: Well, I--

### Moderator
Claim: Scott Gottlieb.

### Conspiracy Advocate (CA)
Claim: --read Dr. Avorn's book. And again, if I misquote you, let me know. I don't think that you trust drug companies in that book. You express a mistrust of drug companies. I know you don't trust physicians to make nuanced prescribing decisions based on the label information. I don't think you think that patients can make fully informed decisions, because the information is too hard to interpret. You don't trust FDA, but you want to give them more authority. So my question is, who do you trust?

### Moderator
Claim: Jerry Avorn.

### Scientific Advocate (SA)
Claim: I trust my wife, who'd-- But if-- you know, Scott, when you put it like that, it does sound like I'm some sort of a paranoid geek who really had fears of everything. I think if we're going to have a regulatory agency-- you know, I don't trust airline pilots if they haven't been certified as being able to fly a plane. I think there're a lot of things in society where we do not accept that whatever a person wants to do is okay because they must have good intentions, it'll probably come out okay. Health care doesn't work like that. We need to assume that if something is effective, it needs to be demonstrated by the people who want to sell--

### Conspiracy Advocate (CA)
Claim: And we're not arguing for no FDA. We're-- what the question is-- what should the level of evidence be? When should judgment take over when it comes to a disease, where there isn't available therapy? Yondelis is a-- I don't want to be an advertiser for the drug company-- a lot of people think it's a very good drug for sarcoma, where there's no available for therapy. What's the harm in making it available here? Watching it closely, allowing doctors who treat that disease-- it's just a small community of physicians who treat that disease-- to use it. I agree with you that there should be vigilant post-market follow-up; FDA has tools to do that. They can be holding the drug companies accountable, and should be. But what's the harm in making it available? Trusting physicians to use it appropriately? Some won't, many will. Trusting patients to make informed judgments. Some won't, many will.

### Moderator
Claim: All right. I want to go to audience questions now. And the way that this will work is if you raise your hand, a microphone will be brought down the aisle once I call on you. I'll need you to stand up, state your name, hold the microphone about a fifths distance from your mouth so that we can hear you on all of the various broadcasts. Remember to keep it on topic to keep these guys debating on this motion. Before we get to that, I just want to do a little bit of celebrity spotting. Three tonight so far. I want to welcome John Stossel of Fox News. Frequent-- a few times a debater on this stage. And it's a pleasure to have you here. Pete Dominick, who has a radio show on Sirius XM-- XM Sirius, and also on CNN, and is a big fan and supporter of Intelligence Squared, down in the front row. But the real prize, since we've been talking about genetics and the world that has been open to us, we have in the audience-- if you remember, from reading “The Double Helix” Watson and Crick, in 1953, in the United Kingdom and here, discovering the structure of DNA. Jim Watson is in the audience with us here. God could not make it tonight, I'm afraid, but we could-- we did pretty well. So let's go to some questions. Sir, right down-- far down-- the microphone is right behind you. And if you stand up and tell us your name. Thank you.

### Moderator
Claim: Hi, my name is Andrew. And I have a question for Mr. Huber. You mentioned that drugs should be approved without demonstrating clinical outcomes. And-- but it seems that there's a risk that if you don't have enough data, you will end up with drugs that harm more than they help. And Dr. Avorn mentioned the thalidomide case. I was wondering what you would say to the people and the families who would be harmed by a drug that is rushed to market before it's ready and before anybody knows that it's safe or effective.

### Moderator
Claim: Peter Huber.

### Conspiracy Advocate (CA)
Claim: The first thing I would say to them is my heart goes out to you. Thalidomide was a terrible tragedy and it involved kids. And any parent, and I am one, that-- it just breaks your heart to read this, okay? I will add that it was a drug from the 1950s. And so, then, I would-- and then now, I'd like to tell you the follow-up on thalidomide. This does not excuse anything that was done back then. It wasn't, of course, licensed in the United States, but it was licensed abroad. You know that thalidomide is licensed as a drug in the United States today, you know? And you know it was-- in fact, it was given accelerated approval through the FDA, was rushed through, and they used the-- an incredibly clever dodge-- whoever-- whichever lawyer thought of--

### Moderator
Claim: Peter, I don't think the thrust of the question was about the--

### Conspiracy Advocate (CA)
Claim: Well, well, just--

### Moderator
Claim: --statistics of thalidomide.

### Conspiracy Advocate (CA)
Claim: Well--

### Moderator
Claim: It was just an example.

### Conspiracy Advocate (CA)
Claim: Just a second. The question is, when you don't understand a thing about what drugs are doing, you make horrendous mistakes. And we've made many in the past. And many of the examples, certainly in Dr. Avorn's book, are about misuse of estrogen, which dates way back, decades; and diet drugs, which have been used for all sorts of non-medical purposes and so on. You know, I-- nobody wants tragedies, but the way you don't-- I would rather prevent them than apologize for them and regret them. The pharmacoepidemiologists find them out late. The people who looked for the biomarkers that control how a drug performs find safety biomarkers too. Dr. Avorn has gotten-- has done important work on liver toxicity with a drug called Rezulin. There are biomarkers for liver toxicity. We should be looking whether they're explaining the liver toxicity when you try the next Rezulin. You get them on the label and you don't prescribe these things. Let's fix problems, not just lament them.

### Moderator
Claim: Another question? Sir. On the second row. Yeah. Sure. That's coming from your left side. If you could stand, please. Thanks. I didn't go to your side because I think that questioner was doing your work for you. But generally, questions can go to both sides.

### Moderator
Claim: Hi. My name is Mitchell. I wanted to ask this question to the side against the motion. You talked about the FDA's role in protecting broad public health.

And I wanted to ask, what is the difference-- or how can you separate public health from the health of those individuals dying from the lack of a fast-tracked drug? And how can you say that a person should not be let to try this drug or they'd be-- are they living in the United States by permission of the government?

### Moderator
Claim: Well, you-- just to clarify. Well, you said you were against the motion, but you're actually for the motion--

### Moderator
Claim: No. No. I-- no. I meant--

### Moderator
Claim: You're for the motion.

### Moderator
Claim: --target the question to the-- to the--

### Moderator
Claim: To the side against the motion.

### Moderator
Claim: Yes.

### Moderator
Claim: Right. Okay.

### Moderator
Claim: Sorry.

### Moderator
Claim: But the rest is crystal clear. Okay. Go ahead. No, no-- it was. Jerry Avorn. It’s a great question. Jerry Avorn.

### Scientific Advocate (SA)
Claim: The question is based on the premise-- well, there're two aspects. One is based on the premise that there are all these great drugs out there that the FDA is keeping from people. And I would submit that that fact is simply incorrect. There are not a lot of great drugs out there that are being kept from people that we know work. Now, you raise a second question, which is an interesting philosophical, libertarian issue. Should the government ever say to a patient, “There's a chemical you want to take and you're-- you have a doctor that you found that wants to give it to you; we don't think you should have it because we don't think it's safe or effective.” I think there is a legitimate political difference within-- certainly on the stage and the audience. I believe that we need to have a governmental agency that does say, “Yeah, you can't have that drug. And we don't know if it works. We have a system of drug approvals. It has not approved. No, you can't have it.” And that may be seen as a violation of individual freedom. But, you know, so is the right to, you know, go through red lights and a lot of other things are not in necessarily society's interest.

### Moderator
Claim: Scott Gottlieb.

### Conspiracy Advocate (CA)
Claim: Yeah. I think we need to think about-- you're talking about the drugs that, you know, you don't see a whole plethora of drugs that just aren't available after they've been developed. I think we need to also think about the drugs that never get developed. I'll give you an example. Polycystic kidney disease: basically, it's an inherited disorder where you build up cysts in your kidneys and eventually go on to have total renal failure. You're very familiar with it. FDA says that in order to demonstrate efficacy for a drug for polycystic kidney disease, you have to see how many patients go on to have renal failure versus, let's say, a placebo, instead of looking at cyst formation. But the problem is it takes 30 years to develop renal failure as a result of polycystic kidney disease. If you could use a reduction in cyst formation as the endpoint in the trial and show that a new drug reduces the formation of cysts, it seems intuitive, you're not going to progress as quickly to renal failure. But they want you to look for the out-- the clinical outcome, renal failure. And guess what? Companies have walked away from developing drugs for polycystic kidney disease. So those drugs just are simply aren't being developed. And that's what I worry most about. It's not the drugs that are getting licensed in Europe and not here. It's the ones that simply aren't being developed.

### Moderator
Claim: Okay. Another question. I would love to hear a female voice tonight. Somewhere. Am I-- I-- thank you. Maybe if-- I'm just not seeing it. Thanks.

### Moderator
Claim: Hi.

### Moderator
Claim: Hi.

### Moderator
Claim: I'm Sarah, and I'm actually a practicing physician. And I want to know, in this age of evidence-based medicine, and also, my concern about suggesting that my patients take a certain medication, how would I know, one, that this medication is efficacious? And two, that I'm not doing my patient any harm. I want to be able to know what the side effects of a certain medication may be. And I want to know how I might monitor a patient for identifying side effects. So--

### Moderator
Claim: Doctor-- can you-- can you focus--

### Moderator
Claim: --it--

### Moderator
Claim: --that actually into a form-- into-- and I know you can-- into a question.

### Moderator
Claim: No-- if every drug were fast-tracked or allowed to be sorted out, how could a physician present a medication to a patient as being something that will help them and not harm them?

### Moderator
Claim: Scott or Peter.

### Conspiracy Advocate (CA)
Claim: I would be--

### Moderator
Claim: Peter Huber.

### Conspiracy Advocate (CA)
Claim: I'd tell you what the very best systems are out there today, to my knowledge, okay? And they are the ones that have, unfortunately not mainly during the FDA trials, but post-market, okay, accumulated huge databases of massive amounts of molecular data and clinical data.

IBM is pioneering some of this work. Their HIV computers outperform doctors. You give a patient profile, root of entry, the-- what country you're in, these things, and they are doing massive searches through very large amounts of molecular data, and they give you precision, custom-tailored-- the best possible prescriptions you can get. You get those prescriptions only when you've accumulated a lot of patient-specific data and a lot of clinical data. We should start doing that during the FDA clinical trials. We don't.

### Conspiracy Advocate (CA)
Claim: The question presupposes--

### Moderator
Claim: Just because the doctor-- of the doctor's expertise-- and then I'll come back to you, Scott. I just want-- if the mic is still with you, should the-- did the answer Peter gave you actually-- is it something that you can work with?

### Moderator
Claim: Well, no.

### Moderator
Claim: Why?

### Moderator
Claim: Because medications, I think, are prescribed-- and I need to know-- and my area is rheumatology, and there are a lot of wonderful, magnificent drugs that have come out in the past ten years that have changed my patients' lives. But many of these drugs have very bad side effects, or potential side effects.

### Moderator
Claim: That you wouldn't know about.

### Moderator
Claim: And I wouldn't know about that, and--

### Moderator
Claim: All right, let me-- let me then stop you there and let Scott Gottlieb come in.

### Conspiracy Advocate (CA)
Claim: The question presupposes that we actually know a lot about the drugs that go through the full-blown clinical trials versus the ones that go through the accelerated approval. And I would say that we don't. There's a lot that we don't know. And to pick on-- to pick up on your field, what do you think would happen if we randomized every NSAID on the market to placebo and did a ten-year cardiovascular outcome study? Do you think that some of those NSAIDs would show the same cardiovascular risk that was shown with the Vioxx which Dr. Avorn talked about? I suspect that they would. We don't know about the latent cardiovascular risks with most of the drugs on the market because we haven't looked for it, and we never will because it's impractical and impossible to do that study. So the advice I give patients, and take myself, is if I'm taking a drug, I make sure I really need it.

### Moderator
Claim: Oh, and to remind you, we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion: "The FDA's caution is hazardous to our health." Let's go to some more questions. Ma'am, blue-- turquoise.

### Moderator
Claim: My name is Kathleen.

### Moderator
Claim: I'm sorry, could you repeat, because your mic wasn't on. Thanks.

### Moderator
Claim: Okay. My name is Kathleen. And my question is in reaction to something that Dr. Huber said, that certain drugs can be approved by the FDA, put on the market, and then doctors can prescribe cocktails of these drugs to their patients, you know. And now, since a medical doctor is neither a chemist nor a pharmacologist, is this a wise practice?

### Conspiracy Advocate (CA)
Claim: Well, let me put it--

### Moderator
Claim: Peter Huber.

### Conspiracy Advocate (CA)
Claim: --this way. If you outlawed it, as some people suggest we should, or actually crack down-- and by the way, under the federal drug law, it's quite clear doctors have a right to practice off-label medicine. But oncology would essentially shut down if you actually prohibited this. Oncology is all toolkits. "All" is not true, but some of the cocktails go through FDA licensing scripts. The vast majority of oncology today is doctors looking at drugs that have a particular molecular medicine – a mechanism unknown. They understand, gee, if I do this to the breast cancer cell, I'll frac this receptor. And they're sequencing the tumor of multiple points in the body and are finding all sorts of different ways to attack it, and they’re-- that's how they do it. There's some areas you just have to do that. Okay?

### Moderator
Claim: Is this ever done in areas other than oncology?

### Conspiracy Advocate (CA)
Claim: Look, look, many people my age and others, you know, are taking fistfuls of drugs all the time. I mean--

### Moderator
Claim: Let me move onto a question. Sir. Yeah, right in the center there.

### Moderator
Claim: My name is Gary Marcus. I have a question that's primarily for Peter, but I'd like to hear everybody's response. It's prompted by your remark about Bayesian statistics. I've been trying to work--

### Moderator
Claim: About what, sir?

### Moderator
Claim: About particular kind of statistics. It was prompted by a view about statistics, but I'll make the question so you don't need to know the term. I'm trying to work out what your view is. And one view that I could imagine is we get really large databases, we get Watson on the job. And then everything is entirely in the discretion of the doctors. Is that the model that you're pushing? And if not, why not?

### Conspiracy Advocate (CA)
Claim: I think, to tell you the truth, and I don't necessarily want to go here, I do-- I think I am quite confident that in our lifetimes, with this massive convergence of digital and biochemical technology and our ability to acquire all this data, we will get increasingly personalized. We will get to the point where the information is there, where the people best qualified to decide how to prescribe one or more drugs to this patient, will be the doctor and patient, because you've got a unique body there. You have a massive record of how things connect to each other. And Bayesians know how to draw those networks. They're doing it--

### Moderator
Claim: But are the doctors--

### Moderator
Claim: I want to interrupt this "ask Peter Huber a question show" to let the other side answer questions. Jerry Avorn.

### Scientific Advocate (SA)
Claim: There is a tendency to believe that we can do anything with big data and that if we just let anyone use any chemicals they want and have a big enough database and a powerful enough computer, it'll all kind of come out in the wash. And I know a little bit about that because that's the kind of research we do in my division. And it doesn't work like that. The reason that we've had clinical trials of the randomized kind for the last many decades is that that's a very powerful tool for learning what works and what doesn't. And saying, “We'll just observe a whole lot of people and see how they do,” is not going to give us the answer. I think the physicians' question is a really key one. The time that we get information about how well a drug works and what its side effects are is heavily centered on the FDA evaluation and the studies the companies bring to the FDA. If we shortcut that, we lose the opportunity to really understand the question that physicians face every day: How well does it work, and how well can I trade off those benefits for the risks that I know that it might also cause? And if we don't collect that information, we're all just kind of shooting blind when we prescribe those drugs in the future.

### Moderator
Claim: Okay. Pete-- celebrity Pete Dominick.

### Moderator
Claim: Celebrity Pete Dominick, I'd like to direct my question to Jim and ask him who he's voting for, but-- I guess for me, the most interesting thing to come out of this tonight that I have learned is that the FDA receives a salary funded by the agency which it's supposed to police. I think it’s disconcerting to most Americans that our regulatory agencies are captured; the SEC by Wall Street, the-- you know, the EPA perhaps in the last administration with oil.

I would-- is this not a concern for us? Why would we allow the pharmaceutical industry or any other medical industry to finance the salaries-- subsidize salaries of those who are supposed to be policing it?

### Moderator
Claim: Scott Gottlieb, first, is it accurate?

### Conspiracy Advocate (CA)
Claim: Well, look, there's a lot of federal--

### Moderator
Claim: Is it an accurate portrayal?

### Conspiracy Advocate (CA)
Claim: Is it accurate, what, that the FDA's captured by the industry because the user fees help fund--

### Moderator
Claim: Well, you don't necessarily need to use that language, but the--

### Conspiracy Advocate (CA)
Claim: No, it's not accurate. I mean, there's a long precedent of user fees being used to help offset the costs of government agencies, state agencies, federal agencies, other models for it in the federal government. You're paying, really, for the review times, the review process. You're not paying for the outcome. And I think that there is something to be said for the industry that's regulated sitting down periodically with the agency that regulates it to talk about how that process is working and to help talk about how funds can be provided to improve how that process is working. There is-- this actually works. And if you look back at the original PDUFA legislation, written into that legislation was language from Congress describing to FDA how to hold a meeting. Now, I would say FDA's management, and the management of the drug review process, is a whole lot better today as a result of the user fees. And they don't need instructions from Congress anymore on how to hold a meeting. But that's the way it was back then. And the user fees are a big reason that the management of that agency has improved so much.

### Moderator
Claim: Would this side like to respond? David Challoner?

### Scientific Advocate (SA)
Claim: Well, I remain troubled-- by the fact that 40 to 50 percent of what the commissioner of the FDA has to consider, in this case her staff, is funded by the industries that she is supposedly regulating. That's got to fit into her equations somewhere. One of the other interesting things--

### Moderator
Claim: How would that play to our-- seriously, how would that play to our motion? Does that make for an FDA that is less cautious by design than you would want it to be?

### Scientific Advocate (SA)
Claim: No. To me, it still means that we have to make sure the FDA is as cautious as it is and continues to be.

### Conspiracy Advocate (CA)
Claim: I'll tell you--

### Moderator
Claim: Scott Gottlieb.

### Conspiracy Advocate (CA)
Claim: --you never think about it. I mean, I worked in the agency for a number of years, and the fact that the agency was partially funded through user fees-- it's effectively become a tax. It's not a user fee anymore. The industry knows they're going to have to pay it. They're not going to be able to withdraw it. It's not even a thought.

### Moderator
Claim: Sir. And after this, I think we have time for one more question.

### Moderator
Claim: Yes, David, I'm an oncologist. But my question really is to Dr. Huber. Dr. Gottlieb makes the point that-- for polycystic-- and there's so many other disease that the-- big pharma will not finance and not put money into it to develop drugs for much-needed diseases because it won't make money for them. And the FDA, by-- I don't want to say by lawn-cutting, by making these 10 years' worth of data for all these different phases will make it impractical for many diseases to be looked at by the big pharma.

### Moderator
Claim: David-- Jerry Avorn.

### Scientific Advocate (SA)
Claim: It is an important question as to when you can use a surrogate measure, the kind that was discussed for polycystic kidneys or other conditions, and when you have to wait for a clinical outcome. But it's not the case that the FDA doesn't look at surrogate measures. In fact, it does all the time in order to speed drug review. They have something called a critical path initiative which is designed to figure out when can you use a surrogate measure and when you have to wait for a clinical event. But there's a downside to surrogate measures we can't forget out. A surrogate measure used to approve diabetes drugs was whether your blood sugar does down. Most of us thought that was a great idea until it turned out that Avandia lowers your blood sugar and causes heart attacks. And so, it's an important balance to know when is it okay to use the surrogate measure and when isn't it? It's not always okay. And we just need to get more thoughtful and astute about that.

### Moderator
Claim: Sir? Front row. Thanks.

### Moderator
Claim: Hi. My name is Edgar. I think a recent-- relatively recent case was the drug of Avastin. And it was a drug that was unanimously declined by FDA. And yet, there were a few patients that showed great promise. I mean, they really responded well to this. And yet, under the old paradigm of chasing P-values, a statistical term, it just was disregarded. So is it-- could it be the case that the low-hanging fruits that fit the old model of statistics are done with and that maybe we should be looking at newer models? I mean, computation power is basically free now. Why not move in a new direction?

### Moderator
Claim: Do you-- and do you feel that you hear them-- well, just for clarity-- do you feel that you hear this side saying they don't want to move in any new directions?

### Moderator
Claim: I feel like this side is saying, keep the status quo.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: No. To be clear, I don't think we're saying that. I think we're saying both--

### Moderator
Claim: Jerry Avorn.

### Scientific Advocate (SA)
Claim: --me and David Challoner, and the approval of devices, and in my case, the approval of drugs, there's a lot of exciting possibilities for looking at genetics, for looking at molecular markers. We're totally in favor of that. And I think one of the most important misstatements made by the other side is that FDA doesn't want to look at this and doesn't care. FDA very much is trying to look at this. They just want to get the science right. So it's a myth that the FDA is--

### Moderator
Claim: So--

### Scientific Advocate (SA)
Claim: --not willing to consider--

### Moderator
Claim: --so Jerry, what is it that you want to hold onto that you think they want to get rid of?

### Scientific Advocate (SA)
Claim: I want to hold onto a careful view of the science, because to not get too statistically wonky, I think it's pretty clear that if you just give, you know, a sugar pill or garlic or anything to a bunch of people with cancer, there will be people who get better, because sometimes people's cancers get better no matter what. And what is at risk here is the idea that that tail of the curve that may have nothing whatever to do with the substance, because we see in-- with placebo, someone's going to say, “Ah ha! That's the subgroup that needed to have this drug, even though there's no molecular basis for believing that.” There's always going to be some people who get better from a bad disease with placebo, because that's the way--

### Moderator
Claim: --keep my question, because I kind of lost it. What is it you say that you want to hold onto that they want to get rid of?

### Scientific Advocate (SA)
Claim: I want to hold onto having a high standard for when a biomarker or a surrogate measure or another assessment of a drug is accepted as really being scientifically true.

### Moderator
Claim: And you think that they're not--

### Scientific Advocate (SA)
Claim: Well, I think the fallacy in the other side's argument is that there's always going to be people who get better no matter what you do. And if you attribute that to a drug, you're going to approve a lot of drugs that not only aren't helping people-- because those same people--

### Moderator
Claim: --answered on their own. But--

### Conspiracy Advocate (CA)
Claim: You know, I think the issue is about caution and risk. And embracing these new kinds of technologies takes a certain degree of risk. And it takes people at the agency outside that comfort zone. And where I think we're arguing is that the agency is just not willing to embrace the risk; they're wedded to a very old model of doing things. And they haven't moved out of their comfort zone. Sure, they have pilot programs. I started the Critical Path Initiative with Dr. McClellen. But they haven't progressed, because ultimately, the leadership can talk about these ideas and does, but when it filters down to the review level, the reviewers ultimately feel uncomfortable moving outside the established models and taking the risk that it would take to adopt those kinds of innovations.

### Moderator
Claim: So it's the cultural thing you mentioned earlier.

### Scientific Advocate (SA)
Claim: Look, and I-- look--

### Conspiracy Advocate (CA)
Claim: You can change the culture, but you have change the structure of the process.

### Conspiracy Advocate (CA)
Claim: Could I add--

### Moderator
Claim: One loophole--

### Moderator
Claim: Let Peter-- let Peter say something, then you, and then we’re going to wrap.

### Conspiracy Advocate (CA)
Claim: In the White House report that I mentioned, they described the IT systems inside the FDA, that they are woefully inadequate. They are-- the systems don't connect among offices, okay? They have incompatible protocols. And they are still resorting to entering data manually. Now, I don't blame this on any individual at the FDA, but that's what happens to large, bureaucratic structures in Washington; they are an information industry and they can't-- you know, they're working with clay tablets and donkeys, really. It's ridiculous.

### Moderator
Claim: Jerry Avorn. Jerry Avorn.

### Scientific Advocate (SA)
Claim: I completely agree, as one of the authors of that presidential report. I totally endorse what you said. One of the difficulties FDA has is that folks who were intent on reducing the size of big government and taking away the budget that government-- agencies have, some of who may be on this stage--

### Conspiracy Advocate (CA)
Claim: That--

### Scientific Advocate (SA)
Claim: --make it impossible-- make it impossible for an agency like that to move into the-- forget about the 21st-- into the late 20th century, because they don't have the budget. You need to be able to fund governmental entities to do the work that they need to do, not just say the marketplace will take care of it. And that's part of FDA's problem.

## Round 3

### Moderator
Claim: That-- and that concludes Round 2 of this Intelligence Squared U.S. debate, where our motion is the FDA's caution is hazardous to our health. Now we move on to Round 3. These will be short closing statements from each debater in turn. They will be two minutes each. Speaking first to summarize his position against the motion, the FDA's caution is hazardous to our health, Jerry Avorn. He is a professor of medicine at the Harvard Medical School. Ladies and gentlemen, Jerry Avorn.

### Scientific Advocate (SA)
Claim: We've heard thalidomide mentioned a couple of times tonight. And I think that may be a good thing to remember as you vote and as you think about whether the FDA's too cautious or not. Before the thalidomide debacle, there were some amendments in Washington that Senator Kefauver had put forward, saying that, in 1962, the agency ought to have the right to make a manufacturer show that their drugs actually worked. That was not a requirement in 1961; that was something which was being debated in the Senate. And by all accounts, the Kefauver amendments were going to go down in flames, because we had people saying, “Oh, we can't let big government get between the doctor and the patient. We can't restrict the liberty of Americans to take whatever they want. We can't have doctors' hands tied by having this government agency saying whether or not a drug is allowed to be sold for a given purpose.” Right before the amendment went down in flames, it turned out that there were women who had children being born all over Europe, Japan, Africa, with little deformities. And many of you have seen these pictures. Instead of arms and legs, they had little flippers, as well as a lot of internal organ damage. And that was because the company was making a drug called thalidomide, called a lot of other things in other countries, as a sedative and anti-nauseant that was particularly marketed aggressively to pregnant women. And there was a reviewer in the FDA named Dr. Frances Kelsey. It was her first task to review this drug. She’s still alive, in her 90s, living in Washington. And she said, “No, I don't think there's enough safety information. We don't need another sedative or anti-nauseant for pregnant women.” And almost singlehandedly, she caused the drug to not be available or to deny it to the American public. As a result, thousands-- perhaps tens of thousands of American kids were not born with these anomalies. That's changed around the legislation-- FDA was given the power in the wake of the thalidomide crisis to say, “Yeah, you’ve got to show that your drug is safe and effective before we're going to let you sell it.” I don't think we want to go back to a pre- thalidomide era by weakening the FDA.

### Moderator
Claim: Thank you. Jerry Avorn. Our motion is the FDA's caution is hazardous to our health. And here to summarize his position in support of this motion, Scott Gottlieb. He's a former FDA deputy commissioner.

### Conspiracy Advocate (CA)
Claim: I want to come back to that drug for Hunter's Disease, Elaprase, I talked about at the outset. When that data from that study were released, the results were impressive. Patients getting the drug could walk 44 meters farther in five minutes than before getting the drug. By comparison, most of the children on the sugar pills showed no improvement and many saw their condition worsen. Science Daily, at the time, relayed the experience of 16-year-old Cody Paxton, one of the first patients enrolled in the trial. And he said, quote, “My breathing is better and I'm more energetic,” unquote. And he said he could put his hand behind his back, which he couldn't do before receiving Elaprase. Most of the patients forced to take that placebo, however, saw their joint disease worsen and advance, making future treatment much more difficult. I'd like to say that the kids who got the placebo would regain all the function they lost during that trial, but many would not. I'd like to say that companies are still developing drugs for these enzyme disorders, but no new companies have entered this space since that time. And only one subsequent drug has been approved for any of these diseases. And I'd like to say that the FDA reviewer in charge of imposing the Elaprase trial isn't handling drug reviews anymore, but he's actually been promoted and now sets drug review policy for the entire FDA.

FDA reviewers are not oblivious to the human cost that we talked about here tonight. But the culture they operate under isn't suited well to minimizing them. By implementing a few key reforms, some of which we've talked about tonight, and modernizing the science of regulation, FDA could modernize its culture and improve its ability to keep Americans both healthy and safe.

### Moderator
Claim: Thank you. Scott Gottlieb. Our motion is "the FDA's caution is hazardous to our health,” and here to summarize his position against the motion, David Challoner. He is vice president emeritus for health affairs at the University of Florida.

### Scientific Advocate (SA)
Claim: Thank you, John. The conversation tonight is obviously focused very highly on pharmaceuticals and not devices. And I understand the reasons for that. But my comments at this point actually would, I think, in the end, help both processes, as long as the FDA was an active, engaged organization. Most voluntary reporting of problems on drugs or devices by patients, the public, the media, health professions, healthcare organizations such as clinics and hospitals, generally first go to industry and then go from industry to the FDA. Legal counsel at many of these organizations are loathe to report due to liability concerns for their own client. What does get to industry is supposed to be reported to FDA, but some estimates put the data that FDA receives as reflecting only 1 to 2 percent of adverse events that actually occur with devices and drugs to the FDA. Moreover, these anecdotes are not informed by any knowledge of the denominator of the report. Absence of evidence is not evidence of absence. Therefore, I would like to say that as things are managed currently, for now, you must reject the premise that the FDA's caution is hazardous to our health.

### Moderator
Claim: Thank you, David Challoner.

And that's our motion: The FDA's caution is hazardous to our health. And here to summarize his position in support of this motion, Peter Huber.

He is a senior fellow at the Manhattan Institute.

### Conspiracy Advocate (CA)
Claim: In the form of arguments for and against this motion, I actually believe only one thing, that we-- the best thing for our health is to get the very best drug science we can possibly develop, and the rest will take care of itself. And I-- and I have been lamenting, in case you haven't noticed, the FDA's dreadful failure to move molecular medicine systematically into its protocols. And it's had 20 years to do this, you know, and to tell us that they're working on it, you know, it's too late now. When they're done, vote for the other side. But for tonight, you know, vote for our side.

But let me-- I would like to give you just a taste, which blew my mind when I read this, of the incredible new powers that medicine acquires once it begins doing molecular medicine, you know, from scratch, thinking mechanistically about what drugs actually do.

True story: Six-year-old Emily Whitehead was on-- you may have read this in the Times. You know, was on the brink of death after a two-year battle with leukemia. Her doctors extracted from some of her cancerous cells some signature molecules and moved them into some of her healthy immune system cells. Exactly as planned, they went in a-- into a wild attack on their cancerous siblings, so wild that they overproduced a molecular-- an immune system signaling molecule, a cytokine. One of her doctors knew that an arthritis drug, of all things, controls cytokines. He prescribed a massive dose. Emily-- the ICU staff gathered to sing happy birthday when Emily awoke from her coma on the day she turned seven. The Times ran her story just before Christmas, and Emily is healthy to this day, and cancer free.

We should be simply appalled, you know, that, you know, intense molecular tracking and learning on the fly and measuring everything you possibly can in sight during clinical trials isn't an-- I mean, isn't just the norm today rather than an exception you have to go through to-- a special rule to even find. What are we thinking when we tell the doctors, you know, to put on blindfolds and do no adaptation, no significant learning during the trials? The diseases that are probably going to kill you, and you, and you, and me, and the people we love are going to require complex arrays of drugs, you know, prescribed in complex ways. We have to do molecular medicine. The FDA isn't doing it.

### Moderator
Claim: Peter Huber, I'm sorry, your time is up. Thank you very much.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: And that concludes our closing statements, and now it's time to learn which side you feel has argued best. Most persuasively. We're going to ask you to go again to the key pads at your seat and look at this motion and vote. The motion is "the FDA's caution is hazardous to our health." If you look at that, and it rings true for you, push #1. If you look at it, and after hearing everything, you don't buy it, push #2. And if you became or remain undecided, push #3. And you can ignore the other keys; they're not live. And you can correct a key press just by pressing the next one, and it'll be-- it'll work out for you. So we'll have the results in-- in about a minute and a half. But before we get there, a few things I want to say. And the first thing I want to say is I really want to say congratulations to what the debaters did here tonight in a debate where-- Yeah. It was really clear that this was a debate where there was a very, very deep fault line between those two sides. And yet they came to it with respect. They knew each other's work. They were intelligent. And that's our goal here. So one more time, thanks to all of them for that. And also, I have to say that sometimes it's a little bit tricky with audience questions. Tonight, there wasn't a clunker at all. You were great with the questions. And thank you, everybody who has the courage to get up and ask a question. So congratulations to you. Also, the doctor who brought up the term "big pharma," I was thinking of stirring a-- you know, setting off this evening with a drinking game every time the words "big pharma" were mentioned. But except for you, we'd be a pretty sober crowd at this point. It didn't happen to come up. We'd love to have you Tweet about this debate. The Twitter handle-- our Twitter handle is @IQ2US. Our hash tag for tonight's debate is #FDA. This is the final debate of our spring season. However, on June 19th, we're going to be in Washington, D.C. We're partnering with the McCain Institute for International Leadership. The motion then is this: “Cutting the Pentagon's budget is a gift to our enemies.” So we--

Oh, I really want you to come down for that, yes.

You know, we'll charter a plane to get you down for that. So make sure to visit our website. We're going to be back in the fall, still here at the Kaufman Theater, we're pleased to say. You can see on our website how to buy tickets and what we're doing. We're at www.iq2us.org. But I just want to go through the topics we think we're going to be doing. We're going to be looking at drones; we're going to be looking at breaking up big banks; the case for going vegan; we're going to look at gun control; and we're going to take on immigration. That's what the plan is now, so it's going to be a great fall. We hope you'll all be there.

Tickets go on sale in late June. And for more information, you can go to our website and pick up tickets. I've mentioned this already, but for those who can't join our live audience, there are a lot of other ways to see these debates. We stream live on FORA.tv, so everyone who is watching on FORA.tv right now, hi. And you can listen afterwards to this debate on NPR, WNYC here in New York, on PBS stations across the country. That's also channel 13 here. And check your local listings for air dates and times. All right, so we had you vote twice on this motion: The FDA's caution is hazardous to our health. After voting twice, according to our rules, the team that has moved the most percentage points to its side will be declared our winner. Here are the results. In the first vote on this motion, the FDA's caution is hazardous to our health, 24 percent of you agreed with the motion, 32 percent were against, and 44 percent were undecided. That's a very big undecided. So those are the first results. Remember, it's the team that’s-- numbers have moved most in terms of percentage points that will be declared our winner. Let's go to the second vote. First, the team arguing for the motion, their second vote is 53 percent.

That's the team that's saying that the FDA is too cautious. They went from 24 percent to 53 percent. They picked up 29 percentage points. That's the number to beat. The team against this motion, their first vote was 32 percent--

Their first vote was 32 percent. Their second vote, 38 percent. That's up only 6 percent. It's not enough. The debate goes to the team that was arguing that the FDA's caution is hazardous to our health. Our congratulations to them. Thank you from me, John Donvan. We'll see you next time.
