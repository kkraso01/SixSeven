# Debate Transcript

Topic: The Two-Party System Is Making America Ungovernable
Motion: The Two-Party System Is Making America Ungovernable

Debate ID: two-party


## Round 1

### Moderator
Claim: Ladies and gentlemen we are going to go right now to the vote where we ask for your party affiliation, or lack thereof. There’s a keypad to the left of your seat, and we’ve designated number 1 to stand for Democrat, number 2 for Republican, and 3 is Independent, and three would also cover Communist Party, Libertarian, Sorry about that. But to a degree I think that’s what we’re discussing here tonight. So if you take just a minute to do that and we’ll lock it in and then we’ll begin the debate. Number 1 is for Democrat, number 2 is for Republican, and 3 is Other. We’d like your cell phones off except for the few who have decided to tweet throughout the event, about the event. Our name on Twitter is @iq2us and we’re using #2partydebate. And now let’s welcome our debaters to the stage.

And it is a true pleasure to introduce the man who has made Intelligence Square U.S. possible. It's why there is an IQ2 U.S. Mr. Robert Rosenkranz.

### Moderator
Claim: Well, thank you and welcome. It's my task to frame the debate. Why did we do this particular debate? And the question, of course, is, is America ungovernable? Well, neither the most liberal Democrats nor the most conservative Republicans can govern the way they like. Our system demands compromise and change by slow increments. And that's exactly what the founders intended. Both parties have always had different philosophy of government and different takes on major policy issues. But for most of the past 50 years, there's been a sense that politics stops at the water's edge, that we won't let partisan politics jeopardize America's security or our standing in the world.

And in domestic policy, the biggest initiatives such as civil rights, welfare reform, the NAFTA free trade pact, Medicare, Medicaid, all have substantial bipartisan support. Well, what I am describing is hardly what politics today are like. Both parties seem to be dominated by their most extreme elements. And the center is driven from the corridors of power. Indeed, the rarity of truly civil discourse in our society is precisely what prompted the creation of the Intelligence Squared debate series in the first instance. Well, how did things get this way? I would point to three developments, each of which quite ironically seem, on the face of it, to enhance democracy.

First, the primary system for selecting candidates has evolved into a highly compressed series of campaigns that require well over a hundred million dollars to contest effectively. Second, the campaign finance reform has required that those vast sums be raised in $2,000 pieces. And it's often the most emotional and intemperate rhetoric that prompts folks to write those checks. Finally, the media environment has become highly fragmented, encouraging people to gravitate to news outlets that will enforce their views and drive them even further from centrist positions. But whether I'm right or wrong about the reasons, it's hard to dispute that the two parties are as far apart as they have been in our lifetimes. Does that mean that America is ungovernable? To help you decide, we have with us tonight some of our most brilliant political commentators.

And it's now my privilege to turn the evening over to them and to our moderator, John Donvan.

### Moderator
Claim: Thank you. And once again, I just want to say thank you to Robert Rosenkranz for making all of this possible. True or false, the two-party system is making America ungovernable. Let's have it out. That's what we are here to debate under the auspices of Intelligence Squared U.S., I'm John Donvan of ABC News. We are at the Skirball Center for the Performing Arts at New York University where we have two teams of debaters, two members each. Arianna Huffington and David Brooks are arguing for the motion. They want to convince you that the two-party system is making America ungovernable. Here to try to make nonsense of that argument, their opponents, Zev Chafets and P.J. O'Rourke. Now, this is a debate. There will be a winner and a loser. And you, our live audience here at the Skirball Center, will be the judges. By the time the debate has ended, we will have asked you to vote two times, once before you've heard the arguments and once again afterward.

And the team that has changed the most minds in the course of the debate will be declared our winner. So let's go to your preliminary vote. Our motion is “The two-party system is making America ungovernable.” If you agree with this motion, press number one on your keypad. The keypad is to your left. If you disagree, press number two. And if you are undecided, press number three. And if you think that you have pressed a key in error, just correct your mistake, and the system will lock in your last vote. All right. It looks like everybody's completed that. We'll be presenting the results of that vote and the concluding vote at the end of the debate.

So onto round one. Our motion is “The two-party system is making America ungovernable.” In round one, uninterrupted opening statements by each debater in turn. They are seven minutes each.

And here to argue, to convince that you the two-party system is making America ungovernable, Arianna Huffington, who is now president and editor-in-chief of the Huffington Post media group. Interestingly, Arianna, you were born in a country that now has five viable parties in its parliament. You came of age intellectually in a country that has three viable parties in its parliaments and you are now living in a country that has two parties, is there a trend, meaningful trend?

### Conspiracy Advocate (CA)
Claim: Yes, I am fast moving toward one party rule.

### Moderator
Claim: Ladies and gentlemen, Arianna Huffington.

### Conspiracy Advocate (CA)
Claim: Thank you so much. David and I are here to convince you that indeed the two-party system has rendered this country ungovernable. And the evidence is all around us. Wherever you look you see that we can only produce suboptimal solutions to our deepest crisis.

And if you have any doubt about that just look around. Why do we still have banks that we have deemed to be too big to fail? Why did our two-party system produce three major disasters in recent years? The financial meltdown, the mining disaster that left 29 miners dead in West Virginia, the BP oil spill, just to mention three major disasters, that were produced as a result of our completely dysfunctional two-party system. And, you know, for many, many years we’ve kind of postponed solving our big problems, we’ve postponed dealing with our deficit, we've postponed dealing with the decline of the middleclass, we've postponed dealing with our crumbling infrastructure, we've postponed dealing with our deteriorating education system. Well, we can no longer keep postponing dealing with these problems. So while the two-party system might have been okay during the ordinary times, we’re not living in ordinary times right now.

We actually have to solve our problems, we have no more reserves, we’ve run out of time, the chickens have come home to roost. And the problem with the two-party system is that is has made us all prisoners of conventional wisdom. It’s made us look at every political problem through that obsolete prism of right versus left. In fact our political problems are not susceptible to that easy completely reductionist way of looking at them. Let’s take Afghanistan, the media consider anybody who wants to leave Afghanistan as a lefty. In fact George Will, the Cato Institute, Pat Buchanan, Joe Scarborough, and many conservative intellectuals see no reason for us to be pursuing an unwinnable war at huge expense. Let’s look at reforming Wall Street.

There are many good capitalists who sleep with a copy of Ayn Rand’s books under their pillow, who believe that Wall Street desperately needs reforming if it’s going to actually operate like a capitalist system as opposed to operating like an oligarchy, crony, system where losses are socialized and gains are privatized. Nevertheless the two-party system makes that kind of thinking impossible because we continue to see everything through that obsolete binary prism. But look around, the favorability ratings of the two parties are constantly declining. We now have Dems at about 39 percent favorability rating and Republicans at 34 percent. And the last election despite all the attention, despite all the media hoopla only 42 percent of the electorate voted. This is an enormous amount of dissatisfaction in the political system to have so many people not even participating in that most elementary duty of citizenship voting.

And then let’s look at what would have happened in any other section of our life if we had such a vacuum. There would have been more competition; there would have been more participation from others, but not in our political system. Indeed inordinate amounts of power is folded in the hands of a few so-called centrist senators, like Olympia Snowe, do you remember during the healthcare debate for 14 months Democrats did everything they could to woo Olympia Snowe. They are like lovelorn high schoolers who are just not getting the message that she was just not into them. And John Adams predicted what would happen when he said that “there is nothing I dread so much as a division of the Republic into two great parties each arranged under its leader and converting measures in opposition to each other.”But that’s exactly what we have done. And the hunger for change is overwhelming. The election of Barack Obama is evidence of that, the rise of the Tea Party is evidence of that. There is huge mistrust of our national institutions, politicians, business people, the media. And the rise of social media, the rise of the Internet has made it possible for young people especially to connect with each other, to reject the existing system, to opt out of politics and try to find solutions in their own communities, bypassing the political system. That’s not ultimately healthy because democracy is not a spectator sport. And if we’re going to revive democracy, if we’re going to overcome all the obstacles in the way of a truly Democratic system, you know, the way we have the huge advantages of incumbency, the difficulty of ballot access, the gerrymandering of our districts.

If we’re going to overcome all these things, we need to actually bring more competition and more voices and fresh thinking to our political system. Because as Einstein put it, to paraphrase him, the problems we are facing right now cannot be solved at the same level of thinking that created them. And that’s all that the two parties are capable of.

So, let me just end by quoting Thomas Jefferson. In a letter to Francis Hopkinson, he said, “I never submitted the whole system of my opinions to the creed of any party of man whatever, in religion, in philosophy, in politics, or in anything else, while I was capable of thinking for myself. Such an addiction is the last degradation of a free and moral agent. If I could not go to Heaven but with a party, I would not go to Heaven at all.” Well, it’s here that our two-party system is not taking us to Heaven. In fact, it’s rapidly taking us in the other direction. Thank you.

### Moderator
Claim: Thank you, Arianna Huffington.

Our motion is “The two-party system is making America ungovernable,” and here to speak against the motion is P.J. O’Rourke, a journalist, a political satirist. Does it say that on your business card?

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: He is the author of 13 books, including “Don’t Vote-- It Just Encourages the Bastards.” Ladies and gentlemen, P.J. O’Rourke.

### Scientific Advocate (SA)
Claim: Thank you. Thank you.

You know, I agree with Arianna about the utter cowardice and perfect ineffectuality of the two major political parties in dealing with any of the political problems that we face, and I would simply concede the debate if I were able to imagine some other political party or independent candidate-- left, right, or fanatically middle-of-the-road-- who would do a better job.

It’s like trying to imagine a politician who would get up on the campaign stump and say, “No, I can’t fix public education. The problem isn’t under-funding or over-crowding or teachers’ unions or a lack of a voucher system or absence of computer equipment in the classroom. The problem is your damn kids.” He wouldn’t get elected. And the problem is us damn voters. And it’s not our political parties, be they few or many. We have voted ourselves more government benefits than we care to pay for. And we’re broke. And, you know, so are all the other democracies in the world, no matter how many political parties they have. Indeed, other countries that aren’t democracies face the same problem. Everybody’s broke except China.

And China has a per capita GDP of just $7,400 a year, as compared to the Dominican Republic’s per capita GDP of $8,600 a year. So the Chinese are broke too.

So, given that we’re the problem, we might as well stick with the system that we’ve got. I mean, after all, we’re the ones who invented it. It must suit our needs in some way. The American two-party system is not a very good political system, but we Americans are not very good at politics. We’re just not. I mean, we don’t seek the good things in life from politics. We seek the good things in life from pluck and luck. You will notice that more people are interested in the New York State Lottery than are interested in the New York State government.

Now, I would argue in favor of America’s two-party system not because of America’s two political parties but because America doesn’t really have political parties at all. I mean, we certainly don’t have political parties in the ideological sense. Republicans and Democrats don't have ideologies. They just have these vague platform planks made of rotten wood of political expediency? If American party platforms were backyard tree forts, you would not let your children climb in them. Anyone can join an American political party, even a witch. No one can be thrown out of an American political party. God knows my fellow Republicans, I have been trying with Sarah Palin, and you see where it's gotten us? Instead of political parties, what we have in America is two fund- raising mechanisms for a pair of general human tendencies.

The tendency to leave things all screwed up like they've always been and the tendency to get the government involved and screw things up more. Democrats are the party that says government can make us all richer, smarter, taller, thinner. Get the crab grass out of our lawns, you know? The Republicans are the party that says government doesn't work and then they get elected, and then they prove it. We have the stupid party, and we have the silly party. Now, I belong to the stupid party. I vote Republican because Republicans have fewer ideas. Not few enough as you may have noticed in Iraq, but you know. Stupid party and the silly party. That would seem to me to cover the range of human political thought.

What do we want to add to that? The insane party? The confused party, the violent party, the drunken, naked party. Well, maybe.

Now, if the key question is governability, two-party system, they've done pretty well by world historical systems, little glitch in 1860. We're used to the idea of political parties causing civil wars, Spain, Vietnam, Nicaragua. But in the case of our own civil war, both the Whigs and the Democrats split on the issue of slavery, thereby in fact actually delaying our civil war for more than a decade which may very well have ensured that the right side won in our civil war. Our two political parties, silly and stupid as they may be, they've shown an ability to reconstitute or replace themselves when the nation needs it most.

The Republican party came from the mess of the Whigs and the anti-slavery Democrats in time to win the Civil War. The Democratic party realigned, broke the power of the dixiecrats in time to win the battle for civil rights, you know. Even in these days of supposed extreme political polarization between Republicans and Democrats, there is a big overlap of feelings and ideas. You know, the rich should get richer but only if I'm one of them, right? The poor need help, but can't they knock it off with the drugs, the crime, the tattoos and the dumb music? We see this overlap in the number of Americans-- I'm sure many of you will be among them-- who tell pollsters they are independent or, as many of us put it when we're phoned by pollsters, "Go to hell. I'm eating dinner."But to be completely outside the two-party system just deprives candidates of any need for a sort of broad appeal, which is why America's third parties have been weird--anti- Masonic party, trying to keep my dad from wearing a fez and riding around on a tiny motorcycle. The know-nothing party, the name says it all. The greenback party. They wanted money to be worth less. That dream came through. So, we Republicans had Teddy Roosevelt which got us Woodrow Wilson in World War I. You Democrats had Ralph Nader who got you George W. Bush and the Iraq war.

In the matter of political systems, never believe that they can't get worse. And in the matter of our two-party political system, I would say dance with the one that brung ya'.

### Moderator
Claim: Thank you. Thank you, P.J. O'Rourke.

Here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate.

I'm John Donvan of ABC News. We have four debaters, two teams of two, who are fighting it out over this motion: “The two-party system is making America ungovernable.” You have heard the first two debaters and now on to the third to speak for this motion, to argue that the two-party system is making America ungovernable, I want to introduce David Brooks, who is a columnist, op/ed columnist for the New York Times and a commentator on the News Hour. And, David, I find it interesting that your debating partner, your teammate, Arianna Huffington, started on the right and moved to the left. And you as a young man making your way through the world started on the left and moved to the right. What happened in your case?

### Conspiracy Advocate (CA)
Claim: Wisdom.

### Moderator
Claim: Ladies and gentlemen, David Brooks.

### Conspiracy Advocate (CA)
Claim: Arianna, I can't explain.

So the defender of the two-party system starts out by conceding that parties are cowardly, ineffectual and stupid and so stands by the proposition that we can't do any better, which is good counter programming toward Obama standing on a position of hopelessness and changelessness, more or less standing up for the "Let's go suck on a gas pipe" party.

And I suggest you support P.J. if you have Jack Kevorkian on your speed dial, that we can't do any better. But then in the middle of his remarks, a sort of miracle occurs, and after telling us how stupid the parties are, suddenly he decides they are about to reconstitute themselves into something not half bad. P.J. and I are old friends, and I know he took a lot of drugs in the '60s. Call Rockefeller University. Apparently, they're still hanging around.

Now, Arianna spoke about the broad dysfunction of our parties. I'm going to speak about the narrow dysfunction, especially in Washington where I cover it. I cover politicians very closely. And I can tell you, from this context, politicians are all emotional freaks of one sort or another. They have what I call logorrhea dementia, which is they talk so much they drive themselves insane.

But they do have these intense social antennae so they, if you meet them, they will guarantee to invade your personal space. They'll stand too close, rub the back of your head.

I was campaigning with Mitt Romney up in New Hampshire once, and he was campaigning in a diner with his five perfect sons, Bip, Chip, Rip, Lip, Sip and Dip. And we go in the diner. He introduces himself to a family and then says, “What village in New Hampshire are you from?” And then he describes the home he owned in their village. And then he goes around the diner and then first-names everybody on the way out.

So they're weird social creatures. Nonetheless, I would say in general, they are better people than one would anticipate. Most of them are in it for the right reason, but they're stuck in a rotten system. They're stuck in our current two-party system which forces them to behave in ways that are worse than they are. It's a mind suck.

First of all, they cannot be entrepreneurial.

They cannot think for themselves because they have to hew the party line. They get-- every Tuesday. They go to a lunch. They get the message of the week. They have to parrot the message of the week. It's a soul suck. They can't behave nicely or even get to know the people in the other party because there are unofficial barriers.

I went to something called the Civility Conference where Annenberg took House members from both parties to the Green Briar Hotel and got them to work together, or to meet together. And I went to the dining room. It was like junior high, all the Republicans over here, all the Democrats over here. They know nothing about each other. When a member of a party starts describing to me the-- what's going to happen on the other side, I know everything they're about to tell me is wrong because they know nothing about each other.

Finally, it's freedom destroying. They come in wanting to cut deals, talking in private about what they'd like to achieve. But they're in a tribal mentality in what-- what they can achieve is severely limited by the tribal sort of Tutsi versus Hutu nature of our politics of the current two-party system.

So as a result, they find themselves unable to lead the lives they'd like to lead.

Arianna talked about how the big problems are therefore not addressed because they are stuck in these little trenches. These problems come up every day, the squeezing of the middle class unaddressed. I would talk about today's story, the issue of the budget. We are facing a fiscal meltdown in this country. And if you took individuals outside the party context that we have now, I bet we could all cut a deal. We could figure out what taxes needed to go up and what spending needs to go down. But we're stuck in this dysfunctional marriage where, first of all, 85 percent of the budget is completely off the table because neither party wants to touch it.

Secondly, you've got the Republicans who at least have big ideas for cutting the spending. But they have no idea what spending should be cut and what isn't, so they're cutting some of our most valuable programs like Head Start and early childhood education because that's the party dogma.

Then on the Democrat side, they've got some decent ideas to save Head Start and early childhood education.

But the present-- the Democrats have no persuasive ideas so we can actually cut the budget deficit and avoid national bankruptcy by 2015 or 2019. In 2019, we will be paying interest on the debt equal to about 800, $900 billion. And this problem has been building and building and building. We are completely unable to solve it because the Republicans refuse to raise taxes, which is going to have to happen, the Democrats refuse to talk about Medicare and Social Security reductions, which are going to have to happen. We are stuck and we are heading toward a national disaster.

So the first thing we need to do is get out of the system where we’re stuck in these party ruts. The University of Maryland had a very interesting study where they took Tea Party people, they took liberals, and they said, “Here’s our budget problem, you deal with it.” And the Tea Party people acknowledged that they had to raise taxes, the people on the far left acknowledged some spending had to be cut.

They all could do it. But the two-party system can’t do it. The second thing we have to do is mobilize independence. We probably need a third party, but we certainly need a de- alignment, we need more movements to come in and affect the parties so people are less hewn to these tribal parties and that’s what the parties have become, they’ve become tribes, almost ethnic tribes. They are no longer the normal political groupings that they were 20 or 30 years ago. They’ve become tribes where your honor is attached to your tribe and any compromise seems like a sign of shame and dishonor and therefore they’re not willing to do it.

So we need to get more movements involved, take up the two parties.

And then finally we need a philosophy, we’ve got two parties in this country, but we’ve got three movements. The first movement is a liberal movement that believes in using government to enhance equality. The second movement is a conservative movement that believes in limited government to enhance freedom.

But starting at the foundation of our Republic there was a movement starting with Alexander Hamilton going up to Abraham Lincoln going up to Teddy Roosevelt which believed in limited but energetic government to enhance social mobility, to give people the tools to compete. This is not big government, it’s not little government, it’s energetic government to give people the tools to thrive in a capitalist economy. That centrist movement is completely unrepresented by the two parties and yet it’s where the largest percentage of Americans are. So if you think, if you take a look at the fiscal situation, if you take a look at some of these big issues and you can see our current two-party system leading to a solution in the near term, you can vote for those guys, but if you can’t see a plausible way out of our problems I suggest you vote for us, thank you.

### Moderator
Claim: Our motion at this Intelligence Squared U.S. Debate, "The two-party system is making America ungovernable," and here to argue against the motion, Zev Chafets, a columnist, the author of 12 books, the founding editor of The Jerusalem Report.

We met when you were working for five years in Jerusalem as the government spokesman for Israel, and interesting to note, we’re talking about two-party system, Israel has proportional representation, which at this point has how many parties represented in Parliament?

### Scientific Advocate (SA)
Claim: Fourteen.

### Moderator
Claim: And how’s that working out?

### Scientific Advocate (SA)
Claim: Great.

### Moderator
Claim: Ladies and gentleman, Zev Chafets.

### Scientific Advocate (SA)
Claim: I'd like to begin by quoting something that I saw in the press just the other day, "Things haven't been moving in Washington, a young Democratic president with an overwhelmingly Democratic Congress can't get much of anything passed except for defense and appropriations, which certainly doesn't add up to dynamism, a sense of delusion has set in among friends as well as foes." That, from Time Magazine, September 7th, 1962, and the young president they're talking about is John F. Kennedy.

And the point that I'd like to begin with is that people always say and have always said that America is ungovernable and that these are times as Arianna put it which are extraordinary, different than other times, and require extraordinary and brand new solutions. But America has always been in unusual times. That's how it always seems to people when they're alive, that they're living in unprecedented times. In the 1920s, America confronted Prohibition which made it seem that the country was ungovernable and also, you know, no place to get a drink. In the 1930s, there was a depression in this country which was far worse than the economic situation today obviously.

In the 1940s, America was able to mobilize itself to go to war against Nazi Germany and Japan even though there was a strong sentiment in this country not to go to war, an America First Sentiment, which was overcome. In the 1950s, we all-- those of us who are old enough to remember, used to hide under our desks in the nuclear drills because we were sure that we were going to get bombed by the Russians. But, in the event, America won the Cold War. In the 1960s, the halcyon days of our youth-- my team anyway-- we not only were living in an ungovernable society, but we were contributing to it, and happily. The 1970s were Watergate, a disaster. It was the end of American democracy. The president was forced to step down, never happened before.

Somehow the country survived those extraordinary times.

And what brought it through each time was the two-party system, which is a stable and consistent system in this country. It’s what provides stability for the United States, politically speaking.

The 1980s-- anybody-- some of you remember the 1980s, it looks like. That was the decade that Japan was going to take over and dwarf the American economy, something like the Chinese. And, by the way, the Japanese growth national product per capita is less than America’s today. And then, of course, we’re living in New York, the ungovernable city, as it was called by Nathan Glazer in 1961, and as it was referred to by others before Rudy Giuliani became mayor. And if you look out the window, those of you who came here today, you don’t see an ungovernable city.

You see a well governed city, both under Giuliani and also under Bloomberg. This was a miracle, but here we are.

The American system is a resilient system. And the notion that this country’s ungovernable is a media trope. It’s not true. It hasn’t been true. I can prove it to you, if you want, with statistics. The World-- is it the World Bank? I’m not too good at my notes here. Because they’re in Hebrew and who can read-- You know, seriously, I’m reading backwards. It’s not funny. I had some-- actually, I did have some great statistics. I thought I was going to impress David Brooks with them, but you’ll have to take my-- oh, here it is.

Okay, the World Bank index-- it has a thing called the Index of Governability, which is so handy for a debate like this. And I just looked it up. You know, why argue when you can have fact-based, evidence-based arguements. All right. The World Bank takes into account one, two, three, four, five metrics. Accountability and voice, which goes to what Arianna was discussing, effectiveness of the government, the quality of regulation, the rule of law, and the control of corruption-- in all of those indices, the United States scored above the 90th percentile in the world, which is an “A,” even at NYU. And only in public stability, which is a function of terrorism, does it get a “B.”In other words, the American system is a-- if you say compared to what? Compared to utopia, it’s a replaceable system. If you compare it to the rest of the systems of the world, it’s a pretty good system. And, as P.J. said, it’s also the system that fits this country. It was built for this country. And it has lasted a very long time.

Back in the day, there was a columnist that we grew up on, Walter Lippmann. And here’s what he wrote, and I like to close with it. This is about force of representation, proportional voting, but it stands for the system in general. He said that “the objection that popular government cannot be conducted without the two-party system is, I believe, refuted by the experience of Europe.” “If I had to choose between a congressional caucus and a coalition ministry, I should not have to hesitate very long.” That was written in 1914, the year that World War I began inexplicably. And I would say that if you look at that system, the European system and the American system, which are the only two real Democratic systems in the world, the American system has done pretty well in the last 80 years. And I think it's a--

Thank you.

### Moderator
Claim: Thank you, Zev Chafets. Your time is up.

### Scientific Advocate (SA)
Claim: Thank you.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate. We'll be right back.

We are back at this Intelligence Squared U.S. debate. Our motion is “The two-party system is making America ungovernable.” We have to teams of two members each.

Arianna Huffington and David Brooks are arguing for the motion. And arguing against, we have P.J. O'Rourke and Zev Chafets.

The team arguing for the motion has been arguing that we are stuck in, as they have put it, an obsolete prism of right and left. And the team arguing has been saying, well, actually, we've been stuck before in our long history. And we had a two-party system, and we worked through those crises, and the crises we're facing now are no more daunting relative to the system than they have been in the past. And we'll get through again.

I want to put to P.J. O'Rourke-- I don't know if you're a founding father kind of guy-- but your opponents have quoted John Adams as saying he dreaded the thought of the body politic dividing into a two-party system. And they're arguing that there's no room for many voices when the structure is right and left. Can you take on that argument?

### Scientific Advocate (SA)
Claim: Well, Washington went further than that. I have his quote around here someplace, written also in Hebrew.

But Washington said that the--

### Scientific Advocate (SA)
Claim: I wrote-- I write the quotes for both of us.

### Scientific Advocate (SA)
Claim: Yeah, yeah. Washington warned against the spirit of party, period. He didn't go so far as to just worry about two. He worried about the system of party absolutely. And I would say that Americans have taken that to heart, that while there are core Democratic and Republican supporters, and while they probably have more influence over our political system than they ought to, that Americans themselves have always been a bit dubious about both of the major political tendencies. And there is no golden period that we can go back to in American history to find, you know, some sort of political system that would be better for us.

The original divide between Jeffersonian Democrats and the Federalists, the Jeffersonian Democrats were an unholy alliance of New York demagogues-- New York demagogues, who would imagine?-- New York demagogues who favored the French revolution and all the fun they were having in France and Southern slave owners who favored states' rights. Meanwhile, the supposedly more respectable Federalists were the authors of the alien-- naturalization alien and sedition acts and the first major political witch hunt in the United States. I think Americans have always been quite aware that both parties stink.

### Moderator
Claim: Let me bring in Arianna Huffington to pick up on it.

### Conspiracy Advocate (CA)
Claim: You know, P.J., I would argue that if we really had-- believed what you believe now throughout the course of American history, we would never have made any moves towards a more perfect union because when we had slavery, you would say, oh, it's as good as it gets. When women didn't have the vote, you would say, well, you know, it could have been worse.

When we didn't have-- when African-Americans could not vote, you would say, well, you know, just think of it. In other countries, it's just infinitely worse, and the World Bank probably would have given us an “A” rating. But--

That World Bank “A” rating really worries me. It must have been the same kind of credit-- credit rating agencies that were giving junk bonds AAA ratings. So, you know, the idea that we're not living through unprecedented times, you know, is an unbelievably elitist idea that stems--

### Scientific Advocate (SA)
Claim: But you see, Arianna--

### Conspiracy Advocate (CA)
Claim: No, no. Let me just finish.

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Because this is like from people who are comfortable like we are privileged to be, those of us here on the stage. But just look at what's happening. A hundred million Americans right now are worse off than their parents were--

### Moderator
Claim: So you're saying, Arianna, we are in an un-govern-- a situation that reflects un- governability.

### Conspiracy Advocate (CA)
Claim: And also that throughout our history, we've always aimed to do better. We believe that we can do better.

### Moderator
Claim: Zev Chafets, are we-- are we in the mess-- the mess of absolute gridlock that I think is being described by your opponent?

### Scientific Advocate (SA)
Claim: Well, I think that Arianna put it very-- very well. There was a time when there was slavery. And there was a time when women couldn't vote. And there was a time when African-Americans couldn't-- when African-Americans couldn't vote. And all those things no longer are the case. They all changed. And they all changed under the two- party system, which is the subject that we're debating tonight. The fact that there are imperfections in America is obvious. And the fact that there are people in America who are suffering is a constant.

### Moderator
Claim: So, David Brooks, why is it different this time?

### Conspiracy Advocate (CA)
Claim: Because it wasn't always thus. If you go back to, say, 30 years ago, and you look at the two parties. In the first place, the two parties overlapped in Congress. Now they do not. There's no common ground between them. In the second place, if you look at the things they were able to do, like tax reform in 1986, you had a whole series of bipartisan agreements.

If you cover Congress the way I do, you had, in those days, a whole series of personal relationships. That simply doesn't exist. And that's what--

### Moderator
Claim: --there was something of a golden era, a silver area.

### Conspiracy Advocate (CA)
Claim: No. There was a period of constructive competition. They fought. Aaron Burr killed Alexander Hamilton. I would write that as highly polarizing. But they fought to balance each other's weaknesses. And now they don't-- they don't-- they fight to stagnate.

### Moderator
Claim: P.J. P.J. O'Rourke.

### Scientific Advocate (SA)
Claim: I think this is normal-- it's a normal sine wave in American politics. After all the 1930s, the New Deal was not exactly a period of huge bipartisanship in them. Bipartisan ideal is always a little worrisome to me. I consider actually the two most dangerous words in Washington to be “bipartisan consensus.” It's kind of like when my wife and my doctor and my lawyer all agree that I need help.

I just-- it just-- it concerns me a little bit.

But finally where I come apart from-- I'm glad to sit here and criticize the two-party system. I don't have that much good to say about it. The alternative. What is the alternative? My biggest concern is that in a multiparty system, it leads to power in small screwy ideology.

### Moderator
Claim: arguing that, you think that the system is making America ungovernable. Are you arguing for a better-functioning two-party system, or are you arguing for a multiparty system?

### Conspiracy Advocate (CA)
Claim: Well, we are arguing for something that will shake up the current dysfunctional system.

### Scientific Advocate (SA)
Claim: But what? But what? I don't want the garden gnome party holding the balance of power.

### Moderator
Claim: Arianna Huffington.

### Scientific Advocate (SA)
Claim: Subsidized garden gnomes everywhere.

### Moderator
Claim: Let Arianna have the mic.

### Conspiracy Advocate (CA)
Claim: I thought that was Michael Dukakis.

### Moderator
Claim: For the record that was David Brooks.

### Conspiracy Advocate (CA)
Claim: Yeah.

Your notes are in Hebrew and mine are in Greek so we all have a problem. But the truth of the moment is that as an immigrant to this country who has lived the American dream. I'm fully aware of the fact that the American dream is dying for millions of Americans. And I have two daughters in college. And a growing number of their friends are graduating from college, and they can't get jobs. We have 26 million Americans at the moment who are either unemployed or underemployed. And we don't have any plan that the two parties seem to be capable of, of how to bring jobs about. So there is a huge dysfunctionality. And the results are really incredibly profound. I mean, they are changing the nature of this country. Upward mobility has been at the heart of the American dream. Now we are number ten when it comes to upward mobility. We are behind France and Germany. Excuse me, but being behind France in upward mobility is like France being behind us in croissants and afternoon sex.

### Moderator
Claim: But to P.J.'s point about this it’s just your dumb kids. Why is that about the two-party system and not about everything else?

### Conspiracy Advocate (CA)
Claim: Well, the idea that it’s dumb kids that are the problem is just charming P.J. I mean, whatever P.J. says, he's charming because he's funny. But it's not true.

### Moderator
Claim: And that's our debate for this evening.

Zev Chafets, come on in.

### Scientific Advocate (SA)
Claim: Well, I would say not true is-- that's pretty definitive. The notion of being in a debate with Arianna Huffington arguing that America has lost its ability to have upward mobility is a startling experience. And I want to say something about David's notion about bipartisanship.

Two things quickly, first of all, polarization is a good thing, not a bad thing. In countries where you don't have polarized political debate, you have no debate. Severity does not equal democracy. And in the many countries that I've visited, and you've all visited and been to and I’m sure many of you where you haven’t heard harsh debate, you have been in the countries that are being ruled, not in Democratic ways and societies that are open. And the other thing about this golden age of advise and consent when all the Congressmen got together, the Senators got together and had cocktails and so on, and there’s no bipartisanship anymore, I just want to say the following words, No Child Left Behind which was passed in a bipartisan way, the Medicaid prescription-- Medicare prescription, the tax cuts, the Bush tax cuts, the Iraq War which like it or not was a bipartisan affair, the TARP stuff, the healthcare bill which was passed in a – a mono- partisan way--

### Moderator
Claim: All right, let me--

### Scientific Advocate (SA)
Claim: all of these things have been passed in the last 10 years.

### Conspiracy Advocate (CA)
Claim: First, on the civility point, screw off, you fat bastard. Let’s go, let’s go! No, I believe in conflict, I’m a columnist, conflict is fine with me. And I’m fine with that as long as it’s constructive. The problem is we have parties that don’t represent the country. We now have, here’s a fact from Morris Fiorina, Stanford political scientist, more people own ferrets than watch Fox News. And so, but we have a party--

### Scientific Advocate (SA)
Claim: Isn't there a lot of overlap?

### Conspiracy Advocate (CA)
Claim: That's a good point, yeah. Glenn Beck’s ferret is loose. But we have a party that’s sort of dictated by that small group, and in the Democratic party we have a party dictated by the public sector employee unions.

And you’ve got vast numbers of people whose views are not basically represented, so the country is still a bell curve country, and the rest of the-- and the two-party system is not. And therefore you don’t have--

### Moderator
Claim: Just tell us what you mean by bell curve?

### Conspiracy Advocate (CA)
Claim: A bell curve is like this, most people in the middle. And so you don’t have constructive competition, which would be us talking and then reaching an agreement after an hour, you just have, eh, you guys suck.

### Scientific Advocate (SA)
Claim: But, David, can I just say that in the last election the Republicans nominated John McCain, a more reasonable Republican than that would be hard to find. And the Democrats nominated Barack Obama who was the soul of reasonableness, and so much is in favor of civility that he said at my alma mater, the University of Michigan, “If you are people who listen to Rush Limbaugh and Glenn Beck, then read some articles on the Huffington Post.” That's what you have. Those are the two leaders of the major parties at least until the next election.

I don't think that you can make the case that these are extremists who don't talk to one another or who are civil with one another.

### Conspiracy Advocate (CA)
Claim: Compare pre-nomination John McCain to post-nomination John McCain and see what a guy has to do to get elected.

### Moderator
Claim: Arianna Huffington, if you-- you said that democracy cannot be a spectator sport. Your opponents are saying that Americans by nature are not ideological. Maybe those two things are not necessarily in conflict with each other, but do you take their point that for the most part, Americans aren't that into politics and therefore that makes the parties rather irrelevant?

### Conspiracy Advocate (CA)
Claim: I think Americans don't believe that our current--

### Moderator
Claim: Could I just ask you just to move a little closer to your mic. Thank you.

### Conspiracy Advocate (CA)
Claim: Oh, sorry. Americans don't believe that our current political system is working. That's why you have 37 percent of Americans who are registered as independents because they don't believe our current two-party system is delivering what the country needs. And increasingly young people who really do want to find solutions to our problems are choosing civic engagement instead of political engagement.

Who have long waiting lists for people to join teach for America, so it's not as if they've given up on making the world better. I mean, P.J. and Zev may have given up on making the world better but-- young people haven't, they just don't see the political route through the two-party system as the way to make the world better, but if we give up on making the world better then we might as well give up on everything. You know, I mean, I think in the end Churchill was right, he said Americans can be counted to do the right thing after they have exhausted all other possibility. And the two-party system is one of the other possibilities we have now exhausted.

### Moderator
Claim: P.J. O'Rourke.

### Scientific Advocate (SA)
Claim: I don't at all feel fatalist about this. And I don't feel like standing pat. I think we are in the middle of a huge fight. I think Tea Party is a very good example. I keep waiting for the Democratic party to have the equivalent. I hope that it will. I think we're in the midst of a political realignment going on in the United States.

I think our opponents mistake a current situation for a permanent situation. I think that the American politics goes through phases like this, and you know people say, “Oh, it's more polarized now than it's ever been,” and I'm going, like the 60s? That wasn’t polarized? You know, the 1860s, that wasn’t polarized?

### Moderator
Claim: So, are you saying, P.J., we may be temporarily ungovernable?

### Scientific Advocate (SA)
Claim: Yeah, I mean, we’re temporarily badly governed. You know, and I think that that happens a lot, and I think that, you know-- this budget crisis will not go away. Sooner or later, these dumb SOBs down in Washington are going to have to face up to this fact. And, you know, if the pass is anything to go by, they will. I still keep waiting for hearing what is the alternative to the system that we have now. I’m open to the idea that there might be an alternative, but I’m not hearing any alternative.

I’m hearing merely a criticism of the system that we’ve got now.

### Moderator
Claim: Well, that’s all they actually need to prove.

### Conspiracy Advocate (CA)
Claim: Exactly.

### Scientific Advocate (SA)
Claim: Well fine--

### Moderator
Claim: But it does raise the point… It’s a very, very important point that I think the audience will want to hear from you, Arianna. As opposed to what?

### Conspiracy Advocate (CA)
Claim: Well, first of all, let me just say that the motion is “The two-party system is making American ungovernable.” And I hope you’ve all heard our opponents make our case again and again and again. In fact, P.J. just said, it’s not good right now, but it doesn’t mean it’s not going to get better. Absolutely. All we are saying is that we need to take steps to make it better. We can’t just wait by the sidelines and expect it to get better. And the fastest way to make it better is to shake up a dysfunctional and stagnant two- party system. That’s all we have to prove.

### Moderator
Claim: But how?

### Conspiracy Advocate (CA)
Claim: That’s all we are arguing. Well, the primary way is to allow more competition.

All of us believe in competition, right? It’s the essence of a private enterprise, freedom- based system. We believe in competition in everything except politics. When it comes to politics, you’ve got to pick your party and run with your party, and actually espouse whatever the party stands for at that particular moment. One election cycle, it may be abortion or no abortion-- the social issues, this election cycle, and it’s around issues that have to do with the shrinking government on the Republican side. So, that’s not the way to fundamentally change the conditions we are all living under.

### Moderator
Claim: Zev Chafets or P.J., if you are ready to move on, I can go to the audience for questions, but if you’d like to respond?

### Scientific Advocate (SA)
Claim: I’m still not hearing--

### Scientific Advocate (SA)
Claim: I don’t-- I’m with P.J. We’re talking about a two-party system in an actual world, or a different political system in an actual world.

The two-party system is a very long-standing-- and by the way, it has plenty of room for Independents, which are part of the system, and also for third-party candidates, which are a function of every election, whether it’s Ross Perot or whether it’s Pat Buchanan, or you can’t name an election-- or Henry Wallace, or George Wallace or-- you can’t name an election that hasn’t had a third-party candidate or more--

### Scientific Advocate (SA)
Claim: Or usually a big nut.

### Scientific Advocate (SA)
Claim: The fact that people don’t want to vote for them is not the same thing as saying that they don’t exist. And I think that we have to-- since we’re talking about reality and not utopia, I think we have to ask ourselves, who, on this stage, the four of us-- the three of you are all brilliant, and John, of course, is also. If the five of us, and I’m just old-- I have more age. I’m older than P.J. by a couple of months, so I have seniority. But if the five of us had to sit down and devise a better political system, even with the wizards on this panel, I don’t think we would be able to do it.

And even if the whole audience participated, we probably might not get there. We have a political-- there is a political system in this country, and thank God there is. It provides stability, and it’s grown organically.

### Scientific Advocate (SA)
Claim: It’s grown organically over the course of 235 years –

### Moderator
Claim: Okay, you’ve had a good run. Let’s let David Brooks--

### Conspiracy Advocate (CA)
Claim: Speaking of this long duration, you know, I grew up here at NYU. I went to the University of Chicago, a Baptist school where atheist professors teach Jewish students Saint Thomas Aquinas. I’m used to long historical visions, and the idea that “Oh, it’s sort of always been like this,” it’s just not true. Let’s take my pet issue, the deficit. Every generation has an incentive to pass debt off on the future generations, but no generation until the current one has done it because the political system--

### Scientific Advocate (SA)
Claim: Finally, our dream come true.

### Conspiracy Advocate (CA)
Claim: --was able to mobilize and basically exercise some self control and cut deals. Ronald Reagan did the biggest tax increase in American history because the political system then basically worked.

The parties are now different than they were then.

### Moderator
Claim: All right, we’re going to go to some audience questions when we come back.

We are back. This is a debate from Intelligence Squared U.S.

### Scientific Advocate (SA)
Claim: That didn’t last long.

### Moderator
Claim: Wouldn’t it be great if commercials really worked that way? TiVo for life. We are back. I'm John Donvan of ABC News. This is a debate from Intelligence Squared U.S. Our motion is “The two-party system is making America ungovernable.” We have two teans of two debaters each trying to change your minds. And I'd like to go now to the audience for some questions. And gentleman with the glasses and neck tie. A mic will come to you. And if you could stand up just so that the camera can find you. And if you can keep it terse and questioning.

### Moderator
Claim: Thank you very much. This is terrific. My question is to the panelists in favor of the resolution. And it's at the theme that you were just discussing.

Given the fact that the two-party system happened by itself, bottom up, organically, to use P.J.'s word, how exactly would you get rid of it, or perhaps worse, what would you impose and in what way?

### Moderator
Claim: David Brooks.

### Conspiracy Advocate (CA)
Claim: First, I'm not necessarily for realignment, but de-alignment. We're seeing all sorts of social movements that are growing up organically like the Tea party, like the Obama movement, like Move On. I'd like to see a lot more of those movements in order to loosen up the parties. And the second thing, I do think there has been an historical tradition, which I talked about, from Hamilton to Lincoln and maybe to moderate Republicans and moderate Democrats today, the very few that exist. That tradition is unrepresented by our politics. And I think that long American historic tradition deserves a voice. So those would be two things I'd change.

### Conspiracy Advocate (CA)
Claim: And I would add that--

### Moderator
Claim: Arianna Huffington.

### Conspiracy Advocate (CA)
Claim: --movement politics really leads us to what I call Hope 2.0.

You know, if Obama was about hope, which is just basically hope being channeled to one of the two parties. Hope 2.0 is about hope being channeled to multiple movements, a community solution, people all around the country unleashing an enormous amount of creativity and ingenuity around finding solutions at the local level. We in the media are doing a lousy job of putting a spotlight on what is working. We need to do a much better job. We need to help them scale up. And this is really part of what we are talking about.

### Moderator
Claim: Arianna, don't you feel that the parties actually are responsive to movements, or they're affected by them ultimately will co-op them?

### Conspiracy Advocate (CA)
Claim: No, I think--

### Moderator
Claim: Be shaped by them?

### Conspiracy Advocate (CA)
Claim: I think to a large extent the parties use movements during election times. I mean, look at the Obama movement. Once Obama was in the White House, he basically disappeared. They are now trying to reconstitute it because he is beginning to run for the election. That's not what makes a thriving movement.

A movement is something which organically continues to grow through elections and beyond them. And that's what we need more of. People do not trust establishments. I mean, look at the tea party movement. It's fundamentally anti-establishment. Look at what's happening among young people on the Democrat side, fundamentally anti- establishment. The numbers of mistrust when it comes to our national institutions has skyrocketed. We need to address that. Otherwise we are becoming an increasingly dysfunctional society.

### Moderator
Claim: Zev Chafets, your opponent.

### Scientific Advocate (SA)
Claim: Well, first of all, I want to take issue with the characterization of the Obama movement. Obama was the nominee of the Democratic party. He wasn't a movement candidate. He was a candidate of one of the two major parties. Had he been only a movement candidate, he would have gotten three percent of the vote or five percent of the vote or whatever movement candidates get. But he went through the system, and he's a part of the system. As far as the notion of young people speaking their minds and getting so much resistance from behind.

We're talk-- that's not a good idea, Arianna. Really, it's not. It's great for everybody to participate. And I'm glad that there's an Internet and all of the cool stuff that we've got these days in participatory Facebook and all the rest of it. But since everybody's quoting the founding fathers, John Adams also said that political parties are there to govern passion. And something needs to govern the un-channeled passions of all of the marvelous passion that kids have and young people have and disaffected people have and anti-establishmentarian people have, and they all can exist within the framework of the two-party system as they have ever since 1865, whenever the Civil War ended, in my opinion.

### Moderator
Claim: All right. Let's go to another question. Right in the center. It might help-- yes. You're - - you're the only one with your hand up in the front row. And a mic is going to come down this way to you.

And if you don't mind standing again. I know you're right in front.

### Moderator
Claim: With the growth of social media and the 24/7 news cycle, what role do you see the media playing in helping reinforce the current two-party system or changing it for the future?

### Moderator
Claim: Can I ask you what you think the media's role is so far in that regard? Do you think it's ossifying the system; it's keeping it in place or-- is that somewhat of your lament?

### Moderator
Claim: I think it's keeping it in place.

### Moderator
Claim: All right. So what you're really asking is can that change, I think.

### Moderator
Claim: Yes.

### Moderator
Claim: Arianna Huffington, sounds like a

### Conspiracy Advocate (CA)
Claim: Yeah, I completely agree with you. And if you look, for example, at the way the media describes our political problems, it’s reflexively through that prism of right versus left. I mean, I mentioned Afghanistan in my opening statement, Wall Street reform, unemployment. Why is it left wing to care about helping people get jobs?

And yet that's how it's portrayed in the media. But if you look at how the discussion is, say, on social media, it's very different. Does not accept those very stale distinctions. So we have a responsibility, those of us in the media and everybody else, to participate in that and change it. And increasingly, more and more, people are participating, and self- expression has become a kind of form of self-fulfillment. More people are participating, uploading videos. We saw it not just here. We saw it in what happened in Egypt recently. We saw a phenomenal outpouring of something which I suppose you might regard dangerous because it's leading to uncontrollable passions. But it's also leading to freedom, liberation and other things that uncontrollable passions provide.

### Moderator
Claim: You need to see the expressions on the faces over there.

### Moderator
Claim: very briefly, because I think we know where you're going.

### Scientific Advocate (SA)
Claim: The reason that the social media was necessary in Egypt, because it was a one-party state. It's not a two-party state. That's the whole point of this. Everything--

### Scientific Advocate (SA)
Claim: --two-party state.

### Scientific Advocate (SA)
Claim: --within the two-party system. You don't need-- you don't need a mob of Facebook- inspired Democrats if you have the ability to nominate candidates then vote for them. And then--

### Conspiracy Advocate (CA)
Claim: Well, first of all, the fact that you are calling it a mob shows what respect you have for them. The other thing is that--

### Scientific Advocate (SA)
Claim: What did you think they were? I mean, what are they? Were they--

### Conspiracy Advocate (CA)
Claim: Why is it a mob? Why are people who are organizing on Facebook or through Twitter in order to overthrow an oppressive regime a mob?

### Scientific Advocate (SA)
Claim: Ask Lara Logan.

### Moderator
Claim: All right. Let's-- let's move on. Gentleman, if you can stand up.

### Moderator
Claim: Yeah, I think one of the reasons the country was more governable in the past, one of the reasons we had overlap between the parties, which I think was mentioned, is that we had much more of a common narrative in the past. The parties agreed more on what the facts were and then disagreed on their interpretations of them.

So you could have, as P.J. would say, the stupid and the silly arguments for the--

### Moderator
Claim: But what era are you talking about, because there were plenty of times when they didn't--

### Moderator
Claim: Up until recently. Today, we have a greater bifurcation in the news than we've ever had. We have FOX on one side, we have MSNBC on the other.

### Moderator
Claim: Okay. So what would your question be?

### Moderator
Claim: Perhaps the problem here is that the country may be ungovernable, but it's not the two- party system that's the problem. Rather, the problem is the way information now flows through the country and the way we end up with essentially tribes around facts as opposed to simply tribes around interpretation.

### Moderator
Claim: P.J. O'Rourke in response.

### Scientific Advocate (SA)
Claim: bifurcation you're talking about. I think there is a tendency to take the period from about the end of the Korean War through, say, Johnson's Great Society, as being somehow normative in American history. It is not.

The two political parties were, of course, violently polarized in the civil war, quite polarized after the Civil War, extremely polarized during the 1920s, extremely polarized during the-- during the 1930s. They are extremely polarized right now. I would argue that polarization is more normal than not. As far as there being some sort of media voice of common wisdom and some sort of-- some sort of objectivity in the media, that was like a sort of little false advertising campaign of the New York Times over the course of about one decade, you know? American newspapers have traditionally been just hysterically partisan. I mean, if you go back through the history of the American press, it has almost entirely been advocating-- and usually in the loosest and most irresponsible way, one particular--

### Moderator
Claim: So P.J., let me put your central point to the other side.

You're saying that polarization is the norm most of the time. David Brooks.

### Conspiracy Advocate (CA)
Claim: Fighting is the norm. Polarization like we've seen is not the norm. This is actually statistically demonstrable. Political scientists take a look at how many votes cross party lines, how many times in each Congress people actually reach bipartisan deals. And the number now is at all time lows, it's cycled through history, but it’s never been like this. People fought Lyndon Johnson in the '60s, fought-- but Lyndon Johnson was able to fashion coalitions. Henry Clay, people then fought, they were able to fashion coalitions. The problem is not that they were fighting. I’m all for fighting, the problem is that each party has become more rigid in my own lifetime of covering this stuff. When I came to Washington in the early '80s I could go to back benchers like Jack Kemp or Newt Gingrich on the Republican side, they had all these weird ideas they were trying to push on leadership. That doesn’t happen, the leaders control everything now. The nature of the parties has changed.

### Moderator
Claim: This time is different.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Okay, question, ma’am, with the scarf, and the mic is coming to your left side.

### Moderator
Claim: One of the reasons that the parties seem to have so much more power now is the control of the money. And even though there have been attempts to do campaign finance reform we seem to be moving even further away from that goal rather than to trying to diffuse some of that. How do you respond to that and is that affecting our two-party system today?

### Moderator
Claim: Arianna? You write about this a lot.

### Conspiracy Advocate (CA)
Claim: Absolutely, I think that’s a very important point and especially with the citizens' united decision. As you said we see the stronghold of money on our political system, the power of special interest, the fact that we have dozens of lobbyists per member of Congress, the fact that even when good legislation is passed it’s undermined at the committee stage.

All those things have made us ungovernable, because even when-- and we have mining reform for example, then you go back and you look at how it was all watered down to the point where the Virginia mining disaster could happen. Even when you have regulators living inside Lehman Brothers or Fannie and Freddie, they were not able to prevent the regulator recapture that allowed the financial meltdown to happen. I mean we have lost trillions in private wealth. We have the greatest increase in poverty in the suburbs at the moment. We are becoming a third world country and if we don’t pay attention now, if we don’t do something where they stand to course correct then it’s going to be too late. And that’s why this is the time to sound the alarm, recognize it to have become ungovernable and change the system.

### Moderator
Claim: All right, more questions from the audience when we come back. You know what would actually help me come back is if I could have one of those rounds of applause that you hear when-- thank you. We are back with this Intelligence Squared U.S. debate, I'm John Donvan of ABC News. Our motion is "The two-party system is making America ungovernable." Arguing for the motion we have Arianna Huffington and David Brooks. Arguing against, Zev Chafets and P.J. O'Rourke, and going to a question from the audience, gentleman with the eyeglasses. And I again want to urge you because we're starting to stray a little bit to make these questions that are terse and that are related to the topic please, so you're first.

### Moderator
Claim: Okay. So responding to Mr. Chafets, the United States is above the 90th percentile in terms of governance compared to the entire world but that's a pretty low bar to set for the world's richest and most powerful country. But my question is for the side in favor of it, in my native Canada there is about 80,000 people for every member of Parliament.

And we have a chance to meet them much more than here where there's about 800,000 people for every member or member of the House, and I'm wondering if it's-- do you think that it's a problem with the two-party system or is the country just too large to be governed? There are many multiparty countries in Northern Europe that are much better governed than us but they're smaller.

### Conspiracy Advocate (CA)
Claim: I guess I would say--

### Moderator
Claim: David Brooks.

### Conspiracy Advocate (CA)
Claim: - I was born in Canada, bula bula. You know, I'm actually not sure that's it because members of Congress fly home every weekend. That's one of the reasons their lives are so miserable and they hold town meetings. And a lot of places-- I meant the flight, not the getting there-- they hold town meetings and if they can get 30 or 50 people to show up they're happy, they love to meet people, they spend a lot of time meeting people. And as I said they have this you and I need food and water, they just need social love, that's what they need. And so I don't think that's it.

I don't think it's when they go home that the problem is, I think it's when they come to Washington and are surrounded by a psychological vortex. I just wanted to make that explicit. I think the psychology within the parties has changed--

### Moderator
Claim: And, P.J., I think you're almost arguing that the bluntness of-- by design of a large system with two parties that you feel have a lot of ideological overlap is perfect for a gigantic country like this one.

### Scientific Advocate (SA)
Claim: Well, I think that it is because I think the intrusion of third parties and other interests just has a tendency to act as a sort of spoiler situation, basically throwing the race to George W. Bush instead of to Al Gore who would have been such a wonderful president. Anyway, you know, that’s another matter. Yeah, I do think it suits us.

You know, the problem, of course, is when we face the kind of crisis like we have at the moment that is both extremely pressing and yet, unlike Pearl Harbor, is not perfectly immediate. Our system is extremely slow to respond. Do we want to live in a country with a political system that is a little too slow to respond, or do we want to live in one of those countries where the political system is a little too quick to respond? I pick slowness, myself.

### Moderator
Claim: Would you like to respond, Arianna Huffington?

### Conspiracy Advocate (CA)
Claim: Well, because it depends on the kind of problems we are facing. And if we are really willing to recognize the problems that we are facing now and how serious they are, when it comes to unemployment, when it comes to foreclosures, when it comes to bankruptcies, when it comes to the fact that growing numbers of kids can’t afford college, and if they graduated from college can’t get jobs.

I mean, these are serious problems. And they are also leading to a kind of political instability and a kind of demonizing our opponents, which always happens during times of deep economic anxiety, when it was the 1880s when we were expelling Chinese workers, or the 1930s when we were expelling Hispanic workers who were actually American citizens. You see what the problems are when we are not taking steps to deal with them in a timely manner.

### Moderator
Claim: Okay, I’m going to go to another question. And I’m raising my hand to my face because I have difficulty seeing farther up. There’s a woman in a blue top.

### Moderator
Claim: Hi. I think this debate is great, but I think one of the concerns that a lot of people have is how do you shift away from a two-party system. Basically, how do you cope with the “Nader effect” where the balance becomes shift too far in one direction as you’re trying to divide the parties? .

### Moderator
Claim: Can you rephrase that in a way that would help people, when they hear the answers, settle their mind on our motion? Because I think you can.

### Moderator
Claim: I’m sorry. I guess, basically, I’m more concerned with the details of how, what type of plan do we implement to move away from the two-party--

### Moderator
Claim: So you’re asking what this side is asking when they are saying “as opposed to what?” Is that what you’re asking?

### Moderator
Claim: I’m basically just trying to figure out, how do we move away from the two-party system?

### Scientific Advocate (SA)
Claim: Yeah, as opposed to what?

### Moderator
Claim: A three-party system? A four-party system? A 12-party system?

### Moderator
Claim: Okay, but I’m sure--

### Moderator
Claim: How do we divide the parties into the different groups without shifting power too far in one direction--

### Moderator
Claim: Do you want to take that question on? Yeah, Arianna or David?

### Conspiracy Advocate (CA)
Claim: Yeah, I would say that even though we don’t have to take that question in doing the debate, we are very willing to take that question on.

And there are many voting measures that could be put in place if the two-party system did not have a stronghold on the current electoral system that would make it possible, for example. If you voted for Ralph Nader, and if Ralph Nader did not win, for your vote to go to your second choice. I mean, that is a completely plausible system that can be implemented immediately if the two parties did not prevent it from being implemented.

### Moderator
Claim: David Brooks.

### Conspiracy Advocate (CA)
Claim: --just another role is non-party primaries. I mean, if you look at the most disaffected people, they’re not actually where Nader is or not where Libertarians are. They’re in the middle 37 percent of the country basically feels disaffected. But they have no candidates to vote for in general elections because they’re just not offered them. And if you had non-party primaries, you’d have a better shot they’d have a voice.

### Moderator
Claim: And that’s a point that I’d brought to you before from their argument that you didn’t really respond to is that they’re talking about the system as it is, really leaving people with such distasteful choices that they don’t have choices, and that that’s a lot of people, and that that’s what they feel is a major flaw in a democracy. Zev Chafets?

### Scientific Advocate (SA)
Claim: I confess that I don’t understand the premise or the question.

### Moderator
Claim: That there’s a lot of people who don’t feel they’re represented by these parties.

### Scientific Advocate (SA)
Claim: Yeah, and in multi-party systems, there are many people who also don’t feel that they’re representing by any of the parties. And I, having lived in a country that has 14 parties, I can tell you that I didn't find any that represented me. That's an inherent problem of democracy. If you have a party that fits the taste of every person or every group of people, you'll have hundreds or a multiplicity of parties that makes it impossible to govern. And if you have any system, whether it's a two-party system or a proportional representational system or a different kind of parliamentary system, I assure you-- and I've lived through this. I'm telling you from personal experience-- that professional politicians will always find a way to game whatever reform you make in the electoral system because they're better at it than you are and I am.

That's what they do for a living.

### Scientific Advocate (SA)
Claim: Exactly.

### Scientific Advocate (SA)
Claim: And therefore I think that if you have something that is open to everyone, anybody can vote in this country. Anybody can join a party in this country. Anybody could run for office in this country. That's great. If, as P.J. says, many people aren't interested, then they're not interested. But you can't force anybody-- the only place I know where people are forced to vote is in North Vietnam, I mean North Korea.

### Moderator
Claim: Australia.

### Scientific Advocate (SA)
Claim: Australia?

### Scientific Advocate (SA)
Claim: it's called the donkey vote, the people that vote because

### Moderator
Claim: And if you get attention of one of the mics, thanks.

### Moderator
Claim: At NYU, we have the privilege to have some very good faculty, including Professor Steven J. Brams, who talks about approval voting, which is one of the systems they talked about, where if your first choice doesn't get elected, your voice goes to your second choice and down the line. It produces more democratic outcomes and would reduce polarity in the parties.

My question is, why would this be a negative thing to institute? Why would making elections more accessible to people, you know, things like approval voting or letting people vote electronically be a bad thing? And if there are other measures, what is a good way to explore them to bring them into the American system to reform elections--

### Scientific Advocate (SA)
Claim: I don't have any inherent objection to this. I think it's interesting that we're hearing the solutions to the problem posited here more from the audience than from the other side. But one of the beauties of America's federalist system, of our highly decentralized system with all sorts of-- states are essentially in charge of voting laws as long as they don't forbid people from voting because they belong to a category such as women or such as blacks.

They actually-- states have enormous latitude in control of the election laws. And the fact that we have this flexible system would allow us to try things out like that. Maybe they would work beautifully and would produce the kind of results that you think that they might. Maybe they would produce perverse and bizarre results. And we'd find out.

### Moderator
Claim: I'm thinking your opponents are saying, though, that the system-- that the way the system runs now has such a stranglehold on the way the system runs now that those reforms are unlikely to be put into place. Am I anticipating?

### Conspiracy Advocate (CA)
Claim: Well, I mean, let's take this case right here.

### Moderator
Claim: David Brooks.

### Conspiracy Advocate (CA)
Claim: We've got a 5-foot 6-inch Jewish guy who runs this city, Mayor Bloomberg. He thought about running--

### Scientific Advocate (SA)
Claim: He's Jewish?

Who knew?

### Conspiracy Advocate (CA)
Claim: I'm amazed he's 5-foot-6. So he thought about running for president. And he had some money, I hear.

And so he thought, well, you know-- and there were a lot of people who were disaffected. So could I win? And then he said, well, I could win some states, probably not all of them, but I could win some. And then it would get thrown into the House of Representatives, a body staffed entirely by Republicans and Democrats. There's no way they're going to vote for me. And so he was dissuaded from running as a third-party candidate by the fact that the two parties have a stranglehold on the presidential process.

### Scientific Advocate (SA)
Claim: And this is bad?

### Scientific Advocate (SA)
Claim: Depends on how you feel about Mayor Bloomberg.

### Conspiracy Advocate (CA)
Claim: One of you guys just said Mayor Bloomberg ran the city well. I think it was you.

### Scientific Advocate (SA)
Claim: I think he did run the-- he does run the city well.

### Scientific Advocate (SA)
Claim: --want to let him out of the city. I’ll live here.

### Scientific Advocate (SA)
Claim: He might be a great president, by the way. I have no reason to think that he wouldn't be. And I might vote for him. But the fact that a guy with $16 billion can't become president of the United States simply by buying the election does not strike me as a flaw in a democratic--

### Moderator
Claim: --raise $500 million?

Yeah.

### Scientific Advocate (SA)
Claim: No, I think essentially we will-- the problems that our opponents raise are valid problems, and these-- but this is a democracy. And these problems will be answered when we, the demos demand that they be answered. There is no magic trick that we can impose to fix this.

### Moderator
Claim: Sir, you are the most aggressive hand-raiser of this evening. So this had better be good.

### Moderator
Claim: Passion, Passion. Mr. O'Rourke, you just mentioned actually that you're getting more responses of how to change things from the audience. I think that was what Arianna was discussing about multiple voices. So that's--

### Scientific Advocate (SA)
Claim: Okay. Fair enough. Fair enough. That's fair and balanced of you.

### Moderator
Claim: indeed. Indeed. My question is actually, our founding fathers wanted church and state separated. If I'm not mistaken, I don't believe it was until the '50s, until "In God We Trust" started getting printed on money. How do you think religion is affecting the two-party system?

### Scientific Advocate (SA)
Claim: Ooh. Ooh, you know? They want them separated. They didn't want them extinguished, either of the two things in question. I actually think that religion is a little bit on the decline in terms of its influence. I think it probably reached its peak influence in the United States with the Prohibition, which was not entirely church driven, but there was certainly a very, very strong. But William Jennings Brian and the Populist party, one of the third parties that some people may be in favor of, was a strongly religious party. He's the guy that ended up prosecuting the monkey trial on the teachings of Charles Darwin.

The strongest religious influence was then. There was then a resurgence, of course, during the social values debate of the '80s. I would say at the moment, it's a bit on the decline partly because fundamentalist Protestants have realized that in many ways they have a lot of things in common with at least centrist Democrats in terms of social policy.

Certain things they don't have in common, of course, questions of abortion and so on. But they--

### Moderator
Claim: But does this relate to the two-partiness of our system, necessarily?

### Scientific Advocate (SA)
Claim: Yeah. There's no doubt that religious questions have a greater influence on the Republican party than they do on the Democratic party, leaving Reverend Wright aside. But really, I think it's a little bit of an issue in decline in the United States--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --personally.

### Moderator
Claim: There is a green striped shirt. And if you could stand up, please.

### Moderator
Claim: You are all the most qualified people to respond to this. In point of fact, it's not a two- party system because there are other parties on the voting ballots. But is the problem the media which makes people think it's only a two-party system?

### Moderator
Claim: Can I ask you-- it's a little bit of a rephrasing of the question we had earlier about the media sort of perpetuating this sense that there are only two parties. Do you have that sense? And do you think that's a problem?

### Moderator
Claim: Yes. It seems like there's very little coverage of third-party candidates unless they're eccentric in some respect.

### Moderator
Claim: And they are.

### Moderator
Claim: And they're always presented as by-- they're represented by their eccentricities instead of by their--

### Moderator
Claim: And what's lost in that?

### Moderator
Claim: --position.

### Moderator
Claim: And what's lost as a result of that?

### Moderator
Claim: I don't know.

### Moderator
Claim: Well, what I'm asking is do you agree with this side that there are voices that are not being heard because of this-- is that a problem for you?

### Moderator
Claim: Absolutely, in the fact that the ballots always have Democrat and Republican first.

I think they should be in alphabetical order because the Republicans would change the name of their party in a second and the fact that people run under different parties, but most Americans are not educated-- sorry-- don't approach the poll I think in a very thoughtful way and realize that they could vote for the same person but under a different party. Strengthen third parties. More money will go to third parties.

### Moderator
Claim: Okay.

### Moderator
Claim: Money follows votes.

### Moderator
Claim: Okay. But I've got to stop you. But why don't you take on the question, because it is slightly different. David Brooks.

### Conspiracy Advocate (CA)
Claim: Well, you know, I do this for a living. And I sometimes go on TV shows, and the TV shows I happen to go on are some of the best on TV, the News Hour with Jim Lehrer, which is much less partisan shouting than most. And yet the shows all of us are on, you are either the Republican seat or the Democratic seat. And I consider myself Hamiltonian, like I've been saying, which fits very awkwardly with the current Republican party. And yet that's my seat. That's my role. That's what I play on TV. And so it's sometimes frustrating. I can imagine for people further outside one of those parties, it's frustrating because you're put into that slot.

And I've been very struck by-- I think when I started doing this, people would say, “Are you conservative or liberal?” Now people come up to me, “Are you a Republican or Democrat?” The label Republican or Democrat has sup planted conservative or liberal. It's not what you believe. It's what team you're on. And that's part of--

### Scientific Advocate (SA)
Claim: --feel that. I happen to be a Republican, but I am primarily a Libertarian conservative and when I go on shows, not quite the same quality of shows as David goes on-- my place-- I'm on Bill Maher-- my place is there as a sort of a kooky Libertarian conservative, a guy who's really, really conservative, really, really Republican, but thinks about marijuana, it’s a drug that makes teenage boys drive slow and what’s wrong with that? and so I think that there are broader categories than merely Democratic and Republican.

### Moderator
Claim: Okay, and gentleman in the center, if you could stand-- yep, that's you, thank you.

### Moderator
Claim: You know, it would seem obviously that the audience by the fact that we’re all here today is very interested in the debate and what the panel has to say. But it would also seem that most Americans are moderate and they don’t think in terms of left or right, but in what affects them. And it doesn’t seem that the two-party system that we have today does reflect what they want as the people.

### Moderator
Claim: Okay, so I’m taking that as a comment to this side.

### Scientific Advocate (SA)
Claim: Except in this one respect –

### Moderator
Claim: Let’s have Zev take this one.

### Scientific Advocate (SA)
Claim: Let me agree with you first of all that most Americans are not here tonight.

### Scientific Advocate (SA)
Claim: We can prove that statistically.

### Scientific Advocate (SA)
Claim: Statistically, the World Bank I do think that statements like the people don’t get what they want, that may be true, I mean you don’t always in life, right? But at least there are vehicles, that's all that a democracy can offer. It can offer ways to express yourself in the media, in new media, old media, on the street corner, in groups, however you want to do it, and politically within organized parties. Are they the Democrats and the Republicans or are they as you suggest the Republicans have changed their name to triple A so they'll be first on the ballot, you know, like--

### Scientific Advocate (SA)
Claim: I was thinking a-hole, myself.

## Round 3

### Moderator
Claim: That concludes round two of this Intelligence Squared U.S. Debate. And here's where we are. We are about to hear closing statements from each debater in turn.

Those closing statements will be two minutes each, and remember you voted before the debate and you’re going to be asked to vote again right afterwards, and this is their last chance to change your minds. So on to round three, closing statements, our motion is "The two-party system is making American ungovernable." Here to speak against the motion, P.J. O'Rourke, political satirist, journalist, and author of 13 books including "Don’t Vote-- It Just Encourages the Bastards."

### Scientific Advocate (SA)
Claim: Okay, our vague and sloppy political system keeps America away from abstract political theories. In all 20th century was an experiment in abstract political theory, vigorously applied in places like Italy, Germany, Spain, Russia, China, North Korea, Cuba, also in Rhodesia, and apartheid South Africa, and among some of my loonier friends who joined the weather underground, you know? Away from abstract political theory is a good place to be.

Our compromised and compromising system with its messy conflicts and its fitful bipartisanship, keeps governance close to real life because in reality we all contain within ourselves elements of the Democrat and the Republican. We are conservatives when we catch the kids smoking pot and we're quite liberal when we catch ourselves doing it. No one ever says “Oh, goody,” when it's time to pay taxes and no one ever turns down a government benefit. Abandoning the two-party system would mean abandoning a great truth, the truth that we're all of two minds about politics, greater certainty in our political opinions would mean more politics, more arguments, more strife, we don't need that, we've got enough, giving up on the lame old political generalities of Democrats and Republicans would make politics more important in America.

Now, as a reporter I have spent a lot of time in places where politics are a life or death matter, let's not go there. Indeed, my closing argument is a simple plea for personal mercy. I've been covering American politics for 40 years, two parties is as many as I can stand.

### Moderator
Claim: Well, thank you, P.J. O’Rourke. Our motion is “The two-party system is making American ungovernable,” and here to speak for the motion, Arianna Huffington, president and editor-in-chief of The Huffington Post Media Group.

### Conspiracy Advocate (CA)
Claim: So, if all you care about here tonight is to make P.J.’s life easier, vote against this motion. If you care about making the life of the country better, vote with us. Basically, the two- party system is like a stale marriage. Democrats and Republicans need something to spice it up. They need to go on craigslist and find a third party. And if that third party isn’t wearing a shirt, they really should do a background check. Because he might turn out to be a member of Congress, and you don’t want to go there.

So, I remember in 2000 I organized a shadow convention. The shadow conventions were intended to address issues that the two political parties were not addressing. And those issues were the growing income inequalities, the failed war on drugs that has put more African Americans in jail than that have jobs at the moment, and also the problem that was addressed here tonight of campaign financial reform and the desperate need to do that. Since 2000, all these problems have gotten worse, and they have gotten worse because the two-party system has made this country ungovernable. And unless you give up on the idea of America becoming a more perfect union.

Unless you give up on the idea of us being able to really live up to the American dream of our ancestors, then you’ve got to vote with David and me.

### Moderator
Claim: Thank you, Arianna Huffington.

Our motion is “The two-party system is making America ungovernable.” Here to summarize his position against the motion, Zev Chafets, a columnist, an author of 12 books and founding editor of The Jerusalem Report.

### Scientific Advocate (SA)
Claim: Ninety-nine years ago, a guy stood up at a political convention, a third-party convention, and he said, “We stand at Armageddon, and we battle for the Lord.” That was Teddy Roosevelt. “Armageddon” was Woodrow Wilson. It’s always Armageddon for people who have that tendency, and it’s good that there are people who think it’s Armageddon because they push. That’s a good thing.

I support that. I’m in favor of it. There’s a place for it in the political parties.

But tonight we’re talking about a specific motion, which is that the two-party system is making American ungovernable. In order for you to vote for that, you have to agree to two things. You have to agree that America is becoming ungovernable, or perhaps it is already, as Arianna said in the beginning, has become ungovernable. I don’t think that that’s the case. I don’t think that any of you who came here today by car, by bus, by train, by plane, however you got here, travelled through a space which anyone could regard as ungovernable. American is a highly governed country. It has flaws, it has problems, it has economic inequalities-- all of these things have existed, and they’ll continue to exist. They’re part of the human condition. America needs to be a more perfect society; it can’t be a perfect society because no society is perfect.

The second proposition that you have to agree to, even if you think that the world and America as you know it is ungovernable-- ungovernable!-- you have to believe that the reason that it’s ungovernable, that the BP disaster took place and the Virginia mining disaster took place, and all the other disasters took place because of the two-party system. And I don’t really think that you can make that case. And therefore, I implore you to vote for our side.

### Moderator
Claim: Thank you, Zev Chafets. Our motion, “The two-party system is making America ungovernable,” and here to summarize his position in favor of this motion, David Brooks, The New York Times op/ed columnist, commentator on the NewsHour, and coming out in a matter of weeks with a new book called “The Social Animal.”

### Conspiracy Advocate (CA)
Claim: Many of you have been looking at our side, at our table, and thought “Those two are so much alike.” Arianna’s a glamorous woman with continental manners. I aspire to be the fittest fat person in America. Arianna created a business in which people write for free, and she sold it for more than $300 million.

I have three credit cards, one of which I can use at any time. Throughout this entire debate, she’s been texting Matt Damon and Fergie. I’ve seen “The Bourne Identity.” Arianna and I agree on most things. In fact, I think I can safely say I agree with Zev and P.J. a lot more than I agree with Arianna. And yet if Arianna and I sat in a room and talked about the big issues facing our country, I bet we could reach some plausible solutions. But if we were elected to the two parties as they currently exist, we would never get in the same room because those two parties have gotten much more rigid. So when I take a look at the issues that are before us, and those issues have been alighted I think during this debate: Immigration, a vital issue about which the two parties can reach no agreement; debt, a vital issue about which the two parties can reach no agreement.

Wage stagnation and inequality, a long-growing issue about which the two parties can reach no agreements; campaign finance. I could go on. These are all concrete issues that are right here in front of us. If you see a way for our current two-party system-- if you see an avenue for them to reach agreement and solutions on these issues, even in perfect solutions, well, then vote for the guys in the red ties. But if you don't, vote for the glamorous side. Thank you.

### Moderator
Claim: David Brooks. And that completes our closing statements. All right. Now it's time to find out which side you feel argued best. We want to ask you again to go to the key pads at your seat to register your vote, reminding you you voted once before. And the team that has changed the most minds after this vote will be declared our winner. Our motion is “The two-party system is making America ungovernable.” If you agree, push number one. If you disagree, push number two.

And if you are or became undecided, push number three. And we're going to have the votes in just a minute. And I'm going to announce the winner of the debate immediately afterwards. We're going to put up on the screen how the numbers broke down according to party affiliations that you registered when you came in. I won't be announcing those, but you can look at them on the board afterwards, or you can visit us online.

A few of the things I want to take care of. First of all, I have thoroughly enjoyed this debate, like perhaps none other this group has been absolutely terrific.

I want to thank them for being smart as well as engaging and entertaining. I also want to draw attention to one of the unsung heroes of this series, Donna Wolfe who puts these things on all the time sitting in the front row.

At a minimum, you could raise your hand. There you go. . And I also want to thank the American Clean Skies Foundation who has underwritten this entire season of debates.

And thank you to them.

And what this season is about, through this spring, this winter and spring, the theme is, “America's house divided.” That's what tonight was a part of. Under that umbrella, and our next debate on Tuesday, the 8th of March, the topic is “Clean energy can drive America's economic recovery.” Arguing for that motion we'll have Bill Ritter, the former governor of Colorado who adopted one of the nation's strictest renewable energy mandates and whose state has the fourth largest concentration of clean energy workers in the country. Joining him will be Dan Reicher, the former director of Climate Change and Energy Initiatives at Google, who served as assistant secretary of energy under Bill Clinton. He now leads a new interdisciplinary center at Stanford to advance clean energy technology.

And arguing against that motion will be Robert Bryce who is the author of “Power Hungry: The Myths of Green Energy and the Real Fuels of the Future” and a self- described, quote, “Liberal who got mugged by the laws of thermodynamics.” And his partner will be Steven Hayward, the author of “Mere Environmentalism,” an examination of the philosophical presuppositions underlying the environmental movement.” I wish I had written this myself. Tickets are available through our Website and also at the Skirball box office.

And don't forget to follow Intelligence Squared U.S. on Twitter and make sure to become a fan on Facebook, and you'll receive a discount on upcoming debates. For those of you who would like to know more about our debate topics, you can go to our Web site, and we have research on tonight's debate, arguments for and against and on also the debates that will be coming up. And our website is iq2us.org. All of our debates, as I said at the beginning, can be heard on NPR stations across the country.

And you can watch them on the Bloomberg television network starting next Monday at 9:00. And you just have to visit Bloomberg.com to find your local channel. Perfect timing.

Okay. So it's all in now. Remember, our motion is “The two-party system is making America ungovernable.” And the team that has changed the most minds in the course of this debate will be declared our winner. So here are the results. Before the debate, 46 percent were for the motion, 24 percent against and 30 percent were undecided. After the debate, 50 percent are for the motion. That's up four percent. 40 percent are for the motion. That's up 16 percent. 10 percent are undecided. The team arguing against the motion, “The two-party system is making America ungovernable has carried the debate.”Our congratulations to them. Thank you from me, John Donvan and Intelligence Squared U.S.

Oh, I said what? Can I have your patience? I misread the numbers. These numbers are correct, but I misread them. I'm just going to do it one more time. And your lovely, perfectly timed burst of applause was-- you did great, but-- but not me. Here are the results. Before the debate, 46 percent were for the motion, 24 percent against and 30 percent undecided. After the debate, 50 percent were for the motion. That's up four percent. 40 percent were against. That's up 16 percent. And 10 percent were undecided. The side against the motion the two-party system is making America ungovernable has carried the debate.

Our congratulations to them.

And thank you from me, John Donvan and Intelligence Squared U.S.
