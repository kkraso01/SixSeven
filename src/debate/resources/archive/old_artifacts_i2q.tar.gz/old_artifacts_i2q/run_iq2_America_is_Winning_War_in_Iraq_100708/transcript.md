# Debate Transcript

Topic: America is Finally Winning the War in Iraq
Motion: America is Finally Winning the War in Iraq

Debate ID: America-is-Winning-War-in-Iraq-100708


## Round 1

### Moderator
Claim: Now our debaters have just come to the stage, I want to begin the evening with a round of applause for all of them. At this point, tedious as it is, I must ask you to make sure your cell phones are off…and I want to explain that, these debates are heard throughout the nation on NPR stations, 150 NPR stations. For that reason, I have to do certain bits of business that might seem somewhat inexplicable, such as repeating certain set phrases over and over again. Please understand I have not lost my mind at that point, I am simply doing the radio bits of the program and they will pass quickly. And with that I would like to introduce the chairman of Intelligence Squared US, Robert Rosenkranz.

### Moderator
Claim: Well, thank you very much, and welcome. Our debate tonight is “America is Finally Winning the War in Iraq.” Now this is—the topic is not: The security position in Iraq is dramatically improved. I think it’s very difficult to argue that one. I’d like to quote from a United States Senator who voted against the surge and still feels that his vote was correct. He said, quote, “In the 18 months since President Bush announced the surge, our troops have performed heroically in bringing down the level of violence. New tactics have protected the Iraqi population, and the Sunni tribes have rejected al-Qaeda, greatly weakening its effectiveness.” That United States Senator was Barack Obama. Most of the times when I get up before this audience to talk about the debate, I try to talk about semantics, because we don’t want the debate really to be about the language of the resolution.

But this time it’s different, this time the debate in a very real sense is about the language of the resolution. What does it mean to be “winning” the war in Iraq. Well it seems to me that there are a number of levels at which you might, uh, gauge success. First of all is the notion that after we leave, will there be sectarian violence, will there be civil war. At a minimum, the answer to that has to be no. But again…there are goals for what the domestic situation in Iraq might look like after success. A reasonably decent society, a reasonably representative government. Raising the bar even higher, US strategic interests, the US would like to have a friendly Iraq. We’d like to have security for our energy supplies, we’d like to be able to project military power in the region, to a greater extent than we could before we entered this war.

And finally there are strategic regional considerations. We’d like to be able to manage Kurdish aspirations without doing violence to our ongoing relationship with Turkey. We’d like to be able to manage Shia aspirations, without handing Iran even more influence in the region than it already has. So these are very daunting goals for victory and I’m not suggesting that we have to achieve all of them, but the meaning of the resolution, the meaning of what we mean by winning the war in Iraq, is really in a sense the subject of tonight’s debate. We have an extraordinary panel, and I’m in for a treat that many of you have already had which is the experience of John Donvan as moderator. And it’s really my pleasure to turn the evening over to John.

### Moderator
Claim: Thank you, Robert. May I urge one more round of applause for Robert Rosenkranz for making these evenings possible. I’m John Donvan, a correspondent for ABC News and ABC News “Nightline,” and your host and moderator for this Intelligence Squared US debate, Oxford-style debating, brought to American shores, where, in this program, the motion is, “America is Finally Winning the War in Iraq.” We are speaking and gathered at the Caspary Auditorium at The Rockefeller University in New York City. You will hear from four panelists on this motion, two who are for the motion, and two who are against. The debate will take place in three parts, there will be an opening section, a mix-it-up section of Q-and-A including questions from me and questions from you, the audience, and then finally closing statements.

This is a contest of persuasion. The goal of the panelists is to the change the minds of this audience assembled in an amphitheater, surrounding the stage, several hundred of you, who will come into this event, with their minds perhaps not made up, or made up, the goal of these people is to move your opinion. Shortly we will take a vote to see what your views are on this motion as you come in off the streets, but I first want to explain. In the opening round the panelists will have seven minutes each. As they approach the six-minute mark, in order to provide them with a warning that their time is running out, they will hear a tone that sounds like this— That’s the one-minute mark, we consider it rather gentle and mild. But to be taken seriously. At seven minutes, if the speaker has not wrapped up, the tone will become more insistent, more like this— And nobody wants to talk through that.

So once again the topic tonight is, “America is Finally Winning the War in Iraq.” It is time now to take our vote, and, as you see, by your seats you have a device that will allow you to vote on this motion. If you are for the motion, “America is Finally Winning the War in Iraq,” please press number 1. If you are against the motion, number 2. If you are undecided at this point, please push number 3. Does anyone need more time? It’s really rather simple. It’s time now for our panelists to begin making their opening statements, and I just want to go back, and remind people of where we were in 2006 when the war in Iraq was not going very well from the point of view of the United States, and from the point of view of President Bush, who wanted a victory.

He sought out a go-between, somebody who could make a trip out to the war front, and come back and tell him whether victory was possible, and how. The person he chose is our first panelist tonight, retired four-star general, Jack Keane, who made those trips to Iraq, and came back convinced that a surge was the way to go. Often to the chagrin of the Joint Chiefs of Staff, he made this argument to the President in a series of meetings over several weeks and months. The entire story is told in Bob Woodward’s most recent book, but at this point you certainly know where General Jack Keane stands on our motion, “America is Finally Winning the War in Iraq.” General?

### Conspiracy Advocate (CA)
Claim: Thank you very much. Appreciate that nice introduction. Somewhat accurate, somewhat inaccurate. It’s always great to be back in my hometown, New York City. I don’t need much excuse to come here, I love this place. Even though I spent most of my adult life in other places. But it always has been home, even though I don’t live here, I live in Washington, D.C. I come here for the Metropolitan Opera and my beloved Yankees. I know I’ve probably alienated half the audience now, I’m not supposed to do that. But I’m delighted to be here and obviously this is an important subject and one that Fred and I have been very much involved in for a couple years. My involvement in Iraq goes back to 2003 when I was on active duty and, I visited Iraq right after the invasion, and shortly left active duty. I joined Secretary Rumsfeld’s policy board at his request with Henry Kissinger and Newt Gingrich and Tom Foley and Freddy Clay, a bunch of others. And Iraq became an increasingly more important subject for us, as the war unfolded before our eyes and the challenges that we were facing. In 2006, I parted company with the administration and the Pentagon over the war in Iraq, because I thought—I believed our strategy was failing.

I took that message to Secretary Rumsfeld, and also the chairman of the Joint Chiefs, Peter Pace, and had devised a new strategy to help promulgate that. While I was in the throes of developing that strategy I met Fred Kagan, over at the American Enterprise Institute, and he put together a planning group that was looking at the war and a new strategy, and we found that, our ideas were exactly the same. And eventually, with others, and I may say others, that had some influence on the President of the United States to admit, that the strategy was failing, and it needed to be changed. I tell you that because, I knew what failure looked like. And I think so did you. And I also know what the word “winning,” or “success” looks like in Iraq, it’s been a stunning achievement in Iraq, somewhat unprecedented in the history of counterinsurgency warfare, for such a dramatic turnaround in such a short period of time.

And that stunning achievement that…you are generally familiar with it. But it’s based certainly on a new strategy, but it’s also based on the premise that security was a necessary precondition for political and economic progress. We had never had that, as a staple, before we tried to do it complementary among those three issues, and that blew up and failed. That’s the reality of it. So we had to get security if we were gonna make political progress and that is a stunning achievement, in such a short period of time. Zero ethno-sectarian violence. All of the violence dramatically down 60 to 80 percent depending on the category, I won’t go into the details of all of that, some of you are familiar with it but it’s quite remarkable. Most of the time, we go to Iraq every few months, about every three months for two weeks at a time, we spend most of our time with the Iraqi people.

Out on the streets where they are, in the schools, in their hospitals, seeing what life was like, in 2006, no children going to schools, hundreds of people being killed every week, people not going to their jobs, only going to marketplaces to seek provisions on an emergency basis. Terrorized and intimidated, a country fracturing, heading towards civil war, it was not a civil war, and a possibly failed state. The conditions in Iraq today and gradually improving over 2007 and 2008 are a dramatic difference. Schools, all schools, are open, in Iraq. Primary, secondary, and 27 colleges, universities and technical colleges that they, they have in Iraq. The marketplaces are teeming, there’s a social fabric in Iraq that’s taken place in the evening, or on the days off when people are visiting zoos and what’s left of museums and, the, the natural rhythm of life is returning to the people of Iraq.

Iraq is all about its people, in my judgment, so that is why we spend so much time understanding what happened to them, and what is now happening to them. And it’s fascinating to see. The security situation dramatically improved because the mainstream Sunni insurgents who started the war have capitulated. They have surrendered. They are coming into the political process, to achieve their political objectives. And that is a dramatic turnaround and that’s how insurgency—either insurgencies end when they walk away and leave the field of battle or they come into the political process. The al-Qaeda have been operationally defeated. They no longer threaten the legitimacy of the regime. They cannot mount a sustained campaign to do that. They don’t have the infrastructure or the networks to do it. Shia extremism, has had a major setback supported by the Iranians, and as time appears to be playing out for us, it appears that it’s going to be a major defeat as well.

The impact on the political process, is extraordinary, there’s a rising political class in Iraq, that we have seen. Every place you go in Iraq, people are interested in the political process.

Participating in it, there are 500-plus parties in Iraq. I mean, we struggle with these two that we have. To say the least. Can you imagine what it’s like. The youth in Iraq, and we’ve attended some of their party meetings, it’s wonderful to see their energy and their motivation and to participate in something that’s all new to them. A fledgling democracy. It’s fascinating to see this taking hold in Iraq. The national legislative benchmarks, 18 of them have been… Only one out of the 18 has not succeeded, and that is really, quite dramatic.

The political reconciliation that has taken place in Iraq is very real, the most recent one is the Provincial Election Law, which will redefine Iraq, it is a seminal event. Power will be shared, and diffused in the provinces, the people will get better services as a result of it, they will have their own budgets, they will have a place to go to express their grievances and their needs. Iraq will never be the same again as a result of what is gonna take place in January of this year. Less than three years after this government, as inefficient as it has been at times and ineffective as it has been at times, when you draw back from it, it has been a remarkable movement towards what the premise is here. Success in Iraq, success in Iraq for them, and success in Iraq for us.

### Moderator
Claim: Thank you, General Jack Keane, arguing for the motion. When a guy hits it big in software and then he sells his company to Microsoft for more than $100 million and then he decides that he wants to start making movies, there is a tendency to think well maybe here’s another rich guy with a vanity project on his mind, except that the movie that our next panelist made, his name is Charles Ferguson, it’s a documentary on the US experience in Iraq. It premiered last year and was almost universally reviewed as superb and serious and ultimately became a contender for an Oscar award. Though he did not oppose the invasion of Iraq initially, the title of his film tells you where he stands now, very quickly, it is called, No End in Sight. Charles Ferguson, arguing tonight against the motion.

### Scientific Advocate (SA)
Claim: Thank you very much, I made this film actually, largely because of my heritage as a policy wonk, before I made money, I got a doctorate in political science at MIT, my thesis advisor, Carl Kazin, had been Deputy National Security Advisor for President Kennedy. And he endeavored to teach me to think rigorously about these matters and I will leave it to you to see whether he succeeded to any measure. He also had a wicked sense of humor which I will feebly attempt to imitate. If the entire cast of “Saturday Night Live” had somehow gotten together with the Marx Brothers, the Three Stooges, and Charlie Chaplin, and they had tried, in their wildest dreams, to think up a catastrophe of a war, they could not possibly have become remotely close, to what the Bush administration did in Iraq. And, I will endeavor to demonstrate that, in the remaining time of my remarks, damage on that scale is not repaired with a surge, it is not repaired over a short time, this is something that that nation and the United States and the world are going to be recovering from for decades.

And, if you think that we’re winning the war in Iraq in any meaningful sense now, then, I invite you to wait a few weeks when the Dow is down to about 2000, and Henry Paulsen stands on the rubble of the American financial system and declares victory when the bleeding has stopped. That would be a roughly comparable—and I’m sure that will happen soon—that would be a roughly comparable kind of event. Why was this war fought in the view of those who decided to fight it? I was an ambivalently, complicatedly, slightly favorable towards the war kind of person, or towards the idea of deposing Saddam. It was fought to remove the threat of WMD from Iraq, and also from the region. To install a pro-Western democratic government, to bring peace and freedom and liberty and security to the population of Iraq and also to spread that to the entire Middle East.

It was also intended to assist the United States in bringing economic, diplomatic and military pressure on Iraq so that it would stop developing nuclear weapons. The administration predicted, and, sometimes said this publicly, believed it internally, widely known, widely quoted, that the costs of the war might reach $50 billion. And that US forces would probably be substantially withdrawn by September of 2003. So, what happened. Not enough troops were used. Planning for the war began 60 days before the invasion, planning for—excuse me, planning for the occupation, began 60 days before the invasion. It was vastly inadequate. Looting destroyed the entire country, most of its infrastructure, 16 of 20 ministries, most important infrastructural objects, power plants, et cetera, were destroyed by the looting. The looting went completely unchecked by US forces.

Ambassador Bremer when appointed, before he had set foot in Iraq for the first time in his life, a man who had never served in the military, never overseen an occupation of any kind, on May 9th, 2003, he decided that he was going to issue a de- Baathification order, which lopped off and purged for life the top 50,000 administrators and technocrats in Iraq. He then disbanded the Iraqi military, throwing half a million soldiers onto the street, unemployed, with no notice. Who promptly formed the insurgency. Virtually nothing was done about the insurgency, for quite a long time its existence was denied. Economic policy was placed in the hands of politically appointed ideologues. And what did we see as a result. 4,000 Americans dead so far, a trillion and a half dollars spent, 100,000 Americans wounded, twice the official number. The official number is a vast underestimate.

And an Iraq that is just destroyed. Of Iraq’s 34,000 physicians, 2,000 were assassinated, 20,000 left. 25 percent of the population of Iraq is either dead, or is displaced internally, or is external refugees, the equivalent of 60 million people in the United States having left the country. At the peak of the violence, several hundred people per day in Iraq, were being kidnapped or killed. Okay, so, but what of Iraq now, I hear you say. Has this country become a paradise. No it has not. Violence is down. It’s down roughly 75 percent, we don’t know exactly how much. To some degree a sense of normalcy is returning to the country. People are haltingly able to go to school, to go to work now in ways that they previously were not. But, the infrastructure of the country remains destroyed, by most indicators, it remains below pre-war levels, in matters such as water supply, sewage treatment, electricity, power generation.

The country is enormously traumatized, it went from being 55 or 60 percent Shia to now, probably 80 percent Shia because the refugees are overwhelmingly Sunni. And a population and a government increasingly dominated, already thoroughly dominated by rather extremist, fundamentalist Islamic parties and beliefs. It’s difficult to believe, but Iraq still with the violence down 75 percent, Iraq is still a more dangerous place and a more hostile place, and a worse place, for most people, than it was under Saddam Hussein. That is difficult to achieve. But we managed. In addition, we have enormously strengthened Iran, which is continuing to develop nuclear weapons, unchecked by the United States. The American military is debilitated and tied down in this country, unable to do anything about the rapidly worsening situation in Afghanistan and Pakistan. The military is exhausted. And, as far as I know, those 4,000 Americans are still dead, those half-million Iraqis are still dead, and the situation remains, I fear, irretrievable. Thank you.

### Moderator
Claim: Thank you, Charles Ferguson, I’m John Donvan, and this is Intelligence Squared US, Oxford-style debating. We have four panelists, for and against our proposition, which tonight is “America is Finally Winning the War in Iraq,” we are halfway through our opening statements, and we’re now going to turn to once again to the side for the motion. Jack Keane’s debating partner, as he mentioned, was also his partner in advising the administration on going ahead with the surge and as General Keane pointed out it wasn’t just the two of them, there were other people. But Fred Kagan has been universally described as the architect of the surge at the American Enterprise Institute. He put the words on paper and connected the dots and drew up the charts and put together most cohesively the argument that ultimately persuaded the White House that the surge was the way to go. He is very much a player in the story of the surge having taken place. Arguing for the motion, “America is Finally Winning the War in Iraq,” Fred Kagan.

### Conspiracy Advocate (CA)
Claim: Thank you very much, it’s an honor to be here, it’s an honor to be talking about this extremely important topic. I might object to, excessive levity and discussions of Marx Brothers and so forth, in regard to a war that has cost the lives of many thousands of people, I actually think this issue’s a little more serious than that frankly. Without meaning to spend my time taking on directly the comments that were just made I’m going to mention a couple of errors of fact.

Electricity production is higher than pre-war levels in Iraq, that is a fact. The country is not 80 percent Shia, although I’m sure that some of the Shia parties would like to believe that. But it absolutely is not. And is life worse than under Saddam, well, that depends on who you are. And, this has definitely been a traumatic, miserable experience for the Iraqi people. I am in full agreement with the assertion that the Bush administration planned for the war badly, conducted the war badly, lived in denial for years. I was on record for all of that time, criticizing the strategy that was being pursued, criticizing the administration…I get it. It’s also irrelevant, to the point at hand. And it’s unfortunate in our national discourse, that we spend so much of our time refighting the issue of whether or not this was a good idea, and not enough time talking about where we are, where we’re headed, what our interests are, and whether we are likely to be able to achieve them.

Which is from the standpoint of a decision-maker, the only thing that matters. And particularly since, President Bush, will not be running for office again, the question of his wisdom or un-wisdom in ordering this war, is something that can be safely left to the historians at this point. So, the question is where are we now, and the question the motion has put is, are we winning the war.

I would like to amend the motion to say, “America and the Iraqis Are Now Finally Winning.” Because one of the things that has gone unnoticed, is that, a tremendous portion of the fighting that was done over the past 18 months was done by Iraqis. Including the 100,000 Iraqi security forces that came on line, in a year, trained in contact with the enemy, marched directly into the fight against the enemy, both Sunni and Shia, and defeated the enemy across the board with American assistance of course. It was a remarkable thing.

One of the most remarkable instances of this, was when Prime Minister al-Maliki ordered the Iraqi security forces to clear the city of Basra, which was under the control of enemy groups of one sort and another. And, the initial operation was a disaster. We worked hard to help him fix it, he worked hard to fix it, and one of the things that he did to fix it, was to order the quick reaction force of the First Iraqi Army Division, to reinforce. That division is based in Anbar. It is a heavily Sunni division. It marched into Basra, where there are virtually no Sunni, and immediately began fighting against local militias and criminals. There were no instances of sectarianism, either by that formation or against that formation. It was accepted, as the legitimate military force of the government of Iraq, acting against criminals and enemies of Iraq. As an instance of reconciliation, and what this government means to Iraqis now, there are few cases that could be more poignant than that.

That formation remained in the south, it continued to fight right up to the Iranian border…which also sent a message to Iran by the way. And as we talk about how Iran has been strengthened by this war, we need to talk about how Iran has been dealt a tremendous defeat, by the destruction of its key proxy in Iraq, Muqtada al-Sadr’s Jaysh al-Mahdi, which organization was militarily defeated, and has now largely disbanded politically as well. Muqtada himself is in disgrace, and the Iranians are scrambling, and hoping, that we will take council of our despair and leave Iraq to its fate. The question will be put…was this war worth it. I would submit, that that’s a slightly different question from whether we are winning or not and we can parse the semantics of this any way you like.

As a military analyst which is all that I am, I can tell you, the trend lines now, are positive. The importance of the elections law that was just passed, passed most Americans by. It is a watershed event. And I can tell that, because I’ve had in the past few weeks, conversations with senior politicians, senior Iraqi military leaders, I’m sorry, senior Iraqi politicians, Sunni and Shia, and before that law was passed, they were very grim, and very gloomy, and so was I. After that law was passed, the nature of the conversations that I had with these gentlemen, changed entirely. And instead of the gloom and doom, we had, almost wistful conversations about, how Iraq will form itself into a country. How the Sunni and Shia will work together, what the relationship between Arabs and Kurds will be, and they also all made to me an interesting point.

They said, you know, Iraq will be a rival to Saudi Arabia. A rival in oil, and also, a threat to Saudi Arabia because Iraq will be a democracy. And Iraq will pose a challenge to authoritarian regimes around the region, and Iraq will be aligned with the United States. They were telling me that. Now I believe that that’s true, and I believe that it is attainable, and I think that the evidence shows that, and I think that, if we are in fact headed in that direction and we can in fact make that happen, then, this war will have been worth fighting. Thank you.

### Moderator
Claim: Thank you, Fred Kagan, speaking for the motion. Sir Malcolm Rifkind has held the post of Foreign Secretary of the United Kingdom and Defense Secretary, a combination that, in this country the only figure I can think of to have comparably held the positions of state and defense would be George Marshall. You can tell me, Fred, if I’m wrong on that. He is a friend of the United States as a member of the Conservative Party who’s been in politics for 40 years, a supporter of many American policies and the special relationship, but when it came to Iraq, he said no. He was against going in, he is against staying in now, and he will be arguing against the motion, Sir Malcolm Rifkind.

### Scientific Advocate (SA)
Claim: Thank you very much indeed for your warm welcome. Lyndon Johnson once said that was the sort of introduction which my father would’ve enjoyed and my mother would’ve believed. I’m conscious that I’m the fourth person to speak this evening so I will say what King Henry XIII of England is reputed to have said to each of his six wives. “Please don’t worry, I don’t intend to keep you long.” I was at first concerned when I was asked to take part in this debate, whether, as a British politician, I should be speaking in a debate about the United States. But I reflected that George W. Bush’s closest ally in the decision to go to war, was Tony Blair. British troops have been in Iraq over those five years, British soldiers have died, and Britain and the United States share a responsibility, along with other coalition countries, for what has happened. I don’t dispute for a moment that the surge to which reference has been made this evening, has been successful in military terms, in reducing the amount of violence. I don’t doubt that the insurgency itself, may be slowly coming to an end, and that fewer people are being killed on the streets of Baghdad, than was the case in the past. But of course that is true of all wars, all wars gradually grind to an end, in one form or another.

But that is not the same as saying, that you have won that war. Because to say that you have won or are winning the war, you have to answer two questions. First of all, are we going to achieve the reasons why we went to war in the first place, either in whole or in part, and even if we were, does the price that has been paid, by the people of Iraq and by the West as a whole, make that sacrifice having been worth being made. Now when you look at what the plus side is, and there’s one factor that also has to be mentioned at this moment. This is not a war like Pearl Harbor. Or like the war in Afghanistan after 9-11, or the first Gulf War to liberate Kuwait. You are wrong, General Keane, to say that Sunni insurgents started this war, they didn’t. The United States, the United Kingdom and the coalition started this war, and they had not been attacked when they chose to do so.

So what has been achieved. Let us be generous and acknowledge, certain things have been achieved. Saddam Hussein is gone and there isn’t a person who will be other than pleased to see him go. But you know, we’d like to see Mugabe go without going to war in Zimbabwe, we’d like to see Kim Jong-il in North Korea go. We’d have liked to have seen Fidel Castro go. These are not justifications for a war. And yes it’s true, Iraq may have a more representative government than it’s had for many years. But it’s not a democratic government, it’s a sectarian government of finely balanced Shia and Sunni, who when they’ve not been slaughtering each other in the last five years, have formed a very, very uneasy coalition. And yes, fewer people are being killed. But by God, you know, that can rise again, at any moment, for all we know. When you look at the price that has been paid and continues to be paid, that cannot simply be put on one side, as simply history, as Mr. Kagan implied.

We know that first of all that the weapons of mass destruction which were the main reason for going to war, never existed. We know that by the admission of President Bush, at least 30,000 Iraqis have lost their lives, and indeed the Iraqi government say over 100,000 Iraqis have lost their lives in the last five years. We know that four million Iraqis have become refugees, half of them fleeing to other countries. 40 percent of the Iraqi middle class, no longer live in Iraq, and as a consequence, the job of rebuilding Iraq is going to be immeasurably more difficult. And we know also that the coalition forces, mainly American, have lost over 4,000 lives. These are a heavy burden. But it’s not just the internal cost that is being paid, look at what has happened in terms of the wider situation. We know for example that the consequence of this war is that Iran…the most dangerous country in the region, has, thanks to the United States and the coalition, now become the most powerful country in the Gulf.

The Iranians cannot believe their luck. Without raising a finger, Iraq which was the state that was their main competitor in the Gulf, has been essentially emasculated, for the foreseeable future. We know that al-Qaeda, who were never allowed to operate in Iraq under Saddam Hussein, have been active, have penetrated Iraq and even if they are ultimately defeated, have already radicalized sections of the community and done enormous harm. We know that the new Iraqi government is not going to be any more pro-Israeli, than any other Arab state, why should they be, they are an Arab government, they will share the view of the Arab world. And we know also, that the United States in particular, has lost at this vital time its moral leadership of the world, because of having initiated this terrible conflict.

But perhaps the most serious geopolitical problem, that has flown from this ill-judged initiative and invasion, has been that the real drama of the present time in that region, is Iran’s attempts to develop nuclear weapons. And we know that as a consequence of the loss of authority, of the loss of leadership, that the United States in particular has experienced as a result of the Iraq war, the United States has found it incredibly more difficult to get agreement either in the Security Council or in the international community, to take the kind of steps against Iran, that would be necessary in order to encourage it to desist from its nuclear ambitions. So when you talk about “winning the war,” it’s not possible as General Keane implied, to simply think of that in purely military terms. One has to look at the overall cost, and the overall benefits. And I conclude simply by saying this. At best you can say, we may be stopping losing the war, but we’re certainly not winning it. And I simply remind you of the words said almost 2,000 years ago, by Tacitus, a great Roman, when in comparable circumstances, he said, “They have created a wilderness, and they call it peace.” That is our legacy.

## Round 2

### Moderator
Claim: Thank you, Sir Malcolm Rifkind, arguing against the motion, we have the results of your points of view with which you arrived for this debate, they are rather lopsided. Those of you who are for the motion, that “America is Finally Winning the War in Iraq,” represent 20 percent of you, 54 percent of you are against the motion, and twenty-six percent of you are undecided. And again, the point of the evening is to see the degree to which those numbers can be moved by the quality of our debate. Now we’re going to move into the mix it up section of the program, and at this point I’d like you to begin formulating the questions that you would like to ask. I know that there are some journalists that would like to ask questions. When they are called upon we would prefer that you identify yourselves, and your organization. The rest of you may remain yourselves, or remain anonymous. We have microphones moving through the hall, and once again to remind you to please hold the microphone very close to your mouth. But, I want to start with the question to Charles Ferguson. Charles, I heard you outlining, in some detail, why going to war in the first place, perhaps, was a mistake, and why the war was prosecuted badly in its first stages, which is a separate question from, now going forward, is the US winning, or can the US win? And I want to ask you what would be victory from your point of view, putting aside whether the war was a mistake in the first place.

### Scientific Advocate (SA)
Claim: Well, I think we’ve, I think we’ve reached the point at which a victory by any meaningful standard is no longer possible. I think that we’re simply now trying to reach a situation that represents some minimal level of stability and some reasonable degree to which our enormous mistakes have been redressed or stabilized.

The reason that I mentioned the way we conducted the occupation, is that the enormity of those mistakes and their consequences are going to be with us for decades—

### Moderator
Claim: Well, what would have been victory, is more my question?

### Scientific Advocate (SA)
Claim: Oh, I'm sorry. If indeed Iraq had been stabilized, if there had been, as almost every pre-war advisory study recommended, if there had been a larger number of troops, if there had been a large number of Arabic speakers, if there had been a large international constabulary force, if the country had had a transitional period of martial law, and then after that gave way to, or was turned into something from a full democracy, which I think that most analysts think was quite unrealistic, but a soft dictatorship, something more like Egypt, say. Then that would have been, if not a victory, something that would certainly not have been a complete, unmitigated disaster.

### Moderator
Claim: Fred Kagan, did you hear in that answer any benchmarks that you think are, are in the process of being hit?

### Conspiracy Advocate (CA)
Claim: I'm troubled by the notion that you can simply dismiss the entire question of whether we’re winning or not by saying that the sum cost is already so high that nothing we could do could conceivably make it worthwhile. Which is rather an intellectual cop out in my opinion. It strikes me that, um, one still has to ask the question, what is the situation that we face, and what are the probabilities of obtaining our objectives? I would say, although I'm fully in agreement with you about the mistakes that were made, I believe that we have actually obtained many of the goals that you’ve just laid out. We clearly have a disagreement about the facts. I do believe that Iraq is being stabilized. With all respect, Sir Malcolm, I do not think that it is likely that you will see violence suddenly explode again, unbeknownst to us. Because when you make it your mission to go around Iraq on a regular basis, and to see what’s going on in the particulars, rather than having this conversation from thirty thousand feet about Sunni and Shia who don’t like each other and are killing each other, and so forth, what you will see is that violence in a particular area results from circumstances in a particular area, there are larger issues of course, but it is astonishing how fractal the complexity of this country is. And the fact that, what I would like to do is have a conversation with you region by region, area by area, and talk about what had been generating violence, why it’s not there anymore, and why I think that it will not be coming back anytime soon in that form. That's how life really works. And that is what we see on the ground. And we see a government forming that is increasingly seen as legitimate by its people, which is astonishing. We see elections coming up that have galvanized and excited the Iraqi people like few things before. And the astonishing thing is having spoken with Iraqi political leaders, Sunni, Shia, and Kurds, they all think that efforts will be made to rig the elections. They all think that some of those efforts will succeed, and they all expect to abide by the results of the elections. In my mind, that’s a very healthy understanding of what democracy is likely to be like.

### Moderator
Claim: Fred, let me bring, Sir Malcolm, it sounds like you were contradicted there. Could you, I just want to ask that you sit a little bit more—

### Scientific Advocate (SA)
Claim: Sure. Mr. Kagan claims that winning the war is because the fighting may be coming to an end. There has never been a war in the history of mankind that does not eventually come to an end as the people involved exhaust themselves. And let us accept that al Qaeda is not going to be the victor in this war, although they’ve already been responsible for many people’s deaths. The point that I have to keep emphasizing is that the, the sheer trauma, the sheer disaster that Iraq has been for the last five years wasn’t just predictable, it was predicted. If you go into a country and destroy its government without understanding the nature of that society, and if you remove an existing regime, you create a political vacuum. And in a situation where Shia and Sunni have been enemies for hundreds of years, it was inevitable that there was going to be this outburst of sectarian conflict. If the United States and the United Kingdom did not understand that or did not accept that, then they're even more culpable. So, to say that now we may be in a situation where the fighting may be slowly coming to an end, and to see that as winning the war, as if somehow we can simply ignore what has come before—

### Moderator
Claim: General Jack Keane—

### Scientific Advocate (SA)
Claim: It does not bear credibility.

### Moderator
Claim: General Jack Keane, for the motion.

### Conspiracy Advocate (CA)
Claim: I think coming to an end is a condition that enables us to make political, and eventually economic progress. And that is why it’s so important, because we could not do that with the hell and chaos that was taking place in that country. The political progress is dramatically real. If you just listen to what he Shia dominated government that Sir Malcolm just wipes away as, as not having any intention of building a better Iraq, this government has passed a de-Baathification law which changes the very social fabric of life in Iraq. It’s equivalent to our civil rights legislation, which took us a hundred years past the end of the Civil War. It permits the Sunnis to participate in the full fabric of life where they were denied that participation by Paul Bremer and our policy back in 2003. The Shia dominated government passed an amnesty law which will free thousands of Sunnis from jail, who were trying to kill that government and return to power themselves. They have done that. Why have they don’t that? Why have they made that decision? They made that decision because they know that they have to reconcile with the Sunnis and with those who wanted to regain power if they're going to have a future. That is a courageous decision that they’ve made, even given the limited political experience that many of these leaders have had who have been thrust into these positions in the last three years as, where there was thirty-five years of autocratic repression in this, in this country. That is dramatic change that is taking place in Iraq, and it has to give you a sense of hope. Our objectives are pretty clear, and we’re well on our way to achieving them. We want a government in Iraq that is elected by its people. That has already taken place, and will be reinforced by the provincial elections which will further defuse that, and make it even a more powerful political model. There will be also national elections in 2000, at the end of 2009. We want a country that is stable and secure and capable of protecting its people. And that is taking place, and is not a threat to its neighbors. We do not want it to be a haven for radicalism in the region, to be sure. And that has been rid of. They came there because of our presence, to be sure, but also Saddam Hussein attracts radicalism. And I'm not re-fighting why we went into the war, I'm trying to deal with what we have here, and the opportunity that is front of us in terms of what our realistic objectives are. We have a country that wants to be aligned with us, that wants a strategic political relationship with us, that crosses education, political, cultural, educational ties. They do not want that kind of relation with the Iranians, they want it with the United States of America. Therefore, we will have the opportunity to have that kind of a strategic relationship with a duly elected government, the only government of its kind in the region, an Arab-Muslim country that has a duly elected government, and is aligned with the United States, and is a clear buffer against a threat in that region, which is radicalism, and particularly in the Iranians. It already is a buffer, and it will be a greater one as this country continues to mature.

### Moderator
Claim: General, let me bring in Charles Ferguson. Charles Ferguson, General Keane just said we want a government that is elected by its people, and we have that. Do you dismiss that?

### Scientific Advocate (SA)
Claim: I don't entirely dismiss it. There is some degree of reality to Iraq’s democracy. But a few points. There are many countries in the world which hold elections, sometimes even elections that kind of mean something, Zimbabwe for example. Transparency International hasn’t announced its 2008 ratings yet. In 2007, the most recent year for which we have available, Transparency International rates countries on its corruption index, by their level of national corruption. Iraq was rated number one hundred and seventy eight out of one hundred and eighty countries. And most of the people with whom I speak, with great regret, I have not been back to Iraq since mid-2006 when I was there for the film. But, I stay in touch with many people, and just about everybody with whom I speak says that the corruption problem has gotten notably worse since 2007 and continues to get worse, and this society is really, in many ways, approaching breakdown, even though by some measures, some very real, significant measures, it is improving. But if you're a woman in Iraq—

### Moderator
Claim: Well, just a minute, Jack Keane explained a situation where people couldn't go to school, they're going to school again, they couldn't go shopping, they're going shopping again, which does not sound like a society that’s breaking down, it sounds like a society that’s knitting together.

### Scientific Advocate (SA)
Claim: I think both are happening at the same time. But, for example, have any of the refugees returned? No. In fact, there is—

### Conspiracy Advocate (CA)
Claim: Yes, they have—

### Scientific Advocate (SA)
Claim: A very small number—

### Moderator
Claim: That’s Fred Kagan interrupting.

### Scientific Advocate (SA)
Claim: …there is still a net out-flux of ten thousand per month.

### Moderator
Claim: What about that, Fred Kagan.

### Conspiracy Advocate (CA)
Claim: I'm sorry, that’s just false. Refugees have returned. If you say, have any refugees returned, the answer is yes.

### Scientific Advocate (SA)
Claim: A tiny number—

### Conspiracy Advocate (CA)
Claim: If you say—

### Scientific Advocate (SA)
Claim: On a net basis, they are still leaving.

### Conspiracy Advocate (CA)
Claim: Are people leaving, that’s fine, we can have that conversation.

But there have been refugees returning, there have been IDP’s returning as well. This is a process that has been, that is ongoing, and I'm sorry, you have to, you have to recognize that. This is not the case where people are still fleeing the countries in droves, and that’s all that’s going on. You’ve got movement back and forth. One of the most important things that’s happened is that key leaders in Anbar, who had fled because of the al Qaeda violence, have returned. That was a key element of the Sakwa they have come back and taken up their traditional positions in society, which is one of the things that has allowed the creation of a new political dynamic in what had been the hot bed of the Sunni insurgency, and they are now participating in the Iraqi political process. Those returnees may be small in number, but they are incredibly important for the future of the country.

### Moderator
Claim: As your moderator I'm hearing not just a difference of opinion on interpreting the facts, I'm hearing a difference of opinion on what the facts are. For example, the question of electricity, either there is more electricity than before, or there isn't.

### Conspiracy Advocate (CA)
Claim: There is.

### Moderator
Claim: Which is it?

### Conspiracy Advocate (CA)
Claim: There is. There is.

### Scientific Advocate (SA)
Claim: Hold on, let me get this in perspective. No one—

### Moderator
Claim: Sir Malcolm Rifkind speaking.

### Scientific Advocate (SA)
Claim: No one is, I think, suggesting that there is more electricity than there was before this war began. All that Mr. Kagan and General Keane are saying is the war which we were responsible for creating, which destroyed Iraq’s infrastructure, which destroyed its schools and its hospitals and its electricity and drove millions of people abroad, all they are able even to claim is it’s now beginning to go back to what it was before we started this war. Now, if that is the culmination of this terrible five years, it’s not exactly something we can be proud of.

### Conspiracy Advocate (CA)
Claim: That’s not what we’re saying—

### Moderator
Claim: Fred Kagan—

### Conspiracy Advocate (CA)
Claim: And that is not the case. Electrical generation and transmission in Iraq is higher, in fact significantly higher than it was before the war.

### Scientific Advocate (SA)
Claim: It is, in fact, that is true, it is, I'm sorry, I did make one misstatement, it’s about thirty percent higher than it was before the war.

### Moderator
Claim: Charles Ferguson.

### Scientific Advocate (SA)
Claim: Most other indicators, most other quality of life and infrastructural indicators, the availability of water, the availability of sewage treatment, the availability of education, et cetera, remain enormously below their pre-war levels.

### Moderator
Claim: We have several hands up, and I want to bring the audience into the conversation. Again, my reminder, please perfect the art of the well-asked question, and hold your microphone quite close to your mouth, about one fist away. A gentleman who is now standing up…? The microphone being brought to you. About halfway up the amphitheater.

### Moderator
Claim: I thought this was supposed to be a debate with two people speaking for the motion and two against, but we’ve had four people speaking for the motion. The point is that Mr. Ferguson and Sir Malcolm have said, you know, that things are getting better. And if that’s not a step towards winning, I don’t know what is. I think that Mr. Ferguson and Mr. Malcolm are debating not a question that’s asked tonight, that’s on the board. They're debating a question—

### Moderator
Claim: So what, formulate a question—

### Moderator
Claim: And the question I want to ask them is, do you have any argument to show that America is not winning the war right now?

### Moderator
Claim: Sir Malcolm?

### Scientific Advocate (SA)
Claim: If you mean winning the war means gradually getting domination over the insurgency, if that’s all you define as winning the war, I happily acknowledge that. And I said earlier, all wars eventually come to an end, and if the world’s great super power is not able to beat some insurgents in Iraq in military terms, it would be a very strange situation. But winning the war means actually achieving the reasons why you went to war in the first place. And by that definition, which is the only meaningful definition, no, we are not winning the war, it remains a total disaster for the people of Iraq, as the hundreds of thousands who have lost their lives, or who have been injured in this war, would happily testify if they were alive and able to do so.

### Scientific Advocate (SA)
Claim: I thought that both of us made it clear that we thought that this war had discredited the United States in the Mid-East and the entire world, had left Iran stronger, had pinned down the American military in Iraq so that it was able to deal with Afghanistan and Pakistan and a number of other issues. I thought we had made that fairly clear, actually.

### Moderator
Claim: Question from the audience.

### Moderator
Claim: I’d like to ask the, for the motion—

### Moderator
Claim: Can you put that mic really, that’s it, thank you.

### Moderator
Claim: I’d like to ask the for the motion group to comment on some of the scary statistics around the flight of professional and middle class, and what do you see as the facts and the reality today of where the country stands. And then how does that evolve or correct itself going forward as the country builds?

### Moderator
Claim: Now that’s a question. Jack Keane.

### Conspiracy Advocate (CA)
Claim: Well actually, I'm going to start off.

### Conspiracy Advocate (CA)
Claim: Fred is going to start off.

### Moderator
Claim: Fred Kagan, his partner, will go first.

### Conspiracy Advocate (CA)
Claim: I, it’s interesting, I just had the, this similar conversation with a senior Iraqi military leader last night, in fact. And he made a point that the flight of the middle class in Iraq, and the technocratic class began, in fact, with the rise of Saddam, when you had a tremendous number of highly educated people flee the country. It certainly was exacerbated as the Baathist elements and the Sunni community, elements of the Sunni community, and also Shia community, there were Shia Baathists, we tend to forget that, fled. Are those people coming back? On the whole, no, they're not coming back. Will they? It remains to be seen. What’s going on is the formation of a new government in Iraq. It certainly was set back by mistakes that we made early on, the excessively harsh de-Baathification policy. On the other hand, there is an analogy to the de-Nazification strategy after World War II, and there was a lot of controversy about that. If you want the people who will administer the country efficiently, then going back to some of the people who were involved in the previous dictatorship might make sense. Although I would point out that that was the most corrupt and inefficient and ineffective dictatorships that there has ever been at everything except keeping itself in power and threatening its neighbors. And so it’s not as though there was exactly good governance in Iraq before 2003, and it’s not as though there was a large cadre of government officials in Iraq before 2003 who you would have wanted to see in senior positions now. Nevertheless, excessive de-Baathification set the process back. What we are seeing now is the construction of a new Iraqi society. This will take a long time. And I think part of the problem that we have in this discussion is that we tend to conflate the question, are we winning, with the question, have we won? The truth of the matter is, we are winning in the sense that, we respect, Sir Malcolm, not just in the matter of military arena, but in respect to politics, and also now finally economic development, we are moving in the right direction, we do see the formation of an Iraqi bureaucratic class. We do see the development of Iraqi technocrats, small in number, ineffective in some respects, still learning the ropes as they develop a new system, but we are making progress. We will have achieved, when we have achieved the aim of working this all out, we won't be winning, we will have won.

### Conspiracy Advocate (CA)
Claim: Let me add to that.

### Moderator
Claim: Jack Keane.

### Conspiracy Advocate (CA)
Claim: Because some of you may be thinking about that. When we talk about a long struggle in Iraq, we do not mean a long troop presence in Iraq. All of us believe, strongly, that we will reduce our forces in 2009, we’ll even more dramatically reduce them in 2010, and I have held the view, if you put Maliki’s number on the table, number and date on the table with Obama’s, McCain’s, and Petraeus’s, they wouldn't be that far apart. And I think that’s where we are, to be quite frank about it. In terms of our combat forces coming out. Because their presence is needed right now to see through the political process, to make certain that these provincial elections are not maligned, and to make certain that the national election is not maligned. We don’t have those large forces there because of the insurgency or because of the al Qaeda. We want to make certain that the political process is moving forward, and the US and coalition presence in Iraq has been the glue that has been holding things together. It is a myth that has been perpetuated, and people who perpetuate it don’t know the Iraqis when they say, by pulling our forces away, somehow that would be a catalyst and a call to action for the Iraqis to do something that they're not capable of doing while we’re there. We have been the catalyst and the glue that have helped them, and our presence has been very important. And that presence is going to dramatically change in terms--it already has in terms of casualties, that’ll continue to go down to almost nothing. And also the numbers of our troops will dramatically go down over time as well. I just want to clear that up, where you have long term political objectives in Iraq, that does not mean that we’re going to have combat troops in Iraq fighting in Iraq for years to come.

### Moderator
Claim: Sir Malcolm, I see you taking notes on that, do you want to respond?

### Scientific Advocate (SA)
Claim: Well, I think that there are always going to be good consequences of bad wars, just as there are sometimes bad consequences of good wars. What you’ve got to do is come to an honest judgement as to where the balance lies. Have the sacrifices been worthwhile, of the Iraq people, of the American people, of the coalition forces, but particularly of the Iraqis. Is the net effect of this terrible five years something that was worth doing in the first place? If the answer is, no, it wasn’t, then the fact that there have been some benefits, sure, that always happens even in the worst wars for the worst reasons.

### Moderator
Claim: Your comment on sacrifices raises for me the question of the price that has been paid in blood. And I want to ask, with as much sensitivity as possible, and as much honor for the families of those who have lost soldiers, Charles Ferguson, did those men die for nothing?

### Scientific Advocate (SA)
Claim: I think it’s worse than that, I think it’s much worse than that. I think that history is going to record George Bush as one of the most horrifically arrogant, rigid, stupid, inhumane morons we have ever… It, look, in my film, six minutes into my film there is a clip of a very intelligent, honest, accomplished man who was the chairman of the National Intelligence Council from 2003 to 2005. And the first thing that he says is that what he found the most revealing, he began, on his own initiative, not asked by the administration, not asked by the President, he began performing intelligence estimates of the insurgency. And he gave them to the highest level of the administration. And he said that what he found most revealing was that President Bush not only had not read the estimate, but had not even read the one page executive summary.

### Moderator
Claim: Would victory vindicate those deaths.

### Scientific Advocate (SA)
Claim: Victory would. In 1972, when he was first visiting China, Henry Kissinger asked Zhou Enlai whether in Zhou Enlai’s view the French Revolution had been a success. And Zhou Enlai’s response was, it’s too early to tell. Now, by that standard, maybe we’re winning.

### Moderator
Claim: Fred Kagan, can you take on the question of the sacrifice?

### Conspiracy Advocate (CA)
Claim: I’d actually like to surprise the audience by agreeing with the last remark that Mr. Ferguson made. It is too soon to tell. If we win the war, then the sacrifice will not have been in vain. I think it’s fair to say that no soldier who sacrifices his life, or her life for their country, makes a vain sacrifice. But, and I dislike that, I don’t think that that’s really the issue, because I don’t think that the nature of the sacrifice should be bound up with our judgements about whether the war is successful or not. It is too soon to tell. The funny thing about a war is that it’s not over until it’s over, and what seems like a good idea in year one can seem like a very bad idea in year three, can seem like a very good idea in year ten, can seem like a very bad idea in year fifty. And that’s why you can't make a permanent decision and stamp it in stone as those speaking against the motion would basically like to do. They’d like to say, this, the sum cost in this war is so high that nothing that could conceivably happen would be worth it, therefore the war was a failure, and lost. And Bush is a word that I can't use on the air. And the problem is the story doesn't end there. The question is, what will happen in the years to come, and we don’t know. Right now it appears to me that the trends are positive to have quite a profound impact on the Middle East. And what impresses me is that it is Iraqis who are engaged in this process actively, who are saying so. And this isn’t—I’m not talking about Ahmed Chalabi and other folks like that who’ve been discredited. I’m talking about people who are actually engaged day to day, in running their country. This is what they’re saying. If that is in fact the case and I think that it is, then, not only will those deaths not have been in vain as—as no military deaths are, but they will have served a tremendous interest of the United States of America and the world.

### Moderator
Claim: Gentlemen— Question from the audience.

### Moderator
Claim: I’m Ed Thompson with the Ayn Rand Institute. I find Sir Malcolm’s assertion, that, because they are Iraqis or Arabs, that there will be violence, I find that a racist statement. I feel compelled to point out— I’ll get to that. I feel compelled to point out that it was the Iraqi troops that went into Bosnia, to clean up the mess that was left behind by the British troops. Now… The question that I have is how the opposition can deny or ignore the evidence of the proponents that we’re winning the war…and state that, Iraq will fall into disarray when the, when the Americans leave, when… Mr. Kagan states, that Iraq will be a—it’ll be a watershed situation, that Iraq will be a rival to Saudi Arabia because it’s a democracy. Now, the question really is, what makes you think that, Sir Rifkind, what makes you think that Iraq will fall into violence, as opposed to becoming a civilized country, like some of the other Middle Eastern states such as the US—UAE, Kuwait, and—

### Moderator
Claim: I’m gonna cut you off because I think the question is clear. Sir Malcolm, I think the question if I can—

### Scientific Advocate (SA)
Claim: I think you clearly misunderstood what I said and that may have been my fault and I’m sorry if you did. But at no time do I suggest that the Iraqis as a people, as a culture are any more prone to violence than anybody of any ethnic background. What I did say, is that if you go into somebody else’s country, who has not attacked you, if you remove their government and if you destroy their political system, then you create a political vacuum. And in the circumstances of Iraq, where rightly or wrongly, the Sunni minority had had power, not just under Saddam Hussein, for a hundred, 200 years, and the Shia majority suddenly see an opportunity to assert power, and the Sunni seeing that they’re losing it resist that, you get effectively a civil war. And when you, as a result of having created this political vacuum, you give people like al-Qaeda an opportunity to get in on the act, encouraging separatist violence, helping mosques being blown up in order to get people to commit acts of revenge in return, then you get all the terrible trauma, of what has happened in Iraq.

Now I do not say that that is the direct responsibility of the American or the British governments, of course, they were not responsible for violence committed by al-Qaeda, or by Sunni or by Shia. What I do say, is that that explosion of violence which has led to tens of thousands if not hundreds of thousands of terrible deaths, simply would not have happened, if the foolish decision to go to war had not been taken in the first place.

### Moderator
Claim: Sir Malcolm, Fred Kagan—

### Scientific Advocate (SA)
Claim: And so ultimately, we have that responsibility—

### Moderator
Claim: Fred Kagan would like to jump in on that.

### Conspiracy Advocate (CA)
Claim: I’d just like to make a point that has been lost in this discussion so far which is to begin with, there was a small al-Qaeda presence in Iraq before 2003, that’s an established fact. Abu Musab al-Zarkawi was already in Baghdad in 2002. I do not regard that as sufficient justification for invading Iraq, I don’t think that. I’m not trying to make that case, I am stating a fact that there was an al-Qaeda presence in Iraq before we invaded. Al-Qaeda then took advantage of our failed strategy and our inappropriate methods and the variety of the mistakes that have been highlighted here, repeatedly, to seize control in Anbar Province, and areas of Ninewa and particularly Salahaddin Province and areas of Diyala and of course Baghdad.

What has been lost, is that, Iraq is now the first place in the Muslim world, where a Sunni Arab population, that had embraced and supported al-Qaeda and provided fighters to its ranks, rose up against al-Qaeda, joined with the military of the United States of America, fought tooth and nail to defeat the insurgents, threw them out of their country, and now you can hardly find an Iraqi anywhere, who will say anything other than, al-Qaeda are foreigners, they’re evil, they’re bad people and we will never let them back into our country. If you want to talk about effects in the war on terror, this is an unintended consequence…let us say. It’s not as though there was an al- Qaeda group in Iraq that was large that we went in and defeated. However. If you watch what the jihadis say, if you watch the al- Qaeda websites, nothing that has happened in the past seven years has distressed them more, with the exception of losing Afghanistan initially— Nothing has distressed them more than the awakening movement in Iraq which they see as a mortal threat to the success of their ideological movement within the Muslim world, and I think it’s very important to recognize that.

### Moderator
Claim: Thank you, Fred— That was Fred Kagan, speaking for the motion. I’m John Donvan, this is Intelligence Squared US, Oxford-style debating, on America’s shores, we have four panelists on the program. Two for, and two against the proposition, “America is Finally Winning the War in Iraq.” We are in our mix-it-up section in which we are taking questions from the audience, and I understand that we have an Iraqi war vet who’s had his hand up for some time far in the back. Sir, the mic is yours.

### Moderator
Claim: Thank you. My name’s Jose Vasquez, I’m a former staff sergeant, US Army, I’m also a member—thank you. I’m also a member of Iraq Veterans Against the War, my organization just recently published a series of testimonies called Winter Soldiers: Iraq and Afghanistan—Eyewitness Accounts of the Occupations. Over 150 members came forward to testify about things like—

### Moderator
Claim: I need a question from you—

### Moderator
Claim: —indiscriminate fire, into civilian occupied areas, ongoing torture, and corporate pillaging, my question for the folks that are for the motion is, given the systemic nature of these types of atrocities, do the panelists for the motion support a military victory at the price of moral and legal failure. Is that victory at all. Thank you.

### Conspiracy Advocate (CA)
Claim: The—the factual basis of atrocities which exist in all wars, as it pertains to Iraq, are far lower than any experience that the United States or Western countries have normally had in wars in the past, and, to— I’m not suggesting they don’t exist, they exist. The difference is this also. Is that, when the United States and its Western allies, when their soldiers do wrong and harm others, there’s accountability for that. Those soldiers and those leaders that are involved in that, are brought very quickly into a judicial process for accountability, that’s what a democracy does, and that’s what we have always been doing throughout our history, we’re not perfect in this. But it’s certainly, that is, the realistic issue here is the fact that they have been committed, but they are much lower than our experience has been on a per-capita basis, and always, there’s been accountability for that horror when it’s inflicted and when the chain of command is, is made aware of it—

### Moderator
Claim: All right, General—

### Conspiracy Advocate (CA)
Claim: and it ignores the overwhelming good and sacrifice and compassion, that we have seen our soldiers display on a day-to- day basis, on the one, one moment…putting their life right on the line for Iraqi families and Iraqi citizenry, and then in the next moment, having tremendous compassion, and helping and assisting them with—

### Moderator
Claim: General, with due respect—

### Conspiracy Advocate (CA)
Claim: —the values of the country—

### Moderator
Claim: —to your passion on that and to the question itself, it’s actually off our point of whether the US is winning the war in Iraq and I would like to get back to that point with a question from the woman—

### Moderator
Claim: Hello, I’m Dina Temple-Raston with National Public Radio. And I wanted to quibble a little bit with your version of events in Basra. Muqtada al-Sadr’s forces there weren’t defeated. I was there for NPR reporting at the time. And the Mahdi army just disappeared. Al-Sadr told them to disappear, and they left with their guns. And we really haven’t seen much of them since. On the same point, similarly, there are enormous issues right now surrounding the Sons of Iraq. And the ability of the Iraqi government to fold them into the Iraqi army, and pay them as the Americans have. So—

### Moderator
Claim: And your question is—

### Moderator
Claim: My question is…how can you say America is winning the war in Iraq when we have these two enormous problems that have been left unresolved, Muqtada al-Sadr, and the Awakening Commission. And, how do you suggest we tackle these problems going forward. And aren’t they just waiting us out?

### Moderator
Claim: Fred Kagan, for the motion.

### Conspiracy Advocate (CA)
Claim: With due respect, I don’t denigrate what you saw when you were there, but I have also spoken with many people who participated in that operation, shortly after it occurred. And they did not simply disappear. Many of them were killed. And, many of them particularly in Sadr City where they fought harder, were killed. And many of their top leaders were killed, which is one of the key reasons why they broke. And if you look at what is actually going on within the Shia community now, and you look at what Sadr has done, and you ask the question, are there Sadrist networks that remain in Iraq, the answer is, of course there are. Then the next question, will they take Sadr’s order, if Sadr tells them to rise up again and do this or do that or the other thing, and what we have seen repeatedly is, the answer is, yes and no, but increasingly more no than yes. For the excellent reason that they have come to fear, not only the American military, but also the Iraqi army. And, there was an interesting and very poignant moment, when some of those— actually I think it was probably Iranian special groups rather than Sadrists who did this—spray- painted on a bridge, across the border into Iran, “We’ll be back.” And the Iraqi army, Iraqi army soldiers spray-painted right under it, “We’ll be waiting.” And that message has gone out. And so I’m sorry, it simply is not the case that Sadr is just waiting us out, Sadr’s son has said for the moment it may rise again, he’s a young man, we’ll see. What will not happen, is that you will have an uprising on the scale of 2004, 2005 or even 2006 when the Sadrists were poised to take control of the country.

### Moderator
Claim: Sir Malcolm, I—

### Conspiracy Advocate (CA)
Claim: That’s not

### Moderator
Claim: —I hear in that response an answer to your point earlier, well, maybe they’re just lying low, and insurgents rise and fall again, what about that, Fred Kagan is saying he thinks this is permanent, it’s gonna last, or very likely to last.

### Scientific Advocate (SA)
Claim: I think it is entirely possible that the insurgency will permanently, slowly, come to an end. We’re not there yet, there is a lot of truth in the argument that Muqtada al-Sadr is simply biding his time. But he’s weaker than he was in the past. And if that is happening, if the insurgency is being brought under control—I would welcome that, any reasonable person would welcome that. But that doesn’t mean we’ve won the war. To win the war, or to be even winning the war, means we are approaching the stage where we can say this whole operation was worthwhile. The last five years was right and justified. That’s a very different question.

### Scientific Advocate (SA)
Claim: May I make a brief comment about this?

### Moderator
Claim: Charles Ferguson.

### Scientific Advocate (SA)
Claim: Look, it is possible that Iraq will stabilize and the insurgency will, fall away gradually. However, this idea, this portrait of an incipient paradise that Mr. Kagan paints is unfortunately just not right. There are enormous tensions still inside Iraq. There’s a three-way, at least a three-way—

### Moderator
Claim: Charles, with respect, I haven’t heard as the moderator Fred Kagan promise an incipient paradise—

### Scientific Advocate (SA)
Claim: Fair enough—

### Moderator
Claim: Right—

### Scientific Advocate (SA)
Claim: —excuse me. I, fair enough, I retract that and I apologize to Mr. Kagan. But—

### Moderator
Claim: Or even anything close.

### Scientific Advocate (SA)
Claim: Also fair enough. But the idea that we are reaching and it’s within sight that we have a stable situation in Iraq, simply is not true. There are enormous tensions over Kirkuk, which could erupt into military conflict. That issue remains entirely unresolved. There’s at least a three-way, possibly a four- or five- or six-way, fight among various Shiite groups for control of the south including Basra. It is true that the Sadrist movement remains fairly strong. The integration of the roughly hundred thousand Sunni Awakening Council concerned citizens, uh, members, into the security forces and into Iraqi society remains extremely unclear and uncertain and is largely being forced by the Americans onto an extremely unwilling central government. So, it’s not—this country remains very fragile, and none of the proposals for withdrawing American troops have envisioned anything more than a withdrawal of roughly one-third of total US forces. Withdrawing all US combat forces would withdraw only about 25 percent of total US forces in the area, not even counting the private military contractors.

### Moderator
Claim: Charles Ferguson, thank you, we’re gonna go to another question in the rear?

### Moderator
Claim: My name is Ross Sandler, I’d like to look to the future a bit, and ask both groups…what events or circumstances or milestones or trends would cause you to moderate your view.

### Moderator
Claim: I love that question. And it’s— And it’s what I asked before of Charles, what would be victory, when—when would you say, well I might’ve been wrong, it’s working out. Or the reverse, I might’ve been wrong, it’s not working out, Jack Keane.

### Conspiracy Advocate (CA)
Claim: Well, I’ll start it off. One is the Provincial Election Law itself, which was the most crucial in our view, because it’s decentralized government and it’s empowering people at local levels, and there’s a lot of that there right now, but now it’ll be formalized and it’ll be a structure for them to vote for, and a structure for them to receive budget money from as well. That’s number one. Certainly, there’s issues that surround the Kurds. There’s Article 140, I don’t wanna get into the details of it because we don’t have enough time. And that is of a concern for us in the future, we’re not—Fred and I are not suggesting that there are not challenges ahead in Iraq—of course there are. But the good news that we are bringing to you is that there’s been significant progress here, and we’ve moved into another phase. We’re moving out of a security phase into a political phase, where people are using the political process to address their grievances as opposed to armed violence, and that’s what we have to be hopeful for. I don’t think that could be turned back easily. And certainly, the second thing that would concern me are the Iranians themselves, they are up to huge mischief here. This is of significant strategic interest, their number-one strategic interest in Iraq, is the removal of the United States. They want a weak central government in Iraq, so that they can have influence over that government. And that is their strategic interest when it pertains to Iraq, not the region itself. Brigadier General Suleimani, who was the Quds force commander, who engineered the operation in Iraq, in southern Iraq on behalf of the Iranians, he is the Quds force commander, who defeated the Israelis in southern Lebanon. He has been in his position over 10 years. He is intelligent, experienced, and ruthless. He works for one person, and one person only, and that’s the Supreme Leader of Iraq. Of Iran, excuse me. Despite the major setback that we have had in the south, for that leader and for his forces, his proxy forces, he is still in command.

### Moderator
Claim: Sir Malcolm—

### Moderator
Claim: Which tells me, that they have not given up on their strategic objective. We believe because of the anti-Iranian attitude that is in the south among its people, and the—and their commitment to move to a greater Iraq, aligned with the United States, that we will be okay. But if you ask me, am I concerned about it, I am, because of their determination. Could it change things in Iraq? It could.

### Moderator
Claim: Sir Malcolm.

### Scientific Advocate (SA)
Claim: General Keane rightly says that the Iranians have a strategic objective of wanting to see a very weak Iraqi government, in order that Iran will be the unrivaled power in the region. He conveniently forgets or ignores, that Iraq did have a very strutting central government, not just under Saddam Hussein, but for the last 50 years under successive Iraqi governments. It is because of the war, that he is supporting, that Iraq as a strong centralized state has been destroyed, and that Iraq today has exactly that weak, decentralized government, with a Kurdish autonomous region in the north, with the Shia and Sunni constantly battling for influence and power, and with the central government having little real power, that is exactly what the Iranians wanted to achieve, and it is American and British policy that has helped them achieve it.

### Moderator
Claim: Sir Malcolm, are you saying that the war makes victory impossible?

### Scientific Advocate (SA)
Claim: I am saying that the only way in which you can test whether victory has been achieved, is not to simply look at whether the insurgency is going up or going down, as if the—the war is simply about the insurgency. The war is about the invasion of Iraq, the destruction of a regime, the creation of a political vacuum, and whether the overall effects of that strategy, pursued by America, by Britain, and by the coalition, whether that has been net plus for the Iraqis and for the region, or whether it has been a net minus.

### Moderator
Claim: Fred Kagan.

### Conspiracy Advocate (CA)
Claim: I’d like to take a minute to address one of the historical myths that seems to me to be embedded in this backward-looking definition of whether we’re winning or not. Which is, how exactly was Iraq doing in the 1990s after the liberation of Kuwait which was generally agreed to be a good war, led to an international- sanctions regime, led to an oil-for-food program that became incredibly corrupt, not only on the Iraqi side which was to be expected, with Saddam Hussein, but also on the UN side unfortunately. Which created significant problems, and I’ve heard Iraqis explain to me, even now, some of the problems that are persistent in the corruption that you see in Iraq date back to structures and practices that were established under the oil-for- food program. Iraq was not exactly a wonderful buffer against Iran in the 1990s when we, the United States and Great Britain were compelled to maintain forces which looked like forever, in that circumstance, conducting overflight and periodically bombing Iraq. And there was no end in sight to that particularly either, now, if you think that this war is going to drag on and be miserable for decades obviously it was preferable to do what we were doing in the ‘90s than that. If you think that there’s a prospect as I do of actual success, then, this is something that can end, in a way that that wasn’t, but the notion that we were the ones who destroyed in 2003 a very effective system of dual containment I think is problematic. But I’d like to answer the question that was asked, because it’s an excellent question. And I think as an analytical matter, it’s something that’s very important to put on the table, and I’m willing to put this on the table, and I’m willing to be judged against this and you can throw this up to me two or three years hence, and we can talk about whether it worked out. What would make me change my mind about the analysis? To begin with, I already changed my mind. As I told you, I had been fairly pessimistic going into the passage of the provincial election law. I’ve changed my view as a result of that. If the provincial elections are not held, are not seen to be legitimate, or badly marred by violence, that will be a very negative indicator, and it will make me revise my view. If the subsequent Council of Representative elections are not held, are not seen to be legitimate, or badly marred by violence, that will be a very important negative indicator. If the Sunni Arab community in Iraq decides that it is not going to participate in the political process in these elections, in subsequent elections, or in any way thereafter, that will be an extremely negative indicator, and we’ll have to revise our view. If the Iranian backed and controlled special groups are able to reestablish themselves in a coherent fashion through the country and conduct the sort of coherent, widespread campaigns that they were able to conduct before the surge, that will be a negative indicator. If a Sunni-Arab insurgency reforms coherently to conduct large scale attacks, and I'm distinguishing that, because I'm not claiming that Iraq will be a paradise. There will continue to be violence, there will continue to be inter-sectarian violence, there will continue to be ethnic violence, and there will continue to be terrorism. The question is, is there a coherent enemy organization on the Sunni or Shia side running it. If al Qaeda actually returned and reestablished significant safe havens, I would say that that was an extremely, uh, negative indicator. And lastly, if large scale, as distinct from periodic, as I say, smaller scale violence and terrorism, if large scale violence between Kurds and Arabs erupts, that will be a very negative indicator. Right now I would say I'm most concerned about the elections, about their legitimacy, particularly of the COR elections, after we’ve drawn down even more forces. I think the reestablishment of special, Iranian Baath special groups, is ongoing, and we will have to see how that plays out. The other, other indicators right now seem to me to be pretty positive. But I think that’s, those are the things that I would look at to evaluate as we move forward.

## Round 3

### Moderator
Claim: Thank you, Fred Kagan. And that concludes our Q&A section. I want to remind you once again of the numbers. We’re going to take the final vote very shortly, and we would really like you, because it’s establishing our base line, to stay and vote, and we’ll have the results very quickly. All four of these people have argued very strenuously, and we would like to register, to the extent possible, every single, every single mind up there in the seats. Reminding you that, coming in, twenty percent of you, with the motion, “America is finally winning the war in Iraq,” twenty percent of you were for the motion, fifty-four percent of you were against the motion, and twenty-six percent, nearly a quarter, more than a quarter of you were undecided. We’re now going to move to final statements by each of the panelists. These statements last for two minutes each, and once again the bell will single time being up. And the first to wrap up… The first speaker to offer a summary statement will be Charles Ferguson, director and producer of the award winning Iraq War documentary No End in Sight. Charles Ferguson.

### Scientific Advocate (SA)
Claim: Thank you very much. Let me begin my concluding remarks by answering the last question that was asked about what would constitute victory, as has already, I think, been made clear, Sir Malcolm and myself both share the view that we’ve long passed the point at which anything approaching victory really is achievable. But let’s suppose for the moment that we magically forget about all the damage done, and we simply focus on starting at this moment. If it were possible for all US troops, not just the twenty-five percent that are combat troops, all US troops to return from Iraq, for that to occur with Iraq remaining stable, and without further violence: if the five million Iraq internally displaced persons and external refugees then returned to Iraq, also without violence: if Iran abandoned its pursuit of nuclear weapons, and if Iraq gets just to number one hundred and fifty in the corruption index, I would consider that we would have made enormous progress. Nobody believes these things are going to occur. Nobody. Nobody. Let me unfortunately conclude with an email message I received a few days before my film was happily nominated for an Academy Award by someone who had seen the film: My son, Noah Charles Pierce, served two tours in Iraq, and in your film you showed a scene of kids throwing rocks at trucks, and you can hear the soldiers wanting to shoot the kids. Which is true. Shortly after the invasion, my son was in Baghdad, cleaning up the dead civilians who were being pelted, while being pelted with rocks. The kids grew braver and became more effective until orders came down to shoot them.

### Moderator
Claim: Charles, I'm sorry, I have to cut you off.

### Scientific Advocate (SA)
Claim: I'm sorry, I'm going to finish.

### Moderator
Claim: I'm sorry, I have to—

### Scientific Advocate (SA)
Claim: The soldiers gunned them down—

### Moderator
Claim: Charles, I'm sorry, I have to cut you off—

### Scientific Advocate (SA)
Claim: …last July my son committed suicide—

### Moderator
Claim: I'm sorry, I'm sorry. Was that the end. Well, since I talked all over it, and the audience is saying let you finish it, read the last sentence again.

### Scientific Advocate (SA)
Claim: OK. My son watched in terror as his fellow soldiers gunned them down. Last July my son shot himself. I'm sorry, that's it.

### Moderator
Claim: Charles Ferguson. Summing up for the motion, General Jack Keane, a retired four star general, and former Vice Chief of Staff of the US Army, a member of the Secretary of Defense’s policy board, summing up for the motion, “America is finally winning the war in Iraq.”

### Conspiracy Advocate (CA)
Claim: As we’ve tried to indicate, Iraq, we’ve tried not to re-fight the beginning of the war in Iraq, because that was not the purpose here. We’ll also have opinions about that ourselves. And we have admitted openly that we had a failed strategy in Iraq for three plus years. But we do have a winning strategy now. And I look at Iraq as an opportunity. It is clearly in the United States’ national interest to have an Arab Muslim country with a duly elected democratic government aligned with the United States in a region of the world, like it or not, that we will spend the next thirty to fifty years involved in. And it will continue to be ideological and serious struggles there. This is a step forward for the national security interests of the American people to have that kind of a relationship with a stable government. We are not there yet, but the signs are clearly there, and they were not there in the past. And with the investments that we are making in resources, and in, certainly with our soldiers’ commitment, and yes, with their lives, that is absolutely worth the sacrifice, in my judgement, in terms of the security of the United States, and what that region, that troubled region of the world will be. There is not a single Sunni Arab state that surrounds Iraq that will not change as a result of the stable, duly-elected democratic government in that country. And the Iranians will have to change and be influenced by it as well. And that is the opportunity that is in front of us, and that is why we are so committed to it. And regardless of all the mistakes in the past, that is in front of us right now.

### Moderator
Claim: Thank you, General Keane. Summarizing his position against the motion, Sir Malcolm Rifkind, former foreign secretary, and a former defense secretary of the United Kingdom. Sir Malcolm?

### Scientific Advocate (SA)
Claim: General Keane has just said that in his view what might be achieved in Iraq is worth the sacrifice that has been made. I think you know that’s a very easy challenge to test. I think we just have to ask ourselves if five years ago we had known that by going to war over a hundred thousand Iraqis would die, two million would be refugees in other countries, the internal economy would collapse, the Sunni and Shia communities would get into Sectarian conflict, and we would have helped make Iran the real power in the Gulf, would we have thought that achieving an Iraq government, which was elected, but which is not a true democracy yet and may never be, that that was on balance a sacrifice worth making? I don’t believe that the hundred thousand Iraqis who have died, or their families who have survived them, will believe it was a sacrifice worth making. Iran is the real winner of this conflict. The Iraqi people have been the losers. The fact that they may now have a government which is better than Saddam Hussein, but what a terrible price they have paid for it. And we know that we’re not going to invade any other country knowing what now know happens when you carry out such a strategy as you have carried out in Iraq.

### Moderator
Claim: Thank you, Sir Malcolm. Finally, summing up for the motion, “America is finally winning the war in Iraq,” resident scholar in defense and security studies at the American Enterprise Institute, Fred Kagan.

### Conspiracy Advocate (CA)
Claim: Thank you. I’d like to start by noting for the record that a number of people left, and I have psychic abilities, and I know that all of those people would now vote for the proposition, and I hope that their votes will be counted. Look, vote however you want to vote… Let me step back from that for a minute and just say, this issue is too important for us to continue to be the bird that flies backwards, always looking at where it was, and never looking to where it’s going. And I'm deeply distressed by the tendency in our political class, our political discourse, and unfortunately the presidential race as well, to focus again and again on re-fighting mistakes that every single person up here agrees were made. And every single person up here criticized. The issue is not did we make mistakes. The issue is, where are we now, and where are we headed? And that is what we need to focus on as a nation, because the world will not stop and stand still while we flagellate ourselves, or as some of us flagellate others, for mistakes that were made, and we cannot go through the entirely self-referential exercise of beating ourselves up for what we did wrong, and assume that the world will wait till we get through that, and then do something. The stakes are too high, and we can't have a conversation like that. As for effect on the region, let me simply end with a little story. I went to the border post opposite Mehran, which has a major Quds Force base in Iran. And I stood on the border and I spoke with an American officer who, every day, met with and spoke to some of the tens of thousands, hundreds of thousands of Iranian pilgrims who come to Iraq every day to go to the holy shrines of Najaf and Karbala, and in Baghdad.

### Moderator
Claim: Fred, I have to cut you off, you have ten seconds.

### Conspiracy Advocate (CA)
Claim: OK. They say three things to him—

### Moderator
Claim: No, I’ve got to give you ten seconds.

### Conspiracy Advocate (CA)
Claim: This is ten seconds. Thank you, we love America, and come visit us soon.

### Moderator
Claim: Thank you, Fred Kagan. So now we see how this turned out. Once again we’d like you to turn to the keypads that are by each of your seats, and reminding you what our motion is, “America is finally winning the war in Iraq.” If you support the motion press number one, if you are against the motion press number two, if you remain undecided press number three. And within a few seconds, actually, we will have the results. As they are being calculated, I want to remind you of what’s coming down the road. First of all, I want to thank all of you in the audience for really excellent questions. I apologize to the numbers of people, there was a forest of hands up, to the numbers of you who were not able to ask your questions. But I just want to ask you to settle down just a little bit. Our next debate will be Tuesday, October 28th, the motion is: “Guns reduce crime.” Panelists for the motion are Stephen Halbrook, who has won three Supreme Court cases on firearm law issues, and who represents the NRA in several lawsuits, Gary Kleck, a professor in the college of criminology and criminal justice at Florida State University, and a lifelong Democrat who was once on the other side of this debate, and John Lott, a senior research scholar at the University of Maryland who believes we would be safer is people carried concealed weapons. Panelists against the motion, John Donohue, a professor at Yale Law School, whose statistical research focuses on the death penalty and employment discrimination, Paul Helmke, president of the Brady Campaign and Brady Center to prevent gun violence, as well as a Republican and former mayor of Fort Wayne, Indiana, and finally Seattle Chief of Police, R. Gil Kerlikowske, who in a thirty-six year career in law enforcement has been a patrol officer, a narcotics and robbery detective, and a hostage negotiator. These debates, as we’ve said before, can be heard on more than a hundred fifty NPR stations across the nation, just check your local NPR member station listings for the dates and times of broadcast. We also want to remind you that copies of books by the authors, as well as DVD’s of previous Intelligence Squared US Debates are available on sale in the lobby. Ah, interesting, we’ve had some movement. Before the debate, to remind you, twenty percent were for the motion, fifty-four percent were against, and twenty- six percent were undecided. The motion for moved more of you, thirty-six percent are now for the motion, fifty-three percent are against, eleven percent remain undecided. So, while the majority view remains against, more people’s minds were changed by the course of this debate in support of the motion, “America is finally winning the war in Iraq.” Thank you for attending, we’ll see you at the next Intelligence Squared debate, and thank you to our panel.
