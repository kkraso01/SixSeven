# Debate Transcript

Topic: Snowden Was Justified
Motion: Snowden Was Justified

Debate ID: 021214%20Snowden


## Round 1

### Moderator
Claim: And, as always, we start these debates by bringing on the person who brought Intelligence Squared U.S. to the New York stage. He frames the evening for us, talks about why we’re doing this debate, why it matters, and a little bit of what we’re likely to see. So let’s now please welcome to the stage, Mr. Robert Rosenkranz. Hi Bob.

### Moderator
Claim: Hi, John.

### Moderator
Claim: So, Bob, this one--we do one of these a month, at least once a month--this one sold out faster than any that we've ever put up, and we know that there have been people calling for the last several days begging for tickets. Why-- what's going on with this topic? Why this one?

### Moderator
Claim: Well, this debate, first of all, touches such an emotional hot button. I mean, people's reaction to Snowden are really extreme in either direction, and they feel very committed to their views. But the other thing that's pretty extraordinary is we have tonight the most famous whistleblower of all time, Dan Ellsberg, who was a colleague of mine at the RAND Corporation many, many years ago and Jim Woolsey, who's a former director of the CIA, so you couldn't have more expert people on-- passionately committed to opposite sides of this motion.

### Moderator
Claim: And we have debated this-- this delicate balance that everyone is struggling to reach between security and privacy. We've-- we debated a few months ago, "Spy on me, I'd rather be safe." But how is this one different from that?

### Moderator
Claim: Well, "Spy on me, I'd rather be safe" was, as you say, this dichotomy or tension between privacy and security. And in these debates-- and that's a theme that's recurred in a number of debates we've done-- the privacy side seems to win. The security side doesn't. And my theory about that is that ordinary people have one and only one contact with domestic surveillance. That's airport security, and it strikes them as a joke, and, the clowns that brought them that joke, they don't want to see have anymore power. So then when Snowden comes along and reveals that there is every single phone call that every American has ever made is-- is saved and recorded-- not recorded, but the record of the call having been made is saved-- that's a degree of surveillance that, frankly, congressmen had no idea was going on, no less ordinary Americans. And it created a really shocking reaction. So I think that the fact that Snowden opened up a debate on this very sensitive topic and brought information to the debate that hadn't been there before is why some people at least feel like he is justified. And then when you get the phenomenon of-- at least a couple of judges at this point have questioned whether the NSA surveillance is authorized or even whether it's constitutional, you know, the step would be to say, well, okay, he was a whistleblower, he called attention to something that needed attention, and while he may have been doing something illegal, from a moral point of view, it was justified.

### Moderator
Claim: So you're making-- that would be the argument that it's justified. What's the shape of the argument that he is not justified?

### Moderator
Claim: Well, the argument in the other direction is that he was far more than a whistleblower. He tried to subvert or at least did subvert the very mission of the NSA. I mean, their job is to keep track of our enemies to see what's going on in Iran and in Russia and with al- Qaeda and so on, or with our adversaries like China. And he undermined their ability to do that job in a very serious way. He revealed which codes they had broken. He revealed what methods they use. He revealed what firewalls had been breached. He revealed which computers had been hacked into, which individuals had been targeted. I mean, this was a serious setback for national security. And he didn't just do this. I mean, this was a very deliberate thing. He took the job with the intention of stealing secrets and disseminating them, held a job for three months. And when he did what he set out to do, he flees to China and then Russia, takes with him four laptops full of secret information, which you have to presume that both the Chinese and the Russians now have. I mean, this is espionage of the most serious sort.

### Moderator
Claim: And it's not justified, you know.

### Moderator
Claim: Well, and the argument would be that he should be punished to the full extent of the law.

### Moderator
Claim: We're going to hear all of those arguments brought to today-- to the stage tonight and in more detail. But let's now welcome our debaters to the stage. you. And you're doing very well at the applause, without any visual indicators, so thank you for that. But I would like to ask for one more round of applause for Bob Rosenkranz, our chairman. Promises, as the saying goes, are made to be broken. But taking an oath, that is meant to be solemn. Oaths are meant to be kept.

And the young man who spilled the secrets about the NSA, taking in all of that stuff about all of our phone calls here in this hall, Edward Snowden, he took an oath, and it went like this, to, "Support and defend the Constitution of the United States against all enemies, foreign and domestic." So when Snowden broke secrecy, did he break his oath, given that those secrets have now, in all likelihood, reached our enemies? Or did he uphold his oath? Because what he exposed in those programs arguably fights the Constitution itself. Well, that sounds like the makings of a great debate, so let's have it. Yes or no to this statement: "Snowden was justified," a debate from Intelligence Squared U.S. I'm John Donvan. We're here at the Kaufman Music Center in New York City. We have four superbly qualified debaters two against two, who will argue for and against this motion: “Snowden was justified.”As always, our debate will go in three rounds, and then our live audience votes to choose the winner, and only one side wins. Our motion is "Snowden is justified." And let's meet one of the first debaters here to argue in support of this motion. Ladies and gentlemen, please welcome Ben Wizner.

And, Ben, you are the director of the ACLU Speech, Privacy & Technology Project. You have litigated numerous cases involving civil liberties abuses post-9/11. You are also personally a legal adviser to Edward Snowden. And, Ben, we understand the two of you are in regular contact over encrypted channels. Not long ago you were in Russia visiting him. And so just out of curiosity, does he know that you're actually doing this debate?

### Conspiracy Advocate (CA)
Claim: He does know. He has been following the global debate very closely, and he's aware of this debate tonight.

### Moderator
Claim: Is he watching this debate tonight?

### Conspiracy Advocate (CA)
Claim: Well, you know, there's a nine-hour time difference, but he's a night owl, so I would put the chances at about 50/50.

### Moderator
Claim: Alright. Ladies and gentlemen, Ben Wizner. Thank you. And Ben--

Ben, would you introduce your partner?

### Conspiracy Advocate (CA)
Claim: I am joined tonight by a genuine American hero. Pentagon Papers whistleblower, Daniel Ellsberg.

### Moderator
Claim: Ladies and gentlemen, Daniel Ellsberg.

Daniel Ellsberg, you were once called "the most dangerous man in America," by Henry Kissinger. And in 1971, you leaked the Pentagon Papers, 7,000-page top-secret study that detailed government secrecy and deception during the Vietnam War. Newspapers published it. It came out as a book. But the-- but the papers themselves were only officially declassified and released by the federal government in 2011, 40 years after the fact. What do you make of that, Daniel Ellsberg?

### Conspiracy Advocate (CA)
Claim: Well, it's a pretty good demonstration of the absurdity of the classification system. Probably 98 percent of what is now classified-- and we're talking about billions of pages here, that is more than two or three years old, should not still bear a classification--

### Moderator
Claim: Alright.

### Conspiracy Advocate (CA)
Claim: Or let's say five years old.

### Moderator
Claim: So--

### Conspiracy Advocate (CA)
Claim: So they’re keeping it for 40 years is typical.

### Moderator
Claim: So we're getting a little bit of a look ahead of what your arguments are going to be. Ladies and gentlemen, Daniel Ellsberg. Our motion is this: “Snowden was justified.” And here to argue against the motion, we have two debaters. First, please, let's welcome Andrew McCarthy. And Andrew, you are a former chief assistant U.S. attorney who led the prosecution against the “Blind Sheik,” Omar Abdel Rahman, and 11 others for the 1993 World Trade Center bombing. This is your second time actually debating with us. The first time was almost seven years ago in our inaugural season. You got us off to a great start. The motion that night was "Better more domestic surveillance than another 9/11."And maybe we don't have to ask, but what side were you on that time?

### Scientific Advocate (SA)
Claim: Believe it or not, I was on the "better more surveillance" side. And--

### Moderator
Claim: How do you--

### Scientific Advocate (SA)
Claim: --we’re on the upper west side, they were on the "better another 9/11" side, so--

### Moderator
Claim: How'd you do?

### Scientific Advocate (SA)
Claim: Well, I had a great time.

### Moderator
Claim: I'm not going to push on that one. Ladies and gentlemen, Andrew McCarthy. And, Andrew, your debating partner is?

### Scientific Advocate (SA)
Claim: My debating partner is a great American patriot, the former CIA director, Jim Woolsey.

### Moderator
Claim: Ladies and gentlemen, James Woolsey. James, you are also arguing against this motion, "Snowden was justified." You were CIA director from 1993 to 1995. You served on five different occasions under both Republican and Democratic administrations.

Your life post-government has included working on security and alternative energy issues. And you're currently chairman of the Foundation for Defense of Democracies. But here is an interesting thing that we dug up: two years ago, in 2012, in a theatrical workshop experimental presentation of a musical comedy, you actually played a CIA director. And you sang, I'm not sure whether you danced, but could you tell everyone what your - - what was the name of the CIA director you played?

### Scientific Advocate (SA)
Claim: Heinous Overreach.

### Moderator
Claim: Which tells us, if nothing else, you have a sense of humor. Thank you, James Woolsey. So those are our debaters. And, as we have said, this is a debate. It's a contest. Only one side will win. And you, our live audience here in New York City, will choose the winner by your vote. We have you vote twice, once before the debate and once again afterwards. And the team whose numbers have moved the most in percentage point terms will be declared our winner.

So let's go to the preliminary vote if you go to those keypads at your seat. The motion is this, "Snowden was justified." Right now that is motion number one. You push number one if you agree with that motion. If you disagree that "Snowden was justified," you push number two. And if you're undecided, you push number three. And we'll lock out the system in about 10 seconds. If you made a mistake just correct your vote and it'll lock in your last vote. And remember, again, at the end of the debate we have you vote a second time. The turnaround time on the results is about a minute and a half. And we draw the comparison between the opening and the closing votes. That's how we determine our winner, the team whose numbers have moved the most in percentage point terms. So on to round one. Round one, opening statements by each debater speaking in turn, uninterrupted.

Those will be seven minutes each. Our motion is this, "Snowden was justified." And here to speak first in support of this motion, Ben Wizner. He is legal adviser to Edward Snowden, and he is the director of the American Civil Liberties Union Speech, Privacy & Technology Project. Ladies and gentlemen, please welcome Ben Wizner.

### Conspiracy Advocate (CA)
Claim: Thank you very much. It's a great honor to be able to share a table with a man I've admired all my life, in support of a man who I've come to admire tremendously over the last eight months. On June 7th of last year, following the publication of the first NSA stories in the Washington Post and the Guardian, but before Edward Snowden had revealed his identity to us, President Obama addressed the revelations. And he said, "I welcome this debate, and I think it is healthy for our democracy."The president was right. This debate has been healthy for our democracy and for democracies around the world. In fact, it's the extraordinary global debate that Edward Snowden launched-- a debate about the threat that mass surveillance poses to free societies, about how surveillance technologies have outpaced democratic controls, about whether the Internet will be an instrument of democratic liberation or authoritarian control-- that provides the best answer to tonight's debate. Edward Snowden is justified because he provided to journalists and through them to us information that we had a right to know and that we had a need to know. The government had not just concealed this information, it had lied to us about it. And the debate that we've had and that we're still having would not have happened any other way. Now, in those same June 7th remarks, President Obama also defended the government's surveillance practices. He said that those practices had been blessed and approved by all three branches of government: within the executive branch, by the courts, and by the Congress.

Now, in making that point, President Obama probably would have said that he was joining our opponents' table. I would respectfully submit that exactly the opposite is true. And why do I say that? I say it because the same oversight bodies that had blessed these activities in the dark have dramatically challenged them and changed course in the light. Now, all three branches of government are engaged in a historic reevaluation of the NSA's surveillance practices. And we're virtually certain to see the first new limits on intelligence surveillance since the 1970s. What a difference an informed public can make. In short, our traditional democratic oversight mechanisms failed miserably before Snowden's revelations. Now, they're doing their jobs. Let's begin with Congress. When the Guardian revealed that the NSA had been-- collected the phone records of every American on a daily basis, many members of Congress expressed shock-- even though that program was purportedly authorized by Section 215 of the Patriot Act.

Now, there's been a lot of debate since then about whether Congress did or did not know, or what they knew or did not know. But does it really matter? Either way, this was a colossal failure of oversight. Either they knew and did nothing, or they didn't know what the NSA was doing in collecting all the Americans' information on a daily basis. Now, we're all familiar with Congress's most dramatic oversight failure. And this was in the notorious exchange between Senator Ron Wyden and Director of National Intelligence James Clapper. Wyden had asked, did the NSA collect any type of data on millions or hundreds of millions of Americans? Clapper's answer was, "No, sir." Now, this brazen falsehood is most often described as Clapper's lie to Congress, but that's not what it was. Wyden knew that Clapper was lying. Only we didn't know. And Congress lacked the courage to correct the record-- allowed us to be deceived by the Director of National Intelligence.

To me, that is the very definition of failed oversight. And Edward Snowden was watching. Now, what about our courts? The court that had blessed the NSA's mass surveillance of Americans is a specialized court that meets in secret and hears only from the government. It was designed to grant warrants for foreign intelligence collection. It makes sense that such a court would hear only from the government. Over the last decade, it expanded its role to rule on the legality and constitutionality of programmatic surveillance. Judicial review of those programs amounted to a secret court upholding secret programs by secretly reinterpreting American-- federal laws. Now, when groups like the ACLU tried to challenge the NSA's activities in open federal courts, an interesting thing happened. The government didn't say to those courts that the programs were illegal. The government said that we had no right to be in court. And the courts exceeded to that demand.

The government's argument was, we couldn't prove that we had been surveilled. Therefore, we had no standing to even raise these challenges. And in a 5 to 4 decision last year, the Supreme Court accepted that rationale and dismissed the case without even considering the legality of these programs. Edward Snowden was watching that too. Now, when critics say that Edward Snowden should have gone through the system, that's the system they're talking about. Courts and a Congress that had abdicated their constitutional oversight role. Now, what's happened since Edward Snowden's act of conscience-- since he brought the public into this discussion? Well, two federal judges have now considered whether the NSA's mass collection of Americans' phone data is legal. One said it's almost certainly unconstitutional, almost Orwellian. Another disagreed, but the key point is that both of these judges heard the challenge. They both agreed that we had standing to challenge the program, which was a remarkable development in itself. Finally, these courts are doing their job and more challenges are on the way. What about Congress? A newly energized Congress has held dozens of oversight hearings-- public ones--And is considering sweeping intelligence reforms that we haven't seen in nearly half a century-- to end bulk collection of Americans' phone records, to reform that secret FISA court so that it doesn't only hear from the government and others. Even the executive branch has undergone an extraordinary reevaluation of these programs. An NSA review panel appointed by the president-- which included very, very senior former intelligence officials-- the number two at the CIA-- concluded that the NSA had allowed its technological capabilities to dictate its surveillance practices, rather than ensuring that its practices conform to our laws and values. None of this would have happened without Edward Snowden. For that reason alone, he was justified.

### Moderator
Claim: Thank you. Ben Wizner. And that's our motion – “Snowden was justified.” And now here to speak against this motion, I'd like to bring to the lectern James Woolsey. He is Chairman of the Foundation for Defense of Democracies and a former director of the Central Intelligence Agency. Ladies and Gentlemen, please welcome James Woolsey.

### Scientific Advocate (SA)
Claim: Thank you. I was honored to be asked to be here tonight, with this distinguished group. But, to tell you the truth, since I spent 22 years as a Washington lawyer, and then some time out at the CIA in the Clinton administration, I'm actually honored to be invited into any polite company for any purpose at all. I am going to be relying on the blog, the Lawfare blog, which publishes material usually a few days after it's released to press, and much of the Snowden material has come into the public media in that way. A couple of introductory points: Once you release material that had been classified or restricted for any other contractual or any other reason, you release it to the world.

Mr. Snowden pledged to protect the Constitution against enemies foreign and domestic, but he didn't do that. What he did was release-- steal and release-- material that went to, among others, Hezbollah, al-Qaeda, Hamas, Pyongyang, Tehran and so on. In the real world, you can't have a principle that it is really important to release material, but you're only going to release it to nice people; you're not going to let terrorists and dictators peruse it and use it. But that's what they do, and that's what they are doing, because Mr. Snowden decided to let them do that.

Also, it is important, I think, that what Mr. Snowden did must be viewed in the context of an overall approach toward dealing with these tremendous issues of privacy versus security. He looked at this question, apparently, from the point of view of one who can pick and choose those portions of an obligation that he wants to maintain. He did not stay with the proposition that he had to fulfill his obligation to the United States across the board. He ignored some duties and did not ignore others. But he did not fulfill his obligations overall.

What are the consequences of this? I'm going to mention five cases that have come to light from Snowden materials and printed in the blogs, about what the consequences are of dealing with international relations in this way, and forcing your country to do it by the leaks that you have sponsored or undertaken. For example, China is the bad boy of cyber attacks. Throughout the world, Chinese cyber attacks-- theft of information and material, malware, on and on-- are a nuisance at best and a potential tragedy at worst to a huge range of countries and individuals.

We had figured out a way, pre-Snowden-- the United States government had-- to essentially have a bit of a jiu-jitsu operation against the Chinese and to create a possibility whereby we could take their malware in a cyber world and send it back to them after make some adjustments and create problems for them rather than they creating problems for us. It's a clever operation. Mr. Snowden, of course, ended it by explicitly turning loose material that dealt with it precisely. We have an organization in the Middle East-- the Islamic State of Iraq-- a terrorist organization of the worst kind.

Pre-Snowden, we were reading not only their emails, but their preparation, their early- stage drafts of emails. Had we been reading fully the emails of al-Qaeda before 9/11, we might well have saved thousands of lives. But here, our ability to read ISI's emails has been now obliterated by having been made public to the terrorist group itself. In the defense department, working together with the intelligence community, it has come to be possible to utilize cell phones, and their operation, with some very clever software in such a way that you can help an individual member of the military or an individual CIA operations officer know whether he or she is being followed or not.

A very clever system, one that saves people's lives. That also is no longer with us because Snowden betrayed it, and it's now known to our adversaries.

In Latin America, we have come to find how to penetrate the communication networks of some of the worst organizations and groups that are selling women, principally women, into sexual slavery. We had a very good handle on how that was being done, working with other Latin American countries in dealing with it. And that trafficking, that human trafficking network and our knowledge of their capabilities is, of course, now gone, with Snowden having released that to those who are enslaving women in that part of the world.

Thank you.

### Moderator
Claim: James Woolsey, I'm sorry, your time is up.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Thank you very much. And a reminder of what's going on, we are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion: “Snowden was justified.” You've heard the first two opening statements and now onto the third. Debating for the motion, "Snowden was justified," Daniel Ellsberg, a former U.S. military analyst and the Pentagon Papers whistleblower. Ladies and gentlemen, Daniel Ellsberg.

### Conspiracy Advocate (CA)
Claim: Thank you very much. Yes, I believe that Edward Snowden was fully justified in what he did.

That does not cause me to support or make a judgment on any particular thing which has not yet been released or which has been released, exactly, but a question of whether he has served the public interest, on balance, in a way that could not have happened otherwise. I don't know the details that Ambassador, former DCI, James Woolsey, has told about. And I'm not sure how you know, actually, unless you are privy in a way that has not been announced here. I do know what has been released by the papers so far. Snowden, of course, has not released a single page by himself. He has explicitly said, over and over, that his own-- he doesn't trust his own bias in terms of transparency here. He wanted a judgment to be made of public interest by journalists that he trusted, and I think with right. And that is what has come out so far. I think that he was justified to the same degree, and in the same way, that I believe I was justified in releasing 4,000 or 7,000 pages of top secret documents 40 years ago, the Pentagon Papers.

I believe that I had been mistaken earlier to keep silent about what I knew to be lies by my president, Lyndon Johnson, and later the president Richard Nixon, for whom I'd also worked, about what they were doing, what was happening, what the costs were, what the prospects were in Vietnam. I was concerned at that moment not so much about the Constitution, which had clearly been violated in terms of lying us into that war, but I was concerned at the people who were dying on both sides wrongly, I thought, by our escalations and by those lies.

I'm saying that Snowden, I believe, did what needed to be done, what the public needed to know. I think there was no other way-- no better way and almost no other way-- for that information to get out; that it was worth, as he said, taking the utmost risks to his freedom and even his life.

And, of course, we've heard exaltations, actually, by Mike Rogers of the House Intelligence Committee, the Homeland Security Committee, that he should be extralegally assassinated. Others have suggested by due process of law-- I give Ambassador Woolsey credit for talking about the need for due process here. But the fact is had I believed the motives that were described by the people, you know, at the beginning of the supposed opposition to Snowden, and we haven't heard that precisely from these two people yet, but-- or at all-- but if I'd believed that he had done this for some other country, for Russia, for China, to their benefit and-- or even to major benefit to them, outweighing any benefit to the public interest-- I would not be supporting him now. I believe firmly that Edward Snowden is no more a traitor than I am or that I was. And I'm not.

I was called that by the president and the vice president at the time, 40 years ago-- 43 years ago. Many-- I was called every name that has been called, virtually, to Edward Snowden or for that matter to Chelsea Manning earlier. In terms of blood on hands, as to what would be the benefit-- the cost of this, none of that came out in my case, which is, I think, why I'm seen somewhat differently now, 40 years later. Nothing in Chelsea Manning's trial actually came out to justify the statement that people had died as a result of his revelations, and I think you should take with more than a grain of salt the descriptions right now that much worse will happen from Edward Snowden, revelations. The fact is that, I think, what he revealed was not just what NSA was doing, which I will make a premise-- I will stipulate-- was essentially with the knowledge of the president, at the orders of the president, desire of the president, and the knowledge of key figures in Congress.

But, as Ben Wizner made the point, that to me reveals his greatest revelation, which is that the reforms that came in after earlier revelations of abuses by the FBI, CIA, NSA, and Army Intelligence, 40 years ago and 35 years ago, that led to the Church Committee and the current reforms, like the FISA Court and the intelligence committees, I think what Snowden has revealed is that those reforms, which were very necessary, failed. And they need to be not only redone, but better reforms are necessary, and I hope very much will result from what Snowden has revealed. As a matter of fact, I'll have mentioned already that Ambassador Woolsey has said that he thought there should be due process, there should be a trial for treason-- that's something I'd argue with-- which implies that he thinks that Snowden adhered to an enemy of the United States-- that's the definition in the Constitution, which I know he knows. I certainly disagree with him on that, and I think there's-- that's absolutely wrong.

But he believes then as a result he should get the maximum penalty for that, which is to be hanged by the neck till he is dead. Now, actually one American was hanged by the neck for giving secrets to Americans. Actually, he was the first American to be charged with giving secrets to Americans. I was the second, 200 years later. His name was Nathan Hale, and it was a name that used to be known to every American school child as I know, and I've found sadly that, that's not-- seems not to be the case today. And he was an American spy for George Washington during the American Revolution, hanged by the British, and the reason he was remembered during my growing up was for his words on the gallows: "I regret that I have but one life to give for my country." What country was that?

Not the country of his birth, that was the colony of King George III, in which he was in rebellion, and was charged with treason essentially, of which he was essentially guilty to George III, like every other signer of the Declaration of Independence, five of whom, out of 56, were hanged as a result. But they pledged their lives, their fortunes, and their sacred honor, like Nathan Hale, to a country that did not yet exist in the world, a country of-- later to be, shortly to be-- of a constitution with separation of powers, independent branches with checks and balances against each other, and a country with a Bill of Rights. When Snowden said there were things worth dying for, I agree with him. That's the mood in which I gave the Pentagon Papers, and I think he was right to do what he did to defend and protect the Constitution of the United States.

### Moderator
Claim: Thank you, Daniel Ellsberg. motion is "Snowden was justified," and here to make his argument against this motion, our final speaker in the opening round, Andrew McCarthy. He is a contributing editor to the National Review and a former federal prosecutor. Ladies and gentlemen, Andrew McCarthy.

### Scientific Advocate (SA)
Claim: Let me jump right in. It's interesting that Mr. Ellsberg should be able to say that he's not able-- or at this point-- to process what's in the documents. What Ambassador Woolsey was referring to was analyses of the actual documents that have been released. If he can't say what's in the documents, that puts him in a common place with Edward Snowden himself. Notice that Mr. Ellsberg mentioned that he removed, he said, somewhere been four- and seven- thousand documents.

And that's what was put out. Snowden has released 1.7 million documents. He couldn't conceivably have known what was in the documents at the time of purloining them and putting them out. We're talking about a massively different leak, and one that's been massively damaging to the United States. John mentioned that this is my second rodeo at Intelligence Squared. I think it's worth revisiting the first one, because it says a lot about the trajectory that we've walked on this road, between liberty and security. When I was here the last time, the question was whether we needed to have more surveillance to prevent terrorist attacks. And-- it was interesting-- the audience was of a mind that, you know, we absolutely did need more surveillance. They recognized we had serious enemies of the United States who wanted to mass murder Americans.

But something made them uncomfortable. And when we got to talk to them afterwards, I got to find out what the something was: George Bush. Not George Bush the person, but the concept that so much power was reposed in one individual-- that one person could be able to order warrantless surveillance, that one person could get to be the judge, the jury-- in some instances, as commander-in-chief-- the executioner, on the basis of the information that was gleaned from the warrantless surveillance that was ordered, surveillance that took place without the permission of a court. And that was what the audience back then had the most trouble with, this idea that we don't have enough checks and balances. We don't have enough legislative buy-in. We don't have enough judicial oversight. It's interesting, because what President Bush was trying to impose on this sort of new kind of war was old rules of war.

And they were probably best explained in 1948-- at least the reason for them-- by Robert Jackson, who's an interesting person in American history because he's a giant in both American law and American politics. Nuremberg prosecutor, Supreme Court justice, FDR's attorney general. In a 1948 case, called Chicago and Southern Airlines v. Waterman-- he explained why national security had to be an executive responsibility. And the primary reason was, in a free democracy, the framers thought the most important decisions we make are the decisions about our national security. And they need to be made by elected officials who answer to the people whose lives are at stake.

And when you transfer that responsibility over to courts, you take it from the accountable public officials to public officials who are purposely insulated from politics and who you can't get rid of when they get it wrong. Well, we've spent about a half- century now experimenting-- and I think the experiment is still ongoing-- with how far we can afford to depart from the vision of the framers. And from the 1970s forward, what we have tried to do is take rule of law protocols-- which apply to the United States, and mainly the law enforcement system, in peace time-- and impose them on war. And we've had a very difficult time doing it. It's been a blistering debate, at times. And nobody's happy about it. Nobody's ever happy about what the outcome is. Some people think the executive doesn't have enough control anymore.

Some think the courts are too involved. Some think the courts are not involved enough. But here's the interesting thing. We did get to a place where we came together as a country-- and even if everybody was not satisfied with the outcome, we did strike a balance. We established laws which took away a lot of the president's unilateral power; forced the president to go to judges in order to get surveillance authority; institutionalized rigorous congressional oversight. In fact, most of what we know about abuses at the NSA actually comes from self-reporting, whether it's self-reporting to courts or self-reporting to Congress. You may not like the laws. I don't like the laws the way that they've-- the way that they’ve finally played out. The NSA program, the metadata program’s a perfect example. There's no question that it's constitutional---- the Supreme Court precedent that holds that. Whether it's legal or not under the statute that Congress imposed is a closer question. It turns on what the legal definition of relevance, as applied to this national security question, is. Is it legal, is it not legal? You can make the argument that it's not, but 15 federal judges who've looked at it have upheld it. And nobody has repealed it yet for all the talk about doing that. But here's the thing: We actually set up this system with exactly the checks and balances that were at issue during the Bush days, the bad old Bush days when too much power was reposed in one person. And now where are we with Edward Snowden? We are right back to one person who's judge, jury, lawgiver, one person who decides what American secrets get kept and what gets exposed to our enemies.

And that person's not the president anymore. That person is a person who had access to this information because he violated his oath. The last time I was here, the audience told me that could never, ever be justified.

## Round 2

### Moderator
Claim: Thank you, Andrew McCarthy. And that concludes round 1 of this Intelligence Squared U.S. debate where our motion is "Snowden was justified." And keep in mind how you voted at the beginning of the evening. And remember, we're going to have you vote again immediately after you've heard the closing arguments. And the team that has moved your numbers the most in percentage point terms will be declared our winner. Now onto round 2. In round 2, the debaters address one another directly and take questions from me and from you in the audience. Our motion is this: Snowden was justified. Arguing for the motion, we've heard from Daniel Ellsberg and Ben Wizner.

They have argued basically that the reaction itself to the revelations, the spasm of reform undergoing-- under-- happening in Washington now indicates that something was wrong, that there was something to blow the whistle on. They also say that the whistleblower system itself internally is broken, that the watchdog system itself internally is broken. And at bottom, there was no other way for Edward Snowden to do what he wanted to do. And by the way, he didn't set out to spy for our enemies. The team arguing against the motion, James Woolsey and Andrew McCarthy say nothing justifies what Edward Snowden has done to the United States; that in fact he has caused series harm to America's security. They went through a list of specific programs that were clever, involved a great deal of investment and that now have been obliterated by his action to the detriment of everyone's security. They say a sign of the irresponsibility of what he did was the sheer number of documents that he released. He could not have possibly known himself what was in all of them, and that, by the way, the internal system does work. Oversight, carefully negotiated and worked out for years is functioning as well as it can.

I want to put first to the side that's arguing against this motion, this question of-- that didn't really come up very much in either of the opening statements-- as to whether what Snowden revealed to the degree that we know it was in any way say whistle worthy. Was there something there that was going wrong that needed to change? And I think in terms of the headline stuff of Angela Merkel's phone being listened into and then the one that everybody here has that direct connection to, the metadata. Anything wrong with those programs? Did they need to be exposed in the first place, Andrew McCarthy?

### Scientific Advocate (SA)
Claim: Well, it's interesting, one of the last times that FBI director Muller testified before Congress, he was asked by our congressmen here in New York, Jerry Nadler, what the big deal was about this, because as far as the metadata was concerned, he said we know all about this.

We heard about bulk collections back in 2006. USA Today had put an article out back then. He said that the broad outlines of this were known, even known to the public. They were vigorously argued about at the time the Patriot Act was amended and at the time of the overhaul of the foreign intelligence surveillance act. So in terms of the program that is most controversial, there's no question that what Snowden has revealed has filled out some details that we didn't know about and certainly the breadth of what's been collected makes you blanch when you hear it. But in principle, that part of the revelation has been known for a long period of time. The revelations that he made that have helped our enemies, the ones that ambassador Woolsey went through and many other ones, I mean, I don't know how you even say with a straight face that--

### Moderator
Claim: But, so, Andrew, just to focus on the question-- I hear where you're going with this. But to the basic question of whether there was really anything whistle blow worthy that we know of, you're not concerned by what he revealed as being in violation of the Constitution, which is his argument.

### Scientific Advocate (SA)
Claim: That's two different things. It's not that I'm not concerned. Congress is concerned. That's why there'll probably be some modifications of the law. Was it whistleblower worthy? No.

### Moderator
Claim: Okay. Let me go to Ben Wizner, please, on the other side. Your response.

### Conspiracy Advocate (CA)
Claim: Well, I've been following this issue very closely, to say the least, over the last ten years or more. I did not know until The Guardian published the document that the NSA, which is a foreign intelligence agency, was, on a daily basis, collecting the phone records of almost every American. Someone else who didn't know, or says he didn't know is Republican representative Jim Sensenbrenner who was one of the principal authors of the Patriot Act, who says that he didn't know until this document was published that section 215 of the Patriot Act was being used in this way.

Whether, again, that's true or not isn't important to my argument. Either he did not know-- he certainly should have known. Either way, Congress didn't do anything about it. As soon as the public was read into this debate, we're now seeing open federal courts debate the constitutionality of this. One federal judge actually enjoined it and said it's almost certainly unconstitutional. And we're seeing Congress threaten not to reauthorize this unless the administration will agree to reforms.

### Moderator
Claim: James Woolsey.

### Scientific Advocate (SA)
Claim: Much of the controversy here involves metadata, which lets the executive branch-- and has for many years-- lets them see and keep a record of what is on the outside of an envelope, let's say, in first class mail, the address, the return address, and the postmark. That's been approved by the courts for a long time.

It has been true for decades, it's true now. That is basically metadata with first class mail. If you do it with telephone calls, call number that was called, number that was called from, length of call. What has changed here is not that the federal government has gone away from a reasonable policy. It was, and I think it still is. What's changed is Moore's law. What's changed is now we are talking about emails and telephone calls in the gazillions rather than first class letters. But you still do not hear of substantial malfeasance or other steps using simply the metadata.

### Moderator
Claim: So James Woolsey, you're saying there really was no-- the alarm did not need to be rung. There wasn't a fire in that sense.

### Scientific Advocate (SA)
Claim: Where alarms need to be running, they should be discussed, and sometimes it's important. I stood behind at the time and I stand behind Daniel Ellsberg now for his courage in moving on the Pentagon Papers. He was dealing with policy issues and major lies that had come at us from the executive branch, and he did a courageous job, defended himself in court. Federal government misbehaved, and he was released. But what Daniel Ellsberg did I think deserved a whistle blowing. What happens when metadata goes as a result of the development of electronics from one instrumentality to another, even if you knew about it at one time, and you're a congressman, and you forgot about it because you're getting older and you forget stuff, doesn't change-- doesn't change-- not talking about anybody in this room. Okay. change the fact that metadata is just metadata.

### Moderator
Claim: All right. Let me bring in Daniel Ellsberg. It's always dangerous when your opponent starts to compliment you. It's a very tricky move. But his point being, you had something to blow a whistle about. Edward Snowden does not. What's your response to that?

### Conspiracy Advocate (CA)
Claim: Let me move on something else--

### Moderator
Claim: No, I-- before you do that, I'd like to hear your answer to that question.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: I'm saying that he is saying that Edward Snowden did not have anything to blow a whistle on, you did, but Snowden didn't.

### Conspiracy Advocate (CA)
Claim: Okay, most of the material that I put out in the Pentagon Papers, 4,000 pages that I gave to the newspapers, an additional 3,000 that I gave only to the Senate Foreign Relations Committee, it so happens, so there's some I didn't put out, it's very clear, by the way, that Snowden had an enormous amount of information that he could have put out. He says, and hasn't been challenged, that he chose not to because he thought it was not in the public interest.

And a lot of what he put out was for background to the press in looking at that, but he relied on their judgment as to what to put out. In terms of when you say there was a difference in my case, in the 4,000 or even the 7,000 pages, there was actually no evidence of clear cut domestic criminality or even international criminality. So if it was whistleblowing, and I would say it was, that's not a requirement. I thought it was reckless, deceptive, dangerous decision making, and I felt it was still going on. And, unfortunately, I did not have the documents to prove what I was saying at the time from oral testimony I got--

### Moderator
Claim: But the point-- to the point that James Woolsey was making, he is saying that Snowden-- that the Snowden revelations don't reveal anything that suggested that a whistleblowing was needed.

### Conspiracy Advocate (CA)
Claim: Okay, right, let me address that. They revealed, of course, and it's the only way we know, that Clapper, director of National Intelligence, Clapper, gave a false statement to - - we know it from Snowden.

Now, I do not believe, as Ben Wizner says, that actually he meant to deceive Congress. I don't believe he did deceive Congress. I believe that he, unchallenged by Congress, meant to deceive the public and did so effectively since Congress didn't challenge it. I just read a very interesting piece of background here by Mr. McCarthy which convinced me that Sensenbrenner is speaking very questionably when he denies that he knew or that his act covered that. That's the problem. Let me assume that Sensenbrenner is not telling the truth on this.

### Moderator
Claim: Remind everyone who Sensenbrenner is.

### Conspiracy Advocate (CA)
Claim: I-- James Sensenbrenner who calls himself the "architect of the Patriot Act," although, again, Mr. McCarthy said that was quite misleading. The point here is that Congress has been willing to deceive the public along with the NSA and the president regularly here, and that's the problem, that Snowden revealed.

And I want to make a specific point here that was raised earlier on this metadata. Why are we talking only about metadata entirely here? First of all, there's a lot of text messages that are not metadata, 200 million a day, that get brought up. But what makes us believe that we were not listening on a different program-- I don't mean listening, I mean collecting recording for later retrieval-- all the content of the emails and all the content of the audio of the telephone? And the answer is the president and the others keep saying, "We don't do it." Why should we believe them? Why would you believe

### Moderator
Claim: Okay, let's take the question to the other side. Andrew McCarthy, why should we believe them?

### Scientific Advocate (SA)
Claim: Because we now have a system where there is oversight by Congress and oversight by the courts, and that has shown time and time again where they have either exceeded their authority or they have gone beyond what the legal is--

### Conspiracy Advocate (CA)
Claim: But how did we hear that? We heard it from Snowden's documents that came out.

### Scientific Advocate (SA)
Claim: No, what--

### Conspiracy Advocate (CA)
Claim: We saw opinions of the FISA Court, the Federal Court had not been made public.

### Scientific Advocate (SA)
Claim: Yes, and-- right, and from the opinions of the FISA Court, what we see is that there's a give and take between the FISA Court and the executive branch which there never was before the 1970s where they actually have to narrow the requests that they make and actually have to go back to--

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: --go back to their desks and rewrite the requests that they make.

### Conspiracy Advocate (CA)
Claim: can actually say how many times, out of 13,000 requests for warrants, 11 had to be modified or refused.

### Scientific Advocate (SA)
Claim: No, no, no, they modify at a very high percentage.

### Conspiracy Advocate (CA)
Claim: Oh,

### Scientific Advocate (SA)
Claim: If you're talking about warrants that get turned down or warrants that have to be totally rewritten--

### Conspiracy Advocate (CA)
Claim: Yeah, warrants that get turned down, turned down.

### Scientific Advocate (SA)
Claim: --sure.

### Scientific Advocate (SA)
Claim: But as far as modification is concerned-- and, by the way, all this-- this argument about how the FISA Court is a rubberstamp, remember the infamous wall before 9/11 where the right hand couldn't-- the left hand couldn't know what the right hand was doing in the Justice Department, the FBI?

The FISA Court, when the Patriotic Act got rid of the wall and the FISA Court ultimately upheld that-- the FISA Court of Appeals upheld it, the FISA Court itself, by judicial fiat, attempted to rebuild the wall. That's the activist rubberstamp court that wouldn't let-- in the post 9/11 atmosphere-- did not want to allow the Justice Department to proceed without the wall--

### Conspiracy Advocate (CA)
Claim: But did they--

### Moderator
Claim: Let's bring Ben Wizner in, who has been

### Conspiracy Advocate (CA)
Claim: Did they succeed?

### Scientific Advocate (SA)
Claim: No. They got overruled because the law didn't support what they were trying to do. The point is, though--

### Conspiracy Advocate (CA)
Claim: They are not

### Scientific Advocate (SA)
Claim: --they were rubber-stamped.

### Conspiracy Advocate (CA)
Claim: --a check in the balance? It didn't happen.

### Moderator
Claim: Ben Wizner. Ben--

### Scientific Advocate (SA)
Claim: What-- when you lose--

### Moderator
Claim: Ben Wizner-- just let me--

### Scientific Advocate (SA)
Claim: What-- no let me-- this is great. When-- when they win-- when they lose, you need-- what is it? The checks and balances are there. When the checks and balances aren't there, you need to have them there.

And when we put them in there, when you lose, there were no check balances.

### Conspiracy Advocate (CA)
Claim: Clapper--

### Conspiracy Advocate (CA)
Claim: Clapper made a full statement.

### Scientific Advocate (SA)
Claim: We want the courts. We want the courts until we lose in the courts. And then we leak everything.

### Moderator
Claim: Ben Wizner, did you-- Ben, did you-- did you follow the point Andrew just made? Because I'd like you to respond to it, actually. The-- he's sort of saying you're kind of arguing it both ways.

### Conspiracy Advocate (CA)
Claim: I might have lost it in the give and take a little bit, but I will say this, that one of the points that I made was precisely that the court that had approved this 15 times had exceeded its mandate. This is a court that quite properly was set up to hear warrant applications in secret. When you're seeking a warrant, you don't need an adversarial process. We don't want the person who we're conducting surveillance on to know that we've sought a warrant. What this court started to do over the last decade was to write long opinions-- 30, 50, 80 pages long-- ruling on whether whole programs of surveillance were consistent with federal statutes and consistent with the Constitution. They did that without the benefit of any adversary. They did that without anybody arguing the other side in front of these courts. Many of these judges who have left the court have said they would have benefited from an adversary.

And what's happened now that these same challenges are being brought in open federal courts? Well, now there's a 50-50 response so far. One judge in New York said that he thought that the phone records program was legal. One judge in D.C., a Republican judge, appointed by a Republican president, said he thought the program was almost Orwellian and a threat to democracy.

### Moderator
Claim: Okay. Let's-- let me-- let me-- I want to bring in James, because you made that point before, and see what his response is to that.

### Scientific Advocate (SA)
Claim: From 1971 to '73, I was General Council of the Senate Armed Services Committee. There was no intelligence committee at the time, so four Congressional staffers from the Senate and the House side-- and four senators-- did all of the oversight work with respect to the intelligence community-- everything-- the National Reconnaissance Office, NSA, CIA, and the rest. I have seen-- either from in the executive branch or as a private citizen interested in these issues and following them-- the oversight personnel capabilities, numbers of offices, numbers of people involved in overseeing the American system of intelligence is truly awesome.

There is no country anywhere in the world that has the massive oversight from legislative, judicial, and executive sides and functions over their intelligence systems-- nobody is even close to the United States. Now, some of you may believe that we need more or we need to change what we've got because it isn't working right. All right. Fine, you know, let's talk about it. Sometimes you've got to keep fixing things. That's what our government is like. Things don't work, you got to fix them. But the idea that across the board, we don't have enough oversight-- I think-- I wish some of you could have joined me back there in 1971.

### Moderator
Claim: --you said in your opening statement that Edward Snowden, having decided as an individual that he saw something wrong-- and your opponents disagree that what he saw was wrong enough to blow a whistle on. Nevertheless, when he decided to blow a whistle-- that he had no other way, but ultimately to steal the material and go to the press.

### Moderator
Claim: That's not the problem.

### Moderator
Claim: Wait, let Daniel Ellsberg respond to it. Daniel. Okay. Why did he have no other way?

### Conspiracy Advocate (CA)
Claim: Okay. Fine. I'm glad to have a chance to address that. Actually, the president and others-- many others-- have spoken about-- there was a better way, the way it was done was sensational, more heat than light. There were better ways to do that. I think that's clearly wrong. I really whether the president is so misinformed about the situation as actually to believe that. There were four NSA high officials-- senior officials-- I'll name them: Kurt Wiebe, Ed Loomis, Bill Binney, and Thomas Drake, who have among them an average of 30 years in the NSA-- one is 28, another is 32-- who left the NSA because it conflicted with their conscience eventually.

They left it because it conflicted with the Constitution. They had tested the proposition - - that is, there are other ways to do it-- in every possible way. They had complained to their superiors that the then warrantless surveillance that was going on since 9/11 was unconstitutional, was a violation of the Fourth Amendment.

### Scientific Advocate (SA)
Claim: But what was the Constitutional violation?

### Conspiracy Advocate (CA)
Claim: The Fourth Amendment.

### Scientific Advocate (SA)
Claim: Oh, really?

### Moderator
Claim: But, Andrew, let him just finish. I want to stay to the point of whether he had another way.

### Conspiracy Advocate (CA)
Claim: Let me say-- let me say on that. Let me go a little further. It wasn't just unconstitutional. The warrant with surveillance I think was blatantly illegal and criminal actually--

### Moderator
Claim: Okay, but Daniel-- Daniel--

### Conspiracy Advocate (CA)
Claim: Well, I'm sorry, I do need to say--

### Moderator
Claim: No, no, no. Wait. Whoa, whoa, whoa. Just a minute. I just want you to complete your thought on why he had no other way.

### Conspiracy Advocate (CA)
Claim: Yeah, okay.

### Moderator
Claim: And I want to hear from your opponents what the other way was.

### Conspiracy Advocate (CA)
Claim: They did everything-- they went to their superiors, they went to the inspector generals and NSA and at the DIB. They went to congressional staff and asked to testify. They asked to testify in open court under oath.

They got nowhere. Every one of them was subject wrongly to an FBI raid which took their computers without charging them ever with anything. Thomas Drake as a result, has got a spurious investigation and so forth. They have each said, in contrast-- without endorsing everything that Snowden has said-- they have said the path he used was the only way to do what they had tried to do, was to bring this to the attention of Congress and the public and that there was no other way to do it.

### Moderator
Claim: All right. So the--

Andrew McCarthy.

### Scientific Advocate (SA)
Claim: So the Supreme Court says that metadata is not Constitutionally protected, but four intelligence agents and you know that it is a Fourth Amendment violation.

### Conspiracy Advocate (CA)
Claim: We were talking in 2001 to 2006 about metadata. They were collecting-- Thomas Drake--

### Scientific Advocate (SA)
Claim: It's the same information.

### Conspiracy Advocate (CA)
Claim: Thomas Drake was saying at the time, within NSA, and has said since, they were collecting content. And he said it's a secret--

### Scientific Advocate (SA)
Claim: I'm not-- I'm not even going to get-- I'm not even going to get into--

### Moderator
Claim: Andrew has the floor right now.

### Scientific Advocate (SA)
Claim: I'm not even going to get into the fact that the metadata base--

### Conspiracy Advocate (CA)
Claim: We're not talking metadata.

### Scientific Advocate (SA)
Claim: --that we're-- I'm talking about meta-- I'm talking about metadata. I get to do that. The metadata base--

### Conspiracy Advocate (CA)
Claim: I can see why

### Scientific Advocate (SA)
Claim: --where they keep talking about how all your records are being collected, your name is not in it, your address is not in it.

### Moderator
Claim: Wait. Hold it. Hold it, hold it, hold it. I don't want us to be talking about metadata all night because there is an-- there is a debate to be held on whether the metadata itself represents a threat to privacy. And we can have that debate. We're trying to make a judgment about Snowden's action.

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: And I--

### Scientific Advocate (SA)
Claim: And the word "Constitutional"--

### Moderator
Claim: And we've gone through the issue of whether you thought he was whistle blow worthy or not. You said no. I want to move on to this point of whether he had another way to - - if he had this conviction that something was wrong, what would he do internally? What's there for him? When your opponents are saying that there are four examples that they cited of other people who apparently he was watching who tried to do the same thing and got nowhere and that that therefore justifies what he did. What's your response to that?

### Scientific Advocate (SA)
Claim: He could have gone to Congress, which is the main place that he could have gone to. He could have gone to inspectors general in his own agency. I haven't heard any evidence that he actually tried to take any of these steps whatsoever.

### Moderator
Claim: Did he try, Ben Wizner?

### Conspiracy Advocate (CA)
Claim: Yeah, he did. He certainly has told Barton Gellman of the Washington Post that he did complain regularly internally. But it's interesting that you think he should have gone to the same Congress that you say knew everything that he was going to report. Congress did know. He was supposed to tell-- Senator Wydenwas on the floor of the Senate with his hair on fire saying, "If only the public knew what I knew, they would be outraged, they would be furious." Well, we didn't know because he didn't tell us. We only know it because Edward Snowden gave it to the press, and the press told us. Now the rules are changing.

### Moderator
Claim: When you say he did try, really, how hard did he try to go up the chain of command?

### Conspiracy Advocate (CA)
Claim: Well, and how effective could it have been?

### Moderator
Claim: No, that's a different question.

### Conspiracy Advocate (CA)
Claim: No, no.

### Moderator
Claim: You're saying he didn't try because-- you're saying he didn't try because he didn't think it would work.

### Conspiracy Advocate (CA)
Claim: No, I'm saying he did report his concerns to superiors.

### Moderator
Claim: Uh-huh.

### Conspiracy Advocate (CA)
Claim: One time when he reported concerns to superiors in a posting in Geneva, he was reprimanded and punished for it. This is the experience of people who complained in the intelligence community is that they either get ignored or they get crushed.

### Scientific Advocate (SA)
Claim: I think that's nonsense.

### Moderator
Claim: James Woolsey.

### Scientific Advocate (SA)
Claim: I have had an inspector general look into my management of the intelligence community and had disputes about it with him. I have seen a whole range of approaches of people inside intelligence organizations go up the chain through the processes that let them argue that they've not been well treated. These systems are not fanciful. They work most of the time. They're not perfect.

But generally speaking, if you have an inspector general or you have a committee of the Congress that has responsibilities, you are-- you live in a free country. You can-- you can go see people. You can make appointments. You can argue. You can compromise. It's the way we do things. But you can't, just forever add people and offices, otherwise you won't have anybody doing anything else. You already have so many people and so many structures preserving oversight over the intelligence community that the mind reels.

### Moderator
Claim: Daniel Ellsberg.

### Conspiracy Advocate (CA)
Claim: I can believe that Ambassador Woolsey is totally sincere in his description of that. Of course, he's not speaking as a whistleblower, and I wonder how many whistleblowers experience-- actual whistleblowers he has actually spoken to. I have, a great many; the government accountability project and many others.

The experience of going to IGs is simply a way of being-- and to your superiors is a way of identifying yourself as a troublemaker who will be suspected of being a leaker if there is a leak. That's why the four NSA people who had not been a leak to the New York Times-- which in my opinion, they should have been and certainly would have been more effective, that's why they were raided by the FBI and the computers, because they identified themselves as somebody who already thought the system was unconstitutional. Ambassador Woolsey, I thought by your own comment, if I understood you correctly-- and I'm interested that you work on Senate armed services committee and were a senior staffer on that. But I thought I heard you say there were four staffers. There were-- which sounds about right. And there were some others. And the idea, of course, that we're talking about effective oversight is absolutely ludicrous. Judges of the FISA court, several of them now, especially ones off and even some who are on, have said, what can we do to see whether any of our orders are implemented? We don't have technical experience. We don't have staff, we don't have budget. And essentially the same is true of these committees.

And I want to make one last point here. Russell Tice-- well, first Thomas Drake has said-- the one I'm talking about-- has said the secret they're trying to hold onto desperately is to talk about metadata and not reveal how much content they are already recording. And Russell Tice has said, I, in the NSA, had phone records of Justice Alito, of journalists' sources, of Congress people, including Feinstein and her staff and a great deal of content. Now, maybe he's wrong-- maybe he's wrong, but he has asked to testify under oath to Congress. And not one committee has asked one of them to testify because they don't want to know.

### Moderator
Claim: James Woolsey, and then I want to move on.

### Scientific Advocate (SA)
Claim: I was emphasizing--

### Conspiracy Advocate (CA)
Claim: And you should have.

### Scientific Advocate (SA)
Claim: I was emphasizing how much the oversight machinery of the Congress has grown since 1971.

### Conspiracy Advocate (CA)
Claim: Up to four. That's pretty good.

### Scientific Advocate (SA)
Claim: It has stunningly grown. That whole wing of the capitol these days, I get the feeling if you walk into it, you know, it may sink into the ground there are so many people's offices in it.

The oversight machinery of the Congress and of-- I think of the executive branch is quite extensive. It may need some reforms. If so, fine. Let's talk about it. If it has to be classified, talk about it in a classified forum. Figure out what changes need to be made and make them. That's the way we do things in the--

### Moderator
Claim: I want to hear audience questions now. And I ask you to bring up questions that keep us on this topic of Snowden's actions, his motivations, the consequences of what he's done and whether they justify what he did. We haven't even talked yet about the against side's argument that he caused enormous harm to key government programs that are protecting all of us, and somebody might want to bring that up. If you raise your hand, I'll call you-- call on you. If-- a microphone will you brought to you. If you stand up and give your name, we'd appreciate it.

Hold the microphone about the distance from your mouth that I have with this microphone so that we can hear you on the radio broadcasts. Ask a tight, focused question that's on this topic. Sir right down here. Mic's coming down from behind you. Could you stand up, please?

### Moderator
Claim: Thank you. Avi Spindel My question concerns, was it necessary for Snowden to divulge the amount of information that he did and still create the process that he was seeking?

### Moderator
Claim: Ben Wizner.

### Conspiracy Advocate (CA)
Claim: Well, that gives us another opportunity to clarify and to respond to one of Andy McCarthy's points.

### Moderator
Claim: But you are going to answer his question.

### Conspiracy Advocate (CA)
Claim: Yes. The number of documents that Snowden has disclosed is zero. Snowden provided a great deal of material to journalists. He entrusted it to journalists, at The Guardian, at The Washington Post. It's since expanded to the New York Times and other newspapers. His instructions to those reporters were that they, in consultation with their own editors, using their own judgment of what was in the public interest, and in consultation with the United States government, should publish what the public ought to know and should withhold what the public should not know.

My view is that the reporting until now has been extremely responsible. There has not been an article published that didn't give at least the government a chance to weigh in. There have been redactions--

### Moderator
Claim: But then why should-- why should critics of Snowden feel better about that? Why should that make them feel better?

### Conspiracy Advocate (CA)
Claim: I mean, this is

### Scientific Advocate (SA)
Claim: Are you saying-- that disclosing to Greenwald is not disclosing?

### Conspiracy Advocate (CA)
Claim: No. What I'm saying is there is a difference and a long tradition of having journalists compete with the security state over what should be secret and what should be public. If you look at the last decade, what we would not have known without leaks and investigative journalists, we wouldn't have known about torture at Abu Ghraib, we wouldn't have known that the CIA had set up a network of secret prisons across Europe and the Middle East, we wouldn't have known that the NSA had engaged in warrantless wiretapping before this was legalized by Congress in 2008.

All of this we know because journalists engage in competition with government for what the public ought to know and what it shouldn't know. Now, what Snowden did was on a larger scale. He gave a large amount of information to journalists, and those journalists include journalists around the world. I think part of what he wanted us to understand is that this is not about demonizing the NSA. The threat of mass dragnet surveillance, of collecting information about all of us in case one of us comes under suspicion, is a threat to all free society.

### Moderator
Claim: But, sir, was your question couldn't he have done the same thing with fewer documents, with the--

### Moderator
Claim: Yes--

### Moderator
Claim: --okay. Could he have not done more of the same thing with fewer documents?

### Conspiracy Advocate (CA)
Claim: We don't know the answer yet. We don't know what has still to be published. And it's possible that the most important revelation that Snowden provided to journalists has not yet been published. Do I think that the reporting so far has been in the public interest? I think so, profoundly.

### Moderator
Claim: Jim Woolsey, do you want to respond to that?

### Scientific Advocate (SA)
Claim: Yes. Snowden has released in some fashion-- maybe he doesn't consider giving to newspaper reporters and letting them hold onto it for a while a release-- but, nonetheless, he's released, according to the press-- 1.7--

### Conspiracy Advocate (CA)
Claim: No, no--

### Scientific Advocate (SA)
Claim: --million--

### Conspiracy Advocate (CA)
Claim: --according to national security officials, not according to the press. The press, quoting unnamed national security officials, quoting classified reports, that information is as false as their testimony was to Congress--

### Scientific Advocate (SA)
Claim: Ah, we can-- we can track back through that, if you want, but I think the key issue is what has he provided to the outside world that gets at the end of this chain of press to the non- press, whatever, gets put in places where people can publicly read it? I gave you four examples of four major American programs that were extremely useful, and the blog material indicates that this is material that was disclosed as a result of Snowden's efforts and operations, and we lost all four of those programs. And we will lose a lot more.

### Moderator
Claim: So does that concern this side? Daniel Ellsberg.

### Conspiracy Advocate (CA)
Claim: I'm sorry. The statement that NSA has lost those programs is as reliable as the statement by NSA that he's released 1.7 million documents. Snowden has said publicly and to me it so happens on encrypted line that, that's an absurd estimate and has no relation to the much, much, much lower amount that he released in terms of this. And the reason that does make a difference is that obviously 1.7 or one million or five-- half a million--

### Conspiracy Advocate (CA)
Claim: --can't be read by him. He learned from Manning to avoid the charge that he was releasing anything he had not read himself.

### Moderator
Claim: Why-- Daniel, why do you say-- I think the word was "absurd," the statement you said Jim Woolsey made, that four important programs had been lost, why is that an absurd statement?

### Conspiracy Advocate (CA)
Claim: No, no, no, it's not absurd. Maybe it happened. But to take at face value the statement that NSA has not been able to replace that, that it doesn't have substitutes, that it got-- that it actually caused them harm

### Scientific Advocate (SA)
Claim: Some of those programs are not NSA programs, they're military programs.

### Conspiracy Advocate (CA)
Claim: Fine, that's also part-- that's part of it.

### Moderator
Claim: the programs of other foreign intelligence services.

### Conspiracy Advocate (CA)
Claim: What I'm saying is that this sort of thing can't be decided by you or me or by the press, it has to be decided by intelligence committees in a court that have an entirely different technical capability and backup and access-- technical access to NSA programs that does not exist now. And I've been trying to give one specific example of that, when Russell Tice has said numerous times and in public that he had evidence, personal knowledge, of targeting of every member of the Armed Service Committee, every member of the Intelligence Committee, including Feinstein, her staff, and home, prepared to testify that under oath-- when he said that he wanted to testify, NSA immediately sent him a letter, which I've seen, saying, "You are--" this is to the Armed Services Committee, your old committee-- and he said, "I want to testify to Armed Services." And they said, "We remind you of your oath under NSA, the Armed Services Committee--" and they didn't distinguish between staff and members-- "the Armed Services Committee is not cleared for that information."What? This is--

### Moderator
Claim: Go to another question.

### Conspiracy Advocate (CA)
Claim: --this is oversight? This is an absolutely broken system.

### Moderator
Claim: Sir, right down here. If anybody's a member of the press, we'd appreciate it if you could identify yourself as well.

### Conspiracy Advocate (CA)
Claim: Isn't this off the record?

### Moderator
Claim: Nothing is off the record-- ever.

### Scientific Advocate (SA)
Claim: Hey, Dan, I thought it was code word.

### Moderator
Claim: Sir?

### Moderator
Claim: Does it disturb you--

### Moderator
Claim: Can you tell us your name?

### Moderator
Claim: Herb London. Thank you. Does it disturb you that some of the revelations that came out when Mr. Snowden was in China and Russia may very well have jeopardized intelligence officers operating clandestinely across the world?

### Moderator
Claim: And your answer can't be, "We don't know if it has," because the question is-- it may well have. It's very plausible--

### Moderator
Claim: Well, if--

### Moderator
Claim: --but I've heard the answer from you guys a few times, and well, who knows? But-- go ahead.

### Moderator
Claim: No, I have--

### Moderator
Claim: Okay. Daniel Ellsberg.

### Conspiracy Advocate (CA)
Claim: Well, the answer I've heard-- and it's a question of who you believe on this-- is that Snowden said that he had actually the knowledge of practically every clandestine office of NSA in the world, not only the knowledge, but he-- I mean, he hadn't just seen it, but he had the knowledge. He said he had no intention of releasing that or taking it with him to China or anywhere else that he took the classified information, because that would not be in the public interest. Now, should we believe him? Well, some say, "No, it's all given to China." First of all, I trust his judgment as to what the public ought to know or not know about NSA more than I trust the judgment of anybody who said, "None of this should be known to the public." I don't think their judgment is to be trusted at all. And I do trust-- subject to analysis. It's the Congress and the courts, and it's the four people in NSA-- plus Tice-- have all said it is essential that there be a group of technies, nerds, hacker types who have the technical knowledge, reporting with full access to NSA data, reporting to Congress and to the judiciary, and that's the only way we will get this system under constitutional control.

### Moderator
Claim: Does anyone have a question that will be directed to this side? And are there any women here who would like to ask a question? I'm trying to balance a bit, but I need you to put your hands up. Thank you. Now it has to be a really great question, of course. Do you mind standing up?

### Moderator
Claim: Of course.

### Moderator
Claim: Thank you.

### Moderator
Claim: Shannon Wilkinson. How could Snowden have approached Congress? I mean, specifically, if someone in his position wanted to have approached Congress before going public, how would he do that? How could he have?

### Moderator
Claim: All right. Thank you.

### Scientific Advocate (SA)
Claim: Picked up the telephone and called staff director of the intelligence committee, and say, "I have a very sensitive matter that I need to discuss with you-- –I want to make an appointment with you."

### Moderator
Claim: And Jim-- for those of us who don't know, that is a realistic scenario. They would take the call. They would take it seriously?

### Scientific Advocate (SA)
Claim: Yes. I mean, it-- Congress does its sometimes rather clumsy best to be responsible to be voters. And I think that-- as a member of the executive branch and a position of importance, if you wanted to talk to somebody senior on the Hill, a staffer-- probably initially-- and then to perhaps a member-- I don't think there are huge barriers to that. There may be with individuals who don't want to be bothered or shouldn't have that job because they're not any good at it-- somebody else ought to have it. That happens.

### Moderator
Claim: But you-- but you've heard from your opponents tonight a fair litany of specific examples that they cite-- none of us can vouch for their veracity, but we think everybody comes here in good faith-- telling the stories of people who've tried that and gotten nowhere. So, what about--

### Scientific Advocate (SA)
Claim: Well, that can--

### Moderator
Claim: --those--

### Scientific Advocate (SA)
Claim: --that can happen. Then you got to try someplace. I mean, Congress is-- there are 535 members up there and they don't all do the same thing, believe me.

### Conspiracy Advocate (CA)
Claim: Can I respond to this briefly?

### Moderator
Claim: Ben Wizner, sure.

### Conspiracy Advocate (CA)
Claim: Yeah, because I think that we may be slightly on the wrong track here. Sometimes the scandal is something that is illegal that's going on, that people don't know about, that Congress doesn't know about. And what the proper channel is, to go to Congress and alert them-- sometimes the scandal is that a whole regime has been created in secret that the system deems legal. And that's what we're talking about here. I believe that these programs were briefed to the committees. I believe that the intelligence committees routinely approved this and were briefed on this, that they were taken to General Alexander's lair, where he had Hollywood set designers design a captain's chair and had the doors whoosh open and close like on the deck of the Starship Enterprise-- this was in an article in Foreign Policy Magazine. I believe that they knew what was going on. So, a 29-year-old contractor calls up Congress and says, "Excuse me, I need to really tell you what you have wrongly approved in secret"-- no.

What was needed-- was for the public to know. And once the public knew, everything changed.

### Moderator
Claim: Right down in front here. Oh, let me just say something for the radio broadcast. I want to remind you, we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two debating this motion: Snowden was justified. Going back to questions from the audience. Sir?

### Moderator
Claim: How long do we have here?

### Moderator
Claim: About another 15.

### Moderator
Claim: Josh Wolfe. Some could say that we are not free unless we are safe. And we know that there are malicious actors. We know that the intent of the NSA's programs were to get these malicious actors. Why is he justified in the context that we are now safer? Why are we safer?

### Moderator
Claim: Great question. That's a great question.

### Moderator
Claim: Go ahead. Go ahead if you want.

### Moderator
Claim: Ben Wizner.

### Conspiracy Advocate (CA)
Claim: Well, you know, again, I treat with great skepticism the claims that we're less safe. The Nixon administration, in trying to block the publication of the Pentagon Papers in the New York Times told the Supreme Court that their publication would cause great and irreparable harm to the security of the United States. Now, that was nonsense. And the lawyer who wrote that brief said so 15 years ago in an apologetic op ed in The Washington Post. I think he's claims of harm to national security don't age as well as whistleblowers who age very, very well. But look, we're not just talking about protecting ourself from a threat of terrorism, which, although severe, is not a common occurrence. We're talking about protecting our republic. And sometimes our republic is more threatened by what we don't know than by publication of things that also alert our enemies. That detention that we face in a democracy, but the cost of democracy is that our enemies have to hear this too. We have to strike the balance in the right way.

My view is that the balance was way tilted towards overclassification and secrecy before Edward Snowden.

### Moderator
Claim: So you're not saying-- but then you're not saying we are safer. You're not saying that Snowden has made us safer.

### Conspiracy Advocate (CA)
Claim: Well, actually, I think with a long term effective, Snowden's revelations will make us safer in a critical respect. They will have an effect on the infrastructure of our communications, that-- one of the effects is that we will begin to prioritize defense, securing our communications over offense, manufacturing vulnerabilities in order to facilitate surveillance, this is a tension that exists within the NSA right now. I think that the spies have won out over the cyber defenders. And I think that it's in all our best-- all of our best interests to put more of our resources into defending the security of our communications rather than being sure that we can listen to every conversation in the world.

### Moderator
Claim: Okay. Let's hear from your opponent, Andrew McCarthy.

### Scientific Advocate (SA)
Claim: May I just say that having worked in the government for a very long time, it's not unknown to me-- and addressing Mr. Wizner's point about hyperbole.

Everything is either the biggest case that ever happened, it's the biggest leak that ever happened, it's the biggest damage that ever happened. It's not the most attractive propensity in government. But the fact that we ought to take a lot of that stuff with a grain of salt doesn't mean that we can't draw our common sense judgment that we've been profoundly harmed. When you give up secrets, you say that you-- the public needs to know. Well, you can't inform the public about the methods and sources of the intelligence community without informing people who want to mass murder Americans. You can't inform the public about the methods and sources not only of your own intelligence service but of the foreign intelligence services that we depend on the cooperation of to keep Americans safe without convincing those foreign services that we are no longer trustworthy repositories of their secrets.

When I was here last time-- I keep going back to it because it's such a strange variance. But when I was here the last time, one of the things that people were very concerned about is that we had isolated ourselves by making unilateral executive branch decisions that not only the other branches of the government didn't support, but that had made us look bad in the international community, and that if we were going to have effective counterterrorism, we needed the cooperation of our allies because there were many, many places in the world where they had good sources, and we didn't. And we couldn't protect the country without that. When you reveal not only our secrets, but their secrets, and you convince them that they might as well not tell us anything because we can't keep a secret, then we lose that cooperation.

And that means that we lose our sources of information in the places of the world that are most dangerous to us.

### Moderator
Claim: Let me cut to the chase with what you just said to the other side and put to Ben Wizner. If, you know, stipulating that Andrew McCarthy may well have a point. You don't really know you're saying the extent of the damage, but it seems, you know, within the realm of possibility that damage was caused. If damage was caused by what Edward Snowden did, of the kind he's talking about, if, was he justified in releasing what he did?

### Conspiracy Advocate (CA)
Claim: Yes, I think so. I think-- look, it's interesting that we have a strict liability standard for disclosing information, but we have a classification system that massively, massively overclassifies. Both can be dangerous. Look, I think that what Edward Snowden is go about it in a way that he considered responsible. He said, I've spent a sheltered life. I've been in the intelligence community. I don't trust my own biases. I'm going to go to principled but aggressive journalists. And those journalists should use their judgment about what should be published.

Now, Edward Snowden told Time magazine-- he didn't agree with all those judgments-- that there were articles that were published that he did not agree were in the public interest, but that proved his point that he is not the one who should have been making those decisions alone and on his own. But, look, I think it's relevant to the question. If you could show me, with evidence and not classified innuendo, that what Edward Snowden did was more damaging to our national security than healthy for our democracy, I would take a different position. Nothing I've heard pushes me there.

### Scientific Advocate (SA)
Claim: Are you saying, though, that he-- then he's not in control of what he took?

### Conspiracy Advocate (CA)
Claim: I'm saying he's not in control of what's being published.

### Scientific Advocate (SA)
Claim: So he takes it, he gives it to others, and then he's done.

### Conspiracy Advocate (CA)
Claim: Well, that's actually what most leakers do.

### Conspiracy Advocate (CA)
Claim: I'm sorry, the point here has been-- again, I'm surprised didn't make-- it's not just that he gave it to journalists for their judgment, I think passed over very quickly here. The Guardian and The Washington Post have both said that they have checked every article that they put out with NSA.

Some would disagree with their doing that, but they have done it, precisely to avoid danger of the sources and methods that you're describing of causing definite harm. Now, in-- that is a first point which hasn't been made here exactly. But the fact is that Wyden and Udall--

### Moderator
Claim: Congressman Wyden.

### Conspiracy Advocate (CA)
Claim: Congressman Wyden-- senator.

### Moderator
Claim: Senator, sorry.

### Conspiracy Advocate (CA)
Claim: Senator Wyden and Senator Udall in fact felt that it was outrageous, that it was shocking to the American people if they knew that, if they knew this stuff, and it was probably unconstitutional. This is part of the intelligence committee. They knew that Clapper was lying when he said that. They could not put it out, supposedly, because the rule of the committee was to keep that secret. I would say they made a very poor judgment there. I'm critical of them. Obviously I'm on their side on many aspects of this. But I think they were not justified in choosing to stay in the committee, the price of which was to keep that secret from the American public that they thought should be public in order to keep that-- to cooperate in keeping that secret.

The fact is that keeping your mouth shut-- and we are talking here about communications intelligence matters here, which were covered by 798. I had clearance for that at the time. I did not put out anything. I--

### Moderator
Claim: Daniel, I'm sorry to interrupt you, but only because of the clock, that we are wrapping up round 2. That concludes round 2 of this Intelligence Squared U.S. debate, where our motion is "Snowden was justified." And now we move on to round 3. And round 3 is where each of the debaters make brief closing statements. They will be three minutes each.

### Moderator
Claim: Two.

### Moderator
Claim: I'm sorry. Thank you. They will be two minutes each. That means everything else I've said tonight is wrong. They will be two minutes each. It is time-- and it is time for you to learn, after that, which side argued best. Oh, sorry, I skipped a page. That's why I'm on the wrong page. Okay, I'm going-- I'm going backwards.

Let's rewind. Round 3, closing statements by each debater in turn. They will be brief, two minutes each, uninterrupted. Let's go to the first of these speakers. Speaking for the motion, Ben Wizner, legal advisor to Edward Snowden and direct-- Ben, for this one, you sit.

### Conspiracy Advocate (CA)
Claim: Okay.

## Round 3

### Moderator
Claim: Ben Wizner is legal advisor to Edward Snowden and director of the ACLU Speech Privacy and Technology Project. Ladies and gentlemen, Ben Wizner.

### Conspiracy Advocate (CA)
Claim: I want to close with a few observations about the surveillance apparatus that Edward Snowden, through journalists has exposed. For much of our history, our privacy was protected as much by cost as by law. It was simply too expensive for governments to track most of us most of the time.

Now because of technology, for the first time in our history, it's technologically and feasibly possible, financially possible for governments to track all of us on a massive scale and to collect and store the majority of the world's communications. We now know that the NSA has built that capability and has used it in ways that are profoundly troubling to many of us. Polls show that 6 in 10 Americans think that the NSA's surveillance practices have gone too far. But Edward Snowden was even more concerned about what the NSA might do with these capabilities, say, in the aftermath of a traumatic terrorist attack. He believed that the weak protections that are in place right now were likely to be swept away and that our country's system would be replaced by one that looked very, very different. Now, whether and with what controls we should entrust our government with those kinds of enormous powers is a hugely consequential decision in a democracy.

We should have debated this issue before the NSA deployed a global dragnet surveillance apparatus. We didn't but it's not too late to debate it now and to impose strong democratic controls. Now, I began this debate by quoting President Obama, and I'm going to end in the same way. Just a few weeks ago he gave a speech in January about NSA surveillance and the reforms that he would be implementing and proposing. And President Obama repeated his words from June. He said, "One thing I am certain of, this debate will make us stronger." The president of the United States believes that the debate Edward Snowden launched, a debate that no one can seriously argue would have taken place without him, has made our nation stronger.

### Moderator
Claim: Thank you, Ben Wizner.

### Conspiracy Advocate (CA)
Claim: I can't think of any stronger justification than that.

### Moderator
Claim: Thank you, I'm sorry your time is up. Thank you, Ben Wizner. And our motion is "Snowden was justified." And here to summarize his position against this motion, James Woolsey. He is chairman of the Foundation for Defense of Democracies and former director of the CIA. Ladies and gentlemen, James Woolsey.

### Scientific Advocate (SA)
Claim: Thank you. I want to take a couple of minutes to describe one incident in my time as director of Central Intelligence, and it's how I think things like this ought to be done. A newspaper reporter was working on a story, and from the questions that he was asking and whom he was asking them of at the CIA it was quite clear that he was onto an extremely sensitive operation that we were conducting, a legal one, I would say, and one that was of potentially great benefit to the United States but extremely dangerous. We did not want him to pursue that line of investigation. He was persistent. I indirectly approached his boss, the editor of the paper. I got nowhere. And so I asked if I could go see the editor of the paper, one-on-one.

And the two of us talked. And I said, "I'm going to do something that no regulation authorizes. Would you promise me you'll never say anything about what I'm going to say to you here to anybody ever?" He said, "Yes, I'll promise." I said, "Okay, here's the problem," and I explained how we were almost certainly going to lose one of our officers and one of his sources killed if we continued to see the kind of material coming out that his reporter was working on. We talked. We got together again the next day and talked. And we figured out that if he would just eliminate any reference in the reporter's story to time and date and leave the story the way it could be without mentioning either date or time, that we could probably have a reasonably secure situation.

He thought about it for a bit. He was not used to having suggestions in the editing of his newspaper come from the director of the CIA. But he--

### Moderator
Claim: Jim Woolsey, I can give you 10 more seconds.

### Scientific Advocate (SA)
Claim: --he thought for a second, we shook hands on it, we did what we said we were going to do, and the story went forward without the time and date, and the operation succeeded.

### Moderator
Claim: Thank you, James Woolsey. I'm sorry that your time is up. Our motion is "Snowden was justified." And here to argue in support of this motion in his closing statement, Daniel Ellsberg, the Pentagon's Paper whistleblower and former U.S. military analyst. Ladies and gentlemen, Daniel Ellsberg.

### Conspiracy Advocate (CA)
Claim: Thank you, I-- I agree with Ambassador Woolsey that, that was, as director of Central Intelligence, an appropriate way to behave, convincing, and that the news editor was right, convinced by your argument, to change it.

The Guardian and the Washington Post have both said that they have modified at the request of the NSA virtually every story that they have written on the basis of this. They did not accept all the objections, but that in every case they have done some. I think that's appropriate. On one question that's come up again and again here as to what might happen with this American NSA government, Congressional collection of potentially everything-- everything including content. Let's call it potential at this moment. In fact, I would ask Mr. McCarthy what he believes the collection storage agency for NSA data being built in Bluffdale Utah right now is for, if it is not for audio and video content. As Tice has said, it is in use right now-- and part of it. And all the digital data in the world-- that's e-mail, chat logs, credit logs, everything-- can be stored in a small room.

This huge facility is being collected, he believes, for content. And I wonder if you believe otherwise. When it comes to 9/11, if anyone here in the audience-- or at this table-- believes that Edward Snowden-- or any of us-- wants to increase the risk of another 9/11 or is indifferent to that, I think they are being very foolish. When it comes to having gone to Congress, I think he learned from the example-- specifically of the NSA four people that I've talked about, plus Tice-- that that would be a foolish thing to do. I must say that if you had asked me a year ago, when I believed these people as to what was being collected, whether there was any chance of reining this in and preserving our democracy, the separation of powers and everything-- with what was being collected, I would have been very pessimistic--

--Edward Snowden has made--

### Moderator
Claim: I'll give you other-- the same 10 seconds I gave your opponents. 10 seconds please.

### Conspiracy Advocate (CA)
Claim: Edward Snowden has given me hope. And the reaction to what he's done and the reaction of Congress and the public has given me hope. And I would say, when it comes--

### Moderator
Claim: Thank you. Daniel Ellsberg.

### Conspiracy Advocate (CA)
Claim: take a very solemn oath to defend our borders--

### Moderator
Claim: Thank you, sir. You're out of time. But thank you. Our motion is Snowden was justified. And here to summarize his position, in two minutes, Andrew McCarthy. Andrew McCarthy-- he's contributing editor to the National Review and former chief assistant U.S. attorney. Ladies and gentlemen, Andrew McCarthy.

### Scientific Advocate (SA)
Claim: Well, finally, I get to agree with Daniel Ellsberg. I think it's absolutely clear and absolutely sure that no one at that table wants another 9/11 to happen. And you know what? No one at the FBI wanted 9/11 to happen, either. I know, because I worked with those guys for years on these cases, knowing the enemy that we were up against. And yet, that didn't stop us from putting in regulations to the point that two weeks before 9/11 happened, we had two of the hijackers known to the FBI to be here.

And the intelligence part of the FBI didn't allow the criminal investigative part of the FBI to try to track them down, because of the internal regulations that we had put in, because we thought that we could impose more law enforcement rules on a national security problem. And the result was, two weeks later, the 9/11 attacks. Now, we are in an eternal tension between liberty and security. We're never going to resolve it. And it's also about as human a problem as you can imagine, which means that whether it's because of misfeasance or malfeasance, or something in between, mistakes are always going to be made. And some of them will sound scandalous, because of the life and death kinds of matters that we're dealing with.

But the fact is, we've spent now-- in earnest, since 9/11, but certainly going back to the 1970s-- a great amount of our time trying to grapple with-- how do you impose the rule of law on the demands of war? Sometimes we get it right. Sometimes we don't get it right. But the point is, we're now at least at a place where civil liberties actually are elevated in a way that they never were before. And that's something to be celebrated. And breaking that is not something that could be justified.

### Moderator
Claim: Thank you, Andrew McCarthy. And that concludes our closing statements. And now it's time to learn which side you feel has argued the best. We're going to ask you right now to push, again, the keypad at your seat that registers your votes. We will get the readout almost immediately. Remember the team who changes their numbers the most-- between the first and the second vote-- will be declared our winner.

The motion is "Snowden was justified." If you agree with that motion, push #1. If you disagree with that motion, push #2. If you are or became or remain undecided, push #3. And we will lock out the results in about 10 seconds, and we'll have them in about a minute-and-a-half. But as we're waiting for that to happen, I would just like to ask everyone to show their appreciation for the level of respect and intelligence that these debaters brought to the stage here today. It's an example of the reason that Intelligence Squared exists, where our goal is to raise the level of public discourse. And we know that the gulf between the gentlemen on this stage is enormous, but it was meant to-- a great deal that they were actually able to have this discourse in this fashion.

And our debates, in fact, are made possible because of support by people like you and our listeners on radio, et cetera, our live stream, the podcasts. And we would ask you, if you would want to consider it, to please consider a donation to our organization by visiting our website and clicking on the "support"-- "support us" tab. And our website is www.iq2us.org. We would also like it if you Tweeted about this debate. The Twitter handle-- our Twitter handle is @iq2us. And the hash tag for tonight's debate is hash tag Snowden.

Our next debate is here at the Kaufman. It's on March 12th. Our motion is "Russia is a marginal power." Arguing for this motion we have Ian Bremmer. He's founder and president of the Eurasia Group. He recently Tweeted an interesting statistic, that 35 percent of Russia's household wealth is in the hands of 110 Russian people. His partner, Edward Lucas is a senior editor at the Economist. He's the author of "Deception," which is a book about Russian espionage.

And he also recently authored an eBook, "The Snowden Operation." Arguing against them Ambassador Robert Blackwell. He's a former deputy national security advisor who co-chaired the task force on Russia and U.S. national interests; and Peter Hitchens, a columnist for the mail on Sunday and former Moscow correspondent of "The Daily Express." And before that debate, in the next couple of weeks, we're going to be traveling up to Harvard Law School. On the 27th, we're going to be debating affirmative action on campus. And then we're going to Philadelphia to the national Constitution center on March 5th. And we will be debating the legality and constitutionality of targeted killing of U.S. citizens abroad. Tickets for all of our spring debates are on sale through our website, www.iq2us.org.

Okay. So it is all in. Remember, the way we do this is the team whose numbers have moved the most between the first and second vote in percentage point terms will be declared our winner. Here are the numbers.

Our motion was "Snowden was justified." Before the debate, 29 percent of you agreed with this motion, 29 percent were against, and 42 percent were undecided. So those are the first results. A big undecided. Here is the second vote now. On the team arguing for the motion, their second vote is 54 percent. That went from 29 percent to 54 percent. That's 25 percentage points. That's the number to beat. Now, the side arguing against the motion, their second vote was 35 percent. They pulled up 6 percentage points, but it's not enough. The side arguing for the motion "Snowden was justified" declared our winners. Our congratulations to them. Thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
