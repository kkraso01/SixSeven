# Debate Transcript

Topic: Spreading Democracy in the Middle East is a Bad Idea
Motion: Spreading Democracy in the Middle East is a Bad Idea

Debate ID: SpreadingDemocracy-091807


## Round 1

### Moderator
Claim: The Rosenkranz Foundation “Intelligence Squared U.S.” “Spreading democracy in the Middle East is a bad idea”

### Moderator
Claim: . I’d like to introduce at this point, uh, the person who, who really, uh…makes these, these debates possible. And that’s Robert Rosenkranz who’s chairman of the Rosenkranz Foundation, sponsor of the evening’s debate. And Bob is gonna make some opening remarks. And I’m hearing some—

### Moderator
Claim: Well, thank—thank you, Robert, very much, …with me tonight is Dana Wolfe, our executive producer, and I’d like to just extend a very warm welcome to all of you, at this, the opening debate of our second series. Intelligence Squared was formed with the goal of raising the level of public discourse in America. The concept is to frame a provocative proposition on a hot-button topic. The panel of experts attempts to convince us to vote, either for or against the proposition. The audience votes before hearing the debate, participates during a question period and then decides who has carried the day with their final vote. The response to this format has been really wonderful. Every one of our debates has sold out. Uh, we’re produced for radio by WNYC and carried on, uh, 70 National Public Radio stations around the country. And tonight’s proceedings, uh, will be aired on public television as well, on Channel 13 WNET here in—in New York. Well, American foreign policy has often been energized by a sense of moral conviction. Most of us have a strong conviction in the merits of the system that includes freedom of speech, free exercise of religion, rule of law, respect for property rights, and an elaborate balancing of power between the, uh, various branches of government. Uh…this is perhaps, uh, are the elements of what Fareed Zakaria has called liberal democracy. And they may be the elements we have in mind when we seek to encourage democracy in other nations. But our founders were as fearful of the tyranny of the mob as they were of the tyranny of the king. They constructed a Constitution that requires far more than a simple majority at a single moment in time to subvert these liberal elements. When democracy means simply the use of a ballot box to choose a leader, the merits become far more problematic. And that’s the subject of tonight’s debate. Should the US encourage democracy in countries where the best- organized and most politically powerful groups are Islamic radicals? How should we react to an elected Hamas? What do we make of polls that show that 65% of Middle Easterners do not believe that spreading democracy is a real US objective? On the other hand, if the US does not encourage democratic ideas, are we merely cynical supporters of despotic regimes and narrow elites? Do we ignore the large, uh, majority of Muslims that believe that democracy will work in their countries? Can such an approach galvanize, uh, domestic support. And if not, can we prudently, uh, take a hands-off approach to a region of the world that is so— of such enormous geopolitical significance. Well these are vexing questions indeed and present a real conundrum for US policy. But fortunately we have a distinguished panel of experts to turn to this evening. Our moderator, Robert Siegel, is the senior host of National Public Radio’s award-winning program “All Things Considered,” and is the radio host of the Intelligence Squared series. He got started in radio broadcasting when he was a college freshman, in 1964, and he’s still at it. He’s reported from Europe, the Middle East, and across the US, and for four years, directed NPR’s news and information department. Welcome back, Robert.

### Moderator
Claim: I’d like to welcome you to this, the first debate of the second series of the Intelligence Squared US debates, tonight’s motion is, “Spreading democracy in the Middle East is a bad idea.” I’m gonna give you a brief rundown of what will happen this evening, first, the proposer of the motion will start by presenting that side of the argument, and the opposition will follow, and each person will get a maximum of eight minutes and we’ll go back and forth, from one side to the other. Second, when all six speakers are finished with their opening remarks, I’ll open up the floor to brief questions from the audience. Third, when the question-and- answer is complete, each debater will make a final statement, no more than two minutes per person. Fourth, after the final closing statement is made, you will vote on tonight’s motion with the keypad that’s attached to the arm-rest of your seat. And fifth and last, I will announce the results of the audience vote, and I’ll tell you which side carried the day. Now, before hearing from our panelists, I’d like to start with a pre-debate vote. And I’d like you to pick up the keypad that’s attached to the, uh, arm-rest on your left. For audience members who are sitting on the aisle to my right, uh, your keypad is attached to the arm-rest on your right side next to your neighbor’s. And when I tell you, after my prompt, you will press “1,” to vote for the motion, “2” to vote against the motion, and “3” if you’re undecided, I’m gonna repeat the—the motion, which is that “Spreading democracy in the Middle East is a bad idea.” “1” is for, “2” is against, “3” is undecided, and you may begin voting now.

I hope you’ve been able to vote by now, I will reveal the results of the pre-debate vote later in the evening, but now though I’d like to introduce our panel. Starting with those who will speak for the motion, a senior fellow at the New America Foundation, former director for Middle East Affairs at the National Security Council, Flynt Leverett. The the founding president of the Nixon Center and publisher of its foreign-policy magazine The National Interest, Dimitri Simes. Uh, the Anwar Sadat Professor for Peace and Development at the University of Maryland, and also a non-resident senior fellow at the Saban Center of the Brookings Institution, Shibley Telhami. And now, the side against the motion, former Near Eastern Affairs Principal Deputy Assistant Secretary, and Coordinator for Broader Middle East Initiatives at the US Department of State, Liz Cheney. Vice-President for Foreign and Defense Policy Studies at the American Enterprise Institute, Danielle Pletka. And the director of the Adelson Institute for Strategic Studies at the Shalem Center in Jerusalem, Natan Sharansky. Let’s start a debate. Flynt Leverett.

### Conspiracy Advocate (CA)
Claim: Good evening. It’s a pleasure to kick off tonight’s debate. I’m gonna start by telling you a couple of things that my colleagues and I are not arguing, in our support for tonight’s resolution. First, in arguing that spreading democracy in the Middle East is a bad idea, my colleagues and I are not arguing that the people of the Middle East—whether defined as Arabs, Muslims, or in any other way—are inherently less capable of democratic development than any other ethnic, cultural or religious group. Second, we do not question the desirability of democracy, or the benefits of living under a democratic political order. I have the good fortune of being an American citizen solely through the accident of my birth. But my two colleagues tonight, came to this country from elsewhere, and embraced American citizenship by choice, precisely because they are convinced of democracy’s desirability. In arguing that spreading democracy in the Middle East is a bad idea, my colleagues and I want to look at tonight’s resolution through the prism of American national interests. Of course US interests in the Middle East are complex and multifaceted, but I’m gonna boil down our most important interests in this critical region to three things. First, the free flow of oil from the Persian Gulf, second, the security and welfare of the state of Israel, and third, keeping the Middle East from providing a platform for further mass-casualty terrorist attacks of the sort that we suffered on 9-11. I will argue for tonight’s resolution because I believe that promoting democracy in the Middle East is not just not helpful for these interests, it is downright harmful to them. Let’s look first at terrorism. President Bush and his administration’s defenders have argued since the United States began preparing to invade Iraq, that spreading democracy in the Middle East is the essential antidote to jihadist terrorism originating in the region. But there is literally not a shred of hard evidence supporting that proposition. From Osama bin Laden on down, that claim that jihadist terrorists are products of economic and political marginalization is simply false. The 9-11 hijackers were truly trust-fund terrorists, from economically and politically advantaged backgrounds. Proponents of democracy promotion in the Middle East also argue, that democratization is needed to counteract the distorting effects of madrasa educations on the mind-set of millions of young Arabs and Muslims in the region. But the fact is that Al Qaeda and other internationally active terrorist groups, don’t recruit from madrasas. Look at it in practical terms. To be an internationally active jihadist terrorist, you need, for example, English language skills, you need a certain level of technical competence. Madrasas are not the place where one acquires that kind of skill-set. That’s why Al Qaeda and other internationally active jihadist terrorist groups recruit primarily among university students and university graduates. Indeed if you look at the backgrounds of terrorists who have been recruited over the years by Al Qaeda, you find the number-one subject that they studied at university was engineering, the number-two subject was medicine. Democracy promotion is not going to win the war on terror, in fact the Bush administration has tacitly acknowledged that promoting democracy is not winning the war on terror. Since 2005, in the annual Patterns of Global Terrorism report, the administration has, as a matter of policy, withheld publishing the aggregate statistics showing the number of significant terrorist incidents around the world each year. They withhold that information, I would suggest, not because the data show that the number of incidents is getting less. It is actually getting greater-- democracy promotion will not help us win the war on terror. Now let’s turn to Israel’s place in the region. Proponents of democratization in the Middle East often advance what I call the garbage-collection model of lowering Palestinian and Arab expectations. This model assumes that Palestinians and their sympathizers in the Arab and Muslim worlds don’t really care that much about Palestinians living under occupation, that Palestinian and other Arab leaders use Israel as a convenient way to deflect popular attention from their own performance. I myself heard President Bush argue in the White House Situation Room, that a democratically-elected Palestinian government would be more focused on collecting garbage, and less, quote- unquote, “hung up” on territory and the status of Jerusalem. Well, we tested this theory in the 2006 Palestinian elections, and the result was Hamas’s victory in internationally supervised balloting in the West Bank and Gaza. The hard reality is that negotiating peace between Arab states and Israel is not popular in the Middle East. Arab-Israel peacemaking requires that Arab states—that, that the United States work with indigenous regimes in Arab states that are prepared to pursue peace with Israel, not because it is popular, but because those leaders judge it to be in their countries’ national interests. This is the approach that was pursued by Anwar Sadat in the Camp David accords. Sadat paid the ultimate price for that initiative. But it is the model that has been followed by his successor, President Mubarek, by King Hussein and his successor King Abdullah in Jordan. It is the model that is being followed today by Saudi King Abdullah in the Arab League Peace Initiative. Promoting democracy in the Middle East will not enhance the prospects for Arab-Israel peacemaking, it will in fact, harm prospects for peace. The same argument can also be extended to eliciting the absolutely essential cooperation of regional regimes, to enable the United States to play its critical role as the guarantor of physical security for Persian Gulf oil fields. The legacy of 20th century colonialism in the Middle East, oil concessions, and all the rest, mean that it is not popular for regional regimes to cooperate with hegemonic power. While there is no evidence that democracy reduces the incidence of terrorism, there is ample evidence—from places like Egypt and Saudi Arabia—that holding more open elections in these and other societies would produce governments that are more anti-American than incumbent regimes. Given this reality, how is it in America’s interest to rush these countries’ populations into voting booths? A couple of final points. Advocate of democracy promotion in the Middle East, oftentimes argue that—

—by promoting democracy, we are also promoting the spread of liberal values, the emancipation of women, um…and other things that Americans hold right and dear. And…they often suggest that, if we are not engaged in promoting this kind of agenda, we really are—to use Mr. Rosenkranz’s phrase—cynical supporters of despotic regimes. But, if you look at popular attitudes in the Arab and Muslim world, these attitudes are not just increasingly anti-American in their orientation toward international issues. They are less reformist on internal issues than many incumbent regimes. The best hope for modernization and ultimately liberalization, in the Arab and Muslim worlds today, lies in incumbent regimes who recognize that, first of all—

—economic modernization is essential to their country’s future.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —by promoting democracy, we are also promoting the spread of liberal values, the emancipation of women, um…and other things that Americans hold right and dear. And…they often suggest that, if we are not engaged in promoting this kind of agenda, we really are—to use Mr. Rosenkranz’s phrase—cynical supporters of despotic regimes. But, if you look at popular attitudes in the Arab and Muslim world, these attitudes are not just increasingly anti-American in their orientation toward international issues. They are less reformist on internal issues than many incumbent regimes. The best hope for modernization and ultimately liberalization, in the Arab and Muslim worlds today, lies in incumbent regimes who recognize that, first of all—

### Moderator
Claim: Thank you—

### Conspiracy Advocate (CA)
Claim: —economic modernization is essential to their country’s future.

### Moderator
Claim: Thank you, Flynt Leverett, speaking for the motion.

Danielle Pletka, against the motion.

### Scientific Advocate (SA)
Claim: Good evening, everybody. You saw me looking around in a little bit of a panic and that’s because I realized I left my glasses in the other room. So I’m just going to hold this a little bit further forward, if you’ll forgive me. Before anything else, let us all agree that democracy is a good, in and of itself. It doesn’t require a wit as sharp as Winston Churchill’s to know that, stacked up against dictatorship, mob rule or even benevolent tyranny, democracy – notwithstanding all of its imperfections, is the best system of government.

Let’s also accept that democracy means a great deal more than elections and that when we say democracy we’re really using a shorthand for a system that contemplates representative leadership, rule of law, economic as well as political freedoms and more. Finally, let’s stipulate that while we expect our news to arrive instantaneously, our paychecks to be deposited immediately and our diets to work miraculously, democracy is indeed a long term project. I’m pleased to see that Flynt, Shibley…Shibley, uh, Dimitri, uh, have accepted the idea that the system of government most admired in the Middle East is democratic and that they agree that people do indeed aspire to freedom in that region. And I must say I agree with the caveat that people do not aspire to freedom that is eclipsed by fear for the future and for their own security and well being. So we have a moral good that we are all agreed upon in the abstract. What we don’t agree about is the strategic imperative or the appropriate role of the United States.

We can debate about that a little bit later but the foundation of that debate should be a proper understanding of the nexus between tyranny and terrorism. How do groups like Al Qaeda operate? It should be clear by now that in parasitic fashion these groups feed off of host nations that are weak. They operate with a key, with a core group who are committed ideologues and do come from all walks of life. But the real sustenance, but that is, that is only part of the story. The real sustenance for Al Qaeda and other light groups is an environment that tolerates their methods in appreciation of their supposed ideals. For many it is not necessarily the virgins that await or the triumphs of the return of the Caliphate. Rather, it is the relief from the life in purgatory that constitutes the average lot of the average Arab. That life is about unemployment, real rates of up to thirty-five and forty per cent – and young men, who when polled consistently complain that their existence offers no hope and no opportunity.

It is about the fact that the United Nations development program estimates that nine per cent of every business deal in the Middle East goes for bribes and when students who want to vote step into the streets of Cairo they risk arrest and torture, like Karim Suleiman who was sodomized and tortured because he demonstrated in favor of the rule of law. These victims of Middle Eastern oppression are the ones who provide the oxygen that enables Al Qaeda to operate and it gives resonance to their political messages. And why? If your life and your father’s life and your son’s life is lived under the yoke between this or dictator for life that, you cannot form a new political organization and you cannot change your system of government and you cannot begin to help yourself and you look for other options.

And if the only haven in which you can talk about those options is in the mosque and the only thing the mosque is offering up is Islamic purity, a return to greatness and the uncorrupted life of the true believer, it shouldn’t be a great wonder that such ideas take hold. If you find that argument unpersuasive let’s for a moment look from our opponent’s viewpoint. They rightly suggest that in Egypt, Jordan, Syria, Lebanon, Saudi Arabia, Kuwait, Palestine – I could go on – the main opposition parties are Islamist. But why? It’s because they have a proven record of delivering on a better life? Is it because somehow they have more charisma than other opponents of the regime? Or is the fact that the Islamists have successfully used the vast religious networks and cash available to them to promote their own political cause – occupying the only political space that exists in the authoritarian Arab world.

There are only two places for breathing room in the current Middle Eastern political construct-- the dictator space and the Islamists. Oppression gives the Islamists the popularity to move their agenda and further the environment in which Al Qaeda is tolerated and worse. And they know it. In extensive writings, including by Bin Laden and Zarqawi-- and here I really disagree with what Flynt had to say – they rail against democracy because they know it represents a threat to their lifeline. Zarqawi wrote to Ayman al-Zawahiri bemoaning the future of their fight in Iraq. Democracy is coming, he wrote, and there will be no excuse thereafter. So what is the answer? The answer cannot be that because Hamas and others take advantage of the democratic process, therefore, democracy is discredited. We must confront systems that tolerate Islamists and provide ideological safe haven to Al Qaeda.

And the way to do that is by insuring that there are other opposition parties, genuine reformers, who have the power and the money to make their voices heard. Our opponents will argue that the United States has no role to play, that where we interfere we make things worse and that with our inconsistency we risk destabilizing the region. That is an unacceptable formulation. It is certainly true that the United States is not a fault free advocate for democracy. I can now agree that there are times when the reality of foreign policy demands that we do business with objectionable leaders. But there is no reason to rely on the brutality of dictators because that brutality at the end only besmirches us. Worse still, there is clear evidence that Jihadists flourish where dictators rule. In supporting the PLO, what did we do to rid Gaza and the West Bank of Hamas in supporting Mubarak?

What have we done to rid Egypt of the Muslim Brotherhood? Sixty years of rooting for the dictator’s stability, as my colleague Liz Cheney will make clear, didn’t protect us on 9/11. Our role must be to facilitate and educate, to hold open the door for democrats like Ayman Nour in Egypt. It should be to use our influence to see laws rescinded to stop the formation of new parties and constrain the grass roots activities of political and economic reformers. It should be to insure that mosques are not the only place where political parties and reformers can meet and it should be to insure that economic reforms go hand in hand with political change. Ultimately, when young men can expect unemployment in a thriving market economy, there will still be a few who are attracted to Al Qaeda – those medical students and those engineers. But the vast mass will not. They will be less attracted to the answers they hear from radical preachers.

Or do our opponents here this evening really believe that reform is not possible, that reformers do not exist? No one among us has suggested the only way to prize open the closed doors of the Middle Eastern palaces is with Middle Eastern…is with Middle East – excuse me – military force. To the contrary – if that is our system it will fail. The same holds true for Al Qaeda. We cannot kill every Pakistani that tolerates an Al Qaeda operative in his midst. We cannot bomb houses of worship that preach Islamic politics and jihad. We can throw our considerable weight behind the people who do believe that rule of democracy – not jihad and bin Laden – offer real hope for the future. We may never do it perfectly but that is certainly not a reason not to do it at all. Thank you very much.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: Or do our opponents here this evening really believe that reform is not possible, that reformers do not exist? No one among us has suggested the only way to prize open the closed doors of the Middle Eastern palaces is with Middle Eastern…is with Middle East – excuse me – military force. To the contrary – if that is our system it will fail. The same holds true for Al Qaeda. We cannot kill every Pakistani that tolerates an Al Qaeda operative in his midst. We cannot bomb houses of worship that preach Islamic politics and jihad. We can throw our considerable weight behind the people who do believe that rule of democracy – not jihad and bin Laden – offer real hope for the future. We may never do it perfectly but that is certainly not a reason not to do it at all. Thank you very much.

### Moderator
Claim: Thank you. Thank you, Danielle Pletka, speaking against the motion. Shibley Telhami, for the motion.

### Conspiracy Advocate (CA)
Claim: Good evening. I think, uh, America should stand up for democracy and freedom. I think it should be an inspiring model, as it has been historically. What we shouldn't be doing is trying to pretend like we’re capable of making spreading democracy a top priority in a world in which we face many threats – and certainly not to do it by force. I think, if you look at what has happened over the past five years as a consequence of this policy of spreading democracy by force, is that we have a public and Arab world that doesn’t believe us: we have a gov…governments that don’t believe us: we have less democracy, more anarchy, more instability, more terrorism – and even worse, the growing American dependence on the very institutions and the very…very governments that need to be reformed.

In essence, we have given democracy a bad name. It is hard for people in the region, including people who badly and desperately are looking for democracy and freedom, to think of democracy and freedom the American way without thinking about the horrors of Iraq. We have paid a price by diverting attention from the important issue of human rights, which we often confuse with spreading democratic systems. That issue which we should trump and advocate has paid a price as a consequence of this policy. Let me begin with some of the facts. The vast majority of people in the Arab world, all polls show, do not believe that we mean to spread democracy in the Middle East. Most of them believe that we’re in Iraq and in the region for oil, Israel and weakening the Muslim world. Even the governments who have faced pressures from us – and yes, they have faced pressures and, yes, they have been told to liberalize – all have believed that this is essentially tactical, that this is done in order to coerce them to cooperate on strategic issue or as a political domestic issue to divert attention from the absence of wea…uh, the weapons of mass destruction in Iraq.

And as a consequence, they dealt with it tactically. They said, The President needs a little political – give him a little election so he can say, I’ve got more democracy in Libya, I’ve got more democracy in, in Saudi Arabia. And then once he claims that he has a success-- he’s not gonna claim it as a failure the next day - - and then you can go on with business. And look at the reality that we have at the moment. The vast majority of people in the Middle East – when you poll them – those people whom we’re supposed to be giving democracy to-- uh, the vast majority believe that the Middle East is less democratic today than it was before the Iraq War – less dramatic today than it was before Iraq War.

And it was horribly undemocratic before the Iraq War, no doubt. And how is that the case? Is this simply made up by the media? Is this what people tell them? Is this what leaders tell them? I’m afraid there’s a little bit of reality to that and we now see it in many of the places that we celebrated early on as examples of democracy. Remember, the three big examples – Iraq, Lebanon and the Palestinian areas-- and you look at where we are in these areas. But separate from that there was some other dynamic that goes on that we are not coming to grips with – something that our policy does because in, in reality we are not making democracy our priority. And we, in essence, deceive ourselves when we think we are. Let me give you an example. Ninety per cent of the Arab public passionately opposed the Iraq War, didn’t want to see it take place. They told the governments, Don’t do it. It’s gonna bring about ruins.

Their government’s instinct was, Don’t support the Iraq War. But when we went to the Iraq War-- these governments are certainly dependent on the U.S.-- in the end they came along and they provided logistical support and bases and everything else. And they were telling us that they’re worried about their public opinion. Well, we had, it was more important for us that they support our policies on terrorism, on Iraq, on the Arab/Israeli issue, despite the anger of the people, than the liberalization.

What happens in the process? How is the Jordanian government or the Egyptian government or the Saudi government going to face up with that pressure that comes from the public at a time of war? What they do is they unleash security services. Yes, they have elections-- and by the way, some of those elections we’ve had as little as twenty per cent and possibly only ten per cent of the public participating. It tells you how people, how seriously people took it.

But in the end these governments became more repressive in order to quell, to, to, to put down any possible opposition, given the anger of the public. And this is essentially what we do, even in the war on terrorism. Who do we think our most important allies in these, uh, countries-- It’s not the Democrats. Yes, the Democrats we theoretically want to empower them. But who do we give most aid to? With whom do we institutionally cooperate – the security services who are embedded with our security services, the military, which are in bed with our military? These are the institutions of the repressions that need to be reformed. But those are the ones we have to deal with. And I’m not saying we don’t need to deal with them. We have to deal with them. But the reality of it is that the consequence is perpetuating repression, increasing it even as we pretend to be promoting it. Let me, just a couple of, make a couple of points to end. One is that I believe that all people in the world and all Arabs and all Muslims want to see freedom and democracy.

No one likes dictatorship. And yes, you, I don’t think they want a different kind of democracy and freedom. When I ask them, uh, Name two countries where there’s most freedom and democracy for their people they name primarily Western countries – Western Europeans and the U.S. They know what democracy and freedom are. People aspire to it. But one thing they don’t want is they don’t want anarchy. They want anarchy even less than they democracy. And they want to see no occupation. They want freedom but they want to avoid anarchy and they want to avoid occupation. And when they see what is going on in Iraq, if a leader in Egypt looks at their citizen and say, Do you want Cairo or do you want Baghdad? I want Cairo over Baghdad any day of the week, with all the pain that people face every day. And that is the reality of how the choices are seen in the region. Let me end by saying I am not in harmony with the view that we –

…shouldn’t advocate democracy. I think we need to advocate democracy. But I believe that there is a better way. I think we should focus on those issues over which there is international consensus, like human rights. We should hold people responsible to treaties that they have signed and in order for us to be powerful in that regard we have to uphold our end of the bargain. We have to be an inspiring model, not just lecture to people while we have the Abu Ghraib prison. And we need to work in economic reform because that is the structure that enables true democracy to emerge from within. We’re treating Arab as a passive people that, that need to be told from the outside. No, they need empowerment from the outside – not manipulation. Thank you very much.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …shouldn’t advocate democracy. I think we need to advocate democracy. But I believe that there is a better way. I think we should focus on those issues over which there is international consensus, like human rights. We should hold people responsible to treaties that they have signed and in order for us to be powerful in that regard we have to uphold our end of the bargain. We have to be an inspiring model, not just lecture to people while we have the Abu Ghraib prison. And we need to work in economic reform because that is the structure that enables true democracy to emerge from within. We’re treating Arab as a passive people that, that need to be told from the outside. No, they need empowerment from the outside – not manipulation. Thank you very much.

### Moderator
Claim: Thank you, Shibley Telhami, uh, speaking for the motion. Liz Cheney, against the motion.

### Scientific Advocate (SA)
Claim: Uh, there are clearly a number of issues that our opponents would like to debate tonight. And I, too, would welcome those debates. I would readily accept a debate on the topic, "Was it Right for America to Go to War in Iraq?" I would readily accept a debate on the topic, "Is America Effectively Promoting Democracy in the Middle East?" Or perhaps one on, "How Accurate Are Opinion Polls in the Middle East?" And I hope Intelligence Squared invites me back if they’re gonna have those debates. But those are not the issues before us tonight. Although I can understand why our opponents would rather discuss those issues than have to stand before you and argue against democracy.

But make no mistake, their protestations aside, that is what they’re doing. The truth is that spreading democracy in the Middle East is not a bad idea nor is it a failed idea. Nor is it an idea that would have been good except that George W. Bush adopted it. It is, by any objective measure, a good idea, the right idea and a necessary policy choice for America today. Here are some facts: America is at war with an enemy driven by radical, ideological hatred to destroy us and all that we stand for. These terrorists were not created by U.S. policy. They are religious zealots who will stop at nothing in achieving their objective of establishing a global Caliphate in which individual lives have no value, women are chattel and the only legitimate faith is a perverted version of Islam.

To accomplish their objectives, the terrorists or the trust fund terrorists – as my colleague Flynt has called them-- need recruits. Because the truth about the trust fund terrorists is they don’t do the dirty work themselves. They’ve got to find young men and women willing to strap bombs onto their bodies, detonate them, killing themselves and taking as many innocents with them as possible. For decades the terrorists have known that they can prey most effectively in societies where young people live in despair, where they have no hope for a better future here on earth – in societies that are characterized by brittle, autocratic regimes and closed status economic systems. For too many years America perpetuated this status quo. We supported those authoritarian regimes, we ignored the aspirations of their people. This policy, essentially the one that our opponents would have us return to tonight, brought only a false sense of security and stability.

It is true that young people in the Arab world, as elsewhere, yearn for the freedom to be heard. They yearn to stand for something larger than self. They yearn to control their own destinies and choose their own leaders – and only democracy can fulfill those aspirations. Our opponents argue there is no evidence that democracy combats terror. To make this argument, you have to ignore the words of the terrorists themselves. If you read the captured letters of former Al Qaeda and Iraq Chief, Abu Musab al-Zarqawi-- who my colleague Dani Pletka quoted – you will see, in 2005 he wrote, quote: We have declared a bitter war against the principle of democracy and all those who seek to embrace it. The terrorists have done this because they know the fundamental truth – that people never choose to ru…be ruled by Al Qaeda or the Taliban. Those are the ideologies that must be imposed by force. Our opponents tonight also argue that supporting democracy is messy and that elections do not always turn out the way we would like them to.

That is certainly true here in America, as well. But that is essentially an argument about how to effectively promote democracy, not one about whether promoting democracy is a bad idea. So let’s dispense with some straw men and agree on several things. Promoting democracy is not only about supporting elections. Elections are necessary but not sufficient and often they should come last in the reform process, not first. America’s democracy policy should and does include supporting freedom of speech, freedom of the press, freedom of religion, women’s rights and a thriving civil society. Asserting, as our opponents do, that somehow promoting democracy in the Middle East is an imperial imposition of American values requires ignoring two critical facts. The first is you have to ignore that the desire for freedom is a universal human desire.

At its base this is an assertion, regardless of what they say, that only some people – maybe those of us fortunate enough to be born in the West – really desire human freedom. At least fifty per cent of our panel tonight is living evidence that that claim is not defensible. Our opponents’ position also requires ignoring the massive change underway in the Middle East today. Five or six years ago state dominated media, state press dominated the media in the region. Today there’s been an explosion of independent newspapers, television programming and access to the internet. Six years ago no woman had ever run for or voted in an election in the Gulf. Today they’ve done both. Six years ago a demo…and discussion about democracy in the Arab world would have brought ridicule and potentially jail time.

Today leaders, reformers, journalists and millions of others are engaged in a constant ongoing debate and discussion about democracy. And America’s actions in this regard matter. As an Egyptian reformer said recently, When the outside world softens its call for reform regimes are emboldened to ignore their citizens’ rights. Knowing that we are on the side of those fighting for freedom empowers them and it strengthens them. Abandoning them or this cause would be unjust and unwise. In that regard, our opponents tonight need to answer this question: If you are truly concerned about America’s credibility and image in the Middle East, why are you willing to accept the grave damage that will be done to that credibility if America adopts your approach, if we return to the policy of support for autocrats and turn our backs on the aspirations of the, uh, Arab people?

Finally, consider this: As we engage in this debate here tonight in Manhattan, a Saudi woman can sit in her home sixty-five miles, fifty-five hundred miles away. She can blog about her life, her fears, her oppression, her hopes and her aspirations. She can post that on the internet for all the world to read. She has a voice, probably for the first time in her life. If we were to tune in right now to any of the scores of Arabic satellite channels we would find young men and women from across the region debating the issues of the day, arguing and questioning authority. Adopting the path proposed by our opponents would be to betray those young men and women. Would our opponents have us tell young Arab men and women that America doesn’t believe they’re ready for democracy? Would they have us say to women across the Gulf that although they have been able, over the last few years, to vote and run –

..for office, that was just temporary and America has now decided we won’t support their efforts any longer. Would they have us assert that we, in our ultimate wisdom, have decided that instead of supporting freedom fighters, we will throw America’s great and unparalleled strength behind autocrats and against the people? That surely is a world in which the terrorists have won. That is a world in which neither the terrorists nor the Americans support democracy and that is not a world in which I imagine many of us would like to live. Thank you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: ..for office, that was just temporary and America has now decided we won’t support their efforts any longer. Would they have us assert that we, in our ultimate wisdom, have decided that instead of supporting freedom fighters, we will throw America’s great and unparalleled strength behind autocrats and against the people? That surely is a world in which the terrorists have won. That is a world in which neither the terrorists nor the Americans support democracy and that is not a world in which I imagine many of us would like to live. Thank you.

### Moderator
Claim: Thank you, Liz Cheney, uh, speaking against the motion. Dimitri Simes, for the motion.

### Conspiracy Advocate (CA)
Claim: This was an interesting presentation. I never knew that I believed in all those things. But it’s always, you know, a learning experience, uh, particularly when you debate Bush Administration officials or many former administration officials. Your kind of plan, what you mean, what you sought and what you said. I don’t think that this was our position and I hope that you will make your own judgment, whether the previous presentation really reflected our side's. How can one be against democracy promotion? A very prominent American leader once said, It is our destiny to promote democracy worldwide because we cannot yield moral ground to repressive regimes because it would be unjust and wrong and because, also, it could be never secure as long as there are repressive regimes. Because they would not leave us alone and would continue to plot against us. Sorry, France, it was not a prominent American. It was Leon Trotsky. And of course, he spoke not about promoting democracy but promoting proletarian revolutions. But he believed in proletarian revolutions very strongly.

He was a sincere man. So were many Crusaders when they invaded the Middle East and you remember what has happened and what did it cost – to the Arabs, to the Christians, to the regions. Uh, we are not talking about our private beliefs. We are entitled to our beliefs. But democracy is not a religion. Democracy promotion should be policy. Therefore I will not hesitate to say that there are some things that are more important than democracy. If, uh, and then in 1930s, we knew what Hitler would do to the Jews and to the others, would we allow him to come to power democratically? Wouldn’t we consider stopping him a wise and honorable policy? And I completely agree with the Israelis now when they would not want to recognize democratically elected Hamas. And I do not care how many votes Hezbollah gets, but as long as they do what they do we should judge them not by the process to which they came to power, but what they’re doing to themselves, to others and what they present to the United States.

I would yield to no one in my commitment to freedom. Freedom - - to select democracy for us and to freedom to allow others to make their own choices. I am touched by anecdotes about Arab women. I don’t need anecdotes when I hear about two and a half million Iraqi refugees – two and a half million, for whom in the name of democracy promotion we are doing almost exactly nothing. And more than a hundred thousand civilians who have died so far in Iraq and more dying. And our democracy promo…promoters don’t seem to be extremely concerned. There was a very prominent American who said, in 1964, that extremism in defense of freedom is no vice. His name was Barry Goldwater. I disagree. Extremism in the name of whatever is never a virtue. And extremism is never a sound policy.

First about democracy as something that stop…stops wars – remember, the Peloponnesian War among the Greeks. More than twenty-five hundred centuries ago and there were democracies on both sides. Now, I just came from Washington. Who, uh, do you think burned Washington in 1812? My impression is that this was the British. And of course, they had a monarchy but they were very democratic by standards of the time. Now, more Americans have died in the Civil War than in any other war in American history. Would you disagree that the Confederacy was democratic – at least by the standard of the time? And what about the British in South Africa, fighting each other at the end of the 19th Century. Democracies do go to war against each other. Now, about democracy and terrorism – well, you know, I think that one of the most democratic countries I know is called Britain.

And you see British born citizens engaging in the most vicious terror against their country. Well, you would say, but this may be terror imported. Well, about, what about the Basques in Spain? What about IRA and their long war against Britain? What about the Oklahoma City bomber? Come on, we know very well that there are many causes of terror. And to say that the absence of democracy in Saudi Arabia and Egypt really is responsible for September 11th-- you know, a claim like that has no scientific evidence whatsoever, is not based on interviews with the terrorists themselves. No senior CIA official who knows how these suspects were interviewed and what they said would ever claim that these people have attacked the United States because their Arab regimes were not democratic. People love freedom, I completely agree with that. But, you know, when people love freedom they may not only that they would be able to vote or even to enjoy free press or even, uh, freedom of religion or even that they would be able to travel.

You know what they also mean? They mean that they want to be able to make their own choices, including to make their own mistakes. And that’s what the American Revolution was all about. And when the only remaining super power is coming to other countries and uses considerable American leverage and sometimes American military power telling them, Follow our indispensable guidance or else pay the price, then some people are unhappy. And people who are unhappy, are not just despots—

—and they’re not just some brainwashed people. India is the greatest democracy, in terms of numbers of people in India, and by now they have a long experience with democracy. And yet India is very strongly against democracy promotion. We should believe in democracy for ourselves, we should promote freedom of choice for others, but we should not presume that we know all the answers, and as the only remaining superpower, we should be the judge and the jury, however noble our intentions may be.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —and they’re not just some brainwashed people. India is the greatest democracy, in terms of numbers of people in India, and by now they have a long experience with democracy. And yet India is very strongly against democracy promotion. We should believe in democracy for ourselves, we should promote freedom of choice for others, but we should not presume that we know all the answers, and as the only remaining superpower, we should be the judge and the jury, however noble our intentions may be.

### Moderator
Claim: Thank you, Dimitri Simes, speaking for the motion. Natan Sharansky, against the motion.

### Scientific Advocate (SA)
Claim: You know, in life…a disadvantage can sometimes be advantage Take being short. I can assure that in Soviet prison, being short was a huge advantage. And not only because punishment cells were very small. But because…the food is rationed. And clothes come in one size. So for tall people, they’re always hungry, and clothes simply doesn’t cover their body, and protect them from cold. But for people of my size, it was easier with hunger, and I always had an extra cloth, to cover myself, from the cold. And the winters are very cold in gulag. There we were praying for global warming. So…one can think that…living under totalitarian regime was a big disadvantage. Of course I’m very happy that my daughters were born in freedom. But, sometimes I really think, that having experience of living in a fear society, I have a big advantage. Because, I will never take freedom for granted. I will never think that the grass on the other side could be greener. I will never say what was said by one human rights, so-called human rights officer of the United Nations two years ago in Baghdad, when he was explaining why under Saddam Hussein it was better. He said, you know, under Saddam, if only you object, give away your freedom of thought and expression, you’re physically more or less okay. Now only the one who never had to give away his freedom of thought and expression can say such a thing. People who live in fear societies, have different perspective, of the advantages of democracy. And when they say democracy, exactly as all the colleagues who are against said, democracy’s not about elections. Stalin had elections. He did pretty well there. And Hitler not only had elections but as just now was said, he has opposition. He was elected democratically, but nobody would think that Third Reich is…a democracy. America’s strong democracy because, it has all these institutions of civil society, free press, independent courts, and so forth. Because…when I—when I’m speaking about democracy …the society which as I call, can pass the town square test--you can come to the center of your city. You can speak your mind, you can express your opinions, and you won’t be punished, you will not be harassed. That’s free society. So, is promoting free institutions of free society, like, free press, or, or independent opposition, independent courts, is promotion of these institutions result us a better year? Of course not. What, that’s, exactly what America was doing, when you defeated Germany, and Japan in the Second World War. You spent enormous efforts, economical, intellectual, financial, to support, to promote democracy, and today Japan and Germany is not a threat. Take Russia, when Russia was part of the totalitarian Soviet system, it was your worst enemy. When Soviet Union fell apart and Russia went towards freedom, it almost became your ally. Today, when freedom is then in retreat, in a big retreat, it becomes again a threat to America. And that is true about every part of the world. Take Venezuela, you take North Korea, you take Iran…what—whenever there is a threat to America is means that democracy is there, in retreat. If Middle East today is a dangerous place, it’s not because of democracy. It’s because in the last 60 years, when democracy was spread to Germany, and to Japan, and to Spain, and to Latin America, and to South Asia, and to Eastern Europe, and even to Russia, it was never spread to Middle East. And one can say, but you cannot impose democracy freedom from outside, of course you can’t impose freedom from outside. But, we find out that you can impose dictatorship from outside, simply by supporting dictators. And that’s unfortunately exactly what so many leaders of the free world were doing. They were supporting and they continued to support, royal Saudis. Ignoring the fact what’s happening there with the rights of even They supported and continue to support…uh, au—au— authoritarian regime of Egypt. Ignoring the fact that practically every week, there is another human rights activist sent to prison. They were supporting Saddam Hussein, until the last day. Day before Saddam Hussein sent troops to Kuwait, leaders of Europe and United States of America believed that he was a good reliable partner, who can get stability. Decades before American President started speaking about promoting the freedom of the Middle East, Al Qaeda was born, that was already the place plagued with wars, with killing, and with repression. Was Middle East safer, before America started talking about promoting democracy. What is— was it safer in the ‘70s, when Jordan had to fight PLO and Syria, when Lebanon was almost destroyed with civil war, when Iranian re—regime in— emerged, and the American diplomats turned into refugees. Was Middle East more safe in the ‘80s, when the American airplane was blown up by, uh, Libya. When in Beirut and hundreds of American soldiers were killed. When one million citizens became victims, killed and wounded, in the war between Iran and Iraq. Has the Middle East been more safe in ‘90s, when Kuwait was sw—swallowed up, by Iraq. When missiles were fired—falling on Tel Aviv and Riyadh. When twin towers survived…the first attack of the terrorists. And when Al Qaeda published its famous fatwa, about killing Americans. Promoting democracy in the Middle East is an excellent idea, by the way I, I idea that it has to be connected with human rights. That the policy of the free world has—in the Middle East has to be connected with the question of human rights, that’s exactly what I was promoting for all my years. Unfortunately, all the administrations of the United States of America in the ‘70s and the ‘80s and the ‘90s, never did it. Promoting democracy in the Middle East is an excellent idea, that’s very—the thing is, how. It’s very difficult to overcome the resistance of all those who don’t want democracy there.

And that’s a very important question. But it’s not the question which we are discussing today, till this day the question which is discussed is, whether it is good idea or not. The march of freedom, ladies and gentlemen, is very difficult. It will not succeed in one day. But there is no alternative. Great struggles between those who on one side, those millions, hundreds of millions in the Middle East, who want freedom, and those who want to deprive them of freedom. The problem is that sometimes we forget on whose side we are. The globe was blessed, and I personally was blessed, with America for—which always knew on what side it is. America which knew that, this divide between free world and fear societies, is much more important than divide between Republicans and Democrats, between this and that party. America which knew that ideal freedom…is bigger than any president, any party, any country.

Thank you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: And that’s a very important question. But it’s not the question which we are discussing today, till this day the question which is discussed is, whether it is good idea or not. The march of freedom, ladies and gentlemen, is very difficult. It will not succeed in one day. But there is no alternative. Great struggles between those who on one side, those millions, hundreds of millions in the Middle East, who want freedom, and those who want to deprive them of freedom. The problem is that sometimes we forget on whose side we are. The globe was blessed, and I personally was blessed, with America for—which always knew on what side it is. America which knew that, this divide between free world and fear societies, is much more important than divide between Republicans and Democrats, between this and that party. America which knew that ideal freedom…is bigger than any president, any party, any country.

### Moderator
Claim: Thank you, Natan Sharansky—

### Scientific Advocate (SA)
Claim: Thank you.

## Round 2

### Moderator
Claim: —speaking against the motion. Uh…we have heard the opening presentations by all six of our panelists, we now enter our question-and-answer session, folks will come to, uh, get a microphone near members of the audience who want to pose a question, I want to start by, uh, picking up on something that Natan Sharansky has said and have…uh, we’ll have Flynt Leverett or another member of this panel answer it. Uh, can one be an advocate for human rights or should one be an advocate for human rights, without at least implicitly criticizing the entire dictatorial structure of a government that might violate human rights, or ultimately, if we’re going to support anybody whose human rights are violated…should we not follow through and say, why not become more democratic while you’re at it.

### Conspiracy Advocate (CA)
Claim: May—may—if I may, um, I’d like to answer this one. Um, you know, I—I think there are two big differences here. Uh, one difference is, that, when we are saying we’re spreading democracy or we’re shaping institutions a long ways, that we imagine ourselves but there is no consensus or international norms, that’s one thing. But when we are talking about human rights there, uh, there are human rights treaties, there are international laws, there are norms against torture. And many of these governments in the Middle East are signatories to these treaties. And therefore, it is a very different order of things, to hold them accountable to those treaties. And it is—and you would get a lot more international support rather than be exposed and be alone in pushing a policy that other people are not doing. And these governments can and must respond, particularly when the international pressure comes. So that’s one difference that is extremely important because we can mobilize supporter, we can strengthen institutions, we can do it, but the other difference is, is that we— There are two…uh, the difficulty in imposing democracy, is a, another order beyond—

### Moderator
Claim: Mm-hmm.

### Conspiracy Advocate (CA)
Claim: —uh, trying to uphold people on, on human rights because I want to say this on, on democracy because I think, we don’t have modesty here, it’s like saying, trust us, we can spread democracy. And we don’t have a good record. Even scholars don’t know how to do it. And yet we want to make it a priority, when in fact, we haven’t been able to do even lesser things very well.

### Moderator
Claim: Shibley Telhami answered that question. Uh, are you satisfied with that, Natan Sharansky, that you can separate human rights out from a—a broader—

### Scientific Advocate (SA)
Claim: No, I—I think—

### Moderator
Claim: —political critique—

### Scientific Advocate (SA)
Claim: I think that’s exactly the ways of more, more, more than relatives That there is constant attempt to separate the question of human rights from the nature of societies. That, like some…organization of human rights say we are not make different mark— giving marks to regimes, we don’t say what regime is good and bad. And as a result, we can have one page about violations of human rights in Syria, and 100 pages of violations of human rights, about in America, and everyone says, well you see America is much worse. And I always say you know, have the same information, it’s very important to me that American will all be criticized for human rights. But rights authoritarian regimes, or totalitarian regimes and democratic regimes. And to be clear that, 100 pages about democratic regime is not the same as one line about authoritarian regime. Unfortunately, the of human rights was absolutely separated from the nature of the regimes themselves.

### Moderator
Claim: Well, at—at this moment, uh, perhaps we’ll have some follow-up on this point, but I—I want to, uh, report to you how you voted before you heard from our debaters. On the motion, uh, that spreading democracy in the Middle East is a bad idea, 46%, uh, of you in the audience using your keypads voted for the motion. 36% voted against the motion, and 18% were undecided. So those were the pre-debate results, and we’ll vote again, a little bit later. Uh… Just on this—this point of human rights, uh, Flynt Leverett, did you, did you have something to add to—to your side?

### Conspiracy Advocate (CA)
Claim: Yeah—yeah, I just wanted to say, yes, it is possible to make that separation and it actually works in the real world. Um, one of the few things I did in my, um, service at the Bush White House of which I am unreservedly proud, is that I drafted the letter that President Bush sent to President Mubarek in 2002 regarding the detention of Saad Eddin Ibrahim, the, the scholar—

### Moderator
Claim: Democracy advocate in—

### Conspiracy Advocate (CA)
Claim: —yes—

### Moderator
Claim: —in Egypt.

### Conspiracy Advocate (CA)
Claim: Um, and basically the tack we took in that letter was, um, we were at that point discussing the possibility of, um, uh, additional aid to Israe—to Egypt beyond what Egypt was already receiving. And we simply said in the letter, you know, you’re doing this to Saad has made it impossible for us to move ahead with any kind of initiative like this. We also said in the letter, you know, existing aid and our strategic cooperation, you know, we hope will go on. Um, but we sent the—

### Conspiracy Advocate (CA)
Claim: —but we sent the signal that you can’t get—

### Scientific Advocate (SA)
Claim: That’s promoting democracy—

### Conspiracy Advocate (CA)
Claim: —you can’t get more—

### Scientific Advocate (SA)
Claim: Exactly—exactly—

### Conspiracy Advocate (CA)
Claim: And—

### Scientific Advocate (SA)
Claim: That’s promoting democracy—

### Conspiracy Advocate (CA)
Claim: —we can’t get more—

### Scientific Advocate (SA)
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: And—

### Scientific Advocate (SA)
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: …in the end, Saad was released in pretty short order after that letter was sent because—

### Moderator
Claim: But the offense that you were addressing, Flynt, was, he’s in jail, you weren’t saying, we want to adopt his reform agenda for democracy—

### Conspiracy Advocate (CA)
Claim: No, we were saying we want him out of jail.

### Moderator
Claim: Hmm. It’s a start—

### Scientific Advocate (SA)
Claim: Can I respond on that, because I think that’s a—

### Moderator
Claim: Liz Cheney.

### Scientific Advocate (SA)
Claim: —that’s a—what, what Flynt has described is accurate, uh, and it is a key—a terrific example of how the US promotes democracy, it is one of the tools to use. Um, Saad Eddin was in jail because he’d been a threat to the regime, because he’d supposedly written an article about the succession in Egypt, he’d written things the regime did not appreciate. He was imprisoned, he was a prisoner of conscience. And at some point, from, from the perspective of US policy, it became unacceptable to us, and we, we said to the Mubarek regime we will no longer continue this level of aid, we will consider future levels of aid at risk—

### Conspiracy Advocate (CA)
Claim: Though we will continue at a present level—

### Scientific Advocate (SA)
Claim: Uh, if you—if you— Right, we will consider future levels of aid at risk if you go down this path, and potentially, in following years, additional amounts would be at risk. At the same it—

### Scientific Advocate (SA)
Claim: Flynt, I was also there but let me finish, I gave you a chance. At the same time, we said to the government of Egypt, we’re gonna take part of the assistance that we are already giving you, and we are gonna set it aside from democracy promotion activities. And we are going to fund activities that you may or may not agree with us on, we are not gonna ask your approval every time we provide assistance to a women’s rights organization, or to a political organization. Uh, we are gonna be promoting democracy, we would rather do this hand in hand, we would rather find ways that we can work together, but it’s US taxpayers’ money and we wanna see it spent in the cause of freedom. So I think it’s important to, to note that this is just one example of the kinds of tools we use, um, to effectively help to support the spread of freedom.

### Moderator
Claim: Danielle Pletka?

### Scientific Advocate (SA)
Claim: I think it’s also important and it’s a little bit unfair perhaps but it is important to bear a little bit of witness to what Saad Eddin Ibrahim has done since he was released, uh, from prison, uh, with the good offices of Flynt, Liz, and, and other folks in the Bush administration, and that is that he has been an untiring and, extraordinarily annoying to the Mubarek regime, voice for change—

### Moderator
Claim: Reform—

### Scientific Advocate (SA)
Claim: —for reform, and he said to the President of the United States in the presence of Natan and others at a recent conference in Prague, why do you not do more. Why do you not stand up for us. Now, that’s not the three of us or the three of you. That is a reformer in the Middle East who’s calling upon us to use our power. And I think that that is what we need to reflect, those voices—

### Moderator
Claim: Dimitri Simes.

### Conspiracy Advocate (CA)
Claim: You know— When I hear this argument, that we should criticize every government, uh, we disagreement with in terms of their domestic practices, I want to ask people in the audience before the vote, to ask themselves…when was the last time you assaulted, even if for rhetorically, your business partners. When if you are a lawyer, when was the last time you told a judge that he was a jerk. Uh, when you came to school where your children study, and there told the principal that you have no confidence in them. You know what…if you have to work with people, not because you appointed them, not because you selected them, but because you need to work with them, you have to know when to stop. You don’t need to praise them artificially. You do not need to pretend like President Bush did, that, uh, President Putin had a wonderful pro-democracy soul. But, you do understand that if you need Egypt, if you need the Saudis, to help you with the Middle East peace process, to create an impression that we are trying to overthrow their governments, well, you know, it’s a little inconsistent. It is counterproductive. And I think like with every good thing, we need to know when to stop. And the Bush administration did not know, and still does not know when to stop.

### Scientific Advocate (SA)
Claim: I need to say one thing in response to that though, and I know Natan wants to answer too. 9-11 changed that. And after September 11th, we were very clearly in a situation where it wasn’t us talking to our children’s teacher. It was us saying to governments in the region, conditions inside your countries have become a national security challenge, threat, concern for us. It’s not us saying that we are going to…impose democracy, saying that we’re going to invade every country in the Middle East as are some of the straw men that are, that are held up, but much more us saying, look, we are threatened by the conditions in your country. We are threatened as a nation because your children are living in despair, because your children have no hope, because they can’t speak, because they go to schools where they’re teaching hatred, and violence and intolerance. Those things are not sort of your concerns which have no impact on us, and anybody who lived through 9-11 has thought about the fact that that danger came here to our shores, primarily from countries in that region which are not allowing freedom for their people. You have to understand that their freedom is not just right but it’s a national security interest for the United States—

### Moderator
Claim: Shib—Shibley Telhami has the last word of this exchange—

### Conspiracy Advocate (CA)
Claim: What Liz has just said is actually rather revealing, because I think that’s an argument about, uh, not democracy as an end in itself but as an instrument to en—to American security, it’s a— it’s a—

### Scientific Advocate (SA)
Claim: It’s both. It’s absolutely both—

### Conspiracy Advocate (CA)
Claim: Well—you, you know, you can’t have it both ways, and I think if this is the tack that was taken, uh, this is part of the problem, you have to make an evaluation, has it served our security, even if you don’t make a judgment about democracy, uh, in the same way that we did have a— I think many people in the American political mainstream came to believe that, somehow terrorism is a function of the absence of democracy. First of all, scho—scholars don’t agree on that necessary. But, but, let’s assume that that was the case. Then you have to make an assessment whether we have more terrorism or less terrorism, as a consequence of the policy that we have undertaken, and I think, everybody could look now and make an assessment on where we are in the Middle East, there’s more— There’s no doubt, that there is more Al Qaeda in the Middle East than there was before, in our world certainly, and, there is more terrorism in the Middle East than before. So it hasn’t worked with our national security, and it is being in a way, argued both as an end in itself and an instrument of security, when in fact, even the scholars who believe it’s possible to do it, believe it’ll take years to do and then meanwhile, all you have is instability. And what instability is correlated with, is more terrorism. And that is why we can’t have it both ways, so when Hamas gets elected, uh, you’re stuck. You don’t know what to do. That’s the problem.

### Moderator
Claim: Natan Sharansky’s gonna make a liar of me and insist on—

### Scientific Advocate (SA)
Claim: Yeah, I—I want only—

### Moderator
Claim: —having the last word—

### Scientific Advocate (SA)
Claim: No, I want only to, to react to the jokes of Mr. Simes because they sounded for me like kind of déjà vu. And I understood why. Because they are exactly those arguments of those who explained to us why Soviet Union should not be called Evil Empire. Why Soviet Union should not be restricted in it trade with the United States. Why should not be massive demonstrations for Soviet Jews when Soviet officials are coming. If these jokes were heard then and there you were very strong. If they would listen to them, I would still be in prison.

### Conspiracy Advocate (CA)
Claim: Well, you know—

### Moderator
Claim: Is there—no, is there a question for—

### Conspiracy Advocate (CA)
Claim: When I came to the United States, one of the first things, uh, I did, was, uh, to become a secretary of the advisory board of the Union of Councils for Soviet Jews. And I was a strong supporter of the Jackson-Vanik amendment.

### Scientific Advocate (SA)
Claim: So—

### Conspiracy Advocate (CA)
Claim: There is absolutely no contradiction, between, uh…helping people like Mr. Sharansky, who is a genuine hero, and whose courage I greatly admire, and also understanding some practical interests. Ronald Reagan called the Soviet Union an Evil Empire. Ronald Reagan also, immediately after his assassination, uh, wrote a handwritten letter to Leonid Brezhnev, suggesting that they should find a way to work together. You need to find the balance. The Bush administration doesn’t know how to do it.

### Moderator
Claim: Now, we have a question— We have a question from the audience on the, on the aisle, sir. And, may I say that, uh… please, ask your questions after someone has arrived with a microphone, if you are a member of the press, uh, please identify yourself. Uh, if you’re not a member of the press you—you have privacy rights.

### Moderator
Claim: What if you wanna be a member of the press.

### Moderator
Claim: If you’re an aspiring member of the press you may also identify yourself—

### Moderator
Claim: My name is Arthur Schiff, my question is, uh, this, what is the moral responsibility of the United States, to that fraction of the population in oppressed countries, and specifically for example the people we left behind in Vietnam and the people we left behind in Iraq in ’91— What is the moral responsibility of the US to those people who advocate, care about, are willing to sacrifice themselves, endanger their lives, because they are committed to democracy, and irrespective of everything else see the US as that bastion of democratic hope.

### Moderator
Claim: Let me ask Liz Cheney, if people sign up in one of these countries for the campaign for democracy at America’s urging, and then they find themselves on the outs, uh, by a, uh, a new strong man, what’s our obligation to those people—

### Scientific Advocate (SA)
Claim: Well I think it’s an excellent question, I think that, um, the record of the United States in 1991 in Iraq after calling on the Shia in particular to rise up and then not being there to support them, um, is a shame. And I think it’s something very much our enemies look to. I think it’s also, uh, something that our allies look to. I think that, those who argue for example that we should leave Iraq today, those who argue that we should pull out of the Middle East today, um, I have not heard them explain what that would mean for the millions of people who have believed us when we’ve said that we are standing for freedom, we’re stranding for a new Middle East. And in fact…I think that, that, in response to one of the points Shibley was making, we have a convergence, it’s a—it’s, often, uh, unusual, maybe too unusual. But we have a convergence today, between what is the right thing to do morally. What is the right thing to do to live up to America’s heritage, and America’s proper role in the world, which is to promote freedom where we can. A convergence between that and America’s national security interest, which is that today, promoting freedom in the Middle East will make us safer and has made us safer, and I disagree with Shibley, you don’t have to choose. When you have a situation where there’s a convergence between those two objectives, um, it seems to me that it’s pretty clear that the path you go do down is to undertake that policy. On the issue of whether it’s made us safer I would only point out that during the 1990s when the United States was in fact undertaking the policy that they have advocated, we were attacked in 1993, 1998, 2000. Since 2001, we have not been attacked again. Now, you can talk about what’s happening in the region, we can argue about that, we can argue about the war in Iraq, as I said I welcome that, I welcome the opportunity to do that. But you cannot ignore the fact that since we have been promoting democracy in the Middle East, since we have been standing on the side of those for freedom, as messy, as complicated, as difficult as it is, Al Qaeda has not attacked us here in the US again. It’s not only because of that policy, absolutely, it’s because of…uh, our own policies to take the fight to the enemy, it’s because of what we’ve done to protect the homeland. But surely that policy has been part of it, and you cannot ignore that absence of attacks if you make the argument that we’re not safer.

### Moderator
Claim: I think Flynt Leverett has something to say about that.

### Conspiracy Advocate (CA)
Claim: Yeah. America’s moral obligation to the kinds of people that you were describing, is first of all, not to lead such people to believe that we will support them in ways that in the end, we will not provide. Our first moral obligation is not to mislead people. Our second moral obligation, particularly in relation to Iraq, is not to go to war, when we do not have a coherent and plausible plan for stabilizing a country like that, after we have overthrown the regime. To do that, I would argue, is the height of moral irresponsibility.

### Moderator
Claim: We have a— A question from the audience. AUDIENCE MEMBER (male) Uh, I have a question for, uh, the side, uh, arguing for the proposition. And granted of course that the United States sometimes does have to make compromises, uh, with dictatorial regimes and sometimes in fact has to wind up being allied with dictatorial regimes, most famously of course in the case of World War II. But what I’m wondering is, are there any regimes so reprehensible in the world today or in recent history, that the side arguing for the proposition would say that we cannot be allied with them. Would you for example say that we should have been allied with the Khmer Rouge as they were running Cambodia and killing 2 million of their citizens. Is there some point at which we actually should draw the line in terms of regimes that we simply cannot stomach. And if so what is that line and how do you differ, and differentiate between that, and some of the regimes that we in fact have supported for years in the Middle East.

### Conspiracy Advocate (CA)
Claim: Well, I—

### Moderator
Claim: Is there a red line.

### Conspiracy Advocate (CA)
Claim: I most definitely would not be allied with Khmer Rouge. I most definitely would not be allied with Ahmadinejad, and I most definitely think it was a mistake for us in the past to be seen allied with Saddam Hussein. But I would have to make one qualifier. That is unless of course, we are facing an apocalyptic threat. That is why Winston Churchill decided to be allied with Stalin. And if you would look at Churchill’s record, vis-à-vis Communism, he probably was most brutal in, uh, being quite honest about what a horrible regime they had in the Soviet Union at that time. But in comparison with Hitler, and I’m not even sure quite that Churchill was making just a moral judgment, he was making a strategic judgment, he felt that Britain had no choice, and let me say this. I wish our foreign policy was a morality play. I wish there was never tension between what we wish, and what we know is security interests. But there is tension. And when we are talking about this tension, we are not suggesting that we do not care about the abuse, about those who have no voice. But we are talking about realistic foreign policy choices. And friends, if you believe in democracy, democracy starts with the serious and informed conversation in home.

### Moderator
Claim: Shibley Telhami, you had something to add to that?

### Conspiracy Advocate (CA)
Claim: Uh, well I—I agree first of all that there are people you don’t deal with, but you know, the choice isn’t between having an ally and, and, and not, I mean, in, in, in most cases there, there are…uh, governments that are bad that you don’t deal with or you can ignore. There’s a difference between, uh, uh, applying sanctions or applying some international, uh, punishment on a—on a regime, and between going to change the system. Uh, I think that, uh, we’re in a great position, uh, and we were after 9-11, to mobilize the international community over issues that were of great importance not just to us but to everyone else. And human rights is included in that. And, we have international forums, uh, for a, in which we can take this, we still are the most powerful nation, and peop—we could’ve led in international organizations, uh, to tighten, to, to punish, to, uh, to, uh, exclude people who were violating human rights in the international system, I believe that we need to do that. I think it is important to have moral values. I think that, national interest cannot explain all of what we do, I don’t wanna just be serving my material interests, I’m a—I’m a moral individual, I want my country to stand for moral issues, I don’t deny that. I think we can—are capable of it, if we’re not capable of it as a—as the United States of America, no country is. We’re far too powerful, not to have something extra to push for the good in the world beyond. What I’m calling for, is more modesty, more selectivity, more…international, uh, organization, uh, type action. Uh, not the sort of, uh, I don’t wanna say—arrogance probably is the word, in this particular case, to say that we know what is best and we’re going to bring it about, that’s not values. Especially, when the morning after, people are far worse as they are in Iraq, than many of them were the day before. That is not values, that is not spreading good in the world, that is not, when you have more than 2 million refugees, most of whom we’re not even trying to provide for.

### Moderator
Claim: Danielle Pletka has a, has a response to what you’ve said, Shibley—

### Scientific Advocate (SA)
Claim: I don’t, I don’t, I don’t have a, uh, a ques—a response, I have a question, um, I would like to ask our compatriots whether, uh, had they had the opportunity, um, and were in a position to do so prior to 9-11, would they have worked to overthrow or change the regime in Afghanistan and remove the Taliban.

### Conspiracy Advocate (CA)
Claim: I’m glad you asked.

### Scientific Advocate (SA)
Claim: Oh, good. Go for it, Dimitri.

### Conspiracy Advocate (CA)
Claim: I was, uh…uh, bus-riding. And talking to people in the administration, including, uh, to the Secretary of State… about, uh, the need to establish American priorities. And after World Trade Center, after what was done to American, embassies in Africa, I felt very strongly, that the big target had to be, Taliban, and of course Al Qaeda. However, the administration at that time was so upset with what was happening in Russia, and so eager to reduce increasing Russia down to size, that they ignored, then Prime Minister Putin, he was not President yet, Prime Minister Putin, suggestions, that the United States and Russia would work together against Taliban. Similar felt, that we, instead of focusing on all kinds of things including democracy promotion in Pakistan, had to make that that very issue, Pakistani support for Taliban, the central issue in our dialogue with that government. But we treated foreign policy as a Christmas tree. We did not want to establish priorities. We wanted to do everything at the time. We cannot conduct an experiment in history, I do not know whether to attack Taliban with the Russians, and with the Pakistanis, whether we would be able to prevent September 11th.

### Scientific Advocate (SA)
Claim: But you would’ve supported that—

### Conspiracy Advocate (CA)
Claim: we would never know.

### Scientific Advocate (SA)
Claim: But you would’ve supported it, right?

### Conspiracy Advocate (CA)
Claim: I most definitely—

### Scientific Advocate (SA)
Claim: Like you supported the overthrow of Saddam Hussein.

### Conspiracy Advocate (CA)
Claim: I—as a matter of fact—

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: I did sup—

### Scientific Advocate (SA)
Claim: I—you did, I know that you did—

### Conspiracy Advocate (CA)
Claim: The amount of—

### Scientific Advocate (SA)
Claim: I’m just checking.

### Conspiracy Advocate (CA)
Claim: I did support the overthrow of Saddam Hussein—

### Scientific Advocate (SA)
Claim: Right, good.

### Conspiracy Advocate (CA)
Claim: You’re absolutely right.

### Scientific Advocate (SA)
Claim: I’m thrilled to hear it.

### Moderator
Claim: As—

### Conspiracy Advocate (CA)
Claim: And I have no regret—

### Scientific Advocate (SA)
Claim: As did I.

### Moderator
Claim: As—as a point of advancing democracy, uh, in Iraq?

### Conspiracy Advocate (CA)
Claim: Uh, that’s, that’s—

### Scientific Advocate (SA)
Claim: Not so fast—

### Conspiracy Advocate (CA)
Claim: That is the big issue.

### Moderator
Claim: Okay—

### Conspiracy Advocate (CA)
Claim: I thought that Saddam—

### Scientific Advocate (SA)
Claim: Not no—

### Conspiracy Advocate (CA)
Claim: —Hussein was a threat, I thought that containment was not working, I thought we had to go and try to do it quickly—

### Conspiracy Advocate (CA)
Claim: —and to turn the project to international organizations.

### Moderator
Claim: Natan Sharansky.

### Scientific Advocate (SA)
Claim: One short note is simply in support of Winston Churchill, because it was mentioned correctly that Winston Churchill had no choice but to cooperate with Stalin to fight Hitler. But immediately after the war, he was the first to declare the beginning of Cold War. He was the first to recognize who—what is the nature of Soviet Union. And he brought back that moral clarity, which is lacking so much today, thank you.

## Round 3

### Moderator
Claim: Well, thank you very much for your answers to my questions and the questions we’ve taken from the audience, and we’ve managed to debate not only the spread of democracy in the Middle East today but the, uh…uh, alliance between the United States, Britain and Soviet Union during the Second World War— And I’m sure we could go still further, and, uh, and you’ll yet have another chance to raise these points now in closing, uh, statements which are to run maximum two minutes. Uh, and we begin with, uh, Natan Sharansky. Against the resolution.

### Scientific Advocate (SA)
Claim: Well, uh, it was mentioned already today that some time ago, I together with Vaclav Havel organized an international conference in Prague on security and democracy. And it became like a kind of international meeting of democratic dissidents from all over the world but first of all from Middle East. For there were so many democratic dissidents from Iran and Iraq and Libya and Syria, and Sudan and Egypt and so on. I know by listening to the stories of these people, I think they themselves, were surprised to discover how each of them has the same story. Of personal struggle, a person who wants to be free and wants his country to be free, against totalitarian regime. And, uh, it was easy to recognize the stories of our dissident stories, mine and Vaclav Havel’s then, and theirs today. With one difference. We knew… that if we go to prison all the free world will be with us. They know that they, when they go to prison, the free world is debating whether it is in our interest to support them, or their…uh, or the people who jailed them.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: And that’s a big problem. Frankly speaking, I’d like on today’s debate, Abraham Lincoln who’s been speaking together with us. Because, this President when he came to the office… black Americans were slaves, and even had to rights to walk. If he was asked if it is good idea to promote democracy, is it…good idea to impose democracy, is stability should be preferred to democracy, what he would answer. He once said—I don’t remember exact quote, I don’t something like this—we will not be the masters, we will not be the slaves. We of course, we are, thank God, we are not slaves. We must make sure that we are not supporting the masters. To promote democracy, it’s first of all to stop supporting tyr—tyrants in the Middle East.

Well, uh, it was mentioned already today that some time ago, I together with Vaclav Havel organized an international conference in Prague on security and democracy. And it became like a kind of international meeting of democratic dissidents from all over the world but first of all from Middle East. For there were so many democratic dissidents from Iran and Iraq and Libya and Syria, and Sudan and Egypt and so on. I know by listening to the stories of these people, I think they themselves, were surprised to discover how each of them has the same story. Of personal struggle, a person who wants to be free and wants his country to be free, against totalitarian regime. And, uh, it was easy to recognize the stories of our dissident stories, mine and Vaclav Havel’s then, and theirs today. With one difference. We knew… that if we go to prison all the free world will be with us. They know that they, when they go to prison, the free world is debating whether it is in our interest to support them, or their…uh, or the people who jailed them.

### Moderator
Claim: Thank you, uh, Natan Sharansky, now… Now for the resolution, Flynt Leverett.

### Conspiracy Advocate (CA)
Claim: I think that…in making your vote this evening, you have, in many ways, a quite simple choice. If you believe that the alternative to the house of Saud, the alternative to the Mubarek regime, is a group of Western-educated Jeffersonian democrats, then you ought to vote against the resolution. If you believe as I do, that under current circumstances the alternatives to these incumbent regimes will actually be worse for American interests, and, I think, worse for the people in these countries, then you should vote for the resolution. It is a red herring to say that by saying democracy promotion in the Middle East is a bad idea, we basically are washing our hands of any concern about how the Middle East develops.

### Moderator
Claim: One—

### Conspiracy Advocate (CA)
Claim: That is simply not true. There is an enormous ferment in the Persian Gulf today, around economic reform, around, as Liz pointed out, the spread of information technologies, the increasing involvement of the Gulf states, and other Middle Eastern countries in the globalized world of the 21st century. That is not a product of American policy, in fact I would say we’re not doing enough to support those developments. Egypt can get a free-trade agreement with the European Union but it can’t get a free-trade agreement with us. That’s nuts, we ought to be supporting economic reform in these countries, we ought to be standing up for human rights, and the political development in these countries will then, over time, take care of itself, and in the meantime, we will be much better positioned to fight terror, protect the security of the state of Israel, and protect our most vital interests in the Gulf—

I think that…in making your vote this evening, you have, in many ways, a quite simple choice. If you believe that the alternative to the house of Saud, the alternative to the Mubarek regime, is a group of Western-educated Jeffersonian democrats, then you ought to vote against the resolution. If you believe as I do, that under current circumstances the alternatives to these incumbent regimes will actually be worse for American interests, and, I think, worse for the people in these countries, then you should vote for the resolution. It is a red herring to say that by saying democracy promotion in the Middle East is a bad idea, we basically are washing our hands of any concern about how the Middle East develops.

### Moderator
Claim: Thank you, Flynt Leverett. Speaking for the resolution. Liz Cheney, against.

### Scientific Advocate (SA)
Claim: Um, I think it’s important as you vote tonight to think about the fact that all three of those arguing for the motion, have argued our point. Flynt’s just argued that we ought to be supporting the changes that we’re seeing in the Gulf, not just the economic changes but the expansion of information technology, the expansion of freedom of the press, that’s part of democracy. Dimitri argued that we ought to be supporting freedom of choice. That’s what we’re doing. Um, and Shibley said we should advocate democracy, we just ought to do it differently. So I think that it’s important for us to focus on what is the debate here tonight, but when we’ve got all three of our opponents arguing that, that the policy itself may have flaws but that in one way or another we ought to be advocating democracy, human rights, freedom, economic reform, uh, it is, uh…hard not to imagine that, that what is, um, urging them to argue for this motion, is a disagreement about our Iraq policy, a disagreement about George Bush, a disagreement about our foreign policy in general.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: And I think it’s critically important to recognize this isn’t a game. There are real people, real men and women, as I mentioned across the region today, tonight, tomorrow, who believe America will stand with them for freedom. And I think that, that the, uh, great moral disservice that we would do, we could do to them, the greatest moral disservice we could do to them would be to fold our tent in the face of terrorist attack, to fold our tent in the face of extremists, who don’t believe that women should be equal, who don’t believe in freedom of religion, who don’t believe in freedom of speech. Our opponents have also said we need a balanced policy, we need to work with regimes when they can help us in the war on terror, and at the same time we need to be supporting freedom. That’s what we do. You can say we don’t do it the way you would do it, we could have a debate about how to do it more effectively, but at the end of the day, that is what we’re doing, that is what the policy is, and I think it’s critically important that we don’t abandon those who are standing with us, to help build a world in which we don’t have to fear attack by terrorists.

Um, I think it’s important as you vote tonight to think about the fact that all three of those arguing for the motion, have argued our point. Flynt’s just argued that we ought to be supporting the changes that we’re seeing in the Gulf, not just the economic changes but the expansion of information technology, the expansion of freedom of the press, that’s part of democracy. Dimitri argued that we ought to be supporting freedom of choice. That’s what we’re doing. Um, and Shibley said we should advocate democracy, we just ought to do it differently. So I think that it’s important for us to focus on what is the debate here tonight, but when we’ve got all three of our opponents arguing that, that the policy itself may have flaws but that in one way or another we ought to be advocating democracy, human rights, freedom, economic reform, uh, it is, uh…hard not to imagine that, that what is, um, urging them to argue for this motion, is a disagreement about our Iraq policy, a disagreement about George Bush, a disagreement about our foreign policy in general.

### Moderator
Claim: Thank you, Liz Cheney. Uh, closing statement, Shibley Telhami for the resolution.

### Conspiracy Advocate (CA)
Claim: We need more democratic change, more liberty, more human rights, not words to claim we are doing it, and not promises that we can in fact do it. The train wreck is too long to miss. It is easy to sell dreams in times of pain, and many after the horror of 9-11 so badly wanted answers. And visions of spreading democracy were too good to resist. If something is imaginable, we thought, it is possible. If something is possible, we thought, it is likely. Thus is the stuff of wishful thinking. It would still be worth a dream if the costs and reality were not so unbearably high, if it weren’t for the fact that the morning after, has been even worse than the day before. That millions are paying the price. There’s a time to go with your heart—

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —and there is a time to go with your mind. And this is the time to go with your mind. Thank you.

### Moderator
Claim: Thank you…Shibley Telhami. Danielle Pletka, against the motion.

### Scientific Advocate (SA)
Claim: Flynt suggested in his closing remarks that, uh, that if the United States harps on the treaty obligations of, uh, of our, our Arab dictator, uh, friends, then perhaps there will be a greater adherence to human rights. Um, I recall the Iranian signature of the International Atomic Energy Agency’s nuclear non- proliferation treaty, um, which was not a very effective treaty that was signed, uh, North Korea, same. Uh, all the counter-terrorism treaties, the genocide treaties, the chemical weapons conventions. Pieces of paper make bureaucrats in Washington feel good. They enable them to come home with victories that they can trumpet on the front page of the Washington Post and the New York Times. But it doesn’t do a great deal for the people who live in these countries, the 300 million people of the Middle East and North Africa who don’t live in freedom. As I came here today and looked out the window and you can see signs hanging from institutions, synagogues in particular that say—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: —“Save Darfur.” Why is it that we have a special regard for Darfur, but not for the 300 million of the Middle East and North Africa who have lived so long with torture, without freedom, and yes, with genocide as well. Our past failings should not dictate our future failings. And our hearts and our minds should work together, for the right thing in the national interest. Yes, it’s true, Hitler was elected by democracy. But that does not discredit democracy. To the contrary, those who are willing to accept that decision, and do nothing in the face of the reality that Hitler was an evil, ruthless tyrant, were the Chamberlains. And those who spoke out to depose and to act and to spread democracy and change in national interest, were with Churchill. And I think history will judge those who stood on the other side very harshly in this regard as well.

Flynt suggested in his closing remarks that, uh, that if the United States harps on the treaty obligations of, uh, of our, our Arab dictator, uh, friends, then perhaps there will be a greater adherence to human rights. Um, I recall the Iranian signature of the International Atomic Energy Agency’s nuclear non- proliferation treaty, um, which was not a very effective treaty that was signed, uh, North Korea, same. Uh, all the counter-terrorism treaties, the genocide treaties, the chemical weapons conventions. Pieces of paper make bureaucrats in Washington feel good. They enable them to come home with victories that they can trumpet on the front page of the Washington Post and the New York Times. But it doesn’t do a great deal for the people who live in these countries, the 300 million people of the Middle East and North Africa who don’t live in freedom. As I came here today and looked out the window and you can see signs hanging from institutions, synagogues in particular that say—

### Moderator
Claim: Danielle Pletka. And in conclusion Dimitri Simes for the motion.

### Conspiracy Advocate (CA)
Claim: Like Mr. Sharansky, I also lived in the Soviet Union. And, uh, for most of us, the United States was a shining castle. And the United States stood, not only for prosperity and freedom for the United States, but also for freedom for the rest of us. The big difference however, for—between standing for this kind of freedom, and what we have witnessed during last several years, that every American President, before this one, was taking the position that we would protect and defend freedom of Americans, and of the allies. And whenever possible, would protect freedom of other nations. The country was not taking upon themselves, telling others on a global scale how they’re supposed to live. And when you go to the world, and offer indispensable guidance, particularly when you are not particular popular, when you—

### Moderator
Claim: One—

### Conspiracy Advocate (CA)
Claim: —are not particularly liked, you know what? It creates a backlash. The debate tonight is not about freedom. The debate tonight is whether we want to have a foreign policy which makes us feel good, or do we have to have foreign policy judged by results. And I am convinced, the dissidents in Iran, democrats in Iraq, they want results, not rhetoric. That is why I am in favor of this resolution.

### Moderator
Claim: Thank you, Dimitri Simes. And so we’ve heard the concluding remarks, it’s now time to vote. Uh, once again, please pick up the keypad that’s attached to the left arm-rest of your seat, and after my prompt, press “1” if you are for the motion, the motion again being, that spreading democracy in the Middle East is a bad idea, “2” if you’re against the motion, and “3” if you are undecided. Please cast your vote now.

We’ll have the results in a moment. I want to thank the debaters, and also the audience, for their good work— And before I announce the results of the audience vote I wanna take care of a few things, first, this is the first debate of the second Intelligence Squared US series. This program has been a huge success, because of the enthusiasm of audience members like yourself, and for everyone at Intelligence Squared, we’d like to thank you for your continuing support. Uh, the next Intelligence Squared US debate will be on Tuesday, October 9th, here at Asia Society and Museum. The motion to be debated is, “Let’s stop welcoming undocumented immigrants.” It will be moderated by journalist John Hockenberry, and the panelists for that debate are, for the motion Vernon Briggs of Cornell University, Mark Krikorian of the Center for Immigration Studies, and Heather Mac Donald of the Manhattan Institute. Against the motion, the Cato Institute’s Daniel T. Griswold, Enrique Morones of Border Angels, and Karen K. Narasaki of the Asian American Justice Center. An edited version of tonight’s Intelligence Squared US debate, can be heard locally on WNYC AM 820 on Sunday, September 30th, at 8 p.m. Please check your local NPR member station listings for the dates and times of broadcast outside of New York City. You can also watch this debate on 13 WNET New York public television, this Sunday, September 23rd, at noon. Uh, some other items, copies of Natan Sharansky’s book The Case for Democracy are on sale upstairs,— as well as complimentary copies of the foreign policy journal, The National Interest. Uh, you can also purchase DVD’s from previous debates here to—tonight, from the Intelligence Squared— or from the Intelligence Squared US website. Now, the debate results. After our debaters did their best to sway you, you voted, 55% for the motion, 40% against the motion, and 5% undecided, which means, that those in favor of the motion, carry the day, congratulations, the team for. And thank you to all the panelists, for your fine work.
