# Debate Transcript

Topic: It's Time To Clip America's Global Wings
Motion: It's Time To Clip America's Global Wings

Debate ID: globalization


## Round 1

### Moderator
Claim: And I'd like to begin the evening by introducing the chairman of Intelligence Squared U.S., Mr. Robert Rosenkranz.

### Moderator
Claim: Well, thank you very much, and it's my pleasure to welcome all of you. My role in these proceedings is to frame the debate. So it's time to clip America's global wings. The U.S. government is in the worst financial shape it has ever been during our lifetimes. China is now the world's second largest economy, and America's largest creditor. With minimal U.S. involvement, popular movements in Egypt and Tunisia have succeeded in toppling autocratic regimes, largely through peaceful means. And where the U.S. has been involved, as in Iraq and Afghanistan, it has sometimes compromised its moral authority-- I'm thinking of Abu Ghraib and Guantanamo, abusive interrogations and civilian casualties--and has often made us more enemies than friends. All these developments suggest that America's hyperactive engagements around the world are financially unsustainable, morally questionable and of dubious value in the hard currency of national self-interest. On the other hand, perhaps developments in the Middle East do reflect well on America's long-standing support for liberty and freedom. They certainly reflect well on such American innovations as Twitter and Facebook. When a tyrant like Gaddafi threatens mayhem, and the U.N. Security Council and the Arab League agree that military action is required, a miracle, by the way, their views are meaningless without U.S. power to back it up.

When Iran is trying its best to achieve a nuclear weapons capability, the U.N. can fret. But only the U.S. can lead a serious effort to prevent them from succeeding. Perhaps we're not loved. The rich and the powerful rarely are. But our unflagging efforts are vital to keep the world moving toward greater freedom and greater stability. Well, these differing views about America's role in the world are among the most profound political fault lines that we face. The outstanding panelists we've brought together this evening will help you decide which is the better view. And it's now my privilege to turn the evening over to our moderator John Donvan. John, thank you.

### Moderator
Claim: Thank you. And I would really like to invite one more round of applause for Robert Rosenkranz because he's the one who makes these debates possible. True or false, it's time to clip America's wings, its global super power wings. Let's have it out. This is a debate from Intelligence Squared U.S. We're at the Skirball Center for the Performing Arts at New York University. I'm John Donvan of ABC News, and this is another debate from Intelligence Squared U.S.

Joining me on the stage, two teams of two members each who will be arguing out this motion. We have, arguing for the motion, Peter Galbraith and Lawrence Korb; against the motion, Eliot Cohen and Elliott Abrams. And I'll point out that throughout the week, the producer of our debate, Dana who has enjoyed describing this Intelligence Squared U.S. debate as having one team that we should call “Elliot Squared.” But-- but we won't. I want to remind you, this is a debate. It's a contest. It's a contest of ideas and logic and argumentation. And you, our audience, will be the judges of this contest.

By the time the debate has ended, you will have been asked to vote twice, once before the debate and once again afterwards on our motion, “It's time to clip America's global wings.” And the team that has changed the most minds by the end of the debate will be declared our winner.

So let's register your first position, you and members of our audience on this debate. If you go to the keypad to the right of your seat, our motion is, “It's time to clip America's global wings.” If you agree with the motion, push number one. If you disagree, push number two. If you are undecided at this point, push number three. You can ignore the other keys. And if you feel that you entered a key in error, just correct it and the system will lock in your last vote. All right. It looks like everybody got it.

Our motion, “It's time to clip America's global wings.” And on to round one. Round one, we have opening statements by each debater in turn. They are seven minutes each.

And our first debater up to speak for this motion, Peter Galbraith. He's a former U.S. diplomat. He served as a special deputy representative of the U.N. in Afghanistan. He was the first U.S. ambassador to Croatia. He is currently a Vermont state senator. His entire life has been involved in diplomacy, including a stint as a cabinet member of the transitional government of East Timor, which comes, Peter, with what sorts of perks, passport, what?

### Conspiracy Advocate (CA)
Claim: Use of the VIP lounge in Dili International Airport. But I will say it is a culmination of a career that began with a foreign relations committee ambassador to Croatia, of ever more important jobs in ever smaller places.

### Moderator
Claim: Ladies and gentlemen, Peter Galbraith.

### Conspiracy Advocate (CA)
Claim: It is time to clip America's global wings.

America's global ambitions, particularly in the last decade, have far exceeded our capabilities. It is more than we can afford, more than a trillion dollars on two wars in Afghanistan and in Iraq. But beyond the fact that we can't afford it-- and my colleague, Larry Korb, will make that case, it is that we are not capable of doing it. We do not need to sit here and debate the rights and wrongs, the moral correctness or the lack of correctness of the Iraq war or the Afghanistan war. The fact is we undertook massive nation building exercises, and we did not succeed. In fact, I will argue to you that we have not only not helped the United States, we have undermined America’s national security.

Now I want to be clear. Larry Korb and I are not isolationists, we are not against U.S.-- use of U.S. power in the world. When I served as the first U.S. ambassador to Croatia, I argued strongly for U.S. airstrikes against the Serbs who were attacking Sarajevo and civilians in Bosnia and Herzegovina, and when those airstrikes took place, they combined with intense diplomacy, they brought a four-year war that had claimed more than 100,000 lives to an end. It was effective. Larry Korb and I support the intervention in Libya, and it is-- for the same reason that it is working in Bosnia-- it was in Bosnia and in Libya we had limited ambitions. In Bosnia it was to end the war, in Libya to protect civilians.

We had allies in Bosnia, the Europeans picked up more than two-thirds of the cost of reconstruction. They’re doing much of the heavy lifting in Libya, and we had partners on the ground. That is not the case in Iraq or in Afghanistan. In the case of Iraq, we went in not appreciating the complexities of the government, and in the end, who ended up as the victor? Iran. For eight years, the Ayatollah Khomeini and the clerical government in Iran fought the Iran-Iraq War, at a cost of a half a million Iranian soldiers for the goal of installing, of getting rid of Saddam Hussein, and of installing in power Dawa and SCIRI, two Iranian-supported Shiite parties. They failed.

In 2003, the U.S. went in, and who is it that is in power in Iraq but the Dawa has the prime ministership, SCIRI plays a major role. Talk about unintended consequences. In Afghanistan, the United States is embarked on a counterinsurgency, I want to be clear about the operation we took to remove the Taliban, to drive out-- to try to kill and capture Al-Qaeda was correct, morally justified, endorsed by the U.N. Security Council, but that mission has now morphed into an exercise aimed at building a central government in a country that has never had a strong central government and a counterinsurgency strategy that requires-- if General Petraeus were here, its architect, he would say just what I’m going to say-- it requires a local partner for it to work.

Our partner in Afghanistan is Hamid Karzai who presides over what transparency internationals described as the second-most corrupt country in the world-- number one is Somalia which doesn’t have a government at all-- is ineffective, illegitimate, having stolen his last election through massive fraud, and as a result, the strategy doesn’t work. We have invested billions in training an Afghan police force. Our idea is that by training an Afghan police force, they'll be partners who can provide security, and why do we train the police? Because that’s what we know how to do, but the problem in Afghanistan is the police are the visible face of a corrupt Afghan regime.

The money that we’ve spent building roads so farmers can bring their products to market in Afghanistan isn’t working because, yes, the roads are there, farmers don’t bring their product to market because the police rip them off by more than the value of the market. We can train the police to be policemen, but we cannot make them honest. Afghanistan is also another case of the unintended consequences of our actions. We are spending this year $117 billion on the Afghanistan war. To fight an enemy, the Taliban, whose budget is estimated between $70 million and $200 million, and how do the Taliban fund themselves? From the United States. Why? Because to supply our military in Afghanistan, we bring in supplies to the Pakistani port of Karachi, they go through Taliban-controlled territory. The contractors pay off the Taliban. And with the money used to pay for U.S. troops in Afghanistan, we ourselves are financing the Taliban.

Now look at this from the point of view from the extremists. We can spend $70 million and get the U.S. to spend $117 billion. That is a pretty good investment. So, our position is simple. We need to scale back what the United States is doing in the world. Yes, to continue global engagements. Yes, to working with allies. But no to this ambitious overreaching. Yes to being smart. So, please join me in supporting the proposition that it is time to clip America’s global wings.

### Moderator
Claim: Thank you, Peter Galbraith. And that’s our motion: "It's time to clip America's global wings." And here to speak first against the motion, I’d like to introduce Eliot Cohen. He’s a professor of strategic studies at the School of Advanced International Studies at Johns Hopkins University.

He’s a former counselor at the Department of State, former Army Reserve officer, so he’s worked with an elite force, former faculty member at Harvard, so he’s worked with a force of elitists, and-- and, given the fact that you have a son who has done two tours in Iraq, none of this is theoretical for you, is it?

### Scientific Advocate (SA)
Claim: No, it’s not theoretical for a lot of people both here and abroad.

### Moderator
Claim: Ladies and gentlemen, Eliot Cohen.

### Scientific Advocate (SA)
Claim: Well, I can see one of our challenges tonight on the con team is to make it very clear that our opponents stick to what the debate’s about. The topic of the debate was not, “The Iraq War: Good Idea, Bad Idea?” The topic was not, “Afghanistan: Well Conducted, Poorly Conducted?” The topic is should we clip America’s global wings? This is not a debate about President Bush. It’s not a debate about President Obama. It’s not a debate about Iraq. It is not a debate about Libya. It is not debate about Afghanistan.

It is most certainly not a debate about whether prudence is better than recklessness. It’s not a debate about military power versus soft power. It is a debate about America’s role in the world. Our view-- my view and the view of the Elliot who can’t spell his own first name correctly-- is very much that of a statesman who said that the United States is an anchor of global security and an advocate for human freedom. That would be President Barack Obama. It is the mainstream view. Now, our colleagues have chosen or have agreed to a metaphor which is not one that I would have signed up to. When you clip a bird’s wings, it can only fly so high or so far.

It’s not a question of where you try to get the bird to fly; it’s what the bird can do. So the question that they will have to address is what capabilities should we give up, not what waste should we curtail? We’re all against waste. What regions of the world no longer matter to us? What issues will we ignore? And what will be the consequences when we do so? They’ve already begun by making a number of distinctions, some of which I have to say I find difficult to understand. We have limited objectives in Libya when President Obama has said that Gaddafi has got to go. We have local allies. Exactly who? I’m not quite sure. Our opponents will and have begun making a number of arguments. They will argue-- they have argued that this is way too costly. I would just remind the audience of one statistical fact.

The United States today spends something on the order of about five percent of Gross Domestic Product on defense, maybe a little bit more. During the Kennedy administration, that figure was over eight percent, during the Eisenhower administration, over 10 percent. Even with the vast expenses of the wars in Iraq and Afghanistan, it is not the defense budget that is the cause of our current economic difficulties. Our record is tarnished. Well, the price of action is frequently exposing yourself in that way. There were plenty of air strikes in Bosnia, the war that Ambassador Galbraith favored, that killed civilians. That’s the price of going to war. I want to make a larger point about the world view that Elliot and I share and that, really, I think, informs our position in this.

The first is a set of propositions about the United States, of which the most important is this: The United States has always been a global nation from the very beginning. We were born as part of an Atlantic community. From the outset, our trade stretched across the world, to China and to the Middle East. When the United States chose not to act as a global power with global responsibilities, we were not always the ones who paid for that. When we did-- and of course, the time that we all think of is the period after World War II-- it was not simply that the United States used its force wisely, as I believe it did. It built enduring edifices of alliances, institutions and practices that have served us and have served the world well. Fundamentally, I think the difference comes down to this: Elliott and I believe that the United States is a force for good in the world. That doesn't mean that we don't make mistakes.

Of course, we will. That is, in many ways, the price of action. But we believe that the United States has been a force for good, can be a force for good and should continue to think of itself that way. We share a second fundamental world view, and that is a view about the nature of our environment. In many ways, we've entered a world which is a dangerous and difficult place, not just thinking of issues like nuclear proliferation or global warming. By the way, it's not clear to me that if you clip America's global wings, why doesn't that cover things like the United States taking the lead on global warming? But beyond that, we live at a time of tremendous movements in human history. I'll just mention two. In the last decade, hundreds of millions of Chinese have risen out of poverty. That is unambiguously a good thing.

It is a good thing that countries like China don't have to worry about famine, that Chinese fathers and mothers can have expectations of a better life for their children than they have had. But it is also true that the same economic growth that has pulled hundreds of millions of Chinese out of poverty, arms a military establishment which acts in support of a foreign policy that claims, among other things, territorial rights to the South and East China seas, to include the territory of some of our closest allies like Japan. Well, let's take the dramatic events of recent months, the Arab spring. In many ways, this is say good thing. There's no question about that. It is quite an extraordinary thing to watch. By the way, it's very striking, I think, to me and to many others, that there's not very much-- there's no anti-Americanism in any of that. But there's clearly potential for this to go in a number of directions.

Our fundamental position is it's in America's interest to act where we can act, to guide and shape these events and not to be timid and not to be afraid, to exercise leadership that only the United States can lead.

### Moderator
Claim: Thank you, Eliot Cohen. So here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. Our motion is “It's time to clip America's global wings.” I'm John Donvan of ABC News. We have four debaters, two teams of two, fighting it out over our motion. And you've heard two opening statements, and now we're going to go on to the third. Lawrence Korb is a senior fellow at the Center for American Progress who served as assistant Secretary of Defense under the Reagan administration. And Lawrence has-- you worked for the Reagan administration, but now you are working for a think tank, you know, populated by a lot of Clinton guys. Is something not adding up in this picture or--

### Conspiracy Advocate (CA)
Claim: What's not adding up is that the Republican Party has changed tremendously since the days of Reagan.

Remember when-- in the Reagan administration, when we got into Lebanon, it didn't work, Reagan got out. He raised taxes 11 times when he recognized that supply-side economics was not working. He worked with members of Congress to reform the Social Security system that kept it in balance until this year.

### Moderator
Claim: I think we might be getting into your set of minutes, so I'm going to--

### Conspiracy Advocate (CA)
Claim: Well, I thought I would take advantage of it.

### Moderator
Claim: So I'm going to launch you with, ladies and gentlemen, Lawrence Korb.

### Conspiracy Advocate (CA)
Claim: My point is that even if you think the United States should be more involved in the world, the problem is right now we're broke. We borrow 41 cents of every dollar that the federal government spends. We borrow-- put it another way-- $4 billion a day. Now, if you go back and you take a look-- and I know our opponents don't want to talk about the previous administration.

Go back to the beginning of this century. The beginning of this century, the United States accounted for one-third of the world's Gross Domestic Product. We spent one- third of what the world spends on military. Here we are today, we account for only one quarter of the world's Gross Domestic Product, but yet we account for half of the world's military expenditures. Five percent of the world's population, which is us, spends half of what the rest of the world spends on defense. Now, remember at the beginning of this century, we had a budget surplus. You may remember the lockbox and all of those debates back in 2000. That surplus was supposed to make sure that Social Security would not run out of money quicker than it has. Where did we end up at the end of this decade? Not with a surplus of about five trillion, but with a deficit of five trillion. And then, of course, when the global economic crisis hit, we had to increase the deficit even more.

Now, the question becomes, how do we get there? Defense played a part. The war has played a part. It wasn't the only part, but I think it's important to keep in mind, in 1968, when we had 540,000 people in Vietnam, we balanced the budget. How did we do it? We had a surtax, a war surtax. What happened this time? You can be for or against the wars in Iraq and Afghanistan. But the fact of the matter is we went to war, and we didn't pay for it. In fact, what we did is we cut taxes. We've never done that in our-- in our history. And what happened? The wars cost-- the direct cost a little over a trillion dollars so far. But the indirect costs, as a lot of economists will tell us, we'll be paying for a long time. And Joe Stiglitz up here, a Columbia economist, estimates it'll cost three to $5 trillion.

We compounded it during that time by increasing the defense budget, what we call the baseline budget. General McChrystal, who everybody knows, I had the privilege of working with at the Council on Foreign Relations about 10 years ago. Before he went to Afghanistan, basically he was on the joint staff and in charge of the baseline budget. And he told me, when I spoke to him the last time, he said, we didn't have to make any choices. We could have everything. The baseline budget also went up during this particular period. Again, during Vietnam and during Korea which had war costs, we looked into the baseline budget of the programs that didn't contribute to our national security. Now, you don't think the deficit's a problem? Admiral Mullen, the chairman of the Joint Chiefs of Staff said it's the biggest threat to national security. And he says unless we get our economic house in order at home, we can't be strong abroad. Now, the defense and I agree with it. Wasn't the only thing.

We as individuals live beyond our means. We all assume that housing prices were going to go up 30 percent a year. And, you know, we made our decisions on that basis. States right now are having a lot of problems because when they had the pension funds for the policemen, the firemen, the teachers, they assumed they would grow eight percent a year. Well, that didn't happen, and they're having problems. Now, the question becomes, okay, now we have these problems. Maybe we should still do a lot more in the world. And again, we're not against involvement. But it has to be selective engagement. You can't deal with every situation. But we've got a lot of challenges at home. You probably have seen all of the statistics. We're 15th in reading, 17th in science, 25th in math. These are our children. Our infrastructure is falling apart. We're 27th in life expectancy. You know, right now, but we are ahead in a couple of things.

Obesity is one, and we're also basically first in the amount of debt that we have and the number of people who are below the poverty-- poverty line. And what we're doing, as a country, we're living off our past investments. If you go back and look where we are today, these are all investments we made in the '50s and the '60s. Now, can you cut defense? Yeah, you sure can. If you take a look at what we're spending on defense, and you put it in constant dollars, go back and look at the Cold War average, it was 450 billion. Right now it's 550 billion. How do I know it's too much? Secretary of Defense says $150 billion in inefficiencies. Well, we could take that money and use it to deal with some of the problems at home. And a couple of things, you know, that we could take a look at in terms of if we get back to where we are-- Secretary Gates, Secretary of Defense goes to West Point. We’re not going to send large land armies into Muslim countries again, okay?

This is a man who worked for President Reagan, worked for President Bush, is now working for President Obama. Well, if you’re not going to do that, let’s take a look at the size of the Army and the Marine Corps. This is something that you can do. We also have to recognize as a country that not all problems can be solved, nor can we solve them all. And I think, as Peter pointed out, I think Libya’s the perfect example of the way to do that. We used our unique capabilities, we got other people involved, and you know who’s a great example for this, the first President Bush. You may remember in the campaign, President Obama said, “I like President Bush,” and everybody said, “You do?” and he said, “Well, the first President Bush.” The first Persian Gulf War we got over 200,000 troops from other nations, and those who couldn’t send troops, we collected money. We collected so much, we actually made a profit on the war. So it didn’t cost us anything and, in conclusion, we’ve done it before.

Eisenhower got us out of Korea, wouldn’t go into Hungary and Poland, or into Vietnam. Nixon got us out of Vietnam, started arms control with the Soviet Union, recognized China, and even Reagan, when he started negotiating with the Russians, you know what Newt Gingrich called him? Neville Chamberlain. Thank you very much.

### Moderator
Claim: Thank you, Lawrence Korb. Our motion is "It’s time to clip America’s global wings," and now to speak against the motion, Elliott Abrams, he’s a senior fellow at the Council on Foreign Relations. He served as a deputy national security adviser in charge of Middle Eastern affairs in the George W. Bush administration. He recently commented himself on the Libya situation by saying the great mistake that the Obama White House had made in its foreign policy-- in its policy towards Gaddafi was believing that Gaddafi was a normal human being. So personality counts in the big picture?

### Scientific Advocate (SA)
Claim: Personality counts because in any given time there are three or four or 10 heads of government around the world who are certifiably insane.

### Moderator
Claim: Ladies and gentlemen, Elliott Abrams.

### Scientific Advocate (SA)
Claim: Thank you. Thank you. Thank you all for being here. Listening to these presentations, here I am, batting cleanup here, and I’ve only got seven minutes to correct so many mistakes. You know the joke, the old, old, old joke about the guy who is looking for his keys under the lamppost and the man says to him, “Did you drop your keys here?” and the guy says, “No, but the light’s better here.” Why are we cutting the military budget? We’re cutting the military budget apparently because the military budget got us into the fiscal mess we’re in? Wrong, it didn’t. Let’s start with the fact that we are cutting the military budget already.

It isn’t as if we’re in a situation where these global wings are spreading, and the military budget is becoming a gigantic-- I mean, Defense News, February, "U.S. Air Force Budget Shrinks." The Air Force, since we’re talking about wings, has been shrinking decade after decade. Armed Forces Journal, "Tactical Inventory of the Air Force is as Small Today as at any Point Since World War II." Many of you no doubt read every morning the website entitled, “War is Boring.” It exists. And it's said of the 2010 budget, the new budget includes cuts and additions. The Air Force took the biggest hits. Now, if you’re going to clip our wings, and in fact many of those wings are being clipped, you have to make some assumptions about the world. You have to assume that there will be no war on the Korean Peninsula.

You have to assume there'll be no war between Israel and Iran. You have to assume absolute stability in Asia despite the rise of China. You have to assume no 9/11 attack on the United States again, that we wish to respond to. Are you absolutely confident about all of that, confident enough to reduce American power, that in one, or two, or five, or 10 years we may need? You know, the person who summed this up best was actually President Obama in his Nobel speech. “The world must remember that it was not simply international institutions, not just treaties and declarations that brought stability to a post- World War II world. Whatever mistakes we’ve made, the plain fact is this: the United States of America has under-- has helped underwrite global security for more than six decades with the blood of our citizens, and the strength of our arms. The position the other side is taking is a very radical position, I mean, well to the left of President Obama.

Now, we have been spreading our wings for some decades as Eliot mentioned. The world is a better place for it. Peter mentioned some of the places where it is a better place. Bosnia was, I think, the example he used. Take a look at Asia today. It’s an interesting thing. You don’t hear the South Koreans, the Taiwanese, the Vietnamese, the Singaporeans, the Indians saying, “Hey, it’s time to clip your global wings,” because they’re afraid of China. And they want our help in balancing a rising China. Look at Vietnam. Some of you will remember the Cam Ranh Bay Naval Base that we had during the Vietnam War. Now-- now, the government of Vietnam has asked us to come back. Their defense minister was quoted as saying, “This port should be a fuel stop for aircraft carriers.” Well, they don’t have any aircraft carriers. He means our aircraft carriers, that they weren’t stopping there to counterbalance China.

The idea that we need to diminish the size of our military-- let me quote from a famous American. Getting the Democratic nomination in 2004, John Kerry said, “I will never give any nation or institution a veto over our national security, and I will build a stronger military. We will add 40,000 active duty troops.” That’s John Kerry. These guys are taking a position well to the extreme on these questions. Now the finances. “We have to cut the military budget because we’re broke.” Bill Clinton’s budget director, Alice Rivlin, wrote last week-- last month, excuse me-- quote, “Defense spending is not a cause of the growing projected deficits. It’s the entitlement programs that drive future spending up faster than GDP can grow.” Clinton budget director.

The deputy secretary of the Treasury for Bill Clinton, Roger Altman, “Imperial overstretch is not the real issue here. It is fiscal, economic, and political failures at home that are threatening the ability of the United States to exert global influence.” The defense budget has been falling as a percentage of GDP for decades. It’s falling under four percent now. It is scheduled in the next five years to go under three percent of GDP. So what’s the argument they’re making? Really, it’s ideological. American power is bad. Well, that’s not exactly the argument. Peter tells us American power in Bosnia was good. So I guess what it comes down to is this: When is American power bad and when is American power good? Just ask them. And they’ll tell you where we need to intervene and where we don’t. Doesn’t work. If the United States is going to reduce our global wings, if we’re going to reduce our power, we’re going to put ourselves in a situation where we cannot do what we need to do around the globe.

Now, who benefits from this? Who benefits? Who benefits if there are more Srebrenicas and Darfurs and Rwandas? The answer is people like Gaddafi and Milosevic and Bashar al-Assad and Saddam Hussein. They benefit. We do not and the people who depend on us and our power for their safety in a very dangerous world, 300 million Americans and hundreds of millions more around the globe. We’ll lose. Do not buy this picture of America that doesn’t exist, with a people and a military and a president just lusting for intervention everywhere, and a military budget that must be decimated if we are to be safe. On the contrary, if we are to be safe, and if the world is to be safe, those global wings need to be strong. Thank you.

## Round 2

### Moderator
Claim: Thank you, Elliott Abrams. That concludes round one of this Intelligence Squared debate where our motion is "It's time to clip America's global wings." Now we want to have you keep in mind how you voted again at the beginning of the evening because at the end of the arguments, we’re going to have you vote again. And the team that has changed the most minds will be declared our winner. Now on to round two where the debaters address each other directly and they also answer questions from the audience and from me. We have two teams of two here at New York University’s Skirball Center for the Performing Arts. We have Peter Galbraith and Lawrence Korb who are arguing for the motion, "It's time to clip America's global wings." They’ve been making the argument that America is drastically overreaching. It’s essentially a pragmatic argument, that we cannot afford to overreach much longer. Their opponents, Eliot Cohen and Elliot Abrams, are making somewhat more of a moral argument. They're saying that the U.S. has always been a global power.

And when it has chosen not to be so, somebody usually ends up paying in the end. I want to put to the team that's arguing for the motion. Now, your opponents are essentially saying, if we can be involved globally, if we can, we should. Your argument is more, we can't, so we shouldn't. It's about-- it's about, you're putting it in terms of a price tag, or that's certainly how it's sounding to me. And if I'm wrong, I'd like you to correct it. But your opponents are also saying that you just basically find beyond that the use of U.S. power somehow distasteful. Peter Galbraith.

### Conspiracy Advocate (CA)
Claim: Well, I'm looking for the elephant here, the elephant in the room, because we just had a discussion from the opponents of this motion that didn't discuss Iraq and Afghanistan which are the two major projections of American power, the two major expenditures in this millennium.

Okay, this century, if you don't want to be too ambitious. The problem with them is that they have ended up weakening the United States. Certainly the Iraq war caused America's prestige, which was sky high after Bosnia and Kosovo to collapse. Turkey, we went from an 80 percent approval rating to a six percent approval rating in the second largest country in NATO. We have ended up empowering Iran. You will recall President Bush describing an axis of evil, of Tehran and Baghdad. They were bitter enemies--

### Moderator
Claim: But, Peter, are you arguing the principle is the issue or the execution is the issue?

### Conspiracy Advocate (CA)
Claim: It is the execution. It is that we try to do things that we can't do. We tried to--

### Moderator
Claim: But your opponents are making an argument about principle.

### Conspiracy Advocate (CA)
Claim: Well-- look, they are the George Bush administration, what they represent is probably the most ambitious idealistic American administration. But they didn't succeed.

### Moderator
Claim: Okay. Let me have--

### Conspiracy Advocate (CA)
Claim: It can't work.

### Moderator
Claim: --one of the Elliotts come in. Eliot Cohen.

### Scientific Advocate (SA)
Claim: I think if you-- by the way, if you notice, the only president we were quoting was Barack Obama.

### Conspiracy Advocate (CA)
Claim: Well, I understand why you wouldn't want to quote Bush.

### Scientific Advocate (SA)
Claim: Well, right.

### Conspiracy Advocate (CA)
Claim: That's understandable.

### Scientific Advocate (SA)
Claim: With whom we agree on basic principles. And the fact is we didn't talk about Iraq. That was not the topic that was given. And in fact, I think you can think that the Iraq war was a stupid idea, as Barack Obama does, and still think that this is a bad idea.

### Conspiracy Advocate (CA)
Claim: Yeah, but how bad an idea could it have been?

### Moderator
Claim: Eliot Cohen.

### Scientific Advocate (SA)
Claim: You supported it, sir, in 2003. So you don't--

### Moderator
Claim: You're pointing to Lawrence Korb.

### Scientific Advocate (SA)
Claim: No. I'm pointing at Peter Galbraith.

### Moderator
Claim: Peter Galbraith.

### Conspiracy Advocate (CA)
Claim: But let me say something here. Let me say something here.

### Scientific Advocate (SA)
Claim: What's the argument?

### Conspiracy Advocate (CA)
Claim: What we're talking about here is-- and you mention my Republican thing-- the way the Republicans always look at cost benefits.

You want to quote someone? Let me quote one of your colleagues, Fukiyama, who wrote the book, “The End of History” and talked about--

### Scientific Advocate (SA)
Claim: He's not a Republican, by the way.

### Conspiracy Advocate (CA)
Claim: He was one of the--

### Scientific Advocate (SA)
Claim: And neither am I, actually, for the record.

### Conspiracy Advocate (CA)
Claim: --supporters of the war. But you know, Frank said-- and he supported the war, he said, if you had told the American people in 2003, we're going to go to war in Iraq, and we're going to have almost 5,000 Americans die, 30 to 40,000 wounded, hundreds of thousands of Iraqis die, spend over a trillion dollars so Iraq could have an election, you would have been laughed out of the ballpark. You've got to have select-- I remember growing up in New York City at the time of the Polish and Hungarian revolutions. And you had a lot of people from Eastern Europe here. And basically, they wanted the United States to do something. How can you stand by? I remember pictures of Cardinal Mindszenty on the head of The Daily News, "We've got to do--" no. Eisenhower made a calculation. When they wanted them to bail out the French at Dien Bien Phu.

General Ridgway came to them and said, “Hey, here's the cost.” He said, “Forget it. Bedell Smith, go to”--

### Moderator
Claim: All right. Let me go to the other side. What you're hearing is an argument that lots of time the U.S. has chosen not to get involved because--

### Conspiracy Advocate (CA)
Claim: Oh, sure.

### Moderator
Claim: --of the cost. Eliot Cohen-- Elliott Abrams.

### Scientific Advocate (SA)
Claim: One of the causes in the world that I do care about a lot is Tibet. I'm not urging us to go to war with China over Tibet. We can’t do it. It would be foolish. But Peter, in 2003, supported the war for the right reasons, I mean morally, the right reasons. What he said was he thought there would be just massacres in Kurdistan, and there would be massacres of the Shia, and indeed, there had already been. Those are, I think, morally compelling arguments for why we did what we did. And we avoided those massacres. And in fact, the Kurds are doing very well now, and there is a Shia majority government, democratic government in Iraq. I also don't accept the view that the Iraq war has been lost.

It wasn't lost in 2007, wasn't when you said it was. Wasn't lost in 2008 or '9. It isn't lost now. It may be too soon to say what the final outcome in Iraq is going to be, but it certainly isn't lost. But I just don't understand how you can say, no, it was-- it would have been right to just let the Kurds and the Shia be slaughtered by Saddam Hussein. And, by the way--

### Moderator
Claim: Well, let me let Peter Galbraith reply directly to that because you worked with the Kurds quite a bit. What about that?

### Conspiracy Advocate (CA)
Claim: Well, there's no doubt that the people-- the peoples of Iraq-- because there isn't such a thing as an Iraqi nation. But that the peoples of Iraq, 80 percent of whom are either Kurds or Shiites have emerged much better off. And possibly, if we had gone in, gotten rid of Saddam Hussein and gotten out, if we hadn't undertaken the Bremer multibillion dollar occupation where we had people-- sent young people in there with no experience to run the Iraqi budget, to draw up the traffic plans for Baghdad, that's how ambitious we were.

We were doing American traffic plans for Baghdad. You know, but we'd gotten rid of Saddam, gotten out, it might have been a rather different history. But you cannot say that this was worth nearly a trillion dollars, especially when it meant that Iran, which had been intimidated in 2003-- its nuclear program was on hold-- had become emboldened in part because its best friends were now running Iraq. And North Korea took advantage of this to get a free pass. I think all of us would agree that proliferation--

### Moderator
Claim: Was it worth a trillion dollars? Eliot Cohen, can you speak to, was it worth a trillion dollars?

### Scientific Advocate (SA)
Claim: So let me get this straight. If we invade Iraq, we depose Saddam Hussein and leave, that's an America whose global wings have been clipped, which is a good thing.

### Conspiracy Advocate (CA)
Claim: No, we shouldn’t--

He was contained.

### Scientific Advocate (SA)
Claim: That just-- that just makes--

That just makes no sense.

### Moderator
Claim: Wait, wait. Let Eliot finish.

### Scientific Advocate (SA)
Claim: We'll come back to your point, by the way.

Since when I was in government, I was looking at the intelligence on the Iranian parliament. It is very curious how they stopped their war head design program immediately after a major geopolitical event that occurred to their West. And that may have had a passing connection with it.

### Moderator
Claim: Lawrence Korb.

### Conspiracy Advocate (CA)
Claim: And they started it back when they saw how incompetent we were, the kind of investment we were making--

### Scientific Advocate (SA)
Claim: We-- we're losing confidence is better than incompetence.

### Moderator
Claim: Lawrence Korb.

### Scientific Advocate (SA)
Claim: That's not the topic being debated.

### Conspiracy Advocate (CA)
Claim: I think-- and we get back-- look, there's a lot of evil in the world, and you have to decide whether the potential benefits are worth the costs that you have to pay. And that's why if you had told the American people that in the beginning, regardless of the outcome, you never would have gotten support. If you had asked people to raise taxes and to have a draft, which we should have done because of the fact that we overworked a lot of these young people, sent them back-- when I was in government, we got the voluntary military going.

We made a compact with the young people. For every year you spend in the combat zone, you get at least two years at home. It didn't work. Okay, you got 500,000 people, according to RAND, who have mental problems because of being over-deployed.

### Moderator
Claim: If you took Iraq and Afghanistan out of this equation, Peter Galbraith, where do you disagree with the other side?

### Conspiracy Advocate (CA)
Claim: Well, I'm in favor of a more limited role where we have allies intervening where-- if we are to intervene, to intervene where we have allies, generally consistent with international law, where there are partners on the ground. I think there are circumstances--

### Moderator
Claim: And you think your opponents are for what?

### Conspiracy Advocate (CA)
Claim: Libya is another.

### Moderator
Claim: But you think your opponent's position is what then?

### Conspiracy Advocate (CA)
Claim: Well, they don't want to talk about Afghanistan and Iraq and this very expansive nation- building enterprise in which both of them were-- administration in which both of them were very intimately involved.

Now, if their position is that they are also in favor-- you know that they will never do that kind of thing again, and that they'll clip America's wings because we're not going to try-- and we'll get out of Afghanistan or reduce our forces to something that's commensurate with an achievable mission, then maybe we're on the same wavelength. Are they in favor of the hundred thousand dollar mission--

### Conspiracy Advocate (CA)
Claim: A hundred thousand dollar mission in Afghanistan?

### Moderator
Claim: But, Peter, let Elliott Abrams come in.

### Scientific Advocate (SA)
Claim: Here's the problem with that. First of all, you guys disagree about Iraq because Peter correctly, in my view said, you know, if we had been able to go in, depose Saddam Hussein, save the Kurds and the Shia and then, in your view, get out, that would have been worth doing. Now, how in hell do you go into Iraq and depose Saddam Hussein in three weeks with your clipped wings? You can't do it. You need to maintain the military that Larry doesn’t want us to maintain in order to achieve exactly that goal.

### Conspiracy Advocate (CA)
Claim: Wait, wait. Wait a second.

### Moderator
Claim: Larry Korb--

### Conspiracy Advocate (CA)
Claim: We went in with--

### Moderator
Claim: Okay, Larry Korb.

### Conspiracy Advocate (CA)
Claim: --Bill Clinton's military, the one you said wasn’t big enough. It wasn’t Bush's military that went in.

### Scientific Advocate (SA)
Claim: It was John Kerry, I'm sorry.

### Conspiracy Advocate (CA)
Claim: And we were spending on defense, about half on the baseline of what we’re spending now. And we marched through Baghdad in three weeks.

### Moderator
Claim: Could I make a request in this debate that this not become Republican-Democrat, and that, that old-- that old shape-- Okay? Not to say that the wars we’re talking about are not material, but I don’t want to go down that old ground. I think we’re talking about something fairly important here and I think we are talking about principles. And it does sound to me as though these two sides agree on the broad principle that the U.S. has a role in the world, wants to try to influence events. Both sides are agreeing on that, and I’m beginning to wonder where the essential disagreement really is unless you are saying it just costs too much on this side and on your side I’m not sure what your comeback is to that.

### Scientific Advocate (SA)
Claim: It doesn’t cost too much. The fact is that--

### Moderator
Claim: Elliott Abrams.

### Scientific Advocate (SA)
Claim: --the percentage of GDP that we are spending on defense continues to decline. What is going up in this country, and I think everybody here knows it, is entitlement spending, and that is what has tied the Congress in knots, because there are very few politicians in either party bold enough to deal with entitlement spending. We are not broke because of the military budget.

### Conspiracy Advocate (CA)
Claim: Now wait a second, wait a second. Let’s go back and take a look. You look at the discretionary budget, the budget that doesn’t deal with entitlements, things that people have earned, like military retirement, these thing-- if you look at discretion-- defense is half of the discretionary budget. And right now the politicians of Washington have frozen nondefense discretionary. That’s not going to help, I agree we need to take a look at the other things. I mentioned President Reagan in 1983 worked on it. But the fact of the matter is you don’t just ignore half of the discretionary budget, particularly if you cut it.

And you mentioned Alice Rivlin. Did you read the report of the Domenici-Rivlin Commission?

### Moderator
Claim: No.

She said cut $100 billion in defense by 2015.

### Moderator
Claim: All right, I want to go to the audience for some questions in a moment. I’d like you to prepare your questions, again, terse questions that have a question mark at the end, and to the point of the debate, and microphones will circulate and when you’re chosen and a microphone comes to you, please stand up and hold it about a fist distance away from your mouth so that the radio audience will be able to hear you clearly. But I want to take one more shot at this issue of whether we’re really talking about execution and price tag only, if in a fantasy world, and it may be therefore irrelevant, if we had unlimited resources, would that mean to the side that’s arguing for clipping America’s wings, carrying your argument out, that our limitation is financial only if we didn’t have that limitation, would you be for doing all kinds of zany stuff out there?

### Conspiracy Advocate (CA)
Claim: Well, Afghanistan is the perfect case in point, and this is probably an issue in which we have a very concrete ongoing difference. In Afghanistan we have 100,000 troops, $117 billion committed to a strategy which cannot work because it-- the essential element for success which is an Afghan partner does not exist. So we don’t need to-- and yet I suspect they would continue this. Well, why don’t we put it to them?

### Moderator
Claim: Yeah good question.

### Conspiracy Advocate (CA)
Claim: I mean, how do you make a counterinsurgency work when you don’t have a partner?

### Moderator
Claim: Eliot Cohen.

### Scientific Advocate (SA)
Claim: First I wouldn't say that we don’t have a partner, I mean we have a weak partner. If we had a strong partner there wouldn’t be an insurgency because these things are basically about governance. And do I think we’re going to be there for a long time? Yes. Do I think we had any choice about going in there? No. Remember, this was the good war. This is the war that everybody I dare say including both of you were in favor of in 2001.

And it is the problem that Elliot has pointed out which is correct, once you go in there-- so what exactly are you going to do, are you just going to sort of leave the thing in chaos and not do anything? Now we can argue back and forth about did we do the smart thing, did we do the stupid thing, should we have backed somebody other than Karzai, should we have organized that place differently, should we have had different ambassadors? That’s not the point. The point is this proposition about clipping America’s global wings. By the way, I cannot imagine Ronald Reagan ever signing up for that sort of proposition. And as long as I have the floor, one other--

### Moderator
Claim: For about 10 seconds,

### Scientific Advocate (SA)
Claim: --tell me how cutting the defense budget by $100 billion makes all the fat people out there lose weight-- increases life expectancy and gets the kids away from Nintendo and into the calculus books. I don’t get it.

### Conspiracy Advocate (CA)
Claim: Now, let me come back--

### Moderator
Claim: Lawrence Korb.

### Conspiracy Advocate (CA)
Claim: Let me make a point here, because I agree. We went into Afghanistan. The problem was and this is what I’m talking about, clipping your wings, selective engagement. You didn’t finish the job in Afghanistan. You diverted your attention to Iraq.

And you allowed Afghanistan to deteriorate. I agree, Afghanistan was the right war. And, in fact, I commended President Bush because he told-- in the beginning, he said to the Taliban, “You turn over al-Qaeda, we’ll leave you alone.” They didn’t, so we went in. We had to. The problem was, within months, we started diverting our attention to Iraq, which was not a critical issue, had nothing to do with 9/11. Back when Eisenhower was president, we were spending 10 percent of the GDP on defense, we didn’t go into Vietnam.

### Moderator
Claim: One more thing before we go to audience questions. Eliot Cohen, you said earlier that you feel your opponents basically think that power is bad, but I’m not hearing that from them at all. I’m sorry, Elliot Abrams-- was it Elliot Abrams that made that point about--

### Scientific Advocate (SA)
Claim: Yes. We’re practically interchangeable.

### Scientific Advocate (SA)
Claim: Just for the spelling, but other than that--

### Moderator
Claim: So, I’m not hearing that.

### Scientific Advocate (SA)
Claim: If you find that the defense budget is not killing our economy, and I think it’s ridiculous to urge that it is, then why are we doing this wing-clipping stuff?

What is it we’re trying to stop? The only word I’ve heard is nation-building. Now, you know, we did nation building in Germany after World War II. We did it Japan after World War II. We’re trying to do it in a number of other places. Generally, people are ending up a lot better off after we try to do the nation-building. So I think ask myself, well, if we’re trying to build democracy-- this is Colin Powell’s old “you break it, you bought it,” the Pottery Barn rule-- we go into the country and we say, “No, we’re not going to depose the head of government and leave it a shambles. We’re going to try to help them build a decent country here and build a democracy.” That’s a good thing to do, and I must say I don’t understand the argument except financial for saying--

### Moderator
Claim: But I’m still not hearing you respond to your earlier statements that this team actually is uncomfortable exerting American power. That’s what I-- it sounded like you’re saying it, and yet I don’t think that that’s any--

### Scientific Advocate (SA)
Claim: If they are comfortable asserting American power, then I think their argument simply falls apart or becomes just a sort of financial argument, that we would love to run the world, but, you know, we’re broke this year.

### Conspiracy Advocate (CA)
Claim: No, no, no, no. We’re not saying that. We’re saying trying to run the world does cost you a lot of money that you don’t have to spend. And, even if--

### Moderator
Claim: But you’re good with running the world.

### Conspiracy Advocate (CA)
Claim: If you had all the money, you got to look at selective engagement. You cannot save the world, okay? There are a lot of problems in the world that you can’t deal with that you have to live with. You ask me what’s the most dangerous place in the world? Pakistan. All right? You want to send troops into Pakistan? Okay? You’re not going to do that. And, again, you should have thought about that before you went into, you know, you went into Iraq and took your eye off the ball in Afghanistan.

### Moderator
Claim: All right. Let me go to some questions. And there’s a gentleman-- I’m looking right-- yes, and you gestured correctly. If you would stand, sir, and give the camera four seconds to find you, and it has.

And, again, if anyone is asking questions is a member of the media, we’d appreciate you identifying yourself. Just do us a favor. But please, go ahead.

### Moderator
Claim: Yes, I have a question for Mr. Abrams. Doesn’t the law of unintended consequences rear its head, for example, in Somalia we went in to restore order, and we wound up with Black Hawk Down and the troops being dragged through the street. We funded the mujahedeen in Afghanistan. That turned out to be al-Qaeda. You mentioned Rwanda. You had two African tribes hacking each other up with machetes. Do you really want to send American troops into these places when, frequently, it turns-- it backfires to our detriment?

### Moderator
Claim: Do you think those were overreaches of power?

### Moderator
Claim: Well, obviously, you have-- basically, you judge a situation by what happened, by the consequences, not by what was intended. But, obviously, in those situations--

### Moderator
Claim: By the outcome.

### Moderator
Claim: We downed it to our detriment.

### Moderator
Claim: All right. Elliot Abrams.

### Scientific Advocate (SA)
Claim: The question of unintended consequences is a very important question.

And you can cite a number of examples where we-- for over 50 years, where we did something wrong or foolishly or incompetently. But take Rwanda, your example. There are hundreds of thousands of dead people in Rwanda because we did nothing. And Bill Clinton has said it is the greatest regret, he has said, about his presidency, that he did nothing to stop it. Now, the repertoire is large and doesn’t only include sending in the Marines. We have no marines in Libya, but we are intervening in a way that is meant to do some good, and with which I agree. So, yeah, you’ve got to-- I guess the argument is, yes, you need to be very careful whenever you commit American troops. You need to be very careful even if you’re not committing American troops. You’re committing American prestige and money. But I don’t think that can be an argument for inaction. It can’t be an argument for saying, “We don’t really know what’s going to happen tomorrow in Srebrenica. Let’s not go in. We don't really know if Saddam Hussein will massacre the Kurds.

Let's leave it alone. It takes you too far.”

### Moderator
Claim: Peter Galbraith, you want to follow on that as an opponent?

### Conspiracy Advocate (CA)
Claim: Well, I think the question of the mujahedeen in Afghanistan's a very good one because we simply allowed the Pakistani dictator, Zia-ul-Haq under the Reagan administration, to decide who to fund. And he funded the most extreme elements. And we are now living with the consequences of that. I want to come to the question of, you know, should web in the business of nation building, building democracies? Yes. We had an interest in removing the Taliban. We had an interest in trying to kill or capture al-Qaeda. What interest did we have in trying to build a strong central government in Afghanistan, a place that has never had one and will not have one in the lifetime of anybody sitting in this room, even young people?

### Moderator
Claim: Okay. I--

### Conspiracy Advocate (CA)
Claim: What interest did we have in--

### Moderator
Claim: Peter, I'm going to interrupt because that was a self-asked question, and I'm-- I'm wanting to really hear from the audience in this.

But that doesn't mean you can't get to that in your closing remarks. Let me just go to the far side here. And there's-- yeah. You have a colorful sleeve. You're welcome. And if you could stand up, they'll find you. Could you stand? Thanks.

### Moderator
Claim: Yeah, I'd just like to ask, you're talking about cutting-- to Mr. Abrams-- about cutting entitlements as one way to deal with America's deficit problem. But not a single one of the panelists tonight has talked about tax extensions or tax breaks to the super wealthy or to--

### Moderator
Claim: All right. Lovely question.

### Moderator
Claim: And that is a huge hole in this argument.

### Moderator
Claim: And stay tuned for a future debate from Intelligence Squared U.S. on that topic. Thank you. I really want to stay on the power clipping issue.

### Moderator
Claim: --taxes to support the war.

### Moderator
Claim: Sir, there's a-- a little farther back, three back. If you could stand, thanks.

### Moderator
Claim: President Eisenhower spoke of the military industrial complex.

And as long as we have so many people in the military and government and in business interested in creating such a great military industrial complex, won't we continue to be in these kinds of wars and have these kinds of--

### Moderator
Claim: But how would you relate that, sir, to our motion about clipping--

### Moderator
Claim: Well, I think part of the reason we're not clipping America's global wings is enough people are interested in keeping the military. And once you-- you have a large military, somebody's going to use it.

### Moderator
Claim: All right. I'm going to let that stand as a comment because it's not quite to our point. Ma'am in the blue-- teal, the teal. Is that teal? Did I get that right?

### Moderator
Claim: Huge number of-- I'd like to commend the lady over there for having questioned the attack on entitlements.

I believe Mr. Abrams spoke about the Marshall Plan having been a very constructive thing. What about a Marshall Plan for the American people who are now suffering--

### Moderator
Claim: Okay. I'm going to let that stand as a comment as well. It's clear that we know what your view is. Folks, really-- I really want you to try to bring it in, just to land these things perfectly. Sir, blue Blazer, yeah.

### Moderator
Claim: Yeah, hi. I think to the point, I don't know if--

### Moderator
Claim: Thank you.

### Moderator
Claim: Yeah, I don't know if the story is true, but I've heard that Benjamin Franklin apparently wanted the turkey to be our national bird. But we chose instead the eagle, a bird with strong wings. And I think the argument can be made that America without strong wings is simply not America.

### Moderator
Claim: You think it's an identity issue literally?

### Moderator
Claim: I think it has to do with who we are and why we're here.

### Moderator
Claim: All right. Do you feel that this--

### Moderator
Claim: The question is, I think the argument is being made strongly that perhaps we should be-- we should not be stupid in how we use our strength and our wealth and our forces. We should be smarter about how we do it. But can you really argue that America should clip its wings as opposed to simply being smarter and more efficient about how we use--

### Moderator
Claim: Lawrence Korb. And that's such a great question. And don't miss it, okay?

### Conspiracy Advocate (CA)
Claim: Since you used a metaphor here, there's a great book written by a professor here at this wonderful university, Peter Beinart. It's called “The Icarus Syndrome.” And he said throughout our history, we get carried away thinking that because of who we are we can solve all the world's problems.

And he goes back, and he talks about Vietnam where we went in, we thought the domino theory and all of that type of thing, found out we even-- when our economy was much better, we still could not achieve the objective that we wanted. And that's what-- you used the term, you've got to be smart about it, there are certain things you've got to do, other things you realize that they're beyond your capacity. And I think that's the key thing. Now, at this particular time, we talk about the fact that defense has nothing to do with it. No. We added $2 trillion to the deficit in the last decade because of actions that happened from 2001 to 2008, okay? If we had those $2 trillion, the other problems would not be as bad. And so that's the point I'm making.

### Moderator
Claim: All right. Let's hear from your opponents on this topic, Eliot Cohen.

### Scientific Advocate (SA)
Claim: On the-- on the eagle, the national seal has the eagle clutching arrows and olive branches. And originally, the eagle pointed at the arrows. And Harry Truman welcomed Winston Churchill to the White House.

And he very proudly pointed to him that he'd redesigned the seal so that the eagle's head looked at the olive branches. And Churchill said-- wise thing. He said, "You know, my view is the eagle's head should be mounted on a swivel." So it can look either at the olive branch or at the arrows as is necessary. He didn't say anything about clipping the damn bird's wings.

### Moderator
Claim: Thank you, sir, for the question. With the program in your hand, arise, and a microphone will find its way to you. Question.

### Moderator
Claim: The side in favor of the resolution has talked about a lot of interventions in retrospect and the cost and how we have allies that aren't accountable or are corrupt. And I want to know from both sides what criteria you think the American public ought to use right now to determine which interventions are acceptable, which ones are not?

### Moderator
Claim: What are the rules, in other words? Can you-- I'd like to ask you-- I'd like to ask you each to answer this excellent question in-- no, seriously, but in a bullet format.

I'd just like to hear your list from each side, what it takes. And I know that, Peter, you actually touched on some of it earlier. But either of you can take it and tell us the four or five most important elements.

### Conspiracy Advocate (CA)
Claim: I was-- I'm glad you asked the question because I was just writing down some bullet points on exactly this. First, I think when we intervene, it's very important that we operate with the vision of the people on whose behalf we are intervening, not ours. I think that's my main critique of what we've done in Iraq and Afghanistan. Why did we want to disassemble Kurdistan and Iraq? It worked. Why build a central government? But that would, to me, be the most important point. Second--

### Moderator
Claim: And what else?

### Conspiracy Advocate (CA)
Claim: Defer to the judgment of others, including in the international community, the U.N., our allies. Don't go it alone. And finally, I would take a count of the costs and the benefits. When we intervened in Bosnia, it was a-- yes, it was by air, but it was for a short period of time, relatively inexpensive incidentally, and all our interventions in both Bosnia, Kosovo, not a single American or NATO soldier died in hostile combat--

### Moderator
Claim: Okay. Let me go to the other--

### Conspiracy Advocate (CA)
Claim: And finally-- finally, as a Vermonter, I have to say, turkeys have very strong wings. We have lots of wild turkeys.

### Moderator
Claim: Now to this side.

### Scientific Advocate (SA)
Claim: Yeah. I--

### Moderator
Claim: Eliot Cohen, question.

### Scientific Advocate (SA)
Claim: First thing I think when you're talking about the use of force, the question is always, are we going to avoid something worse. And I think that it's important to be very serious about this. Using force is a terrible thing. You're going to kill innocent civilians. You're going to make mistakes.

You'll probably get some of your own people killed. And those are real people. Are you going to avoid something worse? That's really the fundamental reason why we do go to war, and we should go to war. Is this doable as far as we can-- as far as we can guess? And it is a guess. Is it in our self-interest? And is it in our broader interest as Americans? From the very founding of this country, we're caught between the tension between the same kind of interest that other countries have and our ideals. That's what it is to be an American. And it's incumbent upon our leaders to wrestle with that and to lay it out for us. But above all, at the end of it, don't think that any of us can come up with a set of rules which we can, you know, give you, and that's a sort of a decision making guide that any president can take with him or her to make a decision.

### Moderator
Claim: No, but the question did reveal a great deal with how the two sides think. And I thank you for it. And I want to take it one step further. I want you to respond to the list that you heard over there, and do you have any disagreement with it?

Or would you add his list to your list?

### Moderator
Claim: I would--

### Scientific Advocate (SA)
Claim: I would critical question here. And I think Elliott is right in saying when we intervene militarily, the chances are that some innocent people and some American servicemen and women will be killed. So the question is to what end? And if the answer is, I'm not sure, you don't do it. If the answer is, to save a million lives, or 500,000 lives, to stop Darfur, to stop Srebrenica, then the balance may shift.

### Moderator
Claim: Okay, and, Lawrence, can you respond to what you heard?

### Conspiracy Advocate (CA)
Claim: Well, I’m going to very quickly--

### Moderator
Claim: Lawrence, can you respond to their list?

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: Thanks.

### Conspiracy Advocate (CA)
Claim: I have very quick Multilateral if you can, unilateral only if you must. I think that's what you have to do, and you have to basically ask yourself that question and the same thing in terms of what you can't know exactly ahead of time but you can do a pretty good idea of the cost and the benefits and recognize that you don't just use the military to solve all these problems.

### Moderator
Claim: Okay, so that's your list. What's your response to what you heard from the other side? Would you-- do you agree with what they--

### Conspiracy Advocate (CA)
Claim: Well, my response to them is basically if you take a look at a lot of the operations we do, they haven’t done that ahead of time in terms of the cost and the benefits.

### Moderator
Claim: Guilty?

### Scientific Advocate (SA)
Claim: You have to take the point that Eliot made at the end, you can’t predict the future or at least you can’t predict it perfectly. You do the best you can, you use the best intel you can, you try to make the best guess as to what the costs will be and what the benefits will be, and sometimes you get it on the dime, and sometimes you’re way off.

### Conspiracy Advocate (CA)
Claim: According to Colin Powell--

### Scientific Advocate (SA)
Claim: Look, I--

### Conspiracy Advocate (CA)
Claim: --Bush never did that before he went into Iraq.

### Moderator
Claim: Eliot Cohen.

### Moderator
Claim: Never was

### Moderator
Claim: Eliot Cohen.

### Scientific Advocate (SA)
Claim: I’ve sat in NSC meetings and I know first that presidents take these issues very, very seriously, particularly when they're committing American lives. That was true of George W. Bush, was true of Barack Obama, it was true of Bill Clinton. I also know that none of these decisions are easy. They don’t get to that level if they were easy, and so there are always going to be-- there’s going to be an element of guesswork, and then an element of risk. The other thing, by the way, is we have really focused, because this is the preoccupation of the other team, on these high end interventions. There are other kinds of things. Let’s talk about the Sudan peace process, let’s talk about what’s been really quite a tremendous success in Columbia which has been an exercise of American power in many dimensions including the nonmilitary, this is not a debate about American military power, it’s America’s global wings, and those wings include a lot of nonmilitary elements which have been tremendously successful.

### Moderator
Claim: All right, we’re going to take a quick break. Our motion is, “It’s time to clip America’s global wings.” We’re going to take a quick break, and we’ll be right back with more questions from the audience.

So I’m going to ask you in a second to help assist coming back from the break in the radio broadcast and television broadcast to applaud, and once you do and as the applause dies away, I’ll reintroduce the broadcast and we’ll go back to your questions. So can I have a round of applause, please? Our motion is, "It’s time to clip America’s global wings." This is a debate from Intelligence Squared U.S. I’m John Donvan of ABC News. We have two debaters, two teams of two, debating this motion, "It’s time to clip America’s global wings." We are taking questions from the audience. The man in the blue shirt, you’ve been very patient.

### Moderator
Claim: Oh, I’m sorry. You know, everybody in the audience could’ve stood up at that point. I’m sorry.

### Moderator
Claim: I grew up as a child in Africa surrounded on one side by Cubans and on another side by Russians, who were spreading their wings, and the one safe thing we always felt as children was, we had the United States, and we were enfolded within its wings.

What would you feel if we clipped the wings with Russia now, with-- I beg your pardon-- China now spreading its wings, and you now clip your wings, how secure would everybody feel?

### Moderator
Claim: Do you-- and I want to clarify-- do you feel that that’s the argument that this side, arguing for clipping wings, is making?

### Moderator
Claim: Yeah, I feel--

### Moderator
Claim: You do, that they’re putting you at risk?

### Moderator
Claim: I feel they’re putting us at risk.

### Moderator
Claim: All right, I want to take that question to the side that’s arguing for clipping America’s global wings.

### Conspiracy Advocate (CA)
Claim: Let me go--

### Moderator
Claim: Lawrence Korb.

### Conspiracy Advocate (CA)
Claim: I think you raise a great point. China is gaining because we’re bogged down in Afghanistan. They would love us to be there forever, keep spending all of this money and help their a foreign policy objectives. They’re a free rider in the Middle East. We’re doing-- what’s China doing? Sitting back and taking advantage of it. So I think our point is that, you know, when you say clip your wings, you’ve got to work with the rest of the community.

We can’t have too many free riders. It’s very interesting when the deficit came up in Britain and France, they cut their defense spending. They cut it. And then, of course, who has to pick up the thing? We do. Well, I’m glad that President Obama said, “Wait a second. You have more interest in Libya than we do.” And I’m glad that the international community did it. So, I think you’re going to look at China. They’re doing great because they’re a free rider.

### Moderator
Claim: Sir, can you-- I just want to ask you about your response to their response, but briefly.

### Moderator
Claim: I feel that China has got such great ambitions and they’re now growing their military, which was on TV just the other day, that to send the message that America’s going to start clipping its wings is going encourage them to go into places they wouldn’t normally even think of going to.

### Moderator
Claim: All right. Let me come to the other side. Eliot Cohen.

### Scientific Advocate (SA)
Claim: A couple of months ago, I had 10 days in Japan before the awful events of the tsunami and the reactor incident. And the main thing we were talking about, particularly with the defense and foreign policy people are these little islands called the Senkakus, which have been Japanese territory for a very, very long time. The Chinese have a claim. And, of course, it’s not so much that they care about the islands. They care about the territorial waters and so forth. And the Japanese are under a lot of pressure, and they are actually quite fearful about the possibility of a Chinese grab for those islands. By the way, the Chinese really do say, “That water is ours.” Japanese do not – then most certainly do not want to see America’s global wings clipped. And I assure you that today they want it even less, when 18,000 American servicemen and women, 22 warships of the United States Navy are helping that country deal with the worst catastrophe that it’s faced since World War II. And a good thing.

### Moderator
Claim: Peter Galbraith, do you want to respond to that?

### Conspiracy Advocate (CA)
Claim: Well, the problem is that national security resources-- money, troops-- are not unlimited. And so you have to make choices. And if you make choices to deploy them in Afghanistan in pursuit of a strategy that, on the face of it, isn’t working, those resources are not available to deal with other threats or other national security issues, be it China, be it North Korea, be it Iran. And so, when we talk about clipping America’s wings, what we’re really talking about is not making-- removing American from the world stage. We’re talking about moving away from very ambitious exercises in nation building-- Afghanistan, Iraq are two cases in point-- to a selective use of power so that we can-- a selective use of these scarce resources so that we can focus on the real challenges. That’s all.

### Moderator
Claim: You know, the gentleman with the red sweater, you wanted to ask a question because you had a blue shirt. I just felt I got you up there, I sat you down--

But I hope it’s a good question.

### Moderator
Claim: If we refuse to clip our wings in any way, shape, or form, if we insist on American adventurism, then why don’t we simply tax everybody on a pay-as-you-go basis and say, “These are the choices that you’ve made. You must pay for it at the end of every year.”

### Moderator
Claim: I’m going to let--

I’m going to let that stand as an interesting comment, which it is, but I don’t think it actually moves our discussion. Sir, yep, yep, you just touched it-- could you stand up please?

### Moderator
Claim: Hi, thank you. Thank you all for being here. I just thought to myself, geez, the last 50 years we’ve borrowed a lot of money to kill people in wars. And here we are, 2011, and we’re borrowing money to keep our own people alive here in the U.S.

It’s crazy. In any case, I believe that we can clip our wings in defense, but we can expand our wings in technology and alternative energy. Would any of you be opening to maybe clipping wings in defense or, if you’re not open to it, maybe the bond market may be open to it, but let’s expand our wings with new entities, new enterprise, and move away from this consistent defense increase year over year. Thank you so much. Thank you.

### Moderator
Claim: Peter Galbraith.

### Conspiracy Advocate (CA)
Claim: I think you make actually quite an important point, which is that we’ve had this go-it- alone policy in the world, which has been very expensive as Larry Korb has made the point. We’ve had a lot of free riders on it. And the end result has been diminishing, particularly in the last-- in the previous administration, diminishing America’s influence in the world.

And so one of the ideas of not doing these kinds of things, being selective, having a sensible defense budget is we might actually be able to devote resources in ways that would increase our influence in the world. You know, we were totally isolated on the issue of global warming. Everybody else recognizes this as a problem. But the previous administration didn't. Now, you know, the U.S. is back in the mainstream. We didn't need to pull out of Kyoto. We could have consulted. And there are all sorts of other issues, free flow of technology, things that are very much in our interest where, if we go it alone, other people aren't just-- aren't going to go along with us.

### Moderator
Claim: Interesting point that you bring up. I want to bring it to the other side, that you're arguing that the expansion, let's say, the opposite of clipping wings, the laissez-faire attitude towards wings, leaving the wings alone, they're actually saying that your argument for power actually might reduce American influence and power.

### Scientific Advocate (SA)
Claim: I don't think that-- once again, there are hundreds of millions of people around the world who rely on American power for their safety. I mentioned, for example, the view Eliot mentioned it again, the Japanese.

### Moderator
Claim: But you made that point before. I-- but Elliott, can you tell-- to their point that they're saying that there's a diminished-- more than diminished returns, that the expression of power--

### Scientific Advocate (SA)
Claim: Is a weaker--

### Moderator
Claim: Is diminishing U.S. influence

### Scientific Advocate (SA)
Claim: A weaker American military is going to hurt the influence of this country. Another thing that's going to hurt the influence of this country is if we are fiscally irresponsible, and we are broke, and we are borrowing billions and billions of dollars. But I don't know what else I can do except to quote all those wonderful Clinton officials who say it isn't the military budget that is exploding. It is the entitlements that are exploding. Nobody wants to hear that, but it's a fact. And we have to deal with it. Least of all, do politicians in Washington want to hear it. That's what we need to deal with to make our economy sound.

### Moderator
Claim: Sir down in the second row.

### Moderator
Claim: I have a question for the Elliotts, both spellings. And I just don't want to one word answer here. In your unclipped and unclippable world, do you think we should send ground troops into Libya? After all, we want him gone, and it will save lives.

### Scientific Advocate (SA)
Claim: I guess my own view on Libya is actually we should have pushed a lot harder when Gaddafi was falling. If the president is going to say that it's our objective to get rid of him, that we better be very serious, I don't think we have to commit ground forces in the sense of, you know, infantry brigades. I do think if you want those-- the rebel forces to succeed on the ground, you probably need to send in the kind of special forces that we have who are good at kind of training and developing local forces, which is sort of what we did to the Taliban. And my guess is that would be enough. If you're also willing to commit the air power to it as well.

It's a NATO operation, by the way, as is Afghanistan I have to point out.

We've gone it alone. I visited German soldiers, British soldiers, Canadian soldiers, Norwegian soldiers, for that matter, New Zealanders, Australians and Danes in Afghanistan.

### Moderator
Claim: Okay. Let me--

Let me get the question to Lawrence Korb about Libya. Would you--

### Conspiracy Advocate (CA)
Claim: No. And I think basically Obama did it exactly right. The cost to put ground troops on there was too great. The cost to the American defense budget and the taxpayer in terms of doing it all by ourselves was too great. So basically, this operation after the first week is costing us $40 million a month. Basically, that's affordable. How much is Afghanistan costing? How much is Iraq costing? That's what I'm talking about, you've got to do the - - you know, do the cost benefits. And he decided that, yes, we would like Gaddafi to be gone. Every-- we'd like a lot of these people to be gone.

But in terms of the cost to do that, it would-- to put ground troops on and all that was just too great. And I think we have actually moved away in our military strategy the way we were doing it in Yemen with the Special Forces and the drones, the way we're doing it in Pakistan and the drones. That is a cost benefit way to do it rather than sending in large numbers of ground troops.

### Moderator
Claim: Another question? Yes, ma'am, your-- yeah, yeah, yeah. Emphatic.

### Moderator
Claim: Hi. I visited the Islamic republic of Iran 10 days before their election in 2009, their presidential election, on vacation. And I've been writing about Iran ever since then, partly in dismay of what happened with their presidential election and the crackdown. In terms of China and--

### Moderator
Claim: But can--

### Moderator
Claim: --of U.S. and Iran--

### Moderator
Claim: Is this your question coming?

### Moderator
Claim: Yes. It is now, just to give you background. So I'm writing mostly for an Iranian audience, actually, so you might want to speak of that when you're also answering too. China-- China is buying a lot of U.S. bonds. And that's part of how we're financing our military. So when we use a lot of military, we do go further into debt. I think it's important-- do you-- do you also think it's important to not underestimate cultural wars or soft wars because the Iranians are very focused also on that, like they're very afraid of Facebook and YouTube. The State Department has--

### Moderator
Claim: All right. I think I see your question. You're using other weapons, softer weapons, for example. I'm assuming both sides are in favor of that. It's cost effective.

### Moderator
Claim: We need to do more of it. We need to do it more intelligently.

### Moderator
Claim: And I would ask a question back to you. Do you think those demonstrators in the streets of Tehran, who exposed themselves to what they got would be voting in favor of this proposition.

### Moderator
Claim: There's a combination of Iranians that are inside and outside of Iran. But the ones that are inside, there are a lot of them that are in jail now unfortunately because they've all been arrested. But also there have been a lot of revolutions in the Middle East, and they had a lot to do with people not having good jobs and so on and so forth.

### Moderator
Claim: But to his question, do you think that the-- that the-- those who are standing up against these regimes would be discouraged to hear an argument that America needs its global wings clipped, or would they find that understandable and acceptable and realistic?

### Moderator
Claim: The people I know who are involved in-- that actually do live inside of Iran, and I'm in contact with probably about a hundred people inside Iran now, and many of them were protesters. I don't-- from what I hear from them, they're not thinking that a military invasion would really be a good idea.

### Moderator
Claim: Okay.

### Moderator
Claim: And that's-- but they're not happy with the position that they're in.

So if there are other ways to sort of balance the power so that-- or other ways to show a good example of government's--

### Moderator
Claim: Okay, ma'am, I just need to get to some other questions. But I think you should get a chair on our next debate on Iran, on the stage. Thank you very much for bringing it up. Sir, in the front row. Yeah. Third row. My apologies.

### Moderator
Claim: My question is, if we clip America's wings, how do we combat radical Islam? And if we expand our global wings, how do we combat radical Islam because we-- you know – it’s growing--

### Moderator
Claim: You know what? Take a minute-- take 15 seconds longer and decode what your point is. You're saying it's a no-win situation either way?

### Moderator
Claim: Well, I just want to hear how do we combat it on either end of the debate.

### Moderator
Claim: Okay. First to this side for a more modest policy.

### Conspiracy Advocate (CA)
Claim: Well, here is the problem.

We have this huge investment in Afghanistan which is because, as actually happened, the September 11th tax began there. However, we're not really-- we're not fighting al-Qaeda there. We're fighting a Pashtun insurgency. Al-Qaeda is now present in Pakistan, Somalia, Yemen and probably certainly more present in probably in Europe than it is--

### Moderator
Claim: But to his question, are you--

### Moderator
Claim: --in Afghanistan. And so the misallocation of resources by this kind of expansive nation-building mission is diverting us from dealing with Iraq.

### Moderator
Claim: His question-- his question is about another world in which going forward, if we're going to have to make hard choices, he's asking would a world operating under those rules be able to confront radical Islam. Lawrence, do you want to take it?

### Conspiracy Advocate (CA)
Claim: Yeah. You've got to confront these violent extremists basically not by killing them.

Rumsfeld said you can't kill all the terrorists. Basically, what you have to do is undermine their narrative. And by going into Iraq, which turned out to be for the wrong reasons, you enhance the al-Qaeda narrative. And so I think what we have to do is live up to our values at home, and that will help. I mean, Peter was talking about the fact that the American opinion around the world has gone up. That's important. That's how you're going-- you're not going to be able to kill them all. You have to undermine their narrative. You know the American opinion in the Muslim world went up when we-- after we helped the people in Indonesia.

### Moderator
Claim: But how does that relate to a more modest exertion of power?

### Conspiracy Advocate (CA)
Claim: Well, it means you don't use your military to do it. It's basically you live at home--

### Moderator
Claim: Because it's counterproductive and makes enemies. Is that what your argument is? It can make enemies? That's what you're saying has happened in Iraq, Afghanistan.

### Conspiracy Advocate (CA)
Claim: Yes, yes, I am saying that, yeah.

### Moderator
Claim: Okay. Let me take it to the other side.

### Moderator
Claim: Well, I'm-- let Elliott finish.

### Moderator
Claim: Which Elliott will take this? Eliot Cohen.

### Scientific Advocate (SA)
Claim: Well, I guess my first thought is, a moment ago you were all in favor of targeted killing in Pakistan and Yemen, so, I mean, that’s-- I’m in favor of living up to our ideals at home, but you were in favor of drones, let’s remember what those drones do. Secondly, I very much believe in American soft power, and that’s what we should be exercising to the best we can in places that are likely to be the incubators of radical Islam, that means being more involved in places like Indonesia to take just one case, rather than less. I mean, again, remember what this proposition’s about. This is not a debate about the use of military power; it’s about America’s global role.

### Scientific Advocate (SA)
Claim: I would just add here, you know, living up to our ideals at home is not going to end the threat of Islamic extremism. One of our ideals at home is equality for women, and the more we live up to that, the more they’re going to hate us because they don’t believe in it. So that is not a solution.

I think there is a one solution, but a key part of it as Eliot just said, is what we do in those countries. I can’t think of a better thing to do than support the expansion of democracy through soft power, not by invading 15 countries, but I think that what is happening now in the Middle East with the Arab revolts, is just killing al-Qaeda because we see what people in those countries want, they want democracy, they want free elections, they want an end to censorship and the secret police, and al-Qaeda isn’t even addressing any of those things. So the expansion of democracy in the Arab world is one of the best things we can do to fight al-Qaeda.

### Moderator
Claim: And how does-- how do we do that with the use of American force?

### Scientific Advocate (SA)
Claim: You’re not going to do it-- you do it with soft power mostly, but it is harder to make your soft power felt if people think that your country is in decline and your wings are being clipped. That’s just the nature of the world.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. Debate. here’s where we are. You are about to hear brief closing statements from each debater in turn. They will be two minutes each, and remember, you voted before the debate on your view on this motion, and we’re going to ask you to vote once again afterwards. This is their last chance to try to change your minds. So, round three, closing statements by each debater in turn. Our motion is, “It’s time to clip America’s global wings.” And here to summarize his position against the motion, Eliot Cohen, professor at the School of Advanced International Studies at Johns Hopkins University and former counselor at the Department of State.

### Scientific Advocate (SA)
Claim: Our opponents would have liked the motion to be resolved, the Bush administration acted like a bunch of arrogant, wasteful, strategic nincompoops in Iraq and Afghanistan, but that wasn’t the topic. I mean, I turned down a topic that I thought was pretty silly. The topic is, “It’s time to clip America’s global wings." You know, you can’t assess these things as if they were some sort of scientific proof, they’re not, but let me offer one way of thinking about it, and one way of formulating your judgments.

Who in the world would be likely to vote for this resolution, who would be likely to vote against it? So here's some of the people in my list who would vote for it. I think Vladimir Putin would vote for it, I think Kim Jong-il would vote for it, I think Mr. Chávez in Venezuela would vote for it, and I think-- I am sure President Ahmadinejad would vote for it. Who would vote against it? Prime Minister Salam Fayyad of the Palestinian authority, and Prime Minister Bibi Netanyahu of Israel, Aung San Suu Kyi in Burma, and I suspect the Dalai Lama, those demonstrators in the streets of Tehran that we talked about, the Kurds, the Kosovars, the Bosniaks, the people of Japan, of Australia, Kenya, Columbia, Darfur. I know which group of people I’d rather be with.

### Moderator
Claim: Thank you. Eliot Cohen, speaking against the motion, which is, “It’s time to clip America’s global wings.” And here to summarize his position for the motion, Peter Galbraith, a former U.S. diplomat who served as deputy special representative of the U.N. and Afghanistan and was the first U.S. ambassador to Croatia.

### Conspiracy Advocate (CA)
Claim: In an op-ed piece in the Washington Post on Sunday, Meghan O’Sullivan, who was an official in the Bush administration, wrote about lessons of Libya that came from Iraq. And one of them was that she said, “Early decisions can have long term consequences." In effect, we made a big mistake deciding that Iraq would have a federal system. Well, guess what, it wasn’t America’s decision to be made. It had been made a decade before by the Iraqis, and that really comes to my point. This world, it’s not all about us.

It’s about-- what’s happening in the Middle East is not because they sat down and they read Jefferson or the Federalist Papers. It is an indigenous movement of people in the Arab world, and it’s terrific. But it isn’t because of something that we’ve done or not done. But we have the potential by intervening, as we did in Iraq with an expansive nation-building exercise, as we’ve done in Afghanistan, as we’re still doing, try and build a central government where none has existed, of undermining our credibility of wasting our resources. We have to remember that military power is not the end-all and be-all of power. Power is a lot of things. Influence doesn’t always come at the point of a gun. It may relate to your prestige. In 2000, America’s prestige was sky-high, again, after Bosnia, Kosovo, and East Timor.

We had a lot of influence in the world. We exercised a lot of military power in this last decade. And by the end of the previous administration, our power and our influence in the world, our ability to make things happen, was rock-bottom. We’re climbing back, but it’s awfully slow.

### Moderator
Claim: Thank you, Peter Galbraith. Our motion is "It's time to clip America's global wings." And here to summarize his position against the motion, Elliot Abrams, a senior fellow at the Council on Foreign Relations, who served as deputy national security adviser in the George W. Bush administration.

### Scientific Advocate (SA)
Claim: My argument, in closing, has been summarized by someone else. I just want to read five sentences. “There will be times when our safety is not directly threatened, but our interests and values are. Sometimes the course of history poses challenges that threaten our common humanity and our common security: responding to natural disasters, preventing genocide, keeping the peace, ensuring regional security, maintaining the flow of commerce. These may not be America’s problems alone, but they are important to us.

They are problems worth solving. And in these circumstances we know that the United States as the world’s most powerful nation will often be called upon to help. But let us also remember that for generations we have done the hard work of protecting our own people as well as millions around the globe.” That’s President Obama, and he’s right. If we are to be safe, if we are to be free, we really can’t escape the world as it is. We cannot escape the need to have and sometimes to use military power. On the wings that you’re being asked to clip ride the hopes of hundreds of millions of Americans and many more people all over the globe, hopes for freedom and security, hopes for a better future - - for the sake of those people, for the sake of their freedom as well as ours, reject this proposition. Don’t clip the eagle’s wings.

### Moderator
Claim: Thank you, Elliot Abrams. And our motion is: "It's time to clip America's global wings." And here to summarize his position for the motion, our final speaker, Lawrence Korb, senior fellow at the Center for American--

### Conspiracy Advocate (CA)
Claim: Since you’ve mentioned it--

### Moderator
Claim: Lawrence, let me-- I just wanted to do an introduction, sorry.

### Conspiracy Advocate (CA)
Claim: Oh, oh, okay.

### Moderator
Claim: Lawrence-- no, no-- we’ll reset. Sorry. Lawrence Korb, a senior fellow at the Center for American Progress, who served as Assistant Secretary of Defense during the Reagan administration.

### Conspiracy Advocate (CA)
Claim: Let me go back-- I was, in the beginning, questioned on my Republican credentials by quoting a couple of Republican presidents, though, I think summarize the point that Peter and I have been trying to make. “Maybe I’m missing something here, but we should encourage people who live in those lands”-- he asked about nation building-- “to build their own nations,” George Bush, 2000, when he was running for president. You remember the humble foreign policy.

That’s the point we’re trying to make. Let me quote from another Republican. “Every gun that is made, every warship launched, every rocket fired signified in the final sense a theft from those who hunger and are not fed, those who are cold and are not clothed.” If you take a look at what the Republican Party today, if you look at Paul Ryan and what he’s proposing, he wants to increase defense spending and then cut the things that are not going to help us improve our standing in science, are not going to help us be more competitive in the world. And what we’re opposed to, by clipping the wings, is to get over these reckless military adventures that we’ve undertaken in the first part of this century, something we hadn’t really done since Vietnam. And let me conclude with this. You’ve heard all the apocalyptic scenarios. I remember when people said, if you got out of Vietnam, all Southeast Asia and Communism and all that kind of stuff.

Elliott meant you were going back to Cam Ranh Bay. I spent a little bit of time there, you know, about 40 years ago. Why are we going back? This is the people that we basically recognized we could not make them what we would like them to be. But they're doing okay now. And I think that's the point we want to make. We can't do it all. We're going to have to clip our wings when something happens. But look inside all your clothes and things like that. Go down to Nike and find out where your running shoes are made. That turned out pretty well, even though we clipped our wings back in the '70s.

Oh, oh, okay.

Since you’ve mentioned it--

### Moderator
Claim: Lawrence Korb, thank you very much. And that concludes closing statements. And now it's time to learn which side you, our live audience, believes has argued best. I'm going to ask you to go again to your key pads. Our motion is, “It's time to clip America's global wings.” If you agree with this motion, after hearing the arguments, push number one. If you disagree, push number two. If you became or remain undecided, push number three.

And we'll have the-- we'll have the results in about a minute and a half. But first I want to take care of a couple of things, one of which, most obviously, is to thank this panel for bringing a very, very intelligent debate to Intelligence Squared. I also want to thank everybody who had the guts to stand up and take a microphone in the audience even if the question didn't pass my filter. I appreciated that you did it. And I did hear some very good idea for future debates, though they're not related to tonight's. Thank you very much. We also want to point out, Intelligence Squared is run as a very, very lean operation. And we are going to be losing one of our key players who's moving on to other things by her own choice. Lindsay Nelson has been with the organization nearly since the beginning.

She is responsible, in fact, for having designed this set, for making the television broadcast possible, for bringing us to this theater. She has designed the programs that are in your hands. She is possibly the youngest member of our staff, so she keeps everyone but me hip. And we're going to miss her tremendously because her impact on this has been profound, and we just want to-- I'm not sure if she's even in the room here. But if she is, she's probably hiding under a chair at this point. We want to thank her with a real round of applause for everything she's done. So our theme this spring has been “America's house divided.” And our last debate of the season is on Tuesday the 3rd of May. The motion will be, don't give us your tired, your poor, your huddled masses. We have arguing for this motion, Kris Kobach. Kris Kobach has been the driving force behind most of the controversial immigration laws sweeping the country, including Arizona's Senate bill 1070.

He is now leading a movement to eliminate birth right citizenship through state legislation. Joining him will be former Colorado congressman Tom Tancredo, who has called amnesty a terrible policy and terrible politics. And he once advocated for a civics literacy test as a prerequisite for voting. Against the motion is Julian Castro. He is the youngest mayor ever to be elected to the country's seventh largest city, San Antonio, Texas. After his win, The Economist declared "Castro has the charm, the brains and the boldness to one day become a Hispanic Barack Obama." His partner will be Tamar Jacoby, who over the years has gone from being an editor at Newsweek and The New York Times to becoming one of the pro-immigration movement's most conservative voices. She is now the president and CEO of Immigration Works USA. Tickets to our future-- or our next debate are available to the website and at the Skirball box office. And don't forget to follow Intelligence Squared U.S. on Twitter and make sure to become a fan on Facebook. And if you do, you'll receive a discount on future debates. And as I said earlier, all of our debates can be heard on NPR stations across the country.

And you can watch them on Bloomberg Television, this debate on Bloomberg Television starting next Monday. If you visit Bloomberg.com, you'll find out where to go for your local channel. Okay. It's all in. I have the results now. Here is how you voted before the debate. On the motion, “It's time to clip America's global wings,” before the debate, 37 percent were for the motion, 26 percent against, 37 percent undecided. After the debate, 47 percent are for the motion. That's up 10 percent. 44 percent are against. That is up 18 percent. And nine percent are undecided. That means the team arguing against the motion, “It's time to clip America's global wings” has won this debate. Our congratulations to them. Thank you from me, John Donvan and Intelligence Squared U.S.
