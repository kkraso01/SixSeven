# Debate Transcript

Topic: The U.S. Has No Dog In The Fight In Syria
Motion: The U.S. Has No Dog In The Fight In Syria

Debate ID: 080913%20syria


## Round 1

### Moderator
Claim: …It started with founder and chairman Robert Rosenkranz-- Normally, before our debates in New York, Bob and I chat for just a couple of minutes about a sort of framing of the evening that's ahead for us. And in this case, the basic question I wanted to ask you is-- you know, the language-- “the U.S. has no dog in the fight”-- could be interpreted a lot of different ways. What is-- what do we intend by that language, this debate to be about?

### Moderator
Claim: Well, let me start off by saying what we don't intend. This is not a debate about whether Syria is consequential. It's clearly Iran's sole ally. It's a site of a humanitarian disaster of huge proportions. There will be no debate about that. So, what-- put me in mind of this language-- “the U.S. has no dog in the fight with Syria”-- was a dinner I attended in Singapore. And my dinner partner was the former head of the KGB, Ambassador Chebrikov. And I was--

### Moderator
Claim: Charming.

### Moderator
Claim: A charming guy. Very well-informed. So, I said, “What are you guys doing in Syria? You can't like the idea of an Islamist regime like the Iranians getting stronger. What are you doing there?” And he said, “Look, we don't like Assad any better than you do. But we think that the alternative to Assad is, at best, an Islamist state. And at worse, a new Al-Qaeda stronghold. So, we think Assad is the best of the bad lot of choices.”

### Moderator
Claim: So, the Russians have picked their side. They picked their guy.

### Moderator
Claim: Yes. They picked their guy and he seems to be doing better, with their support. A few days later, I happened to have dinner with Henry Kissinger. And I essentially posed the same question to him. And his view was unless the United States sees a clear way to influence an outcome and a clear way to make that outcome better suited to our national security interests, we should stay out.

And in a sense, this language-- the U.S. has no dog in the fight with Syria-- is asking whether those two opinions are correct or whether there is an identifiable income that we can get behind, that serves our interests at least reasonably well, and is worth a commitment of U.S. military involvement or other kinds of involvement to try to bring it about.

### Moderator
Claim: Yeah. But we do a lot of debates where it-- there's a clear dividing line between the two sides. You know, one that comes to mind is “Ban College Football.” That was easy. Yes or no. This one is one of those debates that's full of nuance and gradation.

### Moderator
Claim: Well, that's absolutely right, John. I mean, in a debate like this, nobody's going to say, “We should be all in with all the military resources, full-on involved, boots on the ground to try to create an outcome.”And nobody's going to say, “This is a matter of no real consequence to the United States. We can kind of ignore it.” So, it's all going to be matters of degree. But I think, ultimately, there are going to be real differences between these sides and their discussion is going to be very illuminating.

### Moderator
Claim: And robust. And let's bring on our robust debaters. Now, ladies and gentlemen, please welcome our debaters to the stage. Thank you, Bob Rosenkranz.

### Moderator
Claim: Thank you.

### Moderator
Claim: And this is one of those times. May I invite one more round of applause, please? Thank you. are times when, for a president, there is nothing to debate. We are attacked. You go to war. Pearl Harbor. September 2001. Other people's wars, those are trickier. The U.S. intervenes to put an end to the killing in Bosnia and was glad that it did. The U.S. was passive about mass killing in Rwanda and ended up regretting that. So now, there is Syria. And it is a mess. A death toll that is crossing into six figures. Millions of people homeless. A dictator who is suspected of using chemical weapons against his own people. And fighters-- thousands of them, from all over the world, descending on the chaos with a vision of creating an Islamist state. So, does it behoove the U.S., urgently and immediately, to get more involved in Syria? Up to and possibly including military action.

Or is the wiser thing for the U.S., when it appears there are no good options, to stay back and maybe this time, let somebody else mostly sort out the problem? Now, that sounds like a debate. So, let's have it.

Yes or no to this statement: The U.S. Has No Dog in the Fight in Syria. A debate from Intelligence Squared U.S. I'm John Donvan. We are in Aspen and on the stage of the Paepcke Auditorium at the Aspen Institute. And in partnership with the Aspen Strategy Group. We have four superbly qualified debaters-- two against two-- who will be arguing out this motion-- for and against-- the U.S. has no dog in the fight in Syria. As always, our debates go in three rounds. And then the audience votes to choose the winner. And only one side can win.

Let's meet our debaters. Our motion is: The U.S. Has No Dog in the Fight in Syria. And first, ladies and gentlemen, please welcome Graham Allison. Graham, you are the director of Harvard's Belfer Center for Science and International Affairs. You served in the Reagan and the Clinton administrations. You were assistant secretary of defense under Clinton. As a youth, before all of that, you wrote a book called “Essence of Decision” on the Cuban Missile Crisis that forever afterwards changed the way the people understand decision-making. You also, as a youth, at age 31, made it to full professor at Harvard. So, Graham Allison. What took you so long?

### Conspiracy Advocate (CA)
Claim: Well, I was young and even more foolish.

### Moderator
Claim: Ladies and gentlemen, Graham Allison. And Graham, your partner tonight in this debate is?

### Conspiracy Advocate (CA)
Claim: Is the handsome Richard Falkenrath.

### Moderator
Claim: Ladies and gentlemen, Richard Falkenrath. Richard, you're also taking the position that the U.S. has no dog in the fight in Syria. You are a principal of the Chertoff Group.

You're an adjunct senior fellow at the Council on Foreign Relations. You served in several capacities during the George W. Bush Administration, including deputy homeland security adviser, deputy assistant to the president. But you recently told Bloomberg-- and I quote-- “The cold hard facts are that as a global economic matter, Syria just doesn't matter that much.” That is about as blunt as it gets. Is blunt your style?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Ladies and gentlemen, Richard Falkenrath. Our motion is: The U.S. Has No Dog in the Fight in Syria. And here to argue against the motion-- it means that they do believe that the U.S. has a dog in the fight in Syria-- I'd like to introduce and welcome Nicholas Burns. Ladies and gentlemen, Nicholas Burns. Nick, you're a professor at the Harvard Kennedy School and Director of the Aspen Strategy Group. Your career as a foreign service officer-- done a lot of stuff, undersecretary of state for political affairs from 2005 to 2006, lead U.S. negotiator on Iran's nuclear program, ambassador to NATO, ambassador to Greece, special assistant to President Clinton, Director of Soviet Affairs under President H.W. Bush.

Back in 1980, you were stationed in Mauritania as an intern. So, you are here to tell the young people of America that a good internship can get you someplace.

### Scientific Advocate (SA)
Claim: In 1980 I was the lowest ranking person in the history of the United States government in Mauritania, but it was a great experience. Thank you.

### Moderator
Claim: Nick Burns, ladies and gentlemen. And Nick, your partner is?

### Scientific Advocate (SA)
Claim: Ambassador Nigel Sheinwald.

### Moderator
Claim: Ladies and gentlemen, Sir Nigel Sheinwald.

Sir Nigel, you have agreed that while you're here in the colonies, and for the purposes of this debate, you will be Nigel? Thank you. You are also arguing against the motion, that the U.S. has no dog in the fight-- it means you think the U.S. does have a dog in this fight. You were British ambassador to the United States.

You were foreign policy and defense adviser to Prime Minister Tony Blair. And also, as U.K. Ambassador and permanent rep to the European Union, in 2006, you went to Syria. You held secret talks with President Bashar Al-Assad. The Guardian said you offered Assad a choice: continue an alliance with Iran or enjoy a normalization of relations with the West. He made his choice. We know that. What we want to know from you-- what's the guy like?

### Scientific Advocate (SA)
Claim: Not something I'd want to do every week, I think. But it was a very tough conversation. And I'll talk a bit more about it later.

### Moderator
Claim: All right. Thanks very much. Ladies and gentlemen, Nigel Sheinwald. Our motion is: The U.S. Has No Dog in the Fight in Syria. At this Intelligence Squared U.S. Debate, you, our live audience here in Aspen, act as our judges. By the time the debate has ended, you will have been asked to vote twice, once before the debate and once again at its conclusion. The team whose numbers have changed the most-- in terms of your vote, in terms of percentage points-- will be declared our winner. So, let's go to our preliminary vote. There's a keypad at your seat.

And you want to pay attention to numbers one, two, and three. I'm going to give a visual on this because this is a tricky motion because of the negative in it. If you feel that the U.S. has no dog in the fight in Syria, if you're with these guys right now, that means you push number one. If you disagree with the motion that the U.S. has no dog in the fight in Syria, in other words, you think it does have a fight in the-- with Syria, you're voting with these guys, that's pushing number two. And if you are undecided, which is a perfectly honorable position in this one, push number three. You can ignore the other keys, and you can also-- if you push the wrong one, just correct yourself and the system will lock in the last vote. Once we lock out the vote, we have instantaneous results, means at the end of the debate, second vote, within a minute or two we'll be able to tell you who's won the debate according to our rules, which, once again, is the team that has picked up the most percentage points from its starting position.

So on to round one. On to round one. Our motion is: The U.S. Has No Dog in the Fight in Syria. And here to speak first for the motion from the lectern, Graham Allison. He is director of the Belfer Center for Science and International Affairs, professor of government at the Harvard Kennedy School, and former assistant secretary of defense. Ladies and gentlemen, Graham Allison.

### Conspiracy Advocate (CA)
Claim: So thank you very much, John. And it's an honor for Rich and I to appear even in a debate with two such distinguished colleagues. But I want to warn you at the outset that this is a bit of a mismatch. Rich and I are academics and think tank types. Nick and Nigel are two of the most effective public advocates we've seen in recent times.

Nick is one of my colleagues and friends at Harvard, our offices are about 20 feet apart. I introduce him as often as I can to Harvard audiences because I would prefer him to speak than me. And always I say, which is what I truly believe, that the U.S. has had no more effective public spokesman in modern times than Nick Burns when he was assistant secretary for public affairs. Nigel is a legend-- Nigel is a legend in Washington as the British ambassador to the U.S., who is an extremely, again, effective public spokesman. So as you listen to the discussion tonight, I hope you'll think about the evidence and the analysis presented and not the eloquence because if-- if that was the case, you can vote now and be done. So the motion is about a dog in the fight. Let me just ask, how many people here have a dog? Okay. So I just want to see if it's a dog friendly audience. I think Aspen is usually fairly dog friendly. So as you think about the argument tonight, consider this, you go around a corner, you confront dogs in a fight, and you think what to do. And compare that with a second case in which you're confronting a dog fight in which one dog has its mouth around the other's throat and you discover that it's your dog. Now, the question is, "Is this America's dog in this fight?" So as the moderator reminded us, this assignment tonight is not whether the U.S. should care about the dogs that are tearing each other apart in Syria tonight.

It's tragic and anybody who looks at it without having their heart torn ought to have a-- you know, an MRI to see if their heart's turned to stone. The question is, "How much should we care and what should we do about it?" So in the language of national security, the question is, "Does what's happening in Syria so impact American vital national interests that we're compelled to do everything we can including military actions to secure our interests?" That's what it is to have a vital national interest. And, secondly, if the answer to that is, "Yes," or even if you're a little shaky on that one, "Has anybody been able to identify a feasible American military intervention that would likely make the situation better over the long run than-- after we had acted than in the case we did not act?"So if you think about this be clear and let me be as unambiguous as we can. Our answer to these questions-- these two questions are no and no. No, the U.S. does not have a vital national interest in what's happening in Syria, and two, no. No one, is at least to my satisfaction, or Rich's or indeed to Chairman Dempsey, chairman of the JCS, identified a feasible American military intervention, which after the fact would likely make the situation over time better than the alternative. So, it's to our opponents, I think, to explain how and why they disagree with these judgments, and suggest to us what evidence leads them to that conclusion.

In these opening comments, I'm going to just make some general comments-- general big points, big picture, that bear on the question you have in front of you, and then my colleague, Rich, is going to drill down in more detail. Four quick points.

First, Sam Nunn who is a member of the Aspen Strategy Group, which we're all here as part of, insists that we draw the distinction between vivid and vital. Because he says whenever something is vivid, especially if it appears on TV over and over and people are being killed, Americans, or many Americans, imagine well, we must have a vital interest there because it's impacting our interests and since we're the world's greatest military super power, maybe there's a military intervention we could undertake to make things better. In our view, that's not the case here. This is a vivid, painful, but not vital. Vital in the dictionary, read it, says essential for survival and well-being.

In the mantra of national security it says essential for the preservation of the U.S. as a free society with our fundamental institutions and values intact. Syria does not meet that test. Now some of you are saying well, maybe that's too high a test. I mean, could anything threaten our vital interest? And I would say in 1990, when Saddam tried to annex Kuwait and threatened the whole possibility of the flow of oil from the Persian Gulf, President Bush, the father, chose military action and that was the right choice.

### Moderator
Claim: Graham Allison, I'm sorry, your introductory remark time is up and concluded. Thank you very much, Graham Allison.

I want to point out our introductory remarks last six minutes each. I gave Graham seven because he spent the first time saying such nice things about the other side, and-- although it might have been a sneak attack. I'm not sure. Also, your timers will say six minutes from this point forward. Our motion is: The U.S. Has No Dog in the Fight in Syria, and here to speak against the motion is our next debater, Nick Burns. He's professor at the Harvard Kennedy School, director of the Aspen Strategy Group, and former undersecretary of state for political affairs. Ladies and gentleman, Nicholas Burns.

### Scientific Advocate (SA)
Claim: John, thank you very much. Good afternoon everyone. It's a pleasure to be here. Pleasure for Nigel and I to be with Richard and Graham. They're both good friends. I won't try to butter them up anymore. I need my time, but I will say this. We've been asked to address one question. Does the United States of America have a dog in the fight in Syria? The question wasn't whether it's vital. The question wasn't whether it's feasible. Do we have an interest in who wins in this fight in Syria? And the answer is unequivocally of course, yes, without any question. Because Americans should be supporting the Syrian people who have been brutalized by the Syrian dictatorship of Bashar al-Assad.

And we should oppose the Assad regime because it's being supported by Iran and Hezbollah and Russia. So that's the dog in the fight for the United States. And what happens in Syria really matters to our country for our national security. I would say it matters to every American. Let me give you three reasons why.

First, there's a humanitarian imperative. I think everybody knows what's been happening. There's a catastrophic humanitarian situation in Syria. More than 100,000 Syrians have been killed in the last two and a half years, all civilians, 1.8 million Syrian refugees outside the country in Iraq and Turkey and in Jordan in refugee camps, 6.8 million people in need of humanitarian support and of those people, 4.5 million have lost their home in Syria. They're on the roads. They're trying to find a place to live. They've lost their jobs.

Secretary of State-- former Secretary of State Madeline Albright is here. And she and I were in Morocco a couple of months ago. We met with the U.N. Envoy for Syria, Lakhdar Brahimi. He told us something I don't think-- I won't forget. It was very arresting. He said, “Syria is melting away because of this humanitarian crisis.” So, do we have a dog in the fight? We want to help the Syrian people who have been brutalized by their own regime. That's the first reason. The second reason is geography. Look at the map. Syria is a neighbor to very important friends and allies of the United States. It's a neighbor to Israel. It's a neighbor to Turkey, to Iraq, to Jordan, and to Lebanon. So, its central strategic position in the Levant, in the heart of the Middle East, in the heart of the Arab world-- it means that what happens there really matters to the United States and especially to our ally, Israel.

And third, Syria matters to the United States because who is arming and aiding and financing this regime? It's our enemy, Iran. And its partner Hezbollah. And it's our adversary, Russia. So, if Assad wins, Iran and Hezbollah become infinitely stronger. And that puts Israel, the United States, and all of our moderate Arab friends at a distinct strategic disadvantage. Do we have a dog in this fight? You better believe we have a dog in this fight. Nigel and I support what President Obama has been trying to do, what the United Kingdom government has been trying to do, the coalition of countries: the United States, the European countries, Turkey, nearly all the Arab countries, supported by Israel-- who all want to see the following happen-- no one wants to put American troops on the ground in Syria. President Obama has said resolutely he won’t do that. But this coalition is trying to do the following. They're trying to launch an intensified international effort. It has been too weak so far.

It needs to be strengthened to support the moderate rebels and the majority of the Syrian population who support the rebel movement. They're trying to organize more effective humanitarian aid. We the Americans have given a lot. Others need to do more. But it needs to get to the refugees. This group is trying to illuminate-- for international judgment and inspection-- Assad's war crimes, his brutalization of his own people and his use of chemical weapons.

And this coalition as well, is seeking now to build a transitional government-- formed by the rebel movement-- that would be a government that can compete with the Assad regime for political support through which we can give humanitarian aid. And President Obama's former Syria coordinator, Fred Hoff, testified before Congress on July 17th that that should be now the central objective of this coalition. They want to support a political process that eventually-- over time-- and it's going to take a long time-- to make sure that Assad can leave, that a new and more stable transitional government can take his place.

It won't be perfect. They'll go through all sorts of ups and downs and frustrations. But at the end of the day-- and maybe it's a year or two or three from now-- there's a better, more humane government in power in Damascus.

What are the advantages to what President Obama is trying to do? It helps the refugees. It supports the great majority of the population in Syria who are opposed to Assad. It has wide international support. It opposes Iran, Hezbollah, and Russia. It has America leading-- but politically, keeping our troops out of harm's way. This is going to be difficult. It's going to be enormously complex. I think we'll see a lot of setbacks. It is not - - and I'm sure Graham or Richard will point this out-- without its risks. But there is a greater risk of inaction.

The status quo is unacceptable. I've got 30 seconds?

The status quo is--

Thank you. Thank you, John.

We concede back the eight seconds of the-- the status quo here that I've just described-- is unacceptable for Americans. We cannot stand by and let this happen. No American troops on the ground. But yes to America having a dog in this fight. Thank you.

### Moderator
Claim: Thank you, Nick Burns.

### Scientific Advocate (SA)
Claim: The status quo is unacceptable. I've got 30 seconds?

### Moderator
Claim: No, no. No. The--

### Scientific Advocate (SA)
Claim: The status quo is--

### Moderator
Claim: Oh, you do. I apologize.

### Scientific Advocate (SA)
Claim: Thank you. Thank you, John.

### Moderator
Claim: You know, now you got 45 seconds.

### Scientific Advocate (SA)
Claim: We concede back the eight seconds of the-- the status quo here that I've just described-- is unacceptable for Americans. We cannot stand by and let this happen. No American troops on the ground. But yes to America having a dog in this fight. Thank you.

### Moderator
Claim: Thank you, Nick Burns. The jury will disregard my interruption of Nick Burns. I apologize. I'm sorry. I confused myself with that seven minute clock before. So, a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters. Two teams of two. Fighting it out over this motion-- The U.S. Has No Dog in the Fight in Syria. You've heard the first two debaters, and now on to the third. Speaking in support of the motion, that the U.S. has no dog in the fight in Syria, I want to introduce Richard Falkenrath.

He is a principal with the Chertoff Group, adjunct Senior Fellow for counterrorism and homeland security at the Council on Foreign Relations. Former deputy homeland security adviser. Ladies and gentlemen, Richard Falkenrath.

### Conspiracy Advocate (CA)
Claim: Thank you, John. I must just start by saying, this is an immensely difficult and tragic problem. And it's very hard to take clear positions when something is so difficult and hard to solve. I will say, however, that there are some things that divide the two sides of the debate. And one, as my colleague Graham said, is really what it means to have a dog in the fight. And we stand for a view which says it means you have a vital and national interest at stake which makes it so compelling that you lead and do whatever is necessary to make sure that your vital interests are protected. And we don't think that exists in Syria. Graham made the case in summary for us.

There are many things that we are doing as a country, that we could do, that we should do. We heard some of those from Nick. We may hear some more from Nigel. But the real question before us is is the interest engaged in Syria so vital that we must lead and be centrally involved and possibly intervene militarily to remove Assad from power? And we think the answer to that, unfortunately, is no.

Graham made the argument in summary. I want to elaborate it in three ways. First, to give you a little bit of ground truth about this conflict. Second, talk about chemical weapons. And third, the issue of supplying light arms.

On the ground truth in the conflict-- this is not a simple conflict of good versus evil, though Assad certainly is evil. And it is not a single conflict. This is many different conflicts. And frankly, a fatal flaw in Nick and Nigel's position here is there is no opposition for us to support. You'd think that if you had a dog in the fight, you could at least have a name for the dog on the other side. But it's not good enough to say the Syrian people or the Syrian opposition, because the fact is, there is no unified opposition.

And there is no connection between the mostly exile-based political leadership and the fighters on the ground.

I-- we're so draconian on time. I can't really go through all the different factions of Syrian fighters and political entities at the moment. But there's the Syrian Free Army, the Syrian Liberation Front, the Syrian Islamic Front, the Al-Nusra Front, various Kurdish groups, independent groups-- all of whom are, in fact, umbrella groups of smaller numbers of fighters out there in the field running their own operations. And in that context, we-- there are also organizers, The National Coalition, who are mostly outside of the country, not connected to the fighters on the inside, and not able to dictate what happens on the ground. And so, this is a real problem. If you want to have a dog in the fight, to not have the slightest idea who it is, and to hope that it will come together. And in fact, the most effective and vicious and aggressive fighters in this conflict are ones with whom we would never side.

The one-- the last one I mentioned was the Al-Nusra front. This is a wing of Al-Qaeda. It has sworn allegiance to Ayman Zawahiri. So, yes, we-- now, so we have-- we really have two dilemmas in Syria. We've got Assad aligned with Hezbollah, a Shi'ite extremist terrorist group. And the most effective and operationally effective opposition group being one who is completely anathema to us to the point that we've designated them a foreign terrorist organization. So, how can you have a dog in the fight when you can't even identify the dog?

Second, on chemical weapons-- Assad has a massive chemical weapons arsenal-- comprised primarily of nerve gas-- sarin, DX, and mustard gas. Can't go into the details of what it is, where it is. It's not in a condition that can be easily and quickly used, but it is very dangerous. One of the dilemmas we face here is that it is currently controlled by the Assad regime and the Alawite sect. And we do have-- maybe a vital interest-- certainly a very strong interest in ensuring these weapons are not transferred to Hezbollah and they are not used against Israel, Turkey, our allies in the Gulf, our own forces.

And unfortunately, this is actually a sort of restraint on our power. Most of the more aggressive forms of intervention and keeping the military balance in the favor of the rebels will lead-- at least temporarily-- to a loss-- a higher risk of loss of control of the chemical weapons. We cannot forget that.

Finally, on-- and I want to say something about what I'd call the moral hazard of half- measures. We have-- as an unfortunate leitmotif in American foreign policy-- which is every so often, we give support and comfort to groups with which to rise up against an autocrat. And then we get cold feet and leave them dangling. And we did that in Hungary in 1956. We did it in the Bay of Pigs in '61, in Prague in 1968, in southern Iraq in 1991.

And we need to be very careful about small half measures in steps which are-- really have no prospect of success but do make us complicit in the violent outcome which we really cannot control and cannot dictate. And so for that reason it strikes me as that, yes, of course, we should stay involved and engaged diplomatically, and politically there is room for that, but to begin a process of arming a number of rebel groups we can't even control, and don't know, and, frankly, don't trust, I think, is a very dangerous first step since we really are not ready to go the distance. And, in fact, very few people, and certainly none of them on this panel I think, are truly ready to go the distance, which, by the way, we all would be if it were a vital national interest. And that's the essence of the problem here. We want to make it better but it really is not so vital to allow us to be ready to do everything it takes to get the outcome that would be better for us and the region. Thank you.

### Moderator
Claim: Thank you, Richard Falkenrath. Our motion is: The U.S. Has No Dog in the Fight in Syria. And here to speak as our final opening statement debater against the motion, Nigel Sheinwald. He served as British ambassador to the U.S. and as foreign policy and defense advisor to Prime Minister Tony Blair. Ladies and gentleman, Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: Well, thank you very much, John, and my thanks to Intelligence Squared for initiating an important debate. And it's a great honor for me to be here with my three distinguished fellow panelists. Now, I just want to go back to the motion. I'm a Brit, and I think I know something about the English language. And to me having no dog in the fight in Syria means something very simple. It means that you don't-- you're not concerned. You don't have an interest, and you won't be affected by the outcome.

That's my dictionary definition, and I think if you look it up, that's what you'll find. I agree that the other side want to do something in Syria. The question is, "How important is this issue? How much does it affect American interests, European interests, world interests, and is there some sensible way through in a world where things are much more complicated than they were in 1990 when we had the Kuwait conflict, where we have to deal in gray as much as in black and white, and where we risk paralysis if we don't try to do something rather than be paralyzed. So my suggestion would be that the United States does indeed have a strategic interest in what happens in Syria. I don't know that I can meet the very high bar that Graham and our other colleague have mentioned in relation to an American intervention, whether this is important or not.

And the proposers of this motion do want America to stand back. I would say that in today's world you're dealing with complex changes within countries, you're dealing with situations of extremism, instability, you're dealing with a humanitarian tragedy here in Syria, and you have to work out whether there's some recipe which has a reasonable chance of success. And the best need not be the enemy of the good in deciding that. I don't think, too, that we can wait for the perfect opposition party, some Jeffersonian democratic ideal to be formed in Syria. We don't have perfect opposition parties in our own countries, let alone in Syria or elsewhere in the Middle East. We've got to go with the situation on the ground in the Middle East at the moment, where there is a huge amount of uncertainty, and we have to decide whether we understand that dictators like Assad will at some point or other be swept away.

And whether we’re prepared just to sit it out, and do very little to achieve a much better outcome. As Nick said earlier, the status quo really isn’t sustainable for the United States, for Britain, and for our other allies, and that’s where I really part company with Graham and with Richard. If Assad stays in power, Iran, Russia, and Hezbollah are going to win. The vast majority of the Syrian population are going to be in revolt. The longer this goes on the conflict in Syria is going to spill over into the rest of the region. The split between the Sunni and the Shia within Islam is going to expand. And speaking certainly for my country, we've seen a radicalization of our Muslim population because of Syria.

It's become a recruiting sergeant for radicals around the world. And those young men and perhaps women are going to go to Syria and pick up a whole load of skills in violence and in terrorism, which will be re-imported into our own countries and threaten us very directly. And I think that's a real risk for the U.K., for the U.S., and for others.

I spent nearly 36 years in the British diplomatic service. I believe in the transatlantic partnership. I think that there's little good that happens in the world if Europe and America are not standing together. And I and my compatriots are friends of this country. But I do worry about America's credibility and standing if we just sit this one out. President Obama talked last year about red lines and a game changer if Syria were found to have used chemical weapons. We now know that chemical weapons were used by the Assad regime in the conflict.

This administration, my government, many other governments have said unequivocally over the months that Assad must go. So what happens if he stays? Is that without any consequence? At the very least Iran is going to be watching and is going to draw a conclusion about American resolve and determination. Russia and China will be watching. If this audience wants to sustain American leadership of a new kind after the difficult decade that we've had, then I think we need an active, concerted, comprehensive policy in Syria, and not be defeated by the fear that anything we do will suck us in militarily. And as Nick has said, that does not need to happen. We've got a program which addresses the humanitarian problem, which accepts that this opposition is not perfect, but there is a national coalition which has formed, which-- with which the U.S. government recognizes as the alternative government of Syria, which the European governments and Arab League governments see in that role as well.

And there are still moderate rebel forces in the form of the Free Syria-- channel arms through as a way of changing the situation on the ground, which is what we've got to do. Assad will not move by himself. It will require persistent determined pressure over a range of areas, diplomatic, humanitarian, and then with these limited arms supplies from the United States and indeed from other Arab countries.

So to my mind that is a dog in the fight. That's a strategic stake for the United States and for Britain and we've got to support this trend in the Arab world and we've got to support the Syrian people.

## Round 2

### Moderator
Claim: Thank you, Nigel Sheinwald. Your time is up. Ladies and gentleman, Nigel Sheinwald. And that concludes round one of this Intelligence Squared U.S. debate where the motion being debated is: The U.S. Has No Dog in the Fight in Syria.

Remember, you voted before the debate and you will vote again once after the debate, after you've heard the arguments and the team who has won more percentage points of your support when the debate is over will be declared our winner.

Now on to round two. Round two is where the debaters address each other directly and also answer questions from you in the audience and from me. We have two teams of two arguing out this motion, The U.S. Has No Dog in the Fight in Syria. Graham Allison and Richard Falkenrath are arguing in support of the motion, no dog in the fight. They argue that Syria just does not represent a vital U.S. interest, that the U.S. has no options before it that can lead to a desirable solution or a solution that would actually improve the problem, that there is no dog to pick in that fight, that the opposition fighting Assad is so fractured that it's difficult to know who should get the arms and a lot of them are people who would not end up being our friends. They say this is not one where the U.S. should be leading.

Their opponents, Nick Burns and Nigel Sheinwald, say this is one where absolutely the U.S. must lead. The U.S. cannot sit this out, that it has a moral and pragmatic imperative to get involved for humanitarian reasons, for political reasons. They say that if Assad wins our allies in the region are really going to be in trouble, and they say there is a political process already in place that represents the dog that the U.S. can ride on this, and should ride all the way. They are hopeful that it will ultimately produce results. I want to put a question to the side that’s arguing that the U.S. has no dog in the fight in Syria. It looks as though what we have here basically to some degree is a disagreement about definition of terms. You have talked about not having a vital interest in getting involved in Syria, and I want to put to you the question, just I think this allows us to go to some specifics, to look at some of what’s actually happening there, and ask you to tell us why that’s not vital.

For example, as your opponents have pointed out, if Syria melts away as a state, even if-- with or without Assad, if it ends up being a chaotic place fueling and inviting a radicalization of a generation who would be our enemies, who would end up coming to this country with weapons, doing bad things to us, how is that not a vital interest, and why isn’t it? Graham Allison.

### Conspiracy Advocate (CA)
Claim: A very good question. I think the U.S. is a global power. And I think-- if I go back to Nigel's point just for a second-- the-- I think you set up a bit of a straw dog with the-- with respect. The notion that there's anywhere we don't care about-- excuse me, we care about things in 200 countries today. Things happening everywhere impact U.S. interests. We don't sit with indifference for Sudan, for Somalia, for Pakistan, for Iraq, for any of the dozen wars that are going on now. But because the ability of U.S.-- both in terms of mind share and also capabilities is limited-- about each case, your question, John, is right-- the very right question.

If Syria melts down and comes to be three states or more chaotic than it is today, will this be horrible? Yes. Will it have bigger impacts on U.S. interests? Of course. Does it rise to the level of vital-- if this--

### Moderator
Claim: Well, does it rise to--

### Conspiracy Advocate (CA)
Claim: --such that--

### Moderator
Claim: Does it rise to the-- does it rise to the level of justifying intervention?

### Conspiracy Advocate (CA)
Claim: That's right.

### Moderator
Claim: And you're saying it doesn't. Why not?

### Conspiracy Advocate (CA)
Claim: Does it rise to a level of concern that would lead-- that would compel a responsible government to intervene militarily-- if that's the only way to resolve the issue? And I would say the answer is no. If Syria melts down, this will be horrible. It will have impacts on Lebanon, and on-- and on Iraq, of course. It'll exacerbate the Sunni-Shi'ite division. Of course. All those things are also happening before Syria.

### Moderator
Claim: Could you--

### Conspiracy Advocate (CA)
Claim: If Syria--

### Moderator
Claim: Could you take-- I want to go to the other side, first, Richard. But I just want to ask Graham-- just take 15 seconds-- what would represent a threat to America's vital interests? Just to put the marker out there.

### Conspiracy Advocate (CA)
Claim: Yeah. If we look to the year ahead, Iran getting nuclear weapons.

### Moderator
Claim: Okay. Let's go to the other side. Who would like to respond? Nick Burns or Nigel Sheinwald? Nick Burns.

### Scientific Advocate (SA)
Claim: Well, I just say this. The question is-- who has a dog in the fight in Syria? Do we have one? Do we care who wins and loses?

### Moderator
Claim: Well, Nigel, can you-- you've-- I'm sorry. Nick, you made that point in your opening. I just want to see if you can respond to--

### Scientific Advocate (SA)
Claim: I'm responding to-- I'm responding right now.

### Moderator
Claim: Yeah. All right. Sounds very familiar.

### Scientific Advocate (SA)
Claim: Good. You try to repeat your major themes.

### Moderator
Claim: All right. Fair enough. I'm really not trying to clash with you, and I-- All right.

### Scientific Advocate (SA)
Claim: We want you on our side, John.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: I was addressing Graham's point. And, you know, we are good friends and colleagues. And I think that Graham and Richard have raised some really important points. This is not an easy choice. In fact, it's really difficult. And generally, in my career, John, this answers the question. American presidents do not put American troops into harm's way unless it's a vital interest.

But that's not what President Obama's trying to do. He's not trying to put American troops into Syria. In fact, he said he won't. And Nigel and I are just arguing, because of the humanitarian interest, because of where Syria is, its proximity to Israel and other countries, because of the imminent victory of Iran in a major power play, we need to be active with President Obama's plan. But it doesn't have anything to do with vital. And vital is not in that question.

### Moderator
Claim: And I think the key disagreement-- and both sides use this word-- was the word “lead.” And this side said this is not one where the U.S. needs to lead. This side says the U.S. needs to lead and quoting you, Nigel Sheinwald, you can't sit this out. So, I want to take that back to Richard Falkenrath. This question of leadership.

### Conspiracy Advocate (CA)
Claim: There's a lot of information that's coming out of Syria now, about what the people engaged are suffering from this fighting. Actually, I think-- and as far as they're concerned, we're sitting this one out. I mean, there's-- there is-- they're very clear, the reporting out of Syria is the U.S. is having no impact on the ground. In fact, the narrative looks more like Al-Qaeda is having an impact and Hezbollah is having an impact. But we are not.

The-- it strikes me, as you kn0w, President Obama is stuck with no good options. And this will go down in history as a failure of his policy. But he's confronted only with options which make the failure even worse, because in order to really make an impact here, we have to make a difference on the ground. It's not enough to figure out who to write a check to or ship a bunch of light arms to. You have to figure out, who are we tipping the military balance in favor of so that there's a better outcome at the end. And we are not doing that at this time.

### Moderator
Claim: But with your-- I don't want to say approval-- but you think that's the right choice at this point?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Okay. Let's take it back to Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: Well, I--

### Moderator
Claim: You're very good with the word yes. Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: I just think that Richard's analysis is flawed and slanted in his favor, because the reality is that there is a political opposition in Syria. It's fragmented, but there is a central group that's all of us in the United States, in Europe, in the Arab League are supporting and recognize an alternative government.

And there is a group called the Free Syrian Army that can channel arms and it could conceivably tip the balance quite quickly. Just this week we've seen examples of the attempted assassination of Assad. I'm not recommending that. But it happened. And we've seen continued taking of territory by the moderate and recognized groups. I accept that there is Al-Qaeda involved. There are a whole bunch of other groups involved. But that's been the situation throughout the Middle East over the past couple of years. And in all those other areas, we haven't said that the Tunisian president must stay. We haven't said that Gadhafi must stay. We haven't said that Mubarak must stay. We couldn't say that and accept that the will of those people is just going to be completely ignored. And that's what worries me about our opponents' position, that they are really arguing an old-fashioned view of realpolitik. Keeping someone in power because it's the easiest option.

### Moderator
Claim: All right. Let me-- Nigel, let me just interrupt you to give Graham a chance to respond to some of your earlier points. So, Graham Allison.

### Conspiracy Advocate (CA)
Claim: Yeah. I think your-- Nigel, what you're saying is persuasive. But-- okay. The Free Syrian Army representatives and the opposition-- as Rich said-- a lot of Americans know them. These are guys that we meet in Turkey. You don't see them fighting on the ground in Syria. So, they're spending their time talking to folks like us, not having any control over 1,200 different groups who are fighting independently. Chairman Dempsey said last week-- in that-- or two weeks ago-- in very important testimony he says here, just a quote “About six months ago, we had a very opaque understanding of the opposition. Now I want to say it's even more opaque.”

### Moderator
Claim: Okay. Nick Burns?

### Scientific Advocate (SA)
Claim: Just to point a fact-- the Free Syrian Army is inside Syria.

It's commended by General Salim Idris, our colleague David Ignatius of The Washington Post has reported on his activities there. It's the National Coalition, the political group that, you know, goes around the world, raising money, trying to raise consciousness. I would just say another thing about General Dempsey's testimony. All true. This is going to be-- if the United States were to get involved, it would be difficult. But President Obama, his boss, is saying, “We're not going to put troops on the ground.” So I think the real question here that I wanted to address to Rich and to Graham-- and this is hard-- is it's certainly legitimate of you to say there's a risk in what you're proposing, a risk in action. But I think also the onus has to be on you to answer the question-- what is the risk of inaction? If we do nothing, do we suffer? Do American strategic interests suffer?

### Moderator
Claim: And I heard a little clap over there. That's fine, to do that. So-- and again, as I said earlier, because we're a radio broadcast, it tells the radio audience that ultimately will hear this that you're all here. So-- you don't have to overdo it, but it's not like a presidential debate, where you're not allowed and you have to sit on your hands. So-- just so, that's fine.

But it's a great question. And I think it's one we all want to actually hear this side answer. What is the-- what are the consequences of inaction? Now, you've said already you don't think they're vital. But what are they? Richard Falkenrath.

### Conspiracy Advocate (CA)
Claim: Well, first, it's not as though we're inactive. We're doing something. It's just not making any difference. And there's two halves-- and this has been the case for a long time. I mean, this has been-- how long ago was it that President Obama said he needs to go? Assad needs to go? But there's two halves of the argument. The first is about vital national interests. And I think-- it seems to us that you agree with us, that it-- we haven't met that bar. But there's a second half, which is, you need to reasonably articulate a plan that gets you to a better place when you're done.

And if you're unable to do that, then you are, by default, stuck with the bad consequences of inaction or of a policy that really isn't making much difference.

And so, it-- in fact, the onus is on you to articulate an alternative plan that gets us somewhere-- when-- the interestingly-- you know, the chairman of the Joint Chiefs of Staff just testified to this effect for his confirmation hearing. And he basically said there isn't one. And he was-- he went through six different options. And he said, all of them-- none of them work.

### Moderator
Claim: Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: All of them are problematic. But of course, the Chairman of Joint Chiefs supports the limited supply of arms to the Syrian rebels that the president has authorized. So, he believes that that is a reasonable policy choice, which will not drag America in in the way that the other policy options he analyzed might. Now, I think the issue is, is this any different from the other situations we've seen in the Middle East? All very difficult. And in Tunisia, you saw a messy political protests leading to an election and the election of a moderate Islamist group.

In Libya, everyone rightly said, was chaos. But there was a transition process. There were elections, again, with a moderate Islamist group elected. It's still very chaotic in Libya, but we're all going to have to live with 10 or 20 years of unwinding of this extraordinary set of events in the Middle East. We can't wait for that perfect moment to arrive.

### Moderator
Claim: I want to put a question back to this side. It's saying that this-- U.S. has no dog in the fight in Syria, the question was put to you, "What will be the consequences of inaction?" You parried with a question back to the other side. I allowed it to go. But I really want to know what your answer to the question is, the consequences of inaction. Let's take a specific your opponents put to you, not rescuing this humanitarian crisis. Nigel Sheinwald in his opening statement said, "This is just going to look real bad." We talked, I mentioned earlier, Rwanda, great regret about that. Is it not significantly harmful to American interests and reputation not to be acting in the case of the Syrian refugees and the killing that's going on there?

### Conspiracy Advocate (CA)
Claim: And the answer is, of course it is.

### Moderator
Claim: Graham Allison.

### Conspiracy Advocate (CA)
Claim: And of course the U.S. is acting. I mean, let's be clear.

Who is the largest supporter of humanitarian assistance to Syria today? The U.S. President Obama announced last week another $195 million. We have a billion dollars, and we should be doing much more, and we should be raising much more from other parties.

### Moderator
Claim: But, Graham, the--

### Conspiracy Advocate (CA)
Claim: that--

### Moderator
Claim: --I think the sense of the question is not strictly about blankets and tents. I think part of the question is bringing back, say, for example, the example of Bosnia where a refugee crisis-- in addition to other things-- but a refugee crisis prompted very, very aggressive American action not just in the--

### Conspiracy Advocate (CA)
Claim: I think that's a good analogy, and I think in that instance there were very special circumstances. Nick has actually written about this. And he and I agree on this. There were very special circumstances in which a limited U.S. military intervention made the difference at the margin to get to a better place. And I think that was a good example. In this instance, why is it different?

We have an old professor that used to make a list where you draw it down the middle of the page, you say, "Similar," and "Different." The similarities in this case are superficial. The differences are profound.

### Moderator
Claim: Nick Burns.

### Scientific Advocate (SA)
Claim: I guess what I'm thinking is that, you know, I think President Obama is faced with a very difficult choice. Part of the problem is that Assad is trying to frame the international debate, "It's me against the jihadists. You Americans don't have a dog in the fight." Actually, if you listen to the Iranians and listen to Russia, that's exactly what they're saying, "Stay out, you don't have an interest." What we're saying is, "We're facing a complex environment there. There are al-Qaeda groups, and there are jihadi groups." And Richard knows more about this than anybody, he's right about that, but there also is the moderate element. The only way to help the refugees and people of Syria is to support that moderate element. Why should we want to see the jihadis and the Syrian government to be the only people armed?

We have to give these moderate rebels a chance. That's the basis of President Obama's policy, which we support.

### Moderator
Claim: Richard Falkenrath. Richard, can you hold for just one second? After Richard speaks, I'd like to go to the audience to begin getting questions from you. What will happen is the house lights will come up. If you raise your hand I'll call on you. A mic will be brought to you if you could stand up. You'll be recorded and filmed, so if you could just state your name and ask a question that's terse, that doesn't take more than 30 seconds or so, that really keeps on point, that gets these teams to debate on this matter. And I really will discourage you from debating with them. Richard--

### Moderator
Claim: Can we ask questions?

### Moderator
Claim: No, you don't get to ask questions that far away. You can go sit in the audience. Richard Falkenrath, your response.

### Conspiracy Advocate (CA)
Claim: This-- Nick said a key term there, and I think their entire argument hangs on a very slender thread around the key term of "moderate opposition." And so we do, in fact, have a national coalition that was in December, not that long ago, recognized by the, quote, "friends of Syria," as the place to send the money.

But it is dominated by the Muslim Brotherhood, and it is essentially a playground for Qatari, Saudi, and UAE-- and Turkish influence peddling, that is internally divided, that has achieved notional external legitimacy, since someone has to get the money, but has no internal legitimacy. The Free Syrian Army, our best hope for the moderate people on the ground fighting, is not integrated in any way. It's a loose umbrella of dozens of different fighting groups. And let's just be clear, our friends in the Free Syrian Army, they were the ones who criticized us for deeming the Al-Nusra Front a terrorist organization because they coordinate their operations occasionally and the Al-Nusra Front bailed them out of a situation where they were about to get annihilated by the Syrian Army. So these are our friends? This is the moderate opposition and the dog that you think we have? I mean, this-- we don't get to pick the dominant post-Assad faction in Syria.

### Moderator
Claim: Response from this side before the questions? Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: My question back is do you think that, that representation of the opposition mirrors the Syrian people. Let's go back to the Syrian people. Let's think what caused them to go into the streets and to rebel and to risk their lives two and a half years ago. And I think the Syrian people are basically moderates. There is a strong tradition of inclusiveness, indeed of a secular tradition in Syria. We have to get to the point where those people are given the chance to express their point of view, and I don't think I have enough confidence in the way that people operate to feel that if they're given a choice they won't vote for extreme voices. I think you've over-caricatured the fragmentation and extremism of the opposition. I agree it would've been much better if we'd taken much firmer, concerted, and comprehensive action two and a half years ago when the-- extremists and Islamist elements were much smaller than they are today, but I'm afraid the logic of what you're saying is give it another couple of years and it'll be much, much worse.

### Moderator
Claim: All right. Let's go to questions, please. Sir, right on the aisle and, again, if you can stand up and tell us your name.

Mateo Grodofola Hi. My name is Mateo Grodofola I have a question predominantly for the side which is saying that we should, in fact, intervene in Syria. Given the way that large opposition groups like the Free Syrian Army have brutalized and attacked a variety of minority groups, such as the Kurds, the Alawite, the Christians, in Syria, can they necessarily be deemed to have a moral high ground ? Are they the good guys?

Have they disqualified themselves from our support? Nick Burns, would you like to take that question? Thanks for the question.

### Scientific Advocate (SA)
Claim: What we are proposing, and what President Obama is doing, is not proposing a military intervention in Syria. We're proposing an intensified effort by the United States to rally international support for those moderate elements. Are they perfect? No.

But compare them to the other side, to the outside government using artillery against civilian neighborhoods in Damascus and Aleppo and other Syrian cities, razing Homs and Hama. Bashar al-Assad did that as his father did in 1982. So, there's a big difference between the Syrian government and the moderate rebel forces, and in that relative light they are the good guys.

### Moderator
Claim: But do we need to be concerned about, as the questioner asked, the nasty stuff they've done? I mean, deeply concerned?

### Scientific Advocate (SA)
Claim: Sure we do, and as I said before, neither of these sides are pure, but there is a difference. And, you know, I think that what all of us are struggling with is that, you know, there is a risk of doing things and there are a lot of risks involved in what we're proposing, what the president's doing. We just think if we do nothing the status quo continues. The real victims of that will be those 6.8 million Syrians who've lost their home or lost their job or can't live in the way they want to live. And so they're the people we've got to keep focused on.

### Moderator
Claim: On each of these questions I'll give the other side a chance to jump in if you want to or we'll go back to questions. Graham Allison.

### Conspiracy Advocate (CA)
Claim: Very briefly, I think the question was right on target, and I think to Nick-- we're not doing nothing. Nobody's proposing doing nothing. As I said before, we're the largest humanitarian assistance being provided. We're trying to work with the neighbors. The U.S. military is currently in Jordan and Turkey trying to prevent the spread of the violence. We're currently trying to work with an international coalition to get negotiations going. We've been trying to get a peace negotiation in which the Russians would be co-hosting some negotiated outcome, which is our best hope. All those things we're doing, not successfully I would say, so the question is if it continues in this way with the killing and all the other things that we find as negative impacts for us, if it's so important to us, that if the only way to secure our interests is military intervention, we should do so. And we think the answer is, unfortunately, no.

### Moderator
Claim: I do want to put the question to this side is there a level that this thing would reach where you would justify-- where you would support military intervention? Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: Well, I think that if you saw an extraordinary collapse in the situation in Syria, if you saw the chemical weapons getting into Hezbollah's hands or al-Qaeda's hands, then those exceptional circumstances would, I'm sure, cause the United States and cause its allies to think again. I don't think there'd actually be any difference between us on that. I think we're looking more at the situation today, whether it can be allowed to continue and ours is a very, very strong advice is that it can't.

### Moderator
Claim: Okay. Another question. Sir, right down in front here. People who are farther back, I have a bias towards the front of the room because I don't see that well.

So, if you're vigorous with your hand waving, I'll see you and I'm not joking. Sir, please.

Stefan Edlis Stefan Edlis My question has to do with the Israeli-Syrian border. For the last 30-- perhaps longer years, this has been the most quiet border in Asia, in Europe, wherever you can see it. How can it be in Israel's interests when the Assad regime collapses, the Sunni majority will become jihadists, how can that be in Israel's interests?

Well, let me ask you, sir, if I can rephrase the question, because our motion is really what's in U.S. interests. Are you identifying U.S. interest in Israeli interests in this case?

Stefan Edlis How can that be-- U.S.-- and I--

Okay. Fair enough.

Stefan Edlis-- amend the question-- how will that be in the U.S. interests?

Thank you. I'd like to put that first to the side that is arguing that the U.S. should have a dog in the fight in Syria.

### Scientific Advocate (SA)
Claim: I think--

### Moderator
Claim: Nick Burns.

### Scientific Advocate (SA)
Claim: I think that American and Israeli interests are identical. And they have been for a long time on the Golan Heights. And you're right.

The curious, ironic thing was that the Assads kept the peace with Israel and-- on the Golan, between 1967 and two years ago. But the problem the Israelis have now, strategically, is that that Assad regime is significantly weakened. And it looks like-- you know, Assad had some tactical victories in the last couple of months. He suffered two defeats in the last week. He cannot control his country any longer, so the Israelis can't bank on that. What we have to hope is that moderate elements in the Syrian opposition will emerge victorious, the kind of people who will understand they have to keep the peace with Israel as well in the future. That's the basis, I think, of what President Obama is trying to do.

### Moderator
Claim: Richard, do you want to take that? Only-- I'm only asking you because we haven't heard from you in a bit. Or you can seek your partner.

### Moderator
Claim: Graham Allison.

### Conspiracy Advocate (CA)
Claim: This is a-- it's a great question. And I was talking to one of the leaders in the Israeli National Security community, who's a good friend of mine, last week. And so, I asked him just your question. Does Israel have a dog in this fight? And he says, “Absolutely not.”Let's be clear if there's this transfer of advanced arms by the Syrians to people who are fighting Israel, like Hezbollah, we are acting-- and we're acting now-- so, Israel has attacked half a dozen times, particular instances of transfer. But he said, our official position and our operational position is we will not intervene in the civil war. That's the quote.

### Moderator
Claim: Another question? Ma'am?

Emma Rubsax I feel this has moved very quickly--

Will you just tell your name-- us your name, please? Sorry.

Emma Rubysax Oh, yeah. Emma Rubysax I feel that this has moved very quickly from dog to feasibility. So my question is about feasibility. You mentioned the peace talks which have been stalled. And to what extent can increased intervention from the friends of Syria and the United States give both sticks and carrots to give Russia-- particularly-- an incentive to get Assad to the table and negotiate a transfer which might provide some opportunity for those moderate elements?

Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: Well, I think this-- particularly the United States-- have tried that with the Russians, over a long, long period, to get them to change their position sufficiently to get Assad seriously to the negotiating table. And it hasn't worked so far. I'd have to say, in the present state of U.S.-Russian relations, doesn't look more likely to be more successful, you know, in the weeks and months ahead. I fear that the only thing that will get Assad to negotiate or allow his team to negotiate is a change in the situation on the ground. And I think this is where we do differ, the two teams here. We're saying there are things that can change that situation on the ground. And the rebels say themselves, they want more American and international support. They want the arms from the United States. They want the arms from Qatar and from Saudi Arabia and elsewhere. And they believe that with them, they can tip the balance, change the situation on the ground sufficiently to put Assad and his regime under pressure and start a negotiation. And the opposition in Syria isn't saying that Assad-- the whole regime cannot be part of the negotiation.

They're saying, we can't negotiate with Assad himself, but we're not going to do what happened in Iraq. We're not going to banish the whole of the regime, the whole army, the whole public service. We're going to negotiate with the people around Assad, form a transition, and then let the people decide.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: And I think it's conceivable.

### Moderator
Claim: Richard Falkenrath, it's part of your argument is that the undogworthiness of this battle is the impossibility of any of these things coming to being-- or the near impossibility. What's your response to the scenario just laid out?

### Conspiracy Advocate (CA)
Claim: I think-- first Nigel is correct that in order to get a negotiated settlement with Assad, you do need to change the situation on the ground. You do need to change the balance of military power in one way. In fact, it has changed in the last year in two ways-- Hezbollah entered in force from Lebanon. And Al-Qaeda entered in force from Iraq. Not us. And so, I think the basic diplomatic premise is correct. You need to shift the military balance in such a way that it is in their interests to achieve a negotiated settlement.

Now, that's-- the problem with that is that's what we call a proxy war. And so, it is a recipe for entering a proxy war in Syria, not just against Assad, but against Al-Qaeda. And so, proxies are what we do when we want to change the military balance in a country but don't want to be there ourselves. And so, you are left with no alternative on your side of the debate if you do want to change the ground-- the situation on the ground but to engage in a proxy war in Syria which the military analysis-- which is not favorable to that case.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters-- two teams of two-- debating this motion: The U.S. Has No Dog in the Fight in Syria. I can go to another question, but Nick Barnes, I don't know if you wanted to respond to Richard. I thought that I saw that you-- you-- you're-- You're good?

### Scientific Advocate (SA)
Claim: No. I think Richard--

### Moderator
Claim: Go ahead. Nick Burns.

### Scientific Advocate (SA)
Claim: --has addressed the central question-- does it concern the United States that Iran is rising to power in the Middle East?

A victory by Assad is a victory for the mullahs in Tehran. Therefore, it's in our strategic interests to push back. We choose not to push back with American troops on the ground. But if we can push back by weakening Assad and by supporting the moderates and making it more likely than not that the moderates will succeed and be victorious eventually-- that's a defeat for Iran. So, a lot of what we're doing here is trying to counter and limit Iran's inroads into the heart of the Middle East.

### Moderator
Claim: Sir, in the far back, in the white t-shirt?

Steve Began Thank you. My name is Steve Began And I have a question for both panels. We're actually talking about a very complex issue that's playing out before us. I think the real test of each of your positions is going to be in the outcome. And so, what I'd ask you to do is look forward to a potential outcome. If your position prevailed - - and we aren't talking about getting in-- intervening or not. We're talking about degrees of intervention, really, here, I think, between the two panels. If your degree of intervention-- if your position prevailed, what outcome, within realism, do you think would be most favorable for the United States interests?

That's a terrific question. I'd like to put it first to the side that's arguing the U.S. has no dog in the fight in Syria. If you-- if-- what policy prescription are you actually suggesting and what's the outcome of that prescription, if you can predict? Graham Allison.

### Conspiracy Advocate (CA)
Claim: Absolutely great question. I would say that our hope would be-- and the best hope-- but it's a stretch-- but the best hope is a situation in which the combination of humanitarian assistance to the victims and close working with the neighbors in the region and a strategic concept of a government that could exist after a transition leads to a negotiation in which there's an extended transition of power. And I would say that's a stretch. That's a distant hope. But the alternatives to that-- if I looked at them-- are worse.

### Moderator
Claim: On this side? Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: I don't think our recipe is fundamentally different. It's the same. I think our view is that that has to be approached more urgently. And we need to put more tools on the table, get more involved short of being sucked into boots on the ground and real military action. And the worry I have is that it gets much more difficult to see that political transition ending in a reasonable representative Syrian government the longer this goes on. And the problem is that we've waited a long time. The extremists have the upper hand. And what you're saying, I think, is that we just have to accept that Al-Qaeda and Hezbollah should slug it out. We say no. There remains a distinct and credible moderate force within Syria that we have to support and get to the point where they can make their own decision.

### Conspiracy Advocate (CA)
Claim: one more--

### Moderator
Claim: Yes. Graham Allison. Yes. Allison.

### Conspiracy Advocate (CA)
Claim: I-- I mean I think Nigel is speaking directly to the point. But I would have to-- Fareed Zakaria who has been struggling with this a lot-- had a good line recently. And I wonder if you disagree. He says, quote, “We want an outcome in Syria that's even more ambitious than the one we sought in Iraq. And yet, we imagine that we can get it by a no-fly zone or even less than that.” So, do you disagree with that?

### Scientific Advocate (SA)
Claim: I don't disagree fundamentally. But I'm just looking at the other comparable examples. And my comparable examples will be not ones very appealing to this audience or to a British audience in terms of what we'd want politically. But I look at Tunisia. I look at Egypt. I look at Libya. I see all the reasons why it would have been very convenient to keep the old regimes in power, but I don't see Al-Qaeda in charge in any of those places. And I don't see why that needs to be the case in Syria either.

### Moderator
Claim: We’ll hear from Richard and then-- Richard Falkenrath.

### Conspiracy Advocate (CA)
Claim: A lot hangs on your assessment of the character of the Syrian state. And one of the key differences between Tunisia and Egypt, lesser extent Libya, is the sectarian division in Syria is far worse. And so the speed with which the protest took off and the violence took off was not merely a moderate bourgeois rebellion against an autocrat. It was the emergence of a sectarian conflict which has been suppressed by force by the Alawites, a Shi’ite sect, for years, at least going back to 1970, and where the only other active political entity, the Muslim Brotherhood, was destroyed viciously by Assad in Hama. So, I mean, to say that-- to hang so much on the idea that a moderate Syrian secular leadership and consensus will emerge, as Graham says, that's-- we didn't even develop that in Iraq.

### Moderator
Claim: Nick Burns.

### Scientific Advocate (SA)
Claim: I think that-- I think that Graham asked a fair question, and Fareed's a smart guy. The difference between the U.S. intervening and Iraq in March 2003 and what we're talking about now is that the Syrian moderates have a lot more support, frankly, than the United States did going into Iraq. If you look at Turkey's support, and the support of all the Gulf countries, nearly every other Arab country, all of Europe, and the United States, and Canada, I think that's probably the best way for this loose international coalition to succeed eventually in helping the Syrian rebels to stay together and to draw on that international unity. And remember the question here is not whether we have a vital interest, not whether we're going to intervene militarily, we're not going to do that, do we care who wins, and do we put our shoulder behind that side, that's what President Obama's said he wants to do. And I find that logical.

### Moderator
Claim: Right in the center.

Lindsay Hanahan Hi. My name's Lindsay Hanahan and I'm desperate for some hope here. So we have a new leader in Iran. And I'm hearing this conversation about the proxy fight. Does the fact that we have a new leader in Iran give us some possibility he's come up and said that he is willing to reach out?

Can you rephrase your question, and I know that you can, that relates it to what-- kind of what the American interest in being involved is?

Lindsay Hanahan If we're looking at do we or do we not have a dog in the fight, and part of that hinges on who that dog is that we're fighting as well, I believe, so I'm saying if who we're fighting changes in terms of this proxy, do we now have a dog in the fight if Iran pulls out and--

And who's on the other side?

Lindsay Hanahan Who's on the other side--

Right, okay.

Lindsay Hanahan-- changes.

Great, actually really well skillfully done, thank you. Who'd like to take that side first? Richard Falkenrath.

### Conspiracy Advocate (CA)
Claim: I'm arguing the U.S. has no dog in the fight. I don't have a crystal ball but I doubt it. I doubt that the new elected president controls it. It's a longstanding-- I mean, Syria is Iran's last friend in the region. Their support for Hezbollah goes back to 1982. Syria's the funnel through which the arms get to Hezbollah. And the new president is not, in fact, the supreme leader. The supreme leader is the supreme leader. And so this policy seems pretty well marbled in the Iranian state, and I doubt it will change of its own accord just because of an election.

### Moderator
Claim: The other side, Nick Burns?

### Scientific Advocate (SA)
Claim: I think it's a really good question. And I don't disagree with Richard. I think he's probably right. But there is a-- possibly an opportunity here. Rouhani was inaugurated last Sunday. He's a different guy than Jalili, the former nuclear negotiator. The Europeans found him to be more pragmatic and straightforward when they dealt with him a couple of years ago. So we've been talking this week at Aspen. How should the U.S. approach him on this subject of Syria on the nuclear question? We ought to give negotiations a chance.

We haven't had a serious negotiation with Iran and sustained since the Jimmy Carter administration. So we ought to open up a conversation. We may not be able-- probably won't-- I think Richard's right-- change their minds, but let's put Syria on the table, and let's let the Iranians know that this is a big deal for us, and for Israel, and for Europe, and see if we can make some progress there. It's at least worth a try.

### Moderator
Claim: That was a great question. Thank you. And, sir, over here, and I think you might be our last question. Jenna, do we have more time after this, or we need to-- Arly Sherman My name is Arly Sherman As I recall, since I think I'm older than most of this group, that Harry Truman said that it was not in our special interests to defend the Korean Peninsula or the Straits of Formosa. And it was a green light for the Russians, the Chinese, and everyone to move. Are we not giving a green light now for Iran to move and are moving and doing the same thing that Harry Truman did?

Nigel Sheinwald.

### Scientific Advocate (SA)
Claim: Well, that's our worry. I mean, that's one of our concerns over this continued stalemate. Letting Assad stay in power is de facto-- it's a victory for Iran. It extends further their influence because they have thousands of their own people now in Syria in a way that they weren't a short while ago. And I think that, although I too agree that there's going to be-- very unlikely to be an immediate change on the Rouhani’s part, nevertheless, we want to create uncertainty in their minds. And the uncertainty that Assad may go and that something different may emerge in Syria. I think it's a good thing in trying to get them to negotiate seriously with us on the other issues.

### Moderator
Claim: And Graham Allison.

### Conspiracy Advocate (CA)
Claim: Well, I would say in one word, no, okay? The situations are entirely different. There are numerous places in the world where the U.S. does have vital interests.

There usually we have an alliance. For example, Israel we regard as an ally. If there's an attack on an ally we think this reaches the level of a threat to our vital interest, and for those we are prepared to act. There are many, many other situations in the world in which we're not prepared to act. That doesn't mean that on some occasions we don't. North Korea is a good example. But it seems to me that we went around everywhere saying to everyone if something bad happens in Somalia we're going to become involved militarily. If something happens in Sudan we're going to become involved militarily. If something happens in Pakistan, where there's an even bigger war right-- we're going to become militarily involved. We will soon find the U.S. everywhere.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate. And here's where we are. We are about to hear brief closing statements from each debater in turn. Those closing statements will be two minutes each. Remember how you voted just before the debate, immediately after these statements we will have you vote again. So, this is their last chance to try to win over your votes.

Our motion is this: The U.S. Has No Dog in the Fight in Syria. Round three, closing statements, here to speak first against the motion, Nicholas, you do the-- seated for the closing statements-- to speak against the motion, Nicholas Burns. He is professor at the Harvard Kennedy School and former undersecretary of state for political affairs.

### Scientific Advocate (SA)
Claim: Thank you. And I've really enjoyed this debate. Thanks to Richard and Graham. Eighteen years ago at the height of the Bosnian war in 1995, I found myself a State Department spokesperson and my job basically was to give daily press conferences and defend the Clinton administration's foreign policy. One of the toughest and most painful moments of my entire career came in July of that year when the Bosnian Serb military went through a Dutch U.N. garrison outside the city of Srebrenica. They went into the town. They rounded up-- well, they divided the men and the women. They rounded up 8,000 men and boys and they shot them.

It was the worst massacre in the world since the Nazis massacred European Jewry. And I had to explain the following days, as did my White House colleague, Mike McCurry, why didn't the United States act? Why weren't we involved? Why hadn't we made sure that the United Nations had a tougher mission in Bosnia? And a lot of us in the Clinton administration at that time vowed that we would never again stand by with all the power of the United States and our leadership and let something like that happen.

Now we can't be everywhere. Graham's right. We can't solve the world's problems. We're not the world's policemen. We can't intervene everywhere. But at least we can try without putting military forces in, to help the people of Syria. The people who are supporting the rebel groups are the majority in Syria. They deserve a chance. And the approach that Nigel and I outlined is far better than doing nothing, because if we say we have no dog in the fight, we consign the Syrian people to the brutalization of the Assad government. We do have a dog in the fight.

It's to lead by moral example, to do what we can to help those people survive. And it may be two, three, or four years before they're able to get on their feet, form a new government and kick Assad out, but we need to stay the course with them. Thank you very much.

### Moderator
Claim: Thank you. Nicholas Burns. Our motion is: The U.S. Has No Dog in the Fight in Syria and here to speak in support of the motion, it means he thinks the U.S. has no dog in this fight, Richard Falkenrath, a principle with the Chertoff Group and former deputy homeland security advisor.

### Conspiracy Advocate (CA)
Claim: So, if we interpret this motion as do we care, there's no difference between the two panels. We do. I think Graham, I, Nick, Nigel, we equally abhor this violence, and if we could stop this butchery we can, we would. But the proposition before us is what to do about it. And here, I think you've heard slightly different prescriptions from Nick and Nigel and I'm going to choose to focus on the one I heard from Nigel, which I think is correct, that a political outcome in Syria requires changing facts on the ground.

In order to change the facts on the ground you need to tilt the military balance against Assad in some way or another. That is what we call a proxy war. I have no objection-- on a principle basis-- to proxy warfare. But I do, on a pragmatic basis, which is if we are going to get into them, we should have a reasonable belief that we can succeed. And that, unfortunately, is not the case here. And it's not the case for several different reasons, one of which is our proxy is not very reliable, and in fact, not very powerful, this moderate opposition. Another is the opponent is deeply entrenched and their own sponsors-- Hezbollah, Iran, Russia-- are completely uninhibited by the strength that we have. Russia is sending advanced anti-aircraft systems to Syria right now. There-- and apparently lawful under international law. And we can't even-- we struggle over whether to send light arms.

So I think the other side, though they wish to avoid saying we're for military intervention-- in fact, the essence of their political strategy requires a change of the military facts on the ground. And that involves giving military support to the fighters. That is that we call a proxy war. And unless you are very, very sure that you will prevail in the end, it strikes me as an unwise policy. And if you interpret the motion that way, I think you need to say-- invoke with-- where Graham and I stand.

### Moderator
Claim: Thank you, Richard Falkenrath. And our motion is: The U.S. Has No Dog in the Fight in Syria. And here to speak against this motion-- it means he does think the U.S. has a dog in the fight in Syria-- Nigel Sheinwald. He's a former British ambassador to the U.S. and foreign policy and defense adviser to Prime Minister Tony Blair.

### Scientific Advocate (SA)
Claim: Ladies and gentlemen, well, thank you very much for listening this evening. I'm not a gung-ho interventionist. I've spent my life being as a pragmatist and a realist about these things. And as you mentioned at the beginning, John, six years ago, my prime minister, Tony Blair, sent me to Damascus to try to negotiate with President Assad for a better, less confrontational relationship between Syria and our countries.

And we made a bit of progress. We had a long day of negotiation. We made a bit of progress in relation to Syria's relationship with Iraq. But on the big issues-- on Iran, on Lebanon, on his overall relationship with us, I came away empty-handed.

And I concluded two things from that. The first thing was, the importance-- the really crucial importance of Syria in its region and internationally. Things won't get done in this region-- and America has many interests-- Iran, Israel, much else in the Middle East-- without Syria being much more stable, having much better future than it has today. And secondly, I concluded Assad wouldn't make good choices by himself. Unfortunately, things have collapsed significantly since then, because he reacted as badly and unwisely as he did to the revolution which started in March of 2011.

He could have handled it differently, but he chose to terrorize his people, 100,000 people said, as we've all said. So, I agree with what Rich said earlier. I don't think there's a difference between us in the sense of do we care. Yes, I think we do. It's a question about how much and what our tolerance is for allowing the present situation to continue, and about whether we really have reacted to the different world in the Middle East today and elsewhere, where we can't find perfect situations and where we need to intervene in the best way we can. And we think there is a realistic prospect of getting to a position where the Syrians themselves can decide. And that's what we got to back. And that's our dog in the fight.

### Moderator
Claim: Thank you. Nigel Sheinwald. Our motion is: The U.S. Has No Dog in the Fight in Syria. And here to speak in support of the motion who says the U.S. does not have a dog in this fight Graham Allison. He is director of Harvard's Belfer Center for Science and International Affairs and former assistant secretary of defense.

### Conspiracy Advocate (CA)
Claim: Thank you. My old professor, Henry Kissinger, has a cushion in his home office that says, “Try to be the person your dog thinks you are.” Okay? So, if you find your dog in the fight, you're obliged to do everything you physically can-- including risks to your own life and limb-- to rescue your dog. Okay? I had that experience only once. I almost killed a German Shepherd that had its jaws around the throat of our little Corgi, Annie. And I hope I never have such an experience again. So, that's to have a dog in the fight. As you think about your vote tonight, I would say, ask three questions-- I would urge you to consider three questions.

First, we are just exiting two wars in which we entered without understanding the realities of the country to which we sent Americans to fight-- So, who imagines that we understand what's happening in Syria better than we did in Iraq and Afghanistan?

Second question-- this has come up in the debates that we had the Aspen Strategy Group this week. There're almost parallel realities. On the one hand, foreign policy experts look abroad and say, “Here dragons: this is a problem, this is a danger. We need to mount an effort.” But there's another reality, which is where is this country today? Look at Washington-- not just broke, but broken. Stalemated. Unable to even have a budget. And maybe on a drift to a closedown of the government. Is this a government that's ready to engage in yet another military operation?

Finally, I would say-- it-- for those of you-- for those of you that have children or grandchildren, if you imagine that by voting that we have a dog in the fight, you were at risk of sending your daughter or son to Syria, how would you vote?

### Moderator
Claim: Graham Allison, thank you very much. Your time. And that concludes our closing statements. And now it is time to learn which side you feel has argued the best. We're going to ask you again to go to the keypads at your seat. Once again, it's the 1-2-3 vote. If you were persuaded by the side that is arguing that the U.S. has no dog in the fight in Syria, push number 1. It's this side. If you were persuaded by their opponents, who are arguing that yes, the U.S. does have a dog in the fight in Syria-- that is this side-- push number 2. And if you are undecided, became undecided, or remain undecided, push number 3. And we'll have the results and the announcement of the winner-- according to our rules-- in just about two minutes.

And once again, we determine victory by the number of percentage points that has moved from one side to the other.

All right. Ladies and gentlemen, I just want to take care of a couple of pleasant pieces of business. And the main one is to say that the spirit and the honesty and the respect for one another that these debaters brought to the stage is what Intelligence Squared aims for. The level of argument was superb and I want to thank them for that. I also want to say that very often, the questions are a problematic area in these debates. They were superb tonight. Every single question was on point. Or if it wasn't, it was quickly refashioned. And it really moved this debate in a better direction. So, I want to thank everybody who had the nerve to get up and ask a question. I also want to thank, for being here with us, some guests that we're delighted to have. The former Secretary of State, Secretary Albright. Thank you very much for being here. Also, I think I saw Brent Scowcroft and-- yeah-- Ash Carter also and John Podesta is also here. And what I respect about this is that all of you-- sorry-- Joe Nye-- all right. We can go on and on. This is a very illustrious crowd.

What we appreciate about having you here-- why we appreciate having you here is that for all of you, none of this is just theoretical. You've all been in these situations and it wasn't the show on a stage. You actually had to make the decisions.

We respect and thank all of you for having done your best in making all those decisions all this time. And thank you for being here with us. So, we would love it-- those of you who tweet-- not sure this is a big tweeting crowd. But for those of you who tweet, our Twitter-- we would love it if you tweeted about this debate. Our handle is @IQ2US-- the hashtag is #Syria. And we also really want to thank the Aspen Strategy Group for bringing us here. It's been a terrific partnership and a very, very good relationship. And the fact that the leader of the Aspen Strategy Group was actually one of the contestants does not mean the fix was in. Anyway. For those of you who will be in New York this fall, please make sure to join us for a series of upcoming debates. The topics we are going to be debating are drones, breaking up the big banks, the global job market, the Second Amendment, and the case for going vegan. Which is one we could also come back here and do, I think. Tickets are on sale now. For more information and to join our mailing list, just visit our website. That is www.IQ2US.org.

And for those of you who cannot join our live audience and those of you who are now watching us on various live streams, we're on Fora.tv, we thank them for providing the video version of this tonight. We're also streaming on our own site, IQ2US.org. And you can listen to these debates on NPR stations across the country. This debate will be one of those. You can hear your own applause, laughter, and questions. Just check with your local listings for dates and times. And finally we would love it if you would stay in touch with us on Twitter and Facebook. And if you do that, you can let us know the topics that you're interested in seeing us debate. We take those seriously, and debates have come out of that source of information. So that's it. Was I handed a piece of paper with the results? Yes. All right. Remember, once again, it's the team who has changed your vote the most in terms of percentage points from before the debate to after the debate. Oh, I have a note that I needed to say also thank you and hello to Walter Isaacson. Hello, Walter Isaacson. We chatted beforehand. The motion is this: The U.S. Has No Dog in the Fight in Syria. Before the debate 40 percent of you agreed with the motion that he U.S. has no dog in the fight in Syria, 28 percent were against the motion, and 32 percent were undecided. So those are the opening results. Remember, I'm going to say this one last time, it's the team who has changed your minds the most in terms of percentage points will be declared our winner. So here's the second vote. On this motion: The U.S. Has No Dog in the Fight in Syria, the team arguing for the second motion moved to 61 percent, from 40 percent to 61 percent. They picked up 21 percentage points. That is the number to beat. Let's see. The team against the motion, the first vote was 28 percent. The second vote was 33 percent. They pulled up 6 percentage points. It's not enough. The debate goes to the other side. Our winner is the team arguing in favor of the motion that the U.S. does not have a dog in the fight."Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared. We'll see you next time.
