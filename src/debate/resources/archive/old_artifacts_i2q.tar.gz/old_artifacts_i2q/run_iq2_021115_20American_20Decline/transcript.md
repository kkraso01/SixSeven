# Debate Transcript

Topic: Declinists Be Damned: Bet on America
Motion: Declinists Be Damned: Bet on America

Debate ID: 021115%20American%20Decline


## Round 1

### Moderator
Claim: So, please let's welcome now to the stage the chairman of Intelligence Squared U.S., Mr. Bob Rosenkranz.

### Moderator
Claim: Hi, John.

### Moderator
Claim: So, Bob, this one, "Declinists Be Damned: Bet on America," what-- how did we get to this one?

### Moderator
Claim: Well for one thing it's a very special occasion because-- I don't know if you said this in your warm-up but this is our 100th debate.

### Moderator
Claim: That's amazing. Yeah.

I did not say that because I wanted you to get that line and that applause.

### Moderator
Claim: That is very kind.

### Moderator
Claim: That all worked out.

### Moderator
Claim: Good. So but why this topic, bet on America? Well, it seemed to us really appropriate for our 100th because so many of the debates that we've done over the past six years have been on topics that really are central to whether America is a power in decline or a power in the ascendancy. So, we've debated topics like higher education. We've debated topics like inner city schools and the role of teachers' unions. We've debated topics on the economy, on income inequality, for example, on foreign policy, on America's proper role in the world, whether it should be the world's policeman or whether it should clip its global wings, to pick the titles of two debates. We've talked about health care, which is certainly one of the largest public policy challenges that the country faces, income inequality, and so forth.

So, so many of the basic ingredients of whether America is coping well or poorly with the challenges of the 21st century are debates that we've held in the past that have been very exciting, that have engaged a very broad audience, and it seemed like for the 100th it might be really nice to have something that's so broad that it can encompass a lot of those themes and a lot of those ideas.

### Moderator
Claim: So, this is the meta debate in a sense.

### Moderator
Claim: In a sense it is, and we're really proud to be doing it.

### Moderator
Claim: And something that we have done intentionally in a debate about betting on America is we've made sure that at least half of our panel is not American.

### Moderator
Claim: Well, that's part of the view of-- bringing different points of view to the stage.

### Moderator
Claim: Well, let's welcome our debaters to the stage and thank Bob Rosenkranz.

### Moderator
Claim: Thank you, John.

### Moderator
Claim: So, as I said we are-- we are going to be broadcasting ultimately as-- we're livestreaming now but we will be broadcasting ultimately as a podcast and a radio show. And for that reason unless you're actually live tweeting, which we're delighted to have you do-- our hashtag will come up on the screen in just a second for tonight's debate as well as our handle, which is @iq2us-- we'd ask that you shut down your phones so that it's not your phone that an NPR listener hears ringing in Idaho several weeks from now.

And I just heard my own phone go off in my pocket, so that's what reminded me. So I appreciate that. And, again, just to launch the whole thing, I'd like to invite one more round of applause to Bob Rosenkranz, and we'll get started.

Hello, I'm John Donvan.

Welcome to Intelligence Squared U.S. "As a city upon a hill--" a scriptural metaphor that was beloved by both John F. Kennedy and Ronald Reagan to describe this project called, "America"-- but at various times, and this is one of them, we have heard it said that the city upon a hill is actually going downhill. And in a time when the middleclass is shrinking and when events overseas are not going according to American wishes and plans, the question comes up again, and that question is, has America peaked? Are we on the downhill path or is that all just a lot of Chicken Little stuff? Well, that sounds like the makings of a debate. So, let's have it, "Yes," or, "No," to this statement, "Declinists Be Damned: Bet on America," a debate from Intelligence Squared U.S. And this is our 100th debate.

We're at the Kaufman Music Center in New York City.

We have four superbly qualified debaters-- two of them are Americans, and two of them are our honored guests from other lands-- to argue for and against this motion, "Declinists Be Damned: Bet on America." As always, our debate goes in three rounds, and then our live audience here in New York votes to choose the winner, and only one side wins. Again, our motion is "Declinists Be Damned: Bet on America." Let's meet the team arguing for the motion, arguing to bet on America. Please, ladies and gentlemen, let's first welcome George Joffe.

Josef? Josef, I'm going to-- Josef, Josef, I gave you the wrong cue and I need you to sit down, because that's the wrong cue. Josef just got off – never again George, because his name is not George. His name is Josef and that's why for the radio broadcast, thanks to the magic of editing--

--which has saved my career on more than one occasion.

And it also means that all of you are sworn to secrecy when you leave tonight not to tell anyone what I just did. I'm going to once again say ladies and gentlemen, let's please welcome Josef Joffe.

Josef Joffe, you are the publisher and editor of the German weekly Die Zeit and you are a senior fellow at Stanford. You grew up in Cold War West Berlin, but in 1961 you ended up in Grand Rapids, Michigan, and you went to high school there. And I want to know, does that have something to do with your quite favorable view of the United States?

### Conspiracy Advocate (CA)
Claim: Absolutely. First of all, because it was a hot shower every day, which I wasn't used to in Berlin. Second, root beer floats.

Fifteen cent hamburgers and 28 flavors of Baskin Robbins.

### Moderator
Claim: What more could you want? Ladies and gentlemen, welcome the pro-America Josef Joffe.

And Josef, who is your debating partner tonight?

### Conspiracy Advocate (CA)
Claim: Well, don't you know his name?

### Moderator
Claim: I do. Obviously I'm having problems with that.

### Conspiracy Advocate (CA)
Claim: I don't know how to pronounce it. Peter, that's easy.

### Moderator
Claim: Peter Zeihan, ladies and gentlemen.

### Conspiracy Advocate (CA)
Claim: Ziehan or Zeihan?

### Moderator
Claim: Peter Zeihan, ladies and gentlemen. Welcome to our stage.

Peter, you're also arguing for the motion Declinists Be Damned: Bet on America. You're a geopolitical strategist. You helped launch the global intelligence company Stratfor and then you started your own firm. It's called-- actually I don’t have the name right here. What's the name of it?

### Conspiracy Advocate (CA)
Claim: Zeihan on Geopolitics.

### Moderator
Claim: Zeihan on Geopolitics. And you also wrote the book that I do have "The Accidental Super Power," that super power being this one, the United States. And in your introduction you clarify that this book is not about what should happen, but what will happen, and does that mean you're really saying that maybe the U.S. does not deserve the place at the top?

### Conspiracy Advocate (CA)
Claim: Better lucky than good.

### Moderator
Claim: Okay. That's the team arguing for the motion: Bet on America.

And the motion has opponents as well. Arguing not to Bet on America. Declinists Be Damned: Bet on America. They're taking the opposite position. Two debaters. First, let's please welcome Chrystia Freeland.

Chrystia, interesting career and recent career move. You're a journalist. You have worked as U.S. managing editor of "The Financial Times," managing editor-- director and editor of Consumer News at Reuters, but in 2013 you left journalism to become a member of Parliament in Canada. You are on the side against this motion: Bet on America. I thought Canadians were supposed to be our friends.

### Scientific Advocate (SA)
Claim: We are your friends. We love America.

And it's the job of the best friend to say, “You know what? You need to raise your game a little bit.”

### Moderator
Claim: Thank you, Chrystia Freeland.

And do you know your partner's name?

### Scientific Advocate (SA)
Claim: I do know my partner's name. I love my partner and his work and he is the brilliant Jim Rickards.

### Moderator
Claim: Ladies and gentlemen, Jim Rickards.

Jim, you're also arguing against the motion Declinists Be Damned: Bet on America. You're a portfolio manager. You're a lawyer. You're an economist. You've written some best sellers, including "The Death of Money." This is interesting. You have also advised the U.S. intelligence community and the Department of Defense on capital markets and strategy and defense of those. Are they as worried as you are about our financial future?

### Scientific Advocate (SA)
Claim: They are worried about it, but unfortunately they have very little to say about it. That's left to the Treasury and the Fed. So, the people who are most concerned are the least involved.

### Moderator
Claim: Oh, well, that doesn't work out very well.

But I guess we'll hear more about that as the debate continues. Ladies and gentlemen, these are our debaters.

Now this is a debate. One team will win and one team will lose, and that will be decided by you, our live audience in New York. By the time the debate has ended you will have been asked to vote twice, once before the debate and once again after the debate and the teams whose numbers have changed the most in percentage point terms between the two votes will be declared our winner. Our motion is Declinists Be Damned: Bet on America. Let's register your first vote on this. If you go to the keypads at your seat. You see a bunch of numbers. Only pay attention to one, two, and three. If you agree with this motion at this point, Bet on America, push Number 1. And if you disagree, push Number 2. And if you're undecided, push Number 3. You can ignore the other keys. They're not live. And you can correct an incorrect vote just by pushing the button and it'll lock in your last vote.

We'll lock out in just a minute-- less than a minute. Okay. That's locked out? Let's move on to Round 1. Round 1, opening statements by each debater in turn. They are uninterrupted. They will be seven minutes each. Our motion is Declinists Be Damned: Bet on America. And here to speak in support of this motion, Joe Joffe. He is publisher and editor of Die Zeit and author of "The Myth of America's Decline: Politics, Economics, and Half a Century of False Prophecies." Ladies and gentlemen, Josef Joffe.

### Conspiracy Advocate (CA)
Claim: America as a has-been is the oldest story in the book. Even right after the Revolution, the famous American-- French statesman Talleyrand dumped on the United States by saying it's a country with 30 religions and just one dish to eat.

Little did he know that a bit later, like today, that one dish would blanket the world with 35,000 McDonalds.

Decline is not a real serious diagnosis. It's repertoire theater. Today, we are in decline 5.0. We've had four before. And various candidates-- Russia, Europe, Japan-- were about to overtake the United States, leave the United States in the dust, and now it is the Soviet-- it is China. These prophecies did not pan out because they confused the headlines with the long-term trend. Exhibit A for every declinist is the economy, where others are always said to be growing faster. But here's the surprise.

For the last 50 years, the U.S. share of the global GDP has held steady, around 25, 26 percent. In the same period, the E.U. lost 11 points, Japan more than two. And Russia has cut its share in half. So, who's declining, if I may ask? Let's put it this way. If Rome, starting some 2000 years ago, had been declining at America's rate, we would be debating in Latin today.

Now, a certain measure of power is military spending. The U.S. is in a league of its own. It spends almost four times more than China, seven times more than Russia, 12 times more than Japan. It spends as much as the next nine countries together, five of whom, by the way, are allies. What does all this cash buy? The short answer is that the U.S. navy is as large as the next 12 navies together.

In its heyday, Britain only wanted to be twice as strong as the next one. So, only the United States can intervene anywhere in the world, nobody else can. Like those B-2 stealth bombers that took off in Missouri, dropped a load on Libya, and returned home in one trip. Now, that's a snapshot, our opponents will say-- will say. The others will inevitably overtake the United States, because they're growing-- they're rising. Do you mean Russia, with an economy that's one-tenth the size of America? Or China, which has a per capita one-eighth of America? China-- China, you will say, "Look, they came from nowhere. They're now number 2." But the days of China's spectacular growth are over. It's one half of what it once was. And this is no accident-- the Chinese growth model is like Japan's, and Taiwan's, and South Korea-- all of them have come down.

The-- and so, there is something inherently wrong with this model. We'll talk about it later. So, the-- the-- they would say, "But what about the Chinese labor force?" Well, the Chinese advantage is gone, too. Productivity has not kept up with the explosion of wages. In manufacturing, the wage gap with the U.S. has almost disappeared. And worse, this year, the Chinese labor supply will begin to shrink due to rapid aging. The U.S., on the other hand, will be the youngest nation in the industrialized world. Let's think about future. What drives growth in the future? Well, factor number one is higher education. Did you know that of the top 20 universities, 17 are American? The first Chinese university shows up in the 100 to 150 bracket. You look at-- you look at citations in scientific journals.

You look at patents. The gap between the U.S. and China is just as wide as the Pacific. So and but the greatest-- the greatest American advantage is the power of immigration. China and Russia, closed societies, don't even think about immigration. But here, as you know, from the very beginning the tide continues to flow in. Why do I harp on immigration? Because it keeps the country not only young but also from freezing up. Immigration breaks privilege and fuels competition. There's always another group that pushes in, works harder, and rises to the top. The newcomers keep bringing ambition and skill as they have done for the-- for 300 years. Try to become a Chinese. I want to become a Chinese. It's easy to become an American. Here, I'll tell you how to do it. I celebrate 4th of July and Thanksgiving. I joined the PTA and coach Little League.

I stopped smoking. I buy an SUV and shop till I drop.

The serious point is anybody can sign up to the American creed. And, "Where did you go to school?" beats, "Where do you come from?" any time. As a Chechnyan you'll never become a real Russian, but Sergey Brin could come here from Russia and start Google. Did you know that one half of Silicon Valley's engineers were born abroad? Two-fifths of all startups in the Valley built two years ago were founded by immigrants, Vladivostok or Kyoto or even Madrid. Immigration is the inexhaustible source of rejuvenation, bringing in the world's best and brightest. That's the moral of this tale. Let me ask-- end with a surprise confession. I actually like this American obsession with decline. It’s part of the country's religion of self-improvement--

--an offshoot of the prophetic tradition.

Isaiah: Beware of sloth, pride. Look at your own flaws, and keep on hustling. Declinism is the best antidote to decline. But declinism is repertoire theater, like a good scare, like another sequel to "Nightmare on Elm Street." Where are Soviet Russia, Europe, Japan today? Where is 15 percent growth of China? The truth is, only one nation can do an America, and that is America itself. And that's why I like this declinist agitation. It will make sure it won't happen. So, to repeat from-- I've been going downhill at the American rate, we would be debating in Latin today, like “Gratias which means, "Thank you, and see you in the next round."

### Moderator
Claim: Thank you. Thank you Joe Joffe.

And that's our motion, "Declinists be Damned: Bet on America."And here to argue against the motion, Chrystia Freeland. She is a member of the Canadian Parliament and author of the book, "Plutocrats: The Rise of the New Global Super-Rich and the Fall of Everyone Else." Ladies and gentlemen, Chrystia Freeland.

### Scientific Advocate (SA)
Claim: Thank you very much, John. It's great to be here tonight. As John said, I'm an MP. I debate in a Westminster-style parliament. So, I am used to all sorts of rhetorical dirty tricks from the honorable members, the opposite side of the aisle. And I wanted to start by warning you about what I thought were going to be the fiendish rhetorical moves tried out by the other guys. So, here are the three things I want you to beware of and not to be misled by. The first one is-- and it's the tough thing about debating our side of this question-- that in voting for our side, which is the correct one, you are going to be accused of being insufficiently patriotic.

And efforts are going to be made to impugn your love of the United States. Don't fall for that one. The highest form of patriotism is to see clearly what's happening in your country. The second one, which I'm sad to say we've already heard a lot from in Joe's beautiful, eloquent presentation, is what I call the cleanest dirty shirt argument. And this is the defense of the United States which basically says, "Okay, we may have our problems, but everybody else is worse. Look at those Europeans. Look at those Japanese. Look at those Russians. Look at those Chinese." We're not debating here, "Is the U.S. in less trouble than the world's other countries?" We're debating, "Is the U.S. in decline, relative to where it has been?"And you know what? You guys have a responsibility to be super good. You are the last remaining superpower. We need you to be morally, intellectually, and, in terms of world authority, better than everybody else. So, just to be a little bit less bad, that's not good enough. So, why do we believe-- and we say this with real sadness-- why do we fear that America is in decline? The first evidence is what's happening internationally. In the Cold War era and then following the collapse of the Soviet Union, we lived in a time of what you might call the Pax Americana. And as a Canadian it was a great time. It wasn't just a great time for America. It was a great time for the world. Unfortunately, we're seeing America pulling back. We're seeing that on big issues like climate change, a huge-- there's lots of kids here.

We need to be fixing this for you guys. Where's American global leadership on this issue? We're seeing in a place like Syria, there was a red line, the red line was crossed, what happened? And we're seeing it most acutely-- and this is something I'm just so terrified about-- in Russia and Ukraine. Joe pointed out, and he is quite right, the Russian economy is one-tenth the size of the U.S. economy. So, how come Putin is getting away with redrawing the borders of Europe and no one, least of all the United States-- the U.S. isn't even at the Minsk peace talks right now. Is that not a superpower in decline? And this is bad news for the whole world because superpowers, as Bob Kagan wrote very brilliantly, are not allowed to retire. Second argument is your political gridlock.

And here I think we would all agree that the genius of America is the ingenuity of the American people. It's what each individual person does, and that is fantastic. But I think we would all also agree there's a role from time to time for government to do a few things. Joe talked movingly, and I totally agree with him, about immigration being such a strength in America. You guys have a few problems to sort out with that, and you're going to need government to act, and I don't see government acting. Now, you may say, "It was ever thus. Washington has always been a mess." I'm a politician. I know what people say about politicians. But Sarah Binder of Brookings did a study last year, and she found that the likelihood of Congressional gridlock on a given issue has doubled over the past 65 years. Your government is ineffective at a time when you need effective government for yourselves and for the world.

Finally, and this to me is the biggest problem, this is the thing that really keeps me up at night, democratic capitalism, that great U.S. model, isn't working the way it used to and the way it is supposed to. For the past 30 years, the U.S. middle class has been hammered. Wages have stagnated, and wealth has stagnated or declined, while the people at the very top have seen their incomes and wealth skyrocket. That is a huge problem for the United States because the U.S. promise, as Joe so eloquently said, is "If you work hard and play by the rules, you can succeed." But that is not what the U.S. economy today is delivering, and that's why gridlock is such a problem because it is going to take a massive, united social effort and really inspired, brilliant leadership to resolve this economic conundrum, which I believe is a challenge comparable to the challenge presented by the industrial revolution.

Now, you may say to me, "Well, but isn't this a problem that all the Western industrialized economies face to some degree or another?" And I would agree with you. It's a thing we're worried about in Canada, too. But this income inequality is worse in the U.S. than in any other Western industrialized country. Your elites are doing better, and your middle class is more hammered. Did you know that working men, so men between 20 and 50, the employment rate of men in that group in the U.S. is lower than in France? That's a problem. I want to conclude with a quote. This is from Thomas Jefferson. He wrote, "We have no paupers. The great mass of our population is of laborers.

Our rich, who can live without labor, either manual or professional, being few and of moderate wealth. Most of the laboring classes possess property, cultivate their own lands, have families, and from the demand for their labor are entitled to exact from the rich and the competent such prices as enable them to be fed abundantly, clothed, and to raise their families."

I'll finish it next time.

### Moderator
Claim: Chrystia Freeland. I'm sorry. Your time is up, but thank you very much.

### Scientific Advocate (SA)
Claim: I'll finish it next time.

### Moderator
Claim: And the reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two arguing it out over this motion: Declinists Be Damned: Bet on America. You have heard from the first two debaters and now onto the third. Here to argue in support of the motion Declinists Be Damned: Bet on America, Peter Zeihan. He's a geopolitical strategist and he is author of the book "The Accidental Superpower: The Next Generation of American Preeminence and the Coming Global Disorder."Ladies and gentlemen, Peter Zeihan.

### Conspiracy Advocate (CA)
Claim: I considered declining this invitation when it was made. NPR intellectual is not really my crowd. I live in Texas. But then I realized that the word “damn” was in the proposition so I'd be allowed to swear. On NPR. A lot.

### Moderator
Claim: So, here I am. But enough about my hopes and dreams. Let's talk about you. Where are my boomers? People born 1946 to 1964. Come on. Hands up, yeah, yeah, yeah. You guys are a freakin' army. You're the largest generation we've ever had.

You need to tell the radio audience how many people put hands up.

### Conspiracy Advocate (CA)
Claim: Oh, it's like a third of the total, but we've got a lot of youngsters up top. So, you know, it's a swarm. Most of your consumption, however, is behind you. Your kids have left home. The house is paid for. You're at the height of your tax-paying experience, which means that the government's like, “I'll take some of that, and then I'll take some more.”Today's budget battles, that's the start of our debate about figuring out not how to pay things with your money, but about how to pay your retirement without your money. Something to look forward to. Which sucks for this next group. Where are my Gen-Y? Or excuse me, Gen-X. Gen-X. Oh, we're all here. Yeah, we're the smallest generation as a percentage of the population. So very soon it will be up to us, all 11 of us,--

--to pay for 75 million retiring boomers. Taxes are going to be awful, but it's not quite as bad as it seems. Because while the boomers are so convinced that they're so special, there's actually a boomer class globally that relative to the population is about 20 percent larger than it is here. So, yes we do have a boomer donculous tax bill just around the corner, but it's actually considerably less than what everyone else is going to have to pay.

So, you know, not exactly hope, but you know, schadenfreude. And then there's Gen-Y. Gen-Y folks, you know, the millennials. Oh, a few of you showed up tonight. That's great. Your age group does the consuming. Kids, houses, cars, pot. It's--

--spend, spend, spend. Your purchases, especially the pot, by the way, are why the economy is doing so well right now. Because of you, because of your bulk, the United States is going to be the youngest developing-- excuse me, developed country in the world in just four years, younger than China. And in 15 years when you have matured, and I use that term in the loosest possible way--

--you will swarm into the taxpaying class with a fervor that Gen X just could've never matched. And Gen X will be settling into the tardis-like space that the boomers will be vacating and America's 20-year effort to digest the boomer demography will finally be over. Now, as an X-er it really pains me to say this, but you Gen-Y-ers are special.

Because there are no German Y's or Japanese Y's or Italian or Canadian Y's. It's as if the entire developed world forgot how to have kids around 1975 and I think we've all traveled enough to know they got the basics down.

This combination of bigger global Boomer cadre, but no global Y cadre spells disaster. Consumer activity and tax income will shrink every single year. Retiree costs will increase every single year. It's a deflationary spiral with no escape and it will happen everywhere but the United States. And that's the good news. Let's talk about the bad news. Let's talk about trade. The idea that you can trade with a country a quarter, a third, halfway around the world, that's a very strange idea.

Until recently, major countries used their navies to protect trade between their colonies and their mainland. You didn't trade with your neighbor if you could avoid it, because you never knew when someone might throw a war, and you lose access to everything. These separate imperial systems clashed, and those clashes culminated in World War II. Now, at the end of that war, the United States forced all of its allies to sit down, and we imposed a new economic system upon the world. We called it free trade. We told them they didn't need navies. We would patrol the global oceans and allow them to send whatever they wanted anywhere to anyone at anytime. In addition, we would open our market-- the only consumer market survived the war-- so, they could export their ways back to affluence. In exchange, there was one demand. This alliance would fight the Cold War our way. You heard that right. We bribed up an alliance to take on the Soviets. And it worked. Free trade created the free world. Europe united. Japan rebuilt. China modernized.

The global population tripled. Global GDP increased by a factor of 10. One-third of the Chinese and Italian GDP-- export-driven. The EU? The Chinese Communist Party? All of that would have been impossible without the safe and reliable access to the global oceans and the U.S. market. Which leads us to the world's most inconvenient truth-- the United States didn't create free trade as an economic plan, but as a strategic gambit. We don't use free trade's economic features. Our exports-- 9 percent of GDP, the lowest in the world by a significant margin. We are the least integrated country out there. America's economy, and future, are not dependent upon the global system. It's the global system that is predicated upon America's willingness to sublimate its market and its military in order to fight a war that ended a generation ago. That is not a safe bet. I mean, really, have you met Americans? We kind of shoot from the hip.

The world is now dependent upon our mood. And even should we stick to our Prozac regimen, the majority of the world's Boomers will still retire around 2020, which just as surely will trigger a Great Depression, if we're lucky. There are many other reasons, similarly inevitable, why the U.S. will remain the global superpower well beyond our lifetimes. The shale revolution has pushed North America within 2 million barrels per day of outright oil independence. And we now have the lowest electricity prices, non- subsidized-- in the world. The U.S. is home to nearly half of global consumer spending, double that of the combined BRICs. The Navy has a 10:1 ratio, conservatively, in terms of global firepower. And the commitment of that imbalance to the global commons is why trade works. And the dollar is the sole denomination for every commodity in every country, especially for those export-driven rivals who are utterly dependent upon free seas and open markets.

So, when you think of the U.S., it doesn't matter if you feel a swelling pride, a loathing, or a resigned sigh. Your conclusion is as singular as it is clear. Bet on America. Declinists be damned.

### Moderator
Claim: Thank you, Peter Zeihan. And that is our motion, Declinists Be Damned: Bet on America. And here to argue against that motion, Jim Rickards. He is Chief Global Strategist at the West Shore Funds and author of "The Death of Money: The Coming Collapse of the International Monetary System." Ladies and gentlemen, Jim Rickards.

### Scientific Advocate (SA)
Claim: Thank you, John. I want to begin with a simple declarative statement, which is, I love America. I pray for her. And I wish her well. And it's precisely for that reason that I'm here arguing this side, because when you love your country and you see it in decline, when you see a disaster coming, as you do, you really just stand up and say that.

And I appreciate the opportunity to talk about that tonight. The second thing I want to say is that almost everything-- practically everything our opponents said is correct, but I would suggest irrelevant. Joe was exactly right. No one knows more about the diplomatic history of the last 50 years. But if you had been an observer at the Battle of Hastings in the morning, you would have said the English had the advantage. They had more troops and higher ground. If you had looked at the battlefield at noon, the English were still winning because they withstood a barrage of arrows from William the Conqueror. If you looked at the battlefield about 3:00, the English were still winning because their lines had held. They only had to wait until sundown. It wasn't until shortly before sundown, at the end of the day, in a desperate move, that William the Conqueror pulled out some new tactics. The English lines broke, and the course of history was changed forever. My point is, take no comfort from the fact that prior prognostications have not played out, because I think-- I'll explain in a minute why we're in a much more dangerous zone. Joe talked about-- described a declinist view involving rhetoric, agitation, and religion. What I'd like to do is-- there's nothing – I have no problem with rhetoric and religion, but let's talk about science for a minute.

The most important question in economics and geopolitics today is "Are capital markets and is our society a complex system?" If it's not, then maybe our opponents win. But if it is, we have serious problems ahead of us. What do I mean by a "complex system"? A lot of people think, you know, your watch might be complex. It's-- the technical name, "It's complicated, it's not complex." The complex system has the following characteristics. It has diversity, lots of points of view. It has interconnectedness so that those different points of view are in touch with each other. It has communication, so you're communicating, you're transacting, you're interacting with each other. And finally it has adaptability, which is other people's behavior affects your behavior. So, those are the four defining characteristics of a complex system. There is no question, capital markets, finance is not only a complex system, it is the complex system, nonpareil. And this-- again, this is physics, but it applies very carefully, very closely to these economic systems.

So, let's just take-- let's just do a thought experiment. We'll use the-- use the audience. We'll use all of you. There are about 500 people in the room. Let's say that right now a third of you got up, screamed, and ran out the door as fast as you could. What would the rest of you do? I daresay you'd be right behind them. You wouldn't know what was up. You would say, "Well, they know something I don't. The place is on fire. There's a bomb scare. I'm not going to stay around to find out. I'm right behind them." Let's say a third of you were particularly nervous. You're more nervous than the rest. For you, it would only take 20 people jumping up, screaming, running out the door, and you would be right behind them. Now, let's say there are 20 of us who are the most nervous of all, very, very-- very, very much on edge, and for you it would only take five people standing up, screaming, and running out the door, and you would right-- you would be right behind them. How many people do I have to persuade to empty the whole place, to cause a panic, to cause this whole place to run out the door? The answer is five people, because if five people run, 20 more will run.

If 20 run, a third run, and if a third run, the whole audience runs. I like to say when it comes to the collapse of the dollar, Paul Krugman will be the last guy to leave the room, but that's his problem. But the point is, what I just described, there's a technical name for it, hypersynchronous ising model, but the point is that's a cascade. That's how complex systems operate. It takes very small changes in initial conditions to completely, catastrophically change the outcome. What kind of complex system do we have right now? We have got more debt than we had in 2008. You all remember 2008, too big to fail? Well, the biggest banks in 2008 are bigger today. They have a larger concentration of their total financial assets. Derivatives books are bigger. In a complex system, when you increase the scale, and that's what I'm talking about, the risk goes up exponentially. So, let's say I increase the derivatives books-- I triple the derivatives books at the major banks, how much did the risk go up? Well, if you ask Jamie Dimon, he would say, “You know, very little because, you know, it's long, short, long, short. It all pairs off. You net it down, it’s a tiny little amount." If you ask my 84-year old mom, she might use intuition and say, "Well, if you triple the system, maybe you triple the risk."The correct answer in a complex system, it's exponential function. If you triple the scale of the system, you've increased the risk by a factor of 100 or 1,000. You've made it much more dangerous, and I just showed you how it takes a very small change in the initial conditions to cause the entire thing to collapse. So, that's the system we're living in now. We're right on the knife-edge. Very small preservations, very small changes could cause a catastrophic financial collapse. And I'm not talking about the kind of long, slow, gradual decline that Joe is expert on. And, you know, Peter, no one knows more about this sort of geography of geopolitics than Peter. But what are we talking about in the world today? We're not talking about an amphibious invasion on the beaches of New Jersey or Long Island. Peter's analysis might have been certainly pertinent in 1860, probably as late as 1960. Admiral Rogers, who's the head of the United States cyber command, said the next war will be in cyberspace. And my only quibble with Admiral Rogers is that, that war has already begun.

We're in a-- we're in a cyber war with Russia right now. In 2010, it was disclosed that Russian intelligence had penetrated the NASDAQ market operating system with an attack virus. These are not hackers trying to get your credit card numbers. This is-- this is the military intelligence unit getting in the operating system of our second largest stock market. In August 2013 NASDAQ was closed for half a day. We've never been offered a explanation as to what happened there. I want to suggest if the explanation was an attack, there would be good reason not to tell us because it would panic investors, start those people running out of the theater exactly as I described. So, this is the situation we're living in today. One last point, what's the R&D budget for fire? How much did it cost to invent fire? The answer is, "Zero." The R&D budget was-- somebody had a bright idea someday, maybe they saw some lightning, who knows what, but they invent a fire. What's the payoff to humanity from the invention of fire? Incalculable. What was the R&D budget for the Boeing 787, the Dreamliner? It's $32 billion.

What was the improvement? Well, I've flown on a 787. I can't tell the difference. It looks like a 767 or a 777. The point is this is characteristics of complex systems. You get to a point where you have larger and larger inputs for no pay off. Fire was free, huge benefit. Boeing spent $32 billion on a new airline, very hard to see if there's any benefit at all. How are we paying for this? We're printing the money. We're using derivatives. We're creating a dynamically unstable system. It would take very little to cause it to collapse almost overnight. Thank you.

## Round 2

### Moderator
Claim: Thank you, Jim Rickards. And that concludes round one of this Intelligence Squared U.S. Debate where our motion is, "Declinists be damned, bet on America." And remember how you voted before the debate-- before the arguments began. We're going to have you vote again after closing statements. And once again, the team whose numbers have changed the most from the first to the second vote will be declared our winner. Now onto round two.

Round two is where the debaters address one another directly and also take questions from me and you and the audience. Our motion is this, "Declinists Be Damned: Bet on America." And remember how you voted before the debate, before the arguments began, we're going to have you vote again after closing statements. And, once again, the team whose numbers have changed the most from the first to the second vote will be declared our winner. Now on to round two. Round two is where the debaters address one another directly and also take questions from me and you in the audience. Our motion is this, "Declinists Be Damned: Bet on America." Do you want to get a glass of water or--

### Moderator
Claim: I got one.

### Moderator
Claim: --yeah, okay. I'm just going to say that again because there would be this lady coughing in the background in the-- remember that thing about editing? We have a-- I just was told by that mysterious voice in my ear that we can get you a cough drop.

### Moderator
Claim: Great.

### Moderator
Claim: Yeah? Let's bring up the cough drop. We're going to watch a cough drop brought up on the stage.

Let's see how this plays out. Here you go.

### Moderator
Claim: I'm just so worked up about American decline.

### Moderator
Claim: Yeah.

### Moderator
Claim: It's a physical thing for me.

### Moderator
Claim: I'll let you get that started or-- you're good? You're good? Okay. So I'll go ahead and do this one more time.

This is nothing compared to some of the stuff that I've had happen to me up here, so--

### Moderator
Claim: This is great radio, huh?

### Moderator
Claim: --yeah, yeah. Round two is where the debaters address one another in turn and take questions from me and you and the live audience.

Our motion is this, "Declinists Be Damned: Bet on America." We have two teams arguing for and against, the team arguing for, Joe Joffe, and Peter Zeihan-- I've said we've heard this whole declinist thing before. It always turns out to be exaggerated, that, in fact, the long term trends are very much in America's favor, strong GDP, its military is supreme without any near rival, other countries that might be rivals just don't have the advantages that the U.S.-- which include access to new talent through immigration, the fact of our education standards, our demographics, which mean that our population will soon be younger than almost any population in the rest of the developed world, we're on our way to energy independence, the dollar is supreme, that things just couldn't really be better, a very optimistic scenario. The team arguing against the motion, Chrystia Freeland and Jim Rickards, much more pessimistic while saying that they argue that with sadness, but that to point out the flaws in the system are-- is, in itself, an act of patriotism.

But they say that the system is very fragile, that we're at a state where government is essentially ineffective at a time when capitalism is not working the way it's supposed to be and the middleclass is losing out with no way to get out of the rut that it's in, that the immigration argument is a good one but that we haven't sorted out how we're going to do it, and that economically that conditions are in place for a dangerous and quick and overnight collapse, given the level of debt, which is greater and in more mysterious places than ever before, not to mention that we are very vulnerable in issues of cyber attack. It sounds to me that there are areas in which the two of you agree on some of the basics, for example, the relative strengths and weaknesses internationally between the United States and some of its rivals. But where you appear to disagree I would say is on this notion of whether the team arguing-- the team arguing against the motion, arguing not to bet on America, is really portraying a situation in which there's a rot at the core of things.

That there's this fragility that over time is going to undermine much of the American dream. And I want to take that side-- or that argument to the side arguing for the motion to get specific. Peter Zeihan, your opponent, Chrystia Freeland, argued that the American middleclass is really just in a corner that it can't get out of, both because of the way things are running economically and because of political gridlock, that-- and that-- that they're-- that in itself is the reason that you-- that they can argue right now not to bet on America because of the critical role that the American middleclass has played in building America. What's your response to that?

### Conspiracy Advocate (CA)
Claim: Well, actually, the data doesn't support that. But it's my debate partner that is in command of the data on that topic, so I think I'll punt that one to the right, here.

### Moderator
Claim: Okay, Joe Joffe, do you want to take that?

### Conspiracy Advocate (CA)
Claim: Well, we heard this number about the-- declining middle class for a long time.

I don't think it has anything to do with the issue whether the country itself is declining, but let's go with the issue of equality. The way to measure inequality is not by anecdote, but by something called the Gini coefficient, which measures inequality around the world. And lo and behold, you'll be surprised. Once you take into account taxes and transfers, the United States has a Gini coefficient of 0.37. Total inequality will be one. Zero will be no inequality. The great state of Canada has a genie coefficient of 0.34. The great state of Germany, the model of the wealthiest state, 0.35. Italy almost 0.4. So, if you want to talk inequality, talk the right numbers.

Do not talk anecdotes and repeat what you read every other day in "The New York Times."

### Moderator
Claim: Chrystia.

### Scientific Advocate (SA)
Claim: The Gini coefficient point. Joe said that that was after you take into account taxes and transfers. That's a little like saying it's a nice day except for the three feet of snow. The problem is if you include taxes and transfers this is moving very strongly in the direction of a government run society. So yes, with taxes and transfers. Without them, without them our Gini coefficient is worse than Mexico and when I grew up Mexico was a classic oligarchical society. But not taking into account taxes and transfers, we're actually worse than Mexico. That's something--

### Conspiracy Advocate (CA)
Claim: You can’t argue both sides. Either you talk inequality or If inequality comes down by government action, isn't that what the welfare state is all about?

### Scientific Advocate (SA)
Claim: No. Let me--

### Moderator
Claim: Chrystia Freeland.

### Scientific Advocate (SA)
Claim: So, it is a truth universally acknowledged, including I am sure by you, Joe.

That what we have seen over the past 30 years is an increase in inequality in the United States, an increase, a huge increase in the share of income taken by the top 1 percent and 0.1 percent and a stagnation of incomes and wealth of people in the middle. Now, I warned you guys he would use the cleanest dirty shirt argument and say well yeah, but it's bad all over. In this case America isn't the cleanest dirty shirt on the stagnate middle class. It is a problem for everybody. I completely agree with that, but it is--

### Scientific Advocate (SA)
Claim: Hang on. Hang on, Joe. Hang on, Joe. It is a particular problem for the United States for two reasons. The first is we collectively-- I mean, I'm very passionate about this because figuring out how to make the technology revolution 21st Century economy work for the middle class, I think, is the biggest challenge of our generation. And for the western world to figure it out, we're going to need a strong American lead and we're going to need America to accept that this is a problem.

### Moderator
Claim: Oh, let's let Joe Joffe respond.

### Conspiracy Advocate (CA)
Claim: Let me respond?

### Moderator
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: I think that the issue of equality is an interesting moral issue, but it has nothing to do with what we're debating about today. We are talking about whether the United States is declining or not relative to other nations. We are not talking about where the United States was 50 or 100 years ago. It was a hell of a lot more unequal in those days. We are talking about by the measures that we normally use to measure power, economy, military, education, research and development spending, scientific achievements. Those are the measures as opposed to anecdotes that measure up or down.

### Moderator
Claim: Well, I think the language of the motion does not say relative to other nations. You can make the argument that the motion includes relative to other nations and that's fair and they can convince the audience that it means something else. It's up to you to be persuasive on that.

### Scientific Advocate (SA)
Claim: No one in the British Empire, the Roman Empire, the French Empire, would say we're going to have a good deal for everybody.

What they said is there's rich and poor, elites and everybody else. That was the deal. So yes, we have these other things going for us, but fairness, income distribution, that is the heart of the American dream. When you take that away there's nothing left of America. We are different.

### Moderator
Claim: Peter Zeihan.

### Conspiracy Advocate (CA)
Claim: I’ll go now. Yeah. I'm sorry, but how much better than the top slot in absolute relative term do you have to be to win this debate?

The Euro is dissolving as a global currency. Three trillion dollars has flooded the United States in the last five years. Skilled migration is at all time highs. By every measure that matters the United States has not fallen behind. It's pulling ahead. And that assumes that we keep maintaining a trade system that hasn't benefited us for 30 years. God forbid we have a bad hair day.

### Scientific Advocate (SA)
Claim: I'll tell you where America is number one.

### Moderator
Claim: Jim Rickards.

### Scientific Advocate (SA)
Claim: We're number one in terms of incarceration. The percentage of people behind bars in the United States has doubled.

And this is just developed countries. We're not talking about Angola here. Just the OECD members, the developed countries. America is Number 1. Number 2 are our friends, Chile, who have less than half that rate. Turkey is Number 10. Remember that midnight express? They only have one quarter of incarceration rates. So, that's-- we are number one incarceration, which is a major dysfunction of society.

### Conspiracy Advocate (CA)
Claim: Turkey has more--

### Moderator
Claim: Joe Joffe.

### Conspiracy Advocate (CA)
Claim: --journalists in jail than any other country in the world that I know of. Let me just say something about decline. I think decline is a relative issue. It's not an absolute issue. I am taller or fatter, or thinner than you are. Just to say that I'm taller, or fatter, or thinner is not a very interesting issue unless I compare myself to others.

### Moderator
Claim: Well, let's take a moment-- let's take a moment for Chrystia Freeland to respond to that. Is it a relative issue? You said in your opening statement you're comparing it to what we used to be at some point in time.

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: But why is their measurement not valid, relative to other nations?

### Scientific Advocate (SA)
Claim: A couple of reasons. First of all, I think America rightly measures itself not against Turkey.

Is America supposed to be proud it imprisons fewer journalists than Turkey?

### Conspiracy Advocate (CA)
Claim: We have none in prison.

### Scientific Advocate (SA)
Claim: I said-- no. No. Hey, Joe, I didn't interrupt you. so, that's really not good enough. America really is the city on the hill, and America needs to measure itself against itself. I'm arguing decline on two main points. One, America is failing Americans. And this is not about some, you know, namby-pamby NPR-ish, you know, ethical, moral point.

This is about saying the middle class is falling behind. And you talked, Peter-- movingly, about generation Y. If we talk to the Generation Y, people here-- there are no good jobs for Generation Y. Generation Y is being Uber-ized and task rabbit-ized.

### Moderator
Claim: Let's let Peter--

### Scientific Advocate (SA)
Claim: And that is a problem.

### Moderator
Claim: Let's let Peter Zeihan respond-- but before you--

### Scientific Advocate (SA)
Claim: And Generation Y knows it.

### Moderator
Claim: Before you do that, Peter, I just want to point that in celebration of our 100th anniversary, NPR has some executives in the audience joining us tonight.

I mean, they're thinking things over. Peter Zeihan.

### Conspiracy Advocate (CA)
Claim: Let's talk about America's past. You want to make this relative to the United States's past rather than the rest of the world, that's fine. Andrew Jackson's wife was accused in a live debate of being a prostitute while she was first lady. Gridlock is normal. John Adams was accused of being a hermaphrodite with any of the positive characteristics-- whatever the hell that means.

Gen Y doesn't have opportunities? Let's take it from the economic side. Look back to the 1800s. We had an empty continent that anyone for the price of a KIA car could load up the family, head west, take land that we stole from the natives, and be exporting grain for hard currency to war-torn Europe within six months.

That will never happen again. Because there's not another continent.

### Moderator
Claim: James Rickards. Jim Rickards, please.

### Scientific Advocate (SA)
Claim: I'm glad Peter brought up Andrew Jackson. He's one of my favorite presidents for two reasons. Number one, he abolished the central bank of the United States. We went for about 80 years with no central bank, thanks to Andrew Jackson. But the other thing he did-- he paid off the national debt. I don't mean he ran a budget surplus. I mean, there was no national debt. Zero. At the end of the Jackson administration. Today our debt is over 100 percent of GDP. Now, the last time it was that high-- and this is sort of Joe's point-- you know, it was the end of World War II. And Paul Krugman says, "Hey, we had a 100 before. No big deal. We got out of it." Yeah, but we won World War II. We had 60 percent of global GDP. Today we're declining on a relative basis. We have debt. We didn't get anything for the money. The Fed printed the money-- actually the amount of money the Fed has printed is roughly equal to the amount of additional debt in the last five years. They have monetized the debt. There is no way out.

The-- when this collapses, they'll be-- they won't be--

### Moderator
Claim: Okay. Let me--

### Scientific Advocate (SA)
Claim: --able to do it again.

### Moderator
Claim: Let me take it back to Joe Joffe.

### Moderator
Claim: Joe Joffe, there's sort of a ticking time bomb scenario on the economy?

### Conspiracy Advocate (CA)
Claim: relative decline.

And relative decline, by the way-- let me tell you-- of course the United States had 50 percent of GDP and 45. The rest of the world was destroyed. The point is, its share has held steady for the last 50 years. But let me get away from this. Let me talk about gridlock, about the inability, you know, the inability to govern. Do you know what gridlock looked like in the days of Jefferson, when they used to shoot each other?

Okay. That was just a debating point. Let me say something about how, in spite of this so-called gridlock and ungovernability, how this country got out of the great recession? It flooded the country with liquidity.

It went into heavy deficit and it recapitalized the banks, this gridlocked country, that totally polarized country, as a result of which this country is now growing at 3 to 4 percent. What about the Europeans? I'm sorry to compare the United States to other countries, but where are they in terms of growth now? They've tried something. It doesn't work. Do you know with the banking system in China, you just hold a little match to it and it will explode like a nuclear weapon.

### Moderator
Claim: So--

### Scientific Advocate (SA)
Claim: Can I--

### Moderator
Claim: --Chrystia, your argument could be, "The United States is in decline along with everybody else," is what it sounds like?

### Moderator
Claim: No, no.

### Scientific Advocate (SA)
Claim: --well, I think-- I think that there is a big problem in how the Western industrialized economies are operating, and I think it's partly to do with rent seeking and, you know, the inside dealing and changing the rules of the game to suit elites. I think it's mostly to do with the technology revolution and globalization.

And the economy today is not delivering the kind of good middle class jobs which were behind the rise, certainly of America, but also of Western Europe and Canada, in the postwar years. That's gone. We're living through a second industrial revolution, comparable in its scope to the industrial revolution. And you might say to me, "Oh, okay, well, that's fine because the industrial revolution, it sort of worked out. And it did, but it took two world wars, a great depression, the long depression in the 19th century, oh, and also a communist revolution in Russia and China before we--

### Conspiracy Advocate (CA)
Claim: 50 percent unemployment in southern Europe.

### Scientific Advocate (SA)
Claim: --hang on, hang on, hang on, hang on, hang on, hang on, hang on. I didn't interrupt you guys. Don't be sexist and speak over women's voices.

It happens. I'm sorry. It does happen, okay? So, it-- so communists-- we were on communist revolution--

### Moderator
Claim: Just really, you know, I can't help you out on that one.

### Scientific Advocate (SA)
Claim: Yes.

Studies show it. Read Sheryl Sandburg.

Anyway, so communist revolutions in Russia and China, and then the Western world figured out this was a crisis. Industrial revolution was great, but you needed a new social and political accommodation so that it worked for the mass of society.

### Moderator
Claim: Okay, no--

### Scientific Advocate (SA)
Claim: And it was-- hang on, hang on--

### Moderator
Claim: --no, no, now as moderator--

### Moderator
Claim: --and as a sexist, I'm going to--

### Scientific Advocate (SA)
Claim: We need to do the same thing now. That's why gridlock

### Moderator
Claim: Peter, you're on. Peter, you're on.

### Moderator
Claim: She was being sexist.

### Conspiracy Advocate (CA)
Claim: No, I mean, actually in terms of the--

--industrial revolutions, I am in complete agreement. But, wow, if it's going to hurt here, it's going to wreck everybody else. I want to bring up-- go back to a point that--

### Moderator
Claim: No, no, no, I actually want you to respond to her point.

### Conspiracy Advocate (CA)
Claim: --I did,

### Moderator
Claim: About how bad-- well, not very eloquently. I mean, she--

--she laid out a pretty dire picture of things, and I think we'd like to know where that stands.

### Conspiracy Advocate (CA)
Claim: Social development, social revolutions as part of technological change are as old as technology.

### Moderator
Claim: So you're just saying that we'll get over it, we'll get through this difficult time?

### Conspiracy Advocate (CA)
Claim: No, it's going to hurt. Gen Y in particular has to find a new way of doing things because, let's be honest here, government is not going to lead the way in a private enterprise- driven system to whatever comes next.

We didn't do it the last time around. We didn't do it the time before that. We're not going to do it this time around.

And from my point of view, that's neither good nor bad. It just is. But Jim brought up a comment that I really want to get back to on the dissolving of the U.S. dollar. Into what? Ever since the euro zone decided to confiscate insured bank deposits to bail out Cyprus everyone moved out. What's left then? The yen, the yuan, less than 2 percent that's actually traded?

### Moderator
Claim: That's right.

### Conspiracy Advocate (CA)
Claim: You got the Swiss Franc and the Canadian dollar are the next two. Those cannot be a global currency. So the United States--

--not suggesting for a heartbeat that I think printing currency is a good idea, but we are the only country in the world that can actually do it because, you know why? Three quarters of it isn't even held here because it's a trade system.

### Moderator
Claim: All right, let me give it to Jim Rickards.

### Scientific Advocate (SA)
Claim: Yeah, I'll respond to two points. There's an old saying, "You're entitled to your opinion. You're not entitled to your own facts." Joe, I wish--

### Moderator
Claim: That comes up so often at our debates, actually.

### Scientific Advocate (SA)
Claim: --you know, Joe, I really wish we were growing at 3 to 4 percent, as you said.

The fact is in 2014, the U.S. economy grew at 2.4 percent growth. Since the end of the recession, it's 2.2 percent. The debt is growing faster than that. We are going bankrupt. We are on the road to Greece. So, those are the facts. Now, on Peter's point--

### Conspiracy Advocate (CA)
Claim: What's going bankrupt? Just tell me again, who’s going bankrupt?

### Scientific Advocate (SA)
Claim: Well, okay, let's get to that. So this goes to Peter's point, nobody's going to replace the dollar, you're right. It's not going to-- it's not going to be the yuan, Peter, it's not going to be the yen, it's not going to be any of those kinds of things you mentioned. But I'll tell you what will replace the dollar and sooner than you think. The Fed printed $4 trillion to get us through the last recession. What happened was they substituted public debt for private debt. So, you're right, the banks are propped up. But now all that debt's on the balance sheet of the Fed. When the next liquidity crisis comes, what are they going to do, print another four trillion, eight trillion, 12 trillion? What is the confidence limit? There is only one clean balance sheet left in the world. When crisis comes, the world is going to be reliquified by the IMF using the special drawing right, which has been around since 1969, SDR's world money-- and, by the way, China will have a big vote, the U.S. will lose its veto. That's how they're going to reliquify the world.

So, by the way, we won't have it in our pockets. The dollars will be walking around money like Mexican pesos or Turkish lira, but the big stuff, the price of oil, balance of payments, that'll be in SDRs--

### Moderator
Claim: Jim, I want to break in-- I want to move on to something specific that I heard the two sides clash on in their opening statements, and that was the part that education is playing in this debate. The team arguing to bet on America talked about the much vaunted American education system, and the opponents argued that there’re real problems with education. So, let's start with the opponents-- your argument about access to education in the middleclass.

### Scientific Advocate (SA)
Claim: Okay, so, first of all, there wasn't a point made, which I totally agree with, about the excellence of American elite universities. Your universities are great. I went to Harvard. I loved it. The problem with American education is it is a symptom of this wider problem of the hollowed out middle class. American education isn't delivering to the people at the bottom, in the middle. And that's-- you know, everyone in this room is going to agree with that.

It's-- whether you're on the right or the left, you know that's the case. And in a winner- take-all economy, which is today's high tech economy, that means that social opportunity is being blocked, too.

### Moderator
Claim: Joe Joffe.

### Conspiracy Advocate (CA)
Claim: Did you pay your way at Harvard?

### Scientific Advocate (SA)
Claim: No, I got scholarships.

### Conspiracy Advocate (CA)
Claim: Aha.

### Scientific Advocate (SA)
Claim: From the province of Alberta.

### Conspiracy Advocate (CA)
Claim: Let me give you a number--

--60--

### Scientific Advocate (SA)
Claim: Thank you, Sandy Taggert

### Conspiracy Advocate (CA)
Claim: --60 percent of the so-called elite universities, 60 percent of those students are getting scholarships in one way or another. This is probably the best ladder of advancement you can get is the so-called "American elite universities." When I look at these kids in my seminar at Stanford, and I blame them for not knowing American history and then they all look up, and I see Korea, China, India, and so on, so that is one thing. One other point, the next-- once people concede the best universities in the world, they say, "Yes, but what about secondary education?"Again, one has to look at the numbers. Most Americans don't know it, but there's an OECD-- regular OECD study called PISA, Program of International Student Assessment. And, lo and behold, that maligned American high school, when it comes to reading and math skills, these kids are pretty much in the middle of the Italians, French, Israelis are far down, and Germans. So, that American state school system, which has been maligned for the last hundred years, is delivering pretty good stuff, at least it is not as everybody thinks, at the rock bottom.

### Moderator
Claim: Okay, I'm going to go to the audience now for some questions. And how this works is if you raise your hand a microphone will be brought to you. We want you to not ask the question till you get the microphone to you and have it about the same distance from your mouth as this is from mine so that the radio broadcast can hear you and the podcast. And we'd like you to tell us your name and then be very, very terse in asking a question that keeps us on point.

And I'm going to go right into the center, here. And if you can stand up, the mike will be brought down to you. Thanks. Once again, just tell us your name.

### Moderator
Claim: I'm-- it's a question for the opposition. Why does it matter that there is inequality if even the lowest are better off? So, if everyone has moved up, why does the inequality matter?

### Moderator
Claim: Okay, great question. Who would like to take that?

### Scientific Advocate (SA)
Claim: Yeah, I'll take it.

### Moderator
Claim: Chrystia Freeland.

### Scientific Advocate (SA)
Claim: Two reasons, first of all, strongest biggest problem is the middle is stagnant at both-- on income and on wealth. And employment is a real-- those good jobs for the middleclass are vanishing. That figure that I cited about comparing 20 to 50-year-old men in the U.S. and France, the fact that employment is lower in the U.S., that's a real issue. So that's the biggest reason.

### Scientific Advocate (SA)
Claim: And inequality doesn't matter if the lowest are moving up, but they're not moving up. That's the problem. They're getting lower. That's the problem.

### Moderator
Claim: Do you want to respond to that?

### Moderator
Claim: I would be happy to.

### Moderator
Claim: That was sort of a question from your side, but go ahead. Peter Zeihan.

### Conspiracy Advocate (CA)
Claim: Those of you in Gen Y who have college bills, they suck. I totally relate. Those of you who are in Gen Z, did you know that the cost of education if you don't go to Harvard is probably going to drop by 90 percent by the time that you're in college because you'll be able to attend schools online? Now, that's a problem if you're a college professor at the University of Wisconsin, but if you're somebody who's an education consumer, you are on the verge of the fastest advancement in the educational quality ever in the history of this country. And you know what? No one planned it.

### Moderator
Claim: Now, would you like to respond to that or should I go to another question? I'd like to move on unless you're strong-- feel strongly. Okay.

### Scientific Advocate (SA)
Claim: Well, I'll just say, you know, those-- I think that technology transforming education is a terrific thing apart from the professors who are going to be laid off, but the real issue is, "What are going to be the jobs for those kids when they graduate?"

### Conspiracy Advocate (CA)
Claim: Well, I don't know, but I don't--

### Scientific Advocate (SA)
Claim: That's the problem.

### Conspiracy Advocate (CA)
Claim: that question in 1940 who knew what they were going to be in 1960. That's the whole point of change.

### Scientific Advocate (SA)
Claim: It was a different phase in the technology revolution. We have to accept that it's not discontinuum. You know, the industrial revolution changed how the economy works. The technology revolution is doing the same thing and we're going to have to change how politics in society--

### Moderator
Claim: Okay. We're getting repetitive on the point, so I want to move on to another question, sir.

### Moderator
Claim: Sorry.

### Moderator
Claim: No, it's okay.

### Moderator
Claim: Hi. I'm Zachary Karabell. This is a question for Mr. Rickards. So let's say I agreed with you that there is a high probability of a global synchronous economic collapse, which I don't, but if I did, in what way is that an indictment or proof of the statement that America is in decline rather than a separate debate about the tenuousness of the global financial system?

### Scientific Advocate (SA)
Claim: Well, it's like a school bus full of children heading for a cliff and America is the driver. In other words, you know, America is so much better off than the rest of the bus.

The school bus driver is so much more mature than the kids in the back, but if you're going over the cliff you won't-- I don't dispute that when the dollar collapses the other countries will be right behind it, but this is about American leadership, which was Chrystia's earlier point, which is that the rest of the world, you know-- the USA is missing in action in Minsk today. We're missing in action in Brussels where the Greek EU negotiation was going on. There is no leadership from the United States. We are the largest economy in the world. We are the leader. We control the global financial system through the federal reserve.

### Moderator
Claim: Can I--

### Scientific Advocate (SA)
Claim: We're the ones driving the bus over the cliff.

### Moderator
Claim: Joe Joffe.

### Conspiracy Advocate (CA)
Claim: Let me again try to bring this back to the issue of the debate. You can't prove the point about decline versus non-decline by anecdotes. Now let's take the so-called withdrawal of the United States from the global arena, which by the way, is not exactly a liberal kind of critique, but more from the right, but it's true that under Obama this country has withdrawn, whether it's Minsk or Brussels or Pinsk or whatever.

Do you guys know where Pinsk is? No.

I do.

### Scientific Advocate (SA)
Claim: I’ve been there--

### Conspiracy Advocate (CA)
Claim: So-- wait, wait, wait, wait.

Now the problem is here with these arguments is that we can or you can vote Obama out of power in two years and this may change. The kind of long-term forces we keep talking about that Europe suffers under, China suffers under, Japan, you name it, cannot be decided or changed by vote and that's why I plead with you to keep anecdotes and trends apart.

### Moderator
Claim: Joe Joffe, I don't understand why you say an argument can't be made by anecdote frankly.

### Conspiracy Advocate (CA)
Claim: No .

### Moderator
Claim: I mean, Hitler rose to power and messed up Germany. That's an anecdote and it's true.

### Conspiracy Advocate (CA)
Claim: No, it's not. It's not because--

### Conspiracy Advocate (CA)
Claim: No, I'm sorry. To explain Hitler's rise you have to go into heavy duty sociology and economics and history.

Anecdotes prove nothing. They just make good debating points.

### Moderator
Claim: Joe, if I'm--

### Conspiracy Advocate (CA)
Claim: I'm talking about friends and forces.

### Moderator
Claim: Chrystia Freeland.

### Scientific Advocate (SA)
Claim: Joe, I--

### Moderator
Claim: I'm sorry. Jim Rickards.

### Scientific Advocate (SA)
Claim: I took pains. I took pains to avoid anecdote. I used science. If hypersynchronous ising model is complexity theory. I was putting in the scientific space. We probably don't have time for the equations, but I was not using anecdotal evidence. I was telling you how collapses happen.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate.

I want to remind you we're in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two debating this motion Declinists Be Damned: Bet on America. I love this audience. These questions have been great. Sir, in the back there. Keep the streak going.

### Moderator
Claim: Thanks. My name is Nick. The four side described many of America's advantages. So, question for both sides.

How are those advantages dependent or not dependent on our economic might that the other side argued quite heavily against?

### Conspiracy Advocate (CA)
Claim: Well, if I may say. If I'm allowed to repeat myself, some of the points I made have nothing to do with economic might. The power of immigration I'm talking about has nothing to do with it. The fact, what does it mean for somebody like Sergey Bryn to start Google? It means the freedom to dream, invent, and invest. It means rule of law. It means property rights. It means no barriers to competition. That's why this Russian- born kid did Google here and not in St. Petersburg.

### Moderator
Claim: Sounds like an anecdote to me.

### Conspiracy Advocate (CA)
Claim: No.

No. The anecdote made a very important point.

When I talk about the rule of law, that's not an anecdote.

### Moderator
Claim: Okay. Let's let the other side respond. Chrystia Freeland.

### Scientific Advocate (SA)
Claim: That's an excellent question, and it gives me a chance to make a point that I really wanted to make around the immigration and demographics argument. I agree-- those are tremendous strengths. And I think the 21st Century is going to be won by countries that are open to immigration and are feminist, and therefore are able to have demographic growth. What I'm worried about with the U.S. on-- and they're related, is when it comes to immigration, you guys are divided, and you're fighting about it. You know, would Sergey Brin get into the United States today? There is a huge immigration crisis in the U.S. with millions of undocumented immigrants. And your country can't decide whether to keep them and give them status or to kick them out. That, to me, is not a country which is united around what I believe Joe correctly points out to be the virtues of immigration.

But I think you're incredibly divided and torn on precisely this issue. So, I see the American debate, and you know, frankly the American paralysis-- gridlock, if you will, around immigration as a measure of decline.

### Moderator
Claim: Okay. Let's have--

### Moderator
Claim: I--

### Moderator
Claim: --Peter Zeihan respond.

### Conspiracy Advocate (CA)
Claim: Thank you. On the immigration debate, we are divided. But if you look around the wider world, you're right. There isn't that division, because most of them say, "No." And the ones that don't say "Hell no"-- the United States has the third largest foreign-born in the world-- Canada, of course, is Number 1. The United Kingdom is Number 2. You know, there are some commonalities here. But I want to talk about something a little bit more structural that I think might help with that argument. Moving stuff from A to B is really hard, but if you move it on water, it's 1/12th the cost. The United States has more miles of interconnected, navigable waterways than the rest of the planet put together.

### Moderator
Claim: Peter, I'm going to-- I'm going to cut you off there because that's not really to the question. I want to go back to questions.

### Moderator
Claim: Sir, right up behind-- behind you, actually. I'm sorry. Thanks.

### Moderator
Claim: Hi. My name is Hans. Why is moral power not on the table for this debate, specifically as it relates to foreign policy?

### Moderator
Claim: Can you-- can you--

### Moderator
Claim: As far as the measures of power that the team arguing in favor--

### Moderator
Claim: Well, you're asking why isn't it on the table. And that's not a question that's going to get them to this-- that's a different-- think about a way to-- I'm going to go on to another question. If we have time, I'll come back-- and I do mean it-- a way to get them to actually be debating the issue of moral power. Down in the front here, sir.

### Moderator
Claim: John Tierney. I've got a question for the opposition, for Ms. Freeland. The economy tends to grow faster in times when you have divided government in Washington. So, my question is, what's the problem with gridlock?

### Scientific Advocate (SA)
Claim: The reason that I cited the Brookings Survey is to show-- it's easy to argue it's actually not different this time.

And the reason I cited that Brookings study is I think it's qualitatively different if you can argue that compared to 65 years ago, it's twice as hard to get legislation passed. This is not a sort of healthy divided government, where the parties are coming together and making deals. This is a government where you're actually voting to stop funding the government. Is that how an adult country runs itself?

### Moderator
Claim: Would the other side like to respond?

### Moderator
Claim: Yeah.

### Moderator
Claim: Sir, do you want to try again? Did you want to give another shot at the moral question?

### Moderator
Claim: I'll answer, John.

### Moderator
Claim: Oh, I'm sorry.

### Moderator
Claim: I wanted to-- I actually wanted to give the other side a chance, unless you strongly feel so-- would you like to respond to that point?

### Conspiracy Advocate (CA)
Claim: Well, we're not an adult country. We're a young country. Are we making mistakes? Yeah. Do we make the most of our gifts? Of course not.

But how much better than everybody else do you have to be?

### Moderator
Claim: All right. Let me bring it back to Jim Rickards.

### Scientific Advocate (SA)
Claim: I left the moral part of it out of the argument because I was trying to do some less obvious things. A country that celebrates the degradation of "Fifty Shades of Gray" is way past the point of declinance

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Have you seen--

### Moderator
Claim: I've got to pass on it--

### Conspiracy Advocate (CA)
Claim: Have you seen the hit this movie has made in Europe?

### Moderator
Claim: Right down in front here.

### Scientific Advocate (SA)
Claim: That's relative decline, Joe.

### Moderator
Claim: Dana, how are we on time? Okay. Right down in front here.

### Moderator
Claim: Hi. This is for the pro team. It seems to me like--

### Moderator
Claim: For the motion, Bet on America?

### Moderator
Claim: For the motion.

### Moderator
Claim: It seems to me-- and I could be wrong-- that many of the world indexes today still rank the U.S. as 23rd or below most industrialized nations in pretty significant markers of quality of life, including infant mortality, mortality rates, homicide-- which, in the USDI for example, is about 1 percent higher than Syria right now-- literacy, health-- healthcare markers, science and math test rankings.

So, my question to you is how do you factor that into the argument that the U.S. in large measure has not been in a state of decline, if not disgrace, for some time.

### Moderator
Claim: Joe, do you want to take that one? Joe Joffe.

### Conspiracy Advocate (CA)
Claim: Look, you want disgrace, you can have disgrace.

But you can have the disgrace. I mean, the-- some of the numbers that you mentioned are right. The homicide-- by the way, homicide in this country has gone done enormously since the '90s, but that won't convince-- the infant mortality, high, we can explain it, but that's not the point. The point is what kind of standards are you setting here?

### Moderator
Claim: Wait, why aren't-- right, but--

--but why isn't that the point? But why isn't that the point? And you need to explain that.

### Conspiracy Advocate (CA)
Claim: No, I don't-- I--

### Moderator
Claim: You can't simply assert what you say are the standards here. You need to explain to her why her standards don't

### Conspiracy Advocate (CA)
Claim: You're taking sides. I'm sorry you're taking sides.

### Moderator
Claim: No, no, I'm asking to preserve the integrity of the debate, here. She asked a fair question, and I'm asking you to explain-- rather than dismiss her standards, please tell her why her standards are not relevant.

### Conspiracy Advocate (CA)
Claim: I was going to talk about it, but you interrupted me.

### Moderator
Claim: All right. You're true, I-- that's true, I did, and--

### Conspiracy Advocate (CA)
Claim: And you keep interrupting us. Anyway--

### Moderator
Claim: --it's my job.

### Conspiracy Advocate (CA)
Claim: --I can set any kind of standard which no country, no person can live up to. Does the United States have flaws? Of course it has flaws. It had tons of flaws. But it has nothing to do-- this is not an issue-- this is a moral issue which this country must fight and wrestle with but has nothing to do with the issue of decline or not decline. This is moral failure but not a power failure and we are talking about decline-- is about power and not about going to church.

### Moderator
Claim: Okay, you did answer my question. Sir, in the back there.

### Moderator
Claim: Yes, my name is Cliff. And this question is for both sides.

The United States was founded as a free market capitalist society. We were founded as a constitutional republic. How do you see how-- today from over the last 300 years, have we moved closer to that-- to those ideals or have we moved further away? And how does that answer the question as to whether we're in decline or not?

### Moderator
Claim: I'll let the second person--

### Scientific Advocate (SA)
Claim: There's-- I'd say there's nothing left-- there are no markets left. What you have is theater. You have the appearance of markets. Prices and things move around, but the Fed is manipulating the price of money. Money is the common denominator for every market. So when you suppress it and keep it at zero-- by the way, what's the impact of that? When you keep interest rates at zero, so let’s say some of your saving accounts or, you know, my mom has some money in the bank, they get zero. They get zero. The other side of that trade is if you're JPMorgan and you're Jamie Dimon, you're paying zero for your cost of funds.

You can go out and buy some ten year notes 10 to one and make 20 percent returns on equity. That is a $400 billion per year wealth transfer from everyday Americans to the power elite to the richest bankers. That's America today. So we have no markets left.

### Moderator
Claim: Peter Zeihan.

### Conspiracy Advocate (CA)
Claim: The founding fathers developed the political system for a largely agrarian coastal community. The fact that we have evolved so much from that and still have the oldest constitution in the world I think is a sign of incredible flexibility and strength on our part, and, God forbid me for saying this, even on the part of our political leadership. The space that we have is a big part of that on both sides. It also speaks to the question on standards. We're the least urbanized of the industrialized countries. So everything that we do for a city that we then have to do it for a constellation of a thousand small towns that still have autonomy, that is a degree of political self-determination that doesn't exist in any other political system on the planet, and I think that's admirable.

### Conspiracy Advocate (CA)
Claim: Can we--

### Moderator
Claim: Joe Joffe.

### Conspiracy Advocate (CA)
Claim: --can we compare the United States with the United States? I mean, when we talk about moral turpitude or failure, what-- how would we rate what followed the crime of slavery in the '60s when I was in college when we took over city hall for civil rights issues and stuff like that? Hasn't this country done a hell of a good job in-- with the Civil Rights Act, the Voting Rights Act, bringing previously downtrodden and discriminated people up to turn them into real citizens? Is that not the kind of moral achievement or what is this? If we think in terms of inequality, which is to obtain in this country when there was a Anglo WASP overclass ruling over others, and now one group after another being emancipated and made full citizens, is that moral failure or what is that?

### Moderator
Claim: All right, Chrystia Freeland, the argument that there's moral success, moral fiber.

### Scientific Advocate (SA)
Claim: So, I think we're all going to agree that ending slavery is a good thing. I think we'll probably all agree--

### Moderator
Claim: No, no, no, but that was-- that's dismissing the point.

### Scientific Advocate (SA)
Claim: --no, no, but I'm going to continue.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: I think we're all going to agree also that making women citizens and giving us the right to vote and participate fully is a good thing. And I would add-- because I do think there has been a rights revolution, not just in the United States, but around at least the Western world. And I think the fact that lesbian and gay people have increasingly full rights, although they did have the right to marry in Canada in 2005, is a really important and great thing. But we can't ignore Ferguson and the protests and "Hands up, don't shoot." There is still an American underclass, and that underclass today is feeling deeply oppressed partly by the economic circumstances that I was talking about.

And the American moral obligation to constantly advance this rights revolution is one reason why I am so agitated about dwindling economic opportunity in the middle and the bottom.

### Moderator
Claim: I want to let the other side respond first.

### Moderator
Claim: Yeah, sure, don't get me wrong. Ferguson was bad. One happens in Brazil every eight hours. I mean, yes, getting shot in the street is bad. Want to live in Gaza? Sure, political representation is difficult sometimes. How about the fact that a lot of what Snowden stole is being used by the Russians to monitor and destroy communications networks across the Russian Federation right now? Do we screw up? Yeah, a lot. That's what happens when you're a superpower. The lenses are on, your comparisons are made, which are not exactly fair. But the trick is to use what we have, which is the strongest economic system and the strongest political system in the world, to figure out how we want to make it better.

Will we get it with this Congress? I don't know. Will we get it with this president? I don't know.

### Moderator
Claim: Jim Rickards.

### Scientific Advocate (SA)
Claim: The proposition is, "Is America in decline?" And Joe's recitation of some of the great achievements of American history, and there's no disputing them, shows, where are the accomplishments, that the '60s were great, that-- you know, that many, many great things happened in American history. Where are they today? That's precisely the point. Those best days, those highest aspirations, America is a city on a hill. That's what's behind this. That's why we're in decline. We don't have anything to compare to that.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. Debate where our motion is, "Declinists Be Damned: Bet on America." And please remember how you voted before the debate. After closing statements, which will be brief, we'll have you vote a second time, and then we will present you with the results. On to round three, closing statements by each debater in turn, they will be two minutes each. Our motion is this, "Declinists Be Damned: Bet on America."And here to summarize his position in support of the motion, Joe Joffe, senior fellow at Stanford's Freeman Spogli Institute and editor-publisher of Die Zeit.

### Conspiracy Advocate (CA)
Claim: Okay, a lot of our debate reminds me of the story about Socrates being asked, "Socrates, how is your wife?" And he says, "Compared to what?"

And let me repeat this again. Remember, you talk about decline? We are talking about comparison. And we are talking also, if you wish, about progress, how we compare America then with America now. And-- but the most important thing is, "Is there somebody--" as we have argued in this country from decline 1.0 to decline-- "Is there somebody who was better, more agile, more virile, more ambitious, more skillful?

And will that nation overtake the United States?" And as I tried to make the point I was trying to make is that these challenges, we thought, we're growing faster, we're doing better, have all fallen by the wayside, which, therefore, then, made me look at the inherent and not the anecdotal sources of strength of this country. And if you look at the economy, the way this economy has rebounded while no other economy after the crash has rebounded, you must kind of say, there must be something here, or, we can explain it. Why the country does better in those respects, if you look at the relative decline of Japan, Europe, the United States in terms of global GDP, that gives you a sense that, again, transcends individual stories and tells you something about trends. And that's why I think the decline is a good pedagogical device.

And if you'll notice, half the time we spoke about how America should get better, which is a very good thing to talk about, but the issue is whether this country is declining vis a vis others and there you have no data whatsoever that makes the point. In fact, the opposite is true.

### Moderator
Claim: Thank you, Joe Joffe.

The motion is Declinists Be Damned: Bet on America and here to summarize his position against the motion, Jim Rickards, chief global strategist at the West Shore Funds.

### Scientific Advocate (SA)
Claim: I'm not sure how many people in the audience walked to the theater tonight. It's a New York venue, so I dare say some of you walked. New York is a great walking city. And I dare say that your walk to the theater tonight was completely undisturbed, unperturbed, and that's a great thing about New York.

But if this event were being held in Brooklyn, where my daughter happens to live, and if some of you lived in Bed-Stuy, I dare say you might not have made it quite so comfortably as the people here on the upper west side. You might've had your face smashed into a granite wall. You might've had handcuffs put on you. You might've been thrown in a van, taken away, taken to a precinct and strip-searched for nothing. No probable cause. Completely unconstitutional. Now, we call this stop and frisk. That's a nice euphemism. It sounds good, doesn't it? You know, you stop. You frisk the person. If there's a gun or there's drugs, you know, they got a problem. If there's no gun you know, just let them go on their way. You know, it may be unconstitutional, but we're sort of okay with that because, after all, we don't like guns. But that's not what happens. That's not what most people experience. They actually have this, I think, smash and strip would be a better description than stop and frisk. That's what's going on in the city of New York. Now, also in the city of New York a few miles away you have the most corrupt enterprise in history called J.P. Morgan and its fellow banks, Citibank, Goldman-Sachs, Morgan Stanley.

These companies have paid over $30 billion in fines, penalties, restitution, and compliance costs in the last four years and new cases are coming out every day. There was a new case in "The New York Times" yesterday about foreign exchange manipulation. Another one I saw today. Not one single executive of any of these banks has gone to jail. Not one has even been indicted. There hasn't been a trial. As long as America is a country where innocent bystanders are getting smashed and stripped and bankers are being left alone, America is a country in decline.

### Moderator
Claim: Thank you, Jim Rickards. That is the motion Declinists Be Damned: Bet on America, and here to summarize his position supporting the motion, Peter Zeihan, geopolitical strategist and author of "The Accidental Super Power."

### Conspiracy Advocate (CA)
Claim: Never underestimate the ability of the Americans to panic, learn the wrong lessons, and wreck everything. Sputnik. Beeping aluminum grapefruit. We were ahead in metallurgy, electronics, even rocketry.

Sputnik fell from the sky. Three weeks later Vanguard. Our first satellite, still up there. As a result of our panic attack we re-fabricated everything about our educational and scientific system. We coasted on that for three-- I'm sorry, for two generations. Vietnam. We lost a post-colonial war to a rice producer. It wasn't our colony. We didn't lose a single ally and we were the world's largest rice exporter at the time. As part of our overreaction to Vietnam we have crossed what was then information technology with weapons so we would never have to fight at arm's length again. We got everything from cruise missiles to cell phones out of that. Japanophobia. We became convinced in the 1980s that we had lost our position as the super power. Not would. Had. To a country with less usable land than Massachusetts who we were occupying at the time.

Wall Street forced the corporate reckoning that generated the biggest burst of capital that we have ever seen.

We are reliably our own worst enemy, but we are also reliably our own best motivators. You want to talk about the next crisis that we're likely to cause? Look at the aftermath of 9-11. We now have pre-positioned military forces on either side of every significant trade and energy artery on the planet. We are one waking up on the wrong side of bed away from perhaps precipitating the worst economic and military catastrophe this world has ever known and it's one that we would be largely immune to. So, Declinists Be Damned. Bet against America if you will, but do so at your own risk. The record just doesn't hold. I urge you to support the motion.

### Moderator
Claim: Thank you, Peter Zeihan.

That is the motion Declinists Be Damned: Bet on America and here to summarize her position supporting this motion Chrystia Freeland, member of Parliament in Canada.

### Scientific Advocate (SA)
Claim: My mother was born in a displaced person's camp, which you would probably call a refugee camp in Germany. Her family was fleeing the Soviet invasion of Ukraine during the Second World War. And so, it was a particular personal pleasure for me to start my career as a reporter in 1991, in the Soviet Union, as it fell apart. I was in Ukraine when it voted for independence. I was in Belarus when Yeltsin, Kravchuk, and Shushkevich signed the document that dissolved the USSR. And I thought then, as I think many people did, that that was going to be the beginning of an era when even more people around the world could enjoy capitalist democracy, this thing created by many countries, but particularly represented and led by the United States. Instead, where are we today?

Today, as we speak, an irredentist Russia has actually annexed, made part of Russia part of Ukraine. And instead of opposing this, some of these great rising democracies-- Brazil, India-- are actually on Russia's side because they don't want the U.S. to be a bully in the world. So, the world needs an America which is strong enough to assume moral and political leadership, whose middle class feels it has so many opportunities at home. It has the strength and the will to share those with the world. If we can't hang together like that, surely we will hang singly. Now, we've heard from Peter and Joe that America sometimes screws up, but then it comes to its senses, changes course, and gets it right. I'm arguing this side, because I think, in a lot of ways, America needs to change course. Denial is not a strategy. So, please vote for us.

And then go out and vote in 2016, and start changing your country's course. It's really important for all of us--

### Moderator
Claim: But-- thank you, Chrystia Freeland. Your time is up.

And that concludes our closing statements. And now it's time to learn which side you feel has argued the best. We're going to ask you again to go to the keypads at your seats, and take a look at this motion: Declinists Be Damned: Bet on America. If you agree with this motion, push Number 1. If you disagree, Push number 2. And if you became or remain undecided, push Number 3. And we'll give that about 15 seconds, and then we'll lock out the vote and have the results in just a moment. While we're doing that, the first thing I wanted to say was I wanted to congratulate the debaters for the quality of the argument they brought to the stage.

Really-- and I want to tell Joe Joffe, I apologize for calling you George. And I apologize for interrupting you if it felt like too much. I--

### Conspiracy Advocate (CA)
Claim: George is okay. George is okay.

### Moderator
Claim: The George part was okay. All right.

What were you saying?

### Moderator
Claim: No, no, no don’t talk to me!

All right. And the questions were also terrific tonight, even the question that-- as you saw, the moral question-- that was picked up by one of the debaters. So, thank you to all-- everybody who asked a question as well today.

So, on this occasion of our 100th debate, I'd like to thank our first-time and long-time audience members for coming tonight. We have a number of former Intelligence Squared debaters who are with us today, so you've probably seen them here in the past as well. We have members of our Board and our advisory council.

And to all of our friends, the generous supporters who make these debates possible-- I just want to say thank you, after a hundred of these things, for bringing this whole enterprise together. I also want to encourage everybody to please visit the IQ2US.org site and make a donation. The-- I know that you've paid to get in here with tickets, and we very much appreciate that, but the truth is that the ticket price doesn't come close to paying the cost for it. We rely on donations. We have a lovely app that you can get on your iPhone or your Android phone, and you can donate through there or through our website. And it would mean a great deal to us so that we can grow and keep this going for another hundred debates. Our next debate will be right here, March 11th, at the Kaufman Center. We will be debating whether the U.S. should adopt Europe's version of the right to be forgotten. Debating with us, we'll have a former director of global public policy at Google, and law professors from Harvard and the University of Chicago, and the E.U. Commission's Director of Fundamental Rights and Citizenship.

And before that, on Tuesday, February 24th, we're going to be holding a debate in Washington D.C. at George Washington University. The motion will be "Liberals Do Not Tolerate Intellectual Diversity on Campus." For the full list of those debates and to purchase tickets, visit our website IQ2US.org and as I pointed out our app allows you to download all now after tonight 100 of our debates and you can search for IQ2 US to find the app in the iTunes store or Google play and you can watch the live stream. So, we're going to have the results in just a second, but we're going to do something unusual tonight. We're going to bring on a special guest with a piece of art for a few minutes who is going to celebrate with us our 100th anniversary in the form of a short rap history of IQ2. I want to bring on Baba Brinkman. I need, as a disclaimer, this is a work of art. The views expressed will be Baba Brinkman's.

They will be excellently well done. Ladies and gentlemen, please welcome Baba Brinkman.

### Moderator
Claim: What do you do when you’ve had 100 debates besides hire a Canadian rapper to try to summarize them in four minutes. Right?

All right. Welcome to the Gladiator Pit. Where blood is entirely metaphorically shed with razor wit. The crowd is agitated only death can satiate it; they bay for it, also metaphorically. Actually the crowd patiently sits evaluating each debater’s degree of persuasiveness while waiting for their moment to key all of their appraisals in. If you can think of a major disagreement of today, it’s probably safe to say that this place has debated it. Everything from Obamacare to designer babies. Intelligence Squared ,oh yeah the kind of crazy from politics to religion if it’s controversial they’ve covered it. They’ve had debaters Christopher Hitchens to Arianna Huffington.

Now in 2006, the culture of New York was enhanced by the godfather of this event, Bob Rosenkranz--

He saw the competitions they were putting on in Britain and damn he thought New Yorkers would want to give it a chance and bam a hundred debates later it’s still an affair, it’s got a buzz like Phil Collins can fill in the air, Intelligence Squared--

Debaters are debonair like Fred Astaire. Peter Singer was here peddling unpopular fare advocating for euthanasia and rationing end of life care. Robert Reich persuaded a crowd such as yourself to tax millionaires. But Karl Rove won his debate, so it’s not just Liberals in here. The proposition was George W-- the worst president in 50 years. Debatable.

Michael Crichton stood on this stage to deny climate change, followed by hurricanes in New Orleans, along came the waves, and now Michael Crichton is rolling over in his grave. If you want to debate you came to the right place even the titles are designed to get a rise and make us irate.

Things like “Millennials Don’t Stand a Chance” “Spy on Me. I’d rather be Safe,” hey “Legalize Drugs,” “Don’t Eat Anything with a Face.” Some of the titles are provocative and some are just odd. “The U.S. Drone Program is Fatally Flawed.” “Men By The Way are Finished.” Wait, how about this one “Science Refutes God.” Dinesh D’Souza disputed that and got indicted for fraud. See most of the debate titles are actually pretty safe and straight forward and safe, except the hydraulic fracturing one. They called it no fracking way. So, how come the other debate titles don’t get a pun. This was “Declinists be Damned” But I think of a better one like you got to know when hold them, know when to the fold them, know when to walk away from America, know when to run. See, I don’t know if betting against America is a rational choice or if it’s just a feeling, but if it’s just a feeling then it’s one that’s shared by many such as myself and Chrystia Freeland, and I would’ve included you as well Peter, but your last named isn’t pronounced “Z-lin” so that

See you know I don’t know whether it’s really going to happen, like, betting on America doesn’t seem hard, because I am a Canadian right here applying for a Green Card. See or maybe the other side will carry it off, I mean here is a Canadian stealing an American’s job, but either way-- Look this place is no stranger to controversy, Ayaan Hirsi Ali debated mercilessly. Three out of four people would have said that Islam is a religion of peace, but when that little infidel had finished her piece, well then after that 55 percent disagreed. Booyah! You’re grandmother’s benefits, they were defended by Howard Dean and wait a minute, what about banning college football? Only 16 percent agreed, but Malcolm Gladwell flipped that number to 53, the audience blinked and the tipping point was achieved. This event is put on an elite team. No embellishment. You’ve got Dana from Canada. Lia, Clea, Amy and Alison.

You’ve got Adelaide, not the city. And Kris who does the research and it’s hard to overstate how much John Donvan needs her. Speaking John Donvan, he’s a rock, Mr. Constant. 82 straight debates, Mr. Cool, calm confident. Nobody is better at telling an audience member their question is unwanted. Although you guys did pretty well tonight, I have to say. But I swear Donvan can moderate a peace treaty between Brothel and Convent. Intelligence Squared, It’s a New York City phenomena and tonight’s debate is about to make it 100 strong. Give the audience what it wants. Persuasion and clever statements and straight facts and make some noise for the next gladiator debaters to enter the cage match.

### Moderator
Claim: All right.

All right. The results are all in. The motion is this: Declinists Be Damned: Bet on America. You have voted twice, once before the arguments and once again after the arguments. And the team that wins is the team that has changed its position the most in percentage-point terms. Let's look at the first vote. The result was 49 percent agreed with the motion: Bet on America. 23 percent were against. 28 percent were undecided. So, those are the first results. Again, it's the number-- whose team has moved the most-- it's the team whose numbers move the most in percentage point terms. Let's look now at the second vote. The team arguing for the motion, the second vote, they got 64 percent. They went from 49 to 64 percent. They picked up 15 percentage points.

That's the number to beat. Let's see the team arguing against. They went from 23 percent to 27 percent, only four percentage points. Not enough. The team arguing for the motion: Declinists Be Damned: Bet on America-- has won this debate. Our congratulations to them. Thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
