# Debate Transcript

Topic: Congress Should Pass Obama's Jobs Plan - Piece by Piece
Motion: Congress Should Pass Obama's Jobs Plan - Piece by Piece

Debate ID: obama-jobs-act


## Round 1

### Moderator
Claim: And Intelligence Squared only exists because of the foundation, the Rosenkranz Foundation which is making all of this possible. And I would like to introduce, to set the stage for the debate, the chairman of the Rosenkranz Foundation, Mr. Robert Rosenkranz.

### Moderator
Claim: Thank you very much. My role in these proceedings is to frame the debate. And tonight's concerns, obviously, Obama's jobs plan. Congress should approve Obama's jobs plan piece by piece, since the whole thing is no longer at issue in the Senate. The U.S. economy is cruelly stagnating. Unemployment is stubbornly above nine percent. And we risk a serious contraction if Europe fails to deal effectively with its own debt crisis.

While we do need to address the federal government's fiscal position in the medium term, the short term need is for government to encourage jobs creation. President Obama's plan does target the short term, specifically fiscal 2012, with a variety of measures. These include an extension of the payroll tax holiday for employers which is currently in effect. This is Economics 101. By decreasing the cost of labor, the payroll tax holiday encourages business to do more hiring. Another element of the plan is infrastructure spending, putting construction labor back to work for needed improvements to our roads, bridges, airports and the like. The plan will create 1.9 million jobs next year and add nearly two percent to national output. Where is a counter argument? It's that the proposal simply repeats the failed policies of the past, naively hoping for a different result this time.

At nearly half a trillion dollars, the plan adds around 40 percent to the already staggering trillion dollar deficit projected for next year. Even accepting administration claims at face value, it amounts to nearly a quarter of a million dollars in deficit spending to put a single worker in a job for one year. Moreover, it's arguable that the extra jobs will not materialize at all because the bill is rife with regulatory provisions that favor unions and discourage employers.

Both sides of the debate will acknowledge that for the economy to grow, consumers must have the confidence to spend, and businesses must have the confidence to invest and to hire.

Will the passage of President Obama's proposals restore confidence that our government is capable of decisive action and is doing the right thing to jump start the economy? Or will it destroy confidence by portending higher deficits, higher taxes, higher inflation and a bigger regulatory burden in the years ahead. The decision is yours. And we've assembled here an extraordinary panel of experts to help you decide. It's my privilege to turn the evening over to them and to our moderator, John Donvan.

### Moderator
Claim: Thank you. Thank you. And I'd just like to invite one more round of applause to Robert Rosenkranz for making this possible. True or false, Congress should pass Obama's jobs plan piece by piece? That's what we're here to debate, another verbal joust from Intelligence Squared U.S. I'm John Donvan of ABC News. We're at the Skirball Center for the Performing Arts at New York University.

Congress should pass Obama's jobs plan piece by piece. Two teams will argue that proposition from opposite sides, one for it and one against it. And only one team will win. And you, our audience here at the Skirball Center, a packed house, will decide the winner. Let's meet our debaters. Arguing for this motion that Congress should pass the jobs plan piece by piece, a former economic advisor to President Obama and a professor at Princeton University, Cecilia Rouse. Her partner is one of the nation's most prominent economic forecasters, chief economist of Moody's analytics, Mark Zandi. Putting the "Not" in the proposition, Congress should not pass Obama's jobs plan piece by piece, this team includes an influential thinker in legal academia, a professor here at New York University's school of law, Richard Epstein. his partner is a libertarian economist who focuses on tax reform and policy. He's a senior fellow at the Cato Institute, Daniel Mitchell. Now, this is the debate. One side will win, and one side will lose. And you, our live audience, will pick the winners. By the time the debate has ended, you will have been asked to vote twice, once before the debate and once again afterwards. And the team that has changed the most minds will be declared the winner. So let's now establish the baseline. We're going to go to the preliminary vote. If you go to those key pads at your seat, the way that it works, there are a lot of buttons on it. Pay attention to numbers one, two and three. If you agree at this point with this motion that Congress should pass Obama's jobs plan piece by piece, push number one. If you are against this motion, push number two.

And if you are undecided, push number three. You can ignore the other keys. And if you feel that you made an error, just correct it, and the system will lock in the last vote. So as the end of the debate, we will reveal this number that we're registering now and the second number. And by that, you will pick our winner. Okay. So we go in three rounds. And round one, opening statements by each debater in turn. Our motion is, "Congress should pass Obama's jobs plan piece by piece." And here to argue for that motion, Mark Zandi. He is chief economist of Moody's Analytics where he directs research and consulting. He is cofounder of economy.com and the author of the book "Financial Shock." He is also interestingly enough, Mark, I notice that on the White House blog where they are defending this plan, they cite, when they talk about independent points of view, Mark Zandi.

### Conspiracy Advocate (CA)
Claim: Well, I must be right then.

### Moderator
Claim: Well, it would be very interesting to see you agree with yourself tonight. Ladies and gentlemen, Mark Zandi.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you, John, thank you Intelligence Squared for the opportunity to be here. And it is certainly an honor to be here with such a thoughtful group of individuals. It's an honor to be here. I'm going to make four points in my opening remarks. Point number one is that I think there are a number of different reasons for why the Obama jobs plan should be passed. I'm not going to go through all of them. Cece's going to go through some of her reasoning. But for me the key thing is we need to avoid going back into a recession. And the jobs plan is instrumental in ensuring that we don't. The economy is obviously struggling. This is very obvious by looking at the job market.

If you take a look at the jobs data over the last few months, we've been getting job growth that's close to 75,000 per month on average. Just for context, we need almost double that to maintain a stable rate of unemployment. And unemployment is already 9.1 percent and thus threatens to higher. This is a rather dramatic reversal of fortune from where we were at the start of the year. I mean, it's hard to remember back, but just think about January, February, March, April. We were creating a couple hundred thousand jobs per month. And I was quite optimistic about the economy's prospects. But we got nailed by a number of what I call unfortunate events. In fact, John, I say they're unpredictable, largely because I didn't predict them. Higher energy prices due in part to the Arab Spring and the Libyan conflict, and even with the declining energy prices more recently, we're going to spend about a hundred, 125 billion more on gasoline this year than last.

And by the way, that's roughly equal to the payroll tax holiday that we got this year. So we literally took our tax cut, and we put it into our gas tank. It didn't provide the juice that we were hoping for, but I think it forced all the recession, very helpful. The Japanese quake, very hard on manufacturing, which has been a key source of growth. But I think the key thing that did us in this year was a series of what I consider very egregious policy errors. Most obvious being the spectacle over the debt ceiling debate. I think that just completely eviscerated confidence, undermined sentiment. It's not that people are pulling back yet. It's not that businesses are increasing their layoffs. But they certainly have stopped hiring, and that's why we're in the predicament that we're in. I do think that if policy makers do nothing, just sit on their hands and do nothing, the odds of recession are very serious. In fact, I think they're better than even.

Because in current policy, under current law, there is significant fiscal restraint, meaning that given some of the tax cuts that expire, given some of the spending increases that fade away, a federal fiscal policy will cut 1.7 percentage points from GDP growth. GDP is the value of all the things that we produce. They'll cut 1.7 percentage points from GDP growth next year, and if you throw in the cuts at state and local government, it's almost a couple percentage points. The good economy, a solid economy that's growing strongly would have trouble digesting that kind of restraint. A weak economy, the economy that we're in today, I think would be pushed into recession. So we've got to make some policy changes to ensure that, that fiscal drag is less significant than it is currently. Point number two, I think the fiscal stimulus that has been implemented to date has been effective. I think it succeeded. The purpose of physical stimulus is not to provide a source of long term economic growth.

It's about ending the recession. In fact, the Recovery Act-- this is the stimulus that most people are focused on, the $850 billion package that was implemented at the start of the Obama administration, succeeded in ending the great recession just-- a few days. The Recovery Act was passed in mid-late February '09. And by the way, in February '09 we lost 750,000 jobs. The economy was in freefall. By June the economy was growing again, GDP, again, the value of all the things that we produce was increasing, the recession was over by February 2010, one year later. We were creating jobs. And over the past year and a half since February 2010, we've created well over two million jobs. It's not good enough but in the-- I think the counterfactual is here-- here is a much more serious recession. In my view, we would've suffered a depression.

The stimulus efforts were very successful in ending the great recession, jump starting an economic recovery. Third point-- did I tell you how many points I was going to make?

Four. The third point-- just testing, making sure you're paying attention-- third point is that the Obama plan is pretty well structured, 450 billion over two years, 250 billion of which approximately are temporary tax cuts, another 200 billion in temporary spending increases. You know, not all of the pieces of the package are made equal. In my view, the most important element of the plan is the extension of the payroll tax holiday for workers. If we do not extend that, taxes for everyone will rise on January 1, 2012, and again, given this economy, that would be a very significant problem. There are elements of the plan that are really quite creative, some of which Cece has worked on with respect to providing incentives for employers to go out and hire people.

There are reforms to the unemployment insurance system that I think has wide bipartisan support, and there's some really creative elements with respect to infrastructure spending and infrastructure banks to try to get private capital married with public money to go out and invest in our much depleted infrastructure, and the most important thing you should know, it is all paid for. This is not a deficit of finance. It will be paid for by-- at this point, the discussion is to have a tax surcharge on people who make a million dollars a year. Now, that's a negative. I don't like raising taxes on anybody, but I think that's a modest negative in the context of, again, not going back into recession. And finally, point number four, this is very important, the jobs bill is only one part of what policymakers need to do to get this economy on the right track. We also need long term economic policy, but we have-- Congress and the administrative have to follow through on the debt ceiling deal, and we need tax reform.

So we need to reduce the tax expenditures in the tax code, make it fairer, less complex, and put our businesses on solid ground. So this is only the start of what we need to do. It's not the end. I want to thank you very much for your kind attention. We just can't go back into recession. Obama's job plan will ensure that we don't. Thank you.

### Moderator
Claim: Four.

### Conspiracy Advocate (CA)
Claim: Four. The third point-- just testing, making sure you're paying attention-- third point is that the Obama plan is pretty well structured, 450 billion over two years, 250 billion of which approximately are temporary tax cuts, another 200 billion in temporary spending increases. You know, not all of the pieces of the package are made equal. In my view, the most important element of the plan is the extension of the payroll tax holiday for workers. If we do not extend that, taxes for everyone will rise on January 1, 2012, and again, given this economy, that would be a very significant problem. There are elements of the plan that are really quite creative, some of which Cece has worked on with respect to providing incentives for employers to go out and hire people.

There are reforms to the unemployment insurance system that I think has wide bipartisan support, and there's some really creative elements with respect to infrastructure spending and infrastructure banks to try to get private capital married with public money to go out and invest in our much depleted infrastructure, and the most important thing you should know, it is all paid for. This is not a deficit of finance. It will be paid for by-- at this point, the discussion is to have a tax surcharge on people who make a million dollars a year. Now, that's a negative. I don't like raising taxes on anybody, but I think that's a modest negative in the context of, again, not going back into recession. And finally, point number four, this is very important, the jobs bill is only one part of what policymakers need to do to get this economy on the right track. We also need long term economic policy, but we have-- Congress and the administrative have to follow through on the debt ceiling deal, and we need tax reform.

So we need to reduce the tax expenditures in the tax code, make it fairer, less complex, and put our businesses on solid ground. So this is only the start of what we need to do. It's not the end. I want to thank you very much for your kind attention. We just can't go back into recession. Obama's job plan will ensure that we don't. Thank you.

### Moderator
Claim: Thank you, Mark Zandi. Our motion is "Congress should pass Obama's jobs plan piece by piece," and here to speak first against the motion, Daniel Mitchell. He is a senior fellow at the Cato Institute where he focuses on tax reform and supplied side tax policy. In his past, he was an economist for Senator Bob Packwood and the Senate Finance Committee. And, Dan, you do these videos online that I've seen where you explain economics to the masses. I want to compliment you on your delivery--

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: --as from inside the business. It's excellent. I was taken with your discussion of government spending in which you said that in the end you feel that the real reason that government spending happens, you say, "I suspect it's because politicians just love spending other people's money," but you worked for a politician?

### Scientific Advocate (SA)
Claim: Yes, but I've reformed.

### Moderator
Claim: You-- okay. Ladies and gentlemen, Daniel Mitchell.

### Scientific Advocate (SA)
Claim: Thank you very much. It’s a real honor to be here, especially with such a distinguished group of co-panelists. As a matter of fact, I think what am I doing here? I’m sort of like the SAT answer, one of these things is not like the other. But hopefully, since I am representing the Cato Institute, I want to give people a very good impression about what libertarian philosophy of left government and individual freedom is all about. And the way Richard and I are going to divide up our responsibility, I’m going to look at sort of the macro issues of stimulus and Keynesianism and Obama’s Jobs Act. And he’s going to look at some of the nitty gritty details. That of course enables me to do the easy part and him to do the hard part. And I want to divide my part up, the macro part looking first at the theory and then at the evidence.

Now Keynesians say that whenever the economy’s weak, the government should borrow money, spend the money, or give tax rebates or tax relief in some form or fashion. The goal of both the spending and the tax relief is to put money in people’s pockets so people will go out and spend the money and sort of jump start the economy. And that sounds very plausible. It makes sense. We’re all going to have money in our pockets. We’re going to go out and spend money. That has to do something good for the economy. There’s only one little problem with the theory. Where does the government get the money? Government can print money. Government can borrow money. Government can tax money. But there’s no way the government can put money into the economy without first in some form or fashion taking money out of the economy. And what is it that we’re trying to do? What is a recession? A recession means that our GDP, which used to be this much, is now this much.

This by the way is a West Virginia PowerPoint slide here. What is it that we want to do? What is economic growth? Economic growth means we’re going to take this GDP and we want it to be higher. But what is Keynesianism? What is stimulus at least as it’s defined inside Washington? Stimulus inside Washington is well let’s money from the economy’s right pocket and put it in the economy’s left pocket. But are we doing anything to increase this blob called GDP? No, we’re not. My contention is that what Keynesianism does is it redistributes national income, usually in ways that politicians find attractive because they can try to become Santa Claus and buy votes, but our goal should be not to redistribute national income; we want to increase national income. We want a bigger pie so everyone can get a bigger slice, that’s what economic growth is all about. Let me give you an example that I think makes this clear.

This is actually a quiz. It’s not like the thing where you get to vote twice. By the way, if you let them vote five times, you could rename this Chicago. a little quiz that will determine whether or not you’re qualified to be a member of Congress. Let’s divide this room in half. Let’s borrow all the money out of the pockets of the people on this side of the room and give it to the people on this side of the room. Now here’s the quiz. Raise your hand if you think there’s more money in the room. I’m sorry, none of you are allowed to be in Washington because you have failed your elementary test on Keynesian economics. And if you look at what’s happened. If you look at the evidence for Keynesian economics, for stimulus, whatever you want to call it, what do we find? I don’t think we find very good results. You can go back to the 1930s, Hoover and Roosevelt were both Keynesians. Hoover increased government spending by 47 percent in just four years, that was a period of deflation so it was actually more than 50 percent in real terms. The economy didn’t do any better. Roosevelt in eight years, from 32 to 40, increased government spending by more than 100 percent.

Unemployment stayed high, the economy stayed in recession. Now, let me give a little bit of humility, first, on behalf of all economists. If you ask five economists a question, you’ll get nine answers . We have correctly predicted 14 of the last three recessions. We’re not very good at these things. And especially when you’re looking at something like the overall macro economy. There’s trade policy, there’s regulatory policy, there’s labor policy, monetary policy. There are all of these different things going on in the economy, not to mention some of the exogenous factors that Mark talked about. Earthquakes, hurricanes, tsunamis, oil price shocks, you name it. And now we’re expecting to look at one little slice of all of these different policy levers, fiscal policy, and we’re supposed to make sweeping judgments about what exactly it means. Of course at best all we’re really doing is guessing. But if you look at those periods in time when you did have politicians like Hoover and Roosevelt increasing government spending, it doesn’t seem to have worked.

But it’s not just the 1930s. Gerald Ford had a Keynesian tax rebate package in the 1970s. It didn't work. Japan has had, by some accounts, 16 different stimulus packages since their economy entered the doldrums in the 1990s. Those haven't worked. Bush had a Keynesian stimulus package in 2008. It didn't work. And then, of course, Obama more recently has done the same thing. And time after time after time we don't seem to be getting very good results. Now, I'm not up here to make partisan points at all. What I think of policies that have not worked very well, you'll notice that I've listed Republican administrations and Democratic administrations. But if you ask me what should happened, if you ask me for the success story, I look at things such as the Clinton years and the Reagan years. And this should make Cecilia happy because she worked for the Clinton administration before working for the Obama administration. She did a good job her first time around. Her second time, maybe not so much.

But if you look at what happened during the Reagan years and the Clinton years, and you look at these broad measures of economic freedom such as the Frazier Institute, economic freedom of the world index or my old employers at the Heritage Foundation, their economic freedom of the world index, or the world economic forum's global competitiveness report, you will see that during the Reagan years, during the Clinton years, you had more economic liberalization, more freedom, a reduced burden of government spending. And that's why I think we got better economic results during those periods. Now, I'm running out of time, so let me go ahead and say something about what should happen, because obviously I'm up here trying to convince you to vote against the motion. In some sense, politicians should follow the Hippocratic Oath. First, do no harm. And I do worry that when politicians, especially driven by that short- term time horizon of trying to get reelected and wanting to send out press releases, oh, we're doing something. They want to show that, oh, we care. You know, what was that, the first President Bush went up to New Hampshire in '92, message, "I care."I mean, boy, talk about an empty, vacuous statement to make. But that's how most politicians think. They really are driven by this desire to try to demonstrate to voters that they really are concerned about your best interests, when in reality, in many cases, at least part of their decision making is driven by their desire to get more votes. So I don't want--

Thank you very much. Thank you.

### Moderator
Claim: Daniel Mitchell, your time up. Thank you very much.

### Scientific Advocate (SA)
Claim: Thank you very much. Thank you.

### Moderator
Claim: So here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan of ABC News. And we have four debaters, two teams of two arguing out this motion: "Congress should pass Obama's job plan piece by piece." You've heard the first two debaters and now onto the third. Arguing for the motion, I'd like to introduce Cecilia Rouse. She's a professor of economics and public affairs at Princeton University's Woodrow Wilson School. From 2009 to 2011, she was on the inside. She served as a member of the president's Council of Economic Advisors. And Cecilia, I want to ask you about Thanksgiving at your house, because I understand you have a physicist father and a physicist brother, and you're an economist and three PhDs.

Maybe there's a fourth one in the family somewhere. So what, do you talk numbers and formula all through--

### Conspiracy Advocate (CA)
Claim: Actually, there is a fourth PhD, my sister who is also a professor at Princeton, actually. But she's in anthropology. So Dan Hamermesh who is a professor of economics at Texas, says, let me think. Your father was a theoretical physicist. Your brother's an experimental physicist. You're an economist, and your sister's an anthropologist. You're getting weaker as you go.

### Moderator
Claim: Ladies and gentlemen, Cecilia Rouse.

### Conspiracy Advocate (CA)
Claim: Thank you. It really is a pleasure to be here tonight. And, you know, Dan really said it right when you said you have five economists, you really only get nine opinions. I think you get many more. I was in the Clinton administration. Those were good years in the '90s. I think many people might interpret those times, though as that the Federal Reserve, because we were having a lot of economic growth, and the Federal Reserve was not anywhere near having interest rates which were so near to zero, that monetary policy-- the Federal Reserve was actually responsible for a lot of that growth.

In contrast, what we have today is, specifically, a Fed that cannot do as much as it normally can in normal times. Interest rates are near zero. It's near zero, lower bound. You can't have negative interest rates, and therefore it's an opportune time to have more fiscal policy. But my debate partner talked about some of these bigger pictures. I'm a labor economist. I got into economics because I was worried about the unemployed, and I still am. There are 14 million workers in the United States who are unemployed. Half of them have been unemployed for more than six months. There are another two and a half million who are discouraged, meaning that they've even given up looking. And there's about nine million who are working part time, but who would actually like to work full time. So they're working part time for economic reasons. We've had 19 straight months of private sector employment growth. But we've also had many months where the public sector has had negative employment growth.

And as a result, we have a recovery, but it's a recovery with a small R. It's just fledgling. And as Mark pointed out I'm also very concerned that this recovery is just not far enough along. Now, there're huge challenges that this entire downturn is going to pose for us going forward. When workers become displaced, they do not earn-- they have, going forward, for 15, 20 years, they're going to earn much less, by some estimates, 10 to 15, 20 percent less than they were earning before their displacement. It has impact on their children. Their children get lower levels of schooling going forward. It is going to affect the earnings of their children. And look at all of the young people today who are finishing their schooling and can't get a job, meaning they're not even getting started into the labor force. So we know that these have the potential to really hold back economic growth going forward. So yes, I support the Obama plan. I support any plan where it's going to provide some sort of short-term insurance against another double-dip recession or having more downturn.

Now look, last year, I was at the Council of Economic Advisors. And things were looking a lot better. And as a result, if you listened to the president's State of the Union, what he proposed in his budget were investments that were not towards stimulus, but were really towards the foundations of growth, in infrastructure and education, in innovation. And I believe that they are very important. And we all believe that. But we don't have the economy today that we had just six, nine months ago. And therefore, I think the time is right for Congress to act. Now, let's first talk about the pillars of what-- the major components of this plan and what it would do. So first of all, about 40 percent of it is putting money in the hands of individuals. Okay. Some people may say, well, look, that's putting money in their pockets. They're not doing much. But let's talk about it. So the tax cut was providing about $1,500 a year in tax cuts for those who are earned about $50,000 a year, which is about what the median family earns, I should say.

It was about $2,500 for those earning $80,000 or more. It continues the federally funded unemployment insurance benefits. Now, let's talk about that. Six million workers will lose those unemployment insurance benefits. They lost their job through no fault of their own. These benefits are not helping them live high on the hog. It's only replacing about half of their wages, which means they're getting a check of about $320 a week. And we know that that's about a third of the family income. It helps them to pay their mortgage or pay their rent, helps them put food on the table. It helps them to support their local businesses, et cetera. And that's the way in which it helps to support the economy. The Congressional Budget Office has said that these sorts of benefits are one of the fastest and most effective ways in which to help our economy in the short term. Important we can talk more about this. I know many believe that this is not the time to continue-- to continue these sorts of benefits. And I would argue this is exactly the time to do so. It also-- let's face it, the private sector is the most important source of job growth in this country. They provide 80 percent of the jobs.

So another part of this is-- this is not about trying to create a gigantic public sector jobs program. It's about trying to stand up the private sector. So another 20 percent or so are ways to try to cut the cost for businesses to do their business. So I teach microeconomics. Firms do business by having labor and capital. I hope that's as geeky as I get tonight. And there are ways to cut their investments for next year and as well as lowering costs of hiring workers. Again, it extends the payroll tax cut not just to the employee but to the employer now. And it also provides an extra incentive for firms to bring on more workers. And lastly, as I mentioned before-- all of those should help in the next year. But we know we're going to be in this for a little while. It takes a while to recover from downturns that are caused by crises in the financial sector. And so 20 percent of it is also directed towards infrastructure, which again we think is actually one of the pillars of economic growth. Now, as Mark mentioned, there are some innovations in the way some of this money would be spent.

In terms of the unemployment insurance benefit, there are some encouraging states to provide more employment, reemployment assistance to workers. There is encouraging states to stand up programs where firms don't have to choose between laying off workers and keeping some-- they can share the pain, if you will, for a temporary downturn, through work sharing. It encourages entrepreneurship by encouraging states, some of which already have them, including my own state of New Jersey-- help making it easier for aspiring entrepreneurs who are unemployed to be able to start their business while they're receiving these unemployment insurance benefits which they currently are not technically allowed to do. And it also starts an infrastructure bank which is a creative way of trying to bring private money into trying to foster some of these public projects for which normally the private sector doesn't receive enough of a return in order to do. So I think that it's a balanced package, and I think it hits a lot of the right parts. As Mark mentioned, it's paid for. We can talk more about the way it's paid for.

You know, the current idea on the table is Senator Reid proposing a 5.6 percent tax on those whose adjusted gross income is more than a million dollars, that's about .03 percent of American taxpayers. So, in closing, yes, I support a program that will provide support to this economy today because I am very worried about how families are getting by. We have 46 million families living in poverty. I'm worried that our recovery is fragile. This doesn't mean that we don't need longer term strategies to have more robust growth going forward, but I just don't happen to believe that these aren't mutually exclusive. Maybe hope springs eternal, but I think that Congress can walk and chew gum at the same time, thank you.

### Moderator
Claim: Thank you, Cecilia Rouse. Our motion is "Congress should pass Obama's jobs plan piece by piece," and now here to speak against the motion, I'd like to introduce Richard Epstein.

He's a professor of law here at New York University Law School, a senior fellow at the Hoover Institution, and a professor of law emeritus and senior lecturer at the University of Chicago where, interestingly enough, given the context, a colleague you used to bump into in the hallways, an adjunct professor was named Barack Obama--

### Scientific Advocate (SA)
Claim: Yes, he was--

### Moderator
Claim: And I understand you knew him a little bit, and you're quoted as saying that you found him to be an amazingly talented intellectual-- amazingly talented at playing intellectual poker, which, to me, sounds pretty cool.

### Scientific Advocate (SA)
Claim: It's very cool. It was very difficult to read the man, and that's why it was that he was such a great poker player. But the question is not whether he could play poker, it's whether or not the statute that he proposes is one that will do the things that we want it to do. And in this debate, there is no disagreement over the sad state of the American economy and the need for something to be done. The question is how it should be done, what should be done, and why. And I'm a lawyer, and I'm with three economists, and I have at least one comparative advantage or disadvantage as the case may be, I actually spent time reading the statute to see what it says in order to figure out whether or not the pieces make any sense.

And it's interesting that you can talk about this at the macro level, but it's also extremely important to talk about it at the micro level, and so let me tell you some of the pieces which I think are positively self destructive and ought never to see the light of day. One of the truly misguided features of the stimulus program of 2009 was the passage of ARRA, the American Recovery and Reinvestment Act, which instituted a whole variety of buy American provisions in the bill with respect to those funds which were to be distributed through the government to various kinds of employees. If you look at the kinds of provisions that are created there, it's a massive bureaucracy which is designed to ensure that the money which is so distributed will be largely wasted. It is the kind of thing which says that you cannot buy from sensible foreign providers if they are expensive and inefficient American providers, then there are huge amounts of administrative discretion as to when these particular requirements will be relaxed. The whole thing in effect will take a large portion of the stimulus program, and it will turn it into a waste.

A similar provision is a re-incantation of one of the worst pieces of Hoover's legislation, the Davis-Bacon Act, saying that when the government gives this kind of money out, you have to pay prevailing i.e. union wages with respect to the money in question. So the stimulus program seems to say, "The way in which you get the most for your money is to spend as much as you can on labor rather than as little as you can," and there's no way that this kind of monopoly waste can possibly improve the situation with respect to the legislation in question. A third feature of the bill is to introduce a new form of an anti-discrimination act which says that you cannot discriminate against people who are unemployed when you decide whom to hire. That of course is an extremely complicated provision. It has about four separate pages to it, and there's an exception which says that, "Yes, you can take into account their job record under these circumstances." So any employer who now wants to go out into the labor market has to worry about the question when they hire from other places that they may be running-- exposing themselves to either government liability or to private lawsuits.

But of course this does nothing to improve aggregate hiring because if you hire somebody who's already employed, that opens up a position for somebody else. So what you have to understand is at these particular levels, all of the micromanagement is counterproductive to the macroeconomic goal that is in question. Then the next thing that we've heard about, and was praised mightily, was the payroll reduction tax for a single year, and what happens is we know what's wrong with this tax because we've been told so by our opponents in this case. Employers are not people who are foolish. They understand that if they want to hire somebody for the long run, they don't only look at this year's rates, they look at next year's rates as well. Our objective with respect to tax policy is to create some kind of a sustainable system of growth. We cannot do that, say, to people-- hire people this year, train them for 26 weeks, and then when you get to next year, what's going to happen is you're going to go back to the higher rates of taxation.

People will look and discount the future and therefore will not hire on the strength of something unless it has a time horizon equal to that of the benefits that you hope to achieve. You must create lower tax rates that last for a longer period of time if this is going to be able to succeed. Any kind of short term fix at this particular point is doomed to failure. There is no escape from that particular kind of conclusion. So then the question comes, and I’ll talk about this for the remainder of my time, what is it that we ought to do if it turns out that we think that for both macro and microeconomic reasons that the Obama tax plan is doomed to failure? And it seems to me what we have to do is to start from the ground up and then think about how it ties into macroeconomic policy. So as a lawyer in particular, one of things that impresses me is at the same time we hear the grand talk about how it is we have to stimulate labor markets with respect to macro policies, we have an administration that has introduced very destructive policy at the micro level and all of these things have to be reversed.

So if you want to start with some of the difficulties in question, just take for example, as one particular, the decision of the administration to chase after the Boeing company with respect to its decision to locate a plant in Columbus-- or Charleston rather, South Carolina. The net effect of this is that any time a union negotiation breaks down, an employer who tries to make an intelligent response by shifting states is going to be faced with a government prosecution. This is not an incentive to create new plants and new jobs. In effect what it is is it gives the union captive power over workers, over jobs in fact that a sensible employer might want to move to some other place. When you start looking at the other micro things, for example, in 2005, what we decided to do was to raise the minimum wages. And it seemed to be a fine thing because those were optimistic days. But if those wages happen to go down in market terms at the same time that the minimum wage is moved up, what’s going to happen is at the lower level you’re going to find that it’s very difficult for lots of unskilled people to get that first job.

And the point that was already said, namely if you don’t get the first job, you’ll not get the second and third job is in fact something which has been done.

So this is another kind of policy that you have to be able to reverse under the circumstances of this case. And the list can go on. The government has decided that what it wants to do is increase the ability of unions to organize by allowing quickie elections to take place after it turns out that the requisite number of cards have been filed with the National Labor Relations Board. If you’re a small business trying to go in, it’s just a wonderful thing to note that after you’ve been in business for three or four weeks, all of a sudden you’re hit with a suit by a union which says we want to unionize, you’d better go out and find a lawyer otherwise capitulate to our demands. There is no way you can create things in a labor market under these circumstances if in fact you keep kicking people in the shins at the same time that you’re trying to subsidize it at the top.

And also there is at present, the Obama legislation which is essentially designed to create all sorts of medical benefits through the health care system which is going to predicate itself upon the employment relationship. And these again are implicit taxes. So the final message that I want to leave you with is this. The way to deal with labor problems is not to talk about earthquakes; it’s to talk about labor markets. And the way to talk about labor markets is to liberalize it such that when people realize their chances to get gains from trade, they will return to the hiring market. Thank you.

## Round 2

### Moderator
Claim: Thank you Richard Epstein. And that concludes round one of this Intelligence Squared US Debate where our motion is "Congress should pass Obama’s jobs plan piece by piece." Remember we had you vote before the debate to tell us where you stand on this motion. We’ll have you vote again at the end of the debate asking as which side you feel argued best and the team that has moved its numbers the most will be declared our winner. So now on to round two where I ask questions to the debaters.

They address one another. We take questions from you. Our motion is "Congress should pass Obama’s jobs plan piece by piece." We have two teams of debaters. We have Cecilia Roust and Mark Zandi who are presenting the argument in favor of this motion and in favor of the jobs plan, arguing that they feel that it is absolutely critical to avoiding another recession. That workers who are not floating, who are sinking, are going to lead to no growth in the economy and if anything, a step backward, that this program at a minimum, at a minimum puts a stop in there. Arguing against them, Richard Epstein and Daniel Mitchell who argue that this is essentially another stimulus plan, that historically stimulus plans do not work and that it is rife with all kinds of bureaucratic induction of distorted enhancements that will make it difficult for businessmen simply to hire people and make decisions going forward. And therefore, if it were passed, it would never work.

That’s where the two sides stand on this. And I want to start with the question to the side arguing for the motion and to Mark Zandi. With your opponents arguments very strenuously. But essentially this is a stimulus program, and I think you agree with that, and you're saying that, in your argument, that this is needed to avoid a recession. And you have argued that stimulus programs have already worked in this administration in doing good. I wanted you to take on their argument that historically, that's not the case at all.

### Conspiracy Advocate (CA)
Claim: Well, I don't think that's true. I think fiscal stimulus is a tried and true policy response to recession. Since every recession since World War II, we've had fiscal stimulus. In fact, the degree of fiscal stimulus provided is commensurate with the severity of the recession, at least as measured by the unemployment rate. And in fact, one could argue that the fiscal stimulus that was provided in this recession, the great recession, was inadequate.

It was not proportional to the severity of the recession. And that's one of the reasons why the economy hasn't engaged to the degree that I think most would have thought at this point. Moreover, I'm not alone in this view. Cece brought up the Congressional Budget Office. The CBO is a nonpartisan group respected by both Republicans and Democrats. They score the various proposals made by policy makers, tax policy and spending policy. And they do studies of various stimulus packages. And they released the estimates on the impact on GDP, on jobs, unemployment on a regular basis and they show consistently that they believe that this had been--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --a plus to the economy.

### Moderator
Claim: So you're saying it's a mainstream view. I'd like to bring it to Richard Epstein on the other side.

### Scientific Advocate (SA)
Claim: Look, I think in effect we've seen the results already.

At the time that the Obama administration introduced its first stimulus program, there was a confident prediction supported by the CBO that it would lower the unemployment rate down to eight percent. Nothing of the sort happened. It stayed exactly dead level under the circumstances. So the question is, why is this going to happen? And essentially the CBO scores in a very static way. It listens to what the administration says about the number of dollars they're going to spend and the cost for particular jobs, and it thinks that economics is a form of multiplication and subtraction and addition. The problem is the money has to come from somewhere. And the basic tradeoff that you have is this: If in fact you decide to run this thing through a stimulus program, you must raise taxes. If you raise them, as is now proposed on the most productive individuals in society, it turns out that you're taking money from the hands of people who know how to use it and to put it into the hands of a government which simply does not. So the prediction is, at this particular time, what will happen is exactly the same thing that happened before.

There will be a short-term burst, and then magically, there will be another earthquake, and the program will fail.

### Moderator
Claim: Okay. Cecilia Rouse, I'd like you to respond. There were a bunch of points in there, including don't trust the CBO, I think.

### Scientific Advocate (SA)
Claim: Never.

### Moderator
Claim: Never trust the CBO.

### Conspiracy Advocate (CA)
Claim: percent unemployment. That wasn't the CBO.

### Conspiracy Advocate (CA)
Claim: Yeah, that wasn't the CBO.

### Scientific Advocate (SA)
Claim: Well, who did? Did you?

### Moderator
Claim: Cecilia. But Richard's point about these programs remove money from people who make the best use of it and give it to those who don't, can you take that on?

### Conspiracy Advocate (CA)
Claim: Well, you know, there is a theory in public finance that says that you shouldn't have a very high marginal tax rate on the very highest earners. But if you actually look at the-- in our experience over time, there's not a great relationship between the highest marginal tax rates and how we're doing in terms of economic growth. If you look at Reagan, he lowered tax rates for high income individuals. Clinton increased them. And you saw somewhat greater economic growth under Clinton than under Reagan.

So I think the evidence tells us that, yes, there is-- these are tax rates. So I'm not going to say that there's no impact at all in terms of lowering economic growth, et cetera. But it's very small for the highest earners because they don't spend the tax cuts. And it doesn't have that big of an impact on their earnings. You know, some have looked at what some of the highest paid CEOs did with their tax cuts. Some of them, it's true. They exercised stock options creatively and strategically. But in terms of their general income, which is really the income-generating activity, there was really no impact. So I actually think that this is-- I think it's a small tax increase today, but-- not today, it's in a couple of years, and that it'll be at a time when the economy can actually sustain it.

### Moderator
Claim: Daniel Mitchell.

### Scientific Advocate (SA)
Claim: Well, a couple of points. One good thing about being a libertarian is I don't have to respect the CBO because CBO, like a lot of the Keynesian models, they presuppose their results. It's just a mathematical formula.

If the mathematical formula is wrong, if they automatically assume that if the government increases spending by X, the economy goes up by Y, and they never pay attention to the fact that while the economy actually went down by Z, they say, well, it would have gone down by more than Z if it wasn't for the government spending. So it's sort of this perpetual motion machine of economics. The White House in 2009 said if you pass the so-called stimulus, the unemployment rate will never rise above eight percent. And instead, it's never dropped below nine percent.

### Moderator
Claim: Let me just fact check you to the other side. Is that accurate? Cecilia Rouse.

### Conspiracy Advocate (CA)
Claim: That-- okay. So that wasn't the White House. That was a transition paper by Christina Romer and Jared Bernstein.

### Scientific Advocate (SA)
Claim: Okay. So--

### Conspiracy Advocate (CA)
Claim: But you have to remember--

### Scientific Advocate (SA)
Claim: --the head of the Council of Economic Advisors.

### Conspiracy Advocate (CA)
Claim: No. We weren't at the CEA at that point. But here is--

### Scientific Advocate (SA)
Claim: But the person who wound up there.

### Conspiracy Advocate (CA)
Claim: Okay. So here is the point about that number, though, right? There's always a counter factual. And as it turned out, they generated that estimate based on what they knew at the time which was in December 2008. As it turned out, the economy was a lot sicker than what they even knew.

### Scientific Advocate (SA)
Claim: Well, the unemployment rate was higher when they did the forecast.

### Conspiracy Advocate (CA)
Claim: It was. Exactly.

### Scientific Advocate (SA)
Claim: They didn't know it. So in other words, that's-- the Krugman is that no matter how much Keynesianism fails, you just should have spent more money. But that's what gets you eventually to becoming Greece.

### Scientific Advocate (SA)
Claim: There is no way to--

### Scientific Advocate (SA)
Claim: They keep spending more money.

### Moderator
Claim: Richard Epstein.

### Scientific Advocate (SA)
Claim: There's no way to falsify that proposition because if things go better, the stimulus did it. If things go worse, they would have been even worse still. So the question is, why do we believe when we've had a system of stagnation, when what you propose are short- term stimulus, which by definition will drop off. These are not going to have long-term benefits. You're eating your seed corn. Remember, tax revenues are down to an all- time low. Government expenditure is to a high. You now have 40 percent of the budget which is being financed by deficits. And the question is, how long is that going to be sustainable? There is an optimism in your position that somehow or other we can go from short-term stuff to long-term stuff, and yet there's no explanation as to how that transition is to be made--

### Moderator
Claim: And, Mark, Richard is also making the point that you really can't prove your claims for stimulus spending having worked, because as he says, you're saying, well, it would have been worse if they hadn't. So what--

### Conspiracy Advocate (CA)
Claim: I can’t counter-factual. I mean, we can't prove the counter-factual.

### Moderator
Claim: But where does that put you in terms of your argument? And winning that argument is a big thing

### Conspiracy Advocate (CA)
Claim: Well, I tried to make my case with respect to timing. I mean, that's more obvious, right? So February '09, the stimulus, the one that we're focused on, most people are focused on, passed. It was mid February '09, I believe. In February '09, we lost literally 750,000 jobs. We lost 750,000 jobs in January, we lost 750,000 job in March. The economy was shrinking rapidly. We were in a free fall. By June, the recession was over, not by my definition, by the National Bureau for Economic Research. By one year later, we were having job growth. So, okay, you could argue maybe the economy magically would have found its footing without help from the federal government. And I'm not saying stimulus was the only thing. There were many policy responses. There was the Federal Reserve. There were the TARP programs. There were lots of different things.

### Scientific Advocate (SA)
Claim: We know--

### Conspiracy Advocate (CA)
Claim: But I think it's fair to say, just given the chronology of events, that the stimulus had a very positive impact.

The economy would have performed measurably worse.

### Scientific Advocate (SA)
Claim: No, because at the same time, you have to--

### Moderator
Claim: Richard Epstein.

### Scientific Advocate (SA)
Claim: --predict that the stimulus also would fizzle. And that's exactly what it did. So in other words, there are two ways to look at this. What you do is you give people a boost of adrenaline, and they start running furiously. And then you've depleted their future resources, and there's nothing left to recoup. And the question here is long-term sustainability. As Cecilia said, if you're worried about labor markets, keep people out at the beginning, and it's going to affect them for the rest of their lives. And so what I don't understand is why don't you take up the proposals to deregulate the labor markets to increase the expansions from gains from trade?

### Conspiracy Advocate (CA)
Claim: Okay, can I respond?

### Moderator
Claim: Yeah. Mark Zandi.

### Conspiracy Advocate (CA)
Claim: I concur. I concur. I agree with you entirely that the stimulus efforts are not a source of long-term growth. They are not. They were never intended to be. They were to provide support to the economy in a time of crisis, when we were in free fall. But we also need policies, like the ones you're talking about. And we can discuss the merits of it, where we need to focus on regulatory policy. We need to focus on tax policy.

And most importantly of all, we need to focus on our long-term fiscal

### Moderator
Claim: So you're saying that jobs plan is the fire truck rushing from the fire house right now.

### Conspiracy Advocate (CA)
Claim: That's exactly what it is. If you had asked me to come to this debate six months ago when the economy was-- we were creating a couple hundred thousand jobs a month, I'd say, "John, I'm not coming."

### Scientific Advocate (SA)
Claim: Yeah, but can I ask you--

### Conspiracy Advocate (CA)
Claim: But I-- you know, and I'm not a hard-- Keynesian theory works at specific points in time. It's not an immutable fact. It doesn't work in every environment.

### Moderator
Claim: All right, Dan--

### Conspiracy Advocate (CA)
Claim: This is an environment where--

### Moderator
Claim: Wait, wait, Richard, let's-- Richard, let your opponent have the mic for a minute. Daniel, can you respond to the point that Mark just made, that sometimes at specific points in times it works. In your remarks earlier, you said pretty much I think that it never works.

### Scientific Advocate (SA)
Claim: Well, if you take a long-term view and not just cherry-pick an odd month here or there, and you go back in time, and you look at different countries where they have tried Keynesianism, it hasn't worked. And one of the most interesting periods is when we didn't try Keynesianism. The recession coming out of World War I was very steep. We didn't do anything. The economy recovered very rapidly. And probably even more interesting is what happened after World War II.

All the Keynesians thought we were going to have a giant recession. They wanted to plan massive public work spending and things like that. But Republicans control Congress. We had gridlock, we had stalemate. That turned out to be a wonderful thing. Because government didn't do anything and the economy relatively quickly digested millions and millions of people of being demobilized from war. In other words, the Hippocratic Oath about do no harm I think really applies, not to mention the fact that at some point we should consider why do we get recessions in the first place which in many cases is because of government policy mistakes, housing subsidies, easy money policy by the Fed, and things like that.

### Moderator
Claim: Right, but-- you're welcome to-- you don't have to suppress stuff. It sounded so timid and halfhearted.

I want the other side to respond. You just gave us an incident in which you said there was a recession without stimulus, and there was a terrific comeback, and that proves-- that establishes that at least in that instance, if we're going to talk about specific situations, that it-- you can get out of it without this kind of program, and I'd like this side to respond to that.

### Conspiracy Advocate (CA)
Claim: Well, you mean-- okay. You're going to drag me into the 1950s?

### Moderator
Claim: A little bit.

### Conspiracy Advocate (CA)
Claim: Okay, all right, okay, fair enough. I don't agree with that interpretation--

### Moderator
Claim: Well you know what, let Cecilia--

### Conspiracy Advocate (CA)
Claim: No. I actually don't want to speak to this specific point, but I--

### Moderator
Claim: All right, no, no-- I want-- I just to that point. Okay.

### Conspiracy Advocate (CA)
Claim: The 1950s were actually a pretty difficult period. Now, I'm not arguing that stimulus would've been the right – that big public works project would've been the right response to that, but, you know, the '50s weren't the greatest decade. It was--

### Scientific Advocate (SA)
Claim: I'm talking about the 1940s, though.

### Conspiracy Advocate (CA)
Claim: Well, you said after the recession-- I mean, after the war, World War II ended in 1945, and then that period-- then we had the Korean War which was a lot of fiscal stimulus, and then the 1950s was a period of really no growth. In fact, we had three recessions in the 1950s, and it was a very difficult time. So I don't know, maybe. That's stretching the limits of my historical experience, but-- and I know in our recent history, stimuluses work quite well, and in the most recent period, it's been highly successful.

### Moderator
Claim: Richard Epstein, what-- the president's plan also calls for putting investment into jobs that would rebuild highways, and bridges, and airports, and waterways, all of which, you know, it's clear we need, what's wrong with that?

### Scientific Advocate (SA)
Claim: There's nothing wrong with doing it so long as you do it correctly and so long as you do it systematically, and what's happened is, of course, with the rise of the transfer society, there's been a systematic neglect of infrastructure. And so clearly money has to go there, but if you look at this particular statute and the elaborate hoops that you have to go through, it is not a bill which is designed to promote infrastructure. It is a bill which is designed to make sure that the president's supporters, strong union members get jobs which will allow them to contribute to the campaign to win. The difference between this particular-- well, I'm glad to see that you all approve. But if you look at this program as against for example, the WPA, the administrative overlay that you have here is very, very much higher, and if you look at the way in which this relates to the employment jobs, the last stimulus program that was designed to deal with infrastructure was capital intensive and labeled weak, so that it had absolutely nothing to do, whatsoever, with jobs.

So my own view about this is the infrastructure question should be handled on its own merits. It should not be bundled in with the stimulus bill, and once you get that right, if you look at this particular bill with its new and it's four for the president, and three for the other side, that's the last thing that you want to have running this kind of program.

### Moderator
Claim: Cecilia Rouse, could you-- I know you want to get to another point and I'll come back to that, but can you respond to--

### Conspiracy Advocate (CA)
Claim: Yeah, you know, first of all-- look, I'm not a regulatory law expert, but my understanding is at least some of the provisions, such as the buy American provisions and the Davis Bacon, applied to infrastructure projects without this bill, meaning they've been in statute for decades since the 1930s as you mentioned--

### Scientific Advocate (SA)
Claim: And that's why we should get rid of it.

### Conspiracy Advocate (CA)
Claim: Well-- but that would mean that in order for this bill to get rid of them, that would be something new in this bill. And so we could argue about the merits or not, but really all this bill is doing is making it consistent with current law.

### Scientific Advocate (SA)
Claim: Yes, but the--

### Conspiracy Advocate (CA)
Claim: The agencies know how to administrate them, it doesn't add an additional administrative burden, but like I said, we could argue the merits of it, but I think that, that's not really the main purpose of the bill.

### Scientific Advocate (SA)
Claim: When you have failed policies, you try to change them. You're arguing for consistency, and I think that's fine, but if you're doing this as sort of an academic debate, the question is consistency, meaning getting rid of it across the board or keeping it across the board. And the question is-- that Dan put to you is how do we figure out, in theory, which way we want to go, and here's one simple device. If you don't know what you're doing, don't spend government money to do it. And these things are highly problematic, completely protectionist, and so, therefore, their elimination is something which is a matter of first principle should want, not only here, but in all the other bills. Davis Bacon is a public outrage, and there's no reason why we ought to extend it.

### Moderator
Claim: Cecilia, what was the question you wanted to bring up before?

### Conspiracy Advocate (CA)
Claim: The point that I was going to bring up earlier was more about how do we judge the value of stimulus and of the Recovery Act.

And I really just wanted to say, "Look, as Richard pointed out, the problem here is that we're trying to argue about a counterfactual, but I'm really sympathetic to--"

### Moderator
Claim: Can you translate, "We are trying to argue about a counterfactual--"

### Conspiracy Advocate (CA)
Claim: About a counterfactual meaning. Okay we passed the stimulus. And the way we will judge whether a policy is effective, we say what would have happened had we not done so. So we passed it. I don’t yet have a time machine. President doesn’t have a time machine, so we can’t go back and unpass it and see what would have happened had we not passed it. Therefore what economists have to do is try to say, try to create that counterfactual, what would have happened in its absence. Okay, I’m very sympathetic to the Keynesian multipliers, just sort of mindlessly applying the multiplier and saying what would happen.

### Moderator
Claim: Which means what?

### Conspiracy Advocate (CA)
Claim: Which means that economists have estimated okay, if we spend this much on infrastructure spending, then it’s going to chug through the economy and we’re going to get this much out and it’s going to create this much employment. And that’s their way of doing a counterfactual in a sense. I’m a micro-economist. My job is, I do a lot in education, it’s to do a lot of evaluation of programs, so that doesn’t make sense to me.

But what does make sense to me, is that there’re some economists that have not taken that route but have said instead, well can we compare the outgrowth of, or the employment growth in states where they’ve got more money, or in localities where they got more money than in others. Now, you might worry that okay, well but why did some get more money than others. Maybe you got more money because you were doing more poorly. They’ve tried to adjust for that in very creative and credible ways I might add. And this is not by economists that were working for the Obama administration or really had a dog in the hunt. And what they find is, it was actually fairly positive as well. So I’m fairly convinced that not just with one methodology do we find that the stimulus made a difference, but using a variety of them. Will we ever know for sure? No. I can see that because I think that’s what my business--we have to be humble about that.

### Moderator
Claim: It seems to be down on the other side, that you will never know for sure that it doesn’t work in the same way that they’re saying for sure that it does work.

### Scientific Advocate (SA)
Claim: Well that’s why I made my remarks during, about economists having a little bit of humility because we’re trying to predict things that are fundamentally-- we’ll never know the right answer. We’ll be debating, we’ll all be 80 years old up here having the same debate. But I do think looking at history, looking at periods where we tried Keynesianism versus periods when we didn’t, I think there is a pattern there that supports the negative proposition in this debate. Also, you look at countries around the world during this recent economic downturn. It’s been fairly global. Counties that were much less Keynesian in their approach, like Germany and Canada, seem to do better than countries that were more Keynesian in their approach like the United Kingdom and the United States. But again, there are 50 different policies out there and we’re trying to focus on just the narrow issue of fiscal policy. And so it really is a challenge. And I think all of us up here want America to be more profitable and have more jobs. So I think we all start from the same goal, but it really is difficult to figure out what’s going to work.

But I do look at Europe and the fact that they’ve gone down this path of deficit spending and it really does seem to eventually lead you into a cul-de-sac. And they’re in very serious trouble. And I worry about, I have three kids, I don’t want America to be like Greece in 15 or 20 years.

### Moderator
Claim: All right, I’m going to go to questions from the audience.

### Conspiracy Advocate (CA)
Claim: Can I just make one point?

### Moderator
Claim: Let me just do this, and then while the mic’s are moving, you can make your point, are you cool with that?

### Conspiracy Advocate (CA)
Claim: Sure.

### Moderator
Claim: So, what will happen is, if you raise your hand, I’ll find you and a microphone will be brought to you. We ask you to stand up and tell us your name and then ask a question that is focused, terse, on point, and really is a question. And no two parters or three parters. And also what doesn’t work is, I’d like to hear every member of the panel tell me their list of because it would just take up too much time. So those are the questions that I’ll have to throw out, so I just want you to think about that. And while you’re getting ready, Cecilia.

### Conspiracy Advocate (CA)
Claim: I just wanted to thank Dan for bringing up Germany and Canada. Because, one of the reasons why many people believe that, especially Germany, which had a larger, or Germany did not suffer the same employment losses that we did and many people have asked why.

And Canada as well, and both of them have work sharing programs, which were very active. So many people believe, and again if you ask German economists what exactly explains it, you’ll get many answers. But one of the reasons is because German employers were not obligated to try to adjust to the downturn by laying off all of their workers. That’s a lot of the reason why the president actually was looking to Germany and we’ve been trying to expand our own work sharing program for exactly this reason.

### Scientific Advocate (SA)
Claim: You could do work share programs voluntarily without government intervention.

### Moderator
Claim: Okay, let’s go to some questions from the audience. Sir, right there. Yeah, yes sir. Remember the rules.

### Moderator
Claim: Daniel.

### Moderator
Claim: Can you tell us who you are?

### Moderator
Claim: My name's Robin Yellen

### Moderator
Claim: Thank you.

### Moderator
Claim: You mentioned just now that, to me the whole argument is stimulus, no stimulus, this is basically what it sounds like to me.

Now, you’ve mentioned earlier that in, after the First World War, there was a recession, but America survived it, and everything came right. After the Second World War, the same thing. But after two world wars, countries were in situations where they had to build. They had to rebuild. They had to restructure everything. And that, to me, is what President Obama is proposing, is the restructuring, building again to get things going. Do you not think that's-- that was a stimulus all on its own?

### Moderator
Claim: Thank you. Dan Mitchell.

### Scientific Advocate (SA)
Claim: If I understand your question correctly, no, I don't. The reason I pointed out the recession of 1920, which, if we didn't have the Great Depression that would have been viewed as our Great Depression because the macroeconomic numbers were absolutely terrible then, worse than anything we had ever experienced.

And politicians didn't do anything, and the economy quickly recovered. We've always had downturns. And the question is how quickly do we get out of the downturn, what malinvestments and economic mistakes were made, and did the economy have the ability to quickly adjust? My concern about stimulus, if you define stimulus by government involvement and intervention, I think it hinders and retards the economy's ability to adjust and to sort of digest the mistake that caused resources to be misallocated. And I think what's happening today, not only under Obama, but also under Bush, we have gotten to a point where government is so big, so-- you know, just involved in all sectors of the economy, not just spending and taxes, but regulations and intervention, the types of thing Richard was talking about. We have moved to a lower growth level that we may be stuck with permanently in the same way that Europeans have had these, for decades now, slower rates of economic growth.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: And that's what's important to me.

### Moderator
Claim: Along the right side.

Oh, I thought I saw a bunch of hands go up there. Sorry. Right in the center here. Yes. If you look to your right, I think it'll come faster.

### Moderator
Claim: My name is Gene Epstein. A question for those who support the proposal. If there is indeed a crying need for jobs right now, and if there are indeed structural problems in the economy, partly caused by government right now, that could be altered, wouldn't you want to pick up on Richard Epstein's proposal right now to address those problems so that we can have job creation, such as the harassment of Boeing, the greater--

### Moderator
Claim: Okay.

### Moderator
Claim: --strength in

### Moderator
Claim: I'm going to stop you there because you--

### Moderator
Claim: --and so on.

### Moderator
Claim: You actually asked a perfect question, and so Mark Zandi, do you want to take that on?

### Conspiracy Advocate (CA)
Claim: Hi, Gene. How are you? Good to see you. I recognize the voice. Yeah. We haven't talked in a while. Please give me a call, Gene. Yeah.

### Moderator
Claim: You don't return my calls, Zandi.

### Conspiracy Advocate (CA)
Claim: Oh, yeah, yeah. I return everybody's call. I think I would do both. I think Cece said it nicely. You know, policy makers can walk and chew gum at the same time. And we need to do that. I do sympathize with a lot of the points that are being made with respect to regulatory policy and government intervention. I do think some of the policy steps have created uncertainty for businesses and for the banking system. And that's impaired the ability and willingness of businesses to step up and hire and for banks to lend. So I sympathize with that perspective. And I think we need to work on policies to address that. But that does not preclude the fact that we need to reduce some of the fiscal restraint that's dead ahead of us. If we don't make some policy steps here, taxes are going to rise on everybody. Unemployment insurance for many hard-pressed households are going to expire. And that's the prescription for a recession.

### Moderator
Claim: All right. Now speaking of right now, I want to mention our media partner in these debates is Slate. And in fact we're being live-streamed on Slate right now. So to everybody who's watching on Slate, welcome. And thanks for being with us. And we've asked you to submit questions. And there's a "right now" type of question, or its reverse from a Rhonda DuBose-- I'm sorry, from a Darin Clements in Williamsburg, Missouri, who asks, since the jobs bill is basically a temporary funding program, what are-- what are the prospects for this actually having an impact on long-term employment? Are we really talking about jobs, or are we only talking about getting money into the system for stimulus? Are people really going to be better employed in the long term as a result of this program?

### Conspiracy Advocate (CA)
Claim: Can I--

### Moderator
Claim: Cecilia Rouse.

### Conspiracy Advocate (CA)
Claim: Yeah, please.

### Conspiracy Advocate (CA)
Claim: Here's the-- this is what I worry about. I think our economy has made significant progress in righting the wrongs that got us into this mess. We've reduced debt. The businesses are in very good shape financially. Households have made a lot of progress. There's work to be done.

We've got foreclosure issues. The banking system is recapitalized. We've made significant progress. We're on the verge of a much better economy. But if we go back into recession, all that good, hard work is going to go down the tubes. And this is going to cost us enormously. We go into recession, revenues are going to fall because there's going to be fewer people employed. Government spending's going to rise because there's automatic spending increases in our budget. People become unemployed, they'll go get unemployment insurance. It's going to cost us more than this package, a lot more than this package. So it's not only about the very near term. It's about the long run. We can't take that chance. If we go into recession, it's going to undermine the fundamentals of our economy.

### Moderator
Claim: Mark, the question is a little bit different. It's about people actually having-- having jobs, having careers, if you will, being able to count on this going forward. And your opponents have argued that one of the problems they see with this, particularly something like-- like the tax holiday that's being offered to employers, it's a holiday, then it ends. And it's so short term that there's no real incentive for a company to hire workers.

### Conspiracy Advocate (CA)
Claim: But this is the point, John. This is-- let me try one more time. Listen, if we go back into recession, all those fundamentals of our economy are going to erode. All the good things, all the progress we've made is going is go away, and it's going to hurt the ability of businesses to hire and people to get jobs for the long run, for a long time to come. We are running the risk of going into a Japanese-like decade if we go back in a recession in six to nine months. We just can't allow that to happen.

### Scientific Advocate (SA)
Claim: But the difficulty--

### Moderator
Claim: Richard Epstein.

### Scientific Advocate (SA)
Claim: --with that is you can go into recession in 16 to 18 months. And you're talking about the short-term disasters. What about the midterm disasters? The advantage of the deregulation on the labor market side, which could be quite big, getting rid of industrial policies, no more cylinders and so forth, is that has an effect today. It has a long-term effect. It reduces the size of government burdens, and it increases the gains from potential hiring of labor.

So I'm going to ask you, Mark, just plain out, if you're in favor of this bill. Would you get rid of the Davis Bacon provision and the-- and the ARRA provision and the unemployment discrimination provision? I think the answer's got to be yes.

### Conspiracy Advocate (CA)
Claim: This gets to the question of political economy. We have no time left.

### Scientific Advocate (SA)
Claim: But you are--

### Conspiracy Advocate (CA)
Claim: Wait, wait, wait. If you want-- you asked me a question. I'm going to answer it. If we go down that path of trying to repeal these laws that have been in statute since 1930, we'll be debating this 10 years from now. And we're toast.

### Scientific Advocate (SA)
Claim: That's not the--

### Conspiracy Advocate (CA)
Claim: So in-- and here's the other point. And I'm going to ask you a question. Of $450 billion in the package--

### Scientific Advocate (SA)
Claim: What?

### Conspiracy Advocate (CA)
Claim: $450 billion package. How much of that is subject to the statutes that you are concerned about by America?

### Scientific Advocate (SA)
Claim: A fair--

### Conspiracy Advocate (CA)
Claim: No. How much, exactly?

### Scientific Advocate (SA)
Claim: I don't know the exact number.

### Conspiracy Advocate (CA)
Claim: $50 billion.

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: 50 out of the 450 billion.

### Scientific Advocate (SA)
Claim: Okay. Let's get--

### Conspiracy Advocate (CA)
Claim: Do not let the perfect be the enemy of the good.

### Scientific Advocate (SA)
Claim: Let's go back to the other point.

### Conspiracy Advocate (CA)
Claim: I read the statute as well.

### Scientific Advocate (SA)
Claim: No, no, no. That may be for the ARRA provisions.

You've got the Davis Bacon provisions. You've got the employment discrimination provisions. Which And so I'm not asking you to repeal the statutes as they exist everywhere else. I'm asking you not to put them in this particular bill. We're going piece by piece. Will you get rid of these pieces? You don't have to repeal anything. You don't have to have a long-term debate. All you have to say is, not with this one now. And all you've told me is you don't think it's going to do a lot of good. I'm going to tell you it's going to do at least some harm. And spending nothing on this is a lot better than trying to say, we have to tie the two things together. You know it's a political fix. I know it's a political fix.

### Moderator
Claim: Cecilia Rouse.

### Scientific Advocate (SA)
Claim: Just disentangle.

### Moderator
Claim: Cecilia Rouse.

### Conspiracy Advocate (CA)
Claim: I just wanted to say something about the anti-discrimination provision.

### Moderator
Claim: And take one minute--

### Conspiracy Advocate (CA)
Claim: To say what it is.

### Moderator
Claim: Not even a minute, 15 seconds to remind us what this is about.

### Conspiracy Advocate (CA)
Claim: I was going to do that. So many employers have actually been having their ads, when they post for employment, they say, "if you are unemployed, you need not apply." We'll not consider-- or you must currently have a job.

So many employers have this in statute-- or not in statute, but they have that in their ads. And as a result, many people are concerned that this is not particularly conducive to employment growth. So, I understand that employers are being inundated with applications and with applicants. There are over four unemployed workers for every job opening. And employers are having to find ways to really sift through. And I also understand that we want to let employers hire who they need to hire, who they think is the best match. But let's think of some of the negative spillovers of these ads to the rest of society, which is where I think we have a place for government intervention. First of all, imagine you're an unemployed worker. Especially imagine you're an unemployed worker who's been unemployed for at least six months. So you're actually bordering on discouraged. I actually know of a single mother who has been on welfare and is-- you know, marginally thinks she's not very attractive to employers. You understand that employers are putting out these ads, you don't even try to get a job.

And the worst thing we want to do right now is to discourage workers from even trying, from even applying for jobs. So one is I think it discourages workers from even trying to get hired. The second negative spillover is that in our economy one of the ways in which young people in particular have job growth early in their career is by quitting jobs. We have a lot of dynamism in our labor market, and one of the problems we have right now is actually because of the labor market, we have fewer quits than we normally would have, and as a result, workers are staying in jobs, they're not quitting, and so they're not going to be climbing up the career ladder. It's a negative spillover to the rest of society.

### Moderator
Claim: Okay, Cecilia, let me stop you there for some response--

### Scientific Advocate (SA)
Claim: You know, look, I mean--

### Moderator
Claim: Dan Miller, please-- Richard, let Dan Miller come in.

### Scientific Advocate (SA)
Claim: Mitchell, but that--

### Moderator
Claim: I'm--

### Scientific Advocate (SA)
Claim: --but I'll go by Miller.

### Moderator
Claim: No, there is no Miller here, Dan Mitchell.

### Scientific Advocate (SA)
Claim: I want to make a point that some of you should get ready to hiss about because I think this point makes perfect sense but some people don't like it, employers only hire people that they think is going to make them money.

And so, therefore, when we're considering what is going to increase-- oh, you're ruining my fun by clapping instead of hissing-- so when we're thinking about what in terms of like the boots on the ground type issue, what is going to convince companies to hire workers? If you create a new potential legal liability with new government rules about how you're writing your want ads and who you're allowed to hire and what you're allowed to say when you're interviewing, is that going to increase or decrease the likelihood that companies are going to want to hire new people? We want workers to be an asset to firms, not a liability, and this gets into of course all the other policies about what are the-- if we lower tax rates, will that help? If we reduce government regulation of red tape, will that help? I think markets, I think copying Hong Kong is a better idea than copying France. That in some sense is the summary of everything I would say this evening.

### Moderator
Claim: Dan Mitchell, slight-- slight variation on that question, is not having held a job for six to nine months to a year an accurate indicator of your ability to do a job well and to hold onto a job?

### Scientific Advocate (SA)
Claim: Well, there's no question we have a major problem with long term unemployment in this country. You know, five years ago I used to look at the OECD, Organization for Economic Cooperation and Development data, international bureaucracy based in Paris. They look at industrialized countries, all sorts of interesting data. I don't think we should be subsidizing them, but that's a whole separate issue. It used to be that you would look at the data on six months-plus unemployment, and Europe had the terrible numbers, and we had the great numbers. And now we've gone up to Europe and in some cases beyond, in terms of our long term unemployment. Now, interestingly, scholars like Paul Krugman and Larry Summers, at least when they're outside their New York Times writing and their democratic administration appointments, have written that unemployment insurance subsidizes unemployment. Now, as an economist--

### Moderator
Claim: Wait, wait, wait, wait, what is the answer to my question, though?

### Scientific Advocate (SA)
Claim: Well, no, I'm making-- the answer to your question is that we have a problem with long term unemployment, one of the reasons we have this problem is because the academic data shows that people get jobs much quicker when their unemployment insurance runs out, but we now are going on 99 weeks of unemployment insurance, and it sounds like you're an ogre, and, yes, so hiss me, hiss me, but when even Larry Summers and Paul Krugman and their academic writings are saying, "This increases unemployment," we need to figure out a better way of doing it then.

### Moderator
Claim: Mark-- Mark Zandi, Mark Zandi, please.

### Conspiracy Advocate (CA)
Claim: I just want to make one point about the jobs package. You know, there is money in the package, about 50 billion for unemployment insurance-- additional unemployment insurance, but in addition to that, there are a number of reforms to the unemployment insurance system that have been proposed. When Cece talked about the work share that's very popular in Germany and credited for German success, there's also a very popular program in Georgia called Georgia Works that helps send unemployed workers to get on the job training. These are things that have historically had bipartisan support. There's empirical evidence that they work reasonably well.

They do address some of the concerns Dan brought up. I-- they're reasonable concerns. You know, you can't dismiss them. So I think it's very important to realize that in the package there are efforts to address some of these things.

### Moderator
Claim: Richard Epstein.

### Scientific Advocate (SA)
Claim: Yes, I mean, to go back to the discrimination point and the part time point, on the discrimination issue, the evidence suggests that 150 firms have announced that they will not consider people. There are obviously going to be some more-- you're talking about millions of companies, and many people get first jobs, and it seems to me that you can-- if you got rid of minimum wage that's for teenagers it would do much more because then what you could do is to handle the problem of your decreased skills which everybody agrees takes place by making a compensating wage offer. And so freeing up markets will do much better than putting additional burdens on the overall economy in the way in which you're doing.

With respect to part time workers and so forth, the other thing to remember is we've had a long term policy in which there's constantly the notion that there are mandates for the kinds of benefits that you must supply to full time employees, which leads to this fine art where everybody now tries to become an independent contractor so you don't have to supply health insurance in a variety of other situations. One way to improve the employment situation is to drop the mandate. And put it in another term. What the government has now said, there will be no jobs with lavish benefits or you can have real jobs with less benefits. In my view, if you’re trying to increase the employment levels, what you have to do is to stop putting the ties. If you wish to hire X, you must provide for them Y. Because what happens is that’s often the decider and it kills the labor markets. What we did for many, many years is to think that labor markets were robust so you could burden them with all sorts of restrictions. When you get bad times, these restrictions are a lot more costly and what they do is they create a lot more devastation. You can improve this market tomorrow.

### Moderator
Claim: Richard, I have to stop you thee because I need to take a break. Do you know that when you speak, there’s only commas at the end of everything you say? was looking for the period to break in, and there were semicolons and dashes and commas.

### Scientific Advocate (SA)
Claim: One continuous argument.

### Moderator
Claim: Cecilia, I’m going to do a little break and then I’m going to come back to have you respond to it and then we’re going to go back to questions from the audience. Now I need some spontaneous applause from you, if you can do that. Thank you. Our motion is "Congress should pass Obama’s jobs plan piece by piece." We’re in the question and answer section of this Intelligence Squared U.S. Debate. I’m John Donvan of ABC News. We have four debaters, two teams of two, arguing this out and we are talking about the part of the jobs bill that would outlaw discrimination against workers who have been unemployed. And Cecilia Rouse is going to take up the point.

### Conspiracy Advocate (CA)
Claim: So I just wanted to come back to that for just a moment because this law, what this proposes is not saying that employers have to hire a specific person.

What it says is one, you can’t put it in the ad. Okay that is true, that is a restriction. You can’t put in the ad that you will not look at an unemployed person. And two it says that there can’t be a blanket policy, so there can’t be a memo. So what is-- let me say, it’s a largely symbolic gesture. The Obama administration caps damages at a thousand dollars if you actually put something in an ad. It caps it at $5,000 if you can come up with, if the EEOC, Equal Opportunity Employment Commission can actually come up with a memo documenting it. So it’s not, it’s meant to say look, we need for, at least, there not to be overt discrimination against those who are unemployed so we don’t discourage workers from trying to apply to a job.

### Moderator
Claim: Doesn’t the act though also, allow for a waiver that there would be a government official who would have the job of saying well in this case, we’re going to give you a pass. Which does sound to me like one more layer of somebody making decisions for who you can hire and who you can’t and the ultimately this sin that is considered un- committable, you can commit if the government guy says this time we’ll let you go.

### Conspiracy Advocate (CA)
Claim: Look, it really is meant to-- Governor Christie in my fair state, our Governor Christie passed a law that was similar. I’m not saying that makes it okay. But what I’m saying is that, it really is a problem if unemployed workers are discouraged from applying for jobs. And it's really just saying employers try to make--

### Moderator
Claim: Let’s move on to another topic. In the red top, thanks.

### Moderator
Claim: I’m Shaila Dewan from the New York Times and my question is for the no side. And the question is, what do you propose for the short term. I mean, if your proposals all seem to be about long term issues, if we’re going to do a tax cut, let’s make it permanent, that kind of thing. But what do you do for those unemployed people when their payments stop and they can’t get a job because there aren’t enough jobs?

### Moderator
Claim: What is your fire truck from the firehouse I think is the question. Richard Epstein.

### Scientific Advocate (SA)
Claim: The answer that I said is, the only way this thing will stop is through liberalization of markets.

If you repeal the restrictions against people getting jobs, employers will start to hire again. The difficulty with the umemployment situation is that the amount of revenues we have to spend now is probably two or three times the amount of taxes that we collect. And what happens is you will not be able to reverse that pattern so long as you think that stimulus at the grand level--

### Moderator
Claim: But Richard, the question is what is your short term solution?

### Scientific Advocate (SA)
Claim: My short term solution is deregulation. Get rid of mandates, get rid of minimum wages, get rid of the anti-discrimination proposals and so forth. Because what you laugh about, I think it’s fine for you to laugh, but I think you also ought to reflect upon the fact that if you don’t have gains from trade, you don’t get employment. And what’s happened is every time you put an implicit tax on the trade, what you do is release the opportunities for gains. This is the interesting feature about this, is the macroeconomic stuff everybody guesses about. The microeconomic stuff is perfectly clear.

### Moderator
Claim: Okay, your partner Dan Mitchell.

### Scientific Advocate (SA)
Claim: I would just like to make the point that good long-term policy also happens to be good short term policy. Now I come from a school of thought that says that if the economy has misallocation of labor and capital and a recession gets baked into the cake, there's not much you can do but sort of just grit your teeth and try to get through it as quickly as possible. But government sometimes extends and delays and an economic downturn by interfering. I think that's what happened in the 1930s with the Hoover-Roosevelt policies. I want to have a lower burden of government. I sort of throughout, as a throwaway line, I want to be Hong Kong rather than France. But there's actually a very serious point behind it. If you look at all these different measures of economic freedom, Hong Kong's always near the top. And France, among industrialized countries, is down lower. And I think that is one of the reasons why Hong Kong grows five to six percent a year on average, and France grows one to two percent a year. And if we want the unemployed to get jobs, we want a strong, tight labor market like we had during the Clinton years when government spending fell from 22 percent of GDP to 18 percent of GDP.

And what happened during the Reagan years when we also had more free market oriented policies. That, I think is the best answer.

### Moderator
Claim: Cecilia mentioned much earlier that Clinton raised taxes on the wealthy, and things got really good.

### Scientific Advocate (SA)
Claim: No. He-- Clinton raised taxes, but he also did GAT and NAFTA and welfare reform, reduced government spending by four percentage points of GDP. He deregulated telecommunications and agriculture. I mean, if I could take everything else of Clinton's policies and it meant that I had to take the 39.6 percent marginal tax rate, I'd do it. We had a lot more economic freedom under Clinton than we've had under Bush and Obama.

### Moderator
Claim: Okay. Let's take another question from the audience. Ma'am? Yep. If you can stand and tell us your name.

### Moderator
Claim: Hi. My name is Jane Doe, and I'm proud to say I'm not from-- I'm not from the New York Times. My question is for Cecilia. By your own admission, you said that the Clinton administration was able to-- to increase economic growth, but did so because of monetary policy.

And even President Clinton has said so on the Daily Show. My understanding is it's not the job of the president to intervene in monetary policy. He's admitted that he's gone into--

### Moderator
Claim: Can you come to a question?

### Moderator
Claim: Yes.

### Moderator
Claim: Thanks.

### Moderator
Claim: --in two seconds. Sorry. I paid a hundred thousand dollars to go to this university during the Clinton administration, so I'd like to make my point and have her answer the question.

### Moderator
Claim: Okay, but other people want to speak.

### Moderator
Claim: My question is about monetary policy and the Clinton administration. I'm a Democrat. His policies of fiscal policy did not increase economic growth. It was his monetary policy. Could you comment on it?

### Conspiracy Advocate (CA)
Claim: Well, look, I think that there was a lot of good fiscal policy that happened under the Clinton administration as well. So I'm not going to agree with your premise that it was only the monetary policy and that there was no fiscal policy under Clinton. Now, was it necessarily fiscal policy in terms of stimulus as Dan has mentioned?

There was a lot of other--there was NAFTA. There were other attempts to stimulate economic growth. But--

### Moderator
Claim: No, no. Can-- no, we-- seriously. And also I want to move on because we're not talking about the Clinton administration.

### Conspiracy Advocate (CA)
Claim: Exactly.

### Moderator
Claim: And-- and, sir, down in the front. I hope you have gotten your money's worth, though, in terms of a diploma and the whole thing.

### Moderator
Claim: Question for Dan Mitchell. You earlier mentioned Germany. Now, looking at this on the one side, it increases taxes for high income Americans but it reduces taxes for lower income Americans. Isn't that what-- what has been done in Germany?

### Moderator
Claim: That's how you do a question. Dan Mitchell.

### Scientific Advocate (SA)
Claim: As the Germans would say, "Der good. Der good." What I was focusing on in my comments on Germany is what happened to government spending as a share of GDP. Germany did not do a big Keynesian stimulus program.

It doesn't mean that I want to embrace German fiscal policy because the overall burden of government spending is higher, actually not that much higher than it is in the U.S. They're something like 44 percent of GDP. We're getting close to 40 now after the Bush-Obama spending binge. But Germany didn't do a Keynesian stimulus package of any magnitude close to the U.S. And I think that served them well, similar to what happened in Canada. Now, other things were involved. Canada never had a housing bubble. And of course that helped a lot. There's a ton of different economic policies that matter. But my point on Germany was just a simple one, that they didn't do the Keynesian policy--

### Moderator
Claim: Okay, Mark-- Mark Zandi would actually like a crack at that question.

### Conspiracy Advocate (CA)
Claim: Yeah, no, I was just going to make the point that the Germans provided just as much fiscal support to their economy as we did in the recession. The difference is that in Germany, they have automatic stable-- what's called automatic stabilizers in their budget. That means that there is more unemployment insurance. There is more welfare.

There are-- the tax code is such that you generate a lot more fiscal support. In the U.S., we have some automatic stabilizers, but they're not nearly as large as in Europe. And therefore, when we get into recessions, we rely more on what we're calling fiscal stimulus. That is temporary tax cuts and temporary spending.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: So in terms of the fiscal support to the economy, the Germans did exactly what we did in terms of the GDP.

### Moderator
Claim: It's hard for me to see folks that are not in the lights, so I have to keep calling down towards the front. If somebody is up there, wants to take a step down, I'll try to call on you. But for-- oh, actually, yeah, so I see you standing up. Can you come down into the-- walk toward the light. Just five or six steps, and then we can see you. Thanks.

### Conspiracy Advocate (CA)
Claim: He's a tough moderator, isn't he? I mean he--

### Moderator
Claim: No. No, no, no. And-- but I do need this to be terse and, you know--

### Moderator
Claim: This addressed to the opponents who--

### Moderator
Claim: Can you give-- sir, can you tell us your name, please?

### Moderator
Claim: Arthur Tannenbaum.

### Moderator
Claim: Thank you.

### Moderator
Claim: From where I sit, you've been talking mostly about structural issues. This motion is supposed to be directed towards cyclical issue. So my question for you is this: Isn't it a fact that we've had a number of recessions since World War II? There's been some form of stimulus that was the response to each of those recessions? And we have always come out of these recessions and started growing again.

### Moderator
Claim: Thank you. Dan Mitchell.

### Scientific Advocate (SA)
Claim: Well, the question is--

### Moderator
Claim: Okay, Richard, do you want to take it?

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: Okay. Richard Epstein.

### Scientific Advocate (SA)
Claim: Why not? I mean, I think it's a fair question. But, of course, we always came out of them. We're not coming out of them now. So the question is, what's the source of the difference? And the answer is that the degree of regulation that you have with respect to the economy now has deprived it of the kind of flexibility that allows it to respond. And it's in all the markets Thus far we've talked mainly about labor markets. And those are completely tied up by the kind of regulations that are put into place.

Every point and effort to try to revive the housing markets by giving mortgage support programs have turned out to be complete failures. The correct response on that may sound harsh, but in fact, it's the only way to get back the stability which is that banks decide to foreclose, tenants, current owners go, and the property re-circulates at lower rates so that you get the housing market start. You cannot keep a housing market going when essentially you allow people to remain in possession while the underlying value of the assets go down. So our position is really quite this. This stimulus program we don't think it does very much good and has already exhausted itself. But the mid-level regulations that you see in mortgages, in labor, in the banking industry, in the health care industry, all of these things are novel drags. These are discreet programs introduced by--

### Moderator
Claim: Okay. I'm going to-- I'm going to stop you because--

### Scientific Advocate (SA)
Claim: and those are the source of the difficulty.

### Moderator
Claim: I'm going to stop you because we have to let you make you that point. And, sir, in the blue shirt. Yep, if you can stand, please.

### Moderator
Claim: My name is Scott Stevens, and I have a question for Mr. Zandi.

You say that the $450 billion stimulus should keep us out of recession. Could you put a number on that? How many percent in growth do you think we'll get from the stimulus compared to the counter factual? Is that enough, do you think? And--

### Moderator
Claim: I think your answer to that is quoted on the White House blog, actually.

### Conspiracy Advocate (CA)
Claim: Yeah, it is.

### Moderator
Claim: I haven't had a chance to read that.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Yeah. Which, as I said earlier, means it's right, right?

### Moderator
Claim: So, Mark, why don't you take that question? Put--

### Conspiracy Advocate (CA)
Claim: Do you have something else you'd like to say?

### Moderator
Claim: I'd like to keep it as a one-part--

### Moderator
Claim: It's enough and--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: Okay.

### Moderator
Claim: Considering that it's being paid for too, that'd take a lot of the growth away from it.

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: And while you're at it--

### Moderator
Claim: No, no. That's good. Thank you.

### Conspiracy Advocate (CA)
Claim: Yes, and the Cardinals will win the World Series, yes. You like that, huh?

Well, if you do the arithmetic, the math, under current policy, if there is no change in policy, federal fiscal policy will shave 1.7 percentage points from GDP growth in 2012. State and local governments’ cuts will take the total fiscal drag-- this is the headwind to the economy-- to two percentage points of GDP. The Obama jobs package provides stimulus equal to two percent of GDP. So the intent is to neutralize the fiscal drag. Now, you know, if I were king for the day, I'd say, you know, we can digest some fiscal austerity. We don't have to go the whole Monty here, but we need to do something. We can't just-- we're not going to be able to digest two percentage points

### Moderator
Claim: All right. So you were very specific. I want to go to the other side and say that he was very specific.

### Scientific Advocate (SA)
Claim: Well, there's a certain beauty to being exact about something. But if you go back and look at what Mark was saying in 2010 and what Mark was saying in 2009 and what Mark was saying in 2008, and then you compare those things to reality, they're always different than what actually happened.

Now, of course, Mark will say, but other things happened in the economy.

### Conspiracy Advocate (CA)
Claim: No, no, I think I got it right.

### Scientific Advocate (SA)
Claim: But I think this gets at the problem that when you have a model that presupposes the results, Mark has a model and if you put in the certain amount of government spending, that will automatically spit out a certain number of GDP unemployment, probably depending on how it's spent. I'm sure there are some greater details to it. CPO has the same model, and these are the kinds of models that gave us the White House, I guess, Transition Team document that said if we squandered $850 billion, our unemployment rate would never go above eight percent, and it just didn't work. It doesn't matter how many decimals you have in your estimate. If the fundamental underlying premise is wrong, it doesn't work.

### Moderator
Claim: Okay, on that--

### Conspiracy Advocate (CA)
Claim: You're not giving me a chance to respond to that, John? What's that all about?

### Moderator
Claim: You're going to say you were right.

### Conspiracy Advocate (CA)
Claim: Okay, all right.

### Moderator
Claim: That's really why I'm not coming back. You're going to say you were right. And down the front?

### Moderator
Claim: Hi, my name is Giovan Jucovovic I would like to ask a question to the opponent to this. You seem to be presenting a broader and more long term vision for what you think with deregulation and whatnot. I would like to know how your plan of deregulation in general in the economy would benefit Americans besides the wealthiest of Americans and what specifically this would do by creating, like you say, abolishing minimum wage, creating low paying jobs, how would this really benefit Americans as a whole and not just the top one percent?

### Moderator
Claim: And how soon?

### Scientific Advocate (SA)
Claim: The top one percent--

### Moderator
Claim: Richard Epstein.

### Scientific Advocate (SA)
Claim: First of all, with respect to the top one percent, I think one ought to look at some of the numbers. The amount of revenue that has been collected from the top one percent in the last-- from 2007 to 2009 declined by about 30 percent, so that what you're trying to do is to hit a top figure and assume that nothing you could do to them can hurt them.

They have been hurt in terms of the money they have very much. Oh, laugh, if you may, but remember, 40 percent of that goes into your tax revenues. So every time, what you do is you cut the revenue at the top, you cut the revenue for the programs that are needed to support the stimulus. Dream on if you think that you can avoid that kind of situation. If you reduce income at the top, you reduce the amount of money available for transfer

### Moderator
Claim: Mark Zandi, do you--

### Scientific Advocate (SA)
Claim: At the bottom, what you have to do is if you reduce these things, you would get people on the job ladder. The moment they are on the job ladder because employers now find it in their interest, they will advance. When you look at-- for example if people could get in at minimum wage jobs, typically within six months or less they have managed to promote themselves to another type of job. This can take place immediately, but it will not take place by employers unless they have some confidence in the long term stability of the system.

Every major tax measure that we have now has a two-year timeframe on it so that the uncertainty dominates in my judgment the kinds of stimulus that you hope to get by the spending policy.

## Round 3

### Moderator
Claim: And that concludes round two of our debate. And here's where we are-- we're about to hear a brief closing statement from each debater in turn, they will be two minutes each, uninterrupted. And remember how you voted before the debate, because this is their last chance to try to persuade you to vote for their arguments at the end, and the team that has changed the most minds will be declared our winner. So on to round three. These are closing statements from each debater in turn, two minutes each. Our motion is this, "Congress should pass Obama's jobs plan piece by piece," and here to summarize his position against this motion, Daniel Mitchell, senior fellow at the Cato Institute.

### Scientific Advocate (SA)
Claim: Congress should not pass the president's job proposal either in its entirety or piece by piece because it represents a fundamentally misguided view of the economy, that you can make yourself richer by taking money out of one pocket and putting it in the other.

I think the historical evidence, the cross-country evidence does not support the Keynesian theory. But more importantly, I think good long run policy is good short run policy. I want to try to get back the labor market conditions we had under Reagan and Clinton, and the one common characteristic of what we had under both Reagan and Clinton was that economic freedom in America broadly defined-- so we're not just talking the fiscal policy, but more than just fiscal policy affects the economy-- economic freedom in America increased during the Reagan years and the Clinton years, by contrast, economic freedom declined during the Bush years, and that decline has continued during the Obama years. And if we accept-- even if we don't like it, if we accept the notion that jobs are only created when employers think that it's going to be profitable to create those jobs, we need to figure out what type of economic conditions will lead to that greater prosperity.

And, again, I come back to what originally was a joke line, but I really want to make a premise, why is it that an economy like Hong Kong manages to grow so fast over such a long period of time, it takes in enormous amounts of immigrants, people rise from poverty to prosperity relatively quickly. That’s the kind of economy I want to mimic. Not because I care about the top one percent. The top one percent have never really, I don’t know, maybe some of them gave to the Cato Institute, so if you’re out there listening, I love you. But I care a lot more about the people at the bottom than at the top. If there’s a recession, the Donald Trumps and Warren Buffetts and Bill Gates of the world never have to worry about how their household budget is going to be balanced. That’s why I want to copy Hong Kong. In France, the rich people have figured how to work it; I don’t care about them. Thank you.

### Moderator
Claim: Thank you Daniel Mitchell. Our motion, "Congress should pass Obama’s job plan piece by piece" and here to summarize his position for the motion, Mark Zandi, chief economist at Moody’s Analytics.

### Conspiracy Advocate (CA)
Claim: Thank you John. I want to thank you for the opportunity again. And I commend the other group for articulating their views so thoughtfully.

I sympathize with a lot of what’s being said by the other group. I do think that the economy is encumbered by regulatory, legal uncertainty. We have made some major changes to our economy, to our health care system, to our banking system. And these are difficult things for businesses and individuals to adjust to. And I do think we need to work hard in reducing that regulatory and legal uncertainty. And we do need to take steps to address our long-term problems. Again I think it’s vital that we work to achieve fiscal sustainability, to get the long term deficits down so that our nation doesn’t go the way of Europe or France. I think tax reform is absolutely vital.

I think it’s key to bring down the tax expenditures, the tax credits and deductions in the tax code, make the tax code much fairer, simpler. I think our economy would be better for it. And I actually am quite optimistic about our economic prospects. I think, as I said earlier, we have come a long way. Our economy has righted a lot of the wrongs that got us to this point. We’re really very close. We just cannot go back into recession in the near future. That would be damaging, the collective psyche is on edge. You’re nervous; I’m nervous; we’re all very frazzled. Recession will just tip us over. The Obama jobs package, even if it’s passed in small parts, would go a long way to ensuring that we don’t go back into recession and that bright economic future actually will be upon us I think sooner than we realize. Thank you.

### Moderator
Claim: Thank you Mark Zandi. Our motion, "Congress should pass Obama’s jobs plan piece by piece," and here to summarize his position against this motion, Richard Epstein, professor at the New York University School of Law.

### Scientific Advocate (SA)
Claim: Yes, I think what happens is everybody agrees on the importance of trying to get both short term and long term proposals. My view about this is, if we do not make long-term structural returns and make them soon, the stimulus program will not succeed. The most that you could get out of this is six or nine months. After that time, the long term structures will remain and you will fall into a recession that might be deeper than one that you take today. So what is it that you have to do? You have to try to figure out why it is that in the last 10 years it has been a lost decade in terms of economic growth. And the answer is not that the stimulus program does or does not work. It is because all on mid-level institutions are inferior to what they were at an earlier time. The labor markets have become much more regulated. The banking industry has become much more concentrated at this particular point. Dodd-Frank will introduce all sorts of layers of confusion.

The health care bill is a huge drain with respect to potential resources because the unemployment uncertainty is associated with the mandate and everything else are in fact going to wield a very heavy load on this system. The question is when will this load be bourn? The answer is it will be bourn today. There is no way in effect that you can change the situation in the future if in fact you do not change the system correctly today. Employers and everybody else in this economy has rational expectations which don’t only look at the short periods, they look at the long periods. So if we start talking about stimulus programs which have never worked, what happens is we’re just going to add another layer of uncertainty on top of the layer of regulation. And we’ll be worse off than we are before. The question then is, will liberalization work? And the answer is if you engage in a systematic program of retrenchment and repeal, these things in fact will take effect immediately and you will start to see some kind of reversal. We do have a serious problem.

We must do something. But if we think of the economy as being somebody with a diabetic shock, we ought not to add fix it, add to it some sugar.

### Moderator
Claim: Thank you Richard Epstein. The motion "Congress should pass Obama's jobs plan piece by piece," and here to summarize her position in support of the motion, Cecilia Rouse, professor of economics at Princeton University.

### Conspiracy Advocate (CA)
Claim: So I do believe that Congress should pass the Obama jobs plan. I too am concerned about the impact of employer mandates on labor markets and believe we should be very judicious in looking at regulation. I think we should only put into place regulations where the benefits clearly exceed the costs. I think the evidence isn't really there that minimum wage is such an egregious regulation. But that would be another debate. However, if the Clinton administration in the Clinton years were such an example of economic freedom, in 2001, we had a recession where we had a jobless recovery. So what happened? Did the regulatory environment magically change with an election?

I think that what we have is-- what that tells us is that this regulatory environment is not going to address the cyclical changes. And I think we have a cyclical challenge right now. And so I think it's appropriate for the Congress to step in. Now, as I said from the outset, I think one of the most important pieces of this is one that's a tax relief for employees. I think continuing the federally funded unemployment insurance benefit is very important as well.

I just want to add to that that Congress has always extended these benefits during times of recession. And the reason is clear. It's pennywise and pound foolish not to do so. If workers and their families aren't supported, they're going to end up on other government programs. And so Congress-- even Reagan did not stop supporting unemployment insurance benefits until employment had fallen below 7.5 percent. So I think Congress typically steps in during times of recession. I think there are good economic reasons for it to do so. And I think this is one of those times. More importantly, you know, as Mark has said very carefully, we really do risk falling into another recession which will be just devastating for all of us.

Might doing nothing make a difference? It might work. But I've got to tell you, I'm not a gambling girl, and I'm just not willing to make that gamble for 42 million workers who are out of work and the millions more who are really suffering economically. Thank you.

### Moderator
Claim: Thank you, Cecilia Rouse. And that concludes our closing statements. And that means it's time to find out which side you feel argued best. We want to go again-- we want to ask you again to go to the keyboards at your seat and to register your vote for the team that you feel presented the best argument on this motion: "Congress should pass Obama's jobs plan piece by piece." If you feel that the side arguing for the motion has argued best, push number one. If you feel that the side arguing against the motion has argued best, push number two. And if you remain or became undecided, push number three. And we'll have the results in about one minute and 17 seconds, actually.

Come up quite shortly. Yes, yeah. So while that's happening, I just want to-- I just want to say thanks to this panel for-- for the level of debate they brought to this and-- for the spirit and the style and the humor and the intelligence. And to everybody who got up and asked a question, the questions were pretty good tonight, so I want to thank you for having the nerve to stand up and ask the questions. We really do appreciate it. And to everybody who is out there watching on Slate, thank you to as well. So our final debate of the season will be on Tuesday, November 15th. And the motion that we're debating is this: "The world would be better off without religion." Arguing for the motion-- arguing for the motion, the great, great grandson of Charles Darwin whose name tragically is not Darwin because that would be-- his name is Matthew Chapman. He is an author, and he is a filmmaker, and he's cofounder of Science Debate.

His debating partner is A.C. Grayling. He is a renowned philosopher, humanist and an atheist who recently authored a book called "The Good Book: A Secular Bible,” a manifesto for rational thought. On the other side of that debate, we're going to have Dinesh D’Souza who is the president of the King's College and author of "What's so Great About Christianity?" And Rabbi David Wolpe who was named one of the most influential rabbis in America by Newsweek. We'll be announcing our spring topics next month. Is that right, Dana? Next month we're going to have a list of our topics for the spring season, and we'll have five more. And we hope to see all of you there. You can get a discount if you go to our Facebook page and join. And you can follow us as well on Twitter. Also, as I said before, and thank you for all of your-- your audibleness. These-- yeah, you were great. These debates are being carried on hundreds of NPR stations across the nation, and it's glad-- it's good to have you all breathing and speaking and voicing your opinions. So thank you.

It really gives a sense of life to it. You're also on television here in New York City on WNET13 and WLIW and NJTV. All right, now, it's all in. We've had two teams arguing out this motion: "Congress should pass Obama's jobs plan piece by piece." You voted twice, once before the debate to tell us where you stood on it, and again at the end of the debate after listening to these teams try to persuade you to their point of view. We've asked you to choose which team argued the best. Here is the result. Before the debate on this motion, "Congress should pass Obama's jobs plan piece by piece," 45 percent were for the motion, 16 percent against, and 39 percent undecided. After the debate, 69 percent are for the motion. That is up 24 percent. 22 percent are against, that's up only six percent. 30 percent-- nine percent are undecided. That's down 30 percent. The team arguing for the motion that Congress should pass Obama's jobs plan piece by piece carries the debate. Our congratulations to them. Thank you for me, John Donvan. And we'll see you next time.
