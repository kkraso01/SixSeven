# Debate Transcript

Topic: Abolish the Death Penalty
Motion: Abolish the Death Penalty

Debate ID: 041515%20Death%20Penalty


## Round 1

### Moderator
Claim: So, I would at this point like to start things off by please welcoming to the stage the chairman of Intelligence Squared U.S., Mr. Robert Rosenkranz.

Hi, Bob. So, Bob, what strikes me about this debate Abolish the Death Penalty, a lot of our debates are very topical. They're about something that's in the news right now, something-- an election season, something, foreign war. In this case Abolish the Death Penalty is sort of one of these timeless eternal topics.

### Moderator
Claim: Well, it may be timeless, but it seems pretty timely right now in the wake of the Boston Marathon conviction. That's the kind of crime and the kind of heinous crime and with multiple victims and hundreds of collateral damage to all kinds of innocent people that make people think that the death penalty might well be appropriate.

### Moderator
Claim: And this is one of these topics that we can slice into different dimensions, one of them being sort of the policy dimension, the practical side of the death penalty.

### Moderator
Claim: Well, one of the practical issues with the death penalty is simply that it is just so expensive to actually administer. It's much more expensive than a life imprisonment, because the legal process around the death penalty is just so elaborate. So, you do have-- it's actually a very costly process to actually implement and the question I guess from a policy standpoint is are those costs offset by some benefits, and one of the potential benefits is the idea of deterrence, that the death penalty does deter crime, but that again is very much subject to debate.

### Moderator
Claim: And then there is of course a moral dimension. I think it's very visceral for people.

### Moderator
Claim: Well, there is. I mean, I think there is a sense particularly in the case of the most heinous and gruesome and cruel kinds of crimes that the death penalty is the kind of retribution that a society should seek to express its revulsion at some of these kinds of acts.

On the other hand, there's a moral feeling that to take a life knowingly and premeditated and very deliberately is simply the wrong thing to be doing.

### Moderator
Claim: And where our debates get interesting is when the moral conflict and the practical conflict kind of cross. We have that in this one.

### Moderator
Claim: Yeah, I would certainly say we do. I mean, the aspects of it like the potential for error is obviously one, which is-- but the practical reason and a moral reason to question the death penalty, and the other of course is the racial profile of people on death row and whether that reflects something systemically wrong with the system besides its occasional propensity for error.

### Moderator
Claim: Well, as you say, it's very complex and as you point out there is sort of no time when this is not a hot topic. So, let's bring our debaters to the stage and get started and let's thank Robert Rosenkranz.

### Moderator
Claim: Great. Thank you.

### Moderator
Claim: So, this is one of those times when I want to ask you again spontaneously to applaud for launching the podcast and the radio sound, but let's do it by thanking Bob Rosenkranz one more time.

Hello. I'm John Donvan. This is Intelligence Squared U.S. And “an eye for an eye”--That is the reason that Americans cited most often in a credible poll for their support of the death penalty and it seems that six out of 10 of us do support the death penalty, although when “an eye for an eye” was quoted in the New Testament the teaching was that sometimes retribution is not really all that it seems to be cracked up to be, and that's a point that 18 states seem to have agreed with by abolishing the death penalty and the District of Columbia. Another 15 have suspended it and that leaves 17 states and the question is should they follow suit or should they stand by tradition and by their sense of what they see as justice. Well, that sounds like the makings of a debate. So, let's have it. Yes or no to this statement: Abolish the Death Penalty, a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufman Music Center. We have four superbly qualified debaters on stage who will be arguing, two against two, for and against this motion: Abolish the Death Penalty.

As always, our debate will go in three rounds. And then our live audience here in New York City votes to pick the winner. And only one side wins. The motion, again, "Abolish the Death Penalty." Let's meet the team arguing for the motion, the team that wants to abolish. Please welcome Diann Rust-Tierney.

Diann, you are the executive director of the National Coalition to Abolish the Death Penalty. You have spent many years fighting this-- fighting the death penalty, back when you were working for the ACLU, back to the '90s. And as we pointed out, a majority of Americans still do support the death penalty, but the trend is definitely downward. So, what has changed over time?

### Conspiracy Advocate (CA)
Claim: Well, I'd like to think I've gotten better at my job and have done a better job of getting the public to focus on the right questions.

### Moderator
Claim: And we'll be going to some of those questions tonight. Ladies and gentlemen, please welcome, again, Diann Rust-Tierney.

And Diann tell us who your partner is?

### Conspiracy Advocate (CA)
Claim: My debate partner is the wonderful and absolutely brilliant Barry Scheck.

### Moderator
Claim: Ladies and gentlemen, Barry Scheck.

Barry, you are a professor at the Cardozo School of Law, co-director of the Innocence Project. Well-known to television viewers by playing yourself on "The Good Wife." You founded the Innocence Project back in 1992. How many post-conviction DNA exonerations have there been since the project began?

### Conspiracy Advocate (CA)
Claim: There are 362 post-conviction DNA exonerations. 19 people off death row. Many, many people that were convicted of murder in non-capital eligible states.

### Moderator
Claim: All right. And I'm assuming we're going to be hearing more about that in your argument.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Let's again welcome the team arguing for the motion: Abolish the Death Penalty.

And we have two debaters arguing against the motion.

Again, to be clear, they are against abolishing the death penalty. So, you figured out the double negative there. It's pretty clear. First, let's please welcome Robert Blecker.

Robert, you're a professor at New York Law School. You spent 12 years talking to prisoners inside Lorton Central Prison. Another decade visiting death row prisoners. You put all this together in a book called "The Death of Punishment." And in it, you show that although you are a leading advocate of the death penalty, you have a surprising amount of empathy for some of the prisoners you met. I'm wondering, does that-- did that experience, in any way, soften your commitment to the death penalty?

### Scientific Advocate (SA)
Claim: Well, first of all, I spent a lot more time watching and listening than talking. But Daryl Holton, who murdered his four children, taught me a lot and made me laugh. And I do confess sometimes to missing him. And David “Itchy” Brooks, a brilliant and bold-- once saved my life inside the Lorton Prison.

So, it's tough to want him dead. But for the worst, of the worst, of the worst-- not at all.

### Moderator
Claim: All right. And who is your partner?

### Scientific Advocate (SA)
Claim: My partner is the incredibly erudite and always sober Kent Scheidegger.

### Moderator
Claim: Please welcome Kent Scheidegger.

Kent, since 1986 you've been Legal Director of the Criminal Justice Legal Foundation. In this field, you are a leading voice. You are probably the leading public advocate in support of the death penalty. We know that because your writings show up constantly in Supreme Court references. You're quoted constantly in the newspaper. Part of it is that there aren't a lot of other people wanting to take your side, but you said that in a recent profile-- in a recent profile, you said that you served in the Air Force six years and that your passion for military service and your support for the death penalty both come from the same core beliefs. What are those core beliefs?

### Scientific Advocate (SA)
Claim: Well, my basic belief is that in a civilized society, the most important function of government is to protect people from violent assault. And that is true-- whether the source of the threat be foreign or domestic.

### Moderator
Claim: Okay. Thank you. Kurt-- Kent Scheidegger. And again, this is the team arguing against the motion, Abolish the Death Penalty.

And this is a debate. It's a contest. It's a battle of ideas and argumentation. And one side will win, and one side will lose. And that decision will be made by our live audience here in New York by your vote, both before and after hearing the debate. And the team whose numbers have changed the most between those two votes in percentage point terms will be declared our winner. So let's register your first vote. If you can go to those keypads at your seat, motion is very straightforward, "Abolish the Death Penalty." If you believe in this motion, support this motion, push number one, if you are dead set against this motion, push number two, and if you are undecided, push number three.

You can ignore the other keys. They are not live. And if you push the wrong key, just correct yourself. The system will lock in your last vote. Okay, looks like everybody's completed. So, again, I'll just sort of remind you one more time, right after the closing round, takes, again, about 15 seconds to do the vote the same way, and then we have the results in about a minute and a half after that to conclude the debate. So on to round one, our motion is this, "Abolish the Death Penalty." Round one, opening statements by each debater in turn. They will be seven minutes each. And here to speak first in support of the motion, "Abolish the Death Penalty," Barry Scheck. He is cofounder and co-director of the Innocence Project and professor at the Cardozo School of Law.

### Conspiracy Advocate (CA)
Claim: Reasonable people can disagree about whether capital punishment is a morally appropriate sanction for the most heinous of crimes.

And our opponents place tremendous value on retribution by execution. They think that is an incredible benefit. But I think when you reason about this as a public policy issue, and that's why we're here, and you look at the costs and benefits of having a death penalty versus life without parole at a maximum security prison, you're going to reach the same conclusion that six states have reached in the last six years: the death penalty doesn't work. It should be repealed and abolished. What are the costs? The death penalty creates an undeniable and unacceptable risk of executing innocents. The death penalty does not deter. The National Academy of Sciences recently reviewed all of the studies and found no evidence of a deterrent effect. And common sense tells you that, because the states that execute the most, like Texas and Virginia, do not have lower homicide rates, do not have lower crime rates, than the states that don't have the death penalty.

The death penalty is administered arbitrarily. It depends on the quality of your representation. And who has money and your race often turns on-- often determines what kind of representation you get. The death penalty also depends on where you're tried. It's incredibly arbitrary in this sense. It's only 2 percent of counties in the United States that are responsible for 60-- 56 percent of the executions-- of the death sentences and 52 percent of executions. There are race effects that Diann is going to talk to you about at some length, particularly having to do with the race of the victim. And the death penalty, as Diann will also address at greater length, does nothing to increase or insure public safety. So, this undermines the fair administration of justice. Take California.

We know that in California there are over 700 people on death row. And they haven't had an execution for years. And they have hundreds of people who have been convicted and sentenced to death that don't have lawyers in a post-conviction setting, and they're closing down civil courts. And the dockets are clogged, and this led to a judge recently in California saying, "It is the gridlock, it is the-- in California that makes the death penalty unconstitutional, because it is freakish and it is arbitrarily applied." You are more likely to die of natural causes after 24 years in prison in California than you are to be executed. Now, there should not be any disagreement about one moral and one factual question, and that is the unacceptable risk of executing innocent people. Bob talked about the Boston Marathon bomber trial, but let's not forget that in April-- early April Anthony Hinton walked off death row in Alabama. Bryan Stevenson-- he had been on death row for 30 years.

He was convicted based on bogus ballistics evidence. And the prosecution held back exculpatory evidence in that case for nine years. And he had an ineffective lawyer as the Supreme Court itself ruled. Just this week a young man in New Orleans, Mr. Stewart-- Kia Stewart, was exonerated with the help of the prosecutors and the Innocence Project in New Orleans. He was tried for murder in New Orleans, represented by law students at Tulane Law School and a supervisor that had no experience in murder cases. This kind of stuff goes on all across the country, and we've got to face up to it. What is the error rate of convicting people that are innocent? Sam Gross at the University of Michigan Law School submitted a paper in the National Academy of Science Proceedings and showed that when you look at capital convictions, you can demonstrate on innocence grounds a 4.1 percent error rate, 4.1 percent error rate.

I mean, would you accept that in flying airplanes? I mean, really. Now, there's no doubt innocents have also been executed. I hope you're all familiar with the work of our colleague, Jim Liebman, from Columbia Law School, documenting the wrongful execution of Carlos DeLuna. And I certainly hope you're aware of the case of Cameron Todd Willingham, who was executed in Texas based on what now is acknowledged by the state itself to be bogus arson evidence for an arson murder, killing his three children. And we now have evidence that there was a jailhouse snitch that committed perjury by his own admission, and you can demonstrate it in the case. And now the Texas Bar has brought the prosecutor in that case up on charges, because he knew about a deal with the jailhouse snitch that he never revealed. Now, that is unbelievable. You cannot anymore kid yourself on the fact that innocents have been executed due to junk forensic science, prosecutorial misconduct, law enforcement misconduct, ineffective lawyers.

This system is incapable not just of determining who's guilty or innocence in the final analysis when charging them with the ultimate punishment but reliably figuring out who should die and who shouldn't. We shouldn't be tinkering with the machinery of death, and we see prosecutors telling us this every day. Mark Earley, the attorney general of Virginia, who presided and brought about 36 executions, has just come to the position as he left office that "The death penalty is based on a false utopian premise. That false premise is that we have had and do have and will have 100 percent accuracy in death penalty convictions and executions. Who should live and who should die? I can no longer support the imposition of a penalty so final in nature yet so fraught with failures." Go look at the statement of Marty Stroud, a prosecutor in a Caddo Parish, Shreveport, Louisiana-- Glenn Ford, 30 years on death row, innocent.

Marty prosecuted him. He recently gave this statement, he said it'll be his only one, where he said, "How did this happen? I knew that the defense lawyers were-- had never tried a capital case, and I wanted to win. We all wanted to win. I was 32 years old, and I wanted to win, and I didn't see it." So, I leave this to you: our friend, George Will. All right, George Will has said that "Conservatives-- capital punishment is a government program, so skepticism is in order."

### Moderator
Claim: Thank you, Barry Scheck. And our motion is, "Abolish the Death Penalty." And here to make his argument against the motion, please welcome to the lectern Kent Scheidegger. He is the legal director of the Criminal Justice Legal Foundation. Ladies and gentlemen, Kent Scheidegger.

### Scientific Advocate (SA)
Claim: Thank you. Why do we have the death penalty?

There are three reasons. The first reason is that for some crimes, such as the marathon bombing, any lesser penalty is simply a travesty of justice. And Professor Blecker will talk about that in his turn. The second reason is incapacitation. An executed killer never kills again. We cannot say that for certain with a killer sentenced to life without parole. In the cases that I personally have worked on, there are half a dozen cases of murder of people who have been killed by killers who were sentenced to life in prison already, before they committed the murder. One contracted out the murder of the witnesses to his first murder. Another one killed multiple people within prison. Another one escaped from prison and killed people after he left. There-- life without parole is not a zero-risk option. If we choose life in prison for killers, we do risk killing innocent people. Then there is deterrence. It is a basic principle of human behavior that incentives matter, that if you raise the cost of doing anything, fewer people will choose to do that thing.

Logically, then, you would think that an effective enforced death penalty would save innocent lives for deterrence. And we should demand a very convincing evidence by anyone who claims to the contrary. There are empirical studies, but it's not a hard science. The one thing all experts agree on is that the case has not been proved either way, for or against deterrence. It certainly is not true that deterrence has been disproved, and the report Mr. Scheck referred to did not say that there is no evidence in favor of deterrence. There are a number of empirical studies showing a deterrent effect estimating between five and 18 innocent lives saved per execution. These studies have their critics to be sure. The authors have responded to the critics and shown that the results still hold, even considering the criticism. The bottom line is we should not get rid of a penalty that is independently justified by just by justice if doing so risks taking innocent lives through lost deterrents.

The arguments against the death penalty are like a game of whack-a-mole. Every time we refute one of the arguments they just come up with another one. The old claim from the old days was that the death penalty was discriminatorily enforced against African American defendants. That claim was uniformly refuted by study after study, including the defendant's own. Then they came to a backup claim that the death penalty was discriminatorily not imposed on murderers who kill black victims. That-- the evidence there is more mixed. A lot of times somebody with an ax to grind will come out with a study claiming that and a reanalysis of the data taking into account all the relevant variables, will show that that effect just disappears into the statistical grass. Then they fall back to the claim of excessive cost versus life without parole. The problem there is that the studies claiming that are seriously flawed. They often fail to consider the very high costs of medical care for a person all the way to the end of his life if he's truly going to be held in prison to natural death.

They typically include unnecessary costs as costs of the death penalty. In California the study that was cited to claim the excessive cost of the death penalty counted as the number one cost of the death penalty the cost of keeping a person on death row for 26 years of appeals. Well, three fourths of that cost is unnecessary. In a capital case where there is no doubt who did it, which is most capital cases, you can get it done in six years, which Virginia did with the D.C. sniper. Risk of executing the innocent is much less than the other side says and it's less today than it was say 15 years ago with all the greater scrutiny that we have on forensic science. In most capital cases, again, there's no doubt whatever who did it. The claim you may have heard of 152 innocent people, that list has been debunked. People on that list have been proved conclusively guilty by DNA. The same DNA advances that they prove that case guilty were also used for post- mortem testing of people who had been already convicted and already executed.

The other side thought they were going to hit the Holy Grail and they were going to find conclusive evidence through this post-mortem testing of an innocent person executed. In fact, none of them panned out and their poster boy was found conclusively guilty. Now we have the Willingham case. I don't have time for details, but bear in mind there are two sides to that story. There is material in that case. There is evidence in that case you did not read in New Yorker magazine and that will be coming out later I'm sure. There are a handful of cases, though, of people who were really innocent and who were really sentenced to death. But ask yourself where would those people be if they had been sentenced to life without parole instead? In most cases they would still be in prison and they would never get out, because an inmate who is sentenced to death gets a government paid lawyer for the second review of his case and the third review of his case and that is where this evidence often comes out.

Someone sentenced to life in prison, he may have longer time to prove innocence, but he doesn't have the resources, and so in most cases nobody's going to care about his case. The risk of an innocent person dying in prison and never getting out is greater if he's sentenced to life in prison than it is if he's sentenced to death. So the death penalty is an important part of our system. It's important for justice. Reforms are needed to make the process focus more on actual guilt and innocence and less on other issues. And in the process we can make it more sure, more swift, less costly, and more just. So, let's mend it, not end it, and I ask you to vote no on this motion. Thank you.

### Moderator
Claim: Thank you, Kent Scheidegger.

And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two against two, arguing for and against this motion: Abolish the Death Penalty.

You have heard from the first two debaters and now on to the third. Let's please welcome to the lectern Diann Rust-Tierney. She is the executive director of the National Coalition to Abolish The Death Penalty.

### Conspiracy Advocate (CA)
Claim: The death penalty should be abolished because it fails to enhance public safety. We all want a criminal justice system that is effective and secure, one that creates more safety and less violence, but that is not what the death penalty is doing. In states where the death penalty is used, as you've already heard, we have a higher homicide rate. In the South, for example, which has the highest number of executions-- there's the highest homicide rate. In the Northeast, by contrast, which has the lowest execution rate, we have a lower murder rate. These differences tell us that we have to take a closer look at what works and what doesn't, and take a commonsense approach to public safety.

If we take a commonsense approach to public safety, you must vote in favor of the motion to abolish the death penalty. Everyone wants a neighborhood that's safe and communities that are strong. And in order to do that, we have to focus on the root causes of crime. We know why crime and violence happens, when other things are neglected. Mental health services, safe and affordable housing, schools that prepare us for our future jobs, and jobs that pay living wages. When the nation's police chiefs were surveyed about what they thought our priorities should be when it comes to enhancing public safety, the death penalty ranked last consistently. Some even went so far as to say that the death penalty was an inefficient use of taxpayer dollars. What do police chiefs think should be our focus and attention? It should be on more resources for law enforcement, particularly training, drug treatment, and again, a stronger economy with better jobs.

Most of these police chiefs also thought the death penalty wasn't a deterrent. Why? Based on their experience. Because perpetrators rarely consider the consequences when they engage in violence. More evidence that the death penalty is disconnected from at true public safety objective is the fact that it's used so rarely. In 2014, we only had 72 new death sentences in the entire country. And execution rates continue to drop as well. In 2013, we had 39 executions. In 2014, we had 35. The death penalty was used-- executions took place in mostly three states. 80 percent of the executions in 2014 took place in Texas, Missouri, and Florida.

And even in those states that used the death penalty frequently, the death penalty is really relegated to pockets within those states. Abstract justifications for the death penalty have little meaning in a context where it's used so rarely and unpredictably. The death penalty does, however, reinforce our nation's sad and ugly history of slavery, Jim Crow segregation, and racial inequality. A substantial body of research spanning 40 years – it remarkably, consistently shows that race, particularly race of the victim, is the single-most reliable predictor of whether you're going to get a death sentence. The death penalty is rarely used when the victim is a person of color, particularly African American men, even though African American men are most likely to be the victims of homicide. And that figure correlates with the recent report from the Vera Institute, that found that as a society, we provide very little services for African American men, that we don't take the victimization of African American men seriously.

And so, that statistic is borne out by what we're actually doing as a society. We're also seeing, in recent studies, that the most likely person to receive a death sentence is an African American person who is convicted of killing a white victim. We have a system that treats some lives as worth more than others. And we have current information about how, as a society, we are two sets of people living in the same space with very different experiences, with our interactions with law enforcement. Under those circumstances, we cannot have a system that decides who lives and who dies. The death penalty is an outdated practice that is hindering our nation's forward progress. Therefore, I urge you to vote for the motion, to Abolish the Death Penalty.

### Moderator
Claim: Thank you, Diann Rust-Tierney. That is the motion, Abolish the Death Penalty.

And now, our final debater to speak against this motion, is Robert Blecker. He is professor at New York Law School and author of "The Death of Punishment: Searching for Justice Among the Worst of the Worst." Ladies and gentlemen, Robert Blecker.

### Scientific Advocate (SA)
Claim: So, let the punishment fit the crime. We've mouthed that for centuries. But do we believe it? Do we practice it? No. Not at all. We mock it in the very administration of our criminal justice system, because the grand irony is, however counter-intuitive this is, that inside prison, it's nobody's job to punish. Nobody's. I hear Diann Rust-Tierney talking about safety, I think I'm listening to the corrections officers, because that's what I asked them, what their mission is, what are you trying to accomplish here? Their answer uniformly, speaking almost with one voice, "Safety. I want to keep the public safe from these guys, I want to keep these guys safe from each other, and I want to keep the staff safe from the inmates." Safety, safety, safety. And then I ask, "But what about their crime? What do they deserve?"And their answer is, "It's none of my business what a guy did out there. I'm only concerned with one thing: how does he behave once he's inside?" So for lifers, life begins when the sentence of life begins. From the corrections point of view, it's all a clean slate, and it's nobody's job to punish. Look at the mission statements of the departments of corrections. They guide corrections. You will not find the word, "punishment," in any mission statement in any part-- in any department of corrections in the United States, or its synonyms, not one. So, it's no surprise that given the fact that no part of their mission is to punish, that they run their prisons in such a way that life becomes relatively pleasant. Now, what am I talking about? I mean, Barry Scheck talks about life without parole inside of a maximum security prison. For one thing, you may not be sentenced to life without parole and end up in a maximum security prison. You're going to start out there, but you may not end up there.

In many states that I have visited, a perfectly well-behaved killer, the most vicious of killers, who prey on the vulnerable, are likely to be the most cowardly of killers, will be perfectly compliant once they're arrested. So, they will be pussycats, and they will be there for a long time. So, they will be reliable, and, therefore, they will be given the best lifestyles, the best hustles inside the prison. It's fundamentally perverse. Those who deserve it least will often suffer most. Those who deserve it most will have the best lives in prison and may well be transferred to a high medium security prison where they'll be playing softball and volleyball. And, by the way, you can do that in a maximum security prison in Riverbend. I watched convicted killers playing softball in a softball field with chalk base pads and umpires in uniform, and not prison uniform, and softball uniforms, high-fiving it after they hit homeruns.

The reality of life without parole, given the way that prison is administered, given the television sets, given the first-run movies in many cases, given recreation, given the hours and hours outside of the cell daily, the reality is it's nobody's job to punish and there is no punishment going on. The closest we come to serious punishment left in this society is the death penalty. So, when you consider the question, you can't consider it in isolation. You have to consider it in context, that we are a society that is increasingly disavowing punishment itself. Now, we advocates for the death penalty have to struggle against different groups. One group, for example, are the indiscriminate "Kill them all" set, "Person kills, kill them." They don't want to hear about mercy. They don't want to-- they don't want to hear about mitigation, just “kill him." They are indiscriminate. On the other side, there are the indiscriminates whose heart bleeds for every killer, "Evil? No such thing," or, "We're all evil". Punishment? "Let those without any sin punish, we all have sin," so, therefore, nobody punishes.

And a third group we have to set ourselves in opposition to are our supposed allies who say, "No, we're against the death penalty. That's not nearly enough. You really want to punish him? Give him life without parole. Let him die every day in prison." Well, the fact is they don't die every day in prison or at least no differently than we all die every day a little bit. When you examine what goes on, life takes on new meaning, new pleasures, new communities. So when you consider the motion, don't consider it in isolation. Consider the actual alternative in practice. And yet I would argue for the death penalty separately from that. Some people deserve to die, and we have the obligation to execute them. Now, who are they? And can we determine them adequately in advance? Yes, we can. We can do it through definition, and we can do it through enumeration. In terms of definition, it's a function of the attitude, the cruel, the callous, the wanton.

And so I would reserve the death penalty for essentially terrorists, mass murderers, murderers of vulnerable victims, especially children, rapist murderers, contract killers, torture killers, and it-- so definite-- we cannot precisely and fully define it in advance, but we can get to the core. I offer a model death penalty statute based upon thousands of hours and years talking to killers and listening to them. And we can also do it by enumeration. Joshua Komisarjevsky broke into the Petit house, took Michaela and Hayley, tied them to their beds in their upstairs bedroom for six hours. Took Michaela, repeatedly sexually abused her, took cell phone photos of her, and sent them to the friends. And then in order to eliminate the evidence, before he left took gasoline and doused her on and around her and her sister and burnt them to death, alive. He deserves to die. Fedell Caffey and Jacqueline Williams, they wanted another child.

She already had three. So, what did they do? They got Debra Evens. They cut the fetus out of her. And then to eliminate the witnesses, they killed her 10-year-old daughter, abducted her eight-year-old son, and murdered him. They deserve to die. Danny Rolling, the ninja killer, terrorized the whole town of Starke, Florida, broke into houses, tortured, mutilated, murdered. He deserved to die. Lawrence Brewer took an innocent black guy walking down the street, and for sport this white supremacist dragged him to his death in an unspeakable torture. We can enumerate them in advance, not only who should we kill, how should we kill, not by lethal injection, a terrible method, and not because it might cause pain, but because it certainly causes confusion. It confuses punishment with medicine. It's all part of the deeper issue. And so ultimately we get to the question of, why? Why should we punish? Not for the sake of deterrence, that would be using a person as a means to our own ends.

That would be sending a message by killing a person. That's immoral. Not for incapacitation, I disagree with Kent. We have the obligation to build escape proof prisons and safe prisons. We should kill for one reason and one reason only: They deserve it, in three words. In one word: justice.

### Moderator
Claim: Thank you, Robert Blecker.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. Debate, where our motion is, "Abolish the Death Penalty." Now we move on to round two of this Intelligence Squared U.S. Debate, where our motion is, "Abolish the Death Penalty." In round two, the debaters address one another directly, and they take questions from me and from you, our live audience here in New York. The motion, again, is, "Abolish the Death Penalty." The team arguing for the motion, to abolish, Barry Scheck and Diann Rust-Tierney. We heard them argue that the death penalty represents a broken policy that fails to protect public safety, that undermines the fair administration of justice.

Too many examples of racial bias in execution of the policy. It's too arbitrary. It-- factors like wealth, location, geography, quality of legal representation come into play. They argue also that there is an alternative punishment, which would be life without parole. The team arguing against the motion, Kent Scheidegger and Robert Blecker, argue that the system is not perfect but it's not very broken, "Some people deserve to die," they say, that just desserts are appropriate, and that the death penalty serves a very real, moral, and social purpose. They disagree with one another on whether deterrence is the issue or not, but they make the argument that the data on deterrence is murky as well as the data on racial bias, they say, is murky, and life without parole is described as not very punishing.

I want to go to the team that's arguing to abolish the death penalty and point out that to some degree what your opponents are saying is that the policy is not perfect but could be perfected. The things that you're talking about could be fixed. And, given that hypothetical, if the problems that you specify with the death penalty were fixed, would that change your position on the justice of the death penalty? Diann Rust-Tierney.

### Conspiracy Advocate (CA)
Claim: I'll go first. I mean, I think that the real question is whether it can be fixed. I mean, we've been at this for over 40 years. The court has looked at this, and what we've seen is as the justices have looked at this case, one-by-one they're coming to say, you know, "This isn't going to work." So, I don't believe it can be fixed. It is something that seems to be beyond us, to get the racism out, to get the mistake out. We've been trying this. And so the question really is, "Do we continue to do this?"

### Moderator
Claim: But to my question if it could be fixed, and I take your point that you don't think it could be, would that change your opinion? I just want to sort of see where the moral parameters are.

### Conspiracy Advocate (CA)
Claim: Well, I think the moral ground is this is not necessary for the government to do, and I think the burden is really on the proponents of this policy to say that it does something that is of value. And we haven't heard that.

### Conspiracy Advocate (CA)
Claim: Well, the-- and--

### Moderator
Claim: Barry Scheck.

### Conspiracy Advocate (CA)
Claim: --you're missing a point here when you ask a loaded question like that, "if it could be perfected…"

### Moderator
Claim: Well, no. It's your opponents' argument is that--

### Conspiracy Advocate (CA)
Claim: Oh, but my opponents’ argument is, "It should be effective, swift, and sure," right?

### Moderator
Claim: --right. And your argument was, "Here's what's wrong with it. This is wrong with it. This was wrong with it. So I think it's quite logical to say if those wrongs could be addressed, what about-- what does that leave for you?

### Conspiracy Advocate (CA)
Claim: It-- I-- it's an impossible hypothetical. I'm a law professor. I hate to fight the hypothetical, but what--

### Moderator
Claim: Okay. So, why is it impossible?

### Conspiracy Advocate (CA)
Claim: You know, if you're making a public policy argument and you're living just as the attorney general in Virginia said, in a fairly land, where you actually believe that you're going to eliminate the risk of executing innocent people, which you didn't mention, John, is a major cost of the death penalty, which we now know is much greater than we ever did before. Not just because of DNA testing. DNA testing obviously has proven that, but in 2009 the National Academy of Sciences has just indicated in a groundbreaking report that fingerprints, ballistics, bite mark evidence, pattern evidence, all kinds of other evidence that we used to rely on think we're so sure are in doubt and we're now trying to get all these resources together to do basic applied research and make it reliable.

### Moderator
Claim: Let me bring it then to Robert Blecker, your opponents point now, that in fact it could not be fixed on this particular point, that we could never get to 100 percent certainty that an innocent person would never be executed. Do you think that's true and if so does that concern you seriously?

### Scientific Advocate (SA)
Claim: Well, of course I'm concerned about executing an innocent person, every retributist would find that the ultimate horror and I just want to express my respect for what Barry Scheck does with the Innocence Project.

That is fundamentally a retributive program. We don't want the innocent being executed. You say 100 percent certainty. I'm not 100 percent certain that this ceiling won't fall, collapse, and kill us, neither are we all, but we're very brave to sit here. The fact is we trust our lives constantly. We trust our lives for a tiny risk of death and for the sake-- when I walk my beloved grandchildren and do it down Broadway where a truck might jump the curb and kill them for the sake of convenience. Surely if I'm willing to take an infinitesimal risk for those I love for the sake of convenience, I'm willing to take that same kind of risk for those I detest for the sake of something much more sacred, which is justice. It can be refined. I'd love to talk about how it can be refined and improved. And one last point if I might, which is they ducked the question and the reason they ducked the question is because abolitionists-- your question, because abolitionists are divided into two categories.

Some will admit and have admitted to me yes, people do deserve to die, I just don't trust the government to do it. Others deny that anybody can deserve to die. And so when you ask the question you asked, you're using the entering which to split the ranks of the abolitionists.

### Moderator
Claim: Barry Scheck.

### Conspiracy Advocate (CA)
Claim: That's-- I'll admit I don't trust the government to get it right. I'm like George Will--

### Scientific Advocate (SA)
Claim: But do people deserve to die, Barry?

### Conspiracy Advocate (CA)
Claim: It's a government program.

### Scientific Advocate (SA)
Claim: Do people deserve to die?

### Moderator
Claim: Diann.

### Conspiracy Advocate (CA)
Claim: Yeah, I want to bring this back to what this is really a conversation about, which is a public policy question. It is not an abstract conversation about whether some people deserve to die. And I think that's the point. We've been proceeding down this road as if that's the question. The question is do we do things that don't add up to a real product and we've yet to hear. We hear oh, both sides of the story about--

### Moderator
Claim: Diann, why don't you feel the abstract question is relevant?

### Conspiracy Advocate (CA)
Claim: Because we're talking about a public policy like everything else. And when you have a public policy decision to make you look at does this thing that we're doing actually produce what it's supposed to? Does it work in a way that it's supposed to work? And our opponents concede that this thing is broken.

They just say we need to keep trying to fix it. The point is it's broken.

### Moderator
Claim: All right. Kent Scheidegger, just a little bit more on the abstractness of this issue.

### Scientific Advocate (SA)
Claim: Okay. Yeah.

### Moderator
Claim: Your opponents are saying that it-- that the abstractions are irrelevant to this conversation. For example, the question that maybe some people do deserve to die does not belong in this conversation because we're talking about a policy. What's your response to that?

### Scientific Advocate (SA)
Claim: I believe that both the retributive and the utilitarian aspects have to be considered. I think Robert is right that it is a matter of justice and a matter of who deserves to die and I also think that the practical aspects also need to be considered, the questions of deterrence and incapacitation, and I think we need to weigh all three of these factors when we consider the public policy such as this.

### Conspiracy Advocate (CA)
Claim: I should add one thing on the-- I don't want to be perceived as ducking the moral question. I think that there are plenty of people in this country that are pro-life, that believe that it is wrong to take a life.

You know, the Pope-- in the corner with the Pope and others on that question, but when you're debating a public policy issue about something like this that doesn't work and is causing incredible suffering for the wrongly convicted, even for many families of murder victims that don't find closure in this process and go through it, some do, I just, you know, nobody wants to say that the moral question is irrelevant, but it is a factor to be weighed. That's all. And there are plenty of people on the right that think it's morally wrong to take a life.

### Moderator
Claim: I just find it a little bit difficult to disentangle from the policy question, for example, and the question I'm going to put to you, Robert Blecker, where I think I heard you say that if society makes some mistakes and some innocent people do die on rare occasions, as much as you abhor that, that's the price that we need to be willing to pay in order to preserve the right to execute. Am I hearing you correctly, that you're willing to pay that price of mistakes being made?

### Scientific Advocate (SA)
Claim: In order to preserve the responsibility for justice. But then the question is, what is that probability? What is that threshold? And it--

### Moderator
Claim: But let's say--

### Moderator
Claim: --let's say it's one in a million. Let's say it's one in a billion.

### Scientific Advocate (SA)
Claim: Yes. Yes. I mean, we consciously allocate resources in this society. We could make our bridges safer. We could make our roads safer, and we don't. We can statistically calculate how many people will die on the highways that otherwise wouldn't die if we made them safer. We choose to let them die because we think we have other priorities. My point is that justice, which is the second purpose listed in the preamble of the United States constitution, along with "a more perfect union, and general welfare, and common defense," et cetera, et cetera, is a fundamental value that we embrace in this society and that we need to unfortunately take some very small risks. But I would minimize them, and I do have practical solution-- not solutions. Practical suggestions for refining the death penalty.

### Moderator
Claim: Let me bring it to-- let me bring Diann back in.

### Conspiracy Advocate (CA)
Claim: I would just say, you know, we're talking as if we're-- the only thing out there is the death penalty.

The vast majority of homicides do not result in a death sentence. The vast majority of cases that are resolved have justice because people are serving long prison sentences, including life without parole. So, the idea that unless we have the death penalty, we cannot have justice, is just a false premise.

### Scientific Advocate (SA)
Claim: For the vast majority of homicides, yes. Life in prison is justice. But for a very few, for the worst of the worst, no it isn't. It's not for the marathon bomber. It wasn't for Charles Manson. He's grinning at us to this day, because we temporarily abolished the death penalty, networking with his fan base on his smuggled cell phone. And he just has not been sufficiently punished and will not be sufficiently punished.

### Moderator
Claim: Barry Scheck.

### Conspiracy Advocate (CA)
Claim: Well, I-- first of all, I think Bob ducked your question about how many--

### Scientific Advocate (SA)
Claim: Really?

### Conspiracy Advocate (CA)
Claim: --how many innocents-- what is the error rate for executing the wrongly-convicted that would be tolerable in the cost-benefit analysis?

And I know that you'd want to see the system perfected, but when you have really good analysis by Sam Gross in the proceedings of the National Academy of Sciences, pointing that we have a 4.1 error rate-- percent error rate in capital cases in the United States, I'd submit to you that's really an unacceptable number.

### Moderator
Claim: That would be 4,000 in a million.

### Scientific Advocate (SA)
Claim: But it's actually a number that's not characterized correctly. But we'd be getting into a very complex statistical debate over that, and that-- the audience would be uninterested in-- and I'm probably not qualified to--

### Conspiracy Advocate (CA)
Claim: Well, it's not even a question.

### Scientific Advocate (SA)
Claim: --do--

### Conspiracy Advocate (CA)
Claim: You don't even have to characterize it.

### Scientific Advocate (SA)
Claim: There's no 4 percent error rate, Barry.

### Conspiracy Advocate (CA)
Claim: Let's just say--

### Scientific Advocate (SA)
Claim: And you know it.

### Conspiracy Advocate (CA)
Claim: --John asked you, if it's one in a million. What if it's 1 in 400? What if it's one in 1,000? I mean, let's get to numbers that, frankly, are pretty close to that error rate. I mean, you know, we're not even getting into-- there's over 1,500 people whose convictions in this country, since 1989, were vacated based on new evidence of innocence.

And you may say, "Oh, that's two"-- the Registry of Wrongful Convictions says that, and maybe Kent will say, "Well, not all of them were innocent. Maybe some of them just got unfair trials" or something like that. But these numbers are substantial. The 326--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --post-conviction DNA exonerations, they were all innocent.

### Moderator
Claim: Let's dig down into some of the points that were made earlier. Kent Scheidegger, your opponents are saying that the deterrence argument is pretty solid, they say, that the science more or less shows that deterrence doesn't work. They cite examples of states that have high murder rates and high-- and the death penalty-- Texas, for example, as an example. Very compelling argument. What's your response to it?

### Scientific Advocate (SA)
Claim: Well, actually, it's not a very compelling argument. And if you--

### Moderator
Claim: I-- oh, I-- well, I bought it, but--

### Scientific Advocate (SA)
Claim: It's pretty elementary social science that that kind of one-item comparison, between two different groups, is not valid. Texas is different from Vermont in a lot of ways, besides the death penalty. And you're comparing apples and oranges, to just take that one item, compare two groups, and assume that that difference is what caused the difference in the murder rates.

That's the basic problem of correlation and causation. We-- I often hear the argument, "Well, you compare the United States and Europe, and compare their murder rates." Well, you can take the exact same argument and compare Europe and Japan, and you get the opposite result. So, it is not valid to make that kind of simplistic argument.

### Conspiracy Advocate (CA)
Claim: But-- but one thing that we can all agree on-- because Bob believes it, and tell me if you don't--

### Moderator
Claim: I'm sorry?

### Conspiracy Advocate (CA)
Claim: --that you believe it-- and tell me if you don't-- and I thought you conceded it, Ken-- and that is the National Academy of Sciences, when it looked at all the studies on deterrence, said there is no persuasive evidence that it deters. And my point to you is that if you're going to use the ultimate punishment and you want to justify it on the basis of deterrence when there's no persuasive evidence that it deters, we win that point in the public policy debate.

### Moderator
Claim: No response to that.

### Moderator
Claim: Robert Blecker.

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: Robert Blecker.

### Scientific Advocate (SA)
Claim: --well, first of all, in terms of the neighboring states, and the New York Times published a famous study about that neighboring states, and the states without the death penalty had a lower homicide rate than the states with them.

And they conveniently left out Washington, D.C., which is right between Virginia and Maryland, which at the time both had the death penalty. Washington, D.C., did not, and Washington, D.C., had a much higher murder rate. Now, I was in Lorton Prison for 12 years and interviewed and spent time listening to convicted killers in D.C. And you read sometimes in the literature that there's no evidence that it deters. Well, in fact, one of them told me about a situation in which he broke into the house of a drug dealer expecting many keys of coke and found many keys of heroin. In addition to the keys of coke, had him duct taped and a gun to his head and didn't kill him. And I asked him, "Why? What went through your mind at that moment?" He said, "Well, when I was a child, I used to look through the window of the D.C. jail and look at the electric chair, and when I was on Virginia's penitentiary, I used to sweep the hall and look at the electric chair. And what went through my mind at the moment before I let him live was the electric chair, and that I didn't want to have that." That was half the evidence.

The other half was he told me the situation in D.C without a death penalty, same situation, drug dealers had them duct taped, and I said, "What'd you do?" And he said, "I killed them because I can face what they have waiting for me here. I just couldn't face what they had waiting for me there." That's only a single datum, but that is as close as you will ever get to primary evidence that sometimes the death penalty is a more effective deterrent than its alternative, life without parole.

### Moderator
Claim: Diann.

### Conspiracy Advocate (CA)
Claim: But our point is we need more evidence than that, and the burden is on you to show that this is useful. There is no affirmative strong argument or evidence to suggest that the death penalty is a deterrent, and you've admitted that. You said, "It's equivocal, but we should keep going forward," and that's really the public policy question.

### Moderator
Claim: Diann, I want to take to you a point that I believe I understood Kent to make, which was that the-- that your side, the abolitionist's side, moves arguments when the data fails your first arguments.

And the example he gave was on the race question, where he said, if I have this right, Kent, that at one time the argument was that most of the convicts facing-- on death row were disproportionately African-American, but that the argument, failing data confirmation, that you move the argument to "Most of the victims are white," and that, that's a little bit of a dance. So, I'd like you to respond both to his point that you're moving the goalpost and just to go to the point itself.

### Conspiracy Advocate (CA)
Claim: I wish I had the power to move goal posts the way Kent was talking about, but we don't do that. The facts are the same. What I see is sort of Kent looking selectively at the evidence. The case has always been that the death penalty actually tracks our history of racial apartheid when it comes to criminal justice, that the death penalty when we had slave codes actually was meted out based on the race of the victim and the race of the defendant, and even though the slave codes and-- we've made some progress, the-- the process-- the system still works the same way. The core issue is that the death penalty values some lives more than others.

And when it comes to the good that our opponents are saying the death penalty offers, that good is only used when the victim is white, because that's where the system currently sees the value lying.

### Moderator
Claim: And the data is there?

### Conspiracy Advocate (CA)
Claim: And the data is there. And the reason--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --because

### Moderator
Claim: I'll let you finish and then bring it to Kent.

### Conspiracy Advocate (CA)
Claim: Sure. Well, first of all--

--finish.

### Moderator
Claim: No, no, you finish, Diann, and then I want Kent to respond.

### Conspiracy Advocate (CA)
Claim: There was a recent study that just came out that looked at death sentences from 1976 to 2013, and what that study found was two things, first, that the race of victim discrimination continued, that the least likely-- as I said earlier, the least likely victim for whom the death penalty is sought will be an African-American man even though African-American men are the most likely to be the victims of homicide. And they also found that the defendant-- a defendant who was convicted and sent to death for murdering a white victim who was African-American is far more likely.

One other point, prosecutors-- every study-- there's been over 200 studies over 40 years-- every study has found that prosecutors seek the death penalty for crimes against white victims more frequently than other victims.

### Moderator
Claim: Okay, I want to bring this to Kent.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: Kent Scheidegger.

### Scientific Advocate (SA)
Claim: Well, first of all, I'm very glad to hear that we are agreed that seeking the death penalty constitutes honoring the life of the victim. I appreciate that you're conceding that point.

### Conspiracy Advocate (CA)
Claim: I've not said that.

### Scientific Advocate (SA)
Claim: On the studies, the pattern of offending across racial groups is not uniform. That's a demographic reality. If you take these studies and if they are litigated and if they are reanalyzed, if you have competing experts looking at the same data, what you find over and over again is that when additional factors, legitimate factors explaining the differences between cases are taken fully into account, that these racial differences vanish down into the statistical grass where we can say that it's hardly even apparent there's any effect there.

### Moderator
Claim: Well, in the interest of intellectual honesty on all sides, are you all saying that the data we're talking about can be cooked by either side to produce the results it wants?

### Conspiracy Advocate (CA)
Claim: Absolutely not.

### Moderator
Claim: You're not saying that?

### Conspiracy Advocate (CA)
Claim: 40 years of-- 40-- we have studied the death penalty in every state that had it 40 years, different researchers, different approaches, and the data-- the outcome is remarkably consistent, remarkably consistent finding racial bias.

### Moderator
Claim: Robert Blecker.

### Moderator
Claim: You'll have to--

### Moderator
Claim: Oh, Barry

### Conspiracy Advocate (CA)
Claim: --it's the Baldus study in the McCleskey case, that went off on the issue of race of the victim, that is the effect that has been replicated countless times no matter who looks at the data and how often, and that's what you'll find the weight of criminologists and scientists saying, "The race of the victim makes a difference, period."

### Moderator
Claim: So, let me just bring this back to Kent for one more round on this point of-- your opponents are basically saying that the data is really consistent.

You're basically saying that it's not. Do we just declare impasse on this or is there--

### Scientific Advocate (SA)
Claim: No, this is very soft science. These are mathematical models, and there's a lot of leeway when you put together a mathematical model. And you can choose the variables the way you want. You can get the result you want. What we see time and again is the same authors who have a axe to grind put out study after study. And I do want to mention the Baldus study from Georgia, that study went to trial in Federal District Court, and the finding of the Federal District Court was that Baldus's study did not, in fact, prove what he said it proved.

### Moderator
Claim: Robert Blecker.

### Scientific Advocate (SA)
Claim: Yeah, I want to dig down and talk about the meaning of this race of victim effect, if it's real, and I believe it is real. Lorton Prison was the only all-black prison system in the United States, where I spent 12 years. And I explored this issue in depth. Diann Rust- Tierney says that it shows that if it's more likely, that we will execute the killer of a white than the killer of a black, that means that we devalue black life. That's not true. There are alternative explanations for it.

Most killings are same-race killings, whites on whites, blacks on blacks. The budget for death penalty trials, which is very high, tends to be more available-- the money is more available in white jurisdictions than black jurisdictions. The odds of picking a jury that'll go death is greater in white jurisdictions, although there is substantial support for the death penalty in a black-- in black communities, it's less than half. It's in the range of 40 to 45 percent. So, what does it really mean? The victim's family is consulted, "Do you want me to go death?" If it's been a black victim, often they have a much more nuanced appreciation of what the conditions were that produced that killing. They realize that "There, but for fortune, my child who is now dead could just as easily be accused of the killing because he ran in the wrong crowd, he was part of a drug life, et cetera, et cetera. So why compound the tragedy?" So they will say, "Don't go death." That doesn't show that they're devaluing black life. That shows they're continuing to value black life, including the life of the killer. There is--

### Moderator
Claim: All right, let me stop you, and let Diann respond.

### Conspiracy Advocate (CA)
Claim: You know, we have to keep bringing this back to reality. We're in the midst of a conversation in this country right today where African-Americans and people of color do not have the same experience with law enforcement that other people have. And we're telling people that we have essentially two systems of justice, and in that context we cannot have a death penalty. And what we're talking about in terms of years of study is the same science that we use to look at implicit bias generally. It's the same science that we use to determine that there's a glass ceiling for women. It's the same science that we've used to determine that women are not receiving equal pay. I mean, this is not some made-up science. This is how we determine whether a system, even a neutral system, operates in a way that has a discriminatory impact.

### Moderator
Claim: Robert Blecker.

### Scientific Advocate (SA)
Claim: I--

### Moderator
Claim: Before you speak, I just want to say after Robert speaks, I want to go to you for questions, and I'm telling you this now before Robert so you can prepare. The way it will work is I'll-- if you raise your hand, I'll call on you.

We would appreciate if you would stand up, wait for a microphone to reach you. They'll be brought to you. Hold it about as far away from your mouth as I am with this microphone so that we can hear you on all the podcasts and the radio broadcasts. Tell us your name and ask a question that's on point and very terse. Thanks. Go ahead, Robert Blecker.

### Scientific Advocate (SA)
Claim: I just want to acknowledge where there is a real race effect in the death penalty. And that's not the way it's administered. It's the way it's defined. That is to say, because felony murder is the most common aggravator, and robbery murders put more people on death row than any other aggravator, and because robbery is an economic crime and correlates with race, that creates the disparity in terms of percentage of population of population of those who are on death row, if you eliminate the robber aggravator from felony murder as a death penalty aggravator you eliminate the racially disparage effect and the other place that it occurs is the place that nobody wants to talk about, but that I became aware of. There is deep prejudice in both the black and the white community against those who have prototypically African features.

Studies have shown that the hue of the skin, this is true in the black community, as well as the white community, will influence the probability of being convicted and condemned. That is a pernicious form of racism that is extraordinarily troubling and almost impossible to eradicate in both communities.

### Moderator
Claim: Barry Scheck.

### Conspiracy Advocate (CA)
Claim: So, I've heard you say this before and it's true, all right, and the-- you say well if we eliminate the felony aggravator then we'll get rid of some of these race effects, which Bob, you acknowledge exist in the system, and we've got to be in the real world. That's not happening.

### Scientific Advocate (SA)
Claim: Oh, I think you're wrong about that.

### Moderator
Claim: Let's go to some questions. Right there. And remember, I need you to not make a speech--

But to ask a question.

### Moderator
Claim: Hi. I'm D.C. If you-- this is for the against side.

If you are sort of talk so strongly about justice and deterrents, would you then be willing for deterrents in justice to have other ways rather than the death penalty such as caning or cutting off the hand that, you know, may work as a deterrent and maybe bring some kind of justice.

### Moderator
Claim: An eye for an eye. Thank you. So, that's-- that question is put to the side that's arguing against the motion-- I just want to be clear. That means they are arguing against abolition of the death penalty. Would you like to take the question Robert?

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: Robert Blecker.

### Scientific Advocate (SA)
Claim: First of all, an eye for an eye is a measure. It's not a justification as is pointed out classically. If a one-eyed person takes out one of two good eyes of a victim he's left him sighted. If you take out his eye you've blinded him. So we've-- I'm sorry. We've traded the notion of proportional punishment. Now, to directly answer your question what would I have? No, not physical mutilation by any means, but I would have something that I call permanent punitive segregation, which means life should be unpleasant.

The food that they eat every day, I'm talking about the worst of the worst of the worst who are never getting out, they should eat only nutraloaf, which is a tasteless, but nutritionally complete patty, gives you absolutely no satisfaction. I saw Komisarjevsky, Hayes’ cohort on death row with his Hershey bar. He'll wake up, watch a ballgame, and eat a Hershey bar. That's wrong. There should be no such thing as play. Play? Exercise yes. Play for the worst of the worst of the worst? Absolutely not.

### Moderator
Claim: Are you talking about a life without parole scenario or a death row scenario?

### Scientific Advocate (SA)
Claim: I'm talking about both. Life without parole is a fundamentally retributive punishment. When we commit someone to life without parole we're saying--

### Moderator
Claim: Well, your opponents are arguing for life without parole as the alternative to death penalty.

### Scientific Advocate (SA)
Claim: Yeah, but they're saying live in the real world and then they're ignoring what the real world is for the lifer's who serve life without parole.

### Moderator
Claim: Barry Scheck.

### Conspiracy Advocate (CA)
Claim: Bob, I mean, people should know your real position and I understand it intellectually.

Yes, you are saying that, you know, logical extension of your argument is if we had that kind of punitive segregation and-- that that would make life without parole a more acceptable alternative to you than the death penalty. Just in case people missed it, you were objecting to the way that lethal injection is done because you don't want people anesthetized so that it looks like you want people to see that there is suffering at the time of the execution. You think that's important. You favor firing squads, right?

### Scientific Advocate (SA)
Claim: I do.

### Conspiracy Advocate (CA)
Claim: Right. So, let's just look-- I mean, your argument is a retributive argument. You're not arguing deterrence. You're not arguing that there is a high risk of executing innocents. You have a position which I understand, but I actually don't think that that is a generally shared view.

### Moderator
Claim: I'm sure everybody gets this, but I know that when I was studying for this I stumbled a little bit on the word retributive until I realized doh, retribution, that's-- it's obviously sort of the just desserts argument as Kent put it on early today. So, it' s-- again, it does come back to eye for an eye. Let's go to another question. Down here, sir.

### Moderator
Claim: Thank you to all the panelists. My name is Evan Katz from Manhattan. I've always been anti-death penalty for the reasons we've discussed. There is a debate now going on whether this country and the Supreme Court should look to other countries at all, somewhat, or a lot regarding what they are doing. And I've got a question for all the panelists, but especially those against the motion-- it seems that most of the rest of the world is going against the death penalty, especially developed nations. And if you look at who's for it, who's against it abroad, the U.S. is much more aligned-- vastly more aligned with the countries that have abolished the death penalty. Could the panelists discuss what's going on abroad, and especially the panel against the motion, please?

### Moderator
Claim: Only to the degree that this can be relevant to whether we should abolish here. And I'm not sure that it is. Does anybody feel that what's happening abroad is relevant to what we do here?

### Conspiracy Advocate (CA)
Claim: I think--

### Moderator
Claim: Yeah.

### Moderator
Claim: Do you? Yeah. Diann Rust, take it.

### Conspiracy Advocate (CA)
Claim: Well, I would say--

### Conspiracy Advocate (CA)
Claim: --you know, most of our allies who are committed to the advancement of human rights and civil rights really are looking to the United States to abolish the death penalty because we do have a reputation for leading in these areas. And so, I think that in addition to the good that it would do for us to get rid of the death penalty, we could actually make a larger contribution to the broader struggle that many in other countries that you mentioned are fighting. You know, there-- we have a trial. There are people who are sentenced to death without the kind of trial and protections that we have. There are people who are sentenced to death who don't know when they're going to be executed. The guard comes from the-- and those kinds of situations can't really be addressed as long as the United States can be pointed to as still having it.

So, there's a very important benefit for us to abolish the death penalty, because we can advance human rights in other places where we could all agree that human rights need to be advanced.

### Moderator
Claim: We haven't heard from Kent in a few minutes, so I'd like to--

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: --hear Kent

### Scientific Advocate (SA)
Claim: My short answer is no.

I think the United States can and should decide this issue for itself. I think it's entitled to decide this issue for itself. As far as examples to other countries, I think we can serve as an example to those countries that don't want to abolish the death penalty, that yes, you can have the death penalty consistently with human rights. We can do that.

### Moderator
Claim: Robert Blecker? If you can be brief on this one, because--

### Scientific Advocate (SA)
Claim: Sure. You hear "Follow Europe's lead." Let's talk about Europe's lead. Anders Breivik in Norway set off a bomb outside the parliament building in Oslo, killing eight, then went to an island and killed 69 youths. You know what his sentence was? 21 years in prison, the maximum that Norway has. But lest you think they're treating him too well, he's right now on a hunger strike. Why is he on a hunger strike inside prison? Because they're not giving him Playstation 3.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: They're only giving him-- Europe has abolished life without parole.

Do you know that? If we follow Europe's lead, we abolish life without parole-- not only have they abolished the death penalty. You don't read that in the Times.

### Moderator
Claim: Right down in front, please.

### Moderator
Claim: Hi. My name is

I'm interested in something that Kent Scheidegger said. You said that comparing Vermont and Texas is not apples to apples. So, I'm wondering, what are the elements that distinguish your examples of Vermont and Texas as being not apple to apple? And if those elements that are Vermont-ish could be replicated in the Texas examples, then would that be sufficient to justify abolishing the death penalty?

### Moderator
Claim: All right. Great question. A fruit based question--

But it's actually an excellent question. Let's take that to you, Kent.

### Scientific Advocate (SA)
Claim: Yeah. I mean, there's a huge cultural difference between various regions of the country. And the countries that have abolished the death penalty, by and large, are those countries that already had lower crime rates before they abolished the death penalty.

It's just built into the whole culture of the state. To do the analysis, you have to try to control mathematically through models for these other factors. And that's what the deterrence studies do. And I think there is a very substantial body of literature showing a deterrent effect through that kind of mathematical modeling. I do not concede that-- what Barry said, that there's no good evidence. The report that he refers to says very clearly, in the front matter of the report, that it is simply the personal opinions of the authors whose name appear on that report. There are plenty of other experts who disagree with that, so I think there is a substantial basis, once you do that kind of modeling, to believe that there is a deterrent effect. If I really believe there wasn't a deterrent effect, as things stand now, I think-- I still think that justice would be enough by itself to justify the penalty.

### Moderator
Claim: Barry Scheck.

### Conspiracy Advocate (CA)
Claim: Oh, giving little ground there on deterrence, I see.

But look, the question brings up the statistic I cited at the very beginning. If you have counties-- counties is really what you have to look at, although most of them are in the South. But there are a few that over-produce death in California. If two percent of the counties in this country are producing 56 percent of the death sentences and 52 percent of the executions, when two-thirds of Americans reside in counties, where there hasn't been-- there's been one execution or less in 45 years, right? All of a sudden you begin to see-- and it doesn't take much to see it-- that there are just a small number of counties in this country and a small number of states that are engaged in capital punishment in a serious way.

### Moderator
Claim: Another question? Ma'am, right down here. Yep, that's you.

### Moderator
Claim: Okay, so this is for I guess all the panelists.

### Moderator
Claim: I-- if you can just sort of throw it out there. I don't-- we don't-- wouldn't have time for everybody to answer.

### Moderator
Claim: Sure.

### Moderator
Claim: Okay.

### Moderator
Claim: Just so a quick question.

### Moderator
Claim: Sure.

### Moderator
Claim: You mentioned that for someone who's on death row, they have to go through the appeals process and get multiple, you know, government-issued attorneys. Do you think, you know, I guess people for the motion, if that’s actually someone, you know, of color or an African-American, if they had a poor attorney given to them from-- for life on parole, and then they got to go through this process, do you think it would be more helpful for getting truly innocent people off?

### Moderator
Claim: Diann Rust-Tierney.

### Conspiracy Advocate (CA)
Claim: I think one of the sad things about the death penalty is because the punishment is so severe that the limited resources-- as much as Barry is able to do with the Innocence Projects across the country, have to focus on, you know, those people who are sentenced to death. I think if there were no death penalty, there would be many more resources and much more opportunity to look for and address the question of innocence of people who are serving other sentences.

You know, keep in mind, there's one underlying theme, we make mistakes, and we're being told that, you know, "Well, some mistakes are tolerable," but I think your point is the fact that we have to focus on the death penalty means we cannot focus the resources that we need to address the problem of a system that makes mistakes.

### Moderator
Claim: Barry Scheck.

### Conspiracy Advocate (CA)
Claim: And let's be clear about what those costs are. When Maryland studied the death penalty before they abolished it, they were able to determine that a capital case was seven times more expensive than a noncapital case, that the executions in Maryland averaged $37 million per execution, it's $23 million in Florida, it's $185 million in California, and, you know, California's system is completely crazy. There's 734 people on the row, right, hundreds that don't have lawyers, who have been sentenced to death. And there are some pretty good death penalty lawyers there, but there are also some that are not very good.

And we can't fund it. I mean, why would you put all this money into propping up a system where they have no persuasive evidence of deterrence, right, that we need all this money to finance an underfunded criminal justice system that has so much to be fixed, particularly when it comes to forensic science?

### Moderator
Claim: All right, let me-- Barry, let me let the other side respond because the question was to all sides. If you'd like to, Kent Scheidegger.

### Scientific Advocate (SA)
Claim: Well, yeah, the California one is the one I'm most familiar with, and the study counted in as costs of the death penalty a great many things that are not costs of the death penalty. They're costs of the obstruction of the death penalty. The length of time spent on death row was cited as the number one cost. We spend a lot of money in California going over and over and over the same case, litigating issues that have nothing whatever to do with whether the person is guilty or not. And we have been to the legislature and proposed reforms to fix that. They have been killed in the legislature, but we do have an initiative process in California, and I believe that it will be fixed, and it will be both a better system and a cheaper system.

And ultimately the death penalty does not need to cost more than life without parole.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, arguing it out over this motion, "Abolish the Death Penalty." And let's go back to some audience questions. Sir, right in the middle here, the mic's going to come from your right side. Do you see it? Excellent questions tonight so far, folks, really.

### Moderator
Claim: Impressive.

### Moderator
Claim: Yeah, yeah, keep it up. Yeah.

### Moderator
Claim: This question is for both of those against the motion. I think it was asked several times, but I never really heard an answer. If you accept the fact that there are 4.1 percent of false positives, if you accept that and you accept that, that cannot be changed, does that change your position, and, if not, why? And preferably if both of you could answer that…

### Moderator
Claim: Kent Scheidegger.

### Scientific Advocate (SA)
Claim: If I believed that were really true, I would be against the death penalty. I don't believe it's true, not for a minute.

The author who came up with that number is one of the people I've referred to, who just pumps out paper after paper after paper every time supporting abolition of the death penalty. It's easy to cook books in studies like that.

### Moderator
Claim: Robert Blecker.

### Scientific Advocate (SA)
Claim: I, too, if I thought there were a 4.1 percent true error rate, would be opposed-- would impose a moratorium until we fixed it and there was nothing like that. I don't believe it's anything like that.

### Moderator
Claim: Is there evidence against your side in the fact that so many states have moved to abolish the death penalty and in the-- what your opponents claimed is the preference of police chiefs or the-- or the lack of preference of police chiefs for the death penalty, where they rank it last among the things that are

### Scientific Advocate (SA)
Claim: Yeah, the Death Penalty Information Center surveyed police chiefs because they knew that was where they were likely to get the result they wanted. If you surveyed line police officers, you would get a very different result. When my organization has spoken to police groups, the police officers who were actually on the line actually dealing with the bad guys every day, the support is practically uniform in favor of keeping and maintaining capital punishment.

### Moderator
Claim: Diann.

### Conspiracy Advocate (CA)
Claim: But that-- that--

### Moderator
Claim: Let's let Diann speak.

### Conspiracy Advocate (CA)
Claim: --I want to bring it back to what the question was. The question is not-- because many of the people that were surveyed did support the death penalty in theory, but when they were asked from their position of having to manage law enforcement resources and from their experience about what they thought it needed to take-- what it took to make the community safer, they made a choice that said that the death penalty, among all the things that we could have, is the least useful thing that we would need. So, the distinction is not whether these people support the death penalty in theory. The question is whether when you have to make tough choices about resources, whether this is the thing that's going to get the result.

### Moderator
Claim: And, Robert, the part of the question about the fact that states have been moving to abolish more than the other way around.

### Scientific Advocate (SA)
Claim: Oh, so I don't get to answer that. You know what? I wanted to respond to that in terms of management and resources, but-- and why police chiefs aren't the right people to-- there's an analogy inside the prison about why corrections officers are the last people to ask also about the death penalty, because for them it's a management question and it's much easier to manage without it than it is to manage with it.

It's not-- they're not the people to consult about justice. The states are increasingly abolishing the death penalty in my view because they are abetted by the media, which is overwhelmingly anti-death penalty, overwhelmingly, and which skews the perspective on it. You know, just to give you an example of that, the Gallup Poll from the-- not the latest one, the one before that-- had 60 percent of the American people supporting the death penalty, answering the standard question which they've been asking since 1936. The headlines were, "Death Penalty Support a 40-Year Low." The next year, last year, the result was 64 percent. So it had risen by 4 percent. What's the headline? "Death Penalty Support Stays Fairly Constant Over the Last 10 Years." It reminds me of the Russian report of the famous race, the horserace between the Russian horse and the U.S. horse. And the U.S. horse whips the Russian horse, and the report the next day is, "In Major International Horserace, Gallant Russian Horse Takes a Wonderful Second. The U.S. Horse Gets a Disappointing Next to Last."

### Moderator
Claim: In the back, sir, can you come down?

### Conspiracy Advocate (CA)
Claim: wait a second. John, John.

### Moderator
Claim: Yeah, I--

### Conspiracy Advocate (CA)
Claim: I have a

### Moderator
Claim: --I just want to position this gentleman come forward. So, if you can come down a little bit.

### Conspiracy Advocate (CA)
Claim: --but let me-- let me--

### Moderator
Claim: Barry Scheck.

### Conspiracy Advocate (CA)
Claim: --but let's get to the heart of it now, because let me see if I just heard what our opponents are saying. They're saying, "The last people to ask about whether the death penalty is going to make you safer are police chiefs"?

### Scientific Advocate (SA)
Claim: I didn't say that.

### Conspiracy Advocate (CA)
Claim: No? Well, Kent certainly did. He said, "Ask the line cop." Here's the point. The reason why police chiefs, who as Diann pointed out very frequently would count in the votes, they say, "Are you for or against the death penalty in principle or for moral purposes?" and they would say, "Yes." But if you ask police chiefs, "Should we have the death penalty now?" as a public policy matter, they'd say, "No."And the reason they'd say, "No," are all the issues that we've raised in this debate about public policy, that they see no evidence of deterrence, it's extremely expensive, it's taking away resources they need to keep your community safe, right? What they need to have good crime labs, to have good police officers, to have good training, to make the community safe, they are saying, "This is not helping us, it's hurting us."

### Moderator
Claim: Sir.

### Conspiracy Advocate (CA)
Claim: That has to be respected.

### Moderator
Claim: I just wanted clarification from Robert on-- it's related to the media. And our notion of prison is not the research notion that you have, and I think perhaps you might have taken it for granted that it is a cushy type of-- that sentence, waiting period. Please clarify that. And also--

### Moderator
Claim: Wait, wait, I'm not following your question.

### Moderator
Claim: --oh, the life in prison aspect. You seemed to-- I-- feel it wasn't a punishment aspect.

That's right.

And to address the nature of the simply-- the freedom itself being taken away.

I felt like that was somewhat dismissive and that I would like clarification on how--

### Moderator
Claim: So, you're questioning-- you're saying, "Come on, Robert, are you really telling me life without parole is the party you're describing?"

### Moderator
Claim: --yeah, because the media presents it as a differently.

### Moderator
Claim: Okay, and your point is that the media makes it seem like it's not so nice?

### Moderator
Claim: Yeah, exactly.

### Moderator
Claim: I'm actually-- I actually am a little bit between the two of you, because, Kent, you got up there and said that if you are convicted of life without parole, your odds of getting a lawyer and getting legal representation are a lot less than if you are sentenced to die, which makes it sound like it's not so great to have life without parole. And Robert is portraying it as a sort of--

### Scientific Advocate (SA)
Claim: Well, we're talking about different aspects of it.

### Moderator
Claim: Okay. All right. So, Robert, why don't you take the question then?

### Scientific Advocate (SA)
Claim: Yeah, we are talking about-- if you're innocent you're better off getting the death penalty in terms of your odds of it being proven-- you being proven innocent. This is the consistency. In terms of the-- I'm not taking anything for granted. I've got it on videotape. I was given privileged access.

I have tens and tens and tens of hours of lifer's playing softball, first run movies of group rec, et cetera, et cetera, et cetera. The point is that the prison system is being run indiscriminately. It is not on the basis of the nature of the crime you committed. It has nothing to do with that. It has everything to do with how you behave when you're inside. Of course it's a loss of liberty. I don't want to spend my life in prison. I'm not saying that that's not punishment. I'm saying that's not punishment enough for the worst of the worst of the worst and it's often much too much punishment for people who've committed relatively trivial crimes and are put into the same prisons--

### Moderator
Claim: Diann Rust.

### Scientific Advocate (SA)
Claim: --with the same experience.

### Moderator
Claim: Diann Rust-Tierney.

### Conspiracy Advocate (CA)
Claim: My first observation is that--

My first observation is that the death penalty has to stand and fall on its own accord. The conversation that Robert is having about punishment whether it's enough and whether-- it's a whole different conversation. We are here to talk about whether this policy actually advances public safety and it doesn't. The other point I want to make is that, you know, it's not the media is

The public when it thinks about the death penalty has to learn more about it. Most people don't think about the death penalty and so the support is uninformed. What we're seeing is as things like botched executions explode in the media, as we're hearing about states going and getting drugs to kill people from the back of a driving school and all these crazy things, the public is starting to focus on it and when they focus on it they see that they don't like it. So, that's why we're seeing state after state that examines this practice decide hmm, we don't need this. That's why we're seeing the public support for the death penalty continue to decline. It's no magic that the media is doing. It's no magic that I'm doing. When you look at this system and you really understand how it works, you cannot support it. You cannot square it with our other values.

### Conspiracy Advocate (CA)
Claim: I'd like to just--

### Moderator
Claim: Very quickly.

### Conspiracy Advocate (CA)
Claim: --what the questioner said is very important because something that should be corrected.

I understand, Bob, that in your view life in maximum security prisons is not harsh enough punishment for people, and you've described what you think would be harsher punishment, but I can tell you from all the clients I've represented, all these exonorees that I've talked with about what their prison experiences were like and some knowledge of maximum security prisons and familiarity with the literature, it's a terrible place to be. You wake up every morning. You have no idea who's going to kill you and when. You walk into the lunchroom. You look at somebody wrong, you can get stabbed. I mean, there are gangs in prison. There's horrible violence in prison. You know, they should be safe, and that is why the correction people, Bob, tell you that they're interested in keeping it safe and that is their job. And so the whole characterization of maximum security prison is, you know, Club Fed or something--

--it's just really misleading and wrong.

### Scientific Advocate (SA)
Claim: Under court order I went into every maximum security prison in Illinois with a video camera. Illinois is not-- and also not everyone, but most of them in Oklahoma. These are not known as warm and fuzzy states. The number of stabbings inside the maximum security prisons are negligible. The-- in those, now I've not been to every state of course, and some are worse than others, but the point is not that, Barry. The point is this. Why are we having the same day-to-day lifestyle for the worst of the worst of the worst, and that's why, Diann, you're wrong. This is relevant.

### Moderator
Claim: Okay. I'm going to stop this. Diann, you're right that we are kind of getting off the point of whether to abolish the death penalty. I'm going to take one more question. Sir, right here.

### Moderator
Claim: Sorry. Hi. David Seaburg and I am for the death penalty. Question to Barry, actually. I mean, you talk about prisons being so harsh and, you know, painful for these people that experience that.

Why isn't that a deterrent for criminals, one, but when you're talking about--

### Moderator
Claim: Wait. I'm going to give you one question. Is that your best one?

### Moderator
Claim: Well, no. I have another one actually.

### Moderator
Claim: All right. We're going to not do the first one. We're going to do this one.

### Moderator
Claim: When you talk about-- as a deterrent, right, when you think about measuring deterrents, whether or not it actually is effective or not, we're talking about murderers. We're talking about people that have gone out and taken lives of other people, innocent human beings. They're irrational. You can't possibly deter an irrational person in this world. It's just an absolute farfetched--

### Moderator
Claim: Okay, Barry Scheck. Can you deter a person that's irrational?

### Conspiracy Advocate (CA)
Claim: Well, I think your-- both parts of your question, I think, kind of make our point on the issue of deterrence, which is-- that's what the studies show. I mean, that there is no evidence that you can deter somebody that is going to commit a murder for irrational reasons-- many homicides and family situations. That's not how deterrence works, and you don't get it from the threat of capital punishment.

And so, you know, that's--

### Moderator
Claim: Kent--

### Conspiracy Advocate (CA)
Claim: --so, capital punishment is not the answer on the issue of deterrence.

### Moderator
Claim: Kent Scheidegger.

### Scientific Advocate (SA)
Claim: And that's why second-degree murder is not a capital offense. I mean, we do divide murder into degrees for exactly that reason. The heat of passion killing is not a capital offense. We reserve capital punishment for the worst crimes. A person who commits torture does this crime methodically. And he knows what he's doing. And he's thinking about what he's doing. And these are not irrational in the sense that a person doesn't know what he's doing and doesn't know the consequences. They are bizarre and they are demented, but they are not irrational.

### Moderator
Claim: And that concludes Round 2 of this Intelligence Squared U.S. debate, where our motion is, "Abolish the Death Penalty."

## Round 3

### Moderator
Claim: And remember how you voted just before the debate began. Immediately after closing statements, which will be brief-- they'll be two minutes each-- we're going to have you vote again, and then we will produce the results of your vote.

Onto Round 3. Our motion is this: Abolish the Death Penalty. Round 3, closing statements by each debater in turn. Here to summarize his position supporting the motion to Abolish the Death Penalty, Barry Scheck. Barry, you can sit on this one. We'll sit-- Barry Scheck. He is co-founder and co-director of the Innocence Project.

### Conspiracy Advocate (CA)
Claim: Let's not be abstract. Shuja Graham, Byron Halsey, please stand. I want you to see these two people. This is not the cost of doing business. This is not collateral damage. Shuja Graham was sentenced to death in California for murder in prison. He was exonerated in 1981. He has been out since then. He is vice-chair of the group Witness for Innocence. Byron Halsey, my dear friend, was convicted of murder, a crime that-- in New Jersey-- I think, our opponents would immediately say, "This should have been a death penalty crime."Two children that-- of Byron's girlfriend were found murdered in a basement, one with a nail in her head, one sexually assaulted. He was tried and convicted. He was miraculously saved from the death penalty by one juror who was probably motivated by a conscientious objection to the death penalty. But DNA evidence, after 22 years in prison, demonstrated that Byron was innocent and identified the person who really committed the crime. So, don't tell me that there isn't an unacceptable risk of executing the innocent. It's been demonstrated-- the Innocence Movement has demonstrated it. It's not just the 326 DNA exonerations that they can't refute. It's not just the over 1,500 exonerations from the Registry of-- including non-DNA cases. We now know that our system is riddled with error. You go to Europe. 60 percent of people there still think capital punishment is a morally appropriate sanctioned for the most heinous of crimes.

But they don't trust the state to get it right. And that is what we have to come to terms with in this country-- you can't start saying, "We can fix it. We can make it perfect," when nobody's willing to put up the money, and it's an impossible task to begin with. Capital punishment is a government program. Skepticism is in order. Conservatives-- George Will said that.

### Moderator
Claim: Thank you, Barry Scheck. Our motion is Abolish the Death Penalty. And here to make his closing statement against the motion, Kent Scheidegger. He is legal director of the Criminal Justice Legal Foundation.

### Scientific Advocate (SA)
Claim: Among my clients and among my comrades in this struggle are parents whose sons and daughters have been murdered. There is Phyllis Loya, whose son was a veteran and a police officer, murdered in the line of duty, just a few months before his own son was born, a boy now growing up without a father.

There's Marc Klaas, whose 11-year-old daughter was kidnapped out of her own bedroom by a habitual criminal and murdered. There's Sandy Friend, whose 10-year-old son Michael was abducted, raped, and tortured for 10 hours before he was murdered. There is no doubt of guilt in any of these cases. These parents have waited too long for justice already. And I ask you, do not slam the door of justice in their face. Vote no on this motion.

### Moderator
Claim: Thank you, Kent Scheidegger.

And the motion is Abolish the Death Penalty. And here to summarize her position in favor of the motion, Diann Rust-Tierney. She is executive director of the National Coalition to Abolish the Death Penalty.

### Conspiracy Advocate (CA)
Claim: You must vote in favor of the motion to abolish the death penalty because it is inconsistent with the fundamental reality and core value of our society. All human beings are capable of change.

That capacity to change is a fundamental value underlying our criminal justice system which is designed not just to punish but to rehabilitate. We believe that there should always be the opportunity for redemption, rehabilitation, and even grace. And the death penalty cuts that opportunity off. The choice is simple. Do we continue down a path that has continued consistently to produce results? Do we continue with an institution that harms and traumatizes people? I've met and talked to the people that the death penalty harms and traumatizes, prison workers, defense counsel, prosecutors, judges, the condemned, and families of the condemned, jurors, and survivors of homicide. Regardless of whether a victim supports or opposes the death penalty, if you listen carefully to their voices, one message comes through, "It hurts.

The death penalty process by its very nature hurts." It is the nature of the beast, therefore, it must be abolished. I urge you to vote in favor of the motion to abolish the death penalty.

### Moderator
Claim: Thank you, Diann Rust-Tierney.

And that is the motion, "Abolish the Death Penalty." And here to make his closing argument against the motion, Robert Blecker. He is a professor at New York Law School.

### Scientific Advocate (SA)
Claim: Moral facts exist. This is not ultimately just a matter of opinion. I think that might be common ground with at least three of us. The past counts. It counts independently of the future benefits that derive from our actions. We make a covenant between the living, the dead, and the unborn. And so you can't use a cost benefit calculus, not appropriately, not if you're seeking justice. Punishment must be limited, and it must be proportionate. It must be deserved.

It must be proportionate to the culpable mental state. It must be proportionate to the experience of the victim. The worst crime deserves the worst punishment. We can define them in advance. We can enumerate the worst of the worst of the worst. Life without parole as presently experienced and administered is the only alternative, and it's a bad one. There is no adequate substitute for the worst of the worst of the worst but death. The question's been phrased, as has been pointed out, so that it's a double negative on our part. So, when you vote in the negative, you are really voting to uphold something. You're upholding the victim. You're upholding a sense of justice. You're upholding a sense of proportionality. You're ultimately upholding human dignity. We've seen some victims of the process stand up. I have no doubt that they are innocent.

But you can't see the victims stand up who have been tortured, mutilated, raped, and murdered. We as a society have to be a voice for those victims for the worst of the worst of the worst and give them the only punishment that they deserve, which is death.

### Moderator
Claim: Thank you, Robert Blecker. And that concludes closing statements in this Intelligence Squared U.S. Debate, where our motion is, "Abolish the Death Penalty." And now it's time to see which side you feel has argued the best. We're going to ask you to go again to the keypads at your seat and vote a second time on this motion, "Abolish the Death Penalty." Remember, if you agree with the motion to abolish, push number one, or if you've been persuaded to it, push number one. If you've been moved to the other side or are remaining there, push number two. And if you remain or became undecided, push number three. And as I said before, you can ignore the other keys. They're not live. And you correct your-- if you make the-- a mistake, just correct yourself.

The system will lock in your last vote. And while that is happening, I would just like to say that this was a-- this was a very, very hard-fought debate, and, in fact, the morality and the policy issues were impossible to disentangle from one another, and I think that's to the benefit of the conversation that we saw here but it was also greatly supported by the fact that all four of these debaters came to each other with the position of respect and dignity. They heard each other, even to robustly disagree with each other, but that's the essence of what a debate is, so our congratulations to the way all of you did this.

And I also have to say this, the audience questions, fruit based or not, were--

--spectacular tonight. They really, really stirred this debate and got it to better places. So thank you, everybody who got up and asked a question.

I wanted to tell you about our upcoming debate, and I had a card on it which I-- may have disappeared well, in-- what's the date of the May debate? May 13, we're going to be back here, and the motion we're debating is, "Smart Technology is Making Us Dumb."

And we have a terrific panel on that one, and we would love to have as many of you who would be there plus everybody watching on live stream to join us again for that debate. It's one that we all connect to, and I think the motion tells its own story. It was actually suggested to me by a friend of mine who is here tonight, who I will not call on, but it-- see, if you do pitch ideas to us, they do come around.

So, the other thing I want to talk about is the fact that, as I said at the beginning, Intelligence Squared U.S. operates as a philanthropy, and your ticket purchases are very valued by us not only because they get you in our seats and get you in our audience and get you to vote and help the process along, but also because it supports what we do, but the ticket sales don't come close to covering what it costs. And I'm saying that because there's a way to donate to the Intelligence Squared Enterprise by going to our website online, and we would appreciate if you could do that and participate in that way. The other thing is, as I said at the beginning, we are-- exist as a podcast, and that's very easy to find these days, thanks to a quite gorgeous app that you'll find in the Apple Store and in Google Play as well. If you download the app, you can see all of the debates we've ever done, which I think now number 103, 104 as of tonight. And-- see, I keep looking down here because everything that I say is told to me by somebody down here.

It all-- I'm-- it's the telepathy thing. But you can see all of our debates, including the research, the background material, and all of the topics we do. So, if you're interested in these debates, you can watch them or listen to them on your phone. All right, let's get to the final results now. It's all in. The motion goes like this. It's, "Abolish the Death Penalty," and as I said at the beginning, that's our motion. And the team whose numbers changed the most between the first and the second vote will be declared our winner. So, here's the results from the first vote, 49 percent agreed with the motion to "Abolish the Death Penalty," 17 percent were against, 34 percent were undecided. That's the first vote. In the second vote, the team arguing for the motion, their second vote was 54 percent. That means they gained 5 percentage points, which is the number to beat. The team against the motion, their first vote 40, second vote was 40 percent, that's an increase of 17 percent. That means the team arguing against the motion to "Abolish the Death Penalty," has won this debate.

Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.

Everybody hang on. Apparently your host made a mistake.

### Moderator
Claim: You said them incorrectly.

### Moderator
Claim: I said the numbers incorrectly?

### Moderator
Claim: Oh, okay. All right. So, is everybody going to pretend that the last two minutes just didn't happen?

You don't have to go along with this, but just don't giggle.

I'm going to read it again so that we can edit it into the podcast. So right now isn't even happening. Here we go. So I'm going to give the final results. In the vote-- the final vote, the second vote--

--okay, let's see. Against the motion, the first vote was 17 percent, the second vote was 40 percent.

That is an increase of 23 percent. That is what it takes to win the debate. Our congratulations to that side.

Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time. And thank you for great , great questions tonight.
