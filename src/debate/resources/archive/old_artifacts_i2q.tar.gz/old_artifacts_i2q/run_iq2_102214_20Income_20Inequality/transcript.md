# Debate Transcript

Topic: Income Inequality Impairs The American Dream Of Upward Mobility
Motion: Income Inequality Impairs The American Dream Of Upward Mobility

Debate ID: 102214%20Income%20Inequality


## Round 1

### Moderator
Claim: So we always start each of our programs by bringing to the stage the chairman of Intelligence Squared U.S. who brought this program to the United States. He spends a couple of minutes kind of outlining why we're doing these debates, what we're looking forward to, and always brings a fresh insight to the topic. So please welcome to the stage Mr. Robert Rosenkranz.

Hi, Bob.

### Moderator
Claim: Hi, John.

### Moderator
Claim: How are you? So, Bob, something that I don't think our audience knows is that you actually spent some time as an economist in your career.

### Moderator
Claim: Yeah. I was an economist at the Rand Corporation back many, many years ago, early in my career.

### Moderator
Claim: So-- so can you help us-- you know, give us an image for-- for-- to hold onto to get through tonight's debate.

### Moderator
Claim: Well, I think the image is the image of a ladder, climbing the ladder of success in terms of one's income.

And the ladder of success has moved over time in a couple of ways. But the rungs have certainly gotten further and further apart so that the very top of the ladder, the top 1 percent, the top 1/10 of one percent has a much bigger share of the national income than it did, say, 20 or 30 years ago. And the middle rungs of the ladder, frankly haven't moved all that much.

### Moderator
Claim: So this is a very visceral topic. It's not purely academic. Why-- why does it connect to people so strongly?

### Moderator
Claim: Well, I think the-- first of all, before I get to that, let me just say that this debate, in a sense, is not about whether the ladder is as I've described it.

But it's about the difficulty or ease of moving from one rung of the ladder to the next and getting to the top of that ladder or the upper rungs of the ladder.

### Moderator
Claim: The mobility question.

### Moderator
Claim: The mobility question. And this debate is not about anything other than, has this increase in inequality, the widening of the rungs of the ladder made it more and more difficult for people to climb that ladder, or is it really neutral on-- on that dimension?

### Moderator
Claim: And again, why-- why does this grab people beyond the academic world?

### Moderator
Claim: Well, I think it grabs people because it's been so much in the public consciousness. And I'd say there are really three sort of views out there about what it is that's powered this top 1 percent or-- or above.

And one of the views is that it's very benign, that it's a process, a normal process of capitalist economies, that you have companies like Apple and Google and Facebook that have provided goods and services that we all need, that we all use. And the extraordinarily creative entrepreneurs behind those companies have been very richly rewarded, and there's nothing wrong with that. So that's kind of one mindset. Another mindset is that a lot of it is luck. And the kind of luck people are talking about is the luck of where you're born, the luck of how your-- your parents' economic situation, the luck of your race and ethnicity, the luck of how many IQ points you've got, frankly. So there's some-- some people who feel like the primary determinant of where you are on that ladder is luck. And there are other people who take a more draconian view that people have gotten to the top of the ladder in mean-- through means that are not legitimate.

Crony capitalism, where they've gotten the government to subsidize their particular business or activity, are protected with tariffs, or in the case of the big bankers who got huge bonuses and then had to be bailed out by the taxpayer.

### Moderator
Claim: And got bailed out.

### Moderator
Claim: And did get bailed out. So you-- you have three very different and competing visions of-- of what it is that propelled people to the top of that ladder and therefore different visions of the legitimacy of the system.

### Moderator
Claim: So, I mean,-- and there's also just the fact that all of us have a place on the ladder. I mean, on this stage, there are two guys, and one of them is higher up the ladder than the other one. How's the view from up there, Bob?

### Moderator
Claim: Well, you know, John, I thought I'd wear faded jeans and a T-shirt and try to disguise that, but then I thought, why not be honest and wear my English suit?

### Moderator
Claim: Well, you look very smart.

And let's thank Bob Rosenkranz on the stage. And let's bring out--

Let's bring out our smart debaters. Let's welcome them to the stage. Ladies and gentlemen, our debaters.

And I just want to invite one more round of applause for Bob Rosenkranz for making all this possible.

Hello again from Intelligence Squared U.S. I'm John Donvan. We use the word "dream" sometimes to mean almost completely opposite things. We use "dream" to describe an aspiration for something that can be if we try hard enough, "Dream a little dream," "I have a dream."But we also use it in the opposite way to describe something that just is so impossible to get that it's ridiculous to try. You know, "Dream on, buddy," "dream on," "in your dreams." So, what about people who are partway down the ladder of success in America and their American dream? Given that 40 percent of America's wealth, up to 40 percent, and up to 20 percent of its income is in the hands of the legendary 1 percent, does the dreamer on the ladder still have a chance to climb or should he or she simply dream on? Well, that sounds like the makings of a debate, so let's have it, yes or no to this statement, "Income inequality impairs the American dream of upward mobility," a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufman Music Center in New York City. We have four superbly qualified debaters, two against two, who will argue for and against this motion, "Income inequality impairs the American dream of upward mobility."As always, our debate will go in three rounds, and then the live audience here in New York will vote to choose the winner, and only one side wins. Our motion, again, "Income inequality impairs the American dream of upward mobility." Let's meet our debaters. Please, ladies and gentlemen, welcome Elise Gould. And, Elise, you're a senior economist and director of health policy research at the Economic Policy Institute. And one of the topics you study there is wages. And you have a calculator on your website, I'm told about-- I haven't been to it yet-- but it shows what your wages would be today if they had actually kept up with productivity, so that $40,000 today really should be something closer to $60,000. That’s about right?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: So when that was posted on the website, did everybody at the institute ask for a raise?

### Conspiracy Advocate (CA)
Claim: Well, not immediately, John, but we economists really know how to bring the facts to the table when we start bargaining over wages.

### Moderator
Claim: And you'll be bringing some facts tonight.

### Conspiracy Advocate (CA)
Claim: Yes, absolutely.

### Moderator
Claim: Ladies and gentlemen, Elise Gould. Can I just ask to have my IFB be lowered significantly? Thanks. That's a technical term. It's on a need to know basis. Don't worry, I am not going to explode, I don't think. Elise, tell us who your partner is.

### Conspiracy Advocate (CA)
Claim: My partner is the charming and resourceful Nick Hanauer.

### Moderator
Claim: Ladies and gentlemen, Nick Hanauer, please welcome him. Nick, you are also arguing for the motion, "Income inequality impairs the American dream of upward mobility." You are a-- let's just say it-- you are clearly a 1 percenter. You're a venture capitalist. Way back in the '90s you made an investment in a little company called Amazon.com. It worked out. You recently wrote a memo to, as you put it, your "fellow zillionaires," where you warned them that these high and historically high inequality is not only self-defeating, that it's transforming us into a feudal society. How did your fellow zillionaires respond to that?

### Conspiracy Advocate (CA)
Claim: Well, I live in Seattle, Washington, and I reckon you have to go all the way to Texas to find a serious and intelligent wealthy person who doesn't agree that rising inequality is something that we need to-- that we need to address.

### Moderator
Claim: Yeah, Thank you, Nick Hanauer. That's our team arguing for the motion, ladies and gentlemen. And we have two debaters arguing against the motion, which, once again, is "Income inequality impairs the American dream of upward mobility." Please welcome Ed Conard. Ed, you are a visiting scholar at the American Enterprise Institute, former partner at Bain Capital. That makes you also a 1 percenter. You-- author of this book, "Unintended Consequences, Why Everything You've Been Told About the Economy is Wrong," in which you actually explain how society benefits from the wealthy. Ahead of publication on this, you were profiled in the New York Times. And you predicted-- I mean, the article predicted that this could be the most hated book of the year. Was it, Ed Conard?

### Scientific Advocate (SA)
Claim: Only in my wildest dreams do I have that much impact on the national debate.

### Moderator
Claim: Well-- see what happens after tonight's debate. Ladies and gentlemen, Ed Conard. And, Ed, your partner is?

### Scientific Advocate (SA)
Claim: Scott Winship, formerly a renowned poverty scholar, formerly on the left, now on the right. He's examined the data for quite some time and he's gradually come to the other side of the divide.

### Moderator
Claim: Ladies and gentlemen, Scott Winship. Scott, as your partner just said, you're also arguing against the motion that "Income inequality impairs the American dream of upward mobility." And as he pointed out you're at the Manhattan Institute, and a-- you know, a relatively conservative think tank, but you were once part of ACORN, the liberal community-organizing group. And you're editor-- managing editor of the Democratic Strategist. So, being at the Manhattan Institute now, with that background, how-- how do you describe yourself?

### Scientific Advocate (SA)
Claim: I suppose I'm a Liberal-tarian. I don’t know, my mom describes me as handsome.

### Moderator
Claim: Well-- just to tell the radio audience, it's entirely true. Scott Winship, ladies and gentlemen. And our team arguing against the motion. Now, to remind you, this is a debate. It's a contest. One team will win and one team will lose.

And that decision will be made by our live audience here in New York. By the time the audience-- by the time the debaters have completed debating, this audience will have voted twice, once before the debate and once again after the debate. And the way we determine victory is the team whose numbers have moved the most in percentage point terms between the two debates, between the two votes. So, let's have you go to the keypads at your seat and register your first vote. Once again, our motion is this: Income Inequality Impairs the American Dream of Upward Mobility. If you agree with this motion, push #1. If you disagree with this motion, push #2. Or if you're undecided-- which is a perfectly reasonable starting position-- push #3. You can ignore the other keys. They are not live tonight. And if you make a mistake in your vote, you can just correct yourself, and the system will lock in your last vote.

Okay. It looks like everybody's got that done. And to remind you, we'll have you vote again right after you hear the-- the closing round of the debate, and again, to remind you that it's the team whose numbers have changed the most between the two votes that will be declared our winner. So, we go in three rounds. And let's get on to Round 1. Our motion is this: Income Inequality Impairs the American Dream of Upward Mobility. And here to speak first for the motion, Elise Gould. She is Senior Economist and Director of Health Policy at the Economic Policy Institute, one of the top-- oh, I've already said all of that.

### Conspiracy Advocate (CA)
Claim: You can say it again.

### Moderator
Claim: I-- I may well end up saying it all again, but I just want to be briefer this time. But you are very, very generous to give me that opportunity. Elise Gould is a Senior Economist and Director of Health Policy Research at the Economic Policy Institute. Ladies and gentlemen, Elise Gould.

### Conspiracy Advocate (CA)
Claim: Thank you so much for inviting me to share my research and knowledge about the question at hand. We are debating whether income inequality hampers the American dream of upward mobility. And I'm here to tell you that it does. Nick Hanauer and I hope to convince you that as income inequality has increased, the American Dream has been harder to achieve. If we think-- as you've already heard already, the same analogy-- if we think of income distribution as rungs on the ladder, and upward mobility-- or mobility in general-- is movements up and down the ladder, common sense tells you if the rungs get further apart, the ladder is going to be harder to climb. Let's start with the first part of the proposition. Research from a multitude of government and academic sources have indisputably found that income inequality has increased over the last generation. That is an established fact.

The tremendous growth in income inequality comes at a cost to individuals, to families, and to society as a whole. We know from research that rising income inequality has not helped grow the size of the economy, and has likely even harmed growth. This makes the rise in inequality a zero sum game at best. Since inequality means that the larger shares are flowing to the top, middle, and bottom-- the middle and bottom continue to get squeezed. Those consequences aside, the one cost we're discussing today is reduced access to the American Dream. The American Dream itself is a somewhat elusive concept. It's one of those you know it when you see it sort of things. To some it means the happiness of a normal, stable life. Not falling behind every year. It means a good job and a great future for your children. It means that if your kids work hard, they will find success. Working hard is the backbone of the American Dream. To know that your kids have the opportunity to do well, it is only for them to grab it, to seize the day.

The most common concept economists use to measure upward mobility is intergenerational mobility. This is the extent to which your parents' economic position determines your position in adulthood. If your position on the earnings, income, or wealth scale is largely a function of your birth, then even the most talented coming from the lower rungs of society will have a hard time achieving success. Conversely, little correlation between parents and children means that one's economic fate can be directly determined through intelligence and hard work. So how do we raise the economic mobility of the U.S. today? Well, one way is to look at how we compare to other countries. Another way is to look at, historically, what has happened with mobility and discuss the pathways through which mobility is affected by opportunity. The fact that one's economic position in childhood determines one's position in adulthood more so in the U.S. than in many advanced countries. We have less mobility here than in Denmark, Norway, Finland, Sweden.

We have less mobility than Australia, Japan, New Zealand, Germany, Spain, France. Let me talk for a moment about our peer to the north, Canada. Canada actually looks a lot like us, both in economic regime and in its diversity. But family background is twice as important in determining children's success in the U.S. than in Canada. Furthermore, among our peers, we are the most unequal society, and we have seen the greatest growth in inequality. Janet Yellen recently reiterated the fact that lower economic mobility is found in countries with higher income inequality. So, the American dream is more likely elsewhere than here and more likely in more unequal societies. Now, what's happened over time? The truth is that research on mobility has a few years before it can catch up to answer more definitively on this question. We have to wait until the children born in the most unequal times, let's say the last decade, until they grow up, and we can see, we can measure their incomes and their earnings.

So far, high quality research has shown that economic mobility has been stagnant or declining over the last generation. Even so, it's impossible to know what the counter factual is. Perhaps the society got richer, economic mobility would have increased. So, finding stagnant mobility really doesn't answer the question. What is entirely clear and is known that income inequality leads to inequality of opportunity and resources, and this surely hampers mobility. When growing inequality means that poor kids don't get the proper nutrition they need or the glasses when they need them, then it's obvious they can't do as well in school. Opportunity for many often looks like education. Over time, high-income parents are-- are making increasingly larger and larger investments in their children. And that's a good thing. But lower income families simply cannot afford to make those same investments.

We've seen low income families increasing their investments from the 1970s to the 2000s, from about $835 per kid to about $1,300. At the same time, over that same period, high income families' investments went from 3,500 to nearly $9,000. And those investments pay off. It may come as no surprise that more affluent students score better on standardized tests. A recent study actually renamed the Scholastic Aptitude Test the Student Affluent Test. Those with higher family income who tend to be college educated allow parents to live in neighborhoods with better schools and pay for private schools. And it's a self-reinforcing cycle. This provides a direct link between growing inequality, growing gaps in opportunity and declining mobility. Over this period of growing income inequality, college graduation rates have become increasingly unequal. Both groups, the top and the bottom, have seen higher college graduation rates than before. But the bottom only increased by 4 percent while the top increased by almost 20 percentage points.

What is even more troubling for society that defends the reality of the American dream is that low-scoring, high-income students are more likely to graduate from college than high-scoring, low-income students. That is, by definition, not about ability. It is about income. Everyone can't be in the top 1 percent. And we can all name stories of children who did succeed against all odds. But it's "against the all odds" part that we're here to talk about today. Has living in an increasingly unequal society made it harder to climb the rungs of the ladder? Unambiguously, the answer is yes.

### Moderator
Claim: Thank you, Elise Gould.

And that is our motion Income Inequality Impairs the American Dream of Upward Mobility. And here to speak against the motion, Scott Winship. He is the Walter B. Wriston fellow at the Manhattan Institute. Ladies and gentlemen, please welcome Scott Winship.

### Scientific Advocate (SA)
Claim: Well, thank you, John, and thanks to IQ Squared and to the Rosenkranz Foundation for sponsoring this debate, but also for creating a way to combat the polarization that I think it’s really been poisoning a lot of our discourse the last few years. And in that spirit, let me just start by noting a few areas where there's agreement I think with what Elise just said. First, I agree that there is a lot of income inequality in the United States. There's-- frankly, there's a lot of income inequality on this stage. Like Elise, I'm also deeply concerned about inequality of opportunity. I can tell you that I became interested in these issues on April 29th, 1992 when the L.A. riots erupted during my freshman year of college. I believed then and still believe that-- that poor children enjoy far too little upward mobility. What do I mean by that?

Kids with the poorest parents tend, disproportionately, to end up among the poorest adults as well. Where I part ways with my opponents, and by the way, with my 19-year- old self, is that after a brief career in community organizing, after a not at all brief period in getting my PhD in Harvard's Inequality and Social Policy program, after managing the research agenda for the Pew Economic Mobility Project and continuing to study these issues at Brookings and now at the Manhattan Institute, after all of this, I-- I've concluded that if you're, like me, concerned about inequality of opportunity, focusing on inequality of incomes is just misguided. So, my partner, Ed, and I are asking you to oppose the motion on the table. Whatever you think of the state of the American dream, income inequality does not impair it. Okay. So, Elise and I are going to disagree on a few things.

In my mind, if-- if income inequality were impairing the American dream of upward mobility, you ought to see two things jump out at you in the very big literature that we've got on this question. The first thing you would expect to see is that over the period where inequality was growing in the United States, that you would see falling upward mobility. Now, the-- the consensus from a dozen studies on this question is easily summarized by the conclusion from the most recent paper that came to this conclusion. And I'll just quote: It found that mobility has remained remarkably stable over the second half of the 20th century in the United States. That finding is from Berkeley's Emmanuel Saez who, along with Thomas Piketty, who's the most famous economist of the year for sure. They're the two who develops the top 1 percent estimates that we all have seen everywhere. So, that's his conclusion. The second conclusion you would expect to see is, if high inequality impairs upward mobility, is that places with a lot of inequality would have lower mobility.

And you heard Elise mention that the U.S. has less mobility than other countries. That was certainly the conventional wisdom I would argue until this year. In a paper published this year, a Canadian economist named Miles Corak, who had originated this thing called "The Great Gatsby Curve," that some of you might have heard of, that Janet Yellen talked about in her speech. Earlier this year, his most recent paper highlights real serious problems with that chart and the previous research. What he did in this newest paper is to team up with an American economist and a Swedish economist. And the three of them looked at their own countries, compared mobility across them, were very careful to measure them comparably, and they found, quote, "we find almost no differences in upward mobility between Canada, Sweden and the United States."Meanwhile, Saez’s team, in a second study this past year, found that developed countries with higher income concentration have mobility rates that are no lower than countries that are low inequality. And they found the same thing to be true of American counties. Okay. My opponents want you to believe that if the top 1 percent hadn't made as much in the past 35 years, that the bottom and the middle would have made more, that they pay an inequality tax you sometimes hear. But research again finds that in rich countries, those that experience bigger increases in inequality, have experienced bigger income gains at the bottom and in the middle, not smaller. Now, how can that be? Well, Ed is going to talk to you about the research on inequality and economic growth. We disagree, I think, with our opponents on that as well. But essentially, the research finds that countries with more inequality actually experience more economic growth. So, essentially if you enlarge the pie enough, the economic pie enough, then the poor and middle class actually can get more pie even if their slice becomes skinnier.

If you claim that absent rising inequality, the middle class would have had thousands of dollars more than they did, as you sometimes hear, there are a couple of really big assumptions hidden behind that. One is that if we had capped the incomes at the top, that the economic pie would have become just as big as it actually did. The second assumption is that if we had capped those incomes, then essentially the proceeds would be equally distributed across the population. Now, in actuality, if we somehow managed to cap the incomes of the top 1 percent, what would likely happen is we'd be shifting incomes to knowledge workers and professionals who are in the upper middle class or in the rest of the top 10 percent.

To see how important these assumptions actually are, consider one possible outcome if we had successfully held the top 1 percent’s income share in 2007 to their 1979 level, okay? So assume, for sake of argument, that, that would have reduced economic growth, not by a lot, say, by 8 percent. And assume that the middle 20 percent, instead of receiving 20 percent of the proceeds from this redistribution, got 13 percent of the proceeds. Well, I've done the math, and what it works out to is that in this scenario the middle class actually would be no better off for having limited the increases at the top. So, I think that's against our intuition. But it's, nevertheless, the case. So, as you listen to the arguments from the other side, I hope you continue to ask yourself, as I have, that if income inequality hurts opportunity, why is it so hard to find that link when you look across time and look over space?

The answer is that the motion on the table that "Income inequality impairs the American dream of upward mobility," is intuitive but wrong. And that's why you should vote against it. Thank you.

### Moderator
Claim: Thank you, Scott Winship. And a reminder of what's going on, we are halfway through this opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion, "Income inequality impairs the American dream of upward mobility." You have heard from the first two debaters, and now on to the third. I'd like to welcome to the lectern Nick Hanauer. He is a cofounder and partner at the venture capital firm, Second Avenue Partners, and author of the book, "The Gardens of Democracy." Ladies and gentlemen, Nick Hanauer.

### Conspiracy Advocate (CA)
Claim: Let me start tonight by sharing some IRS data.

In 1980, the top 1 percent of Americans shared 8.46 percent of national income. By 2007, it had risen to 22.86 percent. During the same time, the bottom 50 percent of Americans' share of national income fell from 17.68 percent to 12.19. During the same period, the income share of the top 1/10th of 1 percent of Americans rose to 12 percent, equaling the share of the bottom 50 percent of Americans combined. And then in 2008-- remember, 2007, before, those were the good old days-- things went really bad for the American middle class. The distance an American child needs to go to get from the bottom to the top in our society is staggering. CEOs used to make 30 times the median wage now earn 300 to 500 times.

If the IRS data that I just quoted you is not persuasive to you, does not persuade you that the distance from the top to the bottom is larger-- perhaps 10 times larger, then almost nothing Elise and I can say tonight will persuade you. According to Scott, this economic inequality and its impact on mobility is a fiction. The anguish felt by millions of ordinary working middle class Americans is a consequence of a misconception. They are simply confused about the data. Perhaps. But there are two fundamentally different arguments inequality deniers make. The first is that it doesn't exist. The second is that it exists but it's actually really, really good for the economy and the middle class. This argument is equally false, but at least it seems plausible. The idea, of course, is that when the rich get richer, that's good for the economy and for the middle class, and for mobility.

And anything we do to make the poor richer by definition harms the economy and mobility. And this, of course, is the trickledown economics lie. But Ed-- Ed and I do agree on one thing, and that is that innovation is essential to a growing economy and that capitalism needs some inequality to create incentives for people to innovate and to take risk. The question for the house tonight is, is extreme inequality necessary, and should we have more and more of it every year? Capitalism needs inequality to grow, just like plants need water to grow. But in precisely the same way that too much water kills plants by drowning them, too much income inequality kills capitalism by drowning the middle class. Raging inequality is drowning the middle class and killing the American Dream of upward mobility.

Ed and other inequality apologists present us with a false choice-- extreme and rising inequality is necessary to create adequate incentives for innovation and risk-taking, and that without these extreme incentives, it will all disappear. He will tell you that anything we do to blunt inequality, like raising the taxes on the rich or improving labor standards for the poor, to increase wages-- will kill the economy and mobility. This is utter nonsense. Bill Gates, Steve Jobs, Sam Walton-- they all started their companies when taxes were twice as high as they are today. Theoretically, with half the incentive. Did they make some sort of cosmic mistake? Almost two years ago, taxes on capital gains went up 25 percent, theoretically quartering the incentive. But from where I sit as a technology venture capitalist on the West Coast, the rate of innovation is increasing, not decreasing.

Silicon Valley is more on fire, not less. The stock market, since then, has gone from 12,000 to almost 17,000. Clearly, people are responding to incentives, just not the ones Ed thinks. The biggest incentive in a market economy is the market size. And the more money most people have-- in other words, the less inequality we have-- the bigger the opportunity and the bigger the incentives are to invest and innovate. Ed will tell you that the American economy has outperformed all others because of our extreme inequality. If you are a partner at Bain or someone like me, that feels like it could be true, but it is not on a per capita basis. Our economy has performed roughly the same, on a growth basis, as most other industrial countries. 1.7 to 1.9 percent. The difference, of course, is what life is like for the typical family.

Thirty years ago, the American middle class was undisputedly the most prosperous and mobile of any society. Today, that is not true. Today, by every measure, the-- the Canadian middle class is more prosperous than ours. Ed and his trickle down ilk believe that capital is all that matters, but we are awash in capital. American companies are currently sitting on $2 trillion worth of cash. At the same time, the cost to innovate has fallen exponentially. It took a million dollars to start Amazon.com. In our economy, growth is dependent on how many innovators and consumers we include in the economy. The economy isn't the bank accounts of the rich. It is the dynamic feedback loop between sellers and buyers.

This means that the more people we include in our economy as robust innovators and affluent consumers, the faster it grows and the bigger it gets. But clearly and most obviously, high and growing rates of inequality don't help that. They hinder it by excluding more and more people as sellers and buyers. And at the end of the day, that's why rising inequality is terrible for the economy and for the American Dream of upward mobility. When people are excluded by inequality, it destroys innovation. It destroys consumption. And it destroys mobility. Rising inequality is literally drowning the middle class and killing the American Dream of upward mobility. Thank you.

### Moderator
Claim: Thank you. Nick Hanauer. And that is our motion: Income Inequality Impairs the American Dream of Upward Mobility.

And here as our final debater against the motion, in this opening round, to argue against it, Ed Conard. He is author of the book "Unintended Consequences: Why Everything You've Been Told About the Economy is Wrong." And he's a former partner at Bain Capital. Ladies and gentlemen, Ed Conard.

### Scientific Advocate (SA)
Claim: I almost feel like I don't have to speak. Nick said it all for me. But Nick pushes you off what this debate is really about. It's whether income inequality impairs mobility. And if it did, there'd be telltale signs that Nick wants to overlook. The first is that we've seen a lot of growing inequality. But all the evidence says mobility has not declined. We’ve transferred more to the poor. That should increase mobility. It hasn't. Economies with more equally distributed incomes should have more mobility. They don't. We've spent more on education. That should significantly increase our test scores. It hasn't. So--

### Moderator
Claim: Can I interrupt you just for the radio. Can you stand with-- with sort of right up to the mic because--

### Scientific Advocate (SA)
Claim: Closer?

### Moderator
Claim: Yeah.

### Moderator
Claim: All right.

### Moderator
Claim: Do you want him to start over?

No.

Okay. So, just proceed so that it's a cleaner signal. Thank you.

### Scientific Advocate (SA)
Claim: I thought it was-- I thought it was a little loud so, I was backing up.

### Moderator
Claim: And fortunately, we're using up all of your time. It counts against you this whole conversation, so--

### Moderator
Claim: No, I can – I see what’s happened with the clock. We stopped it, and you will get your full allotment. You're on.

### Scientific Advocate (SA)
Claim: Okay. So we may not have found a way to increase mobility, but we have found a way to increase the living standards of the poor, and that's by growing our economy. So this debate really isn't about whether income inequality impairs mobility. Even Emmanuel Saez of the liberal Piketty-Saez duo admits that the chances of a low-income child reaching any higher level of income has increased. The rungs have gotten wider. You can still climb the rungs even though they're wild-- wider. This debate is really about whether the success of America's top earners hurts the middle and working class. Now, our opponents see the pie, the economy as a pie to be divided. They believe that Steve Jobs' success reduces the income of everybody else.

The more he gets, the less everybody else gets. We see his success as growing the economy and the demand for labor. Now, it's true, productivity's grown faster than median wages. Our opponents see this as evidence that lesser skilled employees no longer share in the success of our economy. They overlook the fact that growth can manifest itself in two ways: Where the supply of labor is restricted like it was in the 1950s and '60s, it'll drive up wages. But where the supply of labor is unrestricted like it is today, it'll drive up employment. The baby boom, the increased participation of women in the work force, immigration and growing trade deficits have created an enormous increase in supply in labor. And as a result, employment grew instead of wages. U.S. employment has grown 50 percent since 1980, twice as fast as Germany and France, three times faster than Japan.

Two to three times faster is an unheard of difference in performance. This difference has been even greater-- it would have been-- it was even greater because the other countries have shared in the disproportionate benefit of American innovation. And America has achieved this employment growth at median incomes that are 20 to 30 percent higher than Germany, France, and Japan. Because of this growth, today, America's home to 37 million adult immigrants. There are 16 million native-born children, and all the children of those 53 million adults. So perhaps wages would have grown faster in the supply of labor had been more restricted. But it's disingenuous to close one eye, ignore America's extraordinary employment growth relative to its peers, and claim that income inequality hurts the middle and the working class. No other economy has done more to help the middle class and working poor than the U.S. economy.

And that's why you should vote against the motion that income inequality impairs the American dream of upward mobility. To persuade you that the success of America's top earners subtracts from everyone else's income, our opponents will claim that successful Americans use cronyism to misappropriate their earnings. If these Americans had misallocated the amount of resources that are necessary to achieve their success, growth would have slowed relative to other economies with more equally distributed income. The opposite occurred. America's growth accelerated relative to its peers. Rising cronyism can't explain the faster growth of the United States. And that's not to say there isn't cronyism. There is. But the status quo is under assault from innovation more than it's ever been. The turnover of CEOs, Fortune 500 companies, and Forbes 400 wealthiest Americans have all accelerated. That's a far cry from crony capitalism. And it wasn't crony capitalism that produced America's success.

It was hard work and entrepreneurial risk taking. Nick's right. Information technology made our knowledge workers more productive, and it opened up a large window of low- cost investment opportunities. And this increased the productivity and pay of our most talented workers and gave rise to a growing number of successful entrepreneurs. Americans were uniquely successful at capitalizing on these opportunities. Their growth didn't hurt America. It made us stronger. So, to avoid debating the truth, Nick went down this path. Our opponents will retreat to a more ambiguous claim, that perhaps we could have raised living standards even more if we'd attack success more heavily. Even if that's true, upward mobility has not been impaired. And therefore you should vote against the motion. And even if you believe that higher taxes distribute more income to the middle class than they destroy, you should at least recognize that there's very little evidence supporting this highly speculative claim.

In the real world, Germany, France, and Japan all distributed income more equally, and none of them produced faster employment growth than America, nor, despite more restricted supplies of labor, did they grow their median incomes faster than the United States since the early 1990s. In the academic world, there have been no less than six highly regarded cross country studies on the effect of income inequality on growth, by economists at Harvard, MIT, the OECD, the World Bank, the IMF. All of them have reached the same conclusion: Inequality accelerates growth in high-wage economies. The IMF's most recent study, whose headlines insisted that redistribution does not slow growth, admitted, redistribution above the 75 percentile is indeed harmful to growth as the Okun Big Tradeoff suggests. Guess which country's at the 75th percentile? The United States. Another of these studies also conditions the Okun Big Tradeoff and found that by 2001, the growth-promoting effects of inequality had pushed the income of the bottom 90 percent above what it would have been if their share of income hadn't fallen.

So even if this briefly stated evidence fails to persuade you, it doesn't mean that the success of our top earners hurts America. Quite the contrary. Not only has America's much faster growth created employment for tens of millions of additional workers at much higher median wages than other – and median incomes-- than other high-wage economies, it has improved every capable child's chances of earning a higher standard of living. Even Emmanuel Saez agrees. So, please, don't succumb to our opponents’ divisive politics. Even if you support higher taxes, the success of America's top earners is an asset, not a liability. Vote against the motion that success impairs upward mobility.

### Moderator
Claim: Thank you, Ed Conard.

## Round 2

### Moderator
Claim: And that is our motion Income Inequality Impairs the American Dream of Upward Mobility. And that concludes round one. Now we move on to round two in our debate.

Round two is where the debaters address one another directly, and they take questions from me and from you in the audience. A reminder of where we are. We have two teams of two arguing for and against this motion: Income Inequality Impairs the American Dream of Upward Mobility. We have heard the team arguing for the motion, Elise Gould and Nick Hanauer say, you know, some inequality is built into the system, and some inequality is even a spur to innovation. But a point comes where it becomes too much, and it can actually kill the American dream. They talked about how low income families cannot invest in their kids' futures. That if you can't buy eyeglasses for the kid in school, then the kid's not going to do well in school, and his opportunity will be limited. They say, basically, using the image of a ladder, that if the rungs are spread farther apart than they ever have been before and the top is higher than it's ever been before that intuitively, it becomes much more difficult to climb, that the distance from the bottom to the top has become staggering.

The team arguing against the motion, Scott Winship and Ed Conard also acknowledge that there is a lot of-- also acknowledge that there is a lot of income inequality, but they say that is not the cause of a loss in upward mobility in the United States. They say compared to other nations where income is much flatter, that the United States has greater mobility. They cite a number of studies that have looked at this and have crunched the numbers, comparing income inequality with the mobility and they find that there is no meaningful relationship and that the downward pressure on wages in the United States, which they acknowledge is real, has other causes. But they say the success of the top earners in America is not to blame for America's problems. So, I found it interesting that Scott Winship, who is arguing against the motion, said that the motion as phrased, Income Inequality Impairs the American Dream of Upward Mobility, sounds intuitively correct, but is factually wrong.

And I want to go to Elise Gould who's arguing for the motion and-- and your opponent's point is that the studies show us something that's not intuitively correct. And you're the economist, and you're the one who knows the studies. And it's difficult to get into dueling studies, but does he have a point that the majority-- or the consensus, as he put it, of the studies, should that the numbers just aren't there?

### Conspiracy Advocate (CA)
Claim: Well, I think-- on the one hand, he's absolutely right, that the research is not conclusive, that mobility has declined. There is some research from people at the Chicago Fed--

### Conspiracy Advocate (CA)
Claim: That's right.

### Moderator
Claim: Well, she's not done quite yet.

### Moderator
Claim: I'm kidding. I'm kidding.

### Conspiracy Advocate (CA)
Claim: But I think that the argument that we've seen growing income inequality happen over the last generation, over the last 30 years, income inequality has gotten worse.

When we want to really measure this, we're kind of at a loss because we have to wait, we have to see what happens as those kids growing up in the most unequal times, what is going to happen with their outcomes, which is why I look at education, because that's what we can see today. We can look at those opportunities that lead to a realization of the American dream, and those opportunities are simply not there, and not there to an increasing extent.

### Moderator
Claim: Scott Winship.

### Scientific Advocate (SA)
Claim: Well, you hear this a lot I think as a sort of retreating move. When folks acknowledge that mobility has not fallen, you do hear this argument about, "Well, you know, we'll see it in today's generation," maybe. But I will say that the study that was done by Emmanuel Saez with Raj Chetty, who's a Harvard economist that won the award for the smartest economist under 40 with seven years to spare, they look at young adults. They look at people who are in their late 20s.

They measured the parental incomes in the mid-1990s. At that point they'd experienced rising income concentration. The share of income received by the top 1 percent had been rising at that point for 15 years, and it didn't show up in their results. So none of us can predict the future. We could have this debate again in 20 years. And if the evidence says that we did experience declining mobility, I will be as concerned about it as anyone.

### Moderator
Claim: And, Nick Hanauer, I mean, I don't want to dwell forever on these studies, but they are the evidence we have, and your partner has conceded that there at least is not a consensus on this. What do we do with studies that are done by serious economists who are respected, peer reviewed, who are telling us that they can't find evidence that your side of the motion is actually correct?

### Conspiracy Advocate (CA)
Claim: I think--

### Moderator
Claim: And everybody needs to-- yeah, if you mind, maybe just pulling your seat right into the - -

### Moderator
Claim: Yeah.

### Moderator
Claim: --because just for the radio audience, if you're that far away, they end up hearing you like this--

### Moderator
Claim: Yeah.

### Moderator
Claim: And it doesn't come across in the room, but it's for real. Nick Hanauer.

### Conspiracy Advocate (CA)
Claim: Yeah, so just because the industrialized nations have not been radically unequal enough to allow economists to do timescale studies to prove that it will be harmful doesn't mean it's not. And, in fact, if you look around the world, there are 205 countries running simultaneous experiments on how to create prosperous societies. And in every single case where you find radical inequality you find low social economic mobility around the world, right? This is not-- this is not a far-out concept. There is very low economic mobility in highly unequal places in every place that you look. And so, you know, the truth is that the United States has only been a highly unequal society for 10 to 20 years. Thirty years ago it was not that bad.

And so, the fact that you don't-- we haven't had the time to measure it doesn't tell you anything. Your common sense, on the other hand, should inform you highly.

### Moderator
Claim: Ed Conard.

### Scientific Advocate (SA)
Claim: Yeah, Nick is doing something that a lot of mobility scholars on the left try to do. They want to mix the results from high wage economies with low wage economies. And everybody serious in this field separates those apart. You have to look at them separately. And when you look at high wage economies, you simply don't find what Nick's saying. The second thing I'd ask is, "Well, when we think about going into the future--" we do know this about the future, if we look backwards at the past, things have gotten more prosperous over time. The amount of money that we transfer in this economy has grown from about 11 percent to about 14 percent today.

### Moderator
Claim: You used the term-- explain the term, "transfer"--

### Scientific Advocate (SA)
Claim: It's money that we take from one group of people in the economy and give to the other.

### Moderator
Claim: Through what devices?

### Scientific Advocate (SA)
Claim: Through taxation, government intervention.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: A lot of that goes to the elderly. But the CBOs look very carefully at the income that goes to the nonelderly families in the bottom 20 percent.

In 2006 when they did the study, it was $15,000. It doesn't include state transfers, which brings it up to closer to 20. It's grown with inflation since then. Today it is very close to about $25,000. Now, Nick, you've said it's $8,000. You look at another CBO study, it simply looks at the means tested piece of it, but there's many more pieces than the means tested piece, and there are other CBO studies that have looked very carefully at this. So, we do know this in the future, the amount of transfer that we are giving to people at the bottom of the income distribution is growing faster than the economy, is increasing over the time. It has gotten significant in size. We are doing a lot to try to help people at the bottom of the scale, and to increase their mobility. And as we go forward into the future, we're going to be doing even more and more. And what is driving that? The success of our economy is making that available. And there are studies – Dollar and Kraay for example.

They look at the bottom 20 percent across many different economies. What do they find? The bottom 20 percent is highly correlated--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --to median wage.

### Moderator
Claim: Let's--

### Scientific Advocate (SA)
Claim: The more it grows, the better the poor are.

### Moderator
Claim: Elise Gould, let's have you respond.

### Conspiracy Advocate (CA)
Claim: I mean, what we've seen if we look-- as you said-- we should look at other advanced economies. And I-- and as I said in my opening remarks, we have lower mobility than Denmark, Norway, Finland, Sweden, Japan, Spain, France-- a number of countries that are advanced economies. And you brought up some research about Miles Corak. And we're not going to debate Miles Corak this or Miles Corak that. But the paper that I cited earlier, that family background is twice as important in determining children's success in the U.S. as in Canada is also from a Miles Corak paper from this year. And he finds pronounced stickiness, particularly at the top and the bottom of the distribution, meaning that kids from high income families are far more likely to be high income. Kids from low income families are far more likely to be low income. Less stickiness, so much in the middle.

And I want to respond to one other thing that Ed said about transfers in resources. One thing you said in your opening comments-- you mentioned helping the working poor. The idea that we have working poor in this country is-- I just-- I think it just leaves such a bad taste in my mouth, that we have people that are hardworking, working full-time-- maybe full-year-- and they can't lift their families out of poverty. We absolutely need to think about--

### Moderator
Claim: Let me stop-- let me stop you--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: --and just-- and go to Ed, because the question was directed at you. And the last thing that Elise said goes to the point of our motion-- that they can't lift themselves out of poverty. But that would be the question of mobility. She paints a very compelling, again, intuitive picture of that. What's your response to that?

### Scientific Advocate (SA)
Claim: Well, I think there are many people who have a difficult time lifting themselves out of poverty. If you're sick, you're going to have a difficult time. If you have mental illness, drug addiction, many different things-- if you were convicted of a crime and you're an ex-convict, it's going to be difficult for you to lift yourself out of poverty. But there are many, many, many people who can lift themselves out of poverty.

Tens of millions of Hispanic immigrants have come across the border. They were making $2, $3 an hour. They're making $7 to $15 today. Many of them-- many more than that. And they have--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --lifted themselves out of poverty. But I would like--

### Moderator
Claim: No. Actually, I want to go back to-- I just wanted to have you-- an interruption to that point. And I want-- I will come back to you. Elise, I just want to come back to you with that question. All right. Conceding that some people can't lift themselves out of poverty, what does that have to do with people being very rich at the top?

### Conspiracy Advocate (CA)
Claim: Well let’s just say the pie hasn't gotten bigger. It hasn't gotten smaller from rising--

### Moderator
Claim: It's gotten much bigger.

### Conspiracy Advocate (CA)
Claim: --income inequality. Let's say the pie stays the same size. And if we know that a larger share of the pie is going to the top, that means that there's less there for everybody else. When there's less there for everybody else, there's fewer resources going particularly to the bottom-- is what we're going to talk about here-- particularly at the bottom, there's fewer resources.

And parents cannot afford to make those investments. Children are living in far more stressful home environments. Unemployment is more common. There's less stable housing. And all of those things provide a situation where children just do not have the same opportunities--

### Moderator
Claim: Okay. Scott Winship, in your opening statement, I think I heard you also agree with your opponents. While you were arguing against this motion, you agreed with them that there is a threat to opportunity. Did I heard you correctly in that?

### Scientific Advocate (SA)
Claim: You heard me correctly that I do agree that we have upward mobility that is too limited in the United States. So, the figures that I like to cite, if you are born in the bottom fifth, raised in the bottom fifth, you only have about a 30 to 40 percent chance of making it, either to the middle class or better than that. That's far too low in my book.

But it's-- it's a leap to say that the reason for that limited upward mobility is because of income inequality or because income inequality has risen. And I think that's the fundamental question today. I'm as concerned as anybody about how do we increase upward mobility rates. But I just think-- if you're talking about bang for your buck, focusing on-- on bringing the incomes at the top down, it's just not going to buy you much.

### Moderator
Claim: Okay. So, you're saying the problems are real, but the cause is not the fact that people like Nick Hanauer are making a lot of money. Nick Hanauer. You think it is?

### Conspiracy Advocate (CA)
Claim: Yeah. I-- no. No. I mean-- look, I mean, you misunderstand our point. I do not, for a moment, believe that the problem with the economy is that we have too much success and we should hinder it in some way.

I simply believe that it seems obvious that the most successful should pay into the pot enough so that we can generate the increasing-- the virtual cycle of increasing returns if capitalism can be. And there are a variety of things we have to do to close the inequality gap and to create more opportunity for people. It's certainly not discouraging success. But raising tax rates for private equity investors from the abomination of 15 percent to 39 does not discourage success. It simply allows-- it creates enough money to begin to help people who are struggling in their daily lives to actually have opportunity, to have a decent education, to have a decent place to live, to put food on the table, to lead a somewhat normal life.

You know, so these two things-- these are not-- we are not claiming that we need to eliminate success. We need more success. But the economy grows, the more successful people become. It's not driven by a couple of people at the top like me and Ed. It's driven by everyone else out there. And that's the point-- that's the economy. It's the dynamic interaction of buyers and sellers, not the bank accounts of the rich.

### Moderator
Claim: Ed Conard.

### Scientific Advocate (SA)
Claim: What's the question?

### Moderator
Claim: Oh, I thought you were-- you were like all riled up to respond to that.

### Scientific Advocate (SA)
Claim: No, no since gone.

### Moderator
Claim: Yeah? You're done? Okay.

### Scientific Advocate (SA)
Claim: I mean, I'll-- I'll respond to some of these comments if you like. I think--

### Moderator
Claim: No, I thought you were raring to, but--

### Scientific Advocate (SA)
Claim: Well, I'll go back to one point, which is take, for example, test prep that we've talked about and how much parents are preparing. There are two kinds of colleges. There's prestigious colleges which have a limited number of slots, and then there's other colleges which basically have an unlimited number of slots.

What's happened is that in the prestigious--

In the prestigious colleges, we have allocated more and more slots to lower income students and to minority students. And as a result, what you find is that rich white students are working harder and harder for a limited number of slots in the most prestigious schools. And so it's disingenuous to say that test prep is reducing mobility at a time when we're increasing the number of slots and trying to increase mobility. At the same time, at the low-- at the less prestigious schools, anybody who's capable of going, who takes the test and is able to get through the school, can go to those schools. There is no shortage of slots. We've increased the number of slots. We've increased the number of students participating in that. So, it would be unfair, for example, to say, "Gee, there's more and more rich students going to those schools than there are poor schools-- poor students today." Any student who can get there can get there. And we have spent more and more money trying to help people get as far as they can in life.

And we've tried to help those people at the bottom who are not able to pull themselves out of poverty. It's not as though we're letting those people starve to death. We are giving them a substantial amount of money to try to help them maintain some standard of living at that level. So, I think it's just difficult to make the argument that mobility is declining over time. We're doing everything we can to increase it.

### Moderator
Claim: Okay. Elise Gould, do you want to respond to that? Conceding-- I mean, giving that you're conceding that studies don't show that mobility is declining over time, but take on the point about education because you're talk-- you're sort of saying, let's look at the future, and let's look at-- let's look at the mechanisms in place and the trend and what seems inevitable and intuitive.

### Conspiracy Advocate (CA)
Claim: Yes. Thank you.

### Moderator
Claim: Wait. I'm not supposed to be doing-- putting words in your mouth like that so--

### Conspiracy Advocate (CA)
Claim: No, no, I'm going to--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --talk about what I'm planning on talking about today.

### Moderator
Claim: Very good.

### Conspiracy Advocate (CA)
Claim: You didn't feed me anything. I'm not so sure about there being infinite slots in all the other schools, but that's another question.

And test prep is really far more available to the higher income, so that's not really where I want to go either. I think the direction I want to go is inequality at the starting gate. And from that, I mean inequality at the beginning of kindergarten. These differences are found very early on. The differences in resources available to higher income children is far greater than available to lower income children. As I said before, higher rates of unemployment, instability, lower income, all of those things absolutely come at a cost to kids. And you see vast disparities, even the first day of kindergarten. And schools do their best to try to maintain--

### Moderator
Claim: But let me-- let me just stop you for a second because I'm just looking at the motion on the screen behind you. And you're saying that poverty causes these problems, and I think your opponents agree with that. But they're disagreeing--

### Conspiracy Advocate (CA)
Claim: Yep.

### Moderator
Claim: --with you that the fact that there's an-- that there is some very, very-- there's a top 1 percent that's way, way up at the ladder is at the root of these problems.

### Conspiracy Advocate (CA)
Claim: If--

### Moderator
Claim: So, that makes it impossible for-- that that's the fact that-- that's who the motion is, that that inequality makes it impossible for people to move out of that situation.

### Conspiracy Advocate (CA)
Claim: Right. I would argue that the growth in inequality has led to more poverty in this country as opposed to what the counter factual would be. So if we had had, let's say from the late '50s to the mid '70s, we had economic growth that was associated with falling poverty rates. If that relationship had continued, if, as the economy grew, we had broadly shared prosperity across the entire distribution, then we would have basically eradicated poverty by the 1980s. So, this is absolutely a discussion about the size of the pie, not just the size of the pie, but the distribution of those resources of the pie. And it's not just about the bottom.

If we were to look at what happened to middle income families, and my research shows that if you were to look at sort of the wedge that's created by this growing inequality, that the typical family today would be making 18,000 more dollars in just one year. Those are substantial resources that American families could put a lot more energy into investments in their children.

### Moderator
Claim: Okay. So take it to you, Scott Winship. What I think I hear Elise saying is, it's not-- the relevant issue is not that there are a lot of people that are very rich, it's that there are a lot of people that are very poor, that that level of inequality, those depths are very, very difficult to move out of and therefore there is immobility at that-- at that level.

### Scientific Advocate (SA)
Claim: Well, I think poverty is too high in America. But it's lower than-- quite a bit lower than it was in the 196--

### Moderator
Claim: But how escapable is it?

### Scientific Advocate (SA)
Claim: I'm sorry?

### Moderator
Claim: How escapable is it?

### Scientific Advocate (SA)
Claim: It's probably-- you know, I am fortunate enough not to have grown up poor, I'm guessing it's still very difficult to escape. I mean, the bottom line is if you-- if you start in the bottom, you have something like a 40 to 50 percent chance that you're going to stay in the bottom as an adult.

But the question on the table, I think, is whether income inequality is behind that. And I think the evidence just isn't there. So one reason I think that you might worry about rising inequality is if the attainments of the poor were actually getting worse. But that's generally not what you find. Test scores have risen among the poor. College graduation has risen among the poor. The problem is that in a lot of cases it's risen faster at the top. But it's a very different situation than I think the depiction that as income inequality has risen, it's sort of been just this-- this brutal shift for people at the bottom. I think it's always been tough to be poor, but I don't think it's tougher today because the top 1 percent share has gone from a very high 10 percent to an even higher 24 percent.

### Moderator
Claim: Nick Hanauer, you-- you've heard your opponents say, to some degree, that the pie is bigger because of the people who are successful at the top.

And in your opening remarks, you made the argument that that just doesn't make sense. But can you elaborate a little bit now that they've made more of a point, that their hard work, ingenuity, investment, risk taking actually causes-- you know, actually grows the pie overall.

### Conspiracy Advocate (CA)
Claim: We're in violent agreement about that our economy benefits massively from very clever and very hard working people taking risks and innovating. That's not the question. The question is, should only a few percent of us be able to do that. And the answer to that is categorically no. I mean, look, here's the way to connect these two things. Why are the rich getting richer and the poor getting poorer? Well, here's a reason, because over the last 40 years, the percent of profits that American corporations generate as a percentage of GDP, has gone from 6 to 12 percent.

At the same time, the percent of GDP devoted to labor has gone from 52 to 42. So that difference is about a trillion dollars annually. So that-- here's the thing you have to understand. That trillion dollars isn't profit because it needs to be or should be or has to be. It's profit because powerful people like me and Ed prefer it to be. That trillion dollars could very easily be spent on wages. Or on discounts for consumers. This isn't a consequence of some magical law of economics. This is a consequence of differentials in power.

And the thing is-- the thing is, is that if that trillion dollars was, instead of stuck in my bank account and Ed's bank account, but instead was coursing through the economy as wages and opportunity, we'd have more innovators, we'd have more risk-takers. That's the beautiful thing about capitalism. If you set it up right, it works super well.

### Moderator
Claim: All right. Ed Conard.

### Scientific Advocate (SA)
Claim: I do think there's a popular argument which is, "Investment waits for demand, and if we don't get the customer demand, we won't get the investment." But it isn't true. Investment doesn't wait for demand. Apple will create an iPhone, and Samsung will come up with a competition, and Microsoft will scramble to fix their problem. There's a lot of turn of the economy-- and there's a lot of investment in the economy. And the people who are generating that investment-- the money that Nick's saving which is funding those investments causes a lot of other consumption in our economy and puts a lot of other people to work. And so what these guys have done, because their argument isn't stronger, they retreat to a mathematical truth, which is this, "If the pie stays the same and we split it up different, people would have $18,000 more money."Germany, France, Japan, they've all tried it, they all distribute income more equally, and they are not able to achieve the median incomes that we achieve in the United States. And why is that? Because there's another economic truth that they don't want to admit to which is you have to get a customer to pay somebody $18,000 more a year to buy the product to pay them that. And if you can't do that, all the mathematical splitting of the world won't solve your problem.

### Moderator
Claim: All right. I want to go to some questions and answers now from the audience. And the way this will work, if you raise your hand, I'll call upon you. And the microphone will be brought down to you. The same thing, hold the mike close to your mouth so that the podcast and livestream the radio can hear you. And tell us your name, and then come out with the question. Ma'am, right here, if you can stand up, too, thanks.

### Moderator
Claim: Thanks.

### Moderator
Claim: Oh, no, I'm sorry, I gave the high sign to your neighbor.

### Moderator
Claim: Oh.

### Moderator
Claim: I'm sorry. Awkward.

### Moderator
Claim: Hi, good evening. I'm a teacher.

### Moderator
Claim: Can you-- a little bit closer.

### Moderator
Claim: I'm a teacher.

### Moderator
Claim: So, I just want to set a premise and then address something that was said in the-- with a question. These days the lower income children can't--

### Moderator
Claim: Ma'am, I can't let you make a speech.

### Moderator
Claim: Okay.

### Moderator
Claim: Please go to the question.

### Moderator
Claim: All right. So the question is if the children from lower income families can't afford the investment in the programs that are necessary in order to achieve the grades necessary to go to college, it's not an issue of the money getting into the school, because, yes, they're giving it away, but if they can't--

### Moderator
Claim: Ma'am, I need you to get to a question.

### Moderator
Claim: --the question is how can they compete to get into these schools if they don't have the knowledge necessary because they can't buy it the way that the wealthier families can?

### Moderator
Claim: I'm going to pass on your-- I think it's a fair question-- I'm going to pass on it, because I want to have questions that go to the nature of this motion, which is the impact of the wide-- the height of the ladder and its impact on upward mobility. And I do think we addressed to some degree the education question in remarks made by Elise Gould, but thanks very much. Sir. And I say that with respect.

### Moderator
Claim: Yes.

### Moderator
Claim: Thank you.

### Moderator
Claim: All right, you're you won, okay.

### Moderator
Claim: Okay. I would just like to ask the gentleman on the right how they can compare income mobility in the United States with income mobility in Europe? Very, very briefly, my daughter and son-in-law--

### Moderator
Claim: You know what? I'm--

### Moderator
Claim: No, okay. okay.

### Moderator
Claim: You had a question mark after the seventh word, and we're getting--

### Moderator
Claim: the reason for my question-- no, I do have--

### Moderator
Claim: No, no, I'm sorry, ma'am, I can't let you, because we just don't have time. But how about that question? How can you compare rates in the United States with rates in Europe meaningfully?

### Scientific Advocate (SA)
Claim: Sure, well--

### Moderator
Claim: Scott Winship. Thank you.

### Scientific Advocate (SA)
Claim: --you know, I think the real key is that you look at the positions where kids start out and the positions where they end up. And that's why for so long the conventional wisdom was, as Elise said, that the U.S. had such worse mobility than other countries because it didn't actually look at that if it was a measure that showed worse mobility when inequality rose mechanically. And so that was the innovation of Miles Corak's newest paper, where he looks at ranks of parents, ranks of kids. The other paper that you cited by him was older. I actually commissioned it while I was at Pew.

### Moderator
Claim: Elise, do you want to respond to that or we can move on if you want to. We'll move on? Okay, and then I'm going to come to this side. Sir, yes,

### Moderator
Claim: Hi, my name's Hans I'm just going to add chickens and eggs into ladders and pies. Can you tell me why wages versus employment-- is it the chicken and egg argument, 40 years ago, why people would have chosen for higher rates of employment versus higher wages? Why isn't it just one before the other?

### Moderator
Claim: Edward Conard. And Ed, if you can move in, too.

### Scientific Advocate (SA)
Claim: I'm not sure I understand what you mean by chosen. I think what ends up happening is if you have a restricted supply of labor and you get growth, you'll get higher wages. And if you have an unrestricted supply of labor, you'll get higher employment. It's-- and you'll get a little bit of both. Where you end, I mean, I suppose it's Newton's Third Law of Momentum, how much of it ends up in employment and how much of it ends up in wages? But some of that has to do with real natural restrictions in the physical world. I you don't have the employees, then you're going to get the wage growth as there's more and more demand for that labor. If you have an unrestricted supply, you're going to get faster employment growth. We got two-- three times faster employment growth than Japan, twice as fast the employment growth of Germany and France, the two big economies in Europe. We have even faster growth from most of the other economies in Europe. We can find Norway or something like that, with oil, which can be slightly different, but it's not that much different.

### Moderator
Claim: Elise Gould.

### Conspiracy Advocate (CA)
Claim: To answer your question, I think that Ed is maybe oversimplifying a little bit.

We have seen employment growth and we haven't seen wage growth. But we have a period in recent history-- in the late '90s-- when we saw strong wage growth. We saw a tighter economy. We saw higher employment. We saw, arguably, full employment. And that meant that wages across the entire wage distribution actually rose. And we saw that everywhere, and we actually saw stronger growth at the bottom than anywhere else. And so, I think you can see higher employment. You can also see higher wages. It's not-- it's not-- I don't want to oversimplify that.

### Conspiracy Advocate (CA)
Claim: Yeah. I would just like to add--

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: --that, you know, the fundamental of capitalism is when workers have more money, businesses have more customers, and need more workers. That's what-- why the role of policy is to solve the collective action system-- a collective action problem and push wages up for all workers, because when you do, it's good for business and for workers.

### Moderator
Claim: Scott Winship.

### Scientific Advocate (SA)
Claim: Just to address-- I want to agree with Elise, again, that the 1950s and 60s were this amazing period for the poor.

And the middle class incomes grew more than they did at the top. But again, I think-- it's a leap to argue that the reason we have that-- that period was because inequality was low. The slowdown in incomes at the bottom and in the middle class started in the 1970s, a full decade before income concentration began rising at the top.

### Moderator
Claim: Let's go to another question. Right down front here.

### Moderator
Claim: Hi, I'm Mike. I was expecting to hear the against side arguing a lacking relationship between the two, between inequality and upward mobility. Instead, I kind of heard you guys suggesting that inequality can drive upward mobility. So, I'm wondering if you would advocate active and systemic mechanisms to do just that, to increase inequality as a tough love mechanism – to help the poor.

### Moderator
Claim: That's about the best question we've had in about a year. Edward Conard.

### Scientific Advocate (SA)
Claim: I think that customers decide how much people get paid, how much they're willing to pay for products and for employees and such. And so, anything that gets in the way slows growth. It doesn't increase growth. And so, no. I would be against any policy that tried to artificially do what customers don't want. What customers want will improve the success of our-- of our economy. I would also remind Elise that in the 1990s, we commercialized the Internet and e-mail. It was like the telephone. We had enormous growth in the 1990s as a result, faster than the supply of labor, and it drove up the wages. If we can find another one of those, we'll have great-- we'll have great growth.

### Moderator
Claim: Elise Gould.

### Conspiracy Advocate (CA)
Claim: I don't think customers decide.

I think we're-- you know, we're talking about how we're splitting, how much of the profits come in, and we've seen record-high profits-- I don't think customers decided that CEO to the average worker pay should go from 30 to one 30 years ago to almost 300 to one today.

### Moderator
Claim: Another question? Ma'am, right in the middle there.

### Moderator
Claim: Thank you. Good evening. I'm Lilly. I'm a senior in high school, so I get what you're saying about all the not

### Moderator
Claim: Sorry for the ma’am.

### Moderator
Claim: My questions to both cons and the pro sides-- pro side--

### Moderator
Claim: I need you to pick one.

### Moderator
Claim: Just one?

### Moderator
Claim: Yes. Everybody gets one question, and it's 30 seconds long, and we're 18 seconds in already.

### Moderator
Claim: Okay. Do you have any ideas or solutions to either increase the upward mobility or just to--

### Moderator
Claim: I'm going to pass again because we're not debating what the solutions are.

Fair question, and we may do a debate on it at some point. Sir, in the corner there.

### Moderator
Claim: My name is Ben. For the for side, I would assume that the argument is not that if we lock Nick and Ed up that mobility would increase and that instead it involves transfers of wealth to others. And my question, if that is part of your solution, is transferring income from one group to others really consistent with your definition of the American dream of upward mobility.

### Conspiracy Advocate (CA)
Claim: Oh, that's a great--

### Moderator
Claim: Nick Hanauer.

### Conspiracy Advocate (CA)
Claim: Yeah. So-- so transfers are a very small part of the solution here. Requiring businesses to pay workers a living wage is not a transfer. That's solving a collective action problem. Requiring businesses to pay middle class employees overtime is not a transfer. It's a fairness and collective action problem.

And there are all sorts of ways that everyone benefits when every business pays its workers more, including every business, right? Because when every business pays its workers a decent wage, every business has more customers and every taxpayer is spared the expense of sending their tax dollars to the government to pay for the food stamps that low-wage workers require. So it has less to do with transfers than other things.

### Moderator
Claim: Okay. I want to remind you that we are in the question-and-answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. And we have four debaters, two against two, debating this motion: Income Inequality Impairs the American Dream of Upward Mobility. More questions, right down front, sir. And this front row.

### Moderator
Claim: Hi. What about the aspirational aspect of the-- of the spread, the inequality spread.

In "Freakonomics," Steven Dubnner talked about the drug dealers and how many people were in that trade because there was a chance that they might be able to get to the very top. And if the top is getting higher, is that becoming more aspirational and potentially improving mobility?

### Moderator
Claim: Does the top rung really give you something to shoot for? Okay. That's a really interesting question. Let's take it to Ed Conard. Would you like to take that, or your partner?

### Scientific Advocate (SA)
Claim: Yes. I think that innovation is like any game of chance; the higher the payoff, the more risk people will take. And so what we have seen in our economy is that as we've raised the bar for success, our most capable people at the highest end, or our highest earning people have worked harder and harder, more and more hours than the rest of the world and have taken more and more entrepreneurial risk and produced way more innovation than the rest of the world has. And ultimately, that's translated into a much higher growth rate. And so we do keep raising the bar. And it's not really the bar for money. That's not what motivates people. It's the status that goes along with it.

And as the bar gets raised, you have to achieve more and more to get to the same level of status. And that drives our most talented people to work harder and harder and take more risks. And that is what everybody else needs from the most talented people. We need those people working hard. And in America, we've been able to achieve that. And the failure of Europe and Japan to duplicate our success shows how difficult it is to motivate the most talented people, to get the training that really grows the economy, to put in the hours that really grows the economy and to take the entrepreneurial risk of which 99 percent of them, more than 99 percent of them, will fail, and they'll be set back in their careers as a as a result, which is not to say these talented people won't have a career. They'll have a career. But if they spend 10 years in the garage trying to do something, and then they go back to their career, they'll be behind where everybody else was.

### Moderator
Claim: Nick Hanauer.

### Scientific Advocate (SA)
Claim: And that's what we need to do to get our economy to grow and to get more people employed at higher wages.

### Moderator
Claim: Nick Hanauer.

### Conspiracy Advocate (CA)
Claim: So quick audience poll with your hands, not the buttons: Who thinks they work harder than their parents?

### Moderator
Claim: You need to tell the radio audience what you're seeing.

### Conspiracy Advocate (CA)
Claim: Two-thirds of the room. Do you-- do you think you work harder than your parents because your tax rates are lower than theirs? I don't think so. I don't think so. So hard work is-- is an extremely important thing, but it is completely uncorrelated to the tax rates we pay. That's the first point. And the second thing is-- and this is the most difficult thing to talk about when we talk about upward mobility and the American dream and inequality. And that is this: That humans are status seeking creatures. We are not optimizing for money. We are optimizing for sort of social position.

And when you go from a world where to fly first class is to be affluent, wealthy, to a world where you have to have a $25 million Falcon 2000 to be affluent, to live large, you have stretched the society apart in a way that means that 99.999 percent of the people in the society cannot live the good life. And I would argue--

### Moderator
Claim: You don't think that people will aspire to that? You think they'll be turned off by it.

### Conspiracy Advocate (CA)
Claim: I don't think that they will aspire one iota more in the second scenario than the first. It's just that in the second scenario, 99.999 percent of you fail. And I would argue that having a society that is an arms race, that is structured to be an arms race, that no one except me and maybe a couple other people in the audience, can possibly win, is a winning solution to building a good society.

### Moderator
Claim: Scott Winship.

### Scientific Advocate (SA)
Claim: I think it's a little bit disingenuous to take a poll and say that tax rates don't affect work. I mean, the argument that smart people on the left that I know make about why inequality at the top has risen is because of the Reagan tax cuts, right? The Reagan tax cuts-- this is the argument from the left-- increased the rewards to bargaining. So I don't agree with this diagnosis. But the left says, because tax cuts went down, it became more advantageous for people at the top to bargain, to take risk, to work more, and that's why income concentration has risen. So, it's certainly not a foolish idea in economics if you ask any finance-- public finance person in economics.

### Scientific Advocate (SA)
Claim: I would also say this: Ask the 50 million adult immigrants and their children whether or not they benefited from this arms race or they were hurt by this arms race.

He talks like a rich man, okay? A poor guy benefits from the fact that we are working our tails over and taking the entrepreneurial risks and grow the economy and increase prosperity. Rich guys walk around and say, "Wouldn't it be wonderful if we didn't have an arms race, and I didn't have to have my, whatever it was, Falcon something in order to be successful?" We need you to be working your tail off. It's the poor people that need you to be working your tail off.

### Conspiracy Advocate (CA)
Claim: The poor people are working their tails off.

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: I didn't say-- I didn't say they weren't. But in Europe and Japan, they have not been able to produce the innovation and the growth and the employment that the U.S. economy has. It is two to three times faster. It's an extraordinary difference.

### Moderator
Claim: Do we have time for one more question? We've been a little short on females tonight. There you are. Make it really good because I just put this whole burden on you.

### Moderator
Claim: Okay. Well, I'm actually going to come from people on the left. So, for example, you mentioned the CEO pay ratio.

I don't see how you can compare an economy that was completely manufacturing based to an economy that is information based and globalized. It just makes sense if you're competing on a globalized scale that the pay-- the ratio scale would change as well.

### Moderator
Claim: Okay.

### Moderator
Claim: And you said that the rich are getting richer, but the poor are getting poorer.

### Moderator
Claim: Wait, wait, wait, wait. I need you to put a question or a little up speak at the end of it.

### Moderator
Claim: Okay. Sorry. But if the rich are getting richer and the poor are getting poorer, then why has our poverty rate declined once you include all the transfers that have been made and all that has been done? I think it is--

### Moderator
Claim: Okay, okay. That was our question.

### Conspiracy Advocate (CA)
Claim: Let me address--

### Moderator
Claim: Nick Hanauer.

### Conspiracy Advocate (CA)
Claim: --this CEO pay first. So our companies are not more information based or more globalized than multinational big companies from around the world. But the CEO pay in the United States, which expanded tenfold, that's not true in Norway. It's not true in Australia. It's not true in Canada. It's not true in Germany or Japan.

They did not need to do that in order to run their companies. And I think that that's why, when you look at the mobility data, it's much higher in all of those places.

### Moderator
Claim: Ed Conard.

### Scientific Advocate (SA)
Claim: If you look at the CEO pay in the U.S., it has not risen relative to the .1 percent. The .1-- and 90-- 90 percent of the people in the .1 percent can't go to their board and ask for a pay raise. They have to go to a customer and get them to buy something that will allow them to earn more money. That is not the case –

### Moderator
Claim: Up, up, nope, that's--

### Scientific Advocate (SA)
Claim: They're a lawyer, they're a doctor, they're whatever their who has to go and increase the revenues of their business in order to get a pay raise. Now, what's happened is they've been much more successful in the United States than they have been in other countries. And so as a result, the .1 percent in Sweden is much lower than the income than the .1 percent in the United States. And therefore, it's cheaper to hire a CEO in Sweden than it is in the United States.

And if you want somebody who's in that high level of capability to run your company. That's the cost in the United States because of the alternatives that we have been able to create at the highest end of our wage scale.

### Moderator
Claim: Elise Gould, did you want to respond?

### Conspiracy Advocate (CA)
Claim: Yeah, to the second part of your question, yes, transfers, absolutely, if you take transfers into account, we can reduce poverty using transfers. And we can show that with the data absolutely. And Social Security is the number one way that we have transferred income to the elderly and reduced poverty among the elderly. But I think that we want to do better. I think we should look-- if we look at wage-based poverty rates-- if we look at wage-based poverty rates they have actually gone up. So the rewards to hard work, and you talk about working long hours, the only reason why people at the bottom have seen any increase in their annual earnings is because of how many more hours those households are working, and they are working really hard to make ends meet.

### Moderator
Claim: All right, I'm going to-- we have time for one more question. Sir?

### Moderator
Claim: I don't want to get-- my name is Byron-- I'd like to get a piece of the trillion dollars that Nick is talking about. It seems to me that when you apply for a job they offer you a salary, and if it's enough you take the job. Now, what you're saying is that if the system were as you describe it that I would-- and I'm-- I accept $40,000 as the wage that I'm willing to work for, and if you're saying that in-- if you're going to divvy up an extra trillion dollars, even though I'm willing to go to work for $40,000, you'll pay me $50,000, is that the way you think the system will work? And if you do it your way--

### Moderator
Claim: All right, that was a question. Nick Hanauer.

### Moderator
Claim: --- the borders, believe me, will be mowed down.

### Conspiracy Advocate (CA)
Claim: Yeah, I don't-- I don't think that's a fair way of characterizing it, that the extra trillion dollars is profit because corporations have more power today than workers.

It once wasn't true. We had unions, and we had even better labor standards than we have today, and those have eroded. Again, the only difference, it's not an economic difference, it's simply a power difference. And the question becomes, "What kind of a country do you want to have? Do you want to have a country where a few people earn everything and most people earn nothing or do you want to have a country where most people do pretty well and everybody lives a life that includes upward mobility? And my argument is that we generally should prefer the latter, and that is within the scope of our choice we can do that by using policy and politics to advance a commonsense agenda.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. Debate-- where our motion is ""Income inequality impairs the American dream of upward mobility."And remember how you voted just before the debate began. Immediately after closing statements, which are about to begin, we'll have you vote a second time. And I just want to remind you about our rules. It's the team whose numbers have moved the most in percentage point terms that will be declared our winner. On to round three, closing statements from each debater in turn. They will be two minutes each. Here to summarize her position in support of the motion, "Income inequality impairs the American dream of upward mobility," Elise Gould, senior economist and director of health policy research at the Economic Policy Institute.

### Conspiracy Advocate (CA)
Claim: Thank you. One of the most profound pieces of research that I've encountered in my tenure as a professional economist came from an interdisciplinary group of researchers. They examined the brains of hundreds of young children from various economic backgrounds, beginning at birth and following them every few months until four years of age.

And what they found is that children in poor families lagged behind the development of the frontal regions of the brain, deficits that help explain behavioral, learning, and attention problems more common among disadvantaged children. What's striking is that the brains of the infants looked really similar. You didn't see those differences at birth. You start seeing the separation in brain growth between the children living in poverty and the more affluent children increase over time. And that really implicates the environment in which they live. It boiled down to an elevated fight or flight response from living in a more stressful home environment, which makes them less able to learn and succeed in school. The researchers do note that these children are not doomed. With the right investments, we can survive-- they can survive and contribute to society to the fullest extent. Without that, they are really wasted resources. It's no surprise that families’ economic situation and particularly low levels of economic stability can wreak havoc on children's wellbeing and their success later in life.

While the mobility research has a few years to catch up as the children born in the most unequal times grow up-- the pathways are clear. The evidence is there in black in white in those brain scans. The truth is that income-- increasing incomes for those families at the bottom of the income distribution have extraordinary consequences for children's health, educational attainment, and future earnings. It's not only well-founded, it's common sense. If the economy had delivered jobs and growing wages to all those wanting to work and work hard, children across the income distribution would have a much better chance of succeeding and attaining the American Dream. Luckily, there are steps we can take to reduce this trend, but let's not deny the facts. Vote for increased opportunity. Vote for the proposition.

### Moderator
Claim: Thank you, Elise Gould. And our proposition is Income Inequality Impairs the American Dream of Upward Mobility. And here to summarize his position against this motion, Scott Winship, the Walter B. Wriston fellow at the Manhattan Institute.

### Scientific Advocate (SA)
Claim: Well, thanks, John. As you heard John say at the beginning of the debate, Nick recently tried to convince his fellow zillionaires that income inequality has risen so much that they should fear for their safety. So, I'll just quote: "You show me a highly unequal society, and I'll show you a police state, or an uprising. There are no counter-examples. None. It's not if. It's when." But I can think of one example. It comes from Emmanuel Saez-- we cited before. Saez tells us that the top one percent in Manhattan-- top one percent of parents-- receive 54 percent of the income of all parents on this island, more than double the national figure. That's also much higher than in King County, Washington, home to Seattle and to Nick Hanauer. In King County, the top receives 25 percent of parental income. But the Saez data indicates that in Manhattan, low income children, those poorer than 75 percent of kids, typically, as adults, end up poorer than 59 percent of their peers-- as late 20 somethings.

That's far too high. But how high do poor children rise in King County? They typically end up poorer than 73 percent of their peers. They end up right where they started out. The issue tonight isn't whether poverty is a problem or whether lack of upward mobility is a problem. As we've discussed tonight, there's a lot of consensus about both of those questions. The question tonight is whether rising income inequality caused those problems, whether we would reduce them by reducing income inequality. And as I've argued tonight, the evidence is just not there, as much as we might care about the poor and those who are stuck at the bottom. So, I urge you tonight to oppose the motion on the table-- income inequality has not impaired the American Dream of upward mobility.

### Moderator
Claim: Thank you, Scott Winship. And that's the motion: Income Inequality Impairs the American Dream of Upward Mobility. And here to summarize his position in support of this motion, Nick Hanauer. He is cofounder and partner at the venture capital firm, Second Avenue Partners.

### Conspiracy Advocate (CA)
Claim: Thank you. Scott, I acknowledge that in some ways, economic inequality and mobility may not be as bad as some of the data suggests. But I equally insist that in many ways, it is likely far worse than the data shows. And Ed, people do, of course, need theoretical incentives. But even more, they need practical opportunity. For all of human history, wherever you have found concentrated wealth, you find its defenders and its apologists, the deniers. The people who put lead in paint denied it was harmful. The people who made cigarettes denied they gave us cancer. The fossil fuel industry today denies global warming.

The packaged food industry denies that sugary soft drinks have anything to do with our epidemic of childhood obesity and diabetes, and how could we not have inequality deniers? Like clockwork, they will tell you it's not happening, or if it is, it's really, really good for the economy and for the middle class in mobility. Inequality tonight is being sold like high fructose corn syrup. "Yummy. Have some more." Really? Really? So, we should ignore the facts and the drowning feeling a majority of middle income Americans are experiencing today, as they watch the American Dream recede? Our answer to them to be-- should-- our answer to them should be, "Hey, you just need to look at the data differently. We should believe that the young men in Ferguson, Missouri elected not to become software engineers or partners at Bain because the theoretical incentives to take risk were not high enough."Elise and I do not believe that, and we hope that you don't either. You don't need a PhD in economics to see that extreme and rising inequality isn't just impairing the American dream of upward mobility. Inequality is drowning it.

### Moderator
Claim: Thank you, Nick Hanauer. Your time is up. Thank you.

Our motion, Income Inequality Impairs the American Dream of Upward Mobility. And here to summarize his position against this position, Ed Conard, a visiting scholar at the American Enterprise Institute and former partner at Bain Capital.

### Scientific Advocate (SA)
Claim: Germany is the second most prosperous major economy in the world. In Germany, the 99 percent earns 47 percent of GDP. In the United States, the 99 percent earns 47 percent of GDP. And that's 47 percent of a faster growing economy with median incomes that are 20 percent higher. With America's 1 percent earning a larger share of GDP than their counterparts in Germany, how can it be the case that the 99 percent in both countries earn the same share of GDP.

Relative to Germany, the additional share earned by America's 1 percent comes entirely from the investors' share of GDP, not the share earned by the 99 percent. So for those of you who continue to believe that the economy is a pie, please recognize that the larger share of America's 1 percent comes entirely from investors and not the 99 percent. With valuable on-the-job training at companies like Google, and access to networks of experts like Silicone Valley, the productivity of America's top earnings-- earners is higher than the rest of the world. And given these advantages, it should come as no surprise that America's 1 percent creates a greater share of GDP relative to investors than their counterparts elsewhere. And given this advantage, it should come as no surprise that the returns to college education are significantly higher in the United States than they are in any country in the world.

Ultimately, this debate boils down to whether the outside success of America's talent is an asset or a liability for the rest of the country. By every measure, employment growth, median incomes, return to education and opportunities for immigration, the U.S. provides more upward mobility than any other economy, even ultimate liberal Emmanuel Saez agrees. Mobility has not declined. And even if you believe that we ought to tax the rich more, it does not change the fact that the success of America's top earners do not impair the American dream of upward mobility. They improve it. Please vote against the motion.

### Moderator
Claim: Thank you, Ed Conard.

And that concludes round three of this Intelligence Squared U.S. debate.

And now it is time to learn which side has argued the best. We're going to ask you again to go to the key pads at your seats and have you vote a second time.

Just as before, push number one if you are in support of the motion, income inequality impairs the American dream of upward mobility. Push number two if you come out against this. Push number three if you remain or became undecided. And we will have the results in about a minute and a half and declare our winner. Before we do that, I want to say it was a-- it was a relatively complex topic. The motion itself has several moving parts, and I think debaters dealt with that really well and intelligently and in a spirit of respect for one another. So, I want to congratulate them for the way they did this.

A second thing I want to say, because of the complexity of the topic, I don't usually throw as many questions as I did tonight. And I just want to say to the people whose questions I threw out, there is no disgrace or dishonor in that. This is a topic where you can go off in a lot of different directions. And to the 18-year-old high school student, I really hate not taking your question from a high school student.

We did a debate two years ago where the motion was "The Rich are Taxed Enough," which really went to some of the issues that I think people wanted to get to tonight. And it's on our-- it's available through our app actually, as all of our debates are, which you can get from Apple store and from the Google store. I also want to thank-- take a moment and thank all of our generous supporters who have made these debates possible. The ticket sales do not by any means come close to covering the cost of these debates. So thank you to all of them and we encourage everybody else who is willing to make a visit to our website at iq2us.org and make a donation because every-- every gift counts for us. So thank you to those who are here who have been our contributors.

Our next debate will be here at the Kaufman Center on Thursday, November 13th. The motion will be, on November 13th, Legalize Assisted Suicide.

For the motion, we have Peter Singer. He's a professor of bioethics at Princeton University, often described as the world's most important living, influential living philosopher. His partner will be Andrew Solomon. He's an award-winning author who has written about his own mother's assisted suicide. Against the motion, we have Baroness Finlay who is-- she's a palliative care physician whose own mother considered assisted suicide, did not, and came to regain her full desire for life, so a very powerful personal anecdote in that; and Dr. Daniel Sulmasy who is a professor of medicine and ethics at the Department of Medicine and the Divinity School at the University of Chicago. Tickets are available at our website at iq2us.org. And as I mentioned, we have the app. You can look at all of our debates are available there. We live stream on our website at iq2us and listen-- you can listen to all these debates on NPR stations across the nation. Okay. So, it's all in now.

I have the final results and recall that the way we determine victory here is the team whose numbers have changed the most between your two votes in our live audience here in New York, in percentage point terms. So, let's see what the results are. The motion was this: Income Inequality Impairs the American Dream of Upward Mobility. Before the debate, 60 percent agreed with this motion. 14 percent were against. 26 percent were undecided. So, those are the first results. Again, it's the difference between the first and second vote. Let's look at the second vote. The team arguing for the motion, Income Inequality Impairs the American Dream of Upward Mobility, their second vote was 53 percent. They went from 60 percent down 7 percentage points to 53 percent. Let's look at the team against the motion. Their first vote was 14 percent. Their second vote, 37 percent. They went up 23 percentage points. That's enough for victory by far. The team arguing against the motion, Income Inequality Impairs the American Dream of Upward Mobility, is our winner. Our congratulations to them.

Thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
