# Debate Transcript

Topic: Cutting the Pentagon's Budget is a Gift To Our Enemies
Motion: Cutting the Pentagon's Budget is a Gift To Our Enemies

Debate ID: 061913%20pentagon%20budget


## Round 1

### Moderator
Claim: So we are, as I said before, delighted for the first time ever for Intelligence Squared U.S. to be partnering with the McCain Institute for International Leadership. We started talking about this months ago. We worked through a lot of topics. We found out-- we came to the conclusion that this was the one that was really going to be the one that fit both our sets of values and agendas for the kinds of things that we need to be out there in the public discourse. And for that reason, at this point, I would like to bring to the stage, representing the McCain Institute, Ambassador Kurt Volker. Let's welcome him to the stage.

### Moderator
Claim: Thank you very much. As you heard, my name is Kurt Volker. I'm the executive director of the McCain Institute. We are a part of Arizona State University, and this event is not only on radio but being live streamed back to Arizona, watched by students there on ASU TV, among other things. One of the missions that the McCain Institute set for itself as we established ourselves over a year ago was to bring back a culture of reasoned structured debate about the core challenges facing our country. We embarked on a series of debates. One on Syria, should we intervene or not; one on Afghanistan, should we be getting out or not; what do we do about Iran? And this was the first time that we are partnering with Intelligence Squared. And we are delighted to be able to do so. It should be a very lively debate about a critical issue that is, again, facing our country: What do we do about our defense budget? We'll be doing more of these in the fall as well. Senator McCain wishes that he could be here for this debate at the beginning, but as you may know they’re dealing with immigration issues on Capitol Hill this evening, and so he’s over there for that. We do hope that he would be able to join and say a few words by the end. With that, I want to turn it back to our Intelligence Squared organizers and thank you all very much for coming.

### Moderator
Claim: Thank you, and normally what we do in New York at this point is I invite to this stage the person who brought Intelligence Squared US to New York and increasingly to the nation, and he helps frame what’s a hit for us in terms of the debate and the timing, why we’re going to this topic now. So I would like to welcome to the state, warmly, Mr. Robert Rosenkranz. So, Bob, we've been around the country in the past year. We've been to Chicago, we've been to Aspen. A lot of the time we're in New York City. We're back in Washington for the second time this year. I just want to very briefly touch on the notion of bringing to this process the kind of very structured debate with rules and rounds and timing and a winner and a loser. What does that bring to the discourse?

### Moderator
Claim: Well, I think the point, really, is that the debaters are forced to listen to the arguments on both sides. They're forced to respond in real time to challenges. They're forced to respond to facts that either support or undercut their positions. And they're trying to persuade an open-minded audience to change their minds. So in many ways, it's reminiscent of the debates on the floors of Congress.

### Moderator
Claim: Exactly like the debates on the floors of Congress. So let's talk a little bit about this debate that we're having right now in this era of mandatory cuts coming for the Pentagon budget. The team that's arguing for this motion-- and the "for" side is saying that the cuts really are a threat to national security, or a gift to our enemies, as we're putting it. What do they have going for them in this argument?

### Moderator
Claim: Well, I think what they have going for them is the fact that we live in a very dangerous world. We live in a world where we're facing a much more assertive China. We live in a world where radical Islam seems to be in the ascendancy, and many countries in the Middle East. We live in a world where a lot of people who really wish us ill are trying to get their hands on nuclear weapons and other weapons of mass destruction. So we're in a very dangerous environment, and we need a very strong defense in order to be secure at home and exercise leadership abroad.

### Moderator
Claim: And the team on the other side?

### Moderator
Claim: Team on the other side will say, well, even with these cuts, we are spending more than, I think, the next 13 countries combined on national defense. And that there is a lot of waste and inefficiency in the defense department. They're going to point to the fact that civilian employees in a bureaucratic kind of capacity have grown in numbers far faster than deployable forces. They're going to point to the fact that in a lot of procurement programs they're really driven by politics and job creation more than by any kind of strategic thought or necessity.

### Moderator
Claim: All right. A little bit of a preview. And let's now welcome our debaters to the stage. So we're about to begin. And, as I mentioned, for the sake of the radio broadcast, there may be points in the broadcast where I repeat certain things over and over again like telling you that my name is John Donvan; that would be because we're coming back from breaks. And also it will be helpful when we come back from breaks if I could encourage you to applaud spontaneously-- at that moment, and I'll just let you know that this is the time when I really need you to do that. So the two times when that's the case, we'll be coming back from these breaks, and I'll raise my hand like that. And the other will be in a moment whether I introduce each of the debaters, when I mention their names for the first and then the second time. It would also be terrific if you can applaud. So-- 6,768. That is the number of war ships in the U.S. Navy in the waning days of the second World War. 288 ships. That is the number of ships in the U.S. Navy in the opening days of 2013. And it's about 25 fewer than the Navy says that it thinks it needs. 215. That is what a Secretary of Defense warns that the Navy will shrink to because of budget cuts from the so-called sequester. And the Navy hasn't had a Navy that small since 1915 when our war ships burned coal to get around. Obviously, times change. Military strategies change. Budget constraints change. But will more cuts now compromise the common defense? Or might we already have all of the defense we need and not just ships? Well, it sounds like a debate. So let's have it. Yes or no to this statement: Cutting the Pentagon's budget is a gift to our enemies. A debate from Intelligence Squared U.S. in partnership with the McCain Institute for International Leadership. I'm John Donvan. We have four superbly qualified debaters, two against two. They will argue for and against this motion. Our debate goes, as always, in three rounds, and then the audience votes to choose a winner, and only one side wins. Our motion is, “Cutting the Pentagon's budget is a gift to our enemies." Let's meet the team arguing for the motion. First, ladies and gentlemen, Thomas Donnelly. And, Thomas Donnelly, you are a co-director of the Marilyn Ware Center for Security Studies at the American Enterprise Institute. You actually took part in an exercise, a kind of game, hosted, in fact, by your partner at the table, there at his think tank, where you were asked to rebalance the Defense Department's portfolio of weapons and capabilities on a reduced budget. And when you began your presentation, you said, "All I can offer you are roads to failure." So does that mean you're just a pessimist or…

### Conspiracy Advocate (CA)
Claim: I think that makes me a realist, honestly. We face a pretty bleak road, particularly if we continue to cut as proposed under sequestration and

### Moderator
Claim: And we'll hear that from your argument. Ladies and gentlemen, Thomas Donnelly. And, Thomas, your partner tonight is--

### Conspiracy Advocate (CA)
Claim: My partner is Andy Krepinevich. Probably much to his astonishment, a former teacher of mine, but one of the most astute defense analysts who I know.

### Moderator
Claim: Ladies and gentlemen, Andrew Krepinevich. Andrew, you are also arguing for the motion, "Cutting the Pentagon's budget is a gift to our enemies." You are the president for the Center for Strategic and Budgetary Assessments. You spent 21 years in the U.S. Army. And the journalist, Tom Ricks, once wrote of you, "I will read anything by Andrew Krepinevich, the fine strategic thinker who bears a strong resemblance to Dwight Eisenhower around 1939." Is he talking looks or military mind?

### Conspiracy Advocate (CA)
Claim: Well, since Eisenhower retired as a five-star general and I retired as a lieutenant colonel, I think he's probably going on looks.

### Moderator
Claim: Ladies and gentlemen, Andrew Krepinevich. Our motion is, "Cutting the Pentagon's budget is a gift to our enemies." Two debaters are arguing against this motion. First, ladies and gentlemen, let's welcome Benjamin Friedman. Ben, you're a research fellow in defense and homeland security studies at the Cato Institute. You would like us to have a lighter military footprint around the world. And while you don't like the method necessarily, you think sequestration can be a good thing. Does that mean you are the sequester's only friend in this town?

### Scientific Advocate (SA)
Claim: No, I can't really stand up for sequestration, lonely as it is, but I think the law's okay but it's a dumb way to cut defense.

### Moderator
Claim: All right. Ladies and gentlemen, Ben Friedman. And, Ben, your partner is--

### Scientific Advocate (SA)
Claim: My partner is Kori Schake, who you can't tell by looking at her but she's actually older and wiser than I am.

### Moderator
Claim: Ladies and gentlemen, let's welcome Kori Schake. Kori, you are also arguing against this motion that cutting the Pentagon's budget is a gift to our enemies." You were director for defense strategy and requirements on the National Security Council under President Bush. You were also, during the 2008 presidential campaign, a senior policy advisor to Senator McCain. Your sister, Kristina, however, is communications director to First Lady Michelle Obama. So if she were here-- I understand she's traveling, but if she were here would you automatically get her vote or would you automatically not get her vote?

### Scientific Advocate (SA)
Claim: I'd unquestionably get her vote even if I had their side of the argument.

### Moderator
Claim: Ladies and gentlemen, Kori Schake. So this is a debate. It's a verbal joust, an intellectual competition in which you, our live audience, listens to the arguments and then picks the winners. And the way we have you do that is by registering your vote before and again after the debate. By the time the debate has ended, you will have voted twice, once before and once after, and the team that has moved the most of you in terms of percentage points will be declared our winner. Let's go on to the preliminary vote now, the first vote. And if you go to the keypads at your seat, the motion is, "Cutting the Pentagon's budget is a gift to our enemies." If you agree with this, push number one on your keypad. If you disagree, push number two. If you're undecided, which is a perfectly reasonable position to hold, push number three. You can ignore the other keys. And if you push the wrong key, just correct yourself and the system will lock in your last vote. And again, at the end of the debate, after you've heard three rounds, we'll have you vote again. The team who has moved the most, in terms of percentage points, will be declared our winner. So onto Round 1. The-- our motion is, “Cutting the Pentagon's budget is a gift to our enemies.” And up to speak first for the motion, Andrew Krepinevich, president of the Center for Strategic and Budgetary Assessment. He has served in the Department of Defense's Office of Net Assessment and on the personal staff of three secretaries of defense. He gets six minutes. Ladies and gentlemen, Andrew Krepinevich.

### Conspiracy Advocate (CA)
Claim: Thank you, John. And behalf of my partner, Tom Donnelly, I'd also like to thank Intelligence Squared U.S. and the McCain Institute for sponsoring this debate. And also compliment our worthy adversaries, without whom we could not have a debate here tonight.

Tom and I, in terms of this proposition, believe that further cuts in our defenses will encourage our adversaries, and at the same time, increase the risks to our security, our economic well-being, and the security and economic well-being of our allies and partners around the world. In terms of the overall perspective-- but let's take a look at the big view. At the end of the Cold War, 20 years ago, we were spending, on average, 6 percent of our GDP every year on our defenses. Six percent. Okay? In the span of 20 years, this year, we're down to three percent of our GDP being spent on defense. So we have cut in half the amount of our national wealth that we have devoted to our defenses, okay? I don't think you can find another major part of the federal budget where you have this kind of cut. So, that's point number one.

Point number two is if you look at the defense budget, you see several, I think, important things. One is 30 days ago this year, we decided-- we made a social choice, to adopt a volunteer military. And we never really fully paid the price of that choice until after 9/11, when we engaged in a protracted conflict in Afghanistan and then in Iraq. In order to recruit and retain sufficient members of-- service members to conduct those operations, we've had to increase personnel spending by over 50 percent, after inflation, since 9/11. So that's a dramatic increase. On top of that, the Obama Administration has set forth a revised defense plan which looks to cut nearly half a trillion dollars out of our defenses over the next 10 years. So what do you get? You get a shrinking defense pie, number one. Number two, within that shrinking pie, you get an expanded slice for personnel costs. What does that mean? That means in the coming years, we're going to see a lot less funding for training, a lot less funding for maintaining our equipment, and a lot less money for replacing all the worn out equipment. I've been to this movie before. This is the equation for a hollow military. This is the equation for a military that gradually loses its effectiveness and capability. Now, how will our enemies react to this? Is this a gift to them? I don't know. I'm not-- I'm not privy to their thoughts. What I can tell you is that the silence is deafening. And as Napoleon once said, “When your enemy is in the middle of making a great mistake, don't interrupt them.” And again-- so you have this particular situation. Now, some people say, “Well, gee. We're pulling out of Afghanistan. We're out of Iraq. Let's reduce defense spending. After all, the threat is diminishing. Well, first of all, our operations in those conflicts were funded by something called OCOB, the Overseas Contingency Operation Budget. And those budgets are coming down and will go down to zero. But the base defense budget--- typically, when you draw down that budget, that is when the threat is declining. And as Robert Rosenkranz mentioned, we're in a situation right now where the threat is not declining. He had a pretty good short list, but there's a longer list we can go through. John mentioned that we brought together four think tanks, from the moderate liberal to the moderate conservative, a few weeks ago to look at the sequestration cuts. And these are cuts-- let's-- hey, let's cut another half trillion dollars out of defense over the next decade. Despite the fact that there's a fair part of the political spectrum that was covered, there are two conclusions that the four think tanks agreed upon: The first is that cuts of the magnitude that are discussed and put forth in sequestration will be a disaster in terms of our military readiness and capability. Second, there is a belief-- again all four think tanks-- belief that the dangers to our security, the dangers to our economic well-being are increasing over time. We've cut our budget since the end of World War II in the past, it's been when the threat's been declining, not when the threat's been increasing. So to sum up, those who advocate further cuts to our defenses as a way to put the fear of God into our enemies, kind of remind me of what the duke of Wellington once said about his own troops. He said, "I don't know if they scare the enemies, but by God, these people scare the hell out of me." Thank you.

### Moderator
Claim: Thank you. Andrew Krepinevich. Our motion is, “Cutting the Pentagon's budget is a gift to our enemies.” And here to speak against the motion, Benjamin Friedman. He is a research fellow in defense and Homeland Security studies at the Cato Institute. Ladies and gentlemen, Ben Friedman.

### Scientific Advocate (SA)
Claim: Andrew, it's a great honor to be able to frighten you. That's one of my more impressive achievements. I think if we cut the Pentagon budget to zero, sure, that would be a gift. But the cuts that are on offer in our political system are a different story. The president right now wants to spend roughly $550 billion on defense, including-- that's national defense, budget function 050. That doesn't include the wars. Under sequestration, under the cap that we have in place for this coming fiscal year, that'd have to come down about 50 billion. And over the decade, we'd spend 4.8 trillion on defense instead of 5.3 trillion. We'd still account for over 40 percent of global military spending and spend more than we did at most points during the Cold War in real terms. GDP measures-- the percentage of GDP measures what percentage of wealth we're spending. But, of course, our economy's been growing that whole time. We spend-- we're seven times wealthier than we were in 1950 or something like that. So if that amount of spending is a gift to our enemies, it's sort of a crappy first night of Hanukkah type gift, like sweat socks or toothpaste. I think our enemies are too far behind for it to matter much. They're sort of small potatoes, historically speaking, especially when you consider our wealth, our technological prowess, and our geographic advantage; these oceans around us and our weak and peaceful neighbors. Our biggest threat right now, according to pretty much everyone, is a scattered and increasingly pathetic remnant of the al-Qaeda terrorist movement that’s failed to do much since 2001 except scare us into terrorizing ourselves. And even if you don't buy that take, you ought to recognize that aggressive counterterrorism operations with drones, with special operations forces, intelligence galore requires only a tiny fraction of our military budget. And our state enemies, North Korea, Iran, Syria, they're brutal regimes that pose little threat here. They lack the capacity to conquer their neighbors, let alone come over here and harm us. Russia, if you want to consider that an enemy, of course, has a lot of nuclear weapons, but with a dwindling population, a rusty conventional military dependent on an economy that's about equal to the Iberian Peninsula's, its days of threatening Western Europe are long gone, whatever we do. Now, China is a bigger issue. I'm sure it will come up a bunch here. But they spend about a third of what we do on defense, on the military. And most of that goes to ground forces that are largely irrelevant to a naval and air war that we might have with them if we had any war. We have 11 carriers. They have one that they practice on. Their much heralded anti-ship, ballistic missile capability which is supposed to be a threat to our ships, at the moment remains quite vulnerable to various countermeasures that we have. And I think maintaining that edge is not a problem of absolute resources. More important, China's a trading partner, not a real enemy, that we have no good reason to threaten –unless we’re eager to fight a war over disputed Pacific rocks which we're not. I think we should hedge against China's rise not by surrounding it with our forces, which likely encourages its military buildup, but by staying rich and avoiding debt and keeping a technological edge to allow a buildup later if need be. I think the real question, when it comes to military spending is what's best not for our enemies, or worse for our enemies, but what's best for us. And I think what we want is the cheapest possible military that can defend our shores, that can keep trade routes open in times of duress. And fulfill the balancing function, that long guided British and then U.S. military policy for a long time. It is to prevent a big rival from emerging overseas that can conquer our friends and threaten us. And I think we can do that quite easily with very little overseas military presence right now. What the other side wants from our military is global dominance, which I think is not really possible. They'll say that current or greater spending is necessary to our military strategy which is primacy, which is to be a sort of globe girdling policeman. And that strategy is necessary to global stability. And I think both parts of that statement are wrong. First, we could do essentially what we do in the world now in terms of our alliances, naval patrols, bases, at a substantially cheaper cost. I think you could trim at least 50 billion off the defense budget and do all the stuff we do now. I can't explain the details of how you get there, but a good place to start, if you're interested, is Dr. Krepinevich's Foreign Affairs article from I think it was February this year that says we'll shift a bunch of money out of the army into the Navy. I think that's a good idea. I think you could also look at the joint letter that those-- a number of think tanks signed on to that had a bunch of efficiency savings, including another round and personnel cost reform. We're not destined to spend what we do right now on personnel. And both my opponents signed that letter. Second, global peace and trade I think would be fine if we adopted a more of a restrained strategy, and we'd be safer for it by staying out of avoidable trouble. You know, the-- this argument sort of reinterprets the Cold War. We didn’t get into the Cold War to make global stability or secure international system. We were defending Europe against communism. We were defending some of our Asian allies against communism. And then our allies got rich. And we invented a new rationale for what we're doing. And so the new story is we agree to defend them, and they agree to let us. But I think our allies now have the capacity to defend themselves, and we ought to let them do that. And I think what we'll see that happens is a stable balance of power in Asia. And in Europe, there's basically no threats, so that's not a problem. But we'll see a stable balance of power. And as for trade, trade routes, we don't really defend them now. There's very little military protection of them.

Yep. I'll finish right up.

Okay. All right.

### Moderator
Claim: Ben Friedman, I'm sorry. Your time is up.

### Scientific Advocate (SA)
Claim: Yep. I'll finish right up.

### Moderator
Claim: No, no, I'm sorry. That's the rule. I got to-- you can bring it up in the middle of the debate.

### Scientific Advocate (SA)
Claim: Okay. All right.

### Moderator
Claim: Thanks very much. Ladies and gentlemen, Ben Friedman.

And here's a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two fighting it out over this motion: Cutting the Pentagon's budget is a gift to our enemies. You have heard two of the opening statement and now onto the third. Debating in support of the motion that cutting the Pentagon's budget is a gift to our enemies, Thomas Donnelly. He is co-director of the Marilyn Ware Center for Security Studies and resident fellow at the American Enterprise Institute. Ladies and gentlemen, Tom Donnelly.

### Conspiracy Advocate (CA)
Claim: Thanks, John. I'd like to echo the thanks that my colleagues gave to the IQ people and the McCain Institute people. I'd like to thank the audience too. It's a beautiful day and coming in here and talking about defense budgets is perhaps not the way I would spend my afternoon if I had a choice. The smartest soldier of all time said that everything in war is simple, but the simple things are difficult. And this debate is a perfect example of why that's true. We're really talking about three things and how they relate to one another. We talk about money and budgets. And you've already heard a fog of numbers being thrown out and slices of pies being alluded to. It's a lot of money that we're talking about. But I would ask you to consider defense spending in a different way, as not just a cost proposition but a value proposition. Are we getting a return on our investment that's worth it as taxpayers and Americans? I would say absolutely. Andy says for 3 cents out of our dollar, whether we're getting the global dominance that Ben suggested or merely treading water, we have a remarkably peaceful world. There hasn't been a great power war since the end of World War II. And personally, I would like to keep it that way. That's something that I can't quite put a price tag on. And what we're spending now is certainly affordable. So ask yourselves, is it worth the money we spend? That's the way I would ask you guys to consider the proposition.

Second part is even more unpleasant, the idea that we have enemies in the world. We don't like to think that as Americans. You know, we wish everybody loved us and we try to love them, but it is a dangerous world. Ben sort of downplayed all the threats that are out there. We're going to have a discussion about that. Reasonable people can differ over who's the biggest threat and what the size of the danger is, but, again, do you want to take a risk with this? If we're much stronger than our enemies, is that a bad thing? They're not all enemies. There're people who are sitting on the fence one way or the other. I would prefer to live in a world where we have fewer enemies and the ones that might be enemies don't want to mess with us. And, again, I think that's a great value proposition. The final part of the proposition is whether it's a gift to our enemies or not. As Andy said, "We don't know whether it's a gift, but it is already, we can tell, a dangerous temptation," as we see in the Middle East today. As we have come home from Iraq and we're about to depart from Afghanistan, we see in Syria a war that's metastasizing, it's like the Iraq civil war that we saw in 2006, only on steroids, much more so. So is that a gift to our enemies? I don't know. It's not a gift. Going to war is never a gift. Our withdrawal from the world after World War I was not a gift to Germany and Japan but it was a dangerous temptation to Adolf Hitler and to the Imperial Japanese. World War II was a gift to nobody but it was a necessary thing to do and a temptation to evil people in the world, and there are evil people in the world. So we’ll work through all these questions. I like it that we have allies. They provide the battlefield. That-- you can't put a price tag on that. It's better to fight over there than it is here at home. So having America be powerful as well as be engaged in the world out there in the world has created a world that's more prosperous, that's safer, and for Americans possibly the most important point is freer than it has ever been in human history. We should not give that up. You don't win prizes in war for being the guy who does it in the cheapest way. There are no style points. The outcome is what matters, and that's what we should be focusing on when we weigh this proposition. Is it a gift to our enemies? No.

That is a temptation to them, it's a risk for our friends, and it could be a real danger to us. We send very few Americans-- we have-- the world is so peaceful, and our military is so good that it only takes less than 1 percent of us to maintain the peace. I think that's worth a priceless investment, almost. Vote for us.

### Moderator
Claim: Thank you, Tom Donnelly. Our motion is, “Cutting the Pentagon's budget is a gift to our enemies,” and our final debater who will speak against the motion is Kori Schake. She is a research fellow at the Hoover Institution. She was a senior foreign policy advisor to the McCain-Palin campaign and has served in the state department and on the National Security Council. Ladies and gentlemen, Kori Schake.

### Scientific Advocate (SA)
Claim: So I agree with everything Tom Donnelly just said, and I think you can still agree with Ben and me that cutting defense spending is not a gift to our enemies without compromising anything Tom just said. And let me try and walk you through why I think that's so. First, as most of you probably know, 31 cents of every dollar the United States government spends, it borrows. We may only spend 3 percent of it on defense, but 31 percent of it, we have to borrow. Our national debt, the extent to which our spending is outpacing our revenue, that's the gift to America's enemies. We actually really need to bring our spending into alignment with our revenue, and the defense budget has doubled since 2001. The sequestration, the means by which we are further reducing it is damaging, but the reduction in the top line, the overall level of spending is manageable while maintaining a strong national defense, while retaining allies, while retaining the value proposition, and while frightening our enemies. The United States constitutes-- our own defense budget is 40 percent of global defense spending. 40 percent, all by itself. There are 21 aircraft carriers in the fleets of the world's navies. Eleven of those are in our navy. American dominance in the military realm is overwhelming. Of all the places you could cut spending-- in fact, the margin for error in national defense is enormous. As Tom said, the value proposition that the American military provides: we can do things that other militaries cannot do and that drives our enemies to radical, asymmetric strategies. It drives them to terrorism. It drives them to cyber warfare. It drives them to things-- because they know they couldn't actually fight the American army and defeat it. It drives them to strategies of trying to erode our national will to fight the war, because if we fight it, we're going to win it.

In regard to the threat from China: China is rising. And we're smart to hedge against a rising China. But I would encourage you to remember that one of the most important strategic variables, one of the most important advantages you can have, is time. And we actually have a lot of time to figure out how to deal with a rising China. And our-- the American military is one of many means for managing that rise and one in which we have a strong advantage. A second thing I'd like to ask you to consider is-- I agree with Tom about the value proposition. The American military is extraordinarily good at what it does. That does not mean that the money that we spend on our defense we spend well. Right? The Defense Department, in truth, actually doesn't know if we have enough money to spend on American defense, because they actually cannot pass an audit that every American business has to pass. They already told Congress they won't be able to pass an audit until 2017. Given that the budget has doubled in the last 10 years, and DOD cannot account for the money, that suggests to me that there are reasonable places in the budget from which we could wring greater effectiveness in our spending. The American military is terrific at the effectiveness of war-fighting. We're not cost effective. We're not particularly efficient at how we do it. And I would offer you the testimony of General Dempsey, the chairman of the Joint Chiefs of Staff, who said that if we forced ourselves to think, we could probably do this with less resources. He also said that because budgets have essentially been unconstrained for the last 10 years, the American military has gotten into a lot of bad habits. As Admiral Mullen, General Dempsey's predecessor, said, we have raised a generation of military leaders who don't know how to budget because they've never had to do it.

Let me just point out to you some of the cost-drivers or how expensive American defense is. GAO determined the last year that we wasted $74 billion in the year 2012 because of the procurement process, because of what Senator McCain has described as the political-- as the military industrial Congressional complex. The Pentagon's determined we have 20 percent more bases and facilities than we need and Congress will not permit them to close them. The military-- the Pentagon has tried to ramp down the expansion of the personnel account-- military raises, housing, funding, pensions-- and Congress won't do it. So even the Pentagon understands the resources to be saved here. In fact, the position that we are in is that we have the world's finest military and that all-volunteer force is becoming unaffordable. We have to better constrain the costs of our defense. And even within national security, there are things that need money even more than the American military, right? If you look at why were are not more decisively winning the wars in Iraq and Afghanistan, the wars we have fought in the last 10 years, the reason is we're underfunding diplomacy, development, other things we need to spend our money on.

## Round 2

### Moderator
Claim: Thank you, Kori. And that concludes Round 1 of this Intelligence Squared U.S. debate, in partnership with the McCain Institute for International Leadership, where our motion is, “Cutting the Pentagon's budget is a gift to our enemies. We have two teams of two arguing over this motion. And now, we move on to Round 2. Two teams of two arguing this motion: Cutting the Pentagon's budget is a gift to our enemies. The team arguing for the motion, Andrew Krepinevich and Tom Donnelly have argued that budget cuts threatened-- threaten to make a dangerous world even more dangerous, that a weaker U.S. military would encourage our adversaries and create for us a hollow military. They say that the peace and security that comes in 3 cents of the dollar is a bargain considering what a peaceful world it has led to for so long in terms of wars among the great powers; that this is a dangerous world, and we have to take our enemies seriously, in their perception of this, as a weakness on our part. The team arguing against the motion, Kori Schake and Ben Friedman, say that the threat at this point is exaggerated. Number one, we are so dominant militarily, we have oceans protecting us, a technological advantage, and a dominance that makes it just too early to worry about a real threat to our existence. They say that the-- that their opponents are actually arguing for a global domination that is unnecessary to ensure the common defense. And they also point out that the cost of the military itself actually represents the real threat to our national security. I want to ask the team that's arguing for this motion, the team that is arguing that the cuts are a threat to our security and a gift to our enemies, to put to you a point that your opponent, Ben Friedman, has made, that your argument for a strong military-- military does not have to suffer these budget cuts is premised on a goal of global domination. He says that's really what your vision is. Is that accurate? Do you cop to that, Tom Donnelly?

### Conspiracy Advocate (CA)
Claim: Well, I like to do the crime before I do the time. So no. You know, dominance is a loaded term, no question.

### Moderator
Claim: That's why I used it.

### Conspiracy Advocate (CA)
Claim: Yeah, no.

I noted that. But I'll cop to it. You know, it doesn't bother me if America is stronger than everybody else times two or three. America's role in the world, from my perspective, has been pretty positive. And the use of American military power has made a better world, and so I'd rather be dominant than weak.

### Moderator
Claim: Andrew, let me come back to you because I'd like to just hear from the other side on that. Ben, it was your point. Can you respond to Tom--

### Scientific Advocate (SA)
Claim: Well, that's a false dichotomy. My whole point is that we're incredibly strong now, vis- a-vis our enemies. So weakness is not something that's on the table in this debate. The argument is they say we need to try to have ten times the power of our enemies and basically guide history to be safe. And that's a massive overdefinition of our safety. The United States is incredibly safe from natural geographic reasons because of our economy. And most of what we're doing in the name of safety or defense is sort of a luxury that most states don't endeavor to do. And I think it gets us into trouble that we could avoid. You know, a few difference of percentage points in the defense budget is not going to make a difference. But if we really rethought our strategy, we could be a lot safer because we'd avoid conflicts that we get into.

### Moderator
Claim: All right. We’ll get onto that in a bit. I want to let Andrew Krepinevich respond.

### Conspiracy Advocate (CA)
Claim: Ben was kind enough to cite my Foreign Affairs article. In the article, even absent the sequestration cuts, I said we're going to have to really trim our sails. We're not going to be able to fight or deal with threats in two different regions, even though there are three regions in the world we consider to be vital interests. We're not-- maybe-- I think this is a good thing. We're not going to be able to threaten anybody with regime change. I think we're going to struggle just to maintain access to critical regions where we have trading partners and resource requirements. We haven't figured out a way to deter cyber attacks. And the cyber threat is growing. We haven't figured out a way to protect our assets in space. And I think the next big thing coming down the road is the undersea infrastructure which is huge. And with the spread of robotics, increasingly accessible even to non-state groups who can threaten the enormous energy infrastructure that in military parlance is comprised mostly of soft targets.

### Moderator
Claim: Let me bring that to Kori Schake. The money argument, that just sounds like everything that was just outlined is important and will cost a lot. Kori Schake.

### Scientific Advocate (SA)
Claim: Well, you know don’t have to do things in the future the way we have done them in the past. And I think one of the important advantages of the American military is actually its adaptability, and its innovation. Our biggest advantage isn't our spending; it's the creativity and build a better mouse trap.

### Moderator
Claim: But are you saying that-- is your point really that the U.S. military could do a lot more with a lot less, a lot more? I think both sides agree, and I don't think there's much debate to Kori's point that there's waste, and there could be more efficiency. I think they agree with that.

### Scientific Advocate (SA)
Claim: We can do it differently. We can drive innovation so that our enemies' advantages get matched up better against. One of the challenges that we have in the current defense budget is that the force structure doesn't match the strategy as both our colleagues across the aisle have--

### Scientific Advocate (SA)
Claim: Yeah. We can make more choices. I think at least one of our opponents would agree that if we cut the ground forces a lot we could afford to do lots of things with the Navy, with a smaller budget than we have now.

### Conspiracy Advocate (CA)
Claim: The problem--

### Moderator
Claim: Andrew Krepinevich, go ahead.

### Conspiracy Advocate (CA)
Claim: The problem is right now that, you know, efficiency is everybody's favorite solution, you know. We have efficiencies, magic happens, and then all of a sudden we save all this money. We’ve been going to that movie for about 50 years now, and the result is always the same. We put the cart before the horse. You know, let Congress and the political leadership take on the responsibility, exercise the moral courage to make these changes before we saddle our soldiers, sailors, airmen and marines with the problem. I was talking to one-- in fact Secretary Panetta-- and if you don’t already know, he's very fond of colorful language. And I raised the issue of efficiencies. And he said, “That's a bunch of bologna,” although he didn't use the word "bologna."

### Moderator
Claim: This is a radio show, so I'm glad you censored.

### Conspiracy Advocate (CA)
Claim: And, you know, for those who say, “Well, we spend more than others,” well, as I mentioned earlier, we have a volunteer military. What kind of military do you think we'd have if we paid our soldiers, airmen, sailors, and marines what the Pakistanis pay theirs or what the Russians pay theirs or what the Chinese pay theirs? As Tom said, do you want to wait until the enemy is at your shores and then start figuring out how to deal with the threat?

### Moderator
Claim: All right, let me-- let me put that very question to the other side: Do you want to wait until the enemies are at your shores and--

### Scientific Advocate (SA)
Claim: --we have a lot of straw men coming out now. You know, fight him over here, fight him-- I'm saying, don't fight him. Let's have fewer wars. But, I mean, I think you guys both just signed a letter saying we should reform compensation for personnel. So we're not going to pay them like Pakistan or Russia. We're going to pay them well. We're going to pay them what they would get in a regular market, I think, with those reforms. And I'm for that too. That's an efficiency. So there are some-- a brack we do a lot of the same stuff with fewer bases. That's an efficiency. So there are-- I'm not a big efficiency guy. I basically agree with Panetta. But that's why I said, why don't we cut the size of the army? Which I think you might agree with. You know, we-- not going to occupy a country. We could have a smaller ground force. That's not an efficiency. That's a strategic choice. That's what I'm talking about, more strategic choices.

### Moderator
Claim: Tom Donnelly-- Tom Donnelly, is it accurate what Ben Friedman just said, that you also want to cut the size of the army?

### Conspiracy Advocate (CA)
Claim: No, I mean, I think Ben laid it out very well.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: It’s not an efficiency, it is a choice, a choice to have less power and to withdraw.

### Moderator
Claim: All right. Landed that very well.

Is it an issue of having less power? Is it okay to be less powerful? Kori Schake.

### Scientific Advocate (SA)
Claim: I'm not in favor of that, as a matter of fact. I agree with Tom on that. But it seems to me that maintaining American power in the international order is more affordable than our colleagues across the aisle suggest it is. And let me just give you one example--

### Moderator
Claim: Isn't it more a matter of style? I believe your opponents are talking about not really wanting to do away with a lot of carrier groups. Am I right about that? You want the aircraft carriers there. You want them deployed around the world. You want them near other people's shores. You want troops stationed in NATO ally countries and in South Korea. Am I right about--

### Conspiracy Advocate (CA)
Claim: I think Kori, I think, hit on a good point, which is we're going to need not to do more of the same. We're going to need to begin to think about things differently. As Robert Rosenkranz mentioned, the problem set is becoming quite a bit different than Afghanistan and Iraq. The problem is, as I mentioned before, that when you've got a shrinking budget and exploding personnel costs, what gets squeezed out are science and technology, research and development of new capabilities, training and exercise to test out these capabilities to find out what works and what doesn't. And so you're stuck making a big bet, and you hope it'll work, but you really don't have the chance to test it out.

### Moderator
Claim: Okay. Andrew, let me give the floor back to Kori because I took it away from her, and then you took it away from me. So-- Well done. But it's not going to happen again.

### Scientific Advocate (SA)
Claim: I basically agree with what Andy just said. But the point is that, for example, take the army, right? You don't have to make one big bet by cutting the size of the army. The size of the army in the 1990s, before September 11th, was 490,000 soldiers. That was when you still had the planning construct that said we had to be able to fight two nearly simultaneous wars. It was before you had the revolution in communications and precision and battlefield awareness that has made American forces so much more effective than they were. It was before the defense guidance, which secretary Panetta brought into being in the Pentagon that said that we are not going to size our force to fight a large, sustained land war anymore. And yet, the size the army says it needs is 490,000, the exact same as in 1990. The threats are different, the requirements are different. We need to find new ways to do stuff. The answer shouldn't be the exact same as it was in the 1990s.

### Moderator
Claim: Tom Donnelly and then Ben Friedman. Tom Donnelly.

### Conspiracy Advocate (CA)
Claim: Well this is extraordinary reminiscent-- I mean, this is the kind of talk you heard out of Donald Rumsfeld before 9/11. 490,000 was too small. We proved that by being unable to do Iraq and Afghanistan properly at the same time, so I don't think that was a good experience. And I don't want to expect that the world is going to be technologically transformed and that the art of war is going to be fundamentally different than it's ever been in human history. That seemed like a bit of a long shot to me, too. So numbers matter, and we have just proved that in spades over the last decade.

### Moderator
Claim: Meaning what? You need a lot of boots on the ground, is that what you're saying?

### Conspiracy Advocate (CA)
Claim: There are some things that you cannot do with technology. And we have actually, you know, fought irregular wars and counterinsurgencies in the most technologically sophisticated way ever, but I don't think the result was satisfactory.

### Moderator
Claim: Ben Friedman.

### Scientific Advocate (SA)
Claim: Again, I hear arguments being made for me that I don't make. I am not signing up for the Don Rumsfeld vision of anything in my argument. You know, occasionally we might agree on something, but my argument is not his. He liked war a lot more than I do, and the-- we're hearing a lot of assumptions about the changes that will be made if we-- or what will happen if we cut the defense budget-- personnel will get squeezed and we'll cut the O&M budget, so we'll have a hollow force. If we did that, it would be a mistake. The-- so we don't endorse things that will lead to a hollow force. The military of the '70s I'll grant was a bit of a hollow force. The personnel situation was bad, but that's because we didn't pay them enough. We-- compensation is much better now by a mile. And we are making choices now to avoid cutting the O&M budget at the expense of procurement, so we can avoid that. And our argument doesn’t entail doing all the bad things you say it does. And finally, I think, since you asked, power-- power is our capacity to generate force. It's potential. It's not standing military forces. There are powerful nations that have quite small militaries. The difference is they could-- with weak nations is they could change that if they wanted to. So our long term economic health, of course, is essential to our power.

### Moderator
Claim: I-- question for this side, unless you want to respond, because I wanted to move it along so we if you want to respond because--

### Conspiracy Advocate (CA)
Claim: I'm just saying that we are only at the dawn of sequestration, and all you have to do is read the papers. The Air Force is cutting back on training, the Army's cutting back on training, the Air Force can't replace its aging aircraft in part because we screwed up over the last decade or so in terms of the procurement approach. But, again, that's poor excuse for compromising our security and punishing our service members. So yeah, were mistakes made? Certainly they were. You know, does that mean we give up on our security because we didn't get it right or is that-- do we ignore what's going on now?

### Moderator
Claim: All right, do you want to respond, Ben?

### Scientific Advocate (SA)
Claim: Well, I was going to say the sequestration-- we have one kind of sequestration in fiscal year 2013 which said no matter what happens with the budget we cut across the board, we cut everything equally. And that wasn't quite as severe as the services made it out to be, but it was dumb, and I'm against it. We're against it. But going forward, what we have is budget caps, and if they get under the cap they can do whatever they want. So we don't have to do all those foolish things with cutting back on training in '14, '15, '16, '17. As long as they get under the cap, they can make choices. So sequestration in '13 was dumb, going forward as long as they get under the cap, it's okay.

### Conspiracy Advocate (CA)
Claim: But then we still have the personnel problem. And part of the Budget Control Act, the president was given the option of exempting personnel costs and personnel cuts, and so again you have that situation where you have this personnel budget that is crowding out everything else.

### Moderator
Claim: But benefits are being cut.

### Conspiracy Advocate (CA)
Claim: I'm sorry?

### Moderator
Claim: Benefits are being cut?

### Conspiracy Advocate (CA)
Claim: Benefits-- you know, the proposal right now is to scale back on some of the healthcare benefits and so on, but the-- what the president can do is exempt-- what the-- as Ben was saying, what you have is what the Pentagon calls a "haircut," everything get's cut. And I think one thing we all agree on is this is a foolish way to run things.

### Moderator
Claim: I'm-- what I'm trying to figure out is what you all disagree on-- because I know you do. I know you do, and I think it goes to this issue of, "What are our enemies thinking?" And all of you in your opening statements said, "I don't want to read my enemy's mind because it's unpleasant to be in there." But I think we want to talk about the notion, and this was alluded to by you, Tom, in your opening statement, that this is-- a weaker U.S. military is a temptation not just for China but for who knows to do things that right now they're just not going to bother doing. It's also some freedom for our allies to not be militarized and to dampen down those ambitions. So what about that whole point of our enemies' perception of us being not dominant? Tom Donnelly.

### Conspiracy Advocate (CA)
Claim: I think we-- as Andrew says, if you read the newspapers, or listen to NPR, or whatever--

### Moderator
Claim: Tom, I just want to-- for the radio, to ask you to state-- if you just walk toward the mic. Thanks. Thanks.

### Conspiracy Advocate (CA)
Claim: Again, I-- when I read the newspapers in the morning, or read the news online, or however I get my news, what I see is people feeling for openings in weak spots. We see that very much in Syria and Iraq. The war has spread to western Iraq, northern Jordan, et cetera, et cetera. We see that in the Pacific, in the South China Sea, where the Chinese, even without an aircraft carrier, are nudging and pushing at what Ben calls the various rocks in the South China Sea; the things that really matter to our allies, people who are our treaty allies, like the Filipinos. I don't want there to be a war over a rock in the South China Sea. And what we see is people feeling for how far they can go in the absence of an American military presence.

### Moderator
Claim: Okay. Let me take this to the other side. Very specifically stated that the perception that our commitment to strong defense may be wavering is already resulting in people putting up feelers to see what they can get away with. Sounds very logical. I want to put that to Kori Schake.

### Scientific Advocate (SA)
Claim: I--

### Moderator
Claim: But-- Kori Schake.

### Scientific Advocate (SA)
Claim: Because enemies always probe, like, for your weaknesses. That's what enemies do. The Iranians aren't newly racing for a nuclear weapon. They've been doing it since before we started cutting defense spending. The Chinese have been--

### Moderator
Claim: But the logic of that is--

### Scientific Advocate (SA)
Claim: before--

### Moderator
Claim: --they’re going to race even faster if they think-- if they were getting-- if our resolve is wavering.

### Scientific Advocate (SA)
Claim: Enemies don't play to your strong suit, right? Nobody can fight the American army in an open-space tank battle, because they're going to lose. What enemies try and do is play to your weaknesses. That's why they go for terrorism--

### Moderator
Claim: But that's what he said-- they're saying. That's what they're saying.

### Scientific Advocate (SA)
Claim: but there's-- whether we have eight carrier groups or nine, I actually don't think is going to make that much different to the Chinese calculation about whether they want a Chinese dream that is their dominance of the Pacific. We need a comprehensive sense of our strength. And right now, we are stronger in our military capabilities than we are in our trade agreements, than we are in our diplomacy, than we are in our development. We ought to hedge up what our actual weaknesses are, not continue to reinforce our strengths.

### Moderator
Claim: Andrew Krepinevich.

### Conspiracy Advocate (CA)
Claim: We are being confronted by some strategic choices, to use Ben's term. There are three agents of the world that we rely on for trade and for resources. We're part of the global economy. And we rely on the global common space, cyber space, the sea, and the undersea to link us to those parts of the world. In the Far East, the Chinese, for over a decade now, have been building up their military capabilities to try and push us out of the region. Just listen to what the Japanese, the Taiwanese, the Koreans, and so on are saying. We have a strategic choice. Now, it's not going to be a big army that we respond with. But we're going to have to do something to maintain stability in that region, lest we encourage Chinese adventurism. And you could see it in the paper, in terms of the trends in Chinese behavior. Iran-- a nuclear armed Iran. Do you think they're more or less likely to support Hezbollah, or to support Assad in Syria, or to try and undermine the Gulf monarchies, and disrupt the flow of energy? Pakistan-- and again, you know, I don’t want to go on at length. But you look at cyber situation. Concerns that even non-state entities will be able to inflict serious damage on us by cyber attacks.

### Moderator
Claim: All right. Andrew, let me-- let Ben Friedman respond.

### Scientific Advocate (SA)
Claim: Well, I mean, contrary to how it appears in Washington DC, the world actually doesn't revolve around Washington DC. So what China does vis-a-vis its territorial claims-- this is shocking-- is not completely driven by conversations in Washington or small differences in our defense spending from year-to-year. What Iran does, in terms of disrupting energy flows or funding Hezbollah, is not driven by small differences in U.S. defense budget. They might have some minor preference but it really doesn't matter. They're going to do what they're going to do for other reasons than a margin of difference in our defense spending. If there's been any indication that the United States is not as up for war as it was a while ago, it wasn't because we're spending a little less on the military, it's because we had bad wars that made the public less enthusiastic to go, which is a good thing. And maybe it cuts back on our credibility, but-- if you want lots of credibility to have wars, then don't have dumb ones all the time, you know? Save it for the-- save it for the-- for the good times. So-- I'll leave it there.

### Moderator
Claim: You guys want to pick up? Tom Donnelly.

### Conspiracy Advocate (CA)
Claim: I would-- well, I would just say that--

### Moderator
Claim: Andrew Krepinevich.

### Conspiracy Advocate (CA)
Claim: --take the Far East example. The purpose of trying to maintain a stable military balance in the region and address the capabilities that the Chinese are building up-- the purpose is to avoid war, not to fight war. You can get into a war because of the perception that you're too weak to defend yourselves or that you're irresolute. And cutting a trillion dollars additionally out of defense over the next decade certainly, I think, sends that message as we withdraw from parts of the world.

### Moderator
Claim: Yeah. I just want to put to this. I mean, history-- 20th century has got some great examples of weakness being perceived as an opportunity for aggression. That's the point the other side just made. Again, there's a logic to it, and there's a historical precedent for it. It's not a ridiculous claim, so can you respond to that, Kori Schake?

### Scientific Advocate (SA)
Claim: It's a very strong claim. I agree with it. But it hinges on the belief that we are close to the margin at which another military believes they could defeat the United States militarily.

### Moderator
Claim: Well, the logic of what you're saying is that they only don't because we're so dominant. So you're saying they won't-- they won't mess with us because we're so dominant, therefore we don't have to be so dominant anymore.

### Scientific Advocate (SA)
Claim: Well, I'm saying it's a really wide margin. We're not close to the line at which--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --China thinks they can fight the American Navy--

### Moderator
Claim: So what you're saying is we can afford to be a lot less dominant, and we would still be pretty darn dominant.

### Scientific Advocate (SA)
Claim: Yes, exactly.

### Moderator
Claim: Okay.

### Moderator
Claim: Let me take it to-- that point to the other side, that we have a lot of wiggle room is what your opponents are saying. Tom Donnelly.

### Conspiracy Advocate (CA)
Claim: One of the things that technology has yet to solve is how to be in two places at once. As advanced as our military and-- is-- pardon me-- you know, if it's not there, it's not there. And what we see in the world now is the effect of us not being there. China doesn't want to go to war with us. They probably want to go to war with us even less than we could ever possibly want to go to war with them. They want the benefits of nibbling away, pushing the limits. They want to intimidate the Filipinos and the Taiwanese. They don't want to mess with us. But if we're not there, there are going to be consequences. And you see it every day.

### Moderator
Claim: All right. I'm going to go shortly to the audience for questions. And how that will work is just raise your hand, and I'll call on you, and a mic will be brought to you. And if you can just stand up, state your name--

### Moderator
Claim: I will. I'm going to come back to it. This is all prelude. And a mic-- we're going to try it a little bit more here. I just want to get you to get ready and get your questions really perfect, really perfect.

And just stand up, tell us your name and ask the question. And the last thing I want to just say is to keep the microphone as close to your mouth as this is to mine. Go ahead, Ben Friedman.

### Scientific Advocate (SA)
Claim: Weakness can be provocative, but, you know, a lot of us kept going to history class the day after we talked about Munich and World War II. And strength can also be provocative. States balance power. States design, build military capability in response not necessarily to weakness but to being threatened by other states. States' decisions to build nukes and to build armies are often driven by threats, including the ones that the United States poses to their borders. So it's not so simple that our weakness encourages buildups. And I really think we ought to talk more carefully about what scenario would take place absent a larger U.S. commitment to Asia that's so nefarious. I think, yeah, the Philippines and Taiwan and Japan might spend a little more on defense and create a stronger alliance among them. But that's not a bad thing necessarily. We can-- we can live with other states having geopolitical responsibilities.

### Moderator
Claim: Let's have-- let this side respond to that and I'll come to questions. Andrew Krepinevich.

### Conspiracy Advocate (CA)
Claim: Those of you who recall the Melian Dialogue, and I'm not quite old enough to recall that, but the famous phrase is, “The strong do what they can; the weak do what they must."If you're weak, others will decide your fate. If you're strong, at least you have the option of being smart or stupid. And hopefully we elect people who are the former and not the latter.

### Scientific Advocate (SA)
Claim: being Melians right now. We're the Athenians in the dialogue.

### Conspiracy Advocate (CA)
Claim: I'm sorry?

### Scientific Advocate (SA)
Claim: We're the Athenians in the dialogue. We not going to be the weak, right? We're-- we'll be--

### Conspiracy Advocate (CA)
Claim: Again, getting back to the point we were discussing a little bit earlier-- and Kori kind of set this up. Chinese are good strategists. Yeah, we have the world's best Air Force. But our aircraft in the Far East are concentrated at two bases. What are the Chinese doing? They're building lots of ballistic missiles to target those bases. We have the world's best carriers, as Kori mentioned, and a lot of them. The Chinese are developing missiles to target those carriers and they're building submarines to go after those carriers. So do we cut the-- you know, do we need a big army for China, to maintain stability in that region? Hardly. But we are going to figure out-- or going to need to figure out a way to maintain stability in that region. Otherwise, I don't think the Filipinos are going to say, “You know, the Americans are gone. Let's take on the Chinese.” Now, the Japanese may say, “The Americans are gone, we need nuclear weapons.” And let's see what that does to the neighborhood.

### Moderator
Claim: Let's take some questions. Sir, right down in the front, right in the middle. Yep. Sir. You gave me the nod, and I gave it back to you, and you're standing up. You have to know how to do the nod. It's sort of one of these.

### Moderator
Claim: Hi. My name is Josh Sax My question is for the affirmative side. There's clearly waste in the defense budget I think you would agree on. There's stuff in there that is really more of a jobs program than weapons, stuff the army doesn't even want like additional Abrams tanks. Would you think that if we were to reduce spending on those things that it would be better to reallocate that spending to additional military priorities? Or would it be better in our long-term interest to take those reductions and put it towards reducing the national debt?

### Moderator
Claim: Great question. Tom Donnelly.

### Conspiracy Advocate (CA)
Claim: Yeah. One thing, look, we need to get sort of the best bang for the buck that we can under any circumstances, whether we're spending more or spending less. On the other hand, compared to other forms of government, I would offer the Pentagon is actually, again, a good value proposition. If the public education system educated my kids as well as the military does its job, both my kids would have gone to Harvard, and they didn't. You know, if my doctor kept me as healthy as the military kept the world, I would live forever. So as a government function for all the waste, fraud, and abuse that there may be in the department-- and I wish it were zero-- it's relatively less. And the dollar amount is really trivial when we're talking about the size of the federal debt or the deficit. Look, we spend as much per year almost-- and if interest rates actually go up to a market rate, more on servicing our current debt than we do on military power. So in the relative size of things, we're not talking about a lot of money. You know, trillions and trillions, and pretty soon you're talking about real money. But compared to the rest of the economy or what the government spends, this is peanuts.

### Moderator
Claim: Right down in the front here. And it's coming down the front aisle. I'm-- I have a bad habit of sort of favoring people who are closer to me. It's totally unjustified. So if you're in the back, be a little bit more aggressive to get my attention. Ma'am.

### Moderator
Claim: Excuse me. Thank you. My name is Annabelle Fisher. First I want to say all of us support our military. I don't think there's anyone here who does not support our men and women who are protecting us. And I have worked for the military. This is a question for both sides. Sunday, June 2nd in The Washington Post, costs and benefits for the military. And it talks about 149 billion that will be spent by the military; pensions, salaries, military making more than-- well, I've never made--

### Moderator
Claim: So, ma'am, what is your question?

### Moderator
Claim: So my question that-- both sides, if we can reduce some spending in the military, and you're looking-- you talked about reduction in HR, in costs, pensions, healthcare, yes, tri-care folks need to pay a little more money, is this appropriate? Will this impact our military? And do we have a better-- does China have a better strategy than our military? I think we have a pretty good strategy.

### Moderator
Claim: Okay, ma'am, I-- I'm not sure what the-- you went through a lot of subordinate clauses, and I lost the question.

### Moderator
Claim: I'm really focusing really on this article in the Post that talked about ways--

### Moderator
Claim: Okay, I'm going to--

### Moderator
Claim: --save money.

### Moderator
Claim: I'm going to refer folks to the article and thanks very much. Sir in the back.

### Moderator
Claim: I think we agree that--

### Moderator
Claim: Yeah, I think everybody does agree on that. We've covered it. Sir, right-- I'm pointing right to the very center. You're-- yeah, yeah. If you stand up. Thanks. Okay.

### Moderator
Claim: Hi. My name is Bernie William. I'm a grad student at Seton Hill University, studying diplomacy. My question is, first, to start off, the Carter Center for Peace has said that since World War II, of the 50 major armed conflicts that have gone on, they've all been about religion or ethnic conflict. And they've all been pretty much within borders. So-- and the actual occurrence of violence has gone down, and the number of people being killed has gone down. So is the threat to the United States that much-- increasing so much when we're using our military to go into these countries, essentially almost as our diplomats, and saying, “This is our brand of Americanism, and you have to-- and you have to accept it”? Can the military be changed to be more of our diplomatic arm, or could that money be better spent to diplomats, commerce, and improving trade?

### Moderator
Claim: I'm trying to think if that actually addresses the issue of whether reductions in the military threatens our security. And I don't think it quite gets there. Do you want to take another run at it? Because I think you're close to it.

### Scientific Advocate (SA)
Claim: I can give an answer.

### Moderator
Claim: I know you're all set for it, but I want the People are going to be listening on the radio and not understand that.

### Moderator
Claim: I guess what I'm saying is that it seems that our military is creating more enemies by being out there and doing stuff-- and doing what it does. And it-- and should the-- and it seems like I'm following the “against” side in saying that the military needs to reshape its force so that it's doing more diplomatic efforts, navy admirals going--

### Moderator
Claim: But what about-- what if that costs a lot of money? Your premise is that it would--

### Moderator
Claim: I'm saying-- well no, I'm agreeing that the ground forces be reduced and then we-- and but is it better to--

### Moderator
Claim: Okay, can I phrase your question this way? Does the military have less expensive ways, without using military force, to actually keep the nation safer?

### Moderator
Claim: Yes.

### Moderator
Claim: Now can you say that? I'm Kori Schake.

### Moderator
Claim: Give that man a microphone.

### Scientific Advocate (SA)
Claim: One of the things that has happened in the last-- with the wars of the last 12 years, is that things that have traditionally been diplomatic and development functions have migrated into military space. And that's because we don't train our diplomats and our development people to the same level of professional expertise that we train our military, and we need to do that. That's actually a better place to spend our money. It matters to see diplomats doing diplomatic work, and we could spend our money that way, we just choose not to.

### Scientific Advocate (SA)
Claim: The military--

### Moderator
Claim: Let me go to the other side first and then come back to you. Tom Donnelly.

### Conspiracy Advocate (CA)
Claim: The original question posited a correlation between less war and less dying in recent years. That correlates really strongly with the rise of American power. So, again, that's what I was talking about originally. This has produced great benefits, not only to us, but to humanity-- and there's-- and Kori will remember this from her own time in the White House. The problem with diplomats is that if you want to send them to Afghanistan, at least until recent years, they could say no. They could refuse to go. So we need all the tools in our kit bag of all kinds, but we should not pretend that military power isn't part of what needs to be in that kit bag.

### Moderator
Claim: Okay, one more round and--

### Scientific Advocate (SA)
Claim: Well, I mean, look, let's not make the argument that if only the military would handle diplomacy, diplomacy would be easy. I mean, diplomacy is really hard. We sort of have this idea that because diplomats don't produce magical results in transforming societies that are problems, that we should hand it over to the military, which is really good at destroying things but also doesn't have the tools to build society. So I'm certainly not in favor of transforming the military's mission. The-- what Tom just said ignores a vast social science literature on the causes of the long peace. This idea that peace in the world, this massive decline in violence which you referred to, which is not talked about enough-- everyone should read Steve Pinker's book about this-- civil wars are in massive decline, coups are in massive decline, genocide has been going away. Your chances as a human of being killed in political violence have descended massively since World War II. We don't talk about that in Washington. That's not due to the benevolence of the United States of America, I don't think. It has to do with the spread of liberalism, maybe, the spread of capitalism, and the experience of wars which cause societies to learn. And, again, this isn't just me talking, this is most of the people who study this for a living. This idea that--

### Moderator
Claim: But Ben aren't your opponents arguing that, in fact, the-- American military dominance is what created the conditions?

### Scientific Advocate (SA)
Claim: I'm arguing against that right now. I'm saying that there's all these other factors that are doing the work.

### Moderator
Claim: I don't know, but I think their point is that those-- that the American military dominance enabled those other factors to do all the work.

### Scientific Advocate (SA)
Claim: Well, if you think it's just pure magic, and it does everything in the world, then it's hard to defeat that proposition, but-- you look-- there are parts of the world where the American military is not very present, and we see I think a lot of the same results there, absent that, okay? So and if you read Pinker's book, he says this progression has been going on much longer, even prior to World War II, which is kind of hard to understand, but it's not a controversial sentiment that violence is massively declining.

### Moderator
Claim: Andrew, hang on one second. I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donovan, your moderator. We have four debaters, two teams of two debating this motion, "Cutting the Pentagon's budget is a gift to our enemies." Andrew Krepinevich.

### Conspiracy Advocate (CA)
Claim: There's a saying that hope and wishing is not a strategy. I would like to think that diplomacy could solve all our problems, we wouldn't need militaries. Or that the global economy's stupid, if we all just sit down and shut up, we're going to get rich. Fact of the matter is, in the absence of a stabilizing military force, you tend to get into trouble. Look at the period from 1850 to 1914. The end of the Napoleonic wars. Britain emerges as the world's dominant power. And the Pax Britannica exists for a century, until the time that Britain's power began to wane, they began to cut back on their defenses. They began to expand their social welfare programs, for better or worse. And Germany decided that they could win a war quickly, that they could defeat the Allies quickly. And what you ended up with is World War I and carnage on an unparalleled scale. Again, it wasn't because the British were too strong that Germany decided to go to war. It was because they thought they had an opportunity to advance their aims at the expense of others.

### Moderator
Claim: Sir? Young man who was waving his iPad. I liked that move, so you're next. Back to you.

### Moderator
Claim: Doug Brooks I'm-- I used to run the trade association for companies that work in support of military operations abroad. But one thing that really strikes me is that we have-- we have come to the greatest commercial nation on earth, and yet our military is still using sort of 19th procurement lines and we sort of ignore the sort of ability to essentially create a more effective military for a far cheaper price. I mean, shouldn't we be looking to the--

### Moderator
Claim: You know, I think they both-- they've all conceded that we need to be better at efficiency, so I'm going to respectfully--

### Moderator
Claim: --ask for another question.

### Moderator
Claim: --we can do the stuff and we can do it a lot cheaper. So we're actually-- by changing the way we do things, it's-- makes it worse for our enemies. If the--

### Scientific Advocate (SA)
Claim: But it's not-- it’s not the private sector. The public sector is different. It works differently. The incentive structures are massively different. We keep shipyards because they employ people. That's-- you know, if you're a senator for Maine, I think it makes sense for you to keep that iron works open, even if you have excess overhead. So I don't think there are that many lessons in that regard from the private sector; I think we have to learn lessons from the public sector about how to be more efficient.

### Moderator
Claim: Sir? Andrew, did you-- you need to respond?

### Conspiracy Advocate (CA)
Claim: I just wanted to say--

### Moderator
Claim: Andrew Krepinevich.

### Conspiracy Advocate (CA)
Claim: --again, this is putting the cart before the horse. To say, “Oh, let's cut a trillion dollars out of defense and all of a sudden, everything's going to be efficient, and we're going to stop all this pork barreling”-- I mean, again, that is the triumph of hope over experience.

### Moderator
Claim: And the next question-- we haven't heard much from Kori or Tom for the last five minutes. So I'd like to hear those voices. So, with the iPad. Make it a great question. And could you stand, please? Thanks.

### Moderator
Claim: Thank you for this wonderful debate. By I'm from South Korea. My name is Jaeduk Cho and I'm-- yeah, I'm a student there. And I want to clearly state that my opinion has nothing to do with my government's opinion. So my question--

### Moderator
Claim: And with these people.

### Moderator
Claim: So I do believe that the United States has ridden to the top of the world because it was economically stronger than any other nations at that point, at that time. But now, remaining militarily strong but remaining economically weak, how can it be-- how can it-- how can it maintain its position of the leader of the world? Because I do believe that Great Britain has gone down in flames because it has spent too much. And it's as the name of England. So--

### Moderator
Claim: Can I rephrase you slightly?

### Moderator
Claim: Right.

### Moderator
Claim: And maybe--

### Moderator
Claim: Sure.

### Moderator
Claim: --this is not your point, but I think you're saying that-- you're saying that a strong American military is not enough, on its own, to ensure America's security. Is that what you're saying?

### Moderator
Claim: No. I mean, being economically strong is more important than being militarily strong. That is my point.

### Moderator
Claim: I know this side has already argued that point. And I'm not sure this side disagrees with that. Tom Donnelly.

### Conspiracy Advocate (CA)
Claim: I don't think we-- no, we don't disagree with it. Again, we have to keep things in perspective, as-- although I would add to that, we're not suffering from what, you know, the historian Paul Kennedy called imperial overstretch. We're suffering from things like entitlement overstretch. The money that we're spending that's impoverishing us is not going, for the most part, to buy military power. It's going to buy other things that the government does, like provide social services. Whether that's a good thing or bad thing or not, I-- you know, people can reasonably disagree. But that's where the money is going. And if we want to reform both the federal government's books and to boost economic productivity, we can't do it by cutting the defense budget. We have to do it in other ways.

### Conspiracy Advocate (CA)
Claim: Yeah, I would say-- just let me add something to what Tom said. The problem isn't necessarily entitlements, per se. It's the fact that as a people we're not willing to pay for the benefits we vote ourselves. Entitlements are up around 10 percent of GDP, not 3 percent. And they-- the slope line is going up dramatically. And as Robert Rubin said not too long ago, if we don't get a handle, particularly on the medical entitlements, then there's no way we can solve our economic problem.

### Moderator
Claim: Ma'am. Red sweater. This might be the last question, so make it a killer.

### Moderator
Claim: My name is Michelle Dikeman My question is really that the argument against has always been predicated on that we have this huge gap in our technical capabilities over our enemies. But yet I've seen how China and Russia are stealing our intellectual property and using that to make huge advances in their capabilities. So how can you argue that by cutting the defense budget that we're simply going to be able to maintain our dominance when our enemies are using our technology and our technical development against us?

### Moderator
Claim: Boy, that was a well-framed question.

Kori Schake.

### Scientific Advocate (SA)
Claim: Because I don't think our spending is the metric by which you should judge our innovation, our capacity to adapt to things. You're exactly right, the protection of intellectual property is actually probably the most important thing the American government should be negotiating in our trade treaties, because that is the engine of our economy. I live in Silicon Valley, and you can just feel the way that excitement and interaction and people spurring off each other’s ideas. We build better mouse traps. And so I guess I am less concerned than you are because I'm pretty highly confident that we will continue to be an engine of innovation, of new ideas, and that having them steal the design for the original iPod is a dangerous thing, but it's a lot less dangerous when we go on to the iPod 7.

### Moderator
Claim: And that concludes Round 2 of this debate.

## Round 3

### Moderator
Claim: I was late with my hand cue. I'm sorry. Here's where we are. Were about to hear brief closing statements from each debater in turn. These closing statements will be two minutes each. Remember, you voted before the debate. We're going to have you vote again immediately afterwards. And the team that has moved its numbers the most in percentage point terms will be declared our winner. Onto Round 3, closing statements.

Our motion is, “Cutting the Pentagon's budget is a gift to our enemies.” Here to summarize-- we do all of-- the closing statements will all be seated, Kori, thanks. Here to summarize her position against this motion, Kori Schake, a research fellow at the Hoover Institute.

### Scientific Advocate (SA)
Claim: So spending is an input measure. It's one thing you do to create an outcome that you want. And to argue that constraining one element of why the United States is so dominant and so powerful and such a force for good in the world, that constraining that one element will in fact be a gift to our enemies dramatically understates all the other things that go into America being a dominant power, the innovation that you talked about, the economic strengths that you talked about, the value of our ideas, the extent to which who we are and what we are willing to fight for in the world reshapes other people's sense of the possibilities and their future. There are a lot of reasons the United States is powerful and admired and feared in the world. And defense spending, a small cut on the margin of that, is actually not going to have a major perturbation of effect on it. But in fact, spending is much too crude a measure by which to determine whether or not it-- that the United States is giving gifts to our enemies. It's too small a factor in the overall-- in the overall constellation of who the United States is and why it's powerful and dominant in the international order. And that in order to accept our opponents' proposition, you would have to believe that a small change at the margin of a very large defense budget of a very good military would, in fact, have a major influence on the calculations of America's enemies in the world. And Ben and I are trying to argue there's a more complicated calculation than that. More things go into it, and that we need to think in a broader term. And you can accept many of the very good arguments that Andy and Tom made--

### Moderator
Claim: Kori Schake, I'm sorry. Your time is up. Thank you very much.

### Scientific Advocate (SA)
Claim: And still vote for our measure!

### Moderator
Claim: The motion is cutting the Pentagon's budget is a gift to our enemies. And here to summarize his position in support of this motion, Thomas Donnelly. He's co-director of the Marilyn Ware Center for Security Studies at the American Enterprise Institute. Ladies and gentlemen, Thomas Donnelly.

### Conspiracy Advocate (CA)
Claim: Well, thanks to you all for listening to this sometimes unhappy and complex debate. I still think that the basic proposition is pretty simple and straightforward. And I guess that's why I'm not a political scientist and I'm more of a historian because that's the experience that-- and the measures, the outputs by which I would judge this proposition. Kori keeps talking about Americans building a better mouse trap. The world that we have built over the last seven decades is a really good mouse trap. It's a complex mouse trap, as Kori suggested. There are lots of things that go into making a liberal peace. But it's not a liberal peace that invented itself. The Europeans didn't, after five centuries of slaughtering one another and slaughtering the rest of the peoples in the world, decide-- get all together and say, you know, I think we should cut this out. Not even the imperial Japanese. They were defeated in war by the United States, and because of that, they've become liberal democracies and pretty peaceful ones too. So I don't know what the marginal difference will be, but it's not an experiment that I want to make. We've seen what's happened with the marginal cuts of the last couple of years. We see what's happening in Syria today. We see the Chinese messing about in the South China Sea. Are they coming to our shores tomorrow? No. But let's not let it come to that point. A marginal difference. We don't want to know where the last margin of safety is. It's better to have more margins of safety than less. And that's really what this proposition comes down to.

### Moderator
Claim: Thank you, Thomas Donnelly. Our motion is, “Cutting the Pentagon's budget is a gift to our enemies.” And here to support-- here to summarize his argument against this motion, Benjamin Friedman, a research fellow at the Cato Institute.

### Scientific Advocate (SA)
Claim: For the record, I'm for World War II. I think that was a good move for us to fight that. So let's not say that we oppose that. Look, my argument is-- it has two parts. Number one, we can do a lot-- we can save a lot of money while doing all the things we do in the world. If you think we're agents of history and everything in the world is great because of us, fine. Go listen to some of the recommendations out there on how to cut the defense budget by 50 or 60 billion, and you can do it, okay? You can cut the defense budget and still have these alliances. My own view is these alliances and a lot of stuff we're doing in the world are actually bad for our security, so we'd be even better off if we could get out of the business of trying to run everyone else's security for them. Pax Britannica, Pax Americana, a lot of other things were happening in the world at that time. A lot has changed. There were-- it's a disservice to history to say that there's only one factor that matters, which is whether or not there's a hegemon that's trying to manage international affairs. There's a variety of reasons, changes in the international system that encourage peace, absent the benevolence of the United States of America. So I think what we have today is a luxury budget. It's not a defense budget. It protects our safety in the same way a billionaire's restaurant choices prevent his starvation. There's a lot of room-- there's a lot of room in there for us to be safe and cut. So I think cuts to the Pentagon are a gift to ourselves, will make us a bit richer. And in the long term by inducing some choices that we've avoided in the defense budget, they might make us reconsider some policies that actually erode our security and get us into trouble. And that's why cutting the defense budget is not a gift to our enemies.

### Moderator
Claim: Thank you. Benjamin Friedman. Our motion is, “Cutting the Pentagon's budget is a gift to our enemies.” And here to summarize his position in support of this motion, Andrew Krepinevich, president of the Center for Strategic and Budgetary Assessments.

### Conspiracy Advocate (CA)
Claim: One way to think about your vote is if Vladimir Putin were here tonight or the senior generals of the PLA or the Ayatollah Khomeini, how would they be voting, do you think? The issue we debate here tonight is very real for me. For 25 years I wore the uniform of a soldier, and in the 1973 Middle East war we were one order short of arming nuclear warheads. But we were trained. We were equipped. We were ready. Two years later in 1975 I was stationed on a militarized zone in Korea when the North Koreans were digging tunnels underneath us and trying to intercept the resupply ships we were sending out to some of the islands off the coast of South Korea. But we had confidence in our equipment. We had well-trained troops. We weren't looking forward to a scrape but we were ready. Only two years later, after the results of Watergate and Vietnam and inflation and oil shocks really hit home, I was in a unit where we couldn't train, where our troops were hiding toilet paper because we couldn't get toilet paper for our troops, where some of my best soldiers were leaving the Army because they had no faith that the American people were willing to provide what was necessary for us to be a ready unit. And I say thankfully we were not put to the test. We recovered, but it was a very expensive proposition in the early 1980s to put Humpty Dumpty back together again after the military was broken. We were lucky. I wouldn't want to risk our security or our economic well-being on luck, and certainly not the lives of our young men and women in uniform. Thank you.

### Moderator
Claim: Thank you. Andrew Krepinevich. And that concludes our closing statements, and now it's time to see which side you feel has argued the best. We want to have you go again to the keypad at your seat to register your vote. You voted before the debate, we're going to have you vote again now. And the team that has moved its numbers the most in percentage point terms will be declared our winner. Press one if you are in support of the motion, two if you are against it, three if you are undecided. The motion is, "Cutting the Pentagon's budget is a gift to our enemies." It looks like everybody's ready. We're going to have the results-- I'm going to announce the results in about two minutes from now, but first, we regret that Senator McCain has a day job, that he-- we don't regret it, actually we're glad he's doing his day job-- he is there doing it now. He wasn't able to make it, sends his regrets, but we want to bring back to the stage in his place Ambassador Kurt Volker.

### Moderator
Claim: Thank you. So before we get the results of the voting, I just want to raise one question of my own. Was this the best most illuminating discussion of our defense budget cuts that you have heard in this town in a long time? And also is John Donvan the best moderator you've seen do this in-- Now, when we got here there were a lot of the issues that were going to come out. The fact is we are cutting our defense budgets, and the fact is we're going to have to face a lot of choices about what that means and how we manage it. And I think you heard tonight a lot of the things that we're going to be thinking about in the months ahead as we have to work through that process. So I want to thank all of you again for coming this evening and I want to apologize on behalf of Senator McCain that indeed he does have a day job. I was going to say, "Unfortunately, he's stuck working on immigration,” but actually I think I feel fortunately he's working on immigration. So thank you all.

### Moderator
Claim: Thank you, Kurt Volcker. And just a couple of announcements. We'd love it if you tweeted about this debate. Our Twitter handle is @IQ2US, @McCainInstitute, and #Pentagon. Thank you again to the McCain Institute team. We really, really enjoyed partnering with you on this. It was-- it's been a terrific partnership, and I think we both gained out of it. I also want to thank WAMU which carries almost all of our debates and was very involved in letting a lot of you know about this debate and obviously they got through to you because the place is full and we're delighted by that. This was our 75th debate since Bob Rosenkranz brought Intelligence Squared to the United States. And we are happy to be sharing this milestone with everybody here. Our fall season in New York starts in September. Some of the topics that we're going to be looking at include drones, breaking up the big banks, the case for going vegan-- that's not a Washington topic. Gun-- gun control and immigration. Our tickets go on sale later on this summer. For more information and to purchase tickets, visit our website at www.IQ2US.org, and don't forget to visit the McCain Institute for International Leadership's website, and that is at McCainInstitute.org, for all of their upcoming events. They have a full schedule constantly, things happening here in Washington DC. We wanted to encourage you to take a look at the encyclopedia and look at Dwight Eisenhower, circa 1939. We actually pulled the photograph. We've looked at it. But I don't want to put it up on the screen without your permission. Go ahead? We have your permission? Switched at birth or what? All right. Thank you for being a good sport. That was great. All right. We've had-- I now have the final results. You have voted twice, once before the debate, and once again afterwards, after hearing all of the arguments. Here is the result. The motion: Cutting the Pentagon's budget is a gift to our enemies. Before the debate, in polling the live audience, 22 percent of you agreed with the motion, 57 percent were against, and 21 percent were undecided. Those are the first results. Remember now, the team-- after you vote the second time, the team that has changed the most numbers in percentage point terms is declared our winner. Onto the second vote. Cutting the Pentagon's budget is a gift to our enemies. The team arguing for the motion in the second vote went from 22 percent to 29 percent. They picked up seven percentage points. That is the number to beat: seven percentage points. Now, the team against the motion in first vote was 57 percent. The second vote, 65 percent. That is eight percentage points. It's enough to win, just barely. The team arguing against the motion that cutting the Pentagon's budget is a gift to our enemies has been declared our winner. Congratulations to them. And thank you from me, John Donvan. We'll see you next time.
