# Debate Transcript

Topic: Ban College Football
Motion: Ban College Football

Debate ID: ban-college-football


## Round 1

### Moderator
Claim: And now I'd like to introduce, to set up and frame the debate, the chairman of the board of Intelligence Squared U.S., Mr. Robert Rosenkranz.

### Moderator
Claim: Well, thank you and welcome. You know, my own experience of college football consisted of attending occasional games at Yale Bowl. When I was lucky enough to have a date, she usually knew more about the game than I did. I was a bright, nerdy kid. And when I got into a position to hire people, I looked to hire people like myself. But with maturity and experience, I came to value a varsity football background very highly indeed. Often that bespoke the discipline to work very hard, the perseverance to suffer defeat and endure pain, the personality to be part of a team and sometimes the charisma to lead one.

A healthy mind and a healthy body. What's wrong with that ideal? Well, nothing, except it has very little to do with college football as played at the big state colleges, the Texas, Georgia, Florida, Louisiana, Michigan and the recently infamous Penn State. These are big businesses. They generate profits of 40 to $50 million a year, sometimes more. The coaches are paid more than university presidents. And the athletes are offered all manner of tawdry inducements, often making a sham of their amateur status. They can emerge with little real education, but often with some very real brain injuries resulting in elevated risks of dementia at a young age.

Libertarians would argue that all sorts of sports and recreational activities are risky; motor car racing, downhill skiing, climbing mountains and on and on. And a decent respect for human liberty dictates allowing adults to assume the risks they choose. But query if a small-- if a poor high school student offered an athletic scholarship to play big-time football is making an informed choice or a mature one. And for the colleges, is big-time football a valuable source of funding for other athletic programs? Is it an object of school pride that drives bigger donations from alumni and more generous funding from state legislatures? Or is it a corruption magnet, corrosive with the meaning and purpose of the university itself. Clearly, there's a huge public interest in these issues.

We've rarely had a debate that was sold out so quickly or that garnered so much pre- debate publicity. So let the game begin. Panelists, John, over to you.

### Moderator
Claim: Thank you very much. And I'd like to invite one more round of applause for Robert Rosenkranz for-- Yes or no to this statement, "Ban college football," and jaws drop all over. Yes, we are talking about that time-honored sport, football in the place where it first mattered, college. And we are talking about banning it. Welcome to Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters, two against two. And for a taste of the kind of poetry and passion and pain that comes to bear when we discuss the meaning of football, I just want to give you a taste, a sample of what one NFL player wrote back in 2001 about playing through pain.

He said, "To this day, I will encourage people to feel the knob below my neck where the collarbone was sprung free from my sternum in the middle of a game against the 49ers. That was pain." And he loved it. So are we talking about madness, or are we talking about courage when we debate the question of banning college football. Let's meet our debaters. On the side arguing for the motion to ban college football, Buzz Bissinger, a Pulitzer prize-winning writer and author of the book, "Friday Night Lights." His partner is Malcolm Gladwell, a staff writer at the New Yorker and author of four best-sellers, among them "The Tipping Point." Arguing against the motion, arguing not to ban college football, Tim Green, a college football hall-of-famer and former Atlanta Falcons defensive end.

And his partner, Jason Whitlock of foxsports.com, national columnist and former offensive tackle for Ball State University. Our motion is, "Ban college football." Let's talk to our debaters. Let's talk to our debaters. First, Buzz Bissinger. And Buzz, in 1990, you wrote a book called "Friday Night Lights." It is considered a classic of sports journalism about a small town, Odessa, Texas, and the trials of its high school team. It is considered by Sports Illustrated the fourth greatest sports book of all time.

A movie came from it, a television show. And you have said that you, while critical of what you saw, you have said that you love the sport and that violence is why we like it. So are you on the wrong team here?

### Conspiracy Advocate (CA)
Claim: Well, I don't think so. I think violence is why we like it. And, look, nobody has ever accused me of being consistent about anything. I also think there's a vast distinction between what we're arguing here, which is college football versus pro players who are being compensated very, very well for what they do and know the risks going in. College players receive nothing beyond a scholarship that is really of questionable value because of the demands placed upon them. So I think what I've said is very consistent.

### Moderator
Claim: All right, Buzz Bissinger, let's meet your debating partner, Malcolm Gladwell. Malcolm Gladwell who can't seem to help but writing best-selling books, "Blink," "Outliers," "The Tipping Point."In the New Yorker, you've written about everything from innovation to ketchup to social media and, of course, your piece that helped inspire this debate, the one where you compared college football to dog fighting. You're also Canadian. Canada has football. Is it any different in Canada?

### Conspiracy Advocate (CA)
Claim: Well, the difference in Canada is that we don't care about football.

### Moderator
Claim: Thank you, Malcolm Gladwell. Our motion is "ban college football." And here to meet the team arguing against the motion in support of college football, Tim Green. Now, I, earlier in the program, read a quote from somebody who said, "Come touch the knob on my neck." And that was you, Tim Green. And we're all going to line up and do that afterwards, but-- this paean to punishment you wrote.

### Moderator
Claim: I'm not touching his mouth.

### Moderator
Claim: I-- I--

### Scientific Advocate (SA)
Claim: You're going to go there already? Come on, we've got to have some class on this side of the auditorium.

### Moderator
Claim: Jason, I totally deliberately stayed away from that line myself.

So this paean to punishment that you wrote, what is that about? Why-- why the glory of the pain?

### Scientific Advocate (SA)
Claim: It's how much can you take, how much can you take and keep going? And I think that's one of the great lessons of the sport of football, and I think that's why it's great for our youth. It's great in little league. It's great in high school. It's certainly great in college because it teaches kids that life is tough. Things are tough. And then you pick yourself up, and you go on. I think it's the greatest lesson in the game, and I think it's the greatest game that we play.

### Moderator
Claim: Thank you, Tim Green. And let's meet your debating partner arguing against banning college football, Jason Whitlock. And Jason, you are also a former player. You were an all-state offensive lineman in high school and an offensive tackle at Ball State University where you got a degree in journalism. You are on record, Jason, as saying that you are in favor of paying college players to play the game. So if you were given the choice nowadays back at Ball State, would you play for free?

### Scientific Advocate (SA)
Claim: If we were playing back in the '80s, early '90s when I played, absolutely, because I thought the exchange was fair then.

Coaches and football wasn't generating as much money. And I was prepared to take advantage of the currency that they were paying me in education. Not all of my teammates were. So yeah, I would do it all again.

### Moderator
Claim: All right. Thank you, Jason Whitlock. Ladies and gentlemen, our debaters. So this is a contest. And in this debate, one team will win. The other team will lose. And, our live audience, will choose our winners by your vote. Let's go to the first round of voting now. The keypad at your seat will register where you stand on this motion at this point as you come in off the street. The motion is "ban college football." And if you agree with the motion, press number one. And if you disagree with the motion, number two. And if you're undecided, push number 3. And at the end of the debate we will have you vote a second time and at that point we will reveal the results of both numbers and the team that has moved its numbers the most will be declared our winner.

So we go in three rounds. The first round is uninterrupted statements by each debater in turn. They are seven minutes each. So on to round one. And speaking first for the motion, "Ban college football," like to introduce Malcolm Gladwell. He is a New Yorker staff writer. And, Malcolm, you can make your way to that lectern. Malcolm Gladwell is a New Yorker staff writer, chronicler of the counterintuitive, and author of "Outliers Blink" and "The Tipping Point." Ladies and gentlemen, Malcolm Gladwell.

### Conspiracy Advocate (CA)
Claim: Thank you. I should say before we start that I haven't debated since college and that was many years ago. And that was in Canada, and in Canada a debate isn't really a debate, it's simply an alternate mechanism of reaching consensus. So this is all very new and exciting for me. I want to make one thing clear before we start and that is that this is not a debate about banning football nor is it a debate about whether there are merits to playing football.

You will hear I'm quite sure from Mr. Green and Mr. Whitlock that all kinds of wonderful things happen when you play football, you learn camaraderie and discipline and teamwork. All of those things are true, and neither Buzz nor I are going to dispute any of them. This debate is about a very specific question. Right now in colleges across the country schools field football teams for the purpose of offering recreation to the players and offering entertainment to fans and students and alumni. And the question is, is that appropriate. Buzz is going to say, "That's not appropriate because the players are exploited," and I'm going to say that, "It's not appropriate because schools should not be in the business of encouraging young men to hit themselves over the head." Let's talk a little bit about hitting over the head. Start with a very simple-- the simple physics of football.

The human brain is a mass of soft tissue that is suspended within a hard skull, right? Every time you get hit, that soft tissue rattles around inside your skull. And the effect of that rattling around is to stretch and sometimes tear the connections between your nerve cells. In the course of everyday life, that almost never happens. In the course of playing football, that happens all the time. It is not unusual in the course of a game for a player to sustain hits to the head of between 40 and 100 Gs. To put that in perspective, if you were to get in your car and not put on your seatbelt and drive at 25 miles an hour into a brick wall so that your forehead struck the dashboard of the car, that would be a hit of 100 Gs, right? If you reversed your car and went and did it over and over again so that you hit the brick wall 30 to 40 times at speeds between 20 and 25 miles an hour, that would be the equivalent of a football game. If you reversed your car and over the course of the next three months drove it at 25 miles an hour into a brick wall 1,000 times, that would be the equivalent of a college football season.

Now, you're going to hear from Mr. Whitlock and Mr. Green, they're going to try and tell you that there are ways around this fact, that if we have better rules or better treatment of concussions or better helmets, the effect of that kind of injury can be minimized. That is a fantasy. There are ways to cut down on the number of concussions, but concussions are only a small part of the problem. The real issue is all of those thousands of tiny hits. There isn't a helmet in the world that can be designed that can take the sting out of those hits, and there is no way to play this game of football and remove those hits without turning tackle football into touch football, and the last I checked this was not a debate about whether we should ban touch football on college campuses. I once watched a football practice at the University of North Carolina where the players were playing without pads; they were just doing a simple scrimmage.

In the course of 20 minutes, one of their running backs sustained hits to the head of 79, 60, and 30 Gs. In 15 minutes, he had the equivalent of three car accidents. Now, what's the effect of all of that neurological trauma? Well, we know. It's a condition called, "CTE," which brings about premature death and the equivalent of Alzheimer's in people who are as young as 40 years old. I've seen pictures of the brain scans of people with CTE and it looks like someone drove a truck across their brain. Now, we don't know how many ex-football players have this condition because you can't diagnose it until they die, until you do an autopsy of your brain, but there are people who estimate there are as many as 20 percent of football players who have this condition. And we also know that there are players as young as 18 years old who have been diagnosed with CTE. It’s a problem that begins in high school and is made worse during college.

Now, I have no problem whatsoever with grown men in full possession of the facts and risks of the game choosing to participate in a potentially lethal profession, right? I have no problem with people who smoke cigarettes, I have no problem with people who do deep sea diving, I have no problem with people who want to drive their motorcycle without a helmet on. If you want to play Russian roulette with your brain, fine. But college is a very, very different matter. Every single college in this country, rich or poor, big or small, is supported by the taxpayer dollars of the people in this room. They are subsidized by us, they are given immunity from taxes, they are supported by laws of Congress, by acts of local legislatures. They are in every way funded by the people in this room. And the reason for that special relationship between us and the world of higher education is that they are charged with a sacred trust, and that is to prepare the minds of young men and women to lead lives-- the minds of young-- to lead productive lives as full citizens of the United States.

And nowhere, nowhere, in that social contract does it say that it’s okay to promote and encourage young men to hit themselves over and over again in the head in the name of entertainment. Thank you.

### Moderator
Claim: Thank you, Malcolm Gladwell. Our motion is "ban college football," and here to speak against the motion, Tim Green. He’s a college football hall of famer, a former Atlanta Falcons defensive end, a lawyer, the author of 26 books. He has been called the renaissance man of sports by both Sports Illustrated and The LA Times. Ladies and gentlemen, Tim Green.

### Scientific Advocate (SA)
Claim: Thank you. Can I have the two minutes Malcolm didn’t use? Okay. When I was first asked to do this, I-- of course I asked permission from my wife, as any good husband will, and when she said, “Well, you know, what’s the debate?”I said, “Ban college football or not.” She said, “Well, that’s ludicrous. You know, you’ll win that debate.” I said, “Yeah.” She said, “You can win the debate, can’t you?” I said, “Absolutely.” She said, “Well, who are you debating?” I said, “Buzz Bissinger, Malcolm Gladwell.” She said, “You’ve had too many concussions.” And I have. And I have. And I agree with our opponents, Mr. Gladwell and Mr. Bissinger, in a lot of ways. Football is a brutal game and I have grave concerns about concussions and the impact of concussions. I also agree that I think college football players, because of the revenues that they generate, should be paid I think a small stipend. I think that they deserve that. And so in some ways I do agree with them. But banning college football-- I mean, so I had to first-- I had to get over my initial horror at the notion because, of course, football for me has done a lot of tremendous things.

And then I looked at, you know, just our country, our society in general, and I thought about football and what it does in the colleges and how it’s a unifier. Not just the guys on the teams, not just unifying people from different places and different ethnicities and different religions into one solid unit that learns to work together, but unifying a campus, unifying the students, unifying the faculty, unifying the alumni, unifying sometimes entire towns, communities, and whole cities. And so, in that respect, to me, I said, you know, “How could we? How could we ban”-- college football is a wonderful thing. But then I wanted to look at it and I wanted to look at the numbers, because obviously my opponents are highly intelligent men, they’re passionate men, they’re very learned, and I said, you know, “What is it? What’s behind this?”And so I looked into the numbers as far as what does college football-- what are the benefits of college football and what are the detriments? Well, the detriments certainly are the head injuries. Now, I’ve got to say this because we’ve got to get things straight from the beginning about the concussions and the g-forces, because Mr. Gladwell talked about 100 g-forces when you hit your head into a brick wall at 25 miles an hour 30 times a game. That does not happen in a college football game. That does not happen in an NFL football game because when you get hit at 120-- at 100 Gs, you get a concussion, and when you get a concussion, now more than ever, you are taken out of the game and you are put into some rehab program. Now, back when I played, back when Jason played, it wasn't like that. It was-- do you know where you are? No. How many fingers do I have up? Four. Okay. That's close enough. You're ready to go back in.

It's not like that anymore. And so the game is evolving to become safer and safer, as safe as it can be. But it will never be completely safe. It won't be completely safe. So what I said to myself is, well, let me look at some things that are maybe as unsafe or maybe even more unsafe than playing the game of football. And so, of course, automobile accidents came to mind because the mortality rate is about a hundred times higher for men in that age range that they're going to die in an automobile accident than they're going to die on the football field. And then I said, well, look, how about-- how about going out and riding your bicycle? That's right. That's more dangerous, or downhill skiing. And then I said, well, let me look at sports. And so I went to the NCAA, and I looked at their sports, and I looked at a study that was done at the University of North Carolina. I looked at the study of the fatalities, direct fatalities and the sports that are more dangerous than football. Equestrian riding, female downhill skiing, lacrosse, water polo and baseball.

And then I went to indirect fatalities, and I looked, and I found that rowing, basketball, skiing, water polo and swimming are all more dangerous than football. And so if we're going to say, well, football has to be banned, then I think it's only right that we pretty much have to ban all college sports if we're going to do it based on the risks and the safety. The other thing that I just have to disagree with, with Mr. Gladwell-- and I know this is dangerous territory for me-- but he talked about grown men. And to suggest that college football players at the age of 18, 19, 20, 21 are not grown men, it's-- that's just not true because we'll take 18, 19, 20-year-olds, and we'll send them off to Afghanistan or wherever in the world we need them to help protect our country. And those are grown men. And so at the age of, you know, majority, at 18, I think that they have the-- they have the right to make that decision.

So those are the things that are maybe against. And I don't think that it's that dangerous. What are the things that are for? Education. Mr. Bissinger said, well, you know, all you get is a scholarship. All you get is a scholarship? If you go to my alma mater, that's a $250,000 plus scholarship. That's the value of that education. So you do get an education. How many scholarship football players are there in this country every year? 23,000. And the surplus from the game of football is used for what? Well, maybe it is for research, maybe it is for physical but a lot of it is also used for Title 9, for opportunities for women athletes to enjoy scholarships and enjoy educations that they might never have had before. And to suggest that football and sports aren't educating, especially football, aren't educating students, I looked at that too. In the general population, students have a graduation rate of 55 percent in this country, and it's going down.

It's of grave concern. NFL-- college football players in the last 25 years have gone from a 60 percent graduation rate to a 70 percent graduation rate. So not only are they being educated, they're being educated at a higher and better rate than their peers. For me, the game of football-- and I-- well, I was serious about the lessons of football on an individual basis of teamwork, hard work, perseverance and tolerance. And I know my partner, Jason is going to talk more about that when he has his turn. Those are wonderful lessons that, for me, were an education in and of themselves. So I hope that you will all vote tonight to not ban college football. Thank you.

### Moderator
Claim: Thank you, Tim Green. And here's a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan.

We have four debaters, two teams of two fighting it out over this motion, "Ban college football." You have heard two of the opening statements, and now on to the third, debating in support of the motion, "Ban college football," Buzz Bissinger. He is a winner of the Pulitzer Prize for investigative reporting and author of several bestsellers, including "Friday Night Lights," his newest book is called "Father's Day." It's due out on Sunday. Ladies and gentlemen, Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: Thank you. You know, it seems to me that given that this debate is taking place at a university that is one of the greatest and most innovative in the country that doesn't have football, I think this debate ends right now. Our nation is at a cornerstone. There's no doubt about it. We are questioning everything, tax rate, rich versus poor, who are we? What are we? In a very intense— the most competitive global economy we have ever faced.

And one of the things that we are looking at and must look at which makes this debate pertinent is the role of the university. It is pivotal. Questions over course offerings, allocation of resources in a very difficult era as governors are slashing to the bone, dwindling money, rising tuition. And yet, a recent book by two sociologists, Richard Arum and Josipa Roksa says that basically undergraduates embrace college life, and it is shaped and oriented to nonacademic endeavors. The amount of study time has gone-- and this was by two labor economists. Study time in colleges has gone from over 40 hours in the 1960s to 20 hours in the 1980s to currently 13 hours of study time. And I believe that at the top of what has become the university distraction, the distracted university is football, is football.

It sucks all the air out of the room. The amount of money that coaches make is insulting. It is insulting when a coach is making five to 10 to 15 times more than a college president. What does it say? What does it say about the priorities of a university? It says that the head coach runs the school. And make no mistake. That was the tragedy of Joe Paterno. He did run Penn State. He did run Penn State. And I know he ran Penn State because when Graham Spanier went to his house in 2004 and said, "Joe, it's time to retire," he threw him out. They never spoke for 10 years. Joe ran that school.

And when it was his chance to do what was the morally right thing to do, which was to go to the police, the culture of omerta that surrounds football, he did nothing except harbor a suspected child molester. This is what we're dealing with in football. A few facts in what they call the football bowl subdivision, the big 125 schools. Spending per student in those schools, $13,471. Spending per athlete, $91,053. 6.8 times as much for a student athlete. In the famed SEC, 11.6 times as much. It's become a facility arms race. $15.2 billion spent on new athletic facilities, in particular, stadiums between 1995 and 2005. 20 percent of current spending that by the way is not included in a lot of the revenue statements you'll see in NCAA reports. And that's not from me, that's from Andrew Zimbalist who is considered the leading sports economic professor in the country from Smith College. 20 percent of current spending is on facility expansion, which is wonderful except what happens if these teams stop winning? People will not go. They will not go. From USA Today June 16, 2011, more than $470 million, more than $470 million, most of it in student fees by students who do not play sports went into subsidized college athletic programs, in particular in football. And this is in the era, a national trend of declining state support, tuition increases and salary freezes. How many football programs have cut their budgets? A few did in 2010, but it's back up. It is back up. It is back up.

Salaries of coaches, I mentioned it, average salary for a football coach, $1.47 million. That's up 55 percent in six seasons. A professor, 1986 to 2007, his salary went up 30 percent. The college president, 100 percent. The football coach, 500 percent. 500 percent. And I defy both of you to tell me why Urban Meyer deserves, of Ohio State, $24 million over six seasons. I defy you to tell me that. I defy you to tell me why Mack Brown deserves $5.192 million, not to mention the $850,000 bonus he will get. And I can go down the ride. Not to mention David Cutcliffe at Duke, which has a terrible football program, but we're seeing $1.762 million.

And there are all these myths, all of these myths, character, character from CBS/SI poll in 2011, 7 percent of college football players, 7 percent have criminal records, 7 percent. 2,837 players, they studied the top 25 programs, at the top of the list, Pitt, Pitt, 22 players on the team in 2010 have been charged with a crime. Myth, increased alumni giving, myth, 2005, Robert Frank of the Johnson School of Management at Cornell, existing empirical literature supports that success of big time athletics has little if any systematic effect on the quality of incoming freshmen in institutions able to attract. That's the-- one of the things about football is it attracts better students…it does not. It attracts more applications but the students are of low caliber. Myth, football gives back.

Untrue, untrue, and I'll go into that later. Graduation rates, graduation rates. NCAA has the most ridiculous formula, the graduation success rate, now they've included the Ivy League, it's ridiculous. And 69 percent, and what is worse, what is worse is that the racial gap between blacks and whites is despicable. I'm done.

### Moderator
Claim: Thank you, Buzz Bissinger. The motion is, "Ban college football." Our motion is "Ban college football," and our final debater against the motion is Jason Whitlock. Jason is a national columnist with foxsports.com, he's a contributor to Fox Sports Radio, he lettered as an offensive tackle for Ball State University, and he was the first sportswriter to win a National Journalism award. Ladies and gentlemen, Jason Whitlock.

### Scientific Advocate (SA)
Claim: See, I mean, if we lose the debate, I should be blamed because I anticipated all of their arguments and if I do it justice, I will prove how ridiculous their arguments are or just-- not ridiculous because--

### Moderator
Claim: No, ridiculous.

### Scientific Advocate (SA)
Claim: --Mr. Gladwell and Mr. Bissinger are two of the brightest minds that dabble in sports. No, no, no, no, no, no, no, no, no, no. I did not mean that dismissively. Trust me, if you've read their work, if you've read their work, they do much higher end stuff than just sports, and I'm-- they're lending their brains to sports occasionally. But again, I don't mean that-- I mean that with all due respect. We need to keep him-- I will not match Buzz's intensity or passion.

I think I can match wits with him and Mr. Gladwell. Keep in mind, Mr. Gladwell is a Canadian and you guys are-- I'm not playing this for jokes, I'm being serious. We live in a republic, a democracy. Capitalism is our economic system. The thing we value the most is freedom. We're American and if you believe in freedom, you can't have the free without the dumb. You can't have it. They go hand in hand. Freedom allows you to do dumb things, things we find reprehensible. And I would agree, you can put football right in there with cigarettes, alcohol, porn, everything else, things that we tolerate and enjoy here in America, but you cannot separate them.

And everything in America is connected to freedom and to capitalism and to democracy. And so you can't remove our institutions of higher education from capitalism and from freedom. You can't. We don't do that in America. We let capitalism exploit everything whether we like it or not. And so football has to be tolerated no different than Ronald McDonald. Ronald McDonald has done far more damage to America than any football coach, any of these overpaid coaches that he's talking about. Mr. Bissinger argues rightfully, these coaches are overpaid. Ronald McDonald was overpaid, Hugh Hefner’s overpaid, Jenna Jameson’s overpaid, what-- Charlie Sheen’s overpaid. That’s America. Bissinger argues in the Wall Street Journal and a little bit today that football is removed from the academic experience. He is wrong. People don’t understand football. Many football players don’t even understand football. But, and I mean this respectfully, I’m not playing this for laughs, I’m not trying to be dismissive, Mr. Gladwell, Mr. Bissinger, some of our brightest minds, have not participated in football. And many of you in this audience have not participated in football. Football, whether we like it or not, whether you understand it or not when I say it, but football is America. It is the melting pot. College football is the highest level of the melting pot. Football is the Statue of Liberty.

College football. Your huddled masses, your poor, your tired, people yearning to breath free. I was one of those kids. Football was my access into the mainstream and a better life. My dad didn’t graduate from high school, my mother was a factory worker. I was the first person in my family to go off to college. Football brings the poor and the rich, the black and the white, the Jews and the gentiles-- it brings everybody together, particularly at the college level. Your high school experience, for the most part, is segregated. Your little league experience is segregated. Once you go all the way up to the pros, it’s more segregated because football is a game best played-- pardon, Tim’s an exception-- by the most desperate people on the planet. It’s like boxing. That’s why so many of the football players have hard luck stories in the National Football League.

They came from nothing, they had no other choices, so they had to be good at football. But on the college level, everybody comes together. And I personally played next to-- I was a tackle, the guy next to me, right guard-- keeping it real, don’t laugh. The guy next to me was a bigot. His mom left his dad for a black man and he couldn’t get over it, and he was a bigot. We were very good friends. We’re still very good friends. We found common ground through football. College football, the bringing together of this diverse cross section of people pursuing one goal. If they understood it on college campuses, they would teach college football, they would come and study college football and learn things so that-- I’m a part of the media. I watch our major broadcast media and I watch the clueless, people that don’t have the diversity of experience that I have through college football and through life and I watch them consistently tear this country apart.

I watched them do it with George Zimmerman, OJ Simpson, Rodney King. Whatever the big media story. Barack Obama. Consistently tear this country apart. The reason why-- and if people have ever read my column and understood my perspective, the reason why I never lose faith in America is because of my college football experience. I have seen people of different backgrounds overcome tremendous differences to compete for one goal. That’s what we allegedly are trying to do here in America. I think the argument to ban college football is being argued by well-intentioned people who don’t clearly understand the sport.

America is imperfect. The Statue of Liberty does not promise perfection. Our Constitution doesn’t promise perfection. We pursue perfection. College football needs to be reshaped, remade, less games, less practice, less padded practice--

--share some of the money with the coaches.

It does not need to be banned.

### Moderator
Claim: --I’m sorry, your time is up. Jason--

### Scientific Advocate (SA)
Claim: It does not need to be banned.

## Round 2

### Moderator
Claim: Your time is up. Let’s give a round of applause. Thank you, Jason Whitlock. And that concludes round one of this Intelligence Squared U.S. debate. And now we go onto round two, which is where the debaters address each other directly and also answer questions from you in the audience and from me. We have two teams of two who are arguing out this motion, "ban college football." Arguing for the motion, we’ve heard from Buzz Bissinger and Malcolm Gladwell. They’re arguing that college football is something like a kind of toxic spill in this society.

They make two kinds of arguments, one, the medical argument that it abuses the players, hurts them physically, literally is rattling the brains in their heads, and a financial argument that college football twists universities' priorities so that these schools are less in the education business than they are in the football business, that in these-- on those campuses, football becomes a distraction. The team arguing against the motion, Jason Whitlock and Tim Greenfield, they both played in college, and they are arguing that football is a great unifier for the players and for schools. For the schools, they provide identity and loyalty. For the players as individuals, they provide character and discipline and a shot at education that many of them may not have had. And they also dispute almost all of the medical claims made by the other side. So we want to have them mix it up now. And I want to go to the side arguing against the motion. Your opponents are making a very broad philosophical argument that college football, as it stands now has no place on university campuses because it makes the schools more about football than it does about education, that this actually causes harm-- you make the argument that it's good for the players.

They're making the argument, maybe so, but it's bad for everybody else because it just messes up what the school is supposed to be about, messes up the finances. And they broke this down to a very specific question: Why should these coaches be making millions of dollars and millions of dollars more than the president of universities?

### Scientific Advocate (SA)
Claim: Why shouldn't they be making millions of dollars more? Why-- I mean, this is America. And Jason said it. This is a country where we allow pop stars and rappers and hedge fund managers-- we allow people to make whatever the market determines that it should make. And I don't understand why we would begrudge anyone any amount of money--

### Conspiracy Advocate (CA)
Claim: Wait. That’s your defense, that hedge fund managers are just as bad? At this point can’t we declare the debate over?

### Scientific Advocate (SA)
Claim: What I'm saying is I don't-- I wouldn't begrudge-- I don't begrudge you the revenues from your wonderfully successful books or Buzz, "Friday Night Lights." We're all big fans. I don't begrudge you that. Whatever you get is what you get. And whatever the market determines, that's what you earn.

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: I understand, but first of all, these are not for profit institutions. Second of all, athletic departments are notoriously bureaucracy heavy, notorious. Ohio State has an athletic department of 478 people which is twice as much as the English department at Ohio State. So let's face it. It ain't about capitalism because they're nonprofit institutions. They're not responsible to stockholders. Plus, the Knight Foundation, which has studied football and sports more than any entity in the country in the past 20 years has said there is absolutely no correlation between a winning record and the amount of a coach's salary.

### Scientific Advocate (SA)
Claim: You talk about what's wrong--

### Moderator
Claim: Tim Green.

### Scientific Advocate (SA)
Claim: --with football with academics, right? You talked about--

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: --13 hours a week studying. Guess how many hours a week football players study?

### Conspiracy Advocate (CA)
Claim: 20.

### Scientific Advocate (SA)
Claim: 40. 40 hours a week. I talked about the graduation rate--

### Conspiracy Advocate (CA)
Claim: 40 hours a week what?

### Scientific Advocate (SA)
Claim: You talk about the bureaucracy and the money that's spent on football, maybe that money, maybe the general student population--

### Conspiracy Advocate (CA)
Claim: 40 hours a week doing what?

### Scientific Advocate (SA)
Claim: 40 hours a week studying, 40 hours--

### Conspiracy Advocate (CA)
Claim: Where'd you get that from?

### Scientific Advocate (SA)
Claim: --a week playing football. From the NCAA.

### Conspiracy Advocate (CA)
Claim: I think-- personally, I think--

### Scientific Advocate (SA)
Claim: Listen, you know, Buzz, let's not get into where we got stuff, where you got your numbers where I got mine.

### Moderator
Claim: Buzz hang on a second and just let-- Buzz, hang on a second. I'll come back to you. Okay. Go ahead, Tim. Finish your point.

### Scientific Advocate (SA)
Claim: So-- so football's doing a good job. They're doing a good job educating their players. They're educating them at a better and a higher rate than the general population. Maybe academia should take a page out of the playbook from the football program.

### Moderator
Claim: Malcolm Gladwell, your opponent said-- your opponent's made the point-- Your opponent's made the point that football players' rate of graduation is actually increasing. Can you take that on?

### Conspiracy Advocate (CA)
Claim: Well, first of all, that's small comfort if you get a degree in a short term and a massive brain injury in the long term. But secondly--

### Scientific Advocate (SA)
Claim: You can't--

### Moderator
Claim: Let him finish.

### Scientific Advocate (SA)
Claim: But you can't say that.

### Moderator
Claim: Let him finish.

### Conspiracy Advocate (CA)
Claim: The other thing that I-- almost everything that our two opponents said, I agree with if they simply substituted in another sport for football, right? The issue is not that football does all kinds of wonderful things. Of course it does. Do football players graduate? Of course they do. Do they learn all kinds of wonderful character things? Absolutely. But do we have to bash them over the head in order to communicate those virtues? Why can't they row? Why can't they kick a soccer ball? Why can't they--

### Scientific Advocate (SA)
Claim: They can, but those sports won't generate--

### Moderator
Claim: Jason Whitlock.

### Scientific Advocate (SA)
Claim: They won't generate enough money to sustain themselves. And again, I just want to go back to--

### Conspiracy Advocate (CA)
Claim: It's about money now? They have to get hit over the head because they can't get money otherwise?

### Scientific Advocate (SA)
Claim: In terms of funding all the other sports you're talking about that you like. Yes, they do have to get hit over the head on Saturdays to pay for that, absolutely.

### Conspiracy Advocate (CA)
Claim: But Jason, Jason, you're--

### Scientific Advocate (SA)
Claim: To pay for the rowing team and the soccer team and all the other sports that no one cares about. Yes.

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: Your argument is a perfect argument for why football should not be at academic institutions. Make it into a minor league system then. You'll get the same benefits that you're talking about. The melting pot-- by the way, the melting pot also, I think, includes Latinos and Asian-Americans. And if you can name four Jews who played football, you win the debate.

### Moderator
Claim: Tim Green.

### Conspiracy Advocate (CA)
Claim: And I can name you the only one, which was Sid Luckman from Columbia.

### Moderator
Claim: Tim-- Tim Green.

### Scientific Advocate (SA)
Claim: Malcolm, Malcolm, all due--

### Conspiracy Advocate (CA)
Claim: However,

### Scientific Advocate (SA)
Claim: Malcolm, wait. I'm talking to Malcolm now. I'll talk to you out back later on.

### Conspiracy Advocate (CA)
Claim: I'm going to kick your ass!

### Scientific Advocate (SA)
Claim: And I will defy you, Buzz Bissinger.

### Moderator
Claim: Tim Green.

### Scientific Advocate (SA)
Claim: Malcolm, you know, all due respect, you're talking about all this damage that's done to the brain, okay? Show me the studies.

Show me proof, because what I'm looking at right here is indirect fatalities. You said, why couldn't they be rowing? Per hundred thousand students, student athletes, in rowing, how many indirect fatalities a year? 16. How many in football? 2.2. So why are we going to let them row?

### Conspiracy Advocate (CA)
Claim: But you, it's--

### Scientific Advocate (SA)
Claim: Look, you've got to look at numbers. You can't just say-- you can't just throw it out there and say, oh, it does all this damage, a hundred Gs which is-- that's not correct. All this damage to the head. Look, if there is long-term damage to the brain, okay, and maybe I'm living proof of it. But if there is long-term damage to the brain, I'm the first one to say, boy, maybe we should look at it. But do we eliminate all these other--

### Conspiracy Advocate (CA)
Claim: Well, you can't--

### Moderator
Claim: Malcolm Gladwell.

### Scientific Advocate (SA)
Claim: --sports as well?

### Moderator
Claim: Malcolm.

### Conspiracy Advocate (CA)
Claim: Here's the thing. At that moment in your-- in your remarks when you were comparing fatality rates between sports, I was incredulous.

### Scientific Advocate (SA)
Claim: I was too.

### Conspiracy Advocate (CA)
Claim: We're not talking about-- I'm not talking about fatalities on the field. We're talking about long-term health consequences that show up 20 and 30 years later.

### Scientific Advocate (SA)
Claim: Show me the studies.

### Conspiracy Advocate (CA)
Claim: Here's why we don't know what the long-term consequences of football are, because you have to shoot yourself and have an autopsy before we know whether you have CTE in your brain.

### Scientific Advocate (SA)
Claim: Yeah, but-- you know what? Let me--

### Moderator
Claim: Jason Whitlock.

### Conspiracy Advocate (CA)
Claim: --diagnose it until you're dead.

### Moderator
Claim: Jason Whitlock.

### Scientific Advocate (SA)
Claim: I think, though, we're so caught up in the Junior Seau, Dave Duerson and the aberrations. I don't think that's the norm. I don't think that-- and yes, they make news, and they-- we can write about them, and people will be interested in it. I think what we're arcing, Malcolm, is that's not the case for the overwhelming majority of people that play football, because the overwhelming majority stop in high school. And then the next big group stops at college. And now we have some examples of a few pro athletes that have had these amazing problems. We haven't seen the studies that say college athletes--

### Moderator
Claim: The two--

### Scientific Advocate (SA)
Claim: --in any significant number have these problems.

### Moderator
Claim: Jason, the two of you who have played, I want to ask you, I mean, given the arguments made on the other side, you both probably hit your head a bunch of times.

I mean, they're arguing you're two very successful guys, you might be a lot more successful if you hadn't played football. But do you actually worry about the statistics that Malcolm is citing, since you both have played the game? Do you worry about it?

### Scientific Advocate (SA)
Claim: I have concerns, but this is the cell phone syndrome, folks. Ten years ago, people said, "Cell phones, cell phones next to the head. It's brain cancer. Cell phones, brain cancer." And everyone said, oh, my gosh, cell phones, brain cancer. And I'm walking around, my wife's saying, "You can't use your cell phone. You can't hold it next to your head." And I started to believe it. I'm like, yeah, yeah, I've got to use my speakerphone. I've got to use the thing. Guess what? They've done studies, long-term studies, and they found there is no correlation between cell phones and brain cancer.

### Conspiracy Advocate (CA)
Claim: Wait, wait.

### Scientific Advocate (SA)
Claim: So until you-- until you--

### Conspiracy Advocate (CA)
Claim: Name the last time someone shot themself in the chest because of cell phone use?

### Scientific Advocate (SA)
Claim: Malcolm, you're taking--

### Conspiracy Advocate (CA)
Claim: No, no.

### Scientific Advocate (SA)
Claim: No, you're doing-- you're taking-- you're taking, as Jason said, at aberration. You're--

### Conspiracy Advocate (CA)
Claim: I did because I use AT&T.

### Conspiracy Advocate (CA)
Claim: There are 64-- There are 64 players in the National Football League who are currently suing the league over their brain injuries, right?

That is the thin end of the wedge. We don't know how large the group of affected players is. And the question for us is--

### Moderator
Claim: We can't use lawsuits.

### Conspiracy Advocate (CA)
Claim: --until we know, until we know what the extent of the medical damage is, what is the appropriate position to take as custodians of the-- of the personal intellectual development of young people?

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: Well, I mean, listen, our-- have the studies been definitive? No. However--

### Scientific Advocate (SA)
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: --of the-- but wait a sec. BU has studied the brains of 44 players who died early either because of Alzheimer's, suicide, which is a very, very complex issue, I agree with Jason about why Junior Seau died. We don't know. But in each of those 44 brains, they found advanced CTE. Their brains were shriveled. The first case was Andre Waters who shot himself at the age of 43.

Forget suicide, when they looked at his brain, they said he had the brain of a 67-year-old man, and you know, you know how Andre Waters played, he probably suffered 25 to 30 concussions during his career. So you have 44 cases in which there were advanced signs of CTE in players who either had Alzheimer's, early Alzheimer's, or died. So there are studies. There are studies. And I--

### Scientific Advocate (SA)
Claim: There are 6,000 former NFL players over the last 20 years, and you're talking about--

### Conspiracy Advocate (CA)
Claim: A thousand are filing suit.

### Scientific Advocate (SA)
Claim: Take 6,000 clergymen, 6,000 university professors, 6,000 bus drivers, here's--

### Conspiracy Advocate (CA)
Claim: But Tim, there's a class action suit filed by a thousand NFL players.

### Scientific Advocate (SA)
Claim: I don't want to be this cynical, but-- I don't want to be this cynical, but this is also America. We sue over everything. You get broke and desperate, you-- seriously, I've written about this in the past, about remember we had this whole deal about the old NFL players not being taken care of by the current players.

And I called it "The old NFL--" they want reparations because they're jealous of how much money the current players are making.

### Conspiracy Advocate (CA)
Claim: Do you honestly think--

### Scientific Advocate (SA)
Claim: Absolutely, absolutely.

### Conspiracy Advocate (CA)
Claim: Tim, now, let me ask you, you played.

### Scientific Advocate (SA)
Claim: Is suing a good thing, like cigarettes, porn, and football?

### Scientific Advocate (SA)
Claim: No, but it's just what we do. Everybody-- if you can't earn it, you'll sue somebody to get it.

### Moderator
Claim: Malcolm Gladwell.

### Scientific Advocate (SA)
Claim: That's America.

### Moderator
Claim: Malcolm Gladwell.

### Conspiracy Advocate (CA)
Claim: I think all of you are-- the two of you are sidestepping the crucial fact here, and that is, yes, this is a complex topic, yes, this is clearly a heated topic, yes, we don't know what the full extent of this damage is, the issue is what do we do at our institutions of higher learning in the interim.

### Scientific Advocate (SA)
Claim: That's what I want to respond to.

### Conspiracy Advocate (CA)
Claim: Right?

### Scientific Advocate (SA)
Claim: That's what I want to respond to.

### Conspiracy Advocate (CA)
Claim: What is the prudent step? And you guys seem to take the position that until we have definitive proof--

### Scientific Advocate (SA)
Claim: The appropriate step to take is to walk things back. They're playing too many games, I agree.

They should walk it back to 11 games. The coaches are earning too much. They should share some with the players. They should have less padded practices and less contact-- they should walk things back until we figure it out. You don't just jump to banning--

### Moderator
Claim: Right.

### Scientific Advocate (SA)
Claim: --we would have banned cell phones 10 years ago--

### Moderator
Claim: You're yielding--

### Moderator
Claim: Neither of you--

### Moderator
Claim: You're actually yielding a lot of their points, that there's a real problem there, so you do yield--

### Scientific Advocate (SA)
Claim: No one denies there's a problem.

### Scientific Advocate (SA)
Claim: There was a problem back in 1976--

### Moderator
Claim: So the head injuries are real and the money problem is real.

### Scientific Advocate (SA)
Claim: Look it, helmets have got better in 1976, the rules changed in 1976, absolutely. I mean, we're not saying, "Oh, you know, just go on-- carry on as usual." Yeah, change the rules a little bit, continue to modify, have the strike zone, no helmets to helmet hits-- hang on, Buzz--

### Conspiracy Advocate (CA)
Claim: I'm with you.

### Scientific Advocate (SA)
Claim: Yeah, modify the rules, pay the players, keep making the helmets safer and safer which they are, do everything we can to protect, but don't-- this is America. We don't ban things.

People can burn the flag. We don't ban that. You don't ban college football.

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: But the greater issue, which neither of you have answered, is what is the academic purpose of football on a university campus, and why are we the only nation in the world that looks to universities to provide a primary source of athletic entertainment? You talk about kids getting-- you know what the graduation rate of football players should be? 100 percent. Do you know why? They get a free scholarship, not only that--

### Scientific Advocate (SA)
Claim: It's not free, Buzz.

### Conspiracy Advocate (CA)
Claim: They get a--

### Scientific Advocate (SA)
Claim: It's not free. You work for it.

### Conspiracy Advocate (CA)
Claim: --Tim, I didn't interrupt you. Do not interrupt me. They get a scholarship. Beyond that, you have the Phil Knights and the University of Texas. Phil Knight built a $44 million Taj Mahal academic support center for student athletes. Why doesn't he build it for the average student? They get tutors.

### Moderator
Claim: Tim Green.

### Conspiracy Advocate (CA)
Claim: They get every ancillary benefit.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: And the graduation rate-- and, by the way, the federal rate is 56 percent because the NCAA has all sorts of gimmicks called its graduation success rate.

### Moderator
Claim: Buzz, Buzz, this is landing well. I want to let him respond.

### Scientific Advocate (SA)
Claim: I'll concede that instead of 55 it's 56, all right?

### Conspiracy Advocate (CA)
Claim: As a--

### Moderator
Claim: Take on the question. Why-- he's talking about a great imbalance in disparity and where the investment goes.

### Scientific Advocate (SA)
Claim: The money goes to where people pay for it. People want-- look, this is America. People want winners. They wanted the programs to win. And they'll pay for it. I agree with Jason, the coaches should split some of that salary, create a stipend for the players. I'm in full agreement. Again, look it, you guys can't just say, "Well, football needs to change, there's bad things about it." Yeah, there are. There are some things that are dangerous, that's unsettling. Are we going to not allow-- no students should allowed to be driving motor vehicles. That is 100 times more dangerous.

### Scientific Advocate (SA)
Claim: I want to ask Buzz-- just one second.

### Scientific Advocate (SA)
Claim: We have to protect our youth.

### Conspiracy Advocate (CA)
Claim: I just have to go back. As a Canadian, I have to go back to something you just said when you said that the merits--

### Moderator
Claim: Yeah, but you guys don’t drive, do you?

### Conspiracy Advocate (CA)
Claim: “This is America. We don’t ban things.” Are you sure? You don’t ban things in America?

### Scientific Advocate (SA)
Claim: Do you want me to say this is North America?

### Conspiracy Advocate (CA)
Claim: Let me think. Let’s think for a moment about something that we’ve banned recently in America. Gay marriage, heard about it? We ban things all the time, Tim.

### Moderator
Claim: Jason Whitlock.

### Scientific Advocate (SA)
Claim: It’s not banned in New York state and I think it will cease to be banned everywhere in this country.

### Moderator
Claim: Jason Whitlock.

### Scientific Advocate (SA)
Claim: Buzz, I wanted to ask you, and I don’t know the answer to this.

### Conspiracy Advocate (CA)
Claim: It’s certainly banned on football programs

### Scientific Advocate (SA)
Claim: I would-- Buzz--

### Scientific Advocate (SA)
Claim: Don’t ask, don’t tell, Buzz.

### Scientific Advocate (SA)
Claim: --would you-- Buzz, would you agree that Boobie probably required more support if he-- did he deserve an opportunity-- if he had been good enough to go onto college, would he not deserve perhaps a little more support academically to get through school? I mean, considering his background. And Boobie was a great character in Buzz’s “Friday Night Lights” book.

### Conspiracy Advocate (CA)
Claim: Because-- would he have gotten more support? Yes.

### Scientific Advocate (SA)
Claim: No, would you say the kid deserved it, though? Wouldn’t that be a good thing?

### Conspiracy Advocate (CA)
Claim: If he effectively used it, sure, but I think they are given that support to pass them through and make sure that they are eligible--

### Scientific Advocate (SA)
Claim: Having experienced--

### Conspiracy Advocate (CA)
Claim: And, Jason, the graduation rates for African American players is--

### Scientific Advocate (SA)
Claim: Complex reasons, Buzz. Complex reasons.

--terrible. But wait. Let me just give you-- let’s talk facts. Florida State. Whites, 93 percent. Blacks, 44 percent. Arkansas, 80 percent--

Buzz, if they broke it down--

### Conspiracy Advocate (CA)
Claim: Let me finish. 80 percent-- because I actually did the some work on this instead of

### Scientific Advocate (SA)
Claim: Two-parent home versus single-parent home, I bet you you’d erase the racial disparity. Kids that come from two-parent homes, regardless of color, are more apt to graduate--

### Conspiracy Advocate (CA)
Claim: Yeah, but let me--

### Scientific Advocate (SA)
Claim: --from college than kids that come from single-parent homes.

### Conspiracy Advocate (CA)
Claim: But you’re dismissing the--

### Scientific Advocate (SA)
Claim: It’s not a--

### Conspiracy Advocate (CA)
Claim: You’re--

### Scientific Advocate (SA)
Claim: It’s not necessarily a race issue.

### Conspiracy Advocate (CA)
Claim: But you’re completely dismissing--

### Scientific Advocate (SA)
Claim: The foundation--

### Conspiracy Advocate (CA)
Claim: --the racial disparity. You’re completely dismissing it.

### Scientific Advocate (SA)
Claim: I’m not dismissing it. I’ve experienced it.

### Conspiracy Advocate (CA)
Claim: You are you know that?

### Moderator
Claim: Let me just-- all right, all right.

### Scientific Advocate (SA)
Claim: I’m going to--

### Moderator
Claim: I’m going hope-- Tim.

### Scientific Advocate (SA)
Claim: --quickly throw--

### Moderator
Claim: Tim Green.

### Scientific Advocate (SA)
Claim: --two numbers at you. Since 1984 the graduation for football players across the board has increased 10 percent. That’s a good thing. It’s a good trend. In the last 10 years. So that’s 25 years. In the last 10 years there has been a 15 percent increase in African American football players alone. So it’s not perfect, but guess what? Against the general population, which is going down, the football players are going up. And maybe it does require a little bit more money to get them there with the tutors and the academic centers but they are earning it. They are paying for it with their efforts in practice and in the games on Saturday afternoon.

### Moderator
Claim: Buzz, do you have something further to say on that-- do you have something to move that forward? Because I think you’ve stated your case. I want to put a question to this side because there’s something about your argument that I realize I’m not clear on. Do you believe that athletics have a place, a formal place, in education, period? In the same way, for example, that music, painting, performance may?

Do those things belong on campus? Is athletics part of an education in the college level?

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: Malcolm Gladwell.

### Conspiracy Advocate (CA)
Claim: For all--

### Moderator
Claim: How does it fit in, then?

### Conspiracy Advocate (CA)
Claim: For all of the reasons I think that were so articulately stated by Mr. Green and Mr. Whitlock. They are opportunities to build character, to learn teamwork, to bring people from different backgrounds together. All of that’s true.

### Moderator
Claim: So you’re saying it’s-- Buzz, you’re saying it’s the way in which football is happening now? In other words, if you went back 50 years--

### Conspiracy Advocate (CA)
Claim: Well, I mean, it’s the way-- no, because there is-- the myth of the student athlete is a myth. In the early 1900s, when the Ivy League ruled football, you know what they did? They hired these kids, they gave them a shared of the gate receipts, they never went to school, and they were not expected to go to school. This is a myth propagated by people like Grantland Rice, who raise these players to Biblical proportions and Ronald Reagan playing win one for the Gipper.

Now, in 1950 the average SAT score of an athlete was 18 points below the average student. It is now exponentially lower and I’m not sure-- and Tim played. But what does football--

### Moderator
Claim: Wait, wait, Buzz, just-- I just want to finish up the--

### Conspiracy Advocate (CA)
Claim: Sure.

### Moderator
Claim: --point that Malcolm started. So where does athletics in general and football specifically fit into the process of education?

### Conspiracy Advocate (CA)
Claim: Football does not fit into the process of a college education, not when we rank 14th in the world--

### Moderator
Claim: But rowing does?

### Conspiracy Advocate (CA)
Claim: Rowing may to some degree.

### Moderator
Claim: Why?

### Conspiracy Advocate (CA)
Claim: They could all be college sports.

### Moderator
Claim: What’s the--

### Conspiracy Advocate (CA)
Claim: They could all be club sports. Honestly, we are so athletic-obsessed, and for what? For what? I mean, the number of scholarships that we give out, does Penn State really need 29 varsity sports? Does it?

Is it right that the single biggest individual contribution given was $70 million for establishment of a Division 1 hockey program at a time when tuition is going up? And I imagine a lot of those students are leaving because they can no longer afford school, unlike your football players.

### Moderator
Claim: Tim Green.

### Scientific Advocate (SA)
Claim: I just don't-- I honestly-- I don't understand why opportunities for student athletes makes you so angry. I don't. I don't understand why you begrudge college athletes scholarships, especially when part of your own argument is that these guys-- these football players and basketball players are being exploited because the revenues that they generate. Those revenues that they generate are used to pay for-- you talked about the expenses that are there, the expenses, it's all part of the show. And they pay for it dearly. They work very hard and you do take risks.

You don't take risks, you know, any more than a lot of other sports. You take less risks than riding a bicycle or driving a car, but you do take risks, and you put forth tremendous effort. And from those efforts, you should-- we're in agreement. You should get something back. So which one is it, Buzz? I mean, do you want-- do you want players to-- football players to have the opportunities of education as compensation for their efforts or don't you? You're mixing messages.

### Moderator
Claim: All right. I want to go to questions from the audience, but first I want to tell you, so we are now in the question and audience section of this Intelligence Squared U.S. debate.

I'm John Donvan of Intelligence Squared U.S. We have four debaters, two teams of two, debating this motion: "ban college football." And how this will work, if you raise your hand, I'll call on you. Just wait till a microphone comes to you. And you're being filmed too, so please stand up so that we can see you. Hold the microphone about a fist's distance from your mouth so that it can hear you clearly. We'd appreciate it if you could state your name, if you're a member of the media or a blogger, we'd appreciate that.

And I really urge you to make your question a question, and you'll recognize it as such because a question mark naturally goes at the end of it. And try to keep it on topic. You know, there's a lot of places we could go with this. We really want the question to get these guys talking about in a way that helps you make your decision on whether to ban college football or not to. Sir in the far back, you're wearing a black sweater with horizontal white stripes. I can't see you, by the way, if you're not in the lit area. So if you can't see the hands on your wristwatch, I can't see you. But if you want to come down forward to the lit area, then I might be able to call on you. Sir, go ahead.

### Moderator
Claim: Yes. My name is Rick Levy. I'm not a member of the media, but I do have a question regarding the health of a football player. With the exposure in the New Orleans Saints for pay for injuring players, is this, in your experience, happening in college as well? Are college players being rewarded for injuring their opponents?

### Moderator
Claim: Which brings us to the large area of corruption which we haven't discussed greatly. Which side would like to take that first? Because we can take it to either side. Buzz Bissinger?

### Conspiracy Advocate (CA)
Claim: Well, I don't-- I would think not. I mean, I would think not. But you know, if you want to talk corruption, if you want to talk academic cheating, the numbers--

### Scientific Advocate (SA)
Claim: Let's-- let's answer the question first.

### Conspiracy Advocate (CA)
Claim: No, but corruption in college sports.

### Scientific Advocate (SA)
Claim: No, but he-- let's answer his question.

### Conspiracy Advocate (CA)
Claim: I said I don't think--

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --that any coach or player, there is a bounty system--

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: --for any college program. However--

### Moderator
Claim: And-- and before that, Tim Green.

### Scientific Advocate (SA)
Claim: Unlike everything else, you're right.

### Conspiracy Advocate (CA)
Claim: Let's go to teams on probation.

### Scientific Advocate (SA)
Claim: Wait. Let me just-- let me just answer. Let me answer his question, because I do--

### Moderator
Claim: Buzz, I will come back to you.

### Scientific Advocate (SA)
Claim: --I do happen to know that. In the National Football League, what happened with the New Orleans Saints was an aberration. In my eight years of playing in the NFL, in my 10 years as a broadcaster for FOX Sports and knowing players intimately throughout the league, I never heard of anything quite like it, neither did anyone else.

By the way, people knew about what was happening with the New Orleans Saints for the past three years. And they were warned over and over again, "We hear this. You guys better stop. This is absolutely crazy." It's crazy. It's wrong. It was despicable. It's an aberration. It doesn't happen in pro football, other places, and it certainly has no place, and it has not happened to my knowledge in the college

### Moderator
Claim: Okay. Now you know if anybody wants to stand up and say, "Buzz, what about corruption?" he's ready to go. So--

### Conspiracy Advocate (CA)
Claim: No, but I thought we--

### Moderator
Claim: Go ahead. Go ahead, Buzz.

### Conspiracy Advocate (CA)
Claim: I thought what Tim said, who was in a position to know the best was both eloquent and right and reassuring. Tim played pro football.

### Moderator
Claim: I completely disagree with him.

### Moderator
Claim: Malcolm Gladwell.

### Conspiracy Advocate (CA)
Claim: However-- however, let's talk about teams on probation since 2009. Georgia Tech, LSU, Michigan, UNC, Alabama, Ohio State, New Mexico, USC, Florida International, Alabama State, West Virginia, Boise State, Hobart-- what the F-- I didn't do it! I didn't do it. Nebraska, Tennessee.

How many is that? I know you'll say that's anecdotal. Academic cheating, Florida State, 61 players took online courses where they received answers beforehand or did no work. The team had to vacate wins during those seasons. UNC which has been invoked, all these football players for some reason were taking--

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: --taking Swahili.

### Moderator
Claim: All right, Buzz, I want to ring the bell. Do you guys want to--

### Conspiracy Advocate (CA)
Claim: Swahili!

### Moderator
Claim: You guys want to respond? Jason Whitlock.

### Scientific Advocate (SA)
Claim: Well, I hate to go back to it, but--

### Conspiracy Advocate (CA)
Claim: How can you justify that?

### Scientific Advocate (SA)
Claim: If you have freedom, you're going to have corruption, man.

### Conspiracy Advocate (CA)
Claim: Oh, that's a good thing.

### Scientific Advocate (SA)
Claim: That's part of-- I'm-- just probably-- I should just say it. I don't want to be offensive.

### Conspiracy Advocate (CA)
Claim: You should become head of Citibank, for God's sake.

### Scientific Advocate (SA)
Claim: But probably--

I should have taken a job on Wall Street.

### Conspiracy Advocate (CA)
Claim: You should have.

### Scientific Advocate (SA)
Claim: Look it, you-- it's dangerous to take-- this is throughout sports at every level, right? And the more focus and the more attention we pay to it, the more we are interested and drawn to the people who misbehave.

But the vast majority of college football players. You said 7 percent of college football players have been arrested. That's about-- that's probably about the average in the college male population.

### Conspiracy Advocate (CA)
Claim: No actually it’s not.

### Scientific Advocate (SA)
Claim: Wait a minute. Hang on. You're talking about all these people that have-- look, you've got to add the numbers up. If you've got 30 that broke the rules, how many hundreds do you have who didn't break the rules? If you've got a handful of players who committed suicide and then had serious brain damage, which that makes sense, right? and that horrible tragedy, how many didn't commit suicide?

### Scientific Advocate (SA)
Claim: Buzz is going to be back next month banning marriage because of infidelity.

### Moderator
Claim: Let me take us to another question. Right down in the front there, very first row. And remember to stand up, please. Thanks.

### Moderator
Claim: Hi. My name is Claire Andre. My question is, it's been kind of black and white, either ban or not ban. But what-- what would you suggest as ways or not suggest as ways to encourage-- to--

### Moderator
Claim: Well, can I twist your question just a tad because--

### Moderator
Claim: Sure.

### Moderator
Claim: --I've been wondering the same thing. If it go-- would you be okay with putting it this way?

### Moderator
Claim: Yes, absolutely.

### Moderator
Claim: --to this side, is there a reformable version of college football that you guys would accept? Because they actually are talking about let's make some changes. Can--

### Moderator
Claim: There are suggestions reform.

### Moderator
Claim: Okay. What would be-- let's do it that way. What would your suggestions about and what--

### Scientific Advocate (SA)
Claim: I've answered that previously. I think a shorter season, less practice time, sharing the wealth with the athletes would be some-- I think in my day we played 11 games. Now they play 14 or 15 games. It's ridiculous. It's complete and total exploitation. You could-- 10-game season is completely appropriate. To go to a bowl game, you play in 11. You know, just the more contact, the more likely you are to get injured--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --so less games would be--

### Moderator
Claim: Wait, let me just see if there's anything else on their list.

### Scientific Advocate (SA)
Claim: I think the colleges should continue to work and with the NFL to continue to research and find better and better equipment to protect the players and to continue to-- to kind of tinker with the rules, create the strike zone for the quarter back, eliminate-- try to eliminate helmet to helmet.

You're never going to eliminate it completely, but have a strict liability code where players who do hit helmet to helmet, you'll remove them from the game, suspend them the next time, and then make it very serious.

### Moderator
Claim: Okay. Would any of those steps make a difference to new your conviction to ban college football?

### Conspiracy Advocate (CA)
Claim: No.

### Conspiracy Advocate (CA)
Claim: No.

### Conspiracy Advocate (CA)
Claim: I would--

### Conspiracy Advocate (CA)
Claim: Well, I mean, I--

### Moderator
Claim: No, no. Go ahead, Buzz. I want--

### Conspiracy Advocate (CA)
Claim: This is a very radical solution. It's got all sorts of problems. I understand that. But people are talking about universities. You license out your name. And basically you're creating a de facto subsidiary. The universities are out of it. You still call it USC. You still call it whatever. You still call it Nebraska. You still call it Syracuse. But it's out of the university system. The university gets a licensing fee. They negotiate it. It basically is a minor league system that is separate. Or, you know what? You get rid of it. You don't penalize the players.

You know who the biggest villain in this is? The NFL. The NFL does not pay a single dime for what is the greatest boondoggle and farm system ever created.

### Moderator
Claim: And Malcolm, Malcolm--

### Conspiracy Advocate (CA)
Claim: So make the NFL pony up with a developmental league.

### Moderator
Claim: Malcolm, the other-- the other part of their-- many of their suggestions are related to making the game safer, so can you take that on?

### Conspiracy Advocate (CA)
Claim: Well, I would-- the thing that I would be happy with is intramural flag football. Because you think about it, here's a chance for kids from all kinds of different backgrounds to come together--

### Scientific Advocate (SA)
Claim: You are--

### Conspiracy Advocate (CA)
Claim: --and learn to play together in hard work and perseverance. I get all misty eyed thinking about it.

### Conspiracy Advocate (CA)
Claim: Now, wait a second. Malcolm, no offense, aren't you talking about gay marriage?

### Moderator
Claim: Sir in the black sweater, third row. This way for the mic please. One second. It's coming from your right hand side.

### Moderator
Claim: My name's Herb Antillac I'm a sports fan. I'm just an average person.

If you're going to ban football, then you'd better start banning basketball and all of the other sports because they just have the same problems as football. This country isn't about banning. This is about building and it's--

### Moderator
Claim: Can you turn this to a question?

### Moderator
Claim: Oh, sure.

### Moderator
Claim: Okay, thanks.

### Moderator
Claim: Besides the monetary amount, why do you want to ban football?

### Conspiracy Advocate (CA)
Claim: Well, I mean, you know--

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: --if at this point I haven't made the point, then I'm really screwed-- because first of all, and I didn't mention this, 43 percent of the top 125 programs lose money on football. Now, how-- any program that--

### Moderator
Claim: You really gave him an opening here to get--

### Conspiracy Advocate (CA)
Claim: Any-- so 43 percent lose money.

Why do they maintain football programs? Tim and I talked about this yesterday, because for some--

### Moderator
Claim: I didn't ask that. I asked why do you want to ban football outside of money?

### Conspiracy Advocate (CA)
Claim: Because it has nothing to do with the academic-- I'm amazed-- aren't you concerned--

### Moderator
Claim: It has everything to do with the academics.

### Conspiracy Advocate (CA)
Claim: It does-- has nothing to do--

### Moderator
Claim: It provides-- it--

### Moderator
Claim: Wait, wait, wait, wait, okay, I have to set you down because we’ve only got four seats up here, but thank you.

### Scientific Advocate (SA)
Claim: Can I answer?

### Moderator
Claim: Thank you. Yeah, Tim Green would like a chance to respond to that.

### Scientific Advocate (SA)
Claim: Can I-- in your farm team system, where every school gets to have their own farm team, do the players get to go to class? Do they get an education at the same time?

### Conspiracy Advocate (CA)
Claim: I would think you would give the-- you know, it's an unwieldy mechanism. I think you give the players that option. If they want to be called, "student athletes," and they're actually going to class and they're interested in getting an education, fine, if they don't want to go, don't make them because I have a feeling that most of them probably don't want to go.

### Moderator
Claim: Those would be athlete students.

### Conspiracy Advocate (CA)
Claim: --easy course list, that's why UNC has an easy course list--

### Scientific Advocate (SA)
Claim: Well, you know, you've got to quantify that, but why do you think-- if they don't want to go, why do you think 70 percent are graduating as opposed to 55, 56 percent of everyone else?

### Conspiracy Advocate (CA)
Claim: Well, I said, because in many cases, you know--

What--

### Moderator
Claim: All right, let him finish-- let him answer.

### Scientific Advocate (SA)
Claim: Why are so many football players graduating if they don't want their degree and they don't want to go to class and they don't want to go to school? You're taking-- you--

### Moderator
Claim: Wait, let him answer the question.

### Scientific Advocate (SA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Why?

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: Because it's a game and because the NCAA knows and college football knows that we're under a lot of scrutiny for our graduation rates so they push him through. Why does Stanford have an easy class list that football players-- "Here are the classes you take." Why? Tim, why? Why would they? Why would UNC--

### Scientific Advocate (SA)
Claim: I know-- I have--

### Conspiracy Advocate (CA)
Claim: But why?

### Scientific Advocate (SA)
Claim: I have alum at Syracuse who had easier class loads, easier degrees than I did with an English literature degree--

### Conspiracy Advocate (CA)
Claim: But you're--

### Scientific Advocate (SA)
Claim: --or a biosciences degree, I mean, a physics degree, an engineering degree, I mean, some people get their degrees in-- I don't want to disparage any other degrees, but there are all kinds of things. You know, if you're-- if you get a degree in business or a degree in the liberal arts--

### Moderator
Claim: But I--

### Scientific Advocate (SA)
Claim: --an English degree.

### Moderator
Claim: Let's go to another question. Right in the aisle, there. Yeah.

### Moderator
Claim: Hi, I also am just an average person and a sports fan. My name's Ashley. There is a scholar out of Duke University who has correlated the top 25 universities in the world, 22-- 21, 22 of them are in the U.S., with the big sports programs, having an effect on bringing the community together and getting behind even if it doesn't directly contribute to the bottom line of the university or show honor. And that's one of the reasons that even though our recent numbers haven't been great, our overall numbers of top universities are indeed higher.

### Moderator
Claim: So what is your question?

### Moderator
Claim: So the question is do you feel that, that holds any weight, one of the questions that you've posed several times is what is the purpose of football and other athletics in higher education, and if it's overall to bring our universities to the top of the line--

### Moderator
Claim: So is your question is-- and I may be wrong-- but is your question what about the-- and this side has made this case-- the beneficial effect on bringing a university together, giving it an identity, giving it a sense of purpose and unity--

### Moderator
Claim: Right.

### Moderator
Claim: --so you think that's real, and you're asking this side if that is-- if they think it's real and if they think it's worth it.

### Moderator
Claim: Right.

### Moderator
Claim: Malcolm Gladwell.

### Conspiracy Advocate (CA)
Claim: I-- you know, the thing that I always come back to that has mystified me throughout this whole debate is what on earth is so special about football? I mean, if 50 years ago or 75 years ago the major colleges had all decided that they would compete at Monopoly-- and that somehow Monopoly had gotten lodged in the imagination of the American scholar Monopoly player. And that they started to give out scholarships for Monopoly players and then the Monopoly coaches earned millions of dollars and they built large stadia, which 1,000 people would come to watch the Monopoly players compete against each other.

And then suddenly it was observed that Monopoly had gotten out of control and we said, “Maybe it’s time for us to turn our back on Monopoly.” I can imagine the two of you just standing up there and saying, “No.” There’s something magical about this game.

### Moderator
Claim: Yeah, but her question for--

### Conspiracy Advocate (CA)
Claim: My point is there is nothing-- it’s just a game. Replace it with another game.

### Moderator
Claim: But her question persists that she-- whether it makes no sense to you or not--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: --her question is she feels that this effect is there and is real, and I want to ask you if you think it’s there and if it’s real and if it’s worth it.

### Conspiracy Advocate (CA)
Claim: My point is--

### Moderator
Claim: Let me take-- well, go ahead.

### Conspiracy Advocate (CA)
Claim: My point is it’s probably real but you could get it with something else. Monopoly. Let’s try it.

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: Well, I mean, I think, you know, it’s like anything in life. If a team is winning and successful with certain exceptions like a Texas or an LSU or an Alabama, if you’re winning students go, alumni go, if you’re losing they tend not to go.

I’m not sure if you’re saying that the 25 biggest, best universities in the world have superb football programs because I don’t think that’s correct. I just don’t, because on that list is Harvard, Yale, Penn, University of Chicago, and last time I checked the Ivy League sucks. But, anyway, it does bring students together. But-- however, there was a study done at the University of Oregon by several economists that was in the National Economic Review that showed when the Oregon football team was winning men’s grades went down significantly. They did-- you might think it’s a laugh but it’s not. By an equivalent of 27 SAT points, they studied half as much, and they drank twice as much. So that’s what football does. It makes you drunk and stupid.

### Moderator
Claim: Tim Green.

### Scientific Advocate (SA)
Claim: Malcolm, you asked what’s so special about football and I want to seriously try to answer that because I’m a dad and I encourage my kid-- I don’t-- if they don’t want to be athletes and they don’t want to play sports, that’s fine.

They can do whatever they want to do. But if they want to be athletes, I encourage them. I’ve coached a lot of sports and I’ve coached football. And the thing that I love about all sports is one of the things Jason said. Teamwork. Bringing people together for a common cause, working together, learning that even if you’re not the most important part of a team you can make a difference and help that team win, learning that you have to get along with people even if you don’t like them, to have-- if you have a common goal. The perseverance element of sports. And I think the thing that I love most about football is, and this is what I say to the kids I coach, I say-- and the parents. I say, “You’re going-- when you go out into the world you are going to be knocked down. You are going to be knocked down and guess what? It’s not always going to be fair. And sometimes you’re going to be cheated. And sometimes people are going to do things to you that they shouldn’t do."And all of this happens in a game of football, and it happens in a very confined, intense experience. And I’m telling you that, as a football player and football players, you learn to get knocked down--

### Moderator
Claim: But, Tim--

### Scientific Advocate (SA)
Claim: --“and get back up.”

### Moderator
Claim: --that doesn’t beat the Monopoly argument because--

### Scientific Advocate (SA)
Claim: Oh, it does.

### Moderator
Claim: No, I mean, seriously.

### Scientific Advocate (SA)
Claim: No, it does.

### Moderator
Claim: Because you’re talking about what’s good for the football player and they’re talking about--

### Scientific Advocate (SA)
Claim: Oh, okay. No, you’re right.

### Moderator
Claim: --what’s good for the rest of the university.

### Scientific Advocate (SA)
Claim: I thought he meant what’s so good about football as a player.

### Conspiracy Advocate (CA)
Claim: Look, I mean, football is a part of the American soul. It goes to, frankly, our celebration of-- we like being a violent, hard-assed country. What I resent is that why don’t you get all those things in the school newspaper when you put on a play? When you’re in the orchestra you get all these things. Perseverance, caring. Football players don’t really have to deal with people. They’re told by 23 coaches what to do and all those pursuits have much more long-lived academic pursuits.

### Moderator
Claim: Jason--

### Conspiracy Advocate (CA)
Claim: You have to write.

### Moderator
Claim: Jason Whitlock.

### Conspiracy Advocate (CA)
Claim: You have to learn critical thinking.

### Scientific Advocate (SA)
Claim: Well, I think on a college campus a lot of those endeavors that you’re talking about, and some of them-- I participated in my school newspaper. Again, those tend to be segregated endeavors that don’t reach the cross section of people that football does and, you know, that’s unfortunate. But it’s the American reality, and football is the one thing on the field and even in the stands that seems to bring America together across a lot of different backgrounds.

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: Henry Gates, Sports Illustrated 1981. And we all know who he is and I think we respect him obviously. “The blind pursuit of attainment in sports is having a devastating effect on our people. Imbued with a belief that our principal avenue is to face and-- is to profit through sports, far too many black kids treat basketball courts and football fields as if they were classrooms in an alternate school system."That's Henry Gates. Henry Gates. Now, Henry Gates also-- and then I'll stop. Henry Gates, he went back to his hometown. He asked people, how many black pro athletes do you think there were? The guesses were wild. Half a million, 50,000. But what he was distressed by-- no one believed him when he said there are 12 times more black lawyers than pro athletes. 20 times more dentists and 15 times more doctors. So I frankly think that you are selling a bill of goods to inner city kids that athletics is the way out because there are a lot of other ways out.

### Moderator
Claim: Jason. Jason Whitlock.

### Scientific Advocate (SA)
Claim: There's many--

### Moderator
Claim: Jason Whitlock.

### Scientific Advocate (SA)
Claim: Because it's America, and because of freedom, you have to take responsibility for yourself. And so trust me, having gone through the athletic and academic experience, Ball State University and every other university that my friends attended, they put all the academic goodies right on the table for you to take. And sometimes they put you in a-- you know, get your head and try to stuff the academic-- it's up to you to open your mouth and take it. That's America. And so these issues, whether we're trying to reduce to black and white sometimes are far more complicated, and it has to do with-- for me, I tried to quit college football. My parents wouldn't allow it. Would not allow it.

### Moderator
Claim: Why did you want to quit?

### Scientific Advocate (SA)
Claim: Because it was hard. And me and my coach didn't get along, and I had a big mouth. And I tried to quit. And my parents are like, "Good luck, buddy. You're on your own."And luckily I had those kinds of parents. They wouldn't let me quit. I played with a lot of guys that didn't have those kinds of parents or didn't have parents. And so we're blaming institutions a lot of times for things that a foundation with a kid has to be established from birth all the way up until the point you hand them over to the institution. And if that foundation is not there, if that support system is not there, you're going to fail. That's America. And so it's-- we can demonize the universities and the institutions. But, you know, there's clearly a breakdown in family throughout America that is most acute in African American community. And it contributes to a lot of these problems that Mr. Bissinger's talking about.

### Moderator
Claim: Okay. I want to do a-- I want to do a-- a break to-- we're going to take a quick break. Now the quick break is over.

And I just want to ask you to give us a round of applause to lead me back into it. Thanks. So we are in the question-and-answer section of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two against two, who are arguing it out over this motion: "Ban college football." We're doing questions from the audience. Front row. Makes me nervous when I see that you've written out your question. I hope it's like only four lines. No, go ahead. Start again, please. Sorry.

### Moderator
Claim: Jason Troklis I'm not a member of the media. A question for Jason Whitlock, actually: You've been talking a lot about freedom and American values, capitalist and so forth. I think we can all agree that college football is not-- and pro football is not a free labor market. People have to play for three years in the NCAA before they can be eligible for the draft.

The fact that there is a draft is a little bit ridiculous. I think most labor economists would agree. My question to you is, would you do away with these restrictions on freedom for the players, number one? And number two, would college football exist if you did?

### Scientific Advocate (SA)
Claim: I would not do away with them because, you know, I am pro restraint on freedom within reason. And so no, I actually think it's for the players' best benefit to go on and participate in college football. You know, so no, I'm not for capitalism. We need a system of checks and balances throughout our society. And so there need to be--

### Conspiracy Advocate (CA)
Claim: Wait. Now I'm really confused. I've just been listening to you for the last half hour going on about freedom and dumbing. And all of a sudden now you're not for freedom any more.

### Scientific Advocate (SA)
Claim: Well, no, I am for freedom, but--

### Conspiracy Advocate (CA)
Claim: Except when you're not.

### Scientific Advocate (SA)
Claim: No. That's why we have government and rules and regulations. And there are restraints on freedom. We can't kill each other.

### Conspiracy Advocate (CA)
Claim: Well, then Jason, let me ask you this.

### Moderator
Claim: Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: And no offense. You definitely had concussions when you played. I'm convinced of that. But anyway, I know that was inappropriate. All right.

### Scientific Advocate (SA)
Claim: No. That was a good joke. Buzz and I are friends.

### Conspiracy Advocate (CA)
Claim: Anyway, I was doing so well up until then.

### Scientific Advocate (SA)
Claim: Buzz plays rough, I can handle it.

### Conspiracy Advocate (CA)
Claim: Are in favor, then of an antitrust exemption and many labor economists are who study sports in which no head coach gets more than $400,000 a year, which is a lot of money. Are you in favor of that?

### Scientific Advocate (SA)
Claim: 400,000, I don't know if that would be my limit. But yeah, I'm for-- I wish Congress or our government would step in and put some restraints on the NCAA and college football.

### Conspiracy Advocate (CA)
Claim: And let's face it. The only reason that three-year rule is in effect is because-- and I think Tim will agree-- you need that amount of time to develop as a football player.

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: --to be ready for the pros. So that's the only reason. You know, it's what the NFL wants. And basketball, which frankly-- major college basketball is in worse shape than football because of the one year and out.

You know, the five starting players of Kentucky, all the freshmen are leaving school. So, you know, everything is done basically for the sake either of money or so-called branding or the pros.

### Moderator
Claim: Sir, did you come all the way down from the back? I'm-- you've earned your question.

### Moderator
Claim: The question is actually-- my name is Vince Percoccio I'm not a member of the media. It's actually to Mr. Whitlock, and it's on the topic of freedom. But if you do have a ban, how do you craft legislation that would make the rest of us feel somewhat uncomfortable about over

### Scientific Advocate (SA)
Claim: Setting a precedent that could be used to ban basketball next.

### Moderator
Claim: Exactly. Exactly.

### Scientific Advocate (SA)
Claim: That they decide that they don't like it.

### Moderator
Claim: And it's the message from the other side is we don't like to ban things, even though we do ban things, it doesn't-- it always smells bad so--

### Moderator
Claim: So how did properly craft legislation to do this?

### Moderator
Claim: Well, can you take on-- can you take on-- you're talking about a slippery slope obviously. So take on-- take it on Buzz Bissinger.

### Conspiracy Advocate (CA)
Claim: Tim has played football. He has spoken, I think, very eloquently about why it is a special game. It is a special game. I love football. I do not think it has any academic purpose. And--

### Moderator
Claim: Yeah, but he's asking about all the other sports.

### Conspiracy Advocate (CA)
Claim: Wait. Other teams-- but you know, you do it. You do it. The University of Chicago which was in the Big 10, and Jay Berwanger had won the Heisman trophy six years earlier in the Big 10. Robert Hutchins said, you know what? This serves absolutely no academic purpose, no academic purpose. And he said, I know a lot of students at my school who can win 12 letters but don't know how to write one. And you know what? They got rid of it. They got rid of it. Schools can get rid of it. BU got rid of it. Northeastern got rid of it. Schools get rid of it.

### Moderator
Claim: Chicago, how do you do it globally for the entire country? Do you have to have federal government come in and say, everybody is banning football programs?

### Conspiracy Advocate (CA)
Claim: Well, people can sue. They can do this. They can do that. I think college presidents get-- the problem is with those salaries is they're terrified of head coaches. They're terrified of college coaches. They know at the big schools, they bring in a lot of bucks.

### Moderator
Claim: Yeah, but Buzz, you're giving the reasons not to do it.

### Conspiracy Advocate (CA)
Claim: You ban it.

### Moderator
Claim: But what are the reasons--

### Conspiracy Advocate (CA)
Claim: You know what you do? You ban it. College presidents ban it and then let people sue and let-- then it takes-- who knows?

### Conspiracy Advocate (CA)
Claim: Two weeks ago at the University of Florida, they shut down their computer science department, and they added $2 million a year to their athletic budget, bringing their-- the football program share of that budget to $78 million. Now, they didn't think of the banning of computer science at the University of Florida as setting a dangerous precedent.

### Moderator
Claim: All right. Let's hear from the other side.

### Conspiracy Advocate (CA)
Claim: So if that's the case, I'm not so worried about the football--

### Moderator
Claim: Tim Green.

### Scientific Advocate (SA)
Claim: Why can't we-- to Jason's point about freedom, why can't Florida spend their money on one thing instead of another? Why can't the University of Chicago discontinue football and focus on academics?

This is-- why can't we choose? Why can't we choose? And if someone is-- if a football program is losing money, and a school wants to discontinue it, well, why don't they? Why don't they? They don't because somewhere along the line some benefit is inuring to that university. And that's why they do it. And I just don't understand why you'd say, well, let's ban it. If it's so unproductive, if it's so counterproductive to everything that's going on, it would ban itself.

### Moderator
Claim: Hmm.

### Conspiracy Advocate (CA)
Claim: But, you know, it's not going to ban itself because the amount of money that is now involved that has been poured in that certainly wasn't there in the '60s by ESPN and CBS-- is so enormous that it's just going to create a bigger and bigger monster. And I guess, I don't know, call me silly. These are difficult times for this country. We can put our head in the sand, and sing the National Anthem, and say everything's going to be great, and we can believe in myths, a great country changes.

There was no China in the 1960s that was competing. There was no India. There was no South Korea. And, call me naïve, I really do think that these universities have to be almost exclusively about education. And one other thing, you asked about getting rid of sports? I'll tell you why it wouldn't be a bad idea, because then, that's actually the best argument for keeping football, you keep football, you keep basketball, you get rid of all the other sports that they pay for so that money at least goes into the general fund so the average student is getting something out of it.

### Moderator
Claim: Do you want to add something? Because he had a long run.

### Scientific Advocate (SA)
Claim: Well, I mean, that's another debate, whether--

### Moderator
Claim: Tim Green.

### Scientific Advocate (SA)
Claim: --we want to ban all non-revenue producing sports. Again, those are-- create opportunities for people, and for men, and for women, and I think universities are about opportunities.

And the other thing, I just want to say this because you mentioned something that's absolutely wonderful, Buzz, before every football game and before every athletic contest at the high school level and in the college level, everyone, everyone, both sides, we stand up and-- if we don't sing, at least we stand and respectfully observe the Star Spangled Banner, this country's song. And, you know, our National Anthem, what a beautiful thing, that's the only place where a community, where an entire school comes together and stands up and respects the National Anthem. You don't do it anywhere else in the college experience.

### Moderator
Claim: Malcolm's not singing it, though. Sir, question.

### Moderator
Claim: Actually, Mr. Bissinger, I did go to the University of Chicago and I did play football there. They reinstituted football in 1969--

### Conspiracy Advocate (CA)
Claim: But on a very, very minor, minor scale.

### Moderator
Claim: Yes, so it's Division 3.

But they wear a helmet and hit each other.

And, Mr. Whitlock, I do work on Wall Street as well, so actually I think I had some success in my career after graduating from the University of Chicago.

I can tell you this much, the University of Chicago athletes in general, not just football but athletes overall, have a higher GPA when I graduated in 2000 than the overall student body. So your question, the argument of athletics in education, there is a correlation of your education--

So the question is this, now, it is also true that Division 1 programs without football, no one makes money. Football programs pay for all the other sports. So once you ban football, how do you pay for women's swimming, how do you pay for every other sport there is because there is a correlation between athletics and academics.

### Conspiracy Advocate (CA)
Claim: How do you pay for women's swimming? The way you pay for a lot of things.

### Moderator
Claim: Taxes?

### Conspiracy Advocate (CA)
Claim: No, you get a rich benefactor, and there are plenty out there who will pay for the program because frankly that's what's happening now. The next phase of college football will be Boone Pickens. Why is Oklahoma State so good? Because he's given $300 million to the football program. The University of Oregon, it came out of nowhere to be a football power. Why? Because of the hundreds of millions given by Phil Knight. If you want to have women's swimming, you have a benefactor pay for it.

And you know as well as I do that Chicago is in a very, very different place than the 125 BCS schools. There is no question that places like Chicago and Harvard and Wesleyan where kids don't think that they're going to be pro football players, the most formidable person I have ever met is an athlete because they don't quit. But you know what the problem with athletes are? You know where they do the best? Wall Street. And you know why Wall Street is so screwed up? It’s because athletes--

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: --it's true, athletes don't know when to quit. They're only about winning.

### Moderator
Claim: One of the greatest American philosophers, John Dewey, wrote a book called, "Democracy in Education," and he discusses the importance of sport in play in the-- both K through 12 education as well as the system of American higher education.

And I'm wondering what the side for banning college football would think John Dewey would think of the idea of taking sport in play out of the curriculum of American higher education when it actually is a really important part of the higher education of an individual, whether it's intramural sports or-- I don't know what the level of college sports is, but--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: We're not talking about taking sports out of the curriculum. We're talking about banning semi professional-- or-- Buzz might have a slightly different interpretation of this than me-- but I think that if you look at schools like for example MIT, which has one of the highest participation rates in intramural sports in the country, their level of play is far higher than everybody else's, perhaps as a consequence of the fact that they’ve turned their backs on big time college sports.

So I think you could-- if we focused on precisely what John Dewey was interested in doing, which is bringing sports down to the level of the average-- the ordinary student, then that would be more easily achieved if we got away from this preoccupation with these enormously costly and dangerous spectacles.

### Conspiracy Advocate (CA)
Claim: And just to clarify, I mean, you could have-- people might not like it-- you could have wonderful club sports that could be very, very competitive. I mean, you can have a schedule. The amount of travel the teams do is ridiculous. You can have a schedule where you’re competing against regional teams. I think John Dewey was talking about the development of the whole individual. The fact is, there’s no phys-ed anymore in schools. Everything is about and by and for the athlete. And what happens is you create the athletic culture.

### Moderator
Claim: Let me put to the other side. So the solution of having club sports as opposed to sports at the level that you guys played, what would that do?

### Scientific Advocate (SA)
Claim: You’re limiting access for a lot of people, so--

### Scientific Advocate (SA)
Claim: You’re not going to have college scholarships for the athletes.

And, I mean, one thing I do want to say, though, is almost this line. I mean, are we talking about banning college football or are we talking about only banning college football if it’s Division 1 college football? Are we talking about Division 3, Division 2 football? That’s okay? But Division 1--

### Conspiracy Advocate (CA)
Claim: No, because, I mean, I--

### Scientific Advocate (SA)
Claim: No?

### Conspiracy Advocate (CA)
Claim: You know, I think the model of Division 2 and Division 3 is better. I think if you read William Bowen’s book, I think it’s called “Game of Play,” it’s a fantastic book based on data that he got from the Ivy League and from Duke. I mean, the one thing he did point out, and the little three, he said, “It’s a total fallacy to think that the Ivy League does not recruit and does not play games with scholarships and that Williams actually gives more athletic preference to athletes than the University of Michigan.” I think all these programs are loss leaders and, you know, look--

### Scientific Advocate (SA)
Claim: You’re saying ban college football--

### Conspiracy Advocate (CA)
Claim: I’m advocating-- here’s what I’m--

### Scientific Advocate (SA)
Claim: --entirely?

### Conspiracy Advocate (CA)
Claim: No, but I’m advocating that there are other ways to do it. Whether it’s a minor league season, whether it’s an NFL developmental system, why not the European model?

The European model. They don’t use their colleges and universities to create soccer players. They have sports academies, they have schools. They’ve plucked players as young as six because they say, “All right, you want to be a soccer player, you’re showing talent,” and they go to school there. And the other thing they do that is smart and beneficial is if you’re not going to make it, you’re weeded out early so you learn--

### Moderator
Claim: All right. Buzz--

### Conspiracy Advocate (CA)
Claim: --at an early age--

### Moderator
Claim: --because of time--

### Conspiracy Advocate (CA)
Claim: All right, sorry.

### Moderator
Claim: Only because of time, I want to give you 15 seconds to respond if you want to.

### Scientific Advocate (SA)
Claim: So we’re not going to ban college football, we’re just going to change it? Because we’re going to have colleges that have football teams and some of those players, the players who want, get to go and get their education so they still have--

### Conspiracy Advocate (CA)
Claim: No, I think we ban college football and then you have a developmental system for those who are--

### Scientific Advocate (SA)
Claim: That are--

### Conspiracy Advocate (CA)
Claim: --at the higher echelons of competition. And for the rest of the schools--

### Scientific Advocate (SA)
Claim: That are called Syracuse University, Texas Longhorns--

### Conspiracy Advocate (CA)
Claim: Yeah, you--

### Scientific Advocate (SA)
Claim: --Oklahoma Sooners?

### Conspiracy Advocate (CA)
Claim: I mean, you license it out.

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: You license it out.

### Scientific Advocate (SA)
Claim: As long as they can go to school and so those 70 percent that want to get their education can get it, I think it’s great.

### Conspiracy Advocate (CA)
Claim: Yeah, that

## Round 3

### Moderator
Claim: All right, that concludes round two of this Intelligence Squared US debate. And remember how you voted at the beginning of the debate. We’re going to ask you to vote again in just a few minutes after the closing statements, which will come immediately and be briefly. Round three, closing statements. Two minutes each, uninterrupted. Our motion is ban college football, and here to summarize his position against the motion, Tim Green, a bestselling author, former Atlanta Falcon, and college football hall of famer.

### Scientific Advocate (SA)
Claim: There is no question that there are problems with college football, as there are problems with almost every institution in this country. But I hope that, after some of the things you’ve heard tonight from Jason and from me, people who’ve benefited from the education of college-- the education we had on the football field with the perseverance, the hard work, the teamwork, the tolerance, and the benefits that accrued to us through our education, where we earned the opportunity to get college degrees, where-- and sometimes some of the people who get those degrees wouldn’t have another way to get them except through football scholarships.

So there are great things. They unify our communities in many instances. They unify campuses and colleges, and the reason why it’s there is because it is doing good things and yes it’s making money and yes the coaches are making money and this is America. It’s capitalism, I’m sorry. Brad Pitt makes $25 million to make a movie. That’s just our-- that’s our society. So we pay people what the market says we should pay them. Football, there are concussions, but there are no studies so far that link that to anything other than some isolated instances.

So football-- and it's evolving. With the equipment and the rules, it can continue to get better. But to end it, to me-- Malcolm Gladwell may be best known for his book called" Blink." And in that book, it says that when you're faced with a crucial decision or any decision, just listen to the premise and then give your immediate impression. So that's what I want to ask you to do tonight. Think about this. Think about, are we going to ban college football, and in a blink, I think you'll vote that we will not.

### Moderator
Claim: Thank you, Tim Green. Our motion is "ban college football." Here to summarize his position in support of the motion, Buzz Bissinger, a Pulitzer Price-winning journalist, sports columnist for "The Daily Beast" and author of "Friday Night Lights."

### Conspiracy Advocate (CA)
Claim: Look, there's no question, this is a radical solution.

But I think it is called for in what are radical times. I am surprised that Tim and Jason seem not to be affected at all about our lagging academic performance, that we're now 14th in the world in math and reading and science when we used to be first, that we're 16th in educational attainment, meaning that other countries are catching up and catching up rapidly and exceeding us when we used to be first. We simply do not have time to waste. Universities were set up for a primary academic purpose. They were not set up as sports factories disguised as universities. And I understand the graduation rate is 69 percent. I think it's ginned up.

I think a lot of players, and I think even Tim would-- he'll admit this to me privately afterwards-- a lot of players are pushed through and passed through with no demands placed upon him. And I know the impact. I did write a book called "Friday Night Lights" in which the cornerstone character was a black running back named Boobie Miles. Now, this was high school. And I saw what happened as many college players are when you are treated as a football animal, when you pass-- because the word on the street is-- with the professors is, "You better pass that kid or there's going to be trouble." Boobie Miles got no education. He was a football animal. He was considered dysfunctional, basically an idiot, which he was not. And I'll tell you, with no education, his life has been nothing, nothing but a horrendous hell and a lot of broken dreams that football propagates more than any other sport.

### Moderator
Claim: Thank you, Buzz Bissinger. "Ban college football," that is our motion. Here to argue his position against this motion, Jason Whitlock is a national columnist for foxsports.com and an All Sports insider and contributor to FOX Sports Radio.

### Scientific Advocate (SA)
Claim: I want to start where I began by-- Mr. Gladwell, Mr. Bissinger, Malcolm, Buzz, two of the brightest minds I have ever encountered. And I-- when I said that comment about them dabbling in sports, it's because most of the time they apply their mind to much bigger issues than sports. And so it's been a worthy debate. Mr. Gladwell began talking about the purpose of schools. And overall education is about preparing you for life. And I think if they had a bit more experience with college football, actual participation, and then I don't mean that in any kind of dismissive way.

But it's something you have to experience, because I don't think most people understand the educational benefits of college football. And it's dismissed as a bunch of dummies. Brady Hoke, the head football coach at the University of Michigan is a very good friend of mine. He played football at Ball State University. He had been the head coach of Ball State University. I have watched him up close and personal in this era reach kids at Ball State University and San Diego State University and now at the University of Michigan, with an entire leadership program and men-building program that he and his strength coach implement throughout a player's four and-five-year career. And it helps develop the overall person. And it helps prepare the athlete for life in the real world.

That is a school's purpose. If we truly understood football and what was transpiring, I don't think anyone would argue that it's not part of the academic experience. It may be part of the academic experience that some people don't respect because they don't understand it, but trust me, it is a big part of the academic experience. It's not perfect. It can be improved. It can be more like the Ivy League system. But there's no way we should ban football.

### Moderator
Claim: Thank you, Jason Whitlock. Our motion is "ban college football." And here to summarize his position in support of the motion, Malcolm Gladwell, a New Yorker staff writer and author of "The Tipping Point."

### Conspiracy Advocate (CA)
Claim: The most surprising thing about this debate to me at the send that we only mentioned the name Junior Seau twice. And to my mind, Junior Seau's shadow is cast over this whole evening. Last week he shot himself in the chest.

And he played four years at the University of Southern California, over which I'm guessing he was hit in the head about 4,000 times. He's not the first. Before Junior Seau, there was Dave Duerson, played four years at the University of Notre Dame, during which time he was probably hit in the head around 4,000 times. He wasn't the first, either. Before him, there was Andre Waters. Shot himself in the head. Played four years at Cheyney University over which time he was probably hit in the time at least 4,000 times. I could go on and on and on right down to the captain of the Penn football team who hung himself in his room a couple years ago. Someone did an autopsy on his brain. What did they find? They found evidence of long-term neurological damage that was the result of being hit in the head too many times. Now, I have sat, and I have listened to some-- some of the things that the other side has said have been extraordinarily eloquent. I think some of the things that both Tim and Jason said about what this game can do are absolutely true. It is, in many ways, a beautiful game.

It's a game that teaches all kinds of powerful and fundamental lessons. It's a game that's a central part of our culture. But at a certain time, I think this debate comes down to one thing, and that is you have to look at the collateral damage this game has left in its wake. And you have to ask the question, is it time to say, enough?

### Moderator
Claim: Thank you, Malcolm Gladwell. And that concludes our closing statements. And now it's time to see which side you feel has made the best argument here. We want to ask you again to go to the key pads at your seat to register your vote. This will be your second vote. Our motion is, "Ban college football." If you feel that this team presented the stronger argument, press number one. If it's this team, number two. Decide against. If you are undecided or became undecided, push number three. And you can ignore the other keys.

And if you press anything by mistake, just correct yourself, and system will lock in your last vote. So we'll have those results in about 140 seconds from now. And while we're waiting for the votes, I just want to ask-- this debate was actually one of our best ever.

And part of it was because they really heard each other. They didn't agree, but they listened to each other. And that made it a far more interesting debate. I just want to thank them and a round of applause for both Also just a little secret. There was a wager placed in the back room before the debate began. Everybody-- these four guys put up 20 bucks each. So there is a $40 cash prize in it for whoever-- whoever wins this thing. We want to thank our media partners Slate, especially Jacob Weisberg and his exceptional editorial staff. They've been with us all season. And this is our last debate here at the Skirball Center at NYU.

It's been our venue since the fall of 2009. Thank you to the staff and crew for six great seasons here. We really appreciate it. And I have a very, very short side competition. I'm going to ask a question. The first person in the audience who can answer this question correctly, you'll have about 15 seconds, will get two free tickets to the first debate in our next season. And the question is this. It's football related. "What does the Heisman trophy have to do with the man named Ed Smith, and who was he?" You got it? Yes. He was a football player and-- sorry?

### Moderator
Claim: The model for the Heisman trophy was an NYU football player. Class of 1936. This fall we are moving up-- congratulations-- this fall we are moving uptown to the Kaufman Center.

That's on West 67th Street between Broadway and Amsterdam Avenue, and dates are set, and tickets are already on sale. We're going to be following the presidential election particularly closely this fall, and that means we're going to be doing topics like, "Super PACS," and "Health Care," and "Taxing the Wealthy." The motions and debaters will be announced this summer. One other thing, we are very, very delighted to announce a new partnership. It is with the Richard Paul Richmond Center for Business Law and Public Policy that's a joint venture of the Columbia Business School and the Columbia Law School. The Richmond Center is going to co-sponsor two debates during the fall 2012 and spring 2013 season, beginning with an October 24 debate on domestic tax policy that will be featuring Glen Hubbard, who is dean of Columbia Business School. Glen Hubbard previously served as deputy assistant secretary at the U.S. Department of the Treasury and as chairman of the Council of Economic Advisors. And, once again, we are partnering this evening with New American Tavern around the corner to host a post debate reception at Amity Hall.

That's the locale around the corner, a block away on 3rd Street, between Thompson and Sullivan. Details for that location are in your program, but it's just really literally on the other side of this building. And there you can continue this debate with your fellow audience members over complementary appetizers and discounted drinks. And I'll be there along with some of the other members of our staff for a little bit. We did it last time, and it was great. People just wanted to keep debating the issue with each other. So we hope that we'll see you there. So that's it. I'm just waiting for the results to come. And here they come, for the $40 cash prize, glory. All right. It's all-- and you have heard all of the arguments, two teams of two, trying to change your minds throughout this debate, "Ban college football." That is our motion, ban it or not. Here are the results. Before the debate, 16 percent were for the motion, 53 percent were against, 31 percent were undecided. After the debate, 53 percent are for the motion, that's up 37 percent-- 39 percent are against, that's down 14 percent, 8 percent are undecided.

The side arguing for the motion carries the debate. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
