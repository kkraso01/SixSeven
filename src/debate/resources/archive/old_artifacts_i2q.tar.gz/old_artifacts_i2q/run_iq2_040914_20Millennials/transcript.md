# Debate Transcript

Topic: Millennials Don't Stand A Chance
Motion: Millennials Don't Stand A Chance

Debate ID: 040914%20Millennials


## Round 1

### Moderator
Claim: Hey, Bob.

### Moderator
Claim: Hi, John.

### Moderator
Claim: So we're going to do a little bit of debating and discussing and defining of millennials during the course of the debate. But there may be folks who don't have direct experience or be aware that they have direct experience with the millennial generation. But you were telling me backstage that you've recently had an interesting encounter.

### Moderator
Claim: Well, yeah. I've been interviewing a couple of millennials, people who entered the work force since 2000, and for an analyst position, a quite highly paid position as a credit analyst and security analyst. And one of these guys I think sort of summed up the reason you might vote for tonight's motion. He's showing me his work product, and the grammar was sloppy. There were spelling mistakes. It was basically just a rehash of a banker's presentation with no indication whatsoever of independent critical thought.

And I asked him about his current job, and he immediately started complaining about how they didn't appreciate his work enough.

### Moderator
Claim: Seriously, that was his-- that was his selling point.

### Moderator
Claim: That was serious. And so that, to me, sort of summarized the rap on millennials that you hear from employers.

### Moderator
Claim: But, surely, this generation has superstars as well.

### Moderator
Claim: It does. But, you know, I think an interesting part of the debate is also not just the qualities of millennials themselves but the world in which they have to compete.

### Moderator
Claim: Right.

### Moderator
Claim: And this is kind of interesting. After I interviewed this group of people, I started to think about outsourcing this analytic function. And we found a company in India that is supplying us a team of seven analysts, all with-- with undergraduate degrees in science and math, all with business degrees, all with CFA, charter financial analyst certification. The entire team is going to cost less than this one guy this I wouldn't even give a job to. And that's-- that's what these people are facing economically. I mean, they're facing real competition in a global world and an environment where there is very little job creation in America. So it's not just about their characteristics, it's also about--

### Moderator
Claim: The harsh world out there.

### Moderator
Claim: --the harsh world that they're entering.

### Moderator
Claim: So is there an argument for-- does the other side have an argument?

### Moderator
Claim: Well, I certainly think they do. The other side of the argument, I'd just sum up by naming four companies: Google, Facebook, Twitter, Go Pro. I mean, these are all very successful, very large companies that have provided new services and new products never seen before. And each one of them was started by somebody in their 20s. And I don't think we've ever had a generation of 20-somethings who've been able to start large entrepreneurial businesses, watch them grow, innovate as much as they have. This is the most tech savvy and entrepreneurial generation that I've ever seen, I think that America's ever seen. And I think that's the flip side of this motion.

### Moderator
Claim: Well, I thought we might take one second to look out into the audience and just see a show of hands, how many people identify with the millennial generation. Wow. I would say that that is maybe slightly more than half. So you all are being judged as well. Enjoy tonight And, Bob, thank you very much. And let's bring our debaters to the stage.

### Moderator
Claim: Great.

### Moderator
Claim: Thank you. Thank you. So as I mentioned, from every now and then, I might be asking for a round of applause for sense of atmospherics, but this one is sincere and authentic. I just want to invite one more round of applause for Bob Rosenkranz for bringing this to us.

They are young, they are tolerant, they are entrepreneurial, they are civic minded. No, wait a minute. They're spoiled, they're lazy, they're entitled, they're living in their mother's houses, and they are doomed to disappoint history. I am talking about the generation called the millennials, those born, roughly speaking, in the '80s and the '90s, now America's youngest adults. A caricature, sure, on both sides. But there is something in there, and there's somebody inside there. So let's debate this. Yes or no to this statement: Millennials don't stand a chance, a debate from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters here at the Kaufman Music Center in New York, two against two. They will argue for and against this motion: Millennials don't stand a chance. As always, our debate goes in three rounds, and then our live audience here in New York votes to choose the winner, and only one side wins. Millennials don't stand a chance, that is our motion. And let's meet the team arguing for this motion. First, please, let's welcome Binta Niambi Brown.

And Binta, you did corporate law for quite a while, but you left. You went to the Kennedy school at Harvard where you worked on market solutions to humanitarian and human rights problems. You're on the boards of a lot of great organizations and one university, at least. But this is what I want to ask you about: A few years ago, you were profiled in Real Simple Magazine, profiled as a mentor to a millennial. And I want to ask you, what does it take to mentor a millennial?

### Conspiracy Advocate (CA)
Claim: It takes patience.

### Moderator
Claim: Because?

### Conspiracy Advocate (CA)
Claim: And compassion.

### Moderator
Claim: Because?

### Conspiracy Advocate (CA)
Claim: Because they're millennials. No, I mean-- I'm not going to pick on the millennials. I think they're great. I think I've certainly gained more from mentoring any of them than I have contributed to any of their lives.

### Moderator
Claim: Ladies and gentlemen, Binta Brown.

And Binta, your partner is?

### Conspiracy Advocate (CA)
Claim: My partner is Keith Campbell.

### Moderator
Claim: Ladies and gentlemen, Keith Campbell.

Keith, you are also arguing for this motion that millennials don't stand a chance. You're head of psychology at the University of Georgia. You're co-author of the book, "The Narcissism Epidemic, Living in the Age of Entitlement.” You're here to talk tonight in part-- part of your argument is about the narcissistic trends among millennials, this younger generation. But, Keith, you know that this phenomenon of slightly older generations wringing their hands about slightly younger generations is as old as the hills, right?

### Conspiracy Advocate (CA)
Claim: Yeah. I mean, people wrung their hands about me. Some still do. I think the thing to keep in mind, there's a lot of positive you see in millennials; tolerance for other people being a big one. But there are some down sides I'm going to talk about.

### Moderator
Claim: With an argument.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: You've come to the right place. Ladies and gentlemen, W. Keith Campbell. Our motion is "millennials do not stand a chance.” and two panelists will be arguing against this motion. Please, ladies and gentlemen, welcome David Burstein. David, you are 25. You are, congratulations, the youngest debater we've ever had on this stage. You are founder of Generation 18. It's a nonpartisan organization to get-out-the-vote among young people. You wrote the book, "Fast Future: How the Millennial Generation is Shaping our World.” You made your first documentary back in 2008. It was called "18.” You had interviews with Jeb Bush, Samantha Power, John Kerry. How old were you when you started that project?

### Scientific Advocate (SA)
Claim: I was 16.

### Moderator
Claim: 16 years old. And did you have any idea at the time that you had no idea what you were doing?

### Scientific Advocate (SA)
Claim: Yeah. I didn't really think about that fact. It might have been good to think about in retrospect, but I think it's kind of typical of this generation that we just go out and do right away.

### Moderator
Claim: Thank you, David Burstein. And, David, your partner is?

### Scientific Advocate (SA)
Claim: Jessica Grose.

### Moderator
Claim: Jennifer Grose, ladies and gentlemen. Uh, Jessica. Jessica. I just said Jennifer. Let me do that again.

### Scientific Advocate (SA)
Claim: All millennials are named either Jessica or Jennifer. It's okay.

### Moderator
Claim: We can fix it up on the radio so that millions of people will never know the awful error I just made if I-- if I just say, "Jessica Grose, ladies and gentlemen." Jessica Grose, you are a self-described ancient millennial. You're a contributor to Slate and Bloomberg Business Week. You write a lot about culture and creativity for fast companies, co-create. You've been a senior editor at slate and Jezebel. In 2012, you published your first novel, "Sad Desk Salad.” So you've done a lot, and you are doing a lot. So what is the top reason you took time out from all of that to defend millennials on this stage tonight?

### Scientific Advocate (SA)
Claim: Well, I mean, I couldn't just sit home and listen to my generation be maligned by people who don't understand us. So, you know, I had to come defend our honor.

### Moderator
Claim: All right. You know that you are being judged like they are as well. Thanks very much. Ladies and gentlemen, Jessica Grose. And these are our debaters.

Now, this is a contest. There will be judgment. The debate will, at the end, have a winner and a loser, and that will be determined by a vote of our live audience here in New York City. By the time the debate has ended, you will have been asked to vote twice, once before the debate and once again at the conclusion. And the team whose numbers have changed the most in percentage point terms will be declared our winner. So let's go to the preliminary vote. Let's go to the preliminary vote. Go to the keypad at your seats. Again, look at the motion:"Millennials Don't Stand A Chance.” If you agree with this, if you agree that they don't stand a chance, that means you're for the motion and we want you to push number one. If you disagree with it, if you think they do stand a chance or better, push number two.

And if you're undecided, push number three. And remember how you voted this time. We'll-- at the very end of the debating we'll have you vote a second time, and we got about a 90-second turnaround, and that's how we declare our winner. Okay, we're going to lock it out, and we're going to get started. On to round one, our motion is "Millennials Don't Stand A Chance.” Opening statements from the face-- first opening statement from the first debater. It will be seven minutes each. It will be seven minutes long. And let's welcome to the lectern W. Keith Campbell. He is professor of psychology at the University of Georgia, coauthor of several books, including "The Narcissism Epidemic" and "The Handbook of Narcissism" and "Narcissistic Personality Disorder.” Ladies and gentlemen, please welcome W. Keith Campbell.

### Conspiracy Advocate (CA)
Claim: Thanks. It's always nice when people mention "narcissism" and then they start laughing. I never know why, but it's always like a bad ex-relationship or something. What I'm here to argue for is that "Millennials Don't Stand A Chance.” What I'm not here to do is malign millennials or bash millennials. That's fun. I just don't want to do it. I don't want them to fail. I don't want my kids to fail either who are going to be the next generation. But, that said, I think there's a lot of problems. And to sum it up easily as I can I'd say there is a major disconnect or major gap between how young people were raised in the '80s and '90s, they're born in-- people born in the '80s and '90s, the millennials, and the world they're facing today. Think about it this way, they were raised with a very inflated optimistic view of themselves and the world. And they're-- we've given them a really terrible place to get a start. Let me just expand on this a little bit. If you think about the millennial self, these are kids that started-- that were born in the '80s, they started school right when the self-esteem movement hit. This was brought to us by the good people in California in 1982, started going through schools-- the idea was if we can give kids self-esteem they'll do better in life.

And the way to give kids self-esteem is not to have them succeed at optimal challenges or have strong relationships, which actually works, it was to tell them they're special and unique and give them lots of awards and trophies as people sort of lament. So we set people off that way. And we do have a generation with very high self-esteem, especially college students. Self-esteem is near the top of the scales we measure. We also see some of the darker side of self-esteem with that. We do see increasing narcissism. It wasn't like it was flat with Gen X and then jumped up, but it just keeps going up and up. We see increasing uniqueness. We see this with the names we've given kids, and this is the millennials, but we're still doing this. I mean, now with our children born today we don't even give them names. If we're celebrities we name them directions on a compass so our-- name them after fruit-- so these kids are given a sense of specialness, they think they're better than others. We've raised expectations in young people dramatically, where they have high expectations about professional careers, they have high expectations about going to graduate school, and, again, it's great to raise expectations if you can provide a reality for that.

And finally there's been this big shift in values. There's been a switch from what we call "intrinsic values," which the baby boomers tended to have, to much more extrinsic values. To give you an example of the biggest change would be something like in the baby boom people said, "I want a meaningful philosophy of life.” People don't say that anymore. People aren't looking for their true self. What they're looking for now is a job to make lots of money. Again, that's fine, it just doesn't fit with our world. So if you take that inflated psychology the millennials were raised with and you look at reality right now, we have very high youth unemployment, we're talking about 12-- a little over 12 percent for people in the young 20s with very liberal numbers of unemployment. We have a trillion dollars in student loan debt. And student loan debt is horrible. I mean, this isn't like, "Gee, I bought a McMansion . Oh, I can't afford it. I can live in it for three years and send the keys back."And this is like "I can't get rid of this stuff because the government says, 'You can't get rid of it.'" You have massive levels of competition for jobs. You have massive levels of competition for those elite education tracks. I mean, people are hiring people to write college essays now, it's-- I mean, like paying to make 30 grand to get into college. The millennials are having to put off marriage. The average marriage age now for women is 27, 29 for men. You have over a third of young people 18 to 30-- living back at home with their parents. Not necessarily in a basement. Lots of homes don't have basements, but maybe over the garage. Maybe someplace else. And yet-- I mean, even now, sociologists talk about this period of emerging adulthood-- age 20 to 24-- which is something we didn't talk about 20 years ago. These people are in a cocoon and they're going to butterfly out as adults. And they might. We have decrease in civic engagements. Most measures we look at-- millennials volunteer more than any generation we've studied. So, that number has gone up.

They voted a lot for Obama's first term. But other than that, civic engagement has dropped. And generally, the sense of trust we have in the country for each other and for our major institutions-- our journalists, our government, our religion-- is at the lowest point we've ever measured. I mean, the country in terms of just our basic civil institutions is collapsing. Bottom line, and people grown up, raised by us-- they don't raise themselves. They're raised to have a very positive view and a very optimistic view. And they're put in a reality that is incredibly challenging, incredibly negative. Some are making it. Some are doing great stuff in entrepreneurship. They're creating their own jobs. Other people are part of what I think of as the great fantasy migration. They're dressed up as Wookies or Stormtoopers, or they're living in their mom's basement, playing World of Warcraft. And you get a lot of ego needs met that way and have a lot of good relationships. But that aside, it's very tough. And I apologize for being so negative on such a nice evening. Thank you.

### Moderator
Claim: Thank you. W. Keith Campbell. Our motion is, Millenials Do not Stand a Chance. And here to argue against this motion is Jessica Grose. She writes for Fast Company's Co.Create and is a frequent contributor to Slate and Bloomberg Businessweek. And also author of the novel "Sad Desk Salad.” Ladies and gentlemen, Jessica Grose.

### Scientific Advocate (SA)
Claim: So, like John said, I call myself an "ancient millennial.” I was born in 1982, which is the first year in a lot of definitions of millennial. I have a baby, and a husband, and a mortgage, and all those things that Keith worries millennials will never have. We are the most racially diverse. We are the most educated generation of adults today. We've got the lowest amount of debt in 15 years. And that, you know, in part because we've seen what's happened to the world and we have decided to pull back on buying frivolous things.

We have healthy relationships with our parents, reported highest levels of healthiness among all adults today. And we have a deep entrepreneurial spirit, as the mentioned. So, why do our detractors say that we're doomed? They say we're immature, immoral narcissists who want to live in our parent's basement. It's always the basement. Or maybe the attic. So, these stereotypes are based on false media narratives. And I am urging you to vote against the proposition because I'm going to dispel those falsehoods. And my partner, David, he's going to tell you about some of the under reported truths about millennials. So, let's start with that first myth, that basement myth. So, it's true that a greater percentage of millennials live at home than previous generations. But the degree to which that's true has been completely exaggerated. Keith said a third. That's not the numbers I've read. The numbers from Pew are that 15 percent of millennials live at home, compared to 12 percent of boomers and 13 percent of GenX. So, I don't know where they're getting that.

And the second part of the myth is that it's necessarily a bad thing. Half of the millennials who live at home are in college. And so, I think it's better for them to be living with their parents while they get an education than to be wasting money they don't have on dorms and apartments. So, the second part of the myth is that the people who aren't in college are just sponging and they're playing video games all day. So, I have two examples here. One is Lena Dunham, because you cannot have a debate about millennials without mentioning Lena Dunham. She is the creator of HBO's "Girls.” If you don't know who she is. She lived at home after graduating from college to make her first feature film, which went to South by Southwest and led directly to her being the creator, star, and writer of her own HBO show, which is the most zeitgeist-y show in generations. So, maybe you think, "Dunham is privileged. She's not a good example.” So, how about Sophia Amoruso? She was making $13 an hour. She was a community college dropout when she was living at-- with a family member in their cottage.

She started an online business, selling vintage clothing on eBay. That online business has turned into a multi-million dollar organization called "Nasty Gal Clothing.” She employs 300 people. So, I don't think she would have been able to do that if she had to pay rent on some bad apartment. Really having that support allowed her to launch herself into the world. So, the second myth is that we're immature. And some of this immaturity is said because we're not buying cars and we're not buying homes like the people in generations before us did. And that's not because we don't have the maturity.

It's because we prefer to live sustainably, not just financially sustainably, but environmentally sustainably. We want to live in close communities. We use public transportation. And I think that that's all to the good. With the age of the McMansion and the SUV, the ginormous SUV, that's over, and good riddens to that. So the third myth is that we're immoral, and, as Keith mentioned, we're less religious.

But if you actually ask millennials why they've left the church or temple that they were raised in, a full third of them say that it's because of their church's values about the LGBT community. So I think that actually shows a huge amount of moral backbone to be able to question what you were raised in and to be able to say that you want to be on the right side of history. So the fourth myth, and it's the most pervasive myth, is that we are narcissists. And what galls me is that it's always the boomers saying this. And they were the original narcissists. I mean, I think they forget that Tom Wolfe called them "the me generation" in 1976. But-- so Keith has told you that we have this inflated, overoptimistic sense of the world. But that's not my impression at all. If you went back to 2000, David Brooks wrote an article in the Atlantic called "the organization kit.” It might have been 2001. I was either a freshman or sophomore in college. And that was a much more accurate picture of how we were raised.

We were raised to know that we are competing in a global world. Remember, everybody had to learn Japanese in the '80s and '90s, because they wanted us to-- our parents wanted us to compete the same way that kids are learning Mandarin today. And he says, you know, we are more narcissistic because we agree with statements like, "I will be a success.” You know, those are just statements. You know, it's just words. And I think actions speak so much stronger than that. As has been said, we volunteer more than any generation. 73 percent of millennials volunteered for a nonprofit in 2012. And the percentage of college freshman believing that it's essential or for very important to help people in need is the highest level it's been at in 40 years. There are the lowest levels of drug use, teen pregnancy and youth crime. That speaks louder than any multiple choice test to me. So I'm not going to stand here and say we weren't dealt a bad hand. Like it's been said, we graduated into a recession. The jobs are scarce, and that there are systemic problems in America with poverty and income inequality that plagues all generations, not just us.

But I think that millennials are uniquely qualified to solve these problems because we're committed to social justice, we're committed to sustainability, and we have this entrepreneurial spirit. So I really urge you to vote against the proposition because we are so far from doomed. We're just getting started.

### Moderator
Claim: Thank you, Jessica Grose. And a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, arguing it out over this motion: Millennials do not stand a chance. You've heard the first two opening statements and now onto the third. Debating for the motion that the millennials don't stand a chance, Binta Niambi Brown. She is a lawyer, a startup adviser, a human rights advocate. She has been recognized as one of Fortune magazine's "40 under 40 business leaders" and as a young global leader by the World Economic Forum. Ladies and gentlemen, Binta Niambi Brown.

### Conspiracy Advocate (CA)
Claim: Good evening, everybody. So I'm a lover, I'm not a fighter. I'm not here to fight, I'm not here to bash, I'm not here to talk about all of the reasons why millennials are horrible people and are going to fail of their own doing because I don't believe that. I mentor millennials, and I educate them. And I am a firm believer in their capacity. With that said, the picture is not nearly as rosy as it's been painted by my esteemed opponent, Jessica. So a couple of things that I'd like to unpack. First, the notion that millennials are the most educated generation in the history of humanity, ever. We can look at that from a quantitative perspective, and we can also look at that from a qualitative perspective. Let's talk about it first quantitatively.

My generation, generation X, the forgotten generation. Everybody likes to skip over us. We don't have complexes. We invent companies like Google, actually. It was X that invented Google, not Y. Correction from earlier tonight. So my generation, at this point, depending on the study you look at, we range in education from 30 to 45 percent having completed the equivalent of a four-year college degree. If you look at the Boomer Generation, between the ages of 55 to 64-- and again, I'm reminding you of the quantitative versus the qualitative assessment. If you look at the boomer generation, the boomer generation is now around 32 percent. The very wonderful cohort that comes up behind me, they are currently at or estimated to be around 33 percent. So this notion that they have more education at this point in time than anybody else is actually not true from a quantitative perspective.

It's also not true qualitatively. And what do I mean by that? The quality of education in the United States as we all know and have been reading about over and over and over again has been declining precipitously over the course of the last several decades, in particular as concerns science and mathematics. That people are taking tests, that they are taking APs, that they are going to college does not mean that they are learning any better, particularly in an environment where our government has insisted on teachers teaching to the test instead of developing deep critical analytical thinking skills that are absolutely and unequivocally necessary in our workplace. So qualitatively is not quite there either. Let's also discuss this notion of what a millennial is. I think far too often, when we're having conversations about when a millennial is and what a millennial isn't, we do talk about Lena Dunham, and we talk about Mark Zuckerberg. But I think that they are far and away the exceptions for the millennial population.

As noted, the millennial group is the most diverse in the history of humanity. 43 percent are nonwhite. Of that 43 percent who are nonwhite, 35 percent of them are black and Hispanic. The black and Hispanic millennials are in primarily underperforming schools, they are mostly unemployed, they are not receiving college degrees at the same rate. And the situation for them is particularly bleak and really, really bad. I'm going to keep going with this theme a little bit further because we can't just talk about the exceptions. We have to talk about the whole. So when we say on our side that millennials don't stand a chance, we're not talking about Jess, we're not talking about David, we're not talking about a couple of my millennial mentees who are here tonight, we're not talking about the millennial entrepreneur whom I have given some advice to. We're talking about all of the rest of them. We can't focus on just 1 percent or 5 percent or 10 percent of the stars. So even with that, 66 percent of millennials are not earning college degrees, right?

That sounds like it's a high number, and it's not when you think about the number of people who have actually earned their college degrees. But in an economy that is a knowledge-based economy, where increasingly we need people with these computer science and engineering degrees, it's pretty bad, right? And it's bad because, as was alluded to earlier tonight, we're entering into the age of artificial intelligence. We're entering into the age of machine learning. The kinds of jobs that we've prepared millennials to take, right, are not going to exist. And so then what do they do? They're going to end up in jobs and careers unless there is a dramatic intervention, which I will argue we need to have a dramatic intervention, then will end up in the kind of jobs and the kinds of careers where they are overeducated and underpaid. And that's not particularly good, particularly for a generation, as Keith has already said, which has $1.1 trillion worth of student debt, which, by the way, Jessica, is the reason many analysts are saying millennials are staying home.

So I'm sure it's very nice to have anecdotal evidence suggesting that millennials are staying because they like their parents. I too like my parents. I'm extraordinarily close with my parents. I wish they could have made it tonight. I actually have a lot of millennial qualities. That's not a bad thing. But I think that financial independence for most of us and for most adults means that we want to move out of the house at a certain point. And that's important for another reason, not because we want people to over-consume, but because the traditional indicators for economic growth and what that relies upon is a form of consumption that relies on housing strikes that relies on housing formation, that relies on purchases of furniture and purchases of appliances and other things millennials are currently not able to afford in part because those who are college educated, who are not undereducated, right, so the undereducated millennials are in the absolute worst position.

Those who are college educated, to the extent that they weren't qualified to get the high-tech jobs, which most of them are not qualified for, as I've already suggested, they're in jobs which don't actually require a college degree. And so they're not earning enough money. And this is isn't, by the way, any of their fault. I have about 45 seconds left, so I'm going to hit on two more important points. None of this is the fault of the millennial generation. All of this is the fault of the kinds of policies, Baby Boomers, the greatest generation, and even a few people who are in the Generation X in Washington right now have put into place. It's the absence of a good jobs policy. It's the inability for us to work on entitlement reform and shifting all of that burden to millennials. And so it's no wonder that this generation is completely stressed out. And if I had more time, I would begin to tell you about the very difficult numbers of 44 percent of college students evidencing or suggesting that they have some level of depression. Things are not as good as they seem. Thank you very much.

### Moderator
Claim: Thank you, Binta Niambi Brown. And that's our motion, "Millennials Don't Stand A Chance.” And here, our final debater to argue against this motion, "Millennials Don't Stand A Chance," David Burstein. He is the author of "Fast Future: How the Millennial Generation is Shaping Our World.” He is founder of the voter engagement group, Generation 18. Ladies and gentlemen, David Burstein.

### Scientific Advocate (SA)
Claim: Thanks, John, and thanks to all of you for being here tonight. You've heard obviously a lot of things already about millennials. And, as Jessica mentioned, I'm going to hit on a couple things that are true about millennials that I think are important to consider in this context. I am a millennial, as was stated earlier. And I have been spending the past several years really trying to understand what this generation is and what this generation means and particularly thinking about how it relates to the context of the world that we're living in. And I want to just highlight that. I'll come back to that later, thinking about the context of this world and what that means.

I got my start, as was mentioned earlier, in political engagement, thinking about young people in political engagement. And the trend we have seen in youth political participation over the past several election cycles is really remarkable. And this is in the face of a generation who has seen arguably the most toxic political climate that we've seen in many, many years, who has turned out in record numbers to vote in recent elections, who have actually had an incredible role in pushing issues like gay marriage to be where they are at today. This is the generation who has the largest support of that issue. And it's a generation who have actually worked on campaigns. They've gone to volunteer. They've gotten deeply engaged in what it means to be a candidate for office.

In fact, just this Sunday I was in Pennsylvania for a person in this generation who was actually running for office. So I think there's a lot to consider there about the role of this generation in politics and how that contributes to that. And when Keith talks about civic engagement and the lack of civic engagement in this generation and says that voter participation volunteerism are up, I think that there are other measures of at least political engagement-- there aren't very other many measures you can measure when you look at that. So it's really a deeply engaged generation. It's also the first generation that truly is a global generation, that understands the role of their relationship to the rest of the world. And as you think about, you know, what Robert was mentioning earlier about jobs going to India and other places, this is a generation that gets that. For previous generations, people have actually had the choice about whether or not they wanted to recognize that there was another part of the world out there. This is the first generation who has no choice but to realize that and deeply understands that. In fact, 93 percent of people in this generation say that they at some point in their life expect to live or work globally.

So it's really a generation that's in tune with the reality of the world that we're living in. You also look at this generation in terms of social activism, which is also something I've spent a lot of time thinking about. And it's true that volunteerism is up, but one of the most remarkable things that's happened over the past several years is you've seen record numbers of people in this generation starting their own businesses, starting their own organizations, and caring about issues as diverse as gang violence on their own street or international development in Africa. And you see this incredible range of people from different socioeconomic backgrounds who are participating in trying to make the world a better place. In fact, an overwhelming majority of people in this generation actually say they would take a job that pays them less money if they could have more impact in that work. And you see record numbers of applications for programs like Teacher America, the Peace Corps, a lot of which has followed ever since 9/11, which in a lot of ways was an important civic moment for this generation, which really allowed people to see that there was something that as individuals we can do.

For us, if you think about the context for the past several years of what this generation has gone through, growing up in an age where we lived under the specter of two wars, where we saw every one of our biggest institutions fail, banks, educational systems, our political system, it is incredible to know that this is a really resilient generation. In the face of the economic crisis, people in generation actually became more optimistic about their own economic future. And those numbers are still true today. In fact, eight in 10 people in this generation, according to a Pew study that just came out a couple weeks ago, say that they have enough money now to live the life that they want to life or-- and that they will in the future. And you also look at the fact that 75 percent of the people in this generation have given to-- have given to charity over the past several years. And 49 percent say that America's best days are ahead of us. All of these numbers, by incidentally, have tracked over the past several years, as people have been following millennials.

And they're also relatively on par or higher with people in this generation than they were in their counterparts' years before. But the final thing that I wanted to talk about is this role of entrepreneurship. Binta sort of made the point about the fact that there are only a handful of people who are doing this. But it's important to note, first of all, that there are the largest number of self-made millionaires and billionaires in this-- under the age of 35-- that exist in this generation that have ever existed. And if you were talking about whether or not millennials don't stand a chance, I think that's an important consideration, to look at the amount of wealth creation-- not just what that means in the raw numbers, but what that means in terms of the kinds of things that this generation is capable of. You know, as John pointed out, when I was being introduced, this is a generation that doesn't think about "Should I do this? Should I not do this?" But it's a generation that actually jumps into action. In the face of the economic crisis, well - - there were a number of suicides related to economic challenges for people of older generations.

There was not a single such one for people in this generation. When you look at these indicators of how that economic crisis fared, people in this generation became incredibly resilient in looking at-- looking at the future and continue to do that today. In fact, an overwhelming majority of people in this generation say that someday they might like to start their own company. Whether or not people actually do that is another question, but the idea that people are thinking in that kind of way gives us a kind of strong-headedness and resilience that I think will be very positive going into the future. The jobs of this economy, in this environment-- are different. But this is a generation that has grown up in the future, in this new world, who's absolutely ready to fight and compete for that kind of work. And it's a generation that really has accomplished in its short lifetime an incredible amount. So, I'm going to-- I'm going to stop now. I'm looking forward to discussing with you guys a little more.

## Round 2

### Moderator
Claim: Thank you. David Burstein. And that concludes Round 1 of this Intelligence Squared U.S. Debate where our motion is Millennials Don't Stand a Chance. Remember how you voted before the debate? We're going to have you vote again immediately after the debate. And remember, it is the team that moves the numbers the most, in percentage point terms, will be declared our winner. I want to let you know that tonight's debate is being broadcast worldwide on our website-- IQ2US.org-- and also on FORA.TV. If you are watching the live stream, we'd like to hear from you too. Send us questions via Twitter or Facebook with the hashtag Millennial so that we spot it. And be sure to let us know what city and state you're from, and also your first name. So, now on to Round 2 of this Intelligence Squared U.S. debate, where our motion is Millennials Don't Stand a Chance. Round 2 is where the debaters address one another in turn, and also take questions from me, and from you in the live audience. We have two teams of two arguing for and against the motion. The team arguing for the motion-- W. Keith Campell and Binta Brown-- we heard them say basically that millennials have been set up to fail by being sent into a challenging world without really having any of the antibodies to challenge.

They say that they have not been as well educated as they think they are, that they are postponing adulthood, that they are narcissistic like no generation has ever been. They can see that there are success stories, but they say those are the exception and that things are particularly bleak for minorities. Bottom line? They're not saying nasty things about their opponents. They're saying none of this is their fault, that they've been cheated by the generations ahead of them who left them a terrible deal. The team arguing against the motion-- Keith-- Jessica Grose and David Burstein-- they're saying that basically millennials are the victims of a lot of ridiculous myths in the media. Yes, perhaps, they live in their basement. It's not because they're freeloading, it's because they are frugal, that they are conserving their resources in a difficult time, that they know what they're doing. They say, in response to the notion that they're narcissistic, that no generation has been as civically involved as this one, that this generation has healthy relationships and entrepreneurial spirit, that it's optimistic, resilient. And therefore, that it holds in its hands-- and its personalities-- the solutions to the very challenges that they are facing. What I want to do is put a question to the side that is arguing that millennials don't stand a chance, and tell you that what I hear from your opponents is an explosion of optimism.

They've heard everything you said. To a great degree, concede that times are tough. But, boy, do they believe in themselves, and purely on optimism, they think they're going to get through. And I want to put to either of you a response to that, either Binta or Keith. Binta Brown.

### Conspiracy Advocate (CA)
Claim: So I think optimism is awesome. And I think that when you look at the level of optimism for generation X when we were the very same age as you guys are now, it was actually equal to your level of optimism. Optimism is not something that's lost upon the young, right? We expect the young to be optimistic. And I hope that you keep your optimism. David, I hope that you keep your pragmatic idealism, as you've written about. But the practical reality is that, as people grow older, and as their responsibilities increase, and as they do take on mortgages and have families and have additional constraints, the ability to service that optimism in every generation or over the course of history, it decreases, right? I hope that's not the case for millennials. But it's not anything special when you compare it to other generations, unfortunately.

### Moderator
Claim: Ah, okay. That's the point. David, in other words, your opponents are saying they've heard it before.

### Scientific Advocate (SA)
Claim: Well, I mean, I think you have to look at the context of the circumstances. You know, the hand at which generation X was dealt, and there is a parallel. It's actually a little bit higher among millennials than it was among generation X. But if you consider that in terms of context, as I mentioned earlier, I think that's what's really important, that you would expect in the worst job market in history, you would expect in the face of huge unemployment and the terrible economic climate, that the natural-- the natural tendency would be for people to be incredibly not optimistic about their own economic future. But what's even more interesting is that people are optimistic about their situation at the moment, not just about their future and what's ahead. And I think that that's really what's particularly striking about it.

### Conspiracy Advocate (CA)
Claim: Can we just talk about--

### Moderator
Claim: Let me bring Keith in to respond to that. Keith, do you prefer W. Keith in references or "Keith."

### Conspiracy Advocate (CA)
Claim: "Keith" is good.

### Moderator
Claim: Okay. Because when I first ran by you with Keith, a big voice in my head said, "Say W. before his name."

And so I didn't know if I had to W. all night or not.

### Conspiracy Advocate (CA)
Claim: There are a lot of Keith Campbells out there, and I've gotten hate mail for some of them for cloning Keith.

### Moderator
Claim: Oh, you don't want that. All right, W. it is.

### Conspiracy Advocate (CA)
Claim: --before that, yeah.

### Moderator
Claim: So, Keith, respond to your opponent.

### Conspiracy Advocate (CA)
Claim: Optimism is fine. I'm not as big a fan. I'm a little more of a fan of self-control and sort of effectively moving towards goals rather than global optimism. I don't know if we're seeing that. I just-- I don't know. I don't know if there's data on our people saying, look, I'm in trouble-- I'm going to do X, Y and Z to get out of trouble, or are they-- are they kind of moving into something else to get away from it. I just don't the answer to that.

### Moderator
Claim: Jessica?

### Scientific Advocate (SA)
Claim: I would say we are effectively moving towards goals. It was mentioned that millennials are putting off marriage and family, and that, in large part, is because women have flooded into the work force and have higher levels of educational attainment. And that's why it might seem like immaturity it you don't actually talk to millennials and look at the statistics.

They are putting off these things not out of a sense of immaturity but because they do want all of their ducks in a row. They're planning for these things. It just-- that planning takes longer. And I don't think that that is necessarily a bad thing. I mean, all of the studies show that older parents are better parents. So I just don't see how that's a cause for alarm. That's a cause for celebration.

### Moderator
Claim: Okay. Binta Brown.

### Conspiracy Advocate (CA)
Claim: Just to talk about this context point, David, so first of all, it stinks to be young, having gone through what your generation has gone through. But keep in mind that not only did your generation go through all of the things your generation has gone through, but the X 'ers and the boomers and many members of the greatest generation have gone through the same. And some of them actually somewhat worse. I mean, I think our context is we were children of the Cold War. We were children of gas crises. We were children who saw the walls come down, sure. And that set into some of our optimism. But I think that you can look at any point in history and say, yes, but we're extra optimistic because of-- look at what we've gone through.

That argument just doesn't really sit with me, particularly as-- when you think about what Keith is saying with optimism and what are the dangers, and there‘s a rebuttal in part to Jessica. And I'm sorry to keep doing this to you. But one of the dangers with optimism is that it does fuel consumption. You say that your generation is more frugal, and in fact, studies shows that your generation has had the fastest increase from luxury consumption. I think I saw something along the lines of-- well, 25 percent of millennials report not having enough to cover their expenses. But at the same time, they've increased 33 percent in their purchases of premium fashion and services, more than any other generation.

### Moderator
Claim: Okay. Let's let the other side respond to that-- to that argument about materialism. let's call it. Jessica or David. David, we haven't heard from you in a minute.

### Scientific Advocate (SA)
Claim: Well, I mean, I think the important thing to consider there is what-- as millennial spending patterns change, for instance, as Jessica is mentioning, when people are not planning for these large payments, of course you're going to see increases in other kinds of spending.

That should not be surprising to anyone who looks at economics, that when people are not planning to buy houses and cars and these big capital expenses that people normally go through, that you would see increased spending in other areas. I also think one of the interesting things about, you look at one of the-- in those numbers, there are two things which are kind of tricky, which is one is increased spending on people eating out and increased spending on travel. Both of those things, if you go deeper into studies on both of those issues, show that people are engaging in those activities with friends as a way of developing communal experiences. And this goes to the question of thinking about community, which I think is really one of the big traits of this generation. This generation is finding new ways to engage community in helping them

### Moderator
Claim: So can you very quickly, and in 15 seconds, list some of those ways, then I want to hear from your opponent, Keith.

### Scientific Advocate (SA)
Claim: Well, I think the most important point I would make on that is that this is a generation that has more relationships, more strong relationships with a diverse set of people than any generation.

### Moderator
Claim: Quantified how? Is that your gut, or is there--

### Scientific Advocate (SA)
Claim: No, it's in terms of the kind of access to community that any person in this generation has access to.

### Moderator
Claim: Okay. Keith Campbell.

### Conspiracy Advocate (CA)
Claim: Well, I think what we've traded, in a large part because it's the ability to have social networks, Facebook or whatever, is we have broader social networks. And young people have broader social networks than people who grew up before that. I think there's been a tradeoff of depth to some extent because it takes time to nurture a broad network. But the networks are certainly broader with young people. I just don't think the depth is necessarily deeper.

### Moderator
Claim: All right. I want to-- let me take that question to Jessica, because, Jessica, a couple of times you've done a little flipping of their narrative, as you did with postponing marriage, which I'd like to come back to. But your opponents are saying that this notion of relationships that are online and that are broader, they're saying they're just not as good as real good old-fashioned relationships. And I think a lot of us understand why they say that, why there's a logic to that. But do you need to concede that point?

### Scientific Advocate (SA)
Claim: No, absolutely. I mean, I will make the example of G chat. I talk to my friends throughout the day on G chat, the same people over and over again, the same set of four women who, if, before the advent of technology, I would have had to call them, walk over to them. The constant communication that we can have with our close compatriots is immeasurable. So, yes, we might have geographic distance or, you know, we might have these broader, you know, networks of friends. But I think actually it enables a closeness. And I think, you know, the number of close friends that people have has not demonstrably changed. You know, I think people say it's three people that they consider confidantes. And I don't think that those numbers have moved.

### Moderator
Claim: Are you persuaded, Binta, by that?

### Conspiracy Advocate (CA)
Claim: Yeah, I mean, I-- listen, from my perspective, I have a huge number of friends on all various forms of social media. And I use that as a means of bringing myself closer to them. I have a much broader set of relationships. But what I dispute is that millennials have a more diverse set of relationships.

### Moderator
Claim: Why?

### Conspiracy Advocate (CA)
Claim: Well, because the studies don't show that. And empirical data and analysis doesn't show it either. Again, going back to that 43 percent nonwhite number, I do not see, on college campuses, close integration between the black and Hispanic populations and the white populations. I do not see, when I go to tech conferences, and there are a lot of young entrepreneurs around, a great integration there. I do not see it at social good conferences. I do not see it at like basically anywhere I go.

### Moderator
Claim: Okay. Let me take it to David Burstein because he was making this. David, do you see something that Binta is not seeing?

### Scientific Advocate (SA)
Claim: Yeah, I mean, I think you--

### Moderator
Claim: And where? I mean, she just was-- she just gave three concrete examples of where she's basically seeing, you know, segregation, whether self-motivated or not. But she's saying it's a little bit of a fantasy what you're talking about.

### Scientific Advocate (SA)
Claim: Well, I think you have to look at it in comparison to where that's been in the past. I mean, the idea that those groups you mentioned were worse 20 years ago, I think it's pretty easy to say that. I mean, I think you think about the--

### Conspiracy Advocate (CA)
Claim: One or two-- one or two as opposed to zero is not a real marginal improvement.

### Scientific Advocate (SA)
Claim: I mean, we could go back and forth about that percentage. But I think the question is that today you've got a group of people who are actually able to connect around real fences of ideas, people who are able to bond together in terms of thinking about, if you were someone who is interested in a particular topic or a particular interest, your ability 20 years ago to connect with people and have a conversation about that was relatively limited. The ability for someone to do that today is incredibly increased.

And I would say that the examples of the conferences that you just mentioned are examples of part of what this generation has brought about. You look at the attendees of those conferences and those things that both of us attend you know that the large percentage of the people there are young, people who are engaged in trying to change the world and make the world a better place.

### Moderator
Claim: Let me move on to something now, to Keith Campbell's area of expertise, which is this argument about the generation being narcissistic, that this is a clinical thing.

### Conspiracy Advocate (CA)
Claim: No, I-- well--

### Moderator
Claim: Well, you finish the thought if I'm wrong.

### Conspiracy Advocate (CA)
Claim: --no, I mean, we're talking about personality trait, I mean, it--

### Moderator
Claim: Right, so you're saying that--

### Conspiracy Advocate (CA)
Claim: --I don't like to-- I mean, if-- diagnostic, it's harder to make that claim. I don't want to -

### Moderator
Claim: So what claim are you making?

### Conspiracy Advocate (CA)
Claim: The narcissistic personality.

### Moderator
Claim: So the reason I used the term "clinical" is I want to-- you didn't actually detail what that personality is. What are some of the specifics?

### Conspiracy Advocate (CA)
Claim: Well, it's having an inflated view of yourself and using relationships to regulate that. So if you're on Facebook, it's putting an attractive photo of yourself and bragging about yourself and having more Facebook connections. If it's in marriage you have a trophy spouse. So you sort of use your interpersonal relationships to bolster your self-image.

### Moderator
Claim: And that's bad.

### Conspiracy Advocate (CA)
Claim: Well, it's good for you. I mean, it works for you. It doesn't work for other people. That's the-- it's a problem.

### Moderator
Claim: seriously, you know, I think most people see it from inside. Why does it not work for other people? What's the harm

### Conspiracy Advocate (CA)
Claim: Well, when you're being manipulated by somebody as a trophy or as a prop in their own life narrative--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --it becomes problematic--

### Moderator
Claim: And just to nail it before I go to the other side you're saying that this generation is characterized by that trait, there's a--

### Conspiracy Advocate (CA)
Claim: I'm saying the levels of narcissism have gone up about half a standard deviation which is shifting a little bit.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: What happens at the extremes is that the extremes go up a lot. But the average millennial compared to the average Gen Xer on narcissism is not that different. What happens, though, is you-- when you shift everybody a little bit, the number of people at the extremes goes up a lot, and those are the ones that want to drive you crazy when you interview them for jobs--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --or go out on dates with them.

### Moderator
Claim: So let me bring that to your opponents and to you, Jessica Grose. You've already said that your generation is the victim of a lot of myths, but, you know, your opponent has studied this, takes it seriously, and definitely bears you no ill will on this.

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: So in any way honestly do you recognize your generation in that description?

### Scientific Advocate (SA)
Claim: I don't. I think it's a fundamental misunderstanding of the way we use social media. Look, everyone is trying to present their best face to the world. We just are the first to have these tools, so, yes, maybe a pretty selfie of yourself might seem to be narcissistic but I think that that's just-- that's the way we move through the world. There is-- you know, studies-- this researcher, Danah Boyd, has looked at the way that teenagers and 20-somethings deal with the Internet, and there is-- I think with older people who weren't native to it, there's more of a divide. But it's really just a fluid thing. It's a fluid thing, so you're trying to put your best face to the world virtually just as you would try to put your best face to the world in person. And I just think that it's not actual evidence of anything except these tools existing.

### Moderator
Claim: Binta, I know this wasn't your ammunition that you brought in, but what's your response to Jessica on that?

### Conspiracy Advocate (CA)
Claim: To selfies?

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Alissa don't say anything. So I don't particularly understand them. I have a derivation of the selfie. I call it the "self-bomb," which is where it is not - - the point of it is not for me to look my very best but to show that a corner of myself was somewhere. So it'll be an eye or an eyebrow or something along those lines, but--

### Moderator
Claim: You are very, very meta here.

### Conspiracy Advocate (CA)
Claim: Yeah, yeah, yeah. I mean, but, look, I think that one of the things that's missing in this conversation-- and, you know, I-- all of the hair on my back raises when I hear what I have referred to as "millennial exceptionalism," because it focuses--

### Moderator
Claim: And you think you're hearing that already from the other side?

### Conspiracy Advocate (CA)
Claim: I do.

### Moderator
Claim: All right. Define it again, "millennial exceptionalism."

### Conspiracy Advocate (CA)
Claim: In the sense that everything is going so, so great, and the problem with it isn't to say that there aren't some things that aren't going incredibly well, but--

### Scientific Advocate (SA)
Claim: I never said-- I had a whole paragraph about how we've been dealt

### Conspiracy Advocate (CA)
Claim: Hang on. Hang on. Hang on. Hang on. Our turn. Do not forget the forgotten generation. You know, I get concerned when I hear about "We're-- the greatest is we're-- we're doing this, we're doing this, we're doing that," because it means that we're not focusing on the underlying problems. And the underlying problems are the reasons why-- and narcissism is one thing, some of these other things that you hear in the media-- I think the media has done millennials a complete disservice, because they're not focusing on what the actual issues are. And because they're not focusing on them, our policymakers aren't doing what our policymakers ought to be doing in order to help them out. I'm not going to get particularly excited about things like selfies. You know, I've been in a couple of them myself. I don't think that they're particularly harmful. I think that's the kind of thing that, you know, as people age, they either grow out of or they keep doing it. But I don't think that that is the reason why millennials are going to have a harder time in the workplace.

### Moderator
Claim: Okay. David, do you want to respond to that?

### Scientific Advocate (SA)
Claim: Well, yeah.

### Moderator
Claim: David Burstein.

### Scientific Advocate (SA)
Claim: I mean, I would also add that I think when you think about this question of narcissism, the idea that people are taking pictures of themselves is not, to me-- at least-- a particularly strong case that this is a narcissistic generation. If you look at the growth of camera phones, it's a pretty realistic idea that people are going to use-- if everybody has a phone. Every phone has a camera. It's a pretty realistic assumption to I think those things are really not the best way to look at it. But when you actually look at the way that this issue has been looked at over time, the data about attitudes is much different than when you actually look at the behaviors. I think that it's hard to-- it's hard to argue that this is the most narcissistic generation when you say-- as you said, Keith-- that this generation is volunteering at higher rates. I don't know how-- I mean, making that argument--

### Moderator
Claim: Keith-- how can you--

### Moderator
Claim: --how do those two things go together?

### Conspiracy Advocate (CA)
Claim: Well, the way I'd make the argument is that volunteering for exntrinsic reasons. So, it's done for college applications, or it's done because it's a requirement in high school.

### Moderator
Claim: How do you know?

### Conspiracy Advocate (CA)
Claim: Well, because the rates go up in the first couple of years of college and then they drop-- because kids are forced to do it now. I don't like making that argument. I think-- I'd say, look, a culture volunteering, that's a good thing. I'm not going to cover it up. But yeah, it's not a hard argument to make, because if you see all the data going one direction, except for one data point, but--

### Scientific Advocate (SA)
Claim: When you look at--

### Moderator
Claim: Just before you finish your remarks-- after this I'd like to start going to audience questions. And I want to remind you, the way it'll work-- if you raise your hand, a microphone will come to you. I need you to wait until the mic reaches you so that we can record you-- this for the broadcast. If you're with the media, we would appreciate it a lot if you would identify yourself and your organization. And if you'd stand up so that the cameras can see you. And again, please keep it to a question that's on the topic. Go ahead, David Burstein.

### Scientific Advocate (SA)
Claim: I mean, I want to just sort of push back on this question of exceptionalism. I don't think this is the greatest generation that's ever lived. I think there are a lot of positive things about this generation. And I think what's really interesting is when you look at that-- and that's the study, Keith, that you've looked at-- this idea that people saying, for instance, that they want to be famous or they want to be an important person. If you ask that question-- as it's been asked over a long period of time, 30 or 40 years ago, the only way that people were famous 30 or 40 years ago were as movie stars or as singers. Today, there are a lot of people who are famous and important who aren't those things, who we know about and discuss in the public eye.

### Moderator
Claim: David, wait, but what about this point that both you and Jessica are talking about a subset of your generation?

### Scientific Advocate (SA)
Claim: Well, I wanted to--

### Scientific Advocate (SA)
Claim: --argue back against that, which is to say, you know--

### Moderator
Claim: Jessica Grose.

### Scientific Advocate (SA)
Claim: --minorities and women have historically had a harder time in America. And we're arguing millennials specifically are doomed. And actually, things are better for minorities and women than they have been in the past.

So, I just don't see how those are examples about how our generation specifically is doomed or having a hard time. Certainly those are-- the systemic problems that I mentioned in my intro, that we need to work on fixing. But as we are, racially the most diverse generation already, I think that we're particularly-- we have more global funds. We have more global contacts. We're particularly equipped to fix these systemic problems that have plagued the United States forever, you know? So I just don't think that's evidence of how we specifically are doomed.

### Moderator
Claim: And in the interest of getting to audience questions, can you respond in 30 seconds or--

### Conspiracy Advocate (CA)
Claim: I'm going to try to do this really quick. Of the 15 percent of millennials who are black-- 72 percent of those do not have four-year college degrees. 32-and-a-half percent of them are unemployed. Only 66 percent of black millennials graduated from high school. Of the 20 percent of millennials who are--

### Scientific Advocate (SA)
Claim: But how is that worse than--

### Conspiracy Advocate (CA)
Claim: Hang on.

### Scientific Advocate (SA)
Claim: --the last generation?

### Conspiracy Advocate (CA)
Claim: It is-- actually, the numbers are showing declines and that it's worsening. You have an almost permanent underclass that's being created within your generation, according to many different analysts. We can shake our heads and we can say, "No," that that's not true. But the numbers are indicating--

### Scientific Advocate (SA)
Claim: I didn't say it wasn't true. I just said it's not--

### Moderator
Claim: But Jessica-- Jessica--

### Conspiracy Advocate (CA)
Claim: But the numbers are--

### Moderator
Claim: --just let Binta

### Conspiracy Advocate (CA)
Claim: --but the numbers are indicating otherwise. With 81 percent of Hispanics, the largest cohort-- or soon to be the largest cohort-- 24.2 percent are unemployed. Same statistics, dreadful statistics.

### Moderator
Claim: Okay. We hear you--

### Conspiracy Advocate (CA)
Claim: --that are specifically affecting--

### Moderator
Claim: Let's let Jessica respond.

### Conspiracy Advocate (CA)
Claim: --this generation.

### Scientific Advocate (SA)
Claim: I just don't think that you've--

### Moderator
Claim: Jessica Grose.

### Scientific Advocate (SA)
Claim: I mean, you say, you know, statistics show it's worse. You haven't cited those statistics. I've never seen those statistics, that it's worse. I just think that that's demonstrably untrue. We see, you know--

### Moderator
Claim: There was a packet you were supposed to get in the mail. And everyone here.

Let's go to audience questions. Right there. And a microphone's coming from behind you on the right. If you can, again, tell us your name. And hold the mic about the distance from-- about a fist away from your mouth. That's great.

### Moderator
Claim: Is this-- okay. Hey, I'm Ella. This question's for Jessica. And I love your articles, by the way. Binta and Keith made a point of optimism without substance and spending without conscientiousness, and many millennials being underemployed. Social media is inundated by phrases such as "Yolo," living in a moment, making as many friends as possible. You mentioned millennials using public services because they believe in sustainability. But it's hard to believe that most millennials will turn down a free car or studio apartment. Do you have any further evidence that millennials actively want to follow truly sustainable lifestyles rather than not being able to afford it?

### Scientific Advocate (SA)
Claim: Absolutely. The most-- the millennials are the most urban generation of adults today. They are most like that they really want to live in cities. They want to live closely together. They want to live in close communities. And all of this is that-- and I don't think that they're moving away from not wanting to buy cars. I mean, part of that, yes, is financial. But part of that, if you look at the studies, is because they want to live in cities. They want to live close together. So I think that that's all evidence that shows that they have this commitment to living sustainably.

And there also is evidence that they want to spend-- when they do spend their money, they want to spend it on experiences. They don't want to spend it on cars and homes. And so that, again, is part of this sustainable lifestyle.

### Moderator
Claim: Let's hear from Keith Campbell, your opponent.

### Conspiracy Advocate (CA)
Claim: Well, I think that the car data is interesting. And I didn't know that car manufacturers are really worried about that and a lot of the shared economy. but in terms of the environmental-- and support for sustainability environment, I thought that would go up in millennials, and it's gone down dramatically from the Baby Boomers. And I thought about it for--

### Moderator
Claim: Did you say "dramatically from the baby boomers."

### Conspiracy Advocate (CA)
Claim: Dropped.

### Moderator
Claim: Since the Baby Boomers.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: And I thought about that, and I thought, well, Baby Boomers are the ones who gave us earth day, they're the ones who gave us the Clean Air Act and the clean water act. And I'm no, you know, supporter of the baby boom-- no offense to half the audience. But they really did a lot of this environmental work, the hard work that stopped Cleveland from burning and gen X and the millennials aren't doing it. So that-- we're just not seeing that in the data.

### Moderator
Claim: David?

### Scientific Advocate (SA)
Claim: Well, I mean, I would disagree on that. I mean, I think that when you look at-- you look at that-- that particular indicator, you see millennials actually engaging in behaviors particularly as it relates to spending, which I think we haven't really touched on this. But 93 percent of people in this generation say that the sole purpose of business should not be to generate profit. Now, I don't know about you, but if that is about something-- that's about, I think, a pretty big shift from where that's been in previous generations of how people feel about that. The question that businesses in our economy and our world should be about doing something more than simply trying to make as much money as possible I think is pretty powerful. You've seen a huge shift in how people spend their money. Millennials say that they will spend money if a company does positive things for the world, which largely a big part of that is in environmental. So you can't necessarily look at the same indicators over time, particularly when you think about the fact that, you know, people don't have homes, they're not going to be reducing their energy costs as much as. So I think that you have to look at this and how the attitudes have shifted and behavior that's actually moving millions and millions of dollars because millennials are actually voting with their wallets on these really important issues.

### Moderator
Claim: Okay. Let's go back to the-- ma'am, purple sweater-- jacket, sorry.

### Moderator
Claim: Hi. My name is Sadie. I am part of the younger generation of millennials. I am 16. I was born in 1998. My question is directed towards the opposition-- I mean, I'm sorry, the for.

### Moderator
Claim: --the for-- for the motion. Your question is--

### Moderator
Claim: I'm sorry.

### Moderator
Claim: I'll explain to the radio audience as well.

### Moderator
Claim: Okay.

### Moderator
Claim: So your question is for the team that's arguing that millennials don't stand a chance.

### Moderator
Claim: Yes. Do you think there's anything we can do, like as the younger generation of millennials, people that are in their later years of high school, early years of college, do you think there's anything we could do to turn the tables in our favor, or do you think we've just been dealt a bad hand, and we can't do anything about it?

### Conspiracy Advocate (CA)
Claim: Hi, Sadie. Thanks for your question.

### Moderator
Claim: Oh, it's a plant, huh?

### Conspiracy Advocate (CA)
Claim: No. I don't know her. I like millennials. I think that they're great folks. I think the millennials I know are some of the hardest working, brightest people I've ever met, but I know that they're just a subset of the population.

In terms of what you can do, I think that one of the most important things, and the thing that if it hasn't become evident to you all, that's on my mind, is that I'm worried about social exclusion, particularly when you have such a large percentage of millennials who are diverse. And I'm also worried about stress management. And these things actually go hand in hand because what the recent Pew Foundation study showed, which has been cited several times tonight by myself as well as by the other side, is that with such a large percentage of diverse people, larger than we've had in any other time, first of all, there's some people who are very, very concerned about decreasing trust in society. And trust is really important because only when we trust one another--

### Moderator
Claim: Binta, Binta, let me just interrupt you--

### Conspiracy Advocate (CA)
Claim: Sure.

### Moderator
Claim: --because her-- Sadie's question was really, is there anything that this generation can do? And if your answer is yes, then you lose the debate.

### Conspiracy Advocate (CA)
Claim: Well, no.

I don't--

I disagree.

### Moderator
Claim: Okay. You disagree.

### Conspiracy Advocate (CA)
Claim: I disagree because my purpose here tonight is not for us to be winners or losers. My purpose here tonight is to remind people as to why, as things stand today, millennials don't have a chance, right? So if you want to change that tide, which is something that we are all here responsible for doing, because we're all complicit in the mess that's been made. One of the things is by reaching out to people who aren't like you. Another of the things is protesting the teasing that occurs and cyber bullying that occurs that is affecting your generation and leading to increased suicide rates, things like that, you know, on our friend basis I think you can do. And then the last thing I would say you could do is you could urge your parents and policy makers to put in place responsible policies that will reverse the chances you have currently today.

### Moderator
Claim: Okay.

I'm going to go to another question. Do you-- okay. I'll give you the response, but I don't think it was more of a on point so much. Sir, right down in front here. Yes.

### Moderator
Claim: Hey, my name is Tom. I write for a website called Flavorwire. My question is for Keith. You seem to have written an entire book based on this premise that narcissism has risen. And the closest we got to an actual quantification of that claim was something you said about, you know, half a standard deviation or something. So I'm just interested in how you actually quantify narcissism and how you go about justifying this claim.

### Moderator
Claim: You know, can you put that-- it's-- I just would rather that-- I would prefer if you could phrase the question in a way that relates to whether we can help the audience decide whether the generation is doomed or not as opposed to challenging his credentials.

### Moderator
Claim: I'm not challenging his credentials I'm--

### Moderator
Claim: All right, challenging his

### Moderator
Claim: --as to how one quantifies narcissism.

### Moderator
Claim: So you're asking-- if you were to say, so what are the numbers that support the claim that--

### Moderator
Claim: Yes.

### Moderator
Claim: --millennials don't stand a chance.

### Moderator
Claim: I'd be fascinated to know.

### Moderator
Claim: Can you be very brief? Because we have no way to fact check everything you're going to tell us.

### Conspiracy Advocate (CA)
Claim: Oh, perfect. He can go with anything. It's a very long answer to that because the thing about narcissism is it’ssomething that affects individuals and something that exists as a cultural phenomenon. And there are different ways to quantify both. Individuals, you can look at scores on tests. There's also a giant study out of NIH looking at symptoms of narcissistic personality disorder that found people in their 20s, the lifetime rates were about 1 in 11, about 1 in 3 for people in their 60s, or 1 in 30, excuse me. So there's-- and then there's other personality data that line up with that. So there're several data sets that show that general pattern of inflating self.

### Moderator
Claim: You know what? I'm going to let you ask that question because I think it's relevant, but we need the mic to be with you again so the audience can hear it. But make it quickly.

### Moderator
Claim: What I asked, is that not something that would change over time for any generation, so somebody in a previous generation who is at the stage that millennials are at now, would they not show the same symptoms of narcissism?

### Conspiracy Advocate (CA)
Claim: Yeah. It's a really interesting question, is it's culture changing and the millennials sort of hit-- getting most of it. So with something like Facebook, well, the millennials did it more than anybody, but now, you know, my mom's on Facebook.

### Moderator
Claim: Is she putting up the best picture of herself?

### Conspiracy Advocate (CA)
Claim: Right. No.

Actually, now the millennials aren’t going to be on it pretty soon. They're going to be on Instagram. So is the whole culture change in millennials just getting the-- getting the biggest change? And I think that's probably what's going on. It's very hard to tease that apart with the data we have because most of the data we have come from college students, this historical data.

### Moderator
Claim: Right down front here. By the way, thanks for that. That was a good question. It was really Thank you for asking it.

### Moderator
Claim: Actually, it's good you picked me because this is a very similar question, although it's related, and it's for Keith as well. Like a good millennial, I'm pulling up statistics on my phone, and that was during the whole debate, and I ask this somewhat of a self-involved intention, since I'm writing my master's thesis on the subject. There are--

### Moderator
Claim: And you like to share too, don't you?

### Moderator
Claim: I do. I do.

There are a lot of studies out there that talk about how special media and Instagram activity brings envy and feelings of jealousy. And do you think this kind of competition is breeding this generation of millennial overachievers? And don't you think that's a good thing and will help millennials to succeed?

### Moderator
Claim: Another trick question. That's a good one. Keith.

### Conspiracy Advocate (CA)
Claim: There's some research saying that when you spend too much time on Facebook you get sad because you look at everybody posting their wonderful life, and you compare it to your life that isn't quite as wonderful. So there's a little bit on that. Would that help you succeed? I mean, I don't know. I think it would make you sad.

### Moderator
Claim: I'd like to get some questions for this side. Does anybody have a question for this side, and I'll vary it, man right in the center there, yeah. The mic's going to come from your right side.

### Moderator
Claim: Hi, my name's Charlotte. This is for David. I'm just curious about thinking about social media with kind of political purposes. Clay Shirky, he's a new media expert, and he wrote the book, "Here Comes Everybody," and he's interested in exploring how social media can be used for grassroots activism. And a lot of the talk tonight has been sort of about individual uses of social media for narcissistic purposes. And I'm just kind of curious as to kind of the benefits of millennial social media activity for--

### Moderator
Claim: Again, again, I find it an interesting question, but how will it help you vote at the end of the evening, your question about what the generation is doing? But you can rephrase it to that.

### Scientific Advocate (SA)
Claim: I

### Moderator
Claim: I would love to have the question from--

### Moderator
Claim: Are millennials engaging in social media activity for political ends as opposed to just narcissistic ones?

### Scientific Advocate (SA)
Claim: In a word, "Yes," and, in fact, it's actually one of the great accomplishments I think of this generation. I mean, this is a generation of people who without whom it would have been-- it's very difficult to imagine our current president in the White House. And if you want to-- regardless of how you feel about the president, that doesn't matter. I mean, this sense that this is a generation of people who said that they supported somebody and were able to organize and turn out in incredible numbers on behalf of that. So when you look at this, this is a generation that by 2020 will be a third of the electorate. And they have shown an ability to care about politics, to get engaged in politics, and not-- and it's not just particularly on candidates. I mean, you look at SOPA and PIPA and what this generation did with-- aided by technology companies, be able to work on those things. You look at the Arab Spring, internationally.

You look at all these things where this generation is uniquely positioned to organized in a way that people of other generations are not really prepared to respond to. You look at just last week, CEO of Mozilla was routed out of their job in large part by millennials who didn't agree with his stance on gay marriage. So there's a incredible advantage that millennials have when it comes to social media, particularly in political-- politics and activism, because we have an understanding of that landscape as digital natives that immigrants don't particularly understand as well.

### Moderator
Claim: You mean "immigrants" being everybody over 35.

### Moderator
Claim: Yes, exactly.

### Moderator
Claim: Yeah. I want to remind you that we are in the question and answer session of this Intelligence Squared U.S. Debate. I'm John Donvan. I have four debaters here on the stage with me, two teams of two, debating this motion, "Millennials Don't Stand A Chance.” Keith, did you want to respond to what--

### Conspiracy Advocate (CA)
Claim: Yeah, I mean, I-- social media, like fire, you can use it for good or bad. The two points I'd make sort of in opposition to that is "Kony 2011"-- what was "Kony?" the greatest movie of all time that people are now writing dissertations on. They have master’s on what they call "collectivism" or "selectivism," where people are willing to like a lot of things but don't really act. And in terms of the Obama campaign, I don't know if that was grassroots millennials doing that or if that was a bunch of Gen X behavioral economists figuring out how to manipulate millennials into voting. I mean, I think there's-- different opportunities, but that--

### Moderator
Claim: Wow, you are really assaulting the basic myth here.

### Conspiracy Advocate (CA)
Claim: I'm just saying I know some of them.

### Moderator
Claim: You know, I--

### Moderator
Claim: generation.

### Moderator
Claim: Sorry, go ahead?

### Scientific Advocate (SA)
Claim: Can I respond to that?

### Moderator
Claim: Yes, please--

### Conspiracy Advocate (CA)
Claim: I mean, I just-- sorry. I can't really let that go. I mean, I think first of all, I mean, this notion of collectivism and selectivism is one I really have to push back on.

### Moderator
Claim: All right, define it.

### Scientific Advocate (SA)
Claim: So "collectivism" is essentially this idea that all people are doing is clicking on things and they don't really care about anything. So people are liking a Facebook post and they think, "Here is this great thing I've done for the world by clicking a button on this thing, and now I've done all I have to do to care about the world for today," or, "this week," or, "this year, and now I'm going to go home," I think it's a-- I mean, people are laughing as I'm saying this, it's kind of a ridiculous idea. Sure a lot of people watched that "Kony 2012" video-- why did they watch it? People didn't think they were doing an act of heroism by watching that video, but I tell you one thing, more people in this generation know about an African warlord than previous generations knew and what he's doing and the human rights abuses he's carrying out. So I think when you think about the fact that more people in this generation have awareness about the rest of the world and the problems in the world and have some level of engagement, everything we know about human behavior and how people evolve over time suggests that if you get engaged with a global issue, have one smidge of awareness, or you donate to something when you're younger, the chances that over the long term that behavior is never going to manifest ever again, that would defy everything we know about human behavior and how people develop.

### Moderator
Claim: Binta, you look like you want to respond to this one.

### Conspiracy Advocate (CA)
Claim: I mean, KONY is such a funny example, because aside from the fact that--

### Moderator
Claim: Again, remind listeners and audience members what KONY was.

### Conspiracy Advocate (CA)
Claim: You know, I don't remember all the--

### Moderator
Claim: All right. I will.

### Conspiracy Advocate (CA)
Claim: --details.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Do you want to?

### Moderator
Claim: Yeah. Kony was a film made by some American activists who had gone out--

### Conspiracy Advocate (CA)
Claim: A non-profit.

### Moderator
Claim: --a non-profit who had gone out and been upset by a years-long ravaging of the countryside in Uganda, correct?

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: And by a warlord. And he went and made a film about in 2011, 2012, in April, and put it up online. And it caused-- an announced there was going to be a day of action. And it caused an enormous stir among primarily younger generations, including my 10-year- old daughter, which is why I know about it. They were talking about it at breakfast. They were talking about it at dinner. They were outraged. They-- and it's true. They had never paid any attention whatsoever to Africa. And then the day came. And it was a little bit of a bust, partly because of a little bit of some personal problems with the director--

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: --of the film.

### Conspiracy Advocate (CA)
Claim: I mean, the day was a bit of a bust, in part, of his personal issues. But it was also a bit of a bust because the issue had largely resolved itself before the video came out. And it was also a bust because there was a very large percentage of people in Uganda and throughout the African continent who were extraordinarily offended by that video. You know, it was a video that was done without having a lot of close interaction. I mean, we talk about, you know, social media and technology and the different ways of

### Moderator
Claim: So, that goes to naivete.

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: I think you're saying--

### Moderator
Claim: --of the millennial generation.

### Scientific Advocate (SA)
Claim: --of one social media work to actually make change in this country?

### Moderator
Claim: Yes. But what you address you do-- the question-- the point that Binta made, that there was a naivete--

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: --in your generation--

### Scientific Advocate (SA)
Claim: But I think that--

### Moderator
Claim: --of optimism--

### Scientific Advocate (SA)
Claim: --you know, in the sixties, I think there was a great naivete in a lot of the activists that were-- I mean--

### Moderator
Claim: Well--

### Scientific Advocate (SA)
Claim: --these activists are

### Moderator
Claim: --well-landed. Jessica Grose.

### Scientific Advocate (SA)
Claim: Youth activists are often deeply naïve. I mean, so, the two examples off the top of my head. One was when Susan G. Komen For The Cure, the breast cancer organization, stopped-- went against Planned Parenthood and wasn't giving money to Planned Parenthood anymore. There was a huge uproar. And it basically-- I mean, the CEO was ousted. It completely ruined the-- it didn't ruin the organization. But it gave them a really hard time. And it got a lot more people aware. And not just of breast cancer-- which it did. But also about Planned Parenthood and the work it does. And another-- I write a lot about women's issues. So, the other thing was Wendy Davis and her stand in Texas, and how quickly that circulated around the Internet and made people aware of the issues about abortion rights in Texas. And then a swarm of mostly millennial women stormed the Texas statehouse because they were so-- ultimately it didn't work out, you know? The elected officials in Texas are largely Republican, and they did end up passing that anti-choice bill.

But still, like, there was just this ground swell of support and activism that did not just raise awareness, but I think could be argued, made change. So, I think it's not just clicking on something. People are getting enraged and making action and voting, you know? Young women really care about these issues, and they are constantly aware of them.

### Moderator
Claim: Do we have any questions? And I mean this sincerely, because I haven't seen any hands go up-- of anyone over the age of 35? Thank you. Do not be afraid. Thank you.

### Moderator
Claim: I remember Angela Davis, and she made a great difference. This is for David, who started to explain it-- your generation came into one of the greatest recessions that the United States has ever faced. And when I was invited here tonight, I was asked-- I asked whether this was an internal or external debate, whether we were talking about sociological problems--

### Moderator
Claim: Sir, just in the interest of time, I need you to zero in on your question.

### Moderator
Claim: Okay. So, what generation of Americans got dealt a worse hand than the Millennials? In World War II, we fought together. And that bonded us together and we--

### Moderator
Claim: But is that your question?

### Moderator
Claim: Yeah.

### Moderator
Claim: What generation--

### Moderator
Claim: What-- if we're talk-- we're dividing society into generations, what generation got dealt a worse hand than you?

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: The labor movement is dead. The greatest transfer of wealth in the United States has happened since 1980 upward to the--

### Moderator
Claim: Okay. All right. That sounds like the answer. David, why don't you answer the question?

### Scientific Advocate (SA)
Claim: Well, I mean--

### Moderator
Claim: David Burstein.

### Scientific Advocate (SA)
Claim: --the-- a big part of that is the generation that went through the Great Depression. I mean, the fact that those people, through that period of time, there was a sense-- people had no idea when the Depression might end. You look at the reality of that. My grandmother still thinks that when I call long-distance, it's expensive. And so, urges me to hang up as quickly as possible. So, I think that there is a long-lasting impact there which, interestingly, you're not seeing among millennials, right?

So this idea that-- that we have had this-- this goes to back to what we were talking about earlier-- this sense of resilience I think is really, really important. So there have been-- you know,-- that generation was certainly, in recent history, in this century, I would say that generation was certainly in recent history.

### Moderator
Claim: David, there's one part of your argument-- of your answer there, and it's come up a few times, is that I don't feel you've ever truly addressed Binta's point that while your optimism is real and is authentic, that it's happened again and again and again in time. And that in time that optimism burns out. And you, I believe, are arguing-- and Jessica - - are arguing that, no, it's different with us this time. Are you actually arguing that?

### Scientific Advocate (SA)
Claim: I'm not arguing that.

### Moderator
Claim: You're not.

### Scientific Advocate (SA)
Claim: I'm just arguing that we're not-- the proposition is that we're doomed. I don't think we're doomed. I don't think that we're anything special, but it's just, you know, we have a lot of skills. And one that we haven't talked about before is that we are native to the technology, which is is to use a lame Silicone Valley word, "Disrupting" the world.

And we understand those technologies much more deeply than the older generations, and we are able to harness those technologies. And I think that's that not even been addressed.

### Moderator
Claim: Binta, you think that's not true?

### Conspiracy Advocate (CA)
Claim: I think that that's so unfair. I mean, generation X was known as the computer generation. It is also known as the digital generation. When I was 12 years old, I was playing on things called "bulletin boards" which was an early version of the internet. I wrote my senior thesis in 1995 on the internet and all of the different ways it's going to change society.

### Scientific Advocate (SA)
Claim: We're not talking about internet use.

### Conspiracy Advocate (CA)
Claim: Well, hang on-- hang on. Hang on. The companies that you're talking about that make you digital natives, right, were all founded by, for the most part, with the exception of Facebook, were by and large founded by people in generation X. It's simply inaccurate every time somebody says that the millennial generation is the only generation--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --that gets to

### Moderator
Claim: I'm interested in David's outburst. When you said we're not talking about internet use, what are you talking about?

### Scientific Advocate (SA)
Claim: I mean, the question-- I alluded to this earlier, this question of nativism versus immigrantism, right?

So this idea that you-- if you understand a technology-- enabling in your upbringing, that it actually positions you over the long term to use it more effectively, not just to create companies. That's just a piece of it. And, you know, yes, Facebook, Google, you know, Twitter are big companies, and some of the founders of Twitter-- there's a long debate on who actually founded Twitter-- were people who were-- who were millennials. And you also look at the people who are the kinds of companies that are coming out today, whether it's a company--

### Moderator
Claim: So why does that make it different? Why does that--

### Scientific Advocate (SA)
Claim: Well, I would say there's been a democratization of technology. That--

### Conspiracy Advocate (CA)
Claim: That's true.

### Scientific Advocate (SA)
Claim: The majority of millennials grew up with it whereas, gen X, it was a very privileged thing for them to grow up and have, you know, internet in the home. Like the numbers have just skyrocketed.so I think it's different in that way.

### Scientific Advocate (SA)
Claim: 98 percent of people in this generation have regular access to the internet.

### Moderator
Claim: Okay, Binta.

### Conspiracy Advocate (CA)
Claim: Okay. So when you create something, I would submit to you that you have a pretty good understanding as to how to use it.

And at the same time that your generation was becoming used to using these technologies, older generations have also become used to using these technologies. Now, the boomers, maybe they were a little bit slower, and the greatest generation-- I mean, I don't know what they do. But they're silent. They're silent, right? But I just think that it's a little bit misleading, right? There's a difference between-- you know, we oftentimes talk about millennials and being digital savvy. Having the ability to make a Facebook post or to take a selfie or to SnapChat or to engage on whatsapp is not digital savvy. Having the ability to create the button is digital savvy.

### Scientific Advocate (SA)
Claim: Right. And more of them know how to code than people in generation X.

### Conspiracy Advocate (CA)
Claim: I'm not sure that that's actually accurate.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate.

## Round 3

### Moderator
Claim: --where our motion is "millennials don't stand a chance.” And now we move on to round three. Round three are brief closing statements from each debater in turn to summarize their positions.

They will be two minutes each. The motion is "millennials don't stand a chance.” And here to summarize his position in support of the motion, to say that millennials don't stand a chance, W. Keith Campbell. He is professor of psychology at the University of Georgia and author of "The Narcissism Epidemic."

### Conspiracy Advocate (CA)
Claim: Thank you. I don't have any prepared remarks here. I'm just going to wing it based on the last conversation.

### Conspiracy Advocate (CA)
Claim: Like a millennial.

### Conspiracy Advocate (CA)
Claim: And-- like a millennial. No. That's-- Don't even have millennial jokes. So often what I-- often when I think about things, I think, what do I tell my students, and what do I want for my children who are going to be the next generation? And I'm scared. I mean, I'm scared for the future they have maybe because I lack optimism or maybe because I'm realistic. I don't know. You can decide. I tell my students, figure out something to do that they can't do in China and that a robot or AI won't be able to do in five or ten years, because that's what's going to happen to a lot of the jobs.

I tell my-- grad students to learn how to code, to learn really sophisticated statistics so they can maybe get a job because they're the only one who can do it, and so they're not underemployed in the service industry. And I hope to God my daughter becomes a physician so, you know, if things get really bad, they'll keep her alive to care for the young. So I-- So I think I'm truly negative about things. Does that mean it can't change? Well, maybe. But it should have changed. We've had eight years of collapse. People should have done something. And what we decided to do is give a whole lot of money to bankers, which is great for New York when I looked around. But we haven't done anything so far. And so to me, that doesn't sound like we're going to do anything in the future. You have my time.

Thank you. I don't have any prepared remarks here. I'm just going to wing it based on the last conversation.

### Moderator
Claim: Thank you, Keith Campbell.

Our motion is "millennials don't stand a chance.” And here to summarize her position against the motion, Jessica Grose. She's a contributor to Bloomberg Business Week and Slate, and she's author of the novel "Sad Desk Salad.” Ladies and gentlemen, Jessica Grose.

### Scientific Advocate (SA)
Claim: So the people on this panel all seem to have very short historical memories. We don't seem to have discussed anything before 1930, so I'd like to do that now. If you looked at income inequality in the gilded age, in the late 19th century and the early-- and the turn of the century, it was even worse than it is now. Opportunity-- class movement was even lower than it is now. Poverty was endemic, and it was much-- it is worse than it is now. And I am sure there are newspaper columnists writing in 1870 that the gen-- the millennial, the horse millennials, or whatever they were calling the buggy riders, whatever they were calling them in 1870, were uniquely doomed. So I just think that a lot of the way we frame millennials is based on a period of prosperity in the '60s, which was, in and of itself, the anomaly in American history.

And that's when we talk about marriage, when we talk about children, the age at first marriage in the 1910s and 1920s was in the late-- was, you know, 28 or 29. It was similar to how it is today. So I think we have this warped perspective of, you know, what's facing millennials and how we can-- and then how we can face those problems.

We are a fine generation. We are as fine a generation as a group of 20 million people can be compared to an aggregate of 20 million other people. So I would really urge you to urge against the idea that we are specifically doomed, especially when compared to the generations, centuries of generations that have come before us.

### Moderator
Claim: Thank you, Jessica Grose.

Our motion is "millennials don't stand a chance.” and here to summarize her position supporting this motion, Binta Niambi Brown. She is a corporate tech lawyer, startup adviser and human rights advocate.

### Conspiracy Advocate (CA)
Claim: So I have a confession to make. Last night while I was watching a video on my iPad and exchanging texts with mentees, friends and my mother, and doing some work for a startup I advise, and preparing for this evening, I took the Pew Foundation, "Are you a millennial?" quiz. And I scored an 80, which means that I share more traits with the millennials, actually, than with my own generation, the forgotten generation, the X'ers. I'm not surprised by this. I spend a lot of time with millennials. My parents are Baby Boomers. And I really, really like my parents a lot. So it may seem like tonight I'm arguing against myself, except that I'm not because of the accident of my birth. The fact that I was born 8 to 15 years before the beginning of the millennial generation means that the kinds of reckless policies that have been delimiting life chances for millennials today have not taken root and have not had a substantial impact on my prospective outcome. Things for millennials are not good.

We've let this generation down. We've handed them a bad deal. It's because of our shortsightedness that we have a world with a number of structural and systemic problems that dramatically decrease the likelihood of their life chances. Our education system is failing, our entitlement system is broken. It's hard for them to find engaging work in order for them to become full economic participants. There is increasing distrust and the-- amongst the millennial generation, amongst different groups of people, contrary to what we've heard tonight. And so I'm asking you all tonight not to vote for us because we need to win, because in a sense, we already have. We were born before they were into a world where we had greater opportunity. I'm asking you to vote for us because to do so is a tacit recognition that a problem does in fact exist. And unless we recognize that a problem exists, we cannot solve it. And what I would like to see is for some of these infrastructural and structural problems to be addressed and resolved. So vote for the proposition, not that millennials are doomed, but that they do not have a chance as things stand today.

### Moderator
Claim: Thank you, Binta Brown. And that's our motion, "Millennials Don't Stand A Chance.” And here to summarize his position against this motion, David Burstein. He's author of "Fast Future, How the Millennial Generation is Shaping Our World.” And he is the founder of Generation 18. David Burstein.

### Scientific Advocate (SA)
Claim: So for most of our history, it has been older people who understood the world and where the world was headed better than younger people. And when we talk about young people, in this case we're talking about millennials, what we're really talking about is the future. And if you look at the past decade of our world and the amount of change that has taken place, yes, the world is always changing, but if you look particularly at the last 10 years and the accelerated pace of change, that is the comfort zone for this generation. And that pace of change, that increased constant disruption, constant need to adapt to new ideas, new technologies, new platforms, new ways of doing things in our society, that is where this generation is not only comfortable but truly excels.

So, in fact, young people and millennials at this time understand more about what is going to happen in our world than anyone else does. And we are actually leading the charge on a number of those different things. So when Binta says that we are-- what's going to happen, this generation is already stepping up to lead, we're entrepreneurs, we're innovators, there are people in this generation who are shaping the context and the reality of the world of everyone in this room and everyone on this planet. So to say that millennials don't stand a chance, I think, in fact, millennials not only stand a chance but have an incredible advantage. As we look at what's going to happen in the next 20, 40 years, this is historically the generations of people who are younger, who understand the future, who understand where things are headed, who see an opportunity and move it forward, are able to do service not only for themselves but to the entire-- their entire generation and people of all generations. So I think that this generation has incredible promise, we're not the greatest generation that ever lived, but we certainly stand a very good chance. So I'd urge you all to vote against the resolution.

### Moderator
Claim: Thank you, David Burstein. And that concludes our closing statements. And now it's time to learn which side has argued the best in the opinion of our live audience. We're going to ask you again to go to the keypad at your seat and register your vote, the second vote. We'll get the readout almost instantaneously. The motion is "Millennials Don't Stand A Chance.” Push number one if you're for the motion, two if you are against the motion, and three if you became or remain undecided. Again, it's the team whose numbers have changed the most between the first and the second vote who will be declared our winner. And as that is happening, I would like to actually-- I would like to congratulate the debaters on this stage for-- number one, it takes a lot of guts to come up here and debate. It’s a scary thing, and they all did it, and they all faced up to it. Number two, they did it in such a respectful manner, something that could have become nasty, childish, and ridiculous was actually high-toned, informative, and respectful, so our congratulations to all. A few things, we want to-- love to have you Tweet about this debate. And you can do that with our selfie mirror-- in the lobby. You can-- if you're over the age of 35, everyone else will explain it to you. But there's a pink-framed mirror, you take a picture of yourself, and that's a selfie, and isn't that cool. But if you do it-- Tweet it to us at iq2us, and use the hashtag "Millennials.” Our next debate will be May 7. It will be right here at the Kauffman Music Center. The motion is "Death is Not Final.” And what we're looking at on this one, we're looking at whether the prospect of existence after death is a thing that is real and provable by science or it's a construct of wishful thinking.

And for the motion we actually have somebody who's been arguing about this a lot, Dr. Eben Alexander. He's a neurosurgeon who had a near-death experience during a weeklong coma, but he says it changed his understanding of how the brain works. And he's written about that, and it's fascinating. And it's really why we decided to take on this debate. His partner is Dr. Raymond Moody. He's a psychologist, a medical doctor, and a leading authority on near-death experience. He actually coined that phrase in the '70s. Against the motion, against them, Sean Carroll is a Cal Tech physicist, and he says that believing in life after death requires physics beyond the standard model. And his partner is Dr. Steven Novella, a neurologist at the Yale School of Medicine. And he's host of the popular weekly science podcasts, "The Skeptic's Guide to the Universe.” Tickets to that are available at our website. We still have some. And the website is www.IQ2US.org. And I've already mentioned this a few times, but we're being live- streamed on Fora.tv. You can always watch that live stream and listen to our debates on NPR stations across the nation.

All right. So, I have the results all in. Remember, you voted twice on this motion: Millennials Don't Stand a Chance. The team whose numbers changed the most between the first and the second vote will be declared our winner. Let's look at the results from the first of the two votes. In the first vote, "Millennials don't stand a chance," 18 percent of you agreed with this. 47 percent were against. 35 percent were undecided. Those are the first results. We compare the second round of results now. And the team whose numbers have changed the most will be our winner. The second round. In the second round, the team arguing for the motion-- their vote was 38 percent. That's 18 to 38 percent. That's a gain of 20 percentage points. That's the number to beat. Let's look at the team against the motion. Their first vote was 47 percent. The second vote, 52 percent. That's only five percentage points, not enough to win. Victory goes to the side arguing for the motion: Millennials Don't Stand a Chance. Our congratulations to them and thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
