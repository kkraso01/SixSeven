# Debate Transcript

Topic: Obama's Economic Policies Are Working Effectively
Motion: Obama's Economic Policies Are Working Effectively

Debate ID: obama-economic


## Round 1

### Moderator
Claim: We are starting and I would like to welcome our debaters onto the stage. Thank you for that warm welcome to our debaters and I’d like to also ask for a warm welcome for the chairman and founder of Intelligence Squared US, Robert Rosenkranz.

### Moderator
Claim: Well, thank you all very much for joining us tonight, you know, the mission of Intelligence Squared, is to encourage our audience to consider both sides of contentious issues. To think twice about their positions. So one of our panelists tonight, former Governor Eliot Spitzer, has certainly done that. Just last week he thought twice about arguing in favor of tonight’s motion, and “Obama’s Economic Polices Are Working Effectively” decided to argue against it. When Obama took office, the financial sector had just been saved from collapse by massive government intervention. That collapse occurred against the backdrop of a relatively benign real economy, with decent growth and high employment. Then in the fourth quarter of ’08 and the first quarter of ’09, the real economy went into free fall. Economic output shrank, and unemployment rose at rates that we haven’t seen since the Great Depression. The collapse of the real economy could’ve been a death blow for an already weak financial sector. We were truly on the edge of an economic abyss, and fear itself was becoming a real self-fulfilling prophecy. Well the Obama administration threw every policy weapon it could at the problem. Zero interest rates, increased money supply, backstops for key financial institutions in the entire automotive industry, and a massive fiscal stimulus package. And confidence has clearly been restored. Businesses are building inventories, consumers are spending, investors are no longer hoarding cash. The stock market is up 19 percent since the beginning of the year, and corporate bonds are up nearly as much. Last quarter, we had 3.5 percent growth in the economy. It seems that the recession is over, and that Armageddon has been avoided. Is this not a picture of unalloyed success? Well, not so fast. Unemployment has increased to 10.5 percent. We bailed out the banks so that they could provide “Obama’s Economic Polices Are Working Effectively” credit to businesses and consumers, and instead they’re shrinking the loan portfolios. Government deficits are running in the trillions. Public debt has exploded, and the dollar is collapsing. We may eventually face a stark choice, between default, and inflation. And the private sector, the engine that has powered America’s economic dynamism, is facing the burden of higher tax rates, higher health care costs, carbon taxes, pro- union initiatives, pay czars and other intrusive regulation. With such powerful anti-growth forces in play, can we expect new jobs to put unemployed Americans back to work? Well, I’m not going to be the one to answer that question, but I will make a prediction. That tonight’s debate will be lively and informative, and it’s my pleasure to turn the evening over to John Donvan, and the outstanding panelists we have with us this evening.

### Moderator
Claim: Thank you, Robert. Andmay I just invite one more round of applause for Robert Rosenkranz. Well, welcome, everybody, to another debate from Intelligence Squared US, I’m John Donvan of ABC News and once again it is my pleasure to serve as host and moderator, as the six debaters you see sharing the stage here with me at the Skirball Center for the Performing Arts at New York University, three against three, will be debating this motion, “Obama’s Economic Policies Are Working Effectively.” Now, I want to point out this is a debate, “Obama’s Economic Polices Are Working Effectively” it’s a contest and although we have some professors on the panels they are not here to lecture, they are here to attack and defend but with ideas well-articulated and well-argued, and in this debate, you our live audience here at the Skirball Center, act as the judges. By the time the evening has ended, you will have voted twice, once before the debate begins and once again at the end, to tell us whether you agree or disagree with the motion. And at the end of the debate the team that has changed the most minds, will be declared our winner. Now, it is time to vote our preliminary vote, and if you go to the keypad on your left side…there’s a range of buttons from 1 to 10. Ignore all of them but 1, 2 and 3. If you push number 1 it means that you agree with the motion that “Obama’s Economic Policies Are Working Effectively.” Number 2 means that you disagree, and number 3 means that you’re undecided. And if you feel that you’ve pushed the buttons incorrectly, just repeat the correct entry and it will update to the current one. So it looks like everybody’s done that. And so our preliminary vote is in and let’s let the debate begin, Round 1, opening statements by each debater, seven minutes each. We begin with Mark Zandi who is an economist and the founder of Moody’s Economy.com. During the 2008 Presidential campaign he was an advisor to Senator John McCain, he has since become an advisor to the Obama White House, Mark, I’m not sure what that tells us about which side you’re on… “Obama’s Economic Polices Are Working Effectively” but the floor is yours—

### Conspiracy Advocate (CA)
Claim: I’m an ecumenical economist, let’s put it that way. I want to thank Intelligence Squared for the opportunity to be here today, it’s certainly an honor to be here and to address such an important topic. I’m going to make three points in my opening remarks. Point number one. I think it’s really quite amazing the totality of the policy response from the administration, I think, we forget all the things that have been done to try to shore up the economy and we tend to focus on the one or two or three things that we’re most annoyed about, and we focus on that. Let me just spend a few minutes, well, I’ve got six minutes and 30 seconds, let me spend a couple minutes going over that. And there are three broad areas of policy effort here, first is the effort to shore up to the financial system, and this is everything from what the FDIC has done, increasing deposit insurance limits, to guaranteeing bank debt to allow the banks to issue to efforts by the Treasury to help facilitate all the things that the Federal Reserve Board has been doing to try to provide credit to the financial system and stabilize the financial system. Perhaps the most important thing in my mind with regard to the effort to shore up the financial system, was the banks’ stress tests--do you remember the stress test, this was done back earlier this year. And to me, those stress tests were the modern-day “Obama’s Economic Polices Are Working Effectively” equivalent of what FDR did back in the Great Depression, he— I’m going to exaggerate just a little bit but only a little bit. He closed all the banks on a Friday and he said on the subsequent Monday to his Treasury Secretary, open all of them except a couple hundred of them and the Treasury Secretary said to him, well, which ones should I open, and FDR said, well, it really doesn’t matter because the ones you open, everything will think are safe, and life will go on and— In fact it worked, it restored confidence and that was the beginning of the end of the Great Depression and the stress test in fact did that, it restored confidence and the financial system is stable. The second blotter of the policy response was to shore up the two weakest parts of our economy, the housing market and the auto market. I’m not going to spend much time on the auto market because Steve is so intimately involved in that great effort, and he’ll talk about that, but I know housing, and the efforts to shore up the housing market have been quite amazing, and just to name a few things. The first-time homebuyer tax credit, very important in stabilizing housing values this summer, to help to support buying by first-time home buyers, the loan modification plan to help homeowners who are facing foreclosure, to get their monthly mortgage payments down so that they can afford their, their mortgage payment. Efforts to provide more credit to the residential mortgage market through Fannie Mae and Freddie “Obama’s Economic Polices Are Working Effectively” Mac and FHA. Here’s a statistic for you. 90 percent of all the residential mortgage loans being made today are being made by the federal government, so if the federal government wasn’t making those loans, the housing market would be in complete disarray and we’d be in very significant trouble, so the second broad policy effort was to help shore up those two key sectors, the two weakest sectors of our economy. And the third policy response, broadly speaking, is the fiscal stimulus, much maligned, but ultimately at the end of the day, very successful. I don’t think it’s any accident that the recession came to an end, at the same time that the stimulus was providing its maximum economic benefit to the economy. And the stimulus is lots of things, it’s aid to unemployed workers, it’s helped the state governments, it’s the first-time homebuyer tax credit, it’s Cash for Clunkers, a long list of things, the infrastructure spending, all very important. So, please remember, point number one, that the policy effort is a range of many things, it’s been incredibly— it’s amassing and incredibly unprecedented what has been done here, and key to bringing an end to this Great Recession. Point number two, here are the statistics I think are overwhelming. A year ago, think about a year ago, what was going on, major financial institutions were evaporating or being nationalized, Fannie Mae, Freddie Mac, Lehman, Bear, AIG, Citigroup was on the doorstep of falling apart, and look at the situation today. “Obama’s Economic Polices Are Working Effectively” The financial system is not normal, no, but it is stable. And banks aren’t lending to us yet as business people and as consumers but they’re moving in that direction, and just imagine where we’d be today without that stability in the financial system. Think about the economic statistics, housing activity, new and existing single-family housing starts hit a low in January, housing construction hit a low in January, back at the beginning of the year, housing values were falling very rapidly, today, the last couple of quarters they’ve actually begun to increase. GDP, the value of all the things that we produce as an economy, grew 3.5 percent in the third quarter and the growth was very broad- based, that was the first substantive growth in over a year and a half. And clearly driving the economy forward, the GDP in the fourth quarter, the current quarter, is on track to be positive again. The job market. Last thing to improve, but it is improving, we’re moving in the right direction. We—just to give you a statistic, at the beginning of the year, we were losing 700,000 jobs on average every single month. In the last three months we lost 200,000 jobs a month, now I know, that’s a lot of jobs, unemployment is still rising. But the trend lines are right, they’re moving in the right direction and my view is by early next year, we will have a stable job market, and by the end of next year, we will have job growth that’s meaningful enough to bring down the rate of unemployment, so everything is moving in the “Obama’s Economic Polices Are Working Effectively” right direction. Finally, point number three, I said there were three points… The proposition is, “Obama’s Economic Policies Are Working Effectively.” It’s not, they have worked. This is not a mission accomplished, no one is arguing that this is over and done with, we have more work to do, and the administration is still working. Just last week, they passed another piece of legislation to help extend unemployment insurance benefits for people who lose their jobs in 2009, now if you become unemployed in 2009 you have 99 weeks of unemployment insurance benefits, they extended, and they expanded the first- time homebuyer tax credit into next year to provide support to the housing market, and they’ve provided a number of other supports. They are debating right now and will likely pass other efforts to shore up the economy, extend some of the other provisions in the stimulus to make sure that the stimulus provides benefit to the economy as we make our way into 2010. And more importantly and perhaps most importantly, we are working through some of the structural problems in our economy, working on the hard, difficult issues, the most obvious would be financial regulatory reform. Now this is something you don’t want to do quickly, you don’t want to make a mistake. Our financial regulatory structure has been in place since the Great Depression. It feels like it, and we have got to take time to make it right. So, in my view, what the administration has done has “Obama’s Economic Polices Are Working Effectively” been highly successful.

### Moderator
Claim: Thank you, Mark Zandi. And I just want to point out the amazing virtuosity of Mark Zandi who was watching the clock the whole time, and he said “Thank you” as the clock that’s in front of us you can’t see, turned to zero. It’s just about perfect. Our motion is “Obama’s Economic Policies Are Working Effectively” and our first debater to argue against the motion, James Galbraith of the University of Texas, he generally argues from the left, he also has a rather scathing view of economists in the United States in general, he has said that, on all important policy issues, they are on the wrong side, himself an economist, James Galbraith.

### Scientific Advocate (SA)
Claim: Thank you very much. The question before the house may appear political. But it in fact is not. One person on our panel as you’ve heard, shifted his position to argue our side. Two of us, supported President Obama in the last election and all three of us hope that he will succeed. The question is about the economy, it is about whether the economic program is working effectively. Lawrence Summers, the Chief Economic Advisor to the President, told the Washington Post on November 8th, quote, “I “Obama’s Economic Polices Are Working Effectively” think we got the Recovery Act right. The primary objective of our policy is having more work done, more product produced, and more people earning more income.” We agree with that standard. The economy is not performing up to that standard. Basically, if you leave aside the actions some of which Mark mentioned such as the extension of deposit insurance by the FDIC, that were taken under the Bush administration, the Obama economic program…the principal points are two. One is the Recovery Act, the stimulus bill, and the other is the policy of providing free reserves, credit at zero interest rate, to the banking system in the hopes that credit will flow again. So the question before us is, was the stimulus sufficient, and secondly, is credit flowing again. Now the stimulus did some good things, it helped forestall the complete collapse of budgets in the state and local government sector, it created some construction jobs and will create more. It has provided some tax relief. The question is, is it enough. I think it is pretty clear, that it was not enough. The stimulus was enacted based on a forecast that unemployment would not rise past about 8 percent by the middle of this year, would decline thereafter, that forecast was clearly wildly optimistic. It underestimated the state and local crisis where job cuts, or, just offsetting, the jobs created with federal funds. It did too little too late to meet the foreclosure crisis which is presently running at several million homes a year. Let me quote a distinguished “Obama’s Economic Polices Are Working Effectively” economist. On November 6th, 2009, he wrote, “After rising for more than two and a half years the country’s unemployment rate crossed into double-digit territory in October, with a jobless rate of 10.2 percent. This provides another sign of the severity of the current downturn, the very long road we face back to full employment, and the urgent need for more policy action to create jobs and protect those who can’t find work. With such a huge fire, we need every hose we can find to put it out.” I agree with that. There is an urgent need for more policy action. Who said it? Why, Larry Mishel, President of the Economic Policy Institute said it just 10 days ago. What you said… if you say this, that you also agree with Larry Summers, that the Recovery Act got it right. Now I am not an economic forecaster. But there are forecasters I greatly respect, and here is what one of them testified to Congress, on October 29th. “It is growing clear,” he said, “that more policy help will be needed to ensure that the tentative recovery evolves into a self-sustaining expansion. Although a double-dip downturn is less than likely, meaningful threats to the recovery still exist. Most notable, are the intensifying stresses in the job market, the ongoing foreclosure crisis, the boom and bust in the commercial real estate market the dysfunctional structured finance market and the fiscal woes of state and local governments.” Quite an impressive list and I hesitate to say this in a theater but it “Obama’s Economic Polices Are Working Effectively” sounds like other than that, Mrs. Lincoln, how did you enjoy the play. To go on, “Congress must provide more resources to unemployed workers, whose benefits are running out, to state and local governments unable to balance their budgets and to household and businesses looking to buy homes and invest.” I agree with that. Congress must provide more resources. Who said it. Why, Mark Zandi said it, founder of Moody’s Economy.com, just two weeks ago. Would you say this, if you agreed with Larry Summers, that the Recovery Act got it right. Now it’s true, free money has saved the banks, everyone knows this, from their profit reports and their bonuses. The stock market has come back and so has the price of oil. Is this enough? We think not. We think the housing crisis is important, we think the collapse of small business is important, we think 10 percent unemployment as far as the eye can see is a disaster. We know as every business in America knows that credit is not flowing again. What would a working program look like. First it would dissolve rather than coddle the toxic banks. It would stop the displacement of people from their homes, not just slow it, not just help a few, but stop the displacement of people from their homes. It would help all their workers who are ready to leave their jobs, to retire by providing them with a more comfortable employment, and health care that they can count on at an earlier age than 65, opening up places for younger people who are “Obama’s Economic Polices Are Working Effectively” looking for jobs in today’s catastrophic labor market. And it would fund a lot of new green jobs, all across the country, providing every American who wants a chance to work, for the duration, until the private sector comes back, revives and is able to take up the slack. On our side, we don’t agree, on all of the issues. But on the issues just outlined and I submit they are the essential issues, the facts are plain. Better than nothing is not good enough. There was a poll…released just a few days ago on November 6th, which stated that 47 percent of Americans think that the economy is still the most important issue, that’s against all the other issues that might be considered. The American people know what this is about. They do not think that the program is working effectively, and that is surely telling. If it were working effectively, they would know. Thank you very much.

### Moderator
Claim: Well….we just had another one of those one-second accomplishments. Next to argue for the motion, we asked the White House if they would provide a member of the administration to take part in the debate, they did not want to do that, but they suggested our next debater, Larry Mishel who is the president of the Economic Policy Institute, so Larry—I’m not saying you’re the White House’s guy. But, now everybody’s going “Obama’s Economic Polices Are Working Effectively” to think of you that way as as you get up, but the floor is yours.

### Conspiracy Advocate (CA)
Claim: Well, I hope I get invited to the next official state dinner then— You know, as an economist, over my career I’ve been focused on what are the living standards of the American people, the working class. How they’ve done, and so what has mattered to me most on economic policy, is in fact, what have we done to create jobs, to get the unemployment rate down. And so I’m going to focus on the Recovery Act. And I’m here to say that I think it has actually been a bold and effective act. No, it has not solved all our economic problems. It has not solved the unemployment problem. That is not quite the standard that you should imagine, for judging whether the policies are effective. Let me just say—my imagery for all this. President Obama inherited a really large apartment building, it was all aflame, afire. He gathered all the fire trucks and hoses he could, and he put out the flames, in at least half the floors. But the critics say, look, there’s still fire and so your policies must be wrong. And especially, it turns out, these critics are the conservatives who actually lit the darn fire. And they tried to keep the fire hoses from actually getting to the fire building. I think it’s actually quite outrageous. Now it’s a somewhat different— I think it’s somewhat different to my “Obama’s Economic Polices Are Working Effectively” longtime, I don’t have any old friends, only have longtime friends, Jamie Galbraith. But we’ll get around to that. So let me talk at first about what the fire was. Mark talked about it. Over the nine months that included the last half of 2008 and the first three months of 2009, none of which were the responsibility of President Obama, okay, we had the fastest decline in the economy, basically since they started collecting the data in 1947 on a quarterly basis. We had already seen six million jobs lost by March 2009. The unemployment rate was already 8.5 percent, which is the highest it was since the great, really deep recession of the early 1980s. So we were in deep…you know what. And so we had the Recovery Act which was passed very quickly and effectively, actually started having some effect in March, but mostly started having an effect in April. And I want to go through exactly what it does, so it’s not an abstraction. What are the different components. First as Mark mentioned, support to the unemployed, and helping them not only with unemployment benefits and higher benefits, extended benefits, and health care, and a major increase in food stamps. Why does that matter. By supporting their incomes and their spending it creates jobs, throughout the economy. Secondly. There was a major influx of money to state governments, who, by resolving their own deficits when they have to cut programs and raise taxes, they actually--what Paul Krugman said is they are “Obama’s Economic Polices Are Working Effectively” like 50 little Herbert Hoovers. They are driving us into recession, by actually exacerbating the problem. Okay. When you give them the money, they don’t cut the programs, they keep the people that work for them in the local government’s employ. To keep the contractors and the private sector delivering construction contracts, health care, nursing homes, et cetera, employed, and by all those people being employed through spending money they keep jobs going throughout the economy. Okay, there’s also a third, a tax cut that was in effect in April, everybody’s withholding on their W-2’s, was actually increased, providing more income, more money to spend. Last there was some government spending in infrastructure that started going out. But the main infrastructure spending, actually is scheduled for 2010. That’s when we get the energy alternatives, that’s when we get more infrastructure, and other things that are going to create productivity in the long run as well as create jobs. What has been the effect of all this spending? Well as Mark said, over the last six months, we’ve actually seen a much different outcome than what was projected in the springtime, the economy shrank by a little bit, it would’ve shrunk by around 4 percent, but it actually shrank by a little bit less than 1 percent. In the summer the economy actually grew. Now, as someone dedicated to raising the living standards of the entire broad middle class, who’s satisfied with that, I’m not satisfied with that, okay? But “Obama’s Economic Polices Are Working Effectively” the question is, are you going to judge the Obama administration policy ineffective, because it hasn’t corrected what I think is 30 years of generating inequality, false-hearted, silly deregulation and worshipping of markets where we shouldn’t have done it that got us into this darn mess? I don’t think that’s quite appropriate. Thank you—don’t take my time. Um— We calculate that the Recovery Act has actually created anywhere between 1.1 to 1.5 million jobs by the end of September. I’m not satisfied that the job losses are 200,000 rather than 700,000, but I think it’s quite great. I’m very worried about the fact that unemployment is going to be high for many years to come, too high. I don’t blame that on President Obama, I blame that on the bums that put us in this mess. And you should too. Now, it’s true that the unemployment rate is higher than what the administration said it was going to be. They said if we did the Recovery Act it was going to only get to 8 percent. Well, let me mention something. The unemployment rate in March, before the Recovery Act even had an effect was already 8.5 percent. Now I did tell my friends in the White House, that’s a silly thing, don’t project like that. You shouldn’t do that, you’re going to get caught by that, and in fact, they have been hung by their own petard so to speak. But the fact is that, let me tell you that this is not a policy failure. This is a failure of my profession, economists. If you look at what “Obama’s Economic Polices Are Working Effectively” economists projected right at the time of the election, the blue- chip forecasts, and look at that same period I told you about, the nine months that includes the last half of last year and the first three months of this year. Now they’re already halfway through that period. And they were saying that the economy was going to shrink at a 1.5 percent rate, over that nine-month period. And it actually shrank by three times that much. So the fact is, what the administration got wrong in its forecast was it didn’t have a right sense of what things were going to be without the policy. I think they got the policy right, the policy’s had a substantial impact. Now has it solved all our problems, the fact is I’m not so sure how much more could’ve been done, economically. I can darn well tell you that politically, there was not much more on the table that they could get. What was put through the House and was put through the Senate, what was stopped, is some people that were in the Senate, who are known as moderates which just means they want to do a little bit less of what everybody else—

And thank you very much.

### Moderator
Claim: Larry Mishel—your time is up.

### Conspiracy Advocate (CA)
Claim: And thank you very much.

### Moderator
Claim: “Obama’s Economic Polices Are Working Effectively” So here is where we are, we are halfway through the opening round of this Intelligence Squared US debate, I’m John Donvan of ABC News. We have six debaters, two teams out there, fighting it out over this motion, “Obama’s Economic Policies Are Working Effectively.” And now on to our fourth debater. Allan Meltzer who is an economist at Carnegie Mellon University, he is not the liberal member of his team, he is far from it. And if you caught CNBC a few days ago Allan Meltzer appeared there and I quote, “We have an administration that spends and spends and lies.” Ladies and gentlemen, Allan Meltzer.

### Scientific Advocate (SA)
Claim: I’m here to talk about the Obama policy, not about apartment house fires. The policy has had a mixed result. There’re some small positive effects. But, there are five reasons for concluding the policies are not working effectively. First, the forecast was that $780 billion would be spent, the maximum unemployment rate would be 8 percent. Second, it’s now 10.2 percent, continuing to rise, that’s a failure. The second, is the administration recognition that the policy has failed. If the policy had succeeded, they would not be talking about another stimulus program, it recognizes, that talk recognizes, that the stimulus was not effective. That their “Obama’s Economic Polices Are Working Effectively” policies have, so far, been very weak. Third, the administration invented something called “jobs saved.” You can search economic textbooks from now to the end of time, you will not find something called “jobs saved.” Jobs saved, how do you know if you job is saved. Sure, it was true that, if we paid the states to have a smaller deficit, they didn’t fire quite so many teachers. But, we also shifted the deficit, to the federal government, with higher future tax rates that are going to have to pay for those, over the long term. This administration has failed on the main thing that it needs to do, which is to tell us, how are we going to get out of this mess. The composition of the stimulus is the fourth problem. That was decided in the Congress. It was a mistake by the Obama administration to let it be decided in the Congress, because the Congress was interested much more in the redistribution of wealth than it was in seeing jobs and the economy improved. One-third of the stimulus went to state and local governments, for their deficits. That may be good or bad policy, but it has very little stimulus. It simply transfers the deficit from one place to another. Also, a big piece of the stimulus went for a temporary tax cut. We’ve had lots of evidence on temporary tax cuts. The Bush administration, the Ford administration, the Carter administration, they all tried temporary tax cuts. The economic evidence is, temporary tax cuts don’t do much. The only major stimulating tax cuts that “Obama’s Economic Polices Are Working Effectively” we’ve had in the post-war period were the Kennedy-Johnson tax cuts, and the Reagan tax cuts. They were permanent tax cuts, people knew that once they got them, they were theirs. Finally fifth. This program is so off the block. Do you remember shovel-ready projects? Well, only 25 percent of the dollars for the infrastructure have been spent. Maybe that part of the program will do some good when it gets started, but the economy is in a slow recovery. So that part of the program is hardly a success. Now the economy has recovered, and the members of the affirmative tell us about how much better things are than they were a year ago. But is that a result of the Obama policy, or is it the natural tendency of the economy when it sinks, when inventories get very low, to be rebuilt, because that’s where a lot of the third-quarter improvement came from, the rebuilding of inventories. Very little of it in consumption. Most of the recovery in the third quarter came from temporary clunkers, and housing. The housing policy is full of corruption. People come in and ask for the $8,000, they send their children, because they’ve already bought a house, they send their children to do it, the Washington Post had a long expose of the corruption in the housing problem. I believe that we have the wrong policy. The problem for the United States for the future, the problem that we are all going to face for a long time to come, is that we have a huge debt, that a lot of, part of it is owed to foreigners, and it’s “Obama’s Economic Polices Are Working Effectively” growing. So, you don’t have be to an academic economist to figure out that the way we’re going to pay for that is to export. And the way to export more, would be to invest more, and earn our way out of that problem. What the administration is doing is the wrong thing. It’s trying to build up consumption. Fortunately, it isn’t being very successful. Now the CBO, the Congressional Budget Office, says we have a debate explosion. It’s unsustainable. It’s headed toward a debt crisis. The Congressional Budget Office says that every 10-point increase, percentage point increase in the debt ratio, lowers GDP growth by a quarter percent. This administration is increasing the debt by 50 percentage points. That’s a policy failure. The government debt to GDP ratio was about 50 percent, when the administration took office. The CBO trajectory says, it’s going to 700 percent. 700 percent is not a point we’re going to reach, because it’s unsustainable. That means, we’re headed, unless we do something about the exploding debt, we’re going to have a crisis. We absorb a considerable part of world savings, that too is unsustainable. Why. Well, the Bush drug bill. The Obama health care bill. A great many of the things that the Congress does, increase the deficit. You can’t believe, that we’re going to cut Medicare by $500 billion in order to get the drug bill passed. But that’s what you have to believe, if you believe that this administration is going to give you health care without paying. “Obama’s Economic Polices Are Working Effectively” We are on an unsustainable policy, and it’s a failed policy. Many years ago I started to tell people, capitalism without failure, is like religion without sin. Governor Spitzer’s going to talk about that in the context— In the context…in the context of the banking system—

Thank you. Vote no!

### Moderator
Claim: Allan Meltzer, your time is up.

### Scientific Advocate (SA)
Claim: Thank you. Vote no!

### Moderator
Claim: Our motion is, “Obama’s Economic Policies Are Working Effectively.” And our next debater, who will be arguing for the motion, Steve Rattner, who has gone through many careers. He began as a journalist. He switched to finance. Good call, by the way. And he recently had the beginning of a political career as a treasury official. He came to the White House and was given the job of the auto rescue—the GM deal, that’s him. The Chrysler deal, that’s him. However, he does not like the term Car Czar, which is too bad, because it’s very musical.

### Conspiracy Advocate (CA)
Claim: Well, my paternal grandparents, who were fur peddlers in Moscow, would be rather shocked at the idea that I was a Czar of “Obama’s Economic Polices Are Working Effectively” any kind, so I will...I don’t have anything to follow Allan Meltzer’s last remark, I’m afraid... But I was struck listening to the first two speakers from the other side. I feel a little bit like Goldilocks. I heard one speaker that we in the Obama Administration were too hot and I heard one sort of imply we were too cold. And that makes me think we got it about right. All kidding aside, I actually do want to make a serious point. And with all due respect to the first two speakers from the other side, I want to try to take the ethereal world of theory and connect it to the real world of politics. Because I heard a few things that kind of, that did strike me. I heard Jamie say, Congress must provide more resources. We must resolve the toxic banks. We can’t let it be decided by Congress. Well, who else decides things besides Congress? We have to stop the displacement of people from their homes. I mean, these are all wonderful phrases but this is, as I found in my six months in Washington, not how the world works. As Rahm Emanuel said the other day, It’s fine to imagine yourself sitting under a shady tree at the Aspen Institute thinking of great policies.

But then eventually you have to come to grips with the real world and deal with it. So you can say, people can say our stimulus program was not enough, but the fact is, as Larry said just at the “Obama’s Economic Polices Are Working Effectively” end of his remarks, it was all Congress was going to pass. There was no more there. It took every ounce of political muscle that the administration had to get that. You can say it was too much but I think as Larry Summers has said many times, when you are facing a potential disaster you err on the side of doing more, not less. And they did as much as was possible. So I just want to try to again connect back to this sort of real world of politics and of getting things done that was really one of the biggest surprises that I found coming to Washington.

We may all talk about the President and say, It’s the President’s decision. The President recommends this, the President does that. But there is a little thing called Congress that has to be dealt with as well and that becomes a series of gives and takes and judgments. And so when Jamie Galbraith says, All Obama did was two things: the stimulus program and the low interest rates—which actually wasn’t even Obama. That was the Federal Reserve—it’s really not fair. I think the Obama Administration – and we’ll talk more about autos in a minute—but this Financial Regulatory Reform which has been put forward, this energy which has been put forward, this health care which has been put forward, this housing which has been put forward—all these problems that were unattended to for the last eight years, this administration is trying its hardest to address in a thoughtful, “Obama’s Economic Polices Are Working Effectively” responsible way. Let me turn for a minute now to the auto sector as well because I think my two fellow panelists made very, very coherent and logical and I hope ultimately persuasive cases for why the rest of the policy actions that the administration took were thoughtful. And so let me talk for a second about autos. Because it was an interesting area. It’s one of the few areas where the President actually did have authority. And so if you don’t like what the President did on autos, it’s fair to blame the administration for that because we didn’t have to go to Congress. We had TARP money. We didn’t have to deal with the Federal Reserve and the FDIC, except in one fairly minor way. We were pretty free to act. And when we showed up we had a bunch of people from one side of the aisle saying, You’ve gotta let these companies fail.

You’ve gotta let the market work. I’m sorry I don’t have any quotes from Jamie, but I did see one quote from Allan when I was poking around where, when Lehman Brothers went out of business Allan said, No big deal. It’s fine. That’s the way--you should have consequences from capitalism. That’s the way it should work. And then a year later he said Lehman Brothers should have been saved. And so we had a lot of people saying to us, Oh, just let the market work. Well, I hope the people who “Obama’s Economic Polices Are Working Effectively” said, Let’s just let the market work, knew what that would have meant. It would have meant that Chrysler and GM would have shut down by the end of March. It would have meant that hundreds of suppliers would have gone out of business. They all would have liquidated. It would have meant that Ford would have stopped making cars because they wouldn’t have been able to get parts because their suppliers, many of them, would have been shut down. And you would have had something like three million people out of work, mostly in the industrial Midwest right at the end of March, right when the economy was at its worst.

So it’s fine to say, Let’s let the market work. But again, let’s try to connect it back to the real world and what the real world consequences would be of letting that happen. Then you had some people, frankly, on the other side who basically said, You can’t let these companies go bankrupt. It would be catastrophic, it would be a disaster. Nobody would buy cars. They would eventually liquidate. You can’t possibly do that. But President Obama made the decision that we weren’t going to simply kick the can down the road, frankly, the way the previous administration had, and we were only going to inject money in the context of a fundamental restructuring that might have to include bankruptcy, which it ultimately did. And we achieved unprecedented sacrifices from all the stakeholders—from the “Obama’s Economic Polices Are Working Effectively” lenders, from the UAW, from the suppliers, from the dealers, from everybody who was affected—came to the table and, frankly, with a fair amount of muscle from the administration, participated in this restructuring.

And the result of that was that today General Motors announced their earnings. They’re still losing money but their performance was wildly better than anybody would have guessed. They have forty-two billion dollars of cash in the bank at the moment and they are performing well ahead of the expectations that we had. They’re out of bankruptcy. Chrysler is out of bankruptcy in alliance with Fiat. So I think it is a very vivid example of a place where we weren’t too hot, we weren’t too cold. We were very pragmatic. We addressed the problem, we focused on it and we tried to come up with the best solution for all concerned.

And I think that that exercise, which I was proud to be a small part of, was emblematic of the approach that this administration has taken. Tim Geithner and Larry Summers, the two principal economic policy makers, have strong views of principle but they are experienced, they are pragmatic. They know how to get things done. They are balanced and they are very thoughtful. And I think that the approach that they have taken throughout this process has been enormously positive and has led to all the “Obama’s Economic Polices Are Working Effectively” things that you heard Larry and Mark talk about in terms of bringing this country back from the abyss, bringing us back from a depression and getting us started down the road. Of course, I think it was—I forget who on the other side said—47 percent of people think the economy is the most important issue. Of course it’s the most important issue. But that doesn’t mean we haven’t made good progress. That doesn’t mean that disaster hasn’t been averted and those green shoots that people talk about have begun to sprout. So I was very proud to be a part of that and I would simply say to you, Would you prefer this administration or the last administration or some other administration? Because I think this administration has done awfully well.

### Moderator
Claim: Thank you, Steve Rattner. Our motion is, “Obama’s Economic Policies Are Working Effectively.” And here as our final speaker, to argue against the motion: Eliot Spitzer, the former Attorney General and Governor of New York—a man whose career has been marked much in headlines, some that were favorable, some that were not. He is, however, at this point in the media himself, having become a financial columnist for Slate. And I want to point out to our audience that when this debate was conceived, Eliot was actually going to argue the other side. He was going to say the economic policies are working effectively. He has switched sides now. And Eliot, I hope in your opening remarks “Obama’s Economic Polices Are Working Effectively” you address the basic question: What’s that all about?

### Scientific Advocate (SA)
Claim: Sure. Well, that was not a proposition, but thank you. First, first even, before I do that, John, well, let me just thank Allan Meltzer. If I follow his logic I have found religion. The short answer to your question is that I read Mark’s testimony. I was going to say, Mark, Thank you very much. We were on the same side and then I read his very persuasive testimony that he provided—testified before Congress a few weeks ago. And he goes through point by point—and I’ll get to it in a moment—that the terror that we are facing, and how treacherous the shoals are that we are going to run up against in a very short order economically—and I said, My goodness, this is not working at all. And so, Mark, thank you for persuading me. I will distribute it at the end of the day and you can all be-- I think you will vote our side once you have read Mark’s testimony.

### Scientific Advocate (SA)
Claim: I’m sure you will next time around. Well, let me also say very clearly that the Obama Administration’s economic policies, in my mind, stand for continuity you can believe in. We are still giving away vast sums of money to the same people with the same result so the bank profits are way up, unemployment is up, “Obama’s Economic Polices Are Working Effectively” investment is not increasing, consumption is not increasing and we are not seeing any of the wise transformation in the fundamental structure of our economy that this crisis calls for. We all We all remember Rahm Emanuel’s often-cited statement that a crisis is a terrible thing to waste. Indeed, it is. This crisis is the rare opportunity that we have to change the direction of our economy, an economy that has been sliding in the wrong direction for many years.

On that proposition we would all agree. And I think that Larry used a very prescient metaphor of an apartment house that is burning down. And he would say that the Obama Administration came with fire hoses blazing and put out half of the fire. Our perspective is they didn’t call the fire brigade from the next county, that they didn’t say, What can we do to stop the fire? What can we do from the air? How can we add other fire retardants to turn this off and make sure that there is not a fire next time around? And that is what we have to do, that failure structurally is what we are talking about. Let’s deal with numbers just for a moment. And these are numbers from Mark’s testimony. They are there out online, of course.

These are irrefutable numbers. Unemployment up to 17.5 percent, 26 million people, increasing at the rate of several “Obama’s Economic Polices Are Working Effectively” hundred thousand per month. Yes, the 700,000 a month of that was when we were in free fall. Right now we are still in free fall— two hundred thousand. There is not any affirmative news on the job front. And I will get to General Motors in a moment in terms of what they stand for in terms of jobs. Foreclosures: foreclosures are getting worse, not better. Your testimony—and we all agree—2010 will be worse than 2009, which was worse than 2008. Why? Adjustable rate mortgages are going to reset next year. Fewer and fewer home owners will be able to afford to make their mortgage payments. That crisis continues unabated. And one of the things the Obama Administration did not do that it should have done was push for the legislative power to give judges the power to reform mortgages in the bankruptcy context.

I, at that point, when I saw that, I said, How could they not do this? It is fundamental, it is necessary, it is right. It would help the middle class that we supposedly care about most fundamentally. The number, by the way: foreclosures are up twenty-three percent this year over last year and it will get worse. Commercial real estate, we care about it less, other than as it affects the banking community. You in your testimony say hundreds of banks will go bankrupt next year as a result of the mortgages in the commercial real estate sector that simply cannot be refinanced—grossly undervalued, still “Obama’s Economic Polices Are Working Effectively” accounting gimmicks. They are left, right and center. We have not faced to it. It will be a disaster. Credit markets are dysfunctional. Your word, we all agree with it. Credit markets are dysfunctional.

Small, medium sized businesses cannot borrow, simply cannot borrow, even though we have given trillions of dollars to the megabanks that came crawling to Washington, say, Please, please, please, we can’t pay our bonuses. State and local We won’t even get into it cause I only have 2:52 left. The AIG conduit payments to Goldman, the 12.9 billion, 100 percent on the counter party payments—absolutely outrageous. Tim Geithner must explain this to the American public. Absolutely outrageous. State and local governments will be going bankrupt. They are down ten, 15 percent in their revenues. We have handled it for one year. They will go over a precipice next year. That will lead to the full-time shutdown of school districts, fire districts, community services.

That is where we are seeing it because property values will plummet, property revenues will plummet. Sales tax revenue, real estate revenues—all dramatically down. General Motors today—Steve, you’re right. GM had better numbers today. Third “Obama’s Economic Polices Are Working Effectively” quarter they only lost $1.12 billion. Congratulations. We’re on the road to recovery. Let me tell you something. Do you know where they saw signs of improvement? Their China subsidiaries. Look at, disaggregate the numbers, really read what happened. China sales are up twenty, 30, 40 percent, first quarter to third quarter. Sales in the U.S. down. Next year’s market, they had been presuming under your plan 12 and a half million auto sales next year, calendar year 2010. And the U.S. economy downgraded to eleven today. Think about that and what that means. They will not survive. Chrysler will probably go over the cliff as well. They’re going to be selling Fiats. That’s their business model. It won’t work. Let’s be real about this.

Manufacturing jobs, we are losing. We have lost a third of our manufacturing jobs in the last decade. They do not come back, ever. You look month after month over the last decade, good times and bad, they do not come back. It is worse now than it’s ever been. That is the core of our economy. We cannot all be lawyers and investment bankers. We need clients. The clients are all gone. It doesn’t work. The fundamental error of this administration is that it is continuity. They have embraced the Bush Administration view that if you solve the problem of big banks everything else flows from that. They are wrong. Too big to fail is too big. They don’t get it. The only two “Obama’s Economic Polices Are Working Effectively” people I know who don’t appreciate that are Tim Geithner and Larry Summers. Paul Volcker, Alan Greenspan, Henry Kaufman, Mervyn King—every major academic has said, We must get rid of too big to fail.

They refuse to cross that threshold. Until they do we will not reform the financial services sector and that is where they have focused to the exclusion of virtually the entire rest of the economy. They do not appreciate the power they had. They do not know how to negotiate for the fundamental change. We’ve been involved in what I call a regulatory charade, pretending the problem was lack of power. And the regulators, they had the power, they chose not to use it. Who were those regulators? The same folks we’re now promoting and sitting there making these misguided policies. It’s time for more fundamental change. Call in the fire brigade from the next county. Let’s put out the fire. Thank you very much.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where the motion being argued, “Obama’s Economic Policies Are Working Effectively.” And as you recall, at the beginning of the evening we asked you to vote on whether you agree or disagree with the motion. And we now have the results from our live audience. Before the debate, the motion being, “Obama’s Economic Polices Are Working Effectively” “Obama’s Economic Policies Are Working Effectively”—before the debate 32 percent of you are for the motion, 29 percent against and 39 undecided. That is where things started. You will vote again at the conclusion and the team that has changed the most minds will be declared our winner. Now, on to round two. It’s our middle round and this is the round where the debaters go more head to head. They’ll be taking questions from you, the audience, and from myself as well. And I would like to start by lifting something from what Eliot Spitzer just said. He came up with five words that more or less sum up their position—we are still in free fall. Is it true? Anybody on the team arguing for?

### Conspiracy Advocate (CA)
Claim: I’ll take a crack at it. No. In a word. Do you remember back a year ago? Do you remember? That’s free fall. That’s when we were panicked, when there were runs on major banking institutions— Wachovia, Washington Mutual. You were afraid to keep your money in your bank. The stock market was in complete free fall. Housing values were falling 5, 10, 15 percent. We were losing 700,000 jobs per month. That’s free fall. Today, we’ve got stability. The policies aren’t magic. They can’t work overnight in a matter of a few months. But look where we are today. Think about the counter-factual. Think about what the world would look like without these policy responses. In my strong opinion, we averted what would have been another “Obama’s Economic Polices Are Working Effectively” depression. Yes, this was a very severe recession, but we averted a depression. So, no, we’re not in free fall. We’re

### Moderator
Claim: I’d like to ask the audience to – with a show of applause, whether you find that point convincing. Are we— And now to the response of Eliot Spitzer.

### Scientific Advocate (SA)
Claim: Well, let’s frame it this way for you, Mark. There is the easy decision, which is to spend a ton of money. We needed to do that. We all knew we would. I don’t think it mattered who the President was, and thankfully, obviously, I am a fervent supporter of the President. We were going to spend a huge sum of money. There are—

### Moderator
Claim: Eliot, I just want to encourage you to get a little closer to your mic.

### Scientific Advocate (SA)
Claim: I’m sorry.

### Moderator
Claim: Thanks.

### Scientific Advocate (SA)
Claim: There are three questions that followed that actually matter. Spending the money is the premise. The first question is who pays for it. And it’s not so obvious that it needs to be “Obama’s Economic Polices Are Working Effectively” exclusively the tax payers as opposed to those who are equity debt holders and indeed the former executives of the companies. Even though that would be a small number numerically, nonetheless, symbolically important. So who pays, and we’ve gotten it wrong in that regard. We have not gotten debt and equity to kick in sufficiently. Two: what reform do you get for the money you’re spending? Because rebuilding the same façade, the same edifice that’s been broken will not get us anywhere. And the primary grievance that I have with this administration is that we are spending the money rebuilding the same structures, the same decision making process that got us to what we are right now. And third: job creation is the most important metric out there.

### Conspiracy Advocate (CA)
Claim: That’s fourth, Eliot, fourth.

### Scientific Advocate (SA)
Claim: Great, you’re an economist. I was I was in political science. We can, usually we

### Conspiracy Advocate (CA)
Claim: Don’t fudge, now, don’t fudge.

### Scientific Advocate (SA)
Claim: No, no, no. No, no, no. Mark, we had a premise and three questions.—

### Moderator
Claim: “Obama’s Economic Polices Are Working Effectively” Wait, let me bring in Larry Mishel.

### Scientific Advocate (SA)
Claim: So...

### Moderator
Claim: Larry, what ...what you just heard?

### Scientific Advocate (SA)
Claim: But job, job creation—

### Moderator
Claim: Eliot, let me, let me bring in Larry Mishel.

### Scientific Advocate (SA)
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: Well, I really think it’s worth keeping two things separate. One is the whole financial market issue, which is primarily the motivation of what you’re talking about, Eliot. You’re talking about spending. And then there’s the question of jobs and the Recovery Act. And it seems to me that there was nothing foreordained that anyone who got elected was going to actually do what was done and put together a nearly eight hundred billion dollar package to go through Congress—They wouldn’t have been able to get it through Congress—and that was going to be able to move the needle as much as the needle has been moved. Not that we’re to be satisfied. I mean, you know, this is the-- my “Obama’s Economic Polices Are Working Effectively” friends that are fellow liberals—Jamie and Eliot—are basically arguing against the excellent is the enemy of the very, very good. And that is, in my mind, just not really— and especially to have a former elected official do that, just seems otherworldly to me, to tell you the truth. You know, I’m a close observer of Washington. I watched what the so-called moderates did in the Senate to that stimulus bill. They took out, a substantial amount of aid to the states. They took out a school modernization program that last summer could have actually rebuilt a lot of schools, created a lot of jobs. And they stuck in there something that was going to be done anyway, which is the ANT relief, which is basically tax relief for wealthy income tax payers. That in effect, is proof positive that they got as much as they could out of the political system. If you wanted to get more you had to have a different Congress. I don’t think there was a different political strategy. I can

### Moderator
Claim: All right, let me bring in Jamie.

### Scientific Advocate (SA)
Claim: The question before the House is not whether in the very difficult political environment the President’s team did as much as they could. The question before the House is, Are the policies working effectively? That’s a question about the economy and not about the politics. Let’s look at where we are. Let’s try to come to grips “Obama’s Economic Polices Are Working Effectively” with the scale of the disaster. What has happened here is that the financial wealth of the American middle class in their houses and in their 401k’s and their bank accounts, built up over six or seven decades, has largely evaporated. It’s a colossal disaster. People who thought they were going to retire on their home equity aren’t going to have it. Delinquency rates in the state of Florida are over 20 percent, foreclosures over 10 percent. This is an incredible thing. If we think now how many jobs we need to get back to where, to fill the hole by 2011 it’s more than five hundred thousand jobs a month, if something hasn’t happened since 1950-51. If we want to do it over five years it’s three million jobs over the course of each single year—something that I don’t believe has ever been achieved. If we’re going to deal with the problem we have to think about the scale of policy that goes well beyond what the political environment in Washington is prepared to deal with and we have to persuade it to change. Otherwise, we are not going to solve these problems.

### Moderator
Claim: So let me bring that back to Steven Rattner, who is arguing for the motion, the policies are working. And Steven, that’s an argument that they’re conceding, the rescue succeeded. The canoe did not go off the cliff. But they’re saying going forward, that does not solve where we need to get to.

### Conspiracy Advocate (CA)
Claim: “Obama’s Economic Polices Are Working Effectively” Well, I don’t think any of us would disagree with that. I think, without getting into a big semantic debate over the question, if the question were: Is the economy in a happy place?, we’d all be on one side of the table. The question in effect, in my mind, is, Has Obama put forward and tried to implement policies that will have a positive effect on the economy and move it in the right direction? And I think, I hope we’ve all made a very clear, convincing case that it has, and will. Nobody would disagree, you guys are great at giving us a litany of what’s wrong. Eliot, you gave us six minutes and forty-five seconds of what’s wrong with the economy and I only heard one or two suggestions what to actually do about it. I don’t know what your suggestion is about General Motors. Is it to let it to go bankrupt and have a couple of million people out of jobs? I don’t know what your suggestion is about Goldman Sachs and the derivatives contracts. I don’t like it any better than you do. Would you like the financial system to melt down the way Lehman Brothers did? I don’t know what your suggestion is about how to fix regulatory reform, which the administration has put forward a proposal which is mired in all the Congressional politics around it. And I guess, I’m surprised because you were Governor. You know what it’s like up there. You were the, you showed up in Albany and said, Day one everything changes. And it didn’t because you had the “Obama’s Economic Polices Are Working Effectively” legislature.

### Scientific Advocate (SA)
Claim: Well, then let me, I’ll tell you exactly what I would have done. It may take more than two minutes but I’ll limit it. In terms of cars I would have said, No, we’re not going to just give billions of dollars to a shelvable company. We will say we will buy five hundred thousand battery powered cars two years from now from whatever domestic producer, I don’t care whether it’s GM, Hyundai, Kia. Produce it here, 80 percent produced domestically. We want to stimulate that type of productivity.

### Conspiracy Advocate (CA)
Claim: That’s—

### Scientific Advocate (SA)
Claim: And, no, no, no. And we will build the electric recharging stations, akin to what Eisenhower did, on the interstate system. Build a new infrastructure. Create, take the money that we gave to Goldman and instead of saying, Here it is, 12.9 billion—use it to create Felix Rohatyns in the infrastructure bank. That is what we need, that’s where the dollars should have gone. The dollars could have been used in many different ways. Instead, when we made these enormous transfers, based upon nothing more than the say-so that we need it—which they didn’t because they’ve said they didn’t have any exposure to the AIG CDS, situation. They were fully hedged. We didn’t ask for “Obama’s Economic Polices Are Working Effectively” anything back. It was the failure to ask for anything back that was fundamentally wrong and that is why we are left with the same system we had before.

### Moderator
Claim: Let me ask Allan Meltzer. Aren’t, aren’t we, are we not better off with a GM in some form rather than no General Motors?

### Moderator
Claim: Aren’t we?

### Moderator
Claim: Allan, Allan, are we not better off having some form of General Motors and people working there than no General Motors?

### Scientific Advocate (SA)
Claim: I’m with Eliot. We, what the country needs in a more general sense, not just confined to automobiles—what the country needs to do is think about the enormous debt that it owes to foreigners and how it’s going to pay them without bankrupting the country. And the only answer that exists is you have to export. We have to export. And in order to do that we have to invest. And the right program was an investment program, not a consumption program, not a bailout program. That was a mistake. Now, they want to say the administration was great in pushing this program. The administration made a mistake of letting the Congress write that program. So instead of writing in a program “Obama’s Economic Polices Are Working Effectively” that the United States needs to solve its long term problem, the problems that you and I and everyone else are going to face for the next ten or twenty years, is how to handle that debt, how to get our exports up, how to get our consumption down—not how to get our consumption up. That was a fundamental mistake. The administration made that mistake. It should never have made that mistake because Larry Summers certainly should have known that the problem we’re going to have is how to finance that debt with more exports. And that’s going to require greater investment. And one of those investments is the kind of investment that Eliot was talking about.

### Moderator
Claim: Okay, I want to come back to Mark. I want to come back to you but I want to ask you to hold for just a minute. We’re going to come back to Mark Zandi but I want to, at this point, get you ready to turn this over to you for questions. Reminding you of a couple of things. When the microphone, we have ushers with microphones. If you raise your hands and I spot you, I’ll signal that it’s for you. The microphone will come to you. I’m asking you to rise. If you’re a member of the news media we ask that you to identify yourself. And I want to remind you when you hold the microphone to hold it about one fist’s way, distance from your mouth so that we can hear you. And the last thing is please ask a question. We don’t want speeches and “Obama’s Economic Polices Are Working Effectively” we are not asking you to debate with the debaters because we already have six and that’s even. Mark Zandi, to respond.

### Conspiracy Advocate (CA)
Claim: Well, just a fact, one fact and then two responses. Just another statistic. Household net worth, that’s the value of all the things that we owe less all the things that we owe. This is our net worth. It declined by $15 trillion between the peak in ’07 Q3 through the bottom in ’08 Q4. $15 trillion. And just to give you a context, there’s about $60 trillion worth, at the peak there was about $60 trillion in household net worth. Since the beginning of the year or since the administration’s inauguration, household net worth has risen by $5 trillion, $5 trillion. So that obviously reflects the improvement in the equity markets, stock prices—at least as measured by the S&P 500—are up. I didn’t look today but it’s up somewhere between 25 and 30 percent since he was brought into office. And housing values have started to rise. They fell sharply through the beginning of the year down 30 percent from the peak and now they’ve begun to rise. So to me that’s a very important statistic because that’s our net worth.

Now, two quick responses, one with respect to the deficit. I think this is a legitimate concern. Obviously, it is a critical concern that we had a $1.4 trillion deficit, at 10 percent of GDP in fiscal “Obama’s Economic Polices Are Working Effectively” year ’09. And we’re going to run up a $1.2 trillion deficit at least in the current fiscal year. These are big numbers. But, you know, this was a Hobson’s choice for us. It really was no choice. If the policy makers did not respond aggressively to this and use the resources the economy would still be in recession, the financial system would be in disarray and the cost to taxpayers measurably greater, measurably greater. The deficits would be larger than they are. So we really had no choice in this. And I think, as well, the deficits are something that are the result of it. Now, finally, one other response.

You know, in the efforts to shore up the financial system in the auto sector and other parts of the economy, we did get something. We got equity in a lot of these companies. And today GM said that they were going to begin repaying the loan that we made to them well before plan. And in fact, here’s a prediction. This is what I do for a living. I predict that at the end of the day we are going to get most of that money back, if not all of it, and in fact, many of the banks had repaid a lot of the loans, capital we took into the institutions and we’ve made money on that. So I think when this is all said and done and over and done with, the cost will be measurably greater. And that’s because we did get something when we did help them get through this period. “Obama’s Economic Polices Are Working Effectively”

### Moderator
Claim: Okay.

### Moderator
Claim: John, can I make just...?

### Moderator
Claim: Uh, no, I actually want to go to questions at this point. Thank you. The man with the white card. It was a very good way to get my attention. It’s not going to work again.

### Moderator
Claim: I saw somebody else use it last time I was here. First let me say thank you to the group in the front. Let me say thank you to the group in the audience. This is what New York City is all about. And the question I have for you is this: How long will it take to put solar energy on those buildings that are sitting in back of you? How long will it take for the green economy to get moving? How long will it take for us in America to get off the backs of oil and to do for ourselves? How long will it take? You’re the economists, you’re the predictors. I see it and where I’m at

### Moderator
Claim: All right, let me ask you how you would phrase this question in terms of our motion. I’m coming back to you. How would you phrase this question, how would you relate this question to our motion, whether Obama’s economic “Obama’s Economic Polices Are Working Effectively” policies are working effectively? And if you can’t I’m going to have to pass.

### Moderator
Claim: Well, I could do that, sir. And I’ll do it very quickly. My question is this: It takes a long time to get the ship out of the mud. As a sailor I know. We’re stuck in the mud here. How long do we feel it’ll take for the green economy to take effect? Thank you.

### Moderator
Claim: Good question. Jamie, Jamie Galbraith.

### Scientific Advocate (SA)
Claim: One of the misfires at the start of this process was the idea that you could handle the problem with a stimulus package that would work in a relatively short period of time, over a year or two. It’s not going to work that way. In order to get out of this we are going to need to set a strategic direction for the economy and build institutions and programs capable of mounting a sustained effort over ten, fifteen, twenty years. And the direction that we need to take is clearly in the line that you just indicated, in the line dealing with our energy problem, dealing with climate change, creating green jobs so that people have work to do that is useful for the country. That was our institutional challenges that are on a par with the creation of the middle class in the New Deal in the post-war era. And it’s just nothing short of that. We need “Obama’s Economic Polices Are Working Effectively” to be articulating, visualizing and acting on that scale and over that time frame, in my view.

### Moderator
Claim: Larry Mishel, arguing for the motion.

### Conspiracy Advocate (CA)
Claim: I’m yielding, I yield to Steve. My buddy Steve.

### Conspiracy Advocate (CA)
Claim: My buddy Larry. We’ve never agreed on anything before. No, I’m kidding—

### Moderator
Claim: We’re not seeing that on the other team, exactly.

### Conspiracy Advocate (CA)
Claim: Look, I want to wrap this back to this whole idea about cars and everything. The green economy is an important part of the future—but I think Jamie and I might even agree on this—but it is the longer term future. And the Obama Administration, I would argue, has all kinds of proposals that it is pushing vigorously to implement a green economy. But we are kidding ourselves if we think the green economy is the solution to our immediate economic problems. We are kidding ourselves if we think we could have let General Motors go bankrupt and built five hundred whatever it was that you said you wanted to build, “Obama’s Economic Polices Are Working Effectively” in its place. And that would employ the million people who would have lost their jobs if General Motors had gotten— James Galbraith We’ve moved past that point to try and make a broader point in—

### Moderator
Claim: But let me, let me Steve finish. Steve, were you finished?

### Conspiracy Advocate (CA)
Claim: Not quite.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: The Department of Energy, which was passed under the previous administration, actually, has a $25 billion loan program for advanced electrification of their-- new technology type of vehicles as a loan program. I will be curious to know if that’s the kind of program that Allan Meltzer would endorse as part of his belief in investment or whether he thinks that’s another government sort of give away boondoggle thing.

### Moderator
Claim: Jamie Galbraith. “Obama’s Economic Polices Are Working Effectively”

### Scientific Advocate (SA)
Claim: I’ve made my point, go ahead.

### Moderator
Claim: Oh, who was next? I thought...

### Scientific Advocate (SA)
Claim: I believe—

### Moderator
Claim: Allan Meltzer.

### Scientific Advocate (SA)
Claim: ...the transformation of the economy is the right thing to do. And that’s what we should have done. But the mistake was to allow the Congress to enact a, what was largely a redistributive program instead of enacting a program which was in the long term interest to the United States. The United States is at a crucial point. We are facing a crisis. There’s a new book out that I commend to everybody. It isn’t my book so I can commend it. It’s by Reinhart and Rogoff. It traces crises since 1300, especially since 1800. I read the book and read the newspaper. It’s hard to know when you’re reading the book and when you’re reading the newspaper. Big debts, bailing out the banking system—we are headed for a crisis. So we have to use our resources more wisely. This is the twelfth recession in the post-war period. All the others we recovered from quickly. No one with any sense or knowledge believes we’re going to recover “Obama’s Economic Polices Are Working Effectively” quickly from this one. That’s a failure of the policies that this administration has accepted from the Congress and is endorsing and pushing on you.

### Moderator
Claim: Thank you. The woman in the fourth row. And Eliot, I see you champing at the bit to get in on this so I’m going to let you take this question if it’s relevant to you. But you must answer this question.

### Moderator
Claim: The question is, at what point do we think the financial services and the whole banking system needs a reform? Is the

### Scientific Advocate (SA)
Claim: At what point does it reform?

### Moderator
Claim: Does it need a reform? And in that regard also another question. Once the government is no longer throwing money at the issues, what is going to happen? There is a sentiment that next year could be a double dip. What is your

### Moderator
Claim: Eliot, why don’t you take the first question?

### Scientific Advocate (SA)
Claim: Look, I don’t want to get into a prediction yet about a double dip. I think that on the other hand I will say this, that the data that “Obama’s Economic Polices Are Working Effectively” we see is not encouraging in terms of spending. I know that if you take away cars from the current consumer spending today it was up .2 percent, inventories are down. All of those are negative data. Your first question, which is the fundamental one, which is how do we begin to reform the financial services sector? that is where the fundamental disagreement that I have with the administration emerges. Because they have spent such an enormous amount of effort and capital rebuilding the same edifice. And those funds could have been used—Steve, this is where we disagree. Of course we needed to preserve General Motors but what we also needed to do was invest. And I agree, I think we, most of us would agree, that, yes, the deficit is a real issue. I would have done the energy investments. I would do more energy investments. Having said that, those funds could have been used to confront the mortgage crisis. Those funds could have been used to pay down some of the enormous mortgage overhang that is keeping consumers from being in a position to spend, from requiring the banks that received hundreds of billions of dollars in cash, trillions of dollars in loan guarantees, to step forward, to reform the mortgages. That would have a fundamental impact on the state of our economy in terms of consumer spending, home net worth and the net worth of the families that we are caring about. Instead, we simply gave the cash to these banks and where it is going is, to a great extent, “Obama’s Economic Polices Are Working Effectively” proprietary trading, overseas investment—all of which is economically worthwhile for them but not for the totality of our gross domestic product. That is what we

### Moderator
Claim: And Mark Zandi, the point I would The, Eliot is saying that the policy has rebuilt the machine that broke once, rather than figuring out a new design for a machine.

### Conspiracy Advocate (CA)
Claim: Well, the financial services industry wouldn’t agree with that. They’re fighting financial regulatory reform very strongly. They feel that these efforts aren’t in their best interest. So I don’t think they would agree with that position. And actually it is, well, quite substantive, the reform that is making its way through Congress. You know, there is a lot of debate but broadly speaking, a number of things are going to come out of this. First, the number of regulators that oversee the financial system will be rationalized. One of the problems we had in the previous regulatory structure was that there was just too many regulators and financial institutions could shop for the regulator or avoid regulation altogether.

And so there is an effort to address that. There is also an effort to fashion a systemic risk regulator that can look across the entire financial scene. Another problem we had in this current “Obama’s Economic Polices Are Working Effectively” financial crisis is that the Federal Reserve and the Treasury did not have the ability to quickly resolve cases like Lehman Brothers, which were not bank holding companies at the time. And then, third, also very important, the effort to establish a consumer financial protection agency. The idea is establishing an FDA for financial products because I think it’s clear from the crisis that many people who got loans really did not understand the loans that they were getting and that caused greater problems. So, and I’m quickly summarizing for you. But the scope of the reform—

### Moderator
Claim: That was about two minutes, actually.

### Conspiracy Advocate (CA)
Claim: ...is—Yeah, sorry—is very significant and the system will be very different at the other end of this.

### Moderator
Claim: Let’s have—Sorry.

### Scientific Advocate (SA)
Claim: Yes. Well, when we talk about—

### Moderator
Claim: Allan, let me get to Allan Meltzer.

### Scientific Advocate (SA)
Claim: ...the administration, this administration as trying to do something about the banking system, the financial system, is “Obama’s Economic Polices Are Working Effectively” laughable. What they’re doing is putting it back where it was, only it’s bigger now because there have been more mergers. We have for thirty years, through various administrations, had too big to fail. Too big to fail is not something that just came with history. It came from the 1970s and it grew and grew and grew. Now what is too big to fail? It is a system in which the bankers make the profits and you, the citizens, take the losses. That’s not a good system. The Federal It’s not good for you and it’s not good for the country. And the reason is because it encourages risk taking, excessive risk taking, by some bankers-- not all bankers, but by some bankers. You—

### Moderator
Claim: Steve Rattner, respond.

### Scientific Advocate (SA)
Claim: And then we bailed 'em out.

### Moderator
Claim: Steve Rattner, respond.

### Scientific Advocate (SA)
Claim: One minute. So what you want to put into this thing—

### Moderator
Claim: Allan, Allan. I just want to get some other voices into it. Steve Rattner, please.

### Scientific Advocate (SA)
Claim: “Obama’s Economic Polices Are Working Effectively” I just

### Conspiracy Advocate (CA)
Claim: I’ll make a couple of very quick points. And I don’t want to be an apologist for the financial services industry, even though I spent twenty-six reasonably happy years in it. But let, but I was not at a TARP bank. I was not at Goldman Sachs. Let me just say a couple of quick things. First, to say that nobody in the financial system has suffered any pain, you should ask the people who worked at Lehman Brothers. You should ask the people who work at Citigroup, you should ask the people who worked at Wachovia, they— Most of them had huge amounts of their net worth in those firms. Ask people who didn’t get bonuses last year, Goldman Sachs is Goldman Sachs but a lot of people in the financial services industry took a lot of pain. The—

### Scientific Advocate (SA)
Claim: But that isn’t the issue, it’s the public that’s taking the big loss.

### Conspiracy Advocate (CA)
Claim: Well, no, no, no, no. No, that is not true, because as Mark just said, I think when the dust settles, I think you will find that the government actually did pretty well on a lot of these investments. Maybe not AIG, we can debate AIG. But the money they put into Goldman Sachs and into Morgan Stanley, first of all was “Obama’s Economic Polices Are Working Effectively” involuntary, those banks didn’t even want the money, the government forced them to take the money because they didn’t want the weak banks to stand out, and a lot of them as Mark said have already repaid it. And let me just make one last point about too big—actually two last points, one about too big to fail. Too big to fail, you know, it’s not about repealing Glass-Steagall, it’s not about saying you can’t have more than this amount of assets. Many of you will remember LTCM, which went under in 1998 if I remember correctly, most people never heard of LTCM, it was probably not in the top 50 size of institutions and it almost brought down the entire financial system. I’m all for fixing these problems but let’s do it thoughtfully, not with a meat axe.

### Scientific Advocate (SA)
Claim: Well, speaking—

### Scientific Advocate (SA)
Claim: When—

### Moderator
Claim: Let, let—Jamie, I stifled Jamie—

### Scientific Advocate (SA)
Claim: When Allan said it was the public taking the losses, he didn’t mean the government budget. He meant the citizenry of the United States, they’re the ones who have taken the losses in this matter. As Mark Zandi already pointed out. The question here, is, again as Eliot has said, do we restore the “Obama’s Economic Polices Are Working Effectively” existing banking system, or do we truly reform it. And that means having a system which is more competitive, better-run, easier to regulate, and led by a regulatory structure which is effective at monitoring and preventing the kinds of massive frauds, particularly in mortgage origination, and in the ratings process, and all through the process that led to this incredible disaster. That requires having enforcement mechanisms that work, and going after the perpetrators as was done, in the resolution of the savings and loan crisis, when, I should remind you, about 1,000 industry insiders were convicted of federal felonies and went to jail—

### Moderator
Claim: Eliot—I wanted to bring the question so if you—

### Scientific Advocate (SA)
Claim: Maybe I—

### Moderator
Claim: —if you can give it brief.

### Scientific Advocate (SA)
Claim: I…wholeheartedly agree with everything you just said, I would just add this point, we already have a systemic risk regulator, it’s called the Fed. They just didn’t do their job. The question shouldn’t be, do we need to pass a law—

### Conspiracy Advocate (CA)
Claim: No, that’s not—that’s not true— “Obama’s Economic Polices Are Working Effectively”

### Scientific Advocate (SA)
Claim: It’s absolutely true—

### Conspiracy Advocate (CA)
Claim: That’s not—

### Scientific Advocate (SA)
Claim: Absolutely the case—

### Conspiracy Advocate (CA)
Claim: Absolutely not true— The Fed had no—

### Scientific Advocate (SA)
Claim: Well, you know what—

### Conspiracy Advocate (CA)
Claim: The Fed—

### Scientific Advocate (SA)
Claim: You ask—you ask them whether—

### Conspiracy Advocate (CA)
Claim: The Fed—the Fed—

### Scientific Advocate (SA)
Claim: —through their monetary policy—

### Conspiracy Advocate (CA)
Claim: The Fed had no—

### Scientific Advocate (SA)
Claim: —through the control of the access to the Fed window—

### Conspiracy Advocate (CA)
Claim: The Fed had no— “Obama’s Economic Polices Are Working Effectively”

### Moderator
Claim: All right, all right, all right— I see—I think I see where you both feel about that, the woman in the second row?

### Moderator
Claim: Hi, this question is for—

### Moderator
Claim: I think you might try again, please. It’s on now.

### Moderator
Claim: This, okay, sorry. The question is for Steve Rattner. I would like you to comment on the status of the dollar today, please?

### Conspiracy Advocate (CA)
Claim: Why me—

### Moderator
Claim: I think it’s off our point too much. Um… Gentlemen, two in, three in—? Gray jacket.

### Moderator
Claim: Hi, I hope I don’t ramble, I just thought about this, while you’re talking—

### Moderator
Claim: “Obama’s Economic Polices Are Working Effectively” You better not ramble.

### Moderator
Claim: I’ll try to make this in two minutes and the past few days—

### Moderator
Claim: But you’ve already used 19 seconds.

### Moderator
Claim: Okay. We’ve talked about how there’s some systemic issues out there, we’ve talked about, you know, um, the finance instruments out there, the financial sector. We talked peripherally about how the American consumer is consuming too much and I think that’s pretty much a—I think that’s an issue that’s been going on for decades where the—

### Moderator
Claim: Okay, sir, I—please get to a question—

### Moderator
Claim: My question is that, do you think there is a systematic issue that has been built because of the inequality of wealth out there where the 1 percent, who, basically control the market, there has never been a capitalist market, it’s the 1 percent that controls the market, there’s no transparency, do you think, there’s a big issue because there’s been a massive… there’s a massive inequality in wealth distribution in this country and that’s going to create issues. “Obama’s Economic Polices Are Working Effectively”

### Moderator
Claim: Jamie Galbraith.

### Scientific Advocate (SA)
Claim: It bears very closely to the question of ineffective economic policy. If you try to have the economy recovery by shoring up those few at the top it simply isn’t going to work, it didn’t work in 1929, it’s not going to work now. What you have to do is to have a program which effectively provides employment, income, and security to the entire population of the United States. That’s where you need to begin. Going about it the other way is simply going about it backwards, and doomed not to succeed.

### Conspiracy Advocate (CA)
Claim: Right, can I weigh in on this?

### Moderator
Claim: Yes, Larry Mishel.

### Conspiracy Advocate (CA)
Claim: I absolutely think that the massive inequalities in our nation, were the precondition for the crisis that we’re in right now. And I believe that the Obama administration’s plans actually do address many of the issues, not all the issues going forward, to try to resolve that. Part of it is to develop a productive economy based on a non-carbon-based economy, part of it is to address changes in our basic labor markets, to have enforced labor laws “Obama’s Economic Polices Are Working Effectively” and the basic wage and hours type things, to be able to restore the right to have unions, to raise the minimum wage. We are, they are also pursuing having universal health care, which is a mechanism for distributing income throughout the population, and security, and to try to do they can to try to get unemployment down as fast as they can which I think is in fact what the policy is. So I think that moving forward, building an economy where we’re not having growth based on asset bubbles and consumer debt, is really important, and that the only way to do that is to have wages growing in line with productivity, and to have more economic security, and I think that if Mr. McCain had been elected we would be nowhere on that agenda. With Mr. Obama, I think we’re around 75 percent on the right track towards that agenda—

### Moderator
Claim: All right. Ma’am, I—you used the question about the dollar, and I think I was too abrupt, and I apologize. Was your question, looking at the dollar today, is it an indicator of his success, is that what you were getting at—

### Moderator
Claim: Yes, exactly, that’s why I wanted one of the gentlemen on the panel on the left to answer—

### Moderator
Claim: Well you’re back in, and I’m sorry— “Obama’s Economic Polices Are Working Effectively”

### Moderator
Claim: Okay—

### Moderator
Claim: —about before…

### Moderator
Claim: Well, uh—

### Moderator
Claim: Well, let me put in Mark Zandi, take that.

### Conspiracy Advocate (CA)
Claim: Well, I think the decline in the dollar that we’ve observed recently over the last six to nine months is entirely appropriate, and actually it’s been very orderly. Entirely appropriate and a net positive for our economy, at least so far, that, yes, it has resulted in somewhat higher commodity prices in the one commodity that matters the most--is the price of oil for all of us. But that negative has been offset by an increase in exports. A source of growth in our economy. It was a very significant negative back in the free fall, a year ago, nine months ago, but is now growing again in part because of the better global economy, in part because of the weaker dollar. Also it’s helped corporate profits, a lot of companies that operate overseas are benefiting from the dollar, so it’s a net positive, now, I do think if you look further out, and the dollar begins to decline in a disorderly way for whatever reason, that would be a problem, but so far, no “Obama’s Economic Polices Are Working Effectively” problem, very good.

### Moderator
Claim: James Galbraith.

### Scientific Advocate (SA)
Claim: Very briefly, I’m not a deficit Cassandra, I’m not a public debt Cassandra and I’m not a dollar Cassandra. These issues are often used to make the argument that you simply can’t do what needs to be done in order to bring the economy back on track and overcome our unemployment crisis. And I don’t think they are valid objections. So from that point of view actually Mark and I don’t have an analytical difference, I would just simply say that the dollar will go where it’s going to go. It’s not going—the international monetary system will probably not collapse, and certainly not as the result of an effective effort to restore the American economy.

### Moderator
Claim: Gentleman in the center?

### Moderator
Claim: Yes. I think very few people here would disagree that there’s more that should be done, in terms of correcting the systemic problems that exist in this country. The question before the group though, is whether Obama’s policies are working effectively. Which brings us back to the problem of dealing with Congress. Where you have many people, when you talk about, “Obama’s Economic Polices Are Working Effectively” you know, making more green jobs, you have many people in Congress, far too many who deny that global warming is even a problem. We have people who are in Congress—

### Moderator
Claim: I need you get to a question now.

### Moderator
Claim: The question is, what would the panelists do, to try to implement the change that they’re talking about, dealing with the Congress we presently have.

### Moderator
Claim: Steve—Steve Rattner, you described what passed is almost a miracle because of the Congress— because of Congress and because of—

### Moderator
Claim: I’m sorry, what was it—

### Moderator
Claim: You described the fact that the stimulus package passed as—

### Conspiracy Advocate (CA)
Claim: Yeah, it was almost a miracle—

### Moderator
Claim: —as itself, a rare miracle.

### Conspiracy Advocate (CA)
Claim: I think this is in all seriousness a huge issue for the country to think about, and, you know, there’s this great quote of Jefferson’s “Obama’s Economic Polices Are Working Effectively” where he says if I had to choose between a government without newspapers or newspapers without a government, I would choose newspapers without a government. And I say that not because I’m advocating newspapers but, the whole concept when you get to Washington of realizing what Jefferson had in mind when he designed or was part of designing our system, the Capitol’s on the hill, the White House is down at the bottom. Article I of the Constitution is the Congress, it’s not the executive branch. The power that the Congress has is formidable and it was created in an era where we weren’t going to be dealing with toxic assets and we weren’t going to be dealing with regulatory reform, and we weren’t going to be dealing with green jobs, and it’s a real problem, I think as I’ve tried to argue that I think President Obama has done as effective a job as humanly possible in promoting a responsible agenda through Congress. But if you take something like reg reform—financial regulatory reform, not to use the jargon, it is mired in a series of intra-Congressional jurisdictional disputes over who would be in charge of this agency or that agency if you happen to pass something. It is a very broken system.

### Moderator
Claim: Eliot Spitzer.

### Scientific Advocate (SA)
Claim: Yeah, see Steve, we agree about the merits or demerits of “Obama’s Economic Polices Are Working Effectively” legislative branches, I think we would agree on that point clearly. Having said that… Having said that, the question is what role does the executive play in defining the parameters of the debate. When it comes to regulatory reform as it relates to financial services, the President did not strike a position, did not articulate a position that said very clearly, here’s where we must go, which is what FDR did. FDR rewrote the rulebook, this President unfortunately embraced the existing rule structure, moved jurisdiction around marginally without saying the fundamental predicate of the issue, too big to fail, must shift. He hasn’t yet done. Let me switch gears since you raised the metaphor of Albany. When we went to Albany, I did in fact on health care, fundamentally go to war with the entrenched interests about how health care would be delivered. We had an enormous battle, and we bent that curve in a very significant way. You can do it, it’s a question of articulating, drawing lines in the sand, you won’t win everything. The President has been admirable in many respects, but when it came to financial services in particular, he did not embrace the fundamental change that was needed.

### Moderator
Claim: There’s a gentle— Can you be brief, Allan?

### Scientific Advocate (SA)
Claim: Please. “Obama’s Economic Polices Are Working Effectively”

### Moderator
Claim: Very brief.

### Scientific Advocate (SA)
Claim: Leadership consists of getting people to do the things that they don’t want to do. It doesn’t consist of blaming the Congress, and blaming past administrations, for problems that were there, when you came in.

### Moderator
Claim: Gentleman with the yellow shirt in the dead center of the room.

### Moderator
Claim: Larry touched on this earlier, it would seem to me that, if you’re talking about Obama’s policies, you have to talk about not only the legislation that has been passed, but what is proposed. Small bus—and that would be including health care which is being debated now. Cap-and-trade legislation, the expiration of the tax cuts, the Bush tax cuts, and labor law changes including, a card check, and…the way you would adjudicate disputes between labor and management. Small business is going to—

### Moderator
Claim: Yeah, I need you to ask a question, sir.

### Moderator
Claim: Does anybody think this is going to have any impact, the overhang of these things on the creation of jobs going forward? “Obama’s Economic Polices Are Working Effectively” The uncertainties created and the costs involved?

### Moderator
Claim: Larry Mishel.

### Conspiracy Advocate (CA)
Claim: Well, I think that these kinds of policies are exactly what’s needed to build the economy we need to come out of this recovery. We need an economy which provides broadly shared prosperity, this is something that we haven’t had in 30 years. Prior to 2007 the prior 20 years or so, some 56 percent of all the income gains went to the upper 1 percent. That is not acceptable. It is also the predicate to the kind of crisis that we’ve had, because we can only have a robustly growing economy that’s sustainable if people are able to earn good wages and be able to spend based on those wages without going into debt or relying on asset bubbles. So I do think small business ideology says that these are not going to be good for them, but in fact it will be good for them, because it’s going to create a robust consumer economy that’s going to create a lot of different jobs, and that’s going to start benefiting everybody for once and for all.

### Moderator
Claim: Jamie Galbraith.

### Scientific Advocate (SA)
Claim: Well…I support health care reform, I support a strong energy and climate program, I support financial reform considerably stronger “Obama’s Economic Polices Are Working Effectively” than the administration is proposing. I don’t think anybody argues, I don’t think the President argues, that those three things amount to an economic recovery program, sufficient to create let’s say three million jobs a year over five years, that’s not even close. That’s the issue that’s before us, have we done enough, are we doing enough to deal with the problem, that the population of the United States faces, answer to that question is, no.

### Moderator
Claim: Eliott Spitzer—

### Scientific Advocate (SA)
Claim: I would just add very quickly one footnote to that, it’s perhaps not a footnote, credit to small business is where we are stumbling most dramatically. You cannot get loans if you’re a small business owner or entrepreneur. The reason for that is that all the capital went to the megabanks, and what they’re doing with it does not permit small businesses to grow. That is the egregious macro-error that the administration’s making.

## Round 3

### Moderator
Claim: And the concludes Round 2 of our debate. And here’s where we are, we are about to hear brief closing statements from each debater, two minutes each, and it’s their last chance to change your minds, and as we’ve said all along this is a debate of persuasion, you have been asked to vote “Obama’s Economic Polices Are Working Effectively” before the debate began and you’ll be asked to vote again after the debate, the team that changes the most minds will be declared the winner and to remind you of the results of the preliminary vote, our motion is “Obama’s Economic Policies Are Working Effectively,” 32 percent of you are for this motion, 29 percent of you are against, and 39 percent are undecided. You’ll be asked to vote one more time, and that will decide our winner just a few minutes from now. But first, Round 3, closing statements, we’re going to begin with Jamie Galbraith, James Galbraith, economist and professor of government and business relations at the University of Texas at Austin’s School of Public Affairs.

### Scientific Advocate (SA)
Claim: Our side in this debate has presented an emphatic call for action. The other side has asked you to accept excuses. Excuses for the inadequacy of action so far. Maybe a little unfair but I know that tomorrow morning the Economic Policy Institute is going to issue with a broad coalition a major call for action. It’s exactly what we need, to deal with the gap in action today. Yes, the Congress is an obstacle. I worked for the Congress for 10 years, I know how difficult it can be. I was there though, in 1981 when Ronald Reagan rolled the Congress, and I would like to see once in my professional life, once in my life, for someone on our side to do the same. This is a dangerous moment. “Obama’s Economic Polices Are Working Effectively” The cost of inadequacy is extremely high. If the program falls short, then the political situation, the political momentum, will be lost. If people see results for the bankers, and not for themselves… they see recovery in the stock market, but not in the value of their homes, they will turn away from all sensible measures. It will discredit everything the administration is in fact trying to do. Can you err by doing too much, the prospect is extremely remote and if you did you could always pull back. It’s exactly the kind of boldness that is needed, to confront the situation that we do not have yet and that we could only hope will develop in the next stage of policy of this administration.

### Moderator
Claim: Thank you, James Galbraith. Summarizing for our motion, “Obama’s Economic Policies Are Working Effectively,” summarizing for this motion, Mark Zandi, chief economist and co-founder of Moody’s Economy.com.

### Conspiracy Advocate (CA)
Claim: Yeah, you know, to me, I think people lose sight of the severity of the situation that we’ve been in, the crisis that we’ve just gone through. The panic and the Great Recession, it truly, it is the longest deepest, broadest-based recession since the Great Depression, there’s no--all the statistics are very clear on that. And I think the administration has been thrust into this, in the middle of it, and has been all about trying to bring an end to that “Obama’s Economic Polices Are Working Effectively” crisis, to quell the crisis, to quell the panic, to bring an end to the Great Recession, and here we are, you know, nine months into this administration, and look. The panic has been quelled. We’re still nervous, we’re still cautious. We haven’t gotten our groove back. But, just think where we were, the Great Recession is over. The Great Recession is over, yes, it’s not fully engaged. Businesses went through near-death experiences, they’re not going to forget that and step out and start hiring immediately, you know. Policy isn’t magic. It’s not magic. But the recession is over and we’re moving in the right direction. Now. It’s fair to say that we need to do more. Absolutely. You know, but the proposition is, are the Obama administration’s economic policies working effectively, working. No one’s saying they’ve worked, that we’re done, that this is a work in progress, that the script hasn’t been written, and the administration as got a range of policies that it’s put forward, tough policies on difficult issues, things that we hadn’t been able to address, health care, financial regulatory reform, energy policy, tax reform, a budget deficit that’s been a problem for many, many years, and look, we’re starting to discuss it and that to me is proof positive that, they are working and we’re working in the right direction. Thank you.

### Moderator
Claim: Good—thank you, Mark Zandi. Making his “Obama’s Economic Polices Are Working Effectively” summary statement against the motion, Allan Meltzer, university professor of political economy at Carnegie Mellon.

### Scientific Advocate (SA)
Claim: The subject is, are we… working, is this administration’s program working. The forecasts for the future, this is the 12th I think recession in the post-war years. We recovered from most of them. Most forecasts for the future say, the unemployment rate is going to stay up in the 10 to 11 percent range for a couple of years now. That’s not what I call working. The banking system, the financial structure, is unreformed. In addition to that, something we haven’t talked about, the administration has made threatening moves in the trade area. The World Trade Organization produced the greatest growth in world history, more people, in more countries, had their living standards raised by larger amounts in the post-war years, than at any time in mankind’s recorded history. They did that by reducing tariffs. The administration has increased tariffs on tires, steel pipes, next coming, coated papers, and other items. China is retaliating, by putting restrictions on auto imports. That’s a disaster. A bad policy. Not a policy that is going to produce growth in jobs and improvements in the United States. It’s a policy which is going to make the world poorer.

### Moderator
Claim: “Obama’s Economic Polices Are Working Effectively” And, summarizing for the motion, “Obama’s Economic Policies Are Working Effectively,” Larry Mishel, president of the Economic Policy Institute.

### Conspiracy Advocate (CA)
Claim: If the future is grim…and I agree with Allan Meltzer that in fact there is going to be persistently high unemployment, that’s unacceptable. Is that the Obama’s administration fault? Is that the fault of the kind of policies that actually Allan himself and conservative allies have advocated for many different years. To my liberal friends… What— I’ve said that there was an apartment building on fire, and Eliot says, well maybe there were some fire trucks in the next county that could’ve actually helped put out the fire, in fact, I can tell you that he hasn’t named any other county which had the fire trucks, and what they would do, or said how they would get around the roadblock of the Republican moderates in the Senate that actually blocked an even more effective stimulus that was actually on the table. In my view, there’s been, and I have not been an Obama supporter from day one of that campaign, I’m far from in the bag for the Obama administration, I’m to the left of the Obama administration, okay? I’ve been surprisingly pleased, much more pleased than I ever thought I would be by the direction of what they did with the recovery plan, “Obama’s Economic Polices Are Working Effectively” much larger, well-designed in terms of putting out some money early that got things going. Some back-end public investments for energy alternatives, infrastructure, science, training, education, et cetera, I think very well-designed and smart. A lot of their other policies are directly on target, they’re trying to do big, bold things. I’m quite surprised and quite pleased, you should be as well.

### Moderator
Claim: Summarizing against the motion, Eliot Spitzer, former governor and Attorney General of New York.

### Scientific Advocate (SA)
Claim: Well first of all, thank you all, this has been spirited fun and we probably disagree less than some of the rhetoric tonight would suggest but let me say this, I’m tired of hearing blame pushed to Republicans in Congress. We as Democrats have a majority in both houses, it’s about time we used them. It’s about time we stood up and used our majority. It can be done, and we should do it. Let me tell you where the fire trucks are, the fire trucks are the billions, hundreds of billions of dollars that were given to the wrong banks for the wrong reasons, that were not used to invest in the infrastructure, to invest in jobs, in mortgage reformation. That could’ve had a fundamental effect on our economy and that’s what we should have done. The fire “Obama’s Economic Polices Are Working Effectively” trucks take the form of not demanding reform of those who received the money. Not making them pay for the benefit of receiving tax dollars in return for a reformed regulatory structure, and the fire trucks take the form of not investing in jobs for the future. I am worried, I think Mark is exactly right. Some of the nervousness is gone. The nervousness is gone primarily because of what the Bush administration did, pushing a lot of money to the banks. That wasn’t the Obama administration. But precisely because the nervousness is gone, the moment for the fundamental reform we need is passing. And rather than galvanize that urge for reform, rather than push for the fundamental reform that we need in terms of jobs, investing in education, investing in health care, driving up the average wages of workers, the administration is reinvesting in the status quo, primarily a financial services sector, based upon the incorrect but maybe it’s a benign interpretation, the incorrect belief that putting the money there will generate the jobs. As I said, those manufacturing jobs will not come back, General Motors today said, they don’t anticipate hiring more workers in the United States. Overseas they will. So yes, Steve, we agree, we needed a bailout, but that’s not where jobs are coming from, jobs will come from small-medium business, banks should lend to them but the banks that would lend to them don’t have the capital, because all the capital went to the megabanks that are not going to lend to “Obama’s Economic Polices Are Working Effectively” them anyway. That was the critical mistake. Thank you all for being here.

### Moderator
Claim: Finally summarizing for the motion, Steve Rattner, who led the administration’s efforts to restructure the auto industry.

### Conspiracy Advocate (CA)
Claim: So Eliot, let me see if I have this right, the mistake we made was quenching the fires of financial crisis which took away the urgency to do anything about it so we should restore the financial crisis so there is some desire to do something about it, is that right?

### Scientific Advocate (SA)
Claim: Use it properly. A crisis is a terrible thing to waste—

### Conspiracy Advocate (CA)
Claim: My— Wait a minute, wait a minute, I—

### Moderator
Claim: That is really against the rules—

### Conspiracy Advocate (CA)
Claim: This is my chance to—

### Moderator
Claim: There is two minutes—

### Conspiracy Advocate (CA)
Claim: —to have a last word without you saying anything. So I want to “Obama’s Economic Polices Are Working Effectively” say that the only systemic authority that the federal reserve would’ve had to bail out Lehman Brothers, would’ve been to bail out Lehman Brothers exactly what you don’t want to have happen, so there was no authority to deal with Lehman Brothers. One more comment to you before I leave you alone for a second, this idea that we have—and to Jamie as well—the idea we have a majority in Congress, yes, we have a majority in Congress, it is very much in name only. We created, our political leaders, a big tent in order to have those majorities. That tent spans a lot of ideologies and it is very difficult to marshal majorities let alone the 60 votes you need in the Senate where there are two independents, to get something done, and you guys make it sound easy, it is not, it is not easy, you make everything sound easy, you tell us— You know, just wave your magic wand and you’ll have financial regulatory reform, it’s not that easy. You’ve also set up a false dichotomy, you’ve said that, you’ve raised this question of whether or not we should have more action, of course we should have more action, we all agree that we should have more action. The question is, what is responsible, how do you get it done, and what makes good sense. And I would argue what I said before, I won’t repeat it all, that this administration’s put forward responsible policies in every area. Is financial regulatory reform is it what I would do or what Eliot would do, left to our own designs, no. But is it something “Obama’s Economic Polices Are Working Effectively” that they spent a lot of time vetting with Congress people to try to come up with something that had a change of passage so that we would actually get something done as opposed to getting nothing done, it’s back to Larry’s don’t let the perfect be the enemy of the good. They did, and they have something out there, they have walked the walk, they’ve talked the talk. And what I frankly have heard tonight from the other panel, is, let’s just go do it and let’s pretend we’re at the Aspen Institute or the Brookings Institution, it’s just not how it works.

This is my chance to—

My— Wait a minute, wait a minute, I—

So Eliot, let me see if I have this right, the mistake we made was quenching the fires of financial crisis which took away the urgency to do anything about it so we should restore the financial crisis so there is some desire to do something about it, is that right?

### Moderator
Claim: And, that concludes closing statements for this debate. And now it’s time to learn which side argued best, who are our winners, we’re going to ask you one final time to go to the keypad on your seat, and vote. Press 1 if you are for the motion…2 if you are against, and 3 if you are undecided, our motion, “Obama’s Economic Policies Are Working Effectively,” and we get the results very quickly, they’ll be here instantaneously, just a couple of things. Our winner tonight of Quote of the Night, Mark Zandi, “Policy is not magic.” Congratulations to you. Just the yawner. Just the yawner. I want to thank—I really do want to thank the audience, and especially our panelists for a very spirited debate if we could give them a round of applause. Our next debate will be Tuesday, December 1st, our “Obama’s Economic Polices Are Working Effectively” motion is “America is to Blame for Mexico’s Drug War.” Panelists for the motion are Andrés Martinez, he’s director of the New America Foundation’s Bernard L. Schwartz Fellows Program, Jeffrey Miron, a senior lecturer and Director of Undergraduate Studies in the Department of Economics at Harvard, and Fareed Zakaria, editor of Newsweek International. Against the motion, Jorge Castañeda, the former Foreign Minister of Mexico, Chris Cox, the Executive Director of the NRA Institute for Legislative Action, and Asa Hutchison, a former Congressman and administrator of the DEA. Tickets are still available for this on our website and at the box office here at the Skirball Center. All of our debates will continue to be heard on more than 200 NPR stations, and that number is growing all of the time, across the country. You can also watch these fall debates on the Bloomberg Television Network, and you can check for airdates and times in your local directory. Do not forget, you can read about today’s debate in next week’s edition of Newsweek, and there’re copies in the lobby that you can pick up on your way out. All right, it’s in now, I have been given the final results. And I want to ask you as I read the final results, I’ll raise my hand as a gesture to you to please applaud for the radio audience. Remember the team that changes the most minds here is declared the victor and here’s how it breaks down, before the debate, our motion, “Obama’s Economic Policies Are Working “Obama’s Economic Polices Are Working Effectively” Effectively,” 32 percent were for the motion, 29 percent were against, and 39 percent were undecided. After the debate, 46 percent are for the motion, 42 percent against, 12 percent undecided, the side for the motion wins, our congratulations to them and to everyone who took part, from me, John Donvan. Goodbye from Intelligence Squared US.
