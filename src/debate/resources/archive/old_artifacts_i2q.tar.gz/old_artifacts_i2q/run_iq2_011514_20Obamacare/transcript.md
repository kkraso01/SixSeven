# Debate Transcript

Topic: Obamacare Is Now Beyond Rescue
Motion: Obamacare Is Now Beyond Rescue

Debate ID: 011514%20Obamacare


## Round 1

### Moderator
Claim: And to introduce the gentleman who makes Intelligence Squared U.S. possible, Mr. Robert Rosenkranz. Thanks, Bob. All right, Bob. So normally I-- the question is why are we doing this debate now? And that's pretty obvious, so I'm going to move in a different direction somewhat tonight. Since we're doing a debate about-- essentially about health insurance, as it turns out insurance is your business.

### Moderator
Claim: It's my day job.

### Moderator
Claim: It's your day job, and so we want to take advantage of that and just take a minute or two, a little insurance economics 101, to talk to us about, you know, not from the point of view of the consumer who does know their experience of insurance, they pay for it, they pay a premium, they got their coverage, from the other side, how does the business look at it?

### Moderator
Claim: Okay. Let me start with an analogy. If you go to buy a car, the car dealer knows exactly what that car cost him and, therefore, can charge you a price that reflects that cost plus profit.

When you're buying car insurance, the insurance company does not know how much it's going to cost, how many accidents you might have or what the cost is fixing them. So the insurance company is setting a price tag, but they have to make an intelligent guess about what their future losses are going to be. And in the case of car insurance, for example, an intelligent guess is that young drivers are going to have more accidents, that cars that are poorly maintained are going to have more accidents, et cetera, et cetera.

And the pricing reflects that. Young drivers pay higher premiums because historically they are not as good at, say, driving.

### Moderator
Claim: So how does health insurance work in that sense ?

### Moderator
Claim: Well, it works in a kind of odd and perverse way, because we have as a matter of public policy wanted to see that everybody pays the same premium for health insurance. But there are obvious differences. I mean, health insurance is going to cost much more for older people than it costs for younger people. So by having this idea that everybody should be paying the same, you're in effect having young people overpay a lot and older people get a great bargain.

### Moderator
Claim: Now, there's a term that I think is important, and I'm sure it's going to come up tonight in this health care process of adverse selection, which is something that the business side sees as a bit of a nightmare. What is that?

### Moderator
Claim: Well, the idea is as an insurance company you want to underwrite—or set your price based on what you think are the characteristics of a large group of people, can't predict when John Donvan's going to have an accident, but you can predict whether hundreds of people like you might have an accident.

### Moderator
Claim: And it's a set group.

### Moderator
Claim: Well, that's kind of the point, is that a group of young people is going to have a different experience than a group of old people. And a group of sick people is going to have a very different experience than a group of well people. So as an insurance company you're providing insurance for individuals, you have to be sure or at least have a good reason to think that the individuals who show up to sign up for this insurance are a representative sample, that you're not just getting the bad risks.

And that's why, for example, this idea of preexisting conditions, which sounds kind of cruel, that insurance companies would evaluate coverage for my preexisting condition. But if they didn't have that rule, nobody would buy health insurance except when they get sick and then they rush to buy it. So taking that idea to the rollout here of Obamacare, part of the implication of difficulties of signing up is that the people who are most motivated, mainly older and sicker people, will run that gauntlet. The people who need the insurance less are finding it overpriced, like young healthy people, will not go to that trouble. And that's what's meant by adverse selection. And if I were the insurance companies on these exchanges I would be very worried about that right now.

### Moderator
Claim: Well, it's a term we're going to be hearing in the debate tonight. And you've given us some good 101 basics to help understand it. Thank you very much, Bob Rosenkranz. And let's bring our debaters to the stage. So several times throughout the evening I'm going to again for the sake of the radio broadcast request your entirely spontaneous applause.

And this is one of those times, but I'd actually like to make it a round of applause, again, for Bob Rosenkranz for bringing this to us. a glitch is just a glitch. Your computer program locks up. You close it down again. You open it up again, and you move on because it was just a glitch. So the president's health insurance program, the Affordable Care Act, launches fall 2013 with some problems, problems with the software, problems with deadlines, problems with public expectations. So what are those? Are those just glitches or are we, as some have argued, actually looking at the blue screen of death for Obamacare? Well, that sounds like a debate. So let's have it, "Yes," or, "No," to this statement, "Obamacare is now beyond rescue," a debate from Intelligence Squared U.S., I'm John Donvan. We are at the Kaufman Music Center in New York, and we have four superbly qualified debaters, two teams of two, who will take opposite sides on this motion, "Obamacare is now beyond rescue."As always, our debate goes in three rounds, and then the audience votes to choose a winner, and only one side wins. Our motion, "Obamacare is now beyond rescue," let's meet the team arguing for that motion. First, ladies and gentlemen, let's welcome Dr. Scott Gottlieb. Scott, you have been a practicing physician, you're a former FDA deputy commissioner, you have said in the past that Obamacare is looking more and more like Medicaid, which is an interesting comment because during the Bush administration you were actually a senior advisor to the Medicaid program. So what we're trying to understand is when you say that Obamacare is looking more like Medicaid, is that a compliment or the reverse?

### Conspiracy Advocate (CA)
Claim: Well, it’s the reverse, it’s a problem. Medicaid's quite literally obligating the poor to indecency in seeking medical care and poor health outcomes.

### Moderator
Claim: Thank you very much, Scott Gottlieb. And, Scott, your partner is?

### Conspiracy Advocate (CA)
Claim: The always provocative Megan McArdle.

### Moderator
Claim: Ladies and gentlemen, Megan McArdle. Megan, you are also arguing for this motion, "Obamacare is now beyond rescue." You are a columnist for Bloomberg View. You are author of the forthcoming book, "The Up Side of Down, Why Failing Well is the Key to Success." And given the start to healthcare.gov, which had some failures in its first week, does that mean it had some-- that was good failure or bad failure?

### Conspiracy Advocate (CA)
Claim: Well, the reason that I wrote the book is that I think the key to succeeding, to find out what works. And the best way to find out what works is to fail and find out what doesn't. And I would say we are finding out what doesn't work.

### Moderator
Claim: All right, thanks, ladies and gentlemen. Megan McArdle, ladies and gentlemen. Our motion is, "Obamacare is now beyond rescue." We have two debaters arguing against this motion. First, let's welcome, ladies and gentlemen, Jonathan Chait. you are a daily columnist at New Yorker magazine. You write political commentary for its website and also for the print magazine. You have written on numerous occasions, you've made this point that the law that President Obama eventually signed off on is essentially based on a moderate Republican health care plan. And you used Romneycare as an example of that. So if that is true, what explains why the Republican party is now so vociferously against Obamacare?

### Scientific Advocate (SA)
Claim: Well, the vast majority of them really don't know what the law does. They're not policy wonks, and when Mitt Romney said he was for it, it sounded like a good solid Republican idea. When Barack Obama said he was for it, then it became a Socialist plot to destroy America. And if you don't know what's in the law, that's a pretty sensible way to think about what the law does.

### Moderator
Claim: All right, we see how you're thinking. Jonathan Chait, ladies and gentlemen. And, Jonathan, your partner is?

### Scientific Advocate (SA)
Claim: Doug Kamerow.

### Moderator
Claim: Ladies and gentlemen, let's welcome Dr. Douglas Kamerow. And, Doug, you are also arguing against this motion, "Obamacare is now beyond rescue." You are a family doctor. You're a specialist in preventive medicine.

You spent 20 years in the U.S. Public Health Service, working on a range of issues, clinical research policy, and reached the rank of assistant surgeon general. You have a book a while back, “Dissecting American Health Care," and you started your chapter on health care reform by saying, quote, "Health is a blessing that money cannot buy." So why, Doug, are we talking about dollars this year?

### Scientific Advocate (SA)
Claim: I think the reason, John, is because though health can't be bought, health care is a big business.

### Moderator
Claim: Well, ladies and gentlemen, Doug Kamerow. And let's welcome our four debaters. Now, this is a debate. It's a contest, a contest of wits, and logic, and humor, and ideas, and insight. It's competition, and by the time the debate has ended, we will have one side winning and one side losing and that is determined by a vote of you, our live audience, here in New York. We have you vote twice, once before the debate and once again after the debate, and the team whose numbers have changed the most over the course of the evening will be declared our winner.

So let's go to our preliminary vote. Go to those keypads at your seat. We're going to register you-- we're going to register your opening positions as members of this audience on this motion: Obamacare is Now Beyond Rescue. If you agree with that statement, push number one. If you disagree, push number two, and if you're undecided, push number three. I see a lot of people staring at the graphic on the screen as they push the button. That is not meant to be a subliminal suggestion. It's meant only to be provocative, but not to sway your vote. All right. So we're going to lock out the votes, and I'll remind you again. After the arguments, which go three rounds, we will have you vote a second time and we'll very quickly get the results and find out who, in your view, won this debate.

So on to round one. Round one. Opening statements by each debater in turn. They will be seven minutes each maximum. Speaking first for the motion: Obamacare is Now Beyond Rescue, Dr. Scott Gottlieb. He is a resident fellow at the American Enterprise Institute and former FDA deputy commissioner for medical and scientific affairs, ladies and gentlemen, please welcome Dr. Scott Gottlieb.

### Conspiracy Advocate (CA)
Claim: When it comes to Obamacare most of the focus is on the broken website and the problems enrolling people into the coverage, but the real failures of this plan go well beyond the internet. They’re imbedded in the structure of the law and they’ll become more acute as this scheme unfolds. Obamacare rests on some deeply flawed concepts that turn the proposals against the legislation’s own laudible goals. Simply put, it’s a plan at war with it’s own ambitions. And tonight I want to briefly address some of the paradoxes embedded in this law.

First, Obamacare seeks to lower the cost of health care, but instead it creates new arrangements that will only make medical care more expensive. A big reason is provisions that deliberately force doctors to consolidate their medical practices around hospitals. Having doctors work for hospitals is often the costliest way to deliver care, and we know there's a lot of excess capacity in hospitals. We've basically built in a subsidy of that excess capacity. And we also know that there's ample evidence that when physicians become the employees of hospitals and hospital-owned systems, productivity falls. And when hospitals buy up local physicians in a community, enabling them to exercise monopoly pricing power, they raise prices. Second, the law seeks to increase competition between insurers it’s partly seen as a way to lower costs, but Obamacare will actually reduce the number of health plans in the marketplace and leave you with fewer choices. For one thing, Obamacare taps the operating margins of health plans. This basically protects the businesses of incumbent insurers at the expense of new start-ups and new entrants.

Obamacare also uses regulation to prescribe a single uniform benefit package. The result is that consumers are left with just one option when it comes to the benefits they can choose from. Go on the website and take a look for yourself and I'm putting out some data on this next week. If you look at the health plans that insurance companies sell on the exchanges, the provider networks and the drug formularies are exactly the same. It doesn't matter if you buy a plan that's a bronze plan, a gold plan, or a platinum plan. By buying up to a costlier plan, all you're doing is lowering your co-pays and deductibles. In other words, you're just fronting a higher premium to buy down your out-of-pocket costs. There is no competition between these plans based on benefits or networks. There is no real choice in these exchanges. Third, Obamacare is aimed at reducing the number of uninsured Americans, but the vast majority of the uninsured who get coverage under this scheme will end up on Medicaid.

And so what about the people who sign up for private coverage in the Obamacare exchanges? They're going to mostly be people who were previously insured in the individual or small-group markets and got moved into Obamacare, some of them forcibly. But don't take my word for this. Look at the numbers being put out by the administration. The White House says that 19 million people will be added to Medicaid. That's a 35 percent increase in the size of the program, but at best, five million people will get Obamacare coverage this year and it's probably going to be closer to four million. But we know at least five million people lost their policies when the mandates of this law were imposed on a private market and insurers had to drop old plans to conform. And as for the uninsured, the lower middle class folks, for people above 200 percent of the federal poverty level, family of four earning about $50,000 a year-- Obamacare is still too expensive for them, even with the benefits and the subsidies.

And so, a family of four earning $50,000 a year will have to pay $400 a month, even after the subsidies, to buy that coverage. That's $5,000 a month. And they're getting a plan with a $3,000 deductible. The problem is that's not a good plan for that family. And the problem is that these plans were designed in Washington to meet political aspirations rather than marketplace, to meet the demand of what consumers needed. And think about this. There were 46.3 million uninsured in 2008, when President Obama took office. This year, there were 48 million uninsured Americans. The only way the president is going to leave office with fewer uninsured Americans than when his term began is by obligating more people to Medicaid. Obamacare is really a Medicaid law. And so, it begs the question, what about Medicaid? There is now ample evidence in the clinical literature that people on Medicaid are experiencing worse health outcomes than people in other insurance schemes. And sometimes even in the uninsured. Simply put, reimbursement rates have been driven so low in the Medicaid program that folks can't get access to the benefits that they're promised on paper.

I don't consider it successful if the only way we reduce the roles of the uninsured in this country is by obligating more Americans to a Medicaid program that is quite literally worsening medical outcomes. This doesn't seem moral. Yet Obamacare does almost nothing to fix that Medicaid. It just pushes more people to an already failing system.

In many ways, these problems that plague Medicaid will also plague Obamacare. Obamacare makes so many costly promises on paper, but the only way to pay for these commitments is to reduce what providers are paid. And Obamacare, this is now a network that contains a very short list of providers and closed drug formularies that leave key medicines uncovered. And the Obamacare regulations don't just apply to the Obamacare plans. This is a federalization of all insurance in this country, so everyone's benefits need to conform to the single, uniform national standard. Obamacare was a response to a flawed healthcare system. There's no question about that. But it makes things worse. It reduces choice and competition in health plans.

It increases costs by reducing the productivity of the practice of medicine. And finally, it only reduces the number of uninsured by obligating millions of more people to a Medicaid benefit that's quite literally harming people's health. In all of these ways, Obamacare works again its own laudable intentions. There are far better ways to address issues of the uninsured in this country and far better ways to address the issues of those who are priced out of the insurance market. For all these reasons and more, Obamacare is now beyond rescue. Thanks a lot.

### Moderator
Claim: Thank you. Scott Gottlieb. And that's our motion: Obamacare is now beyond rescue. And here to speak against this motion, Dr. Douglas Kamerow. He is a Professor of-- I'm sorry. I just want to pronounce your name correctly. I'm going to get it right this time. Dr. Douglas Kamerow. He is a Professor of Clinical Family Medicine at Georgetown University and Chief Scientist of Health Services and Policy Research at RTI International. Ladies and gentlemen, Dr. Douglas Kamerow.

### Scientific Advocate (SA)
Claim: Thanks, John, and thanks for inviting me. The motion that you've heard is "Obamacare is now beyond rescue.” What you heard Dr. Gottlieb argue is not that it's beyond rescue, it's that he doesn't like a lot of the provisions of the law. What we're here to discuss, it seems to me, is what has been in the proposed. And the proposed was either Obamacare is now beyond rescue-- meaning it's not doing what it was supposed to do - - or it is not beyond rescue, and therefore it is doing what it can do. My partner, Jonathan Chait, and I will argue that not only is this law not beyond rescue, it doesn't need to be rescued because the law already has worked and is working. And to understand whether it's working, we need to understand where we were before the law was passed and what the goals of the law were. I'll cover that. And Jonathan will also discuss the achievements of Obamacare.

But he'll focus on criticisms and dire predictions of which we've already heard many from the opponents of the law. Speaking of the dire predictions, we'll come back to some of the ones we heard. But there are a few, I think, that we'll have to deal with sooner rather than later. Let me first turn to the question about Obamacare and what it does. It's an insurance law, but of course it includes cost controls and quality improvements as well. I want to focus on the insurance stuff, because the question occurs, why is health insurance important? There are a lot of studies that show a lot of reasons for it. Some include showing that kids who have healthcare insurance are less likely to miss their shots. And if they don't have insurance, they're more likely to miss them. Healthy adults without insurance tend not to get mammograms and other preventive services that they need. People who have diseases such as diabetes and hypertension and they don't have insurance do poorly.

They tend to be more out of control, and if they have bad outcomes like strokes, they tend to be more severe. But just as important in terms of outcomes besides health, people who have no insurance and have a serious health problem can be bankrupted by it in this system that we had until very recently. This led a group at the Institute of Medicine in a big report to say that a lack of health care insurance results in needless illness, needless suffering, and needless death. Let's turn the clock back a little bit to 2008, 2009 when this law was being debated. At that time, we had 40 to 45 million people uninsured. We were spending two and a half trillion dollars a year on health and health care and growing, and we had some of the worst statistics for health outcomes in the developed world. In addition, most of the insurance products that we saw at that time didn't have portability. If you lost your job, you often lost your insurance. You didn't have guaranteed issue, so if you had a preexisting condition and tried to get health insurance and you're not in a big group, forget about it.

And there were no national standards for insurance policies. We were largely-- not exclusively, but we were largely in a fee for service system with incentives really pushing towards more care, not better care, not the appropriate care, but the more you did, the more you got paid. And so it was estimated at that time that unnecessary care could've been 10, even 20 percent of the money that was being spent. And equally important were the projections-- and this is just now four years ago-- the projections of where we are going to be by 2018, which is just four years from now, if nothing had been done, over 60 million people uninsured at that point, health care spending going from trillion to $4.7 trillion a year, family health care premiums going up from $13,000 to average 30,000 a year, Medicare trust fund runs out of money, and no change in that fee for service culture that pays for more medicine, more health care, and not necessarily better.

So in March 2010, which is now almost four years ago, we had this law signed, Obamacare, the Affordable Care Act, ACA, hugely complex, admittedly, admittedly imperfect law, but not just insurance quality improvement, cost reductions. What are some of the things that have happened in the first three years of this law? Young adults 26 and under now can get coverage on their parents' policies, and three million have. Preexisting conditions not allowed to prevent coverage. There's portability of insurance coverage, no lifetime caps, community rating, which means if you're in a small business, one person gets very sick or their family member does, it doesn't raise the rates for everybody. No lifetime caps on coverage, lots of stuff, and in some ways very importantly, no copays, no deductibles for preventive care that's evidence based.

Also, cost related things, we're now paying hospitals for outcomes and not the services they deliver. There are penalties for hospital readmissions when someone's discharged and then readmitted to the hospital soon afterwards. Something called accountable care organizations are getting paid for performance rather than piecework, and there are many experiments and demonstrations from part of the government now called the Center for Medicare and Medicaid Innovation. Importantly, cost reforms have slowed down cost dramatically. That is, the increase per year is just an average of 1.1 percent in the past three years, 2010 to 2012. So in summary, before this year, before anything that's been controversial in the news happened, there are already a lot of good things that are going on because of Obamacare. Then we come to October 2013. Everyone knows, what a disaster. Okay? People can't sign up. The computer systems don't work. The website's a mess. There's lots of confusion. Some provisions of the law were postponed.

But even conceding that all this was a mess, let's look what's happened recently. Six million enrollees, two million in exchanges, 4.4 million in Medicaid-- we'll come back to Medicaid-- people up to 400 percent of the federal poverty levels are getting subsidies to help pay for insurance, and cost increases continue to moderate . Let me conclude now by asking you to remember where we were, where we've been, and where we are now. I want to quote from a mock interview that was in one of my favorite newspapers, a satirical newspaper called The Onion. The headline was, "Nation Recalls Simpler Time When Health Care System Was Broken Beyond Repair." Here's the quote, "Back then, if you couldn't afford health care insurance and got really sick, you went bankrupt, plain and simple," said a Modesto , California, mother of three. "You didn't have this whole mess of lower cost options or all these subsidies you might or might not qualify for based on your income.

People didn't have to deal with any of that stuff and those headaches, just went ahead and died of preventable causes."

### Moderator
Claim: Douglas Kamerow, I'm sorry, your time is up. Thank you very much. And here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two against two, arguing it out over this motion, ""Obamacare is now beyond rescue." You have heard two of the opening statements, and now on to the third. Let's please welcome Megan McArdle. She is a columnist for Bloomberg View and author of the forthcoming book, "The Up Side of Down." Ladies and gentlemen, Megan McArdle.

### Conspiracy Advocate (CA)
Claim: To hear Doug Kamerow describe it, it's amazing, and I want to sign up. But, you know, these debates often tend to sort of devolve into "Who doesn't want people to die?"So that's not actually what's on the table here. The issue is not "Are Democrats Socialists? Are Republicans stupid and venal and terrible people?" The issue is, "Is this law, Obamacare, accomplishing what it set out to do? Is it making Americans better off, and can it survive in its current form?" As you listen to the administration, it's impossible for Obamacare to fail because every time they don't hit some number that they've been promoting, they just change the terms and redefine its success as whatever's already happened. So, for example, just a few months ago, Kathleen Sebelius, who's the secretary of Health and Human Services, was saying that success in the exchanges was seven million people signed up by March 2014. And then they had a few problems with the exchanges, and then suddenly success wasn't having seven million people signed up, success was having a healthy demographic mix in the pool-- in the insurance pools on the exchanges.

Then they said that we got-- needed about 40 percent of the people to be young adults, which is between the ages of 18 and 35. And then we got some data on the demographics. And so far about 20 to 25 percent of the people who've signed up are young adults, and we got many more old people than we expected, which, for a few reasons that should be fairly obvious, could make insurance cost a lot more than we were hoping, so in the most recent conference call, they said that success would be signing up as many people as possible, which is this beautifully circular reference, right, of however many people you've signed up is the number that was possible. It's the self- licking ice cream cone of policy programs. But for the rest of us, I don't think it's enough for Obamacare to merely exist. It has to actually do something and do something that we want. So what did we want? What were we promised? We were promised lower costs for government and individuals, and we've heard some of that.

The administration likes to claim that this has already happened. This hasn't. Health care cost growth has indeed slowed, but health care cost growth started slowing in 2004 when Barack Obama was a junior state senator from Illinois. He had not even been elected to the U.S. Senate, much less to the presidency. You see a big decline in 2005 to 2007-- in 2003 to 2005, another between 2007 and 2009, but it actually leveled off in 2010 right when Obamacare comes in and cost growth is kind of bumping along if you look at the OECD figures on that. Kaiser projects-- you remember we heard that the average family was going to save $2,500 a year on their premiums? That didn't happen. Kaiser is now projecting that premiums will go up. We wanted people to get healthier as a result of this law, but then we got the Oregon Medicaid Study, which is the gold standard in studies of Medicaid, and it looked at the three things you really want to look at, in preventative care, it looked at hypertension control, cholesterol control, and it showed no statistically significant results.

More than half of the expansion in Obamacare comes through Medicaid. We wanted people with preexisting conditions, all of these millions of people with preexisting conditions we were told were out there to be able to buy insurance. But when they set up pools in order to cover people with preexisting conditions, they were expecting to get 400,000 people between 2010 and 2013, instead they got a quarter of that number, and they only managed to get that by lowering their requirements and doing an aggressive outreach campaign to sign more people up. And we wanted expanded health care coverage, right? But at this point, we can't even say that there are more people insured right now than there were on January 15, 2013. We-- the administration says that there have been four million people added to Medicaid, but half of those people came in states that didn't even do the Medicaid expansion. So definitionally they were already eligible for Medicaid. Of the other states, some of those people were already eligible or may even be renewing their coverage.

The administration can't even say that these are people who are getting new coverage. Some of them may just be going back on to Medicaid just like they were last year. We have 2.2 million people on the exchanges, but five million people had their policies cancelled. No one, I think, predicted that at this point this late in the game you wouldn't even know whether we've increased the insurance numbers and the administration refuses to certify that that is actually happening. Meanwhile, we were not supposed to hurt anyone who had insurance, right? If you liked your plan and you liked your doctor, you could keep them. We all know that that has not happened, so five million people have had their plans cancelled, and many people who are buying new plans are seeing that their doctors are not-- the best hospitals and doctors in their area have been kicked off the network in order to keep the premium costs down on the exchanges. So, it was also supposed to be really popular, , right? Because we had all of this great stuff, this giant Rube Goldberg apparatus layered on top. We didn't take anything away, we only gave.

And it's kind of time for a Dr. Phil moment, how is that working for you? Nothing is working the way the administration said. So you can say it does not really matter whether it is unpopular, right? The point is not to be popular, and yes, some people have gotten hurt, but you can't make an omelet without breaking eggs, right? It was never reasonable to think that everyone was going to get to keep the doctors and the plans that they wanted. Something had to change and this is a foundation for something better. But this foundation has so many cracks you cannot build a healthy structure on top of it. Just look at everything the administration has had to do in the last few months just to keep the law running. They had to delay the employer mandate and the enforcement, apparently because they couldn’t even figure out how to make this regulation work. It may never go into effect, which means we'll lose millions of people who were supposed to get coverage expanded through and the cost will go up to the government. They delayed the Spanish language website, and now apparently part of it is written in Spanglish. Despite the fact that Hispanics are a major constituency for insurance expansion. They delayed the small business exchanges.

They've allowed people to keep plans that were supposed to be illegal because they weren't real insurance Kathleen Sebelius told us. They've delayed deadlines over and over again. They've done all these things by asserting emergency powers by doing administrative fixes through executive fiat, and yeah fair enough, Obamacare is certainly an emergency, but all of these changes have had the effect of undermining and destabilizing the law that they think is so important. They’ve had to do these things even though they know it makes the insurance pools less actuarily sound, because they can't face the political backlash. And what happens when Republicans get into office and I assume they, too, think Obamacare is an emergency and could be fixed with some executive orders. Essentially they've made it so that Republicans can undo two-thirds of this law with a stroke of the presidential pen. Obamacare is Now Beyond Rescue. The administration has destroyed their own law in order to save it. Thank you.

### Moderator
Claim: Megan McArdle. And that is our motion: Obamacare is Now Beyond Rescue. And now to speak against this motion coming to the lectern is Jonathan Chait. He is a daily columnist for New York magazine. He's author of the book, "The Big Con: Crackpot Economics and the Fleecing of America." Ladies and gentlemen, Jonathan Chait.

### Scientific Advocate (SA)
Claim: Has anybody here ever renovated a house? I've done it twice. It was hell. Every day I went through brought fresh misery and fresh reason to think why am I doing this, but in the end it worked, and the reason it worked is because we know how to renovate houses, right? So when you hear about the problems that our opponents are describing in the law, they had to delay this, they had to fix this, the Spanish language website didn't work as well as they wanted the first day. You have to ask, are these things that are going to fundamentally destroy the law or are they the kind of problems you have in a renovation? They said, oh, we didn't quite get the counters we want. Oh, this went a little bit over cost. Well, then you have to ask-- to answer that question you have to ask what kind of endeavor is Obamacare?

Is the Obama administration trying to build a moon base? Is the Obama administration trying to build a thriving liberal democracy in a hostile Muslim country? No. What they're trying to do is build a national health insurance plan. Can you build a national health insurance plan? Well, every advanced economy in the world, except the United States, has built a national health insurance plan. All of those countries insure all their citizens and all of them pay considerably less than we pay here in the United States. So you’re a priori assumption has to be yeah, this is something you can basically do that the problems you have are not signs that everything is about to collapse onto itself, but the problems you have any time you go through any major project. So, what our opponents have been trying to do for months, and months, and months, actually is paint this picture where every time the contractor comes to you and says, "Oh, it turns out they don't have this color, oh, it turns out the plumber is unavailable on this day," it means the whole thing is going to collapse on its own.

But actually, nothing like that is happening at all. And there is no evidence that anything like this is happening. The main argument that the opponents have been making the entire time is that there is going to be a death spiral. That's the only plausible mechanism that they have, that the law will fail. A death spiral is a term that I expected them to talk about, because that's what they've been talking about for months. It's something they've barely invoked at all. And I think the reason is it's become clear, in recent days, that there's no chance of a death spiral in the Obamacare law. A death spiral is when you have too many old, sick people who drive up the cost, making the premiums more expensive, leading the healthy people to flee, driving up costs more.

That is theoretically possible, but is not something that can possibly happen in this law. In fact, if you want to say, "Is the law succeeding?" you don't have to ask the administration. You could ask the insurers, right? Because the insurers have recently been saying they're very happy with the mix of people-- the mix of people you have in the exchanges is sound. It's sustainable. They don't need-- they don't need it to change.

They've got a mix of people that's healthy enough to keep the exchanges going forward. What's more, even if you had more old people going into the exchanges than they expect, you had-- the Kaiser Health Foundation ran the numbers and said, "What's the worst-case scenario?" We don't get any increase in young people at all. And they said it would be about a 2.4 percent increase in premiums 2.4 percent increase in health insurance premiums. If any of you have ever had health insurance and you get a 2.4 percent increase over your bill last year, you'd say, "Thank God it's only a 2.4 percent increase," right? That's a rounding error. No one notices 2.4 percent. That couldn't possibly set off a death spiral. So there's really no plausible mechanism that the law could fail. So I think what they're giving you-- instead of what used to be the plausible mechanism for which the-- this can fail, they're giving you a mix of wishes and hopes and completely debunked facts. They said, "Cost growth leveled after 2010.” No. Cost growth in 2012 was lower than at any year in 50 years. And in fact-- this is important because when the law was passed, cost growth was the main thing they talked about.

Obamacare was supposed to control costs. And they said, "No, no, it's going to make costs explode with all this bureaucracy regulation. They're going to go out of control.” What happened is that cost growth came in way lower than the most optimistic estimates believed it would be before the law was signed. And so now, they're reduced-- instead of saying, "This disaster of cost growth is going to happen," they're going to say, "This incredible miracle of low cost growth is simply a coincidence.” So, all they're saying is essentially that this wonderful thing that's happened has nothing to do with the gigantic change in healthcare or that happened just before costs started going to the lowest level in 50 years. And you can't prove that it's not a coincidence. But you have to-- see, this is indicative of the mentality we're dealing with, where it simply moves from one possible disastrous scenario to another possible disastrous scenario.

So you have to wonder, "Why are they simple moving from one disaster scenario to another disaster scenario?"Actually, I wanted to debunk a couple points they made, because a lot of this is just-- we've heard from the other side-- are not true. I can't give you links and charts to debunk them, but let me say that it's not the case that 5 million policies have been canceled. That's a number that was floating about that you can't verify. It's almost certainly not true. Many journalists have tried to figure out exactly how many policies have been canceled. And they don't have good enough records to know, but they know it's not 5 million. And they suspect-- the administration suspects it's closer to one-tenth of that figure. They can't actually prove that either, but for various reasons, you don't have a good enough count. This-- that's almost certainly nowhere close to 5 million. And that's a big number that's-- they're citing because they're saying, that-- those are the losers. But it's really nowhere close to that. Yet they say-- Megan said we can't-- we can't say for sure how many-- how-- that there are more insured now than there were before. We can't say for sure, because again, this number can't exactly be counted. We don't know that 400,000-- it was 500,000. But we know it's not anywhere close to 5 million. And it's a mortal certainty that far more people have health insurance now than would have had in absence of the law.

So why are we having this kind of lurch, from one argument, abandoning these arguments when they disappear, and simply coming up with new ones? The truth is, they disagree with the goals of the law. And I think you could hear that in their remarks. They say, "There's less choice.” And it's true. The government says insurers have to provide certain benefits right. They have to provide pregnancy coverage. That's-- and maternity care. Those are the most controversial things that are mostly cited, because they want people who are male or old to not have to pay for those things. And they want people who are young and female and might have to bear children to pay those costs themselves, because that's an ideological difference between the two sides. And that's fine for them to have an ideological difference between the two sides. But we're not here to debate whether this law is a good idea. We're here to debate whether the law is actually working, and the truth is the only reason they're desperately trying to claim the law is not working is because they oppose national health insurance.

## Round 2

### Moderator
Claim: Thank you, Jonathan Chait. And that concludes round one of this Intelligence Squared U.S. Debate, where our motion is "Obamacare is now beyond rescue." And now we go on to round two, and round two is where the debaters address one another directly and they take questions from me and from you and our live audience. Now, I want to remind you that tonight's debate is being broadcast worldwide on our website, iq2us.org, and on FORA .tv, and if you're watching this live stream right now, we would like to hear from you. Send us your questions on Twitter or Facebook with hashtag Obamacare so that we don't miss it. Be sure to include your city, state, and first name. And if you're going to do that, what we really request from you is not a statement or an assertion of your views, but really a question that moves these debaters along on the motion, the specific motion of whether Obamacare is beyond rescue. Try not to be ideological. Try to be provocative.

So on into round two, and round two, as I said, is where the debaters address each other directly. The motion is "Obamacare is now beyond rescue." We have two teams arguing for and against that. The team arguing for the motion, Scott Gottlieb and Megan McArdle, have argued-- in a sense, they are arguing that the law from its beginnings has always been beyond rescue, that it reduces competition, it reduces choice, it pushes people into Medicaid, a system which does not have good medical outcomes, or at least not the kind of medical outcomes that people would aspire to for it. And they've described the law as a Rube Goldberg kind of apparatus and that the administration only gets away with calling it "successful" in any way by continuously moving the goalposts. Team arguing against the motion, Dr. Douglas Kamerow and Jonathan Chait, say, "Yeah, the law is not perfect," but they're arguing that it's working in real ways already, that there are more people insured now than there were three years ago in the United States, that standards are being forced, and that-- in general, that we've come a long way.

And they also argue that the terms of the basic law, the aspirations of the law, that lots of countries do it, and that, in fact, it does work. They argue that the opposition from their opponents is more ideological, that they just don't actually want the law to succeed, a question I'd actually like to put to the side arguing for the motion. Is that the case? Would you-- in an ideal world, would Obamacare succeed or would you hate that? Scott Gottlieb.

### Conspiracy Advocate (CA)
Claim: Well, look, I-- look, in a wealthy country, I think we need to address issues of people who are priced out of the market, people who have preexisting conditions and can't find coverage. I think there were far more efficient ways to do that. You could've given people incentives to get insured and stay insured, and it would have required that you subsidize certain people to get into the marketplace and subsidize them through transitions in life where they might otherwise not have the income and lose coverage. There's nothing inherently wrong with pooling people based on what state they live in, for example, if that's the point, if this is copying Mitt Romney's plan.

What's inherently wrong with this law is the way that the law tries to prescribe a uniform federal standard for what needs to be in everyone's insurance policy. And so these decisions get made in a political context, and you end up with policies that are exceedingly expensive, laden down with mandates that don't meet what consumers want. And then you tell insurers they can't underwrite risk, they can't use cost sharing as a tool to steer people to certain benefits or others, they can't change the benefit design, and so they're forced to do one thing which is to narrow the networks of providers that people have access to and to skinny down the drug formularies, which is exactly what we've done in Medicaid.

### Moderator
Claim: Scott, to the point of the motion and granting all of that, are you saying that, therefore, the law cannot work, that it's doomed to collapse in on itself--

### Conspiracy Advocate (CA)
Claim: It’s the structure that's inherently flawed.

### Scientific Advocate (SA)
Claim: Scott, can I ask a question? Scott, you're saying-- you're describing what you would have liked, but let's be real-- let's be realistic: if the choice is we have Obamacare now, it's a law, what are the chances of any kind of scenario that you're describing taking-- taking flight, passing both houses of Congress at any time in the foreseeable future?

### Conspiracy Advocate (CA)
Claim: I think that the problem is that the people in Washington-- progressives in Washington can't resist the temptation to tinker with every aspect of what the provisions are, and you end up with regulations that prescribe exactly what people have to have and don't have to have. Surgical sterilization is in. Certain things are out. You have a law that gets laden down with mandates and it ends up being-- exceeding expensive to provide this coverage to everyone, they have to do it, the insurers have to go after the network, exactly what we've done in Medicaid. We've promised a very rich set of benefits on paper in Medicaid. It looks like a fabulous program, but we know Medicaid recipients can't get access to the care. I don't think it's being done politically because it-- these decisions now are being made in Washington.

### Moderator
Claim: Jonathan Chait, do you want to respond?

### Scientific Advocate (SA)
Claim: Megan, answer the question

### Moderator
Claim: Yeah, Megan?

### Conspiracy Advocate (CA)
Claim: Oh, well, I would say that I certainly agree with Jonathan Chait, that this is going much, much, much worse than I thought, and there are all sorts of problems that I didn't anticipate. So to that extent, it's true.

I'm picking on stuff that I did not predict because my worries at the time of passage were about things like the federal budget deficit and would the cost controls hold. Will this tamp down innovation, which is, if you think about the millions of unborn or still living but not yet sick people who can be cured by innovations that haven't happened yet, I was worried about that. But we haven't gotten to the point where I can worry about those sorts of things. We've gotten to the point where I'm now worried that this is going to implode and destroy the market for insurance.

### Moderator
Claim: And by "implosion," you mean bankruptcy, you mean sick people-- sicker people than before?

### Conspiracy Advocate (CA)
Claim: I think that Jonathan is way more optimistic than I, that a death spiral isn’t possible. For one thing, you know, a lot of the-- the thing that everyone has been leaning very hard on-- I haven't heard the insurers saying that they are real pleased with the mix. Humana and other people have said it's more adverse than they expected.

### Scientific Advocate (SA)
Claim: No, at the JPMorgan Conference a series of insurers were interviewed, and they all said that they were generally expecting getting what they expected.

### Conspiracy Advocate (CA)
Claim: But that-- neither-- leaving that point aside-- well, I mean, like he can say, "Yes, they have," and we can say, "No, they haven't," and you guys don't know either way, so I think this is not--

### Moderator
Claim: Yeah, I'm actually with her on that. Unless-- were any of you at that conference?

### Conspiracy Advocate (CA)
Claim: I was

### Scientific Advocate (SA)
Claim: There were a series of insurers quoted at the JPMorgan Conference on January 15.

### Conspiracy Advocate (CA)
Claim: There were also a series of insurers quoted, saying that they've had adverse--

### Conspiracy Advocate (CA)
Claim: And they've announced--

### Conspiracy Advocate (CA)
Claim: That they're announcing earnings adjustments because of their adverse selection. But that's not really even-- the issue is that, you know, a lot of the mechanisms they're depending on are these things called these risk corridors, which are temporary kind of reinsurance facilities to help insurers transition, and also the fact that these subsidies basically grow with the cost of the policy so that if we do start seeing adverse selection, if we do see young people not in the pools, healthy people not in the pools and so costs go up, well, then the subsidies will rise and these risk corridors will kick in. But those things end in 2018. Subsidy--

### Moderator
Claim: All right, let's let Jonathan Chait--

### Scientific Advocate (SA)
Claim: Right, but what we're seeing right now is that they're not even going to need that kind of adjustment in the first place because they're saying the pool of people is young enough that it's meeting their expectations, that they don't need to raise premiums, whatsoever. And so if you want to-- if you have to ask, "What is the definition of success?" The definition of success is putting in place a law that will get at a certain point to having a dramatic expansion of coverage. So at one point you said, "Well, by January 1, there aren't as many people covered as there were before."

### Conspiracy Advocate (CA)
Claim: I said we don't know.

### Scientific Advocate (SA)
Claim: Right, we don't know.

### Conspiracy Advocate (CA)
Claim: The government will not--

### Scientific Advocate (SA)
Claim: You're right, you said-- that's correct.

### Conspiracy Advocate (CA)
Claim: --the administration will not say--

### Scientific Advocate (SA)
Claim: Right, we don't know exactly--

### Conspiracy Advocate (CA)
Claim: --that we have more people covered.

### Scientific Advocate (SA)
Claim: --right-- we don't know the number of people who had their plans cancelled. It's way less than five million. We don't know, so we can't say exactly how many But why is January 1, the first date the law started, the best mark? The law's supposed to--

### Moderator
Claim: Stop right there because I want to hear the answer to that question.

### Conspiracy Advocate (CA)
Claim: Well--

### Conspiracy Advocate (CA)
Claim: We know this pool is exceedingly unhealthy by virtue of--

### Moderator
Claim: No, no, no, that's-- his question is "Why set January 1 on the day that everything has to be successful?" It's a fair question. I just want to hear the answer to it. Megan, Megan.

### Conspiracy Advocate (CA)
Claim: totally fair question, but, again, this is so much worse than I would've predicted. I was a critic of the law, but if you had asked me, "Is it likely that there could be fewer people insured, even that small number, on January 1?" I would've said, "No, that's insane." But that may actually be-- the administration won't-- it's not asking them how many people. When reporters on conference calls say, "Can you assure us that more people are insured through anything, through private insurance, through Medicaid?" they won't say, "Yes."

### Conspiracy Advocate (CA)
Claim: What does it tell you that no-- people don't want this coverage. The administration on the conference call which I was on the other day, and announcing this data, bragged about the fact that 44.5 million people went to the website and started to look at health plans, we know only 1.2 million signed up, that conversion rate is worse than banner ads. It's worse than sex ads on Twitter.

I mean, that is a bad conversion rate. That tells you people are looking at these plans and not buying them because they're not good plans for consumers because they weren't designed to be.

### Moderator
Claim: Doug Kamerow.

### Scientific Advocate (SA)
Claim: I want to go back and ask the question to you all again, if, in fact, you're saying that Obamacare--

### Moderator
Claim: Doug, I just want to point out if you keep asking questions you don't get to talk.

### Scientific Advocate (SA)
Claim: Well, but, I mean, the point of the debate is to say that it's beyond-- you know, either it's beyond rescue or it's not beyond rescue. So you guys say can't be saved, can't be fixed. What's the plan then?

### Moderator
Claim: Well, actually they don't need to actually answer that question-- technically to win this debate.

### Conspiracy Advocate (CA)
Claim: But I will say that Mr. Chait says that I’m against national health care and which is actually not true. I have long been proposing that the government should provide catastrophic reinsurance for people, basically picking up medical costs above fifteen percent of their income. It’s something that preserves the market mechanism. It’s progressive.

Everyone is-- you know, you're taking care poor, but otherwise it's progressive. It preserves the market mechanism, it makes sure people do not get bankrupted by their medical bills. I think that is actually the kind of system that you could grow out of Obamacare if it failed.

### Moderator
Claim: Jonathan Chait.

### Scientific Advocate (SA)
Claim: The reason I wrote that you're against national health care is because in 2009 you wrote a column called "Why I Oppose National Health Care." You've also predicted-- a few months ago you predicted the exchanges might not even open on January 1, that the administration would have to stop its whole law. So if you're talking about moving the goal post your definition of failure just keeps getting smaller and smaller.

### Conspiracy Advocate (CA)
Claim: Well, I'm just saying that in 2010, 2011, and 2012, and 2013, I have written that I support the sort of catastrophic reinsurance program. I've been proposing it for a fairly long time.

### Conspiracy Advocate (CA)
Claim: Let me tell you what a death spiral looks like. Every year-- this is a provision that a lot of people haven't noticed yet. Every year that these subsidies make these sort of value of the health plans sold in this law get re-priced. In Medicare Part D they also get re- priced. The subsidies get re-priced. They get re-priced each year from a blended average of all the plans in the marketplace. They had a convergence of sort of a mean value of the plans. In this marketplace they get re-priced off the second cheapest plan in every market. The second cheapest plan in Florida is a plan that has seven pediatricians for a county with 250,000 kids. Next year all the policies in Florida will now be re-priced off that plan. So all the plans will have to conform to that benefit structure. That is a death spiral.

### Scientific Advocate (SA)
Claim: You're using the word death spiral in a way that no one in health care and economics ever uses it.

### Conspiracy Advocate (CA)
Claim: It's a death spiral in the quality of the coverage. You end up with a plan that looks like Medicaid. Now again, I haven't heard anyone defend Medicaid.

### Moderator
Claim: Do you guys want to-- anybody on the actually want to defend Medicaid? Doug Kamerow.

### Scientific Advocate (SA)
Claim: Well, I want to go back to your point though.

### Moderator
Claim: Just as the point is out there right now, the reason I bring it up is that in his opening statements Scott emphasized that essentially Obamacare is really a Medicaid plan and the problem with that is he talked about the outcomes for Medicaid are not satisfactory, but I think it's a valid point for him to have put out there.

### Scientific Advocate (SA)
Claim: I think one of the things we have to remember is that this law changes lot’s of things. It doesn't just change the coverage. It also talks about who's going to be taking care of patient on Medicaid, what the doctor is going to be paid. As you know, as a practicing doctor, where you practice a lot of places don't take Medicaid and they don't take it because the rates are laughable. Reimbursement is very low. It's not because, I don’t think, because the patients have certain problems that they're not willing to deal with, seems unlikely. It's a matter of dollars and cents. One of the things it does, at least temporarily it can presumably be extended, raising the rates of Medicaid and Medicare. A lot of doctors take care of Medicare patients. And also I would think that you'd be happy to see these kinds of-- it seems to me at least, speaking from the inside , as a conservative philosophy.

You're saying look, if this doesn't work very well, clearly these high-priced providers, wherever they are, are going to have to make some kind of a change. Hospitals or other places that are going to be left out of the networks pretty soon--

### Conspiracy Advocate (CA)
Claim: I'm not happy with giving people false promise. We've done that with Medicaid and we've done it now with Obamacare. Obamacare will evolve into Medicaid. It will be the same quality, the same narrow networks, because--

### Scientific Advocate (SA)
Claim: Because you're predicting it.

### Conspiracy Advocate (CA)
Claim: Well, it's already happening. I mean, if you look at the quality of these plans, if you look at the networks, and I'm putting out data on this next week, I hope everyone goes to the website and sees it. If you look at the networks in Obamacare they are Medicaid networks. If you look at the plans that are preparing bids for next year, it's Medicaid plans that didn’t get into the market this year. This will evolve into a Medicaid benefit. We didn't need to obligate people to a Medicaid benefit and we have done nothing to fix the existing Medicaid benefit. The changes you talk about was a temporary increase, a small increase in payments to primary care providers, that now sunsetted at the very point that we're going to push 19 more million people into Medicaid.

Can you imagine trying to service 19 more million people with the existing Medicaid program? What is that going to look like?

### Scientific Advocate (SA)
Claim: That's all you keep saying-- obligate people to Medicaid, but I don't think the word means what you think it means. No one is obligated to go on Medicaid. People are offered to go on Medicaid and they very rationally choose to go on Medicaid.

### Scientific Advocate (SA)
Claim: Because it's free.

### Scientific Advocate (SA)
Claim: Right. Now, our opponents have made two different claims about Medicaid. Scott’s made a terrible argument about the quality of Medicaid and Megan made one that is merely bad. Scott's argument, he's obliquely citing studies that have taken two populations, one of which is on Medicaid and one which is not on Medicaid and compared their health. Now, if you're on Medicaid you're in a terrible place. Something has gone bad in your life. You're very poor. You're very sick. Bad things are happening to you. So, a lot of studies are comparing two completely different kinds of populations and finding the people on Medicaid are worse off.

### Conspiracy Advocate (CA)
Claim: Jonathan--

### Scientific Advocate (SA)
Claim: Those are the studies people don't take seriously.

### Conspiracy Advocate (CA)
Claim: The studies controlled that.

### Scientific Advocate (SA)
Claim: Then the study that Megan cited is still not a very good use of data. It's not a good use of data for two reasons-- if I may--

### Moderator
Claim: Very--

### Scientific Advocate (SA)
Claim: Number one--

### Moderator
Claim: Very briefly, but you've got two people lined up to defend themselves.

### Moderator
Claim: That's right.

### Scientific Advocate (SA)
Claim: So, there are a series of studies on the effectiveness of Medicaid. Many of these studies-- most of them show what you would intuitively think. Going on Medicaid and being able to see doctors, even if you don't get a lot of choice, even if a lot of doctors don't want to take the low prices, is better than not having health insurance and going to good-- going to the doctor at all. Because as my partner explained in fairly strong detail, not having health insurance is dangerous. It's terrible. Nobody wants to have it. And people are right not to want it--

### Moderator
Claim: Megan McArdle.

### Conspiracy Advocate (CA)
Claim: Well, it shows actually-- Here's something interesting-- is a lot of these studies have looked at Medicaid versus the uninsured. And the uninsured do better. Having no insurance is better in these studies than having Medicaid, even when you control for Now, that said, do I think that having Medicaid is actually worse than being uninsured? No, I don't.

It's very hard to actually measure lots of things. But the-- you would want to know about the impulse control, or social support and so forth. But I think that most people agree that Medicaid is bad coverage. It's not good coverage. You wouldn't want to go on it. And there are people who had cheap policies canceled-- got cancellation notices and found that when they went to the exchanges, they were were into Medicaid. That's

### Moderator
Claim: So, let-- I think--

### Conspiracy Advocate (CA)
Claim: So I'm not--

### Moderator
Claim: Scott, go ahead and then I will ask--

### Conspiracy Advocate (CA)
Claim: Yeah. I think the discussion about Medicaid is operative here, because this is-- this is a real dilemma that I can't get to the bottom of. People feel good about Medicaid in Washington. I worked in Washington. People look at the benefits that are being promised on paper in Medicaid and think that it is a fabulous program. The practical reality is that anyone who works in the medical marketplace knows that's just not the case. We have done the same thing with Obamacare. We have promised something that looks very good on paper. The practical reality that's already taking shape in the marketplace is people are not going to be able to get what they're being promised on paper.

And so, the question becomes, why do we feel good about what we do in Washington on paper when the reality doesn't approximate what we've said we've done--

### Moderator
Claim: All right. Well, that actually takes me to-- to-- that takes me to my question, because my sense of what this motion says is that the Rube Goldberg machine that Megan's described the Obamacare plan as being is doomed finally to crash a-- crashing to a halt. And your opponents are saying, it may be a Rube Goldberg machine, but it's going to keep moving in its fashion. And it already is moving and things are happening, and it can be tweaked around the edges. You're-- you're not actually describing a Rube Goldberg machine coming to a halt. You're describing a Rube Goldberg machine producing an outcome that you don't like.

### Conspiracy Advocate (CA)
Claim: Well, no, I--

### Moderator
Claim: I mean, and this should have been-- if it's Medicaid, it's not good.

### Moderator
Claim: Well, but--

### Moderator
Claim: And that's fair enough that that's your argument. You're--

### Conspiracy Advocate (CA)
Claim: But it's not an outcome I don't like. It's--

### Moderator
Claim: No. No. But-- I don't mean ideologically. I mean, you're saying it's an outcome that nobody should cherish, that it's going to be more sick people at more cost with less competition.

### Conspiracy Advocate (CA)
Claim: But--

### Moderator
Claim: Is that what you mean by "beyond repair?"

### Conspiracy Advocate (CA)
Claim: It's not what we set out to do. We set out to achieve something and we're not even-- we're not even pretending that we're going to achieve it. I mean, I-- they can't defend that Medicaid is an abysmal benefit in terms of what it's promised and what it's delivering and Obamacare won't involve it, with Medicaid-like benefits.

### Moderator
Claim: either one of you to say what you think the Obama-- White House plan hopes to achieve and how we're falling short of it already.

### Conspiracy Advocate (CA)
Claim: Well, I don't--

### Conspiracy Advocate (CA)
Claim: I think that what they hoped to achieve was a program that even if it wasn't perfect, would be politically self-sustaining in that it would be impossible to repeal, because some, they think, would love it. And I think that's what a key issue is with Medicaid--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --and with these narrow networks, is people aren't going to love these and aren't going to fight to keep them.

### Moderator
Claim: Okay. Great. Then-- that's a point I want to bring to the other side-- because there's the argument being made here that for the program to be sustained, there needs to be an issue of public trust, enthusiasm, and participation so that people will sign up for it. And they're saying that they're concerned that with the way things are going, that won't happen and that does make it unsustainable. And I want to take that to the other side gentlemen.

### Scientific Advocate (SA)
Claim: You've got to remember, the proposition here is "beyond repair.” So they're not-- that's not a claim about beyond repair. That's a claim about something that might happen in the future that they can plausibly say will be--

### Moderator
Claim: I think it's a--

### Moderator
Claim: --the

### Moderator
Claim: I think it's a fair sort of trend line argument. I mean, you may-- I'm not--

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: --taking their side, but--

### Scientific Advocate (SA)
Claim: So--

### Moderator
Claim: --but I think it's-- I think it's-- I think it's food for thought--

### Scientific Advocate (SA)
Claim: Right.

### Scientific Advocate (SA)
Claim: So the initial projections were-- CBO said they guess about 7 million people would be in the exchanges by the end of the open enrollment period in March. Now, the website was broken for the first few months. That wasn't just people could enroll. That means the whole outreach campaign that the administration, its outside allies, and in the insurers had planned to direct people to this website-- which was broken-- had to be put off. So basically, we’ve lost two-thirds of the time to enroll people in the exchanges. It was trying to enroll people in the exchanges that we've had, October, November, December. Only December wasn't working. Yet-- so in one third of the time they've had available, they did a whole two thirds of the target they were supposed to have in the exchanges. They thought by the end of December they would have three million. Instead, they have two million. So that seems to be--

### Moderator
Claim: But they're saying it-- they're saying it does need to be popular to succeed and that it's not popular and they don't think it's going to be

### Moderator
Claim: Well, I--

### Moderator
Claim: Well, I'm sorry. I shouldn't speak for you if you want to speak, Scott. Go ahead, and then I want to go to questions from the audience right after that.

### Conspiracy Advocate (CA)
Claim: This is very quickly evolving into a plan for service. the high risk pool of the service people who have preexisting conditions were priced at a prior market aren't in the existing insurance pool, and those below 200 percent of federal poverty levels benefit enough from the subsidies to make these plans even partially affordable.

### Conspiracy Advocate (CA)
Claim: That's about 20-- well, once you get above 200 percent of the federal poverty level, these plans are more expensive than what you could've got in the existing individual market because look at the numbers. They're subsidized up to 400 percent. The subsidies fall off at 250 percent quite rapidly. That's about 20 million people. My question is, "Why did we--" if we wanted to target 20 million people, which is what this law inevitably is going to end up doing, why did we have to disrupt the insurance scheme for 350 million Americans? I mean, everyone was affected by this.

### Moderator
Claim: And there's simply no evidence of any of that disruption.

### Moderator
Claim: All right, I want to audience questions--

### Conspiracy Advocate (CA)
Claim: How many people-- how many people got notice from insurance plans, that their plans were changed or canceled this year? I guess in New York City...

### Moderator
Claim: All right, that works so well on radio when the hands go up. For the radio audience, a scattering of hands went up. I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two debating this motion, "Obamacare is now beyond rescue." Let's go to some audience questions. And I Sir, in the reddish shirt, I'm not good with color description once we're off the basic red, chartreuse? You can stand up and tell us your name, please. And, again, I need this to be a question, and if it's not on point, I'll have to pass. Thanks, go ahead.

### Moderator
Claim: Hi, guys, my name is David, and my question is if you can't determine who has enrolled and who has cancelled, how will you be able to input the penalties that are paid due to Obamacare plan?

### Conspiracy Advocate (CA)
Claim: Well, I think the penalties are irrelevant. Nobody actually believes those penalties are going to be enforced. They're just a claw back on your tax return if you're owed a refund. A clever accountant can easily structure your tax returns so that you would never have to pay a penalty. I think everyone recognizes the individual mandate, so- called tax penalty really isn't an operating feature in this anymore, and will probably be suspended this year, but they will wait till after March 31 to do it.

### Conspiracy Advocate (CA)
Claim: Yeah, I would also guess that sometime in April the administration will announce that mandate is not going to be enforced for 2014, this year everything is going to be disrupted and not going according to plan and we will have people who lost insurance and didn’t get it, and the political backlash would slowly dismantling the law in order to preserve its temporary political viability.

### Moderator
Claim: Would the other side like to also answer the question?

### Scientific Advocate (SA)
Claim: I'm not sure why they have to going to be-- that's going to be delayed, but even if it is delayed, it still doesn't go to the point that it's not going to ultimately be useful and even despite the tax dodges that people like Dr. Gottlieb have access to-- I'm sorry, Scott, my mistake.

### Conspiracy Advocate (CA)
Claim: That's all right.

### Scientific Advocate (SA)
Claim: --that Scott has access to, even without those, there's a bit of a moral imperative where people don't like to break the law, people don't like to do what they're not supposed to do, and that's one of the reasons, the moral imperative was put in there.

### Moderator
Claim: --another question. Oh, sir, right down here, sorry. On this side?

### Moderator
Claim: My question is for Scott and Megan, so--

### Moderator
Claim: Can you tell us your name, please?

### Moderator
Claim: My name is Rahod Janahan So clearly Obamacare is a large scale complex change. My question is are you opposing the intention, execution, or both of this large scale reform change?

### Conspiracy Advocate (CA)
Claim: Well, I'll let Megan speak for herself. I was quite clear, and I've been quite clear when I've talked about this a lot. I think the goals here were laudable.

I think we have to do something to try to help people who are priced out of the insurance market or people who found themselves in between plans that didn't have-- weren't in insurance pools where they had portability. We could've addressed those issues in a far more disrupting with so many dislocations in the marketplace. I think we still can. This isn't the edifice to do it. We-- I--

### Moderator
Claim: Okay, Scott, you-- I'm going to-- would like to go to Megan because you actually made that point a couple times, because I asked that very same question, but not in very good way so I get to hear Megan.

### Conspiracy Advocate (CA)
Claim: Do I have the intentions of protecting families from financial damage for medical bills? Absolutely. Do I think that the execution was good? I think that's a hard argument to make. But, you know, I also think that there are better structures and attempts to like preserve everything that any person in the United States had, which we already know wasn't possible manage to do it, while simultaneously layering a bunch of new stuff on top of that, was just an inherently flawed design, I don't think that I understood that it would be executed so badly, but I--

### Moderator
Claim: So your answer is both?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Okay. That woman right there.

### Moderator
Claim: My name is Dana. So we've seen that universal health care to be successfully implemented in other countries than the U.S. Can we explain why it can work there and not here? Are there learnings that we can take to adapt the current system to be more successful?

### Moderator
Claim: Can you rephrase that question that gets them to talk about whether it's beyond repair?

### Moderator
Claim: Okay, so can we take-- can we take lessons from successful implementation of universal health care in order to prevent Obamacare from being unsuccessful or beyond repair?

### Moderator
Claim: Thank you, I think that did that. That's a question I think that's for this side, so I'm going to let them take it. I'll want you to give me a response depending on what they say, and if somebody has a question for this side, it's not getting many, I would like to have some Thank you.

### Conspiracy Advocate (CA)
Claim: I think of it as sort of like the autobahn, which is great, but I wouldn't necessarily say that you could just build that in the United States now. We already have a highway system.

And so looking at what another country has done with a really long history is helpful in the sense that you can see elements that work, but that doesn't mean that we can have Germany's health care system. We have a different set of doctors and nurses and patients and all sorts of things, and that's why I like the idea of a kind of very American - - we're going to have the government insure your financial losses after a certain point, but we're going to leave you out there as a market driven consumer, making choices of whatever health care you want when you get sick.

### Scientific Advocate (SA)
Claim: I think that's exactly point is, is that is if you don't like a state run kind of program, then, you know, you don't like the kind of systems that are elsewhere. You can say, "We're not the same, we're different," but it is interesting that every advanced economy in the west and some more in the east has these kinds of programs, and yet there is something special about us where we can't seem, apparently, figure out a way to do it here.

We've got to have some special American take on it. So I think we probably can learn from it. I think we probably can learn a lot from other countries.

### Conspiracy Advocate (CA)
Claim: Well, you know, we-- I mean, we have-- look, we have a market that's much more fragmented in a much larger country. We have people who want to exercise more choice in their benefits design. We have people who have higher expectations than what many people are willing to acquiesce to in other countries, and the one final point I'd make is that the structures in Obamacare that I've talked about tonight, the narrow networks, the closed drug formulators, I guarantee you they're going to be showing up in your commercial plans in the next two years. These structures will not be confined to Obamacare. They will now migrate into the commercial marketplace.

### Scientific Advocate (SA)
Claim: I-- here's one way to tie this together. For years and years, when you asked conservatives about national health reform, they would say some horror story, right? They would say some man in Canada walked 100 miles in snow and lost his feet because of the Socialist horrors of Canada to come to the freedom of America, and everyone in Britain has lost their teeth because of the NIH-- and all these, you know, weird kind of mix of anecdotes and half-truths. Those

### Conspiracy Advocate (CA)
Claim: But that's actually true, Jonathan.

### Scientific Advocate (SA)
Claim: --that was what was like floating around out there. And I think what's happened here is that all these horror stories simply migrated to the United States and now describe Obamacare. They've kind of forgotten all about the horrors of socialized medicine, and the way that they understood national health insurance in the other countries is now the way they understand national health insurance in the United States. It's a very partial anecdotal kind of slightly hysterical way.

### Moderator
Claim: I'm so tempted to ask who in the audience is British and would like to smile at us right now. Our motion is, "Obamacare is now beyond rescue," and I'm saying that because I've repeatedly said it's beyond repair. The motion language is beyond rescue. Here comes a question right now. And if you rise, they'll find you a mic. Thanks.

### Moderator
Claim: I'm Michelle. I'd love to ask the group against the motion to have a chance to explain why the Obamacare needs a bit more time for it to play out.

I find it a little bit unrealistic that partisan zealots in Washington are ready to kill it, and it's only a couple of months out of the gate, and I'd love to hear them explain to the audience why and how Obamacare is going to succeed over the next year.

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: Jonathan Chait.

### Scientific Advocate (SA)
Claim: --you know, I think it's kind of self evident that this target date-- that we've heard from the other side of-- are things better by January 1 is oddly irrelevant, the first day that the law is actually in operation. The point is to make a change over a series of years. Now, the outreach campaign to the public is something that by definition just takes months and months and months and years and years and years to build up. And no one envisioned that the law would reach its coverage target even under the best circumstances the first year. And again, the website responded. So, in 2013 they lost two-thirds of the available time. So naturally you're just going to move back the target for the ramp up year, you're going to hit it more slowly, but nothing about that process changes the law's ability to fundamentally reach its goals in the coarse of time.

### Scientific Advocate (SA)
Claim: We're also making a huge change here, there’s no question about that, and it takes time to do that. Plus lots of the law has things that are demonstrations, that are experiments, that are trying to find different ways to improve things. And we're not going to know the results of those for a year, two years, or even more. And they can, the nice thing about it Centers for Medicare and Medicaid, can then ramp things up when they find successes in demonstrations to show how we can help to incentivize patients, those kinds of things are out there in existence right now.

### Conspiracy Advocate (CA)
Claim: Look. You know just one comment to follow up on what Doug said. What Doug is talking about reform, these are things we've been talking about for a decade and they're not a key feature of Obamacare, although they were in the law. We could've done a lot of that without disrupting the entire commercial insurance marketplace these were bipartisan ideas.

I'm not sure that Obamacare is going to successfully implement them anyway. I'll just give you one anecdote. They have a new law that hospitals get penalized for readmission, so hospitals are admitting fewer patients. When patients show up in the ER they're being put in what's called observation status. They're sitting in the hospital for 36 hours and not being admitted and so since they're not admitted to the hospital, they're considered outpatient, so they're being hit with 20 percent co-pays on that.

### Scientific Advocate (SA)
Claim: And, of course, other hospitals are working on programs where they have outreach workers for the first time to try to follow up with patients.

### Conspiracy Advocate (CA)
Claim: This isn't Obamacare, Doug. These are ideas they could've done apart from disrupting the entire marketplace

### Scientific Advocate (SA)
Claim: --very much part of Obamacare. I mean, you're saying Obamacare is beyond rescue. We're saying lots of parts are doing good things.

### Conspiracy Advocate (CA)
Claim: Obamacare is a federalization of insurance, though. That's what Obamacare is. I mean, this was a feature added into Obamacare. We could've done that in separate bills.

### Scientific Advocate (SA)
Claim: Part of the law is working and you're saying this functional part of the law could-- might have been tapped without Obamacare, but whether or not that's true it’s in the law.

### Moderator
Claim: But is it an unsuccessful federalization of health care or

### Conspiracy Advocate (CA)
Claim: It's a bait and switch, they're arguing components of Obamacare. That's not the essence of what the law set out to do.

They were thinking they were attached to Obamacare. The Sunshine Act is part of Obamacare.

### Scientific Advocate (SA)
Claim: No, the law set out to do things to reform the cost structure of benefits to control costs and by all evidence it's succeeding beyond the best expectations and--

### Conspiracy Advocate (CA)
Claim: You know, the recession lowered medical spending. Let's be honest.

### Moderator
Claim: Megan McArdle.

### Conspiracy Advocate (CA)
Claim: Even the government's actuaries say, you know, CMS economists are saying that it was the recession, not Obamacare. But look, you know, is everything in Obamacare going to go away? No. Obamacare involves, for example, changes to the student loan program. Are those going to be rolled back if the insurance markets don't work out? No. The question is, are the major super structures going to stay in place, and especially the things that you needed to do of a piece. You know, our-- we're going to go back to-- we're going to take kids under 26 off their parents insurance? I doubt it. But that doesn't, you know--

### Moderator
Claim: But are you-- Megan, are you saying that those few examples of things that are popular and working are fringe to the basic concept?

### Conspiracy Advocate (CA)
Claim: That's entirely fringe.

### Moderator
Claim: Okay. Are those things fringe to the basic concept of Obamacare that this side is arguing towards?

### Scientific Advocate (SA)
Claim: No. I mean, the law intended to do a lot of things. It intended to cover people in a lot of ways. Covering people under 26. That was the way they covered people under 26. But controlling costs-- what they decided to do was not have one big blunt force wave to hold down medical inflation they let thousand flowers bloom and change the infrastructure in a lot of ways and there's a lot of good evidence--

### Moderator
Claim: Okay. So what we have here is your basic disagreement about what we mean by Obamacare.

### Scientific Advocate (SA)
Claim: It's a big law with a lot-- with two major goals accomplished in a bunch of different ways.

### Moderator
Claim: All right, but you both need to persuade the audience that way you're talking about is Obamacare that we’re arguing about. As an audience they have to consider that. Yes, right down-- right here.

### Moderator
Claim: I guess my question would be to both sides. Being that it is a large, you know, plan, meaning that it has to be popular. How much would you say that the backlash from Republicans instead of making it pretty much not work as a whole, just kind of delaying it by spreading all of this venom about it?

### Moderator
Claim: I'm going to pass on the question, because I think they actually address that. I think it's a great question, but I think it was addressed When they were talking about the definition of failure I think that Here comes the mic to you.

### Moderator
Claim: Hi. My name is Jennifer and my question is both positions have admitted that there is a lack of metrics program. If we lack quantitative data, which we use to assess organizations and businesses health, then how can we measure the potential sustainability of the program?

### Moderator
Claim: Good question.

### Scientific Advocate (SA)
Claim: So we're-- I think where we lack the metrics is how many people had their plans with their private insurance plans cancelled? That's what we don't know. And that's the kind of negative sum in their ledger, that they're trying to say the law failed. We don't really know that no one has the-- but we do know who's signing up. We've got very good metrics on that.

So, do we know how many people are going in the exchanges, how many people are going into Medicaid, what type of healthcare costs? All those things can be measured and are being measured. And they're all very positive.

### Conspiracy Advocate (CA)
Claim: You-- there's absolutely metrics around this program. The problem is the administration doesn't want to release the numbers. As far as the cancellations, you've made the point a few times. It is 5 million. It might be more. All you need to do is look at the analyst reports around you at the United/Humana, which are very large insurers. And it comes to something very close to that. So we know people had their policies outright canceled. We know many millions more had them changed in substantive ways, where it's no longer affordable to them.

### Moderator
Claim: I have a question from Twitter, from Jerry Weinstein or Weinstein-- or Weinstein or Weinstein. No, it's two I-- E-I-E-I-- Jerry Weinstein He asks to the side that is opposing the ACA, which is actually the side arguing for our motion that Obamacare is now beyond rescue-- "Tell us, how successful was the Romney Care law in Massachusetts and where is that program now?"

### Conspiracy Advocate (CA)
Claim: Well, it's--

### Moderator
Claim: Megan McArdle.

### Conspiracy Advocate (CA)
Claim: --In some ways it lowered the number of the uninsured.

It did it in its first year, which I'm not clear we're doing now. But in other ways, it didn't do what it was expecting to do. For example, they had expected to really lower the rate of uncompensated care, which was something that you hear a lot about. And they did lower it somewhat, but it came in at only about 40 percent lower than the projections-- instead of the 100 percent lower than they’d basically been expecting. Costs are still going up. Medical bankruptcies don't seem to have abated nearly as much as you would think, given how much insurance-- you know, they've now-- they're now the-- by far the lowest rate of uninsured people in the nation. But Massachusetts is also a little bit hard to compare to the rest of the country. They already had the lowest rate of uninsured people in the country before they started this. They've got a weird mix of employers-- you know, a lot more employer-based insurance than you're going to get in Texas. There's many fewer illegal immigrants-- and even legal immigrants, which is one of the big areas where you see uninsured people for kind of understandable reasons--

### Moderator
Claim: Go ahead,

### Conspiracy Advocate (CA)
Claim: And we also-- we've seen costs go up in Massachusetts. And Massachusetts was a market that was saturated with providers. So it was easy to get leverage on them and burn them down. It's going to be a little harder to do that in Obamacare, but I think they'll get there.

### Moderator
Claim: Would this side like to take the Massachusetts question. I don't think that they need you to make your point-- so in the front row there.

### Moderator
Claim: Oh, no, I--

### Moderator
Claim: Oh, Jonathan's going to-- I see--

### Scientific Advocate (SA)
Claim: I would like to, actually. There's a huge amount of data. It contradicts what the others are trying to say. Let me cite one. Two Urban Institute researchers published a study finding that the number of adults reporting that they skipped care because of high costs in Massachusetts fell 17 percent to 11 percent for the first two years of the law. So I think of all the things it's trying to do, is-- quit-- stop people who can't get healthcare because they can't afford it. That was the main goal of the law and it succeeded

### Moderator
Claim: yeah, you can stand up

### Moderator
Claim: Hi. I'm Erica. I'm just wondering what aspects off the law were put into effect that lowered costs by 2012 of overall health insurance.

### Moderator
Claim: Jonathan, Sounds like it's yours to--

### Scientific Advocate (SA)
Claim: Sure. Oh-- you-- there are a number of things. And one of those is getting people into care so they don't have--

### Moderator
Claim: You could go ahead--

### Scientific Advocate (SA)
Claim: All right. There were a lot of cost reforms in the way that hospitals were compensated, that happened before 2012, right? So, instead of paying people based on more care-- the more medicine you perform, the more money you get-- it changed the model where people get paid based on providing quality of care and actually in measurable ways of improving patients health. So, one way is it penalized hospitals that have high rates of infections. Because previously, hospitals-- if your patients get an infection, that's a bonus for you. They have to go back in the hospital and get treated again. And you make more money. So, instead the law changed and said, "No, we're going to penalize you if you have a high rate of infections.” And the rate of infection has actually fallen. There's a wide series of reforms like this changed the cost structure of American medicine. And I think a lot of researchers have looked at this and concluded they're actually working on changing the cost model and making people try to provide quality instead of just more and more care for more and more money.

### Moderator
Claim: Jonathan-- looks like your opponents want to challenge that?

### Conspiracy Advocate (CA)
Claim: So, there's a lot of--

### Moderator
Claim: Megan McArdle.

### Conspiracy Advocate (CA)
Claim: --there's a lot of changes in the law that were supposed to control costsThere are some that take effect immediately, like hospital remission. But that was only in Medicare. And the cost reductions have been occurring across the board, not just in Medicare, a recent paper at Brookings suggests it's probably due to a combination of the recession and technological slowdown, we haven't had a lot of innovation for whatever reason in the last few years. Going forward, there are things like accountable care organizations that think they're not looking as great as they thought that they were. Other issues with electronic medical records, also not looking as great as we had hoped. And some Medicare pilot programs. And eventually, the comparative effectiveness for slow Medicare costs and it doesn't come down on its own. But all-- most of that stuff hasn't really-- either hasn't finished being implemented or isn't expected to return dividends or is going to be started being implemented this year.

### Conspiracy Advocate (CA)
Claim: Most of the cost control provisions in this law form transfer risk to providers. That's how the law seeks to control cost. That's what accountable peer organizations bundle payment share savings. It's all forms of capitation, and that's what we're seeing in the marketplace. That's why doctors are selling them back to hospitals, so they can form larger entities and take that capitated risk. If you think that's a good idea, then you're more than welcome.

### Moderator
Claim: All right question right there? We’ll get a mic to you.

### Moderator
Claim: Hi, I'm Dave. Thank you so much, Intelligence Squared, and thank you to the debaters. 2.7 million people under the age of 30 out of seven million enrollees is what hinges Obamacare's success. Social Security and Medicare, $66 trillion in deficits, what provisions decide against-- what provisions in the law ensure Obamacare does not result in financial failure like Social Security and Medicare when it hinges on taking from the young to get to the old when the demographics clearly suggest this is unsustainable. Thank you.

### Moderator
Claim: And it's just sort of a big philosophical question which wraps up everything that we've been talking about, but I think we should take it.

### Moderator
Claim: I think so.

### Scientific Advocate (SA)
Claim: That's exactly-- that's exactly what insurance is about. And so if you don't want to have a system where people contribute so that the entire population benefits, then you don't have a system like that. But as a youngish person, I can't quite see, yourself, you know, you may feel that this is a big problem. Guess what? There's a future you, and the future you is going to be much older, and it's going to be--

### Moderator
Claim: If he walks carefully in traffic. Megan McArdle, you want to respond?

### Conspiracy Advocate (CA)
Claim: You know, I think that, that is a political issue. We already on net transfer a lot to older people and a lot of the set up here is transferring more and more to older people and to sicker people, which is a kind of a separate issue.

It's actually kind of interesting how few people-- how little the transfers are until you get to be about 50. And I know we're all hoping to make it there, but is that politically sustainable when that's the minority of the voting base and when they're already getting most of the transfers and growing every day? And when the budget is under strain, when we have to find ways to cut, I do question that. I question whether in 20 years we're still going to be gung ho about giving money to people over the age of 50 instead of people over the age of 65.

### Moderator
Claim: All right, a great question because it really wraps up what this whole debate has been about. And that concludes round two of this Intelligence Squared U.S. Debate-- where our motion is "Obamacare is now beyond rescue." So we're going to have you vote shortly. We're going to have closing statements in a moment, and we must remind you that you'll be voting again immediately afterwards for the second time. And it's the difference between those two votes that determines our winners.

We do this section seated. So on to round three, closing statements by each debater in turn. They will be three minutes each, and here to summarize his position against this motion that says, "Obamacare is now beyond rescue," Dr. Douglas Kamerow, a family doctor and former assistant attorney general. Ladies and gentlemen, Douglas Kamerow.

### Scientific Advocate (SA)
Claim: Brief correction, never been an attorney or an assistant attorney general.

### Moderator
Claim: What'd I say?

### Scientific Advocate (SA)
Claim: It's okay.

### Moderator
Claim: Do you want to be the-- you're a surgeon general. Do you want me to say that you're an attorney general? You know the magic--

### Scientific Advocate (SA)
Claim: No offense to the attorneys out there.

## Round 3

### Moderator
Claim: --the magic of editing. I'm going to say it again so that the radio producer can make me seem a lot smarter than I am. Here to summarize his position against the motion, Douglas-- Dr. Douglas Kamerow, a family doctor and former assistant surgeon general.

### Scientific Advocate (SA)
Claim: Thank you very much, John, and thanks to you and the IQ2 sponsors, and to Megan and Scott for a spirited debate. I want to thank the audience as well.

The motion that we're talking about is, "Obamacare is now beyond rescue." We've had a lot of fun throwing statistics back and forth and trying to make clever remarks, but it seems to me this really comes down to a very personal question. Given where we are, what’s come before, and likely to happen in two scenarios. We keep Obamacare or we dump it, what should we do? And like most of us, I could cite personal stories about health care coverage and access, recent ones about friends who had trouble getting coverage because of preexisting conditions, and now with the Obamacare see their insurance and drug costs decrease markedly to 75 percent, or about young people like two of our kids who've already gotten affordable insurance coverage between college and their first jobs.

But I think really the most telling story that I want to mention in conclusion is about Medicaid, much maligned in this discussion today, but 35 years ago, my first job for the Public Health Service was working as a GP in the National Service Board, the Community Health Center in an urban underserved part of town, but because that city was in this state, that is, in New York State, the state that had and still has a generous Medicaid program, most of our patients had insurance. Most of our patients had access to care. They were poor. They were working or disabled. But they had health care, they had a medical home, and they had prescription drug benefits. And they benefitted from this, despite what you've heard here today. A lot of good care is delivered to Medicaid patients. When I later moved to Washington, D.C. and looked for a job in Virginia, I asked about Medicaid--

### Moderator
Claim: Douglas you have 10 seconds left. I'll give you an extra five, so--

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: Cut to the chase.

### Scientific Advocate (SA)
Claim: I want to say that because of Obamacare, a lot of people are going to have Medicaid, but also a lot of doctors are going to be paid more to take care of Medicaid, and there's more money for the National Service Corps with doctors like me taking care of them.

### Moderator
Claim: All right. Thank you, Doug Kamerow. Our motion is "Obamacare is now beyond rescue." And here and to summarize his position in support of the motion, Dr. Scott Gottlieb. He's a practicing physician and a former FDA deputy commissioner. Ladies and gentlemen, Scott Gottlieb.

### Conspiracy Advocate (CA)
Claim: If I were to-- if I were asked to distill downObamacare's essential flaw, it would simply be this, the law tries to exert so much control over aspects of medicine and health care that it's subject to so much heterogeneity and individualism that nobody should ever have thought that they could be micromanaged from a remote bureaucracy in Washington in a big piece of legislation. The result is what you're seeing, an over- engineering that may have started out elegant on someone's flowcharts but became undone when it was subjected to political realities and the marketplace. And it has-- and the marketplace had to conform to its rules.

And the result is a massive exercise in unintended consequences and a health insurance product that clearly people don't want. People are saying this is just a rough start, but I will tell you this will get worse as this scheme unfolds. There’ already evidence plans aren’t entering the market in 2015, premiums certainly will rise next year, probably not as much as we thought because of the reinsurance pools, but those pools eventually go away. Small businesses will dump people once their grandfathering is up at the end of this year, and you're going to see small businesses' cancellation notifications. Networks and drug formulators will have to be narrowed further next year as this whole market gets repriced off the second cheapest plan in every state. And these structures in Obamacare that are so unappealing will start to evolve into the commercial marketplace just like the Part D structures involved in tier commercial drug plans. 2014 was the high water mark for this scheme. The insurance part will only get worse from here. And this is hardly the ambition that is that its architects had in mind. Obamacare surely will help some people.

Those below 200 percent of the federal poverty level will be helped by this I think, but a lot more will be hurt as they find themselves spending more money than they previously did to buy their way out of this scheme. We didn't have to hurt some people to help some people in this country, but that's precisely what we did.

### Moderator
Claim: Thank you, Scott Gottlieb. Our motion is "Obamacare is now beyond rescue," and here to speak against the motion in his summary statement, Jonathan Chait. He's a daily columnist for the New Yorker magazine. Ladies and gentlemen, Jonathan Chait.

### Scientific Advocate (SA)
Claim: Let me let you in on a secret. When we set up this debate back in the fall, it was a while ago, it looked like Obamacare might really collapse. The website was broken. We didn't know when it would be fixed. We didn't know if it would be fixed. Some people thought it would never be fixed. It looks like it's possible the law would actually not come into effect. But now it has come into effect. Now we're actually living the experience of this law. So the position that was an outlandish and somewhat exaggerated fear three months ago, is now kind of silly.

And I think if you look back into the history of libertarian anti-statism in America, there's a long tradition of these kinds of fear mongering predictions, senators who were opposed to child labor laws a few years ago saying that children would refuse to do chores in their household, Ronald Reagan saying, "If we pass Medicare the government will tell doctors they can't live here, they can't live there, and one day we'll look back at a day when we had freedom in America and wonder what happened to it." So this is a constant recurring pattern, Social Security, all kinds of civil rights laws, labor laws. The American far right lives in terror of government, and it's ideologically understandable that they would oppose these laws, but they translate this ideological terror into a series of verifiable predictions about what will happen if these laws come into effect. And one day we're going to look back at the kinds of predictions they've been making about Obamacare, and those will go in the time capsule, and they'll look just as silly as the predictions that were made by all these other reforms, which is not to say that it works perfectly. It's not to say those other things that work perfectly. Believe me, child labor was a big part of the economy a hundred years ago and when we banned it it actually imposed a lot of disruption and pain on people.

Right now it seems obvious and back then it was really hard. Families lost an income. But these changes did fundamentally work. The market responded. People responded and I think when we look back time we'll see that the people who were saying the law must fail were really just people who didn't agree with its goals in the first place.

### Moderator
Claim: Thank you, Jonathan Chait. Our motion is: Obamacare is Now Beyond Rescue. And here to summarize her position in support of this motion, Megan McArdle. She's a blogger and columnist for Bloomberg view. Ladies and gentlemen, Megan McArdle.

### Conspiracy Advocate (CA)
Claim: So, I don't want to go into an anecdote; we can talk about people who just got coverage and there are people who have and couldn’t get it before and I’m happy for them, or I could talk about the people who have written me and said now I can't afford coverage and I had it before what do I do, and I don't have anything to tell them. That's not really the assessment of the law. They're just individual stories. It doesn’t tell us how it’s going.

And the question isn't whether the status quo was bad, or anyone on this stage is a bad person. I think we all didn’t want the status quo. We're all good people. We all want to help the other Americans to be as healthy as possible. The question is whether the law is undermining its own goals. And to think about going forward, we, you know, Mr. Chait says it’s now here. In fact, we still have a long way to go with a bunch of unpopular stuff that is going to happen. Small businesses are starting to get a wave of cancellations that are going to come through the year, and they're being asked for a lot more money. A lot of that is due to Obamacare. The Cadillac tax, 40 percent surcharge on generous health insurance is especially hard on companies with old sick people, but a lot of benefits managers are saying basically everyone is going to have to go to light plans and scale down rather than get hit by that tax. We’ve got comparative effectiveness research which is going to start determining what sorts of things Medicare will reimburse at what rates.

We've got the individual mandate. People aren't going to pay it this year. They pay it in 2015. As each of those things comes due, there will be an outcry from people who are affected. And the administration has so far shown no willingness to stand up. Yes, you may have to break an omelet to make eggs, but the administration is not going to tell the eggs that, and the Republicans certainly aren't going to make the eggs crack itself. So, if we are not willing to impose the pain, and so far we haven't, this law cannot survive. It is set up as a giant piece of interlocking machinery. You can't just rip the carburetor out and hope that it’s still working. That is why Obamacare is beyond rescue, because we are not willing to face the hard choices the law made necessary.

### Moderator
Claim: Thank you, Megan McArdle. And that concludes our closing statements. And now it's time to learn which side you feel has argued best. We want you to go again to the keypads at your seat and vote now a second time after hearing the arguments.

The motion is: Obamacare is Now Beyond Rescue. If you agree with this motion, push number one. If you disagree, push number two. If you're undecided, push number three. And remember it's the difference between the opening vote and this vote that determines our winners in percentage point terms. We’ll the results locked out in just a couple of minutes. Give me a few more seconds before we lock it out. Okay. We have locked out the votes and I just want to say a couple of things. If I could have your attention, please. This is something that really is important for us to say, because the whole purpose, goal, and culture of Intelligence Squared is to raise the level of public discourse to get people on the stage to argue about the ideas and not about each other’s characters and personalities, just as Megan McArdle said, everyone up here is good, they all basically in the long run want the same thing. I just want to congratulate these debaters for bringing that spirit to this conversation-- and I don't think this has ever happened before, but all of the questions were good tonight. They were all really, really well phrased and I want to thank everybody who got up and asked a question. I just wanted to ask Scott Gottlieb, I thought during the middle of the debate I saw your smartphone open on the desk and you were watching a Twitter feed. Is that your lifeline coming in there?

### Conspiracy Advocate (CA)
Claim: I just wanted to see how I was doing.

### Moderator
Claim: Yeah, well, watching a live Tweet about myself sounds like something I would do. We’d like you all to Tweet about this debate. Use the Twitter handle @IQ2US, the hashtag is Obamacare. We want to also talk about our upcoming debates. We've made a change to our lineup. Our debate next month-- it's on February 12th. The topic was going to be on labor unions. That has been moved to our Fall 2014 debates. Taking its place-- we're going to do it here at the Kaufman-- the motion will be Grant Snowden Clemency. Arguing for the motion, we'll have Ben Wizner. He is Snowden's legal adviser and director of the ACLU's speech privacy and technology project. He'll be for the motion. Against the motion, Ambassador James Woolsey. He's Chairman of the Foundation for Defense of Democracies and former director of Central Intelligence. His partner, also against this motion, Andrew McCarthy, the former top federal prosecutor and contributing editor at National Review. The remaining seat on that panel arguing for the motion has not been filled yet. We will announce it on our website shortly. It's not who you think it is-- you know-- The rest of our spring topics are these: Putin's Russia. We'll be doing universities and online education. We'll be doing millenials in the workplace. And we'll be doing death. going to be traveling up to Harvard shortly to debate affirmative action on campus, and to the National Constitution Center in Philadelphia, where we will be debating the targeted killing of U.S. Citizens abroad and its constitutionality. Tickets for all of our spring debates are on sale through our website www.iq2US.org. And for those of you who can't be in our live audiences and those of you who are watching now on our website or on for a.TV-- we can be seen that way. And as I've said, all of these debates will be available on NPR stations across the nation.

All right. We have the final results in. Our motion is this: Obamacare is now beyond rescue. We've had you vote before the debate and had you vote a second time after hearing the arguments on this very motion. And remember, the team whose numbers have changed the most in your judgment-- in percentage point terms-- will be declared our winner. So, the initial vote on the motion: Obamacare is now beyond rescue-- before the debate, 16 percent agreed with the motion. 53 percent were against. 31 percent were undecided.

So, those are the first results. Remember, you voted a second time. The winner is the one that has changed the numbers the most in percentage point terms. So, here are the results of the second vote. Obamacare is now beyond rescue. The team arguing for the motion, their vote went to 32 percent. That's an increase of 16 percentage points-- That's the number to beat. The team against the motion, they went from 53 percent. Second vote, 59 percent. That's only six percent. It is not enough. The team arguing for the motion: Obamacare is now beyond rescue has triumphed in this debated. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
