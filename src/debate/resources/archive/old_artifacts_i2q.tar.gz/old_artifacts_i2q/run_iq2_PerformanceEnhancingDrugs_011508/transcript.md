# Debate Transcript

Topic: We Should Accept Performance-Enhancing Drugs in Competitive Sports
Motion: We Should Accept Performance-Enhancing Drugs in Competitive Sports

Debate ID: PerformanceEnhancingDrugs-011508


## Round 1

### Moderator
Claim: … And now I’d like to introduce Robert Rosenkranz, who is the chairman of the Rosenkranz Foundation, and the sponsor of Intelligence Squared, who will frame tonight’s debate. Bob? This is Bob.

### Moderator
Claim: Well thank you very much. And, uh, uh, on behalf of, uh, Dana Wolfe, our executive producer and myself, uh, I’m just, uh, thrilled to welcome you. When we scheduled this event some, uh, five months ago, we had no idea it would be so timely. Just in the past month the, uh, Mitchell Report was released, naming some eighty eight Major League Baseball players alleged to have used steroids and, uh, uh, other drugs. Roger Clemens’ denials have been heard in 60 Minutes and were front page news in Sunday’s New York Times. Uh, record breaking sprinter Marion Jones was sentenced to six weeks in prison-, or six months, I The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” should say, in prison, for lying to a federal grand jury about steroid use. Uh, Congressional hearings, uh, on steroid use and the Mitchell Report actually started today in Washington. Uh, closer to home, just a few days ago, Ben Johnson dropped out as our panelist on his counsel’s insistence, because of Johnson’s involvement in a le-, a related legal case that was just noticed for trial. Well timely we certainly are, but what is the debate? This is not a debate about whether cheating in sports should be accepted. That would hardly be interesting. Instead, it’s about whether the rules governing professional sports should ban performance-enhancing drugs. After all, we routinely use performance-enhancing drugs, uh, to enhance our, uh, mental performance. A virtual pharmacopoeia of drugs is used to help people, including minors, stay awake, improve concentration, alter moods. And the whole point of competitive sports is for spectators to see athletes striving to be the very best they can be. We want their training and equipment to use the best science and technology. So why is the use of performance-enhancing drugs an exception? Is there persuasive evidence that these drugs are health risks? If so, how do those risks stack up against the risk athletes assume every day by getting into a racing car or a boxing ring, or on a football field or a baseball diamond? Why shouldn’t athletes make their own informed determinations about risks and benefits of performance-enhancing drugs? And how should we The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” think about the wisdom of rules that are inherently so intrusive and difficult to enforce? Well to help us grapple with these interesting questions, we have an exciting panel, including professional athletes and medical experts. And as our moderator, we have Bob Costas, perhaps the most famous sportscaster in television and radio today. Bob, the evening is yours.

### Moderator
Claim: Thank you again, Bob. So this is the sixth debate of the second Intelligence Squared US Series. The resolution being debated tonight is formally, you know what it is, but formally it is, we should accept performance-enhancing drugs in competitive sports. Here’s a brief overview of the way the evening will work. Members of each team will alternate in presenting their side of the argument, and the presentations are limited to seven minutes each. When opening arguments are complete, I’ll open up the floor to brief questions from the audience. And after the Q&A, each debater will make a final two minute summation. And finally, you vote on tonight’s motion with the keypad attached to the armrest of your seat, and I’ll announce your decision on which side carried the day or the evening, when, uh, the festivities conclude. Let’s start with a pre-debate vote. Please pick up the keypad attached to the armrest on your left. For audience members sitting along the aisle to my right, your keypad is attached to the audience on your right side next to your The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” neighbor. So, the resolution is, we should accept performance- enhancing drugs in competitive sports. After my prompt, please press one to vote for the motion, two to vote against the motion, or three if you are undecided. You may begin voting now. Has everybody cast their initial vote? You’re all set? All right. Now to introduce the panel. And please hold your applause until all six are introduced. For the motion, former policy analyst for the Cato Institute, senior editor and investigative journalist for Reason magazine, Radley Balko on the far end. Professor of pediatrics and bio-ethics, and director of the program in medical ethics at the University of Wisconsin, Norman Fost. And Uehiro chair in practical ethics at the University of Oxford, and director of the Oxford Center for Practical Ethics, Julian Savulescu. Against the motion, former host and creator of the Sports Machine, the award-winning sportscaster George Michael. The former Atlanta Brave two-time National League MVP, multiple Golden glo-, Glove Award-winner, and founder of the I Won’t Cheat Foundation, Dale Murphy. And the former chairman of the World Anti-Doping Agency from 1999 through 2007, chancellor of McGill University and partner at the Canadian law firm Stikeman Elliot, Richard Pound. For most of the evening as points of view are exchanged, all of us will be seated, but as each debater makes his initial seven minute presentation, we will call him to the podium. And we will begin The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” with someone who is for the motion, “We should accept performance-enhancing drugs in competitive sports,” Norm Fost. Norm?

### Conspiracy Advocate (CA)
Claim: Thank you. Everyone in this room uses performance-enhancing technology and drugs. We use cars and computers to make our work more efficient. We use caffeine, alcohol, and Viagra to improve our performance. We send our children to fancy schools and Suzuki lessons to improve their cognitive skills, and enhance their musical ability. And every athlete in recorded history has used performance-enhancing drugs. Babylonians and Romans used herbs to improve their performance in battle. Naked Greeks put on shoes to run faster. Kenyan runners trained at altitude to improve their oxygen-carrying capacity. And runners everywhere carbo-loaded before races to enhance their performance. Why then, do we have a replay of the Salem witch trials? To discredit, humiliate, and incarcerate, uh, elite athletes for doing what has been a standard practice for millennia? And why, out of the thousand and one ways in which athletes enhance their performance, have steroids and growth hormone been selected for particular vilification? The short answer is that they’re illegal and that these athletes are breaking the rules and perhaps the law, and therefor it’s immoral. But this begs the question, as Mr. Rosenkranz said, why are they banned in the first place? We The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” contend that the reasons given are morally incoherent, wreak of hypocrisy, and are based on ice cold wrong information. I will identify six reasons that are offered why we should ban these drugs. Number one, critics say that they confer an unfair advantage. But advantages are only unfair if they’re unequally distributed. The usual solution is to expand access. When Bob Seagren showed up at the ’72 Olympics in-, with a fiberglass pole, it was not banned, but, a-, uh, there was a time to allow others to practice with it, and it was incorporated. When Kenyan runners were found to enhance their performance by raising their hemoglobin by training at altitude, the reaction was not to ban abnormally high hemoglobins, or to prohibit others from training at altitude, but to encourage everyone to do it. The unfair advantage aim, uh, the unfair advantage claim is further undermined by rampant hypocrisy. In the ’88 Olympics, when Ben Johnson lost his gold medal because of steroid use, on the same day and the same press den, Janet Evans, the American swimmer who had won the 5k swim, bragged about the greasy swimsuit that we had kept secret from the East Germans. Johnson used a drug that was available to everyone, although illegally, virtually on the training room tables. Evans used a secret technology available to none of her competitors and bragged about it. The press cheered American ingenuity and made Johnson a pariah. Bud Selig, the baseball commissioner, The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” preaches about a level playing field, but presides over a league where the Yankees’ payroll is three to four times that of most competitors, including my beloved Brewers, and guess what? The Yankees always make the playoffs. Two, critics say these drugs are harmful, but they rely on information that’s wiley-, wildly exaggerated or just fabricated. We are told repeatedly that these drugs use heart disease, cancer, and stroke, while human growth hormone has been given to almost a million children for fifty years, and there’s still no real serious side effects that have been discovered. Oral testosterone dis-, did cause liver cancer, but for twenty years athletes have been using injectables, which have never been associated with cancer. Lyle Alzado the football player, was a poster child for the horrors of steroids. He died of a brain tumor. Then the New York Times and Sports Illustrated told us on cover stories that this was due to steroids without a single quote from an informed physician or a single source showing any association with steroids, because there is none. But still, Costas, I mean, excuse me, uh,

…eh…Alzado is constantly rolled out as a poster child for the horrors of steroids. I ask you in the audience to quickly name, in The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” your own minds, a single elite athlete who’s had a stroke or a heart attack while playing sports. It’s hard to come up with one. Anabolic steroids do have undesirable side effects: acne, baldness, voice changes, intrangent infertility. But sport itself is far more dangerous, and we don’t prohibit it. The number of deaths from playing professional football and college football are fifty to a hundred times higher than even the wild exaggerations about steroids. More people have died playing baseball than have died of steroid use. Three critics say that allowing their use is coercive, that you’re forced to use them. But the first year that baseball did universal testing, anonymous testing, only six percent of the players were positive. From those numbers, it seems that 94% were able to play at a very high level and didn’t feel coerced at all. Coercion is the use or threat of force that's never occurred in this country to the best of my knowledge. There is no entitlement to play professional sports; it’s a privilege requiring an enormous sacrifice and taking on enormous risks, with or without steroids. Many walk away from it and choose not to do it, and no one is forced to take it on. Four, critics claim that steroids undermine fan interest, and this is simply empirically false, baseball attendance has ridden steadily in the steroid era, professional football is even more popular, and Barry Bonds, widely assumed to be a steroid user, is the biggest draw in sports, adding ten thousand fannies in the seats everywhere he The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” goes. Chicks love the long ball, guys love the long ball, they don’t care what they're using. Fifth, critics claim that steroids undermine the integrity of records. This is naïve, the records are not comparable with or without steroids or growth hormone. Baseball fences are shorter, the mound is lower, the ball is livelier, and Coors Field is a mile above sea level. By one estimate, Babe Ruth playing in today’s ball parks would hit a thousand home runs, not the mere seven hundred and fifty that Hank Aaron and Bonds have hit. The only valid comparison is with peers playing in the same arenas with the same equipment against the same opponents, and Ruth hit more home runs in one season than any other team. He is in a league of his own, and no one has come close. Finally, critics claim that steroids present bad role modeling for children—

Everyone agrees these drugs should be banned for children. The adverse effects are different, they stunt growth, they are not competent to make informed choices. I support testing in schools, not to punish the kids, but to catch the peddlers. Anyone caught selling drugs to children should be hung, followed by a fair trial. In closing, when you go out to dinner tonight, enjoy the wine that relaxes you, or start your day The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” tomorrow with a double mocha latte that gets you going, but please be less critical of others who, like you, try to enhance their performance in a variety of ways. Thank you.

### Moderator
Claim: That is deep-, deeply, deeply Freudian.

### Conspiracy Advocate (CA)
Claim: …eh…Alzado is constantly rolled out as a poster child for the horrors of steroids. I ask you in the audience to quickly name, in The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” your own minds, a single elite athlete who’s had a stroke or a heart attack while playing sports. It’s hard to come up with one. Anabolic steroids do have undesirable side effects: acne, baldness, voice changes, intrangent infertility. But sport itself is far more dangerous, and we don’t prohibit it. The number of deaths from playing professional football and college football are fifty to a hundred times higher than even the wild exaggerations about steroids. More people have died playing baseball than have died of steroid use. Three critics say that allowing their use is coercive, that you’re forced to use them. But the first year that baseball did universal testing, anonymous testing, only six percent of the players were positive. From those numbers, it seems that 94% were able to play at a very high level and didn’t feel coerced at all. Coercion is the use or threat of force that's never occurred in this country to the best of my knowledge. There is no entitlement to play professional sports; it’s a privilege requiring an enormous sacrifice and taking on enormous risks, with or without steroids. Many walk away from it and choose not to do it, and no one is forced to take it on. Four, critics claim that steroids undermine fan interest, and this is simply empirically false, baseball attendance has ridden steadily in the steroid era, professional football is even more popular, and Barry Bonds, widely assumed to be a steroid user, is the biggest draw in sports, adding ten thousand fannies in the seats everywhere he The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” goes. Chicks love the long ball, guys love the long ball, they don’t care what they're using. Fifth, critics claim that steroids undermine the integrity of records. This is naïve, the records are not comparable with or without steroids or growth hormone. Baseball fences are shorter, the mound is lower, the ball is livelier, and Coors Field is a mile above sea level. By one estimate, Babe Ruth playing in today’s ball parks would hit a thousand home runs, not the mere seven hundred and fifty that Hank Aaron and Bonds have hit. The only valid comparison is with peers playing in the same arenas with the same equipment against the same opponents, and Ruth hit more home runs in one season than any other team. He is in a league of his own, and no one has come close. Finally, critics claim that steroids present bad role modeling for children—

### Moderator
Claim: One minute.

### Conspiracy Advocate (CA)
Claim: Everyone agrees these drugs should be banned for children. The adverse effects are different, they stunt growth, they are not competent to make informed choices. I support testing in schools, not to punish the kids, but to catch the peddlers. Anyone caught selling drugs to children should be hung, followed by a fair trial. In closing, when you go out to dinner tonight, enjoy the wine that relaxes you, or start your day The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” tomorrow with a double mocha latte that gets you going, but please be less critical of others who, like you, try to enhance their performance in a variety of ways. Thank you.

### Moderator
Claim: Thank you, Dr. Fost. And now speaking against the motion, Dick Pound.

### Scientific Advocate (SA)
Claim: Thank you. This evening’s debate deals with one of the most important problems facing sport today: doping, the use of performance enhancing drugs and methods. It’s important because it affects the health of the athletes who practice it, and those who emulate the sport heroes thought they admire. It’s important because it goes to the very heart of sport and its integrity. I want to focus on two elements in this portion of my remarks: health and integrity. So let’s start at the beginning. Sport, like this debate, is governed by rules, to which the participants agree. In fact, the rules are the essential element of sport as we know it. Some of them may seem arbitrary, why the race is a hundred meters as opposed to ninety-five or a hundred and five, but they are the rules, and they are the rules on which we agree. One of those sport rules is that participants do not take certain drugs or use certain methods for performance enhancement. And also, we should be clear here, until there is a rule against the use of something, it may be foolish, it may be The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” dangerous, but it can't be criticized as a breach of ethics or a rule of conduct. Don’t get led off into the wilderness by examples from ancient Greece and so forth that preceded the rules that we now face today. Once there is a rule, however, that becomes the deal, and part of the game, whether the rule relates to drugs, equipment, or anything else central to the sport. And those rules become our deal with each other’s, other, as participants. If you don’t like the rules, unlike society in general, you're not obliged to participate. You can find somebody who wants to play by the rules that you prefer. Almost all of the prohibited substances and methods have the potential to damage the health of the athletes. In the 1950’s and 1960’s before there were rules, veterinary products were used to beef up the human cattle. Shot putters went from throwing from sixty feet to seventy feet. It’s true, they had terminal acne, testicles the size of jelly beans, a sperm count of zero, and were in a perpetual rage, but boy, they could sure toss the shot a lot further. The initial anti-doping rules were adopted mainly as a result of concerns regarding health. A Danish cyclist died during the 1960 Olympics in Rome, that was the Olympics in which I participated. And he died as a result of drug use. He didn't just get sick, or incur a long term health problem, or fall off his bike and skin his knees. He died. If a particular sport rule proves to be no good or unnecessary, or in need of amendment, the sport can change it. There’s no problem The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” about that. But you as a participant cannot do it unilaterally and clandestinely. Why do you suppose that no one, no one with any responsibility, let me underline that, is willing to say let the athletes do whatever they want? Even the professional leagues don’t say that. They know perfectly well there’s a danger to health. With the rules comes a question of trust. We have expectations of each other that we play in accordance with the rules that we agreed upon as part of our participation, including rules prohibiting drug use. We’re ready to demonstrate that compliance at any time, that’s also part of our deal. We don’t hide behind spurious claims of privacy. We agree on the penalties if there’s a breach of the rules. And the sport rules on drug use are no different from sport rules regarding such things as gambling. Pete Rose has been kept out of the Baseball Hall of Fame because of gambling, because nobody was really sure whether they were watching real sport. In the, in more modern times, my, my view is that Henry Aaron has a record, Barry Bonds has a number. When there’s a breach of that trust, you have to see what it is. And drug use in sport is no more or no less than cheating, and in most cases, dangerous cheating. Remember that, that athletes don’t take these drugs to level the playing field. They do it to get an advantage. And if everyone else is doing what they're doing, then instead of taking ten grams or ten cc's or whatever it is, they’ll take twenty, or thirty, or forty, The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” and a vicious circle simply gets bigger. The end game will be an activity that’s increasingly violent, extreme, and meaningless, practiced by a class of chemical and/or genetic mutant gladiators. The use of performance enhancing drugs is not accidental, it is planned and deliberate with the sole objective of getting an unfair advantage. I don’t want my kids, or your kids, or anybody’s kids to have to turn themselves into chemical stockpiles just because there are cheaters out there who don’t care what they promised when they started to participate. I don’t want my kids in the hands of a coach who would encourage, condone, or allow the use of drugs among his or her athletes. I was always struck by Vince Lombardi, a wonderful coach. There’s one thing he said that I wish he hadn't, when he said, “Winning is the only thing.” It’s not. I liked it much better when he said, “If you're not fired with enthusiasm, you will be fired with enthusiasm.” That’s a much better message. So, going forward, what we need is an increased change of attitude. Cheating in sport destroys everything—

…that the athletes set out to accomplish. It turns them, among other things, into liars. Marion Jones persisted with a lie for more than seven years. Ben Johnson lied to me in 1988. I was The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” really looking forward to having him here tonight, twenty years later. It’s too bad his lawyers pulled him out of this at the last minute. But attitudes can change, even big attitudes like this. If, if ten years ago I had said that in ten years from today it would be illegal to smoke a cigarette in a restaurant in Paris, you’d have laughed. So, it’s important for me to keep up, keep the question of doping and drug use from becoming banal and being turned into various shades of gray. The issue of cheating is not gray, it’s black and it’s white. Drug use may not affect fan interest, but it should, and that's our failure as fans, compounding the failure of drug-using players in the leagues.

Are these really our personal values, that dangerous cheating is what we stand for? Bishop, let me finish with Bishop Fulton Sheen, he had a great thing. He said, if it’s wrong, it’s wrong. Even if everybody is doing it. And if it’s right it’s right, even if nobody’s doing it.

### Moderator
Claim: One minute.

### Scientific Advocate (SA)
Claim: …that the athletes set out to accomplish. It turns them, among other things, into liars. Marion Jones persisted with a lie for more than seven years. Ben Johnson lied to me in 1988. I was The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” really looking forward to having him here tonight, twenty years later. It’s too bad his lawyers pulled him out of this at the last minute. But attitudes can change, even big attitudes like this. If, if ten years ago I had said that in ten years from today it would be illegal to smoke a cigarette in a restaurant in Paris, you’d have laughed. So, it’s important for me to keep up, keep the question of doping and drug use from becoming banal and being turned into various shades of gray. The issue of cheating is not gray, it’s black and it’s white. Drug use may not affect fan interest, but it should, and that's our failure as fans, compounding the failure of drug-using players in the leagues.

### Moderator
Claim: Please finish up.

### Scientific Advocate (SA)
Claim: Are these really our personal values, that dangerous cheating is what we stand for? Bishop, let me finish with Bishop Fulton Sheen, he had a great thing. He said, if it’s wrong, it’s wrong. Even if everybody is doing it. And if it’s right it’s right, even if nobody’s doing it.

### Moderator
Claim: Our thanks to Dick Pound, and uh, I indicate no disapproval of the opinions about to be expressed by Radley Balko when I note that he is ironically named to be on themselves panel. Radley, Radley Balko, for the motion that performance enhancing drugs The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” in competitive sports should be accepted.

### Conspiracy Advocate (CA)
Claim: Well, let me start by saying, for those of you who might be confused, I am not Ben Johnson. On the train ride from DC this morning, we passed through Baltimore. Doing so reminded me of one of my favorite authors, Baltimore native H.L. Mencken, who I think would have had a good laugh at the hypocrisy, the posturing, the uh, moral prudery that’s associated with this steroid controversy. Eighty years ago Mencken aptly summarized this debate when he wrote, quote, “The urge to save humanity is almost always a false face for the urge to rule it.” So why are we here tonight? Is this about saving sport, or is this about some people imposing their view about what sport should be? If we’re here to talk about fairness in competition, I'm dubious. Take representative Tom Davis, one of the more cam-, camera hungry politicians to demagogue this issue. After the 2000 census, Representative Davis maneuvered to have his Congressional District gerrymandered to include as many Republicans as possible, ensuring his continual reelection, eliminating the real number of options for his constituents to vote. He ran the next year unopposed. Davis also snuck a, a provision into an unrelated piece of Federal legislation preventing an apartment complex from going up in his district because, he told the Washington Post, he feared it would bring too many The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Democrats into the district. This guy is cheating at Democracy, and he’s lecturing baseball players about fairness. If we want to talk about the health risks of professional sports, we might discuss the ballooning weight of NFL lineman over the last twenty years, or the corresponding life, drop in life expectancy that’s come with it. Or you might talk about the particularly hellish world of thoroughbred horse racing jockeys, who subject themselves to sweat boxes, diuretics, suppositories, and intentional eating disorders. In fact, any world class athlete subjects his body to stresses it wasn’t really designed to endure. And as we’ve seen with government bans on consensual activity, from alcohol to gambling to cocaine to prostitution, prohibitions not only don’t work, they make the activity in question more dangerous by pushing it underground. So what about the children? Survey data actually shows that teen steroid use has mirrored the use of other elicit drugs over the years. It went up mildly in the 1990’s, and has since either dropped off slightly, or leveled off since 2000. It’s likely that the same trends that govern cocaine or marijuana use govern teen steroid use far more than what’s happening in the sports pages. In fact, a study released last year, and one of the few studies to actually attempt to find out what motivates teen boys to take steroids, found that the most reliable indicator of steroid use was a teen’s own self, self esteem and body image. The suggestion, and I think we can all The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” agree it’s pretty intuitive, is that teenage boys who do take steroids do so not because they want to look like Barry Bonds or Mark McGwire, but because they want to look good for teenage girls. So what is this debate really all about? I’d suggest it’s about paternalism, and it’s about control. We have a full blown moral panic on our hands here, and it’s over a set of substances that, for whatever reason, has attracted the ire of the people who have made it their job to tell us what is and isn't good for us. Our society has an oddly schizophrenic relationship with pharmaceuticals and medical technology. If something could be said to be natural, we tend to be OK with it. If it’s lab made or synthetic, we tend to be leery. But even synthetic drugs and man-made technology seem to be OK if the aim is to make sick people better, or broken people whole again. And so when we talk about expanding or transcending what we consider to be normal, uh, then a certain uneasiness starts to set in. There was an article in The Chronicle of Higher Education last month about university professors taking stimulants like Adderall to increase their academic productivity. Oddly, the article quoted, quoted several professors who considered this cheating at academics. I have to confess, I really don’t understand this way of thinking. Academics is the search for truth and knowledge, if a drug can make that search more productive with few side effects, why in the world wouldn't you take it? It’s also important to note that The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” what we consider completely natural and acceptable today was quite out of the ordinary not too long ago. A hundred years ago life expectancy in the US was fifty, today it’s seventy-eight. Thanks to technology, medicine, and pharmaceutical, we’re today taller, stronger, faster, healthier, and expecting to live longer than ever before. Genetically advanced agriculture, anti-aging technology, and other advancements we’ve yet to see today will likely push our longevity even farther. It’s an old cliché that sports is a metaphor for the human condition, but there’s a lot of truth to that. As technology helped humanity obliterate a lot of these milestones, and helped us move beyond what, until a hundred years ago, had been a long, bleak history, similar advances over the years in nutrition, training, and using technology to improve technique have enabled sports records to fall with astonishing regularity. Sports is about exploring and stretching the lengths of human potential. Going back to even the pre-modern Olympics, when athletes ate live bees, and ate crushed sheep testicles to get a leg up on the competition, uh, sports has never been about physical ability alone. It’s been, been about ingenuity, innovation, and knowledge about what makes us faster and stronger, and avoiding what might do us harm. It’s always been part of the game. It shouldn't be surprising, then, that many of the biggest proponents of banning performance enhancing drugs in sports are also suspect of some The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” of these continued advancements in human achievement. Leon Kass, former, formerly President Bush’s top advisor on bio-ethics, this is the same Mr. Kass who champions rigorous sports testing, has also spent much of his career actually lamenting the fact that human beings are living longer than ever before. He considers this contrary to some odd concept of natural order. Uh, of course there have been luddites and naturalists like Mr. Kass standing athwart the tide—

…of human progress for much of human history. The essence of the agreement today I think is what people like Mr. Kass and some of our opponents tonight, they have a decidedly different definition of what’s pure, natural, and human than what I do. I think the difference is that I'm sort of willing to take a live and let live approach and let everyone sort of explore their own boundaries and their own potential. Um, whereas I think some of our opponents are more interested in opposing their view of what is natural and what is, uh, human on everyone else, which of course brings us back to Mencken. I think, uh, our opponents want to legislate away what they believe are bad decisions, and if a free society means anything, it means we should be able to make all decisions, including the bad ones. Thank you.

### Moderator
Claim: One minute.

### Conspiracy Advocate (CA)
Claim: …of human progress for much of human history. The essence of the agreement today I think is what people like Mr. Kass and some of our opponents tonight, they have a decidedly different definition of what’s pure, natural, and human than what I do. I think the difference is that I'm sort of willing to take a live and let live approach and let everyone sort of explore their own boundaries and their own potential. Um, whereas I think some of our opponents are more interested in opposing their view of what is natural and what is, uh, human on everyone else, which of course brings us back to Mencken. I think, uh, our opponents want to legislate away what they believe are bad decisions, and if a free society means anything, it means we should be able to make all decisions, including the bad ones. Thank you.

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Radley Balko, thank you. And now speaking against the motion, Dale Murphy.

### Scientific Advocate (SA)
Claim: To, to accept this motion would simply set us back. Accurately just mentioned, studies, recent studies are showing that young athletes and high school kids are, are using performance enhancing drugs to a lesser degree. To legitimize, um, the performance enhancing drugs in sports I feel would send the wrong message to young athletes. There are certainly legitimate uses for human growth hormone and steroids, um, as, as we all know. That’s why they’re a controlled substance under a doctor’s orders. But to hit a baseball further, or to run a hundred yard dash faster is not the reason and the legitimate use of these, uh, of these drugs. Um, Dr. Fost mentioned that at one point in time there were six percent that were using, um, performance enhancing drugs in the major leagues. It really makes my point exactly. Ninety-four percent of the guys were not using, then that tells me that you don’t need these things to be the best athlete in the world, that there are plenty of legitimate ways to get bigger, stronger, and faster that everyone has access to, equal access to. Um, if accepted, what about those, for instance, in Major League Baseball, what about those who do not want to use it? The The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” playing field, then, once again, is, is not level. Um, the only way, someone said earlier, the only way you could probably make this work is that if you forced everybody to take performance enhancing drugs, which um, we all know wouldn't work. Um, people do not want to see, I would argue the point that people do not want to see performances, uh, based on, uh, false premises, that it is, it is their ability, athletically or psychologically or mentally, alone, um, that if it’s being enhanced people do not want, accept that. You mentioned Barry Bonds adding, um, seats, um, fans in the seats every game he played. I would have to say that in San Francisco he was, um, generally accepted, but everywhere else he went, I think those ten thousand extra went there to jeer him and his accomplishments. After the season, after all this has come out with Mark McGwire, I think most of us look back now and say we got caught up in something that we really didn't want to support. If there was no alternative, I could understand us giving into this problem. Certainly there are a lot of problems that young people have and society has. But this is one of them. If, uh, if there are a, a percentage of young athletes still taking performance enhancing drugs, to me it’s still a problem. Um, and if there was no answer to, uh, this problem I think I would understand giving in, and voting, uh, in favor of this motion. But I believe that there is a pro—there is an answer to the problem. And, uh, as was mentioned earlier we look at The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” smoking in public. Uh, we— most of us grew up with that being totally acceptable and now it’s against the law, there’s truly been a culture change. There can be a change in culture in professional athletics, and I believe that it is starting. We need, uh, better testing, harsher punishments, and, and people will decide not to get involved with performance-enhancing drugs. Uh, gambling in baseball is the perfect example. Um, the culture of, uh, professional baseball players is the one thing they know, and, and one thing they learn from the minute they sign a professional contract, is that if you gamble on the game in any way, shape or form, your career will be over. Uh, my understanding is, uh, I don’t have any statistics to show this, but once one of the greatest hitters, uh, is kicked out of the game because he gambled on the sport, that reinforced the culture in baseball that you don’t gamble on baseball. I believe we can change the culture, and to accept this motion, really would set us back with the progress that we have made. After tonight, I think you will see—you will feel, uh, as you listen closely, that, you feel as I do, that there is no sustainable, logical, reasonable, um, uh… reason, for these things to be accepted. If you put any of these, uh, alleg—these, uh, positions under scrutiny, I think you will all come to understand, that we simply do not need this in sports at any level. Let alone the high school kids that see professional athletes and are tempted to use them. If you put an age limit on The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” use, you’re still gonna have abuse at the younger ages. To me it’d be much better…to change the culture and the idea and the thinking about competing in sports. And we are making progress, and studies have shown that. Certainly we don’t want all of our athletes to look like the American Gladi—Gladiators or professional wrestlers. Um…if, if that’s what we want, with all of our ath—athletes, um, then I can understand that but I don’t think that’s what the public wants. As far as baseball is concerned, certainly people like the long ball. Um, but, uh, this, this past year was, in the la—in the last 10 years, this past year, had the seventh fewest home runs of the last decade, and yet we broke records again with attendance. Attendance is good, home runs do not have to be up. People love the game, they appreciate the game, they appreciate finesse. Um, again, we don’t all want to look like professional wrestlers out there and I don’t think that’s what the fans want. Um…uh…I think the, uh, um…the thing too you need to be careful about is drawing, uh, as—

—as was mentioned earlier is drawing, um, the opposing side, drawing, drawing analogies and conclusions, with things that really are not, uh, are not comparable. For instance— um, um, comparing, uh, anabolic steroids or performance-enhancing The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” drugs to the Greeks wearing tennis shoes. Or to the ancient Greek athletes, uh, eating bees. This is not what we’re talking about and that is not—to me does not compare, what we’re talking about, is drugs that are a controlled substance that have very many good, legitimate uses. As was mentioned over a million kids take human growth hormone, they don’t take human growth hormone without exhaustive studies to make sure that they are not already producing enough on their own. When kids abuse these drugs, and athletes abuse these drugs, I don’t think there’s any question that we know, uh, that there are side effects. And some of ‘em we do not know now.

Especially with our use. What concerns me is the example that the athletes at the highest level set for our youth. I feel like we’re making progress and a vote in favor of this motion would, would, uh, be definitely a step backward, backward, in our efforts to, uh, correct this problem. Thank you.

### Moderator
Claim: One minute—

### Scientific Advocate (SA)
Claim: —as was mentioned earlier is drawing, um, the opposing side, drawing, drawing analogies and conclusions, with things that really are not, uh, are not comparable. For instance— um, um, comparing, uh, anabolic steroids or performance-enhancing The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” drugs to the Greeks wearing tennis shoes. Or to the ancient Greek athletes, uh, eating bees. This is not what we’re talking about and that is not—to me does not compare, what we’re talking about, is drugs that are a controlled substance that have very many good, legitimate uses. As was mentioned over a million kids take human growth hormone, they don’t take human growth hormone without exhaustive studies to make sure that they are not already producing enough on their own. When kids abuse these drugs, and athletes abuse these drugs, I don’t think there’s any question that we know, uh, that there are side effects. And some of ‘em we do not know now.

### Moderator
Claim: Wrap up—

### Scientific Advocate (SA)
Claim: Especially with our use. What concerns me is the example that the athletes at the highest level set for our youth. I feel like we’re making progress and a vote in favor of this motion would, would, uh, be definitely a step backward, backward, in our efforts to, uh, correct this problem. Thank you.

### Moderator
Claim: Dale Murphy, thank you. Now as the format indicates before we hear from Julian and from George, I’ll direct, uh, a question of my own toward either side of the debate. Dick Pound, you have stated that there are obvious health risks to the The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” use of performance-enhancing drugs, steroids in particular. Are those health risks truly obvious.

### Scientific Advocate (SA)
Claim: I—I think they are too anybody who’s, who’s studied these, uh, issues, and, and I think it—they’re obvious to, uh, the folks that have had to deal with, uh, badly damaged or dead athletes. If you take cycling as an example they, there, there’ve been dozens and dozens and dozens of, of, of young men who’ve had heart attacks. They’ve had heart attacks because their hearts can’t pump the sludge that their blood has become, uh, as a result of

### Moderator
Claim: Doctor—

### Scientific Advocate (SA)
Claim: So yes, there are real dangers—

### Moderator
Claim: Dr. Fost points out that, there have been more players killed, one at the major league level and many at the amateur level, playing baseball, than have been killed because of steroid use as baseball players. And many more killed or seriously injured playing football, which is incidental to playing the sport, than…we’re able to determine have suffered serious health consequences because of steroid use, how would you respond to that? Yes—

### Scientific Advocate (SA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Me still? I—I would say that the, part of the difficulty with this is, is collecting data, both his and, and other data, because, for many years, all of this use has been clandestine, and hidden. And so you don’t have the, the, the, the data that are, uh, as accurate or as complete as you’d like.

### Moderator
Claim: Radley Balko, uh, you are advocating a live-and-let-live approach to this. Isn’t it a reasonable response to that to say, fine, that’s one argument for a different day about society in general. But all sports have rules which regulate the competition. No one can stop me in my back yard from using an aluminum bat if I wanna play a game of my own. But they can in a major league game. Cork and saliva are perfectly natural and legal substances but not in the context of major league baseball. So why are these— why are these things analogous.

### Conspiracy Advocate (CA)
Claim: Well, I—I agree, um, I think we’re—what we’re debating tonight is what the rules ought to be, um, I’m not advocating, uh, uh, I’m not defending the people who have been caught cheating, I think, uh, I think Mr. Pound is right, when you enter into a league and you agree to, to compete, uh, you agree to a predetermined set of rules. Um, but I think tonight what we’re trying to determine is, is what those rules ought to be. Um, and I think that, you know, The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” I think that athletes, uh, care about their bodies and they care about their, their earning potential. Uh, they care about the next season, and I think they are going to seek out a competitive advantage, but they’re not going to do so to the point where, they jeopardize future earning potential or they jeopardize the next season. I think, I think people, uh, have, I think athletes have a little bit, uh, more respect for their bodies than that.

### Moderator
Claim: Although you’re probably aware that there have been surveys of Olympic athletes who have been asked the question, if it would guarantee a gold medal, would you reduce your life expectancy by 20 years to get it. You’re dealing with people who are in their late teens to…early twenties in many cases, they have a certain sense of vulnerability, a reduced lifespan from 80 to 60 may seem somewhere in the distant future. A huge percentage of them answer yes.

### Conspiracy Advocate (CA)
Claim: Well, I mean and if, if the, you know, US Olympic Committee wants to, to, uh, set those rules, uh, you know, I, I, I think there are important distinctions to be drawn, uh, uh, between amateur athletics and professional athletics but, uh, you know, I—I think, uh, a couple ones, I think… First of all I think, private leagues and private sports, uh, professional sports organizations should be able to set their own rules, I’m not advocating, uh, that The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Congress mandate to the, the NFL that they have to allow performance-enhancing drugs. Uh, but I also think, don’t think that it’s any business of Congress telling leagues that they’re— they have to ban them as well, uh, I think that, uh, uh, the league should be able to set their own rules and I think the people will, uh, athletes will, will, uh…lobby to get the rules that both reflect their desire to get a competitive advantage but also protect their health.

### Moderator
Claim: All right, now let’s, uh, return to the formal presentations, and, uh…presenting his viewpoint for the motion, Julian Savulescu.

### Conspiracy Advocate (CA)
Claim: The finest, uh, Italian cyclist, Fausto Coppi was once asked, and winner of the Tour de France was once asked, uh…how often had he taken la bamba, or amphetamines during his career, he said, only when absolutely necessary. And when asked precisely how often that was he said, almost always. Another Tour de France, Jacques Anquetil in a debate with a French politician said, what do you expect us to do, ride the tour on mineral water? Where our team agrees with, uh, Dick Pound and, and, uh, the opposition is that this is really only the tip of the iceberg. The war on drugs has failed, drugs have always been present in sport, and we’re only seeing probably less than 5 percent of the drug-takers being caught. Not only has it failed, it The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” must fail. Growth hormone is extremely difficult to detect, blood doping is also extremely difficult to detect, and in the future we’ll have gene doping. Insulin-like growth factor can be injected into muscles, to improve muscular strength, it would have to be detected with a muscle biopsy. Uh, science has created super- mice capable of running six, uh, kilometers instead of 200 meters, by altering their glucose metabolism. They’ve created Schwarzenegger mice with vastly stronger muscles and marathon mice capable of running much faster marathons, these could all be done in humans. We will not be able to detect these changes. Not only is the war on drugs bound to fail, uh, it also has other adverse effects, it reduces interest, this year, uh, in the Tour de France the race leader Michael Rasmussen, was, uh, sacked by his team on allegations of taking drugs. There’s always a cloud over winners, of whether they’re taking drugs or not. It’s unfair, the honest athletes are penalized because they’re denied access to safe performance enhancers and of course the rich can buy the undetectable enhancers. They can buy hypoxic air tents for 7000 US dollars which are legal, whereas EPO, which is banned, costs only 120 US dollars a month. But most of all it’s unsafe. What happens is there’s pressure to develop undetectable performance enhancers with no eye to the safety. The BALCO scandal illustrates what a back yard situation we have at the moment. What is policy and the current zero-tolerance approach The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” to drugs in sport, is inconsistent and confused. External technologies like hypoxic air tents, or altitude training, are acceptable, they raise the red blood cell level, yet if we do this directly by retransfusing our own blood, blood doping, or using EPO, a natural hormone, that’s illegal. Yet they all have exactly the same effect. Some enhancers have been permitted in sport. Caffeine increases the time to exhaustion, or reduces the time, uh, increases the time to exhaustion by 20 percent. It used to be illegal, athletes were stripped of their medals for taking caffeine, it’s now legal, and it hasn’t corrupted the spirit of sport, it hasn’t had the effect of creating violent mutant gladiators, as the opposition has suggested. Creatine also increase the time to exhaustion by 10 percent, it’s also legal. Tour de France riders use intravenous nutrition to give them enough calories, uh, overnight, and of course Tiger Woods has used lasik eye surgery to give him better than 20/20 vision. None of these have had adverse effect on sport. One of the major arguments is that it’s against the spirit and integrity of sport, Dick Pound wrote—raised this issue. When Dick Pound was asked in an interview with the New York Times which performance enhancements he thought were against the spirit of sport he said, it’s like pornography. You know it when you see it. Well of course D.H. Lawrence’s novels were thought to be pornographic a century ago, they’re not now. Professional classical musicians regularly take beta blockers to The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” reduce, trim and enhance their performance. The music sounds good, it’s not against the spirit of music. The spirit of sport is entailed in what sport is, it’s the display of human physical excellence. Indeed, just as we can increase the artistic expression through the use of beta blockers to enhance musical performance we could use them to enhance performance in archery, or indeed, in many, uh, sports requiring control of anxiety. Ben Johnson famously said, the human body was not meant to run at the speeds it’s asked to run today. To recover from the grueling training necessary to run those times you need steroids to increa—increase recovery. And of course, Tiger Woods has used lasik eye surgery, and that hasn’t been seen to compromise the spirit of golf. To say that we should reduce…drugs in sport or eliminate them because they increase performance, is simply like saying that we should eliminate alcohol from parties because it increases sociability. So our proposal, is that we allow a modest approach. We allow performance enhancers which are safe, and consistent with the risks that athletes already entail. You’ll notice that Dick Bou— Dick Pound has had to reel out examples from the ‘60s of deaths from steroids, when they were taken orally. And indeed the blood doping deaths all occurred in the ‘90s before the International Cycling Union set a maximum hem—hematocrit of 50 percent. No athlete today is dying in competition from taking The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” EPO. Indeed I would prefer to take growth hormone prescribed by a doctor, than compete in professional American football, because I know of no ventilator-dependent quadriplegic caused by taking growth hormone. The drugs need to be consistent with the spirit of an activity, creating webbed hands and feet, which is possible, which is possible, would compromise the spirit of spearing— swimming. But allowing athletes to recover from injuries consistent of sport. We should set limits, as the International Cycling Union has done, on the hermatocrit…and test health, not test for drugs. It makes no difference whether an athlete’s hermatocrit goes from 46 to 48 percent, by altitude training or by taking EPO or blood doping. It’s a waste of time trying to detect

Drugs in sport, far from being against the sport, embodies the human spirit. We are not horses or dogs, flogged to display our maximum biological potential, the spirit of being human, is to make choices. To be human is to be better. To make, to make choices, and performance enhancement as we’ve argued per se is not against the spirit of sport, it embodies the history and spirit of sport. It’s true that cheating is ruining sport. But there are two ways to reduce cheating. One is to ramp up the war on The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” drugs which is bound to fail, the other is to change the rule, the rules to allow regulated, supervised access. We agree that you should hear—adhere to the rules. But the rules will provide a better spectacle, protect the athlete’s health, narrow the gap between the cheaters and the honest athletes, if we allow access to safe performance enhancers. One of the greatest advantages of allowing, uh, the, the access—

—the access to performance enhancement is the, the limited funds that are used by what are $22 million, could be better devoted to detecting those drugs which are seriously against athletes’ health, rather than wasting time on substances that do not harm their health, and are actually already a part of the sport. Thank you.

### Moderator
Claim: One minute.

### Conspiracy Advocate (CA)
Claim: Drugs in sport, far from being against the sport, embodies the human spirit. We are not horses or dogs, flogged to display our maximum biological potential, the spirit of being human, is to make choices. To be human is to be better. To make, to make choices, and performance enhancement as we’ve argued per se is not against the spirit of sport, it embodies the history and spirit of sport. It’s true that cheating is ruining sport. But there are two ways to reduce cheating. One is to ramp up the war on The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” drugs which is bound to fail, the other is to change the rule, the rules to allow regulated, supervised access. We agree that you should hear—adhere to the rules. But the rules will provide a better spectacle, protect the athlete’s health, narrow the gap between the cheaters and the honest athletes, if we allow access to safe performance enhancers. One of the greatest advantages of allowing, uh, the, the access—

### Moderator
Claim: Please wrap up.

### Conspiracy Advocate (CA)
Claim: —the access to performance enhancement is the, the limited funds that are used by what are $22 million, could be better devoted to detecting those drugs which are seriously against athletes’ health, rather than wasting time on substances that do not harm their health, and are actually already a part of the sport. Thank you.

### Moderator
Claim: Julian Savulescu, thank you, and now our sixth and final debater, speaking against the motion, George Michael, George.

### Scientific Advocate (SA)
Claim: Don’t start my timer. He’s from St. Louis, he’s a Cardinal fan like me. Bob, I have embroidered Mark McGwire’s 70 home run single-season T-shirts, $39, do you have any? Do you wear ‘em?

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Uh, they’d be too big for me.

### Scientific Advocate (SA)
Claim: I gotta give mine away, it kills me that he had to be on anabolic steroids but that’s another story, the reason I’m here tonight, is that I’ve talked to a lot of these athletes, I’ve spent the last…I guess since I first talked to Rich Pound almost, almost six weeks talking to athletes…and trainers, and they all say the same thing. Don’t use my name. Don’t use my name. So I’ll avoid the names but there are a couple things we need to know. Number one, the rules of the game say that steroids and for good reason, performance-enhancing drugs are absolutely illegal. Cheating is cheating and you can’t change it, you can do it any way you want with any documentary but you can’t change it. Steroids however you have to know this. They will make you faster, they will make you stronger, and they make help you look and feel and be younger. That’s a lot of attraction. Steroids will make you wealthy. Steroids will make you famous. Steroids will help you get success and if you don’t believe it, look at some of the guys that hold the records. During the course of my preparation I talked to a Hall of Famer. I said let me ask you something. I said with the steroids, you didn’t have ‘em when you were playing. What if there were steroids now. And he said if it got me back on the field, regardless of the penalty, I’d do it. I thought man, Hall The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” of Famer, you wanna play—he said you don’t know what it’s like, not to be able to excel at the game anymore. Said steroids are the greatest attraction, it’s like walking on the beach with no one around, you and a beautiful girl. You know what’s gonna happen. Said, well. I had to tell my wife, I can’t talk about that one. However…even though there is no clinical proof, let me repeat, there is no clinical proof that steroids directly lead to death, there are certain guys have suffered something, now, Lyle Alzado was mentioned. Lyle Alzado is— as—Alzado is not a name to me. I knew him, I interviewed him, I liked him. Thought he was crazy, but that’s why we got along. Lyle Alzado…this is what’s not commonly discussed, when he was a freshman in college, weighed 190 pounds. When he graduated as a senior and he started steroids in 1969 as a freshman. When he graduated it was 300-pound muscle mass. That’s a gain of 110 pounds, and you knew he was going big in the NFL draft. Went on to become the NFL Defensive Player of the Year in 1977. Couple of weeks before he died he said, damn, if I’d never done steroids and human growth hormone, I wouldn’t be dying today. He died, at the age of 43. 43 years old. Ken Caminiti. He’s a third baseman for the Padres, it’s spring of 1996. He’s chasing a fly ball, he goes out, he dives. He tears his rotator cuff. Ken Caminiti was a good guy, a tough guy, a bull of a guy. He said I gotta get well, so he played even though he was in great pain.

The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Said Ken. Go down to Tijuana, get you some anabolic steroids, you’ll be back on the field better than ever. So he did. In the year 1996 when he got hooked on steroids and didn’t just do cycles, but did double cycles, so don’t tell me we’re gonna monitor it. Ain’t nobody gonna monitor it. He used so much steroids, that he became a giant of a man, he was bulging, Ken Caminiti went from hitting .282, to hitting .330. He went from 23 home runs to 40 home runs, he had 130 RBI’s, he made millions on a free-agent contract, and, he was absolutely hooked, he said, the more I used the more I had to use, because if I didn’t use I felt like I was going on the field naked. Nobody wants to walk out on a field naked. But that’s how he felt. ‘Cause he said, I was hooked. He was the MVP of baseball in 1996. Eight years later he was dead, at the age of 40. But, there’s no clinical proof that steroids led to his death. Even though, he was an ala—anabolic steroid type free. If any of you are Yankee fans, think back to 1999. The Yankees win the World Series. They have a relief pitcher you may or may not have heard of named Dan Naulty. You ever heard of him, Bob?

Dan Naulty pitched for the Twins then became with the Yanks. Now follow this, in 1992 Don Naulty was six foot eight, The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” he’s a strapping right-hander, he weighs only 165 pounds. Guy said to him, Don, you gotta get on some steroids, man, you put some body on you. So he did. In 1999 he was with the Yankees, he weighed 245 pounds. That’s a weight gain of 60 pounds. And it was all muscle. Unfortunately he described himself as being suicidal, he said, “I was absolutely nutso.” Now he didn’t die, he survived. But he had to have major surgery because his veins were clotted against his arteries. He had to have major surgery because he tore the muscle right off—the, the muscle and the groin completely off the bone. Dr. James Andrews, a man I consider to be one of the foremost absolutely best surgeons of all. He said—he’s a north—noted orthopedic surgeon, he said that…now check this out. That in 2002, 17 percent…17 percent of total baseball payroll went to guys who were on the injured list with muscle tears, muscle strains, ruptured Achilles tendon, and on goes the list. He said that we have had a 200 percent increase in just the five years prior to 2002. Baseball owners paid $370 million to players who were not able to play. Most of them accord9ing to Dr. Andrews, were related to their use of anabolic steroids. And you now wanna admit—legalize it, and govern it? No definitive clinical proof though, that it was the result of steroids. No proof. I’m probably the only guy in the room who is friends with professional wrestlers, I started in 1980 with Bob Backlund. I’ve MC’d a lot of their events, I’ve enjoyed ‘em, I love The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” ‘em. Guys that are just names to you like Hulk Hogan, Ricky Steamboat, Nature Boy, Rick Flair, these are all friends of mine. I wanted to call and check with some of the wrestlers—

—I used to know, how they’re doing today. How’d they recover after the use of steroids. I went to call ‘em and you know what I found? Of the wrestlers who were professional stars, 40 were dead by the age of 40. 70 were dead by the age of 50. But there’s no clinical proof that they died of steroid abuse even though they all used steroids. Here’s the bottom line. I am not willing to pay the price for legalizing steroids and performance-enhancing drugs, ‘cause I’ve seen too often what it can do. I don’t wanna go to the cemetery and tell all the athletes who are dead there, hey guys, soon you’ll have a lot more of your friends coming, because we’re gonna legalize this stuff. The only good news out of it? They wouldn’t hear the news. Because they’re all dead. Thank you.

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: Dan Naulty pitched for the Twins then became with the Yanks. Now follow this, in 1992 Don Naulty was six foot eight, The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” he’s a strapping right-hander, he weighs only 165 pounds. Guy said to him, Don, you gotta get on some steroids, man, you put some body on you. So he did. In 1999 he was with the Yankees, he weighed 245 pounds. That’s a weight gain of 60 pounds. And it was all muscle. Unfortunately he described himself as being suicidal, he said, “I was absolutely nutso.” Now he didn’t die, he survived. But he had to have major surgery because his veins were clotted against his arteries. He had to have major surgery because he tore the muscle right off—the, the muscle and the groin completely off the bone. Dr. James Andrews, a man I consider to be one of the foremost absolutely best surgeons of all. He said—he’s a north—noted orthopedic surgeon, he said that…now check this out. That in 2002, 17 percent…17 percent of total baseball payroll went to guys who were on the injured list with muscle tears, muscle strains, ruptured Achilles tendon, and on goes the list. He said that we have had a 200 percent increase in just the five years prior to 2002. Baseball owners paid $370 million to players who were not able to play. Most of them accord9ing to Dr. Andrews, were related to their use of anabolic steroids. And you now wanna admit—legalize it, and govern it? No definitive clinical proof though, that it was the result of steroids. No proof. I’m probably the only guy in the room who is friends with professional wrestlers, I started in 1980 with Bob Backlund. I’ve MC’d a lot of their events, I’ve enjoyed ‘em, I love The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” ‘em. Guys that are just names to you like Hulk Hogan, Ricky Steamboat, Nature Boy, Rick Flair, these are all friends of mine. I wanted to call and check with some of the wrestlers—

### Moderator
Claim: One minute—

### Scientific Advocate (SA)
Claim: —I used to know, how they’re doing today. How’d they recover after the use of steroids. I went to call ‘em and you know what I found? Of the wrestlers who were professional stars, 40 were dead by the age of 40. 70 were dead by the age of 50. But there’s no clinical proof that they died of steroid abuse even though they all used steroids. Here’s the bottom line. I am not willing to pay the price for legalizing steroids and performance-enhancing drugs, ‘cause I’ve seen too often what it can do. I don’t wanna go to the cemetery and tell all the athletes who are dead there, hey guys, soon you’ll have a lot more of your friends coming, because we’re gonna legalize this stuff. The only good news out of it? They wouldn’t hear the news. Because they’re all dead. Thank you.

## Round 2

### Moderator
Claim: Our thanks to George Michael, and again, according to the format I’ll pose a question to each side of the table. Dr. Fost, if there were unfettered access to performance-enhancing drugs, isn’t it The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” reasonable to posit that, even now, or even during the so-called steroid era, there were some constraints, some fear of being, uh, caught, there were some tests, however flawed— But if it’s all wide open, it would go beyond any levels we’ve seen heretofore, and could possibly, get into an area where not only would the competition be grotesque, but where there would be real and verifiable health risks.

### Conspiracy Advocate (CA)
Claim: Nobody knows but my guess is it would be exactly the opposite.

### Moderator
Claim: Why.

### Conspiracy Advocate (CA)
Claim: Because if athletes could go to doctors and get drugs without having to go to Mexico or to BALCO Labs, they could A, get drugs which had been studied and tested and approved by the FDA, they’d know what they were taking. They could get drugs that would be manufactured in an American manufacturing facility with oversight by the FDA, and they’d be getting advice from doctors on which drugs were safe and effe— effective, which now they can’t find out even if they want to because the stuff comes from Mexico.

### Moderator
Claim: All right, suppose we were to adopt Julian’s suggestion, that there were regulated, permissible regulated use of performance- The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” enhancing drugs, and in each case it was appropriate to the spirit of the particular sport, that’s fine in the ideal. But it’s naïve to believe that each competitor, many of them obsessed with victory and believing in the full bloom of youth that they’re invulnerable, would stay within those limits, once there were unfettered access, they could just take as much as they wanted to gain whatever short-term competitive advantage they wanted, couldn’t they?

### Conspiracy Advocate (CA)
Claim: Uh, whatever a doctor would prescribe to them and probably some would go outside the system as they do now—

### Moderator
Claim: Well couldn’t they get more than the doctor prescribed, people do that all the time now with HGH, there’s a certain amount you can prescribe plausibly for certain conditions, even for anti-aging purpose, and people just double it, triple it, quadruple it, to whatever level they want, right?

### Conspiracy Advocate (CA)
Claim: Yeah, that’s what they’re doing now, the difference is that you’d have drugs which could be tested, you’d have follow-up studies so that they would know what the facts are. You’d know whether any of these deaths that George Michael refers to have anything to do with steroids. As he said, there’s no evidence that they do. But there are other adverse effects of steroids that I would worry about, but we’ll never find out about them, because we can't The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” study them. So, I think athletes might be more constrained from using them if there was more data out there that they could know about.

### Moderator
Claim: Anybody else on this side of the table want to add anything to that, or respond?

### Conspiracy Advocate (CA)
Claim: Can I?

### Moderator
Claim: Julian.

### Conspiracy Advocate (CA)
Claim: So what, if this is the honest athlete, and this is the cheater, at the moment the cheater has a significant advantage.

### Moderator
Claim: Part of this will be heard on radio. So Julian is holding his left arm at a certain level and his right arm above it.

### Conspiracy Advocate (CA)
Claim: So, so what will happen if you allow access to safe performance enhancers is the honest athletes will come up, but of course the cheaters will still take, as you suggest, an advantage in the black market. But what you will be doing is narrowing the advantage that the cheater has, because now there’s a market for safe performance enhancement. So you’ve made the honest athletes better off by bringing them closer to the cheaters without The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” compromising their health. That's the reason why you want to create a market for safe performance enhancers. So growth hormone, we heard all this discussion about steroids, growth hormone is a very safe substance. Now, you may be able to achieve a lot of the benefits that you can achieve with steroids by using growth, growth hormone. And you’ll be developing new substances that will be competitors for, at the moment, the stuff that, that is simply on the black market.

### Moderator
Claim: George?

### Scientific Advocate (SA)
Claim: Julian. Would you hear what you just said! If I don’t want to do drugs, I can't play against you.

### Conspiracy Advocate (CA)
Claim: If you don’t want to take the risks of a spinal cord injury, you can't play professional football.

### Scientific Advocate (SA)
Claim: No, come on, say with the drugs—

### Conspiracy Advocate (CA)
Claim: No, no, no—

### Conspiracy Advocate (CA)
Claim: George, George, there’s a, for three years in the NFL there’s a ninety percent chance of permanent disability. If you want to play in the NFL, that’s what you buy into. People choose to do it… The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

### Moderator
Claim: How do you, how do you define permanent disability?

### Scientific Advocate (SA)
Claim: I'm talking about anabolic steroids.

### Conspiracy Advocate (CA)
Claim: I'm talking about… …there’s a ninety percent chance of permanent disability. People make that choice. You want to, you want to ban professional football because—

### Scientific Advocate (SA)
Claim: No, but you play within the rules, and if you get hurt, as Bob says, that’s an unfortunate accident.

### Conspiracy Advocate (CA)
Claim: But the reason you want these rules is because you're concerned about the health and safety of the athletes. Why aren't you against football?

### Moderator
Claim: A question that can be posed later in the debate when the format actually calls for direct questions from either side of the table. Here, one more question to this side, and then we’ll announce the results of the preliminary voting by the audience. I’ll pose it to Dick Pound, but again, Dale and George can respond as well.

The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Dick, after all your years with the Olympics and with WADA, are you troubled by the fact that despite best efforts, the penalties are almost by definition disproportionate? You catch a handful, and we can reasonably assume that a larger group goes free. Marion Jones was never caught by Olympic testing, sophisticated as it was. She was caught by the legal system. And the same year that Ben Johnson was caught, others had statistical anomalies in their performances, and for whatever reason, they were not caught. Does that trouble you?

### Scientific Advocate (SA)
Claim: Oh, sure it does, of course it does. Any time you see somebody who’s cheated and gets away with it, that's very troubling. It’s one of the reasons why, why in WADA we devote, I think it’s about twenty-five percent of our entire budget to scientific research, so we can, we can find EPO, we can find HGH, we can find, uh, evidence of blood transfusions. And we’re developing a test that is not a muscle biopsy, for genetic manipulation. We’re getting a screening test that I think will be able to detect the stuff very unobtrusively by the time it comes on. So yes it, of course it bothers us, but you don’t, you don’t go in the direction Julian’s suggesting, which is, you pick the lowest common denominator, help the guys who want to play honestly catch up with the cheaters, instead of bringing the cheaters back down to where, what they promised to do, which is not to use these things. I The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” think it’s a complete reversal of responsibility and approach.

### Moderator
Claim: Dale? George? Anything to add?

### Scientific Advocate (SA)
Claim: Yeah, I was, I was going to say, as I said earlier, if, if I didn’t think we were making progress, and that this is a winnable battle, however long it takes, um, then I would understand giving in. But I, I can't, I can't comprehend just giving up. Um, those who are against smoking in public have stayed with it, have stayed with it, and have stayed with it. And it has worked. And we can change culture, we can change the way people feel about things. And, and this is a battle about fighting, instead of just giving in.

### Conspiracy Advocate (CA)
Claim: Here, here’s a reason to think this battle is unwinnable. Given the massive prize money, and the incentives to cheat, and the low probability of being detected, you can win the battle if you reduce the prize money, but that’s not going to happen. All you can, unrealistically, increase the detection rates, but you're not going to achieve that either. The economic models all push this into a prisoner’s dilemma where people irresistibly will cheat given the incentives that are on offer, and the probability to—

### Scientific Advocate (SA)
Claim: How many, how many rich canoeists do you know?

The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

### Conspiracy Advocate (CA)
Claim: I'm sorry?

### Scientific Advocate (SA)
Claim: How many rich canoeists do you know?

### Moderator
Claim: Who many rich canoeists do you know?

### Conspiracy Advocate (CA)
Claim: It’s not, it’s not—

### Scientific Advocate (SA)
Claim: It’s just money, I agree that it’s—

### Moderator
Claim: There’s a whole array of, a whole array of Olympic sports, obviously that have little or not financial reward attached to them.

### Scientific Advocate (SA)
Claim: Mr. Balko, let me, let me make one quick point. You took, took on the horse industry, I’ve been named the top American Paint Horse Breeder, and the American Quarterhorse Breeder twice. So, I’ve had a lot of horses in my barn, a hundred and fifty at a time. We’ve never used a sweat box. Ever. I will not allow steroids. Ever. When you talk about the horse industry, and you know how we get horses ready for shows or race, make it real general that some people do, because I would never do it.

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” All right, we’re going far afield here, so—

### Scientific Advocate (SA)
Claim: So what?

### Moderator
Claim: Briefly—

### Scientific Advocate (SA)
Claim: It involves steroids.

### Moderator
Claim: Briefly Radley, and then I’ll try and get back to the format. Go ahead.

### Conspiracy Advocate (CA)
Claim: I was referring to, there was a cover story on Sports, in cover, Sports Illustrated a couple of years ago about the lengths that jockeys go through to, to make weight.

### Scientific Advocate (SA)
Claim: Oh, the jockeys, OK.

### Conspiracy Advocate (CA)
Claim: Right, the jockeys, not the horses.

### Moderator
Claim: OK.

### Scientific Advocate (SA)
Claim: You want to get back to your format?

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Yeah, we have to get back to the format because, uh, they, they threaten me with draconian punishments if I, uh, went too far afield. So, what we do at this point, before opening it up to, uh, some back and forth between the panelists, and then ultimately to a long session of Q&A, most of it from the audience, we let you know the results of the initial balloting. Now, this is before any of the debaters took to the podium, the proposition is, we should accept performance enhancing drugs in competitive sports. Before the debate began eighteen percent of you were for the motion, sixty-three percent were against, nineteen percent were undecided. You’ll have a chance to vote again after the debate has concluded, and we’ll see if those numbers move in one direction or the other. Now we’ll allow the panelists to question each other directly. Norm Fost will go first, and you can ask a direct question of any panelist on the other side of the table.

### Conspiracy Advocate (CA)
Claim: I'm going to try to squeeze in two, two questions, if I can. Uh, I want to ask Dale Murphy a question. Andy Petitte, the Yankee pitcher who recently, he was named in the Mitchell Report, and he admitted to using, um, growth hormone. And he said the reason I used it was because I had injuries, the my doctor said my injuries could heal faster, um, which is true, that’s the way these things work, they let you to repair injuries faster so you can The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” train harder and get back on the field. If Roger Clemens said that, if Ben Johnson said that, if they all said that, which they equally could have said, I used them because they help me heal faster, would that have been, are you OK with what Petitte said, and would you be OK with them? And I want to ask—

### Moderator
Claim: Let’s, let’s let him ask, answer that first, then you ask your second question. Dale?

### Scientific Advocate (SA)
Claim: Yeah, absolutely not, it’s, it’s still trying to get an advantage over the guys that are not taking human growth hormone to recover from an injury. That’s why guys take steroids. It’s not necessarily to look like Barry Bonds, but it’s to recover quicker. Pitchers, that’s why pitchers take them. Um, so I think in answer to your question, it would not be as big a story. Andy Petitte was smart. But is it still right? No. It’s still not within the rules and the spirit of the game to take steroids or human growth hormone to recover from an injury quicker, because a lot of guys are following the rules, and they don’t get to recover faster because they, they kept the rules. So it’s still wrong. I think he had a good P.R. agent and lawyer to say this is how you get it off your back. It doesn't make it right.

### Conspiracy Advocate (CA)
Claim: But, but we’re talking about what the rules should be, and, and The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” I'm interested, as a former player, of your opinion, if, if it’s true, that the side effects of HGH are minimal, particularly when compared to steroids, and it does help, I mean, these are people, athletes are people whose livelihoods depends on, on basically what amounts to physical labor, right? And if a guy can, uh, get back into the game quicker because of HGH, is that any different than a, you know, a construction worker who wants to get back on the job quicker because his pay check is dependent on it, taking something, a drug that has minimal effects that helps him recover quicker?

### Moderator
Claim: Reasonable question, let me focus it a little bit. Um, are we in a pass/fail mindset about the whole array of performance enhancing drugs, especially after the Mitchell Report, if we talk about baseball, where if you're in the Mitchell Report, you're guilty, no matter what you did, you're as guilty as the most full blown juicer. And should even those who were generally against the use of performance enhancing drugs in competitive sports, should they consider that possibly we’ve lumped all these drugs and all the circumstances under which they might be used into the same grouping, and we might be able to take a more nuanced approached, and that maybe using HGH short term to help rehab an injury is not the same thing as going steroids full blown and going from a one hundred sixty pound whippet who hits twenty The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” home runs to some sort of gargantuan figure who hits seventy- three?

### Scientific Advocate (SA)
Claim: Are you referring to Barry Bonds?

### Moderator
Claim: It was just a number.

### Scientific Advocate (SA)
Claim: I retired, I retired—

### Moderator
Claim: He hit seven sixty-two.

### Scientific Advocate (SA)
Claim: I retired at, at thirty-seven, Barry Bonds hit seventy-three home runs at thirty-seven. Um, you know, what, what’s the future hold? I mean, it, do, does it help you heal quicker? Yeah, that's why guys take them. But do we need them? No. You're going to heal a little slower.

### Moderator
Claim: Isn't that—

### Scientific Advocate (SA)
Claim: I mean, you're going to, let’s, let’s stop the abuse of a controlled substance. Human Growth Hormone for kids helps them grow when they're not producing enough of their own. That's a legitimate use for it. But for a, a pitcher to get back quicker, to me, in sports, you're going to get back a little later. It’s OK. I The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” want to stop the abuse. And I think to allow any of it in, for whatever reason, increases the odds of abuse, and increases, again, the kids seeing the example that they have to take this stuff to succeed. It just isn't needed. It’s not needed—

### Moderator
Claim: In the, in the interests of time, Norm, quickly your second question.

### Conspiracy Advocate (CA)
Claim: Well just first, as a doctor, I don’t understand what medicine’s about if it’s not about trying to help people recover from injuries and heal, and if you're—

### Scientific Advocate (SA)
Claim: But not to hit home runs.

### Conspiracy Advocate (CA)
Claim: And if you have a, if you have a drug that doesn't, has almost no side effects, and it helps people heal, I don’t know how it differs from anything else that—

### Moderator
Claim: Your question.

### Conspiracy Advocate (CA)
Claim: Second one, Dick Pound, um, a lot of the discussion here has been about fair competition. Um, knowing that Janet Evans used a greasy swimsuit that was not available to her opponents, did you speak out at the time against that? Would you speak out The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” against it now? Do you think her medal should be taken back? And if not, why not?

### Moderator
Claim: Dick?

### Scientific Advocate (SA)
Claim: I, I think you’ve got a, a completely bizarre perception of the difference between Ben Johnson and Janet Evans. I mean, Ben Johnson used a prohibited anabolic steroid. There was a rule against it. There was no rule about whether you could have nylon swimsuits or greasy swimsuits.

### Conspiracy Advocate (CA)
Claim: Do you think it was fair?

### Scientific Advocate (SA)
Claim: I think it was, I don’t think it was, uh, I don’t think that’s the question here. Did she break… What if she practiced harder? I mean, frankly, I, I greatly admire Janet Evans, I think she won the Olympics because she trained harder and was a better swimmer than everybody. I don't think the swimsuit made any difference, and there’s been subsequent tests on all of these suits. And the International Swimming Federation said, wear whatever you want, it does not appreciably, if at all, effect performance. So I think you, you’ve got your, your priorities really mixed up on that question.

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Dick, you're right back at the microphone, because it’s your turn in the running order here to pose a question to the other side.

### Scientific Advocate (SA)
Claim: Well, I was struck by something that both, um, both Radley and, and Norman said talking about, uh, you know, having access to all of this, and coercive rules. I mean, coercive rules, you're talking, you make it, you make it sound like it’s three guys at the IOC headquarters making up all these rules. The anti-doping rules are approved by two hundred plus companies, two hundred plus national Olympic committees, seventy-five or more international federations, athletes commissions from all over the world. It’s a consensus about what is right for sports. And, you know, maybe the question to you is how come all you guys with these fabulous ideas aren't able to persuade two hundred governments and two hundred national—

### Moderator
Claim: Two whom specifically are you directing the question?

### Scientific Advocate (SA)
Claim: Well, I’ll address it to both, because the other is, not all of the athletes you're talking about will have access to a Yale medical doctor. What about the athletes in Mexico? In, in Bulgaria? I mean, you— The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

### Moderator
Claim: Norm, Radley—

### Scientific Advocate (SA)
Claim: If you want, you want equal, you want equal playing fields, you're not talking the same.

### Conspiracy Advocate (CA)
Claim: Well, what about the athletes who have the funds to travel to Colorado Springs to train in high altitude versus low income athletes who might not? Uh, you know, there, there are built-in advantages and disadvantages. I think actually making a, uh, a cheap, a relatively cheap drug that mimics that effect, like EPO, which is much, much cheaper than, you know, flying an athlete out to Colorado to, to train at high altitude, um, actually democratizes, uh, that effect. I don’t think it actually, uh, makes it more difficult, uh, to achieve parity.

### Moderator
Claim: Once again, Radley, stay at the microphone, because it’s your turn to question the other side. Unless Norm, you wanted to have a quick response?

### Conspiracy Advocate (CA)
Claim: I just wanted, Dick keeps reminding us that these athletes broke the rules, as if we’re not all agreed about that. I didn't know the debate topic was, should athlete be allowed to break the rules. No is the answer. OK, that’s the end of that debate. The The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” question is, why the rules are there. Why do we have a rule that prohibits a doctor from prescribing a drug that helps you heal that has no side effects? Where did that come from? I haven't heard an answer to that yet.

### Moderator
Claim: Isn't it fair to ask whether you’ve limited the definition of why someone might use steroids? It’s not so high-minded as, it helps you heal. Many of the people who undertook taking steroids had no problems. Their only problem was they wanted to run faster, grow bigger, hit more home runs. So, there’s no medical indication for that, it’s performance enhancing. That's why we call them performance enhancing drugs.

### Conspiracy Advocate (CA)
Claim: All athletes want to get back out there and work out and get back on the field as soon as possible.

### Moderator
Claim: You make it sound like they're all on the disabled list. Many of them were quite good to begin with, then they, they went from good to super human by using performance enhancing drugs.

### Conspiracy Advocate (CA)
Claim: Yeah, what it, what it enables them to do is to train harder and to recover from injury quicker, and that’s why they get better. Yeah.

### Scientific Advocate (SA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” I tell you what, I had an experience with medical ethicists a few years ago, and I, I posed a question after the panel. I said, listen, let’s say I'm a track and field athlete. Call me Ben, not a real name. And I come to you, and I say, listen, I would like to win the Olympics in Seoul. I can't do this unless I use anabolic steroids. There’s nothing therapeutic about this. And I have to tell you that it’s totally contrary to the rules of the sport under which I compete. Would you prescribe the anabolic steroids? And the entire panel of medical ethicists said, of course. And I said, what!? And they said, yeah. And I said, on what basis? They said, the autonomy of the patient. Sounds like Radley.

### Conspiracy Advocate (CA)
Claim: Sorry, I didn't hear what—

### Scientific Advocate (SA)
Claim: The autonomy of the patient.

### Conspiracy Advocate (CA)
Claim: No, I don’t think—

### Scientific Advocate (SA)
Claim: That's, that's what they said.

### Conspiracy Advocate (CA)
Claim: No, I don’t think, for the fifth time, I don't think we should break rules, and I don’t think doctors or ethicists should encourage The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” people to break rules. But uh, if an athlete came, well, I’ve said it, if, if Ben Johnson, somebody named Ben came to me and said, I've got an injury, do you know anything that will help it heal, and it’s risk-less, and there’s no rule against it, um, I’d say, I can't think of any reason not to—

### Moderator
Claim: And, and what if the person came to you and they didn't want to make up a story, as they might have to, and they said, I have no injury. And I train like a demon. But I’d like to have benefits on top of that, would you prescribe the steroids for them?

### Conspiracy Advocate (CA)
Claim: Well, first of all, I'm, I'm not in sports medicine for a reason, so I'm, I'm not into prescribing it. But uh, that athlete would misunderstand it if he thought he, the reason that stops athletes from working out, and why you can't lift weights eight hours a day and five days a week, is because you're suffering recurring injury. They may not understand that. All they know is that they're sore and they can't work out, and that limits their ability to improve their performance.

### Moderator
Claim: So you believe the sole benefit of steroid use, we’re not talking about HDH, we’re talking about growth steroid use, is simply the ability to work out harder and recover from injury, that in and of themselves, they do not, on top of that, enhance performance and The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” allow you to do something which you could not do, if for some reason you could work out that hard without steroids?

### Conspiracy Advocate (CA)
Claim: Bob, if you and I started taking steroids now, we’re not going to look like Dale Murphy anytime soon—

### Moderator
Claim: Of course not—

### Conspiracy Advocate (CA)
Claim: Or Barry Bonds. Uh—

### Moderator
Claim: You, you can't, you can't win the Indy 500 in a Honda either, but if you have… But if you have Indy, if you have two Indy cars, and one gets auto fuel and the other gets rocket fuel, you might have a different outcome.

### Conspiracy Advocate (CA)
Claim: As best we know, the, the main way they work is by enabling you to work out harder. Steroids without working out are not going to really change anything very much. They do increase your aggressiveness, which also makes you, helps you to work out harder, so they have a psychological effect. But I think it’s all tied to working out.

### Moderator
Claim: All right, against the rules, I briefly became part of the debate— The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

### Scientific Advocate (SA)
Claim: No!

### Moderator
Claim: I’ll slap myself on the hand and turn it over to Radley to ask a question of the other side.

### Conspiracy Advocate (CA)
Claim: Sure, my, uh, question is directed at George. Um, let’s say for the sake of argument that the, the names that you mentioned during your presentation did die directly as a result of their using steroids. Uh, during alcohol prohibition people drank alcohol that was, uh, wood alcohol, uh, they drank alcohol that was, gin that was distilled in bathtubs, toxic, nasty, nasty stuff. The reason they drank is because safer, cheaper, um, better alternatives weren't available at the time. Uh, once prohibition ended, you know, nobody drinks bathtub gin anymore. Uh, nobody drinks wood alcohol anymore. Um, assuming that all these deaths were tied to steroids, all these deaths occurred during a period where steroids were illegal, and were still prohibited. So, they were prohibited its entire time, people were doing them anyway, why not lift that veil, let people who are going to do it anyway get steroids from, from a doctor, get steroids from more reputable distributors so they don’t have to go to Tijuana. Maybe it wasn’t steroids itself that killed them, maybe it was the fact that it was some black market steroids that they weren't The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” being, um, advised by a reputable doctor.

### Scientific Advocate (SA)
Claim: You're absolutely correct, and maybe, you know, if they were controlled better, maybe Lyle Alzado wouldn't have died. Maybe Ken Caminiti, who got most of his from Tijuana, wouldn't have died. But what about the tight end I talked to a couple of weeks ago who admitted that he gained sixty pounds, this guy is only thirty-eight years old, gained sixty pounds, beat up his wife, went to his coach and said, coach help me, I'm doing the juice, but God, I beat up so and so. I know these people. He didn't get his from Mexico. Now, I don’t know where he got them. But if, the, if you, if you allow one, if Bob can do steroids, if we’re playing side by side, he hits two thirty, I hit two thirty, we both move up to the next level. If he’s allowed to do juice, when I sit back to sitting on the bench in St. Louis, I’d have done juice. So that, so whether it’s legal or illegal is, is immaterial. If we make it legal the problem is only going to become worse. In relationship to alcohol, I don’t happen to drink, so I'm not a good one to discuss it with.

### Conspiracy Advocate (CA)
Claim: Well, I guess my point is, if we’re talking about the safety of athletes, isn't it better to have this all happening above ground and in the open air—

### Scientific Advocate (SA)
Claim: No, it’s better to have it, if you use it, you're out of baseball. It The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” should be a very strong penalty. Nothing, Pete Rose, one thing about the, Dick made the point earlier, and Dale followed up, they know that if you gamble, you're dead. So that’s the way it should be with steroids, unless the doctor says, you know what, I'm going to go to the commissioner and say, Dale needs to have this, so he’ll be able to come back. Then I accept that.

### Moderator
Claim: Dale, your question for the other side of the debate?

### Scientific Advocate (SA)
Claim: OK, um, Dr. Fost, you mentioned the increased, uh, intensity of workouts of those on steroids. Would you consider that “’Roid Rage?”

### Conspiracy Advocate (CA)
Claim: “’Roid Rage” as I understand it refers to people who do criminal things, that is who assault people or—

### Scientific Advocate (SA)
Claim: OK, but is “’Roid Rage,” quote, unquote, without getting into the technicalities of what “’Roid Rage” means, isn't that one of the side effects of taking anabolic steroids?

### Conspiracy Advocate (CA)
Claim: You become more aggressive when you take steroids, and that is one part of why I think some athletes feel they can work out harder, they sort of get more aggressive.

### Scientific Advocate (SA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” They, so is it psychological, or is it a brain chemistry thing? It’s totally psychological?

### Conspiracy Advocate (CA)
Claim: I think there is a psychological effect, right, that impels them to train harder.

### Scientific Advocate (SA)
Claim: So, when you increase the testosterone, and, and you increase your intensity, um, isn't that, that is a, an effect, you're saying? That, it will effect you that way?

### Conspiracy Advocate (CA)
Claim: Sure, sure.

### Scientific Advocate (SA)
Claim: And also are you saying that HGH, the only thing it does is help you heal faster?

### Conspiracy Advocate (CA)
Claim: No, it has many—

### Scientific Advocate (SA)
Claim: Do you think these guys, in other words, do you think guys took HGH for other reasons other than healing faster?

### Conspiracy Advocate (CA)
Claim: Well, they took it so they could get back on the field sooner, could body build better, could lift weights, could train more vigorously, all of which enhanced their muscle mass. That’s the ultimate The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” goal, is to become stronger.

### Scientific Advocate (SA)
Claim: OK.

### Moderator
Claim: Decreases fat and, and increase muscle mass.

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: So, so the ability to recover faster and work out harder and gain muscle mass, steroids does help muscle mass product, productivity?

### Conspiracy Advocate (CA)
Claim: Combined with working out, yeah.

### Scientific Advocate (SA)
Claim: And if I don’t want to do that, are you saying in the future, if the motion is accepted, that essentially, I am at a tremendously unfair advantage if I decide that I do not want to take this stuff?

### Conspiracy Advocate (CA)
Claim: I don’t know about tremendously unfair, I think that—

### Scientific Advocate (SA)
Claim: Well, I would, I would say tremendously unfair.

### Conspiracy Advocate (CA)
Claim: Well I don’t—

### Scientific Advocate (SA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” I mean, we can look at numbers, we can look at performances, um—

### Conspiracy Advocate (CA)
Claim: Dale, you're exhibit A, I mean, I'm assuming you didn't use any of these drugs, and you're an All-Star, and uh, you know, one of the great players of—

### Scientific Advocate (SA)
Claim: Well doesn't, then doesn't that make my point?

### Conspiracy Advocate (CA)
Claim: You didn't seem to be at very much of an un-, of a disadvantage?

### Scientific Advocate (SA)
Claim: But doesn't that make my point that we don’t need them?

### Conspiracy Advocate (CA)
Claim: There’s all sorts of reasons—

### Scientific Advocate (SA)
Claim: Why, why do we need them if, if people are able to perform at the highest level without them, and that it also provides a huge advantage if you use them, but you can still be a world class athlete, why would we need them? Why not ban them and, and change the culture to the point to where guys think a lot time before they take this stuff? Why do we need them?

### Conspiracy Advocate (CA)
Claim: Well we don’t, we don’t need them, and we don’t need sports The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” either. We don’t need tackle in football, we can play two hand touch, it’s just—

### Scientific Advocate (SA)
Claim: Yeah, but we’re not talking about—

### Conspiracy Advocate (CA)
Claim: It’s just not as much interest.

### Scientific Advocate (SA)
Claim: We’re not talking about football, the people that die, that’s not the argument. The argument isn't the inherent risks of any sports tonight, it’s performance enhancing drugs. You don't need them to be a, a world class athlete. You do not need them. And if you don’t take them, you're at a huge advantage. And so I, I just, I cannot understand it. Wouldn't you agree, one last question, that the example that the young people see, wouldn't you say that abuse of these kind of drugs is particularly, we talk about side effects, wouldn't you agree that it’s particularly, um, harmful to young people, that we may not even know abuse of these kind of drugs—

### Moderator
Claim: Again, let me—

### Scientific Advocate (SA)
Claim: …what may happen.

### Moderator
Claim: Let me slightly redirect it, would you agree, Dr. Fost, with The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” superior medical knowledge, would you agree that there are risks for adolescents that are not present, at least to the same degree, and you might argue at all, for adults?

### Conspiracy Advocate (CA)
Claim: Absolutely, and I said in my remarks that I thought they should be banned in children, there should be testing in children, there ought to be—

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: …harsh penalties for suppliers to children—

### Moderator
Claim: If that’s the case then, isn't it inevitable, if you were to allow unfettered access to performance enhancing drugs beyond a certain threshold of competition and a certain age limit, that those who aspire to play at the collegiate level, and ultimately to play at the professional level, wouldn't just be influenced, they’d be nearly compelled to begin using sooner than you would advocate—

### Conspiracy Advocate (CA)
Claim: No—

### Moderator
Claim: …to get there?

### Conspiracy Advocate (CA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” I don’t think so. First of all they couldn't, wouldn't be able to get them through prescribed channels, they wouldn't be able to get them through illegal channels—

### Moderator
Claim: Plenty of people get them now—

### Conspiracy Advocate (CA)
Claim: And that’s why we need rigorous testing and criminal penalties for those who do it. Look, I'm much, it’s interesting how we obsess about this issue, which again, has caused very little serious harm to adolescents, and the ones who do use them, as Julian said, are using them mainly to bodybuild, not, they're not being used, for the most part, in uh, competitive sports. Most of the adolescent use is in the gyms, not in the playing field. But listen, alcohol kills fifty thousand people a year, and what are the big leagues doing about that. When players drink, I don't hear anybody talking about lifetime bans for drunk driving by baseball players. That kills fifty thousand people a year, including innocent victims, including a lot of kids, and here we are talking about something that kills almost nobody. Chewing tobacco is a big problem among youth in this country, and we have the networks showing Terry Francona drooling every ten seconds during the World Series. What kind of—

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Although they have banned it in the minors, and they would ban it at the Major League Level if they could unilaterally impose it. But they can't—

### Conspiracy Advocate (CA)
Claim: And most seriously of all is the violence by professional athletes. I'm talking about sexual assault, and criminal violence, rampant in professional sports. No lifetime penalty, no ban, do a little community service, and come back. What message does that send—

### Moderator
Claim: Is, isn't that why, to uh, the side of the table that is against the motion, isn't that why the argument against the use of performance enhancing drugs is best focused on competitive issues, the sanctity of the records, uh, the level playing field argument. And if we start moralizing about health dangers, or relative impact on society, then you run up against all the arguments that Dr. Fost just laid out, and isn't the best argument for this side of the table the argument about competitive balance, or competitive fairness?

### Scientific Advocate (SA)
Claim: True, but Doctor, remember what Dr. James Andrews said, that is we have more torn muscles, we have more pulled muscles because we have too much muscle mass for the body, and that’s The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” the direct result of steroids and the workouts with steroids.

### Moderator
Claim: Very briefly.

### Scientific Advocate (SA)
Claim: That, that’s the best man.

### Scientific Advocate (SA)
Claim: I find, I mean, one of the things here are like the guy who’s pulled over on the highway by the, by the policeman saying, but, but officer, why are you stopping me, there are all kinds of people going faster than I was? But to, to deal with the, the young people, I mean, you're familiar with, with the state imposed doping programs in East Germany and some of those, and the medical data arising from that. Clearly there are health impacts, adverse health impacts on the athletes—

### Conspiracy Advocate (CA)
Claim: Yeah, those were horrible, and that was close to coercion, and, as I said, the side effects in kids are sufficient to have very rigorous penalties against those who do that sort of thing.

### Moderator
Claim: Julian, your question.

### Conspiracy Advocate (CA)
Claim: OK, so on the topic of children, it’s a major plank in your argument. Dale Murphy said it would send the wrong message to children, and, and Dick Pound said, uh, you didn't want your The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” children or anyone else’s children becoming chemical stockpiles. So, the argument, as I understand it here, is we need to ban performance enhancing drugs in adults to protect our children. So, my question to Dick Pound is, don’t we have, already in society, different rules and laws for children and adults, so on your argument, um, we should ban everyone from driving motorcars, because some children may illegally drive them and kill themselves. So, my question to you is, do you think we also should ban driving cars in adults because it might be abused by some children?

### Moderator
Claim: Well, or using alcohol.

### Scientific Advocate (SA)
Claim: Isn't, isn't that a silly question?

### Conspiracy Advocate (CA)
Claim: That, that’s the, why, why do we accept the rules—

### Conspiracy Advocate (CA)
Claim: Let’s say, let’s say alcohol then.

### Conspiracy Advocate (CA)
Claim: …alcohol then.

### Conspiracy Advocate (CA)
Claim: Should we ban alcohol for adults because kids are going to drink it?

### Scientific Advocate (SA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” No, no, no. I mean, the issue, the issue…

### Conspiracy Advocate (CA)
Claim: …what’s the difference?

### Scientific Advocate (SA)
Claim: Because the community at large, sport is not going to solve every problem on the face of the planet, even though we come to affairs like this and like to pretend it can. Uh, but the community, governments, National Olympic Committee, Sports Federations, the public at large say, here are things that you should not take, and there’s a reason for them. They're, they're either, they're performance enhancing, they’re risk to health, or they're contrary to a defined term, not a pornographic definition, uh, called Spirit of Sport. And you, you examine every, um, substance or method against that matrix, and if it meets two of the three criteria, then chances are it may be on the list. There’s a good reason for it. It may be wrong. Maybe somebody’s got the science wrong. Maybe they do. Nobody’s perfect. And science goes on. But, in the meantime, that’s the community, and that’s the values that, that are reflected in, in the community.

### Moderator
Claim: All right, we are running behind on time, and I will take some of the blame for that. George Michael, last question, and then we’ll The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” open it up to the audience, and we’ll try and pick up the pace. George?

### Scientific Advocate (SA)
Claim: I’ll just make it real quick. Doctor, you said that only six percent of the tests came back positive?

### Conspiracy Advocate (CA)
Claim: In that year, that first year of universal testing.

### Scientific Advocate (SA)
Claim: Let me just say this. Bob, you’ve got to back me up, I only have one statement.

### Moderator
Claim: Yeah?

### Scientific Advocate (SA)
Claim: It was the single worst drug testing in the history of sports period. Don’t ever refer to that six percent—

### Moderator
Claim: If you, if you failed, if you failed that test—

### Scientific Advocate (SA)
Claim: That was a disgrace, an American disgrace.

### Moderator
Claim: …then you failed an I.Q. test simultaneously. No—

### Scientific Advocate (SA)
Claim: I have a strong opinion.

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” No one thinks, no one thinks that—

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: …that an announced test that didn't, that didn't test for all, a whole array of designer steroids, and still showed somehow six or seven percent failing, no one thinks that’s the limit of it. In fact, you could reasonably… …many multiples beyond that—

### Scientific Advocate (SA)
Claim: It’s worse than that.

### Moderator
Claim: …and I think everyone who knows the dynamics of baseball at that time—

### Scientific Advocate (SA)
Claim: We’re going to test—

### Scientific Advocate (SA)
Claim: It’s worse than, it’s worse than that—

### Scientific Advocate (SA)
Claim: We’re going to test next Tuesday, go ahead and drink all the orange juice you want between now and then.

### Scientific Advocate (SA)
Claim: If you tested positive on that, on that series of tests, you could The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” come back two weeks later, and if you were then cleaned out, they, they took away the first test.

### Moderator
Claim: That, that was a sham.

### Moderator
Claim: Sham?

### Moderator
Claim: Let, let us open it, let us open it now, uh, to questions from the audience, uh, please, unlike some of us, get to the point quickly… And, uh, wait until you get to the microphone to pose your question and if you’re a member of the press, identify yourself as such. Yes, sir.

### Moderator
Claim: I’m not a member of the press and I—but I would like to thank all of the panelists for your comments. Um, I’d welcome comment from any and all panelists, as to the legitimacy if any, of our Congress imposing its will on this issue and holding these hearings. What is its technical legitimacy in doing that, and philosophically do you think it’s any of their business or not—

### Moderator
Claim: All right, we’ll let one person from each side respond to that, is it any of Congress’s business to be involved as they have been, Radley?

### Conspiracy Advocate (CA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” You—you can probably guess my answer, um…uh, just a very, very quick anecdote, when baseball first objected to the, the, uh, Congress’s jurisdiction to look into this matter, uh, Congressman Davis and Congressman Waxman sent a letter back to baseball, stating that Cong—their, their particular committee, the Government Reform Committee, had jurisdiction over any matter at any time. Uh, this is the, the sort of arrogance of Congress, they think that there’s nothing that they don’t have authority, uh, and jurisdiction over. Um, I, I…people are gonna say that, uh, the baseball anti-trust exemption, uh, somehow means that they, they have to sort of bend to the will of Congress. Uh, I would submit that if, if that’s your argument, then, everybody who gets a government benefit, uh, sort of throws, uh, all of their rights out the window from student loan recipients to, uh, public housing recipients to, you know, corporate subsidies, so— Uh, I, yeah, I, I don’t think this is an issue of Congress, I think baseball can determine what its rules ought to be, uh, on its own.

### Moderator
Claim: On the other hand, uh, even though there may have been plenty of grandstanding involved, you can’t deny that there was movement after Congress first, uh, convened hearings in 2005. It was, it was a perfect storm, there was Canseco’s book, BALCO was breaking, and the Congressional hearings were part of it, but The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” it seemed to move the issue along.

### Conspiracy Advocate (CA)
Claim: Oh, absolutely it did, and we—whether, whether or not that’s a good thing or bad thing that individual Congressmen can force an entire industry to sort of bend to their will, uh, I, I, I happen to find that troubling.

### Conspiracy Advocate (CA)
Claim: And I, I have to say there’s something fishy going on, when the Congress holds hearings and the President takes time in a State of the Union address told about the horrors of steroids, which as far as I know haven’t killed any kids yet this year or not very many—

### Scientific Advocate (SA)
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: And, and smok—and smoking, George, will kills 400,000 people every year, 400,000, 90 percent of whom start smoking in childhood, but this is not worthy of Congressional hearings or 30 seconds of the State of the Union address—

### Moderator
Claim: Well, the—the nation lacks an effective steroid lobby… Unlike the tobacco lobby—

### Conspiracy Advocate (CA)
Claim: There’s something going on here other than deep concer—

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” They don’t have an effective steroid lobby.

### Conspiracy Advocate (CA)
Claim: There’s something going on other than deep concern for the well- being of children.

### Moderator
Claim: Congress’s involvement. Dale maybe, what do you think?

### Scientific Advocate (SA)
Claim: Well, I, uh…I think, uh, it’s been helpful, I think though what we will find is that the Mitchell Report will—something that was done internally, will be of most help, uh, to this problem. Um, I think it’ll be a catalyst for us to make some progress. But I, I gotta say, if the argument is smoking or alcohol or prohibition or lasik surgery, that’s not what it says up there. It says should we allow performance-enhancing drugs, I still don’t see the correlation between bringing in the problems with alcohol which are real, I would love to next year to come back and discuss whether baseball should, uh, get rid of all their beer sponsors. I would be in favor of that, but that’s not the question tonight. There, there—it is a relatively small problem, totally agree with that. But that’s just not the question tonight.

### Moderator
Claim: Next question from the audience.

The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

### Moderator
Claim: I always thought that competitive sports meant a natural competition, a motivation, an incentive, a desire to want to be the very best. That’s what we always teach our kids no matter what it is that we do—what they wanna do in life. And it seems to me, that by taking any kind of a performance-enhancing anything, you are taking away the naturalness of wanting to achieve. Of wanting to be the best, of wanting to grow. It says just pump me up, and you have a good business thing here, and put me out.

### Moderator
Claim: To whom specifically is your question or statement directed—

### Moderator
Claim: It’s not really a question, it’s just a confusion—

### Conspiracy Advocate (CA)
Claim: Right. There have to

### Moderator
Claim: As to—it’s a confusion as to why— It’s not a matter of death, it’s a matter of life, why would drugs even be permissible under any level.

### Moderator
Claim: Dr. Fost, a brief response—

### Conspiracy Advocate (CA)
Claim: Like Carnac I can answer the question without even knowing the question.

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Place—place an envelope to your forehead when doing so in that case.

### Conspiracy Advocate (CA)
Claim: Um, that’s a nice notion about sports and it’s certainly what we ought to promote for our kids but it hasn’t been what sports has been about at an elite level for 7,000 years and that’s why I mentioned the Babylonians, if you took the steroids and the growth hormone away, what you would have is literally a thousand other things that athletes do to enhance their performance, none of them natural. Uh, athletes drink Gatorade from a factory, they take pasta to carbo-load that’s made from a factory. Uh, they don’t eat potatoes out of the ground to carbo- load, they put on fancy shoes, they train at altitude, they do everything—

### Scientific Advocate (SA)
Claim: Can I interrupt, Doctor—

### Conspiracy Advocate (CA)
Claim: —there a—there’s no athlete since the beginning of time, who competed naturally to win a race.

### Scientific Advocate (SA)
Claim: Doctor, I gotta interrupt. You’re comparing drinking Gatorade to taking anabolic steroids?

### Conspiracy Advocate (CA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” No, I’m not, I’m just saying that—

### Scientific Advocate (SA)
Claim: What are you—well then why bring it up, it, it’s—

### Conspiracy Advocate (CA)
Claim: It’s really what she bring—she said, it should be just about nature, just, people on—by their own natural ability, I don’t know a single athlete who relies on his or her own natural ability to compete.

### Conspiracy Advocate (CA)
Claim: Do—do you think a hypoxic air tent is natural? Is that a—is that a—a hypoxic air tent. This is what all US athletes use to, to boost their—

### Scientific Advocate (SA)
Claim: Well, my understanding is the reason they do it is to level the playing field with those that live at high altitude, which, this training is readily accessible and, and permissible.

### Conspiracy Advocate (CA)
Claim: But not—

### Scientific Advocate (SA)
Claim: Performance-enhancing drugs are not permissible.

### Moderator
Claim: To the audience— The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

### Scientific Advocate (SA)
Claim: So—

### Moderator
Claim: To the audience, yes. Yes, ma’am.

### Moderator
Claim: I’m Sara Schorno with the Huffington Post. And this question is more for those against the notion, um, maybe particularly Mr. Pound. Setting the legalities aside and the fact that it’s against the rules, um, what difference do you see if any between an athlete using performance enhancers to stay in the game and say an actress using injections and cosmetic surgery to stay in the movies?

### Scientific Advocate (SA)
Claim: Be—because what we’ve agreed…in sport—

### Moderator
Claim: But setting the rules aside is what I’m saying, I mean you mentioned a lot of ethics, and you mentioned a lot of unfair advantages. So using those two examples that you’ve used, what do you see the difference is.

### Scientific Advocate (SA)
Claim: Well, you, you have to have rules in order to have sport. You, you can’t have sport without rules, it’s not, uh, it’s not, you know, the only, the world’s shortest rulebook I know is Australian-rules football. You know. “Get ball to end,” and, and, uh— The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” So I, I don’t think you can compare that. We’re talking about sport. What, what—

### Moderator
Claim: No, no, I understand—

### Scientific Advocate (SA)
Claim: actresses do—

### Moderator
Claim: —I understand sport, but, one of the arguments that you’ve used is the ethics of it. Um, that it’s against the rules because it’s unethical and because it’s unfair—

### Scientific Advocate (SA)
Claim: No, no, no, that’s, it’s backwards. It’s unethical because you have agreed to the performance of a, a particular skill in a particular way, and you’ve broken that promise. You’ve cheated on your fellow competitor, that’s what’s unethical.

### Moderator
Claim: So then do you think that if it were to be accepted in sports that it would then still be unethical, or if they did allow steroids within sports would it then be ethical to use them.

### Scientific Advocate (SA)
Claim: It would not be unethical to use them. That’s right. No, no, it’s, it’s the rule.

### Moderator
Claim: Couple more quick questions. Limit—we know—now all the The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” hands are going up, but we don’t have time for everybody so, whom have the fine folks out there decided—yes.

### Moderator
Claim: Uh, Jon Frankel, HBO’s “Real Sports.” Um, first thing is your, your statistic of 90 percent permanent disability in the NFL is way off and I’ve done pieces criticizing the NFL so it’s not fair to invoke that specific—

### Conspiracy Advocate (CA)
Claim: What—what is the right number.

### Moderator
Claim: Well, there’s—there is no real number, there’s, there’s no way to know what permanent disability is and that’s been one of the long-running arguments—

### Moderator
Claim: How are you defining permanent disability, Dr. Fost.

### Conspiracy Advocate (CA)
Claim: I was just quoting a New York Times study of, uh, people who had—weren’t able to perform activities of daily living, um, I think was the definition, but I don’t remember precisely.

### Moderator
Claim: Jon—

### Conspiracy Advocate (CA)
Claim: But if you have a different number I’d like to know what it is.

### Moderator
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Well, what I really would like to get at is you, you are talking about the fact that there are no, or minimal side effects when it comes to steroids and you’re comparing adults versus youth. Um, I haven’t turned on a television and seen a commercial for, um, some sort of medicine that doesn’t spend half its time telling us about the side effects, so I’m—I dare find it hard to believe that steroids don’t have some side effects that don’t have serious health implications. Um, you all on this side of the panel for the motion, seem to suggest that, any advantage, whether it’s drinking caffeine or such is a good advantage, so it is worth doing. So, I wonder whether you advocate insider trading, um…uh, in that, in that way, because it clearly gives us an advantage. My other point is to the kids, and it’s been brought up by the side against the motion and that is, why should my son, who at eight years old, who already watches Barry Bonds, when he gets to the high school level, and there’s a kid who plays second base, who’s—he knows is taking something, and all he wants to do is play second base on his high school baseball team, he may not even wanna make it to college or to the pros. He just wants to play at the high school level. Inevitably he’s gonna be faced with that decision of, should I take, or should I not.

### Moderator
Claim: All right. Are all advantages positive advantages, and what about The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” the scenario that Jon Frankel just laid out, who wants to respond, Radley—

### Conspiracy Advocate (CA)
Claim: I’ll take the first part if, if you wanna take the second, um, I— Look, I don’t know what advantages are harmful and what advantages are helpful, I mean my, my position on this is that, part of the problem is, is what we don’t know, uh, because everything is, is, is black market and is, and it is under this veil. Uh, I think my point is that we need to lift that veil and, and trust adults to make their own decisions about what risks they’re going to take.

### Moderator
Claim: Norm?

### Conspiracy Advocate (CA)
Claim: I think your son, uh, should, we should do everything we can to stop him from smoking, from drinking, from using steroids, and other things that are harmful and that he is not in a position to make informed choices, so I’m in favor of whatever we can reasonably do, to prohibit it, make it illegal, make it criminal, to test, to use kids as indicators for these activities when they’re occurring, so I’m completely sympathetic to your concern, and I think we should do everything we can to stop it.

### Moderator
Claim: We apologize to all those audience members who had good The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” questions of their own but because of time we have to move on to the summation portion but before we do that let me pose a question to this side of the table. It’s often tossed out, well, people use various medications for this reason or that, or, uh, the woman from the Huffington Post used the example of an actress who might resort to plastic surgery as she ages, other performance enhancers of various kinds. But isn’t that a specious argument because, there is no objective competition for who has the fewest wrinkles. And if, and I don’t mean to be flippant, but if there were some kind of competition, that people cared about, and that people entered into in good faith, and that had an ongoing history that people cared about, and that competition entailed how frequently and with what level of, uh, of effectiveness one could perform sexually, then perhaps you might, you might have to put in rules against the use of Viagra, one com—competitor to another. But that doesn’t apply, that doesn’t apply to the use, or the suggested use of Viagra, it doesn’t apply to the suggested use of plastic surgery. In competitive sports, which are, which are conducted with a structure and with objective rules and goals, it seems to me that whatever anyone uses for performance enhancement of one kind or another, outside those spheres, isn’t analogous. Response?

### Conspiracy Advocate (CA)
Claim: No, I agree, I mean we’re—but, but we keep going back to the The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” rules here and, none of us is advocating breaking the rules, uh, I mean the purpose of this debate tonight is to deter—we’re debating what those rules ought to be. Uh, I’m not saying that once you enter into an agreement with a league that says you will not use these—this list of substances, I’m not defending people who then go and use those substances, I mean that—that’s fraud basically. Um, what we’re debating here is what those rules ought to be—

### Moderator
Claim: But you would agree that what is used outside competitive sports and taken for granted in society, really is not a persuasive argument for what should be allowed within competitive sports. You have to make a different argument and maybe there’s a good one but that isn’t it.

### Conspiracy Advocate (CA)
Claim: Uh, I think it’s a different argument to say that because we use liposuction or, or get, uh, Botox injections, that that’s the same as, uh, uh, entering into an agreement, uh, to, to, to have a competition, uh, under, under set guidelines—

### Moderator
Claim: Yeah, if there were a flat-abs competition and one guy had to do sit-ups and someone else got liposuction, it wouldn’t be a fair competition, if anyone cared about that competition.

### Conspiracy Advocate (CA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Absolutely, if it—if you’re having a beauty contest and the, and the judge—and the, the criteria is natural beauty and someone went out and got breast implants, uh, and won the competition—

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: —I, I, I would object to that, yes.

## Round 3

### Moderator
Claim: All right, it is time now…on that uplifting note, uh, for our, for our summation. And, and here is the order of debater presentation, it begins with Dick Pound. Two minutes.

### Scientific Advocate (SA)
Claim: Thank you, I think that, that out of the mouths of the other side you’ve heard, um, all kinds of reasons why this, uh…motion should be voted on in our, uh, direction. Human nature is not gonna change. Um, the—we’ve heard from a number of the, uh, other, uh, the other opponents talking about, there would be ongoing development of these things, without care for safety. In, in the cat-and-mouse game of trying to improve what’s out there, there would be no care for safety, so that if you have a doctor prescribing 10 cc’s of…anabolic steroid, uh, and everybody’s doing that, then there’s no more advantage. So the person who wants the advantage is gonna use 20, or 30, or 40. And that will The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” be pursued, uh, as will the, the sort of, uh, research in that area— We had Kelly White, uh, American sprinter, come to the World Anti-Doping Agency after she got caught in the BALCO situation. They were giving her the clear THG. She said she was having two enormous menstrual cycles every month, and she had blood pressure that was going right to the roof, and she went to Conte and the others and said, uh, this is happening, he said oh, huh. Well, maybe you should take a little less and, and, oh, and drink some more water. They had no idea…the stuff was going from a laboratory bench into her system. And, and the system of other athletes. Uh, excellence within sport is what everyone searches for, but it’s excellence within agreed rules. And, and the community speaks. That, that—

### Moderator
Claim: 30 seconds, Dick.

### Scientific Advocate (SA)
Claim: 30?

### Moderator
Claim: 30.

### Scientific Advocate (SA)
Claim: The community has spoken, I think the community has a legitimate interest in things that may be a health interest. You know, what happens in the major league influences triple-A, double-A, single-A, high school ball. There are pyramids in The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” hockey and basketball. This is a public-health problem. And finally I thought, um, one point made by, by Dr. Fost was, was quite telling. He said, more or less, that alcohol—in response to this gentleman’s question, alcohol, tobacco, steroids, and other dangerous things should be discouraged. And I agree with him entirely.

30?

Thank you, I think that, that out of the mouths of the other side you’ve heard, um, all kinds of reasons why this, uh…motion should be voted on in our, uh, direction. Human nature is not gonna change. Um, the—we’ve heard from a number of the, uh, other, uh, the other opponents talking about, there would be ongoing development of these things, without care for safety. In, in the cat-and-mouse game of trying to improve what’s out there, there would be no care for safety, so that if you have a doctor prescribing 10 cc’s of…anabolic steroid, uh, and everybody’s doing that, then there’s no more advantage. So the person who wants the advantage is gonna use 20, or 30, or 40. And that will The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” be pursued, uh, as will the, the sort of, uh, research in that area— We had Kelly White, uh, American sprinter, come to the World Anti-Doping Agency after she got caught in the BALCO situation. They were giving her the clear THG. She said she was having two enormous menstrual cycles every month, and she had blood pressure that was going right to the roof, and she went to Conte and the others and said, uh, this is happening, he said oh, huh. Well, maybe you should take a little less and, and, oh, and drink some more water. They had no idea…the stuff was going from a laboratory bench into her system. And, and the system of other athletes. Uh, excellence within sport is what everyone searches for, but it’s excellence within agreed rules. And, and the community speaks. That, that—

### Moderator
Claim: Now his summation for the motion, Norm Fost.

### Conspiracy Advocate (CA)
Claim: Uh, every person on this panel agrees that people should play by the rules, and there isn’t anyone up here who has defended breaking the rules. The topic that’s here for debate tonight is, what are the basis of those rules. If there was a rule prohibiting people playing with red hair, we would say of course if you have read hair you can’t play. But we wouldn’t say that that was a sensible rule. So rules have to have some moral basis or some rational basis. The fact that they simply are there doesn’t tell us anything about the basis of them. When we look at what the claims for them are, they seem hypocritical, inconsistent, or based on bad facts. People say they’re based on concerns about fair competition, but sports allow grossly unfair competition, Olympic sports, countries against countries, baseball, Yankees against Brewers, the leagues tolerate unfair competition, so I simply don’t believe them when they say they’re passionately The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” concerned about fair competition. They say they’re concerned about harm. When the president of the—

### Moderator
Claim: One minute—

### Conspiracy Advocate (CA)
Claim: —National Hockey League, says that he’s— has screening for drugs because he’s concerned about the safety and health of the athletes, and there’s no laughter in the press room, you have to really wonder about what’s going on. Uh, if you have good arguments you don’t make up things. We have Lyle Alzado being rolled out again tonight, three times. There’s not a doctor in America who knows anything about steroids and cancer who thinks Lyle Alzado’s tumor had anything to do with steroids. There’s not another steroid user ever who had the kind of cancer he had. So if the headline had said “Lyle Alzado, Alcohol User, Has Brain Cancer,” I guess we’d be talking about alcohol causing brain cancer.

Uh, every person on this panel agrees that people should play by the rules, and there isn’t anyone up here who has defended breaking the rules. The topic that’s here for debate tonight is, what are the basis of those rules. If there was a rule prohibiting people playing with red hair, we would say of course if you have read hair you can’t play. But we wouldn’t say that that was a sensible rule. So rules have to have some moral basis or some rational basis. The fact that they simply are there doesn’t tell us anything about the basis of them. When we look at what the claims for them are, they seem hypocritical, inconsistent, or based on bad facts. People say they’re based on concerns about fair competition, but sports allow grossly unfair competition, Olympic sports, countries against countries, baseball, Yankees against Brewers, the leagues tolerate unfair competition, so I simply don’t believe them when they say they’re passionately The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” concerned about fair competition. They say they’re concerned about harm. When the president of the—

### Moderator
Claim: 20 seconds.

### Conspiracy Advocate (CA)
Claim: So the need to roll out misinformation over and over again suggests there’s not much going on the other side. Thank you.

### Moderator
Claim: And now speaking against the motion in summation, Dale Murphy.

### Scientific Advocate (SA)
Claim: The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Well, um, tonight was—it—the, the motion is about performance- enhancing drugs, should they be allowed in sports, I agree with, uh, what has been said, that it wasn’t about breaking the rules. But I’ve also heard performance-enhancing drugs tonight compared to your morning latte, uh, to lasik eye surgery, maybe we should not allow glasses, or a contact lens. Uh, but that is not the question, if the question was about alcohol abuse, again, I think we would all love to come back and talk about that. But performance-enhancing drugs is the issue, and to me, this, no matter how long it takes, this is a, a, a battle worth fighting. Um, what happens if I’m a major league baseball player under a doctor’s supervision, he tests me, looks at me, looks at my blood pressure, looks at all the factors and decides, you know, Dale, I don’t think you are gonna be on our guinea pigs as Dr. Fost, um, uh, intimated that we, we could use major league baseball players for if we—

### Moderator
Claim: One minute.

### Scientific Advocate (SA)
Claim: —if we let this go. Because your blood pressure is, you know, I know you’re trying to have kids, we don’t wanna boost your testosterone. Um, it—I—if, if, if it is generally acceptable to use The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” these things in my sport, but I can’t use ‘em or choose not to, I am at, at totally unfair, um, disadvantage. Speaking of the Yankees, and that they have more money than anybody else. Dr. Fost must’ve not been following the Yankees during the ‘80s. When they had more money than anybody else. If, if somebody with a lot more money than George Steinbrenner wants to buy the Yankees, again, that is fair competition, you can spend your own money, um, but it doesn’t guarantee success. Again, performance-enhancing drugs somehow was linked to the fact that the Yankees have an unfair advantage because they have a higher payroll. Again, the two don’t compare, that’s what we’re discussing tonight, and—

The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Well, um, tonight was—it—the, the motion is about performance- enhancing drugs, should they be allowed in sports, I agree with, uh, what has been said, that it wasn’t about breaking the rules. But I’ve also heard performance-enhancing drugs tonight compared to your morning latte, uh, to lasik eye surgery, maybe we should not allow glasses, or a contact lens. Uh, but that is not the question, if the question was about alcohol abuse, again, I think we would all love to come back and talk about that. But performance-enhancing drugs is the issue, and to me, this, no matter how long it takes, this is a, a, a battle worth fighting. Um, what happens if I’m a major league baseball player under a doctor’s supervision, he tests me, looks at me, looks at my blood pressure, looks at all the factors and decides, you know, Dale, I don’t think you are gonna be on our guinea pigs as Dr. Fost, um, uh, intimated that we, we could use major league baseball players for if we—

### Moderator
Claim: Time to wrap up.

### Scientific Advocate (SA)
Claim: And, um, to me, again, uh…Julian mentioned a zero-tolerance rule, that it’s confusing and we don’t know what’s out there. In baseball there is not a zero-tolerance rule. I wish there was, I think we would make great strides. In the—and again, in comparing that to the zero-tolerance—

### Moderator
Claim: Time.

### Scientific Advocate (SA)
Claim: —rule we have, on gambling on baseball. We can make progress The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” and change the culture.

### Moderator
Claim: Radley Balko.

### Conspiracy Advocate (CA)
Claim: Um— I—I’ve been really disturbed over the last month, listening to sports talk radio over…the—

### Moderator
Claim: It’s generally disturbing, Radley.

### Conspiracy Advocate (CA)
Claim: Yeah. Well there—there’s been a, a certain amount of glee and kind of a “gotcha” mentality to, to the Marion Jones situation and, uh, you know…I find it troubling that a woman is—a young woman is being pulled away from her kids, uh, and put in jail, uh, for six months leaving her kids without a mother, uh, for that time, over, uh, you know, a, a decision she made about her own health knowing the risks involved. Now granted she broke the rules. But, we’re in a…sort of a feeding frenzy about this at this point and it’s a, it’s a common tactic or it’s a common phenomenon, uh, when drug issues hit the media, uh, things tend to spin off into a moral panic. And, we sort of saw it tonight from our opponents, I mean the question tonight, the entire time is what should the rules governing sports be. And, a commoner frame particularly for Mr. Pound was that, well, we shouldn’t allow— The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

Um— I—I’ve been really disturbed over the last month, listening to sports talk radio over…the—

### Moderator
Claim: One minute.

### Conspiracy Advocate (CA)
Claim: —performance-enhancing drugs in sports because the rules say we shouldn’t allow them. Um, and I guess what I’m hoping you’ll take away from this after listening to our side of this is that maybe, every now and then we should sort of take a step back and examine whether the rules themselves are moral and are justified.

### Moderator
Claim: And some applause for Radley for actually using up only a minute and 120 seconds, Wow. that was good. All right. Speaking against the motion. And summarizing his viewpoint, George Michael.

### Scientific Advocate (SA)
Claim: The mother went to jail because Mom cheated, not with steroids, but it was a check-cashing scheme, and people like interviewed her a lot, before she ever became a star. And I bought in and believed everything she said when she said she didn’t use. I believed her. So that’s maybe why you might hear a little glee. Doctor, about kids. I don’t know if you all have ever heard of Efrain Marrero. Efrain Marrero—have you ever heard of him, Bob?

The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

### Moderator
Claim: The kicker.

### Scientific Advocate (SA)
Claim: No, this is, this is, no, this is his cousin. Efrain Marrero’s—

### Moderator
Claim: His cousin—

### Scientific Advocate (SA)
Claim: —a kid wanted to play—

### Moderator
Claim: His cousin—

### Scientific Advocate (SA)
Claim: Hey. Wanted to play baseball. He was good, not great. But he found out, someone told him, he’s 19 years old, he was told use steroids, and you’re gonna be good enough. You’ve got everything you need, just need some more power. So he starts using steroids and he becomes good. This is not make-believe, this is real. Efrain Marrero, 19 years old, his parents found out, and like good responsible parents Dad said, get off that stuff, because he was starting to get a little nutso. Get off that stuff or you can never play another baseball game. He obeyed his parents.

—a kid wanted to play—

No, this is, this is, no, this is his cousin. Efrain Marrero’s—

The mother went to jail because Mom cheated, not with steroids, but it was a check-cashing scheme, and people like interviewed her a lot, before she ever became a star. And I bought in and believed everything she said when she said she didn’t use. I believed her. So that’s maybe why you might hear a little glee. Doctor, about kids. I don’t know if you all have ever heard of Efrain Marrero. Efrain Marrero—have you ever heard of him, Bob?

The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”

### Moderator
Claim: One minute—

### Scientific Advocate (SA)
Claim: And he stopped cold turkey. One week later he went into his The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” bedroom and he blew his brains out. But there’s no evidence, that it was steroids that did it. Time up.

### Moderator
Claim: Actually breaking Radley’s record by seven seconds. And the last summation comes from Julian Savulescu. Julian.

### Conspiracy Advocate (CA)
Claim: Okay, both sides agree that cheating is ruining sport, and that this is really the tip of the iceberg. Their position is that we should increase the war on drugs, our position is that we should adopt a policy of regulated access to performance enhancers that are safe enough, and that are consistent with the particular sport’s spirit. This is not a debate about steroids. If indeed, these claims which are largely anecdotal claims are true, that steroids have these terrible effects, our side grants that steroids under those circumstances should be banned. However, that doesn’t deal with the use of human erythropoietin up to a hematacrit of 50 percent, it doesn’t deal with caffeine which is already a performance enhancer that’s been legalized, it doesn’t deal with growth hormone. There are many, many substances, in baseball, you could use Modafinil to increase reaction time, you could use new neutropics such as the Piracetam family to increase reaction time. These substances may well be safe enough. The question is should performance enhancers be The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” allowed, and there are many performance enhancers, our side believes, which should be allowed. Their position is bound to fail, it has been failing, it will fail because the prize money and the sophistication of the drive to technology—

### Moderator
Claim: 45 seconds.

### Conspiracy Advocate (CA)
Claim: Paradoxically, it harms athletes. Our proposal is enforceable, it frees up the limited resources to focus on drugs that may be affecting children, which we grant should not have access to drugs, it could be focused on drugs which are substantially un— un— harmful to athletes, and drugs which hare against the true spirit of sport. This is not a debate about steroids, it’s about whether performance enhancement itself is against the spirit of sport. As we’ve argued, performance enhancement is not against the spirit of sport, it’s been a part of sport through its whole history, and to be human, is to be better, or at least to try to be better.

Okay, both sides agree that cheating is ruining sport, and that this is really the tip of the iceberg. Their position is that we should increase the war on drugs, our position is that we should adopt a policy of regulated access to performance enhancers that are safe enough, and that are consistent with the particular sport’s spirit. This is not a debate about steroids. If indeed, these claims which are largely anecdotal claims are true, that steroids have these terrible effects, our side grants that steroids under those circumstances should be banned. However, that doesn’t deal with the use of human erythropoietin up to a hematacrit of 50 percent, it doesn’t deal with caffeine which is already a performance enhancer that’s been legalized, it doesn’t deal with growth hormone. There are many, many substances, in baseball, you could use Modafinil to increase reaction time, you could use new neutropics such as the Piracetam family to increase reaction time. These substances may well be safe enough. The question is should performance enhancers be The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” allowed, and there are many performance enhancers, our side believes, which should be allowed. Their position is bound to fail, it has been failing, it will fail because the prize money and the sophistication of the drive to technology—

### Moderator
Claim: Julian, thank you. We also thank all of our audience members, and again, though we had a spirited and I think every informative debate I wish we had had more time for questions from the audience, but you do get the final say, because now, you get to decide which side carried the debate. Once again, pick up the The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” keypad attached to the left armrest of your seat, and after my prompt, press “1” if you are now for the motion, “We should accept performance-enhancing drugs in competitive sports,” press “2” if you are against the motion, or “3,” if somehow after all this you remain undecided. Go ahead and cast your votes.

### Moderator
Claim: Apparently the debate continues even as you cast your votes. And, and after—after we tabulate, I know your question, it’s a good one, and we will, we will pose it, I wanna thank the debaters and the audience, uh, for their participation. And we have to take care of some housekeeping here, the next Intelligence Squared debate will be on Tuesday, February 12th, here at Asia Society and Museum. The motion to be debated then is, “America should be the world’s policeman.” It will be moderated by “60 Minutes” correspondent Morley Safer. The panelists for the next debate are, for the motion, Senior Fellow for National Security Studies at the Council on Foreign Relations Max Boot, Professor and Director of the American Foreign Policy Program at Johns Hopkins University, Michael Mandelbaum, and author and director of the Centre for Social Cohesion, Douglas The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” Murray. Against the motion, president and founder of Eurasia Group Ian Bremer, President and CEO of the Henry L. Stimson Center, Ellen Laipson, and Matthew Parris, writer for the Times of London and broadcaster for the BBC. An edited version of tonight’s Intelligence Squared debate can be heard locally on WNYC-AM 820, on Sunday, January 27th, at 8 p.m. These debates are also heard on more than 90 NPR stations across the country, please check your local NPR member station listings for the dates and times of broadcast, outside New York City. Copies of Dick Pound’s books, Inside Dope: How Drugs Are the Biggest Threat to Sport, Why You Should Care and What Should Be Done About Them, and Inside the Olympics: A Behind the Scenes Look at the Politics, the Scandals, and the Glory of the Games, are on sale upstairs in the lobby, you can also purchase DVD’s from previous debates here tonight, or from the Intelligence Squared website. And now, very, very briefly, should there be two tiers of sports, Olympics or otherwise, one for those who use, one for those who don’t, one on this side, one on that side, 10 seconds. Should there be two tiers?

### Conspiracy Advocate (CA)
Claim: Why not.

### Moderator
Claim: Why not he says, and uses only one second. Should there— Should there be two tiers, Olympics or otherwise, The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports” users, non-users—

### Scientific Advocate (SA)
Claim: Ab—absolutely not, because the, the bad users will pretend that they’re non-users.

### Moderator
Claim: All right. And now…after the debaters did their best to sway you, before the debate, 18 percent of you were for the motion that performance-enhancing drugs should be permissible in competitive sports. After the debate, 37 percent agree with this side of the table. Before the debate, 63 percent were against the motion. Now 59 percent are against the motion. Before the debate, 19 percent of you were undecided, and after the debate, only 4 percent of you wander into the night still shaking your heads, so— In summation, 59 percent against, 37 percent for, so, they improved their position, once the debate was over but not enough—

### Scientific Advocate (SA)
Claim: We just ran out of time—we just ran out of time—

### Moderator
Claim: —not enough to— You didn’t lose, you just ran out of time, many an athlete and coach has voiced the same lament. Thanks to all of you. The Rosenkranz Foundation - Intelligence Squared US Debate “Performance Enhancing Drugs in Competitive Sports”
