# Debate Transcript

Topic: America Should be the World's Policeman
Motion: America Should be the World's Policeman

Debate ID: AmericaWorldPoliceman-021208


## Round 1

### Moderator
Claim: I’d like to introduce Robert Rosenkranz, Chairman of the Rosenkranz Foundation, the sponsor of Intelligence Squared, who will frame tonight’s debate.

### Moderator
Claim: Thank you, Morley. And thank all of you for braving the rather forbidding elements tonight. With me is Dana Wolfe, our Executive Producer. Well, tonight’s debate reflects what will almost certainly be a major theme in the upcoming Presidential election, particularly if Barack Obama’s momentum and fundraising prowess carry him to the Democratic nomination. We can expect campaigns that reflect stark differences in views about America’s military engagement with the world. Each of Rosenkranz Foundation-Intelligence Square U.S.- these views has a long political pedigree – antecedents ranging from Jeffersonian isolationism, Hamilton’s economic liberalism, Jackson’s muscular populism and Wilson’s humanitarian idealism. Each would come to very different conclusions on tonight’s resolution. Among the arguments that America should be the world’s policeman are: Who else will protect the peaceful from the ruthless, especially the ruthlessness of Islamic radicalism. Who else will cope with nuclear proliferation or threats to the world oil supply. The U.N. has proven useless. NATO is too unwieldy and has under-invested in its militaries for decades. Only the U.S. has the capability to lead and to act.

The counter-argument is that no single nation is fit for the role of global policeman – certainly not an over-stretched and economically challenged America, an America with a deeply flawed intelligence operation, ineffective public diplomacy and only a superficial understanding of other cultures. Police are viewed skeptically and for good reason, particularly if there are no international institutions to check their power. We need a multilateral approach for legitimacy and to be successful. So these are the two arguments that are going to be elaborated on by a wonderful panel of speakers that I’m particularly proud of. And I’m pleased to turn the evening over now to our moderator, Morley Safer. Morley has received many awards for his long and Rosenkranz Foundation-Intelligence Square U.S.- distinguished career in broadcast journalism. He’s been a correspondent on 60 Minutes for CBS since 1970. So this is his thirty-eighth year on the show this season. Morley, the evening is yours.

### Moderator
Claim: Thank you, Bob. I’d like to welcome you to the seventh debate of the second Intelligence Squared U.S. series. The resolution being debated tonight is: America should be the world’s policeman. And let me give you a brief run down of the rules of the game. Members of each team will alternate in presenting their side of the argument. Presentations are limited to seven minutes. When opening arguments are complete I will open up the floor to brief questions from the audience. After the Q&A each debater will make a final two minute summation. And finally, you will vote on tonight’s motion with the keypad attached to the armrest of your seat and I will announce your decision on which side carried the day. Let’s start with a pre-debate vote. You should have one of these. Pick it up. It should be attached to the armrest on your left. And for audience members sitting along the aisle, to my right, your keypad is attached to the armrest on your right side next to your neighbor’s. Again, tonight’s resolution is: America should be the world’s policeman. After my prompt please press one to vote for the motion, two to vote against the motion or three if you’re undecided. You may Rosenkranz Foundation-Intelligence Square U.S.- begin voting now. Everyone voted? Okay, I will announce the result of your vote later on in the evening. I’d now, now like to introduce the panel, and please hold your applause until all six are introduced. For the motion, a Fellow in National Security Studies at the Council on Foreign Relations, Max Boot, professor of American Foreign Policy at the Johns Hopkins University School of Advanced International Studies, Michael Mandelbaum, and author, commentator and director of the Centre for Social Cohesion, Douglas Murray. And to my left, against the motion, president and founder of the Eurasia Group, Ian Bremmer, President and CEO of the Henry L. Stimson Center Ellen Laipson, and writer for the Times of London and the Spectator, then broadcaster for the BBC and a former British Member of Parliament, Matthew Parris. We will start with Max Boot voting for the motion.

### Conspiracy Advocate (CA)
Claim: Thank you very much. And first I’d like to thank Bob and Alexandra and Dana for the terrific job they’ve done in turning this debate series into reality. And I’d like to thank all of you for showing up on such a miserable evening to hear a debate about what I do think is one of the most important issues that we could possibly talk about. No doubt many of you are asking yourselves tonight, why should America take on the thankless task of policing the globe. To answer that question, start by Rosenkranz Foundation-Intelligence Square U.S.- asking, does the world need a policeman. That’s like asking whether New York City needs a police force. As long as evil exists, someone will have to protect peaceful people from predators. The international system is no different in this regard from your own neighborhood, except that predators abroad are far more dangerous than ordinary robbers, rapists and murderers. They are, if given half a chance, mass robbers, mass rapists, mass murderers. Without an effective police force the world community would fall apart faster, and more completely than New York City did in the 1970s.

There are to be sure lots of international laws on the books prohibiting genocide, landmines, biological weapons and other nasty things. But without enforcement mechanisms they are as worthless as the Kellogg-Briand Pact, which outlawed war as an instrument of national policy, 11 years before the Vermacht rolled into Poland. The hope of idealistic liberals for more than a century has been that some international organization would punish the wicked. But the League of Nations was a dismal failure, and the UN is not much better. The best multilateral alternative is probably NATO. But from Bosnia to Afghanistan we have seen time and again that NATO has trouble acting effectively. In fact five retired NATO generals have just issued a report that bemoans the absence of a properly defined political Rosenkranz Foundation-Intelligence Square U.S.- objective, the absence of an integrated strategy to achieve that objective, and the absence of capabilities to implement the strategy. Now that doesn’t mean we should abandon NATO. It does mean we should have no illusions that its European members can fend for themselves. So who does that leave to be the world’s policeman. Belgium, Bolivia, Burkina Faso, Bangladesh?

I think the answer’s pretty obvious. It’s the country with the most vibrant economy, the most fervent devotion to liberty, and the most powerful military. In the 19th century, Great Britain battled enemies of all mankind such as slave traders and pirates, preserved the balance of power on the continent, and kept the world’s seas open to commerce. Today the only nation that can play an equivalent role is the United States of America. Allies will be needed, but America is, as Madeline Albright said, the indispensable nation. Now skeptics will reply that America has an isolationist past, and no desire to past globo-cop. But rumors of American isolationism are greatly exaggerated. Since the earliest days of the republic American traders, missionaries and soldiers have penetrated the farthest corners of the world, and they have a long history of upholding civilized norms. I am reminded in fact of the words spoken 104 years ago, by a great New Yorker. He said, “Chronic wrongdoing, or an impotence Rosenkranz Foundation-Intelligence Square U.S.- which results in a general loosening of the ties of civilized society, may ultimately require intervention by some civilized nation.

And in the Western Hemisphere, the adherence of the United States to the Monroe Doctrine may force the United States, however reluctantly, in flagrant cases of such wrongdoing or impotence, to the exercise of an international police power.” Now when Teddy Roosevelt spoke those words, the Western Hemisphere was the only place where the US exercised military hegemony. Today America exercises almost as much power everywhere around the world, as we once had only the Caribbean. In fact we have more power than any other state in history. Thus, by Roosevelt’s logic the US is obligated to defend civilization, and that is precisely what we are doing. That is why American troops have fought in places like Bosnia, Kosovo, Afghanistan and Iraq to up—restore the rule of law and uphold human rights. That is why American troops are still stationed from South Korea to Germany, to prevent aggression and a return of dangerous rivalries. That is why the US Navy patrols the world’s oceans, to prevent the closing of checkpoints at— chokepoints, such as the Straits of Hormuz.

And that’s why numerous agencies of the US government work to combat terrorism, and to stop the spread of weapons of mass Rosenkranz Foundation-Intelligence Square U.S.- destruction. That is what being the world’s policeman is all about. Of course we cannot right every wrong, nor intervene everywhere. We have to use prudence and judgment in the exercise of our power, something we have not always done in recent years. But America’s occasional missteps should not lead us to abdicate our indispensable role, any more than the NYPD should stop doing its vital work, simply because cops occasionally do the wrong thing. On balance, the NYPD still does far more good than harm, and so does the United States of America. In fact America has been the greatest force for good in the world in the past century. Just think of what happened when we did not act as globo-cop. Think of what happened in 1914, in 1939. By contrast, think of what happened when we did act as globo-cop. Think of what happened in 1945, and 1989. American intervention made possible the defeat of Nazism, and Communism. American isolationism made possible the outbreak of two world wars.

As these examples demonstrate, there is nothing altruistic about our globo-cop role. As the world’s most prosperous country, and as a country that depends for its prosperity on the free flow of people, capital and products, we are the biggest beneficiaries of the liberal international order that we safeguard. Compared with the benefits that we gain the financial costs are trivial. We Rosenkranz Foundation-Intelligence Square U.S.- currently spend 4% of our GPD on defense, a lot less than the average during the past four decades. That 4 cents on the dollar preserving international peace and stability is a bargain. Now I imagine that the other side will claim that our international policing function makes us hated, and leads to greater violence against us. That is sometimes the case and I will be the first to admit it. But we are as often reviled for not acting, for not stopping the genocide in Rwanda or Darfur, for not imposing peace between the Israelis and Palestinians. And yes, there is a cost to be paid for action, as we’ve learned in Iraq.

But there is also a cost to be paid for inaction. During the 1990s we ignored our policing responsibilities in Afghanistan. As the civil war raged between the Taliban and the Northern Alliance, our leaders said in essence what Britain’s leaders said in the 1930s—that there is no reason to be concerned about a quarrel in a faraway country between people of whom we know nothing. Well on 9-11 we found out why we should care. The answer can be seen a few miles from here, where the World Trade Center once stood. 9-11 should’ve taught us that we cannot ignore potential peril, nor count on others to protect us. We must safeguard ourselves, and not simply by launching retaliatory Rosenkranz Foundation-Intelligence Square U.S.- strikes after thousands, perhaps millions have perished. We need to play a proactive role. We need to police areas of unrest, and to do what we can to bring decent government to war-torn lands. If we fail to act, we, as the mightiest nation in the world, will pay the heaviest price. I therefore urge you to heed Theodore Roosevelt’s admonition, and to vote in favor of America exercising an international police power. Thank you.

### Moderator
Claim: One minute—

### Conspiracy Advocate (CA)
Claim: But there is also a cost to be paid for inaction. During the 1990s we ignored our policing responsibilities in Afghanistan. As the civil war raged between the Taliban and the Northern Alliance, our leaders said in essence what Britain’s leaders said in the 1930s—that there is no reason to be concerned about a quarrel in a faraway country between people of whom we know nothing. Well on 9-11 we found out why we should care. The answer can be seen a few miles from here, where the World Trade Center once stood. 9-11 should’ve taught us that we cannot ignore potential peril, nor count on others to protect us. We must safeguard ourselves, and not simply by launching retaliatory Rosenkranz Foundation-Intelligence Square U.S.- strikes after thousands, perhaps millions have perished. We need to play a proactive role. We need to police areas of unrest, and to do what we can to bring decent government to war-torn lands. If we fail to act, we, as the mightiest nation in the world, will pay the heaviest price. I therefore urge you to heed Theodore Roosevelt’s admonition, and to vote in favor of America exercising an international police power. Thank you.

### Moderator
Claim: Against the motion, we’ll begin with Ian Bremmer. No, I’m sorry, I am sorry… Okay. I should sure this, can’t I—

### Scientific Advocate (SA)
Claim: Okay? Well, good evening, everyone, I’m not Ian Bremmer, I’m Ellen, and I rise to oppose the notion that the US should be the world’s policeman. The United States indisputably has a vital role to play in world affairs, we have unique qualities for leadership. At present, perhaps not as a permanent state of affairs, some of this unique role is circumstantial because our only peer adversary for over half a century is no more. Some of it is inherent in our qualities. The size of our country, the wealth that we enjoy, and the talent of our people. We can influence world affairs, both by conscious decisions that our governments make, by our society’s desire to respond to humanitarian Rosenkranz Foundation-Intelligence Square U.S.- disasters, and in positions that we take in multilateral negotiations and in regional organizations. Americans for the most part do want to be active on the world stage. But we can do good in the world, and we can benefit as a society, from active engagement in the world, without being the world’s policeman. Let’s talk some definitions.

Now, I don’t know whether the organizers of this debate meant “police” in a literal sense. But let’s take the word “police” at three different levels. First would be “police” as in a demand for someone to enforce the rules, not make the rules, but enforce them. So who do you—when you’re in trouble, call 911, the police come. So that’s the kind of bottom-level, literal definition of, of policeman in this case. We could also think of the world’s policeman as a metaphor for a security provider in much broader dimensions. Who sets the laws and enforces them. This would be a reference to the hegemonic stability system that we’ve known internationally since World War II, that would refer to for example America’s military presence in East Asia, or in the role that we played when we finally decided to topple the Taliban in Afghanistan.

And then there’s a third definition that’s perhaps a little more abstract. “Policeman” as a surrogate for any use of force, or for a Rosenkranz Foundation-Intelligence Square U.S.- monopoly on the use of force, including going to war, preemptive wars, preventive wars. We decided Saddam Hussein had to go, we made the rule for ourself it wasn’t a rule for anybody else, it was just for us. So that’s a third definition of “the world’s policeman.” So I oppose this motion and I hope you will agree with me, for several reasons. First let’s take some practical reasons. The US is a country, not a global government. We have to know our limits. The United States should use force when it’s in our interest, just like every other country has to make existential decisions about the use of force and about war and peace. If we step up to the role of the world’s policeman we would be committing to act and to put our soldiers and police and our citizens in harm’s way where U.S. interests may be very modest. Do we want to assume responsibility to go anywhere anytime? A second practical argument is that we can’t do it. And here I mean both in terms of quantity and quality. Quantity: guess how many of the eleven thousand police who are currently deployed worldwide in U.N. operations are American? Out of eleven thousand, two hundred and ninety-one are U.S. policemen. And they are in Kosovo and Haiti, principally. So the U.S. has not provided robust manpower from our police forces. We’ve also learned that the way we train our policemen in a federal system is not all that well suited to the requirements for police in a lot of peace operations post-conflict. And then let’s Rosenkranz Foundation-Intelligence Square U.S.- ask literally, are we capable of doing the job? Can we be the beat cop that Max talked about? Do we know the neighborhood? Do we speak the language? Do we know the culture so that we can diffuse conflict before it breaks into violence? I’m not so sure about that. It turns out that a lot of other countries, by the way, are willing to train their citizens and deploy them to be policemen in such circumstances – the South Asians, the Australians, the Canadians and the Nordics, in particular.

A third practical reason is that I’m not sure the American people want us to play this role alone. There is a deep belief that the security burdens in the world need to be shared and that not all security problems affect American interests. We need to make choices. Polls show that Americans want to respond when there are humanitarian requirements, et cetera, but they don’t want to do it alone. Now, I’m not going to make the cost argument because I actually don’t think it’s the most persuasive one. The U.S. does still contribute twenty-five percent of the U.N.’s costs to deploy forces around the world but we are behind in our dues. And before we criticize the U.N., I think we better decide whether the under-funding of some of the U.N.’s activities are, in fact, because we haven’t paid our, our fair share.

Second set of arguments I want to make against this motion are Rosenkranz Foundation-Intelligence Square U.S.- political ones. And here basically it’s two arguments. One is an argument about today, the particular moment that we’re in. And another is an argument about the horizon, about the future. I think today we have a particular problem trying to assert that we could or should be the world’s policeman. We have over-used our global leadership role. We have abused, in a way, the, the good will of the international community by deciding that we knew better than anyone how to bring security to dangerous parts of the world. And it turned out we weren’t as good at it as we thought we would be. We have not necessarily made – at least the key, Iran and Afghan…Iraq and Afghanistan – more secure or more stable. This is not the moment to reassert the policeman’s role.

A third set of arguments – at the horizon my argument is that there is a realignment of power in the 21st Century. Other countries are rising. This does not mean that the United States is in decline. It does not mean that we’re weak. But other countries are rising and it’s a good moment to try to reallocate some of the responsibilities for these activities. I have a third, a last argument, which is a philosophical one. I think it would behoove American society and the long term interests of the Rosenkranz Foundation-Intelligence Square U.S.- American people if we would take a more nuanced and egalitarian sense of our place in the world. In the age of globalization we’ve benefited at least as much as everybody else.

But we have to be, we have to start to recognize that other people are good at this game too, and that we have to have more respect for the capacity of others to contribute to the global commons. So what I advocate is a multilateral approach to the security needs of the international community. I want an integrated approach that doesn’t look just at the security aspects of some of these problems but weaves together cultural, political and economic dimensions of policy responses. And I want us to care a lot more about the legitimacy of how we engage internationally, particularly since, as the world becomes more democratic –

Okay, thank you very much.

### Moderator
Claim: One minute.

### Scientific Advocate (SA)
Claim: A third set of arguments – at the horizon my argument is that there is a realignment of power in the 21st Century. Other countries are rising. This does not mean that the United States is in decline. It does not mean that we’re weak. But other countries are rising and it’s a good moment to try to reallocate some of the responsibilities for these activities. I have a third, a last argument, which is a philosophical one. I think it would behoove American society and the long term interests of the Rosenkranz Foundation-Intelligence Square U.S.- American people if we would take a more nuanced and egalitarian sense of our place in the world. In the age of globalization we’ve benefited at least as much as everybody else.

But we have to be, we have to start to recognize that other people are good at this game too, and that we have to have more respect for the capacity of others to contribute to the global commons. So what I advocate is a multilateral approach to the security needs of the international community. I want an integrated approach that doesn’t look just at the security aspects of some of these problems but weaves together cultural, political and economic dimensions of policy responses. And I want us to care a lot more about the legitimacy of how we engage internationally, particularly since, as the world becomes more democratic –

### Moderator
Claim: Time is up, Ms. Laipson.

### Scientific Advocate (SA)
Claim: Okay, thank you very much.

### Moderator
Claim: And now for the resolution, Michael Mandelbaum.

### Conspiracy Advocate (CA)
Claim: Thank you. You will observe that some of the things that I have to say overlap some of the things that Max Boot said. This is so, I daresay, not only because great minds run in the same channel, Rosenkranz Foundation-Intelligence Square U.S.- but also because the things on which we agree are true. All societies, when they become sufficiently interdependent, need governance. The society of states, the society of sovereign countries has reached that point. The international society needs governance and the United States provides it. The United States provides to other countries some, although not all, of the services that governments provide within the countries that they govern. This, as it happens, is the thesis of my 2006 book, The Case for Goliath: How America Acts as the World’s Government in the 21st Century, that the organizers have very kindly provided outside this room. Hmm. The United States provides order to the world, as governments must, in two ways. First, economic activity within countries requires a secure backdrop. Government protects commerce and enforces contracts. The United States does this in the global economy. American military deployments and the American alliance systems assure the free flow of trade and the movement of capital across borders. This economic activity known as globalization, and made possible by the American role as the world’s police force, has brought benefits to hundreds of millions of people. Second, the United States helps keep order in the world by leading the effort to keep weapons of mass destruction Rosenkranz Foundation-Intelligence Square U.S.- out of the hands of groups or individuals that would deploy them in ways antithetical to the interests not only of the United States, but of the world in general. The United States leads the effort at global nuclear non-proliferation. And in these two ways above all, the United States acts as the world’s police force.

Now, to this argument at least three objections may be made. And we’ve already heard one of them. One objection is that the United States does not carry out its policing duties as well as it should. As Ellen Laipson said, the United States is not present everywhere and doesn’t act perfectly. And this is certainly true, but neither does any police force. Every police force is subject to criticism, legitimate criticism. But criticizing a police force is not the same thing as arguing that there should not be one. A second objection to the motion is that it would be better if global policing were carried out, not by the United States, but by other countries or groups of countries or international organizations.

Now, I daresay if the proposition were put that way to the American public a majority of them might agree. But it is the fact, as Max Boot noted, that there is no other country or group of countries that is willing or able to take up the burden of global policing. And as for international organizations, they are far too feeble to do so, and that emphatically includes the international Rosenkranz Foundation-Intelligence Square U.S.- organization to which some would like to assign the task of global policing – the one whose headquarters is located a few blocks from here – the United Nations. So the alternative to the United States as the world’s policeman is not a better international order. It is more international disorder. Well, a third objection is, what about Iraq? Well, the American military operations in Iraq really have two parts. The first part involved removing a tyrannical government and insuring that neither it nor a tyrannical successor would possess weapons of mass destruction.

The second part of the operation involves trying to construct a stable, decent democratic government in that country. The first task which falls within the purview of global policing was successfully accomplished. The second has not been done so successfully. But the second task – what’s wrongly called nation building and should be called state building – is not an example of police work. It’s an example of social work. The United States is not good at social work but it doesn’t have to be to perform as the world’s police force. So to oppose this motion you must believe one or both of two things. You must believe either that the world does not need policing or that there is some better source of global policing than the United States. There is, I submit, no reason to believe either. And I will add, by way of Rosenkranz Foundation-Intelligence Square U.S.- conclusion, that there is one group of people with a keen interest in global order and extensive familiarity with the American role in the world that emphatically does not believe either proposition.

I refer to the world’s governments. They could, if they chose, circumscribe or abolish altogether by banding together to oppose it, the American role as the world’s policeman. But they have done and shown no signs of doing any such thing. And the reason is that they understand and appreciate the benefits that America’s role as the global policeman confers upon their countries and on the world as a whole. So whatever the verdict of the people in this house, the governments of the world above all, by what they have not done, have voted in favor of this motion. Thank you.

### Moderator
Claim: Against the motion, uh, Matthew Parris.

### Scientific Advocate (SA)
Claim: Ladies and gentlemen, I was touched by what Max Boot, Max Boot said about the excellence of the British empire and British imperialism in the 19th and early 20th Century. I'm old enough – he’s not – to remember that that was not the American attitude towards British imperialism, even in the 1950s and the 1960s. What happens when any one nation tries to assert, coercively, its predominance over the rest of the Rosenkranz Foundation-Intelligence Square U.S.- world is that other nations begin to gang up against them. And in that case the United States was part of the group that ganged up against the British empire. It might be fair, it might not be fair. But it will always happen and it’s something to which I want to return. But first – and if you’ll forgive me that spirit of malice which I find rescues these occasions from the horrors of constructive debate, may, may I,-- I say what a privilege it, it is to find ranged, against me three of the finest minds it’s possible to locate among protagonists for a doomed cause. One of my fellow countrymen, Douglas Murray’s precocious genius – well, few on the British, the thinking British right have not heard of Douglas Murray’s genius. I have to tell you, ladies and gentlemen, that he has taken elements in Britain quite by storm. One commentator praises him as the right’s answer to Michael Moore, God help us. His unkinder critics have suggested – I, I think in jest-- that when younger he had a brief flirtation with the Baptist Church. Only on discovering that baptism by total immersion meant disappearing entirely from the public view for all of thirty seconds, made Mr. Murray relent. Max Boot appeared last year on a list of the Five Hundred Most Influential Foreign Policy Thinkers. We, on this side of the debate, do not dispute Mr. Boot’s influence on foreign Rosenkranz Foundation-Intelligence Square U.S.- policy thinking any more than we dispute the influence of Donald Rumsfeld or King George the III. Both Murray and Boot and Michael Mandelbaum, too clever for the mob on their own side, represent one of the most interesting political experiments in outsourcing ever conducted-- U.S. conservatism’s franchising out to experts of its higher mental faculties. Their function, they’re a kind of priesthood, is to flatter stupider people that there exist higher arguments, smarter than they themselves can quite grasp, for things that they wanted to do anyway. They should be here in white robes. Three fine fellows, then – one of them older, one of them younger, all of them prettier and all of them cleverer than the argument that they represent. We salute them. Next, to the, to the argument that they represent: why must Washington shun the mantle of world policeman? For three reasons: First, America can’t; Second, America shouldn’t; and Third, Americans won’t embrace this role.

We don’t debate whether Belgium should police the world because the possibility does not arise nor does it for America, as Ellen Laipson says – not even America. She is more powerful than any but nowhere like more powerful than all of the nations of the world. The point at which the United States most closely Rosenkranz Foundation-Intelligence Square U.S.- approached political hegemony – military, political and economic – was more than half a century ago. It was at the end of the Second World War. Since then, and despite magnificent growth in absolute terms, America has been in almost continuous relative decline. After the implosion of the Soviet Union the impression of power vacuum was just a mirage. It was not a vacuum. It was a fragmentation, as America and my own country, Britain, are discovering in Iraq and Afghanistan, where we are hopelessly entangled in two quite undeveloped countries, both of which I visited since the occupation.

Where are the armies? Where are the fleets? Where are the treasure chests to finish this job, let alone embark on new coercions? If the predominance of America’s wealth and power in comparison with any single rival has misled some into supposing that America could out-punch all of them together, it never misled cleverer men like Messrs. Boot, Mandelbaum and Murray. They have advanced a more subtle theory that if America picked on a single miscreant nation and sorted it out by force, then mission accomplished – others would learn the lesson. It’s an attractive idea. It didn’t work – quite the reverse. It triggered an international up-swelling of resentment and resistance. This has weakened America’s greatest resource – good will, her powers of persuasion.

Rosenkranz Foundation-Intelligence Square U.S.- Maybe you think the world is judging America unfairly. I, I think the world judged imperial Britain unfairly. But ask why that happens, why that always happen. And if you want to know the answer, ask how Americans would feel if the boot – Max will forgive me – were not on the American foot. Of all people, Americans should know that a policeman implements laws made by and for the people that he polices, under a government whose legitimacy derives from its being their own. Police other nations and there will be no such assumed legitimacy. Without acquiescence you can only impose. America does not have the brute power to impose, nor the right. I said that not only can America not police the world but that she should not. With whatever good will you set out with –

…on your policeman’s beat, your decisions must in the end take account of your own interest. How can it be otherwise? Faced with a conflict between the interests of the American people and anywhere else in the world, how can a democrat believe that Washington can or would stand blindfold in disinterested judgment between the two? We act, in the end, in our own interests. Finally, I said that America won’t police the world. I Rosenkranz Foundation-Intelligence Square U.S.- don’t believe it is the will of the American people. I’m not a narrow horizon Englander. I was born in Africa, schooled in Cyprus, Zimbabwe. My family lived for five years in Jamaica. I was at school in Swaziland and for two years at Yale University. I know a bit about America and Americans. And I think there’s something different about you. I think that even if you could police the world, I don’t think that Americans want to police the world. I don’t think that Americans are isolationist. I think that on occasions America has to intervene abroad, has to respond, has to defend herself. But I think it’s in the instincts of the American people to demand of their statesmen that reasons are given for that. There will never be a long, longstanding will among the American people for international intervention. Curiously enough, I

May I just finish my sentence?

Though you think your argument faces a tough test before an audience of internationalist New Yorkers, it’s out there in the sticks, among the right, where it will finally flounder. I know Rosenkranz Foundation-Intelligence Square U.S.- those people. I represented them in England. They are conservatives. You, Max, Douglas and your cartload of doctrine and theory, are not. I beg to oppose the motion.

### Moderator
Claim: One minute.

### Scientific Advocate (SA)
Claim: …on your policeman’s beat, your decisions must in the end take account of your own interest. How can it be otherwise? Faced with a conflict between the interests of the American people and anywhere else in the world, how can a democrat believe that Washington can or would stand blindfold in disinterested judgment between the two? We act, in the end, in our own interests. Finally, I said that America won’t police the world. I Rosenkranz Foundation-Intelligence Square U.S.- don’t believe it is the will of the American people. I’m not a narrow horizon Englander. I was born in Africa, schooled in Cyprus, Zimbabwe. My family lived for five years in Jamaica. I was at school in Swaziland and for two years at Yale University. I know a bit about America and Americans. And I think there’s something different about you. I think that even if you could police the world, I don’t think that Americans want to police the world. I don’t think that Americans are isolationist. I think that on occasions America has to intervene abroad, has to respond, has to defend herself. But I think it’s in the instincts of the American people to demand of their statesmen that reasons are given for that. There will never be a long, longstanding will among the American people for international intervention. Curiously enough, I

### Moderator
Claim: Please wrap it up Mr. Parris.

### Scientific Advocate (SA)
Claim: May I just finish my sentence?

### Moderator
Claim: Sentence.

### Scientific Advocate (SA)
Claim: Though you think your argument faces a tough test before an audience of internationalist New Yorkers, it’s out there in the sticks, among the right, where it will finally flounder. I know Rosenkranz Foundation-Intelligence Square U.S.- those people. I represented them in England. They are conservatives. You, Max, Douglas and your cartload of doctrine and theory, are not. I beg to oppose the motion.

### Moderator
Claim: Thank you. Before we continue, I—I have a question or two for each side here. Max Boot, you make the case…that the alternative to unilateralism, is isolation. Whatever happened to diplomacy?

### Conspiracy Advocate (CA)
Claim: If I gave you the impression that…the alternatives are either unilateralism or isolationism I—that’s, that’s false, and in fact I tried very hard not to give that impression because what I talked about was not necessary unilateralism, it was American global leadership, and as I said, we should try to act with allies wherever possible. We should certainly not go it alone unless it’s absolutely necessary. But in certain circumstances it is absolutely necessary, and even with allies we cannot simply do what the herd wants, we have to provide leadership. We saw in the case of Bosnia for example in the early 1990s what happened when American global leadership was absent. And that was genocide occurring and it was only when we stepped forward and mobilized our allies in the way that a policeman might mobilize a posse that we were able to be effective, so—

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- But the record for intervention is abominable, when you think of the intervention in Vietnam. When we think of the intervention in Cuba, I mean the list goes on and on—and, and Chile.

### Conspiracy Advocate (CA)
Claim: Well, I would say to you—

### Moderator
Claim: And all of those places.

### Conspiracy Advocate (CA)
Claim: Well, in the first place—

### Moderator
Claim: We are—interventionists we may want to be, but inept we are.

### Conspiracy Advocate (CA)
Claim: Well, in fact I would argue that a lot of our interventions have worked out reasonably well and I think for example of World War II or the Gulf War and more importantly I think of the consequences of not in— intervening, for example the fact that we did not intervene in Europe in the 1930s, I think that failure speaks for itself.

### Moderator
Claim: Well, in an age of atomic proliferation, “reasonably well” just isn’t good enough, I guess. Ms. Laipson, you talk about engagement—

### Conspiracy Advocate (CA)
Claim: How many debaters do we have on—on the other side there.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- You talk about engagement. But, in the case of Iran where the other side really has no interest in engagement, or North Korea has no interest in engagement, I mean, we can be out there engaging all we want, and nobody’s accepting the ring.

### Scientific Advocate (SA)
Claim: Well I think the North Korea and Iran cases are a category that’s a little bit different than the requirement for a policeman, although Michael Mandelbaum put non-proliferation inn this basket that we’re talking about tonight. But both of those problems are being managed with, you know, international cooperation, and even if the United States had—didn’t want to engage initially with North Korea, and still today with Iran, the reality is we have found interlocutors to engage with both. And the progress has been made in the six-party talks with North Korea. I certainly agree with you that Iran is in one of those, you know, very hard baskets, and engagement alone is not necessarily sufficient. There are circumstances in which coercive diplomacy, sanctions, there are other instruments of international politics that can be, can be exercised. But I would argue that at least under today’s circumstances, you know, Iran is not, Iran has many policies that we do not like, but it is not playing the role of a belligerent, that requires a military action right now.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- We will continue now with…for the resolution, Douglas Murray.

### Conspiracy Advocate (CA)
Claim: Okay, thank you, thank you very much, it’s very good to be here. And thank you for listening to me, it’s good to be another Brit here, partly, partly so that you don’t all think that Brits think like Matthew Parris… It’s an odd position to be in, perhaps some of you think to have somebody from another nation coming along to you here and saying, effectively, please police me… A strange misquote of that wonderful thinker Engelbert Humperdinck… But… But it’s not quite as masochistic as it sounds when we talk about the world’s policeman, a lot of people assume up the idea of force, and that you have the right to do it because you’re powerful.

I don’t think that is what the reason is, that America has the right to be and should continue to be as it currently is the world’s policeman. It’s not your force as a nation which I think allows you that right, it’s America’s virtues that allow it that right. It’s the fact that, when America goes into a country like Afghanistan or Iraq, you don’t do the things which previous great powers did, that the moment, if anything this is a failing, if anything, when you go into a country like Iraq, you don’t say how long can we Rosenkranz Foundation-Intelligence Square U.S.- stay here, but how soon can we get out. You want to dabble as little as possible in the world--I think that’s a virtue. You know when you have to intervene. But you also know when you have to get out. But, uh, to clear up some of the mistakes from other side already, just because you’re the world’s policeman doesn’t mean you don’t have allies. It doesn’t mean you don’t have friends and others who will do the job, who’ll join you in the job.

America in the last few years, despite the caricature of her greatest enemies, is not the unilateral organization that a lot of people would portray her as being. Now, as my two colleagues and comrades on my side have already intimated to you, there are really only two reasons not to vote for the right side if I may, in this in this motion. The first is that you think that the world does need a policeman, but that someone else can do it. Someone else will step up for the job. We’ve heard quite a lot at the moment, uh, from people talking more I think in glee than sorrow about the rise of China, for instance. You can look in your papers any day and see what the rise of China would bring in its wake if you wanted them to police the world, look at the athletes for instance going to the Olympics, being, attempting to be forbidden from speaking out about any Chinese abuses whilst they’re there.

Rosenkranz Foundation-Intelligence Square U.S.- You want a perpetual silencing like that across the globe? You don’t see America trying to do that, you don’t see America trying to silence her enemies. America is the only force I can think of which tolerates people standing up against it, shouting as loudly as possible, picketing its military institutions and all this kind of thing permits that. Think of another world power that would permit that kind of thing, or another policeman that wouldn’t object when people continue to rejoice in poking it in the eye. Who else might be on the horizon? You might see, there’s a lot of talk for instance at the moment about Saudi Arabia. We have a lot of talk about that in Britain at the moment with our Archbishop of Canterbury, or soon to be promoted to the Grand Mufti of Canterbury. Saying that he wouldn’t mind Sharia law in Britain, I was sitting opposite a clerical goon two mornings ago in London who was explaining to me, Sheik Sewit Hassan what the sharia that he would like to bring to Britain would be and that, yes, we should cut off hands, we should stone women to death, because it would teach the others, and he hadn’t seen any adultery in Saudi Arabia. And I pointed out you don’t actually often see adultery happening, but— But you might get those kind of global systems if you, if you wish Rosenkranz Foundation-Intelligence Square U.S.- it hard enough, if you wish hard enough for America to fall, for America to be poked in the eye. But what will you do, who will sort out these problems, who will sort out a problem like Iran, when you have years of talks and the only progress you’ll really hear of is Iran getting closer and closer to its desired objectives of nuclear power. So that’s the first reason, the first reason why you would vote against this motion, the second, is that you think that the world doesn’t really need a policeman. It will be just fine without one. This, ladies and gentlemen, is, I think, a terrible, terrible illusion, it’s a siren call which has called across history to people. It called to the people of Athens two and a half millennia ago when Demosthenes warned them of the threat from King Phillip and said you do have other people who will tell you, if you ignore this threat, you will save money, and you’ll be able to spend it on other things… But, I know that if you listen to them, you will one day wake up, and you’ll realize how much this optimism cost you. You’re in the same position today, ladies and gentlemen. As people have been throughout history, as the person—the famous journalist who before the First World War wrote that, war in Europe was now an impossibility, because it was so economically unviable. Well it turned out to be more unviable for more reason than economics and people did it anyway. You will not be able to live Rosenkranz Foundation-Intelligence Square U.S.- in a world in which no one acts as your policeman. And let me cite one example of where the virtue of American intervention has been cited already by Max Boot, is not only necessary but vital and I’d cite the case of Kosovo. This might well come back again and again later. But, when the concentration camps in Europe reopened in the 1990s in the Balkans, and when we saw an ethnic genocide, an ethnic cleansing, from a third-rate tin-pot dictator and the European governments couldn’t stop it, who was it who had to stop in.

It wasn’t France, France provided us with a phalanx of lawyers, and a leak. America provided us with 98% of the world—the air power, and they stopped a genocide, that’s no small achievement, ladies and gentlemen, I will—could go through all of the things which Ellen Laipson said, of the problems that you have enforcing, as nobody says that it’s good being the world’s policeman, nobody says it’s enjoyable, nobody would want the job. Other than people who you wouldn’t want to have the job. And, if Matthew Parris— It’s always wary when somebody opens with compliments. Mr. Parris describes my cause, our side’s cause, “I think your cause is a doomed cause.” If it were a doomed cause, ladies and gentlemen, if my cause were a Rosenkranz Foundation-Intelligence Square U.S.- doomed cause, it would mean that our cause as a civilization is a doomed cause. It is I think too early to try to give up like that. Thank you.

### Moderator
Claim: One minute.

### Conspiracy Advocate (CA)
Claim: It wasn’t France, France provided us with a phalanx of lawyers, and a leak. America provided us with 98% of the world—the air power, and they stopped a genocide, that’s no small achievement, ladies and gentlemen, I will—could go through all of the things which Ellen Laipson said, of the problems that you have enforcing, as nobody says that it’s good being the world’s policeman, nobody says it’s enjoyable, nobody would want the job. Other than people who you wouldn’t want to have the job. And, if Matthew Parris— It’s always wary when somebody opens with compliments. Mr. Parris describes my cause, our side’s cause, “I think your cause is a doomed cause.” If it were a doomed cause, ladies and gentlemen, if my cause were a Rosenkranz Foundation-Intelligence Square U.S.- doomed cause, it would mean that our cause as a civilization is a doomed cause. It is I think too early to try to give up like that. Thank you.

### Moderator
Claim: Now, against the resolution, Ian Bremmer.

### Scientific Advocate (SA)
Claim: Good evening. Delighted to be here. Let me first say I fully expected in a couple of minutes when we see the numbers for and against the motion that I’m against the motion, I expect most of you are against the motion. When we vote at the end, I know a lot of you, if it’s really skewed on the side of being against the motion are gonna want to give these guys a couple of votes. It’s kinda like wanting to vote for Huckabee right now. He’s still in the game. And there’s stylishness and you kinda want to give him a little something for being in the game and taking the side. But we all know we can’t get there. And that’s where I am, look, Michael Mandelbaum made very clear that there are only two ways you can agree with me. Number one, you have to believe that the world doesn’t need a global policeman, or number two, that there is a better system out there than having a global policeman. That’s spoken like a true academic.

I agree with both of those things. I think the world does need a Rosenkranz Foundation-Intelligence Square U.S.- global policeman, I think it would be the best system if the US was…the global policeman. But I also think we are incapable, and unprepared to do it. So, I’m trying to be a realist. I’m trying to look at what we can actually do, the limitations of our power, look, I need a loving family, but my mom and dad died of cancer, I’m sorry, I’m not gonna get there. That’s kind of—it’s true, but it’s—I’m not looking for sympathy. My point is, we’re just—or laughter. But we’re, we’re not going to get there. And that’s really the crux of my argument, now, let me make a couple of points here. The first is I fully agree with the notion that the world desperately needs leadership. We are in a situation where global architecture is not catching up to the radical change in geopolitical shift.

The United States doesn’t have the lifting power it used to, China’s growing like crazy. Energy’s increasingly coming from unstable parts of the world. NATO’s ineffectual. Security Council’s ineffectual, the proliferation regime is broken. Don’t even get me started on climate change. Lord knows, you need a leader, to take advantage of this, and to move the system in the direction that we will all be able to live more secure, more prosperous lives. I do believe the United States needs to fill as much of that void as possible, the United States needs to be a global leader. Condi Rice said as much at Davos a couple weeks Rosenkranz Foundation-Intelligence Square U.S.- ago. The Russians strongly disagreed, they said the world does not need a conductor for the orchestra. And then Shimon Peres, the closest to Henry Kissinger on the panel, said, what we really need is a composer. Not a leader.

And I think the world does need a leader. I think a policeman is a very different fact on the ground, look. When we talk about a policeman I think about enforcement, and I think about Max Boots on the ground. I don’t think we have the political will in this country, I don’t think we have the political capital in this country, and I think trying to argue that we do, risks a growth of anti-Americanism abroad. But more importantly and more dangerously, it risks a rise of protectionism in the United States, it risks a rise of neo-isolationism in the United States. Look at the Pew polls, look at how Americans increasingly feel about support for free trade. Look at how they increasingly feel about whether or not they believe America has benefited from the way the world system is evolving, they don’t. Part of the reason they don’t, I suspect, is because folks in the Ninth Ward in New Orleans don’t feel like they’re doing as well as they should. And they don’t necessary like the idea of giving billions of dollars of aid after a tsunami in Indonesia when we can’t build our own homes in New Orleans. I am not suggesting we shouldn’t be giving the billions of dollars in aid, I firmly believe we should.

Rosenkranz Foundation-Intelligence Square U.S.- But I think that taking on the role of global policeman creates far more sentiment in the United States in opposing the world of good the United States does and should continue to do. Let me be specific on a couple of issues. Iran. The United States desperately needs to help reduce the threat of Iran. How might we do that? Effective sanctions? Look at who provides refined product to Iran, from around the world, it’s not the United States. It’s the Europeans, it’s the Indians. You want to be a global policeman on Iran, you better get their support. How about shutting down their accounts, the accounts of the Quds force, um, or of the Revolutionary Guard. Better get support from Dubai. It’s not the United States. The US in a globalized world can’t act as a global policeman, with one of the most important conflicts facing us today.

Lord knows they’d like to try, but unless you’re arguing that this is gonna be the next American military intervention— and there doesn’t seem to be much direct support for that even among the most ardent neoconservatives in the United States—you’ve got a serious problem. How about a place where we can’t even argue about military support, how about North Korea. The United States said, if the North Koreans develop a nuclear weapon, we are gonna be very, very angry. And the North Rosenkranz Foundation-Intelligence Square U.S.- Koreans tested a nuclear weapon, and you know what, the anger in Washington was palpable. But we didn’t do anything, and we went back to the Chinese, and the Chinese said, we told you you don’t have a military options, sanctions aren’t gonna work, now let’s sit down at the table and work with them. The United States said yeah, you’re right, okay, we’ll sit down and we’ll talk to you. At the end of the day, I’d love to be in a position where the Americans could be the global policemen on Iran and North Korea, it would be a better system, it’d be a safer system. But we can’t do it, and the more we try to do it, by ourselves in that role—

—the less—the, the more incapable we’re going to be, okay, two final points since I only have a minute. First point is, what I like in terms of leadership is what Bob Zoellick did, vis-à-vis the Chinese, is talk about stakeholdership, and the Chinese originally didn’t know how to translate that word but once they did they kinda figured it out. We need more responsibility from the actors that are becoming vastly more powerful every day, every year vis-à-vis the United States. We’re increasingly going to be unable to be in favor of this motion, in four years, in eight years, in 12 years, we’d better prepare for it, by getting more Rosenkranz Foundation-Intelligence Square U.S.- stakeholdership, leadership, and dare I say global policemanship, from the folks around the world that can increasingly take some of that lifting regionally.

Final point. Indispensable nation. Madeline Albright came up with that term, actually originally from James Chase, one of my mentors, I fully admit the United States is an indispensable nation. But you know what? If you’re the indispensable part of a family, if you’re the husband, if you’re the father, you do not go out, and buy a house you can’t afford, with a mortgage you can’t service. What you do, is you actually get your apartment, you bring home the bacon, you keep your nose down, and you ensure that you are there in a sustainable way. We need to recognize, that we have to eat within our means. We’ve got a serious problem with that in the American economy, I fear we have a serious problem with that in terms of global security, and I truly hope as a consequence you’ll vote with us against the motion, thank you very much.

### Moderator
Claim: One minute—

### Scientific Advocate (SA)
Claim: —the less—the, the more incapable we’re going to be, okay, two final points since I only have a minute. First point is, what I like in terms of leadership is what Bob Zoellick did, vis-à-vis the Chinese, is talk about stakeholdership, and the Chinese originally didn’t know how to translate that word but once they did they kinda figured it out. We need more responsibility from the actors that are becoming vastly more powerful every day, every year vis-à-vis the United States. We’re increasingly going to be unable to be in favor of this motion, in four years, in eight years, in 12 years, we’d better prepare for it, by getting more Rosenkranz Foundation-Intelligence Square U.S.- stakeholdership, leadership, and dare I say global policemanship, from the folks around the world that can increasingly take some of that lifting regionally.

Final point. Indispensable nation. Madeline Albright came up with that term, actually originally from James Chase, one of my mentors, I fully admit the United States is an indispensable nation. But you know what? If you’re the indispensable part of a family, if you’re the husband, if you’re the father, you do not go out, and buy a house you can’t afford, with a mortgage you can’t service. What you do, is you actually get your apartment, you bring home the bacon, you keep your nose down, and you ensure that you are there in a sustainable way. We need to recognize, that we have to eat within our means. We’ve got a serious problem with that in the American economy, I fear we have a serious problem with that in terms of global security, and I truly hope as a consequence you’ll vote with us against the motion, thank you very much.

## Round 2

### Moderator
Claim: I have a question for each of you gentlemen. Mr. Murray. You talk about Afghanistan and Iraq, two places that have no interest in democracy, no record of human rights. These are…there are tribal wars going on in both countries and certainly in Rosenkranz Foundation-Intelligence Square U.S.- Afghanistan where they managed to resist… How many wars did the British fight in Afghanistan, and ultimately lose? Seven I think. Or six or three or something like that. And the Russians and everyone else who’s poked their nose in there. What on earth can this cop on the beat, this American cop on the beat, do in a place like, either Afghanistan, or in Iraq.

### Conspiracy Advocate (CA)
Claim: Well, I’ll tell you one—

### Moderator
Claim: Other than stay there forever?

### Conspiracy Advocate (CA)
Claim: Sure, well I can tell you one thing it can do and has done straight away which is that Afghanistan is no longer a base where there are open training camps where terrorists can train and come and attack cities like this one we’re sitting in.

### Moderator
Claim: And their heroin—

### Conspiracy Advocate (CA)
Claim: And that’s—I don’t think, I don’t think that’s a small achievement.

### Moderator
Claim: And the heroin business is booming.

### Conspiracy Advocate (CA)
Claim: I think that’s a different question—

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- So which—what does—well, the cop’s out there, what’s he doing?

### Conspiracy Advocate (CA)
Claim: Well, hang on, if you let me finish. Or—I thought it was one question. Look, as I said it’s no small thing to get the first thing done, the thing that was originally why America and her allies went into Afghanistan which was to take out flagrant training camps of terrorists, and that job has been done. Now it seems to me that the job of sorting out the Afghan economy is a separate one, one which the world community generally is involved in, but I think that’s a different point. I don’t know if you wanted to try to make me an apologist for the American administration or a spokesperson for them but I’m not.

### Moderator
Claim: Well, you’re—

### Conspiracy Advocate (CA)
Claim: My own, my own view for what it’s worth on it is that the job of creating a viable, booming economy in Afghanistan is a quite different one, now this particular policeman went in and sorted out the problem. It doesn’t also have to be the Social Services Department.

### Moderator
Claim: Ian Bremmer— Rosenkranz Foundation-Intelligence Square U.S.-

### Conspiracy Advocate (CA)
Claim: Thank you—

### Moderator
Claim: —you talk about a leader…a fuehrer, out there, someone who’s going to, you know, some big pie in the sky who is going to suddenly have the world bowing down and saying, we want to follow you, leader, whoever that may be. I mean, this is wonderfully kind of anti-Orwellian… stuff you’re saying, but, what leader? What single leader is the world gonna follow? America can’t follow a single leader.

### Scientific Advocate (SA)
Claim: Well, historically that’s certainly true, America can’t follow a single leader but in terms of values and regimes, when we talk about for example free trade, the fact is we have an international system that the United States has been at the forefront of and has been pushing until some trends very recently, has been pushing a very strong agenda in free trade where it’s been seen as the global leader as a consequence and, whether we’re talking about, you know, sort of international norms and regimes or whether we’re talking about regional bilateral ones that’s been an extremely important process. The WTO, the World Trade Organization, the United States has played a leadership role, the US as the world’s largest economy, has helped to smooth and create many, many efficiencies.

Rosenkranz Foundation-Intelligence Square U.S.- If you want to talk about, um, what happened after the Soviet Union, uh, collapsed, if you want to talk about the efforts to denuclearize places like Belarus and Kazakhstan and Ukraine, the US took a leadership role, that clearly made the world a more safe place. That’s very different from talking about being the world’s policeman, I think that there are a lot of countries that do criticize when the US doesn’t take a leadership role. Look at the tsunami in Indonesia. The Chinese put $4 million on the ground, about a week afterwards. The United States got the Japanese, the Indians, and the Australians together, billions of dollars, in this case, boots on the ground from adding— for providing humanitarian assistance, and actually made a serious difference. The United States is clearly indispensable in these roles as a leader, but I would not say that the US has the capacity to be the global policeman.

### Moderator
Claim: Okay. I am now ready to announce the results of the pre—

### Conspiracy Advocate (CA)
Claim: Do Matthew Parris and I not get the questions, have we so intimidated you that you’re not gonna ask us questions?

### Moderator
Claim: Well, they’ve given me four questions to ask and we’ve, they’ve— Rosenkranz Foundation-Intelligence Square U.S.- I’m sorry.

### Conspiracy Advocate (CA)
Claim: Well, congratulations—

### Moderator
Claim: You’ll get your chance, you will get your chance, I promise you. More or less. Anyway… I’m now ready to announce the results of the pre-debate vote. Before the debate you voted…24% for the resolution, 44% against, and a huge 32% undecided. You’ll get a chance to vote again. Now to begin the discussion portion of the evening, I’d like to ask each of our panelists to pose a question to the opposing side. Max Boot—

### Conspiracy Advocate (CA)
Claim: Well, I’d like to ask a question of Matthew Parris and I am tempted to ask if you know what the words “ad hominem” mean but I will refrain from asking that—

### Scientific Advocate (SA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Instead I would like to ask about your fascinating claim that you have great knowledge and power to intuit the feelings of the American people which is denied to those of us who actually live here. And I would like to ask you, therefore, why you claim that the American people will not support this role of Rosenkranz Foundation-Intelligence Square U.S.- global policeman if in fact they have supported American troops being stationed in East Asia and Europe for over 60 years and why you think that Republican and conservative voters in particular, do not support an interventionist role for the United States when they consistently back Presidents and Presidential candidates such as Ronald Reagan, George H.W. Bush, George W. Bush—

### Conspiracy Advocate (CA)
Claim: —and John McCain who are in fact leading advocates of intervention—

### Moderator
Claim: I must remind the panelists that these are questions, not speeches. So—

### Conspiracy Advocate (CA)
Claim: Well—

### Moderator
Claim: —please keep the question brief, and then Matthew Parris—

### Conspiracy Advocate (CA)
Claim: There was a question mark at the end—

### Moderator
Claim: —please keep your answer brief.

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Square U.S.- Well of course I know a great deal less of the American people than almost everybody else on the panel, I only have the hunches that I get from those whom I know and the time that I spent there. And also a little bit that I know about the history of the British empire and British colonialism and much of which I’ve lived in my own childhood, and, my impression, and I may be wrong, is that the—there’s a good patriotic spirit in America for invasions of foreign countries where those invasions can be seen as palpably in the national interest in order to defend America from people abroad. But that there isn’t the same interest in administering other countries, there isn’t the same interest in prolonged occupations of other countries, there isn’t the same interest in doing what policemen do abroad, and that it’s only as long as America is winning in those circumstances that public opinion remains positive, it quite quickly turns against, when conditions seem to be coming adverse.

### Moderator
Claim: Ellen Laipson, who do you have a question for.

### Scientific Advocate (SA)
Claim: I’d like to ask Michael Mandelbaum to tell us how he would get to the end state that he desires, of the US as the world’s policeman, what would you do, you spoke very disparagingly of the UN. What would you do with the 17 current peace missions that the Rosenkranz Foundation-Intelligence Square U.S.- United States has supported, by its vote authorizing them in the Security Council, the 100,000 soldiers and policemen that are deployed worldwide in these trouble spots. Is your view that those operations should simply shut down and go away?

### Conspiracy Advocate (CA)
Claim: Not at all, I’m delighted with them, I think we should have more of them, I think the United States should support them, but they add up to only a small fraction of the policing that’s necessary in the world. In fact, I claim that the United States does police the world and does do so effectively and let me give you three examples. In East Asia, contrary to what Mr. Bremmer said, the United States does a very effective job of containing although not preventing the acquisition of nuclear weapons by North Korea, with the Seventh Fleet, with its security treaties with Japan and South Korea, without them, East Asia would be a much more dangerous place. Similarly, in the Persian Gulf, although the United States has not dealt with complete success with Iran, our military presence over the horizon and our naval presence assures the free flow of petroleum which is a global necessity. A policeman walks the beat. The United States does that in the Persian Gulf and in East Asia, it’s extremely important that it do so. To the extent that other countries can chip in, all the better. But they just don’t do enough, and I don’t have any expectation that they will.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- Michael Mandelbaum, who do you have a question for.

### Conspiracy Advocate (CA)
Claim: Well, I’d like to make a comment—

### Moderator
Claim: No, no, it’s question time, not opinion.

### Conspiracy Advocate (CA)
Claim: Well then I’ll—I’ll turn it into a question.

### Moderator
Claim: And who—

### Conspiracy Advocate (CA)
Claim: Mr. Parris gave, I would say a rather broad view of American anti- imperialism but not altogether inaccurate so let me give a reply in a similar spirit and it follows onto what Ellen Laipson said and my response. I would say in response to you comment about American opposition to the British empire—

### Moderator
Claim: Question, in question, sir.

### Conspiracy Advocate (CA)
Claim: It’s a question. We thought— We thought we could do it better than you did. But we were wrong. Come back. We would be delighted for the British to do more by way of global policing, so will you, as an influential member of the political class in Britain, commit to agitating in favor of the Royal Navy Rosenkranz Foundation-Intelligence Square U.S.- growing larger rather than smaller so that it can resume the policing of the Atlantic and the Mediterranean that it did so well and so necessarily and with such great benefit to everyone, including that large free-rider across the Atlantic, the United States, in the 19th century.

### Scientific Advocate (SA)
Claim: Well, I’ll I’ll reciprocate your humility. You suggest that you or the Americans have learnt that imperialism, indeed British imperialism was a better thing than you thought it was at the time. I would say that we British have learnt that imperialism was not as good a thing as we thought that it was, at the time, but there is a limit to the extent that a country that has no economic global predominance can continue to police large sections of the globe. We learnt that, to our very great cost, it’s a lesson that we’ve learnt and I think we’re not going to un-learn it and if we have any advice for you it is not to repeat the mistake.

### Moderator
Claim: Matthew Parris, do you have a question for someone here.

### Scientific Advocate (SA)
Claim: Yes. I’d—again, it’s to Mr. Mandelbaum. It’s a serious question, I— rather than a—an ad hominem one, I’d like you to…I’d like you to deal with the question of legitimacy with policemen, a policeman in New York works for an authority that is elected, enforces laws which have been enacted by people who have been Rosenkranz Foundation-Intelligence Square U.S.- elected and is in many ways of the community that he polices. America as world policemen would be a very different kind of animal. There would be no such presumed consent, there’s a real problem—

### Moderator
Claim: Question—

### Scientific Advocate (SA)
Claim: —about legitimacy—

### Moderator
Claim: —question, please, sir—

### Scientific Advocate (SA)
Claim: —about authority, and I wonder how you answer that problem.

### Conspiracy Advocate (CA)
Claim: I answer it as follows. The United States as the global policeman is not as legitimate as the New York City police force is. And it cannot be because there is no global government, no global state to give it legitimacy. But it has enough legitimacy, because nobody opposes it, as they would if they didn’t like it and felt threatened by it. Indeed, as I say in my, my book The Case for Goliath, I think there is a threat, there is a threat to the American role as the world’s governments, but it doesn’t come from other countries. It comes from the mounting costs of social welfare, of our entitlement programs, the great threat to the American role as the world’s policeman and to global order Rosenkranz Foundation-Intelligence Square U.S.- comes not from China—pace Mr. Bremmer—it comes from Medicare.

### Moderator
Claim: Mr. Murray…

### Conspiracy Advocate (CA)
Claim: Gosh, I don’t have any lack of questions for the other side, but the one I’d most like to ask is Ian Bremmer, who mentioned, I just pricked up about the Pew polls, about what people across the globe think of America. And aside from the vaguely unpleasant sight of anyone caring that much about how much they’re liked I wonder if you’ve seen the Pew polls about suicide bombing—people who are in favor of suicide bombing as a tactic, across the Arab and Muslim world, particularly, legitimizing vast percentages the murder of Israelis. And whether you’ve seen the Pew polls that show the number of people across the Middle East and elsewhere, the huge numbers of people who think that for instance 9-11 was a conspiracy, forced on the American people by their own government, by Mossad and all this sort of thing. Based on all this, do you think that this is all America’s fault, or do you think other people have agency and the ability to cock up.

### Scientific Advocate (SA)
Claim: No, I certainly don’t think this is all America’s fault. I think I’ve Rosenkranz Foundation-Intelligence Square U.S.- pretty much said I’d like the idea of the United States being the world’s policeman, we just can’t get there, it’s generally a kinda country I’d probably enjoy, again I’d like the idea of having a private plane but it’s not happening tomorrow. You know, I would say that you’re referring to the wrong Pew polls. In terms of my comment, it wasn’t on how much countries like America. It was about how much Americans actually support globalization, how much they support free trade. And also how much they believe that the United States benefits from growing foreign companies, companies in emerging markets and the rest. And they compared those views on free trade, with the views of other foreign nationals in countries like Russia, China and India. And, for—in a dramatic shift of fortunes, Americans have proven to be less pro-globalization, less pro-free trade than the Russians, the Chinese, and the Indians, and that shows something very disturbing, in my view, which is that increasingly the average American does not believe that they benefit from the trajectory that the world is moving towards. And that not only speaks against growing opposition to the United States serving as the world’s policeman, but it also speaks against the United States serving the role as, as a leader on key issues where international leadership is lacking, and I really fear that we will throw the baby out with the bathwater on this one.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- Ian Bremmer, do you have a question.

### Scientific Advocate (SA)
Claim: Yes I do, and I would ask it to Michael but he’s already gotten two so I’m gonna ask either Max or Douglas if they—if they want to take it. It is, that—it follows on this issue of legitimacy and the notion that all countries around the world kind of like the idea of the US as a policeman. And I’m wondering, what do we do in those big issues where it’s clear that they don’t. You know, what do we do about Russia, where clearly, whether we’re talking about Chechnya, or Georgia, or Ukraine, the Orange Revolution and the rest, the Russians really assertively don’t want the United States to be a policeman. What do we do in a place like Taiwan, where the Chinese really assertively—and increasingly have the power to stop the US—don’t want the US to act as global policeman, how do we— and I’m asking, actually out of legitimate curiosity, how do we deal with those sorts of challenges.

### Conspiracy Advocate (CA)
Claim: I guess I would reply that’s a little bit like asking well what do we do about the fact that John Gotti doesn’t like the NYPD in his neighborhood. Well, you have to deal with those issues, and sometimes you have to deal with them diplomatically and obviously nobody’s suggesting that we start a war with Russia or Rosenkranz Foundation-Intelligence Square U.S.- China because we dislike some of their behavior. But, you—the problem with the position that your side takes which is multilateralism is that basically, you hold us hostage to the views of a Russia or China, you basically say, we cannot act by leading a coalition of the willing, we cannot act with our posse, we have to wait for some multilateral institution before we can do something and of course, Russia and China have vetoes in the most powerful multilateral institution that exists and they use their vetoes to shield wrongdoers such as Iran developing nuclear weapons, or to try to prevent us from intervening for example in Kosovo to stop the genocide. So if you pay too much heed to the opinions of countries like Russia or China or other dictatorships which don’t have the best interests, our best interests at heart or the world’s best interests at heart, basically you allow the world’s worst criminals free rein. And that’s something I don’t think we can afford to, to let happen.

### Moderator
Claim: I’d like to open the Q-and-A up to the audience now. Please stand when you ask your questions, and I ask that you do not start to ask the question until you have the microphone, one will get to you. And please, please make the question short and to the point. And if you’re a member of the press here, please identify yourself. Any questions?

Rosenkranz Foundation-Intelligence Square U.S.-

### Moderator
Claim: I—over here. I have one, over here. I have a question for Mr. Bremmer. You adduce a nuclear North Korea as an example of a failed…police work, is that—is that the case?

### Scientific Advocate (SA)
Claim: Inability of the United States to act—not failed police work, just the US doesn’t have the capacity to act as a policeman in the case of North Korea, yes.

### Moderator
Claim: My understanding is that Madeline Albright went over, Jimmy Carter went over, flattered Kim Jong-il…then he went nuclear. If you’re aware of some other…non-diplomatic means that were employed and failed, would you please share them with us.

### Scientific Advocate (SA)
Claim: Look, I mean, I’m not trying to argue, I think Morley raised the same point in a question to Ellen which is that, oh well, engagement clearly doesn’t work with Iran because the Iranians don’t want to be engaged—I’m with you. The Iranians don’t want to be engaged, they’re moving, they’re going nuclear. The North Koreans didn’t want to be engaged, I mean criminy, they don’t want pro-globalization, you throw CNN in North Korea, you know, probably Kim Jong-il falls relatively quickly, they want to keep the place isolated, they want to build their nukes, they want to buy people off, they want to blackmail, they want to sell drugs, Rosenkranz Foundation-Intelligence Square U.S.- they want to sell ballistic missiles, they want to engage in human trade. This is a nasty, brutish and quite short regime. I don’t expect that any of the United States’ policies were likely to work, my point was, the Chinese have more leverage over North Korea than the United States does, there was no military option, you attack North Korea to try to stop them, South Korea’s devastated within 36 hours because of artillery if you look at geography. So that wasn’t an option. Even the most ardent opponents in the Defense Department weren’t trying to go there. So given the fact that you don’t like the regime, given you don’t want them to develop the nukes, you want to stop them, the United States has to think about who has the power, and it’s not just the US, you gotta go to the Chinese, who actually are providing these guys with the lifeline economically, and say we need to work with you. That’s not the US acting as a global policeman, that’s America in a more multilateral role trying to cajole relatively incalcitrant countries, recalcitrant countries to do their best.

### Moderator
Claim: Other questions?

### Moderator
Claim: I think one of the key questions has been avoided. And this only was personally alluded by Mr. Parris. And the, the question is, how do you be the policeman if you don’t longer have predominance. The key and imperative word is “predominance.” Rosenkranz Foundation-Intelligence Square U.S.- Like the English empire, lo— lost its role as master of the world when it lost economic predominance after the First World War, the United States no longer has the predominance it ought to have to be the policeman. So the question is what can we—be done, without the predominance.

### Moderator
Claim: You want to take that…

### Conspiracy Advocate (CA)
Claim: Ah.

### Moderator
Claim: —Michael Mandelbaum?

### Conspiracy Advocate (CA)
Claim: The United States can continue to act as the world’s policeman as long as serious countries do not actively oppose it. And that means that since there is no longer a Cold War, it is in many ways cheaper for the United States to carry out the legitimate police functions in the world that it does carry out. And it carries them out, with the sufferance, with the tacit agreement of major countries, including Russia and China, that disagree with the United States on some important issues, but still value the American role at least to the extent that they do not oppose it.

### Conspiracy Advocate (CA)
Claim: Can I also add to that? There’s a confusion going on at the moment here, between policing and being an imperial power.

Rosenkranz Foundation-Intelligence Square U.S.- Which is going to I think, cause a problem on the voting at least for this side. Which is why I mention it, being a world policeman in the definition that we’re going on at the moment is quite different from being a world authoritarian. And to go back to Ellen Laipson’s definitions when she said that, the definition of policing would be enforcing the rules, setting the rules and having a monopoly on the use of force— America does enforce the rules, they tend not to be ones set by themselves, they tend to be set by all sorts of other organizations and nations in history. And America certainly doesn’t have monopoly on the use of force as for instance the intervention in Sierra Leone by my own country would demonstrate. But I would just tidy that up, just because you—we’re saying on this side that, that we would like America to be the world’s policeman does not mean we’re suggesting that it is like the British Empire was, or that it’s like any other empire, I don’t think it is an empire, being a policeman’s quite different.

### Moderator
Claim: There are a lot of nasty conflicts in the world at any given time, so this is a question for those who support the motion. What’s the criteria… for the, the United States to intervene as policemen, would that include Kenya today, would that include, Mozambique, would that include Darfur, would that include Rwanda in the early ‘90s…

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- Excellent question, who wants to field it.

### Conspiracy Advocate (CA)
Claim: Well, I don’t think that you can come up with any hard and fast criteria, I think a lot of what you do has to be really based on a realistic assessment of your capabilities at the moment, and nobody suggests that for example, that, if you have…if you saw murders occurring in New York City that therefore, the New York Police Department is a complete failure. Obviously there are going to be crimes occurring in the world. We cannot stop all of them, it’s beyond our means, everybody will admit that. But I think we have to do what we can. And I think—I’m with Bill Clinton when he said that it was a mistake not to have intervened in Rwanda, not to have stopped a genocide that it was in our power to stop, I think, it was correct that we did intervene in Bosnia and Kosovo and we stopped terrible bloodletting in the Balkans. Today obviously our forces are engaged in Afghanistan and Iraq and we don’t have the capability to intervene as many including me would like in places like Darfur. And that’s a sad, tragic reality, which means that hundreds of thousands of people are dying. But of course, even if we don’t have the capability to lead an intervention with massive use of force we can do other things such as using our global leadership role to push economic sanctions, or to provide enablers that might allow others to Rosenkranz Foundation-Intelligence Square U.S.- intervene, but unfortunately for all the talk from the other side, about how there are so many others out there willing to play this global policing role, we find time and time again, there’s been very few cases of anybody willing to step forward where the United States does not lead and, I’m in favor of American leadership while recognizing the limits of our power and the fact that we cannot possibly intervene in every case, I think we should try to do as much good as possible within the bounds of our power.

### Scientific Advocate (SA)
Claim: There was—if I can just put in quickly, there’s a good quote here from Mr. Blair, our former premier in Britain. When--I mean I think on the important point to make which is that just because you can’t intervene everywhere doesn’t mean you don’t intervene anywhere. And before the Iraq war Mr. Blair was asked by a journalistnwhy he was going for this particular conflict and he said, it’s a very important phrase and I absolutely agree with it, he said people—I get fed up when people say to me why not the Burmese lot, why not Mugabe. He said, I don’t, because I can’t. But when you can, you should.

### Moderator
Claim: We have time for two more questions, brief ones, please.

### Moderator
Claim: Question is for the proponents of the motion. Given the fact that Rosenkranz Foundation-Intelligence Square U.S.- Medicare and Social Security, and other elements in our safety net are gonna be with us for a while would any of you advocate the institution of a military draft, to provide the power that would be necessary to be the world policeman on a scale that would fit the needs of the problems that are going to arise in the foreseeable future.

### Conspiracy Advocate (CA)
Claim: I don’t think a draft would solve the problem. And of course the military doesn’t want a draft, and the United States carries out its policing role without a huge mass army of the kind that great powers fielded until the last third of the 20th Century. But I do agree, and I did say, that this is a substantial problem and does present a threat to American foreign policy. And if it results in the curtailing of the global services that include providing a global police force, the whole world, including those who most harshly criticize American foreign policy, will be sorry.

### Conspiracy Advocate (CA)
Claim: Can I just jump in and just make one point? Because I think in your question and some of the others I kind of scent this notion of American declinism in the air. And the fact that we’re…Woe is us. We’re over-stretched. We can’t do everything that we want to do. And I think you should be aware of just how vast our power is. The fact is that we spend more than the rest of the world, or as much as the rest of the world combined, on defense. And Rosenkranz Foundation-Intelligence Square U.S.- we’re still spending only four per cent of our GDP, which is several percentage points less than we were spending during the Cold War. We still have the world’s largest and richest economy. We’ve been creating jobs at a pace that out-clips any other industrialized economy over the last twenty or thirty years. Our population size is growing. We’re already the third largest country by population in the world. And we’re projected to increase by another hundred and fifty million over the course of the next fifty years. There are vast pools of power and resources in the United States that can be mobilized for the task that we have to undertake. And in fact, we have mobilized them in essentially policing the world over the last sixty years. It is a very doable mission.

### Moderator
Claim: One more question. And please, a brief one and direct it to one of the panelists.

### Moderator
Claim: I have a question over here. Actually, unfortunately, it’s a very general question, which is I’m getting more and more confused as this discussion goes on what the difference is between policing the world and actually using the military to go to war. And the two seem to be discussed along with each other. And I think they’re very different issues. So I don’t know if anyone wants to take it.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- Who, who is that question directed to? Which side?

### Moderator
Claim: I’ll take it for the motion.

### Conspiracy Advocate (CA)
Claim: You’ve answered it. You’ve already answered the question. Why don’t you answer it again?

### Conspiracy Advocate (CA)
Claim: Yeah, I mean, just to get back to this point is that, I think that I can speak for people on this side and just say that again, that the policing issue, it doesn’t – First of all, it does not have to be prime…only military. And I think that’s my, that’s fairly obvious. And even a member of the other side conceded, America’s role in operations like the post-tsunami operations a couple of years ago. And I think that, as I say, this should be cleared up before you vote – that the issue – and I think I mentioned it in my comments earlier, that the issue of, for instance, sustaining an operation, remaining in a country and all these sort of things, is not what we are talking about as policing. That policing operations are not welfare operations, as I mentioned earlier, but are also not imperialist operations. They’re not even operations which, people might think of sustaining for the long term.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Square U.S.- If I could just, could I just--

## Round 3

### Moderator
Claim: No, we will in a moment. We are going to wind this up. Each of the debaters has two minutes and I will give you a one minute warning. And we will start with the team against the motion, Ellen Laipson, please.

### Scientific Advocate (SA)
Claim: Thanks, Morley. I admire the optimism of the other side, that America’s power remains preeminent and will continue to be in – and they have been somewhat selective in their metrics or their use of factual information. I do think that we have some serious questions about the capacity to spread our military and civilian forces thinner around the world. One only needs to listen to military commanders’ concerns about recruitment, retention, the cost of medical care to our soldiers, et cetera, to realize that, you know, there are limits to our ability to serve this function. And I think there is both an ethical and a political argument of why not share it with others? I’ve heard the other side say, Oh, we’re, we like allies. Allies are fine. But they still believe that the essential decision making authority of deciding when to act –

### Moderator
Claim: One minute.

### Scientific Advocate (SA)
Claim: …and where to act, is, resides in the United States. And I just Rosenkranz Foundation-Intelligence Square U.S.- don’t think that’s the way the world works anymore. I really do believe that while the United States remains a country of exceptional wealth, talent, et cetera – and I deeply hope we remain so indefinitely-- we should be aware of a redistribution of talent, capacity in the international system. And we should embrace this and turn it into a virtue. We should not be afraid of it. We should not be threatened by it. And we should not think that that United States alone has a monopoly on wisdom about how to respond to the world’s trouble spots. And for me one of the strongest arguments of this discussion tonight has been legitimacy. Michael conceded that we would have less legitimacy than the New York police, but that other countries so far haven’t pushed back. I think that’s not a permanent state of affairs and I think that we should be looking for, in – if we believe truly in democratic values, and I know we do – legitimacy should matter a lot. We should care more what other countries think and what their preferences are for finding the best solution to the world’s policemen. Thank you.

Thanks, Morley. I admire the optimism of the other side, that America’s power remains preeminent and will continue to be in – and they have been somewhat selective in their metrics or their use of factual information. I do think that we have some serious questions about the capacity to spread our military and civilian forces thinner around the world. One only needs to listen to military commanders’ concerns about recruitment, retention, the cost of medical care to our soldiers, et cetera, to realize that, you know, there are limits to our ability to serve this function. And I think there is both an ethical and a political argument of why not share it with others? I’ve heard the other side say, Oh, we’re, we like allies. Allies are fine. But they still believe that the essential decision making authority of deciding when to act –

### Moderator
Claim: Max Boot, you’re next.

### Conspiracy Advocate (CA)
Claim: Well, I’d like to begin by addressing the question that was just asked because I think it’s an important point. And by no means do those of us on this side advocate waging perpetual war. In Rosenkranz Foundation-Intelligence Square U.S.- fact, what I believe is that if America takes seriously its global policing responsibilities that makes war less likely, not more likely. When you think simply about what an urban police force does, for example – cops on the beat walk the beat. They don’t fire their guns very often. And the more they’re out there, the more they have a presence the more they deter crime and the less, uh, likely it is that criminals will prey on innocent people.

And they can have their greatest effect simply with the same kind of, uh, street corner presence that we expect here in New York City. And that’s essentially what the United States has been doing around the world for more than sixty years, where our navy keeps the Straits of Hormuz open. They patrol the world’s ocean to prevent pirates or other predators from disrupting the flow of global commerce.

### Moderator
Claim: One minute.

### Conspiracy Advocate (CA)
Claim: Our troops are stationed in countries like Japan and South Korea and Germany and elsewhere to prevent conflict, to deter conflict from occurring. And all you have to do to realize why this is a good thing is just to imagine the consequences of a world without American leadership. I mean, imagine arms races spiraling out of control in East Asia and Europe. Imagine Iran Rosenkranz Foundation-Intelligence Square U.S.- closing the Straits of Hormuz. Imagine chaos and civil war spilling over the borders of Iraq and Afghanistan into neighboring states. Imagine terrorists getting their hands on nuclear weapons. Now, you may think I’m being melodramatic but, in fact, I think history shows the dire consequences of America abdicating its global policing role. And if even ten percent or a third of the things that I’m talking about are likely to happen if we give up this policing function, it’s an unacceptable risk. And we can afford the, the, uh, global policing function which we have performed. It is not bankrupting our country. It is a very small share of our public purse.

Well, I’d like to begin by addressing the question that was just asked because I think it’s an important point. And by no means do those of us on this side advocate waging perpetual war. In Rosenkranz Foundation-Intelligence Square U.S.- fact, what I believe is that if America takes seriously its global policing responsibilities that makes war less likely, not more likely. When you think simply about what an urban police force does, for example – cops on the beat walk the beat. They don’t fire their guns very often. And the more they’re out there, the more they have a presence the more they deter crime and the less, uh, likely it is that criminals will prey on innocent people.

And they can have their greatest effect simply with the same kind of, uh, street corner presence that we expect here in New York City. And that’s essentially what the United States has been doing around the world for more than sixty years, where our navy keeps the Straits of Hormuz open. They patrol the world’s ocean to prevent pirates or other predators from disrupting the flow of global commerce.

### Moderator
Claim: You must wrap it up.

### Conspiracy Advocate (CA)
Claim: We have to continue in order to prevent the very wars that all of us decry.

### Moderator
Claim: Matthew Parris.

### Scientific Advocate (SA)
Claim: Well, I’m becoming more and more confused listening to Max Boot as to whether the United States can or can’t afford this role. In one breath he says they can and then challenged over Africa, he says they can’t. That quote from Tony Blair that Douglas Murray gave us was thoroughly disingenuous. I don’t because I Rosenkranz Foundation-Intelligence Square U.S.- can’t. Britain is perfectly capable of toppling Mugabe’s regime in Zimbabwe. The United States is perfectly capable of instigating free and fair elections in Kenya. Britain and the United States together could do something about Darfur. They don’t and the reason that they don’t, I believe, is that there is no coherent view on the part of the allies as to what the role of world’s policeman would be or where the world’s policeman would police. And I believe that one of the reasons there’s no coherent view is American democracy. I don’t think the American people are really into this kind of thing. I don’t think the American people really want this role. If they did there would have been much more discussion as to how it should be imposed. Secondly, multilateralism.

### Moderator
Claim: One minute.

### Scientific Advocate (SA)
Claim: Are they in favor of it or are they against it on the other side? Max Boot seemed to speak very disparagingly about multilateralism. Mr. Mandelbaum spoke about the feebleness of the United Nations. One of the reasons for the feebleness of the United Nations is that countries like America, and to some extent Britain, have not entirely supported the United Nations. There’s lots of things wrong with the United Nations. But one of them is there is no feeling that the United States any longer really wants Rosenkranz Foundation-Intelligence Square U.S.- to make the United Nations a driving multilateral force. Douglas, Murray spoke about police not policing, not really meaning the assertion of force. He seemed to call up a vision of an American world policeman as a kind of world marriage guidance counselor or world social worker or world priest or, uh--

Well, I’m becoming more and more confused listening to Max Boot as to whether the United States can or can’t afford this role. In one breath he says they can and then challenged over Africa, he says they can’t. That quote from Tony Blair that Douglas Murray gave us was thoroughly disingenuous. I don’t because I Rosenkranz Foundation-Intelligence Square U.S.- can’t. Britain is perfectly capable of toppling Mugabe’s regime in Zimbabwe. The United States is perfectly capable of instigating free and fair elections in Kenya. Britain and the United States together could do something about Darfur. They don’t and the reason that they don’t, I believe, is that there is no coherent view on the part of the allies as to what the role of world’s policeman would be or where the world’s policeman would police. And I believe that one of the reasons there’s no coherent view is American democracy. I don’t think the American people are really into this kind of thing. I don’t think the American people really want this role. If they did there would have been much more discussion as to how it should be imposed. Secondly, multilateralism.

### Moderator
Claim: I must ask, I must ask you to wrap it up.

### Scientific Advocate (SA)
Claim: …or Rabbi. I will wrap up. America has two great weapons. One is force and the other is persuasion, the power of moral persuasion. They are not complementary. The more force is used the more the power of moral persuasion will be undermined. And I would urge you to oppose the motion and to support the idea of moral persuasion and not the use of force.

### Moderator
Claim: Michael Mandelbaum.

### Conspiracy Advocate (CA)
Claim: Some people in New York – possibly including some people in this room – are unhappy. The New York Police Department can’t help you. Morley Safer noted that despite the presence of NATO forces – and incidentally, if you want to see just what America’s allies are willing to do in a cause with which they agree, check out their performance in Afghanistan. It’s pretty pathetic. Despite, Morley Safer has Rosenkranz Foundation-Intelligence Square U.S.- noted that drugs are still traded. They’re still traded in New York, within a few blocks of here. That’s not an argument against New York having a police force. And what is true of New York is true of the world as well. The fact that the United States cannot bring Chechnya to a successful resolution is not an argument against the United States acting as the world’s police force.

The job of a police force in the world, as in New York, is not to make things perfect. It’s to keep things from becoming worse. And that the United States does in the world in two important ways – by its military deployments and alliances that undergird globalization and by leading the effort against nuclear proliferation and deterring rogue states if and when they get nuclear weapons. Those are important global tasks. They are the tasks of global policing. Other countries and other organizations have shown no inclination to do them. Therefore it is in everybody’s interest that the United States continue to do so. That is why you should support this motion.

### Moderator
Claim: Ian Bremmer.

### Scientific Advocate (SA)
Claim: You’ve brought up a number of times the notion that nobody else wants to be the global policeman so the United States has to step up for the job. I agree. Nobody else wants to be the world’s Rosenkranz Foundation-Intelligence Square U.S.- policeman. Lots of people want to be their own region’s and their own neighborhood’s policeman. Some of them, thankfully, are incapable, like Venezuela. Some of them are increasingly capable, like China in Asia and like Russia in Eurasia. And the United States has to recognize that. They have to recognize that the extraordinary shift in importance of alliances and the importance in the battles of the hearts and minds, not of the individual people in these countries, but of the leaders that have to support this policing role to provide legitimacy is not only assured by the world’s largest military but also by the world’s largest trade flows. But –

### Moderator
Claim: One…

### Scientific Advocate (SA)
Claim: …but also by the influence in these countries. And we’re seeing that in terms of China’s extraordinary influence in Latin America, which is growing by the second, in Africa, by Russia and Eurasia and the rest. The United States is going to have to learn to live with this. Look, it’s true that a lot of Americans aren’t happy. They’re unhappy because of subprime. They’re unhappy because of recession. They’re unhappy because of energy and security. They’re unhappy because of Iraq. And increasingly they’re unhappy because the bailout that’s coming isn’t like the U.S. government with the S&L crisis. The bailout Rosenkranz Foundation-Intelligence Square U.S.- that’s happening with the big blue chips right now is coming from China and the Gulf and the rest. We don’t want to throw the baby out with the bath water. We don’t want Americans that are increasingly insecure to say the U.S. shouldn’t play a leadership role. Look, every debate needs a theme. For me this theme is that the great should never be the enemy of the good. Okay, now I’m an American and I’d love to have the great. But I tell you, I’d take what I can get.

You’ve brought up a number of times the notion that nobody else wants to be the global policeman so the United States has to step up for the job. I agree. Nobody else wants to be the world’s Rosenkranz Foundation-Intelligence Square U.S.- policeman. Lots of people want to be their own region’s and their own neighborhood’s policeman. Some of them, thankfully, are incapable, like Venezuela. Some of them are increasingly capable, like China in Asia and like Russia in Eurasia. And the United States has to recognize that. They have to recognize that the extraordinary shift in importance of alliances and the importance in the battles of the hearts and minds, not of the individual people in these countries, but of the leaders that have to support this policing role to provide legitimacy is not only assured by the world’s largest military but also by the world’s largest trade flows. But –

### Moderator
Claim: Douglas Murray.

### Conspiracy Advocate (CA)
Claim: Thank you. I’d like to start off by mentioning something Ellen Laipson said that she said some time earlier, that the rest of the world is providing the actual police. And one of the reasons why that may be the case is because you as a nation are the ones that are doing the heavy lifting. It’s not hard for Canada or somebody to not be able to provide troops, but to be able to provide policemen. It’s not hard for Germany to send legions of people to Afghanistan who won’t fire a gun. You can find those people.

Who are you going to call? This is the question that we should have in our minds. When something goes wrong, when a tsunami occurs, when a massive humanitarian catastrophe like that, when a rogue state emerges, when a failed state becomes an Rosenkranz Foundation-Intelligence Square U.S.- even more failed state or a successful one starts to fail who are you going to call? Is it going to be another nation state? Or is it going to be the U.N.? Matthew Parris mentioned the U.N. The idea of the U.N. policing the world is like saying that you just pick a cross section of every household in New York and say that that house will do the policing and that one and that one. In other words, an entirely random process which will mean you’ll get a certain amount of people who are fine but you won’t get the driven people. You won’t get the people who are prepared to do the job, who are trained to do the job, who are financed to do the job.

You’ll get some people who can do it accidentally. You’ll also get some bums and some lazy guys and some guys who are just wicked and others. And that’s what the U.N. is composed of, is a whole group of people who you would give more legitimacy for the simple fact that they’re there? And you know, this comes back to this issue I raised earlier about America wanting to be liked. You can police the world, you can be the world’s policeman. You should not be, it looks extremely bad to look like you’re desperately wanting to be loved by the rest of the world as well. You will be blamed when you’re the world’s most powerful nation. You will be blamed when you intervene and you will be blamed when you don’t. You will just have to put up with that. And Rosenkranz Foundation-Intelligence Square U.S.- when the other side says that the great should not be the enemy of the good, I don’t think anyone on this side would be or has implied that it would be. But the great should certainly be the enemy of the bad.

### Moderator
Claim: Wrap it up. Well done. It’s now time for you to decide who carried the day or the night here. Once again, please pick up your keypads and after my prompt, I want you to press one if you’re for the motion, America should be the world’s policeman; two if you’re against the motion or three if you are undecided. And please cast your votes now. I want to thank the debaters, both sides. I thought they were really extraordinarily on their toes tonight. And the audience for, first of all, for coming out in this weather and secondly, for your really excellent, excellent questions. And I also want to thank you for not heckling the side you didn’t like. Before I announce the results of the audience vote I want to take care of a couple of things. The next Intelligence Squared U.S. debate will be on Tuesday, March 11th here at Asia Society Museum. The motion to be debated – this is a good one, too, the motion to be debated is: Tough interrogation of terror suspects is necessary. It will be moderated by WNYC’s Brian Lehrer and the panelists for the next debate are – For the motion: Professor at the Deakin Law School in Australia, Mirko Bagaric; Rosenkranz Foundation-Intelligence Square U.S.- Retired U.S. Air Force Lieutenant Colonel and Military Analyst for NBC News, Rick Francona and the John M. Olin Fellow at the Manhattan Institute, Heather Mac Donald. Against the motion – Former FBI agent and President of Clayton Consultants, Jack Cloonan; former Judge Advocate General for the Navy and President and Dean of the Franklin Pierce Law Center, John Hutson; and Darius Rejali, Professor and Chair of the Political Science Department at Reed College.

An edited version of tonight’s Intelligence Squared U.S. debate can be heard locally on WNYC, AM 820, on Sunday, February 24th at 8:00 p.m. These debates are also heard on more than one hundred NPR stations across the country. Please check your local NPR member station listings for the dates and times of broadcast outside of New York City. Copies of books by Max Boot, Ian Bremmer, Michael Mandelbaum and Douglas Murray are on sale upstairs in the lobby. You can also purchase DVDs from previous debates here tonight or from the Intelligence Squared U.S. website. And now the debate results: After our debaters did their best to sway you, you voted - - twenty-four percent for. Sorry. I’m sorry, I gave you the early results. After the debate, forty-seven percent for, forty-eight percent against. And five percent Rosenkranz Foundation-Intelligence Square U.S.- undecided. It’s fascinating.

### Moderator
Claim: Wow, wow, wow.

### Moderator
Claim: I, it, it – I mean, if this was one of those dreadful election night results, things that Wolf Blitzer does, it would say, too close to call.

### Moderator
Claim: Does this mean that the Super Delegates decide?

### Moderator
Claim: Yes, I’m the Super Delegate and I decide Against won by a whisker. But you both did remark…You, both sides did really remarkably well. And I thought it was one of the most articulate cases from the six of you that I’ve heard either for or against. And I thank you both very--all very much.

### Moderator
Claim: Thank you.

### Moderator
Claim: That’s remarkable.

### Moderator
Claim: That is remarkable.
