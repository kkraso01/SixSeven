# Debate Transcript

Topic: The President Has Constitutional Power To Target And Kill U.S. Citizens Abroad
Motion: The President Has Constitutional Power To Target And Kill U.S. Citizens Abroad

Debate ID: 030514%20Targeted%20Killing


## Round 1

### Moderator
Claim: So that's the shape of it. We hope you'll enjoy this, and we're delighted that you're all here. And we are delighted to be here. And to that end, I want to bring to the stage two gentlemen. I will introduce them first, and then I'll tell you why they're here. But first I'd like to bring to the stage Nicholas Quinn Rosenkranz. He is a professor of law at Georgetown. And he is a director of the Rosenkranz Foundation which is what initiated the Intelligence Squared debates series here in the United States back in 2006. Please let's welcome to the stage Nick Rosenkranz. Oh, you walked up--

He jumped his cue on me. And Jeffrey Rosen. Jeffrey is the president and chief executive officer of the National Constitution Center. And he is also professor at the George Washington University Law School. I think you know him well. Ladies and gentlemen, Jeffrey Rosen.

And what we want to do is chat very briefly about how this debate came about. Both of these gentlemen had a part in the fact that IQ2, as we call it, IQ2US, normally based in New York, but we come to various cities. Our first time in Philadelphia. Jeffrey, how did this happen?

### Moderator
Claim: Well, first of all, let me say how thrilled I am by this collaboration between IQ2 and the National Constitution Center. I have been the head of this wonderful organization since June.

And the National Constitution Center is the only institution in the country chartered by Congress to disseminate information about the U.S. Constitution on a nonpartisan basis. So our current board chair is governor Jeb Bush. Previous chairs have been President Clinton and H.W. Bush ’41. And on basically my first day on the job, I went to Governor Bush and said, "I want to be the place in the country where all sides of constitutional debates come, and people can make up their own minds.” I said, "We're not going to talk about politics, just about constitutional issues, and bring together folks who never talk to one another.” And Governor Bush said, "You know, you've got to talk to IQ2 because they are the best policy debate organization in the entire country.” So I called up Bob Rosenkranz, the head of IQ2, and he said, "You've got to talk to my son Nick.” and I said, "I've heard all about Nick. He teaches constitutional law over at Georgetown, and I'm at GW, and I've been eager to meet him.” So I called up Nick, and I said, "Why don't we start up a constitutional debate series?" and he immediately said, "Yes. What a great idea.

We're only going to debate the Constitution. We're not going to debate politics. And we are going to do this better than anyone else in the country.” Here we are. I am so thrilled to welcome you to the National Constitution Center.

### Moderator
Claim: We're thrilled to be here.

### Moderator
Claim: Can you corroborate all of that?

### Moderator
Claim: I corroborate all of that. That's what happened.

### Moderator
Claim: So, Nick, in fact, we actually did do a debate several months back in our last season on the issue of the practical, political side of what was then called drone— we were calling "drone warfare.” The motion was: The president's drone warfare policy is fatally flawed. And yet now we're, in a sense, revisiting this issue again, but we're doing it in a different cut, with this constitutional issue. Why are we doing it that way?

### Moderator
Claim: Yes. That's a great question. I know you flagged this a bit before we came out to the stage. But so this is the constitutional question. And it is distinct, potentially, from the policy question. So, for example, it is completely coherent for you to believe that these targeted killings are a great idea and yet unconstitutional. It's also completely coherent for you to believe that they're a horrible idea and yet constitutional. Those things are fine to believe. We are talking today only about the constitutional question.

### Moderator
Claim: And to that end, what would be some terms of art that would be useful for us to know as the law professors here that would be relevant to today's debate?

### Moderator
Claim: Well, so most important probably is what clause of the Constitution is going to turn out to be at issue. I would predict we'll end up talking mostly about the due process clause. So "no person shall be deprived of life, liberty or property without due process of law.” I think we have it up on the screen there. And you can expect one side to say, look, the text is clear. You cannot do this. On the other hand though, you might say, well, wait a second, that doesn't apply in a war zone or it doesn't apply to someone who's taken up arms against the United States. You know, or I suppose you could say, yes, it does apply, but this isn't a process. This is the amount of process that's due. And so, I think you might hear something along those lines.

### Moderator
Claim: All right. That gives everybody a jump start on their thinking about this. And Jeffrey and Nick, I want to thank you again for bringing us here.

And let's bring our terrific debaters to the stage. Thank you, Jeffrey-- both.

### Moderator
Claim: Great.

### Moderator
Claim: Thank you.

### Moderator
Claim: Have a great debate.

### Moderator
Claim: Thank you. And as I mentioned, as this is a radio broadcast, there will be times during the evening when you'll hear me repeating certain things over and over again. I will tell you again and again what my name is. And it's not because I forget. It's for coming back from breaks in the radio broadcast. And also, for the same purpose. There are various times when I might ask you to applaud spontaneously. But the signal for that spontaneous applause would be-- would be this. And we might actually get started with that right now. Ladies and gentlemen, thank you. a police officer is chasing a bad guy, and he's got him cornered. And the cop has a gun out, pointing at him. And does he get to shoot the bad guy at that point and decide his fate right then and there? Well, no. Unless the bad guy happens to pose an imminent danger, as in he pulls out a gun and tries to shoot the cop. But otherwise, the bad guy-- the suspect— actually gets a trip downtown. And he gets his day in court, which is his right. But what if the bad guy is a suspected American terrorist living overseas who is believed, in the last few months to have planned attacks on the United States, and the president is told by his aides, "We know where this guy is right now, we can get him today," does the president get to kill that guy, decide his fate right then and there, or does that American have rights, too?

Well, that sounds like the makings of a debate. So let's have it, "Yes," or, "No," to this statement, "The president has constitutional power to target and kill U.S. citizens abroad," a debate from Intelligence Squared U.S. I'm John Donvan. We are at the National Constitution Center in Philadelphia. We have four superbly qualified debaters who are divided on this issue, two against two, with the motion being "The president has constitutional power to target and kill U.S. citizens abroad.” As always, our debate goes in three rounds, and then the audience votes to choose the winner, and only one side wins. Our motion again, "The president has constitutional power to target and kill U.S. citizens abroad.” Let's meet the team arguing for the motion first. Ladies and gentlemen, let's welcome Alan Dershowitz. And, Alan, you are the Felix Frankfurter Professor of Law at Harvard.

You're well known for your civil liberties advocacy. You've served as legal advisor to Julian Assange. You have argued to save two brothers from the death penalty in front of the Supreme Court. You defended the right of neo-Nazis to march through Skokie, Illinois. You recently retired, but you have described it as more of a career change, so what are you doing with all your free time?

### Conspiracy Advocate (CA)
Claim: Free time, I wish. I am busier than ever—writing, litigating, debating, and occasionally taking walks on the beach in Florida.

### Moderator
Claim: Well, we're glad we have you here during this free time of yours. Thank you, Alan Dershowitz. And, Alan, tell us who your partner is in this debate.

### Conspiracy Advocate (CA)
Claim: My partner is a real American hero. He served in the military. And now he does a great job in defending the military, the distinguished professor, Michael Lewis.

### Moderator
Claim: Ladies and gentlemen, Michael Lewis. And, Michael, you also are arguing for the motion that "The president has constitutional power to target and kill U.S. citizens abroad.”And, as Alan Dershowitz mentioned, you're a professor of law at Ohio Northern University Pettit College of Law and you served in the Navy. You flew F-14s, and you flew those in missions including Operation Desert Shield and Desert Storm. So your having this combined law experience and this combined combat experience combines in what way for you?

### Conspiracy Advocate (CA)
Claim: Well, it gives me a perspective that most people that write in this area don't have. Most lawyers are military lawyers first. I was a combatant before I knew the law. I first encountered the law when I was learning ROE in the Gulf War.

### Moderator
Claim: So that means you know what you're talking about.

### Conspiracy Advocate (CA)
Claim: I hope so.

### Moderator
Claim: Well, we'll find out. Ladies and gentlemen, the team arguing for the motion. And we have two debaters arguing against this motion that "The president has constitutional power to target and kill U.S. citizens abroad.” Let's meet the first of them. Please welcome Noah Feldman. Noah, you are the Bemis Professor of International Law at Harvard Law School.

You were an advisor in the drafting of Iraq's constitution, and in-- which meant you were over there.

### Scientific Advocate (SA)
Claim: Yes, you see how well that went.

### Moderator
Claim: Well, you try. You try. And you are also a very prolific author including in 2013 coauthoring the casebook Constitutional Law, 18th edition? So were you there at edition one?

### Scientific Advocate (SA)
Claim: Not exactly.

### Moderator
Claim: That was how far back?

### Scientific Advocate (SA)
Claim: That was in 1937.

### Moderator
Claim: All right, so you may have been precocious but not that precocious. Ladies and gentlemen, Noah Feldman. And, Noah, your partner is?

### Scientific Advocate (SA)
Claim: My partner is also a genuine American hero, the inspiring and remarkable Hina Shamsi of the ACLU.

### Moderator
Claim: Ladies and gentlemen, Hina Shamsi. Also arguing against the motion that "The president has constitutional power to target and kill U.S. citizens abroad.”You are the director of the ACLU's National Security Project. You have directed Human Rights First’s Law & Security Program. And right now, Hina, you are in the middle of litigating a lawsuit actually directly related to the subject before us tonight. Tell us briefly what's going on in that.

### Scientific Advocate (SA)
Claim: I represent the families of three U.S. citizens who were killed as part of President Obama's targeted killing program in Yemen in 2011. These family members want to know why their sons and grandson died, and one of the people who died is on Anwar al- Awlaki, who's referred to in your program. One of the other people who died was his 16-year-old son whom no one has accused of wrongdoing but who was blown up by a drone while he was eating dinner at an outdoor restaurant.

### Moderator
Claim: All of which tells us that none of this is theoretical. We are talking about the real world. Let's please welcome Hina Shamsi. So, as we said before, this-- this is a contest. This is a debate.

Only one side will win, and they will win by determination of your vote-- our live audience here in Philadelphia. By the time the debate has ended, you will have voted twice-- once before the debate, and once again after you've heard the argument. And the team whose numbers have moved the most in percentage point terms will be declared our winner. So, let's get the preliminary vote registered. If you go to those keypads at your seat, take a look again at this motion: The President Has Constitutional Power To Target And Kill U.S. Citizens Abroad. If you agree with this motion, push #1. And if you disagree, push #2. If you're undecided, #3. You can ignore the other keys. They're not live. And if you push the wrong key, you can correct yourself, and the system-- in about 15 seconds-- will lock out your most recent vote. And remember, what we do at the end of the debate-- you vote a second time. And the team whose numbers have moved the most in percentage point terms is our winner.

All right? It looks like everybody's completed that. So, onto Round 1. Round 1 are opening statements from each debater in turn. They will be six minutes each. Up first for the motion-- The President Has Constitutional Power To Target And Kill U.S. Citizens Abroad-- Michael Lewis, a professor of law at Ohio Northern University Pettit College of Law and former Navy fighter pilot. Michael, if you can make your way to the lectern, when you get there, I'm going to tell everybody your name one more time. Ladies and gentlemen, Michael Lewis.

### Conspiracy Advocate (CA)
Claim: Thank you all for coming, and thank you to the National Constitution Center for hosting the debate. The president does have the power-- the constitutional power-- to target American citizens overseas in the exercise of his war-making power. Now, that war- making power is not unfettered. The Founding Fathers saw to it that only Congress may declare war.

Now, while formal declarations of war have not occurred since World War II, major military operations, such as the Gulf War, the 2001 Afghan War, and 2003 in Iraq-- all only happened after the executive was authorized to use military force by large bipartisan majorities of both houses of Congress. Now, the AUMF-- the authorization to use military force-- in 2001, which is the basis for President Obama's continued use of his war-making power against Al-Qaeda and associated forces-- our opponents will say, was only directed at those that participated in or planned 9/11. However, since that time, the judiciary, in the line of habeas cases from Guantanamo, has determined that the scope of that authority actually is Al-Qaeda and associated forces. The thinking behind this is that when you're dealing with an enemy like Al-Qaeda, that is diffuse, that is splintered, you are not going to require the president to return to Congress for authorization every time a new group with a new name shows up in a new location-- as long as they are still trying to kill Americans in this country or kill American troops and contractors in Iraq and Afghanistan.

Further, since that judicial gloss has been placed upon the scope of the authorization, Congress-- the Senate Armed Services Committee-- held hearings last year on whether the AUMF should be revised, repealed, or retained. And at the conclusion of those hearings, they left it as it was and so, at least implicitly, have accepted the scope of the authorization that the judiciary has put on this.

Now, once the executive has received the authorization to use military force from Congress, it is then the exclusive province of the executive branch to determine when, where, and how that war is fought. Congress tells him who we are declaring war on.

We declare a war on Germany, he can't go fight France. But it is up to him how he fights Germany, where he fights Germany, who he targets. That is exclusive executive decision-making. And no other branch has any constitutional basis for challenging that decision-making. And this is true, even when we are talking about targeting Americans. During World War II, the United States Armed Forces killed a number of American citizens that were members of the German and Japanese armies. But in today's war, we are being told that although those people-- the Germans and Japanese that we killed without questioning whether we were invading or infringing upon their due process rights. We're told that today, because our enemy doesn't wear uniforms, doesn't carry arms openly, hides amongst the civilian population and uses human shields, in other words, because they undermine all of the basic tenets of the laws of war, that they should be afforded due process rights that an American putting on a German uniform does not have.

Now, the president does have a duty, under international law, to distinguish between targetable individuals and civilians. But he does not have a duty under either international law or the U.S. Constitution to distinguish between targetable Americans and targetable non-Americans. And as my partner will argue, such a distinction would be immoral. Now, you will hear our opponents argue that this authority of the executive is geographically bounded by “hot battlefields.” You can only use this authority in “hot battlefields.” That is a term that does not appear anywhere in either international law or in the U.S. Constitution.

And yet because internal armed conflicts have been determined to exist based upon a level of violence measure, by some commentators in some courts, they are trying to impose that view of international law on our president. However, the U.S. view of international law is consistent with that of many other nations that face non-state actors that have committed terrorist acts against their citizens and then tried to seek sanctuary by crossing some international boundary. And just as Columbia and Turkey and Israel and even Iran reject the notion that you may gain such sanctuary, the United States also agrees that the laws of armed conflict go where the participants in the armed conflict go. And because this is an armed conflict, there are no due process rights available.

Lastly, we are going to hear from our opponents that there is insufficient transparency on the part of the administration.

They are not telling us enough about how they know what they know about our enemies and what they know about our enemies and why they are targeting our enemies. Now, of course, if they reveal this to the American public, they are also revealing it to our enemies. And to say that the due process rights of our enemies must be vindicated by telling our enemies what we know about them and how we know it does not-- well, let me say that it is obvious why there is no constitutional requirement for such disclosures. Thank you.

### Moderator
Claim: Thank you, Michael Lewis.

Our motion is “The president has constitutional power to target and kill U.S. citizens abroad.” And our next debater to speak against this motion, Hina Shamsi. She is the director of the ACLU National Security Project. And she is currently litigating a lawsuit that challenges the government's killing of three U.S. citizens in Yemen. Ladies and gentlemen, Hina Shamsi.

### Scientific Advocate (SA)
Claim: Good evening, ladies and gentlemen. Today the president is claiming an absolute power that would have horrified the Founding Fathers. He asserts the authority to kill American citizens without judicial review based on largely secret law, entirely secret evidence, and he asserts this power even with respect to Americans who are found far from any conventional battlefield. Noah and I are here to argue against the proposition, because the power that the president is claiming is unlawful and it is unwise. In our system of checks and balances, the president cannot be the judge, jury and executioner. Now, for very good reason, our Constitution and international law strictly limits the government's power to kill people without judicial review. In areas of actual armed conflict, under the law, the government can kill people without judicial review because of battlefield requirements.

Outside that context, extra judicial killing is legal only if it is a last resort and only if its in response to a truly imminent threat. The government can't kill Americans simply because it believes that they may do something dangerous at some point far off in the future. This is a democracy. It's not Minority Report. So in every context, the Constitution, outside of armed conflict, the Constitution requires the government to prove its case to a court before it delivers a death sentence. That's because even the most serious allegations are not evidence. And due process requires evidence, not just allegations. Now, the president, and our opposition, seek to circumvent due process in ways that strike at the heart of our system of checks and balances of what it means to be a nation ruled by law, not men or women.

First they want to redefine the battlefield so that it covers the globe. That's not just wrong. It's a very dangerous proposition. And Noah's going to address that more. Then they want to redefine the law. We only found out after the leak of a so-called white paper which purports to summarize still-secret legal memos that were written to justify the killing of a U.S. citizen, Anwar al-Awlaki. The white paper acknowledged that he was going to be killed outside of recognized battlefields, but argued that the killing could be lawful in response to an imminent threat. It then redefined imminence to mean its very opposite. The White House now says that it can order the killing of an American it suspects may some day present a threat even without evidence of an actual plot.

This is a radical reinterpretation of the law. What should trouble us as much as these legal shenanigans is that the actual full standards for killing Americans far from any battlefield are still secret. The government refuses to disclose to us its killing memos. Was Anwar al-Awlaki truly an imminent threat? The only way to find out would be for President Obama's Justice Department to present its evidence to a court. This the government refuses to do. Instead, the Justice Department has made a profoundly disturbing argument and claim. It said that the courts have no role to play in deciding whether al-Awlaki's killing, far from a battlefield, was lawful. Now, you may hear a lot tonight from the other side about why we need to trust the government when it comes to national security and threats. But one of the core lessons of the last decade is that "trust us" is never enough when the government claims power over life and liberty.

Do you remember when the Bush administration claimed that the people at Guantanamo were all terrorists, the worst of the worst? Remember when President Bush's Justice Department fought for years to prevent any judicial review of those claims ultimately without success? And do you remember what happened next? As the courts finally started reviewing the Bush administration's claims, it turned out that more often than not, the evidence that the government relied on was overstated, it didn't exist, or it was just plain wrong. The result was that the Bush administration itself released the majority of people at Guantanamo. When a president wrongly detains people, there's always the possibility of judicial review and release. There is no appeal from a drone strike.

Many Americans were outraged when President Obama claimed worldwide authority to detain people, suspected terrorists, without charge or trial.

We should be similarly outraged when President Obama claims something far more radical: The power, worldwide, to kill people the government unilaterally deems its enemies. Now, our concern here tonight isn't just for citizens. Four Americans have been killed in the targeted killing program. But thousands more non-citizens are dead. Several hundreds of these were far from any battlefield. They include a grandmother, for example, who was picking vegetables in her garden. And there are many more horrific accounts of similar tragedies and wrongful deaths. It isn't surprising then that military leaders warn that President Obama's lethal program is creating more enemies than it kills. Unlawful killings will never lead to security no matter how many of them our government commits. Think about the world we're creating. If the U.S. can carry out targeted killings in Yemen and Pakistan, why can't the Russians, the Chinese and Iranians do the same, Russia in Kiev, London or Washington, D.C.?

This is not the world that we want to live in. And Noah and I hope you agree with us and vote no to the motion. It's a proposition that is un-American, unlawful and unwise. Thank you.

### Moderator
Claim: Thank you, Hina Shamsi. And a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, arguing it out over this motion: The president has constitutional power to target and kill U.S. citizens abroad. You've heard two of the opening statements and now onto the third. Here to argue for the motion, ladies and gentlemen, Alan Dershowitz, who is the Felix Frankfurter Professor of Law at the Harvard Law School and author of 30 books, including his autobiography, Taking the Stand: My Life in the Law. Ladies and gentlemen, Alan Dershowitz.

### Conspiracy Advocate (CA)
Claim: Thank you.

Under the precise motion before this house, our opponents have the extraordinarily heavy burden of showing that under no circumstances should the commander-in-chief ever have the authority to order the targeting of dangerous terrorists—regardless of how imminent the threat may be, how impossible it would be to capture him—if that enemy happens to have been born in the United States or naturalized as an American citizen.

Consider the implications of that extreme position. It would mean that if Osama bin Laden had been born in America, had been planning the attacks on 9/11, were targeted, it was impossible to arrest him, and the only way to stop him from carrying out 9/11 would be to subject him to a drone attack, under the negative of the resolution, the president would lack that authority. That just makes no sense at all. Of course what they're going to try to do now is try to modify their extreme position by saying that the president would be authorized under certain circumstances, they've already conceded in the battlefield if it's an American, they've already conceded apparently if the judiciary agrees, so they've already undercut their proposition considerably.

But consider the implications even of their modified position. It would mean that unelected judges unfamiliar with the situation on the ground and inexpert at making intelligence assessment and operational decisions could prevent the commander-in- chief from taking action designed to protect Americans from terrorist attacks—even if such preventive action would be entirely lawful under both American and international law—if the people happen to have been American citizens. This is not Minority Report. These are cases where there is clear evidence that somebody in the past has joined al- Qaeda or its affiliates, has been an operational leader of al-Qaeda, and has participated in the planning of operations against the United States.

That's not Minority Report. Our opponents argue that a terrorist commander planning an imminent attack on the United States that can only be prevented by a drone attack has a constitutional due process right to a judicial predetermination. But consider the following relevant analogy: what if an American citizen wearing a T-shirt emblazoned with his passport on one side and the American flag on the other took a series of hostages? You don't even have to imagine it. Just consider if Timothy McVeigh instead of killing so many children in Oklahoma City had taken them hostage, and let's assume that he had said, "I'm not going to kill anybody for 48 hours until I complete the negotiation," but during that 48-hour period a sharpshooter was able to target him, not knowing exactly when he might start killing Americans. Would anybody in their right mind demand a due process prejudicial determination, or would you say that the situation there permits for the use of deadly force?

That's not murder. Yes, it's an extrajudicial killing, but extrajudicial killings occur all the time. Every time a fleeing felon runs away with a machine gun from a bank robbery, even though the bank robbery's complete, just on the basis of the possibility they may do it again, the United States Supreme Court has definitively ruled that deadly force may be used without violating his due process rights and without a predetermined judicial authority. In fact, the Supreme Court, just two days ago, heard a case on that issue, and the report in the New York Times said none of the justices gave any attention to the claim that it would be a due process violation in shooting a fleeing felon under those situations. Of course mistakes are made. There are-- mistakes are made with fleeing felons, and of course every effort should be made to reduce the number of casualties.

Some of the people referred to by my distinguished opponent were accidentally killed, including the son. He wasn't targeted. When you drop bombs people are accidentally killed. It's especially the case when terrorists make the decision to hide among civilians. They make the decision to violate the rules of law, the rules of warfare, and, as the result, the only option put to a democracy is to use the drone in the most targeted possible way, knowing that there might be some collateral damage and civilian casualties or allow the terrorists to continue. There should not be a distinction drawn between terrorists who are American citizens and terrorists who are not, except, of course, if they're captured, in which case being an American citizen makes it worse because it's treason. But if they're not captured, if they're on the battlefield, once one signs up to become an al-Qaeda operative, his or her citizenship does not and should not matter. The important distinction is not between Americans and non-Americans, but rather between combatants and civilians.

All Al-Qaeda operatives are unlawful combatants. That is, they are subject to being targeted as combatants, because they've joined Al-Qaeda, because they are at war with the United States. But they are not entitled to the benefits of being legitimate combatants because they do not comply with the rules of warfare. So, just use your common sense and ask yourself the question-- does the Constitution really straight- jacket the Commander-in-Chief of the United States Armed Forces? Does it really deny him the constitutional power to prevent an act of terrorism just because the person planning the act of terrorism is an American citizen? I urge you to vote that the president has such power to protect you and your children. Thank you.

### Moderator
Claim: Thank you. Alan Dershowitz. Our motion: The President Has Constitutional Power To Target And Kill U.S. Citizens Abroad. And here, our final debater making opening statements, and he is arguing against this motion-- Noah Feldman. He is the Beamis Professor of International Law at Harvard Law School and a contributing writer for the New York Times magazine and Bloomberg View. Ladies and gentlemen, Noah Feldman.

### Scientific Advocate (SA)
Claim: When I was a kid, I really liked to argue. And my parents told me that I should grow up and I should defend civil liberties, like Alan Dershowitz. I don't think they thought-- and I know I didn't think-- that I would eventually have to defend civil liberties from Alan Dershowitz-- But that seems to be where we are. We're on hallowed ground here. Those of you who live in Philadelphia are accustomed to invocations of the Constitution and its importance. But for those of us who are visitors, it's not a trivial thing to come from the airport, get out of the taxi, and see Independence Hall, where the most basic principles of liberty were set down for the United States.

And indeed, the Framers believed, that by demonstration, they were setting down those principles of liberty for the whole world. That matters, and it ought to matter to us in thinking about this issue, because it pushes us to ask what's really the most fundamental question you could ask about the nature of liberty and democratic government: What is the essence of liberty? What's it all for? Why do we even have a constitution? And if you boil that down to its deepest essence, the most fundamental component of liberty, going back to Magna Carta, which is 1215-- if you're counting. Not the time 12:15. The year 1215. The essence of Magna Carta-- the thing that was demanded from King John of England-- was to promise that the government would not kill its own citizens without a trial. That's it.

That's the essence of liberty. Your government can't kill you without a trial. And when we say "due process," which is a fancy expression, that's all it means. That means you get a chance to explain that you didn't do it, that it wasn't you. And before that happens, they won't kill you. Now, if you are fighting at the Battle of Guadalcanal in a Japanese uniform, and you suddenly hold in the air your U.S. passport, sure, there is no doubt that in that context, the American soldier on the other side can kill you, because you are on the battlefield in a legitimate war. And to think otherwise would be preposterous. And it is, to be completely blunt, a classic debaters' trick to say that somehow, we have a radical position or that we've modified our radical position for denying that. That's just common sense. And common sense should, I insist, drive your vote in this case-- though not exactly in the direction that our opponents think it ought to.

Now, what is the difference between a person on the battlefield fighting in a war and an American citizen, thousands of miles from home, who is targeted by a government program? The answer is pretty simple, and there are two of them. One is, under the international law of war and under our domestic law, the threat has to be imminent. As Hina explained, imminence is-- means what the word imminence sounds like it means. Imminent. About to happen. And if you read the white paper, what it says-- this government document-- it's nominally a description of an even more secret document - - it says "Imminence is not imminence. Imminence is where you might have done something in the past and you're a member of Al-Qaeda, and maybe you're a senior member of al-Qaeda, and so you might do something in the future. That's not imminence under the law, and it's not imminence under common sense.

The second element is, you have to be in the war. You have to be on the battlefield. Now, the other side has said, quite honestly-- and I give them a lot of credit for saying this-- that in their opinion, the battlefield is anywhere. Anywhere. So you get off the plane at Heathrow, some of you probably travel every so often. You're abroad, so you're under the terms of our motion. You can be killed. Why? Because the president of the United States could determine, secretly, by a secret process, that he believes that you are affiliated with either al-Qaeda or some other force that he says, now, 13 years after 9/11, is affiliated with al-Qaeda. We'll leave aside whether you could be affiliated with an affiliated group, but there's reason to think that even that would satisfy the administration. And when that happens, you can be killed. Now, is that consistent with the idea of a declaration of war?

No, it is not, because a battlefield cannot stretch forever in time and everywhere in geographical dimension. That is not war under the meaning of our Constitution. It is not war as our Founding Fathers would have recognized it. It is not war even as Congress would have intended. And it is certainly not war under the meaning of international law as is shared by people around the world. That meaning, by the way, is relevant to our Constitution, because when our Constitution talks about the declaration of war, it's referring to a concept from international law. The word "war" means something in our Constitution. It gets its meaning from international law.

As a consequence of all this, you have to have ask yourselves, where will it end? So there's a plausible answer, which is, eventually, Congress will say the war is over. When do you think that's going to happen? When do you think it's going to be in the political interests of your elected representatives to stand up and say, you know, 9/11 happened. We fought back.

The war against terror is over, and we hereby-- what, peace treaty? There's not going to be a peace treaty. So I think it's quite realistic to expect that from the standpoint of Congress, and therefore from the standpoint of the executive, they're never going to end this war. And the same goes for geographical range. They're never going to say they can't kill you. If that bothers you, you should vote no on the proposition.

## Round 2

### Moderator
Claim: Thank you. Noah Feldman. And that concludes round one of this Intelligence Squared U.S. debate where the motion is: The president has Constitutional power to target and kill U.S. citizens abroad. I have dropped my notes. I will be right back. I'm back. Now onto round two. And round two is where the debaters address one another directly and take questions from me and from you in our live audience here in Philadelphia. We have two teams of two arguing for and against this motion.

The team arguing for the motion, arcing that the president does have this Constitutional power, Alan Dershowitz and Michael Lewis. We've heard them argue that this power actually grows out of the president's war-making abilities and that it was sanctioned by Congress. They say it is up to the president to decide how war is to be fought, and they argue that the battle goes where the combatants go, that that's what defines the location of the battlefield and that there is no distinction to be made between combatants who are our enemies, who are Americans, and combatants who are not Americans; that anybody who signs up for the other side more or less gives away many of the protections of American citizenship.

The team arguing against the motion, Hina Shamsi and Noah Feldman, argue that, first of all, the rules matter, that the question of where the battlefield is, a hot battlefield, is essential to this the idea of whether it's right for killing to take place, also where and when that due process is owed to American citizens no matter where they are.

They also argue that a trial before getting a death sentence is in essence of liberty, that that's part of who we are and has been for a very long time. They say for the president to have this secret power to act as judge, jury and executioner is a killing power that has no limits. Let's-- let's go through-- actually, what I think we need to do is go through some of the discussions and the disagreements we see about definitions and the rules. And I want to go to the side that's arguing that the president does have this Constitutional power and point out that your opponents have made the argument that your-- your argument that the war goes where the combatants go is false because it's without end and that in fact it's pretty well-established in international law what we mean when we define a battlefield. They say, you're wrong, that a guy sitting in a house in Yemen having coffee is not in the middle of a hot battle, and therefore is not a legitimate target. Alan Dershowitz or Michael Lewis? Alan Dershowitz.

### Conspiracy Advocate (CA)
Claim: Well, in the old days, they used to actually have battlefields that were marked off. And the battles would occur on the battlefield.

Obviously, over time, the concept of battlefield is expanded. Al-Qaeda expanded it even more by declaring that the battlefield was anywhere where they can legitimately operate from and kill Americans. There's no doubt that the battlefield includes Yemen. It includes the Sudan. It includes parts of Pakistan. Of course, it doesn't include Heathrow Airport because we can arrest people at Heathrow Airport. For purposes, functionally, of defining the powers as we discuss it, it includes anywhere where al- Qaeda is operating functionally, where it has the protection of local people, where they can't be arrested, and from where they can attack the United States. That is a reasonable, functional definition of battlefield, and we have to adapt the definition to our enemies, otherwise our enemies will defeat us through law fare, not through warfare.

### Moderator
Claim: Hina Shamsi.

### Scientific Advocate (SA)
Claim: I'm reminded of something that Senator Daniel Patrick Moynihan said, which is that you're entitled to your own opinions, but you're not entitled to your own facts.

Here in this situation, you're not really entitled to your own reinterpretations of the law and presenting it as the law currently is. Actually, the law is pretty clear. There are tests under international law about what a battlefield constitutes. It's called hostilities, and it is exactly what it sounds like, which you-- you've got to have a certain threshold of violence. You've got to have a certain threshold of repeated violence. That standard is quite simply not met by the one that our opponents offer up. They would have the battle field be wherever the government says that it is. And it's not where the government says it is. It isn't where al-Qaeda says it is. It is where there actually are the kinds of hostilities happening on the ground. But you know, one thing I really want to pick up on and address back and ask our opponents, if I may, and that is-- well, one of the challenges is, professor Dershowitz was citing so many straw men, it's hard to know which one to take up with him.

But I think one of the ones that I want to lay to rest is the idea that there is somehow a substantive difference in terms of the legal standards when we're talking about citizens and noncitizens. It isn't. The same legal standards apply to both. The difference is that there is no question that citizens are able to have their cases reviewed and to see if there was a Fifth Amendment due process violation. Unfortunately, since 9/11, the courts have reduced that possibility for noncitizens. But my question for you is, why do you think that it is impossible to have judicial review, at least after the fact when the Supreme Court of that other democracy that carries out targeted killing as state policy, Israel, has actually examined and made a determination about when and whether targeted killings are lawful, set out the standards that must be followed, and established a process for independent review, including judicial review.

### Moderator
Claim: Let's take Michael Lewis.

### Scientific Advocate (SA)
Claim: Why should the U.S. be different?

### Moderator
Claim: Michael Lewis.

### Conspiracy Advocate (CA)
Claim: Expost, after the strike.

### Scientific Advocate (SA)
Claim: That's right.

### Conspiracy Advocate (CA)
Claim: The motion that we are having argued is, does the president have the power to order the strike in the first place without prejudicial review. After the review, that's a different matter. You're right, Israel has that. We do have post-strike evaluation within the executive branch. If we want to expand that to the judicial branch, I would be in favor of that, but that doesn't change the fact that the motion should carry. The other thing that I want to say about your discussion of the boundaries of the battlefield, or what constitutes a battlefield, the threshold of violence discussion that she mentions is from the Tadicopinion from the ICTY (International Criminal Tribunal for the Former Yugoslavia). And that applies to internal armed conflicts, right? This is not dealing with a conflict between a nonstate actor that crosses international boundaries. That was from the Yugoslav war, right?

If we are talking about the boundaries of battlefields between two nations, World War II did span the entire globe. Americans killed Japanese and Germans in the south Atlantic and in China and in Burma and off Australia. All over the world, those things were going on. And more importantly, if we're talking about what other nations do, other nations facing nonstate actors do not allow them to have a sanctuary, which is what they are saying they should get, by going across international boundary. You get to Yemen, you get to Somalia, you get to Sudan, and you're safe. You are immune from attack just because you got to a certain place, and then you can rearm, refit and reattack. The laws of war do not work that way.

### Moderator
Claim: Noah Feldman.

### Scientific Advocate (SA)
Claim: I just want to clearly refute the point that somehow the battlefield is anywhere where we can't arrest somebody.

First of all, we could we could arrest the people in lots of these countries, Yemen and Pakistan included. And if you want proof of that, it's that those governments actually agreed to our drone strikes. The Obama administration's official position is we don't do drone strikes in a country without the permission of that country. You know why? Because otherwise it would be an act of war against that country. So we get permission, and we got permission in all of these cases. So if you can get permission from a country, you can get help from that country. And, in principle, arrests would be possible. Want to add one more point. If you think that anywhere in the world counts as the battlefield, then even though our motion talks about abroad, if you vote, "Yes," on this motion, "Yes, the president can do this abroad," it follows logically that the president could do it within the United States.

### Moderator
Claim: Let me stop you there because I think I want to hear the other side respond to that point. Alan Dershowitz, is that-- does that frighten you, that thought?

### Conspiracy Advocate (CA)
Claim: No. I--what frightens me is the idea that a law professor would be telling the president that it's possible to arrest known terrorists--

### Moderator
Claim: But, Alan, that's a little bit of a subject change because I really want to hear an answer to the question, would this-- would the logical conclusion of your argument be that the president could use and execute this power inside the borders of the United States against a perceived enemy?

### Conspiracy Advocate (CA)
Claim: Well, the president already-- I mean, the executive already has that power as I proved in my opening--

### Conspiracy Advocate (CA)
Claim: --no-- let me answer the question the way I want to answer it-- the executive already has the power to kill Americans if they are fleeing felons if they are holding hostages. If we had a situation where al-Qaeda established a base in the Smoky Mountains from which they were sending rockets to Philadelphia and we couldn't arrest them because they-- the geographical situation was difficult and it would require the sacrifice of 10 or 20 or 30 American soldiers to arrest them, the answer to the question would be, "Yes.” We could use a sniper, as we have in the past. We could use a drone. We could use any modern technology to kill an American citizen who was endangering American citizens imminently by having a base firing rockets.

Yes, the answer to that question is, "Yes.” Now, it's not, "Yes," in the sense of the same response that would occur to somebody who was abroad. The criteria would be different, but the power already exists. And there's no doubt about that. And, Noah, how would you respond to "What is the difference between a terrorist holding hostages in the United States and the only alternative is to let him continue to hold the hostage, you can't arrest him, but you could kill him by a sniper or a drone, would you deny the executive the power to do that?

### Moderator
Claim: Let's let Hina answer that question, Hina Shamsi.

### Scientific Advocate (SA)
Claim: So the answer to that is that no one questions seriously that the police forces, military have the ability to use lethal force in response to an imminent threat. What we're talking about is what the president's authority as he claims it today is. And that authority is very distinct from what we've been talking about. It is based on a global battlefield, and it is based on a definition of imminence that does violence to life, to the rule of law, and to language itself because it radically reinterprets it.

That's really at the heart of what this debate is. And one of the key points that we keep going back and forth on is there's no question that it-- perhaps it sounds like you would agree that judicial review is needed. We can see if you agree with that or not. It's a very hard thing to talk about what kind of judicial review, right, because if you're using the law as it applies, if lethal force is used in response to an imminent threat, then by definition you won't have judicial review in advance. That's understandable. But if you're using imminence as the administration defines it, with apparently people being placed on kill lists for years, then the argument against judicial review falls away as does the legal justification.

What's most troublesome right now about the government's position and what it argues in court is that the courts have no role to play, none at all.

### Moderator
Claim: Let me interrupt you and bring in Michael Lewis to respond to that. Does that-- is that troubling or not, that the courts have no role to play, because your partner was saying that it's kind of ridiculous, the idea that a judge who doesn't know very much about war would be brought into this process?

### Conspiracy Advocate (CA)
Claim: No, the courts do not have a role if we are talking about war. And we are not here defending the white paper, right? We are here supporting the motion. The government's stance on the white paper and the discussion of imminence is not necessarily the standard that we are asked to meet today. What we are trying to say-- if you're talking about wartime, there is no imminence. You are allowed to kill an enemy during wartime whether they are armed, whether they are awake, right? You are allowed to kill enemy-- positively identified enemy soldiers in wartime-- at any time, right?

That doesn't require a showing of imminence. And the question is, are we at war with Al-Qaeda? Were we at war with the Confederacy when we killed a whole lot of Americans based upon their status?

### Moderator
Claim: So, you're saying the imminence question is actually irrelevant--

### Conspiracy Advocate (CA)
Claim: Yes. If we're talking about war.

### Moderator
Claim: Noah Feldman.

### Scientific Advocate (SA)
Claim: There was a wonderful moment where I was going to invite Michael over to the side of the good. But then I realized he was going in the other direction. Imminence--

### Moderator
Claim: For everyone-- for everyone-- you defined the word very nicely, but let's take the Latin out of it and-- imminence means "It's about to happen right now."

### Scientific Advocate (SA)
Claim: Imminence means, "It's about to happen right now.” It has a meaning in international law. It has a meaning in American domestic law. And it has a meaning in English. If you have time to leak to the papers, over the space of week, that you think you're possibly considering killing a guy-- which some of you may have noticed in the papers, the administration has been doing over the last couple of weeks, with an American, who we know by the name Abdullah al-Shami. I don't know his actual name. That's not imminent. But I just want to point out--

### Moderator
Claim: But they're saying it doesn't matter.

### Scientific Advocate (SA)
Claim: Right. Michael is now saying-- which I haven't heard Alan say-- but Michael has said now, "Imminence doesn't matter.” We can kill an American citizen abroad any time we feel like it if he's affiliated with Al-Qaeda, based on a decision made by the president in secret.

### Moderator
Claim: Okay. But-- that's your view--

### Moderator
Claim: Are you saying-- is that your view?

### Scientific Advocate (SA)
Claim: That's, like, a great thing for us if-- you don't--

### Moderator
Claim: You can see that-- but is that your view?

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: Michael Lewis first. Is he-- is he paraphrasing you accurately?

### Conspiracy Advocate (CA)
Claim: If they are a positively identified enemy-- member of Al-Qaeda or associated forces-- and an operational role, right? That's another requirement we've placed upon ourselves. If they are doing that, then we don't have to wait for them to be on the phone, about to order the attack, because we may not see them when they're on the phone ordering the attack. We may only see him-- we only may have a shot at him when he's sleeping. And I do want to say one other quick thing about Pakistan and law enforcement.

### Moderator
Claim: Can you-- just-- can you hang onto that?

### Conspiracy Advocate (CA)
Claim: Yeah, okay.

### Moderator
Claim: Because I really Alan Dershowitz.

### Conspiracy Advocate (CA)
Claim: I think you are prepared to concede that. I mean, if you have Osama Bin Laden, who is planning these things long-term, and you can find him-- let's assume, on a hot battlefield-- then surely you don't require imminence either. You require-- you define imminence functionally as well. And the question I want to throw back at you is-- let's go back to my terrorist holding hostage in the United States, in a place where he can't be arrested. He's holding 24 children. He's not imminently going to kill them. He wants to negotiate over days and over weeks, but you now have a shot at killing him and eliminating all risk to the children with no risk to anyone else. Would you suggest that you have to get a warrant in order to kill that terrorist? Of course not. So--

### Moderator
Claim: Well, actually-- before-- let-- don't make it just rhetorical. Let's hear their answer to that.

### Scientific Advocate (SA)
Claim: The terrorist with the gun to the head of the child-- that is the definition of imminence. There's a little picture of that in the-- that’s imminence--

### Moderator
Claim: No, no, no, no. But Alan-- Alan said the guy wants 48 hours to talk--

### Scientific Advocate (SA)
Claim: He wants--

### Moderator
Claim: --and you have your shot now.

### Scientific Advocate (SA)
Claim: He wants 48-- and he wants a week. That's--

### Moderator
Claim: And that's a valid-- that's a valid enough framing.

### Scientific Advocate (SA)
Claim: I think the view of the terrorist who says, "You’ve got 48 hours. And if you walk in the door, I'm going to kill the person right now.” Otherwise, you would just walk in the door-- so, it's not 48 hours then.

### Conspiracy Advocate (CA)
Claim: Isn't the Al-Qaeda guy saying, "As soon as we have an opportunity to put a bomb on a plane and a guy wearing a shoe or a guy wearing the underwear, we're going to do it"? It could be tomorrow. Why is that not a gun to the head--

### Scientific Advocate (SA)
Claim: That's a--

### Conspiracy Advocate (CA)
Claim: --to all of us?

### Scientific Advocate (SA)
Claim: That's actually not the position that the White Paper takes. What it says is--

### Conspiracy Advocate (CA)
Claim: Well, we're not defending the White Paper. We're defending the power of the president--

### Scientific Advocate (SA)
Claim: Well, you're putting two opposite views, now, of imminence. You're saying imminence is pretty darn imminent, which I'm actually prepared to think is--

### Conspiracy Advocate (CA)
Claim: No.

### Scientific Advocate (SA)
Claim: --reasonable.

### Conspiracy Advocate (CA)
Claim: No, no. I'm--

### Scientific Advocate (SA)
Claim: And Michael is saying imminence is not relevant.

### Conspiracy Advocate (CA)
Claim: I'm saying it's a functional definition. You have to ask yourself, "What is the opportunity to prevent an event which is highly likely? We don't know exactly when it's going to occur, but we have an opportunity to prevent it now.

We may lose that opportunity tomorrow.” So, imminence may not define the harm. It may harm the opportunity to prevent the harm.

### Scientific Advocate (SA)
Claim: If it's highly likely to occur in the immediate future, I think that's imminent.

### Conspiracy Advocate (CA)
Claim: No, not in the immediate future. What if it's--

### Scientific Advocate (SA)
Claim: I mean, imminent future. That's--

### Conspiracy Advocate (CA)
Claim: --in the longer term?

### Scientific Advocate (SA)
Claim: --using-- I'm trying not to use the--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --word imminent.

### Moderator
Claim: I want to go some questions from you in the audience. And you sort of see the spirit of this. We'd like you to be-- raise your hand, stand up. Really tight, focused question that keeps these debaters focused on this motion. Sir, right down front here. And a microphone will come to you from your left side. And if you can just wait for it. And if you can bring the mike to about this distance from your mouth, so I have-- the radio broadcast will hear you out. Now, tell us your name as well, please.

### Moderator
Claim: When you mentioned that the--

### Moderator
Claim: Can you tell us your name?

### Moderator
Claim: --fathers--

### Moderator
Claim: Sir, can you tell us your name? And your mike is not on yet.

### Moderator
Claim: My name is Jerry Volk And I'm a Philadelphian. And when you mentioned that the Founding Fathers would not have tolerated this, I think back to when Washington crossed the Delaware and chased the Hessians-- in New Jersey, down the pike.

What about that civilian who was in a house overlooking the route where the troops marched and the Hessians marched, and that civilian who had a hand grenade in his pocket, was killing him justified in your opinion?

### Moderator
Claim: I don't follow the question. Do you? Are you better than me at this? Because I-- I just want to-- the anachronism of the hand grenade at Valley Forge is confusing me. So I'm not sure where you're--

### Moderator
Claim: Valley Forge yet but--

### Moderator
Claim: Okay.

### Moderator
Claim: The question, in my mind, and the Founding Fathers, deals with the issue of imminence and what that person with a hand grenade in his pocket may do to the combatants who are passing by.

Do they have a right to act first or wait until they get blown up by the hand grenade?

### Scientific Advocate (SA)
Claim: If I understand your question, it's one that is based on the existence of an actual war and an armed conflict and the participation of a civilian in that armed conflict. And the law actually does permit lethal force to be used against civilians who are at or on the battlefield and directly participating in hostilities. There's no question about that. The difficulty we're having here now, that you're hearing this evening, is that our opponents want the battlefield to be designed so broadly that there is no limit to it, that the limits that international law has always recognized that have helped us contain when the government can use the broadest authority that it may have to kill no longer apply. And that is

### Moderator
Claim: Is there a very common sense-- a very common sense notion to their claim that the-- that a battlefield is everywhere. And in his opening statement, Alan said basically this is common sense. And you are talking about international law as it exists and saying that it doesn't fit the scenario. And they are saying, well, in a common sense way, the war is everywhere. Now, I think we all understand what they mean by that. And I'd like to hear more of a challenge to it.

### Conspiracy Advocate (CA)
Claim: By the way, we're not saying everywhere. We're saying everywhere--

### Moderator
Claim: Where they are.

### Conspiracy Advocate (CA)
Claim: --where they are and have sanctuary and can't be reasonably arrested.

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: Not Heathrow Airport.

### Moderator
Claim: So I-- the common sense side of that argument is appealing to the intellect. I want to see if there's a response to it. Either of you-- either of you would take that.

### Scientific Advocate (SA)
Claim: Sure. Let me--

### Moderator
Claim: Hina Shamsi.

### Scientific Advocate (SA)
Claim: --just start, and perhaps Noah will jump in. You know, what they're positing is common sense is actually far from that. And listen to the language that they're using, "Everywhere where they are.” Who is "they"? The government is telling us, President Obama has said that core al-Qaeda has been decimated.

So now we're talking about associated forces. Who are associated forces? The government refuses to define them. It refuses to tell us who they are. Part of the core of what we look to in a democracy is when we go to war, we need to know where we're at war at. And we absolutely don't know that right now. And the kinds of thresholds for war to exist, the kinds of powers that the president can claim in war time to exist, simply are not there.

### Moderator
Claim: And Michael Lewis, you-- you're-- in fact your opponents, in making that point earlier, also said that's a very big mistake to go into the whole notion of "trust us.” You know, give the executive a "trust us" pass, and that that's-- history shows we don't want to do that. And it sounds as though you're being accused of doing that.

### Conspiracy Advocate (CA)
Claim: But I don't think-- well, first of all, when you talk about-- it's not the executive that is saying we are at war. It is Congress that is saying we are at war, and it's their job so say so. And al-Qaeda and associated forces, who are they?

### Moderator
Claim: But in the operational sense, in the executive sense.

### Conspiracy Advocate (CA)
Claim: In the operational sense, then you're talking about al-Qaeda, al-Qaeda--

### Moderator
Claim: I'm talking about the White House is saying, "Trust us," in the operational sense.

### Conspiracy Advocate (CA)
Claim: So they are saying that if we are going to-- we cannot distribute in detail how we are determining who the enemy is because if we describe in detail who the enemy is, then they will make sure that they are not that, right? If you think about Rico laws, Rico laws are developed to deal with the mafia because the individuals in the mafia knew what they could say or not say, and therefore not be guilty or not be close enough to the crime. Same thing here. If we say, what you need to be to be on our list is you have to be doing A, B and C.

### Moderator
Claim: But does that mean they're right, that it is a "trust us" situation?

### Conspiracy Advocate (CA)
Claim: At some level, you always have to trust the executive because it's the executive that is given the authority to do this.

### Conspiracy Advocate (CA)
Claim: But also, every single act of targeted assassination is then reported to the House and Senate intelligence committee. There is review. And by the way, I'm not opposed to after the fact judicial review. Virtually every exercise of legitimate presidential power is subject to judicial review. There is no inconsistency between saying the president has the power, which is our proposition, and them saying, but if he violates that power or abuses it, you can take him to court under judicial review. We don't oppose that. What we oppose is having the judiciary or the Senate or House, that would be a bill of attainder, but the judiciary in advance saying, well, maybe this guy you can kill, this guy you can't kill, when the president and the intelligence community have information that they cannot disclose. And one more point that I have to make is that you're so solicitous about al-Qaeda members. About 600 Americans are killed every year by police in the course of arresting fleeing felons.

We do that without judicial review. The Supreme Court in the case of Gardner vs. Tennessee has said if there is any possibility that the person is dangerous and might commit a crime in the future, if the alternative is to let him escape or not let him escape, you can shoot him dead. How do you distinguish that

### Moderator
Claim: Noah Feldman.

### Scientific Advocate (SA)
Claim: I just want to be really clear that what we're debating-- and this is an answer to that. What we're debating here is the president's power under the Constitution, what he's really authorized to do Constitutionally. The president is authorized. The police are authorized to use deadly force in a situation of true imminence. Absent imminence, the president is not authorized. And what we're talking about here in the real world, and we're talking about a real world case, is where there is no imminence in the ordinary sense of the term.

### Conspiracy Advocate (CA)
Claim: Imminence of what? When the fleeing felon is imminence of escape, not imminence of committing another crime.

### Scientific Advocate (SA)
Claim: That's just wrong.

### Moderator
Claim: Alan, I just want-- I just want to--

Noah, you have the floor for the next minute.

### Conspiracy Advocate (CA)
Claim: Gardner vs. Tennessee--

### Moderator
Claim: Let him have the floor for the next minute because I've given this side a bit of a long run. Go ahead. Noah Feldman.

### Scientific Advocate (SA)
Claim: The purpose of using deadly force against a fleeing felon, its fundamental purpose is to protect the public. It's not to punish the person.

### Conspiracy Advocate (CA)
Claim: Of course to protect the public. So is--

### Moderator
Claim: Come on. Come on, Alan. Alan.

### Conspiracy Advocate (CA)
Claim: Protect the public.

### Scientific Advocate (SA)
Claim: And where there is true imminence, the court has held that the executive can do that, and that makes a lot of sense.

### Conspiracy Advocate (CA)
Claim: Imminence or not--

### Moderator
Claim: Alan, I-- I'm going to-- I'm going to give you--

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: I'm going to give you a response time, but I'm about to take it away. Go ahead, Noah.

### Scientific Advocate (SA)
Claim: As I've said I don't know how many times now, imminence of immediate deadly harm, that's the standard, that's the reasonable standard. It makes sense in the war context. It makes sense in the police context. It does not make sense when the administration has time to run it up the flag pole and see who salutes.

### Moderator
Claim: Yeah, you know, that's-- that is common sense from this side now in terms-- imminence means right-- you know, imminence means it's going to happen today.

### Conspiracy Advocate (CA)
Claim: No.

### Moderator
Claim: --and the guy's on the plane, right?

### Conspiracy Advocate (CA)
Claim: Well, the question is--

### Moderator
Claim: No?

### Conspiracy Advocate (CA)
Claim: --imminence of what? Now, let me be very clear. Let me put on my hat as a law professor who has been teaching Tennessee vs. Gardner for the last 25 years. The law is completely clear that the person does not have to be imminently planning another crime. The imminent is he will escape unless he's shot dead. The only alternatives are shooting him dead or letting him escape. He's committed a past crime. He may commit a future crime. So the Supreme Court, for American citizens, has already defined imminence functionally. If this is your last opportunity to arrest him, and he will otherwise escape, you may shoot him dead. So Noah, you're just wrong when you say that the imminence requirement always modifies the imminence of the ultimate harm. Sometimes it modifies the imminence of the escape.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared-- I have to do this for radio, and I need you to not be chuckling. I want to remind you that we're in the question-and-answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator.

And we have four debaters, two teams of two, debating this motion: The president has Constitutional power to target and kill U.S. citizens abroad. We're taking audience questions. And the gentleman has been very patient. I hope-- I-- I'm sorry. I promised with the visual eye thing your neighbor. So I'll come to you next, but I hope it's a great question.

### Moderator
Claim: Daniel Berger from Philadelphia. Let's try to cut through all the sophistry. This is a question to both sides, to each participant. Aren't you really saying the president has the power, it's just not absolute?

### Moderator
Claim: Hina, do you want to take that first?

### Scientific Advocate (SA)
Claim: Yes. That’s I think what I started off saying in the first two minutes of when I started talking, and I think that that is correct. What we're talking about here is the power that the president is claiming today that goes beyond what the Constitution and international law permits.

No one seriously questions that the president has the power to order the killing of people, citizen and noncitizen alike, when they are on an actual battlefield. Those are the battlefield rules under certain constraints. No one's questioning that lethal force may be used in response to an imminent threat. And one point here, the thing about fleeing felons is they're felons. They've been found guilty--

### Conspiracy Advocate (CA)
Claim: Oh, no, no--

### Scientific Advocate (SA)
Claim: --after charge or trial. And one of the core things--

### Conspiracy Advocate (CA)
Claim: --no, you're missing my point. They have just committed a crime. The policeman thinks he's a fleeing felon. It may be a movie. He may have wondered onto a movie set. But if he reasonably believes that there's been no trial, that's my point.

### Moderator
Claim: Okay, all right, Hina.

### Scientific Advocate (SA)
Claim: So let me--

### Moderator
Claim: Now you get an extra 30 seconds. Enjoy it.

### Scientific Advocate (SA)
Claim: Thank you. So the answer is that we're not being absolute. We're talking about what is going on today and why that is impermissible, why that goes beyond the boundaries of anything permitted by law.

### Moderator
Claim: Okay, and this side want to take that question as well? Mike Lewis? I have a feeling you agree that nothing is absolute.

### Conspiracy Advocate (CA)
Claim: No, nothing, nothing is absolute, but I think it-- there's no question the president has this power and he has this power and the Constitution has set up how he gets that power-- it's not up to him to get it, it's up to Congress to give it to him in the course of a war. And I think one of the big disagreements we have here is where is a battlefield? And one thing that I heard them say earlier and that I want to come back to really quickly now is law enforcement. Let's have law enforcement in Pakistan, all right? Let's have law enforcement in the FATA region of Pakistan. There are no police in the FATA region of Pakistan. That is not how it's constructed. The Pakistani constitution does not apply in the FATA region of Pakistan. This is not how-- so you can't say, "Well, Pakistan can enforce the law there.” No, it can't, right, under its constitution, the way this works is you have an agent from Islamabad that goes up and deals with local tribal disputes, and those are enforced by tribal militias. There are no police in FATA--

### Moderator
Claim: And your point being?

### Conspiracy Advocate (CA)
Claim: --and there is no law enforcement in FATA.

### Moderator
Claim: your point--

### Conspiracy Advocate (CA)
Claim: So for them to be saying that we should rely on law enforcement to capture people in the FATA region of Pakistan is ridiculous because it doesn't exist.

### Moderator
Claim: Sir.

### Moderator
Claim: Mr. Feldman, you had mentioned--

### Moderator
Claim: Can you tell us your name, please?

### Moderator
Claim: Huh?

### Moderator
Claim: Can you tell us your name, please?

### Moderator
Claim: Oh, Len Galeman I'm from Philadelphia. And, Mr. Feldman, you had mentioned-- you had made a reference to "When does the war end? Does the war end when the president says it ends?" but the fact of the matter is we're dealing with al- Qaeda, we're dealing with radical Islam and other forms of radical Islam, and they say the war will never end because they feel that we are the infidels. So let me ask you something, do you really feel that the end of the war is in America's hands, or is it in the radical Islam's hands?

### Scientific Advocate (SA)
Claim: I deeply appreciate Mr. Galeman-- is that your name--

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: --Mr. Galeman 's question because I think it really captures the tremendous danger of the position that the other side is arguing for and that the administration has adopted.

The United States is not at war with radical Islam or even with jihadi Islam as a matter of law or as a matter of policy, okay? That's not the state of play. Congress did not declare war on all Muslims. I think-- it did not declare war on all radical Muslims. It did not declare war on all jihadi Muslims. It declared war on al-Qaeda and forces who are fighting with al-Qaeda. Now, there is a natural human tendency, and I sometimes share it myself, to think, "Look, one radical jihadi group is a lot like another. They're all kind of similar.” And, in fact, in the world of al-Qaeda, where there's no formal organizational method, you can just start your own jihadi organization, and you can call yourself "al- Qaeda," and there's no one there to stop you. We've actually seen versions of this happening in Syria recently. On the view that the United States can indefinitely fight wars against anybody who dresses himself or herself up in the guise of al-Qaeda, there really will be no end to this.

We will really be in a situation where wherever the president wants to kill someone, anywhere in the world, who happens not to like us very much, it will fall arguably within this same degree of authority. And that's what the problem is. I just want to close by saying-- to that point by saying that we are all busy people, and you didn't come here to listen to a debate about an abstract topic. We're debating a real topic in the real world, and that's what we're debating is what the actual government of the United States is actually doing and its real world policies. That's what's on the table.

### Moderator
Claim: Okay, I'd like to-- are there any women raising their hands? Thank you.

### Moderator
Claim: Thank you, Mary Beth from New Jersey, my question is at what point does a U.S. citizen lose the right to due process?

### Moderator
Claim: Let's put that first to this side who has actually made that point in some detail but to take the opportunity to elaborate.

And either of you can take it, Michael Lewis or Alan Dershowitz. Michael Lewis.

### Conspiracy Advocate (CA)
Claim: I think the answer to that is when they become an operational member of Al-Qaeda. An operational member means you are not just proselytizing, you are not just giving people religious reasons for liking Islam or hating America. You can say, "I hate America" all you want. But when you become an operational member, that means you are making bombs. You are planning attacks. You are carrying out attacks. You are conducting weapons training. You are training others. And you are directing them how to make suicide bets and conduct suicide attacks. How do you build a car bomb, how do you drive a car with 500 pounds of explosives in it effectively. You learn those things, you teach others those things, you are an operational member of Al-Qaeda. And so, this is not a surprise. You don't get off the plane at Heathrow Airport. "Oh, I'm suddenly targetable.” No, you are doing these things. And it's not a surprise to either Anwar Al- Awlaki or Al-Shami-- who is designing IEDs in Pakistan-- IEDs are the biggest, most effective killers of American troops in Afghanistan. That is why he is possibly going to be targeted. It's not a surprise to him--

### Moderator
Claim: Okay. Let me take--

### Conspiracy Advocate (CA)
Claim: --that that's going to happen.

### Moderator
Claim: Same question to the other side. Hina, would you like to take that?

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: Hina Shamsi.

### Scientific Advocate (SA)
Claim: You know, American citizens always have the right to due process. The question is, what does due process look like in a particular circumstance? And when we're talking about an actual armed conflict, people on a battlefield, then due process does not require trial or charges if lethal force is going to be used. When we're talking about an American citizen who is posing an imminent threat, walking down the street waving a gun or some other kind of imminent threat situation-- then, no, due process does not require charge and trial, conviction before anything-- before a death penalty.

### Moderator
Claim: So, you're saying his right to due process is context-sensitive-- context-related?

### Scientific Advocate (SA)
Claim: Well, and-- but--

### Moderator
Claim: To how it's actually--

### Scientific Advocate (SA)
Claim: To these limited circumstances, right?

But what we're talking about here is something that goes far beyond that, which is the claim that a person may be deprived of their due process rights, even when they are far from any battlefield, even when they do not pose an imminent threat, and that the government will not let-- or does not want to let the judiciary test that claim. That is, at heart, one of the most problematic things that is going on.

### Moderator
Claim: Michael Lewis.

### Conspiracy Advocate (CA)
Claim: In other words, he gets to build all the bombs he wants until we get the judiciary to say otherwise.

### Scientific Advocate (SA)
Claim: That--

### Moderator
Claim: Well, let Hina follow and then I'll actually come back to you.

### Scientific Advocate (SA)
Claim: Do you want to ask your question

### Moderator
Claim: I guess my question is, who--

### Moderator
Claim: All right. We need the mike or you won't be--

### Moderator
Claim: Oh, sorry.

### Moderator
Claim: --on the radio.

### Moderator
Claim: Who decides that I'm an imminent threat--

### Moderator
Claim: The executive.

### Moderator
Claim: --okay? It's-- I know-- are you saying that the government has records of these people and they have documentation that I've been building bombs and that I'm a member of this terrorist organization?

### Conspiracy Advocate (CA)
Claim: Well, not only that. They have-- they have--

### Moderator
Claim: Alan Dershowitz.

### Conspiracy Advocate (CA)
Claim: --drones which actually see them doing it. It has to go through about six levels before a targeted assassination is authorized. It has to first go through the intelligence community. They have to have a report. The reason there have been leaks is the President of the United States has apparently refused to accept the recommendation of the killing of this person now who is on the possible hit list. He wants more evidence. He wants more review. He wants more process. Essentially, this administration-- I'm not here defending the administration-- has insisted on essentially an administrative warrant, essentially a multi-layered process. And they have been very, very cautious about when they've done it, how they've done it, and to whom they've done it. That's why there have only been four. When you compare that to how incautious we allow our police often to be in making on the spot decisions about whether to use lethal force against fleeing felons or against hostage-takers, you will see that we're much more cautious about our enemies who are trying to kill us than about American citizens in the United States-- we should not apply a higher standard-- a more difficult standard to people who have as their--

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: --declared goal--

### Moderator
Claim: Can you

### Conspiracy Advocate (CA)
Claim: --to kill as many Americans as possible.

### Moderator
Claim: --so I can get in one more question?

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: Hina Shamsi.

### Scientific Advocate (SA)
Claim: I really want to get at what the heart of this issue is, which is what the administration's policy and what is the legal interpretation standards that they are applying. Evidence-- they're keeping it entirely secret. Apart from naming four U.S. citizens who have been killed, they have not identified any other information on the record to a court where it can be subjected to independent review. That is the heart of due process. The administration's claim is that due process does not equal judicial process. And we could not disagree more. The one other things that I would add is that when you look at the White Paper, which is all we currently know are the standards that the administration is using, it uses the same cases that we have used to the courts, to argue for judicial process.

It uses the same language of due process. It recognizes what is due, but then it radically reinterprets what the courts have said to fit a situation in which the legal constraints, important constraints that the law places to ensure that the people, the government--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --kills really are their--

### Moderator
Claim: I have to interrupt you for this reason. I would like to get in one more question. Can everybody commit, including the questioner, to you pop out a question, 30 seconds, 30 seconds. Can we do that? All right. Pop that question, sir. And just wait for the mike.

### Moderator
Claim: Okay. Larry Nessbaum of Philadelphia. Listen, real quickly, it's a thin blue line to me. I want to understand, let's look back to the Taliban, when we supported them--

### Moderator
Claim: What I-- can you just make a question, if you will.

### Moderator
Claim: What would you do if now we switch allegiances? We're for the Taliban, now we're against the Taliban.

What happens to those Americans who are stuck in the middle when we change allegiances, and we're supporting one country, and Americans are there, and they get killed, and we've switched allegiances? And they're not targeted, but they die.

### Moderator
Claim: Okay. I'm-- I'm going to pass on your question because I think it's a little bit more of a policy question and a little bit more of a statement. And it's interesting and relevant. But, ma'am, down front here. And just wait for that mike to come around.

### Moderator
Claim: Mary Greg, Philadelphia. I'd like a definition of where the battlefield is. Thank you.

### Moderator
Claim: I'm going to pass because they've-- they've defined it a couple of times.

### Moderator
Claim: They have. But where do you see the battlefield now? Where is it?

### Moderator
Claim: All right. Fair enough. This side.

### Scientific Advocate (SA)
Claim: Sure. Right now--

### Moderator
Claim: Hina Shamsi.

### Scientific Advocate (SA)
Claim: --the battlefield exists in Afghanistan and potentially the border regions with Pakistan.

### Conspiracy Advocate (CA)
Claim: So they can get asylum in Yemen. If they just go to Yemen. Aren't you encouraging every al-Qaeda terrorist to leave those two countries and go to places where you say the president can't get them?

### Moderator
Claim: Noah Feldman.

### Scientific Advocate (SA)
Claim: The president can get them, provided their threat is imminent. It's as simple as that.

## Round 3

### Moderator
Claim: And we've circled back, and that concludes-- concludes round two of this Intelligence Squared U.S. debate, where our motion is, the president has Constitutional power to target and kill U.S. citizens abroad. And now we're going to move on to round three. And round three are brief closing statements from each debater in turn that last two minutes. You do these seated. And I just want to remind you that you voted before the debate began, and you're going to vote immediately after these closing statements. And the team whose numbers have moved the most in percentage point terms will be declared our winner. Onto round three, closing statements from each debater in turn. They will be two minutes each. The motion being, the president has Constitutional power to target and kill U.S. citizens abroad. Here to argue in his closing statement, in support of this motion, Michael Lewis, a professor of law at Ohio Northern University, Pettit College of Law.

### Conspiracy Advocate (CA)
Claim: Having flown after hostile territory, I have some appreciation for the restrictions and constraints that our opponents are trying to place on our commander in chief and the armed forces he commands.

You have to remember that every soldier is an extension of the president's war-making power. For me to use my weapons, certain parameters had to be met. And those parameters were established for me by my chain of command which ended with the president of the United States. On missions in which those parameters might be exceeded, provisions were made for me to contact people higher in my chain of command who could give me weapons release authority in situations outside of the narrow discretion I was given in my brief. But according to our opponents, even if I had the president of the United States himself on the line, if my target was an American citizen, or if there was an American citizen amongst the enemies that I was targeting, then he could not give me the authority to release the weapons. We would have to go to the judiciary to ensure that the due process rights of our enemies were not infringed.

And while there may be certain circumstances-- they were talking about, well, how imminent is it if we're talking about al-Awlaki? There may be certain circumstances in which there is time for discussion between the judiciary and the executive branch. But I guarantee you that there are many, many times in which there is not sufficient time for such discussions and deliberations. Justice Jackson famously said that the Constitution is not a suicide pact. But for members of our armed forces, that is precisely what our opponents are trying to make it. Thank you.

### Moderator
Claim: Thank you, Michael Lewis.

The motion, the president has Constitutional power to target and kill U.S. citizens abroad; here to summarize her position against this motion, Hina Shamsi, director of the ACLU National Security Project.

### Scientific Advocate (SA)
Claim: When I started out earlier this evening, I laid out the ways in which both Constitution and international law work together in order for there to be authority to protect us as well as to protect individual liberties.

We talked about the extent to which there is a right to use lethal force and how important it is that that right be constrained. And I remind you that our founders included the due process clause in the Bill of Rights at a time when the very life of the republic was at stake, when it was facing an existential threat. That's not the issue now. But even then, at that time, founders believed that there's some powers that a people should never concede to their government. That's why they included the due process clause, because they thought that extraordinary powers in one office inevitably will be abused no matter who sits behind that desk. That's especially true when we are faced with amorphous terms like "global battlefield," "associated forces," terms that can be subjected to misuse, abuse, regardless of how good the intent of the human being can be.

The basic proposition before you today is that the president can carry out a targeted killing of a person, including American citizens, without due process, without ever presenting that evidence to a court. The executive has that power even with respect to a 16-year-old who is killed far from any battlefield. That is quite simply not the law. The president has gone beyond what the Constitution and international law permits him to do. We ask you to vote against the proposition in order to start reining back the kinds of powers that have been so dangerously assumed and asserted today.

### Moderator
Claim: Thank you, Hina Shamsi. Our motion, the president has Constitutional power to target and kill U.S. citizens abroad, here summarizing his position in favor of this motion, Alan Dershowitz, the Felix Frankfurter professor of law at Harvard Law School.

### Conspiracy Advocate (CA)
Claim: I think that our opponents have essentially conceded the motion. The president does have Constitutional power to target and kill U.S. citizens abroad they concede, if it's on the battlefield, if it's imminent, and they don't distinguish between Americans and non- Americans. That, it seems to me, essentially concedes the proposition and imposes some limitations on it. They throw out some red herrings like a 16-year-old. Nobody ever targeted a 16-year-old. That 16-year-old was tragically and accidentally killed the way 16-year-olds are tragically and accidentally killed on battlefields, and in all aspects of war and the way they're killed by terrorists.

Look, I love the Constitution. I have devoted my life to defending civil liberties and the Constitution. I, too, was on the national board of the ACLU. I'm here today to defend civil liberties.

The civil liberties of noncombatants, all noncombatants, whether Americans or non- Americans, I believe in a living Constitution which adapts to changing times. I fear that if the president's ability to defend us against terrorist attacks, even those committed by American citizens is placed within an unrealistic straight jacket, grave damage will be done to our Constitution and to the international laws of war that distinguish between civilians and combatants, not between Americans and others. The Constitution is a living document that permits every generation of Americans to strike the appropriate balance between protecting our civilians and living within the rule of law. We can do both. We can do both as long as we adapt to new realities such as the fact that terrorist groups operate all over the world and operate within civilian areas. We must adapt. Allowing the president to employ these drone strikes will strike that proper balance.

So in the name of the Constitution, in the name of civil liberties and human rights and common sense, I urge you to vote yes.

### Moderator
Claim: Thank you, Alan Dershowitz. The motion, the president has Constitutional power to target and kill U.S. citizens abroad, here to summarize his position against this motion, Noah Feldman, the Bemis professor of international law at Harvard Law School.

### Scientific Advocate (SA)
Claim: I really love debating. And this has been a really fun debate. And arguments have been terrific on all sides. But the stakes of your vote and the stakes of this debate are a little different than they would be for almost any other kind of debate that Intelligence Squared could put together. And I want so just say why that is. In the real world, the way that drone strikes are now used, is that an administration-- it could be Democratic or Republican-- leaks to the press that it plans to target and kill a particular American somewhere in the world.

Last time it was Yemen, this time in process it's Pakistan. Now, that leaves that person a choice. And in the case of the Yemen example, that person through his father actually came to a U.S. court and said, "Hey, I'd like to be heard. You got the wrong guy. I'm a propagandist. I don't like America very much. But I'm exercising my free speech rights." And the executive branch said to the courts, "Don't hear this case." They used a bunch of reasons, but one of them was, "It's a secret whether we're targeting him or not." This was after they had leaked it. Then they killed him. And then they said, "Well, you definitely don't get review after the fact," right? "Oh, and, by the way, we did kill him," so it wasn't apparently that much of a secret after he was dead or when it was leaked in the first place.

Now, we're in the midst of one of these processes right now. Now, we could speculate about why the government does it this way nowadays.

One possibility is that they've got a bad conscience about whether this is really imminent under their own legal definition. But I'll tell you this, and I'm really not joking, when they're running something up the flagpole to see who salutes, they're trying to see how you, not "you" in the abstract, "you, the particular people in this room" will vote on this question. How you vote will be noticed. It will be a component of a real world process at the end of which someone will live or die. And on that basis I urge you to vote, "No."

### Moderator
Claim: Thank you, Noah Feldman. And that concludes closing statements. And now it's time to learn which side you have been persuaded by or not. We're going to ask you again to go to the keypad at your seat and look again at this motion and its language and the two teams that have argued for and against it, "The president has Constitutional power to target and kill U.S. citizens abroad." If you now support this motion, push number one. If you are against this motion, push number two. And if you became or remain undecided, push number three.

I'll let another 10 seconds go by to lock that out, and it will take us about a minute and a half to get the results back to you. And while that is happening, a few things I would like to say, one is what a pleasure it has been to be hosted here today by the NCC, and, you know, the comments that Noah Feldman said about seeing Independence Hall and the references to the history, I mean, it really felt tonight as we were having this Constitutional debate that we could feel the vibrations of history coming through the floor. It was spectacular to be here, and it was an honor to be the guest of Jeffrey Rosen and the National Constitution Center. Thanks so much for having us. This program was also supported in part by the Daniel Berger Esquire, Programming Fund for the National Constitution Center. Our thanks as well to the fund. We would love to have you Tweet about this debate. You can use the Twitter handle, @iq2us, and the hashtag POTUSdebate. Our next debate is going to be at the Kauffman Center in New York next week. The motion is-- and I'll tell you, we planned this one six months ago-- the motion is, "Russia is a marginal power." So if you can make it up to New York, please do that. The other thing I want to say is that the mission of Intelligence Squared is to-- the name is in the title partially, and it's to raise the level of public discourse. And that happened in two ways. The first way is the spirit of intellectual engagement, honesty, and respect for one another that all of these debaters brought to the stage. I would really like to thank them for the way that you all handled this debate. And the second thing I want to say is that very often the audience Q&A thing can be very tough in New York and getting it all to work out. This audience was spectacular, and I heard you. And even the questions that I passed on, I think they were excellent.

They were just a little bit off point, but I want to thank everybody who got up and asked a question. And thank you, all, for the way that you participated in this debate tonight. So, all right, it's all in now. I have been given the results. Remember, the team that has changed the most votes in percentage point terms will be declared our winner. The motion is this, "The president has Constitutional power to target and kill U.S. citizens abroad." When we have announced the winner, you may feel free to congratulate them with your applause. The first vote, 29 percent were for the motion, 44 percent were against, and 27 percent were undecided. So those are the first results. Remember, you voted a second time. The winner is the team that has changed its numbers the most from the first vote to the second. So here is the second vote.

The team arguing for the motion, their second vote was 54 percent. That's 29 to 54 percent, 25 percentage points, which is the number to beat. The team against the motion, their first vote, 44 percent, their second vote, 39 percent. They went down five percent. That means the team arguing for this motion has prevailed, with the motion being "The President Has Constitutional Power To Target And Kill U.S. Citizens Abroad." Our congratulations to them, and thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
