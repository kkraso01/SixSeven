# Debate Transcript

Topic: Flexing America's Muscles In The Middle East Will Make Things Worse
Motion: Flexing America's Muscles In The Middle East Will Make Things Worse

Debate ID: 093014%20Middle%20East


## Round 1

### Moderator
Claim: And I want to introduce the gentleman who has brought this program to the stage and has produced now almost 100 Intelligence Squared Debates. We're in the high 90s. So, please welcome the Chairman of Intelligence Squared U.S., Mr. Bob Rosenkranz.

So, Bob and I always take a couple of minutes to talk ahead of time just a little bit about why we've chosen this debate and a little bit about the timing. And just in terms of timing-- and we plan these several months in advance. But talk to me about where we, you know, where we are on the timing of this one now.

### Moderator
Claim: Well, the timing of this-- I mean, we couldn't have a more timely debate. When you have Americans having their heads cut off on video and showed on television, it just so demands a response that the timing is just incredible.

### Moderator
Claim: And the response is obviously forward-looking. But how much are we actually here, in trying to wrestle with this topic, going to be talking about history?

### Moderator
Claim: Well, I think both sides have a fair amount of history to bring to the table. I mean, there's plenty of history of muscle-flexing, by which we mean military action, that have produced terrible and unintended consequences. And there are also plenty of examples of inaction that have produced pretty bad consequences, too. So, both sides are going to have a fair amount of history to cite tonight.

### Moderator
Claim: And as you say, for clarification, what we're talking about when we're talking about muscle-flexing, we are talking about the use of military force, the use of American might. It could be broader than that, but for the sake of clarity, we're focusing on that. And to the degree that they both now are going to be making historical arguments, well, what do they need to nail-- to really nail down in order to persuade this audience to vote with them?

### Moderator
Claim: Well, I think one of the debaters that we had on the middle east last year, Graham Allison at Harvard, set out a kind of set of criteria or ways of thinking about foreign policy challenges that I think, if we keep in mind tonight, we're going to have as a good guide to listening to tonight's debate. The first question really is what happens? What is happening? What's actually going on? The second question is, why does it matter? The third question is, it may matter, but how does it rank in importance versus all of the other things out there that matter as claims on our attention, on our resources, and our political will. The fourth question is, what are the risks of inaction, of doing nothing? The fifth question is, what courses of action are actually open to us and available?

And the final question is to try to evaluate those courses of action in terms of their risks, in terms of their costs, and in terms of their benefits, and to see if any of them meet the bar of being better than a course of inaction, given an understanding of all of those other points.

### Moderator
Claim: So, they all seem to shape around this question of action versus inaction, which I think is the crux of what we're going to be talking about tonight. So, Bob Rosenkranz, thank you very much for the warm-up. And let's please welcome our debaters to the stage.

### Moderator
Claim: Thank you, John.

### Moderator
Claim: You guys do very good applause. That was excellent. I just want to ask for one more round of applause for Bob Rosenkranz. Once upon a time, the U.S. had it all worked out. Speak softly and carry a big stick. As we all learned in the seventh grade, those were the words of Teddy Roosevelt. His wise approach to the world. There was just one thing about it, and that was about the big stick. He didn't say how big it should be and how fast we should swing it and at who and how often. And those are questions that are bedeviling the United States right now. When they're cutting off the heads of Americans in a Middle East that is in a spin cycle of disintegration. And what is the U.S. supposed to do about this, and with its big stick, which is the strongest military on earth, run away, get more deeply involved, stay on the sidelines? And how is that "speaking softly" thing really working out? Well, this sounds like the makings of a debate, so let's have it. Yes or no to this statement: Flexing America's muscles in the Middle East will make things worse, a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufman Music Center in New York City.

We have four superbly qualified debaters, two against two, who will argue for and against this motion: Flexing America's muscles in the Middle East will make things worse. As always, our debate goes in three rounds, and then you, our live audience here in New York, votes to choose the winner. And only one side wins. Our motion, flexing America's muscles in the Middle East will make things worse. Let's meet the team arguing for the motion. Please, ladies and gentlemen, first welcome Aaron David Miller.

And, Aaron David Miller, you are at the Wilson Center. You served for two decades at the Department of State helping formulate U.S. policy on the Middle East and the Arab- Israeli peace process, an aspiring peace maker.

In 1990, though, you were working with Secretary of State James Baker who said to you, rather famously, "Aaron, if I had another life, I would want to be a Middle East specialist just like you because it would mean guaranteed permanent employment." Was he right about that?

### Conspiracy Advocate (CA)
Claim: Baker-- Baker was one smart guy. He had no idea just how right he was.

### Moderator
Claim: All right, thanks, Aaron David Miller.

And, Aaron, your partner is?

### Conspiracy Advocate (CA)
Claim: Paul Pillar.

### Moderator
Claim: Ladies and gentlemen, please welcome Paul Pillar.

Paul, welcome. And you are also arguing for the motion, flexing America's muscles in the Middle East will make things worse. You are a senior fellow at the Center for Security Studies at Georgetown. Twenty-eight years as an analyst at the CIA. During the last five years as national intelligence officer, specializing in the Near East and South Africa. You once said an interesting thing, that, in major foreign policy decisions, though you were at the CIA, you said, "Intelligence is not the decisive factor. It's actually something about the leader himself, his own strategic sense, his lessons from history, his personal experience, even his personal neuroses."Is that true for President Obama?

### Conspiracy Advocate (CA)
Claim: Well, the president hasn't invited me to the White House for one of those chats over a beer to talk it over, but like all of our other presidents, he's a human being, and he's a political annual too, and so the answer, John, is yes.

### Moderator
Claim: All right. Thank you, Paul Pillar.

I just got a note in my ear that I said something wrong about Paul? What was it? Did I say South Africa? Let me just pretend that I didn't say any of that, and I'm just going to read it so that it can be edited-- wouldn't it be great for everybody if life was like this?

You just rewind, and all of your mistakes went away. Well, I get to do it. Very briefly. I'm just going to say this: Specializing in the northeast-- specializing in the--

Specializing in the Near East and South Asia.

Thank you for your patience.

It's so embarrassing. The only way to be-- to handle the embarrassment is to pretend I'm not embarrassed at all. Our motion is this: Flexing America's muscles in the Middle East will make things worse. And we have two teams arguing against the motion. Please, folks, let's welcome Michael Doran.

Michael, you're a senior fellow at the Brookings Institute. And prior to that, you were professor at Princeton. You also served as deputy assistant secretary of defense in public diplomacy. You were a senior director for the Near East and North Africa at the National Security Council. And we were listening to a recent interview you gave where you actually advised people not to take up Middle Eastern studies. Why is that?

### Scientific Advocate (SA)
Claim: Because it's so contentious that if you say anything serious you'll be deeply hated. So you have a choice between being boring and anodyne and liked or serious and hated.

### Moderator
Claim: But you're not going to be boring and anodyne.

### Scientific Advocate (SA)
Claim: I'm going to be-- I'm going to be anodyne and loved.

### Moderator
Claim: All right. Thanks very much. Mike Doran, ladies and gentlemen.

And, Mike, your partner is?

### Scientific Advocate (SA)
Claim: My partner is Wall Street Journal and Pulitzer prize-winning columnist, Bret Stephens.

### Moderator
Claim: Bret Stephens, ladies and gentlemen. Bret, you are also arguing against the motion, flexing America's muscles in the Middle East will make things worse. You're-- your background has just been described, so I'm going to skip straight to your first book, which was called "America in Retreat: The New Isolationism and the Coming Global Disorder" coming out in November. And Joe Lieberman said of this book, "It's worth buying even if you only read chapter 9." What's in chapter 9?

### Scientific Advocate (SA)
Claim: Well, the other nine chapters are terrific, but in chapter 9--

--you get the world as I see it in 2019 when Hillary Clinton is president and wondering why she ever wanted that job in the first place.

### Moderator
Claim: So it's a-- it's a prophetic novel?

### Scientific Advocate (SA)
Claim: We'll see.

### Moderator
Claim: All right. I guess not. Thanks very much. This is the team arguing against the motion.

So, I want to remind you, this is a debate. It's a contest. And one team will win, and one team will lose. And that decision will be made by you, our live audience, by your vote, both before you hear the arguments and again afterwards. And the team whose numbers have changed the most in percentage point terms will be declared our winner. So, let's get on to the preliminary vote. If you go to those key pads at your seat on the right hand side, there are a lot of keys on them, but you only need to pay attention to 1, 2 and 3.

Push number 1 if you agree with the motion at this point that this side's arguing for; and push number 2 if you disagree with the motion, this side; and push number 3 if you're undecided, which is a perfectly honorable position. You can ignore the other keys. They're not live. And if you feel you made an error, just correct yourself, and it'll lock in your last vote. And we'll take about another 10 seconds. Then at the end of the debate, we do the same thing, and we get the results in about a minute, minute and a half, something like that. They'll be carried out to me, and I will announce them, and I will announce our winner. Okay. Onto round one. Round one, are opening statements by each debater in turn. They are uninterrupted. They are seven minutes each. Here to speak first for the motion and making his way to the lectern, Paul Pillar. He's a nonresident senior fellow at the Center for Security Studies at Georgetown University and at the Brookings Institution. He served 28 years in the U.S. intelligence community.

He is here to argue for the motion, flexing America's muscles in the Middle East will make things worse. Ladies and gentlemen, Paul Pillar.

### Conspiracy Advocate (CA)
Claim: Thank you, John. Flexing muscles, that sounds like posturing, doesn't it? And posturing doesn't sound like a very good way to conduct foreign policy. It's not. But, look, we know what this motion is all about. It's about the use of the most salient form of muscle the U.S. has, and that's military force. And so that's what Aaron and I are going to talk about. We're not pacifists. The military instrument has a legitimate role, carefully used in certain times and places. But unless we carefully consider all the costs and risks and limitations and consequences and reactions to our use of military force, it can, and unfortunately very often in the past has, made things worse. Now, Aaron's going to talk later about some of the specific issues we've got facing us in the Middle East.

I want to start by talking about how we ought to think about this question. We hear a lot of "if only" kind of arguments: "If only we used force here or used more force," or "if only we had used more force or put our troops in here or there, something better would happen." Lots of speculation, lots of counterfactuals. We don't have to dwell just with speculation and counterfactuals. We have a real record out there of having done a lot of application of military force in this region. Data point number one-- in fact, there's a whole string of data points-- was, of course, the invasion of Iraq, which extended an expedition for another eight and a half years. That made things a lot worse for the United States, considering the trillion dollars of cost and the casualties and everything else. It made things worse for the region because it was a negative example of the so- called birth pangs of democracy and because it stimulated the kinds of sectarian conflict and consciousness we see in Syria and elsewhere.

And it was certainly bad for Iraq which-- where it touched off a civil war that has never ended and also gave rise to various forms of extremism. That group ISIS, or Islamic States, or ISIL, or whatever you want to call it that we're so worried about today, it was born under a different name as a direct response to our invasion of Iraq and the civil war it touched off. ISIL did not exist before we went into Iraq. And to talk about Iraq in the past is not just dwelling in the past, it raises the very issues which Aaron will go into more that we're still facing today. Now, one thing you hear often in the sort of "if only" category is "If only we had somehow kept troops there beyond the eight and a half years, that somehow things would have worked out differently."Now, set aside the question of how that could have been done when we had an Iraqi government that was determined to get us out and the previous administration under Mr. Bush was the one that set the withdrawal deadline. But the fact is we did try to up the ante militarily. We had the so-called surge. You remember that? And it, along with some other factors, like disillusionment with the extremists among Iraqi-Sunni Arabs, temporarily brought down the level of violence. But the surge failed in its more fundamental political objective of providing the space for Iraqi politicians to reach an accommodation and build a new and more stable Iraqi political order. They never did that, and we have the mess that we see today in Iraq. And anyone who thinks otherwise I think has to answer the question: If eight and a half years were not enough, then how many years would be enough? Let me just mention one other thing in the past briefly, because it comes under a different administration: the intervention in Libya. Now, there you already have a civil war going, but we used force to help overthrow Gaddafi, and look at the mess that Libya's in now.

About the closest thing we have in the region to it, total anarchy. And I might remind you, whatever you might have thought of the late Mr. Gaddafi, years before any use of force or even threatening the use of force, he got out of the international terrorism business and he gave up his unconventional weapons programs, leaving him as a sort of quaint and curious dictator, but, frankly, not much of a threat to U.S. interests. So, what's going on here? Why do we have these unfortunate results? Well, I think there are several patterns that we've seen again and again. One is military force is good to accomplish a lot of things. It's pretty poor to accomplish a lot of other things. The U.S. military's a great hammer, but some of the thorniest problems we've got in the Middle East simply are not nails. Building political and social order is not primarily a matter of killing people. One's a matter of construction. The other's a matter of destruction. What has mattered again and again in places like Syria and Iraq and Libya and elsewhere is political will and political culture and the will to reach political accommodation.

And that can't be injected through the barrel of a gun. Closely related to that is the principle that we need the people in the region and the players in the region to become owners of any solution. If it's just outsiders, whether it's the United States or someone else, then whatever good effect may be brought about, as long as we've got the strength there, like we had 168,000 troops at one point in Iraq, is not going to last, just like the benefits of the surge didn't last. Another thing that's happened when we flexed our muscle in this way in the Middle East is the United States has been taking sides in someone else's internal conflict, which in that part of the world is often defined in sectarian or ethnic terms. And that's no good either. It's an invitation for the other side to get more involved. And for the United States, we have no interest-- no national interest-- in taking sides in someone's sectarian civil war.

And finally, again and again, we see our use of our muscle engendering the reaction of hatred and anti-Americanism and extremism and terrorism, partly because of the inevitable collateral damage, partly because we're who we are, the superpower, hated, because we come in with our boots trampling on someone else's ground. So, again and again, we see the reaction, including when Osama bin Laden was initially radicalized as a result of U.S. troops going into Saudi Arabia, or when ISIS was born after we went into Iraq, or today when ISIS is committing those grisly murders and justifying it by saying it's in response to something we've done. So, the Middle East is a pretty messy place. It can get messier.

And to prevent us from making it even messier, we have to ask not what we would hope would happen or wish would happen with the application of military force, but to look at what we've done in the past and how often it has, in fact, made things worse. Thank you.

### Moderator
Claim: Thank you, Paul Pillar. And that's our motion, "Flexing America’s Muscles in the Middle East Will Make Things Worse.” And our next debater will be speaking against the motion. I'd like to welcome to the lectern Bret Stephens. He is a Deputy Editorial Page Editor and Foreign Affairs Columnist for the Wall Street Journal, and author of the forthcoming book, “America in Retreat: The New Isolationism and the Coming Global Disorder”. Please welcome Bret Stephens.

### Scientific Advocate (SA)
Claim: Well thank you, John. It's an honor-- and I want to say this with real sincerity-- to be debating two very distinguished public servants, each of whom has done a lot for this country. How distinguished, you might ask?

So distinguished that they are prepared to take an intellectual bullet tonight-- if not for their country, then for this audience-- in order to defend an implausible, illogical, and frankly nonsensical proposition that neither of them can possibly believe is true. The proposition we are debating this evening is this: flexing America's muscles in the Middle East will make things worse, by which we mean, intervening militarily. Notice that it falls to Paul and Aaron to defend that statement categorically-- no exceptions. They must convince you that, no matter what the circumstance, U.S. military intervention in the Middle East cannot be the answer. But also notice this: Michael and I are not arguing the opposite case. We are not saying, “Bomb every time and everything.” We are not saying, “Whatever the question, war is the answer.” This is a caricature position, and all of you in this room are, frankly, too smart for that. Right? What we are saying is that, in the Middle East, as in the world, as in life itself, you take it on a case-by-case basis. You look at the circumstances. You distinguish between the preferable and the necessary; the merely important versus the absolutely vital. What we are arguing is not dogma and not absolutism. We are arguing the case for pragmatism. Ladies and gentlemen, ask yourselves this: If you were the president and you were in a position to use force to prevent the massacre by ISIS of the Yazidi people, would you authorize force? Would you do what Barack Obama did? Would you send flights of F18s to relieve the siege of Sinjar mountain? Or would that simply have made things worse?

When the other week, tens of thousands of Kurds faced death at the hands of ISIS, would you have used air power, as President Obama did, to help them get to safety? Or would you have left them to their own devices? Would military force in that circumstance make things worse? Ladies and gentlemen, if you had been George H. W. Bush in the spring of 1991 when Saddam Hussein was besieging the Kurds in northern Iraq, would you have launched Operation Provide Comfort to save them? Or did that just make things worse? Now, I know what you're thinking, and I know what they're going to say: These aren't really military interventions. They're quasi-humanitarian rescue efforts. But that's not true. When bombs are being dropped, that's not humanitarian work. American fighter pilots are not NGO workers. GPS-guided bombs are not care packages.

All of this is an example of flexing America's muscles; of using the American military in the service of a good cause. So, the question before you tonight is, are you for it, at least occasionally? Or are you against it in every circumstance? Now, let's take another example: when Saddam Hussein invaded Kuwait in the summer of 1990, and George H. W. Bush said this aggression will not stand. Was he wrong to oppose it? Would the world have been a better place if Saddam had simply swallowed Kuwait whole? Is that the kind of world that you want to live in? Maybe if you're Vladimir Putin, that's the world you would like to live in. But I'm asking you, the audience. Aren't we better off that that aggression was opposed, just as Bill Clinton opposed Serbian aggression in Bosnia and Kosovo? Now, we remember the 1990s as this halcyon period for America, and indeed it was.

And it was a great period because the world understood the U.S. was prepared to enforce the rules of international order with force when those rules were flagrantly violated by tin-pot dictators with genocidal tendencies. Now, you heard from Paul, and soon you're going to hear from Aaron. And they will tell you, “Yes, but what about the intervention in Lebanon in 1983, and how did that turn out? And what about Iraq, as Paul just mentioned, and Afghanistan, and maybe the prospect of bombing Iran in the event that nuclear negotiations go nowhere?” Let me make two points about this. Noting that military interventions and wars can go horribly wrong is not an argument in this debate. It is totally beside the point. World War I may have been totally pointless, but World War II was not pointless. Like everything in life, there are just wars and unjust wars, smart wars and dumb wars, smart wars that are badly executed and dumb wars that are well executed.

And the second point is this: Telling us that actions have consequences, particularly unintended consequences, tells us nothing about the consequences of inaction, because what we are seeing today, contrary to what Paul just mentioned, in the Middle East-- the near collapse of the Iraqi government; mass executions; the fall of cities like Mosul, Tikrit and Fallujah; the vortex in Syria; the progressive radicalization of the Syrian opposition to the point that even al-Qaeda isn't radical enough; the beheading of journalists; millions of refugees straining the resources of Lebanon and Jordan and Turkey-- all this is not the consequence of flexing America's muscles. It is a consequence of a presidential decision in the last four years not to flex those muscles.

Each of us, in our everyday lives, know that every action carries risks, but there is also a price to be paid when we do nothing, when you don't make the phone call, when you don't challenge your colleague, when you don't make the move to another job.

Foreign policy is not that different. Ladies and gentlemen, it would be nice to live in a world where the best policy is to do nothing, to look away, to always choose the peaceful route, to offer kindness and get kindness in return, to always take the diplomatic option. But you and I and they don't live in that world. We live in the world as it is, not the one we'd like to pretend it to be. And in that world, as it is, you sometimes need to flex your muscles, prudently, discriminately, effectively, yes. But to choose simply never to exercise those muscles at all is an absurd motion. I urge you to reject it. Thank you.

### Moderator
Claim: Thank you, Bret Stephens.

And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two against two, arguing it out over this motion: Flexing America's muscles in the Middle East will make things worse.

You have heard from the first two debaters, and now onto the third. I'd like to welcome Aaron David Miller. He is vice president for New Initiatives at the Wilson Center. He served in the Department of State for two decades and has a new book out next week, "The End of Greatness: Why America Can't Have and Doesn't Want Another Great President." He's debating for the motion: Flexing America's muscles in the Middle East will make things worse. Ladies and gentlemen, Aaron David Miller.

### Conspiracy Advocate (CA)
Claim: John, thank you very much. It's an honor and privilege to be here. It's an honor to debate Mike and Bret, friendly but formidable opponents, and it's wonderful to be here with Paul Pillar who brings a measure of honesty and clarity to this debate, sometimes controversial, but it is sorely needed. I really do find myself, unfortunately, sadly, paradoxically, in the anomalous position of agreeing with almost everything Bret said.

And at the risk of never being invited back to IQ2-- I have to say at the outset that this is a national conversation that is simply too important to be constrained and confined to simple propositions. I will defend the proposition, but the nuance is clear. And Bret made the case, and that is to say there is smart muscle flexing-- the effective application, formidable application of American military power-- and there is dumb muscle flexing. And that anomaly, that inconsistency, has to be reflected not just in the debate but in the actual execution of policy. If the application of American military power had always been smart, we wouldn't be having these conversations, and I'd be applauding Michael and Bret for everything that they've said in their compelling arguments, nor would I have ever agreed to debate and argue for the proposition.

But sadly, that has not been the case. Muscle flexing has, on balance, in my judgment, as my inestimable partner, Paul Pillar, has mentioned, it's messy, and it's, for the United States, been on balance a very unhappy enterprise. And it is likely to remain unhappy as well. This is not to say-- and I want to repeat this for my own personal credibility and what remains of my professional reputation-- The reality is that the application of military power can be effective, can be appropriate. Bush 41, for whom I worked, pushing Saddam out of Kuwait. Go read Baker's memoir of why Bush didn't continue that operation to Baghdad. Read Baker's prescient memoir about the risks, the limitations, and the constraints. Bush 43's application of military power in Afghanistan, air power, local allies, good intel, managed in a manner of months to defeat al-Qaeda and to decimate the Taliban, at least for the moment.

But in recent years, I would argue to you, respectfully and humbly, we have not been nearly as effective as in years past. In fact, I would argue that the U.S. is like some modern-day Gulliver, wandering around in a part of the world that it does not understand, constrained by its own illusions, by smaller powers whose interests are not its own all the time. And in search of Hollywood endings to a region that is broken, angry, and dysfunctional, and offers up not solutions and definitive outcomes at all, but just outcomes. And do not let our debating opponents try to persuade you that this is a Republican issue or a Democratic issue. I worked for Rs and Ds. I voted for Rs and Ds. And I can tell you, with some authority, that muscle flexing, dumb muscle flexing, is a bipartisan-- as well as equal opportunity employer.

Twain quipped, and he was right, famously, that history does not repeat-- it does not repeat. History rhymes. And it's the rhythmic patterns that you need to pay attention to when it comes to smart application of American military power. Let me identify four, perhaps five, cautionary tales with respect to why you need to support our rendition of this emotion-- of this motion. Number one: There is muscle flexing as overreach. Paul has referred to Iraq, what I call-- not to trivialize the men and women who served, who died, and who suffered life-crippling injuries from which they will never, ever recover. This turned out to be, in my judgment, with all due respect, a trillion dollar social science experiment that fundamentally failed.

It caused 6,000 Americans dead, trillions expended, most of our credibility in tatters. And for what? A standard of victory was not, could we win, but when could we leave? And extrication is not a metric that you want to use to judge the performance of the most consequential power on earth. That's muscle flexing as overreach. Then you have muscle flexing as bluster. That is to say, talk without action. And I would argue, even though I have supported the president's willful refusal to militarize the American role in Syria in order to defeat Assad-- ISIS is a different story now-- that was an example of talk without action. That is dumb muscle flexing because it erodes and undermines credibility. Presidential rhetoric has to be rooted in reality. If you say it, you've got to mean it, and you have to follow through. Then we have what I call one-off muscle flexing. That's Libya.

That's where we and NATO took eight months to take care of Colonel Q, but without much regard or thought to the implications of what would come next. And we lost the first sitting ambassador since 1979, Chris Stevens, as a consequence. Fourth, there is split-the-difference muscle flexing. I support the president's strategy in Syria, but it is replete with anomalies and contradiction that are going to be extremely difficult to maintain. We strike ISIS, we essentially empower Assad. We try to take out Assad, we leave the field open to ISIS. Caliphates in Damascus, with Baghdad next. And fifth-- and this is why this is deadly serious. What is happening tonight, this conversation is not some sort of academic exercise. The mother of all military interventions may be not far away.

If negotiations do not produce a comprehensive accord, if sanctions do not work with respect to the mullahs in Tehran, if the mullahs accelerate their program, this president has set his own red line. He will not allow Iran to acquire a nuclear weapon. We have committed ourselves to the Israelis repeatedly over the last several years not to preempt, we will do it for them. So I urge you when you vote, think about the consequences and implications, both for and against, of the application of military power. Let me conclude by simply saying neither this administration that has been risk averse or the last one that has been too risk ready has got it right. The next time we apply military force, we need to think through how, why, and where.

### Moderator
Claim: All right, Aaron David Miller, I'm sorry your time is up. Thank you very much. And that is our motion, "Flexing America’s Muscles in the Middle East Will Make Things Worse." And our final opening statement will be against this motion, like to welcome Mike Doran. He's a senior fellow in the Center for Middle East Policy at the Brookings Institution.

He served as senior director for the Near East and North Africa at the National Security Council. Please welcome Mike Doran.

### Scientific Advocate (SA)
Claim: Thank you, John. And thank all of you for coming. It's a great pleasure to be here. It's an honor. It truly is an honor to be debating Aaron and Paul and to be on the same team with somebody as talented and silver tongued as Bret Stephens. Handsome. Handsome, silver tongued, and talented. I thought that what Aaron just said was very wise and very gracious. I noted, as you did, that he accepted our victory. He agreed with everything that Bret said. And so I would very graciously like, in complete reciprocity and the spirit of reciprocity, I accept your admission of defeat.

And I accept your challenge to discuss this in terms other than the motion. Look, it's true that we have to have wise use of force as opposed to dumb use of force. I think we can all agree to that. If we're going to say though, as I think Paul and Aaron are, that we need to have a kind of bias in favor of restraint, then you're saying one of two things. You're saying that action is either going to-- military action is either going to destroy some beneficial process that is ongoing, or you're saying that it is going to generate some new bad process that doesn't exist.

And I think that, that proposition, the proposition basically that Paul laid out, is the one that President Obama accepted when he took office in 2009 and he made policy toward the Middle East-- from 2009 up until yesterday or a couple of weeks ago-- on the basis that restraint is almost always better than the use of military action. And I look at the last five years as a kind of referendum on that proposition, and I think it comes up, and it comes up faulty. And I'd like to explain to you why. So, what did we see over the last five years? We saw, first of all, in Iraq, we saw the Maliki government become increasingly sectarian, increasingly dependent on Iraq, and increasingly dictatorial. And it alienated the Sunni Arabs living in al-Anbar Province and in the north. Now, Paul said that the surge did not stop the civil war, it just lowered the violence a little bit.

It's not true. It's not true. The surge created a political space that Maliki could have used to have created a more inclusive government. It needed, though-- that process needed continued American pressure, which the Obama administration would not apply. And so David Petraeus handed to the Obama administration and he handed to Maliki an opportunity that was lost. Now, that's what was happening in Iraq, so the civil war started up again in a vicious sectarian fashion, alienated the Sunnis. Meanwhile in Syria another civil war started, which had nothing to do whatsoever with the application of American force. It started completely as a result of indigenous processes. But there, too, we have a sectarian Shiite government aligned with Iran that is destroying Sunnis. Now, think about the extent of the destruction in Syria.

Syria's a country of around 20 million people. Nine million of them, possibly even 10 million of them are now displaced. That's almost half the entire population of the country has been displaced. Three million of them have been driven out of Syria and are now refugees in the surrounding countries and risking to destabilize those countries. Let's not even mention the systematic rape, the torture, the dropping of bombs onto breadlines as women and children wait to buy bread, by the Assad regime and supported by Iran. So, if you want to say that using military force is going to stop some kind of beneficial process that is ongoing, you can't make the argument, because if you look at what's happening, the Middle East is spiraling out of control.

And that's why President Obama finally had to apply force, because there was this process spiraling out at full force. Now, back in 2012, his National Security Council went to him and said, “You have to apply force. You have to arm the Syrian opposition.” This was David Patraeus, Hillary Clinton, Leon Panetta, and so forth. And President Obama said, “No, I won't do it.” Now, at the same time that this argument was going on, Sarah Palin was asked what she thought about this. Sarah Palin-- the war was going on and she was asked, “Should we arm the Syrian opposition like the National Security Council wants to?” And she said, “No.” She said, “My answer is, let Allah sort them out, right? Let the Sunnis and Shiites kill each other.” Now, that is basically the policy that President Obama followed. He didn't call it that, but that's what he did. He let Allah sort it out. That is the policy that Paul Pillar and Aaron David Miller are calling for. They're saying, “Let Allah sort it out”-- the Sarah Palin Doctrine.

We know-- We now know that the Sarah Palin strategy does not work. It does not work. We have to use military power. And we have to use military power. Now, Paul Pillar said something interesting. He said, “You cannot-- you can't make people increase their will by use of military force.” This is patently not true. The fact of the matter is that what we have in the Middle East are countries run by mafias, basically, or organizations like ISIS that are first and foremost mafia organizations. If somebody goes to the United States and beheads its citizens on television and the United States says, “I'm not going to do anything,” it sends a message to all of our allies in the region that if we're not going to go take action when our citizens are beheaded, we're certainly not going to come help them.

And that encourages them to go and cut a deal with the mafia rather than showing the will to fight. If we don't put skin in the game-- and skin in the game means military force-- then we will not-- then we will undermine the will of our allies whom we need. Thank you.

## Round 2

### Moderator
Claim: Thank you, Michael Doran. And that concludes Round 1 of this Intelligence Squared U.S. Debate, where our motion is Flexing America's Muscles in the Middle East Will Make Things Worse. So, remember how you voted when the evening began. And we're going to have you vote again after the debate concludes. And once again, I want to emphasize that the team whose numbers have moved the most in percentage point terms will be declared our winner. Now onto Round 2 of this Intelligence Squared U.S. Debate where our motion is Flexing America's Muscles in the Middle East Will Make Things Worse. We have heard from each of the teams now-- two teams of two. The team arguing for the motion, Paul Pillar and Aaron David Miller, made a presentation in which they said they are not against all use of force all of the timeThey are against the use of force in a dumb way, that force has a downside, and that downside is unintended consequences that have costs. They ran through situations in history where this has already occurred, most recently Iraq and, in 2003, a situation they said that gave us ISIS. They point out that once the U.S. gets into the Middle East militarily, then it's in a situation of taking sides. And that doesn't win us friends, it produces anti-American sentiment and it ends up having the United States pushed around by small time dictators. The team arguing against the motion, Michael Doran and Bret Stephens, argue themselves. They say that inaction also has unintended consequences. And they say, also, that that has been seen in the disintegration of Iraq and in the creation of ISIS. Their argument is that a U.S. that is seen to be passive looks weak. It's an invitation to rogue states to act even more roguely.

They blame-- they basically say that the argument that restraint most of the time is the right option is actually the wrong option. And they also make a case based on history. So, what I'm finding-- there's a worrying amount of agreement between the two sides here on the-- on the basic--

### Moderator
Claim: They're agreement with us.

### Moderator
Claim: Yeah. The basic-- the basic point that you're-- you're only in favor of force when it's intelligent, and you're in favor of force when it's intelligent.

So we can all go home now, except that I do-- I do think that there's actually a debate here. And as Aaron David Miller pointed out, there's a national conversation about this, and that's what I am here to help us tease out, because there were points that made-- that were made in case-- and examples of specific cases. And I think what we want to do is go look at some of these specifics but we know on them what we're talking about. We're talking about, where do we go from here, and what's happened in the recent past.

And I want to-- I want to look at the fact that President Obama did indeed take a relatively restrained view on the situation in Syria and Iraq until August of 2014 at which time he stepped up the military force. And that makes me want to ask the side that's arguing for the motion, did the president-- was the president once on your side on this argument, and then he switched to the other side? Aaron David Miller.

### Conspiracy Advocate (CA)
Claim: Again, we're constrained and confined by a motion that is, in many respects, really not appropriate to the national conversation that has to be had. This president, frankly, is risk averse, except in one area where he has emerged to be George W. Bush on steroids. And that is the protection-- that is the protection of the continental United States.

He's killed ten times the number of, however you want to describe them, terrorists, militants, extremists, with predator drones. He's expanded the drone war to Pakistan, to Yemen, to Somalia. He killed Bin Laden. He dismantled al-Qaeda core.

### Moderator
Claim: So, let me stop you before you go too far down that road because I think we see where you're going. So are you saying that he has been a muscle flexor and that it has not made things worse?

### Conspiracy Advocate (CA)
Claim: What I'm saying is the reason he interceded several weeks ago is because the organizing principle of the nation's foreign policy is the protection of the homeland. 9/11 was the second bloodiest day in American history, exceeded by only one other day, September 17th, 1862, when more Americans were killed in a single afternoon in the battle of Antietam, than any other day. That is the organizing principle. That's why public opinion, frankly, has become risk ready, not because we believe, or the president believes, that he is somehow going to put the Iraqi and Syrian Humpty Dumpty back together again.

### Moderator
Claim: All right, then go to Bret Stephens.

### Conspiracy Advocate (CA)
Claim: He can't.

### Moderator
Claim: Bret Stephens.

### Scientific Advocate (SA)
Claim: Look, I mean, we're all happier in this room, I suspect, as New Yorkers, that Osama Bin Laden is dead. What did it require to kill him? It wasn't smart diplomacy. It wasn't flowers dropped from 30,000 feet. It was a team of Navy Seals deployed from a military base in eastern Afghanistan who went in and killed him. Are we better off for him being dead or not? I think inarguably, we are. Psychologically, we are. We're a healthier country because we killed the enemy who wounded us so deeply. I'm sorry I'm not going to sort of play by Aaron's rules, because Aaron-- I adore Aaron, and Aaron has realized the hollowness of his proposition. But I came here to debate this motion which is something that--

### Conspiracy Advocate (CA)
Claim: No, Bret, that's unfair.

### Scientific Advocate (SA)
Claim: --that Paul-- that Paul is sticking to.

### Moderator
Claim: Actually, Bret, I have to say, you can win the debate taking that position, but it's a rather sterile-- sterile position to take in the situation where we're really trying to have a national conversation about this. So I say, resurrect that argument at the end to win. But get into the spirit of really trying to figure out what should we do right now, if you could.

### Scientific Advocate (SA)
Claim: And I

### Moderator
Claim: I take your point that--

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: I take your point that we phrased it in such a way that it's too absolute for them to win.

### Scientific Advocate (SA)
Claim: Let me-- you know, Aaron said something very interesting somewhere in his talk. He said-- I think towards the end. He said, we have to find some middle ground between the over-ambitions of the freedom agenda, of the Bush doctrine, and perhaps the lack of ambition of what was the first five years of the Obama presidency. What is the Goldilocks formula? That's essentially-- you would agree with me, that's what we're looking to do. And let me make two brief suggestions.

One of them is this: The purpose of American foreign policy should not be, particularly in the Middle East, should not be to make our dreams come true, because your dreams will never come true when it comes to the Middle East, not Israel-Palestine, not democracy in Iraq, not development in Afghanistan, not women's rights in Saudi Arabia, not gay rights in Iran and so on. However, we can have an achievable goal of keeping our nightmares at bay. And we can define what those nightmares are. We don't want Iran to get a nuclear weapon. We don't want ISIS to consolidate a caliphate in northern Iraq and Syria. We don't want the humanitarian disaster of Syria to spiral endlessly and affect all of its neighbors.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: How do we calibrate a foreign policy that keeps our nightmares at bay? That is the question.

### Moderator
Claim: Let's let Paul Pillar respond.

### Conspiracy Advocate (CA)
Claim: Yeah, Bret's absolutely right that we can't think in terms of what our dreams are in the Middle East. And that's exactly part of what Aaron and I are criticizing.

Again, Iraq 2003, the outstanding example, 2003 plus 8 1/2 years, we had a dream, or at least the makers of that war had a dream of using the regime change in this central Middle Eastern state to stimulate free market economics and democracy, not just in Iraq but throughout the region. It was the dream. It wasn't meeting a threat. It was trying to use military force to accomplish a more positive objective. And that's one of the ways we went wrong. You know, meeting real threats, absolutely. And Bret gave a couple of excellent examples in his initial presentation, like World War II. We couldn't agree more. But it's where we've gone beyond meeting threats.

### Moderator
Claim: Paul, what about the example he gave of the Yazidi community stuck on the top of a mountain facing genocide? That's not a threat to our national security. Was it our business militarily?

### Conspiracy Advocate (CA)
Claim: Well, it was a threat to the Yazidis.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: And I think there are some very tactical decisions that have been very difficult for the administration to make. And we can get really down in the weeds in terms of, you know, hitting this mountain rather than mountain. And I don't think Aaron and I are saying, despite the efforts of our worthy opponents to frame the debate in a way that we have to say that every use of military force is for the worst. That's, of course, not what we're saying.

### Moderator
Claim: Aaron?

### Conspiracy Advocate (CA)
Claim: May I just try to frame this-- look, we are stuck in a region we cannot transform, and we cannot extricate ourselves from. We have interests, allies and enemies there. When you cannot transform, and you cannot extricate, that leaves only one course, which is, I would argue, my word, you transact. You essentially apply a cruel and unforgiving standard to what constitutes American national interests, and you willfully pursue those interests. You decide what's doable from what isn't, what is vital from what is discretionary.

And when I say, "vital," what do I mean by "vital"? I mean an enterprise in which we are prepared to expend American lives, American treasure and American credibility. That leads you back to the one thing most Americans do care about, and that is the protection of the continental United States, which was--

### Moderator
Claim: Okay, let me--

### Conspiracy Advocate (CA)
Claim: --in effect was the basis for Obama's intervention.

### Moderator
Claim: Mike Duran.

### Scientific Advocate (SA)
Claim: Thanks. Aaron used a nice phrase in his earlier comments. He said that the Middle East was bad-- or, no, was broken, angry and dysfunctional, which I think makes a nice acronym, BAD. Right. It's a very bad place. And you also say we have interests, allies and enemies there. We-- it's a bad place. We want to keep it as far from us as possible, and yet we can't extricate ourselves. I agree with absolutely-- absolutely all of that.

I think we need a metaphor, a kind of different metaphor. And I would say that the Middle East is like having diabetes, right? It's miserable, it's horrible. You can't-- you can't get rid of it. You have to-- you have to manage it. And so my argument is that-- that a bias toward action and a bias toward military action is the best way to treat the disease rather than Paul's way, which is to-- which is basically to cordon off the area and stay away from it. Now, we've already-- as I said earlier, we've already seen-- we tried to cordon it off and move away and ignore it, and it comes to us just like diabetes. I just want to make one point here about the importance of using military force. When - - if we don't show a bias toward action, then we won't have allies. And allies-- this is a counterintuitive thing. We were accustomed, as a result of the kind of rhetoric that we heard from Paul, to think that when we use military force, we alienate people. And we want to-- we want to believe-- remember, there was this whole "hard power, soft power" thing.

We want to believe that people in the Middle East love us for the reasons that we love ourselves. It's not true. Why-- the people in the Middle East want us primarily for one thing, and that is our ability to provide security and the guarantee that we will provide them security. Look at Syria today. If we want to solve Syria, or if we just want to make it a little bit better and keep it at a distance, we want to put others out in front. We want to have allies. We would like to have Turkey, one of the most important countries there, go and do things in Syria.

### Moderator
Claim: Let me--

### Scientific Advocate (SA)
Claim: They're not-- if I can just one sentence, all right?

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: They're not going to go out and take risks in Turkey if they think that we might do like President Obama did a year ago with Syria and say, "Ah, you know what? I'm tired of this fight." They need to know we're going to go all the way with them and back them no matter what happens, and that requires military force.

### Moderator
Claim: Paul Pillar, very good argument made by your opponents about our credibility and which was put up in opposition to your saying that we make enemies by getting in there.

And they're saying, "At least we're keeping allies by going in and showing strength consistently." Can you respond to that?

### Conspiracy Advocate (CA)
Claim: Yeah, one of the big myths about credibility is that any time we back away from something that's either a losing proposition or not worth the effort or isn't in defense of our key interests, that somehow people and governments all over the world are going to think, "Oh, the Americans are a bunch of weak-kneed people who aren't going to stand up to their vital interests." That is simply not the case, and there's academic research on this, that it's not the way that other governments think or perceive us. And to understand that, how would we view the Russians or the Chinese or anyone else who backed away from or did not use military force or flex their muscles in something peripheral, something that was losing, something that was not in their vital interests? Would we say, "Oh, they're a bunch of weak-kneed lily-livered weaklings, and they're not going to stick up for their vital interests"? Of course not. We would assume they would, and that's the same thing with us.

### Moderator
Claim: Bret Stephens.

### Scientific Advocate (SA)
Claim: Look, what Paul said is just simply manifestly untrue. I think Paul and I would agree that we do not want-- the American government does not want Israel to attack Iran in the event that Iran or the Israelis perceive that Iran is approaching a nuclear capability, some point of no return. But when we show, when we tell the Israelis, when we announce that we have a red line in Syria, and then we erase that red line and the president goes before the cameras and says, "Oh, I never said, 'red line,' the world had a red line, it was someone else's red line, and, by the way, I have this interesting diplomatic gambit that I've worked out with Sergey Lavrov,” what does that tell decision makers in Jerusalem and in Tel Aviv? It tells them that America's promise that it will not allow Iran to get nuclear weapons is a totally hollow promise that they cannot trust.

And you don't have to take my word for it. You can ask the Israeli defense minister who is on record as saying this. So we have this issue of credibility that Paul has just raised and dismissed-- we have exponentially increased the chance that Israel will become a foreign policy freelancer in what is perhaps the most fraught situation in the Middle East. Why? Because they don't trust the Americans. Same story with the Saudis. We used to have a close defense alliance with the Saudis. The Saudis don't trust us anymore, which is why John Kerry had to go on bended knee to Riyadh a few weeks ago to say, "No, this time we're actually serious."

### Moderator
Claim: Okay, point made, and I want to take it to Aaron David Miller.

### Conspiracy Advocate (CA)
Claim: We've spent the-- and, again, I haven't seen a piece of classified information since 2003, so what I'm about to say is my view-- we've spent the last several years trying to preempt the Israelis from striking Iran prematurely.

On the assumption that negotiations and or sanctions, some combination of the two would retard, ultimately undermine Iran's pursuit of a nuclear weapons capacity-- forget the weapon itself, just the threshold capacity-- we've make commitments to the Israelis based on the assumption that if they stay their hand and Iran moves to weaponize, we will do this because we can do it better, we can do it more comprehensively and more definitively. This president may well be called on, Bret, to make good on that. And this is an issue for 2015 if these negotiations don't reach an agreement in November, which is highly unlikely in my view.

### Scientific Advocate (SA)
Claim: Nobody in the Middle East believes he'll do that, not a single leader.

### Moderator
Claim: Can you come a little closer to the mike and just say that?

### Scientific Advocate (SA)
Claim: Sorry. I said nobody in the Middle East believes he'll actually do that. He's said it or he's signaled it, suggested it, and so on, but there is nobody, nobody in Riyadh nobody in Jerusalem, nobody in Baghdad, and nobody in Tehran believes that he will actually use military force to stop Iran.

### Conspiracy Advocate (CA)
Claim: Two things would undermine and destroy the Obama presidency, what remains of Obama's credibility. One is another consequential attack on the homeland-- I'm not talking about a lone wolf inspired attack, I'm talking about directed attack that leads to scores of American casualties, regardless of his actions now-- and the second, which three administrations have now committed themselves to, is Iran's crossing the threshold to weaponize--

### Scientific Advocate (SA)
Claim: Which is-- and he agrees with you. He agrees with you. And that's why he is caving in the negotiations. And--

### Conspiracy Advocate (CA)
Claim: Well, look, I'm not here to--

### Scientific Advocate (SA)
Claim: --and making concession after concession after concession in order to get past the-- in order to hold them at this first-end goal for the next two years.

### Conspiracy Advocate (CA)
Claim: This one may not have a Hollywood ending.

### Moderator
Claim: Okay. I want to come to questions in a minute. But I just want to do one more thing before we do that, and I want to look at the counter-claims that were made about the promulgation of and the success of ISIS in the last year. And the two sides may directly oppose statements based on their theses that inaction caused ISIS and that intervention caused ISIS.

And I want to maybe split those into two. And first, to go back to Paul Pillar, your argument that ISIS is there and successful because the U.S. got into the situation and messed it up. Just make that point in about 40 seconds and we'll have your opponents respond to it.

### Conspiracy Advocate (CA)
Claim: There was no such thing as ISIS or a forerunner of it before we invaded Iraq. And once we did and the multi-faceted civil war got rolling, a major ingredient of it was Sunni- Arab rejection and resistance both to the Shiites and to us because we were seen as overthrowing, which we did, a Sunni-dominated regime and opening the way to Shiite rule, which is exactly what happened. And part of that-- one of the most extreme parts of that resistance to what we did was what was then known as Al-Qaeda and Iraq under Mr. Zarqawi, which is the group that evolved into what we now know today as ISIS or Islamic State.

### Moderator
Claim: Okay, I want to go to the other side and say that's a coherent statement. Before making your case that it was inaction that did that, what's your response to his argument that--

### Scientific Advocate (SA)
Claim: I think it's very simple.

ISIS is the creation of the last five years of inaction. Above all--

### Moderator
Claim: No, no, no. But that's the part I don't want you to get to. I want you to tell us not what's so good about your argument; what's wrong with his argument? Which is not the same discussion.

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: And then, I'll come to you.

### Scientific Advocate (SA)
Claim: Well, the problem with his--

### Moderator
Claim: He makes a logical argument that we came in as Americans. We picked sides. We took the wrong sides. We fomented onto other side.

### Scientific Advocate (SA)
Claim: It's perfectly simple. It's not as if Jihadism was born in March of 2003. That's just simply not true. We had Jihadi groups all over the Middle East. And what we know about Jihadism is that the Jihadis thrive in areas of chaos, lack of governance. And that's what we've allowed to expand and multiply not simply in Iraq, but above all, in Syria through a policy of deliberate inaction.

### Moderator
Claim: So Bret, the piece of their argument that, by our being there and stirring the pot, we exacerbating the situation that led to ISIS, you just reject out of hand?

### Scientific Advocate (SA)
Claim: Of course we weren't there at the-- we weren't there at all.

### Moderator
Claim: That's right.

### Scientific Advocate (SA)
Claim: We are talking about ISIS is a creation of the last few years. You had never heard of ISIS until about two years ago.

### Moderator
Claim: They changed their name.

### Conspiracy Advocate (CA)
Claim: Can I just add one point? ISIS is a response to two failed and/or failing states and a pool of Sunni grievances which mount faster than the numbers of moderate Sunni rebels that we can stand up-- grievances generated by Assad and grievances generated by Maliki.

### Moderator
Claim: Precisely. Precisely.

### Conspiracy Advocate (CA)
Claim: You are receiving some that we could fix that?

### Moderator
Claim: Aaron, can you just come closer to your mic--

### Conspiracy Advocate (CA)
Claim: Sure. You're assuming somehow we had the power, the incentive, the motivation after the two longest wars in American history to basically put the Syrian Humpty Dumpty and Iraq back together again? That's your assumption?

Do you think that would--?

### Moderator
Claim: But Aaron, that doesn't answer their point to your point that--

### Conspiracy Advocate (CA)
Claim: No, but Bret--

### Moderator
Claim: --that how did the Americans make ISIS, let's say, exacerbate the--

### Conspiracy Advocate (CA)
Claim: To the extent we enabled the weakness of Iraq and Syria, Bret has a point. But I do not believe we bear the primary responsibility for ISIS' emergence. It was Larry Summers who said, “In the history of the world, nobody ever washed a rental car.” You know why you don't wash rental cars? Because you care only about what you own. And the problem in this region is a lack of ownership. It's a lack of gender equality. It's a lack of transparency, accountability, pluralism, and the emergence of national leaders who care about the vast majority of their people.

### Moderator
Claim: Michael Doran.

### Conspiracy Advocate (CA)
Claim: That helped ISIS--

### Scientific Advocate (SA)
Claim: I just want to point out that that-- you just undermined Paul's argument.

### Moderator
Claim: I thought so, too.

### Scientific Advocate (SA)
Claim: Because you--

### Moderator
Claim: I was having trouble following.

### Scientific Advocate (SA)
Claim: No, no, because you said-- you have basically said that it's the bad qualities of this region that are generating these actors-- these malevolent actors rather than our-- rather than anything that we did. And--

### Conspiracy Advocate (CA)
Claim: To the extent-- yeah. To the extent we enabled it, we deserve a responsibility.

### Scientific Advocate (SA)
Claim: Look, look. Even if you say we're the prime mover, which I don't accept-- but if I accept it for the sake of discussion that we're the prime mover and we set this thing rolling, the only solution to it now is a military solution, and that's the conclusion that President Obama came to, and that's the only conclusion that a logical person can come to.

### Moderator
Claim: Paul Pillar.

### Conspiracy Advocate (CA)
Claim: Bret was absolutely right about radical jihadists capitalizing on chaotic situations. And in this main country we're talking about Iraq, we caused the chaos. We overthrew the regime, and we didn't have a plan for what followed.

### Scientific Advocate (SA)
Claim: It's Iraq and Syria.

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: Right? It's Iraq and Syria. We had nothing to do with Syria, nothing.

### Moderator
Claim: And Bret? Bret, you may have made the point already in your response to his, but in what way did American inaction lead to the spread of ISIS?

### Scientific Advocate (SA)
Claim: Look, it's a matter of record and a matter of fact, which I'm sure at least Aaron will agree with, that Iraq was at peace in 2009, that al-Qaeda was defeated in 2009, through a combination-- this is-- let me explain why-- through a combination of the application of American force which gave confidence to the Sunni tribes in Anbar province that we were a reliable partner that meant business, that would stick around and that would support them when they-- when we-- when they needed us there. And what did we do? We withdrew, and we withdrew entirely because we wanted to pretend that the Middle East didn't exist, that these problems way out there wouldn't come back to haunt us. And that was the fundamental mistake that we made. Look, we can – re- litigate the Iraq war, and Paul would love to re-litigate the Iraq war endlessly because he has a winning debate card there. But the issue is not-- I mean, why don't we just simply go back to 1920 or Sykes-Picot. We could have that debate in 1916 as well. And there's an endless chain of causation here.

But the immediate cause of the problems of the Jihadi problem is that we allowed Iraq and Syria to descend into chaos because we believed that the best policy was a policy of inaction. What we are living with now, Jihadi movements that have trebled in size in the last four years happened with a president who wanted nation building at home, not abroad.

### Conspiracy Advocate (CA)
Claim: Well, that point may be true, but you--

### Moderator
Claim: Aaron-- Aaron, I want to give both-- Aaron, I want to give Paul a chance to speak because you've had-- our unofficial clock shows you're racking it up, unless, Paul, you want to--

Unless, Paul, you want to yield. But before you do that, I want to say this: This is an Intelligence Squared U.S. debate where our motion is: Flexing America's muscles in the Middle East will make things worse. We have two teams of two debating this motion, flexing America's muscles in the Middle East will make things worse. On the side arguing for the motion, Aaron David Miller and Paul Pillar. On the side against the motion, Mike Doran and Bret Stephens. Paul Pillar.

### Conspiracy Advocate (CA)
Claim: Just, Iraq, most assuredly, was not at peace in 2009. And we're not going back to Sykes- Picot or running the causation back deck indicates. We're talking about problems right now, the very issues we're wrestling with right now that are a continuation of what began in the case of Iraq, in 2001.

### Moderator
Claim: Let's go to some questions from the audience. Sir, right down here. A microphone will be brought to you. And when it does, we'd appreciate it if you could stand, hold the mic about this far away from your mouth as this mic is from mine, about a fist. Tell us your name and ask your question. Tightly, tightly focused question.

### Moderator
Claim: Thank you. May name is Gerry Ohrstrom. Up till now, much of the discussion has been about the past, yes, the recent past, but still the past, and the good, the bad and the ugly of what happened in Iraq, Afghanistan, Libya and so forth, and a little bit about what caused ISIS to evolve. My question is, what about where we are right now? What about our attack on ISIS? What is the good and the bad and the ugly of that?

The consequences, outcomes, good or bad. Can we win and air attack? Do we need boots on the ground? What will the consequences of that be, good and bad and why?

### Moderator
Claim: Will that muscle flexing make things worse? Let's put that to Aaron David Miller.

### Conspiracy Advocate (CA)
Claim: I mean, I think--

### Moderator
Claim: Aaron, again, on the mic.

### Conspiracy Advocate (CA)
Claim: It's the Goldilocks approach, which I happen to support. It's trying to find a balance between risk readiness and risk aversion, an effort-- first of all, we already had boots on the ground, especially operators in Iraq. And I suspect, over the next year and a half, that number could double and triple. You should also not be surprised to learn one day that in effect, we already have boots on the ground in Syria, and we will have additional boots on the ground, but not the massive redeployment of thousands of American combat forces. That's one red line that will not turn pink with respect to this particular president. The campaign is effective for undermining, retarding, preempting, keeping ISIS, Nusra, Khorasan on the defensive.

If we hit them repeatedly, they'll have less time to spend planning attacks. But if you asked anybody from the CIA today, what is the most imminent threat to the continental United States right now? They won't say, ISIS. They won't say Iran. They'll say AQAP.

### Moderator
Claim: Okay, Mike Doran.

### Conspiracy Advocate (CA)
Claim: Al-Qaeda in the Arabian Peninsula.

### Scientific Advocate (SA)
Claim: Do you know that before, in the green room before we started, Aaron came in and said, "I don't think I'm going to use my whole seven minutes."

It was a debating tactic. The problem that-- the current campaign will set them back, clearly, and put them on the back seat, but it's impossible to win with this campaign because what we have from Baghdad to Damascus, Baghdad to Beirut, is a problem of Sunni society.

We have a Shiite government in Iraq, aligned with Iran, using horrible murderous sectarian forces on the ground against the Sunnis, and we have a Shiite government in Damascus allied with Iran or a non-Sunni government in Damascus also using horrible, murderous sectarian forces supported by Iran. And our Air Force is coming in and by intention or by accident, is changing the balance of power on the ground in favor of the Shiites against the Sunnis, which is not going to give us the ability to root out ISIS. We need to separate the local population Sunnis from ISIS, and we can't do that in this conflicting--

### Moderator
Claim: Mike, and I want to bring this question back to Aaron as well. In terms of our motion, this is a muscle flexing, and you're saying that it's not going to make things better. You're not saying it will make things worse, but you're just not saying it's not going to make things better.

### Scientific Advocate (SA)
Claim: We-- there's no-- the president has not defined-- he has not defined victory, and he is on a path that will not achieve victory.

### Moderator
Claim: And, Paul, and risking giving your opponents their point that you might agree with some of their-- sometimes you might think force is called for. In this case, do you think that this muscle flexing is called for, or do you think it will make things worse?

### Conspiracy Advocate (CA)
Claim: Well, one difference we've had between the two sides of the stage here, John, is that our opponents keep trying to make this a pro or anti-Obama administration thing, but that's definitely not the case. And I think Aaron and I both can see pluses and minuses in what's taking place on the ISIS front. The one substantive point I'd add, John, is that-- is this issue of political will, because ultimately, the fate of this group certainly in Iraq, but also in Syria, is going to depend on the politics and the capital-- and we've had some encouraging signs in Baghdad-- but further political evolution so that Iraqi Sunnis know that they've got a future in an Iraq that is not dominated by ISIS.

### Scientific Advocate (SA)
Claim: That's-- wishful thinking, fantasy, total fantasy.

### Conspiracy Advocate (CA)
Claim: Well, we--

### Moderator
Claim: Mike, actually, I don't want to –

### Conspiracy Advocate (CA)
Claim: --we got rid of Maliki.

### Moderator
Claim: That's kind of wandering off our question about what our choices should be, I believe.

And so I just want to bring it back to the principle of the debate-- question being asked by the debate, Paul. In this case, is the muscle flexing going to make things worse, or is this not one of those cases?

### Conspiracy Advocate (CA)
Claim: I think overall the more deeply we get immersed into sectarian and internal conflicts in either Syria or Iraq, the greater are all the hazards that we've talked about of making things worse.

### Moderator
Claim: Do you think we're on that--

### Conspiracy Advocate (CA)
Claim: That does not mean there are not appropriate uses of military force such as rescuing the Yazidis on a mountaintop.

### Moderator
Claim: Do you think we're on that path already?

### Conspiracy Advocate (CA)
Claim: I think the path we are on carries much risk of escalation to damaging directions that do make things worse.

### Moderator
Claim: I'm going to have the other side respond to that. Bret Stephens.

### Scientific Advocate (SA)
Claim: You know, the Israelis are great philosophers of Middle Eastern war diplomacy and overall conduct. And it boils down to a wonderful Israeli phrase, "it's depend."

### Moderator
Claim: Oy, thanks God.

### Scientific Advocate (SA)
Claim: And it's a wonderful phrase because it depends.

It depends on the kind of force the president uses. It depends on whether he's smart about it, whether he listens to his generals, whether his considerations are mainly political or they're mainly strategic, whether he's looking to completely defeat ISIS, to simply degrade them, how much he's thinking about the view that our allies in the region take of us in our willingness to apply force as well as our-- as well as the way our enemies look at us. Michael, I think, came up with a defining metaphor. And this is a good question-- I thought it was a wonderful first question to begin with. We are not going to solve ISIS. We are not going to solve Iraq, and we're certainly not going to solve 1400 years of Sunni-- Sunni-Shia sectarian conflict. What we can try to do is manage this situation so that, A, it inflicts a serious strategic military and psychological blow against ISIS.

B, it creates the possibility for other actors in Syria who are real, who exist, who might become more attractive and more popular to a majority of the population that is enchanted neither with Assad nor with ISIS. And we might also demonstrate to our Arab allies, to our Persian enemies, to our Israeli friends that we are a serious player that takes a group or takes something like the rise of ISIS seriously.

### Moderator
Claim: Okay, I'm just going to take another question.

### Scientific Advocate (SA)
Claim: That's the issue, we want to manage.

### Moderator
Claim: Ma'am, you're wearing green. Yeah. Mike's coming on your right hand side, if you could stand up please.

### Moderator
Claim: My question is for the for side. Assuming practicality that the sanctions are now becoming squishy, do you think it's worse to flex American muscle than to allow the Middle East to go into a nuclear arms race?

### Conspiracy Advocate (CA)
Claim: I don't know what you mean by sanctions getting squishy.

We can argue all night about sanctions. They've worked in some cases and not worked in others, and there are all kinds of variables that take too much time to come into play. But I would mention just one example. And we've cited it in other ways in the past. Libya, that was a successful use of sanctions against Gaddafi. And he made this tremendous turn away from his previous outrageous behavior with regard to his unconventional weapons programs, weapons of mass destruction, and his rampant involvement in international terrorism. And back in the 1990s, after several years of multilateral sanctions in which he felt both the economic hurt and the political hurt of being a pariah, he changed. He got out of the international terrorism business, and he opened up and gave up his unconventional weapons program. And that was all without use or even the threat of military force. That was a successful case.

### Moderator
Claim: Mike Doran.

### Scientific Advocate (SA)
Claim: That's a fanciful chronology.

He gave up his weapons program after a massive application of American force in 2003. It was the example of the invasion of Iraq that turned him. And, by the way, it was also the--

### Conspiracy Advocate (CA)
Claim: That's factually wrong there.

### Scientific Advocate (SA)
Claim: --it was also the invasion of Iraq that compelled the Iranians to stop their weaponization--

### Conspiracy Advocate (CA)
Claim: I know it is wrong because I was personally involved in the negotiations with the Libyans back in 1999--

### Scientific Advocate (SA)
Claim: I was personally involved with the--

### Conspiracy Advocate (CA)
Claim: --four years before that--

### Scientific Advocate (SA)
Claim: --I was personally involved with the--

### Conspiracy Advocate (CA)
Claim: --four years before that--

### Scientific Advocate (SA)
Claim: --I was personally involved in negotiations--

### Conspiracy Advocate (CA)
Claim: --and that was after--

### Moderator
Claim: Wait, we've got some real insiders here. Mike, will you wait, and, Paul, you make your point, and I'll come back to you. Bret, Bret, Bret, Bret, Bret-- hang on. Paul.

### Conspiracy Advocate (CA)
Claim: Gaddafi made those decisions in the 1990s. When I sat down across the table from his intelligence chief, he had already decided to get out of the unconventional weapons programs and get out of international terrorism.

That was four years before the invasion of Iraq.

### Moderator
Claim: Mike Doran.

### Scientific Advocate (SA)
Claim: His intelligence chief, Moussa Koussa-- what's his name, great name, yeah, Moussa Koussa-- Moussa Koussa once had a beautiful villa overlooking the Mediterranean. And he came home one day to his villa and it was turned into rubble, bulldozed into nothing, right? And there was a message for him that, "The leader wants to see you." And so he went to go see the leader. And the leader said, "Moussa, that villa." And he said, "Yes." He said, "I didn't like it. It wasn't right for you." And he handed him some keys, and he said, "I've built another villa for you, and I want you to have that." And he gave him this other villa. And so what was the message? The message was, "Don't get too big for your britches. Everything you've got comes from me, everything. And I can destroy you in an instant." That's the mentality of a leader in the Middle East, and you've got to ask yourself, "If that's who we're dealing with, do we deal with him with soft power or do we deal with him with hard power?"

### Moderator
Claim: All right, let's go to another question, sir. Yes, you're standing up, yep. Mike's coming from your left.

### Moderator
Claim: My question is also for the for side.

### Moderator
Claim: Could you tell us your name, please?

### Moderator
Claim: I'm Alex Selkir. I'm a student at Princeton University, and thank you for having me here this evening. Mr. Pillar and Mr. Miller, your point of only fighting smart wars is well taken. However, military force is not bound to times of war. It is the threat of force, the capability and willingness to use it, from localized strikes to ground invasions that shapes the decision

### Moderator
Claim: Sir, can you just cut to your question?

### Moderator
Claim: --yes-- how can the United States effectively influence the perceptions, calculations, actions, and goals of its adversaries, particularly those who only deal in terms of violence, without a muscular foreign policy? Thank you.

### Conspiracy Advocate (CA)
Claim: Well, you know, the notions--

### Moderator
Claim: Can you move in--

### Conspiracy Advocate (CA)
Claim: --the notions that we can have a cookie cutter strategy that is applicable to any number of situations in a region that is so fundamentally complex in my judgment is simply not possible.

### Moderator
Claim: But he wasn't asking for a cookie cutter--

### Conspiracy Advocate (CA)
Claim: No, no, no, but you're asking for a sort of Rx, a prescription for how to force smaller--

### Moderator
Claim: No, he wasn't. He wasn't saying, "What do you do all the time?" I-- honestly I don't think his question was, "In those situations where you are up against a guy who is only going to respond to tough force, how do you get through to him if you're not going to be a hard ass about it?"

### Conspiracy Advocate (CA)
Claim: I think that as long as you calculate means and ends, and that, in effect, military power, the projection of it, is an instrument to serve a set of political goals-- then military power can be an effective tool. What do you do, however, in a situation like Egypt where, in effect, they are an ally-- former ally-- still our ally. We have a freedom agenda. We want to promote democracy in a country that is, since the overthrow of Mubarak, has been dominated by a struggle between the military in one hand and the Islamists on the other. We have interests in Egypt. We've reduced their military assistance. We haven't threatened sanctions. We have to be artful and relatively sophisticated.

But my basic point is, in a region in turmoil, it's simply going to be very difficult create to an action-reaction phenomenon. That's why I go back to the notion of understanding what our core interests are, identifying them, and then trying to protect them.

### Moderator
Claim: All right. Let me go to this side because-- and Aaron has made that point a few times about core interests. He's been pretty clear about them. But you had us rescuing Yazidis in Syria. And we didn't really get very far with the question. I don't want to delve into it too much. But what are our core interests in terms of using force?

### Scientific Advocate (SA)
Claim: Well, one thing is we don't want to allow genocide to happen against a helpless population of women and children starving and trapped on a mountain.

### Moderator
Claim: So, that is a core interest.

### Scientific Advocate (SA)
Claim: Yes. Well, that is a core democratic value I would say. And we are a country where values do often go--

### Moderator
Claim: Let me stop you and ask the other side. Is that a core interest?

### Conspiracy Advocate (CA)
Claim: Look at our behavior. How can you argue it's a core interest?

Well, we are incredibly hypocritical when it comes to humanitarian intervention. We decide what is feasible, what is convenient, and we essentially ignore the tough cases. Bill Clinton, to this day, and the late Fouad Ajami called him to count. “This is your Rwanda, President Obama.”

### Moderator
Claim: So, you're saying--

### Conspiracy Advocate (CA)
Claim: So, we took a pass.

### Moderator
Claim: These are not core interests, you're saying.

### Conspiracy Advocate (CA)
Claim: I mean, look. Our interests--

### Moderator
Claim: I just need it for clarity.

### Conspiracy Advocate (CA)
Claim: I know. You're looking for a short answer. I understand that.

### Moderator
Claim: No. Yes or no isn’t a short--

### Conspiracy Advocate (CA)
Claim: All right. Okay.

Our interests and our values and our policies are constantly at war with one another. On the issue of genocide, we have not been consistent. Not since Roosevelt refused to be more ambitious with respect to trying to overcome the military's opposition to bombing the railways to the concentration camps. We have taken a pass on genocide and humanitarian intervention in Rwanda, in Congo, in Syria--

### Moderator
Claim: So, Mike Doran, your opponent is saying that it's not a core interest because we've demonstrated again and again that it's not.

And you want to chat to that briefly? And then I want to go to another question while we have time.

### Scientific Advocate (SA)
Claim: No. Values are a core interest because we're a democracy and the American people demand that our leadership respect our values. We can--

### Moderator
Claim: But your opponent is saying we haven't shown that we really believe in that.

### Scientific Advocate (SA)
Claim: Yeah, well, the fact that there's no human being that is the perfect representative of his or her values. But it doesn't mean that they don't have them and don't aspire to apply them.

### Moderator
Claim: Bret?

### Scientific Advocate (SA)
Claim: I was just going to say, we're a country that in a sense is unique in that we often find ourselves defining our interests by our values rather than the other way around. And by the way, a reputation for being a humane hegemon is good for us in the long run. It allows us to maintain a pox Americana in the way that the Russians were not able to maintain a Soviet peace in their sphere of influence because, at some level, countries around the world understand that we operate differently from the Iranians, the Chinese, and the Russians.

And it what makes countries want to be our allies, our friends, our trading partners. So yes, we do have an interest in making sure when we can tip the scales at relatively low cost to ourselves, that we shouldn't allow atrocities to happen. That's not the kind of country we were born to be. And I think this is a common-sense proposition all of you would agree with.

### Moderator
Claim: In the back there, wearing a necktie. Yes, sir. If you just put your hand up. If you can stand up. Thanks.

### Moderator
Claim: Hi. I have a question for the far side--

### Moderator
Claim: Could you tell us your name, please?

### Moderator
Claim: Hi, my name is Carl Shashi to think about the impact on where whether it stops any good process and whether it generates any bad process in the future. And you argument to say it doesn't actually stop any good process, the military intervention. Could you talk a little bit about what your thoughts are about what are the bad process that the military intervention would generate that you don't think it would.

### Moderator
Claim: Wait, so you're saying what are the bad consequences of inaction?

### Scientific Advocate (SA)
Claim: No, I think I got him. He was saying what are some of the bad things that our action could generate. Is that what you're saying?

### Moderator
Claim: Yeah.

### Moderator
Claim: But why would you want this side to believe that this side would want to give you all that ammunition?

### Scientific Advocate (SA)
Claim: I can answer that.

### Moderator
Claim: Okay. All right. Go ahead.

### Scientific Advocate (SA)
Claim: I can answer it. And I hopefully will not shoot myself in the foot in doing so. Look, the problem that you have is that-- is that we can never know the future. So it's always a question of, do the risks of inaction-- or are the risks of inaction worse than the risks of action? That's what it-- that's what it comes down to. And so that's why I argued that we should have a bias toward action because lack of action destroys our alliances. And if we desire to keep this region at a distance, then we have to persuade other actors on the ground to take action in order so that we don't have to go in unilaterally.

The Paul Pillar thesis here is that if we-- if we are always showing restraint in keeping the region at a distance, then we won't have to use unilateral action. And I'm saying, no, it's actually the opposite. The more we don't flex our-- the more we don't flex our muscles, the more likely we make it that we're going to have to go in alone and massively because we won't have any allies.

### Moderator
Claim: Let's let Paul Pillar respond.

### Conspiracy Advocate (CA)
Claim: You know, Mike now has twice used phraseology that I think John shows some of the differences we have despite all that wonderful agreement we had earlier.

### Moderator
Claim: And he mispronounced your name.

### Moderator
Claim: Oh, that's right. Well, I didn't-- I didn't--

### Conspiracy Advocate (CA)
Claim: I didn't hit him on that, but--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: A bias-- you know, I don't think our foreign policy ought to be biased one way or the other toward action or toward inaction. It ought to be an unbiased way of cost and benefits and weighing of those core interests that we were talking about a moment ago – and not come at it with a preconception that we ought to be acting more than or the other way around.

### Scientific Advocate (SA)
Claim: There's a system-- there's a system out there that has its own logic.

### Moderator
Claim: Mike, let me just do one bit of radio, and I'll come to you in a few seconds.

### Moderator
Claim: And can I--

### Moderator
Claim: Wait, wait.

And I need no laughter. I want to remind you that we're in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, debating this motion: Flexing America's muscles in the Middle East will make things worse. The team arguing against the motion. Bret Stephens.

### Scientific Advocate (SA)
Claim: Very briefly, it was our bias toward inaction-- and by the way, I'm using "bias" in an unbiased sense. I presume you're all grammatically and tactically literal. It was our bias toward inaction that has made the Syrian problem, which began has a peaceful uprising against a brutal regime, turn into a quagmire that is in fact very different-- difficult to figure out.

It is our bias toward inaction which has allowed the crisis in Iran, the nuclear crisis in Iran, to that lady's question there, to go from being a potentially manageable problem to being a particularly difficult problem, not the least-- not least because if Iran either acquires a nuclear program-- a nuclear weapon or is seen as being in a kind of a zone of ambiguity, we will soon be faced with a Middle East in which Saudi Arabia has a nuclear weapon, perhaps the Algerians get a nuclear weapon, perhaps the Egyptians get a nuclear weapon, or the Turks, all of them countries capable of getting them. And then our problems will be that much more serious because we won't be looking at a kind of symmetrical standoff. We will be looking at these kind of overlapping, multiple asymmetries. Are the Turks enemies of Israel? Are they enemies of Iran? Are the Saudis enemies of--

### Moderator
Claim: Bret, let me-- let me cut in because of time. I want to let Mike Doran say something, and then we'll give the last word to this panel. Mike Doran.

### Scientific Advocate (SA)
Claim: The-- we have two problems in the Middle East: Malevolent actors that want to do us harm like al-Qaeda and the Iranians and our friends.

Our friends all-- there's a big frenemy problem in the Middle East that we're all familiar with. And the problem is, if we sit back and do nothing, it doesn't mean that our friends do nothing either. They go, and they do things to look after their interests, and they use tools and follow policies that are dangerous for us. So, if we want to vector them, we have to take action.

### Moderator
Claim: Last word from the side arguing for the motion, Paul Pillar.

### Conspiracy Advocate (CA)
Claim: Bret's mentioned several times this Iranian nuclear thing. I wish we had more time to talk about that, but that's one thing where the U.S. administration, the current one, has taken a lot of action. They seize the opportunity to have the negotiations that have taken place over the last year, which gives us the best chance to deal with exactly the sorts of threats if you're worried about them, that Bret described. Military force, flexing that muscle, isn't going to do any good, because besides not destroying the capability of Iran to build a nuclear weapon, if they really wanted to, it gives the best possible incentive to construct a nuclear deterrent.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate.

## Round 3

### Moderator
Claim: Where our motion is "flexing America's muscles in the Middle East will make things worse." And here is where we are. We are about to hear brief closing remarks from each debater in turn. They will be two minutes each. And remember how you voted beforehand. This is their last chance for them to change your minds. You'll be asked to vote again right after these closing remarks which will be in just a few minutes from now. On to round three, closing statements. First summarizing his position in support of the motion "flexing America's muscles in the Middle East will make things worse," Paul Pillar, a senior fellow at the Center for Security Studies at Georgetown and former national security officer.

### Conspiracy Advocate (CA)
Claim: Well, first I want to thank Bret and Mike for their very spirited contributions to this debate and, John, for your very even-handed moderation, and most of all to my colleague Aaron. You know, we Americans have an awful lot of faith in our ability to do great things overseas.

It is a well founded faith, because we have done some great things, including with the use of military force, like Bret mentioned earlier in his opening remarks. World War II is probably the best example of all. But some things, even we the superpower can't do, even with our military might. I've served in the U.S. military and in a foreign conflict. And in my case, it was as an army officer in the Vietnam War. That war was an extremely painful lesson to us, the American people, about the limitations of what we can do with military force. And among the bad consequences it had was getting to the issue of credibility, it reduced the credibility that the U.S. would use that military instrument in other better ways because of the American people's reaction to what had happened. Enough years went by, and we finally got over what happened and what we called the Vietnam syndrome. In one way, we demonstrated we got over it was another thing that Bret mentioned, the splendid victory in the Middle East reversing Saddam Hussein's aggression against Kuwait in 1991.

But the problem is, since then, we've been thinking more and doing more of using military force not just to reverse someone else's aggression like in World War II or operation Enduring Freedom or Desert Storm. We got into other things, changing regimes we didn't like or taking part in someone else's civil war, or trying to inject democracy through the barrel of a gun. Leadership is not just flexing muscle. It is having the wisdom to know the limitations and the costs and the risks, and most of all to follow the Hippocratic principle of "first do no harm."

### Moderator
Claim: Thank you, Paul Pillar.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: The motion is flexing America's muscles in the Middle East will make things worse. And here to summarize his position against this motion, Bret Stephens, a foreign affairs columnist and member of the editorial board at the Wall Street Journal.

### Scientific Advocate (SA)
Claim: Well, thank you, and thanks particularly to Aaron and Paul for this wonderful debate and to the entire audience.

### Scientific Advocate (SA)
Claim: What about me?

### Scientific Advocate (SA)
Claim: Mike, I'll get to you in a second.

For the last few years, the United States has conducted precisely the kind of diplomacy and geopolitical strategy that Paul Pillar has spent this evening advocating. We have focused on nation building at home. We have had a president who has told us time and again that the tide of war is receding. We've had a president whose bias, generally speaking, has been toward inaction, not action. We've had an administration that believes that the best course for the United States is to reduce its footprint, particularly in the Middle East, to pivot away from that region, to look at Asia, to look at our own problems at home, with the idea that in so doing that region would perhaps sort out its own problems and affect us less.

And yet the reality is exactly the opposite of what we have seen. A Rand corporation study showed that the number of Jihadists in the Middle East, of Jihadi groups and fighters more than doubled between 2010 and 2014, precisely during the time that the Obama administration was saying "the tide of war is receding," and precisely during the time that we were essentially following the counsel of our opponents on the other side of the stage. We have not made the world go away. We have not made the world a safer place. The world is more dangerous today than it was a few years ago. The world is a scarier place not just in the Middle East, but Russia and China. Machiavelli once said "the best policy is to be a firm friend and a thorough foe." For the last few years, we have been neither. We have to change that, or we will imperil our security here in New York.

Well, thank you, and thanks particularly to Aaron and Paul for this wonderful debate and to the entire audience.

### Moderator
Claim: Thank you, Bret Stephens.

And the motion is, flexing America's muscles in the Middle East will make things worse. Here to summarize his position in support of the motion, Aaron David Miller, vice president for new initiatives at the Wilson center and former U.S. Middle East negotiator.

### Conspiracy Advocate (CA)
Claim: Thanks, John. And, Paul, thank you for articulate, compelling and a gallant defense. And, Mike and Bret, it's-- I appear with you guys all the time. We have to do this again. Two days before the Camp David Summit, President Clinton, during a briefing, remarked to us-- he knew the odds were long-- that trying and failing was better than not having tried at all. And I remember how inspired I was by his remarks. The more I thought about it, the more I watched this angry broken dysfunctional region and Republicans and Democrats alike, equally trying to navigate a course between too much and too little, I began to understand that "Trying and failing is better than not trying at all," is an appropriate slogan for a high school college football team.

It is not a substitute for foreign policy of the most consequential nation on earth. We need to think before we act, and we need to understand, above all, that the dividing line for a smart foreign policy is not between left and right, not between liberal and conservative, not between Republicans and Democrats, it's between smart on one hand and dumb on the other. And the only question that you have to decide, and I implore you to vote for this motion, because I think our arguments, Paul's in particular, has struck the right balance between risk readiness on one hand, risk aversion on the other, a clear definition of when U.S. military power and its projection is important and vital and when it is not. Three questions need to be asked, and if I'm too risk averse in this region the historical record of the last 20 years validates my risk aversion.

Three questions, number one, "What are we trying to achieve by deploying military force?" Number two, "Do we have the means at our disposal to accomplish our ends?" And, number, three, above all, "What will it cost?" You ask those questions, you're firm and resolute, and American interests can be protected.

### Moderator
Claim: Thank you, Aaron David Miller. Our motion is "Flexing America’s Muscles in the Middle East Will Make Things Worse." Here to summarize his position against his motion, Mike Doran. He's a senior fellow at the Brookings Institution and former senior director at the National Security Council.

### Scientific Advocate (SA)
Claim: Thank you, John. Paul, Aaron, it really has been an honor and a pleasure, it's really been great, but, Bret, working with you has been the highlight of the evening for me. Paul would have us believe that we can stay back, sit back, away from the region, and not be involved in the sectarian fight on the ground.

And it's simply not true. I once had a good friend who went on the Peace Corps to Tuvalu, little Pacific nation that most of us have-- probably haven't heard of. I had never heard of it until I met him. And I found out that the people of Tuvalu were very angry with us because we had come up with some fishing regulations that destroyed their economy. Of course, nobody in America even knew that we did this, right? It's the same thing in the Middle East. We are judged by our action, and we are judged by our inaction. And we are participants by the nature of our size and our historic role in the Middle East in the sectarian conflict, in all of the conflicts in the region, whether we think we are or not, whether we stay out or whether we don't. So, the question is not whether to intervene or not to intervene, it's how to shape what's going on there. And the most important resource that we have in order to keep us from having to have massive interventions like the kind that we had in Iraq in 2003, is to build up our alliances.

And the only way we can build up our alliances is by providing security to our friends. And right now our friends in the Middle East don't believe that they can rely on us because, time and again over the last decade, we have backed away from commitments to them. And that's why we have to use military force so that we will not have the kind of wars that Paul wants to prevent.

### Moderator
Claim: Thank you, Mike Doran. And that concludes our closing statements. And now it's time to learn which side has argued best. We're asking you again to go to the keypad at your seat that will register your vote. We will get the readout almost instantaneously. Remember the motion is "Flexing America’s Muscles in the Middle East Will Make Things Worse." If you agree with the motion, push number one. If you disagree, push number two. If you became or remain undecided, push number three. And you can ignore the other keys. They are not live. And we'll have the results in just about a minute and a half. And while we're waiting for that to happen, I, too, want to-- all the debaters got up here and congratulated each other and thanked one another for a great evening-- I think we actually did carve a pretty good debate out of this near agreement at the beginning. We found your fault lines. And more importantly, we found that they're sincere, passionate, and important. But you brought a spirit of decency and respect to this whole thing. I congratulate all of you for doing that. And I'd also like to thank everybody who got up and asked a question. I didn't have to throw anything out tonight. The questions were all good. So, thanks to everybody for getting up and doing that. Again, as I said at the beginning, we would love it if you would tweet about the debate. Our Twitter handle is @IQ2US. The hashtag for this debate is #MidEastDebate.

Our next debate here at the Kaufman Center. It's Wednesday, October 22nd. The motion is Income Inequality Impairs The American Dream Of Upward Mobility. We have an economist and a one-percenter on each side of this debate. For the motion, we have Elise Gould. She's a Senior Economist at the Economic Policy Institute. And she studies wages, poverty, inequality, and healthcare. Her partner is Nick Hanauer, who is an entrepreneur and venture capitalist. His TED Talk on The True Job Creators went viral back in 2010. Against the motion, Edward Conard. He's a former partner at Bain and author of “Unintended Consequence”-- oh, we should have had him here tonight-- “Unintended Consequences: Why Everything You've Been Told About The Economy Is Wrong”. His partner is Scott Winship, a fellow at the Manhattan Institute who studies living standards and economic mobility. And in a week, October 7th, we're going to be in Philadelphia at the National Constitution Center.

The debate that night is Mass Collection Of U.S. Phone Records Violates The Fourth Amendment. Tickets for all of our debates are available at our website, iq2us.org. And I wanted to let you know also that we have a new app that you can get through the Apple Store and the Android Google Play Store that lets you watch all of the debates that we've ever done, which is now 97 after tonight-- ish-- and what's upcoming. And you can comment. And it's free. And it's actually a lovely app. Okay. So, it's all in. I have the final results. The motion is this: Flexing America's Muscles In The Middle East Will Make Things Worse. That was the motion. And before hearing the debate, our live audience here in New York voted this way: 26 percent agreed with the motion; 31 percent were against; 43 percent were undecided. That's a large figure for us. So, those were the first results.

Remember, now you have voted a second time, and the winner is the team whose numbers have changed the most in percentage point terms from the first vote to the second. So, let's go to the second vote. On the motion Flexing America's Muscles In The Middle East Will Make Things Worse, the team arguing for the motion, their second vote was 45 percent. That's 26 percent to 45 percent. They picked up 19 percentage points. That is the number to beat. The team arguing against the motion, their second vote was 31 percent-- their first vote 31 percent; second vote, 45 percent. They pulled up 14 percentage points. It's not quite enough. The team arguing for the motion wins our debate. That is, Flexing America's Muscles In The Middle East Will Make Things Worse. our congratulations to them. And thank you from me, John Donvan, and Intelligence Squared. We'll see you next time.
