# Debate Transcript

Topic: More Clicks, Fewer Bricks: The Lecture Hall Is Obsolete
Motion: More Clicks, Fewer Bricks: The Lecture Hall Is Obsolete

Debate ID: 040214%20MOOCs


## Round 1

### Moderator
Claim: Tonight’s debate is taking place in partnership with the Richard Paul Richman Center for Business, Law, and Public Policy, which is a joint venture of the Columbia Law School and the Columbia Business School. We want to thank them for partnering with us tonight and are very pleased to introduce Dr. Christopher Mayer, Paul Milstein Professor of Real Estate and co-director of the Richman Center who’s here to say a few words.

### Moderator
Claim: Thanks a lot John, good evening, welcome everybody. On behalf of the Richard Paul Richman Center for Business, Law, and Public Policy it is my honor to welcome all of you to this evening’s debate. The debate marks the fourth time that the Richman Center has partnered with Intelligence Squared U.S. in furtherance of our mission to promote evidence-based public policy, and dialogue on timely and relevant policy issues. Inaugurated in May of 2011, the Richman Center provides a platform for scholars of law and business schools to collaborate and formulate ideas and debate important public policy issues, and to inspire students to pursue careers in areas at the intersection of business, law, and public policy. This evening’s debate addresses whether online education, such as massive open online courses, they’re called MOOCs, will fundamentally alter the traditional classroom ecosystem in higher education, or serve to enhance the college-based educational experience. I am proud that the Richman Center and Intelligence Squared U.S. have picked up the gauntlet on this issue and worked so diligently to bring us four of the most notable figures engaged in leading the dialogue on online education, and what better place to hold such a debate than on the campus of Columbia University, at least so long as campuses exist, as we may find out. I wanted to thank Intelligence Squared U.S., and Robert Rosenkranz in particular, for their ongoing partnership and collaboration. Thank you to Richard Paul Richman, who is here with us tonight, for his ongoing support and generosity. Thanks to each of the debaters and the moderator, John, for engaging in this important topic. And most importantly, I’d like to thank all of you who are attending the debate and actually participating in the conversation this evening. And now I’d like to bring back John Donvan, who, in addition to his many wonderful qualifications, is actually a graduate of Columbia’s journalism school—so we wanted to welcome you back.

### Moderator
Claim: Thanks very much. It's a home team crowd for me. And so the next conversation I want to have-- and this is part of the ritual of Intelligence Squared-- our founder, Robert Rosenkranz likes to come on stage and share with-- he's spent some time thinking in advance about what debates should we be putting on in a season, and he comes on and shares with us how we got to this debate, why this topic, why now? And in general, he's made Intelligence Squared U.S. possible. So please give him a round of applause as we bring him to the stage.

### Moderator
Claim: Thank you, John.

### Moderator
Claim: So normally you talk us through a little bit of the pros and cons that we're likely to hear. But before we get to that, I need to bring up the fact that I find it curious that at another university campus that we shall not name in a city called New Haven, Connecticut, there stands a building called Rosenkranz Hall. Same last name as yours, which suggests to me that you may actually, as in fact the benefactor of that building, you have some kind of a commitment to the bricks thing, do you not?

### Moderator
Claim: Well, I do, but-- but I try to be fair and balanced. So my most recent Yale philanthropy was a fund to create online courses for Yale professors, to the center for educational innovation at Yale, so I'm on both sides of this issue.

### Moderator
Claim: So have you ever actually tried an online course?

### Moderator
Claim: You know, actually, I did. I was-- I felt like online courses might be a truly revolutionary kind of development in education. And out of personal curiosity I took a course in statistics. And I thought it was fascinating. It had a number of elements that really seemed very interesting to me. First of all, you could go at your own pace, which you can't normally. Secondly, you've got instant feedback or continual feedback as the material was presented. I gave wrong answers deliberately in some cases just to see where that led, and it gave you hints as to where you went wrong and how to correct yourself. So it seemed like a very, very interesting way of learning with frequent rewards and frequent feedback.

### Moderator
Claim: Did you get a grade?

### Moderator
Claim: I did.

### Moderator
Claim: How'd you do?

### Moderator
Claim: I did fine.

### Moderator
Claim: So it sounds like you just sort of made the case for why-- why there's an appeal to the online course. What's the opposite argument?

### Moderator
Claim: Well, I think the opposite argument is that you really-- there's something very much missing in a purely online approach to education. You miss the give and take of a vital classroom. You miss the requirement to think on your feet, to try to persuade other people. So I could well imagine that somebody could learn to be a very good statistician taking statistics courses online. But I can't imagine that somebody would learn to be a great debater doing that.

### Moderator
Claim: You need the personal touch.

### Moderator
Claim: I think you do.

### Moderator
Claim: Well, let's see how we can test our people on the personal touch as debaters tonight.

### Moderator
Claim: I think they'll do fine.

### Moderator
Claim: Let's welcome them to this stage, our debaters, ladies and gentlemen. Thank you, Bob Rosenkranz.

And I would just like to ask for one more round of applause to Bob Rosenkranz and to Richard Paul Richmond for bringing this debate to us here tonight.

So an idea for the times we live in. Who needs the college campus anyway? College by internet: You get to learn at home, you make your own schedule, you save money. But did we hear some of this going on already back in 1948? College by radio, when NBC collaborated with the University of Kentucky to put courses on the air waves; college by television, when Britain ran its great experiment called "The Open University."It's been going since 1971. The thing is the demise of the traditional college campus has been talked about for a long time now. But it has held off against all of these technological assaults so far. And the question is, would it be different this time with online education? Is this a game changer that will make the traditional lecture hall obsolete? Well, that sounds like the makings of a debate. So let's have it. Yes or no to this statement: More clicks, fewer bricks: The lecture hall is obsolete, a debate from Intelligence Squared U.S. I'm John Donvan. We are here at Columbia University's Miller Theatre. We have four superbly qualified debaters, two against two, who will argue for and against this motion: More clicks, fewer bricks: The lecture hall is obsolete. Our debate, as always, goes in three rounds, and then the audience votes to choose a winner. And only one side wins. Our motion is, more clicks, fewer bricks: The lecture hall is obsolete.

Let's meet our debaters. First, ladies and gentlemen, please welcome Anant Agarwal.

And, Anant, you are a professor at MIT. You are the CEO of edX. That is an online learning platform founded by Harvard and by MIT. Recently, it was announced that Columbia would also become one of its charter members. Anant, you are not only the CEO and the first president of edX, but you also taught its first course, which was circuits and electronics. You had an enrollment of 155,000 students from 162 countries. Is this a hard course?

### Conspiracy Advocate (CA)
Claim: It's not a hard course. It is an MIT hard course. It had differential equations as its prerequisites. And we were petrified we would have a hundred people sign up for the course, looking at the differential equation prerequisites. We were shocked when we had 10,000 people register in the first hour of announcing it. And before we knew it, 155,000 people signed up for this hard course.

### Moderator
Claim: How many passed?

### Conspiracy Advocate (CA)
Claim: So more people passed this course than I would be able to teach at MIT if I were to teach it at MIT for 40 years.

### Moderator
Claim: How many passed?

### Conspiracy Advocate (CA)
Claim: 7,200.

### Moderator
Claim: Wow. But less than 5 percent.

### Conspiracy Advocate (CA)
Claim: Correct. The same percentage pass the course as MIT admitted into its current batch. MIT admitted 7 percent of the people who applied to MIT this year. Somehow the same number passed this MIT hard course.

### Moderator
Claim: Okay. I can see you're good with numbers. Thanks. Ladies and gentlemen, let's welcome Anant Agarwal.

And Anant, tell us who your partner is.

### Conspiracy Advocate (CA)
Claim: Ben Nelson.

### Moderator
Claim: Ladies and gentlemen, welcome Ben Nelson, please. Ben, you are also arguing for the motion, "More clicks, fewer bricks: The lecture hall is obsolete." In 2010, you left your job as CEO of Snapfish, you had a plan to reinvent the university experience.

The result is the Minerva Project. It's an elite-- meant to be elite online undergraduate program. And your plan is to rival the kind of education you can get at the Ivies at a fraction of the cost. And you said you want to make it more difficult to get into Minerva than to get into Yale. So how many people were in your inaugural class?

### Conspiracy Advocate (CA)
Claim: So we admitted 45 students this year. That represents a 2 1/2 percent acceptance rate. And we admitted these students not based on an artificial capacity constraint, but we actually admitted every single person that passed our bar, and one of the extraordinary students was right there in the audience.

### Moderator
Claim: Where are you? We'll chat with you later. You can ask a question. So it's obviously-- there's-- you obviously are finding a market for this?

### Conspiracy Advocate (CA)
Claim: Absolutely. Our-- the demand that we have received for Minerva has been extraordinary because we not only are tapping a global market, but we also are approaching admissions purely on the basis of the human potential of this candidate and not about their lineage or who their parents are, what country they were born in.

### Moderator
Claim: But you want it to be elite?

### Conspiracy Advocate (CA)
Claim: We are designing the curriculum such that it is made for the very-- the very most capable people in the world.

### Moderator
Claim: Okay, so by one definition it's "elite." Ladies and gentlemen, thanks to Ben, and welcome to the debate. Our motion is, "More Clicks, Fewer Bricks: The Lecture Hall is Obsolete." We have two debaters who are arguing against this motion. First, please welcome Jonathan Cole. Jonathan, this is a home crowd for you. You are the John Mitchell Mason professor at Columbia University. You served 14 years as provost and dean of faculties. You wrote the book, "The Great American University." You wrote the book about this whole story which traces the origins and the evolution of American higher education. You've been in academia your entire career, and this particular university, Columbia, you have seen through decades and decades of change and growth.

And just to give the audience an idea of how much change and growth, what year did you actually start at Columbia?

### Scientific Advocate (SA)
Claim: I began the fall of 1960. I have never left, and I say I'm not gainfully employable by any other institution, quite frankly. But I've been here. I've gone through many roles, and I've seen many changes, from wearing a beanie as a freshman and having tug of wars with ropes to-- well, I won't go into the rest. I mean--

### Moderator
Claim: Back in 1960, you had to ride a horse to get to class?

### Scientific Advocate (SA)
Claim: If you had a horse.

### Moderator
Claim: Ladies and gentlemen, Jonathan Cole. And, Jonathan, your partner is?

### Scientific Advocate (SA)
Claim: Rebecca Schuman. She's fantastic, irrepressible, and logically, incredibly sound.

### Moderator
Claim: Ladies and gentlemen, Rebecca Schuman. Schuman, you are arguing against the motion, "More Clicks, Fewer Bricks: The Lecture Hall is Obsolete." You are a columnist for Slate. You are also a writer for the Chronicle of Higher Education and with its Vitae Project. You are also an adjunct professor at the University of Missouri, St. Louis. You teach German. So you are really in the trenches. This is the real world for you, and you're living it. We're curious. Have you ever had a conversation with your students in your German class about their preferences or dislike, however, for online education and for what are called MOOCs?

### Scientific Advocate (SA)
Claim: Yeah, actually I was just talking to them about it yesterday. I don't teach German right now. I teach something similar to the core curriculum here at Columbia actually. I teach a freshman literature sequence. And I asked them yesterday, "How do you guys feel about MOOCs and how do you feel about online classes?" They didn't know what MOOCs are, and most of them do not like their online classes.

### Moderator
Claim: Well, that sounds like an advantage for your side already. All right, ladies and gentlemen, Rebecca Schuman. Thank you very much. And we're going to be hearing that term, "MOOCs," so stay tuned to hear it defined, because it's important. Now, this is a debate, and that means it's actually a contest, a clash of ideas, and one side will win and one side will lose. And that will be determined by the vote of our live audience here at Columbia University. We want to go now to set you up to vote twice, once before the debate, and once again afterwards. And the way that we determine the winner is the team whose numbers have changed the most. So we want to set you up with the first vote. Go to the keypad at your seat, and register for us where you stand at this point on this motion, "More Clicks, Fewer Bricks: The Lecture Hall is Obsolete." If you agree with this motion at this point push number one. And if you disagree with this motion push number two. And if you are undecided push number three.

And the system will lock out in about 20 seconds. If you pushed the wrong button, just correct yourself. It'll lock in your most recent vote, and you can ignore the other keys. They're not live. And, again, at the end of the debate we'll have you vote a second time, and we'll look at the difference between the votes.

And the team whose numbers have changed the most in percentage point terms will be declared our winner. So we're going to go in three rounds, and we're just going to start now with round one. Round one, our motion is this, "More Clicks, Fewer Bricks: The Lecture Hall is Obsolete." And here in round one to open and arguing for the motion, Anant Agarwal. He is a professor of electrical engineering and computer science at MIT and the CEO of edX, an online learning destination founded by Harvard at MIT. He'll be making his way to the lectern to make his opening statement. It will be seven minutes long uninterrupted. Ladies and gentlemen, Anant Agarwal. Let me just correct. I said seven minutes. It's six minutes of statement. Thank you. The floor is yours.

### Conspiracy Advocate (CA)
Claim: You know, I'm going back to when I was an undergraduate, oh my god, 30 years ago, 32, 31 years ago. I'm sitting in class and this is like most of the classes I've been in. This was at IIT in Madras, lots of bright kids around me, extraordinary and bright.

And the fifth minute mark was my transition point, I would follow everything the lecturer did, the instructor did until the fifth minute mark, and then at the fifth minute mark I would lose the professor. And I would look at all-- and everybody seemed to be following the professor, but I would've lost the professor and then spent the remaining hour simply scrambling taking notes, completely-- I just lost the professor, scrambling taking down every word with no idea what is going on. I wonder how many of you in the audience have felt like that in a classroom. I won't ask for a show of hands, I just want you to think about it. I certainly felt oh my god, everybody around me knows what's going on, what's up with me? Our education system, this whole system of the lecture and getting together a lot more students in the classroom really is based on the factory model of education.

Get a whole bunch of people sitting in a classroom and then you have a person lecturing at them. It's a very, very efficient system, it started a thousand years ago, and this university below me is still standing, it's a thousand years old, and you know what? Nothing has changed. You could wake up a thousand years behind you or a thousand years ahead and absolutely nothing has changed. Everything has changed around us, but the university education system hasn't. Our communication is different. We don't have to yell across a continent. We have smartphones. Our medical system has changed. We don't have to hit somebody on the head to knock them unconscious and operate very quickly. We have laparoscopy today, but education system hasn't changed. We can fly from one continent to another, communicate in all kinds of ways, but our education system hasn't changed. Don’t you believe it is important? We can do-- the online education of today is very different from my grandfather's online education. It's completely different today.

In this new system we can use self-based learning. Just imagine I can watch a video of an instructor. I can pause the video. I can rewind the video. Not once, but six times. Heck, I can even mute the professor. This self-based system allows me to learn at my own pace. I wish I had that when I was an undergraduate student. Another thing, I would submit my homework and I would get the graded homework back two weeks later if I was lucky. I still haven't gotten some homework back 32 years later. No feedback. The feedback came too late. I wasn't interested in the feedback when it came late. But in online learning today, if you go onto edX.org or one of the MOOC platforms, feedback is instantaneous. We can grade all kinds of questions, equations we can even grade essays, believe it or not. So that feedback comes instantly. I can get a-- when something's wrong I can think about it, fix it. I can learn.

In fact, I learn the most when something is wrong say hey, what do I do here? I can try to fix it. Instant feedback is critical. In the many, many studies education researchers have known this for 40 years. Study Chen in 2003 showed that if you apply instant feedback students learn better. If you don’t provide instant feedback they don’t learn as well. We also do another thing, we use active learning. Again, these ideas are old ideas, we've just not applied them. There’s a very famous paper by Craik and Lockhart talked about active learning. Heck, just go back to Socrates. It's a Socratic method. You know, you teach by asking questions. So now what we can do is we can interweave videos with interactive exercises. So you watch a video at your own pace then you go answer a question to see if you've learned the material or not. This is mastery learning. If you haven't quite gotten it you go back and review the video or the materials, you come back and you try it again. So this way you don’t face forward until you have picked up and really learned the material.

And studies like the Craik and Lockhart study from as early as ’72 has shown that this, again, improves learning outcomes. So online learning today incorporates all of these principles and is completely different from what it was before. We can even bring gamification to our system. We can do online labs, check out the demo course on edX, it’s called Demo 101. We have online labs in biology, chemistry, physics, mathematics. You can play around and bring gamification into the picture. Our millennial generation is completely different. Just two weeks ago I remember walking past my daughter's room, she's 14, and she was lying in bed. She's got three screens in front of her. Okay, on one screen she was doing physics. On the second screen, she swiped my iPad, and she's watching Netflix, and on her third screen, she was “WhatsApp-ing”, now, whatever that is, with her friends. It's not tweeting anymore. It's “WhatsApping” with her friends. And they learn differently. The millennial generation is able to do these things. And then in the classroom, you still need that. You interact with each other, learn the soft skills and so on and so forth.

But they can get all the content and so on completely online if that's how they want to learn. They want gamification, they want engagement, not the same old boring lecture where they lost the professor after the first minute everywhere. Everybody should really have a high-quality education. And with online learning, I can really bring this to the classroom as well. And bringing online learning to create the blended model of learning. In an experiment we did with San Jose State University, they used their online material in class to create the blended model. Students would watch videos, interactive exercises in this active learning model before they came to class. And in class, they would ask questions of the professor, interact with other students and learn soft skills and collaboration. But a big part was online. And here they demonstrated that traditionally, the students were-- 60 percent of the students would pass the course, 40 percent would fail. In this blended model at San Jose State using our material online, they found that the failure rate fell to 9 percent.

### Moderator
Claim: Anant Agarwal, I'm sorry. You're time is up. Thank you very much. Anant Agarwal, ladies and gentlemen. Our motion is "more clicks, fewer bricks: The lecture hall is obsolete." And here to make his position clear against this motion, Jonathan Cole. He is the John Mitchell Mason professor at Columbia University where he served as provost and dean of faculties. Ladies and gentlemen, Jonathan Cole.

### Scientific Advocate (SA)
Claim: Thank you. And then there were MOOCs. The latest technological messianic movement that will disrupt and then save higher education. I want to make 12 points in six minutes as to why you should vote against the motion that more clicks will end the need for bricks and alter fundamentally the nature of higher education. Online education will not replace the great colleges and universities in the United States. At the selective colleges, MOOCs will be one of the many forms of new technology that will be useful, mostly for courses, as was pointed out by my worthy opponent, for those where you can get the right answer that's at the back of the book.

For all other courses where there are subtleties and interpretation, where there's a need to argue, for a close-knit community of participants, where there's a need for critical thinking, for close reading, where analysis plays back and moderates initial formulations, MOOCs will be less useful. In fact, as the biological scientist Stuart Feinstein says, "Questions are more relevant than answers." Indeed, Richard Levin recently signed on as the CEO of Coursera, and he said that it couldn't replace the traditional four-year residential college. Let's take the democratizing effect. Levin says that's what one of the purposes is. But who in fact takes those courses from all over the world.

The noble purpose, the people who take that course at least from the evidence that we have to the moment, are people who are already educated, not the people who we're trying to target for education. The next point is that there is no good empirical evidence that supports the idea that MOOCs represent a disruptive technology that will overturn the current business model of the best colleges and universities. Let me just tick off a few of the things for which there is absolutely no good empirical evidence. There's no economic or cost model that has been shown to work. The cost of creating content is very high. Friends of mine have told me that they spend $100, $200,000 or $300,000 a course. In short, there's no evidence that MOOCs will in fact lower the cost of tuition. There's no method that has been shown as to how intellectual property will be divided up, how much will go to the professors, how much to the university?

There's no good evidence that MOOCs have a democratizing effect as much as they might be desirable to have a democratizing effect. There's no good evidence of how people with different learning styles respond to the flipped classroom and the MOOC culture on campus. There's no good evidence on how you can examine thousands of people taking online courses without massive cheating. There's no good evidence about who drops out of MOOC courses. Those 7,000 who graduated may well have been people who already took the course at MIT. Now, how do we know who they really are and what their characteristics are? 72 percent of the professors who answered the questionnaire about teaching online courses, who were committed to them, said that they would not give credit for those who did well in the course. Sebastian Thrune, one of the founders of one of the leading MOOCs, Udacity, has said we were on the front pages of the newspapers and magazines and at the same time I was realizing we don't educate people as others wished or as I wished.

We have a lousy product. It was a painful moment. People learn from each other when they eat together, read together, converse together, sleep together. If nothing else, sex will reinforce bricks over clicks on the campus. This is not to say, I want you to know that the Khan Academy where small, short, highly focused courses are offered won't be appealing to some. It is, and it will be. But it is not going to end the need for the kind of close interaction that we need to find in the classroom in physical structures. MOOCs will not solve the cost disease.

I will answer what the cost disease is and why they won't actually lower tuition and the increases in tuition that you have read about in the papers during our next part of this debate. Let many platforms grow. I don't know how many of you have seen Brian Greene, the physicist at Columbia's new platform on-- he created for the world science fair, it takes place in New York. He built it himself. It is for people who know nothing about science to Nobel prize winners. It is far more sophisticated than the platforms like edX. One author allowed many of these platforms to grow and see how they work. MOOCs are one tool that will help to make higher learning better, not cheaper, for both undergraduates and professional school students. It's not likely to infiltrate the world of the laboratory, however. Remember, what makes American universities the greatest system of higher learning in the world is the research discoveries that have changed our lives and the lives of people around the world.

You never hear the MOOC discussers, the MOOC proponents, talk about the influence of MOOCs on laboratory life. It will have a tremendous effect on accessing information; JSTOR, ARTstor, visual libraries, all of these things are wonderful inventions and part of technology that help us learn. But that is no substitute for being able to analyze Moby Dick.

Thank you.

### Moderator
Claim: Jonathan Cole, your time is up. Thank you very much.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: And here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate, where our motion is "more clicks, fewer bricks: The lecture hall is obsolete." You have heard from the first two debaters and now onto the third. I'd like to welcome to the lectern Ben Nelson. He is the founder, chairman and CEO of the Minerva Project. That is a new online undergraduate program that aims to reinvent the university experience.

And, Ben, we had four teachers up here, and I was hoping that one of them would, in the opening statements, explain to those who do not know what a MOOC is. So I want to give you an extra 15 seconds before you launch to tell everyone in our audience and our listeners what this odd word means and why it is exceedingly relevant to this discussion.

### Conspiracy Advocate (CA)
Claim: So a MOOC is a massive open online course. And as Jonathan pointed out, it is one of several formats and technologies used for online education.

### Moderator
Claim: That's perfect. Ladies and gentlemen, in his opening statement, please welcome Ben Nelson.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you so much for having us, and thank you, Jonathan, for pointing out two very important things; first, that I should have absolutely gone to Columbia as an undergrad because they have sex in class.

And I certainly made a huge mistake going to Penn. We did not have that. And secondly, thank you for making such a compelling argument to vote for this motion.

The-- what Jonathan put together as the framework was a critique of the state of online education, not even online education, but a segment of online education today, as it stands. It was not a critique of the potential of online education, and it was based on an analysis of a very small portion of American higher education, these small courses in the most elite institutions in the United States. But we're not talking about the future of the most elite institutions. We're talking about the future of higher education in general. And so let's look at the facts. The facts of the matter are that when you look at what even the elite universities do, they are largely about disseminating knowledge, lecture- based courses, the lecture hall, where a university professor stands up in front of a large audience, gets paid $300,000, $400,000, fully loaded, and teaches one, maybe two courses a year to 200 students, is not an economically viable model.

And it is in fact a worse form of delivery than what Anant described, the very first version, the version 1.0, of these massive open online courses. The fact of the matter is, is that all of the problems listed about MOOCs, whether we're talking about who is taking them, cheating, whether we're talking about the completion rates, whether we're talking about whether or not it's economical to create the upfront costs, all of those problems got solved over time. And even before they do, with identity verification online, with the fact that once you create one of these MOOCs, it can be taken to hundreds of thousands of dollars-- once you realize that the fact that these courses are not completed or they're taken by the people that already have a university education, not because they're the only ones that can benefit from them, but because today they're not issued for credit.

Compare completion rates at massive open online courses-- that are there purely for fun-- versus the completion rate at Chicago Community College. They're both in the single digit percentages. But when you go to Chicago Community College, you're going there and paying to get your associate's degree. Here you have an opportunity to learn for free, and you have an opportunity to learn at your own pace with those around you. But let's go beyond the lecture. Let's address even the most esoteric elements of higher education. The close conversations between students and professor is small groups that explore subject matter. Well, turns out you can do that online as well, and you can do it in a better way than you can in an offline classroom.

When we first created our platform at Minerva, which is limited to 19 students per course, every student is on live video, we went to the University of Washington Medical School and we tested a very rudimentary version of our platform with a live class offline and a live class online, taught by the same professor, the same subject matter. The results were universally accepted that the online class was far superior to the offline class simply for the fact of the matter that even though there were the same number of students in the class, when you look straight into that camera and the professor sees your face and all of the other students see your face, you are paying attention. The professor can call on students and ask them a question and find out what they're going to answer rather than having them ask or answer at random. So the professor can choose to pick not the right answer but the spectacularly wrong answer which is interesting, one that curates the course of the conversation in ways that simply are not possible offline.

What we all have to remember is we are at the dawn of interactive, high quality, personalized education, whether it's a broadcast to many, whether it's in a small seminar format, or whether it is done in an individualized adaptive learning platform that caters the process of education to the individual student. But the fact that we are at the dawn means that none of us in this room, including Anant and myself, who are working on this every day, can conceive where this will bring us in the future. Here's what we do know. We do know that when students are given the option of going to their illustrious lectures, even at the world's best universities, there are far more students on the first day of class than there are on the last day. We know that oftentimes when we ask students, "Did the courses that you took in your college career change your life?

Did they make an impactful change in the way you perceive the world?" majority of students say, "No." We know that technologies will continue to improve and will bring intellectual development of students not just among the elite but among students around the world to a newer and higher level. Thank you.

### Moderator
Claim: Thank you, Ben Nelson. Our motion is, "More Clicks, Fewer Bricks: The Lecture Hall is Obsolete." And now to hear-- to her argument against this motion, let's welcome Rebecca Schuman. She is a columnist for Slate and the-- for the Chronicle of Higher Education's Vitae Hub and the author of the forthcoming book, "Kafka and Wittgenstein." Ladies and gentlemen, Rebecca Schuman.

### Scientific Advocate (SA)
Claim: Thank you. Thank you so much everybody for being here and to my co-panelists for just presenting. Anant, I tried really hard to get my assignments back to my students really fast. I really try my best and I always make it in under two weeks, but now I'm going to try even harder.

I really appreciate Jonathan. He brought up the fact that in person I like to teach classes where you can't get the answers in the back of the book. In my class there is no back of the book or the back of the book is just the last chapter of the book. It wouldn't really help. And, Ben, I did not know I made $400,000 a year-- To be honest. I teach two classes a year and I make $14,000 a year. So, I don't know. I’m doing it wrong. All right. So what I want to talk to you guys about is the MOOC I'm taking right now. I’m taking MOOC with edX and you sign up with edX. They ask you why you're signing up and I wrote definitely not for opposition research for the debate I'm going to do. I didn't say that. It's called Think 101X the science of everyday thinking with two good professors from Australia. Actually, I love it.

It's great. It's really fun. I've learned all sorts of different nefarious ways my own brain goes behind my back to thwart me. I love it. It's fantastic. It's pretty easy. It doesn't take too much time. I've learned a lot. Should I go over there? But I'm a 37 year old American with a doctorate. I already know how to learn. I learn for fun. I do it as a hobby, and it's a great hobby for me as a dabbler, but I don't think that it is an adequate replacement for college yet. There are a lot of reasons for this, but the number one reason for this is really just one word and that word is contact. Ladies and gentlemen, I hope that you'll vote no on the motion: More Clicks, Fewer Bricks: The Lecture Hall is Obsolete, because more clicks means less contact, less contact with professors like me. I'm not a superstar. I'm not a celebrity. I'm not a millionaire. I don't even have tenure and I never will. But that doesn't matter to my students.

I'm going to talk a little bit about some of my students today. I have one student who lives with dyslexia, and she is so smart in class. She's just bright in class, but her written work really suffers. And if she were taking an online course she might be mistaken quite unfairly for somebody who was not as bright as she is or drunk maybe, I don't know, but the fact that we can actually talk to each other in class has changed her life, because she knows that I know how smart she is. I have another student who is so shy that he shook last semester in class. Whenever I called on him-- I have ways of getting students to pay attention, by the way. He shook when I called on him. He gave presentation and he actually stopped halfway through because he went so clammy. Two weeks ago he came in, second semester, same class, Dostoyevsky killed it. Did such a great job. Blew us all away and I was talking to him about his story because I wanted to use it today, and he said I want you to know that our class has helped me learn how to talk to people.

The importance of that cannot be over-stated. It has helped him learn how to talk to people.

So, people, my students, actual real people, I know them. They know me. I don’t just enter their lives with the dissemination of content. They enter mine and we connect, we make contact. And that's important when things are going well in class. It’s even more important when things are going poorly. The community college research center right here at Columbia did a multi-year study where they determined that when students at community colleges and other sort of non-prestige institutions are struggling and they're taking classes online, they're much more likely to fail. They're much more likely to drop out. They're much more likely to give up. So I urge you to vote no on this motion: More Clicks, Fewer Bricks, because with every click a student loses contact.

With every click the student loses opportunities for growth. With every click the student might even lose their future. So right now students aren’t just failing online classes in enormous numbers, although they are. Online classes are also failing them. I have a lot more to say on this, but I'd like to transition to discuss, but while I am I'm going to be thinking about my students who all waived their right to privacy for me to be able to shout out to them today. So I hope that like me you'll be thinking of Miranda and Emma and Alex and Alex and Sarah, Sarah, and Sarah, Kayla, Amanda, Katrina, Megan, Braxton, Andy, Dick, Sandy, another Rebecca, not me, Josh, Jake and James, Taylor, Ryan, Elden and Ethan, Josie, and Dimitri. I think that they deserve contact. I think they deserve devoted personal attention. MOOCs are great for dabbling, and they're great for supplementary education, but I don't think they're a substitute for human interaction.

The Minerva Project sounds fascinating, and I heard that you were hiring. You probably pay more than I make. But no matter how advanced software is, I still don't think that it can replace face to face and being in the same room. Interaction is the most important part of college. It can be the difference between success and failure. And because of that, I urge you to vote no today on the motion, "More clicks, fewer bricks: The lecture hall is obsolete." Thank you.

## Round 2

### Moderator
Claim: Thank you, Rebecca Schuman. And that concludes round one of this Intelligence Squared U.S. debate where our motion is "more clicks, fewer bricks: The lecture hall is obsolete." Remember now how you voted in-- just before the debate began. We're going to have you vote again after you hear all of the arguments. And again, to remind you, the team whose numbers have changed the most will be declared our winner. Now we move on to round two. And round two is where the debaters address one another directly and take questions from me and from you in the live audience. The motion is, "more clicks, fewer bricks: The lecture hall is obsolete." Arguing for the motion, we've heard from Anant Agarwal and Ben Nelson.

They have argued that critics of online education are looking at the flaws in how it is now and failing to see the potential that it has at the era that this is now only the dawn of. They say that it can improve dramatically and cash up in a field of academia where nothing has changed for eons, that there's an advantage in fact to being able to stop a professor and wind and rewind and even silence, if you want to, that there's a generation now, the millennial generation who are essentially wired to learn this way, that it will connect to them, that there are different learning styles and that the technology can adapt to all of them, that technology allows that.

The team arguing against the motion, Rebecca Schuman and Jonathan Cole, they have argued-- they put it this way: People learn from each other said Jonathan Cole. Contact is critical, said Rebecca Schuman. They argue that too much of an education-- too much of education is not just about the answers in the book, but it's about what develops over time in an intimate, close contact, that that is critical and that software can't be the answer for everybody.

Now, I want to point out that there is a level of nuance to this debate. Neither team is deep into their corner where they don't see merit in the other side's argument. The team arguing more clicks, fewer bricks, is not saying, no bricks ever again. And the team on the other side is not saying, "No clicks ever." They concede that around the margin, the team arguing against concedes that around the margins, sure, some online education can be supplemental and useful, and the team on the other side is saying, sure, there needs to be a way to have human contact. And the Minerva Project that Ben Nelson is sponsoring builds that in. So let's make it clear that this is not this kind of fight to the death over this issue, but it is a discussion over emphasis. And I think in the emphasis there is a wide gulf. And I think some of that emphasis has to do with faith in technology itself to solve some of the problems.

Particularly since the side arguing for the motion is saying, well, we're at the dawn of a new era, and you have to see how much it can improve. So I want to put the question to this side that's arguing for the motion and making that point that we're at the dawn of a new era. As you pointed out in the opening, we have heard this before. Correspondence courses were going to democratize education, and they didn't. The open university in the United Kingdom, no, there were people who had degrees for that, but the great universities of England haven't flinched whatsoever. And the radio courses, et cetera. We've heard that technology was going to change the game dramatically so many times in the past. Why is it different this time, Ben Nelson?

### Conspiracy Advocate (CA)
Claim: Well, I would argue it has helped. And I think you have to understand the context. Think of the general population educational level in the 1930s around the world. What the radio has done, and television has done, to teach people and some of the information has been dramatic.

For example, in India, it's something like a hundred million people have learned to read from a program that adds subtitles to Indian soap operas. And the eye naturally learns to read those subtitles.

### Moderator
Claim: But let me stop you there, Ben, just in the interest of time, because my point is that that has not had much impact on the university model, which your partner says hasn't changed forever.

### Conspiracy Advocate (CA)
Claim: Correct.

### Moderator
Claim: Why not?

### Conspiracy Advocate (CA)
Claim: It's not interactive. It's broadcast. This is an interactive medium.

### Moderator
Claim: Okay, let me put that to the other side. That the game changer, Rebecca Schuman, your opponents are saying, is that it's interactive this time. It truly is two-way. It's not a letter through the mail to your professor with your answers. What's your response to that?

### Scientific Advocate (SA)
Claim: Well, the current technology I would say just isn't interactive enough. I think that students lose motivation when they don't have their peers around them to pressure them to go to class. I don't teach online at UMSLwhere I teach right now, but I have colleagues who do.

And they have interactive components, but it still doesn't really engage the students. And when the students start having trouble, they tend to really just give up.

### Moderator
Claim: Anant?

### Conspiracy Advocate (CA)
Claim: I think the big difference this time around is twofold, one is interactivity. And the second big one is exactly the point that my opponents are making, which we can bring online, and it's called peer to peer learning. If you look at Facebook and Twitter and all of these peer groups where teens and grownups in the billions are interacting with each other online, why can't we bring that? Why this scare of technology? Let's bring that into our learning education system and fold that in how people learn online so that the peer learning is part of the platform. As on edX, the whole discussion forum is part of the learning process.

### Moderator
Claim: Jonathan Cole.

### Scientific Advocate (SA)
Claim: Well, I'd like to just quote from Sherry Turkle who wrote a wonderful little book called "Alone Together." And she's an MIT colleague of yours. And she said, "technology is seductive when what it offers meets our human vulnerabilities." And as it turns out, we are very vulnerable indeed.

We are lonely but fearful of intimacy. Digital connections and a sociable robot may offer the illusions of companionship without the demands of friendship. Our networked life allows us to hide from each other even as we are tethered to each other which I think often is reflected in the social media and the kinds of contacts that people make through technology. It is not the kind of interaction that students have debating each other in class, involving the individual instructor to force people to confront their biases and presuppositions, to read texts extraordinarily closely, that can be useful in other ways. I don't believe it's possible yet.

### Moderator
Claim: Okay. Ben Nelson, respond please.

### Conspiracy Advocate (CA)
Claim: Well, I encourage all of you after the debate to go and find our student in the audience because she's been on the platform that not only enables that but enables you to have the kinds of debates, the kind of interactions, the kinds of interrogations of students that actually is even more difficult in an off line environment.

When you build a platform to teach a hundred thousand students, that's not your goal. Your goal is not to build a platform that optimizes for one-on-one debate. When you build a platform that's about bringing the seminar and adding data to pick which two students will be the ones on both sides of the debate, which kinds of analyses should you go back to in class and listen from another section so you can build upon? That makes online seminars even richer. So even though we don't have as many students on those platforms, this resolution is about where the future of universities will go. The technologies are here now. They will get propagated.

### Scientific Advocate (SA)
Claim: One of the things that came up--

### Moderator
Claim: Jonathan Cole.

### Scientific Advocate (SA)
Claim: --in the discussions about MOOCs in-- certainly in the heyday of excitement about their early inception was that they could reach hundreds of thousands of people. If they reach people in the seminar type of arrangement, with 15 or 20 people, it may be possible to generate some of the kind of discourse that you're talking about. But that's not where the imagery of the MOOCs really come from.

### Conspiracy Advocate (CA)
Claim: So, remember, I just have to respond to that.

### Moderator
Claim: Anant Agarwal.

### Conspiracy Advocate (CA)
Claim: MOOCs are-- and online learning in this form are two years old. You're comparing it to a thousand-year-old system which has failed. The economic model--

### Moderator
Claim: Which has failed, the MOOC or the thousand-year-old system?

### Conspiracy Advocate (CA)
Claim: The thousand-year-old university system has failed.

### Moderator
Claim: Well, no, it had a long, long run at a thousand years. I wouldn't call that failure.

### Conspiracy Advocate (CA)
Claim: They still don't have an economic model. But the point is that in terms of small seminar, the simple mechanisms are being introduced on the edX platform. It's called a cohort. You can create Google instant hangouts and small groups of five and ten people, interact with each other.

And it's much more connecting than a professor picking one student out of a class while 300 other students are sitting there twiddling their thumbs.

### Scientific Advocate (SA)
Claim: But I don't necessarily want my students to be in charge of each other. I love them. I love them to death. But--

### Moderator
Claim: Would you mind naming them again?

### Scientific Advocate (SA)
Claim: Their peer review, you know, they're freshmen, they're-- I got rid of peer review in my class because it was like the inmates were in the prison. It made the papers worse. It made things-- they don't-- they're bright, they're inquisitive, they're great, but they don't quite know enough yet to help each other learn in a way that I can help them learn.

### Moderator
Claim: That's a really interesting point and I think maybe goes to the whole notion of authority versus the inmates running the asylum as they say. Ben, so what about-- is that part of what this conflict is about?

### Conspiracy Advocate (CA)
Claim: Well, I think that's a wonderful Intelligence Squared debate for another time, but we shouldn't conflate the enabling technology with the educational philosophy. The question is, "What can the educational technology provide us--"

### Moderator
Claim: Well I think we should conflate those things.

### Conspiracy Advocate (CA)
Claim: Well--

### Moderator
Claim: I think it's relevant because she's actually giving a reason why she needs to be there in the classroom, kind of running things.

### Conspiracy Advocate (CA)
Claim: She can be there in a 15-person breakout. So there's nothing preventing the edX platform from having the professor jump from breakout to breakout. That's just a philosophical point of view, right?

### Moderator
Claim: So your argument really-- the side that's arguing for fewer clicks-- more clicks, fewer bricks, you're talking about-- you're basically-- you have a faith that ultimately the technology can address all or nearly all of the criticisms that are coming from--

### Conspiracy Advocate (CA)
Claim: Nearly all.

### Moderator
Claim: --you have a lot of faith that it's flexible, adaptable, and that it's only learning.

### Conspiracy Advocate (CA)
Claim: Absolutely--

### Moderator
Claim: All right, I want to take that to the other side. So that's philosophically what your opponents are saying, is that "You ain't seen nothing yet, and you're-- and it-- it's going to be amazing." And I want to sort of get a response from your side about that. Jonathan Cole.

### Scientific Advocate (SA)
Claim: Well, I mean, we didn't see anything yet with the .com bubble either, and that kind of exploded, but the technology was worse at the time.

I guess that I would also say is that learning does not only take place in the lecture room, and the nature of the bricks that bring people together, part of the learning experience, go far beyond necessarily the lecture room. And part of the subtitle of this debate is really whether or not the format and the structures and even the architecture of the old university setting will be obsolete. And I believe that students learn perhaps almost as much or as much outside of the classroom, interacting in these physical spaces, as they do in the classroom.

### Moderator
Claim: But, Jonathan, they're-- I think your opponents concede that point, but they say that the analogy is that those physical spaces can be created online, that those social interactions can happen online.

### Scientific Advocate (SA)
Claim: Yeah, well, I do-- I think the--

### Moderator
Claim: Even the sex can happen online.

### Scientific Advocate (SA)
Claim: Would you turn me to that program? What's the website? No, I-- well, there I just simply, you know, disagree. I mean, I think that when we are dealing with, let's say, a course that allows you to get answers that are known answers, I have no doubt that this new technology can have an extraordinary influence. But a great teacher, talking about the subtleties of text, about being a perfect reader, of how reading will influence your life, not only in terms of enjoyment, that I think has yet to be demonstrated. This is an assertion by our opponents, our worthy opponents. It is not demonstrated. And as I said earlier, there are a lot of empirical questions that I haven't heard any answers to thus far from my worthy opponents.

### Moderator
Claim: We're going to come back to some of those, but I want to let Anant respond to what you just said.

### Conspiracy Advocate (CA)
Claim: Sure. So you mentioned that-- I think you're making a mistake here. You're comparing the best teacher-- I would love to be in your class, Rebecca.

I think that you would be delightful. With a class of 10 or 15 working with Rebecca, that is fantastic. But how many people around the world-- how many children in the U.S. or the rest of the world can afford that kind of luxury, to have a great teacher in a small classroom setting, talking about reading , non-fixed answers at the end of textbooks? We have technology today where we can grade essays using machine learning technology. And if you talk to the teachers in the California School District, they are saying they are giving their children fewer essays because they just don't have the time to grade. I know teachers in high school, I know my wife who teachers, they spend hours and hours grading essays. That is a good thing, and as long as there are teachers like Rebecca to grade my essays and give me instant feedback, that is fantastic. But what about all the students where teachers are not able to give essays and writing assignments because they don't have time to grade? We have technology today in experimental form that will be able to grade essays using a machine learning technology.

### Moderator
Claim: Okay, let's let Rebecca respond to some of that. Rebecca Schuman.

### Scientific Advocate (SA)
Claim: I mean, I don't like grading essays. I wrote a very popular article in Slate about how I would like to stop assigning them because I don't like grading them. But when I grade them, I do grade them pretty fast. Essay grading technology is not very good right now. It might get better, but, I mean, when I think about the idea that a robot can replace the nine years of post-college higher education that I had, doing my Ph.D., reading 13 hours a day, learning breadth and depth, really just piercing into the inner depths of my brain and scraping around inside it, I have to confront that technological possibility with sheer terror. I don't know if I want to be in a world where a robot can do what I have worked so hard and sacrificed so much and trained so much to do.

### Moderator
Claim: Well, Rebecca--

### Conspiracy Advocate (CA)
Claim: not comparing-- I'm not comparing you.

### Scientific Advocate (SA)
Claim: I know, but-- Anyone who can

### Moderator
Claim: But I'm with Anant on his point being let's put aside the impact on you and how discouraging that would be to you. What about the impact on your students?

### Scientific Advocate (SA)
Claim: Of having a robot grade their papers?

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: They’d learn how to game the robot immediately.

### Scientific Advocate (SA)
Claim: But the point is not simply writing papers. Even the most conservative organization in the world, the college board and the SAT, are giving up the essay part of the SAT examinations, because they are doing the grading by rote, in effect. They're not nuanced. They're not teaching students how to think for themselves independently, which is a very difficult thing to do. Now maybe it is doable through technology, but I haven't seen it demonstrated.

### Conspiracy Advocate (CA)
Claim: Well, and again, I do think that we're ratholing on a piece of content. I happen to agree with you both. I mean, I do think that at the very high levels of education you do want people who are expert in the subject to grade essays. That has nothing to do about where the class occurs.

To say the professor doesn't sit in front of a lecture hall or even a 10-person class and says hold on a second while I read this paper and grade it, that's not a very interactive format. It's not very engaging. And so the question is what is the cost structure that is going to be built around actually disseminating that education? Even in a small format. Even in the scenario we believe in. What you actually do want is very tight student/faculty interaction, 15- to 19-person classes. We still opt to use chronology to facilitate the goings on in the classroom, because we think that it can enhance the experience for the student and dramatically lower the cost where you don't need to build buildings and maintain campuses when you can gather the students and have them experience what the world has to offer as opposed to necessarily in a very expensive, very exclusive campus environment.

### Moderator
Claim: Jonathan Cole.

### Scientific Advocate (SA)
Claim: Well, I mean first of all, I think that, you know, educators have done a terrible job, especially at the selective colleges dealing with the issue of costs.

I mean, students at Harvard graduate with no debt. They have a tremendous endowment. Columbia College students graduate with about $6,000 worth of debt, but the sticker price is the only thing that is talked about. So it's not as if those who can't afford it who come from, you know, poor socio-economic backgrounds can't go to these great colleges. I think as a conflation, however, if I can switch a bit, what the purposes are of these MOOCs. Are they to democratize the world as it were, which in some ways may well be hegemonic, who owns knowledge, to reach hundreds of thousands of people? Or is it to hold seminars in a different way with 16 or 17 people? Those are very different types of issues and questions. It seems to me Ben is trying to do one thing and it seems to me that edX is trying to do something slightly different.

### Moderator
Claim: Is that a fair depiction of the two of you?

### Conspiracy Advocate (CA)
Claim: Well, absolutely. I think there are different ways of using technology in the classroom. Every click is not the same. And Ben is using clicks in one way, we're using clicks in another way. I think the point here, the debate is about more clicks and fewer bricks. Can we include the classroom experience? Can we include the way we teach students? Can we teach more students than can have access to a great Rebecca? Can we create using technology the approach where people can learn from each other through peer learning online? Can we access-- can we increase educational access to millions of more students around the world who just don't have access to the Rebecca's of the world?

### Moderator
Claim: And Jonathan, let's take-- we just heard Anant talk about people not having access. In fact, it is an argument for the MOOCs. What's your response to that?

### Scientific Advocate (SA)
Claim: Well, you know, if you say don’t have access to the MOOCs I'm not sure who you're referring to, frankly, but I--

### Moderator
Claim: Well, let's find out. Who are you referring to?

### Conspiracy Advocate (CA)
Claim: I'm referring to all the children and students who cannot afford college or that leave college with huge amounts of debt or that simply don't have access to college.

### Moderator
Claim: Okay, okay

### Scientific Advocate (SA)
Claim: And that's a wonderful aim and a wonderful objective that I actually fully endorse, but the evidence that I've seen, and it's bad-- you know, it's not particularly good evidence, empirical evidence, suggests that the people in remote places that can't get to MIT, can't get to, you know, Amherst or Williams or wherever it might be, are people who are already educated. They're the ones who are signing on to these courses and may well be enjoying them, but it's not reaching the population yet that I think would have, you know, it would have very beneficial

### Moderator
Claim: Is that correct-- Anant, is that correct?

### Conspiracy Advocate (CA)
Claim: Again, I think it's how you play the numbers. So we have 2.2 million learners on edX and of that, 30 percent of the 600,000 are high school and college students. And so just because 70 percent of learners already have a degree doesn't mean that you are still not reaching-- they're reaching more students at the college age and high school level today than the largest university in the United States.

And so we cannot-- so we really cannot say that we're not reaching students in the right demographic. We are.

### Conspiracy Advocate (CA)
Claim: And I would add to Anant's point that if these universities would actually issue a degree alongside with that, you wouldn't have 600,000 students, you'd have 60 million. That one of the reasons that people don't complete is the same reason that people who sometimes read a textbook from cover to cover decide, hmm, I got to chapter 5. That was good enough. Thank you. But there is no point except for interest right now.

### Moderator
Claim: Well, Rebecca Schuman, do you see the democratization argument that is, to some degree, being made by the other side?

### Scientific Advocate (SA)
Claim: Well, you know, yes, I think that it does-- the numbers are-- it does reach more people than not having it would reach.

But I-- again, I agree with Jonathan that it doesn't necessarily reach the kind of people that it had originally intended to reach. And that shows in the corporate directions of edX's two main competitors, Coursera and Udacity, both of whom have decided to concentrate on corporate training instead of the sort of loftier democratization of education. And it also comes at the expense of people like me. There-- you know, you - - I love that you think that I'm irreplaceable and that everybody should just be in my class, but I am not that special. There are literally over a million low-level professors just like me in the United States right now desperate to reach students, desperate to work, working for--

### Moderator
Claim: And what happens to you million if their world comes true?

### Scientific Advocate (SA)
Claim: Well, I guess we go from working for poverty level wages to working for no wages. We're extinct.

### Conspiracy Advocate (CA)
Claim: I disagree.

### Conspiracy Advocate (CA)
Claim: I think that I would completely disagree.

### Scientific Advocate (SA)
Claim: true.

### Conspiracy Advocate (CA)
Claim: --is a rising tide that will lift all boats.

Give you an example of Professor Jamie L’heureux. She teaches at Bunker Hill Community College in Massachusetts. And what she did was her students did not have access to a great computer science class, so she took the online material from one of her introductory computer science classes, and she used that in a blended model in the community class. And she said, if not for the online material from the edX course, she said she never would have been able to teach that course on her campus. And she also said she's irreplaceable. If not for her and her helping with the online material, the students would not have passed the course. So I think teachers are necessary. I think bringing online learning into the classroom can really up-level the whole educational experience.

### Scientific Advocate (SA)
Claim: I think you're expecting too much of administration. I think if they have the opportunity to get rid of pretty much all professors, type in MOOCs from super professors and then use low-paid adjuncts and TAs to basically proctor people, they would jump at that. They would do that in a second.

Maybe not at super elite institutions like this one, but at the regional and directional universities where the vast majority of Americans earn their degrees, I just can't see that not happening because it would help the bottom line so much.

### Conspiracy Advocate (CA)
Claim: It would not happen when the supply and demand comes back in balance. Right now, too much supply of professors, not enough supply of completing students. A lot of students desire to complete drop out because we don't track their progress. We don't know when we lose them until the final grade.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: In the future, we'll be able to do that, and therefore there'll be much more demand for adjuncts and therefore salaries will rise.

### Moderator
Claim: I want to go to the audience now for questions from you. And I want to ask-- the way this will work, especially if you came in late, you raise your hand. We need a microphone to be brought to you. We need you to stand up, tell us your name and ask something that is-- really is a question, not to debate with the debaters, but to ask them a question that gets them debating with one another, and so make it very short and terse. And if it's not on the topic that gets them continuing on this topic, I'll have to pass. Sir, right down front here. If you can stand again, thanks.

### Moderator
Claim: Hi. My name is and I’m a grad student at NYU. My question is, don't you think that vocational education is more suitable to be online, and while liberal arts courses or materials will be

### Moderator
Claim: Okay. And to some degree, Jonathan Cole made that point in his opening, but your hasn't responded to the sense of different kinds of-- different kinds of material may lend themselves to different kinds of settings. So I want to-- and one of those settings cannot be online, liberal arts. Ben Nelson.

### Conspiracy Advocate (CA)
Claim: So I believe that there are different kinds of subject matter that lend itself to different format of student faculty ratios. But the question about whether or not technology can assist, whether it is a large lecture, a small seminar, even a one-on-one tutorial in many cases is clear. Now--

### Moderator
Claim: You can see-- you can see a creative poetry writing class online?

### Conspiracy Advocate (CA)
Claim: Well, there are creative poetry classes online. And both in lecture format and as well as not. And let me tell you--

### Moderator
Claim: I don't happen to know the texture of this, but how good an experience is doing poetry online?

### Conspiracy Advocate (CA)
Claim: It's amazing. I think it's phenomenal. I mean, it-- but I'm biased in that answer. I'll tell you where I don't think that online instruction can compare with off line, even though it already is happening. In conservatory instruction, if you are training someone to be a pianist, training someone to be a violinist, very hard to deliver at a very professional level, not Suzuki method-- very hard to get that level of nuance and personal guidance - -

### Moderator
Claim: All right. So I just want to go the side on the-- the other side. So your opponents have argued that there is a small sector of material that doesn't lend itself. You have conceded, I think, that there is-- there are areas that would lend themselves to online learning. Jonathan Cole?

### Scientific Advocate (SA)
Claim: Well, I certainly do, and that's why the University of Phoenix exists, to raise human capital to the point where some people can get better jobs than they have. And there's no reason why those kinds of enterprises shouldn't exist. I would simply like to raise again, for my worthy opponents, the answer to the empirical questions that I raised at the very beginning: What's the cost model that will work that didn't work in the 1990s? And the various other issues that have to do with intellectual property and the rest. If you don't answer those questions, you're living off the future.

### Conspiracy Advocate (CA)
Claim: Let me address the economic--

### Moderator
Claim: Anant Agarwal.

### Conspiracy Advocate (CA)
Claim: --model question that you raised. In fact, I think you made an argument against yourself. So you said that MOOCs cost between a hundred and $300,000 to create. You're absolutely right. They cost between $10,000 and half a million dollars to create. But the second time you offer the MOOC, you bring that into your classroom. The third time, the fourth time, it's like a textbook. A text-- for someone who's written a textbook, it took me five years to write the textbook.

But then to stamp out a new textbook is, you know, is 50 bucks or a hundred bucks. So repeating is much easier. And the MOOCs and online education, that’s how it is, the repetition is very cost effective and very high quality. However, in the classroom, I'm not sure what they pay-- you know, professors at Columbia or other universities, but I know it's not $14,000. It's certainly on the order of a hundred to $300,000. So in other words, we are teaching-- or we are paying a hundred to $300,000 each time a course is repeated. So therefore, the existing model is broken. With MOOCs, we can fix that, where the cost of creation is high, but the repetition, that's how you get the scaling of--

### Moderator
Claim: Okay, Jonathan-- Jonathan Cole, that was an answer to your question. Rebecca, do you want to take that?

### Scientific Advocate (SA)
Claim: Well, I mean, it's-- I-- I enjoy ribbing on tenured people who make too much money as much as the next guy. But the fact is that almost 80 percent of faculty today work off the tenure track. Definitely do not make in the six figures, and over half of faculty working today are adjuncts like me who make in the low five figures.

Most of our salaries begin with a 1 or a 2.

### Moderator
Claim: And Jonathan.

### Scientific Advocate (SA)
Claim: I must say that you have given me the perfect reason for retiring faculty. They make their MOOC, and they leave the door, and you don't have to pay them again next year. Now, if they make two MOOCs, who owns the property?

### Conspiracy Advocate (CA)
Claim: So the first point about retiring faculty after they create a MOOC, of course not. They have to be involved in--

### Moderator
Claim: Then no one would ever want to make a MOOC.

### Conspiracy Advocate (CA)
Claim: Exactly. So that would be the self-fulfilling prophecy.

### Moderator
Claim: Anant, we want you to make a MOOC now.

### Conspiracy Advocate (CA)
Claim: Exactly. So you make a MOOC, and then you have to support the MOOC. You teach the students. But you're not spending a hundred and $300,000 each time you teach it. You're still teaching it. You're still involved, but to a lesser extent.

### Moderator
Claim: And the intellectual property question.

### Conspiracy Advocate (CA)
Claim: The intellectual property is very straight forward. Actually, I don't see what the issue is. The courses and content, it's like-- we've addressed the problem with textbooks and other course content.

So I frankly don't see an issue there. So I would have

### Scientific Advocate (SA)
Claim: Do the professors own the intellectual property? Do they get whatever income might be available from the MOOCs that are commercial enterprises?

### Conspiracy Advocate (CA)
Claim: So the textbooks, the IP's owned completely by the professor and the publisher. Universities are completely cut out from it. And in online education, I think they have the chance to save the university with universities having discussion where three stakeholders can share the IP, not just the publisher and the professor, but the professor, the university and in this case the publisher of the MOOC platform like edX. There can be a three-way sharing of IP, which I think is the right way of doing as opposed to the textbook model.

### Moderator
Claim: I want to go to another question. Sir, right there.

### Moderator
Claim: Yeah, my name is Noel Capon, and I am a professor at Columbia. A simple model of the university, is that is in the business of both creating and disseminating information.

You know, on this side of the house I've heard nothing about creation. Does that mean essentially that the online operations--

### Moderator
Claim: But can-- sir--

### Moderator
Claim: --are freeloaders?

### Moderator
Claim: --can you-- because you were waving the mike, the radio audience--

### Moderator
Claim: Oh,

### Moderator
Claim: --who just asked question one more time.

### Moderator
Claim: A simple model of the university is that it both creates and disseminates information. I've heard the online people say nothing about creation. Does that mean that you are, in effect, freeloaders on the university system?

### Conspiracy Advocate (CA)
Claim: Well, I--

### Moderator
Claim: Ben Nelson.

### Conspiracy Advocate (CA)
Claim: --I'm delighted to address that. This debate is not about research. It is about the dissemination of knowledge. It's only about the second part. And--

### Moderator
Claim: Is that a "Yes" to his question?

### Conspiracy Advocate (CA)
Claim: No, it is not. I do think that what you enable when you remove the constriction of the campus environment from not just the student but from the professor is that you can enable much more flexible research.

I'll give you a couple of very quick examples. If you do field research, having a university job, we have to show up physically to class nine months out of the year, does not do wonders for your career, especially before you're tenured, or, like my father, who's a molecular biologist and is now doing structural biology, he needs to fly to the particle accelerators in Europe every three weeks just so he can shoot photons at his crystals. Well, if he were still teaching-- he's emeritus, so he doesn't-- he wouldn't be able to do that, so-- at least in an offline environment. So research can also be dramatically helped by the removal of physical requirements-- physical presence requirements for the faculty.

### Moderator
Claim: What do you think of that, Rebecca, which-- I mean, it doesn't apply specifically to the kind of teaching that you're doing, but you would have a-- you would have the ability, for example, to travel and study and do sabbaticals, et cetera, and still teach. Do you like that?

### Scientific Advocate (SA)
Claim: I mean, I think--

### Moderator
Claim: Would you believe in it?

### Scientific Advocate (SA)
Claim: For me it sounds great because I'll never have a sabbatical anyway, but I think the few people in my discipline who are left on a tenure track would probably have a heart attack because they'd be like, "Oh, I would have to coincide my sabbatical with teaching."Yeah, I mean, I have to say with that-- that is so esoteric, but I guess in an esoteric way I don't disagree with the opposite side on this particular thing.

### Scientific Advocate (SA)
Claim: I do disagree. I mean, I--

### Moderator
Claim: Jonathan Cole.

### Scientific Advocate (SA)
Claim: --I'm not at all sure that you have a university if you were that the sole function of that university in terms of bricks rather than clicks-- although clicks will exist in it-- is the research mission and all of the students are basically no longer there. Now, the essence of our great universities and our great colleges, whether they're very large state universities or much smaller ones, is that they create knowledge. They create discoveries and inventions.

I don't see how taking students out of the laboratory is going to enhance that process since they are the people-- the students-- the postdocs and others, the post-doctoral fellows, they are often doing the bench research and learning from each other through close interaction. You take all the undergraduates away and there are no bricks, I'm not sure what kind of university is left.

### Moderator
Claim: Let me-- let me just say this, and I'll bring the question back to you. I want to remind you that we're in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, debating this motion, "More Clicks, Fewer Bricks: The Lecture Hall is Obsolete." And the point was just made by Jonathan Cole that a world where universities devolve into institutions that basically do research and all of the undergraduates are off campus, online, is not a university that he would call a university. Anant, do you want to respond to that?

### Conspiracy Advocate (CA)
Claim: Let's be very careful here. I think we're taking some of the best institutions in the world, some really high quality institutions, and tarring the whole world with this utopian brush.

The world is not like that. Most universities in the world are not research institutions. Most colleges in the world, community colleges in the world, and high schools, and places where teaching happens are not research institutions. We happen to be in a research institution which is great. So I think we really need to look at the average, the median, and at universities around the world where education may be the predominant thing that happens. So I dream of a world where we have universities where professors are creating content and also disseminating content, just that they do it differently. It's the same people, but they do it differently. They do it bringing a lot online and so that they can spend a lot of time creating great content which they don't have the time to do because they have to do it every single semester. So now I can really create great content without a huge amount of effort and then focus on interacting with students in ways that I cannot do today.

### Moderator
Claim: Let's go to another question. Professor Mayer. – You’re a little bit of a ringer, but I think

### Moderator
Claim: I ask this not on the Richman Center behalf, but actually because I study real estate, and in the 1990s we heard people say that an online address was actually much more important than a physical address, but we see technology companies like Google and Facebook locating in the most expensive real estate in the country in the world presumably about the interactions of their employees who are working together and creating together. What's different about the business of education than the business of technology and creativity?

### Moderator
Claim: Ben Nelson.

### Conspiracy Advocate (CA)
Claim: I actually don't think it's very different at all. In fact, you can learn from what these companies are doing. If you look at where these companies set up 10 to 15 years ago, they created campuses. Google has a campus and they said oh, we're going to provide everything you want here on the campus, free food and laundry and, you know, slides and things like that.

And guess what their employees said? We don't want to live on the campus. They want to live in the city. Open up an office in San Francisco. Open up offices in New York City. Like, all right free food, that's great, but don't think you can re-create the world at huge cost and make it better than reality. So I think that's highly illustrative. I think that the more universities open, the more the university embraces the resources of the world and is open to students, whether they are their students or not, the more vibrant the physical elements of the university would become, like the research infrastructure, and the less university will start to compete-- or will continue to compete in an area like who has the better climbing gym.

### Moderator
Claim: Okay, we will take some other questions. I'm favoring the front because I can see it more easily, so I just want to Ma'am, all the way in the back there. And again, if you could stand up.

### Moderator
Claim: My name is Jessica.

### Moderator
Claim: Jessica, I've just been asked in my headphone to ask you to step down into the brighter light so that the television camera can see you for the live stream. And, by the way, I didn't mention this in the beginning, but we've been live-streaming. We also do with TV and on our website, IQ2US.org. So that's why you need to walk towards the light.

### Moderator
Claim: Can you see me now?

### Moderator
Claim: Yep. Yep.

### Moderator
Claim: I'm wondering how students are better prepared after receiving their degree.

### Moderator
Claim: I asked for really short questions, but you got me. Just a little more context.

### Moderator
Claim: Assuming that students online and offline complete their degree, how are they better prepared for the world?

### Moderator
Claim: If they're-- how do the online versus the old model students-- okay. So to rephrase if I'm correct, you want to know whether students who graduate with a largely offline diploma-- or largely offline as good-- their education is as high quality as those who graduate from the old model, is that correct?

Or are you asking how are they getting jobs?

### Moderator
Claim: Exactly. Not comparing the quality of the education, but how are they prepared--

### Moderator
Claim: For the real world.

### Moderator
Claim: --to enter the world.

### Moderator
Claim: Okay. Let's put that question first to the side that has more experience with that. I would think Anant and Ben Nelson, that's you.

### Conspiracy Advocate (CA)
Claim: So again, I think online learning as we know it-- I really called it online learning 2.0, because the old style online learning, it really gave online learning a bad name, and I think different today. Online learning today is completely different and you should go check it out. We have online labs. We have discussion forums. The kind of things we can grade are simply

### Moderator
Claim: that it's better now, but to her question how are

### Conspiracy Advocate (CA)
Claim: So if you assume this kind of quality of online learning-- I think at the end of the day it really depends on the content. If a great teacher created the online content or if a great teacher taught the in-person campus course and if the learner took one of the other and had a great experience and a degree, I would say that it shouldn't matter which one they did.

### Moderator
Claim: And do you think that's realistic that if two guys walk into job interviews-- walked in and one of them got a degree online and one got a degree at a campus, and we don't need to stipulate which one it was, that they're roughly equal in terms of the kinds of courses offered, but the employer is going to look at them equally?

### Conspiracy Advocate (CA)
Claim: I don't think so. I think if someone had enough money to pay for a completely campus experience and the same quality education they would have better soft skills, but I think the debate is about fewer bricks, more clicks, is the emphasis. So I think that on campuses to bring a lot more online learning, the blend of the online with soft skills and so on can be substantially better than anything they have on campus today.

### Moderator
Claim: Would the other side like to respond? Because the last two questions have gone to this side. If you don't want to I can move on. Let's move on. Give me a question that would be more focused toward this side? Ma'am, right here.

### Moderator
Claim: Yes. I was just curious for this side if you felt like maybe if future faculty or future professors took more training or became somehow more involved in the online world or, you know, that kind of iteration, they could still be a more competitive valuable part of--

### Moderator
Claim: That's a great question. That's a great question. It's almost a challenge to you, Rebecca Schuman, to get with the program.

### Scientific Advocate (SA)
Claim: With what funding. Yeah, I mean, maybe. I tried to flip my class last semester as an experiment, and it didn't go that well. But I used pretty good content. It was just that the students didn't like it. And what I find from talking to my students is that they do prefer the face-to-face experience. That's just what they prefer.

I-- you know, I don't know if I get really good at making podcasts or if I had some higher production values with my YouTubes or something, maybe. But right now I just-- I don't think it has to do-- the MOOC that I'm taking on EdX is gorgeously produced, and the guys are experts, and it's still just kind of dabbling, like it's not a replacement for a class yet.

### Moderator
Claim: Jonathan Cole, do you want to answer the question as well?

### Scientific Advocate (SA)
Claim: Well, I mean obviously-- it's a hypothetical and an interesting one. If more people had experience in producing these things, they might teach better courses. But we don't know. I mean, one of the problems that I have with this is that-- all of this-- is that it seems to me that there are many possibilities for technology and many ways in which technology can improve universities. But we don't know, for example, the answer to the question before, which is how do graduates of one form or another respond in terms of employment opportunities?

We don't know very much about different learning styles. We have so little evidence that it seems to me what we're doing is we are essentially casting our fate to the wind and saying, look, this is a possibility, not necessarily a fact, because we don't have very much empirical evidence to demonstrate the case of our opponents.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate where our motion is "more clicks, fewer bricks: The lecture hall is obsolete." And remember how you voted just before the argument began, right after these closing statements which will be two minutes each. You will be asked to vote a second time, and then our winner will be declared. So onto round three. Round three, closing statements from each debater in turn, uninterrupted. The motion: More clicks, fewer bricks: The lecture hall is obsolete." And here to summarize his position in support of the motion, Anant Agarwal, CEO of edX and a professor at MIT.

### Conspiracy Advocate (CA)
Claim: Well, I have to say, you know, there are some great statements from our colleagues. I would love to take a class from Rebecca. But this is not about comparing the absolute best that you can get in a particular kind of course against the online learning of yesteryear. I think we need to look at where is the average going to be? Where is the majority of the university, the classroom, the students going to be? And I think in Rebecca's case, she was able to recite the names of 15 of her students. In my case, it would take me forever to recite the names of 155,000 students that got something out of that course. But I will tell you-- very quickly about three students. Deward Mukendi He came up from a family of 14 from the Democratic republic of Congo. He goes to the University of Cape Town to learn computer science. In his first year, his father passes away.

He can't pay his tuition anymore, and so he goes off into the world, and he's been working for ten years. Now that online learning is available, he is going back to study, and he's taking these MOOCs, and he's learning. And he's saying, "I'm going to get a better job because of the kind of learning that I'm doing." I can give you name after name, Omobavay 15-year-old student from in India, took my course, did really well. He applied to MIT, and he got into MIT, now he's a sophomore at MIT. And at MIT, two out of three students today compared to virtually zero two years ago are now doing blended online learning. MIT moved into this in a big way. They're blending the classroom with a lot of online technology. So 2800 out of 4500 students at MIT are now using the edX platform on campus in a blended model. And this is just two years old. I think if we look at where the average is going to be, I think things are going to be very different going ahead. So I would like you to think about the average student in all the world in terms of where universities should be and given that, I really urge you to think about more clicks, fewer bricks in terms of increasing access and also improving the quality of education on our campuses.

### Moderator
Claim: Thank you, Anant Agarwal.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Our motion is, "More clicks, fewer bricks: The lecture hall is obsolete." And here to summarize his position against this motion, Jonathan Cole. He is the John Mitchell Mason professor at Columbia University.

### Scientific Advocate (SA)
Claim: Those of you among the jury sitting out there, consider closely whether my worthy opponents here-- I think they've made very interesting cases-- are espousing what is in fact fact, what is fiction, or what is wishful thinking. Let me conclude with three anecdotes. A while ago, I offered a course in law, science and society. It was designed to challenge the presuppositions and biases of the students. Frankly, it was designed to be both challenging and unsettling. At the end of the semester, one of my very smart students said to me, "I loved this course, the debates we had and the people I met. But every time I left this class, I had a headache.

Not knowing quite what I believed in any longer." and I said, "Sam, those headaches are a great thing. It shows that you were really thinking hard. And those debates and those doubts you had are an essential part of learning." no set of clicks will replace students' experience. Then there are the extremely popular courses at Stanford's D school, an institute for design innovation, where one of the assignments was to rethink how people eat Ramen noodles or an assignment that led to a news reading app that was bought by LinkedIn" for $90 million. The students came from every field, sciences, engineering, social sciences, et cetera. The students were taught by David Kelly, one of the school's founders. And they were invited to really think of developing empathy muscles. They were also taught to forego computer screens and spreadsheets and focus on people.

At the D school, says Kelly, we learn by doing. Sounds a lot like John Dugas's philosophy brought back to being. It's a huge success with students churning out dozens of innovative products and startups.

### Moderator
Claim: Jonathan Cole, I'm sorry, your time is up. Thank you.

### Scientific Advocate (SA)
Claim: Two minutes go by so fast.

### Moderator
Claim: They do. Our motion is "more clicks, fewer bricks: The lecture hall is obsolete." And here to summarize his position supporting this motion, Ben Nelson, founder, chairman and CEO of the Minerva Project.

### Conspiracy Advocate (CA)
Claim: I wouldn't want to end this debate without getting into the facts that Jonathan so desperately wanted us to get to. So I'll give you two facts. One fact is what we actually know, not about online education, but about off line education, not at the community college, not at a state university, but at our most illustrious universities. Professor at Harvard University, Eric Mazur who teaches physics wanted to know how much his students retained from his physics classes.

So he surveyed them two years after the end of the course. You know what their retention rate was? 10 percent. The question isn't as much whether or not online education is effective, is it can’t possibly be any worse than the existing model? In fact, even when you give students a choice, as was done with the very first MOOC, one offered by Sebastian Thrune at Stanford University. Sebastian Thrune is a celebrity. He is the reason why you go to courses. He invented the self-driving car. Neat guy. And he had a course of 200 students in artificial intelligence, and he gave them an option: Schmooze with me in the lecture hall or go on version 0.1 of this terrible product and take the course online. Of the 200 students, 85 percent never came back to the lecture hall. 85 percent decided to take the online course in the very first most rudimentary version of online education. You don't need much more data than that to realize that the future of universities won't be without bricks, won't be all clicks, but will certainly be far more clicks than bricks. Thank you.

### Moderator
Claim: Thank you, Ben Nelson. And that is our motion: More clicks, fewer bricks: The lecture hall is obsolete." And here to summarize her position against this motion, Rebecca Schuman.

### Scientific Advocate (SA)
Claim: Thank you. I just want to go on the record that Anant thinks I am the best at teaching. I'm going to put that in all of my review portfolios. So I want to talk a little bit about my class again, not naming them, but I'm talking about what we did this week. So I don't lecture. My room is a seminar room not a lecture hall. And this week we're reading "Things Fall Apart," by Chinua Achebe, one of my favorite books, one of the greatest books of all time.

And our activity this week was about proverbs from the Igbo culture and how they figure into the narration of the book. And so one of those problems is looking at a King’s mouth, one would think that he never sucked at his mother's breast. And I said to my class, "This is a very evocative proverb, very provocative, what do you think it means in relation to the protagonist, Okonkwo’s struggle with his masculinity?" And I just called on a student at random because I like doing that-- it's fun-- and he said, "uh, I don’t know, you should never forget where you came from?" And I said, "Okay, that's a start. Let's do it." So we went back and forth in the class, me back to him, other students to him, other students to me. If you want to know how it turned out, you're going to have to come to my class, but the point is that most of the students in the class had never thought about that proverb like that before. They had never thought about it at all. This was a moment that we created together. This was a moment we created together in real time, face-to-face, in the same room with energy you could feel, with energy between people that you could feel, and that changed us all just a little bit.

The second part of this motion is that the lecture hall is obsolete, and it's certainly true that in a thousand-person lecture, that kind of moment that you can feel is few and far between, but I don't think the answer is to put that lecture online in five-minute chunks. And I don't necessarily think it's to get rid of the classroom altogether for some fascinating sounding space technology of the future that I haven't seen yet, which sounds great. So that's why I hope that you will join our team in voting, "No," on the motion, "More Clicks, Fewer Bricks: The Lecture Hall is Obsolete." Thank you.

### Moderator
Claim: Thank you, Rebecca Schuman. And that concludes our closing remarks, and now, at this time, to learn which side you feel has argued the best. I'm going to ask you again to go to the keypads at your seat. And now vote a second time. And we're going to get the readout almost instantaneously. Same as before, you push number one if you're for the motion, number two if you are against, and number three if you became or remain undecided.

And we'll let the voting go on for about another 15 seconds, and then we will lock it out. And while that is happening, I just want to say a few things. One is our-- it's our first experience in coming up to Columbia, and it's been fantastic for us. And what really sealed that was the quality of this debate and the level of argument and enthusiasm and intelligence and decency and honesty and respect for one another that these debaters brought to the stage. I just want to thank them for hitting all of those marks-- which Intelligence Squared. We also want to give thanks again to Columbia University's Richard Paul Richman Center for partnering with us for this debate. It is the fourth time, and it's a great partnership. And we hope that it continues to go forward. We would-- yeah, We'd like to have you Tweet about the debate. The handle-- our handle is @iq2us and @columbia_biz, that's B-I-Z.

The hashtag for this debate is OnlineEd. Our next debate is next week in Midtown, April 9, at the Kaufman Music Center. It's Broadway and 67th. The motion that night is "Millennials Don't Stand a Chance." We're looking at the fact that the media often paints millennials as uniquely, you know, narcissistic and coddled and helicoptered, but we're asking also, "Are we so blinded to the qualities that they embody that we should be admiring like openness and optimism and innovation?" For the motion we have Binta Niambi Brown. She's a lawyer. She's a startup advisor. She's a human rights advocate who is named one of Fortune Magazine's 40 under-40 business leaders. Her partner is W. Keith Campbell. He's a psychology professor at the University of Georgia, and he is co-author of the book, "The Narcissism Epidemic." Against them, David Burstein. At 25 years old he has already directed two documentaries, founded a voter engagement organization, and published the book-- how annoying, really-- "Fast Future."His book-- I'm joking-- is "Fast Future: How the Millennial Generation is Shaping Our World." And his partner is Jessica Grose. She is a self-defined "ancient millennial." She's a journalist and author of the novel, "Sad Desk Salad." And then on May 7 our final debate of the season, where we debate the question, "Is death final?" Tickets for all of that will be at our remaining spring debates, on sale through our website, www.iq2us.org. And for those of us who can't join our live audience, there are many other ways to join our debates that involve going online. You can watch the live stream at iq2us.org, on fora.tv, and listen on NPR stations across the nation. I also want to say, Jonathan Cole, you sounded like you got cut off in your closing statement in the middle of something that sounded really well planned and eloquent. And I would like if you are okay with it to post your full text on our website so that it's-- so that it's up there.

### Scientific Advocate (SA)
Claim: I'm sure everyone's going to go to it, yes.

### Moderator
Claim: It wasn't just to make you feel better.

### Scientific Advocate (SA)
Claim: I appreciate the sentiment. I really do.

### Moderator
Claim: Okay. All right. So I have the final results. It is all in. You have voted twice. Our motion is: More Clicks, Fewer Bricks: The Lecture Hall is Obsolete. Remember, the way this works is the team whose numbers have changed the most between the two votes will be declared our winner. On the first vote on the motion: More Clicks, Fewer Bricks: The Lecture Hall is Obsolete, before the debate 18 percent agreed with this motion, 59 percent were against, 23 percent were undecided. Those are the first results. Here is the second round of voting. In the second round, the team arguing for the motion went from 18 percent to 44 percent. They picked up 26 percentage points. That's the number to beat. The team against the motion, their first vote was 59 percent. Second vote 47 percent. They lost 12 percentage points. This vote-- this debate goes to the team arguing for the motion: More Clicks, Fewer Bricks: The Lecture Hall is Obsolete. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
