# Debate Transcript

Topic: The GOP Must Seize The Center Or Die
Motion: The GOP Must Seize The Center Or Die

Debate ID: 041713%20gop


## Round 1

### Moderator
Claim: We always begin these debates by bringing out onto the stage the chairman of Intelligence Squared, Bob Rosenkranz, who frames this debate for us. So let's welcome to the stage Robert Rosenkranz. So we're just going to take a couple of minutes to explain why we're doing this debate. Bob, why did this one get on our board for the season?

### Moderator
Claim: Well, the reason it's timely is that, of course, Mitt Romney lost an election that he might have won, given the state of the economy at the time, and because the Republican National Committee just published a 100-page report that was very self reflective about why they might have lost.

### Moderator
Claim: So the Republican Party itself is putting this out there as a debate?

### Moderator
Claim: Absolutely.

### Moderator
Claim: And the side that's arguing for some sort of shift to the middle, what points are they making?

### Moderator
Claim: Well, the point they're making is that the GOP has alienated large parts of the potential electorate with, particularly, its stands on social issues, on things like gay marriage, women's freedom of choice, and immigration, and the thought is that those social parts of the GOP agenda are just fatal to their success in national elections and need to be rethought.

### Moderator
Claim: And the side arguing against it, what's the argument not to move to the center?

### Moderator
Claim: Well, I had a-- I actually posed the subject of tonight's resolution in a private chat with Mitt Romney a couple of weeks ago, and he said that he felt that there was simply no chance for a pro-choice Republican to win the presidency, and the reason he felt that way was because the most reliable Republican voters are evangelicals.

They're about 80 percent Republican. The counterweight to that is blacks and unions on the Democrat side, but if the Republican Party alienates those people who are their most reliable supporters they just cannot win.

### Moderator
Claim: So they without the base, they can't win?

### Moderator
Claim: That's exactly what he was saying.

### Moderator
Claim: All right, and that's straight from the candidate's mouth?

### Moderator
Claim: Right.

### Moderator
Claim: Now we're going to hear from four more mouths, our debaters. Let's welcome them to the stage and thank Bob Rosenkranz. Thank you. And I'd like to just invite one more round of applause for Bob Rosenkranz for making all of this possible. all possess, you and I, all of us here, something that the ambitious, and the powerful, and the wannabe powerful keenly covet, and that is our votes. The rules say that political parties cannot have power unless they first have our votes, and when they fail to get them, as the Republican Party did in sufficient numbers in the race to the White House in 2012, it inevitably sets off soul searching within the party. How did we fail to connect to the American voter? Do we need to change to do better next time? That is the debate that's taking place right now inside the Republican Party, and we are bringing it out now onto this stage. Yes or no to this statement, "The GOP must seize the center or die," a debate from Intelligence Squared, U.S. I'm John Donvan. We have four superbly qualified debaters who will be arguing for and against this motion.

As always, our debate goes in three rounds and then the audience votes to choose a winner. And only one side wins. The GOP must seize the center or die. On the side arguing for that motion, let's welcome David Brooks, an op-ed columnist for the New York Times. His partner is Mickey Edwards, a former U.S. congressman from Oklahoma. The GOP must seize the center or die. Arguing against that motion, Laura Ingraham, host of “The Laura Ingraham Show.” And her partner, Ralph Reed, founder and chairman of the Faith and Freedom Coalition. Our motion is the GOP must seize the center or die. Let's meet the team arguing for the motion. First, ladies and gentlemen, David Brooks. you are an op-ed columnist for the New York Times. In that position, often referred to as a moderate, you get a lot of flack from both sides. A few examples, the conservative blogger, Michelle Malkin wrote of you that you are "the Eddie Haskell of the fourth estate." The liberal writer, Jonathan Chait writes that you are-- "David Brooks is now totally pathological." My question to you, as somebody who's sort of getting it from both sides, does it hurt more when the zingers come from the left or the right to your bruised body?

### Conspiracy Advocate (CA)
Claim: It hurts more when it comes from intelligent people. So that would be the right.

### Moderator
Claim: Thank you, David Brooks. And, David--

### Conspiracy Advocate (CA)
Claim: That's my last one I'm giving you, Laura.

### Moderator
Claim: David, your partner is?

### Conspiracy Advocate (CA)
Claim: The lovely and glamorous Mickey Edwards.

### Moderator
Claim: Ladies and gentlemen, Mickey Edwards.

Mickey, you served as chairman of the American Conservative Union.

You are a founding trustee of the Heritage Foundation. You spent 16 years in Congress as a member of the House Republican leadership. That sounds pretty conservative. But if you ran for office today on the same platform you used to run on, would you be conservative enough to get nominated?

### Conspiracy Advocate (CA)
Claim: Are you kidding? I wouldn't get 5 percent of the vote.

### Moderator
Claim: Wow. That's pretty serious. Ladies and gentlemen, we want to hear more about that in detail. Mickey Edwards, ladies and gentlemen.

Our motion is the GOP must seize the center or die. And here to argue against that motion, let's welcome first Laura Ingraham.

Laura, you host the eponymous show, “The Laura Ingraham Show.” You were not happy with how the Mitt Romney campaign went in 2012. And you said quite plainly that election should have been a "gimme," given the situation in the economy, among other things. And you said this: "if you can't beat Barack Obama with that record, then shut down the party." How literally did you mean that?

### Scientific Advocate (SA)
Claim: Well, "shut down the party," as in, let's say a college basketball coach has a perpetually losing record. You don't then give the coach a raise. You get rid of the coach. So all of the people running the Republican Party, Reince Priebus, nice person. Why are they still employed? And all the people in leadership should be gone, and we should have a new crop of people running it.

### Moderator
Claim: What do you really think?

### Scientific Advocate (SA)
Claim: That's what I think.

### Moderator
Claim: Ladies and gentlemen, Laura Ingraham.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: And, Laura, your partner is?

### Scientific Advocate (SA)
Claim: The ever-cutting-edge Ralph Reed.

### Moderator
Claim: Ladies and gentlemen, Ralph Reed.

Ralph, you're also arguing against this motion that the GOP must seize the center or die. You are actually-- legitimately can claim to be part of American political history in the 20th century. You were the first executive director of the Christian Coalition. You are the founder and chairman now of the Faith and Freedom Coalition. Time magazine once named you "the right hand of God." mean, that's a very, very-- you know, very heavy--

### Scientific Advocate (SA)
Claim: They apparently didn't know that that seat was taken.

### Moderator
Claim: Ladies and gentlemen, Ralph Reed. Our motion is, "The GOP must seize the center or die." We go in three rounds of debate. Before we do that, however, we have you, the live audience, vote to tell us what your view is on this motion as you come in off the street. If you go to those key pads at your seat, you can register your vote. If you are in support of this motion at this point, the GOP must seize the center or die, press number one on your keypad. That means you're with this team at this point. If you're against, you're with this team, push number two. If you're undecided, push number three. You can ignore the other keys. And if you feel that you pushed the wrong button, just correct yourself, and the system will lock in your last vote. And the way this works, at the end of the debate, we have you do this again.

And we get the results almost instantaneously. And the team whose numbers have changed the most in percentage points will be declared the winner. Onto Round 1, opening statements from each of our debaters in turn. They will be seven minutes each. Arguing on this motion, the GOP must seize the center or die, and here up to argue first in support of the motion, David Brooks. He is an op-ed columnist for the New York Times, a commentator on the “News Hour with Jim Lehrer” and a former senior editor at the Weekly Standard.

### Conspiracy Advocate (CA)
Claim: Now, I did this once before, and the competitive juices got going, and I turned into an insufferable jerk attacking the other side. So before I do that, I want to just express my love and admiration for my opponents. We came into this business together, Laura, the slowly aging portrait of Ralph that he keeps in his attic, and I-- just complete admiration for them, the fact that they-- the Democrats have hired them to burrow within the Republican Party and to destroy it from within, I do not hold against you.

Now, I admit I was on the left at one point. In the '60s, my parents took me to a "be in" where hippies would go just to be. And to demonstrate their liberation from money and material things, they threw their wallets into a garbage can. I was five. I saw a five dollar bill on fire in the garbage can. I ran into the fire, grabbed the money and ran away. And that was my first step over to the right in my life. Kept going. But we had one other influence in my family, which was my grandfather and his father, immigrants, lower east side, a Jewish kid trying to make it in the city. We had the attitude, the think Yiddish act British attitude, "We'll fit in." We had the dream of making it in the city which meant making it in this neighborhood where we're standing, in the upper west side, the Upper East Side.

And that was the-- how the Republican Party was started. It was started by Abraham Lincoln, a poor boy in Illinois who wanted to make it. And he did it when he was in the state legislature, using government to give poor boys and girls the power to make it and achieve social mobility. He created it by creating a state bank to invest, building canals and railroads. He got to the presidency, created railroad legislation, Homestead Act, Land-Grant College Act, even introduced the income tax. It was using government to give poor boys and girls a chance to succeed. And that was still around when I got there, when I got to Washington. Ronald Reagan, a much more pragmatic and flexible person than is now portrayed by many people on the right, it was about using government in limited but energetic ways to give poor people a chance to succeed. Reagan did it. Is the Republican Party doing it now? I think they have not because they've been so hostile to government. Ronald Reagan was more pragmatic than the current Republican Party.

It's also no longer 1980. Now if you want to rise and succeed, it's not enough just to work hard and row a boat across the Ohio River like Lincoln. Think of a poor girl who wants to be like Lincoln today. She can't just work hard ferrying people across that river. She grows up probably without a father. She grows up in a chaotic community with low social trust, high economic pressure, few community bonds. To succeed, she's probably going to need some language instruction. She's probably going to need some early-- some protection from early childhood distresses that'll destroy her self-control. She's going to need institutions that'll help her build relationships so she can use people as tools for learning throughout life. She's probably going to have to spend 21 years in education to qualify for a middle class job. And so what does the Republican Party today have to say to her? Almost nothing. This party is encased in a simplistic and archaic metric, government versus the market. Government bad, the market good.

If you're an energy executive or chemical executive, maybe the government is your central pain. If you're that little girl, the government is not your big problem. If you're that little girl, the government, through Pell grants is sometimes the solution at helping you work hard and becoming a better capitalist. Does the Republican Party offer anything? No, which is why Asian Americans, for example, voted against the Republican Party three times to one. The Republican Party has become so hostile to government that they find it very hard to have anything positive to offer. So hostile to government they can't really stand for social mobility, the cause they started with. And so this is a party that has lost the essence of having a positive agenda even in the cause that was its founding principle. And the country knows that. Republicans have lost five out of the last six popular votes in the elections. They've lost the Senate. They should have won. They held onto the House by force of redistricting. The Republican party has a 33 percent overall approval rating when the Democrats have 47 percent. You take every rising group in America. The Republican Party is losing that group. Latinos, by 4 to 1. Asian Americans, by 3 to 1. African Americans, by 9 to 1. People in single households by 2 to 1. They're getting slaughtered among young people. If this electorate, and the electorate of the 20th century, was made up of 85-year-old men-- white men, the party would be doing awesome. This party is not that party. This party sometimes looks like the receding roar of a white America that's never coming back and has to move to recapture that. It has-- and what is the people's top criticism of the Republican Party? Recent Gallup poll this week, the top criticism is they do not compromise. So this is a party going down the drain. It's a party that's unwilling to compromise on budgets, unwilling to compromise on guns, apparently unwilling to compromise on immigration.

Bob Bennett of Utah, a very conservative guy, thrown out of the Senate for working with a Democrat. I had lunch with the fourth most conservative member of the Senate - - terrified of getting primaried from the right. Unwilling to have any flexibility. Becoming an uncompromising party. To me, this is a party that has to tackle two big issues. The first issue is the welfare state, which is making us unsustainable. The second issue is that little girl and the social immobility, the social segmentation that Charles Murray writes about. And my advice to the Republican Party: don't move to the center for the sake of moving to the center. The center is nothing. Move to the center for the sake of that little girl, which is your founding principle, which is social mobility. Do right by that little girl and you'll do right by yourself politically. And that means having a positive agenda. It means being more flexible. It means being prudent and sensible, not a party of a red rump of America.

And so, I don't necessarily want to call the party to the center just for centrism. But I want to call them back to their essence as a party. And so, I ask you to vote for the proposition. Thank you.

### Moderator
Claim: Thank you, David Brooks. Our motion is the GOP must seize the center or die. And now here to argue against the motion, Ralph Reed. Ralph Reed is the founder and chairman of the Faith & Freedom Coalition and former executive director of the Christian Coalition. Ladies and gentlemen, Ralph Reed.

### Scientific Advocate (SA)
Claim: Thank you very much. It's great to be here on the Upper West Side of Manhattan, or as I like to refer to it, my mission field. I feel a little bit more at home since I got to walk past Lincoln Center. Makes me feel a little more at home to know that a Republican president has something named after him in this part of town.

And you know, it's good to be here with Mickey Edwards and David Brooks, who was often referred to in Republican ranks as “Obama's favorite conservative.” And I'm looking forward to a very lively and spirited debate. You know, I think for those of us who grew up in this party-- and I knocked on doors and walked precincts in my first campaign for a Republican candidate, 35 years ago-- we've seen this movie before. Virtually everything that David just said from that podium would have been said in 1949 after Dewey lost. It would have been said in 1965 after Barry Goldwater lost. It was said in 1977 after Ford lost. It's been said every time the Republicans lose a major election. And I would just say, paraphrasing Mark Twain, “When it comes to the Republican Party, the premature reports of its death are greatly exaggerated.”And in fact, I would argue that in spite of a personal defeat for the party's presidential nominee, that in fact, if you look across the board, in spite of the polls that David cited, the Republican Party is institutionally and demographically stronger than it's been in decades. And if you don't believe me, I'll walk you through the statistics. First of all, look where the Republican Party was after Hoover and the Depression: 36 in the Senate, 117 in the House. Look where they were after Nixon and Watergate, after those devastating defeats following scandal and humiliation and national failure. And the party's brand then was even lower than it is now. 36 in the Senate, 144 in the House.

Even after George H.W. Bush, after his defeat by Bill Clinton, the worst defeat, by the way, for an incumbent president since Hoover in 1932. The Republicans at that point stood at 44 in the Senate and only 166 in the House. You compare that to today where they have 30 governors compared to the Democrats' 20, and there's no question that the Republican governors, whether it's Nikki Haley in South Carolina. or Scott Walker in Wisconsin, or Bobby Jindal in Louisiana, or Chris Christie in New Jersey are among the most popular reformist conservative forward looking governors in the country, reforming education, reforming public sector unions, balancing budgets without raising taxes. The same policies that we're being told are repudiated and dead, and can't be sold anymore, are more popular than ever at the state level.

And the truth of the matter is that that's not just at the gubernatorial level. The Republicans elected over 700 state legislators in 2010. They controlled both Houses of 24 legislatures to only 13 for the Democrats. So I tell you what the Democrats are going to find out. They're going to find out that second terms of two-term presidents aren't a lot of fun. For Eisenhower, it was the recession, Sputnik, and a heart attack. For Nixon, it was Watergate and Vietnam. For Clinton, it was impeachment. For Reagan, it was the loss of the Senate, and ideological control of the House in '86, and Iran Contra. And, of course, George W. Bush, Katrina, and Iraq. Second terms aren't a lot of fun, and there's only been one president in the post-World War II period who won House seats in his second off year election as a two-term president, and that was Bill Clinton in 1998.

So just keep that in mind when you listen to all these premature obituaries. I'll quote you one from 1993. This was by the then outgoing RNC chairman, and he said, "We should not cling to zealotry masquerading as principle and stale ideas of a dead and dying past." Sixteen months later, the Republicans gained control of the House and Senate for the first time in 40 years. My second point would be we've tried this before. This formula's been applied. If you don't believe me, go to California, a state that once produced Nixon, Reagan, and other great conservatives. They moved to the mushy middle. They nominated candidates for statewide office that were pro- choice, pro-gay rights, and fiscally moderate.

And today it is fair to say that the Republican Party stands on the verge of extinction, having followed these same policies that are being recommended now. Only 25 out of 80 in the California assembly are Republicans, only 11 of 40 in the state Senate, following this same playbook that's now being recommended nationally. And the other thing I would remind you is this is not going to be a freebie. If the Republican Party walks away from core conservative convictions-- remember that 27 percent of the electorate is self-identified evangelical Christian, 10 percent are frequently mass- attending, pro-life, pro-family Catholics. They voted 75 to 25 percent for Mitt Romney. That constituency is larger than the African-American vote, the Hispanic vote, and the Union vote combined. And if this party retreats from those core conservative principles, those folks will stay home or support a third party, and then the Republican Party will become the Whig Party.

One last thing because I'm running out of time. I'm an old high school and collegiate debater. Defining terms really matters, and we're in a debate. And remember what this resolution says. It says the Republican Party must seize the center, that is to say become a party that splits the difference between where it is now and where the Democrats are, basically become a Democrat light, or it will die. It doesn't say, "lose elections.” It doesn't say, "under perform among minorities." It says, "it will die." Now, based on what I have just told you about the state of the Republican Party today, there is no way, intellectually, to agree with that resolution. Thank you very much.

### Moderator
Claim: Ralph Reed, your time is up. Thank you very much. And a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. Debate where our motion is the GOP must seize the center or die.

I'm John Donvan. We have four debaters, two teams of two arguing both for and against. You have heard the first two opening statements and now onto the third. To debate for this motion that the GOP must seize the center or die, a former eight-term Republican congressman from Oklahoma, vice president of the Aspen Institute and a founding trustee of the Heritage Foundation, ladies and gentlemen, Mickey Edwards.

### Conspiracy Advocate (CA)
Claim: John, thank you.

Well, it's a great privilege to be able to be here at Intelligence Squared. Thank you very much for doing this. It's great to be here with my friend, David Brooks, and also to be here with my friends Laura Ingraham and Ralph Reed who have devoted so much of their lives to fighting for principles they believe in. And I admire them both. I hope they lose badly, but I admire them both. I think the question here tonight is-- to put it even more bluntly: do the positions that they are speaking in behalf of serve this country well?

And if they do not, if they do not stand for where America is and where America is going, what claim can they make for support from the American people who find a party that is increasingly at odds with the new, more tolerant, more diverse population that is going to elect America's political leaders for years to come? The fact is, Ralph, this is not the country of 1964 that the party recovered from. It's going to be much harder to recover in a society that looks like the one we have become. Let me be clear. I do not think the problem is that the Republican Party is conservative. The problem is that what it advocates-- what they advocate very sincerely is not at all consistent with what American conservatives have traditionally stood for, certainly not in the days of Ronald Reagan, who almost definitely could not win a Republican primary today.

It's not consistent with the days when the Republican Party stood for things like prudence and responsibility and they did not attempt to dictate to the people how they were supposed to live and what their values were supposed to be. I spent a good many years championing the Republican Party and conservatism. Among the other things, besides chairing the American Conservative Union and the Conservative Political Action Conference, I chaired Ronald Reagan's 1980 policy task forces for his election. And I have watched this country change, and I have watched the Republican Party also change in the opposite direction. Americans still agree with conservative principles.

They defend the right of citizens to own guns. But they don't applaud a party that supports people being able to carry loaded guns across state lines and into restaurants and schools and churches. The people support conservatism, but they don't support a political party that can't refrain from carrying every sound and defensible principle to its unacceptable extremes. You know, Ralph quoted people like Bobby Jindal, who has been giving speeches saying that what you're advocating will destroy the Republican Party. The people will support a political party that wants a smaller deficit and lower taxes and small government, but they're not going to support a party that draws the line, and when they're offered a chance to have lower taxes and smaller government, they say, “No, we're unwilling to compromise, accept any kind of a tax increase,” who are willing to say that compromise is bad, compromise is evil.

You know, I'll tell you, compromise is what makes a nation of 300 million people work. And without compromise, drawing a line in the sand, you can't make it. Real conservatives support free enterprise and small business but not giant corporations with giant tax loopholes. And yet today's Republican Party would fight to the death to protect every single tax advantage of the wealthy, so they leave it to the middle class to pay for the wars and the roads and keeping the drinking water safe. So we have two questions, and one of them goes directly to a point that Ralph made. What does it mean to move to the center? I would not suggest that moving to the center means finding some precise magical spot on the 50-yard line of public opinion, but engaging in a rational politics that is within the range of reasonable and thoughtful discourse, a politics that stands for principle, as Ralph and Laura do, but also stands for the principle that self-government, government of the people, works.

And in a nation of 300 million people, that means not just drawing a line in the sand, but fighting for what you believe, make your case, argue for it, get as much as you can and then find the common ground so that we can move together as one people, as one America. That's what the American people don't see. That's what the American people do not see in today's Republican Party. So people are fleeing from the political parties largely because of the dysfunction in Washington that traces back in large part to the kinds of people the Republican Party attracts and nominates for office. Will it doom the Republican Party? You saw Barack Obama with his numbers down and the economy in a mess get reelected. Laura has written that it's Mitt Romney's fault. Why did Mitt Romney do things that alienated the people? It's the only way you can win a Republican primary today, is to say the kinds of things that he did. the-- and in terms of the other things, the nonpresidential races, we had this great chance in the Republican Party to win control of the Senate. Everybody thought we would win control. Democrats were going to lose control of the Senate. In fact, they gained seats. Why did they gain seats? Because Republicans put up candidates that allowed Democrats to win the Senate seats in Delaware, Nevada, Missouri, Indiana, who-- those were states where people were inclined to think good of Republicans, but they just could not go there. So the other question is what it means to be a political party. And it's not just about catering to whatever part of the population one agrees with, but being a serious contributor to the governance of America. So what's really at stake here are two things: Whether a hardcore, unyielding, uncompromising Republican Party can survive, and second, whether it should.

The Republican Party must come back to the conversation, to the deliberation, to the search for common ground, to that broad range that makes up the rational center, or it, my party, will disappear, and it should. Please vote for the proposition.

### Moderator
Claim: Thank you, Mickey Edwards. Our motion is "the GOP must seize the center or die." And now to speak as our final debater against the motion, Laura Ingraham. She is host of “The Laura Ingraham Show.” She is a contributor on the FOX News channel and also is a best-selling author. Ladies and gentlemen, Laura Ingraham.

### Scientific Advocate (SA)
Claim: Great to be here. And I have deep admiration for all of my co-panelist debaters. No snarky comments. All of them contribute to the dialogue, and I really appreciate the opportunity to be here. Last-- on Saturday, I was at the NRA 500. Do you guys know what that is?

Anyone in Manhattan know-- it was a NASCAR race in Dallas. What a great country it is. I could be at the NRA 500, be here with you today. Is there any crossover audience, any people-- oh, none. Darn. I'm totally losing already. I'm a duck out of-- I'm a duck out of water, okay? I'm really a duck out of water here because for me, a centrist is someone who owns only two guns. Oh, come on. I have a question, if this thing is tied by the end, does the Supreme Court actually pick the winner like in 2000? Can we actually get Justice Scalia to write the opinion? I have to say that debating with David Brooks and Mickey Edwards, the politics-- David Brooks, an esteemed columnist for the New York Times, in New York is like-- it's like Barack Obama debating Wayne LaPierre about gun control at a gun show, okay? The odds are definitely stacked against us. But you must vote against this proposition. A couple of points first to Mickey's argument.

If Mickey's argument is correct, then one would think that in the bluest of states, which would be very hospitable to moderate Republican views, quote, "centrist views," people like Scott Brown would be victorious. Scott Brown obviously went down in flames. One would think that someone like the very centrist Tommy Thompson of Wisconsin would have won his Senate seat. Unfortunately Tommy Thompson, thought of as a middle-of- the-road Republican, went down in flames. Republicans had their issues, but for every Todd Aiken and Richard Murdoch, I can cite a Republican moderate who could not make the grade. The proposition should be rejected because moderate Republicanism, going to this mythical center, has been tried, and it has failed repeatedly. Last two elections. The Republican Party already died. It died in 2000 with the elite's choice, which was John McCain. Remember, back then, Mitt Romney was the insurgent candidate. I supported Mitt Romney in 2008.

He was going up against John McCain, who was for immigration reform. He worked for Ted Kennedy on a bunch of issues. He was for McCain-Feingold. John McCain was the media's favorite Republican. John McCain went down in flames. Move forward to the last election. Everyone said, “The only guy who could beat Barack Obama would be Mitt Romney. Couldn't be that Rick Santorum. Certainly couldn't be Newt Gingrich.” Gosh, Jon Huntsman, the other moderate Republican, he got no traction. Lo and behold, Mitt Romney ran. Mitt Romney lost. Moderates usually lose elections with few exceptions. And before you pull out the “Chris Christie is a moderate and everybody loves him” example, let me tell you what The New York Times said about Chris Christie in 2009: Chris Christie, described as plainly conservative on issues such as school choice, rolling back regulations, and very restrictionist on abortion. Chris Christie won the governorship of New Jersey with the help of people like yours truly, the early Tea Party and conservatives.

He was no middle-of-the-road centrist when he won. The proposition should be rejected for another reason. The mythical center. The proposition misunderstands what the word center means. Think about this. You don't seize the center. You create the center. Think about this. George Bush saying that conservatives should be more compassionate. Or Marco Rubio saying that you have to agree with Chuck Schumer on immigration. You say that. I don't know what you-- what you've seen, but to me, it seems a little bit more weak than you would have seemed if you just said, “You know, these are my views. Take them or leave them.” But Barack Obama-- did he seize the center in, let's say, 1994? When Newt Gingrich was changing the face of Republican politics in 1994 or when Ronald Reagan was triumphantly winning elections in the 1980s, did young Barack Obama say to himself, “Gosh, I've got to seize the center.

I've got to move and adopt a new point of view, and a new tone, and a new idea, because guess what? Conservatism is all the rage. Unilateral disarmament is out the window. I need to seize the center.” Of course he didn't do that. And he was very smart not to do that. Constantly changing viewpoints are a fact of life in the United States. They usually change when someone makes a coherent, strong argument that the status quo is unacceptable, that the policies that are being advocated by the other side actually don't help the American people. So that to say, “seize the center or die” doesn't mean anything. I can remember when the center was the Defense of Marriage Act. Barack Obama believed in that centrist position. So did Bill Clinton. So did Hillary Clinton. So did most Americans. The left found a new way to approach it and guess what? The center changed.

I can remember when the center position was for the war in Iraq. David was a big supporter of the war in Iraq, as was I. But guess what? Facts changed. Circumstances changed. Arguments changed. The center changed. Does that mean that people who had a principled view about the war in Iraq should seize the center and just admit that the war in Iraq was wrong? If that happened and, David, you wrote that column, I must have missed that. The proposition should be rejected because it misunderstands what a political party is. Mickey touched on this-- and I agree with him on this point. A political party doesn't exist just to get elected, right? A political party exists to make people's lives better. Edmund Burke-- I'm sure a lot of fans of Burke out there. But Edmund Burke said that, “Look. A political party is to implement certain agreed on principles. And by the way, it should-- you should reject the entreaties of the elites who will urge you to change your principles to fit the mood of the day.”We saw, time and again, people who come across as flip-floppers. They want to change their views for political convenience. And time and again, those people are rejected as candidates. A party does not exist to win elections. If it did, then guess what? We would have a different scenario today in the United States, because, guess what? Flip- floppers don't win. Would anyone have agreed that the center position of-- about slavery-- you think slavery is a good thing? Slavery in America is a good thing? That was a centrist position in 1850 during the famous 1850 compromise. That center changed. And it should. We had Abraham Lincoln. He came around and guess what? He was a Republican--

You must resist-- thank you.

### Moderator
Claim: Thanks, Laura Ingraham.

### Scientific Advocate (SA)
Claim: You must resist-- thank you.

## Round 2

### Moderator
Claim: Laura, your time is up. Thank you, Laura Ingraham. that concludes Round 1 of this Intelligence Squared U.S. debate where our motion is "The GOP must seize the center or die." Keep in mind how you voted at the beginning of the debate. We're going to have you vote again at the end of the debate, and the team who's moved your views most in percentage terms will be declared our winner. Now we move on to Round 2, and that is where the debaters address each other directly, and they answer questions from me and from you in our audience. We have two teams of two arguing this motion, "The GOP must seize the center or die." We have David Brooks and Mickey Edwards in support of the motion. We've heard them say that the Republican Party has become too hostile to government, that it is losing ethnic minorities and young people, and that those are two growing groups. They say that resistance to compromise is not a winning message and that the party has found itself at odds with the more diverse population. The side arguing against the motion, "The GOP must seize the center or die, Ralph Reed and Laura Ingraham.

They've argued that the sky is not at all falling for the GOP, that the GOP is doing very, very well in the states and in local governments, that it has had these losing streaks before and has bounced back, and that never has a move to the mushy middle, as they called it, turned out to be a winning strategy, and if they tried and compromised their core convictions, they would alienate a base that is too large to be alienated. They would lose. I want to put a question-- I see that we're already debating this whole notion of what are we talking about when we say there is a center. And I want to put to the side arguing against the motion-- against the notion of compromise on this. You have said that the center is really a moving target; it can change by the month or by the year. One of your opponents, Mickey Edwards, put it a different way. He talked about the center as an approach to your opponents, an approach to the process, that it's a willingness to compromise, and that ultimately being willing to go to the center is a willingness to go to the common ground, and when you get there, that's where the center is.

I'd like you to take that on and elaborate more on this debate about what we mean by "the center." Laura Ingraham.

### Scientific Advocate (SA)
Claim: Yeah, well, I-- again, I think that the center is a moving target. When you say "seize the center," which is the proposition of the debate, what does that mean? I'm looking at the hole that--

### Moderator
Claim: But allow me to interrupt you because you just made that point. And my question to you-- request to you is to respond to his point that it's a style of government and a willingness to compromise.

### Scientific Advocate (SA)
Claim: Well, a compromise over what? If you compromise over the core principles of your party, then you are ultimately representing nothing, and you might as well just be a shimmer or a figurehead, representing nothing. So compromise on, "Well, we're going to spend X amount of money versus Y amount of money," oh, that's compromise, I understand what you're saying. But when you say "seizing the center," that stands for a set of principles. In the liberal lexicon, seizing the center for Barack Obama never meant, "Okay, I'm going to actually now look at the way we spend our military money or the way we run our foreign policy differently."He doesn't believe that's seizing the center. Compromise only exists when it sets about to erode conservative principles.

### Moderator
Claim: So you're saying there are situations where there cannot be compromise, where--

### Scientific Advocate (SA)
Claim: Well, yes. Yes, I am.

### Moderator
Claim: Okay. All right, I want to take that point back to the other side, David Brooks or Mickey Edwards, either side-- either-- first Brooks.

### Conspiracy Advocate (CA)
Claim: Well, I guess the first thing I've noticed about this debate so far is our esteemed opponents are mostly talking tactics and we're mostly talking substance.

### Scientific Advocate (SA)
Claim: No, actually not.

### Conspiracy Advocate (CA)
Claim: So they've talked about how to win elections. Mickey and I have talked about how to solve problems. Mickey talked about the problems of political dysfunction in Washington, and that's to start with a position and then behave in a prudential manner to try to ease political dysfunction in politics, and that's a centrist position, which involves the practice of patriotic service to the country, understanding there are two sides and both sides contain some truth. I talked about social segmentation, a problem that Charles Murray has talked about, a problem that I think can be addressed with limited but energetic government.

We've talked about how to solve those two problems, so neither of us has talked about moving to the center--

### Moderator
Claim: But the response I heard-- the response I heard from Laura was that her opposition to compromise is that in certain situations for a party to compromise makes the party not stand for itself, and I see the logic of that. I'd like you to respond to that point. Mickey Edwards.

### Conspiracy Advocate (CA)
Claim: You know, it's not about the party standing for itself. It's about the party standing for the country. You know-- James Madison is my hero. I love Madison, the champion of limited government. But he was also for government. The Constitution was not just to put constraints on government but to empower government to act in a reasonable, rational way as a nation. This is not a collection of disparate ideas. This is a full-fledged nation of people who must come together if they're going to do anything worthwhile. Government doesn't have all the power.

Government doesn't have all the responsibility, but government does have some responsibility. And that's where the Republican Party is copping out.

### Moderator
Claim: Ralph Reed.

### Scientific Advocate (SA)
Claim: Well, I would say, first of all, to David's point, David, what we've been debating is the resolution. And what the resolution says is that the Republican Party must move to the center or die. Now, I haven't heard the other side define these terms. I offered my definition. I'll give you a further definition from Merriam’s, which is “The center is the middle point that is equidistant to both end points on a sphere,” okay? That's what the center is. So we're not going to let you off the hook by saying, you can be a conservative, but you've got to compromise. The resolution makes it very clear that the point to which you must compromise is the point that is equidistant between Democrats and Republicans.

The resolution further says that if the Republican Party doesn't do that, that it will die. Now, ask yourself, if you're Governor Scott Walker in Wisconsin, and you want to reform the pension program for public employees, because if you don't, it's going to bankrupt your stay. And then that young lady that David's so concerned about isn't going to be able to get any social services because the state's going to be bankrupt. And he offers a proposal that the public unions opposed. And then it goes to a vote. Where is the compromise? They tried to recall him. You want to know what? He won the recall election by a bigger margin than he won the original election because he stood on principle, and he didn't compromise away his principles.

### Moderator
Claim: All right, Laura Ingraham.

### Scientific Advocate (SA)
Claim: I want to add to that. I mean, the argument that Mickey and David are making-- and that I would say it's not a substantive argument.

I would say American greatness conservatism, which was at the crux of much of what David Brooks argued for during the Bush years, supporting a larger, more energetic federal government, supporting not only the war in Iraq, but the war in Afghanistan. It was an utter failure. It grew the deficit. It ended up losing the Republicans, their hard- fought gains in the Senate and the House of Representatives. And by the end of this moving to the center of the Bush administration, the Republicans had lost the House, the Senate and turned the White House over to the most liberal president ever to step foot in 1600 Pennsylvania Avenue. So the Republican Party moved to the center, David Brooks-- I like you very much-- and it got clobbered. And only when it moved away from the--

### Moderator
Claim: All right. David Brooks.

### Scientific Advocate (SA)
Claim: --center did it win in 2010.

### Conspiracy Advocate (CA)
Claim: Let me think about the--

### Moderator
Claim: David Brooks.

### Conspiracy Advocate (CA)
Claim: --the centrist Republican Party we've seen over the last ten years. The centrism of Tom Delay, the centrism of Newt Gingrich.

### Scientific Advocate (SA)
Claim: George Bush.

### Conspiracy Advocate (CA)
Claim: The centrism of Mitt Romney. We talked about makers versus takers who had a deportationist immigration policy.

We have not seen a centrist Republican party.

### Scientific Advocate (SA)
Claim: Was Bush centrist?

### Conspiracy Advocate (CA)
Claim: No. He was--

### Scientific Advocate (SA)
Claim: He wasn't?

### Conspiracy Advocate (CA)
Claim: No.

### Scientific Advocate (SA)
Claim: Okay. Well, I haven't seen that column written by you.

### Conspiracy Advocate (CA)
Claim: I don't write about Bush so much anymore.

### Scientific Advocate (SA)
Claim: Last time I checked, you were defending the surge in 2008 when the country, the center was against the surge. You wrote a column, June 24, 2008, defending the surge as the right thing to do against the center of the country that was against the war in Iraq. You wrote that column, I didn't.

### Conspiracy Advocate (CA)
Claim: Wait, did--

I support the surge, and I supported the surge. The surge is not exactly the crucial issue in 21st century American policy.

### Scientific Advocate (SA)
Claim: Iraq is pretty important to me.

### Moderator
Claim: We would have lost the war without it.

### Scientific Advocate (SA)
Claim: Barack Obama wouldn't be president if the war in Iraq hadn't been fought. Hillary Clinton would be President of the United States right now.

### Moderator
Claim: All right, all right. You know, we've done a bunch of debates on the war in Iraq and--

### Scientific Advocate (SA)
Claim: Well, we're talking about the center.

### Moderator
Claim: And they were good, and they're available as a podcast.

At IQ2 U.S.

Let me put something else into the conversation here. And it was the argument made by the side arguing for motion, that the party as it now stands is losing touch with-- has lost touch with growing segments of the population, that part of the population being the young, maybe some segment of women and ethnic minorities. And I just want you to take that on. And Ralph Reed, I acknowledge your point, and I want to take it to the other side ultimately, that you're also talking about the basis, it cannot be alienated. But right now, take on their point, because again, I see the logic to that, and it's hanging out there, so I'd like you to respond to it.

### Scientific Advocate (SA)
Claim: Yeah, I mean, here, again, those who counsel moderation, trimming your sails, moving to the, quote, "middle," never succeed in winning minority votes. The candidates who do well among minority voters-- and, Mickey, I know when you were one of the most conservative members of the House, serving in the '80s, you regularly won large percentage of the African-American vote in your district.

Conservatism is not anathema to minority voters. And in fact the high water mark in the post-World War II period for a Republican presidential candidate in winning Hispanic votes was George W. Bush in 2004. And if you look at that, he won 44 percent of the Hispanic vote. You look at the Hispanics he did well among, he over-performed among self-identified conservatives. 40 percent of Hispanics self-identify as conservatives, 22 percent are Evangelical, another 25 percent are faithful Catholics, 2 million of them are small business owners. And that's how you win their votes. Bush won 75 percent of Evangelical Hispanics. They're pro-life, they're pro-marriage, they're for lower taxes. These are conservatives. So you don't-- it's not an either/or.

You know, Mike Huckabee who is a pro-life, pro-marriage conservative, won 60 percent of the African-American vote in Arkansas.

### Moderator
Claim: Let me stop you there and take it to this side because I see your point. They really punched some holes in your argument that the party is-- you know, your comment about if it were for old white men, that would be terrific. But they're actually saying that there is not a natural alienation between the current conservative views of the party and minorities, women and young people. David Brooks.

### Conspiracy Advocate (CA)
Claim: There's a lot of chum being thrown in the air, a lot of tracers flying up. The idea we should be debating the surge, that's a little bizarre.

### Scientific Advocate (SA)
Claim: The center-- the center of the country was wrong.

### Conspiracy Advocate (CA)
Claim: The idea that Republicans did well among Hispanics, it's bizarre. They did not do well among Hispanics.

### Scientific Advocate (SA)
Claim: I said when George W. Bush ran, and you said he was a conservative.

### Conspiracy Advocate (CA)
Claim: Well, he had a much better immigration policy than the current Republican Party does, I'll grant you that. And he had an immigration policy which involved comprehensive immigration reform. So that's the kind of centrism I can support.

It's an immigration reform that includes something for Democrats, something for Republicans and most of all a lot for the country. It's the sort of immigration reform--

### Scientific Advocate (SA)
Claim: But you just said that George W. Bush wasn't a centrist.

### Conspiracy Advocate (CA)
Claim: Ralph-- Ralph, come on. Let me finish.

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: It's the kind of immigration reform that includes getting new skilled workers into this country. It's the kind of immigration reform that involves increasing economic growth, welcoming the sort of people into this country who pay taxes over their lifetime and create the country. It's the kind of immigration reform that George Bush supported, that’s centrist--

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --if you want to call that-- let me finish that. It’s centrist Republican supported, it's the kind of immigration reform that is now in mortal peril because of a Republican Party that has gone to the red rump. And if they defeat this immigration reform in this election--

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: --they might as well write a suicide note.

### Moderator
Claim: David, I need you to park the car and let Laura Ingraham--

### Scientific Advocate (SA)
Claim: Let me-- let me--

### Moderator
Claim: --Laura Ingraham respond, then I'll come back to you.

### Scientific Advocate (SA)
Claim: I happen to have a Latina daughter, okay? She's almost eight years old. And I take this issue very seriously. And I take the issue of immigration seriously. I believe in it. I believe it adds enormously to the fabric of our society. But the resolution on the table is the Republican Party must move to the center or die. And we are arguing about George W. Bush only because George W. Bush is the most recent national example of a Republican that all the individuals under the age of 35 remember. If you're under 35, the only national Republican you really have any experience with is George W. Bush. And the last time I checked, George W. Bush drove up the deficit, got us involved in two wars that ended up being either badly explained or just wildly unpopular because they didn't seem like they were helping Americans at home and were not all that successful. And I will say that when he left office, he had-- I believe, the last approval rating he had was about 32 percent.

The Republican Party was decimated between 2005 and 2008. And during those years, there was not a Tea Party. There was no Sarah Palin. This was no issue with the Tea Party influence. It was because we had an abysmally centrist and out of touch George W. Bush in the White House that the Republican Party has still not come to terms with.

### Moderator
Claim: Mickey Edwards.

### Scientific Advocate (SA)
Claim: And I believe he was in many ways the centrist dream that David Brooks loves.

### Moderator
Claim: Mickey Edwards.

### Conspiracy Advocate (CA)
Claim: You know, I feel like I'm watching one of those games where you try to see which shell the pea is under. So, I mean, you guys keep talking about the definitional problem, we're not defining the issue right, and yet you keep redefining conservatism. I mean, Ralph, I appreciate the fact that you pointed out that when I was running for Congress, and when I was there, I routinely carried the African-American vote by good margins. But, you know, a very interesting thing happened.

There was a political scientist who did a study of me. I can't imagine why he would do that, but he looked-- and he compared my voting record with what it would be today. And he said, “Holding things steady”-- when I was in Congress, you're absolutely right. I was one of the most conservative members of Congress. And if I were in Congress today, voting exactly the same way on exactly the same issues, I would be one of the most liberal Republicans in Congress. It's the party that has changed. That's not the party of Reagan. It's not the party of Barry Goldwater. You know, it's-- this is a party that has become something different and unrecognizable, something that is at war with the American people, that's at war with people's rights--

### Scientific Advocate (SA)
Claim: I don't think that's true--

### Conspiracy Advocate (CA)
Claim: --to make their own choices.

### Scientific Advocate (SA)
Claim: If the Republican Party is as out of touch as you claim it to be, how do we have a-- how do we have people like Nikki Haley, Susana Martinez, Ted Cruz?

We have incredible people across this country-- Scott Walker and--

### Conspiracy Advocate (CA)
Claim: Marco Rubio.

### Scientific Advocate (SA)
Claim: --Marco Rubio and all these other people. It's--

### Conspiracy Advocate (CA)
Claim: Where is Marco Rubio---

### Scientific Advocate (SA)
Claim: --the idea that that party--

### Conspiracy Advocate (CA)
Claim: --on immigration? I mean--

### Scientific Advocate (SA)
Claim: What?

### Conspiracy Advocate (CA)
Claim: I agree with you on those points. But those people don't agree with you.

### Scientific Advocate (SA)
Claim: Excuse me.

The party-- what are you talking about?

### Moderator
Claim: Wait a minute.

### Scientific Advocate (SA)
Claim: Mickey, Mickey. No. No.

### Moderator
Claim: Can I-- so--

### Scientific Advocate (SA)
Claim: So, first of all-- I want to know--

### Moderator
Claim: Let Ralph Reed come in. Ralph.

### Scientific Advocate (SA)
Claim: Can I--

### Moderator
Claim: Ralph Reed.

### Scientific Advocate (SA)
Claim: --respond to that?

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: I helped them during their campaigns, Mickey.

### Scientific Advocate (SA)
Claim: As did I.

### Scientific Advocate (SA)
Claim: I assure you, they agree with me. I don't know about this resolution, but let me say this. I think Laura and I-- I'm not sure, but we-- I don't want to get too down the rabbit trail of immigration. But I think that it elucidates the disagreement we're having. They seem to be saying, or at least Mickey is, that it's okay to be a conservative, you just have to be willing to compromise. Well, as I understand it, that's not really the resolution. It goes without saying that in the legislative process, you have give-or-take.

I mean, if you read this comprehensive immigration proposal that was released this morning, it has the toughest enforcement and border security measures in U.S. history. If you entered this country illegally, the soonest you can get a green card is 13 years. The soonest. For many, it'll be 20 years. And nobody-- but nobody under this bill moved ahead of the 4.7 million people who have played by the rules, obeyed the law, and are waiting in line right now. Not one. Now, that is not amnesty. And I-- even if you don't agree with the bill, I defy anybody to say that what Marco Rubio has done is seize the center. What he has done is he has-- as a brilliant legislator and he's very gifted-- and this is not just me talking. The president has said he's been a positive influence. Chuck Schumer called him a “game-changer.” He brought conservative principles to bear, okay?

### Conspiracy Advocate (CA)
Claim: Okay. Ralph, can you move your chair over here? Okay Laura--

### Moderator
Claim: David Brooks.

### Conspiracy Advocate (CA)
Claim: --do you agree with a single word of what Ralph just said-- I think Ralph just joined our side.

### Scientific Advocate (SA)
Claim: No, I didn't--

### Conspiracy Advocate (CA)
Claim: We're on your side.

### Scientific Advocate (SA)
Claim: I will say that that's not actually the proposition either, David. But you're right. I disagree with what Ralph said on a number of issues. But that's not the proposition so, cute little tactic. That might work at the Gray Lady. It doesn't work here.

### Conspiracy Advocate (CA)
Claim: I posit that--

### Scientific Advocate (SA)
Claim: No, no. Let me--

### Conspiracy Advocate (CA)
Claim: I posited that as a--

### Scientific Advocate (SA)
Claim: No, no. Let me--

### Conspiracy Advocate (CA)
Claim: --as a-- as a living example--

### Scientific Advocate (SA)
Claim: Mr. Donvan, let me add something.

### Conspiracy Advocate (CA)
Claim: --of the sort of governance--

### Moderator
Claim: Wait, wait. Laura, let's--

### Conspiracy Advocate (CA)
Claim: --Mickey and I are talking about.

### Moderator
Claim: David, now start speaking. Say it again.

### Scientific Advocate (SA)
Claim: No, he's--

### Moderator
Claim: No, no, whoa. Whoa--

### Scientific Advocate (SA)
Claim: not for-- he's against the resolution.

### Moderator
Claim: I’m thinking in terms of a radio broadcast and the engineer's going to be, “Who's talking?”

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: David, make your point. I'm going to come back to Laura. David.

### Conspiracy Advocate (CA)
Claim: Well, I just-- I'll just say it again. I posited immigration reform, which Marco Rubio-- this gang put together as a perfect model, not some abstraction of George Bush as a centrist, which I do not remember really, but a concrete thing we can argue about as an example of the sort of governance I think Mickey and I agree with. Democrats, Republicans getting together, a substantive bill that helps the country, that Mickey, me, and Ralph all support.

### Moderator
Claim: Laura Ingraham. Laura, do you want to-- no.

### Scientific Advocate (SA)
Claim: Now, Marco-- first of all, Marco Rubio was the upstart candidate against the establishment, moderate, centrist Charlie Crist. Do not interrupt me, please. Charlie Crist, who is now a Democrat. Charlie Crist's positions in Florida were widely hailed by liberal Republicans and liberals, period. He also happened to be unseated by the Tea Party. I had Marco Rubio on my radio show in February of 2009. He was 23 points behind. I saw in Marco Rubio someone different from the Republican dinosaur establishment, the same people who had driven the party, from Bush on down, into almost oblivion. All the gains we won during Gingrich were lost almost under George W. Bush. Marco Rubio is a different type of legislator. It doesn't mean I'm going to agree with him on everything.

### Moderator
Claim: Wait, but--

### Scientific Advocate (SA)
Claim: But I like what he’s trying to do with the national conversation.

### Moderator
Claim: Does he represent the conservative wing that is not moving to the center?

### Scientific Advocate (SA)
Claim: I think Marco Rubio is a doer and I think he's a conservative. It doesn't mean on every issue you agree with him, but that's not the proposition. The proposition is you either move to the center or die. Marco Rubio was campaigned against by establishment Republicans--

### Moderator
Claim: But has he moved to the center and not died?

### Scientific Advocate (SA)
Claim: I don't think he's-- I think he's-- he had the idea of immigration reform seven years ago.

### Scientific Advocate (SA)
Claim: Not by any-- no.

### Scientific Advocate (SA)
Claim: Seven years ago.

### Scientific Advocate (SA)
Claim: You cannot say that Marco Rubio is a moderate by any intellectually defensible analysis - -

### Scientific Advocate (SA)
Claim: Pro-life, pro-traditional marriage, against

### Scientific Advocate (SA)
Claim: --of America's political--

### Moderator
Claim: I just need one person speaking at a time, and right now it's Ralph Reed.

### Scientific Advocate (SA)
Claim: Well, and I would go further and say that, you know-- again, to point out what Laura was saying, if you think Marco Rubio's a moderate, I urge you to go home after tonight's session and read his speech to CPAC a couple of weeks ago, where he began his speech by defending the definition of traditional marriage, where he began by defending the sanctity of innocent human life.

And, by the way, we have a new NBC News Wall Street Journal pullout I think within the last few days--

### Scientific Advocate (SA)
Claim: Last few days.

### Scientific Advocate (SA)
Claim: --that shows that 53 percent of the American people favor restrictions on abortion or having it banned entirely. The CNN poll within the last two weeks shows it at 52 percent, the Gallup Poll shows it at 51 percent. My point is if we had had this debate at an earlier time, they would've been saying, "You need to moderate your stance on that issue." We didn’t. We've done fine without moderating it. People are hungering for candidates who are authentic, who have core convictions, who have moral clarity, but, yes, are willing to work across party lines.

### Moderator
Claim: All right. Mickey, you haven't had a word in a bit. Do you want to come in or do you want to cede to David?

### Conspiracy Advocate (CA)
Claim: Well, I would love to cede to David, but let me just make this one point. I mean, this is-- it's not about Marco Rubio. What happened with Marco Rubio was he got elected, and he became a member of the United States Senate, and he said, "I've taken an oath of office for the Constitution, and my job is to help govern America." It's-- you know, it can't be that everything is a matter of principle. It--

### Scientific Advocate (SA)
Claim: He voted against the gun bill today. Is that centrist?

### Conspiracy Advocate (CA)
Claim: --cannot be that you never compromise on anything, you know? And that's the reputation the Republican Party is getting, the party of "No." You don't say, "No," to America. You say, "I've taken an oath of office. I'm a member of government. I have to try to make something happen." And that's what Marco Rubio has done.

### Conspiracy Advocate (CA)
Claim: I really think-- I--

### Moderator
Claim: David Brooks. David Brooks. I-- let me come back to you guys after this.

### Conspiracy Advocate (CA)
Claim: I mean, I just think you guys aren't listening to us. When we are talking about--

### Scientific Advocate (SA)
Claim: Where's Dr. Phil?

### Conspiracy Advocate (CA)
Claim: --in moderation-- we're not talking about being--

### Moderator
Claim: They're so right you just don't know it.

### Scientific Advocate (SA)
Claim: We need Dr. Phil here.

### Conspiracy Advocate (CA)
Claim: Hear me.

### Moderator
Claim: David Brooks.

### Conspiracy Advocate (CA)
Claim: So-- Mickey and I have consistently-- when we talked about moderation, we have not said, "You have to be without principles." We have not said, "You have to be some invisible squish." We say, "You start with your principles. First, you address your real principles to real problems like the economy and immigration. And then you try to work with the people on the other side who contain some piece of the truth." Now, what's happened to the Republican Party is that it shifted, and people who used to be thought of as "conservatives" are now thought of as "moderates." First there was Mickey. Now there's Ralph. You’ve turned Ralph-- you, with your immigration position, you've turned Ralph into a squish.

### Scientific Advocate (SA)
Claim: David, David, nice try. I don't think anybody's buying that I'm a moderate.

### Scientific Advocate (SA)
Claim: John, John--

### Moderator
Claim: I want to move on to-- I want to move on to--

### Scientific Advocate (SA)
Claim: Can I just say this--

### Moderator
Claim: All right, but very quickly.

### Scientific Advocate (SA)
Claim: I think this is a part of the false premise of the other side. We have never taken the position nor does the resolution require us to take the position that in the give and take of a legislative process or a negotiation between a governor and legislature that you compromise.

You don't get off that easy. That's not what this resolution says. What this resolution says is that the Republican Party should cease to be the party of unalloyed, authentic, unapologetic conservatism and should instead try to split the difference between where it is and where the Democrats are. Let me just let you in on a little secret, A, that won't work politically; and, B, it ain't happening.

### Moderator
Claim: Ralph, we--

### Scientific Advocate (SA)
Claim: It's not going to happen.

### Moderator
Claim: Ralph--

### Scientific Advocate (SA)
Claim: The Democrats are on the left. The Republicans are on the right. And there are lots of reasons for that that we could get into.

### Moderator
Claim: Ralph, I feel we now need from you, if you can do it in 18 seconds, talking about defining your terms, defining "conservatism." What are the tenets? What are the pieces of it? Because I think that's where a lot of this disagreement is coming.

### Scientific Advocate (SA)
Claim: Well, I think conservatism in a nutshell is a philosophy that argues that as government gets bigger, that freedom necessarily constricts. And we believe people are best able to rise as high and as far as their God-given talents, abilities, ambitions, and desires will carry them when government gets out of the way and allows free men and women to do those things that are best left to them. Government should be small. It should be limited, and it should be confined to specific enumerated purposes.

### Moderator
Claim: Where do the social issues fit in?

### Scientific Advocate (SA)
Claim: Well, I'm happy--

### Moderator
Claim: Wait a minute. I am not trying to zing at all.

### Scientific Advocate (SA)
Claim: Media-- well, I'll chime in here.

### Moderator
Claim: Laura Ingraham.

### Scientific Advocate (SA)
Claim: It's the idea of ordered liberty. Jefferson wrote about it. Madison, Mickey's favorite framer, wrote about it, that liberty without virtue is really meaningless because my idea of liberty could conflict with your personal space or everyone does what everyone wants to do in his or her own time, and obviously you'll have natural conflicts.

So ordered liberty is obviously the best. And a moral core, encouraging moral behavior, society changes, maybe society will change what the meaning of the world "moral" is, and I understand that. But the morality has a place. We see it playing out today with the reaction to what happened in the horrible attack in Boston. Morality is around us. We can try to ignore it, we can try to say that--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --government has no role in it. But reality actually matters.

### Scientific Advocate (SA)
Claim: By the way, it fits in in the same place that the Civil Rights Act of 1964 fits in, okay? I'm not allowed to deny you the right to sit at a lunch counter simply because of the color of your skin. And we believe that if you take, for example, the issue of abortion, that an unborn child is a person for purposes of the 14th amendment of the Constitution; therefore, to take their life without due process, as we're seeing unfold in this gruesome trial in Pennsylvania, with this doctor who systemically executed children who could perform outside the womb, violated their God-given right, and by the way, their Constitutional right to life and liberty and the pursuit of happiness.

### Moderator
Claim: All right. Let me bring it back to the other side. Mickey Edwards, you want to respond to the-- as we move into the part of conservatism being involved with socialism.

### Conspiracy Advocate (CA)
Claim: Yeah, I have some thoughts here, but I kind of got stunned here by this definition of liberty. So in the case of the civil rights and you cannot deny African-Americans, obviously you shouldn't, these rights, you know, that's a good thing. But denying gays rights, that's different, right? So, I mean, there’s a point where you're not being consistent, are you for liberty, or are you for restrictions on liberty? Are you for a workable government, or are you against it?

Are you for limited government or not? I mean, you're on every side of everything. That doesn't work.

### Scientific Advocate (SA)
Claim: Can I respond to that?

### Moderator
Claim: I'd like to go-- I'm going to give one note to the audience, then you can respond. I want to now go to, for questions after Ralph responds to that. And how it works is if you raise your hand, a mic will be brought to you down the aisle. Just please wait till the mic reaches you. If I call on you, please stand up so that we can see you with the camera. Tell us your name, and pop out a question, you know, a really focused question that's on this-- on this topic. We're-- we know that a lot of people have passions on this on one side or the other. We don't really-- really not really looking for you to tell us how you feel about one side or the other. We believe you do. We really want you to throw something into the mix that gets these guys talking to each other. And I will pass on questions, respectfully, that don't meet that standard. Ralph, go ahead.

### Scientific Advocate (SA)
Claim: Well, I would say, first of all, gays and lesbians have not experienced the same level of Jim Crow-like invidious historic discrimination that African-Americans did.

They've not-- wait a minute. They've not been denied the right to vote. They've not been prevented to run for political office. If you believe that gays and lesbians were subjected to slavery and segregation and denied the right to vote for over 100 years after the 13th amendment granted them the right to vote, that has never happened in American history. So they are free in a free society to make moral choices with which I may disagree. Just by the way straights are. There are straight men and women who live together outside of wedlock, do so every day, and they're free to do so in a free society. I'm not going in there to try to interfere with their personal decision. The issue before the country is whether or not that relationship should be defined as the institution of marriage.

### Moderator
Claim: Let's go to some questions. Right down in the front.

And I want you to wait for the microphone. It's coming from your right-hand side, just being passed down. If you could stand up and tell us your name. And also, you need to hold the microphone about a fist's distance from your mouth for the radio broadcast. That's all you have to remember.

### Moderator
Claim: Bella Cohen. My question is really for Mrs. Ingraham.

### Scientific Advocate (SA)
Claim: I'm not married, but I'm glad-- is there a husband out there-- oh, great.

### Moderator
Claim: Sorry.

### Scientific Advocate (SA)
Claim: "Ms." is fine. I'm bought into that now.

### Moderator
Claim: Oh, so--

### Scientific Advocate (SA)
Claim: Yeah, I've evolved.

### Moderator
Claim: Things have changed.

### Scientific Advocate (SA)
Claim: I'm centrist, David.

### Conspiracy Advocate (CA)
Claim: Centrist, yeah, like Bush.

### Scientific Advocate (SA)
Claim: What can I say?

### Scientific Advocate (SA)
Claim: So now it's all four on one side.

### Moderator
Claim: And you didn't die.

### Scientific Advocate (SA)
Claim: I'm a little too old for the "miss" at this point, so go ahead.

### Moderator
Claim: My question is, why has the Republican Party failed-- what do you see as the failure-- because you have to admit there have been many, many failures in the last… So how do you define what the failures-- I was--

### Moderator
Claim: By the way, that was a really great model for a question. Do that, and it's going to work. Well, done. Thank you.

### Scientific Advocate (SA)
Claim: I was a-- very briefly, I was a kid growing up in Connecticut. My mom was a waitress. I had a middle class lifestyle. I kind of gravitated toward Reagan. I didn't really have any reason to be political. But this guy was kind of an older guy, but he seemed to love America, and he thought government was kind of out of control. I saw my parents in these gas lines, and interest rates are really high. Parents couldn't make much more money. Listened to him and thought that message made sense. The Reagan experience was not without its pitfalls. Reagan did compromise on some issues. But that vision of conservatism, which was a happy warrior conservatism, which was unyielding in the face of the Soviet threat, which understood that the power of the individual, individual prosperity, was best achieved with a government that didn't get in the way. Those messages were clearly stated, mostly optimistically stated. But he could throw the punches when necessary.

Reagan was a great example for me as a young person. I think as time went on, they had some successes obviously in the '90s. Republicans took the House of Representatives for the first time in 50 years in 1994. Seemed like we were back on track. And George Bush-- I mean, I sound like I'm beating up on George Bush, but George Bush comes along, I like him very much. We had an idea that Republicanism--

### Moderator
Claim: Laura, I--

### Scientific Advocate (SA)
Claim: --needed to expanded.

### Moderator
Claim: Laura, just in terms of--

### Scientific Advocate (SA)
Claim: The Republican Party turned its back on core conservative principles. Conservatism was never about remaking the world in its image. Conservatism was not about starting wars that we didn't have clear exit paths with. And it wasn't about running up big deficits. Conservatism became that sadly during the Bush years. And it nearly destroyed the Republican Party. It wasn't the Tea Party in 2010. It was Bush from 2004 to 2008.

### Moderator
Claim: Does the other side want to respond to that? David Brooks.

### Conspiracy Advocate (CA)
Claim: I just want to respond to the Reagan revisionism which I knew would come up. It took a lot longer than I thought. So Reagan raised taxes 14 times. He included the biggest tax hike in American history to that point.

Reagan signed the Therapeutic Abortion Act, which was one of the bigger liberalizations of abortion laws. That didn't make him a moderate. It made him someone who was practical politician. And he fought for what he could and tried to get things done, but he was willing to address real problems and not govern on the basis of a prefab ideology.

### Scientific Advocate (SA)
Claim: Was he a centrist?

### Conspiracy Advocate (CA)
Claim: No. But he was someone who was willing to govern.

### Scientific Advocate (SA)
Claim: He took on the Republican orthodoxy which was made up of centrists. From 1976 onward and years before that, he debated everybody from RFK to Republican-- Rockefeller Republicans, many of whom would probably agree with a lot of the points you're making and you're making well.

### Moderator
Claim: It sounds like where you're disagreeing on Reagan is a question of substance and style.

### Conspiracy Advocate (CA)
Claim: Right. So, well, maybe two ways. Ronald Reagan adjusted to the problems of his day. In the late 1970s, there was a stagflation. There was a global shift of overregulation. There was a global shift of government which really did stagnate the country.

And Ronald Reagan, I think, responded very intelligently, along with Margaret Thatcher, to the problems of those days. The problem is the problem of 2013, it's not 1980, and the problems are different. And if you stay with some mythical, pure Reaganism, which includes no tax increases ever, small government all the way, which is mythical, then you are not responding to the problems of today.

### Scientific Advocate (SA)
Claim: Where are the centrists winning, and where are there centrists making a difference in government today? What centrist Republican has won and changed the face of the Republican Party? Where? Where is it happening? It didn't happen in California.

### Moderator
Claim: Okay. I want him to answer the question because, I mean, that's a great question.

### Conspiracy Advocate (CA)
Claim: Okay. Well, we're sitting in New York City.

### Scientific Advocate (SA)
Claim: At the Bloomberg?

### Conspiracy Advocate (CA)
Claim: We just had a couple of mayors of New York City who were, I would say, moderate Republicans, probably pretty good for New York. I'd say Governor Chris Christie would be good for New Jersey.

### Scientific Advocate (SA)
Claim: He won with the Tea Party, David.

### Conspiracy Advocate (CA)
Claim: I would say outside the Washington, D.C. and some of the red states, it's impossible to become a centrist because--

### Moderator
Claim: Let me go to another question.

### Scientific Advocate (SA)
Claim: They're not winning. That's the whole point.

### Moderator
Claim: Let me go to another question.

### Scientific Advocate (SA)
Claim: Can I-- can I quickly--

### Moderator
Claim: There down in the front.

### Scientific Advocate (SA)
Claim: --respond to what Dave said before we go to the question?

### Moderator
Claim: I want to move on if you don't mind.

### Scientific Advocate (SA)
Claim: Okay. All right.

### Moderator
Claim: And you can save a little bit for your--

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: --closing remarks. So-- can you tell us your name, please? Thanks.

### Moderator
Claim: Jamal Thomas. I thought David started out everything excellent when he talked about the little girl. And I haven't heard a lot from the other side. And I think the center would love to hear-- when there's a parent who is on drugs and various different things of that effect that can't take care of the child, who's responsible for that? And again, I think the--

### Moderator
Claim: Wait, can you frame your question more towards-- to something that feeds into our motion? Rather than saying, who's responsible for the vulnerable?

### Moderator
Claim: Well--

### Moderator
Claim: In terms of what are you saying that's-- what is-- how does that question relate to the Republican Party that you see today?

### Moderator
Claim: Well, I mean, I'm somebody who would consider myself a moderate. I look at the right, I look at the left, but I can't completely move in that right direction because I don't feel the level of compassion for that little girl that David spoke to. And I--

### Moderator
Claim: All right. Can I--

### Moderator
Claim: --I didn't hear the other side--

### Moderator
Claim: --rephrase your question to--

### Moderator
Claim: Of course.

### Moderator
Claim: --and I think-- it seems to me as to this side-- and I may be wrong-- can I rephrase your question to ask this side, is does the party have a reputation for not connecting to the-- to the problems of--

### Scientific Advocate (SA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: --ordinary people?

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: Yeah. Can I just-- I want to make sure that I'm clear about it. It-- when their parents cannot take care of them, who is, then, responsible?

### Moderator
Claim: Well, that's a different question from our debate.

### Scientific Advocate (SA)
Claim: If I can respond-- the Party does have that reputation. It is an undeserved reputation, but it nonetheless is the case. But the fact of the matter is that what the Republican Party stands for, what it fights for and what it seeks to advance, is policies that will strengthen marriage, family, childbearing and rearing, so that young people are not left behind in circumstances where this young girl could end up finding herself. We seek policies that strengthen the family, because we know that if somebody gets married and stays married, bears children within the institution of marriage, and gets a job, any job, and graduates from high school-- that person that I just described, in the United States of America, you know what that-- what chance that person has of living in poverty?

Two percent. You do the opposite of those four behaviors, you don't graduate from high school, you don't get your first job, you bear children outside the institution of marriage, you have an 85 percent chance of living in poverty. And I read “Losing Ground.” And Charles Murray's exactly right. But the sociology and pathology of poverty in America today is largely as a result of government policies that don't strengthen those institutions.

### Conspiracy Advocate (CA)
Claim: Can I just ask for detail? You mentioned you support--

### Moderator
Claim: David Brooks.

### Conspiracy Advocate (CA)
Claim: --policies that support child-rearing. What exactly are those policies?

### Scientific Advocate (SA)
Claim: Well, I can give you a number of examples. Number one, school choice, which we know dramatically increases parental involvement in a child's education, David.

All the social science shows that if a parent can choose the school, that they're going to be more involved in that child's education. Secondly, we supported the $500 per child tax credit, which became $1,000 per child tax credit, which we made fully refundable. David, that is the most successful anti-poverty program in the last 30 years. It lifted 9 million people out of poverty last year. That was in the Contract With America.

### Moderator
Claim: Ralph--

### Scientific Advocate (SA)
Claim: So, the idea--

### Moderator
Claim: Ralph, can I just ask you-- Ralph--

### Scientific Advocate (SA)
Claim: --can I-- let me give you one more. let me give you one more--

### Moderator
Claim: --are those policies-- let me-- with respect to this debate. Are those policies non- centrist?

### Scientific Advocate (SA)
Claim: I've been trying to give an example--

### Moderator
Claim: Are those policies that you just listed non-centrist?

### Scientific Advocate (SA)
Claim: What?

### Moderator
Claim: Do those policies belong to the conservative party or--

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: They're non-- no, they're non-centrist?

### Moderator
Claim: I agree with him.

### Scientific Advocate (SA)
Claim: If you think that-- I will tell you this. I mean, Bill Clinton vetoed our budget with the child tax credit in it two times. Do you think welfare reform was a moderate idea?

We helped move 2 million people from welfare to work in the 1990s. And people said they would end up homeless. These are conservative ideas--

### Scientific Advocate (SA)
Claim: It's not-- the--

### Scientific Advocate (SA)
Claim: --that lift people out of poverty--

### Scientific Advocate (SA)
Claim: And Washington--

### Scientific Advocate (SA)
Claim: --and give them hope. And instead of their hope being in government dependency, it allows them to move to dignity and self-reliance, work, stronger marriages, and families. And that's what's going to lift people out of party, not government programs out of Washington, D.C.

### Moderator
Claim: All right. Let me go to another question. Sir, right in the middle. Yeah. Yeah. And if you can stand and tell us your name when the mic reaches you? I need the mic to reach you. It's coming on your right-hand side. Thanks.

### Moderator
Claim: The question, for those are in favor of this proposal, is if immigration, in the future, for whatever reason, wasn't an issue, could these conservative values that are quite far right capture the Hispanic vote, which is very religious and which might be more prone to support this position?

So I agree it's--

### Moderator
Claim: All right, great question. Let's put that to Mickey Edwards.

### Conspiracy Advocate (CA)
Claim: You know, I-- first of all, yes, but here's-- I mean, I agree with a lot of what Ralph said about the positions that he was advocating. You know, those are conservative. But I-- we used to call-- people used to call the Republican Party the "dumb party," and I tried to think, "Why is that? Why is it the dumb party?" So what happens when you have good ideas like the ones you just talked about, and you have the president of the other party and the Senate of the other party, and you want to advance toward what you say, but if they say, "Okay, let's find a compromise," you say, "No," and, therefore, you get nothing, instead of moving in the direction you're advocating, you get nothing. That's dumb. That's really dumb, and that's the reputation the Republican Party is getting.

### Moderator
Claim: Laura Ingraham.

### Scientific Advocate (SA)
Claim: Well, on the issue of compromise, Barack Obama brooks no compromise on certain issues. Number one, on D.C. Opportunity Scholarships, I don't know if you guys know what that is, but that was a school choice initiative, wildly popular in my hometown of the District of Columbia. African-Americans, Latinos line up around blocks to get their kids enrolled in the D.C. Opportunity Scholarship. The centrist, Barack Obama, zeroed out-- approved the zeroing out of the money, pittance, I think it was $13 million, a drop in the bucket in our budget, for those families. Okay, so the idea that somehow that's compromise or that's-- there's all sorts of compromise going on, on the other side, not when it brooks the teacher's union, not when they're up against their people, so Republicans need to compromise and move to the center, but Democrats on issues like the unions and opportunity scholarships, there's no way they're going to do that. And on the point about the-- about the African-American point, I think it's an important one, I'd just like to say one brief thing, you're absolutely right.

Republicans have been abysmal, from Romney, to McCain, and to pretty much everybody in between, about talking to people as people. They have different views. They have different values. That's okay. Rand Paul, Tea Party, not centrist Republican, is the first Republican to actually really go speak to African-Americans in a meaningful way. He did that last week at Howard University. He was booed for having done so, but I give him great credit for doing that. He began the conversation. I hope it continues, but you're making an absolutely important and valid point, and we have been terrible at that.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. Debate, and I'm John Donvan, your moderator. We have four debaters, two against two, debating this motion, "The GOP must seize the center or die." Sir, you're waving so vigorously, it makes me nervous. for the microphone to come on up and please don't make me regret this.

### Moderator
Claim: My name is Robert Rosenthal. The low point of the campaign last year for presidency was during the Republican primaries when the candidates were asked if they would lower the deficit by 10-part spending cuts to one-part tax raising, and everyone said they wouldn't do that. My question to this side is do you see that as an admirable stand for their principles or as an indication that they just can't govern the country?

### Moderator
Claim: I owe you an apology. That's a pretty darn well-worded question.

### Scientific Advocate (SA)
Claim: Well, the--

### Moderator
Claim: Ralph Reed.

### Scientific Advocate (SA)
Claim: --the short answer is, "neither," because there're two rules in American politics. The first is you can be asked any question that the questioner wants to ask you. The second is you can answer it any way you want.

And our candidates just didn’t seem to fully grasp that second rule. They were given a choice of raise your hand. What they should have said was-- and I can't remember who the moderator was, you know, doesn't matter-- but you should say, "That offer will never come. There has never been a time in modern American political history where a Republican president has been offered a deal of a dollar in tax revenue-- new tax revenue for $10 in spending cuts, and it never will happen.” And, by the way, you know, David was talking about the tax increase that Reagan signed in 1982, which was then the largest tax increase in American history. I was there. I was working in the U.S. Senate at the time. It was supposed to be $3 in spending cuts for every dollar in tax increases. Reagan signed it. All the taxes went up. The spending never got cut.

He never got the spending. He went on to say it was one of the biggest mistakes he made as president. And that's why. If you look at what Obama's proposed, it's basically dollar for dollar. Now at a time when we're spending a trillion dollars a year that we don't have, Republicans are not going to agree to that kind of ratio.

### Moderator
Claim: Well, Mickey had asked for permission to speak next. And I'll come to you, David, and I'll leave you guys--

### Conspiracy Advocate (CA)
Claim: I just wanted to respond to the point in the gentleman's question. What shows you where the Republican Party is, it is-- you mentioned the primaries. It's the primary system where the Republican activist, the true believers, people like you show up. And what happens is you end up with nominees like Christine O'Donnell and Sharon Engel and Richard Murdoch and Denny Rehberg. That's what has to come out of a Republican primary, and that's what's killing the party. It's not some magical moderate or not moderate.

It's that the Republican Party continues to put, on the ballot as its champions saying, “This is what we believe,” people who are so far out of the acceptable mainstream that people just can't accept it.

### Moderator
Claim: And your partner David Brooks wants to add something.

### Conspiracy Advocate (CA)
Claim: You know, Ralph's a good consultant. If he had consulted-- if they had asked him before they raised the hand question, he would have given that good advice of how to dodge it. But they didn't just dodge that. They didn't just answer that question. They raised their hand, and then they defended it for the rest of the campaign. They defended the position that $10 in spending was not worth $1 in tax increases. They support that. They believe in that, they talked about it. It was a perfect example of the sort of absolutist position; a position of preference that a lot of us have that taxes shouldn't go up turned into an absolute fetish. And as a result, this party is incapable of reaching a budget deal. Now, I don't support all the budget deals that were out there, but a couple years ago, they were given a budget deal of $3 to one, $3 of spending cuts to $1 of tax increase.

That, to me, was the no-brainer of the century. Take that deal. They didn't take the deal. They lost the election. Now we're down to maybe one to one. This is a party that's incapable of getting to yes.

### Scientific Advocate (SA)
Claim: The centrist president--

### Moderator
Claim: Laura Ingraham.

### Scientific Advocate (SA)
Claim: --Barack Obama has produced two budgets, I guess, right? Is that right, two budgets in five years. The last one late. I think it's the first time a president delivered a budget that late in modern history, or maybe ever. And the president's first budget got a total of zero votes for his budget, which apparently would be filled with compromise and moving to the middle and understanding governance and all of that. Got no support. And it doesn't look like his current budget is getting any support either. So the idea that the Republicans are sitting there as this-- as this buoy in the water, and it will not tact to one direction or the other. It's ridiculous.

The Republicans have tons of problems, believe me. But the idea that if they-- again, the proposition on the table, they have to move to the center or die. They are alive and well in blue state Wisconsin. They are alive and well in blue state New Mexico where representative Steve Pierce, Republican, anti-immigration reform, just won 41 percent of the Hispanic vote in southern New Mexico by actually, as our--

### Moderator
Claim: Mickey Edwards.

### Scientific Advocate (SA)
Claim: --questioner said, talking to the people there, including Latino voters.

### Moderator
Claim: Let me ring in Mickey Edwards.

### Conspiracy Advocate (CA)
Claim: I wasn't going to make a point. I was going to ask a question of Laura, whether or not the centrist Obama you referred to was the same one you referred to in your opening states as the most liberal president ever.

### Scientific Advocate (SA)
Claim: No. A centrist, according to your-- no, no, centrist according to your definition, because he is moving with the times.

### Moderator
Claim: You were saying, "centrist," in quotation marks.

### Scientific Advocate (SA)
Claim: I don't think he's centrist at all, my gosh. I mean--

### Moderator
Claim: Okay. Let's go to another question.

### Scientific Advocate (SA)
Claim: He's left the stage he's so left. I mean, come on.

### Moderator
Claim: I'm sorry, folks, upstairs, if you're raising your hands, I can't see you, and we don't have mics up there, and that's why I'm only calling downstairs. Ma'am, over on the far side.

You've now seen some very good questions, so let's keep that going. No pressure.

### Moderator
Claim: My name is Alison Proleski I wanted to ask-- nobody has really brought up the issue of the GOP's position on climate change. And I wanted to see both sides address where maybe that might play a role in the debate.

### Moderator
Claim: All right. Let me just start with Mickey Edwards first on that.

### Conspiracy Advocate (CA)
Claim: I don't know what you mean.

### Moderator
Claim: Climate change.

### Conspiracy Advocate (CA)
Claim: Oh, climate change. I couldn't hear what you said. Climate change?

### Moderator
Claim: She wants to know the party's position on climate change and where that fits into your argument about the party--

### Conspiracy Advocate (CA)
Claim: One of the things that was always very interesting was that during the Bush and Cheney years, when you were talking about the chance that a terrorist threat might be 1 percent real, that you had to take an action because you couldn't afford the chance it was real.

Believe me, the environmental threat today is more than 1 percent possible. And I think it's an obligation of the Republican Party, of conservatives, to recognize that if you're going to fight against things that might do harm, might do danger, you know, that one of the things you have to look at is what's happening in the environment and what you need to do to secure our safety in that regard, too.

### Moderator
Claim: And where do you think the party stands on-- its record is on that?

### Conspiracy Advocate (CA)
Claim: Well, I don't-- I mean, should I quote Senator Inhofe that-- I don't want to say deniers, but they're deniers.

### Moderator
Claim: All right. Let me take it to the other side. Do you want to tangle on the issue of climate change? Ralph Reed.

### Scientific Advocate (SA)
Claim: Look, the Republican Party takes the position that the science on climate change is not sufficiently settled. Let me-- let me--

### Scientific Advocate (SA)
Claim: That's an easy way to get a "boo" in this audience, Ralph.

### Scientific Advocate (SA)
Claim: Let me finish the sentence.

### Scientific Advocate (SA)
Claim: I'm dissociating myself--

### Scientific Advocate (SA)
Claim: It’s not sufficiently--

### Scientific Advocate (SA)
Claim: I'm very hot.

### Scientific Advocate (SA)
Claim: --settled to justify a federally run cap in tax, cap and trade system which has been an unmitigated disaster in the Eurozone.

You should know that the Eurozone has adopted what this administration has proposed; a cap and trade system where you have permits that trade carbon emissions back and forth across industries and factories and even across country lines. What are their CO2, emissions up roughly over the last two years? 4 percent. We don't have a cap and trade system. Our carbon emissions have fallen by about 1 percent per year without it. You know why? Because we've incentivized corporations to adopt cleaner technology without going to that system. So we clearly oppose a cap in tax system which one study would show, through higher utility bills, higher gasoline, and higher built-in energy prices for everything from keeping your home warm to running a factory or a manufacturing establishment, will be a $1,800 tax on every family of four in America.

### Moderator
Claim: I want to go--

### Scientific Advocate (SA)
Claim: We're not for that.

### Moderator
Claim: I want to go to one more question here.

### Scientific Advocate (SA)
Claim: And by the way, neither are a lot of Democrats.

### Moderator
Claim: Here is my rule on the next question. You need to be able to state it in ten seconds, and we're up against the time limit here. I'm going to give each side 30 seconds to respond to it.

### Scientific Advocate (SA)
Claim: Uh-oh.

### Moderator
Claim: I'm going to stop them at 30 seconds. Does anybody have a 10 second, "I can just pop it out" question. Right in front.

### Moderator
Claim: The other side, David and Mickey's side--

### Moderator
Claim: Can you tell us your name, sir?

### Moderator
Claim: Peter Bass. The other side typically cites the changing demographics of the country as a reason why the Republicans can't succeed as a national party. I wonder if you could drill into that issue a bit more specifically on the demographics.

### Scientific Advocate (SA)
Claim: Yeah, I-- look.

### Moderator
Claim: And 30 seconds for Ralph. Go ahead.

### Scientific Advocate (SA)
Claim: Well, let me put it to you this way: If Ronald Reagan got the same share of vote among every voter group that he got in '80s, in the 2012 electorate, he would have lost. The electorate in '80 was 88 percent white. Today it's 73 percent white. I think we've already stipulated that we need to do better among minority voters, younger voters, single voters. We can do that with conservative policies. That's the disagreement. We all agree we need to do better among minority voters. You can do it by talking about conservative policies.

### Moderator
Claim: Okay. That was discipline. Who would like to respond on this side on the demographic issue? David Brooks.

### Conspiracy Advocate (CA)
Claim: I'll go. Ralph-- I think Ralph or Laura, I can't remember which, mentioned how the Republican party has collapsed in California. And apparently it was because of the mushy moderate policies of Pete Wilson and others. What I don't remember is Pete Wilson proposing a restrictionist immigration reform and destroying the Republican Party’s chances among Latino voters in California. And that's what destroyed the Republican Party in California. I sit here this week, and I watch the Republican Party learning from the lesson of California and trying to do the same thing nationally. And I think that's about to happen to--

### Scientific Advocate (SA)
Claim: We're going back to Pete Wilson.

## Round 3

### Moderator
Claim: All right. Ladies and gentlemen, that concludes Round 2 of this Intelligence Squared U.S. debate where our motion is "the GOP must seize the center or die." And remember, we had you vote just before, and we're going to have you vote again right after closing statements which we're going to move to immediately. Onto Round 3, closing statements by each debater in turn. Those statements are two minutes each. Our motion is "the GOP must seize the center or die." And here to summarize his position against this motion, Ralph Reed, the founder and chairman of the Faith and Freedom Coalition.

### Scientific Advocate (SA)
Claim: Well, I want you to remember when you vote tonight, that we're not voting on whether or not Republicans ought to compromise more, whether or not they ought to work with members of the other party to find common sense solutions. That's not what we're debating. We're debating whether or not the Republican Party philosophically should move from where it is to a point equidistant the two parties. And if it does not do so, it will die. Now, we have lots of data to demonstrate that that's not true. I've mentioned some of it tonight. Look at the exit polls in 2012. People asked whether or not they thought government was too big and was doing too much or whether or not they thought was government was too small and was doing too little. And a majority of Americans said government was too big and was doing too much. 41 percent of the electorate was conservative, only 23 percent liberal. I mentioned earlier that a plurality of Hispanics are conservatives. Only 23 percent of Hispanics are self-identified liberals. Now, the Republican Party may need to talk about these issues more effectively. You know, I think about what Oscar Wilde said. You know, sometimes you can tell somebody they're going to hell in such a way that they want to get there as rapidly as possible. sometimes the Republicans have done that. But we're not talking here tonight about better candidates, better candidate performance. The gentleman who asked the question about engaging and connecting with minority communities, you can do all those things and remain an authentic, genuine, Reagan-style conservative. And if the Republican Party doesn't do that, if it moves to the mushy middle, if it tries to trim its ideological sails and tries to be simply a Democrat-lite, then the tens of millions of people who lick the envelopes, and knock on the doors, and make the phone calls, the volunteers who turn out on the-- on these primaries-- they will walk away from this party because it walked away from them.

### Moderator
Claim: Thanks, Ralph.

### Scientific Advocate (SA)
Claim: Vote against this resolution.

### Moderator
Claim: Thank you.

Thank you, Ralph Reed. And our motion is the GOP must seize the center or die.

And here to summarize his position supporting this motion, David Brooks. He's an op-ed columnist for The New York Times.

### Conspiracy Advocate (CA)
Claim: We've had a lot of politics and some references to the dictionary tonight. Ralph has his Laura has her animus to George Bush. I want to go back to the little girl I mentioned. I want to go back to the high-tech entrepreneurs looking for a worker. I want to go back to the young person saddled with debt, the gay or lesbian person in a relationship who wants to solidify that relationship within the covenant of marriage. The party that doesn't serve the people is going to die. The party that doesn't serve the contemporary problems of the age is going to die. Those are some of the people who have to be served by a party in order for it to survive. I'm a conservative. I have some doubts. I have a lot of skepticism about government. But you have to use government in limited and energetic ways to serve those people that I've mentioned. You have to be willing to compromise to get a budget deal so the young person is not saddled with millions of dollars of debt.

You have to be able to work for a comprehensive immigration reform so that the high- tech worker can get a job, so the young people living in the shadows have some chance of dignity in their lives. You have to be willing to use government in limited but energetic ways to re-weave the social fabric so the young girl living a few miles from here can grow up in a neighborhood that's orderly, so that people can have jobs with earnable wages, so that people have an incentive to marry, some of them men who are now drifting through society. And that takes more government than I would have thought 10 years ago. But that is the problem that's out there. And that's the problem we have to deal with. So, I may have moved more toward the center since I worked at the Wall Street Journal editorial page or the National Review. But I think I've done it because the problems have changed. And some of those problems demand a little more government action. And if you're stuck, unwilling to use government in any of those problems, then your party will die.

### Moderator
Claim: Thank you, David Brooks. Our motion is the GOP must seize the center or die. And here to summarize her position against this motion Laura Ingraham, host of “The Laura Ingraham Show” and a Fox News contributor.

### Scientific Advocate (SA)
Claim: This proposition I hope you will reject, because I'm going to buy you all after margaritas afterward if you vote with me. And it's the top shelf stuff, not the stuff they were-- I want to start by saying-- you're not going to believe I'm saying this. But I'm going to say you should reject this proposition that the Republican Party should seize the center or die because I have a lot of faith and respect in the decision-making that Barack Obama made when he could have gone that way. He could have, himself, seized the center. He could have seized it in 1985 when it looked like liberalism was on the run. He could have seized in 1994, when this Newt Gingrich guy just took the country by storm, love him or hate him, but changed the face of politics. He could have given up hope in 2001 and 2002 when the whole country was rallying toward this war in Iraq, and he decided, "You know something? It's-- in my view, it's the wrong thing to do. Because the establishment and everyone around him was probably telling him, "The center has moved. You've got to go that way."He didn't go that way. He had a certain set of principles. I disagree with him deeply, but he had a certain sense of himself and sense of principles that he decided to follow, and he followed in a new way by reaching out to all those disaffected Democrats who were kind of tired of the old way and Republicans who were kind of sick of where the Republicans were falling down. And, lo and behold, Barack Obama, by not seizing the center, unseated the establishment candidate of, of course, Hillary Clinton, decided, "Guess what? Liberalism is back. I never let it go. I never moved to the center, and I'm going to bring along constituency after constituency in looking at the world and the country in a new way." He found his center. Republicans, guess what? They know where they-- what they believe and how they believe it. Seizing the new center is political death. Please reject the proposition.

### Moderator
Claim: Thank you, Laura Ingraham. And the proposition is "The GOP must seize the center or die," and here to summarize his position against the proposition, Mickey Edwards, a former Republican Congressman from Oklahoma and vice president of the Aspen Institute.

### Conspiracy Advocate (CA)
Claim: I should support the other side so that Laura will buy the margaritas. Look, there's just one simple question on the table. It's not whether Ralph and Laura are good people, which they are, who believe strongly in their positions or whether those positions are defensible. I'm a conservative, too. I agree with a lot of the positions they've taken. But it's whether or not they are positions that can gain in total the support of a very diverse nation.

The Republican Party we have today could disappear and be replaced by a range of its little subsets, all these other-- a Christian right party, a libertarian party, a no government, no tax party, a gun owner's party, a no gays and no immigrants party, each one with its own small niche of true believers, but America would no longer be a single nation of people standing together, and for the purposes of this discussion, then you will have lost. The Republican Party that once served as a viable noble alternative, a serious part of the national conversation will be, like the Federalists, the Whigs, and the know-nothings, irrelevant and disappeared. That is not an end that we should embrace, but as long as the Republican Party remains a coalition of extremes outside the broad range of reasonable discourse, that's precisely what will happen. We political people are kind of self-referential; we like to think of ourselves as thinking it's all about us, but it's not about us alone.

It's not about just what we think. This is a big diverse nation, and a political party that gets smaller and narrower as the country gets larger and broader is a party that is doomed.

### Moderator
Claim: Thank you, Mickey Edwards. And that concludes our closing statements. And now it's time to see which side you feel has argued the best. We're going to ask you again to go to the keypads by your seats and vote your view now on this motion, "The GOP must seize the center or die." If you agree with the side arguing for the motion, push number one. If you disagree with the motion, vote for that side, push number two. If you're undecided, became undecided, remained undecided, push number three. You can ignore the other keys and we'll have the results in about two minutes actually. And so, while we're doing that, I just-- I want to ask your attention for a moment because this could have been a very ugly debate and it wasn't. It wasn't. I think all four debaters came to the stage respecting the fact that there are arguments on the other side. They played it that way. This was a good, honest exchange of ideas, and I think progress was made just in understanding where both sides stand. I'd like to give a round of applause to all of them. And I'd also like to thank every single person who got up and asked a question tonight. You hit the target. Thank you to all of you for doing so. I love this. I think this is the first time it's ever happened-- and forgive me for typecasting, but I-- you know, I think it's the first time we've ever asked a probably overwhelmingly liberal audience to choose between these conservatives and these conservatives. So that must have been a challenge. We’d love you to keep Tweeting about the debate. We know you've been doing it all along. Our Twitter handle is @IQ2US. Our hash tag tonight is #GOP. Our next debate is here in New York. It's on Wednesday. It's May 8th. The motion is "the FDA's caution is hazardous to our health." Arguing for that motion, we'll have Scott Gottleib. He served in various capacities at the FDA. Most recently, he was the director of medical policy development there. His partner will be Peter Huber, a senior fellow at the Manhattan institute. He has also debated with us in the past and was terrific on this stage. Arguing against them, Jerry Avorn; he is a professor of medicine at Harvard who believes that when it comes to drug safety, the FDA is not doing well.

And David Challoner is his partner; he is chair of an institute of medicine committee that found the FDA's medical device clearance process to be fundamentally flawed. Tickets are still available for this one. The 19th we will be in Washington, D.C. in partnership with the McCain Institute for International Leadership. We're doing a debate there with this motion: "Cutting the Pentagon's budget is a gift to our enemies." For more information, you can visit our website, www.iq2us.org. And as I set at the beginning, we're on NPR stations, PBS stations here in New York, across the nation. We're a podcast. Download us, talk about us. Come back next time. All right. All right. It's all in. Remember, the way we do this, we have you vote twice and the team whose numbers have moved the most in percentage point terms will be declared our winner. Our motion is "the GOP must seize the center or die."Here are the results from before you heard the arguments. 65 percent of you agreed with the motion. 14 percent were against. 21 percent were divided. Those are the first results. Remember, the team that changes its numbers the most from first to second vote is the winner. So let's go to the second vote. Let's first look at the team arguing for the motion. They went from 65 percent to 65 percent. They picked up-- They picked up zero percentage points. Zero is the number to beat. The team against the motion, their first vote was 14 percent. Their second vote was 28 percent.

They went up 14 percentage points. That's enough. The motion, "The GOP must seize the center or die" has been defeated. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
