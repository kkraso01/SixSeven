# Debate Transcript

Topic: Mass Collection of U.S. Phone Records Violates the Fourth Amendment
Motion: Mass Collection of U.S. Phone Records Violates the Fourth Amendment

Debate ID: 100714%204th%20Amendment


## Round 1

### Moderator
Claim: So I'd like to first welcome to the stage Nick-- Nicholas Quinn Rosenkranz. He's a professor of law at Georgetown and a director of the Rosenkranz Foundation which initiated the Intelligence Squared series in 2006; and Jeffrey Rosen. He is president and chief executive officer of the National Constitution Center and professor of the George Washington University Law School. Let's welcome them onto the stage. Oh, you're here already.

So I'll take the center, because I'm moderate, moderating. Tell-- what I want to have you share with the audience is what's the purpose of Intelligence Squared, which normally does policy debates, partnering with the National Constitution Center, and how did we come to be here tonight?

### Moderator
Claim: So, the National Constitution Center's partnership with Intelligence Squared is the proudest thing we do. I think it is the crown jewel of our town hall programming.

And it is premised on this idea that Nick and I both share that there's a difference between political debates and constitutional debates. So whenever I teach constitutional law I begin by saying, "I'm not interested in your policy or political views. I want you to learn enough about the arguments on either side of the constitutional debate to make up your own minds.” And that's what we're going to talk about tonight. So, for example, Intelligence Squared has already held two phenomenal debates about surveillance. One was "Spy on me, I'd rather be safe." The other was "Snowden was justified." Tonight I don't care whether you think that Snowden was justified or whether you'd rather be safe. What I want you to do is listen to the text of the Fourth Amendment to the Constitution, which Nick will read to you and help explicate and also to the historical and contemporary arguments on either side about whether or not NSA surveillance is like the general warrants that inflamed the American Revolution by authorizing searches without particularized suspicion or whether it's justified because we have no expectation of privacy in phone numbers that we voluntarily turn over to phone companies.

And believe me there are strong arguments on both sides, and it's not clear which way the Supreme Court would rule. So it will be perfectly plausible and principled for you to conclude that you don't like NSA surveillance but you think the Fourth Amendment allows it, or, conversely, you might conclude that you very much do like NSA surveillance but you think the Fourth Amendment prohibits it.

### Moderator
Claim: So it's a little counterintuitive in that way, and I want to turn to Nick. He's a professor of constitutional law. And he is going to just take about a minute and a half to give you some things to look at in the text of this amendment to sort of get at the idea of the kinds of things these debaters need to test. Nick.

### Moderator
Claim: Yeah, so you have up there on your screen the text of the Fourth Amendment. I'll just draw your attention to a couple of details. First, notice “The right of the people to be secure in their persons, houses, papers, and effects against unreasonable searches and seizures shall not be violated.”I guess our first question will be, are these searches at all? Are these searches or seizures? Because if they aren't then this amendment is not in play at all. So that'll be sort of question one, are these searches or seizures? Then, second, if they are, are they unreasonable? How do you think about the reasonableness of a search or seizure?

That'll be sort of question two. And then notice there's this second clause, "No warrants shall issue but upon probable cause." A tricky question is, what's the relationship between these two clauses? Does it quite require that every search have a warrant? Doesn't exactly say that. It's-- you know, these two clauses have a kind of a tricky relationship. So, keep an eye on that. And then the last thing I'd urge you to keep your eye on is you may hear the phrase, "reasonable expectation of privacy." It's a kind of crucial doctrinal phrase in the Fourth Amendment context.

Just-- you might just ask yourself, how do you form such a thing? How did you form your reasonable expectations of privacy? Can they change? So when Snowden says that everybody's reading your-- that the NSA's reading your email, does it now then become unreasonable to expect privacy in your email? There's sort of a circularity built into the idea of a reasonable expectation of privacy. So, you maybe just keep your eye on that. I think we're going to hear a lot about that tonight.

### Moderator
Claim: And there will be a quiz at the end of all this. Actually there won't be but you are all going to be sitting in judgment of how well these debaters do on these quite fine points. So, I want to thank these gentlemen for being on the stage. Thank you for all being here. And-- we'd like to welcome our debaters to the stage. Please let's first welcome Alex Abdo. Alex, take your seat, and Elizabeth Wydra, your partner. Ladies and gentlemen, Elizabeth Wydra. Thank you. Good luck. Stewart Baker. And John Yoo. Thank you. John, you are from Philadelphia, are you not?

### Scientific Advocate (SA)
Claim: I am.

### Moderator
Claim: There you go. I hear your mom is here.

### Scientific Advocate (SA)
Claim: Yes, my mom is here, because there's no way the other side could possibly win with my mother in the audience.

### Moderator
Claim: All right. We're going to start formally now. I just want to tell you that in a minute, once we begin, I'm going to ask you to vote before you hear the debate about your view on this motion. And that keypad at your seat will be how you do it. You'll push number one if you're for the motion, two if you're against, and three if you're undecided. But let's begin the formal part of this evening. And I want to ask your indulgence in one thing. Because we're going to be ultimately a radio broadcast, there are a number of times in the evening when I might ask for your applause, which links to coming back and forth from breaks that the stations take on NPR when we're on NPR stations.

So, I'll just raise my hand. And when I do that, you have to spontaneously applaud. So, we can begin by-- one point I'd like to make is that our founder of Intelligence Squared U.S. is here. He's come down from New York. He's the reason we have this whole series. He's in the front row. And Bob, if you want to just stand up and take a bow, I'd like to welcome Bob and thank him for that. A smart old guy once said, and I paraphrase, “If you don't want your enemies knowing your secrets, then don't share them with your friends.” That was Benjamin Franklin, who obviously had a well-developed sense of privacy himself, as did his friends, the framers of the Constitution, when they went on to add the Fourth Amendment to the Constitution. And that is the one that bars the government from searching our houses and from going through our stuff without a good reason and without a warrant.

But none of those framer guys really foresaw this world of the internet and mobile phones and the government's present practice of sweeping up huge amounts of data from both of the sources on us. And the question is, does that violate the framer's intent? What would Ben Franklin say about all this? Well, that sounds like the makings of a debate. So, let's have it. Yes or no to this statement: “Mass collection of U.S. phone records violates the Fourth Amendment”, a debate from Intelligence Squared U.S. I'm John Donvan. We are here at the National Constitution Center in Philadelphia. We have four superbly qualified debaters, two against two, arguing for and against this motion, “Mass collection of U.S. phone records violates the Fourth Amendment”. Our debate goes in three rounds, and then the live audience here in Philadelphia will vote to choose the winner, and only one side wins. Again, our motions is “Mass collection of U.S. phone records violates the Fourth Amendment”, and here to argue for the motion, let's first meet debater team number one, the for side, and debater number one. Please welcome Alex Abdo. And Alex, just a little biography on you. You're a Staff Attorney with the American Civil Liberties Union. You are involved in the ACLU's lawsuit against the NSA's phone record program. In June of 2013, pertinent to your case, it was revealed that Verizon was required to turn phone records over to the NSA. And as it turns out, your outfit, the ACLU, is a Verizon customer. So, my question is, does this now mean you all switch massively to AT&T or Sprint? What happens?

### Conspiracy Advocate (CA)
Claim: No, we're still Verizon customers. And I don't think we'd escape the NSA that easily. But it's one of the reasons why we had a minor cause to celebrate at the ACLU, because we could finally prove the NSA is collecting our records, which was allowing us to have our day in court.

### Moderator
Claim: It was a good thing then.

### Conspiracy Advocate (CA)
Claim: I didn't say that.

### Moderator
Claim: Thanks, Alex Abdo. And who is your partner?

### Conspiracy Advocate (CA)
Claim: I'm joined by the illustrious Supreme Court and Constitutional Law Expert, Elizabeth Wydra.

### Moderator
Claim: Ladies and gentlemen, Elizabeth Wydra. Elizabeth, welcome. You are also arguing for the motion that mass collection of U.S. phone records violates the Fourth Amendment. You are Chief Council at the Constitutional Accountability Center. That's a think tank and a law firm and an action center whose mission is, to quote, “fulfill the progressive promise of our Constitution's text and history.” And I'm just wondering, since we're here in Philadelphia, about two blocks from where the Constitution was drafted, does that give you a bit of an exciting jolt?

### Conspiracy Advocate (CA)
Claim: Oh, yes. I think it's fabulous. You know, I don't know if it's because I was christened on the 4th of July in a bicentennial year or maybe my mother read a lot of American history while she was pregnant with me, but since birth, I've always been very inspired by the work of those framer guys.

### Moderator
Claim: You sound like a total ringer with the July 4th birthday.

### Conspiracy Advocate (CA)
Claim: I know, right? I'm a lucky girl.

### Moderator
Claim: To the team arguing for the motion, ladies and gentlemen. And that motion is mass collection of U.S. phone records violates the Fourth Amendment. We have two debaters arguing against this motion. Please first welcome Stewart Baker.

### Scientific Advocate (SA)
Claim: Good to see you.

### Moderator
Claim: Stewart, you're a partner at the law firm Steptoe & Johnson. You were-- you've got some pretty good credentials in terms of this issue. You were Homeland Security's First Assistant Secretary for Policy. You've also served as General Counsel at the NSA. That was back in the '90s, before we had this massive amount of internet and cell phone data. On the whole, is having that amount of data more of a curse or more of a blessing?

### Scientific Advocate (SA)
Claim: It's a blessing but a mixed blessing, I think. For all of us, right? We all like the stuff, and we worry about the costs.

### Moderator
Claim: But you're not shy about the internet. You have your own podcast?

### Scientific Advocate (SA)
Claim: I do, every week. If you have not gotten enough of my views after tonight, you can subscribe and get them every week.

### Moderator
Claim: What's it called?

### Scientific Advocate (SA)
Claim: It's the Steptoe Cyberlaw Podcast.

### Moderator
Claim: You've got about 400,000 new fans now.

### Scientific Advocate (SA)
Claim: Terrific.

### Moderator
Claim: Ladies and gentlemen, Stewart Baker.

And, Stewart, your partner is?

### Scientific Advocate (SA)
Claim: Is the only man in America who gets more hate mail on this issue than I do, John Yoo.

### Moderator
Claim: Ladies and gentlemen, John Yoo.

John Yoo, you're arguing against this motion, Mass Collection of U.S. Phone Records Violates the Fourth Amendment. You were two years at the Justice Department, right after September 11th. You authored a series of controversial memos on the Geneva conventions and enhanced interrogation. But now, you're a professor at law at Berkeley, University of California at Berkeley, which is somewhat caricatured as a liberal stronghold, I would say. So is-- how does that work for you?

### Scientific Advocate (SA)
Claim: Well, I enjoy the company of liberals from time to time.

They're not as bad as everyone says. They have nice views from their houses, and they cook pretty good food, and they make wonderful hand-made items. for sale at gift shops. I love-- I love living amongst liberals. I would dread to live in a conservative city. I never have. I don't know what it would be like. It would be no fun there.

### Moderator
Claim: Alright, so it sounds like you worked something out. Ladies and gentlemen, John Yoo and the team arguing against the motion.

So this is a debate. It's a contest. These debaters, these two teams are arguing to persuade you of the rightness of their stance on our motion, Mass Collection of U.S. Phone Records Violates the Fourth Amendment. And the way that we judge the winner in this debate is by your vote, our live audience here in Philadelphia. By the time the debate's ended, we have had you vote twice, once before and once after the debate. And I want to point out, victory for us is the team whose numbers have moved the most between the two votes in percentage point terms. So, let's go to the first-- the preliminary vote. If you go to those key pads at your seat, just pay attention to keys number one, two and three. You can ignore the others. They're not live. And if you are in support of this motion as it now stands, as you come in off the street, with this team, push number one. If you are against this motion as you come in off the street, with this team, push number two.

And if you're undecided, which is a perfectly reasonable position, push number three. And if you push the wrong button, just correct yourself and the system will lock in your last vote. And we'll finish this in about 15 seconds. Anybody need more time? Looks good. All right. We're going to lock that out. Onto round one, round one, opening statements from each debater in turn. They will be six minutes each, uninterrupted. Our motion is this: Mass Collection of U.S. Phone Records Violates the Fourth Amendment. And here to argue for the motion, Alex Abdo. He is a staff attorney at the American civil liberty-- he is a staff attorney at the American Civil Liberties Union's Speech, Privacy and Technology Project and counsel in the ACLU's lawsuit challenging the NSA's phone records program. Ladies and gentlemen, Alex Abdo.

### Conspiracy Advocate (CA)
Claim: Thank you, John. I'm honored to be here tonight to discuss the mass collection of Americans' phone records. But before I get into the program, I think it's critical to recognize that tonight's debate is not just about phone records and is not just about the NSA. This is a debate about the kind of society we want to live in. Do we want to live in a country in which our government routinely spies on hundreds of millions of Americans who have done nothing wrong? Or do we prefer to live in a country that's true to our vision, to the vision of our nation's founders, who believe that the government should, as a general matter, leave us alone unless it has cause to invade our privacy? I think our founders got it right, and I hope you'll agree, which is why you should vote for the resolution, mass collection of our phone records violates the fourth amendment. Here is what it looks like to live in a society of mass surveillance. Every time you place or receive a call the government knows who you talked to, when the call started and how long it lasted.

The government knows every time you called your doctor and which doctor you called, which family members you stay in touch with and which you don't, and which pastor, rabbi or imam you talked to and for how long you spoke. The government knows whether, how often and precisely when you called the abortion clinic, the local Alcoholics Anonymous, your psychiatrist, your ex-boyfriend, a criminal defense attorney or the suicide hotline. If you called someone today, by tomorrow morning, the government will have a record of that call. It will keep that record for the next five years. And it is doing the same for every one of your calls and every one of the calls of millions of other innocent Americans. This program is the most sweeping surveillance operation ever undertaken in the United States. And it is unconstitutional for the simple reason that the Fourth Amendment does not allow dragnet surveillance. As my partner, Elizabeth, will explain in a few minutes, dragnet surveillance in fact was the principal evil that the Fourth Amendment was designed to prevent, and for good reason. Dragnet surveillance intrudes on the most fundamental of liberties in a free and democratic society: to be left alone by our government, absent good cause.

The phone records program breaks that promise. It places the entire country under surveillance without any suspicion. It threatens our ability to communicate freely without having to worry that the government is looking over our shoulders. It discourages journalists’ sources from coming forward, knowing as they now do that every-- every one of their calls is being documented in a government database. And it causes ordinary Americans to hesitate before calling individuals or organizations that they would rather not have as a part of their permanent record on file with the NSA. Now, our opponents will attempt to minimize the NSA program's intrusiveness and exaggerate its effectiveness. They'll argue that the Fourth Amendment does not protect our phone records, that there are protections in place for our privacy under the program and that the program is necessary for our national security. All of those arguments are wrong. First, our phone records, especially when they're collected in bulk, are extraordinarily sensitive. They reveal all of your associations, personal, professional, medical, all of them.

In fact, your phone records can be every bit as sensitive as the content of your phone calls. If you call someone other than your spouse routinely at 1:00 in the morning, you don't have to know what's said in order to know what's going on. And if a government employee calls a reporter a dozen times before news breaks of an illegal government operation, again, the call pattern tells the story. Our phone records are, in other words, a proxy for the content of our calls. Our opponents will say that the Supreme Court has already decided that phone records are not protected by the Constitution. This argument is based on a Supreme Court case from 1979 called Smith vs. Maryland. But that case involved collection for several days of an individual criminal suspect's phone records. The NSA's program, in contrast, involves the indefinite surveillance of millions of innocent Americans. Our opponents will say that these differences don't matter.

But it's truly bizarre to define the boundaries of privacy in the digital age on the basis of a legal opinion issued before the internet as we know it was created, an opinion that many Supreme Court justices have already said is ill suited to the digital era. Second, the privacy protections that our opponents will focus on are a red herring. Those restrictions are weak. They can be violated, and they already have been thousands of times. But more importantly, under our opponents' theory, the Constitution simply does not apply to our phone records. This means that the government could collect them without any of the supposed privacy protections that they will describe. Another fatal flaw in this argument is that the government's collection of our phone records violates our privacy even if there are restrictions in place for their later use. The collection itself is a violation. For that reason, we don't let the NSA keep a copy of every single email sent in the country so long as there are protections in place on the back end. And we don't allow the NSA to put a video camera in our bedrooms so long as it promises not to press play unless it has a good enough reason. Third, bulk collection has not made us any safer.

Virtually every independent review of the NSA's phone records program has concluded that it hadn't stopped any terrorist attacks and that the government can track down terrorists without bulk collection by issuing targeted requests to the phone companies. A congressional review group said this: That after studying the NSA's classified evidence, it could not, quote, "Identify a single instance involving a threat to the United States in which the telephone records program made a concrete difference." A separate presidential group came to the same conclusion, and the president himself has now agreed. One final point: Tonight's resolution is focused on phone records. But don't be fooled. The consequences are much, much broader. If the Fourth Amendment permits the bulk collection of our phone records, then it would permit the bulk collection of other similar records. The problem is that virtually everything we do today leaves a digital trail of some sort. Whenever you send an email, visit a website, use your credit card or even just walk around with your phone turned on, you are leaving a rich trail of digital bread crumbs in your wake. The arguments our opponents will make tonight would expose all of that information to routine, bulk collection by the government.

That's not the world that our framers envisioned when they drafted the Fourth Amendment, and it's not the world that you should accept. You should vote for the motion, the mass collection of our phone records violates the Fourth Amendment. Thank you.

### Moderator
Claim: Thank you, Alex Abdo.

And that is our motion, Mass Collection of U.S. Phone Records Violates the Fourth Amendment. And here to argue against the motion, Stewart Baker. He is a partner at Steptoe and Johnson and former assistant secretary for policy at the Department of Homeland Security. Ladies and gentlemen, Stewart Baker. That's an applause line.

### Scientific Advocate (SA)
Claim: Thank you. It's really a pleasure to be here for the Intelligence Squared Debate. These are among the most civil and thoughtful public engagements on issues that I'm familiar with in the current world and a world where civility is often in short supply. So, it's a pleasure to be here. But I have to say that while Alex has anticipated some of my arguments, he's left a few things out.

The question that we're debating is a question of law. Does the Fourth Amendment-- is the Fourth Amendment violated by mass collection of phone records? And what he glided over was the fact that the Supreme Court has decided this. If this were a true and false question on a constitutional law exam and you said, "Yes, the Fourth Amendment is violated by that," you'd get a D because the Supreme Court has decided that these are records that are not protected by the Fourth Amendment because of what Ben Franklin said, If you give away your secrets, they're not yours anymore. Other people get a say in them, and it's not a search when those people make those secrets available. So, that is the state of the doctrine. What Alex said is essentially he doesn't like it, he wants you not to like it. But it is the Supreme Court's law ruling.

And of the 20 judges that have been asked to evaluate the argument that Alex made that somehow the passage of time and the adoption of the Internet means that this case is no longer applicable to a mass collection of data, 20 judges have looked at that and 19 of them have rejected Alex's argument. He's got one judge who said, "Yeah, I would just as soon overrule the Supreme Court." But district court judges don't ordinarily get to do that. So, the answer to the question I think, and what I hope you will ultimately decide, is that the Fourth Amendment is not violated by this. But there's a second aspect of this that I do want to get to, which is you're probably asking, "Yeah, but can that be-- really be the right result?" And I want to address that because in the end, if you decide-- even if you decide that taking these records is an event that implicates a reasonable expectation of privacy, the question is "Is it reasonable for the government to have done what they did?"And for that I think we ought to address the question of why the government did this. The biggest terrorist threat we face is some terrorist group, well organized, well-armed, with a safe haven that-- where they can bring people with clean passports together, recruit them, train them, finance them, and then send them into the United States to carry out a coordinated attack without any warning, it's almost impossible for us to catch those plots as they're being trained if there truly is a safe haven. So, our best hope for catching those plotters is that they will have to coordinate, probably by phone, inside the United States and perhaps with their trainers and recruiters back in the Middle East. And if we can catch those calls back to the Middle East and then tie them up to the calls that, that person has made inside the United States, we have at least a fighting chance to roll up that attack before it occurs. That's what happened in 9/11. We missed that opportunity.

And that's what this program was designed to deal with. They can't, however, pursue the idea that Alex has been offering: go to each of the phone companies and say, "Do you have anybody who called these numbers?" Give every phone company in America a list of the most sensitive targets, all the terrorist numbers we know in the world, and make sure that they hold those in confidence. Very difficult to do, and then once you try to find somebody in the United States by matching up their calls, once you get past the first hop to the first person, and you're looking to see whether he had sensitive conversations, you're going back to every phone company in America and asking them about those calls. This is a nightmare. The only way you can actually do this as fast as the terrorists can carry out their plot is if you have them in one place where you can search them.

And that is what the government tried to do. They put them in one place so that they could search them. That's a collection. Alex says that fact alone made it unconstitutional and that we're somehow-- NSA knows when you call your girlfriend at 1:00 in the morning. But the fact is it does us no great harm if all that record is sitting on a hard drive in a safe somewhere and nobody has actually opened up those records to look at. And that's what the government did. They put the protections for privacy not on the collection but on the question of "What are we going to search?" And they said, you can't search without a good reason for searching, a reasonable, articulable suspicion, limited people who can do it, lots of audits, no number-- no names in this database, only numbers-- and the number of searches that were performed on an annual basis was about 300. Out of that, they found some suspicious patterns. And they referred those-- about 500 a year-- to the FBI to find out who these people are and what they're doing.

That's the extent of the government's intrusion into privacy, at a time when about a million records are gathered under criminal subpoena. So, we have a choice. We can either say, “No, the government can never do that because it's a violation of the Fourth Amendment,” or we can say, “We want to allow that to happen, but with privacy safeguards.” I think the choice, especially at a time when suddenly we have a terrorist group that does have a safe haven, the choice is to choose privacy and security. Thank you.

### Moderator
Claim: Thank you, Stewart Baker. And a reminder of what's going on, we are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, arguing it out over this motion: Mass collection of U.S. phone records violates the Fourth Amendment. You've heard from the first two debaters, and now onto the third. I'd like to welcome to the lectern Elizabeth Wydra.

She is Chief Council at the Constitutional Accountability Center and former Supervising Attorney at the Georgetown University Law Center Appellate Litigation Clinic. Ladies and gentlemen, Elizabeth Wydra.

### Conspiracy Advocate (CA)
Claim: Thank you so much. Thank you so much, John. It's great to be here tonight. Now, Stewart certainly presents a frightening picture of terrorists working here in the United States. But he presents a false choice between the idea of securing our nation and remaining faithful to the fundamental values that our nation holds dear, as expressed in the Constitution and, relevant to tonight, the Fourth Amendment. We can do both. As my partner Alex has ably explained, the NSA has not established that its massive intrusion into the lives of everyday Americans is necessary in order to keep us safe. But while this dragnet surveillance program has not been established as necessary, the importance of protecting against such suspicionless, sweeping searches, as those conducted by the NSA, is established in our Constitutional tradition beyond question.

Intrusive searches like the one being conducted every day by the NSA strikes at the very core of what the Fourth Amendment was enacted to prevent. It gets to the very heart of why our nation's founders were willing to lay down their lives if they had to in order to protect the liberty, security, and personal privacy of Americans. So, as you listen to our debate tonight, I would ask you to keep in mind the vision and the values of our founders. The reasons why they wrote into our Constitution the Fourth Amendment in the first place-- keep that as your North Star tonight. When the founding fathers drafted the Fourth Amendment, the mischief to which they were responding was principally the British use of general warrants and writs of assistance.

Broadly authorized searches that allowed British officers to go into the homes of American colonists without any particularized suspicion of wrongdoing. And they were used broadly in the hope that if they went through enough people's stuff, they would find something that would show evidence of wrongdoing. Now, that sounds a little familiar to me today. These generalized searches back then were decried as instruments of arbitrary power. They were used to silence critics of the crown and to trample the personal liberty of the American colonists. In fact, American colonists' opposition to these sorts of generalized searches was, as Chief Justice Roberts explained in a recent Supreme Court decision on behalf of all nine justices on the court, applying robust Fourth Amendment protections to the searches of cell phones, the opposition to these sorts of warrantless, generalized searches was one of the driving forces behind the Revolution itself.

To illustrate, the Chief Justice recounted a famous speech given in 1760s Boston by the patriot James Otis, denouncing the use of warrantless searches, generalized searches without individualized suspicion, that invaded American colonists’ privacy without probable cause. One young man listening in the audience that day was none other than John Adams. And recounting Otis's speech and the day, Adams described it later as, “the first scene of the first act of opposition to the arbitrary claims of Great Britain.” Then and there the child independence was born. The need to get a warrant to have reasonable suspicion before invading someone's privacy, that wasn't a mere technicality, something on a checklist that you have to go through that slows down good law enforcement, something that the guys on “Law and Order” sort of get past with a wink and a nod.

It was something that was so important to our founders that it was an essential part of the struggle for independence. We are no longer in that first act of the great American story, and we are fortunate that we have to guide us today the wisdom and the words of the Constitution. James Otis in the 1760s didn't have the Fourth Amendment to back up his arguments, but fortunately, Alex and I do tonight. The text of the Fourth Amendment, which you've seen on the screens, declares the right of the people to be free from unreasonable searches. And it tells the government that it needs to have probable cause before it wants to invade our privacy. The detailed text enshrines a specific prohibition, something that's rather unusual in the Constitution, which often speaks in broader terms, a specific prohibition against the types of suspicion-less searches that the NSA is conducting every day on Americans-- sweeping searches and surveillance of very private information without any individualized suspicion of wrongdoing.

And the wisdom of our founders applies just as much today as it did in the 18th century. I think those framer guys still have a lot to tell us about what kind of society we want to live in, as Alex said. Just because the sensitive private information that we hold-- that we hold dear today can be gleaned remotely and electronically rather than having a British red coat break the padlock on our leather trunk and our cute brick colonial in Boston, as Chief Justice Roberts said, that does not make that information any less worthy of the protection that the founders fought for. Now, the other side will try to say that there isn’t a search or there is some exception that makes it reasonable under the Fourth Amendment. But I would submit that any exception to the Fourth Amendment that allows the government to collect data that can reveal sensitive, deeply private information about every American citizen without any suspicion that we are engaged in real wrongdoing.

Any exception to the amendment that allows that would swallow this most important protection in the Constitution, something that was so important to our founders that it breathed a spark to the fire of revolution. So, if you keep as your north star those founders, I trust that you will vote for the proposition that mass collection of Americans' private records violates the Fourth Amendment. Thank you.

### Moderator
Claim: Thank you, Elizabeth Wydra.

And that's our motion: Mass Collection of U.S. Phone Records Violates the Fourth Amendment. And here to argue against that motion, John Yoo. He is the Emanuel Heller professor of law at UC Berkeley and former deputy assistant attorney general in the office of legal counsel at the Department of Justice. Ladies and gentlemen, John Yoo.

### Scientific Advocate (SA)
Claim: Thank you very much for that invitation. And it's a real pleasure to return to National Constitution Center.

I'd like to thank Jeff Rosen, an old college and law school friend of mine and now the president of this wonderful center, and our worthy opponents, who have the misfortune of not being from our great home city of Philadelphia and so are destined to lose; and my co-arguer, Stewart Baker, and also the Rosenkranz's family I've known for quite some time. It's a real pleasure to be here under their support. None of that comes out of my time for the debate. So-- and I still want to say, it's very likely that I personally be the worst debater because I'm used to sitting in a faculty lounge and not speaking within a six-minute window. In my classes, it takes about six minutes for me to figure out what cases are being covered in the class that I'm certainly standing in. So, I apologize if I don't get to all my points. And I don't-- as I'm amazed, my colleagues all did finish exactly at 00:00. I was quite impressed. But I want to make just make two important points-- three important points. See, I already started. One, from the-- what you heard from the other side, you would think that the government was just interested in collecting information about all of us because they're just interested in collecting information about all of us.

The most important point is that there's a reason why the government created these programs. It's the one that was present when I was in the government on 9/11 itself and the reason I was-- one of the first things I had to do in the Justice Department was to pass on the legality of what became the surveillance programs. And the reason why is that if you look at the text of the Fourth Amendment, it says we have a right to be free from unreasonable searches and seizures. Much of what Ms. Wydra had to say was about British general warrants and when you get a warrant from a judge, they conduct a search of our houses. I think that's an entirely different question than when the government can institute a broad program that doesn't look at the content of our communications, just looks at the addressing information and the phone numbers and whether it can do that, whether it's a reasonable search given the circumstances. That's how the Supreme Court’s interpreted the language, and that's how we should.

And those reasonable circumstances, it seems to me, as my co-panelists argued, on 9/11, we were attacked by a different kind of enemy, not a foreign country, but an enemy that hides and disguises itself as normal civilians, that communicates using normal civilian communication methods like the internet and phone calls to launch surprise attacks with devastating effect on our cities, with a goal of killing as many civilians as possible. After 9/11, confronted by this problem, this challenge, we decided this would be a reasonable thing to do to try to find any more terrorists coming to the United States by looking at phone numbers of people from abroad calling into the United States and what those phone numbers called, to try to detect patterns of enemy agents trying to infiltrate into the United States. That's the purpose of the program. And I vigorously deny any idea that this is just part of some government dragnet because the government just likes to collect information about all of us just for the fun of it.

The government did not do it for that reason, and I was present at that time, and the reason we did it is because we were suffering from the 9/11 attacks. Second point, I want to just point out, I'm sure that our debate opponents are not often compared to conservatives, but they are as the bed fellows of Robert Bork, because what they have done is said, “I don't care what precedence says. I have discerned the principle of the framers, and I am going to impose it over the democratic choices that we have made in our society today. Throw out Smith vs. Maryland, the governing Supreme Court precedent in this area which every lower court judge to examine this program and similar programs has used as a governing law. Throw out the fact that every federal judge to examine these programs at the appellate level and almost all them at district court level have approved this. Throw out that the president has approved it, the Congress has approved it, and the special FISA court made by federal judges has approved it under the Smith vs. Maryland idea.

Instead, from the phrases in the Fourth Amendment, I am going to discern this overriding principle that will be imposed on our society.” Now, how do they know that the text the Fourth Amendment knows this? We have so many debates in constitutional law. Nick Rosenkranz and Jeff Rosen, who you just heard from in the beginning, they can spend six hours arguing about the meaning of the word "the" in the Constitution. You probably just saw a little bit of it at the beginning. How do they know that the framers would have disapproved of a collection program that collected phone numbers; didn't listen in on the conversations themselves, but only collected the phone numbers? When people, judges, lawyers who've devoted their lives to trying to figure out what the Constitution means have almost unanimously agreed in their written decisions to approve the constitutionality of this program. So, if anyone's the radicals here, it's the people on the other side, Ms. Wydra, Ms. Abdo-- Mr. Abdo, who want to throw out all those decades of cases governing in favor of their understanding of the Constitution.

But suppose you disagree with the Supreme Court, what should you do? Maybe I, as a policy matter, would draw the line between security and privacy somewhere else. We should decide it the way we decide most of the questions in our society. We have elections. If you don't like the line that the government has drawn, elect a president and Congress who would draw it differently. This is not a question, I think, as a democracy, that we should leave up to five-- no offense to the retired people in the audience-- superannuated elderly people on the Supreme Court, probably don't know how cell phone or smartphone really works; I'm sure have no Facebook or Twitter accounts to let you know about their latest opinions. And so if you really want to change the law here and change what the government does, elect different people to Congress. Elect Rand Paul to president. Put-- have them put into effect the policies that we want. But that's how our Constitution is designed to work.

### Moderator
Claim: John Yoo, I'm sorry, your time is up. And thank you very much. John Yoo, ladies and gentlemen.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is Mass Collection of U.S. Phone Records Violates the Fourth Amendment. Now we go on to round two. And round two are where the debaters address one another directly and they take questions from me and from you in the audience. Again, this is our motion: Mass Collection of U.S. Phone Records Violates the Fourth Amendment.

We have a team arguing for the motion, Alex Abdo and Elizabeth Wydra. They have painted a picture of a world in which the government knows an enormous amount-- about us because of its ability to skim details about our lives from phone records, places who we called. And as they point out, an awful lot of content, real stories about who we are can come out of that information. They make the argument that the opinions governing this process that have been relied upon by courts that have approved these practices are out of date, and they also make the argument, almost paradoxically, that if you go back in time, that the founders of the Constitution and the writers of the Fourth Amendment certainly would not have approved such a massive, as they would say, "dragnet" kind of search because it was this very sort of thing that the colonists were fighting and went to war for in the American Revolution.

The team arguing against the motion, John Yoo and Stewart Baker, they are making the technical point initially, "Look, we've won this debate because the Supreme Court has already settled this question," but in the spirit of the exchange of ideas here they do go on to say that in wartime the stakes themselves, American lives, the threat of terror attack, make the reasonableness issue-- put the reasonableness issue in a different light, that the Fourth Amendment bans unreasonable search and seizures and that the government program of collecting only data about when and where and who we called is not unreasonable when put up against the stakes of needing to save American lives and to defeat our enemies. So, those are some of the arguments that we've heard. And I want to say two things at the outset.

We really do want to make this an argument about the constitutionality of this practice, and so, Stewart, I will say, although technically you are right, let's look at this from the point of view that, you know, we-- this is the Supreme Court and we've gone back in time, and this side is arguing that the thing is unconstitutional, and you're arguing that it's constitutional. And I want to say to Alex in particular, because you rested so much of your case on the kind of world we have and that we wouldn't like that, that really isn't the point that we're debating here tonight. We're really debating about whether the government has the right to do this under the Constitution, not to say that the kind of world is irrelevant, but to try to stick to this question of whether it stands under the Fourth Amendment or not, which I know that, Elizabeth, you very clearly were saying it was not. So, let's get to some of the specifics that we heard about this. First of all, there's this whole notion of "What is a search?"And, Stewart Baker, your opponents have said that basically the NSA sweeping up an enormous amount of information, regardless of the fact that they're not actually listening to what's in the phone calls, is-- by itself constitutes a search, and, therefore, gets us right into the area that is protected by the Fourth Amendment. So, I'd like to talk-- have you respond to that and then go back to Alex to talk about this issue of "When is a search a search and when is it not?"

### Scientific Advocate (SA)
Claim: So, if John keeps a diary and the police want it, if they come into his house and take it, that's a search. If he gives it to his mom and she takes it home and the police come and knock on her door and say, "Would you give us a copy of John's diary?" that's not a search. What the government has done here is they have gone to people to whom these records have been given by the people who made the phone calls. We all know the phone company needs to know what numbers we're dialing in order to deliver the call to the right place.

So, we have shared this information already. We can't expect to be able to claim a property right against search, wherever that information was.

### Moderator
Claim: So the underlying principle of what constitutes privacy, vis-à-vis sharing information with other people, works how? In other words--

### Scientific Advocate (SA)
Claim: The Supreme Court's decision essentially stood for the proposition that you have a much diminished expectation of privacy once you knowingly shared information with someone else, especially if the government gets it from that person.

### Moderator
Claim: Okay, Alex Abdo, to respond to that.

### Conspiracy Advocate (CA)
Claim: I think that reflects a pre-digital understanding of our privacy, and I think that's one of the fundamental problems with our opponents' position is that they ask a very simplistic question that may have made sense in the 1960s and 1970s but doesn't make any sense today where the vast majority of our communications have to be shared with an intermediary, not because we're voluntarily giving the information over to AT&T or not because we're voluntarily giving it over to Yahoo or Microsoft or Gmail, but because we have to in order to use those communication systems.

And I think it would be-- it would undermine the security of all those systems and undermine our right to privacy to say very simplistically that this doctrine, this notion of sharing, is an on/off switch. That is never how our judges have applied it. It's not how the Supreme Court has applied it. And if you look at recent cases, you're seeing the Supreme Court struggling with how to update privacy law to account for this dramatic change in technology. And--

### Moderator
Claim: And the essence of the change is what? I mean, we all know that the essence of the change is that they can get a lot more of this kind of data. And 25 years ago, when this law was passed, they could look at one person and the phone numbers he dialed over a couple of days. Now we know that they can get millions for a lifetime essentially. What-- why does that make a difference in the impact on the kind of information.

### Conspiracy Advocate (CA)
Claim: I think that's part of the change. The other part of the change before-- and if I can say before answering your question-- is that it is now not really possible to meaningfully participate in society without using the communications platforms that all of the tech companies have brought to us. And so, it's necessary to, as Stewart would say, share this information.

But it's not of that same voluntary nature that I think our opponents rely on.

### Moderator
Claim: Okay. John Yoo, your response to that.

### Scientific Advocate (SA)
Claim: Yeah. I think we ought to be caution of these efforts to claim, just because some new technology came along, we have to throw out all the rules that we've had before and replace it with some uniform, general, radical, simple rule. Life is not that easy, and life is not that simple, especially when the technology is so new. We need to learn more about how all these technologies work, how they interface with law enforcement. Then, slowly, incrementally, we should be making decisions of what the best rules are rather than just saying, “Oh, because automobiles have come along, we can throw out all the rules about horse accidents because those were horses and these are cars.” Instead, we should try to analogize from the things that came before using common sense. That what the Constitution seems to say when it says “reasonable searches and seizures.”

### Moderator
Claim: Elizabeth Wydra.

### Conspiracy Advocate (CA)
Claim: Well, you know, John mentioned in his remarks, he said that he didn't want to leave these decisions to, you know, five old guys on the Supreme Court.

But I'm sorry to say that you're behind the times of nine justices on the Supreme Court, however old they are, because just a few months ago at the end of last term, a unanimous Supreme Court told us that digital is different in a case that applied the Fourth Amendment to Smartphones.

### Moderator
Claim: Different how?

### Conspiracy Advocate (CA)
Claim: Well, you know, I think there's a great analogy that Chief Justice Roberts used. He said that, “Saying that a ride on a horse and buggy is the same as taking a rocket ship to the moon makes about as much sense as using some of these old precedents and rules when applied to the digital age, because the type, the quantity, and quality of information that can be gained in the digital age is just so different that it actually makes a real difference to the Fourth Amendment.

### Moderator
Claim: I want to let Stewart Baker respond. But can you take one sentence to say, different how? How does it add up to a different kind of experience?

### Conspiracy Advocate (CA)
Claim: So before, when you would have this information that was available to the public, it was sort of a random tile that could give you a very small glimpse into a person's life.

But because of the quantity of data that can be accessed very easily-- this came up in a case about GPS locators-- it adds up to a mosaic that provides a rather clear picture of a person's life in a way that you couldn't in a pre-digital age.

### Moderator
Claim: Okay. That was two sentences with a parenthetical phrase-- but it was pretty tight.

### Conspiracy Advocate (CA)
Claim: With a semicolon, maybe.

### Moderator
Claim: Stewart Baker.

### Scientific Advocate (SA)
Claim: So, the one thing that we're acting as though is though if we don't have the Supreme Court ride to our rescue, all of this data is suddenly going to be available to the government under no restrictions whatsoever. Since Smith against Maryland was decided, Congress has enacted and amended the rules on electronic searches four or five times. We can rely on democracy to make these decisions. The average age, by the way, of a Supreme Court-- 70 years. You know, I don't know about you; I am a boomer and I'm sick of having boomers make these decisions.

There's no reason why we should ask the Supreme Court--

### Moderator
Claim: Stewart, though, does your defense of the position that there are safeguards in place actually defend the constitutionality?

### Scientific Advocate (SA)
Claim: Yes. My argument is we should not turn-- right now, these records are not subject to Fourth Amendment analysis under Smith against Maryland. The argument is, “Well, that's going to open us all in a digital age to--”

### Moderator
Claim: I know you've all alluded to Smith against Maryland. Just take three sentences-- or I can do it.

### Scientific Advocate (SA)
Claim: Yeah, I can do it.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: So, in Smith against Maryland, the cops were investigating calls to a woman-- harassing calls to a woman. They got a pen register on a suspect's phone.

### Moderator
Claim: What is a pen register?

### Scientific Advocate (SA)
Claim: A pen register records all the numbers that he dials.

### Moderator
Claim: And it does it down at the phone company.

### Scientific Advocate (SA)
Claim: Down at the phone company. And essentially, they had call data records on this guy for several days until they realized yes, he's making the bad calls.

And the court said yeah--

### Moderator
Claim: So, I'll break it down a little bit. So, he got arrested. She picked him out in a lineup, said, “That's the guy.” He got busted. And his lawyer said, “That was an unfair search because you tapped me without a warrant.”

### Moderator
Claim: And the court said, “Well, when you dial a phone number, that's not a secret because you just dialed it. You put it out into the world.” Okay. So, that's what the court is using now to say that the metadata is not a secret. Do I have that pretty much nailed, Alex?

### Conspiracy Advocate (CA)
Claim: I think that's right. Yeah. Can I respond to one thing that Stewart just said?

### Moderator
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: And something that, Professor Yoo said as well, which is that we shouldn't trust courts to safeguard our individual rights. And I think that reflects a fundamental misunderstanding about what the Bill of Rights is about. The Bill of Rights was designed to withdraw from political the majorities the decisions that affect the individual rights of people who can't protect themselves through political constituencies. It was precisely for that purpose that the Constitution and our framers placed those decisions in unelected, tenure-protected judges so that they could safeguard individual rights.

And so I think the wrong answer is to say we should leave our individual rights to Congress, particularly this Congress or the next.

### Moderator
Claim: John Yoo, do you want to respond to that?

By the way, vocal approbation is fine with us. We like our audience at home who's listening to know that you're here. We only discourage booing and hissing.

### Scientific Advocate (SA)
Claim: This is how you know that John is not from Philadelphia, because we know in Philadelphia we boo and his our hometown players more than the opposing side.

### Scientific Advocate (SA)
Claim: And Santa Claus, I hear.

### Scientific Advocate (SA)
Claim: snowballs for Santa Claus if you're old enough to be here, as I was.

### Moderator
Claim: Oh, no. I’m from the Bronx, but I'm showing enormous restraint.

### Scientific Advocate (SA)
Claim: As I often say, you know, nothing the opponents could say would be as mean as what my Korean mother would say to me, so-- nobody laughed at that?

I guess that's just Korean humor.

### Conspiracy Advocate (CA)
Claim: We know she's here. We don't want to get in trouble.

### Scientific Advocate (SA)
Claim: Yeah, you don't want to be in trouble with my mother here.

So, there's a number-- a number of things to say, most of which I've forgotten because I was telling jokes. But the problem with this view of the Bill of Rights is, I quite agree the Bill of Rights is there to protect minority rights. I missed it in their presentation. I didn't hear any discussion of any minorities who are being singled out here for mistreatment by the government. This is a surveillance program that works on everybody. In fact, there is no way to know what the race or gender of the people whose data's being collected for. If there were cases-- if it was targeted-- say, for example, if the IRS was only considering the applications of conservative groups or liberal groups for tax status, that would be targeting a minority group, right? target some for their ideology. Then I think you would have a much better claim. This is not about--

### Moderator
Claim: Let me take that argument while you're on it and take it to Elizabeth Wydra. What about that-- John's argument that says the process is not discriminatory as far as we know?

### Conspiracy Advocate (CA)
Claim: Well, that would be relevant if we were making a claim under the equal protection clause of the 14th Amendment, but instead we have a specific text in the Constitution, the Fourth Amendment, which prohibits these types of searches.

So that's what's violated, not equal treatment under--

### Moderator
Claim: All right. Let me stop you and go back to John. Did she just slam you down?

### Scientific Advocate (SA)
Claim: No, I disagree.

### Conspiracy Advocate (CA)
Claim: mom.

### Scientific Advocate (SA)
Claim: I disagree because, you know, again, the text of the Fourth Amendment says that people have a right to be free from unreasonable searches and seizures, and so that's why you have to look at democracy. My claim is not that this means this is not to be done. It's that all of us in society have a view on what's reasonable and unreasonable. It's not a monopoly of five justices of the Supreme Court to tell us as a society what is reasonable and unreasonable. And we have, as Stewart mentioned, in previous cases, looked to Congress and the president and the courts all together picked by us in elections to decide what's a reasonable search when telephones came along and the internet comes along.

### Moderator
Claim: And on the point of reasonable versus unreasonable, Alex Abdo, I want to take it to you, something that, John, you said that's opening remarks.

He made the argument that the program is not unreasonable-- see, I think basically his context was being in a-- you know, in a war situation that it's a security situation, that reasonable is weighed in the context of larger consequences. And his argument was, if it's saving lives, if it's defeating the enemy, then it stops being so unreasonable because of the stakes involved.

### Conspiracy Advocate (CA)
Claim: I think that's a narrow way of viewing the Constitution, but it's not particularly surprising that professor Yoo makes that argument. You know, professor Yoo made the same argument with respect to the fact that war time authority trumped individual protection against torture. And I think that's a wrong way of viewing the Constitution.

### Scientific Advocate (SA)
Claim: I-- that's not correct, by the way. But go ahead.

### Conspiracy Advocate (CA)
Claim: We can discuss that another time. But in any event, the question of whether--

### Scientific Advocate (SA)
Claim: Let's discuss it now.

### Moderator
Claim: Actually, let's--

### Scientific Advocate (SA)
Claim: I mean--

### Moderator
Claim: Let's have you withdraw that.

### Conspiracy Advocate (CA)
Claim: I'll withdraw that. I apologize.

### Moderator
Claim: Because I don't want to take time on that. And we are going to withdraw it to let you make a different point if you would like to, because we really don't want to go back to people's records on other issues because it becomes an irresistible rabbit hole that we go down.

So I would just ask you to--

### Conspiracy Advocate (CA)
Claim: Sure.

### Moderator
Claim: --to not base the argument on what John said in the past.

### Conspiracy Advocate (CA)
Claim: So, I think the Constitution protects us from unreasonable searches and seizures. And the initial question that you need to ask is whether it is ever reasonable for the government to engage in bulk collection. And the problem with going down that route is we would end up in a society that the framers could not possibly have envisioned which is that the government would always, for good purpose, it would say, collect vast quantities of information about people who've done absolutely nothing wrong. But even if you think that's an acceptable way of thinking about the Constitution, the problem with our opponents' arguments is that two separate review groups, both with access to classified evidence, who've now reviewed the case that they're relying on to suggest that this program is necessary, have concluded that it simply isn't necessary. That the government could have accomplished its interest through the targeted use of surveillance orders to these companies or to other companies.

### Moderator
Claim: Stewart Baker. And after that, I want to go to questions.

So, you can prepare your questions, I will come to you, and I'll explain how we do that after Stewart speaks.

### Scientific Advocate (SA)
Claim: So, the notion that you can somehow figure out-- well, there's something like mass data collection, and we'll just say, that can't be collected without implicating the Fourth Amendment is just as Alex said, superseded by the march of technology. There are a million subpoenas today for call data records for law enforcement purposes. That means tens of millions of records in the hands of government agencies on what amounts to a mass basis. There are ten million suspicious activities reports filed by financial institutions about their bank account holders because they want the government to know about what's happening. Is that mass collection? There are 4.5 million medical records reviewed by Medicare, your medical records and ours, reviewed by Medicare, looking for fraud every day.

All of those things are things that serve important antifraud purposes that the United States government is pursuing. If we suddenly start to say, it's mass collection, it must be a Constitutional problem, we're going to have a line-drawing problem to beat every line-drawing problem we've ever seen.

### Moderator
Claim: Okay. Let's go to the audience for questions. And the way that I would like it to work is, if you raise your hand, there'll be microphones circulating up and down the aisle. I'll call on you. Wait till a mic is handed to you. Stand up, tell us your name and hold the mic about this distance from your mouth so that we can hear you over the air. And the one thing I would urge is to keep in mind that we're trying to do a debate of a Constitutional nature here. And I would also urge you not to debate with the debaters, but to ask them a question that you think that they should be debating among themselves. So, any hands go up on that? Sir, right-- right-- the farther back one, yes. Two rows from the back. Thank you. If you can tell us your name, please, too.

### Moderator
Claim: My name is John Sword

I have a question for the group for the motion. If we find ourselves in a situation-- and I hope this never happens-- that terrorist attacks significantly increase, would that change your argument, or that's irrelevant to this question?

### Moderator
Claim: That's a great question. Alex Abdo.

### Conspiracy Advocate (CA)
Claim: No, I don't think I would. Everyone to have reviewed the way that the NSA should go about its business says it should go about it in a targeted way. And that the key to protecting the country is not through suspicionless surveillance of everyone, but through very targeted efforts directed at those who are doing us harm. I think that's the lesson of the two review groups who reviewed this program. That's the conclusion that the president himself has come to. I think that's what's also consistent with our Constitutional values.

### Moderator
Claim: So you're saying it's never going to be a matter of degree. It's an absolute.

### Conspiracy Advocate (CA)
Claim: I think when you're talking about bulk collection, yes.

### Moderator
Claim: Let me go to the other side, just see if they have a response to that. You've already, to some degree, answered that. But John Yoo, if you want to take it on.

### Scientific Advocate (SA)
Claim: Yeah. I mean, I think that that shows how unreasonable the other side's position is that that no matter how much the security threat goes, they are unwilling to bend and allow certain kinds of searches.

I think that choice is actually allowed to us under the Fourth Amendment by saying "reasonable searches and seizures." I was there on 9/11. And we were confronted by an enemy that snuck into the country, communicated by email and phone calls. How did we even find them? How did we even know they were all hijackers together? We looked at exactly this kind of data to piece it together. Of course, this is going to be the way we would need to catch such people in the future. Look at what our great terrorist enemies now-- I'm really worried, actually. I think the threat is much greater now than it was earlier because we have an enemy, ISIS, that controls a lot of territory, population, sophisticated weapons and is beheading Americans abroad, and we are doing very little about it. I think we need to have such kinds of programs in effect to stop them from getting over here.

### Moderator
Claim: Okay. The more you're using your 9/11 credential, the more I'm thinking I have to unleash Alex's critique from before. Elizabeth Wydra.

### Conspiracy Advocate (CA)
Claim: Yeah, I just wanted to say, you know, especially when you bring up a lot of these very frightening scenarios, I think it's important to remember that, as Alex pointed out earlier, these bipartisan commissions that have access to the classified data have not found that this bulk data collection has led to the prevention of an imminent attack. You know, I think I might take a slightly softer position than Alex on this in the sense that the Fourth Amendment doctrine does allow for exigent circumstances, exceptions to a warrant requirement, and that's-- but that's very, very narrowly circumscribed.

### Moderator
Claim: So, you don't think we're in that-- you don't think we're in that now.

### Conspiracy Advocate (CA)
Claim: I don't think we're in that now, and I don't think that bipartisan commissions that have access to classified information think that we're in that position now.

### Moderator
Claim: I think that's another-- unless you want to respond-- Stewart, go ahead.

### Scientific Advocate (SA)
Claim: Let me just take this briefly. The last 10 years, this program has not produced an enormous number of successes. It is designed for an attack from a safe haven that is carefully planned. We've had 10 years in which we've wiped out the safe havens.

We've put boots on the ground in Afghanistan to make sure that al-Qaeda could not plan attacks there. Only now is there a new safe haven where we can't put boots on the ground. We are in a different world. And the idea that this program might not have been particularly effective in a time when there was no safe haven does not tell us what it will be like in the future.

### Moderator
Claim: Okay. I want to remind you we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, arguing it out over this motion, “Mass collection of U.S. phone records violates the Fourth Amendment.” And we're taking audience questions. Sir.

### Moderator
Claim: Hello, my name's Rusty Bearcloth One of the premises of-- I'm sorry, this is for the against side-- one of the premises of your argument is due to the fact that there's a third party involved, due to the fact that you released this information to the telephone carriers, themselves, therefore, it's not a violation of privacy.

Is there a subject matter which you would disagree with that idea-- for example, bank records or medical records, you have to submit those to your insurance-- do you believe the federal government should be able to amass every transaction I do digitally with a credit card on any account because I go through a merchant?

### Scientific Advocate (SA)
Claim: So, let me try that.

### Moderator
Claim: Stewart Baker.

### Scientific Advocate (SA)
Claim: Briefly, no, I don't believe that the government should be able to access willy-nilly all those records. And I support legislation that Congress has passed that by and large already addresses financial privacy, already addresses the privacy of your email, already addresses the privacy of your medical records. Congress has stepped into this area, and we want them there, that it is too hard to let the Supreme Court every 35 years--

### Moderator
Claim: Steward, I think what the relevance of the question is would those things be a violation of the Fourth Amendment?

### Scientific Advocate (SA)
Claim: No, I think it's a bad idea to bring the court in and let this stuff be decided--

### Moderator
Claim: But they would not violate the Fourth Amendment?

### Scientific Advocate (SA)
Claim: They would not.

### Moderator
Claim: Okay. Do you guys want to take a crack at that or we can move on?

### Moderator
Claim: Move on.

### Moderator
Claim: Let's move on. Any women want to ask questions? Thank you. Then I'll come back to my gender.

### Moderator
Claim: My name's Sally, and my question is for the against group, what would you say to the statement that what you propose is actually destroying our country in the way that our enemies would approve of, and that--

### Moderator
Claim: I'm going to pass on that question because it's more of a policy and sentiment question - -

### Moderator
Claim: Okay.

### Moderator
Claim: --and not about the constitutionality, unless you want to try to rephrase.

### Moderator
Claim: How would you-- would this actually-- it's actually attacking our constitution to reverse our rights as in the Fourth Amendment, that--

### Moderator
Claim: I'm going to pass again with respect--

### Moderator
Claim: Okay. I can’t rephrase it.

### Moderator
Claim: --because I think they kind of-- I think they've addressed that they solidly think it's constitutional. Sir, right down front. Oh, you need the mike to come to you and to stand up. It's going to come from your right side. Thanks.

### Moderator
Claim: This is addressed to the against panel. Held as the use of burner phones, affect your reasonableness argument?

### Moderator
Claim: What kind of phones?

### Moderator
Claim: Burner-- phones you buy at Walmart and aren't traceable.

### Moderator
Claim: The phones are called "burner phones"?

### Moderator
Claim: Yeah.

### Moderator
Claim: I feel very street savvy now. Yeah, I'm going to get some burner phones right after the debate here. All right, thank you.

### Scientific Advocate (SA)
Claim: on the wire in the streets of Philadelphia, you know it's called "burner phones," of course.

### Moderator
Claim: Yeah, get some in Philly. John Yoo.

### Scientific Advocate (SA)
Claim: You elitist New Yorker, you.

### Scientific Advocate (SA)
Claim: Let me try this.

### Moderator
Claim: Stewart Baker.

### Scientific Advocate (SA)
Claim: Burner phones make it much easier for you to make one phone call and throw the phone away, buy another phone, make one phone call. It makes it much harder to find people, and it's certainly impossible to say, "I have a wiretap order on this person," and to be able to get all of their calls. But what you can do, again, you can use the pattern of their calls to identify people as suspect.

If you use a burner phone to call a safe house in Yemen, the government ought to be able to find out about that call and then to look at the pattern of calls--

### Moderator
Claim: Okay, I'm going to stop you because the question really was a huge softball to your side because--

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: --yeah, but I wanted to let the other side take a crack at that question because you are being presented again and again with situations where the defense of the nation-- the cases increasingly amaze that the defense of the nation would be enhanced it is argued by the ability to do these searches or seizures, and that, therefore, that affects the reasonableness issue. Do you-- let's hear from Alex on this one.

### Conspiracy Advocate (CA)
Claim: Yeah, I think, again, one of the easiest responses is simply that this issue has been analyzed by two bipartisan groups of individuals who concluded that we can engage in targeted collection of information to solve these problems. You know, one of the repeated hypotheticals has come from Stewart about the Safe House in Yemen. And in that particular example, which was the pre-9/11 one that NSA supporters have used as the best example for why they need this program.

Both-- or maybe it was just one of the commissions. But one of the commissions very carefully studied that particular example. And they decided that it would have been very easy for the government to have used targeted surveillance requests to uncover the link between the Safe House in Yemen and the parties on the U.S. end because they had the phone number of the Safe House. Indeed, they had to have the phone number because that's the only way they knew about the Safe House. And they could have taken that phone number and gone to the three major telecoms in the United States and served them with this order. And they would have very quickly uncovered the existence of the Safe House. That's what the commission concluded. And I think the same is likely true for burner phones.

### Moderator
Claim: I want to bring the question-- oh, sorry. Go ahead, John Yoo.

### Scientific Advocate (SA)
Claim: Do you think we so distrust ourselves that we need justices and Supreme Court Justices five to know what a burner phone is and then to figure out the right rule? You know, I mean, the Justices of the Supreme Court, they probably think a burner phone is something that's too hot to touch for a little while. You got to let it cool down. They have no idea what burner phone--

### Moderator
Claim: Well, like the moderator, they could just ask the question and find out the answer very quickly.

### Scientific Advocate (SA)
Claim: Do we so distrust that we can't make that decision through legislation to figure out the best way to-- the worst thing would be if the judges set a rule down in concrete, and then set our response in a way that we can't take account of evolving technologies. I think it's much better for a legislature, Executive Branch to study the problem, figure out the best responses as we go along, as new technology develops.

### Moderator
Claim: Elizabeth Wydra.

### Conspiracy Advocate (CA)
Claim: Yeah. You know, we have already made this decision. We the people ratify the Fourth Amendment. And so, I think that to make it seem like that's still in play just disregards the Constitution. But I, you know, I want to make a point about law enforcement. And, you know, the Fourth Amendment does not yield to concerns of efficiency. The Supreme Court very clearly stated this just at the end of its last term when it said that, “If the police want to search a Smartphone when it's arresting someone, that would be a great way to find really good evidence.” And, in fact, they did in those cases.

They have, you know, pictures of this guy with guns in front of a car that used in a shooting. But the court said that privacy comes at a cost. And when that cost is efficiency, that must yield to the concerns of the Fourth Amendment. So, you know, these Justices understand technology. They have clerks. And they have said that digital is different when it comes to the Fourth Amendment, and that the Fourth Amendment doesn't just yield to make things easier for law enforcement in all circumstances.

### Moderator
Claim: I wanted to take note of something about how both teams have responded to actions of our predecessors. And Alex Abdo, you were saying we shouldn't be bound by Smith V. Maryland. It's 1979. Technology has changed. John Yoo, you were saying we shouldn't be bound by what we think we're trying to imagine what the framer's thought that-- and to some degree, both of you are saying, “Let's not worry too much about the past,” I think. But in the sort of fundamental, romantic sense, I think a lot of people will find appeal to what Elizabeth Wydra was saying initially, that the colonists went to war to stop this kind of invasive search that the British government was doing at the time.

Well, what is-- you didn't actually make a direct response to that, somewhat sentimentally, a powerful notion--

### Scientific Advocate (SA)
Claim: No, I mean, we wouldn't be here at something called the National Constitution Center if we didn't have a romantic vision of the Constitution and the Revolution and our framing. And I'm someone who loves to look at the evidence from the framing in my own written work, which is on sale at a very low price on amazon.com. All you have to do is, apparently, look at your phone now and you'll buy-- you can buy my book. But the point is, is that this is exactly the same argument that are confronted by our courts all the time, too, and our government leaders. This claim, “You're going to overthrow the Constitution. You're making our-- enemies would agree what we're doing to our own country.” But when they're faced with these claims, they have never said, “Oh, there's a blanket rule that we know from the framers in the search and seizure context we have to impose.” You would think that they would from their description-- the opponents' description of the Constitution. Think about all the places where the court has not done that. The metal detectors at airports.

### Moderator
Claim: Then why not also update your view of Smith V. Maryland as your opponent--

### Scientific Advocate (SA)
Claim: They could, but that's-- but they haven't done it yet. And now lower court has yet. Instead, in all-- there's lots of other contexts where the court has adopted this balancing approach. I was going to say, metal detectors at airports. Aren't those searches? Drunk driver checkpoints, aren't those searches? Urinalysis drug testing for employers. I mean, there's lots of contexts, actually, where our government has been allowed to conduct broad, non-particularized searches that are considered fairly minimal in order to stop a great threat to public safety. If our justices don't--

### Moderator
Claim: Let me just I want to take one more question. I just want to let Alex Abdo respond to that and take one more question.

### Conspiracy Advocate (CA)
Claim: I think it's wrong to say that our courts are not grappling the question of whether Smith V. Maryland remains relevant today. Not too long ago, a Court of Appeals said that our email is protected by the Constitution, even though we have to share it with Gmail. That's a very common-sense conclusion, but it's one that our opponents would apparently resolve by saying email is not protected because it's stored on the servers of a third party.

And more recently, the Supreme Court has said, five justices have said, in various opinions, that Smith vs. Maryland may not make sense in the digital era. And it's quite obvious why, because if that were the law of the land, then virtually everything we do today, which is reduced to a digital trail, would be susceptible to bulk collection by the government.

### Moderator
Claim: One last question? Sir, right in the middle there. And wait for the mic, please. Thanks.

### Moderator
Claim: Yeah, hi. My name is Aaron. I think both sides gave very different definition to what the world "reasonable" means. I think the for side is talking about reasonableness as opposed to the public and the against side is talking about reasonableness for the government. So, I was hoping both sides can explain why they take their interpretation of what "reasonable" applies to.

### Moderator
Claim: Do you all agree that you disagree-- that one of you is talking about-- you're talking about reasonableness in two different contexts, or would you say your "reasonableness" is to both parties, both sides, both to the government and to the public?

Let me-- let me go to--

### Scientific Advocate (SA)
Claim: I think we're stressing different sides of the ledger when the government--

### Moderator
Claim: John Yoo.

### Scientific Advocate (SA)
Claim: When the court has taken these questions, what's reasonableness mean, they actually say, we weigh the interest of the government versus privacy interests of the individual. And then all I'm saying is I think we as a society should look at all of that and balance it ourselves. My personal, I think Stewart's personal, and I think the views of the Congress and the president and many judges has been, in this context in war, the national security interests, which is the most important government interest there is it-- the courts have said that, and the framers said that many times-- just outweigh the intrusion of-- I'm not denying there's an intrusion of privacy. But the-- you know, outweigh the intrusion of privacy in collecting phone numbers-- phone numbers, not the calls. Email addressing, not the content of emails.

### Moderator
Claim: A balancing act is what you're saying.

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: And let's go to Alex Abdo on that.

### Conspiracy Advocate (CA)
Claim: I would just amend Professor Yoo's response on the legal question in just one way.

The Supreme Court has said that "reasonableness" means-- is in general a balance, except when the government can accomplish its interests in a targeted way. And in that context, the Supreme Court has always said that the government must proceed with a warrant based upon probable cause. If the government can accomplish its interests in that targeted way, it must. And that's not perhaps surprising. That's been our Constitutional tradition since-- since the late 1700s, and it should continue to do so today.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate where our motion is Mass Collection of U.S. Phone Records Violates the Fourth Amendment.

## Round 3

### Moderator
Claim: And here's where we are. Remember how you voted just before you started hearing the arguments because immediately after these brief closing statements, we're going to have you vote a second time. And I'll remind you that it's the team whose numbers have changed the most in percentage point terms will be declared our winner. First, onto round three, closing statements from each debater in turn. They will be brief, two minutes each. First, to argue-- first to summarize her position in favor of the motion, Mass Collection of U.S. Phone Records Violates the Fourth Amendment, Elizabeth Wydra, Chief Counsel at the Constitutional Accountability Center.

### Conspiracy Advocate (CA)
Claim: Thank you so much, John. So I think it's important to think about what we haven't heard tonight. We haven't heard any solid case for why the government needs to engage in this mass collection of Americans' phone records, going on every day. As Alex said, if you make a call tonight, the NSA will know about it and have it recorded tomorrow. They haven't shown that there is the need to engage in this dragnet surveillance that offends the principles of the Constitution, to thwart an imminent attack. And while we have talked a lot about some of these very disturbing scenarios of terrorist activity, I think that getting back to one of the questions earlier, it is in these times of crisis, it is in those times, as well as in the easy times, that our principles and our devotion to our founding principles are tested.

And we the people have already determined that the question of whether or not the people shall be subject to unreasonable searches and seizures is not up for debate. It is something that is enforceable in our courts, and it's something that we the people have decided upon many, many years ago. And in closing, I just want to get to this very odd idea which we didn't explore any more, about somehow that it's okay that the government just collects the information and it's not really problematic for the Constitution if they don't actually look at it. Well, I want you to think about this before you vote again. You know, if the government stationed a person to stand next to your bathtub every time you took a bath, do you think your privacy isn't invaded if the government agent stands there with his hands over his eyes the whole time? I'm going to think that you're going to think things have gotten a lot less private up in there before he looks when you're taking your bath.

So, I think we need to think about the collection of this information is just as bad as if they actually looked at the content and not just the fact that they take this information in the first place reveals a lot of data and personal information about us in general.

### Moderator
Claim: Thanks, Elizabeth, Wydra. Your time is up. Thank you very much.

Our motion is Mass Collection of U.S. Phone Records Violates the Fourth Amendment. Here to summarize his position against this position, Stewart Baker, a partner at Steptoe and Johnson and former general counsel at the NSA.

### Scientific Advocate (SA)
Claim: So, I think to vote for this motion, you have to want to change the law to create more privacy than current law creates. And let me explain why I give these speeches and appear here. It's because I spent the 1990s advocating for a privacy and civil liberties doctrine that would separate intelligence and law enforcement, because I thought that it was important that intelligence capabilities not be used if at all possible against ordinary American criminal suspects.

I thought it sounded like a good civil liberties doctrine, and we ought to change the rules so that that was the case. We created a wall. We built that wall higher and higher until in August of 2001 when we found out from intelligence source that's there were al- Qaeda operatives in the United States. And the FBI law enforcement task force that had all the resources and all the people they were investigating the Cole bombing, said, "We just heard about this. We can find these guys. They're in the United States. We'll get them. Let us at them." And they were told to sit down and shut up because this came from the intelligence side of the government, and they weren't allowed to do anything with it. They never did-- we never did find those guys because the intelligence agencies had very few capabilities inside the United States until they flew into the World Trade Center. I never want to live with myself again for saying, "Well, it sounds like a little more privacy. What the heck. Let's change the rules. How bad could it be?"It could be very bad. This is not a good law to change at this time.

### Moderator
Claim: Thank you, Stewart Baker.

Our motion is Mass Collection of U.S. Phone Records Violates the Fourth Amendment, and here to summarize his position supporting this motion, Alex Abdo, a staff attorney at the ACLU's Speech, Privacy and Technology Project.

### Conspiracy Advocate (CA)
Claim: Thanks, John. I want to take a slightly different tack. So, in 1981, it cost around $300,000 to store a gigabyte of data. By 2010, just a couple years ago, that cost had plummeted to about 10 cents. And by next year, some people estimate it'll be about 2 cents to store a gigabyte of data. And just to give you a sense of what that means for surveillance, it means that you could store the entire audio from every single phone call that a single person has made over the course of an entire year for about 10 cents. And by next year, it'll be about 2 cents.

That result of that plummeting cost of storage is that for the first time in our nation's history, truly pervasive surveillance is possible. It'll be possible for the government to store not just-- not-- to keep track of not just who you email, who you call and what websites you visit. They'll be able to make a copy of every email you send, to record every phone call you make, to archive every website that you visit. And the cost has fallen so much and so dramatically that it will soon even be possible for the government to record virtually every step you take once you leave the house. This is not science fiction. This is a predictable result of falling storage and the proliferation of these types of surveillance devices on military fields now coming home to return to us to local law enforcement. I think that's why this debate, tonight's debate on mass collection of phone records, is about so much more than phone records and so much more than the NSA. If our opponents are correct, it won't end with the NSA. It won't end with the FBI, and it won't end with even local law enforcement. Mass collection will be the norm.

So, the choice you have is whether you want to live in a free society or one in which our every movement and our every communication is tracked, recorded and stored in a database. In the past, cost was the main protection we had against that sort of world. But cost is no longer an issue. The Fourth Amendment is all we have left. And that's why I think you should vote for the motion that mass collection violates the Fourth Amendment.

### Moderator
Claim: Thanks, Alex Abdo.

And that is the motion: Mass Collection of U.S. Phone Records Violates the Fourth Amendment. And here to summarize his position against this position, John Yoo, professor of law at UC Berkeley and former Justice Department lawyer.

### Scientific Advocate (SA)
Claim: Well, it's been a great pleasure to participate in this debate and try to urge you one way or the other. And, you know, we're sitting in Philadelphia. Again, I'd like to emphasize, my hometown.

And we're at the site of the drafting of the constitution in the little room across the way. And this is not a perfect document. It wasn't a document that bent to one overall principle or another. One thing you get very much a sense of if you go visit that little room or you read accounts of the Constitution that it was the product of compromises made by practical people who wanted to create a workable government. That's why we have with the Senate melded with popular representation in the House. And so our Constitution does two things. It does protect rights and the right to be from unreasonable searches and seizures. But as many justices, particularly Justice Jackson, remind us, the Constitution is also not a suicide pact. It is not a document that's designed to place individual rights above the ability of our society to defend itself from foreign attack. And so that's how we are supposed to look at these kinds of questions by the text of the Fourth Amendment and by decades and decades of Supreme Court opinions, going back many, many years. What is a reasonable thing for us as a society to do? Is it reasonable to try to find al-Qaeda terrorists using these kinds of technologies or do we think that they so outweigh our rights to privacy that judges should stop them?

I would say actually that this is a decision where our side is arguing for a little bit of modesty and humility, that we don't have the right answer. We cannot predict the way technology will run. We can't predict everything al-Qaeda's going to do, our enemy's going to do. We think that the best way to make this decision is to have an evolving standard based on what legislatures and executive branch do, not to rely on a few judges. As I keep saying, what kind of society do we want to live in? I think that's for us to decide through elections, through our own choices and not because a few judges on the Supreme Court tell us what kind of society to live in. So thank you very much, and vote for us.

### Moderator
Claim: Thank you, John Yoo. And that concludes our closing statements. And now it's time to learn which side has argued the best. We're going to ask you right now to go to the keypad at your seat that will register your vote after hearing the arguments. Push one if you agree with the motion, “Mass collection of U.S. phone records violates the Fourth Amendment.”Push number two if you disagree with this motion. Push number three if you remain or became undecided in the course of the debate. And we will have the readout in about a minute and a half. And while we're doing that, the first thing I want to say is it's the goal of Intelligence Squared to show that tough discourse can be had in a civil way. And I really think these four debaters were great at that. And I want to congratulate all of them for what they did. And I also want to ask-- I want to-- also want to thank everybody who got up and asked a question, including the question that I didn't take. It's not that it at all was a bad question, and we've done a couple of debates where it would have been a magical question, so you're going to have to come up to New York the next time we revisit the NSA issue, because it would be great. But to everybody who got up and asked a question, it really did move along the debate for us, so thank you for that and congratulations. We want to thank Jeffrey Rosen, of course, of the National Constitution Center for inviting us here today.

And we hope that this remains a continuing series. This is our third time here, and each time the debate has just been sparkling. And this program, I want to point out, was supported by Daniel Berger, Esq. Programming Fund for the National Constitution Center. Our gratitude to them and a round of applause, please, thanks. We would love it if you would Tweet about this debate. The baby boomers will have all of that explained to them, how that works, and the burn phones, and all--

### Moderator
Claim: I've already Tweeted this

### Moderator
Claim: Oh, okay. Our Twitter handle is @iq2us and @constitution, C-T-R for Center, constitutionctr. The hashtag is 4thamendment. We will be partnering with the NCC and the Richman Center at Columbia University next spring, debating the president's constitutional war powers. But until then our next regularly scheduled debate will be at the Kaufman Center in New York. That's on Wednesday, October 22. Our motion there is, "Income inequality impairs the American dream of upward mobility."So, it's a 90-minute train ride. We hope we'll see some of you. We will have an economist and one presenter on each side of that debate. For the motion, Elise Gould, she's a senior economist at the Economic Policy Institute. And her partner is Nick Hanauer. He's an entrepreneur and a venture capitalist. Against them, Edward Conard. He's a former partner at Bain Capital. And his partner is Scott Winship, who is a fellow at the Manhattan Institute. You can get tickets for all of our debates at our website, iq2us.org. And we've recently launched a quite elegant little iPhone and Android app for Intelligence Squared. It will let you see what our debates are coming up. It will let you vote on our debates. It will let you hear all of the nearly 100 debates that we've put on since 2006. And you can watch the live stream of debates you can't get to on our website, iq2us.org or listen to the debates on NPR stations across the country. Okay. Oh, one thing I need to ask you, because last time-- and I don't know, John Yoo, if it's a Philadelphia thing.

But some people walked out with our keypads. So –

### Scientific Advocate (SA)
Claim: I think they're for sale right outside.

### Moderator
Claim: So, then they were on eBay. We just want to ask: make sure that you leave those at your seat there. They're not take-homes. Okay. Okay, so, it's all in. I have the final results now. Remember, you have voted twice: once before the debate, and again after hearing the argument. And the team whose numbers have moved the most in percentage point terms will be declared our winner. So, let's look at the first vote on the motion, “Mass collection of U.S. phone records violates the Fourth Amendment.” Before the debate 46 percent agreed with the motion; 17 percent were against the motion; 37 percent were undecided. So, those are the first results. You need to move the numbers most, by percentage point terms, to win this debate. Let's look at the second vote. The team arguing for the motion, their second vote was 66 percent. They went from 46 to 66 percent, picking up 20 percentage points. That's the number to beat. The team arguing against the motion, their first vote was 17 percent; second, 28 percent.

They pulled up 11 percentage point, but it's not enough. The debate won by the team arguing for the motion, “Mass collection of U.S. phone records violates the Fourth Amendment.” Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared. We'll see you next time.
