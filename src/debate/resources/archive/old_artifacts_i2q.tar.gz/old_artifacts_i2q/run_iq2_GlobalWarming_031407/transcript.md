# Debate Transcript

Topic: Global Warming is Not a Crisis
Motion: Global Warming is Not a Crisis

Debate ID: GlobalWarming-031407


## Round 1

### Moderator
Claim: Global warming is not a crisis

### Moderator
Claim: . I want to introduce to you, Robert Rosenkranz, Chairman of the Rosenkranz Foundation, the sponsor of this evening’s debate, who will make some opening remarks.

### Moderator
Claim: Thank you, Brian, and, and welcome to all of you. I’m Robert Rosenkranz, Chairman of Intelligence Squared, which is an initiative of the Rosenkranz Foundation. With me tonight is Dana Wolfe, the Executive Producer of this, series of debates. I see a number of, uh, a lot of familiar faces in the audience but also a lot of newcomers. So let me just say a word about why we’re, we’re doing this. It’s really with the intention of raising the level of public discourse in this country. It comes from a feeling that, uh, political conversations are just too rancorous and that, this nation could benefit from a forum for reasoned discussion of, key policy issues. The topic tonight is, is one that, uh, has attracted an enormous amount of, of interest. The proposition: Global warming is not a crisis. And the, panelists are going to try to persuade you to vote for or against the motion. Uh, ultimately your votes will decide which side has carried the day. Uh, well, why this particular, topic? Senator Barbara Boxer, Al Gore have assured us that on this particular topic the debate is over. Well, we took that as throwing down the gauntlet and I personally am cynical enough to think that perhaps there’s a distinction between science and political science. Um, and maybe a side that feels like there is nothing to debate, might feel that there are perhaps some inconvenient truths on the other side that they would prefer not to deal with. I’m old enough to remember when there was a, uh, scientific consensus on global cooling, and this was in the 1970s with all kinds of alarmist data on that subject. I’m enough of a businessman to know that the modeling and the use of the computer, uh, algorithms and forecasting the future is a very, very difficult undertaking. I mean, if one could predict, uh, the weather or patterns of storms even a year in advance it would be worth billions and billions of dollars to people engaged in energy trading or, uh, or, insurance underwriting and a whole bunch of other pursuits. And yet it can’t really be effectively done. So tonight’s debate, I think, is addressing issues that for me are very real and, which, at Intelligence Squared we feel can use some serious enlightenment. Uh, first of all, on the science of it. Does science really have the, the ability to tell us with, with a good degree of reliability what is going to happen to our climate over a hundred year period? And secondly, the economics. Um, this all leads in effect to public policies that say, We should invest, money now for benefits in the future. Well, that always poses the traditional questions of, well, what are the costs? What are the benefits? What are the alternatives? What are the risks of action? What are the risks of inaction? So there are a whole welter of economic aspects that I think, hopefully tonight we’re going to get some enlightenment on as well. Uh, this evening, of course, is a live event but it will reach an audience through National Public Radio of over fifty radio stations around the country. We’re produced for radio by by WNYC in New York. And it’s now time for me to turn the, uh, proceedings over to Brian Lehrer, who is the award winning host of, WNYC’s New York public radio call in program, The Brian Lehrer Show. This has been called New York City’s most thoughtful and informative talk show by Time magazine. It covers politics and life locally, globally. Brian not only holds a master’s degree in journalism but also a master’s in public health and environmental studies. So he is very well equipped to lead these proceedings and to introduce the extraordinary group of panelists who are the real stars of tonight’s event. Thank you very much.

### Moderator
Claim: And, Bob, thank you so much. I so personally appreciate your commitment to public discourse at a high level. We need much more of that in this country. I would like to welcome you all formally to the sixth Intelligence Squared U.S. debate. Let me give you a brief run-down of the evening. First, the proposer of the motion will start by presenting their side of the argument. The opposition will follow. Each person will get a maximum of eight minutes and we will go back and forth from one side to the other. Second, when all six speakers are finished with their opening remarks I will do some follow-up questioning and open up the floor to brief questions from the audience. And when I say brief, I do mean brief. We have, we are limited to twenty minutes for the entire follow-up discussion after the eight minute presentations. And so I ask that you limit your questions to thirty seconds and not give any speeches tonight and I will do the same in my follow-up questions. Uh, third, when the Q and A is complete, each debater will make a final statement, not lasting more than two minutes per person. And fourth, during the closing statements, uh, ballot boxes will be passed around for voting. You have your tickets. This is what the ballot box looks like and you will put in either the “for” piece, the “against” piece or the whole ticket if you still don’t know which side you favor. If anyone does not have a ticket ballot – are you snickering at the very idea of being undecided or ambivalent? This is what we’ve come to? Um, an usher will get you a ballot at the appropriate moment if you still need one. And fifth, and last, after the final closing statement is made I will announce the results of the audience vote and tell you which side carried the day. Now, to introduce the panel. For the motion, author and filmmaker, best known as the author of Jurassic Park and the creator of E.R., Michael Crichton. The Alfred P. Sloan Professor of Meteorology in the Department of Earth, Atmosphere and Planetary Sciences at MIT, Richard S. Lindzen. And Emeritus Professor of Biogeography at the University of London, School of Oriental and African Studies, Philip Stott. Against the motion: Climate Scientist at the Union of Concerned Scientists, Brenda Ekwurzel. Climate Modeler at the NASA Goddard Institute for Space Studies, Gavin Schmidt. And distinguished Professor of, uh – I’m sorry. And distinguished Professor at Scripps Institution of Oceanography, University of California, San Diego – Richard C.J. Somerville. And that was all very polite. I couldn’t tell how many people voted for or against the motion. All right, first, for the motion: Richard Lindzen. Please go to the microphone.

### Conspiracy Advocate (CA)
Claim: Okay, I’d like to thank Intelligence Squared, the staff, Bob Rosenkranz, Brian Lehrer and of course, our worthy opponents, for the opportunity to debate the proposition: Global warming is not a crisis. Please keep in mind what the proposition is. It is not a debate over whether the earth has been warming over the past century. Uh, the earth is always warming or cooling, at least a few tenths of a degree. And we’re talking about, so far, something on the order of six tenths of a degree centigrade. We’re not even arguing about whether greenhouse gas emissions are contributing at some level to warming. And they most certainly should or I would suggest it would be very little. Indeed, as far as I can tell, even our opponents do not claim that global warming is a crisis at present. Rather, we are primarily addressing the future. Now, much of the current alarm, I would suggest, is based on ignorance of what is normal for weather and climate. Extreme weather events occur all the time. There’s, there is really no evidence of systematic increases, judging from reports from bodies ranging from the National Hurricane Center to the U.N.’s Inter-Governmental Panel on Climate Change. In fact, outside the tropics the theory of such storms and variability says that the variability should decrease in a warmer world. Thus, if this is a matter of crisis for where we live the world is in a permanent state of crisis and will be less prone to crisis in a warmer world. Sea level has also been a matter of concern, I think largely because it’s very telegenic, as opposed to a half degree of temperature. And sea level has been increasing since the end of the last Ice Age glaciation, with the most rapid change increase about twelve thousand years ago. In recent centuries the rate has been relatively uniform, averaged over ten year periods. Uh, it amounts to a couple of millimeters per year and this is residual of much larger positive and negative changes locally. Uh, those changes are due to tectonics. And, and the risk, if you’re worried about sea level change, from these changes is larger than it is from warming. The impact of warming on agriculture is not easy to ascertain. But, for example, India has warmed in the second half of the twentieth century and agricultural output has increased greatly. The impact on disease seems dubious at best, according to articles in Lancet. Infectious diseases like malaria are not so much a matter of temperature as of poverty and public health, most notably the elimination of DDT. Malaria is still endemic in Siberia and was once so in Michigan. Exposure, I would suggest, to cold is generally found to be both more dangerous and less comfortable. Now, recently the IPCC summary for policy maker came out and it had an iconic claim about man’s impact on temperature change. Uh, does this imply crisis? Well, the impact on temperature per unit carbon dioxide actually goes down, not up, with increasing CO2. Uh, the role of anthropogenic greenhouse gases is not directly related to the emissions rate or even CO2 levels, which is what the legislation is hitting on, but rather to the impact of these gases on the greenhouse effect. Uh, modelers use double CO2 as a convenient benchmark and on the basis of current models, it’s claimed that this should lead to about one and a half to four and a half degrees warming. What is less often noted is in terms of greenhouse forcing we’re already three quarters of the way to that doubling. And we’ve only seen point six degrees. And there’s no reason to suppose, furthermore, that this is all due to man. Now, this certainly does not support the model forecasts upon which alarm is based. Modelers commonly claim it’s still possible that aerosols have canceled much of the greenhouse warming. Unfortunately, the impact of aerosols is considered by the IPCC to be virtually unknown. And indeed, many people consider that canceling the warming involves a larger effect than seems plausible. There have also been claims that warming has been delayed by the ocean. But the results I’ve mentioned are from coupled models involving the atmosphere in the ocean. And in many of these the oceans have been tuned to have particularly long delays. And I think it’s crucial to distinguish between the claim that models can display past behavior from the actual situation, which is that models can be adjusted to display past behavior once that behavior is known. There is no reason to suppose that the adjustment corrected the relevant error. It is worth adding that warming, instead of accelerating, has been essentially absent for about the last ten years. So the iconic statement is itself not indicative of crisis. And one could, if one had time, explain why the iconic statement itself may very well not be true. The major defense of the statement is modelers cannot think of anything else that gave warming over the last thirty years. But these are the same models that cannot account for the Medieval warm period, or for that matter, even do a good job of replicating El Nino. So even the basis for the iconic statement is not particularly meaningful. So crisis is not a product of current observations.

I suggest it’s not even a product of projections. Now, there is no reason to suppose that anything will cause a threshold to change this assessment. We’re still talking about a two per cent imbalance and we’re also talking about the impact of CO2 per unit CO2 that decreases. This is not the usual condition for a threshold. Moreover, there are positive reasons to suspect that greenhouse warming is not significant. The real signature of greenhouse warming is not surface temperature but temperature in the middle of the troposphere, about five kilometers. And that is going up even slower than the temperature at the surface. Finally, the underlying present concern is not the greenhouse effect, per se. Doubling CO2 by itself only gives you one degree warming. The--

Okay.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: I suggest it’s not even a product of projections. Now, there is no reason to suppose that anything will cause a threshold to change this assessment. We’re still talking about a two per cent imbalance and we’re also talking about the impact of CO2 per unit CO2 that decreases. This is not the usual condition for a threshold. Moreover, there are positive reasons to suspect that greenhouse warming is not significant. The real signature of greenhouse warming is not surface temperature but temperature in the middle of the troposphere, about five kilometers. And that is going up even slower than the temperature at the surface. Finally, the underlying present concern is not the greenhouse effect, per se. Doubling CO2 by itself only gives you one degree warming. The--

### Moderator
Claim: Richard Lindzen, thank you very much for your opening statement.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: I do have to cut you off there. By the way, audience, you may feel free to, to applaud. Uh, you can give polite applause, you can give enthusiastic applause. Uh, that is your right. Of course, we ask that nobody shout anything out. Richard Somerville, the next statement is yours.

### Scientific Advocate (SA)
Claim: The motion before us, global warming is not a crisis, means we ought to know what crisis means. The word does not mean catastrophe or alarmism. It means a crucial or decisive moment, a turning point, a state of affairs in which a decisive change for better or worse is imminent. We are talking about the future here. The entire world now really does have a critical choice to make. It is whether to continue on the present path of adding more and more carbon dioxide and other greenhouse gases to the atmosphere or whether to find another path. We’re speaking of the future. And science tells us that the path we choose will largely determine what kind of earth our children and grandchildren will inherit. Our task tonight is to persuade you that global warming is indeed a crisis in exactly that precise sense so you should vote against the motion. The science community today has impeccable settled science, despite what you have just heard, that demonstrates the reality of global warming and its primary origin in human activities. We fully understand the fundamental physics behind the greenhouse effect. We also now have persuasive observational evidence of dramatic changes already taking place in the climate system, changes that are not in any sense small. Mankind’s fingerprints have now clearly emerged above the noise of natural variability. That is the primary message of the intergovernmental panel, climate panel, the panel on climate change report that Professor Lindzen referred to – the IPCC. We also have powerful tools to prode…project many aspects of the future climate with considerable confidence. We take into account other important factors besides greenhouse gases – the sun, volcanoes, pollution particles. Some of our forecasts have already come true. A group of people dispute these consensus findings of mainstream scientists. Call them contrarians. Some are here in this very room. Contrarians are not unique to climate. They exist in many fields of science. There are a few retrovirus experts, fully credentialed, who don’t think that HIV causes AIDS. The New Yorker this week, many of you will have seen, writes about them. When the revolution of continental drift was sweeping through geology and geophysics, some imminent earth scientists couldn’t be persuaded that plate tectonics were real. Continents can move. These contrarians were mistaken. They faded from the scene. Experience, long experience shows that in science it tends to be the rare exception rather than the rule when a lone genius eventually prevails over conventional mainstream scientific thought. An occasional Galileo does come along or an Einstein. Not often. Most people who think they’re a Galileo are just wrong. We’re talking here about managing risk for the future. It’s a big risk to the planet to bet it on the contrarians. Here’s a brief look at some of what we know. The IPC said…C said, quote: Warming of the climate system is unequivocal, unquote-- based on many kinds of observations. Also our knowledge of ancient climates tells us that the warmth of the last half century is unusual in at least the previous three…thirteen hundred years. The IPC said…C said, Most of the observed increase in global av…globally averaged temperatures in recent decades is very likely due to the observed increase in human caused greenhouse gas concentrations. These are summary conclusions of, of experts. In a painstaking process, lasting, uh, years with thirty thousand reviewer comments, each log numbered responded to by teams of experts who represent, um, the mainstream science and who take into account views from the fringes as well. There’s never been as thorough and vetted a process for summarizing science precisely for the point of making input to policy makers. Nothing said here tonight in a few minutes that we have can possibly undermine, uh, this powerful statement from the scientific community. We also project a further warming of a half a degree Fahrenheit for the next twenty-five years. Beyond that it does depend largely on how much more CO2 and other greenhouse gases humanity dumps into the atmosphere. Global warming since the nineteenth century is already more than a degree Fahrenheit. It’s continuing. Of the twelve warmest years in the instrumental record, uh, eleven of them have occurred in the most recent twelve years globally. 2006 was the sixth warmest year in this record globally and the warmest year of all in the U.S. Arctic temperatures in the last hundred years increased twice as much as the global average. Since 1950 the number of heat waves globally has increased. The heat wave in Europe in 2003 that killed more than thirty thousand people was unprecedented in modern times. Intense tropical cyclone activity, the IPCC concludes, has increased in the North Atlantic region since about 1970. The global ocean, down to a depth of at least six thousand feet, has been warming since the early 1960s. This warming is contributing to sea level rise. It’s by no means all vestiges of the last Ice Age. Sea level rose some seven inches over the twentieth century. The rate of rise has apparently increased recently. Water vapor in the atmosphere, as predicted, is increasing as the world warms. This additional water feeds back. It’s a greenhouse gas. It amplifies the warming. It’s as though you had your house wired funny so that when it got warm the thermostat turned on the furnace and made it warmer still. Snow cover and mountain glaciers are decreasing markedly. It’s a long list. The list goes on. None of these observational facts is a surprise to the climate science community. They are what we had predicted. We scientists have been expecting measurements like these and now we see them. The question for the future is simply how much worse do we, do we intend? How much more severe, uh, will we let these trends become? The science warns us that continuing to fuel the world using present technology will bring dangerous and possibly surprising climate changes by the end of this century, if not sooner. Business as usual implies more heat waves, higher sea levels, disrupted rainfall patterns, vanishing glaciers and much more. Limiting carbon dioxide amounts to any reasonable level will take large cuts in emissions. It takes time. We have a giant intra… infrastructure based on fossil fuels. To have a meaningful effect by mid-century we need to start soon. The question is really whether humanity has the collective determination to act in any meaningful way. The economic case can be made convincingly, once people understand the cost of doing nothing or too little. It’s like elective surgery. It’s, uh, not free to decline it. Technology can accomplish great things once society is committed to such a goal. We know now that humanity has already increased atmospheric carbon dioxide by thirty-five per cent above natural levels. And humanity, as a group, by default or on purpose, will now decide what level it wants to tolerate. Then, after humanity has made this decision, how much CO2 do you want in your children and grandchildren’s atmosphere?, which –

…after that, nature will have its say and the climate system will change in response to the level of greenhouse gases in the atmosphere. Nature is superbly indifferent to politics and, and spin. But it will have the last word, uh, in this debate. I have a few seconds and I’ll say a few words about the IPCC. I’ve been a coordinating lead author in it, uh, for three years. I’ve, I was in Paris last month when this summary was negotiated and released. It’s an extraordinarily impressive international collaboration-- thirty thousand review comments, a hundred and fifty, uh, authors – seventy-five per cent of whom, by the way, were new to the process. We’re not a clique defending what we said six years ago. And I urge you to familiarize yourself with the science because the science here has spoken very plainly. Thank you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …after that, nature will have its say and the climate system will change in response to the level of greenhouse gases in the atmosphere. Nature is superbly indifferent to politics and, and spin. But it will have the last word, uh, in this debate. I have a few seconds and I’ll say a few words about the IPCC. I’ve been a coordinating lead author in it, uh, for three years. I’ve, I was in Paris last month when this summary was negotiated and released. It’s an extraordinarily impressive international collaboration-- thirty thousand review comments, a hundred and fifty, uh, authors – seventy-five per cent of whom, by the way, were new to the process. We’re not a clique defending what we said six years ago. And I urge you to familiarize yourself with the science because the science here has spoken very plainly. Thank you.

### Moderator
Claim: Thank you, Richard Somerville. Michael Crichton, you have the next statement.

### Conspiracy Advocate (CA)
Claim: The microphone goes up. Before I begin I want to just say one brief thing about what Richard has just told you. He’s, he’s giving you the story of plate tectonics but it’s fascinating. He’s turned it upside down. He’s turned it on its head. The story of plate tectonics actually is the story of one person who had the right idea – Alfred Wegener. He had it in 1912. And it is the story of major scientists at Harvard and elsewhere opposing him for decade after decade until finally it was proven to be incorrect what they were believing. So it is, in fact-- when I was a kid I was told the continents didn’t move. It is, in fact, perfectly possible for the consensus of scientists to be wrong and it is, in fact, perfectly possible for small numbers of people to be in opposition and they will be ultimately be proven true. I want to address the issue of crisis in a somewhat different way. Does it really matter if we have a crisis at all? I mean, haven’t we actually raised temperatures so much that we, as stewards of the planet, have to act? These are the questions that friends of mine ask as they are getting on board their private jets to fly to their second and third homes. And I would like, with their permission, to take the question just a little bit more seriously. I myself, uh, just a few years ago, held the kinds of views that I, uh, expect most of you in this room hold. That’s to say, I had a very conventional view about the environment. I thought it was going to hell. I thought human beings were responsible and I thought we had to do something about it. I hadn’t actually looked at any environmental issues in detail but I have that general view. And so in 2000, when I read an article that suggested that the evidence for global warming might not be quite as firm as people said, I immediately dismissed it. Not believe in global warming? That’s ridiculous. How could you have such an idea? Are you going to try and tell me that the planet isn’t getting warmer? I know it’s getting warmer. I grew up in Long Island. And when I was a kid we always had days off from school for hurricanes. There are no hurricanes on Long Island now. I spent thirty years in California. We used to have something called June gloom. Now it’s more like May, June, July, August gloom with September, October, November gloom added in. The weather is very different. However, because I look for trouble, um, I went at a certain point and started looking at the temperature records. And I was very surprised at what I found. The first thing that I discovered, which Dick has already told you, is that the increase in temperatures so far over the last hundred years, is on the order of six-tenths of a degree Celsius, about a degree Fahrenheit. I hadn’t really thought, when we talked about global warming, about how much global warming really was taking place. The second thing I discovered was that everything is a concern about the future and the future is defined by models. The models tell us that human beings are the cause of the warming, that human beings, uh, producing all this CO2, are what’s actually driving the climate warming that we’re seeing now. But I was interested to see that the models, as far as I could tell, were not really reliable. That is to say, that past estimates have proven incorrect. Uh, in 1988, when James Hanson talked to the Congress and said that global warming had finally arrived, The New York Times published a model result that suggested that in the next hundred years there would be twelve degrees Celsius increase. A few years later the increase was estimated to be six degrees, then four degrees. The most recent U.N. estimate is three degrees. Will it continue to go down? I expect so. And this left me in a kind of a funny position. But let me first be clear about exactly what I’m saying. Is the globe warming? Yes. Is the greenhouse effect real? Yes. Is carbon dioxide, a greenhouse gas, being increased by men? Yes. Would we expect this warming to have an effect? Yes. Do human beings in general effect the climate? Yes. But none of that answers the core question of whether or not carbon dioxide is the contemporary driver for the warming we’re seeing. And as far as I could tell scientists had, had postulated that but they hadn’t demonstrated it. So I’m kinda stranded here. I’ve got half a degree of warming, models that I don’t think are reliable. And what, how am I going to think about the future? I reasoned in this way: if we’re going to have one degree increase, maybe if, if, climate doesn’t change and if, uh, and if there’s no change in technology – but of course, if you don’t imagine there will be a change in technology in the next hundred years you’re a very unusual person. And I also was aware that we have actually been starting to do exactly the kind of thing that we ought to do, which is to decarbonize. Jesse Ausubel at Rockefeller University points out, for example, that starting about a hundred and fifty years ago, in the time of Abraham Lincoln and Queen Victoria, we began to move from wood to coal, from coal to oil, from oil to natural gas and so on. Decreasing our carbon, increasing our hydrogen makes perfect sense, makes environmental sense, makes political sense, makes geopolitical sense. And we’ll continue to do it without any legislation, without any, anything forcing us to do it, as nothing forced us to get off horses. Well, if this is the situation, I suddenly think about my friends, you know, getting on their private jets. And I think, well, you know, maybe they have the right idea. Maybe all that we have to do is mouth a few platitudes, show a good, you know, expression of concern on our faces, buy a Prius, drive it around for a while and give it to the maid, attend a few fundraisers and you’re done. Because, actually, all anybody really wants to do is talk about it.

They don’t actually do anything. And the evidence for that is the number of major leaders in climate who clearly have no intention of changing their lifestyle, reducing their own consumption or getting off private jets themselves. If they’re not willing to do it why should anybody else? Is talking enough? I mean, is, is-- the talking cure of the environment, it didn’t work in psychology. It won’t work in the environment either. Is that enough to do? I don’t think so. I think it’s totally inadequate. Everyday 30,000 people on this planet die of the diseases of poverty. There are, a third of the planet doesn’t have electricity. We have a billion people with no clean water, we have half a billion people going to bed hungry every night. Do we care about this? It seems that we don’t. It seems that we would rather look a hundred years into the future than pay attention to what’s going on now. I think that's unacceptable. I think that’s really a disgrace.

This doesn’t need to happen. We’re allowing it to happen. And I don’t know what’s wrong with the rich self-centered societies that we live in in the west that we are not paying attention to the conditions of the wider world. And it does seem to me that if we use arguments about the environment to turn our back on the sick and the dying of our shared world, and that's our excuse to ignore them, then we have done a true and terrible thing. And it’s awful, thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: This doesn’t need to happen. We’re allowing it to happen. And I don’t know what’s wrong with the rich self-centered societies that we live in in the west that we are not paying attention to the conditions of the wider world. And it does seem to me that if we use arguments about the environment to turn our back on the sick and the dying of our shared world, and that's our excuse to ignore them, then we have done a true and terrible thing. And it’s awful, thank you.

### Moderator
Claim: Thank you Michael Crichton. Gavin Schmidt, you have the podium next.

### Scientific Advocate (SA)
Claim: Thank you. I want to talk to you a little about the nature of this public debate. And I want to give you some background to what you’ve been hearing so far, and what you’ll hear a little bit later on. The issue of global warming and whether it’s a crisis or not, is in fact a scientific decision, it’s a scientific issue. It’s not a political one. On the other hand, deciding what to do about it is obviously political. Science can inform those decisions, but it can’t determine what decisions society makes. But we’re here to debate the existence of the problem and whether it is a crisis. That's something that the scientists on this side are eminently suited to do. You’ve all seen or heard about the CSI police drama, where high tech forensic scientists try and work out who done it when they come across the scene of a crime. Well think of climate scientists as CSI planet Earth, we’re try-, we see a climate change and we try and work out what’s done it. Just like on CSI we have a range of high tech instruments to give us clues, satellites, ocean probes, radar, a worldwide network of weather stations and sophisticated computer programs to help us make sense of it all. The aim is to come to the most likely explanation of all the facts fully anticipating that in the real world there are always going to be anomalies, there are always going to be uncertainties. Conclusions will be preliminary and always open to revision in the light of new evidence. If this all sounds familiar, it’s because it’s exactly the same approach that doctors take when examining a patient. They don’t know everything about the human body, but they can still make a pretty accurate diagnosis of your illness. We end up then with a hierarchy of knowledge. Some things that are extremely likely, some things we’re pretty sure of, and some things that we think might be true, but really could go either way. There isn’t a division into things that are completely proven and things which are completely unknown. Instead, you have a sliding scale of increasing confidence. Let me give you a few examples. We’re highly confident that the sun is gonna rise tomorrow, it might not, it might go nova. But it’s likely that it will happen. It’s quite likely that you’ll be able to get a cab home from this event, unless it’s raining of course. But, but those two things have different levels of certainty. You’re used to the idea that different kinds of knowledge come with different levels of certainty, and that’s exactly what we’re talking about when we talk about the impacts of climate change. Going back to being climate detectives, we’re certain that carbon dioxide and methane are greenhouse gases and they’ve increased because of human activity. We’re very confident that the planet has been warming up, and we’re pretty sure that the other things that are going on, changes to the sun, changes to particles in the air, changes to ozone have made some difference but aren’t dominant. The physics tells us that this is a very consistent picture. Our suspects, the greenhouse gases, had both the opportunity and the means to cause this climate change and they’re very likely guilty. And they are increasing faster than ever. Now, the lawyers get involved. Lawyers are paid to present a certain case regardless of its merits and they do that by challenging everything in the case, and if one argument doesn’t work, well, they’ll just move on to the next. This procedure works very well when the proposition being debated is very binary, a yes, no. Is the subspe-, is the suspect guilty, uh should he go free, should he go to jail? It is designed specifically to prevent significant action in the face of uncertainty. If there is still reasonable doubt, the suspect gets acquitted even if you still think that they did it. But contrast that with the scientists. They want to know the most likely explanation. The lawyers, they want to win the case. In their own domains both ways of finding out things are very useful, it’s only when they come together in situations like this that things get tricky. Particularly when scientific results are perceived to have economic or moral implications, it’s common for political debates to get shifted into the scientific arena. It makes the political argument seem much more scientific and therefore logical. But since the basic disagreement is still political, this is a disaster for any kind of action. So tonight, you’re not gonna hear us arguing about obscure details in climate science, if you have any questions, I have a web site realclimate.org, you can go and check that out and I’ll be happy to answer any questions you might have. But here we’re gonna talk about the bigger picture. Let me give you a few examples of how that works. Creationists have argued that the eye is too complex to have evolved. Not because they care about the evolution of eyes, but because they see the implications of evolution as somehow damaging to their world view. If you demonstrate the evolution of eyes, their world view won’t change, they’ll just move onto something else. Another example, when CFCs from aerosol cans and air conditioners were found to be depleting the ozone layer, the CEO of DuPont, the main manufacturer argued that because CFCs were heavier than air, they couldn’t possibly get up to the ozone layer. So there was no need to regulate them, that was pure fantasy, but it sounded scientific. Again, tobacco companies spent millions trying to show that nicotine delayed the onset of Alzheimer’s because that was a distraction from the far more solid case that, that linked tobacco to lung cancer. That was a distraction and a red herring. These arguments are examples of pseudo debates, scientific sounding points that are designed not to fool the experts, but to sow confusion and doubt in the minds of the lay public. This is a deliberate strategy and you’re hearing it here tonight. So during this debate, let’s play a little game. I’ll call it spot the fallacy. Every time that you hear the other side claim that we are predicting an imminent catastrophe, give yourself one point. Every time you hear an anecdote used to refute a general trend, that’s cherry picking and we heard that already, uh give yourself another. And every time you hear there’s a lag between carbon dioxide and temperature in the ice cores, give yourself two points because that’s a real doosy.

So far this evening we’re running at about two red herrings, two complete errors, three straw men and one cherry pick. So see how you do and we’ll compare notes at the end. Scientists have to be professional skeptics, right, they are trained not to take new information at face value, they have to ask where measurements come from and what they could possibly mean. They have to be dispassionate about the data, and just see where it leads. Once you start making logically fallacious arguments in order to support a predetermined position, you are no longer acting as a scientist, you are acting as a lawyer, however scientific sounding you might seem. Despite that natural skepticism, the national academies of all eight, G8 countries, all the major scientific societies, even the White House have agreed with a scientific consensus on this matter, which pointedly did not happen in the 1970s by the way. Michael Crichton for one has frequently stated the

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: So far this evening we’re running at about two red herrings, two complete errors, three straw men and one cherry pick. So see how you do and we’ll compare notes at the end. Scientists have to be professional skeptics, right, they are trained not to take new information at face value, they have to ask where measurements come from and what they could possibly mean. They have to be dispassionate about the data, and just see where it leads. Once you start making logically fallacious arguments in order to support a predetermined position, you are no longer acting as a scientist, you are acting as a lawyer, however scientific sounding you might seem. Despite that natural skepticism, the national academies of all eight, G8 countries, all the major scientific societies, even the White House have agreed with a scientific consensus on this matter, which pointedly did not happen in the 1970s by the way. Michael Crichton for one has frequently stated the

### Moderator
Claim: Gavin Schmidt, thank you very much.

Philip Stott, you have the podium next.

### Conspiracy Advocate (CA)
Claim: Brian may I just take one second to thank very much the Rosenkranz Foundation and Intelligence Squared for having the great courtesy to invite me over from London to participate in this very exciting set of debates. Thank you also to all my colleagues for their contribution and above all to the audience for I’m sure, gonna be exciting participation as well. I want to start exactly with the consensus word that was used by Richard. Can I just remind you he wanted an example. In the early 20th century, 95% of scientists believe in eugenics. Science does not progress by consensus, it progresses by falsification and by what we call paradigm shifts. And in my, riposte I’ll be coming to a paradigm shift that could actually throw the whole of what that other side is saying through the window. But that's later. What I want to come to now is the 1970s that Robert Rosenkranz quite correctly reminded us of. Because then a crisis was announced. And I want to quote from three newspapers. The Christian Science Monitor, “Warning, Earth’s climate is changing faster than even experts expect.” I really like that. Your own New York Times, “A major cooling of the climate is widely inevitable.” And in Newsweek, back to consensus, “Meteorologists are almost unanimous that catastrophic famines will result from global cooling.” That was the 1970s. And there are many headlines. And what I would like to stress is, it was a stress on consensus, it was faster than expected, the evidence came from the oceans, from polar bears, it’s always polar bears, from the changing seasons and it’s always disaster. Why do we believe them now? And what is important in this I think is to remember what that first Earth Day claimed. The first Earth Day in America claimed the following, that because of global cooling, the population of America would have collapsed to 22 million by the year 2000. And of the average calorie intake of the average American would be wait for this, 2,400 calories, would good it were. It’s nonsense and very dangerous. And what we have fundamentally forgotten is simple primary school science. Climate always changes. It is always as Dick said warming or cooling, it’s never stable. And if it were stable it would actually be interesting scientifically because it would be the first time for four and a half billion years. Second, humans have been influencing climate for a million years as hominids, from the first hominid that set fire to the Savanna grasslands in Africa, when particulates and gases started to rise and they changed the reflectivity of the surface of the Earth. It’s a long relationship. So the debate, is climate changing and are humans affecting climate change is actually nearly irrelevant. The answers are yes and yes, and always will be. What is really crucial in all this is something that none of the scientists or none of the politicians want you really to hear. Climate is the most complex system we know governed by thousands of factors, I haven’t time to list them. But the point is, it’s like in my country, Glasgow on a Saturday night, chaos. And what we’re trying to do is manage it by dealing with one pub. One. And it just won’t work, that’s the danger. In such a system, doing something at the margins and not doing something in the margins are equally unpredictable. And the question we should be asking our politicians are, what climate are you actually aiming to produce and when we get there won’t it change anyway? The crisis is therefore in ourselves and if we are rejecting this and I ask you passionately to do so for the next two more important reasons, our uh, political agenda as Michael hinted is wrong. There are two great crises in the world of which the biggest unquestionably is four billion people in poverty. And this topic is an ecocondria of our rich selves, London, New York and Washington. It’s about us and about our hypochondria about the world. If you actually have clean water, you have modern energy, you will cope with change whatever it is, hot, wet, cold or dry. I’m a left wing critic of global warming because the agenda is fundamentally wrong and dangerous. And believe you me, neither Republican nor Democrat will do anything about it, because our second crisis is a crisis of hypocrisy. Now Michael hinted at this, but I come from Europe which has been lecturing the world on this subject. Let me tell you, the hypocrisy in Europe is absolutely mind blowing, I am embarrassed. The latest statistic from the Environment Agency in Europe will predict under the Kyoto Protocol we won’t even be minus, that by 2012, we’ll be plus four percent. And did you know that island whom we all love actually under the Kyoto Protocol is allowed a growth of 13%? And some of the figures for the, for Europe are just spectacularly worrying. Spain, Italy, Portugal, we’re in the 40 percentile. And yet we lecture the world. What we see in this is an enormous danger for politicians in terms of their hypocrisy. I’m not going to say anything about Al Gore and his house. But it is a very serious point. Global warming is also dangerous because I am an environmentalist, but what I’m beginning to see is that global warming is setting age-, agendas which are actually damaging for the environment. Bio fuels in which the energy relationships are very dodgy, but which have a very significant effect certainly in my country on biodiversity. What is more, we’re having wind farms placed for global warming on very, very sensitive peatmoor habitats. Don’t think therefore that if you’re an environmentalist, you have to be attached to this agenda. Because it is now overarching, overdominant and is actually taking money and effort away from genuine and real on the ground

…..environmental concerns. But let me end with two images. Angela Merkel the German chancellor, my own good prime minister for whom I voted let me emphasize, arguing in public two weeks ago as to who in Annie get the gun style could produce the best temperature. “I could do two degrees C said Angela,” “No, I could only do three said Tony.” Stand back a minute, those are politicians, telling you that they can control climate to a degree Celsius. This is a political crisis, not a crisis as put here, and I ask you passionately to vote against it. And Samuel Johnson and James Thurber, I have to end with Thurber because of the New Yorker. Samuel Johnson, the great lexicographer talked of a, in Russia last talked to an astronomer who thought he could control the sun and the

….he was mad.

I can’t get Thurber in, thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …..environmental concerns. But let me end with two images. Angela Merkel the German chancellor, my own good prime minister for whom I voted let me emphasize, arguing in public two weeks ago as to who in Annie get the gun style could produce the best temperature. “I could do two degrees C said Angela,” “No, I could only do three said Tony.” Stand back a minute, those are politicians, telling you that they can control climate to a degree Celsius. This is a political crisis, not a crisis as put here, and I ask you passionately to vote against it. And Samuel Johnson and James Thurber, I have to end with Thurber because of the New Yorker. Samuel Johnson, the great lexicographer talked of a, in Russia last talked to an astronomer who thought he could control the sun and the

### Moderator
Claim: Philip Stott.

### Conspiracy Advocate (CA)
Claim: ….he was mad.

### Moderator
Claim: Thank you very much.

### Conspiracy Advocate (CA)
Claim: I can’t get Thurber in, thank you.

### Moderator
Claim: Brenda Ekwurzel, the podium is yours.

### Scientific Advocate (SA)
Claim: I’d like to thank the Rosenkranz Foundation, to all of you for taking time to discuss this urgent topic. Uh, Gavin Schmidt, like in the climate scientists to forensics team of the CSI, uh another metaphor that applies is that of a doctor. And studying global warming is like taking the Earth’s temperature. We’ve seen that it’s rising, and also we have diagnosed the dominant cause of this fever is the heat trapping emissions from human activity. So far temperatures have gone up about over a degree, point, one point four degrees Fahrenheit. That doesn’t mean much to our everyday lives, but it means everything to the Earth. All of us have experienced 100 degree temperature, a hundred and two degree temperature, but we’ve survived. Now the body cannot withstand 107 degree Fahrenheit temperature. That’s about an eight degree jump above the average body temperature. Now when it comes to the Earth, the Earth is much more fragile than the body when it comes to temperature. What we see is that a seven degree increase in global warming would mean that we would accelerate, we would intensify the water cycle, that means the wet places will get wetter and the dry places will get drier. It means we put at risk species that are gonna go extinct. It means that the summer arctic ice is at risk of disappearing. It also means that a seven degree rise in temperature would commit us to substantial sea level rise from melting of the Greenland ice sheet. The Earth’s fever is only getting worse and the animals and the plants that are out there struggling are already giving us the early warning signs. We’ve seen them shift their habitats and we’ve seen them struggle as they cope with the shifting of the period, the warm periods and the cold periods of the seasons. Furthermore, there’s already heat in the pipeline as the oceans play catch-up to the atmosphere loading that we’ve put, these heat trapping gases in our atmosphere. As the oceans warm up, the temperatures will commit us to further warming. We’re locking in another degree of Fahrenheit of warming. That’s heat in the pipeline. Do we really want to lock in even further warming? We’re going to keep studying the symptoms of scie-, as scientists. But the diagnosis is very clear and the course of treatment is even clearer. Choosing not to fight global warming is as foolhardy as ignoring the early warning signs of a fever of a young child and not attending to that. So what is the course of treatment and can we really do something about it? The answer is yes, but we have to act soon, we have to start tackling this problem on all fronts. Our landfills, farms, and livestock are emitting methane and other heat trapping gases. Our fossil fuels, our oil, our coal, our gas, cutting down forests, are committing us to ever increasing levels of carbon dioxide in our atmosphere, in fact, these levels of heat trapping gases are at the highest level than they’ve ever been for hundreds of thousands of years. It’s not natural. Since the dawn of the industrial age, humans have been digging up carbon and putting it on fire, and using it as energy. Now the Earth doesn’t normally set on fire million year ol- , million year old stores of carbon, it’s unnatural. It’s not, it’s not a normal thing. What we’re doing by using these fossil fuels is overwhelming the Earth’s capacity to clean up and absorb that carbon dioxide from the atmosphere. The Earth takes hundreds of years to get rid of carbon dioxide and what’s most important, is that this fact is very important to help us decide when we have to start acting about global warming. While some of the worst effects might not be felt for decades or centuries the actions we take today will determine how much carbon dioxide will be in the atmosphere, how much global warming we are locking in, how bad are the effects going to be for ourselves and for our children and grandchildren. That’s what’s really important. We probably have a decade to institute meaningful solutions. Why ten years? That’s because the decisions we make today have a long term commitment. If we do not reform our agriculture practices heat trapping gases will continue to accumulate in the atmosphere. However, if we were to capture methane from our landfills, not only would we stop those emissions from going to the atmosphere, we would also be creating energy at the same time. If we make a building in the old way then we would be polluting for decades to come. However, if we were to build with renewable energy sources new cleaner buildings then that means that we have eliminated that fossil fuel loading of emissions to the atmosphere. If we construct coal power plants the conventional way that means we are substantially increasing the heat trapping emissions in our atmosphere for fifty years and they will linger for many, many more years. However, if we invest in research and technology to capture carbon from those coal plants this will would be welcome news to all the nations of the world that have deep, vast coal reserves. Increasing energy efficiency and harnessing renewable energy from the sun, from the wind, from other sources will help us along this path. If our cities continue to grow, that increase the commuting distance of our citizens, that means we are committing ourselves to burning more fuel. There are better ways. With profitable solutions at hand it’s irresponsible to postpone action. Right now we could put nations on target to reducing emissions. If we start now we reduce each year. However, if we delay that means that the cuts that we have to make to meet our goals will become steeper and steeper and we may not even be able to meet those demands. They will become too hard for us to reach. It’s the equivalent to the person with a credit card who can no longer pay off the minimum payments, that cannot reach their goals. Right now we’re on a spending spree with our heat trapping emissions. We’re building up the future costs of global warming. And –

And when this bill comes, uh, when the bill for our emissions today comes, comes due in the not too distant future, um, choosing not to fight global warming is about as irresponsible as not making payments on a high interest credit card. With such high stakes common sense requires that we act now and while we still have options. Um, within the next decade we will continue to determine whether or not our children and grandchildren look back at this time and decide whether we failed them. Or will they look back at this time and see that built a better planet for ourselves and for them? We have a chance to avert this crisis and to assure a safer planet. And if we wait for the children to solve this problem it’s too late. The risks are too big. But before we act on the global warming –

…we must recognize it for the crisis that it is. Vote no.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: And when this bill comes, uh, when the bill for our emissions today comes, comes due in the not too distant future, um, choosing not to fight global warming is about as irresponsible as not making payments on a high interest credit card. With such high stakes common sense requires that we act now and while we still have options. Um, within the next decade we will continue to determine whether or not our children and grandchildren look back at this time and decide whether we failed them. Or will they look back at this time and see that built a better planet for ourselves and for them? We have a chance to avert this crisis and to assure a safer planet. And if we wait for the children to solve this problem it’s too late. The risks are too big. But before we act on the global warming –

### Moderator
Claim: Brenda Ekwurzel, thank you very much.

### Scientific Advocate (SA)
Claim: …we must recognize it for the crisis that it is. Vote no.

## Round 2

### Moderator
Claim: And thank all our panelists for their initial presentations. I am now ready to announce the results of the pre- debate vote, rounded to the nearest whole number. Those for the motion that global warming is not a crisis, were 30% of you. Those against the motion were 57% of you, those undecided, were 13% of you. Not worthy of snickering, those 13 percent. Or, more precisely, 29.88% for, 57.32% against, and 12.8% undecided. So we’re now ready to begin the Q-and-A portion of the program, I will call on the questioners, someone on each side of the auditorium will come to you with a microphone when you raise your hands. I will be looking for, from you, challenging questions for the pro side and for the anti side. Uh, if you can identify yourselves that way, uh, to the people with the microphones that would be good. Um, if some of you don’t fit into that category that’s okay too. Uh, we’re gonna mix in my questions and your questions and to the panelists, um, I hope to keep a good pace here because by the rules we have 20 minutes only, and there is so much to follow up on. Also…audience members, uh, please do not start to ask your question until you have a microphone. please make your questions short and to the point, please, 30 seconds if you can, and, the more focused your question, the more likely you are to be on NPR. So— There you go. Okay. Brenda Ekwurzel, and Richard Lindzen. Can I get the two of you to engage for up to two minutes on one thing I noticed in your conversations, in your presentations, um… Richard Lindzen, you seemed to say that warming could make the climate more stable. Brenda, you seemed to suggest, that it would make it less stable. Richard Lindzen, I’ll start with you, and talk to each other. Are you arguing that global warming could be good for the earth?

### Conspiracy Advocate (CA)
Claim: Yeah, of course it could be. That’s, uh, goes without question. There’s no reason to assume we’re at the optimum for climate. It’s been all over the place—

### Scientific Advocate (SA)
Claim: But it’s the climate that we have adapted to, it’s the climate that has led us to put—

### Conspiracy Advocate (CA)
Claim: It may be—

### Scientific Advocate (SA)
Claim: —Battery Park City right at the waterline, that’s the problem—

### Moderator
Claim: Gavin Schmidt, thank you, let him, let him— Hang on, hang on, hang on, well— Let him finish your thought, go ahead, Richard Lindzen—

### Conspiracy Advocate (CA)
Claim: What I was referring to was the issue of variability. And that depends basically on the pole-to-equator temperature difference. And since the models are suggesting that the warming would be greater at the poles, then you are reducing the equator to pole- temperature difference, you’re increasing the—decreasing the forcing for storms, and you’re decreasing the range.

### Moderator
Claim: Brenda Ekwurzel?

### Scientific Advocate (SA)
Claim: Yes, I think the risks are gonna grow, we know this with the warming of the planet further. And furthermore, if we have those risks that means that governments are gonna spend much more money, hand over fist, bailing out farmers that are suffering from more extreme draught, we have arable lands growing—

### Conspiracy Advocate (CA)
Claim: Look—

### Scientific Advocate (SA)
Claim: —uh, stuff like this—

### Conspiracy Advocate (CA)
Claim: But they’d have less water source—

### Scientific Advocate (SA)
Claim: —this is gonna be—and less money for fighting poverty and all those other aspects that are important—

### Moderator
Claim: Philip Stott, you wanted to get in here?

### Conspiracy Advocate (CA)
Claim: Just to say I did find Gavin’s comment a little amusing because in fact 8,000 years ago, at a peak of warming much higher than today, you know what the climate people call it? The climate optimum. In other words it’s actually perceived as more optimal in terms of vegetation and other factors.

### Scientific Advocate (SA)
Claim: Not for people who own—

### Moderator
Claim: Gavin, go ahead and respond.

### Scientific Advocate (SA)
Claim: Not for people who own basement property in Battery Park City.

### Moderator
Claim: A low-lying area of New York City for those of you living… around the country.

### Conspiracy Advocate (CA)
Claim: But I think that raises a really interesting issue because of course adaptation to change is always the way that humans have coped with it, in fact of course bad planning and bad building doesn’t excuse and is not proof of global warming.

### Moderator
Claim: Here’s a question for the anti side. A question for the anti side if I might, these 1970s headlines about global cooling. That always comes up as an inconvenient fact. I’ve almost got a title there. How do you explain that? Who wants it.

### Scientific Advocate (SA)
Claim: You know, that’s an—that’s the scientific equivalent of an urban legend and I’m shocked, that not—

### Moderator
Claim: Richard Somerville.

### Scientific Advocate (SA)
Claim: That not—not only, uh, did we hear it from Michael Crichton and Philip Stott but we heard it from the fourth member of the pro team, Mr. Rosenkranz, at the beginning. The—there wasn’t a scientific consensus in the ‘70s about global cooling. There was hype in the news media. Quoting Newsweek is not the right way to evaluate, uh, scientific thought, you can look it up.

### Conspiracy Advocate (CA)
Claim: But, can I—can I answer that?

### Moderator
Claim: Wait, Richard Lindzen, go ahead?

### Conspiracy Advocate (CA)
Claim: Yeah. But, you know, the claim of consensus right now is also not based on a vote…or anything else, and in fact it was invoked by Newsweek in 1988…when they stated all scientists agree.

### Moderator
Claim: But wait, on—do you agree on this 1970s global cooling thing, that that was media hype, Richard Lindzen?

### Conspiracy Advocate (CA)
Claim: Actually, I do not disagree with Richard on that.

### Scientific Advocate (SA)
Claim: Thank you—

### Conspiracy Advocate (CA)
Claim: I think it is true that the media amplified what was going on considerably, and that the field itself was in a much healthier state at that time and the open discussions were greater.

### Moderator
Claim: Philip Stott, very briefly.

### Conspiracy Advocate (CA)
Claim: Yeah, what’s very amusing was, one scientist came out in 1970, a Swedish scientist, and actually said we should pump out carbon dioxide to ensure that we didn’t go into global cooling.

### Scientific Advocate (SA)
Claim: You know, you—you can always find, uh, people on the fringes—

### Moderator
Claim: Richard Somerville, go ahead—

### Scientific Advocate (SA)
Claim: You can always find people, uh, on the fringes, consensus doesn’t mean unanimity and science isn’t a democracy anyway but it’s not good to misrepresent, the situation when an overwhelming majority of genuine experts have come to conclusions opposed to some of those who’ve heard, uh, from the other side.

### Moderator
Claim: So, so to the yes team…Michael Crichton, you talked about, how consensus is sometimes wrong and it takes the individual to burst through the consensus. Excuse me. Um, this debate is set up three on three, as if everything were even. But in the real world out there, we just had the big inter- governmental panel on climate change report in which 90% of the world’s governments and 90% of their atmospheric sciences declared with 90% certainty, that global warming is real and human beings are causing it. Why would you three be more credible to the non-scientists in our audience, than all of them?

### Conspiracy Advocate (CA)
Claim: It—it’s…this is always to me a very fascinating point. If, if we were to say, um, does the moon revolve around the earth, uh, we would say yes, and no one would ever, would ever preface that by saying, well, the consensus of scientists says this. You know, the, the notion of consensus is only a vote for very particular kinds of things, and to me it’s a serious warning signal. For example, ordinarily if I were to say the moon is full of green cheese, no one would, no one would vilify me or— they would take me out and prove to me that that wasn’t the case. It’s, it’s when there isn’t a very good and powerful counter-argument, that’s the first answer, the second answer is, is one I really like very much and it’s one Einstein made. He, um…there was a— the Nazis decided that they would, uh, do something to demonstrate that German science was bad and they got 200, uh, German scientists to say that Einstein was wrong and then somebody asked Einstein, how does it feel to have 200 scientists against you. And he said, it takes only one to prove me wrong.

### Moderator
Claim: All right, who on the anti side wants to respond. Uh, Gavin Schmidt.

### Scientific Advocate (SA)
Claim: Okay. You’ve frequently stated that consensus is not science. And you know what, I agree with you. Consensus is what’s left over, after the science has been done. Consensus is what goes into the textbooks. The science is happening at the frontiers. It’s the filling in of the interesting pieces of the jigsaw puzzle. It’s the, not—it’s not the overall picture, the big picture, is the stuff that everybody knows and everybody understands. Your, your assessment of— You’re—you’re arguing that, because something is—people agree on it, you can’t possibly agree with it. It’s like saying, well if you disagree, then I’ll agree.

### Conspiracy Advocate (CA)
Claim: No, I was—

### Scientific Advocate (SA)
Claim: You’re saying you’ll never agree which means that you’re not listening to what the people are saying—

### Moderator
Claim: Yeah—

### Conspiracy Advocate (CA)
Claim: —what am I saying again—

### Moderator
Claim: Michael, go ahead, I’m sorry?

### Conspiracy Advocate (CA)
Claim: I’m not saying that the consensus is necessarily wrong, I’m only saying that consensus is not a—a clear proof that it’s right.

### Conspiracy Advocate (CA)
Claim: And moreover, Michael—

### Conspiracy Advocate (CA)
Claim: Of course not, no—

### Conspiracy Advocate (CA)
Claim: —has made the point—

### Moderator
Claim: Richard Lindzen on the same side, go— continue.

### Conspiracy Advocate (CA)
Claim: Lamont made the same statement, you don’t use consensus if you have a proof.

### Conspiracy Advocate (CA)
Claim: What’s very important—

### Moderator
Claim: Philip Stott, you wanna back that up further—

### Conspiracy Advocate (CA)
Claim: Yeah, quite, Gavin right, you said, we should always be at the edge, the edge of science on climate change has nothing to do with CO2, it’s to do with what we call cosmic rays, the relationship to the sun, and water vapor.

### Moderator
Claim: Anybody else on the anti side wanna come back on that? They all three got a—got a lick in there.

### Scientific Advocate (SA)
Claim: I—it is—

### Moderator
Claim: Richard Somerville—

### Scientific Advocate (SA)
Claim: It is mind-boggling, to say that cosmic rays are the cause of, of climate change is to en—endorse one of the least proven, most tentative—

### Conspiracy Advocate (CA)
Claim: I didn’t say that.

### Scientific Advocate (SA)
Claim: Oh, good, I’m glad—

### Scientific Advocate (SA)
Claim: But then why—why did you bring it up.

### Scientific Advocate (SA)
Claim: Why did you bring it up, yeah—

### Conspiracy Advocate (CA)
Claim: Simply because there are a whole range of scientists who are working on this particular topic and they say it’s one of the big unknowns and a great deal of research has just been done on it. At the edge—

### Scientific Advocate (SA)
Claim: But we’re—we’re talking about global warming, we’re talking about the trend in temperature that—

### Moderator
Claim: Gavin Schmidt—

### Scientific Advocate (SA)
Claim: —we’ve seen over the last 30 years. There has been no trend in cosmic rays. So any change that there might have been because of cosmic ray impacts on climate, can’t possibly have an impact on what’s been going on—

### Conspiracy Advocate (CA)
Claim: The most famous—

### Scientific Advocate (SA)
Claim: —in the last changes.

### Conspiracy Advocate (CA)
Claim: But the most famous astrophysicist working on it say that it has.

### Scientific Advocate (SA)
Claim: Uh, he is wrong.

### Moderator
Claim: Okay—

### Scientific Advocate (SA)
Claim: I’m sorry.

### Moderator
Claim: We’re now ready to vote—no, I’m kidding. Um, for—

### Conspiracy Advocate (CA)
Claim: That’s a serious accusation against some very serious sci—some are infinitely better than any of us on this platform today.

### Scientific Advocate (SA)
Claim: I’d like to meet the person—

### Conspiracy Advocate (CA)
Claim: Explain that—

### Conspiracy Advocate (CA)
Claim: There are some very eminent scientists, Professor Jan Veizer for example, uh, uh, Nir Sh—Professor Nir Shaviv who won the Young Scientist of the Year in Israel two years ago, who are in fact arguing that 70% of, of climate change is primarily driven by cosmic rays working through water vapor and clouds. I’m not saying they’re right or wrong, they’re pointing however at the edge, to new research. You cannot dismiss that, because it’s a consensus for CO2.

### Moderator
Claim: Gavin Schmidt, one more time?

### Scientific Advocate (SA)
Claim: Okay, this is exactly what I was talking about. You see? Now, it looks like we’re having a scientific argument, but, this is completely bogus. You don’t know that it’s bogus, but I know that it’s bogus, he knows that it’s bogus. You’re being led astray.

### Conspiracy Advocate (CA)
Claim: You’ll forgive me, Gavin… If—if you seriously wish to maintain that, then you’d better explain why—

### Moderator
Claim: Richard Lindzen—

### Conspiracy Advocate (CA)
Claim: —between you and Richard, you’ve made statements that are overtly untrue. And I’ll give you some. You say, the earth has been warmer—is warmer now than it has been for 1300 years. The national academy evaluating this said, the methodology was no use beyond 400 years. Why do you make this statement. You keep on quoting these groups, and when they disagree with them, you make up the quote.

### Scientific Advocate (SA)
Claim: I—I’ve gotta say that one, one thing at a time—

### Moderator
Claim: Gavin Schmidt—

### Scientific Advocate (SA)
Claim: —let’s deal with that. The National Academy of Science report said that we have good evidence that we’re warmer from 400 years ago, we have credible evidence that we’re warmer from 900—

### Conspiracy Advocate (CA)
Claim: No, they did not—

### Scientific Advocate (SA)
Claim: Yes they did, Richard, please—

### Conspiracy Advocate (CA)
Claim: No, the—

### Scientific Advocate (SA)
Claim: Read the reports before—

### Conspiracy Advocate (CA)
Claim: —front end—the front end said—

### Scientific Advocate (SA)
Claim: Read the—read more than the front page, Richard—

### Conspiracy Advocate (CA)
Claim: No, I’m saying the text, said it was not credible beyond 400 years—

### Scientific Advocate (SA)
Claim: That’s not what it—that’s not what it said—

### Scientific Advocate (SA)
Claim: Moreover, moreover—

### Moderator
Claim: Right, well, wait, wait, wait, wait, wait—

### Scientific Advocate (SA)
Claim: I can tell you why it’s not—

### Moderator
Claim: We’re into “he said”-“he said.” But— But Gavin Schmidt, you seem to suggest that the other side does not have a real scientific argument, but a culturally or politically constructed one. You don’t think they’re sincere?

### Scientific Advocate (SA)
Claim: That’s a very difficult question. I think—I— no, I, I do think that they’re sincere—

### Moderator
Claim: You as much as said it.

### Scientific Advocate (SA)
Claim: I don’t think that they are completely…doing this on a level playing field that the people here will understand. And, there are…

### Moderator
Claim: Well… explain yourself, because—wait a minute—

### Scientific Advocate (SA)
Claim: No, let me—let me explain, explain that—

### Moderator
Claim: Because they have larger cultural or political agendas?

### Scientific Advocate (SA)
Claim: No, um, I have no idea what their political or cultural agendas are, and to be frank I’m not very interested.

### Conspiracy Advocate (CA)
Claim: I’m left-wing and have no money whatsoever from any oil company—

### Scientific Advocate (SA)
Claim: Okay, and—

### Conspiracy Advocate (CA)
Claim: —and I wouldn’t.

### Scientific Advocate (SA)
Claim: That’s fine. That’s fine. But I’m, I’m—

### Moderator
Claim: All right—

### Scientific Advocate (SA)
Claim: —I’m not interested in your motivations—

### Conspiracy Advocate (CA)
Claim: But I know—

### Moderator
Claim: All right—

### Conspiracy Advocate (CA)
Claim: has interests.

### Moderator
Claim: Let’s go to the audience, and, when you ask your questions, uh, members of the press, please identify yourselves as such. Members of the audience who are not with the press, you have the option to identify yourself, or not. Okay. Right down here.

### Moderator
Claim: Hi, my name is Linda Caro, um, it kind of surprises me that , uh, the emphasis is on CO2 which is about one-third of 1% of the total atmosphere, whereas global—uh, water vapor is the vast bulk of it all. Uh, is it possible that we are, um…are not accounting properly for, uh, the giving off of heat such as nuclear power plants which are several thousand degrees Centi—uh, Fahrenheit, that we’re cooling with water and air, every day, every week, every month, every year, that can’t—

### Moderator
Claim: Is there anyone you would particularly like to answer that question?

### Moderator
Claim: Whoever feels most qualified.

### Moderator
Claim: Richard Somerville is raising his hand.

### Scientific Advocate (SA)
Claim: The, the direct heating from sources like power plants is negligible, uh, compared to these, these other factors, solar radiation, greenhouse effect. And the greenhouse effect is due to water vapor, primarily carbon dioxide and other gas is secondary, we can’t control water vapors. It’s controlled by the atmosphere itself, largely by temperature, so when you add CO2, you humidify the atmosphere and the water adds to the warming. That’s one reason why Richard Lindzen’s talking about CO2 only giving you a degree or so is disingenuous because that feedback is expected theoretically and has been observed.

### Moderator
Claim: I think Richard Stott is, uh—Philip Stott is bursting out of his chair to agree with you.

### Conspiracy Advocate (CA)
Claim: I could not agree more. Yes, it’s governed by the atmosphere. Absolutely, and is not under our control.

### Scientific Advocate (SA)
Claim: But it’s—

### Conspiracy Advocate (CA)
Claim: It is therefore one of the big factors, that we have no control over.

### Scientific Advocate (SA)
Claim: It’s—

### Conspiracy Advocate (CA)
Claim: In a non-linear couple system.

### Scientific Advocate (SA)
Claim: I’m, I’m, I’m stunned by, by your amazement that non-linear coupled chaotic systems are things that we can’t understand even in part, that—

### Conspiracy Advocate (CA)
Claim: He didn’t say that—

### Conspiracy Advocate (CA)
Claim: I said—I said control.

### Scientific Advocate (SA)
Claim: Very—very good. You can control how much CO2 you put in the atmosphere and that will have a big effect on how much water vapor is in the atmosphere, that’s not controversial.

### Conspiracy Advocate (CA)
Claim: Well you can’t predict—

### Conspiracy Advocate (CA)
Claim: That is controversial—

### Conspiracy Advocate (CA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: —and it’s controversial because it is not a homogeneous distribution of water vapor.

### Conspiracy Advocate (CA)
Claim: Yeah, exactly.

### Conspiracy Advocate (CA)
Claim: And, you know, to pretend this is settled, is bizarre. Moreover with clouds, which are comparably important, you know full well, that that is not settled.

### Moderator
Claim: Let us—

### Conspiracy Advocate (CA)
Claim: By a long shot.

### Moderator
Claim: —go to another questioner from the audience—

### Moderator
Claim: Down on this side in the front.

### Moderator
Claim: Uh, Andy Revkin from the New York Times, this is, this is kind of neat to, to listen to.

### Moderator
Claim: Did I hear a hiss?

### Moderator
Claim: Ssss. Back atcha. Um, I’ve been writing about this for a long time. Uh, most every aspect of it. So my question is, uh, one about the hedging, managing risk came up before, which is not what you think of when you think of crisis and catastrophe. My—my sense is that there’s one thing that everyone has agreed on, at least—except maybe Philip, which is that, more greenhouse gases will make the world warmer. Is there anyone other than Philip who disagrees with that—

### Conspiracy Advocate (CA)
Claim: I don’t disagree with it.

### Moderator
Claim: Okay, you did it—yeah, so, we all—I love to find the things we agree on. Um, so everyone agrees, more greenhouse gases will make the world warmer. Uh, the doubling is, is a step on the staircase we’re—we’re heading on toward tripling or quadrupling, I think everyone would mostly agree that if we go to nine billion people, all of whom would love to have our level of affluence, we’re going in that direction. And so, as a hedging exercise, if it weren’t costly to slow the pace, beyond the Jesse Ausubel very slow decarbonization, if we could find a new way that didn’t cost a lot, that actually could give energy for those developing countries that crave it, and limit emissions at the same time, would anyone on the pro side think that it’s a bad idea to stop emitting greenhouse gases, if there were a solution.

### Moderator
Claim: Michael Crichton, you’re shaking your head no?

### Conspiracy Advocate (CA)
Claim: No—

### Moderator
Claim: As a hedge—

### Conspiracy Advocate (CA)
Claim: —no, I don’t think anybody objects, uh, the, the, the question is whether or not you’re gonna spend what Bjorn Lomberg thinks which is $558 trillion and I think, if in fact it’s going to prove to be that kind of enormous construction project, then that should not be the first priority right this minute. But no, I don’t—

### Moderator
Claim: So let me pursue Andy Revkin’s stab at striking a consensus on what to do. For the anti side…if this is a crisis, what kind of lifestyle change, what kind of economic pain, and how quickly are you proposing…to hedge our bets?

Brenda Ekwurzel.

### Scientific Advocate (SA)
Claim: As soon as possible because—

### Moderator
Claim: But what?

### Scientific Advocate (SA)
Claim: Everything, everything that we can throw at solving this climate crisis—well, this climate problem, is important because, every day that we emit carbon dioxide means that it will last for many, many centuries, and so we have to start weaning ourselves off of ways of emitting more methane, more nitrous oxide, all the heat- trapping gases, not just carbon dioxide, it’s the ones that have long life, nitrous oxide, carbon dioxide, that are very, very important, in the short term methane is very important ‘cause it has such heat-trapping potential.

### Moderator
Claim: But forgive me—

### Scientific Advocate (SA)
Claim: And so, landfills—

### Moderator
Claim: —but the question from—

### Scientific Advocate (SA)
Claim: —everything, uh—

### Moderator
Claim: The—the question from the audience was, things that we could do, correct me if I’m wrong, Andrew, things that we could do without much pain that would stave this off—

### Conspiracy Advocate (CA)
Claim: Well—

### Moderator
Claim: Either you’re talking about—

### Scientific Advocate (SA)
Claim: Well, what—

### Moderator
Claim: —revolution, anything necessary.

### Conspiracy Advocate (CA)
Claim: The real problem is—

### Moderator
Claim: Philip Stott—

### Conspiracy Advocate (CA)
Claim: —there’s no social discounting in this, let’s get a bit of economics in. So in fact, if you—if you have an increase now, and you take inflation into account, what you’re doing is an average world, um, income at the moment of $7,500. Predicted by a—a distance ahead, that will rise to about $88,000, you knock off what in fact the Stern Report in Britain estimated, as in fact the cost of global warming, 13.27 or so percent, it comes down to something like, uh, 70-something thousand dollars but even taking inflation account that is still a massive increase in wealth so what you’re actually asking in economic terms, is what is strange but a poorer generation to sacrifice a great deal for what will in any case, even with global warming cares, be a wealthier generation.

### Scientific Advocate (SA)
Claim: The thing is that companies right now when they reduce heat- trapping emissions they find profits that keep giving back to them because, right now we’re so wealthy in many nations of the world that we are wasting energy because we can afford to. And the reality is many companies are saving lots of money when they make small investments to reduce their emissions, DuPont did 50 million to invest, they’re getting 2 billion on return on that investment, and it keeps on giving, so, it’s not an economic…argument.

### Moderator
Claim: Anything else from the anti side that you think might be…

### Moderator
Claim: The, the—

### Moderator
Claim: —consensus, uh, good for us anyway kind of measures that they might agree to?

### Scientific Advocate (SA)
Claim: Right. Energy conservation—

### Moderator
Claim: Gavin Schmidt.

### Scientific Advocate (SA)
Claim: Everybody is gonna agree that energy conservation is a good thing and it should be encouraged. Um, right.

### Moderator
Claim: That’s three heads nodding on this side?

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: You’re gonna argue with energy conservation—

### Moderator
Claim: Two—all right, two, two and a half. Two and a half heads, that’s good enough. Go—go on, Richard Somerville.

### Scientific Advocate (SA)
Claim: You know, a lot of things could be done, once you free up the creativity of, uh, of technical people, of business people by making this a priority nationally and internationally, the problem isn’t that there’s nothing that can be done, the problem is that, the people who are asking for your vote haven’t heard loudly enough that this is an important issue to the electorate, so it’s way down on people’s priorities, that’s the reason for the lip service that Michael Crichton talked about, people are a lot like, like Mark Twain, they’re all for progress but are opposed to change.

### Moderator
Claim: Let’s go— Let’s go back to the audience, someone on this side, do we have someone lined up on that side? Okay.

### Moderator
Claim: Thank you, my name is Heather Higgins, I’m not a scientist, so, pardon my ignorance when I hear the scientistic—scientific establishment believes in something I immediately think of flat- earth consensus, and the fact that there’s no geography that should be admitted as science and that women are all hysterics and ought to be bled. Uh, so, uh, that, um, assurance that the scientific community believes something does not take me very far. My question is address particularly to Brenda, as well as to anyone else. Um, I was fascinated by your statement that the earth is more fragile than human beings are. Uh, I am not a scientist so maybe you can explain to me how we managed to get through the Ice Age and the Middle Ages when Greenland was actually green and people were a foot taller and there was farming there, uh, and nobody was digging up coal to warm the earth. Um, and, I’m curious as to why you think that this is an optimal period of climate, uh, certainly for far less money we could move everybody out of Battery Park City. And I am curious, if you believe that CO2 is actually the, the—the particular problem is actually the issue, the degree to which you are willing to, to become like France, where instead of having 20% of their power from nuclear, they have 86%.

### Scientific Advocate (SA)
Claim: When there was a natural ice age before and when we were coming out of that ice age there weren’t millions of people, 80% of our population living on the coasts with their high-dollar homes or, maybe fragile homes, not such high-dollar homes. There are many people living in Bangladesh that are squeezed between sea- level rise and the melting of the, the Himalayas and flooding from the land side. And so, we are talking about the fragility of humans adapting to this rapid change, as well as, when— In the past, sea-level rise, you could have, for example, wetlands marching up onto land, and moving inland and adapting and dunes moving inland, right now we have all our infrastructure in its place, and you can see, Miami is stranded out there, Atlantic City is stranded out there, we spend many of— millions of dollars dredging, and, and keeping these unsustainable systems that are not able to adapt naturally anymore because we’re in the way. And we also are gonna suffer, if we don’t, uh, make action.

### Moderator
Claim: Philip Stott, you get 20 seconds to respond—

### Conspiracy Advocate (CA)
Claim: Yeah, it was a, I think a brilliant question that, because the earth is as tough as an old boot. If there is any fragility it’s in us and that’s what we’re concerned about, the earth will survive whether we’re here or not or whether there’s global warming or not—

### Moderator
Claim: Question on this side?

### Moderator
Claim: Hi, Van Greenfield, just following up a little bit on the, uh…question two minutes ago on what we could do, um… Philip, you had said in another article, “My own instinct is that our ability to change reflectivity on the earth’s surface will in the end prove to have been far more important.” In terms of the concept of reflectivity could you expand on that and its possible…less expensive method for dealing with this?

### Moderator
Claim: Very briefly, please.

### Conspiracy Advocate (CA)
Claim: Very briefly, but it’s a very important point, the point is very simple, that humans are not just doing CO2, we do many factors, and the way we have altered the albedo as we call it, the surface reflectivity of the earth, uh, particularly I may add since the Neolithic revolution in agriculture has had probably quite a significant effect. However, we can’t model it very well. And the problem is it’s one of those big gaps like many others things in the models that we’re talking—and that is a human factor. So in other words I agree with that, exactly how we cope with it though is another issue, because we know so little about it. And can I remind everybody that IPCC that we keep talking about, very honestly admits that we know very little about 80% of the factors behind climate change.

### Moderator
Claim: One more thing for the anti side…bef—oh, you wanna—okay, go ahead and give a quick response to that, 20-second response? Go—

### Scientific Advocate (SA)
Claim: Uh, what is 80%—

### Moderator
Claim: Gavin, Gavin Schmidt—

### Scientific Advocate (SA)
Claim: —of the counter-factors even mean. If you look at, if you look at the radiative forcing from carbon dioxide, from methane, from nitrous oxide, from CFC’s, from tropospheric ozone, from stratospheric ozone, from land-use change, from aerosols, from black soo—from black soot’s pa—um, impacts on, um, snow albedo, you know…all of those, all of those things, we know some of them very well, we know some of them less well. But to, to, to claim that we don’t know anything about 80% of them, is, it’s, it’s a meaningless statistic—

### Scientific Advocate (SA)
Claim: Yeah, I’d like to—could I chime in there just for a moment, Brian—

### Moderator
Claim: Richard Somerville, also 20 seconds—

### Scientific Advocate (SA)
Claim: Listen, it’s, it’s fun to hear other people practicing meteorology without a license, so, and you know— This, this field is like all fields of science, you know, medical science is incomplete and has uncertainties too. But it’s good enough to be useful. You don’t dismiss your doctor’s advice, because she hasn’t solved all the diseases. And I think the same is true of climate science today.

### Moderator
Claim: Philip Stott—

### Conspiracy Advocate (CA)
Claim: Don’t dismiss it—

### Moderator
Claim: —one—one retort.

### Conspiracy Advocate (CA)
Claim: Well let’s use an engineer, I don’t think I’d want to cross Brooklyn Bridge if it were built by an engineer who only understood 80% of the forces on that bridge.

### Moderator
Claim: There’s one thing…

### Scientific Advocate (SA)
Claim: I—I actually—

### Moderator
Claim: That—

### Scientific Advocate (SA)
Claim: —I, we, we…I think we might have a solution to the energy crisis, we just need to tap Philip Stott.

### Moderator
Claim: There is one thing that I think we need to get to before we wrap up. For the anti side…they say…the real crises today include poverty, dirty water, and a lack of modern energy supply to 4 billion poor people on earth. So if this is a crisis, how do you prioritize it, compared to those other things, and assuming that it takes tremendous amounts of resources to solve any of them.

### Scientific Advocate (SA)
Claim: You know, I—I cannot imagine why Philip Stott and Michael Crichton seem to think that doing something about these terrible crises is impossible if you do something about climate change, or even made more difficult, climate change need not be in competition with or be an alternative to doing something about the terrible toll that poverty and preventable disease take. We can do both of those and many other worthy things as well, in fact, it’s exactly the poorest and most vulnerable people on the planet who will suffer the most from the consequences of, of global warming which goes on unabated.

### Moderator
Claim: Michael Crichton?

### Conspiracy Advocate (CA)
Claim: You know, uh, I’m really fascinated at the number of newspaper headlines and articles that I see about global poverty and the, and the difficulties of people in Africa as compared to the headlines about, about global warming, and, um, uh, of course Richard it’s very true that we can do two things at the same time, it—the, the reality is that we don’t. And the reality is, that, we are failing and have continuously failed to address the issues of the third world even though, everyone knows that if you were to, to look at it for bangs for the buck, if you were to look at it from a humanitarian standpoint, if you were to look at it from the easiest way to do the most for environmental degradation as it’s created around the world, you would address global poverty. But we’re not. We’re talking as we’re talking tonight, we’re all getting very heated about something that may or may not happen 100 years from now. And while we’re doing, 3,000, 5,000, 10,000 people are dead.

## Round 3

### Moderator
Claim: That concludes… the discussion portion of our program. And it is now time to vote. If you wanna vote for the motion, tear off “For” from the top…of the motion, uh, ballot, and slip into the ballot boxes… This is a ballot box, that will be passed among you. If you are against the motion, tear off and deposit “Against” into the ballot box, and if you still don’t know where you stand…put your entire ticket into the box. The ballot boxes will be given to the person at one end of a row, please pass the ballot box to your neighbor until it reaches the end of the row, pass it down just like in third grade. One of the ushers will then take the box to the next row, everyone will get a chance to vote so please don’t reach over your neighbor, wait for a ballot box to be passed to you. If you need a voting ticket, the ushers will give you one, just ask. No voter fraud, please. Okay. Now, here’s the deal. While you’re voting, we will have the closing remarks, two minutes, from each presenter, so we ask for your silence while they finish up, and then of course we will read the results of your voting. So now the final remarks from the panelists, beginning with the side opposing the motion, panelists, please stay in your seats this time around, we begin with Richard Somerville.

### Scientific Advocate (SA)
Claim: You know, the, the fossil fuel age will surely end, sooner rather than later I hope if we’re wise. Sheikh Yamani, the Saudi oil minister was fond of saying “The Stone Age did not end because we ran out of stones.” And continuing to generate 80% of the world’s energy from fossil fuel and using the atmosphere as a free dump for waste products, will ultimately produce a damaged planet. We’ve heard a lot of chatter about decarbonization this evening, the fact is that carbon dioxide emissions in the US and globally are going up, not down. Sherwood Rowland, later a Nobel laureate, was a frustrated person in 1984, because humanity was so slow in dealing with the issue of ozone depletion. He said, quote, “After all, what’s the use of having developed a science well enough to make predictions, if in the end, all we’re willing to do is stand around and wait for them to come true.” Roland’s remark is apt for our topic tonight. As in the case of ozone loss, so with global warming, once again, powerful technology, in this case abundant cheap fossil—

### Moderator
Claim: One—

### Scientific Advocate (SA)
Claim: —fuel energy, with unanticipated side effects, has brought us a Faustian bargain. Once again, the world finds itself at a point where difficult decisions must be made. That’s the definition of a crisis. Nothing to do with alarmism or catastrophe. Once again doing nothing or too little will lead to dire consequences. Belittling the science, attacking the scientists, impugning their integrity and, and competence and motivations, refusing to recognize what we have learned about climate change in the vain and naïve hope that the problem will somehow solve itself is irresponsible. Action is needed, meaningful action, soon. Global warming is a crisis. Thank you. I hope you voted against.

You know, the, the fossil fuel age will surely end, sooner rather than later I hope if we’re wise. Sheikh Yamani, the Saudi oil minister was fond of saying “The Stone Age did not end because we ran out of stones.” And continuing to generate 80% of the world’s energy from fossil fuel and using the atmosphere as a free dump for waste products, will ultimately produce a damaged planet. We’ve heard a lot of chatter about decarbonization this evening, the fact is that carbon dioxide emissions in the US and globally are going up, not down. Sherwood Rowland, later a Nobel laureate, was a frustrated person in 1984, because humanity was so slow in dealing with the issue of ozone depletion. He said, quote, “After all, what’s the use of having developed a science well enough to make predictions, if in the end, all we’re willing to do is stand around and wait for them to come true.” Roland’s remark is apt for our topic tonight. As in the case of ozone loss, so with global warming, once again, powerful technology, in this case abundant cheap fossil—

### Moderator
Claim: Philip Stott, your closing statement.

### Conspiracy Advocate (CA)
Claim: May I say that the last thing I want to do is to demean any scientist. The whole point about science is that it is a constant debate. And actually, what has worried me deeply about this is not the demeaning of scientists but the attempt to close down the debate, and actually take it away from science. If I may use a musical analogy, my other great interest, trying to reconstruct the climates of the moment as we’re talking about is a bit like trying to play Mozart’s wonderful Symphonia Concertante 364, when you’ve no viola part and only a quarter of the violin part. In other words we know remarkably little about so much of the climate that, that we are facing. And, what I would like to stress is, it—it’s a debate on the crisis. We’ve mentioned the crisis of poverty, and I think the crisis of hypocrisy. Actually where I think we probably agree entirely as a panel, what there really is in the world, there’s not a crisis of climate, a crisis of energy. That is certainly true in my country. And I’ll tell you what worries me particularly about attaching it to climate.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: In the world, there are groups, including some very reputable groups in Denmark and in Russia and in other countries, which are predicting actually that we will enter a global cooling phase between 2012 and 2015. Now, I no more necessarily believe that than I do about the global warming. But just supposing that happens, and just supposing what the public reaction is to the hype that there has been about global warming, I actually think that we have to face up to a genuine energy issue in the world, and that most of our politicians are not doing that, in fact they’re dressing it up in this idea of global warming and saving the world, and what we desperately need are very practical decisions about energy, on the ground. And I think the idea of using the climate to do this is potentially a very dangerous one. So, what I am worried about is that everybody is now using the global con— global warming construction for their own agendas. From capitalist carbon trading, right the way to making you wear hemp underpants. I distrust that because in the end—

May I say that the last thing I want to do is to demean any scientist. The whole point about science is that it is a constant debate. And actually, what has worried me deeply about this is not the demeaning of scientists but the attempt to close down the debate, and actually take it away from science. If I may use a musical analogy, my other great interest, trying to reconstruct the climates of the moment as we’re talking about is a bit like trying to play Mozart’s wonderful Symphonia Concertante 364, when you’ve no viola part and only a quarter of the violin part. In other words we know remarkably little about so much of the climate that, that we are facing. And, what I would like to stress is, it—it’s a debate on the crisis. We’ve mentioned the crisis of poverty, and I think the crisis of hypocrisy. Actually where I think we probably agree entirely as a panel, what there really is in the world, there’s not a crisis of climate, a crisis of energy. That is certainly true in my country. And I’ll tell you what worries me particularly about attaching it to climate.

### Moderator
Claim: Philip Stott—

### Conspiracy Advocate (CA)
Claim: —it’s an ism—

### Moderator
Claim: —thank you very much—

### Conspiracy Advocate (CA)
Claim: —and I distrust isms.

### Moderator
Claim: Gavin Schmidt, your closing statement.

### Scientific Advocate (SA)
Claim: Hemp underpants, ugh. Climate change is not a new issue. Even human-cause climate change is not new.

Richard Lindzen was arguing these same points 15 years ago, Michael Crichton is recycling talking points that are decades old. Philip Stott is grasping at extremely flimsy straws. Serious scientists in the 1960s made predictions for what would be found if human emissions of greenhouse gases were to continue. They said the planet would warm. It has. They said the water vapor measurements would show rises. They do. They said that hos— ocean heat content would rise. It has. They said the stratosphere would cool. It did. If I had time I could go on listing the number of challenges this basic idea has faced and come through. But you only need to know that it is still standing, and that there are no coherent theories that fit the observations better. Given that understanding, and the ever-increasing emissions that we are putting into the air, to deny this is a crisis on a planetary scale is truly to fiddle while home burns.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: I’m done.

### Moderator
Claim: That’s it? Richard Lindzen, your closing statement.

### Conspiracy Advocate (CA)
Claim: Yes. I think it’s a little bit difficult to know how to respond, to be told that, uh, one shouldn’t attack scientists while you’re attacking scientists, to go and say you have to control methane without explaining that methane has stopped growing. You don’t explain why there’s global warming on Mars, Jupiter, Triton and Pluto. You don’t look at the ocean data and see, that whereas your boss Jim Hansen was saying that the heating of the ocean proved the flux that he needed for high sensitivity, that in the last year there’ve been two papers in the same journal, that point out that the original Levitus data’s wrong, that the ocean is cool, and that the new numbers would call for one-tenth the sensitivity that Hansen mentioned. If all this is so certain, why is the data changing, or is it a case when the data changes you ignore it, and—

### Moderator
Claim: One—

### Conspiracy Advocate (CA)
Claim: —stick to the point.

### Moderator
Claim: You have a minute, do you want the other minute? You have a minute—no? Uh, okay. Brenda Ekwurzel, your closing statement.

### Scientific Advocate (SA)
Claim: Global warming is here today and is accelerating. Many business leaders are already realizing that it makes economic sense to start fighting global warming. Wal-Mart, DuPont, BP, General Electric, they all are asking for action. And, businesses need a clear signal from the national level. Because they want to have a level playing field, and, they want to plan for the future. And that’s what makes good business sense. We need a national policy because people, cities and states cannot reduce global warming enough to make a significant dent in this issue. Ultimately the atmosphere is gonna register all of our choices from today onward. We must act now because if we leave it to our children, the risk will be too great and it will be too late. Fortunately there already exist solutions, all we—we need now is the will to implement them rapidly. Thank you.

### Moderator
Claim: Michael Crichton, your closing statement.

### Conspiracy Advocate (CA)
Claim: There was a time when I worked in a clinic and, uh, one day a young woman came in, she was in her early twenties for a routine checkup and, I said what’s going on with you and she said I’ve just become blind. And, I said, oh my gosh, really, when did it happen, she said, well just, uh, coming into the clinic, walking up the steps of the clinic I became blind. And I said, oh, and I’m—by now I’m looking through the chart and I said, well, has this happened before, she said yes, it’s happened before. I’ve become blind in the past, and, what she had of course was hysterical blindness. And the characteristic of that, is that, the severity of the symptom is not matched by the emotional response that’s, that’s being presented. Most people would be screaming about that but she was very calm, oh yes, I’m blind again. And I’m reminded of that whenever I hear, that we’re facing, whether we wanna call it a crisis or not, a significant global event, of, of, of importance where we’re gonna have species lost and so on and so forth—

### Moderator
Claim: One—

### Conspiracy Advocate (CA)
Claim: —that we can really address this by changing our light bulbs. Or that we can really make an impact by unplugging our appliances when we’re not using them. It’s very much out of whack. And so if…if it were only gonna do symbolic actions, I would like to suggest a few symbolic actions that right—might really mean something. One of them, which is very simple, 99% of the American population doesn’t care, is ban private jets. Nobody needs to fly in them, ban them now. And, and in addition, let’s have the NRDC, the, the Sierra Club and Greenpeace make it a rule that all of their, all of their members, cannot fly on private jets, they must get their houses off the grid, they must live in the way that they’re telling everyone else to live. And if they won’t do that, why should we. And why should we take them seriously.

There was a time when I worked in a clinic and, uh, one day a young woman came in, she was in her early twenties for a routine checkup and, I said what’s going on with you and she said I’ve just become blind. And, I said, oh my gosh, really, when did it happen, she said, well just, uh, coming into the clinic, walking up the steps of the clinic I became blind. And I said, oh, and I’m—by now I’m looking through the chart and I said, well, has this happened before, she said yes, it’s happened before. I’ve become blind in the past, and, what she had of course was hysterical blindness. And the characteristic of that, is that, the severity of the symptom is not matched by the emotional response that’s, that’s being presented. Most people would be screaming about that but she was very calm, oh yes, I’m blind again. And I’m reminded of that whenever I hear, that we’re facing, whether we wanna call it a crisis or not, a significant global event, of, of, of importance where we’re gonna have species lost and so on and so forth—

### Moderator
Claim: I wanna thank the debaters… and the audience for all your good work. Before I announce the results of the audience vote I wanna take care of a few little things. First, the next Intelligence Squared US debate will take place on Wednesday, April 18th, here at the Asia Society and Museum. The motion to be debated is, “Better more domestic surveillance than another 9/11.” The remaining two debates in this spring series including that one are all sold out. The good news is that packages are available on-line and by phone for the Fall 2007-Spring 2008 series. Priority will be given to full-season subscribers, so avoid disappointment and buy those series packages now. Tonight’s debate can be heard locally on WNYC AM 820, on Friday, March 23rd at 2 p.m. You can also purchase DVD’s from previous debates upstairs in the lobby or on the Intelligence Squared US website. Finally, please be sure to pick up a copy of the Times Literary Supplement—are those actually available, there was some question about that. Is that a—yes, yes, they are available, uh, as you leave the auditorium, and in a minute you can all go home and watch the “American Idol” results show. And now the results of our debate. After our debaters did their best to sway you…you went from, 30% for the motion that global warming is not a crisis, from 30% to 46%. Against the motion, went from 57% to 42%… And “undecided” went from 13% to 12%. The hardcore ambivalent are still among us. So, in terms of opinion change, those in favor of the motion, have carried the day, congratulations to the team for the motion. And thank you all again very much, good night.
