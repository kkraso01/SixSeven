# Debate Transcript

Topic: Two Cheers for Super PACs: Money in Politics is Still Overregulated
Motion: Two Cheers for Super PACs: Money in Politics is Still Overregulated

Debate ID: 091212superpacs


## Round 1

### Moderator
Claim: He is the chairman of the board of the Rosenkranz Foundation and Intelligence Squared U.S. Bob Rosenkranz. And what Bob does is a lot of study. We both do, before the debates, to really figure out the way that we want to frame this. And so Bob is going to do that for us. He's going to talk us through what's at stake here and why we're talking about it now. So, Bob, why now? Why this debate now?

### Moderator
Claim: Well, of course, this is election season, and we're all seeing the effects of huge amounts of money in politics. So this is really a debate that is timely and especially pertinent following the Supreme Court decision in Citizens United, which created the whole super PAC phenomenon.

### Moderator
Claim: And is this a debate that really has two valid arguments on both sides?

### Moderator
Claim: I think it does.

### Moderator
Claim: So the side that's cheering for super PACs, what do they have going for their argument?

### Moderator
Claim: The biggest thing they have going for their argument is the principle of free speech.

In order for speech to be heard, it needs money behind it. And the most important kind of speech of all is political speech. And critical political speech is essential because otherwise Congress or the president could shut down speech that's critical.

### Moderator
Claim: And the side arguing against?

### Moderator
Claim: Their best argument it seems to me, is that things have gotten out of hand. There's just too much damn money involved in politics, and we're drowning out the voices of people who can't be heard because they don't have access to money to get on the airwaves.

### Moderator
Claim: And one thing the Citizens United decision changed in 2010 is increased participation by corporations and unions. How does that change the game?

### Moderator
Claim: Well, I think that the unions have always been a source of very, very big money in politics and almost always on the Democratic side, probably 98 percent or so.

Corporations, on the other hand, have been divided pretty equally between Democrats and Republicans, in part because they want to hedge their bets, and in part because they don't want to offend any of their customers. So in some sense, this legislation-- I'm sorry, court decision, really opens the door not so much for corporations but for wealthy individuals.

### Moderator
Claim: All right, Bob, thank you very much again for making this event happen. And now let's welcome our debaters to the stage, everybody. Thank you. And I just would like to invite one more round of applause for Bob Rosenkranz for making this possible. Deep and durable and well-known by all of us is the influence and place of money in American politics. If you go to that famous quip by one of the all-time politicos of American history, Mark Hanna, an Ohio Republican, this is what he said: "There are two things that are important in politics. The first is money. And I can't remember what the second one is." Hanna died in 1904. He did not have super PACs. But we do, and we have a debate. "Two Cheers for Super PACs: Money and Politics is Still Overregulated," that is our motion. I'm John Donovan, a debate from Intelligence Squared U.S., four superbly qualified debaters, two against two, all of whom have grappled with the question of where money fits into a system that we refer to as democracy.

We debate, as always, in three rounds. Then the audience votes to choose the winner. And only one side wins. Let's meet our debaters. Let's meet our debaters. On the side for the motion, "Two Cheers for Super PACs," David Keating, president of the Center for Competitive Politics. Your partner is Jacob Sullum. He is a senior editor at Reason Magazine. On the side arguing against the motion, Trevor Potter. He is president and general counsel of the Campaign Legal Center. And your partner is Jonathan Soros. He is a senior fellow at the Roosevelt Institute and cofounder of Friends of Democracy. going to introduce our debaters once again in more depth for our television broadcasts. And I know you just applauded your hearts out for them. But when I name them again, I'm going to ask you to do that one more time. Thank you. Our motion is "Two Cheers for Super PACs: Money in Politics is Still Overregulated." Let's meet our debaters and welcome first, David Keating. And, David, earlier this year, you became president of the Center for Competitive Politics. It represented a group that you also founded in a landmark case that was SpeechNow.org versus the Federal Election Committee. Citizens United gets most of the credit for the fact that we have super PACs. But without SpeechNow, we would not have them at all. And in addition to that involvement, you also spent a lot of time in your career working on tax policy. So the question is, which is the more twisted set of legislation: campaign finance or tax policy?

### Conspiracy Advocate (CA)
Claim: Well, that's simple. The election laws. The tax laws are a model of clarity and simplicity.

### Moderator
Claim: By comparison.

### Conspiracy Advocate (CA)
Claim: Yes. And the IRS is reasonable compared to the Federal Election Committee.

### Moderator
Claim: All right. Thank you, David Keating. Your partner, arguing for the motion, "Two cheers for super PACs," Jacob Sullum. Jacob, you are a senior editor at Reason magazine where the motto is "free minds and free markets." You are also the author of "Saying Yes: In Defense of Drug Use." Jacob, you graduated from Cornell University where you majored in both economics and psychology, psych and ec. And the question is, is that what equals a libertarian?

### Conspiracy Advocate (CA)
Claim: I did learn a lot about politicians in my abnormal psych course.

### Moderator
Claim: All right. Our motion is "Two Cheers for Super PACs: Money and Politics is Still Overregulated." Here arguing against the motion first, Trevor Potter. Trevor, you are president and general counsel of the Campaign Legal Center and a former commissioner and chairman of the federal election commission. But you may also know Trevor as the man behind Steven Colbert's super PAC, Americans for a Better Tomorrow Tomorrow. You are an attorney, and you've advised several Republican presidential candidates. So how did you end up on comedy central?

### Scientific Advocate (SA)
Claim: I answered my phone.

### Moderator
Claim: Easy enough. It could have been a pollster.

### Scientific Advocate (SA)
Claim: Steven Colbert called, said, "Can you explain what a Pac is?" I laid it out, explained how to game the system. He said, "Are you willing to say that in public?"

### Moderator
Claim: All right, I-- thanks, Trevor Potter. And let's meet your partner, also arguing against super PACs, Jonathan Soros. Jonathan, you are a senior fellow at the Roosevelt Institute and CEO of JS Capital Management.

You are also one of the cofounders of Friends of Democracy. And a Washington Post headline about this says it all: "Son of liberal financier George Soros launches anti-super PAC super PAC." So how does that work?

### Scientific Advocate (SA)
Claim: Well, we're never going to change any of these rules unless we can build some political power to do so. And right now both political parties are locked into the status quo. And so the only way to do so is from the outside.

### Moderator
Claim: So working from the inside. All right, thank you. Ladies and gentlemen, our team of debaters. Now, this is a debate. It's a contest. One side will win, and one side will lose. And in that debate, you, our audience, our live audience, act as the judges. By the time the debate is ended, you will have been asked to vote twice; once before the arguments and once again at the end. And the team whose numbers have moved your position, your vote on this proposition, the greatest, will be declared our winner.

So let's register your first vote. Go to the key pads at your seat. On the right hand side, and the numbers one, two and three are the only ones you need to worry about. Our motion is "Two Cheers for Super PACs: Money and Politics is Still Overregulated." And if you agree with this motion, push number one. If you disagree, push number two. And if you're undecided, push number three. You can ignore the other numbers. They're not live. And if you make a mistake, just correct yourself, and the system will lock in your last vote. And what we're going to do is hold that vote until the end of the debate when you vote the second time. And then we'll reveal both numbers. And the team whose numbers have moved the most on this motion will be declared our winner. So onto round one, opening statements from each of our debaters in turn. They will be seven minutes each.

And speaking first up for the motion, "Two Cheers for Super PACs: Money and Politics is Still Overregulated," David Keating. He is president of the Center for Competitive Politics. Before this, he was executive director of the Club for Growth and president of SpeechNow.org, an organization that he founded to protect free political speech. Ladies and gentlemen, David Keating.

### Conspiracy Advocate (CA)
Claim: Well, thank you. I think largely what we have tonight is a debate about the First Amendment and what it means and whether we still value the First Amendment. Do we want to keep the First Amendment the way it was written, or do we want it to say something else? And who will say what that "something else" is? First, let's review what it says. It's pretty simple actually. The part that we're talking about tonight is Congress shall make no law abridging freedom of speech. Well, I'm sorry to inform that we have a lot of laws abridging freedom of speech and regulating speech.

The Supreme Court has said there are now 30 different types of regulations on political speech. We have laws and regulations that come to-- close to 400,000 words. But these words are not clear enough so the Federal Election Commission has already issued close to 1,900 advisory opinions that you must review to know what the law means. And on top of that, there have been nearly eight-- 7,000 enforcement actions by the Federal Election Commission during its history. To really understand the law, you need to understand all that. And the fact is no one does understand what the election law means. In fact, if you want to speak out about politics and elections you have to hire a lawyer like this one over here. I don't know how much he charges, but most grassroots groups probably can't afford it.

And if they don't have a lawyer, they're probably going to make mistakes. I lived under this, working at a political committee. I saw the regulations firsthand, and we-- a lot of this we're getting very upset with how complicated it was and the fact we couldn't get an answer to many of our basic questions. On top of that, in 2002 Congress passed the McCain-Feingold Act, and for many of us that was the last straw. A portion of that-- not all of that law was bad, but there was one portion that many of us found offensive no matter what our views on politics. Part of it said that within 60 days of an election, a group that you were a member of could not run an advertisement mentioning the name of a congressman if it aired on radio or TV. That was illegal.

Now, the court has overturned that, but it took them a number of years to do that. I thought that was outrageous. And there is no group fighting on the political front for the First Amendment.

We hear about groups fighting for Second Amendment rights but not First Amendment rights. That's why I started SpeechNow.org because I think we need a group to fight for our political free speech rights. Now, I designed this group in a way that I thought would allow us to be effective. In fact, one of our panelists who doesn't support free speech-- unfettered free speech has adopted the SpeechNow.org model, which is now called a super PAC. And basically here's how it works. It's Americans getting together and pooling their money. I talk to you. I make the case as to why you should donate money, so then we can talk to other Americans. That's what the SpeechNow model was. There was only one problem with it. It was illegal to do that. So the SpeechNow.org with the assistance of a couple of public interest law firms sued the FDC, to make a long story short, we won.

That case, SpeechNow.org versus FDC, is what created the super PAC. Now, let me explain how these groups are actually functioned, because these are different from normal PACs. These are different from political parties. These are literally Americans getting together independently. The Federal Election Commission calls these groups "independent expenditure only committees" because that's all they can do. We don't make any donations to candidates. We don’t make any donations to political parties. We don't coordinate our speech with the candidates. We don't coordinate our speech with the political parties. All of our donors over $200 are disclosed to the public on the Internet on the FDC website. And all of our spending is donated-- is reported as well. That is what the media has come to call a "super PAC."So when you think about it, what's wrong with that? It's basically a group of people getting together and saying, "Hey, we want to speak to our fellow Americans about what direction we think the country should go, what leaders we should elect, who should represent us, and we're not going to give any money to the candidates or the parties." That's what a super PAC is. Now, this model has been so popular that there are now 805 of them that have formed since June of 2010 when super PACs first became legal.

Now, I want to tell you a story of how important money can be in making speech. And I will go back to 1967, when a U.S. senator named Gene McCarthy wanted to run for president. The incumbent president, Lyndon Baines Johnson, was a very powerful political figure. Today most people would think it'd be impossible to take down a sitting president in a primary, especially if you started in November previous to the election year.

But Gene McCarthy did it. And you know how he did it? He went to a handful of people, about five people, and they gave the equivalent in today's dollars of $10 million, $10 million.

Now, that's the kind of money that we're talking about in super PACs, but back then, the money went directly into Gene McCarthy's campaign committee. Gene McCarthy was opposed to the Vietnam War. He wanted to make his run for president based on opposing the Vietnam War. And he wanted to help build a movement to help end the Vietnam War. He couldn't have done it without those contributions. He couldn't have done it. And you know what? He did it. He didn't win the nomination, but he forced LBJ out of the race. And it's the only time since-- since we've passed these campaign restrictions, we have never seen a sitting president removed by a challenger.

And I daresay it probably won't happen for many, many years. So if you believe in the right of the people to change their government, we have to give people the right to do everything they can to speak to other Americans. And independent political groups are the way to do it. Thank you.

### Moderator
Claim: Thank you, David Keating. Our motion is, "Two Cheers for Super PACs: Money in Politics is Still Overregulated." And here to debate against the motion, Trevor Potter. He is president and general counsel of the Campaign Legal Center and a former commissioner and chairman of the Federal Election Commission. He is also the lawyer behind the creation of Stephen Colbert's PAC, Americans for a Better Tomorrow Tomorrow. Ladies and Gentlemen, Trevor Potter.

### Scientific Advocate (SA)
Claim: Thank you, John. may surprise our worthy opponents, but all of us on the stage tonight recognize and celebrate the importance of the First Amendment, the right each of us has as citizens to criticize the government and speak freely. We are all American patriots in this room tonight, not supporters of King George III. None of us believe that the crown, or our government, should be free of criticism. But our opponents want this to begin and end as a debate about the First Amendment, and only about their view of the First Amendment. They want to ignore the rest of the Constitution and the functioning of the government that we the people created. The Constitution created a congress that represents the will of the people, the voters.

It created a president whose job is to faithfully execute the laws passed by Congress. What we have learned over the last 200 years, by sad experience, is that our government can be corrupted by campaign money so that it primarily responds to the sources of money that fund elections-- special interests and big political contributors and spenders-- rather than representing the people and seeking the common good.

So tonight I'm going to look at how campaign money can corrupt our government and why, for 100 years, there have been limits on money spent in politics to try and control that corruption. Then, my debating partner Jonathan Soros will explain why super PACs and their related nonprofit C4s and C6s only make the possibility of corruption greater.

Theodore Roosevelt began this national discussion in 1905 after being elected president with huge contributions from Wall Street. He actually had Mark Hanna. And Mark Hanna had what we would call super PAC money, unlimited contributions from corporations that elected Roosevelt. Afterwards, those corporations came to him for their reward which they expected would be less government regulation. Roosevelt responded by saying to Congress, "All contributions by corporations to any political committee or for any political purpose should be forbidden by law. Directors should not be permitted to use stockholders' money for such purposes." Later, he said, "Every special interest is entitled to justice, but none is entitled to a vote in Congress to a voice on the bench."Congress reacted to Roosevelt's call by passing the Tillman Act in 1907 forbidding corporate political contributions in federal elections. Later in 1947, the Taft Act extended this prohibition to labor unions and to independent expenditures. Roosevelt and the Congress believed that the election of representatives of the people to Congress should be left to individual citizens and voters, not corporate or union interests almost always seeking special legislative favors in return. Under President Richard Nixon, these prohibitions were violated because of a lack of disclosure. Then in the Watergate scandal, these hidden violations became public. We learned that the Department of Justice had dropped an antitrust case against ITT in return for $400,000 given to finance the Republican convention where Nixon wanted it.

We might never have known that except an ITT lobbyist wrote it all down in an internal memo which then saw the light of day. The result was that after Watergate, Congress passed new reform laws and tried to require the disclosure of all money given for political purposes. These laws were later revised and strengthened in the McCain- Feingold law in 2002. As Senator Alan Simpson said at that time, too often members' first thought is not what is right or what they will believe, but how it will affect fundraising. Who, after all, can seriously contend that a $100,000 donation does not alter the way one thinks about and quite possibly votes on an issue? The goal of each of these laws was to prevent actual corruption, the selling of government action or inaction in return for financial support for candidates and campaigns.

Just as important, though, has been the goal of avoiding the appearance of corruption. As the Supreme Court said in the Buckley case in 1976, Congress has the right to deal with the reality or the appearance of corruption inherent in the system, permitting unlimited financial contributions. The Supreme Court also recognized one other reality in that case which is central to our debate today. There is a significant difference between my speaking myself or giving my money to someone else for their speech. My own speech and my own words has higher First Amendment protection than a contribution. That brings us to the world of super PACs.

They were created, as we heard, by the Supreme Court Citizens United decision and the DC circuit's SpeechNow case. The majority in Citizens United, overturning previous decisions, said that in their view of the First Amendment, corporations had the same right as individuals to make unlimited, independent expenditures in federal elections because such spending does not give rise to corruption or the appearance of corruption. The court based this new somewhat novel view that independent spending can never corrupt on two important predicates. The spending must be totally independent of candidates and political parties, and it must be fully disclosed so that in the words of Justice Kennedy and Citizens United, the public can see whether elected officials are in the pockets of so-called money interests.

So are their spending totally independent of candidates? Do we have full disclosure? Jonathan Soros will tell us in a few minutes.

### Moderator
Claim: Thank you, Trevor Potter. And a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two who are fighting it out over this motion: "Two Cheers for Super PACs: Money in Politics is Still Overrated"-- you have-- sorry. Not overrated. I'm going to say that again so that-- so that that can be edited out. It's great to control the process. "Two Cheers for Super PACs: Money in Politics is Still Overregulated." You have heard two opening statements, and now onto the third to debate for the motion: "Two Cheers for Super PACs," a senior editor at Reason Magazine and reason.com, an award-winning journalist and author of the critically acclaimed books, "Saying Yes," and "For Your Own Good," Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: Thanks. I feel a little bit under qualified for this debate because I think I'm the only panelist who has not created a super PAC. Although I briefly contemplated starting an anti-anti-super PAC super PAC. It seemed too complicated to me, but maybe Trevor could help me out. So I'm talking instead from the perspective of somebody who has been writing about civil liberties issues for about 25 years now. And I see this as fundamentally an issue of freedom of speech. Consider the legal situation before the Citizens United case. Wealthy individuals were free to speak without limit. Jonathan's father, for example, spent about $24 billion during the-- or excuse me, million dollars during the 2004 election season to defeat George W. Bush. And more power to him.

Media corporations such as the ones that own FOX news and the New York Times were also free to speak without limit. Parties and candidates could spend as much as they wanted on political messages, although the contributions for them were limited. By contrast, unions, businesses and nonprofit advocacy groups such as the NRA or the ACLU, could not talk about their issues on the air close to an election if they happen to mention the name of a candidate for federal office. Furthermore, as David mentioned, people of lesser means could not get together and pool their resources to use for election-related messages unless they registered with the FEC and were subject to strict contribution limits. People often overlook what was actually at issue in the Citizens United case. This was a documentary that was produced by a conservative group, Citizens United. It was called "Hillary: The Movie." They wanted to air it during the 2008 election season, and they were prohibited from doing so. Why? First of all, it mentioned a candidate for federal office. She was running for the Democratic presidential nomination at the time.

And two, it made her look bad. Now, whatever you think about Hillary Clinton or about this particular movie about her, how can that possibly be consistent with a constitutional provision that says "congressional shall make no law abridging the freedom of speech"? The Supreme Court concluded that it could not. And it also concluded that the First Amendment made it-- forced it to override an earlier rule that said you cannot engage and express advocacy if you are a corporation or a union, meaning you explicitly were advocating the election or defeat of a candidate. You frequently hear a couple of arguments in response to this decision from people who didn't like it. First of all, they say, money is not speech. Well, that's literally true. But you do need money in order to get your message across to a mass audience. So I suppose Congress passed a law saying newspapers can exist, but they can't spend any money. Or newspapers can exist, but they can only spend up to this amount of money. Clearly, that would be abridging the freedom of the press. Similarly, if Congress said, you can spend as much as you want if you're a newspaper, but we're going to limit how much you can take in from advertisers and readers.

So once you understand that this is really controlling-- money in effect is controlling speech, I think you also have to recognize that loosening these regulations on speech does not mean empowering people to buy elections. Why? Because the messages that you pay for still have to persuade voters. You're still talking about convincing people to vote a certain way. There are a number of striking illustrations from recent elections that show you that money can't buy you love. And I'll just give you a couple of them. One from 2010, Linda McMahan is trying again this year. She spent $46 million of her own money on a Senate campaign in Connecticut. It was nearly a hundred dollars for every vote she received. She lost by 12 points. This year, Jeff Lake won the Republican nomination for the Senate in Arizona. Even though he was outspent two to one, he won by 48 points. So clearly, money is not the whole story.

It is, nevertheless, true that in general, the people who win tend to spend more. But it's also true that stronger candidates tend to attract more money. Well, what makes a candidate strong? There are various characteristics that you can imagine that would make people both better able to raise money and better able to get votes, charisma, popular policy positions, but one of the most important is incumbency. And incumbency gives people tremendous advantages in terms of visibility, the power to dispense pork, name recognition, and the reelection rates for members of Congress are insanely high. I mean, historically, in the past few cycles, 90 percent or more even in the last-- in the 2010, when Democrats lost a bunch of seats, it was still about 85 percent. So incumbents have this huge advantage and they use campaign finance regulations to reinforce that advantage. One great example is the so-called Millionaires Amendment, which was part of McCain-Feingold Act. It said that if you face an opponent who is spending his own money, he's financing his own campaign, then we're going to lift the limits on the contributions you can get.

So this is clearly designed to help out incumbents who are facing self financed challengers. Another argument you often hear is that corporations are not people. Well, that's also literally true, but corporations are created by people. I mean, they're not created by robots or dolphins or extraterrestrials. I mean, they're created to achieve certain goals. The question in Citizens United was whether people lose the right to freedom of speech when they organize themselves as corporations. I think people tend to think when you hear the word "corporation" of these huge businesses like Wal- Mart or Exxon Mobile, but, you know, every one of us works for a corporation. This debate tonight is sponsored by a corporation. The groups that are complaining that corporations have too much influence over politics are themselves corporations, right? So you have to understand that corporations overwhelmingly consist of small businesses and nonprofits, not these huge businesses. And they represent all sorts of points of view and take on all sorts of issues.

Our moderator, by the way, works for a corporation, Walt Disney Company, correct?

And he had this privilege before Citizens United that most corporations did not, they were allowed to talk about politics on the air even if it meant mentioning a candidate for federal office. Now, that was an exemption, a media exemption for media corporations, that journalists took for granted, but it's very hard to justify under the First Amendment because when you talk about the freedom of the press you're not talking about the freedom of members of professional news organizations, you're talking about the freedom to use technologies of mass communication. That's a freedom that we all have that's guaranteed to all of us by the First Amendment. So by lifting the restrictions on the money that people could collect and spend on political messages, these two decisions, Citizens United and SpeechNow, signal that freedom of speech is not a privilege that's reserved to billionaires or to media corporations or to politicians, it's a right that belongs to all of us no matter how we choose to organize ourselves.

And I think we're seeing benefits from that in terms of diversity of voices and greater competition in elections that we can talk about later. Thank you.

### Moderator
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: And he had this privilege before Citizens United that most corporations did not, they were allowed to talk about politics on the air even if it meant mentioning a candidate for federal office. Now, that was an exemption, a media exemption for media corporations, that journalists took for granted, but it's very hard to justify under the First Amendment because when you talk about the freedom of the press you're not talking about the freedom of members of professional news organizations, you're talking about the freedom to use technologies of mass communication. That's a freedom that we all have that's guaranteed to all of us by the First Amendment. So by lifting the restrictions on the money that people could collect and spend on political messages, these two decisions, Citizens United and SpeechNow, signal that freedom of speech is not a privilege that's reserved to billionaires or to media corporations or to politicians, it's a right that belongs to all of us no matter how we choose to organize ourselves.

And I think we're seeing benefits from that in terms of diversity of voices and greater competition in elections that we can talk about later. Thank you.

### Moderator
Claim: Thank you. Thank you, Jacob Sullum. Our final debater, and he is speaking against the motion, "Two Cheers for Super PACs: Money in Politics is Still Overregulated," is Jonathan Soros. Jonathan is chief executive officer of JS Capital Management and a senior fellow at the Roosevelt Institute and cofounder of the super PAC, Friends of Democracy. Ladies and gentlemen, Jonathan Soros.

### Scientific Advocate (SA)
Claim: Thank you. I can see that we're going to have a lot to talk about tonight, but my partner, Trevor Potter, laid out the case for why in response to the First Amendment we still have an important interest in mitigating the corruption that can result from even independent political activity but from in particular from contributions to candidates. I'm going to take us on a closer look at the proposition, itself, "Two cheers for super PACs," and suggest that we don't even have the rules that super PACs were premised on.

Mr. Keating laid out a very rosy picture of what super PACs are, but that doesn't really resemble what they are in fact. After 40 years of Supreme Court intervention, what we have is more loophole than law. Let's start with the issue of independence. As my partner mentioned, the Supreme Court has repeatedly said that speech that is independent of campaigns can't be corrupting, and, therefore, can't be restricted. Let's set aside for a moment how ridiculous that statement is, that if somebody showed up and said, "I'm going to spend a billion dollars to support candidates who favor position X or position Y," that that's not going to have some influence on candidates or elected officials. We'll leave that aside for a moment and just look at what "independent" really means today because the rules around what independent is for super PACs are basically nonexistent. There are in effect only two rules that apply.

One, candidates may not share inside information from what they're thinking and what their resources are with a super PAC, and the super PAC may not give a contribution directly to the campaign. Obviously, they can give lots of things of value indirectly, like spending lots of money on television. There are more rules about what Goldman Sachs' partners can say to each other than there are about what super PACs can say to candidates. We've all seen the jokes that this leads to. My partner's super PAC, Americans for a Better Tomorrow Tomorrow, has been referenced several times. It's one of the best pieces of political theater that has happened in the last 24 months. I would strongly suggest, if you haven't seen it, you go online and find it. It's really funny.

But what we're seeing in that-- and they've provided a tremendous example-- is that there are, in effect, no lines between super PACs and candidates. Let's just give a couple of examples. Candidates can raise money for super PACs. They can show up at their fundraisers, and they can raise money, at least up to the $5,000 federal limit.

But then what happens after they leave? Who knows? We all know, at least in the presidential election, the super PACs are being run by long-term aides of the candidates, in both instances. Candidates can endorse super PACs. You hear Mitt Romney talking about "my" super PAC. And just in the last couple of weeks, since we've watched the conventions, we heard about Karl Rove, who, of course, was senior advisor to President Bush and to many other Republicans, getting briefings about his super PAC around Tampa. And last week in Charlotte, Rahm Emmanuel, who had been, at one time, White House chief of staff, and was the honorary chairman of the Obama campaign, left that position and the next day was giving interviews on the floor of the convention about how he was now tapped to be the lead fundraiser for the Obama-aligned super PAC. So, clearly, independence under the current rule is a joke. That, in effect, leaving aside what's happened in the super PAC, has undermined something we thought we had before.

We thought we had contribution limits, again, as my partner described, for very good reason, to avoid the issues of political corruption that come with large contributions to candidates. Now, those rules still technically exist. You can still only give $2,500 to a candidate. You can only give $25,000, or whatever the limit is, to a party. But you can then turn around and give $25 million to a super PAC that's working, essentially, as a surrogate for the campaign. Though, let's remember that those $2,500 and $25,000 are irrelevant to most of the population anyway. It's only 1 percent of 1 percent of the population that's giving north of $10,000 a year to those entities. Well, now, with super PACs, we've seen that shrink even further. So 200 people account for 80 percent of the money that was raised for Super PACs, at least as of the last filing.

Lastly, let's talk about transparency. It's true; super PACs do have to disclose their donors and their expenditures.

Transparency is something that the Supreme Court speaks glowingly of in Citizens United and other cases. But there's a loophole that you can drive a billion dollars through, right? You don't have to give your political money to a super PAC. You can give your political money to a so-called social welfare organization, or corporations can give them to industry groups, and those can do almost exactly the same thing as super PACs can do, and they don't have to disclose their donors. So when people say, "How much money is being spent in this election?" the answer is, "We actually don't really know." We know that it will be more than ever before, but we don't know exactly how much, and we don't know exactly where it's coming from.

These are problems that can be addressed. We can have rules on transparency that address disclosure of all political spending that's related to the election. We can have rules, coherent rules, around independence that require that super PACs are at least an arm's length distance from the campaigns.

We need a functioning enforcement agency, and I hope that we'll have a chance to talk a little bit about the dysfunction of the FCC later on. But none of this will make a difference without an alternative. A friend of mine likes to say that transparency alone is like the webcam that was at the bottom of the Gulf of Mexico showing us the Deep Water Horizon well, right? Shows you everything that's spewing into the Gulf, but it doesn't do anything to fix it. We need an alternative. We need a system of citizen- funded elections that allow candidates to run for political office without dependence on large contributions and big donors. That's commonly known as public financing, but when you think about it as a system that is designed to change the incentives of candidates, then it becomes something slightly different. If you think about a system we have in New York where, if you're participating in the system, $175 contribution is matched six-to-one. What's the result?

It's transformed the way that funds are raised for city offices here in New York. Instead of going to the Plaza or the Waldorf, you're going to people's living rooms and dining rooms talking to normal folks, constituents about what the interests of their community are. So if the premise of this debate had been "money and politics is badly regulated," I would have happily switched sides and sat over there and argued that case. But the answer to the current lawlessness is better rules, not less of them.

## Round 2

### Moderator
Claim: Thank you, Jonathan Soros. And that concludes round one of this Intelligence Squared U.S. debate. Now we move on to round two. And round two is where the debaters address one another directly and take questions from me and you in the audience. Our motion is this: "Two Cheers for Super PACs: Money in Politics is Still Overregulated." We have two teams of two arguing it out.

David Keating and Jacob Sullum are arguing for Two Cheers. They say that in a world where political speech depends on money, you don't want to put limits on either of those things; that, in fact, super PACs and spending of money in politics has the effect of extending and widening political discourse and that attempts to regulate it usually are instigated by politicians who are already sitting in office and don't want their competition to be financed and elected either.

On the other side, Trevor Potter and Jonathan Soros are making the argument against super PACs. They're saying that unlimited money puts people into office who are then beholden to the suppliers of the unlimited money. The larger the amount, the more beholden that they'll be, especially if the source of the money is secret. They say that what's needed is a better and saner system of regulation, but that regulation, there must be. I want to put a question to the side that is arguing for super PACs. Your opponents have really hammered at the theme that money is corrosive in politics, essentially that votes can be bought.

And I didn't hear in your statements from either of you that you are especially agitated about that phenomenon. David Keating.

### Conspiracy Advocate (CA)
Claim: Well, there is really no evidence that votes can be bought. The voters still-- No, come on. We-- out of 58 candidates who used 500,000 or more of their own money in federal races in 2010, fewer than one in five won. So my point is simple: That money does not control the outcome of the election. I'm not saying money isn't important, but it's just one factor. I do also want to point out a lot of what you just heard from Jonathan is just simply wrong about the regulations. He said, for example, we don't know how much is spent in the election. That's simply not true.

Any independent expenditure that is run in the election needs to be reported to the Federal Election Commission. That is a law. Now, you can argue about whether people are abiding by the law or not. But they-- I think, by and large, people are reporting their independent expenditures.

### Moderator
Claim: All right, let me--

### Conspiracy Advocate (CA)
Claim: Now, there are other things, perhaps, that are not--

### Moderator
Claim: Let me let you come back to some of the points because you are raising a couple of things that I want to let this side respond to. And the first of those is your response to my question that, yeah, money is necessary, money plays a part, but that money ultimately isn't nearly as corrosive as your side has been talking about. It's not that bad a problem. Take that, Trevor Potter.

### Scientific Advocate (SA)
Claim: Well, we're talking about two things. David's talking about whether you can guarantee you're going to win an election if you spend a lot of your own money. That's-- we're not saying that. What we're saying is that we have a history in this country. It's human nature that candidates who become office holders are going to be grateful to the people who put them there if they can identify somebody who spent an enormous amount of money to elect them.

They are going to feel beholden to them rather than everyone else.

### Moderator
Claim: So with that clarification, let me bring that back to this side, Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: Yeah. I mean, actually, it often goes unnoted that in most states it was perfectly legal for corporations and unions to spend money on political campaigns even prior to Citizens United, and there's no evidence that the states that allowed unlimited spending by unions and corporations were more corrupt than the states that didn't. You would expect there to be some evidence if it's the case that money is corrupting. That doesn't seem to be the case. I mean, it seems commonsensical that obviously money buys people's votes. But in fact if you look at the research that's been done, there's very little evidence that legislators are actually driven by the campaign donations they're receiving as opposed to their party's interest, their constituents' interests, things that might appeal to the voters who elected them.

By the way, I find a lot of that, at least as troubling as selling your vote for money. I think that is something to be concerned about, selling your vote for money. But I think we should be more focused on the actual policies being introduced by politicians. And if they're good policies for bad reasons, I prefer that to bad policies for good reasons. So, you know, for a politician to do something like take other people's money from around the country and spend it on some pork barrel project in his district and then go to brag to voters about this and say, "Reelect me. Look how great I am," he's basically stealing other people's money from around the country and using that money to buy the votes of the voters. And to me that's at least equally troubling.

### Moderator
Claim: So the side arguing against the--

### Conspiracy Advocate (CA)
Claim: Perfectly legal though.

### Moderator
Claim: Your opponents are saying that there is no evidence that in fact politicians will be influenced in office by contributions from donors as they were running for office. Jonathan Soros or Trevor Potter, do you want to take that on?

### Scientific Advocate (SA)
Claim: So maybe just very quickly first, without getting-- I think we could get into a very technical debate. But issue advertising is not disclosed.

There's a lot of that going on this summer. It doesn't flow through independent expenditure committees, and so it doesn't get disclosed. So in the aggregate, we actually don't know the answer. So I don't think we want to get bogged down on that. I think one of the things we should think about here is the definition of corruption in the first instance. And because we're not only talking about buying a vote, that there's actually a deal that says, I'm going to hand you this money, and you're going to vote this way. We're talking about, A, that does-- that is an issue that can be prosecuted. It doesn't happen--

### Moderator
Claim: Can I step in, just to the bottom and I will let you continue. But they're saying there really is no evidence that-- there really is no evidence that politicians will perform in office according to how they were funded on the way to office.

### Scientific Advocate (SA)
Claim: Well, what they said was there's no evidence of corruption. That would be a great surprise to all those people sitting in jail across the country because they were the subject of FBI stings where they took money for official action. There are people in a variety of state legislatures.

There're members of Congress who have freezers full of cash because they took--

### Moderator
Claim: Okay, but that's not--

### Moderator
Claim: Those are direct bribes. Those are not campaign contributions.

### Moderator
Claim: Yeah, he's got you. That's--

### Moderator
Claim: Those are two different things.

### Scientific Advocate (SA)
Claim: Actually, you know, a couple weeks ago, the governor of Alabama was returned to jail for having taken a campaign contribution and then given someone an official appointment for it. I'm not saying everyone does this. I'm saying two things: First, it definitely has happened across the country and in our history. There is a long series of affidavits in the McCain-Feingold litigation and testimony from members of Congress and, not surprisingly, former members who feel freer to speak about it saying, I see votes affected all the time by where the money came from, which industry was being affected. And that's the underlying corrosive problem, plus the amount of time that these members spend, which is now estimated at up to 70 percent of their working days raising money.

Those are the problems we face.

### Conspiracy Advocate (CA)
Claim: We're talking about a couple of different things here.

### Moderator
Claim: David Keating.

### Conspiracy Advocate (CA)
Claim: What we're talking about here is the ability of Americans to get together as-- in groups together to speak to each other and to speak to other Americans. And you can't point to a single member of Congress, to a single independent expenditure where they have felt this kind of pressure. It hasn't happened. And it's not going to happen. Now, we can argue about the rules we may need to ensure the independence of these groups. But we think these groups should be able to independently raise as much and speak as much to the American people. The difference between Americans getting together and speaking to other Americans is one thing. Americans and contributing directly to candidates may be a separate issue.

I'd also like to point out that before the SpeechNow decision and the Citizens United decision, there were many states, in fact a majority of states in the country that allow unlimited contributions not only to independent expenditure committees but to the candidates themselves. I think what we should be looking at is the quality of the government in those states. And Pew, along with Governing Magazine, Pew Charitable Trusts and Governing Magazine, rated the states for quality of governance, efficiency of providing services. And the states, six of the best managed states in the country were states where there were unlimited contributions allowed to these types of super PACs, and most of these states also allowed unlimited contributions to the candidates. So good government, efficient government is consistent with people having full free speech rights.

### Moderator
Claim: All right, so two attacks have been made on your argument that money is corrupting. Number one, they said there's no evidence that politicians are-- once in office are arguing--- are operating as agents of the people who funded them, and, secondly, that there is superior or equally good government in states that have unlimited contribution.

### Scientific Advocate (SA)
Claim: So let's--

### Moderator
Claim: Jonathan Soros.

### Scientific Advocate (SA)
Claim: --go back to the first one for a second. I think in the first instance, I think Mr. Keating is fighting yesterday's battle as it relates to whether groups are allowed to gather together and form super PACs. They are. The question is should there be rules around that and what should those rules be. Our principal argument in ours is that those rules are virtually nonexistent now, and that's a real problem. You're suggesting that there is no evidence of independent expenditures corrupting. I would say we're at the early stages. This is kind of like the year after they invented television, we're looking at television ads, right? We're seeing the first wave of these independent expenditures, and so not clear that that's true, but we're actually not even arguing that, that shouldn't happen, we're not arguing that people shouldn't be allowed to come together in groups and speak in a collaborative voice, in a collective voice.

We are arguing that if the evidence presents itself that that is, in fact, corrupting, that you might want to go back and consider regulating that activity as well, but what we are saying is that the rules around independence and separation from the candidates are clearly not there.

### Moderator
Claim: Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: Could I just ask just a quick question? So do we now have unanimous agreement on the panel that super PACs should be permitted-- are we all in agreement on that? That would be great, because then--

### Scientific Advocate (SA)
Claim: What we just said was that we are starting the first year of this wave of money in federal elections. We don't know yet what the effect is going to be.

And what Jonathan just said was, "If we find out that they have the same corrupting potential that contributions have been found to have, found by the Supreme Court to have, based on lengthy trials, that then they, too-- we will have to look at whether they should be limited." One of the things that the court did, as I explained in my opening comment, is to say there's a difference between our own independent speech and a contribution to something. The Supreme Court has never faced this question of what happens when you take your own money and you contribute to one of these super PACs and somebody else then decides how to spend the money and what to do on the advertising, is that really your own independent speech which the court has said can't be limited, or is that a contribution to a group, and they have found contributions can be limited to prevent the demonstrated danger of corruption.

### Moderator
Claim: Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: I think there's-- there's a problem here with the definition of "corruption." I mean, if you take a very broad definition of it, it's basically any inappropriate consideration, right, that causes you to vote a certain way.

Well, some of it is actual quid pro quo corruption where you hand the guy a pile of cash and you say, "Vote my way," and that's definitely illegal, if you can prove it. But if what you're saying is that politicians tend to be grateful for people who support them, or to people support them, then it's true, but that would apply to celebrity endorsements, that would apply not just to super PACs but obviously also to rich people spending their own money independently, which has always been legal, it would apply to voting a certain way because you like the way the lobbyist from that corporation dresses, you think she's pretty. I don't think that's illegal, but it seems improper. You can vote for terrible policies for all kinds of reasons. I think we should be focused more on the policies. I mean, people vote for terrible policies because they have crazy ideologies that drive them to do it, you know. So I don't know why we're focused on this one particular area where there's potential for improper considerations when there are all kinds of other considerations that people might deem improper, and shouldn't we be focusing more on the results, the performance that people actually deliver once they're elected.

Is it a good performance, is it bad? And part of that whole process is being able to speak on both sides of that.

### Moderator
Claim: I want to move on and I-- just give me a second and I'll-- I'm going to ask your permission for this-- I want to move on to the second point that David was raising before when I interrupted him. So do you want to respond to that point? And then I'm going to go back to where David was talking before about the actual execution of the rules and regulations.

### Scientific Advocate (SA)
Claim: Sorry, which one was that?

### Moderator
Claim: No, you can answer-- you can say what you want to say. But let's stop after that.

### Scientific Advocate (SA)
Claim: Okay, sure. So just in responding to this question of corrupt-- I think that there are important features that distinguish the different types of influence from the influence of money, right? In the first instance, with money and we're talking about a class of individuals who have a disproportionate and clear influence over the political process. You made a comment in your opening statement that the increase of money and sort of the increase of spending has generated more diversity of thought.

Well, I don't think that we can rely for political diversity on disagreements between rich people. That's not a political process that allows for a full and open debate. And so let's talk about results--

### Moderator
Claim: being rich people.

### Scientific Advocate (SA)
Claim: Let's talk about results for a moment, right? Because when we talk about corruption, we talk about the appearance of corruption, what we're talking about is the integrity of the system of representative government. It's about the belief that citizens have that the people who they elect to office are representing them. And the evidence shows that less than 10 percent of Americans in a Gallup poll believe that their elected representatives are actually working in their interest. That's a dangerous place for a democracy.

### Moderator
Claim: Okay, let's keep going on this. Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: The problem with this standard-- this crazy standard-- and I grant you, it was endorsed by the Supreme Court, but it's still insane-- the appearance of corruption, that we need to prevent the appearance of corruption. So that means the more that Jonathan and Trevor go around talking about corruption and how horrible it is and how everybody's corrupt and, of course, money buys votes and everybody knows it, even if it's completely false, they go around talking about, now everybody's worried about corruption. That justifies whatever regulations they're proposing.

It has this sort of circular quality to it. I don't think it should hinge on the appearance of corruption. Maybe it should hinge on the reality of corruption, although I don't buy this argument at all that the fear of even actual corruption, quid pro quo corruption, justifies restrictions on speech. And the Supreme Court has basically said it does. I think they were wrong. I think that they're moving in the right direction now. But I just don't buy it. Is there some kind of, you know, codicil that's attached to the First Amendment that says, "Except when you're worried about corruption, you know, then you can restrict speech"?

### Moderator
Claim: David Keating. I'll come back to you. David Keating.

### Conspiracy Advocate (CA)
Claim: You know, one of the benefits of all this new regulation and all these new laws that we've had basically since the mid-1970s is we've been able now to track how attitudes about government have changed.

And what has been found is the states that have the strongest laws, the most restrictive contribution limits, the people have no more faith in those governments than the states where there are unlimited contributions. This has no affect in the people's opinion about the appearance of corruption or the corruption of policies at the state level. So it simply doesn't work. If the idea is that people are going to have more faith in their government from these restrictive laws that are very complicated, burden speech, and prevent grassroots groups from forming easily, they simply don't work.

### Moderator
Claim: One more point on this. Trevor Potter.

### Scientific Advocate (SA)
Claim: On that, I think we have to recognize-- it's not a reach at all-- that there is, in this, a fundamental difference between the federal government in Washington and what is happening at the state level. The federal government has this enormous power. The Libertarians in the room will be happy I'm saying this. But it has this enormous power over the purse, the tax system, the way much of American life works.

And so it makes sense that if you were seeking a major tax break, if you want your aircraft carrier bought, the big money that you would be trying to influence what Congress does, that, it seems to me, is why we see the amount of money being spent on federal elections, and it's vastly more than is going to be spent in state elections, because the benefits of that extra money, if you get your aircraft carrier, your special tax break, the bill that hurts your opponent and saves you, that's huge for the interests that need that.

### Moderator
Claim: All right. I want to move to the point, David, when I interrupted you at the beginning in your opening comment. Your opponent Jonathan Soros has described the tangle of federal election laws as a Swiss cheese of loopholes that's ineffective. I don't know if cheese can be effective or ineffective, but you know what I'm saying.

In other words, he's saying there are regulations, but they're not regulating. It's not working at any level. And I want you to take that point on.

### Conspiracy Advocate (CA)
Claim: Well, I would agree that we need to have more clarity about what's permitted and what is not about fundraising, candidates, and these single-issue PACs, and, I think, single- issue-- single-candidate super PACs. And I think part of the problem is no one has asked the question whether a candidate can raise money for one of these single-candidate PACs. My view is the candidates cannot do that, and they should not be doing that. And I think it would be helpful if that was made clear. But the laws--

### Scientific Advocate (SA)
Claim: So, just to be clear, do we have agreement on this panel that there should be more regulation of Super PACs?

### Conspiracy Advocate (CA)
Claim: No, that's-- I'm not talking about regulating the people. I'm talking about regulating the candidates. To me, that's a different thing.

When people-- let me say, the laws on coordination are actually-- they're not as weak as you make them out to be. It's not just a matter of sharing inside information, although that's part of it. There-- and it covers much more than independent expenditures. It's any communication that's run within 90 days of an election is covered by the laws on coordination. And a communication is considered coordinated if it meets one of just any one of five different tests. One is if the communication is requested or suggested by the candidate or if you suggested it somehow to the candidate, and the candidate agreed. You don't need formal collaboration or formal agreement to this from the candidate. If the candidate or their committee or their party is materially involved in the decisions in any way; if someone creates the communication after one or more substantial discussions about the campaign's plans, projects or needs; or if they employ a common vendor and use any of that information, or they use someone who is previously employed by the campaign in the previous 120 days. So--

### Moderator
Claim: These are all rules that you-- that are in place that you think are being enforced and that are effectively limiting speech already? That they're-- that they're having effect?

### Conspiracy Advocate (CA)
Claim: Well, I-- this is part of maintaining the independence. I don't have a problem with that because I've said I think independent groups-- I think Americans should be able to get together and independently of the parties and the candidates, be able to speak about where the country should be headed, what candidates should be elected or what candidates should be defeated.

### Moderator
Claim: But in a-- I'm just a little unclear on the point that you were just making. Were you going through a list of rules that you feel you're good with?

### Conspiracy Advocate (CA)
Claim: These are the rules that exist today.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: I think a lot of people say, oh, there really aren't any laws against coordination. I mean, the idea that someone used to work for a candidate, it wouldn't be surprising that they would support the candidate. They probably worked with them. They've seen the candidate as a good person, maybe a good leader potentially.

It wouldn't be surprising--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --they'd want to get involved.

### Moderator
Claim: So Trevor Potter and Jonathan Soros, what David Keating has said is there are rules in place, and they're-- there is regulation. And some of it they're okay with, and that your argument that there's a Swiss cheese of loopholes is a great exaggeration.

### Scientific Advocate (SA)
Claim: Well, I heard David say--

### Moderator
Claim: Trevor Potter.

### Scientific Advocate (SA)
Claim: --it gives me great hope in the outcome of the debate because I heard him say that there are rules in place. We may need more rules, and that would seem to support our side of the proposition. But let's talk about the rules that are actually here. You know, David-- I think David has to say that it's important that these groups be independent because the Supreme Court said, in allowing these independent groups to exist, that the reason they wouldn't corrupt and therefore could take unlimited money, they're totally independent of candidate and party committees. As I think Jonathan did a good job of saying, totally independent of candidate and party committees?

You do have former campaign aids, lawyers, fundraisers for the candidates running these things. Unfortunately, one of the few times the FEC has not dead locked in the last couple years was actually agreeing that candidates could raise money for these super PACs as long as they did so within only limited amounts. We have incidents this year of the candidates traveling with the principal funder of a super PAC, candidates thanking the super PAC when he left the race saying he couldn't have done it without them. This seems to me not to be totally independent of candidates and parties.

### Moderator
Claim: Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: Yeah, I think, you know, there is an issue here. I mean, it does look--

--get rid of these limits on contributions to candidates then you can raise whatever money you want to raise for your own message, and you will be responsible for your own message, and you can't play this game of saying, oh, we can't coordinate. I can't talk to them. And you have to be responsible for your own speech. That's not to say that you get rid of the genuinely independent voices. But I think if what you're worried about is this sort of sneakiness, you know, it's kind of like, you know, a prostitute who pretends she's an escort, or you go into a head shop, and they got all these fancy water pipes, and it's for-- you know, for use only with tobacco or other legal herbs. And you might say these are very dishonest people. But in fact, it's bad laws that produce that kind of dishonesty. So we've got bad laws we should get rid of.

### Moderator
Claim: All right. I want to go in a moment to you in the audience to take questions from you and to remind you that I encourage you to-- to be terse in your questions, to try to really make it a question that's related to our topic. And I'm fine with you stating a short premise, but I really don't want you to make a speech because these are the guys who have to make the speeches. And what will happen is if I call on you, there will be a microphone in the aisle passed over to you. Please stand up. We would appreciate it if you will tell us your name and then hold the microphone about a fist's distance from your mouth. So as that is getting set up, I just want to take one more question-- one more point back to the side that is arguing against super PACs from your opponents. It was very much a thrust of their argument that there is a First Amendment here-- issue in this. And you haven't addressed at all whether in fact there is a valid core at all to their argument that there is a free speech issue here. And, you know, you may-- you may feel that there are other interests that outweigh it, or you may feel there is no free speech and just-- but I want to hear your view on it. Is there anything to it?

Jonathan Soros.

### Scientific Advocate (SA)
Claim: I actually think that Trevor acknowledged that in the first line of his remarks. That there is a free speech interest here. But what I-- and I wanted to-- I guess we're not going to go back and have time, but I was really startled by the comment about corruption not being a sufficient logic for countervailing some of that. So to focus on "Congress shall pass no law," that's just not true. We have lots of laws that curtail our speech in favor of some other public interest. And here there's a clear public interest in protecting the integrity of our electoral process from the possibility of corruption.

### Moderator
Claim: All right. But it is a curtailment of speech, regulation of money and politics would be--

### Scientific Advocate (SA)
Claim: Can be, yeah. And again, as Trevor indicated-- the Supreme Court actually didn't do a terrible job with this when they addressed the question in Buckley, to say there are different considerations when you are speaking yourself that has a stronger interest than when you are giving money to other folks, when you're making a contribution.

And so the limits and the rules that you put around that have to be appropriately tailored to how strong the interests are.

### Moderator
Claim: But to your partner's point on that, Trevor.

### Scientific Advocate (SA)
Claim: Well, I mean, the answer is, of course. When you're talking about the First Amendment and political speech, you're going to have a free speech issue when you are regulating money in politics. But that doesn't-- that just starts the question. It doesn't answer the question. The Supreme Court itself, in Citizens United said government can't choose among speakers. Listeners have the right to hear every speaker. The government's role is not to decide who speaks. Great absolutist language. The next case that comes along is a group of foreigners who say, good, I want to speak. I live in New York. I happen to work here. I'm not a U.S. citizen. There's a law that says I can't speak. People should hear me. It's a First Amendment right of the American people to hear me. The court throws them out on their ear. So this is not a clean-cut issue.

You look at this in balance among other things, as the court has done: The integrity of our government, the importance that people have confidence in the decisions being made, and then you look at where the money is spent, how it is disclosed, what we know. Those are all aspects of this.

### Moderator
Claim: All right. So Jacob Sullum, they're saying the free speech-- it's another example, or free speech is not an absolute right.

### Conspiracy Advocate (CA)
Claim: Well, I mean, this particular exception was just kind of pulled out of thin air. But there are other kinds of restrictions like those that prevent fraud. I mean, that's a kind of speech restriction, but it has to do with preventing a right violation. And other-- you know, other exceptions like obscenity that I don't necessarily agree with. But I just never-- have never bought this particular argument. Seems invented from whole cloth. And I want to say one thing in favor of disagreeing rich people. Is that how you put it, Jonathan?

### Scientific Advocate (SA)
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: I mean, don't knock them. I mean, first of all, you have people of more modest means, as David pointed out, who can pool their money as a result of having super PACs. But there is something to be said for disagreeing rich people. You've got billionaires, you know, who favor Democrats, and you have billionaires who favor Republicans.

You've got a bunch of rich guys who got together and put together a group called "The Campaign for Primary Accountability," which I love, because what they do is they go around the country. They look for entrenched incumbents of both parties, and they target them for defeat. And I think this is a great thing. And just to give you one example of what most people will consider to be a progressive outcome, there was a congressional race in Texas where Sylvestre Reyes, who was a long-time congressman, very comfortable, terrible on the war on drugs. He was challenged by a guy named Beto O'Rourke. I think that's his name. He's a former city councilman. And he got help from the campaign for primary accountability. And I don't know how much it helped him, but it presumably helped him somewhat, and he won. So you now have a guy who is written in favor of legalizing marijuana, written a book about it in fact. It says we need serious drug policy reform, replacing a hard line drug warrior. Both Democrats, right? So that's an example of how rich people-- disagreeing rich people can-- can aid progressive causes.

And of course in the Republican presidential primaries, you had Rick Santorum and Newt Gingrich-- these are not the greatest examples, but they did hang in there a lot longer than they would have, thanks to rich guys who gave money to super PACs supporting them. Mitt Romney had challengers who were different in some particular ways from him, not identical, in some ways better than him on certain issues, you know, it's not a great group to pick among, but-- but it-- very clearly they could stay in that race. That race was more competitive than it otherwise would have been, thanks to the super PAC money.

### Moderator
Claim: I want to remind you, we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters arguing it out over this motion, "Two Cheers for Super PACs: Money in Politics is Still Overregulated." Let's hear from our audience. That was-- I'm considering using that applause, that was-- we could make that a moment. I'm going to pass, though.

Any hands up. On the far-- gentleman on the aisle there, and if you wouldn't mind rising so that we can see you, thanks.

### Moderator
Claim: Yes, my name is Jay Lipow I've always believed that a fundamental right like free speech can be abrogated only if you can show a compelling state interest. And I haven't seen any evidence that the presumption or the likelihood of corruption is satisfactory to prove a compelling state interest. There hasn't been shown any actual corruption, has there?

### Moderator
Claim: All right, challenge to the side that's arguing against super PACs. Trevor Potter.

### Scientific Advocate (SA)
Claim: As I think I tried to explain earlier, there has. There are people who have gone to jail for actual corruption proved at trials. In the McCain-Feingold litigation, former members of Congress were interviewed by the other side who objected to the law, saying, "Did you ever see actual corruption?"The answer was, "Yes, I saw that money changed what happened in the Congress of the United States." Either the desire to fundraise and get money from particular interests or the facts that they had given money to party committees and, therefore, party leaders said, "We can't go after that, we can't do this--"

### Moderator
Claim: Can you give us an--

### Scientific Advocate (SA)
Claim: "-- because of--"

### Moderator
Claim: --a concrete example, not quite hypothetical of the sort-- you know, do you recall any specifics of any sort of deal that was done that way?

### Scientific Advocate (SA)
Claim: Sure, Senator McCain testified that in the Republican caucus when the subject came up of tobacco legislation the Republican leader said, "They've just given us hundreds of thousands of dollars. This is something we really can't support."

### Moderator
Claim: That's worrisome. Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: Can I push-- I want to push this definition of corruption a little bit because I think--

### Moderator
Claim: No, no, but can you respond to that case? To that example? If that happened, does that--

### Conspiracy Advocate (CA)
Claim: You're talking about soft money, is that the deal?

### Scientific Advocate (SA)
Claim: Correct, sell contributions to party committees.

### Conspiracy Advocate (CA)
Claim: Yeah, yeah, I don't think that should be happening. Is that the question? Yeah, it should not be happening.

### Moderator
Claim: Yeah, yeah, that's the question, yeah.

### Conspiracy Advocate (CA)
Claim: But seriously think about what you have in mind when you say, "corruption." There's a guy, a state senator in New York, Roy McDonald, who voted in favor of the Gay Marriage Bill and the primary's tomorrow, right? So he is up for reelection, or he's up for renomination tomorrow, and before he decided to vote in favor of the Gay Marriage Bill, he had assurances from gay rights activists that they would help him raise money to support his campaign. Is that corruption? And I think that your idea of whether that is corruption is going to hinge on your policy views to a large extent. So keep that in mind. I'm-- you know, just think about it.

### Moderator
Claim: Sir, on the aisle, yep. Mic is coming to you from behind you. Thanks.

### Moderator
Claim: Jamie Weinstein, senior editor of the Daily Caller. Jacob kind of stole my thunder at the end with my question, but I would like to get your side to answer it.

He pointed to the Republican primary this year, and it actually seems to be more competitive because of the super PACs. Gingrich and Santorum were able to stay in the race longer and gave Mitt Romney a challenge where he otherwise may have been able to mow down them much more easily without his super PACs. Isn't that a positive? More competitive elections?

### Scientific Advocate (SA)
Claim: Well, what you had was--

### Moderator
Claim: Trevor Potter.

### Scientific Advocate (SA)
Claim: --huge contributions to what Romney referred to as "my super PAC," what Gingrich clearly saw as his super PAC, as a way of getting around the normal contribution limits. I don't know that, that was a particular benefit to anybody, that all the sides were armored up significantly larger than they normally would be in a primary. You're right, the primary went on longer because instead of having to worry about for Gingrich whether they were donors who would support him and how he could keep going when he kept losing primaries, all he had to worry about was whether he made one man happy or not-- and under these coordination regulations he could go meet with that man and talk to him.

### Scientific Advocate (SA)
Claim: I just want to--

### Moderator
Claim: Jonathan Soros.

### Scientific Advocate (SA)
Claim: So I want to echo that. I mean, I think that the issue is, what would have happened if Newt Gingrich had won the primary? Would we have been asking about what he owed to Sheldon Adelson for the support that he got during the primary?

### Conspiracy Advocate (CA)
Claim: And also, how could we have done this?

### Scientific Advocate (SA)
Claim: So I just want to-- you know, we keep talking about the question of corruption, and I want to go back to this notion a little bit of integrity, briefly, that what we're talking about, in part, when we talk about corruption and the appearance of corruption is whether or not people believe in the integrity of the political process, that people are representing them. And I'll just comment that there's actually nothing in our current limit system to give people a lot of confidence. As I said in my opening, when you've got contribution limits of $2,500, those are out of reach for most people in America.

And $25,000-- so you end up with a very, very small fraction of people who are contributing as it is. It seems like the system's actually designed to maximize the amount of time that candidates spend with rich people, right? That's one of the reasons that I said, at the end, we really need to be focused on an alternative as well, to focusing on a system where candidates can run for public office where they're not dependent on these contributions.

### Moderator
Claim: There's a gentleman in a white-- fully white shirt. Could you-- sir, could you stand forward a little bit, just into the more lit area so the camera can see you?

### Moderator
Claim: Hi. This question is for the in the affirmative of the motion. You still maintain that money in politics is still overregulated. So I'm just wondering where you find it to be still overregulated and what the right amount of regulation should be.

### Moderator
Claim: David Keating.

### Conspiracy Advocate (CA)
Claim: Well, I--

### Moderator
Claim: Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: Yeah, just briefly, I did mention, I think, that they should get rid of the limits on contributions. I think a lot of the false independence you're worried about, this apparent dishonesty, the evasions and so forth, come out of that.

And what happens historically with campaign finance regulation is, they impose one rule, people find a way around it; they propose a new rule, people find a way around that; and so on, and so on, and so on. And speech gets more and more restricted. Regulations get more and more complex and intimidating for the average person who might want to get politically involved. And I think we need to-- we cut our losses and make things as simple as possible. I don't buy the distinction between giving versus spending. I think if spending is speech, giving is also speech, or it amounts to speech if you restrict giving. So there should be no limits on giving. I am sort of on the fence about disclosure rules. I think it's legitimate to require candidates, as a condition of running for office, to disclose donors, but I don't think it's necessarily legitimate to require disclosure for independent spenders. There's an argument to be made that that chills speech. In fact, it's designed to chill speech.

### Moderator
Claim: David Keating, would you add any other gripes to that list?

### Conspiracy Advocate (CA)
Claim: Well, there's-- first of all, I would agree with a lot of that. I do think it makes sense to allow candidates to decide when they file, as a candidate, what the contribution limit will be, if any, and let the voters decide. So if they want to accept unlimited contributions, the candidates can do that. If the candidates will agree with each other to accept a limit, whether it's today's limit of $2,500 or some other limit of, say, $10,000, let them do that, and let the voters decide. "Do I trust this person taking these kinds of money from these kinds of people?" So I think that makes sense. Now, there are lots of other laws and regulations. As I said, there's-- the laws and regulations have 376,000 words. For a lot of small grassroots groups that just want to say something about their member of Congress, as soon as they spend $1,000, they have to file with the Federal Election Commission.

A lot of people just can't navigate these forms and these regulations. And then it's not clear what they're allowed to say and what they're not allowed to say. There are regulations describing what's express advocacy that's regulated by the Federal Election Commission. But people look at the regulation and they don't know what it means. And, in fact, we helped a group that had a question about a number of ads. They submitted nine ads to the Federal Election Commission, and the Commission itself couldn't agree whether it was regulated speech or not. This is not a situation that is good for our country, where people want to speak out about what's going on in the election, and they have to hire a lawyer to do it. We've got to simplify the thing so the election law is not more complicated than the tax law.

### Moderator
Claim: All right. You know, I'm just thinking that, so far this evening, counting myself, the debaters, the questioners, Bob Rosenkranz, we have heard eight men speaking. Are any women going to raise their hands with questions? Because I'm looking, but I'm not seeing.

### Moderator
Claim: Right in the middle.

### Moderator
Claim: Have you been doing that the whole time? Oh, you're in the dark. I'm sorry. I can't see you. I just want to ask, is that okay for the camera, that you're in the shadows there? Yeah, you can pick it up. Okay.

### Moderator
Claim: I was just wondering for the proponents of free speech, without regulation, how do you differentiate between me supporting a candidate with my voice or me going to the store and buying Scott's Miracle-Gro and having my support of green lawns representing a political concern?

### Conspiracy Advocate (CA)
Claim: Because that company is supporting a particular cause, you mean?

### Moderator
Claim: Yes. Scott's Miracle-Gro recently--

### Conspiracy Advocate (CA)
Claim: Well, actually, I mean, that's an issue that hasn't actually come up. But that was one of the arguments that the Obama administration used in favor of keeping the regulations that were overturned in Citizens United. They said there was not only this concern about corruption, but also a shareholder interest. And I guess you're talking about a consumer interest, but it's somewhat similar.

I think the answer in both cases is the same. If you're a shareholder in a company, you don't like their political speech, you can-- you can sell those shares, or you can object at a shareholder meeting. If you're a consumer, and you don't like the political speech of the company you're buying from, you can stop buying from them. I mean, you can protest as well. But you have the power to decide where your money is going based on that consideration.

### Moderator
Claim: Jonathan Soros.

### Scientific Advocate (SA)
Claim: So I'm glad-- thank you very much for raising that. I'm glad that this came up because we haven't talked at all about the corporate question which is actually what Citizens United was originally about. So that's an interesting theoretical argument. The problem is Scott's Miracle-Gro decided, voluntarily, to fund a super PAC, which is one of the few instances of a public company doing that. So if they decide to give their money in a way that's not disclosed, then as a consumer, you have no idea about it and as a shareholder, you have no idea about it. The second thing is that as a shareholder, you may very well have no ability to do anything about it anyway. So let's-- the issue of corporate democracy, we could go on for a long time.

But let's just stick with somebody who owns those shares through a pension fund, right? Forty-seven states in this onion, if you're a public employee, you're required to put your money into a pension fund. That money can go anywhere. It can go into any company, and you have no control over it. So there is a problem with corporations speaking because they're speaking on behalf of other people that don't have the ability to give their consent. And you can also suggest maybe you shouldn't have to give your consent in order to participate in the modern economy of owning shares.

### Moderator
Claim: Another question? I'm still gender hunting. Right in the center. You were the only woman from seats and seats around. But then I'm going to go back to gender blind after that. Do you mind standing up too, please? Thanks.

Debra Jerkerson No. I think--

And we'd just like to ask your name.

### Moderator
Claim: Okay. My name is Debra Jerkerson. And just going back to David's point that people have a right to sort of organize themselves, or people have a right to change their government, it seems that we're getting into this long conversation about how to regulate money.

But on the other hand, you're kind of saying that money doesn't really influence politics. I wanted to go back to what Mr. Soros is saying, what could we look at as a different system such as campaign finance reform, or public funding of campaigns, and how do you think about that?

### Moderator
Claim: David Keating.

### Conspiracy Advocate (CA)
Claim: Well, I-- the question is whether we should have tax funded campaigns. And it's very hard to design such a system. I think there are a lot of problems with it. I mean, we talk about disconnecting candidates from the people. If they don't have to raise money for their campaigns, we're disconnecting them additionally. But there's also real questions of how you design such a system so that it's attractive so the candidates will even want to do it.

We have tax funded campaigns for the presidential candidates. And in this election, both candidates have decided to forego that financing. In other states where they've designed these tax funded campaign systems, they've designed them in such a way as to penalize independent groups that speak out. Now, the Supreme Court has struck down those provisions. But it makes it even more difficult to design such a system. So I don't think it's terribly workable, for one. Second, I don't think it's politically possible to pass, either. When you put together the words basically "tax funding" and "politicians" together, it's not popular. People don't like paying taxes. They don't like their money going to politicians. They don't like politicians generally. So I think if we're looking for solutions to try to make our government more accountable, to provide cleaner government, that that's not something that's probably going to work politically.

### Moderator
Claim: Sir on the aisle?

### Moderator
Claim: Yes. Thank you. My name is Stanley Fish, New York Times, professor of law and author of a book called "There's No Such Thing as Free Speech, and It's a Good Thing Too." I had a question for Mr. Keating who said, at the beginning of his address, that the issue is, do we value the First Amendment and keep it as it is, which suggested that there was a First Amendment that was libertarian in the form that he likes it. But in fact, as I think you know, that's a product of the last 35 years. As early as 1942, in Chaplinsky versus New Hampshire, there was a paragraph listing all of the forms of speech that do not deserve Constitutional protection--

### Moderator
Claim: Mr. Fish, can-- can you land this as a question?

### Moderator
Claim: Sure.

### Moderator
Claim: Thanks.

### Moderator
Claim: In '71, made the argument that only political speech could be protected so that--

### Moderator
Claim: I'm sorry. Can you-- I-- I need you to bring the mic in and just do that last part again.

### Moderator
Claim: Your First Amendment is a very recent invention. In fact, an invention that began with New York Times versus Sullivan which I think is one of the worst cases ever decided.

### Moderator
Claim: Okay. You don't have to respond to that because it wasn't a question. That was a speech. That was one of those things I don't want to have happen.

### Scientific Advocate (SA)
Claim: In that case, can I go back to that last point because I think it--

### Moderator
Claim: Yeah, sure, Jon, I'm sorry.

### Scientific Advocate (SA)
Claim: --because I think it's an important one.

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: Because what I heard as an argument against the citizen funding is essentially that it's unpopular and that it's hard. And I think both of those things are true, but I don't think this is a debate about what's politically popular or not. It's a debate about what's the right answer. So you can design a system that actually drives politicians towards their constituents. I described it in my opening remarks. So the system we have in New York City where you only get the funding from the city when you raise money from your constituents in small dollars.

That transforms the way that people-- people raise money in this city. And you have to make it big enough to-- it's true, we still have, on the books, a presidential public financing system. I don't know what it is this year, but in 2008, it was worth about $110 million. So that's just not a relevant number any more. It has to be robust enough that a candidate opting into the system believes that they can really run a credible campaign.

### Conspiracy Advocate (CA)
Claim: How many of you checked off the little box on your tax return that said you were willing to give money to that fund?

### Moderator
Claim: Jacob Sullum. David Keating.

### Conspiracy Advocate (CA)
Claim: Well, I find--

### Moderator
Claim: Did you want an audience response from this? I think it's a fair question. You're asking how many people have actually checked off--

### Conspiracy Advocate (CA)
Claim: It looked like most people did not. Is that accurate? Who-- who checked off the box for that fund? So right here in this audience, which I suspect is disproportionately in favor of this sort of thing-- you can't even get a majority here.

### Moderator
Claim: Just for our radio audience, let's mention that all the hands went up.

Nearly all the hands went up.

### Conspiracy Advocate (CA)
Claim: Anyway, I actually--

### Moderator
Claim: David Keating.

### Conspiracy Advocate (CA)
Claim: --found it kind of amusing that we're pointing to New York City's council as a model of clean government. I mean, Jonathan-- Jonathan just described a system of tax funded elections that's the model they want to take to the rest of the country. And we're looking at New York City's council as the model of great representation produced by this. I, for one, don't agree with that. You look at the quality of the law making coming out of there, and, you know, it doesn't seem to work. So I don't think we want to copy that model.

### Moderator
Claim: Sir in the neck tie. Gil Hyde Hi. My name is Gil Hyde, I do high school debate here in the city. And I have a question that's more theoretical than anything else. You talk about the appearance of corruption, both teams have. And my question is the appearance of corruption versus actual corruption, whether it would make a difference if we didn't see the corruption towards the debate.

### Conspiracy Advocate (CA)
Claim: That's a great point because the response to the appearance of corruption is you just hide it, and then people don't worry about it. It's not a problem.

### Moderator
Claim: Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: But yes, I think that is a problem because it hinges on something that may not be real. And this whole notion that underlies this, that you want people to have faith in your government ought to be controversial. There's such a thing as having too much faith in your government. Some people look at these declining ratings for Congress and the federal government, and they say this is terrible. People are losing faith in the government. Other people look at that, and they say, thank God voters are finally wising up, right? And so obviously that's going to depend on your own views about how big government should be, what it should be doing and so forth. But it is not an uncontroversial idea that everyone should have faith in the government.

### Moderator
Claim: Jacob-- I'm sorry, Trevor Potter.

### Scientific Advocate (SA)
Claim: So that may mean that we would have been better off if we'd never known that the Nixon administration sold milk price supports for $2 million to the--

### Conspiracy Advocate (CA)
Claim: According to corruption argument, yeah.

### Scientific Advocate (SA)
Claim: --milk people and sold an antitrust case to ITT. What the court said is you have to worry about both. You have to worry about actual corruption because that means that government is not doing its job.

It's not impartially deciding in the common good. And you have to worry about the appearance because if citizens think that's what's going on, and they look at all this money and they look at who's getting it and the way these super PACs are working linked closely to candidates, and think, "Well, I don't have any role in this, they are all in a league different than mine, and they're getting something for their money," that appearance is a problem for us, too.

### Moderator
Claim: One more question, sir, right in the-- oh, right down in the front here. Thanks. Mic is coming.

### Moderator
Claim: I guess I get the women vote then, right? I heard you got-- my name's Kim Barker-- and I've heard you talk a lot about super PACs this evening and some mention of social welfare, nonprofits, and trade associations. I guess I'd like to ask both sides what role you think those anonymous donation groups are going to play this election, and to get a defense of anonymous money in politics, and also why it might not be so good.

### Moderator
Claim: You're asking for a defense of anonymity in politics?

### Moderator
Claim: Anonymous money, the trade associations and the social welfare, nonprofits--

### Moderator
Claim: Yeah, such as the National Rifle Association, Sierra Club--

### Moderator
Claim: Yeah, yeah, yeah.

### Moderator
Claim: --organizations like that do not have to disclose who their donors are, okay. And you're asking for somebody-- and you're looking for a defense of that anonymity.

### Moderator
Claim: A defense and also why that's not so good.

### Moderator
Claim: And an attack, okay. Jacob Sullum.

### Conspiracy Advocate (CA)
Claim: Well, and I think it's the case, and David can correct me if I'm wrong, because it's actually-- this is a small percentage of the money for super PACs that comes from these nonprofits.

### Moderator
Claim: I'm asking about the direct spending because a lot of these groups spend directly.

### Conspiracy Advocate (CA)
Claim: Oh, okay, I thought you meant donations, super, I'm sorry.

### Moderator
Claim: No, no, no, I mean, you look for example.

### Conspiracy Advocate (CA)
Claim: Right, okay. As I said before, I think there really is a value in not having to disclose the people who are supporting these groups. I mean, imagine somebody who supports, say, NORML and doesn't want his employer to know that, or he supports NORML, or-- fill in your favorite group, whatever it is, you can imagine reasons why people don't want their support to be widely known. And, in fact, this has been recognized to some extent by the Supreme Court in a case involving the NAACP, where I think it-- was it Alabama-- wanted to force them to disclose all of their supporters.

And the Supreme Court said, "No, this is--"

### Moderator
Claim: We're all going to close our eyes, and the person--

### Conspiracy Advocate (CA)
Claim: This hinges on freedom--

### Moderator
Claim: The phone is interfering. We are-- okay. Resume.

### Conspiracy Advocate (CA)
Claim: The Supreme Court said basically, "If you have to reveal who all your supporters are for a group that's engaged in advocacy that's controversial, that obviously has a chilling effect. It chills freedom of association and freedom of speech, too." So I think there is an argument-- a strong argument you've made against forcing those groups to disclose who their supporters are.

### Moderator
Claim: Jonathan Soros.

### Scientific Advocate (SA)
Claim: So the NAACP case is a popular argument and response, and there are a lot of reasons why it doesn't quite fit. But one of-- first of all, it stands also for the proposition that there is an exemption for disclosure if there's a real threat to the members from disclosure-- a clear-- and Alabama at that time, there were clearly threats to members.

There was also no state interest at all in getting that membership list in NAACP. So a couple of things on the information First of all, elections are different, right? There's lots of anonymous political speech in our society, and we don't go around looking for the sources of those speech. But when you're talking about advocating for the election of someone who's going to represent their population, and you want to have that clear connection between the electorate and the elected official to know that they're actually representing their constituency, elections are different. There's an informational component, right, so you want to be able to evaluate the message that you're hearing. And part of being able to evaluate that is knowing who's speaking.

### Moderator
Claim: Jonathan, I have to step in because we hit our time limit.

### Scientific Advocate (SA)
Claim: Yeah.

## Round 3

### Moderator
Claim: And I want to say, that's the conclusion of round two of this Intelligence Squared U.S. Debate. here's where we are. We're about to hear brief closing statements from each debater in turn. These will be two minutes, each. It is their chance-- their last chance to try to affect how you will vote at the end of this debate. Remember, you voted before the debate and we're going to ask you to vote again at the end on this motion, "Two Cheers for Super PACs: Money in Politics is Still Overregulated." So on to round three, closing statements. Here to speak against the motion, "Two Cheers for Super PACs: Money in Politics is Still Overregulated," Trevor Potter. He is president and general counsel of the Campaign Legal Center.

### Scientific Advocate (SA)
Claim: Thank you. I'd like you to imagine a state where industrial hog operators began to worry about proposed new environmental regulations that would prevent them from dumping untreated waste into local rivers. Imagine they formed a group called, say, "Farmers for Fairness," to persuade legislators to block such regulation.

Imagine they created some campaign ads which attacked legislators by name, never mentioning hog farming at all, but claiming legislators were not in touch with "our values." But now imagine that Farmers for Fairness did not go out and run these ads, but instead scheduled meetings with legislators and screened the advertisements for them in private. Imagine Farmers for Fairness told the legislators privately that they would hate to run these ads, but would do so if the legislators didn't vote the way they wanted. You don't have to imagine that. It happened in North Carolina, documented by a federal judge in a case called Life v. Leake.

But today a super PAC nonprofit could do this in Congress with huge sums of unlimited, undisclosed money at their disposal, and we might never know it happened. Two cheers for super PACs? I don't think so. That would be a problem even if the super PACs complied with the Supreme Court's assumptions about no coordination at all with candidates and party committees and full disclosure of all this money being spent in elections. That is not the system we need.

### Moderator
Claim: Thank you, Trevor Potter. Our motion is, "Two Cheers for Super PACs: Money in Politics is Still Overregulated." And here to summarize his position in support of this motion, Jacob Sullum, a senior editor at Reason magazine.

### Conspiracy Advocate (CA)
Claim: So during the first round of arguments in Citizens United, Deputy Solicitor General Malcolm Stewart was asked, "Well, if you can ban this movie, 'Hillary: the Movie,' what about if you have very similar material but it was presented in a different medium, like DVDs or on the internet or even in books?"And he said, "That would be constitutionally permissible too." This was pretty shocking, because it raised the possibility that the government could ban books in the name of fighting corruption. It was widely seen as the turning point in the case. They had a second round of oral arguments, which was very unusual, prompted largely by this revelation. And during that round, the solicitor general, Elena Kagan, said the government had changed its answer. She said there would be a strong constitutional case against punishing an organization for publishing a book, but that pamphlets were different because they were classic electioneering. Well, that raised new questions. When does a pamphlet become a book? Is it a matter of the number of pages? Is it the kind of cover it has, the binding, or what? Now, the media exemption that I alluded to before, upon close examination, looks equally arbitrary. Citizens United, after all, was producing movies. So why was that, Citizens United, not a media corporation?

The NRA started a radio show, daily radio show, after McCain-Feingold was passed, and they said, "Look, we're a media corporation; we're exempt." If that's legitimate, then why couldn't every advocacy group do the same sort of thing? Does the internet count as a medium? Presumably it does. Then doesn't every group that has a website qualify as a media corporation? This media exemption puts the government in the position of deciding who deserves to have unfettered freedom of speech and who does not, which is precisely the sort of distinctions the First Amendment is supposed to prohibit. And whether you're worried about corruption or you're worried about undue influence, the arguments for regulation are just as strong, if not stronger, in the case of media corporations. So while many of my fellow journalists have supported these kinds of regulations, basically lobbying to keep their own special speech privileges, it's always seemed foolish to me for people who make a living by talking about politics to appoint the government as a sort of national debate moderator, because you never know when the moderator will decide that it's time for you to shut up.

### Moderator
Claim: Your time is up, Jacob Sullum. Thank you. Our motion, "Two Cheers for Super PACs: Money in Politics is Still Overregulated." And here to summarize his position against the motion, Jonathan Soros, senior fellow at the Roosevelt Institute and cofounder of Friends of Democracy.

### Scientific Advocate (SA)
Claim: So I'm going to return to this question of Scott's Miracle-Gro, because what's not part of the story yet is that last week Scott's was fined $12.5 million for violations of federal pesticide laws for, among other things, putting toxic insecticide in their bird seed that was killing birds. Now, they got caught doing that, and they actually as far as I could tell, acted admirably. They admitted it. They pled guilty. They entered into an agreement. But they were caught, and that was dealt with because we have laws that protect clean elections-- excuse me-- laws that protect clean air and clean water, and we have an enforcement agency that deals with that.

In June, they gave $200,000 to the pro-Romney super PAC Restore our Future. This is not that it was Romney or Obama, but that they gave money to a super PAC. There are no laws in place after Citizens United, no clear legal regime that would require them to disclose that information so that their consumers would know about it, so that their shareholders would know about it, that anybody else would know about it. They could have used a different organization other than the super PAC and done basically the same thing. And we have no effective regulatory agency that will provide us with clean elections. A lot of what our opponents have talked about essentially arguing from the past. They're arguing from pre-Citizens United, pre-SpeechNow. We deserve disclosure of contributions. We deserve an effective disclosure regime. We deserve something that protects our-- the integrity of our political process.

The proposition that we're arguing is whether money in politics is still overregulated, and the answer to that is clearly no.

### Moderator
Claim: Thank you, Jonathan Soros. The motion: "Two Cheers for Super PACs: Money in Politics is Still Overregulated." And here to summarize his position in support of the motion, David Keating, president of the Center for Competitive Politics.

### Conspiracy Advocate (CA)
Claim: Well, since we passed the major campaign finance restrictions in the early 1970s, we've seen competition decline dramatically. We used to see elections that were far more competitive than they are today. The re-election rate has gone up not down. But fundamentally I think what we have to keep in mind here is when-- who is going to write these restrictions? Who is going to write the campaign finance laws and regulations? Well, the answer is it's going to be the incumbent members of Congress. There is no other way to write them. And if there is ever a conflict of interest about how this is going to be written, that's a conflict.

They get to write the regulations so they probably will write them so that they will be able to have a better chance at keeping their jobs. They're not so much concerned about our freedom of speech or our ability to criticize the job they're doing. In fact, they would like to see less criticism of it. So basically, this is a debate about who decides what you can say? Should it be us the people getting together and deciding, or should it be the politicians? And should it be the prosecutors who are looking to make a name for themselves? You have to keep in mind many of these laws that are written not only have civil penalties but criminal penalties. And if you think that's far-fetched, the very first political prosecution taken under these laws was a group that took out a full-page ad urging Nixon's impeachment for the invasion of Cambodia.

That was the first prosecution under the campaign finance laws. I would say free speech is messy. But the cure of additional regulations written by politicians who want to stay in office is worse than any disease of free speech. So I hope you will support the motion "two cheers, or three cheers, for super PACs." Three cheers for independent action by the people.

### Moderator
Claim: Thank you, David Keating. And that concludes our closing statements. And now it's time to learn which side you and the audience feel has-- feels has voted the best. We are asking you again to go to the keypad at your seat that will register your vote. We're going to get the readout on this almost instantaneously. The motion is "Two Cheers for Super PACs: Money in Politics is Still Overregulated." If you feel this side argued best, push number one. The opposing side, push number two.

If you are or became undecided, push number three. And you can ignore all of the other keys and correct your vote, and it will just register the last vote. Okay. So while you're doing that, and while the votes are being tabulated, the first thing I want to say is that this was, for us, relaunching this season in the midst of a political campaign, it was just about a perfect-- just about a perfect target for us. And I think all of us at Intelligence Squared are really, really impressed by the level of debate that these panelists brought to this. It was very serious and informational without being medicinal. It was terrific. So thank you for that. And also, I want to say sometimes we have some tricky times with audience questions. Questions tonight were terrific. So to everybody who got up there and had the nerve, thank you very much for that. few things about what's coming down the road. First of all, we-- anybody who was Tweeting tonight, thank you for that. And you are welcomed and encouraged by us to Tweet after the debate and get the word out about us. Our Twitter handle is @IQ2US. And the hash tag is the same, #IQ2US. Our next debate is on Thursday, October 4. The motion is "Better Elected Islamists than Dictators." Arguing in support of this motion we're going to have Reuel Marc Gerecht, a senior fellow at the foundation for defensive democracies and a former Middle East specialist; Brian Katulis, he is a senior fellow at the Center for American Progress, who has been focusing on U.S. foreign policy in the Middle East and South Asia. Arguing against this motion, Daniel Pipes. He is president of the Middle East forum. He is described as perhaps the most prominent U.S. scholar on radical Islam by the Washington Post.

And Zuhdi Jasser, he is president of the American Islamic Forum for Democracy which he founded to advocate for the separation of mosque and state. October 10th, everybody get on a plane and fly to Chicago because we're going to be doing a debate there. We're taking part in the second annual Chicago Ideas Week. There we are debating the motion, "Ration End of Life Care." I may later pronounce it "ration." I haven't decided yet. But you get the point. Tickets and more information about all of the upcoming fall debates can be found on our website, www.iq2us.org. And if you can't make it to the next debate, watch the live stream as we had tonight. Our new partner is the Wall Street Journal's video initiative, WSJ live. And you-- as I said at the very beginning, you can listen to all of our debates online. And this particular debate on WNYC here in New York.

Our turnaround time is usually several days. And just look at their schedule. And also for the televised version, WNET and the WORLD digital channel. All right, we have the results in. Remember, our motion is this: "Two Cheers for Super PACs: Money in Politics is Still Overregulated." You heard the heated and intelligent arguments. We've asked you to vote twice, both before the debate and again at the end of the debate. And the team whose numbers have moved the most will be declared our winner. And it goes like this: Before the debate, 19 percent were for the motion, 63 percent were against, 18 percent undecided. After the debate, 22 percent are for the motion. That's up 3 percent. 69 percent are against. That is up 6 percent, 9 percent are undecided. That's down 9 percent. That means that the side arguing against the motion in a squeaker has carried this debate. Our congratulations to them. Thank you from me, John Donovan.

We'll see you next time from Intelligence Squared US.
