# Debate Transcript

Topic: Universal Health Coverage Should be the Federal Government's Responsibility
Motion: Universal Health Coverage Should be the Federal Government's Responsibility

Debate ID: Health-Coverage-091608


## Round 1

### Moderator
Claim: I want to thank you all very, very much for making it out this evening and for making this a sellout, the first night of the new series. And I would like to turn it over to Chris Browne of Rockefeller University.

### Moderator
Claim: Thank you very much. I’m Chris Browne, I’m a member of the Board of Trustees here at The Rockefeller University. A universally world-renowned center for research in the biomedical and biological sciences. I’m also a supporter of Intelligence Squared US and a long-time friend of its chairman, Bob Rosenkranz. We’ve known each other for so long that I won’t admit how long. But it’s been a while. It’s a special Should Be the Federal Government’s Responsibility” (9/16/08) pleasure for me to welcome you this evening, in which two organizations I admire are working together. Rockefeller is providing the new and larger venue, enabling Intelligence Squared to better meet the demand for the elevated public discourse it supplies. Bob Rosenkranz will now be joining us, via videotape, to frame tonight’s discussion.

### Moderator
Claim: Thank you, and welcome. In the upcoming political campaign, we’re going to hear an awful lot about health care. The 45 million uninsured, are cited as a national scandal. And the efficiency of our current system is very questionable. Our current health care system, consumes about 50 to 100 percent bigger piece of our national output, than health care in other rich countries, with very, very little to show for it, in the way of improved outcomes. Those who favor a federally mandated universal coverage, argue that, it will produce greater efficiency, as the federal government drives private-sector costs down. It’ll promote better health outcomes, as we are able to have more early intervention, and more preventive medicine, and it’s more fair to the disadvantaged people in our society who are not getting the full benefits of, of health care coverage that our country can provide.

On the other side of the argument, are those that rarely link the Should Be the Federal Government’s Responsibility” (9/16/08) terms “efficient” and “government” in the same sentence. They see the problem as grossly exaggerated. Of the 45 million uninsured, many are young people who are relatively healthy, people who can easily afford medical coverage but elect not to buy insurance, illegal immigrants, and people who are eligible for Medicaid but have not enrolled. They think that the inefficiencies in the system, are caused by the fact that most consumers of medical care don’t pay for the service directly, and therefore, have no incentive to control costs. And finally on the subject of fairness, universal care may be seen as simply a way of compelling healthy young people, to subsidize the cost of providing health care to their less healthy elders. To discuss these very timely matters we have a truly outstanding panel with us tonight, and it’s my real pleasure to introduced John Donvan, our new moderator, and the radio voice of Intelligence Squared, on the 150 National Public Radio stations that carry these debates. John is an Emmy Award-winning journalist, with 20 years at ABC News, most recently at Nightline. He’s been a White House correspondent, and a foreign correspondent, in Moscow, Jerusalem, Amman, Iraq. John, the evening is yours.

### Moderator
Claim: Thank you, Robert Rosenkranz. And I would also like to invite a round of applause for Robert Rosenkranz whose vision makes these evenings possible, normally he’s here in Should Be the Federal Government’s Responsibility” (9/16/08) person but— I am John Donvan, your host and moderator, for Intelligence Squared US, I am with ABC News Nightline but tonight it is a pleasure to be introducing and moderating these debates, Intelligence Squared US, Oxford-style debating on America’s shores, the motion for tonight’s debate as you know, “Universal health coverage should be the federal government’s responsibility.” You are going to be hearing from six panelists throughout the program, three who are for this motion, and three of whom are against, we’re going to have a three-part debate, the first part, the most substantial part in a certain way will be opening statements, each of the speakers in turn will be given seven minutes to make the case, I want to clue you in there is a sound that you will hear at the six-minute mark, it’s a warning sound telling them that they’re running out of time and it sounds like— Very gentle sound, and— It can become more insistent and at the seven-minute mark it will become rather relentless like this. All righty. All righty. We’re going to poll you both before and after the debate because, the point here, is to win the room. These debaters are trying to persuade you to their point of view, everyone comes in here with a point of view or the absence of a point of view known as undecided. We’re going to poll you to Should Be the Federal Government’s Responsibility” (9/16/08) find out what our baseline is coming in but this is in a sense a contest, it’s not quite a reality show but it is a contest, it’s a contest of wits and facts and information and persuasion, and all of you are the umpires, you are the referees, you are the judges in this.

We will also, later in the program, after the opening statements, we’ll be coming to you for questions, and then the evening concludes with each of the debaters taking two minutes to sum up and reach a summary position, at that point we will vote again, to find out how they did, who were the winners of the evening. So, once again the topic, to reiterate, “Universal health coverage should be the federal government’s responsibility,” if you go to the keypads attached to your seats at this point…number 1 means that you are for the motion, number 2, you are against the motion, number 3, you at this point are undecided. Please vote.

Does anyone need more time? It was pretty simple. So in a short time we’ll have the results to share with you but we want to begin now, with the opening statements, once again our topic, “Universal health coverage should be the federal government’s responsibility,” and arguing first for the motion, Should Be the Federal Government’s Responsibility” (9/16/08) Paul Krugman, a well-known op-ed columnist for the New York Times and I want to point out that in an era when many of us were beginning to refer to our potatoes as Freedom Fries, Paul Krugman stood up and talked about the French when it comes to health care, in some ways, doing it better than the United States, and the Germans, and the Koreans…Paul Krugman, the podium is yours.

### Conspiracy Advocate (CA)
Claim: Thank you. So I’m an economist which means I’m supposed to talk about efficiency, but I actually want to start, by talking about morality. And in fact I don’t want to start by talking about health care. Let me talk about something that’s going on right now. As we sit here there are several million people in the Houston metropolitan area, who are without electricity or running water. Been hit by disaster, they didn’t do anything wrong. They stayed in their houses because that was what they were advised by the governor of Texas to do, it was the right thing to do given the impossibility of evacuating a city that size and now, a lot of them are in trouble.

Some of them can manage, some of them can now go and stay with relatives, some are in good health and, others are not, they’re in a lot of trouble. Now, do we think that the people who are in trouble, who are elderly, who are in poor health, who just Should Be the Federal Government’s Responsibility” (9/16/08) don’t have the financial resources, whatever, to get themselves out of that situation, do we believe that, well look, you know, it’s not a government responsibility to help them, they should be left on their own. Well of course we don’t, I mean, I imagine there are some people who do believe that, but not many. They certainly don’t show their heads in our American politics. We do believe that if our fellow citizens suffer misfortune that is no fault of their own, and we can help them, that we should.

Now imagine, some American who is in poor health and can’t afford medical care. Some American who is elderly and in need, trouble, or maybe not elderly, something’s gone wrong, someone who is trying to work but can’t get a job that has health insurance, someone who is in difficulty. Do we believe that that’s their problem, that we should not be taking care of them. And by the way, we’re not just talking about the 45 million without health insurance. We’re also talking about the roughly 75 million people who have inadequate health insurance. Health insurance that basically crumples, whenever it’s put to the need, we’re talking about a large part of this country, that does not have adequate health care coverage.

Well I would submit to you that actually as a nation, we don’t believe that it’s appropriate to leave these people on their own.

Should Be the Federal Government’s Responsibility” (9/16/08) That we actually believe that the right thing to do is to help people, we don’t think that people should be protected from all of the risks of life but when there is something you can do, we believe that we should do it. And in fact by and large, if you ask people, should people have health coverage in this country, should people be guaranteed health care, most polls I’ve seen say that a heavy majority of the public thinks that they should. So then the question would be, well how is it that we don’t actually have that, how is it that we haven’t actually taken care of our citizens in the way that overwhelmingly, as a nation, we believe is the morally right thing to do, that as a matter of values, we think we oughta do. And the answer is of course that we’re told…well actually we’re told two things. We’re told first of all, that we already do it. That we already take care of everybody, and we’re also told, that it’s impossible to take care of everybody.

Now you might think that it was impossible to believe both those things at the same time but, that’s why these guys are paid the big bucks. So we’re told that, well, look— And I can quote the President there. “I mean people have got access to health care in America. After all you just go to an emergency room.” And of course--I think we probably have a fair number of doctors here right--you know, it ain’t the same thing. First of all, going into emergency is no substitute for continuing care. And secondly, if Should Be the Federal Government’s Responsibility” (9/16/08) you go to an emergency room, they will bill you. Now if you’re indigent, we’ve got the care all the same but you will get the bill and if you’re indigent maybe that doesn’t matter, but, for working Americans who don’t have good incomes, they’re terrified of emergency room coverage, and it’s—there’s something sick about our debate, that anybody can even claim that the emergency room is a substitute for universal health care.

But the other argument is that it’s impossible. That if you try to have some form of universal health care, it’ll be terrible. It’ll be lousy quality, it’ll be wildly expensive. So people are told that a government insurance system can’t possibly work. It will be lousy insurance, it’ll be awful, it’ll lead to awful care… Which, now we’re going to hear a little bit I think later on about some of the international evidence, we’re going to hear about other countries. But you know, I—there’s a secret, I don’t know if people know about it but you know, there’s this program called Medicare. Covers every American 65 and older. It is, horrors, it’s a single-payer health insurance system run by the federal government. When it was being proposed, people said it would be terrible. You may have heard of something called Operation Kaffeeklatsch.

Or you may not have heard of it. Doctors’ wives were urged to Should Be the Federal Government’s Responsibility” (9/16/08) hold kaffeeklatsches, in which they would try to convince the doctors’ patients what a terrible idea this proposal called Medicare was, and they would play a recording by a fellow named Ronald Reagan, explaining what a terrible idea Medicare was and how it would lead, not only to destruction of health care, but actually the destruction of freedom, it’s quite something, you can listen to it online and, at the end, it basically says Medicare is the root to a totalitarian state. Well, it’s become as American as apple pie. Famous quote among, in the health care field is the, constituent who accosted Senator John Breaux saying, Senator, don’t let the government get its hands on Medicare.

The fact of the matter is we have universal health coverage for our elderly already. The other thing that people say is that it would be impossibly expensive. Now, the truth is, a little-known other big secret, really have to go in deep research and actually look at a couple of official statistics that are easily available to find this out— In this country, the government already pays more health care bills than private insurers do. Medicare and Medicaid together, are already a bigger program than private insurance, all private health insurance. The reason is that we already cover the expensive cases. We already have the expensive cases. The elderly, the very sick who end up being bankrupted and therefore end up poor enough to get Should Be the Federal Government’s Responsibility” (9/16/08) Medicaid are covered by public programs. What’s left, are generally lower-income working adults, and we pay an enormous amount to not cover them. The fact of the matter is that our health care system is wildly inefficient, largely because we have an insurance industry that devotes enormous resources to try to identify who really needs health insurance, so as not to give it to them.

And we have health care providers devoting enormous resources, fighting with the insurance companies, to actually get paid. And the result is a wildly inefficient system. It would be cheaper, by far, to just cover everybody. We pay this huge price because we’ve managed to convince ourselves, or be convinced, that somehow, something that every other advanced country does, and that every other—that we do ourselves for the elderly, is impossible. Thank you—

### Moderator
Claim: Paul Krugman, thank you very much. Pretty well- timed actually. Speaking against the motion, John Stossel, my colleague from ABC News, but we did not discuss this ahead of time, in fact, though both of us have worked a quarter-century at ABC News we’ve never met until tonight. Bizarrely enough, separate orbits I suppose. I kept my feet on the ground. John Stossel’s hard-nosed take on many a liberal policy Should Be the Federal Government’s Responsibility” (9/16/08) assumption is summed up in his catch-phrase, “Gimme a break.” Tonight in a sense we’re discussing, what if you break your arm, or your neck…should the federal government be there to provide your insurance safety net, John Stossel, here to argue against that idea and the motion tonight.

### Scientific Advocate (SA)
Claim: It is intuitive to think that it should, that we have…very poor and helpless people and it’s the job of government, to help them, and, actually we have that, we have Medicaid. If you are poor, you are covered in America. It’s not a good system. It’s tempting to think that a wise government could step in. Paul Krugman has just said look at Medicare, people like Medicare. And that’s true. But, of course they like it, because, it gives you stuff free. People like that. But it’s unsustainable, it’s $35 trillion in the hole. That’s the unfounded liability of Medicare.

They made promises to cover us when we’re 75, when the panel is 75, there’s no way they can possibly do that. Right now it’s working, because there are lots of young people and relatively few older people, but there’s just no way it can be sustained, if a private company tried to run its pension system that way I bet they’d throw the owners in jail. It’s a Ponzi scheme. Now, some people will talk tonight about the widely publicized data that America spends the most on health care, and we do, and studies Should Be the Federal Government’s Responsibility” (9/16/08) have found that we have the worst result. But those studies are deceitful. They compare us by how long we live. But Americans are different. We drive cars more. We kill each other more often. Our accident rate, deaths on the highways triple that of the United Kingdom, we murder each other 10 times as often as the United Kingdom.

When you take that out, we live longer than those other countries. And that doesn’t even include, diet issues, because we eat more and that kills people. A lot of these studies are skewed to make America look bad. Now many people say that the perfect system is in Europe where you have universal health care, and it’s true—most other countries do have systems like that. And it gets rid of the horrible anxiety that some people have in America, will I be covered. And that is horrible, and that does make people sick. But it’s better to be anxious, than to be in horrible pain. Or to be dead. And these universal coverage systems, they don’t guarantee universal access to actual care. In Canada, more than a million families can’t get a doctor. We taped in one town in Ontario where they have a lottery, they have a little box, everybody puts the family name in and, the town clerk pulls out a name, oh, you get to see a doctor this week. There aren’t enough doctors to go around, in Britain, one in eight patients waits more than a year for Should Be the Federal Government’s Responsibility” (9/16/08) treatment in a hospital.

The journal Clinical Oncology says 20 percent of potentially curable lung cancer patients, become incurable on the waiting list. Now why does this happen, well, because when everything is free, when the government pays for it…everybody wants everything. But the government doesn’t have infinite money so the government then must ration. And they do it by not giving you the latest, most expensive stuff, or they make you wait in line. In one town in England they opened a, a new office where you could get dental treatment, people lined up for blocks. Now most of them didn’t get in, so people pull their own teeth. The dental tools are pliers and vodka. This is not a good way to live.

Still, despite the fact they spend less, European care is not remarkably inferior, it’s pretty good for most people. But that’s true only because they freeload off of us. Because most of the innovation comes from America. From the greedy profit-driven companies that want to take as much money from you as they possibly can, they’re the ones who gave us so much good stuff, the MRI’s, the CT scans. ACE inhibitors to lower blood pressure. The statins like Lipitor, to reduce cholesterol, coronary bypass surgery, hip replacement, knee replacement. What will the world be like if we have universal care and we don’t have America to Should Be the Federal Government’s Responsibility” (9/16/08) invent those things? Yes, the private market is awful in many ways and wasteful. Health insurance companies waste all this money on advertising, paperwork, duplication, claims officers trying to make sure you’re not cheating ‘em. It is intuitive to think a single payer would be more efficient. And Michael Rachlis who will speak shortly has written that, a public bureaucracy is cheaper.

And, I used to believe that, when I attended Paul Krugman’s university I was taught that, that the wise elites in Washington and state capitol can plan these things better than these competing companies. But then I became a consumer reporter, and I watched the market work. I watched government and private greedy companies trying to deliver services to people. And now I say that’s nonsense, government can’t do anything even close to the efficient way that private companies do it. When government pays for things, people don’t change, they don’t innovate, they keep doing the same thing they did to get paid. So, as an example look at the inefficiency of the private car companies. They waste millions in advertising on my program, I’m glad they do. And they run these gross ads, they sell cars not based on their engineering perfection or safety, they sell sex and muscle cars. They have these competing dealerships and pushy salesmen selling things like rust-proofing that we don’t need.

Should Be the Federal Government’s Responsibility” (9/16/08) Despite all of that, what’s the worst you get when you buy a car in New York? The worst you can get, is better than this, this is what the planned economies…universal coverage gives us, and I apologize to those of you on the radio, you can’t see I’m holding up a picture of the Trabant, that East German car. This was the best those brilliant East German engineers could produce, it was an awful car, you had to put the oil and gas separately and shake the car to mix ‘em together. As soon as the Berlin Wall went down, this disappeared, because it couldn’t compete with the mediocre products that produced—were produced by our competing companies. I don’t want to have this kind of health care, and that’s what we’ll get if government runs it, at the beginning, government could do things well, you get the Peace Corps, New York’s public schools. But after a while it deteriorates because they don’t change, they don’t improve, maybe once every 12 years they change a little. If we have universal health care, this is what we’ll get.

### Moderator
Claim: Thank you, John Stossel. We have a Canadian in the house tonight, Michael Rachlis. A physician who— Maybe we have a lot of Canadians in the house tonight. Michael Rachlis is a physician who has lived on the Should Be the Federal Government’s Responsibility” (9/16/08) other side of the US-Canada border, he trained in Canada, he practices medicine there. He is a health policy expert there. And given that Canada so often is the example cited as— for why universal coverage is the solution or why universal coverage is the problem, we are pleased to have Michael Rachlis standing at our podium to argue for the motion, “Universal health coverage should be the federal government’s responsibility,” Michael.

### Conspiracy Advocate (CA)
Claim: Thank you very much, John. And I’d like to thank the Rosenkranz Foundation and Intelligence Squared very much for inviting me to New York, I’ve had a wonderful time while I’ve been here. I also have a strong personal connection to the United States, my wife is an American and I visit her family on a regular basis and see the great health care that the United States has, and the terrible health care that this country has. And one is given to her father and one is given to her uncle, and the difference is insurance coverage. I’ve also slept overnight, I don’t want to give the impression I sleep around but, I’ve slept overnight in 23 US states and I have a pretty good idea of the health care system in this country as even my daughter has used it when she had a catfish spine through her palm in Florida.

Now, as Paul has said, that this is very much a question of values. And it’s actually a case where you can have your cake Should Be the Federal Government’s Responsibility” (9/16/08) and eat it too, in fact, you can only eat your cake if you have it, in other words, you can only get cost control if you—if you have equity. And as Paul has said, as we’ve heard others say, the US system costs the most in the world, it denies care to tens of millions of Americans and I have seen that personally. And the international performance and quality is just so-so. Does this really reflect American values. Is this really what you want out of your health care system. In Canada, our values for health care go back to Tommy Douglas, the premier of Saskatchewan between 1944 and 1961. And when Tommy was a boy in my hometown of Winnipeg, Manitoba, he developed osteomyalitis, an infection in his leg. There were no antibiotics at the time, the recommendation of the doctors were that his leg should be amputated.

Fortunately Dr. Robert Smith, a noted surgeon, saw Douglas, told him that because he was an interesting case, he would treat him for free if he allowed teaching students to--allowed Dr. Smith to teach with him. Douglas was left with the impression all his life if he hadn’t been fortunate enough to run into Dr. Smith and be interesting, he would’ve lost his leg. Then a few years later, after Douglas’s government in Saskatchewan had implemented universal hospital insurance and universal medical insurance, despite the fact that in the 1940s being the poorest province in Should Be the Federal Government’s Responsibility” (9/16/08) Canada, Justice Emmett Hall, a Supreme Court justice in Canada, and if anything a conservative, was asked by our then- Prime Minister, John George Diefenbaker, to review our health care system. His conclusion, was that we should move ahead with medical insurance ‘cause we already had hospital insurance. The main reason he gave was, efficiency. He said that it would be a lot cheaper to have a single-payer system, than to have multiple private payers. And so his vote was for efficiency. And those are the values on which our system are based. Equity and efficiency.

What are the results? Fifty years ago we had the same as your country. We had the same health status. We paid the same amount for health care. Fifty years later, all Canadians are covered for hospitals and physicians service. In the United States millions have no coverage, and tens of millions have, have inadequate insurance. We actually get more of most services than Americans do. We have more visits to doctors every year, more days in hospital, more days in nursing homes, we take more prescription drugs than you do. I mean, not all of these things are good, too much health care can kill you. But even though there are some services we don’t get as much of, like nobody in the world does as much cardiac interventions as you do, the Belgians are close, but nobody really else is close, we Should Be the Federal Government’s Responsibility” (9/16/08) actually do more bone marrow transplants. We do more lung transplant surgery. Toronto is an international center for lung transplants. And that, far from lacking innovation, we’re the country that brought you insulin, we developed bone marrow transplantation. When Paul Tsongas was telling the electorate years ago that he wouldn't have got his service in Canada, it greatly offended the two people, two doctors in Toronto who had developed the procedure. And all of this costs way less, ten percent of our GDP compared to sixteen percent in your country. How does that happen? Well, half of the extra expense is administration, because of the extra expense of this multiple payer system. The other half is due to higher prices because you don’t have effective cost control because you don’t have a single payer. Now, this must cost us a fortune, we must be basket cases. The Canadian Federal Government has run surpluses equal to one to two percent of our GDP for eleven years in a row. There’s no problem affording health care when you do it because you're concerned about other people. Then you can make it affordable. And our health status, of course, is not a true reflection, but in other, but from what you’ll hear, perhaps, from these panelists and others, you’d imagine Canadians are dying in the street waiting for medical care. In fact, we now live three years longer on average than you do. This is over a fifty year period, we’ve now got a three year longer life expectancy. Our Should Be the Federal Government’s Responsibility” (9/16/08) infant mortality rates are twenty to thirty percent lower than yours. And finally, it’s a great boon to business in our country. The province of Ontario has, the last couple of years, has been assembling more motor vehicles than any US state including Michigan. The costs to manufacturers are nine percent of payroll for health care costs in this country, one and a half percent in Canada. That our manufacturing center is under pressure, but it would be gone without our health care system. So, Canada has done well, but Canada is not the outlier. Canada is the outlier in North America. Around the world wealthy countries, all wealthy countries that Americans would think of when they think of other countries they could live in, with a comparable standard of living, all other countries have a mainly public system. And Canada does have problems in its system, just as every country has its problems. Our problems are second order problems. We’ve dealt with coverage, and we’ve mainly dealt with affordability. So we, we have waits and delays in Canada, they're improving, but we do have them. But France and Germany have much shorter waits for care than you do in this country. So, despite the individual anecdotes that you're going to hear, health care in Canada or Germany or France are remarkably similar to the US. A recent letter to the editor by Lou Holman from Rochester New York reported on his heart attack in Toronto while he was visiting, and he was having his surgery within one hour of calling Should Be the Federal Government’s Responsibility” (9/16/08) the ambulance. So, let’s get serious. Health care is pretty standard in most developed countries, we have similar problems in delivery, you are the only ones that really have problems with coverage and affordability. So, it comes back to values. If you focus on equity, you get a bonus. You get cost control. If you focus on cost control, you don’t get equity or cost control. And I strongly encourage you folks to vote for our side. Thank you.

### Moderator
Claim: Thank you Michael Rachlis. I am John Donvan, and this is Intelligence Squared US, Oxford-style debating. We have six panelists for and against the motion. The motion in this debate is, “Universal health coverage should be the federal government’s responsibility.” We are halfway through the opening statements at this point, halfway to our Q&A section, but I’d now like to introduce, arguing against the motion, Sally Pipes, author of The Top Ten Myths of American Health Care: A Citizen’s Guide. She is president and chief executive officer of the Pacific Research Institute, a think tank based in California. She also comes from Canada, but not only does she argue against this motion, two years ago she completed a personal journey and became a citizen of the United States. Sally Pipes.

### Scientific Advocate (SA)
Claim: And I'm still Canadian, and proud of it. I am against the Should Be the Federal Government’s Responsibility” (9/16/08) proposition that universal coverage should be the responsibility of the federal government. I do think that everyone here would agree that the key goal for America is affordable, accessible, quality health care. The question is, how do we achieve that goal? There are two competing visions for health care reform in this country today, and also for achieving universal coverage. One focuses on government, mandates, and taxes, while the other focuses on free markets, innovation, and empowering consumers. Today that government vision is on the rise. The long term goal of most liberals is a Canadian-style, single payer, Medicare for all, health care system. These liberals tell us that socialized systems like those in Canada and Europe are better and cheaper and can provide universal coverage for all of us. They also site, as Michael did, life expectancy and infant mortality as evidence of the superiority of these systems. Well, let’s look at life expectancy. People who make this claim usually note that life expectancy is higher in Canada and Europe. The World Health Organization ranking does not measure, though, the quality of a health care system. The World Health Organization ranks systems that treat people equally higher than those that treat people well. Now let’s look at infant mortality. The US does have a higher infant mortality rate than Canada, hence their government system is rated better. The reality is that the United States, with its superior neo-natal care facilities, has Should Be the Federal Government’s Responsibility” (9/16/08) allowed more high risk babies to live. But this also pushes the infant mortality rate higher because of a greater number of at risk births, babies being born. And in other countries many of those at risk babies do not live and are not counted in infant mortality statistics. Earlier this year, a woman in Calgary was expecting quadruplets, there wasn’t a single neo-natal unit for that woman to deliver her babies. She was airlifted to Great Falls, Montana, a city of fifty-five thousand, where she successfully delivered her quads. I'm from Vancouver, Canada, I was home three years ago visiting my mom, and the front page story in the Vancouver Sun was, “Pregnant Mother with Twins Airlifted to Edmonton, Alberta.” When they came back, the husband, in the interview, on the front page of the Sun said, the Canadian Health Care System is that of a third world country. Now let’s look at adult cancer survival rates. A study published in the August, August issue of the British Journal Lancet Oncology said that America is much better at treating cancer than Europe or Canada. Researchers found that Americans have a better survival rate for thirteen of the sixteen most prominent cancers. For example, breast cancer survival rate among American women is eighty-three point five percent, whereas in Britain, seventy percent. American men and women are thirty- five percent more likely to survive colon cancer than their British counterparts. Now, I have discussed the data, but let’s look at Should Be the Federal Government’s Responsibility” (9/16/08) the reality of universal coverage systems in Canada and Europe. Michael Moore, in his movie Sicko, where I have a cameo appearance, points to the wonderful health care systems in Canada, France, England, and Cuba, and he says they're all free. The US does spend, as has been pointed out, sixteen percent of its gross domestic product on health care, while Canada spends on the range of ten to eleven percent. The reason that Canada spends ten to eleven percent is because the government sets a global budget and says, that’s what we’re spending. And what is the result? Long waiting lists for care, rationed care, and a lack of access to the latest technological equipment. Today in Canada there are eight hundred and twenty-seven thousand Canadians waiting on a waiting list for procedures. There are three point two million, or ten percent of our population, waiting to get a primary care doctor. The average wait in 2007 from seeing a primary car doctor to getting treatment by a specialist was eighteen point three weeks. That’s over four months. Canada ranks thirteenth out of twenty-four OECD countries in MRI’s, and eighteenth out of twenty-four in CT scans. When I turned fifty, I know it’s hard to believe that I turned fifty, but I did, my doctor in San Francisco said, you have to have a colonoscopy. And I said, well, there’s nothing wrong with me, I don’t need a colonoscopy. Well anyway, I had one. But my mother in Vancouver, Canada, three years ago, July, started feeling ill and Should Be the Federal Government’s Responsibility” (9/16/08) was convinced she had colon cancer. But her doctor kept saying, you're old, there’s nothing wrong with you, go to bed, sleep more. Finally in December my mom started hemorrhaging from her colon. Her doctor said, you have to go to the hospital in an ambulance to get service in the emergency room--I could not take her. After being in the emergency room for a number of hours she was then transferred to the transit lounge where she waited for two days to get a bed in a room. But she was not counted as waiting in an emergency room because she was in a transit lounge. The issue is that she was too old, it was decided by the health care system, to have a colonoscopy, when she was convinced that she was ill. And what about people with government coverage wait and wait in socialized systems, except the politicians. Belinda Stronach, former Canadian MP, opposed any privatization of Canadian health care. And yet, when she was diagnosed with breast cancer in June of 2007, on the advice of her doctor, she flew to UCLA and had her breast surgery and paid for it herself. As my friend in Vancouver, Dr. Brian Day, orthopedic surgeon, and head of the CMA, Canadian Medical Association, told the New York Times, Canada is a country in which your dog can get a hip replacement in under a week, and in which humans wait two to three years. Is this the kind of government run health care system Americans desire? Think about the post office. Think about the DMV and the handling of Should Be the Federal Government’s Responsibility” (9/16/08) Katrina. A majority of Americans rate the quality of our, our system as excellent, or good. In Canada, according to Decima, only thirty-three percent rate the system as a grade A or B, and twenty-two percent say it’s failing. Canadians intuitively know that long waits are the outcomes of government run systems. While we can no longer deny there are problems in health care, markets, consumer choice, and innovation will solve them, rather than putting the government in charge.

### Moderator
Claim: Thank you, Sally Pipes.

You owe me eight seconds. Striding to the lectern now is Art Kellermann, who is a surgeon at the ER at Grady Memorial Hospital, Atlanta’s public hospital. He’s also professor of emergency medicine at Emory. And given that, as we know, so often the solution that the uninsured come to when they need medical care is to go to an emergency room, and it’s extremely valuable to us to have on the panel somebody who is at the receiving end of that process. I give you Art Kellermann.

### Conspiracy Advocate (CA)
Claim: Thank you. Actually, I'm not a surgeon, I am just an ER doc, and I don’t have the distinguished background of my fellow panelists, but I have treated thousands of patients, insured and uninsured, Should Be the Federal Government’s Responsibility” (9/16/08) and I’ve also broken bad news to hundreds of families. I want to tell you about one of them that I’ll never forget. It took them two hours to reach Atlanta from the north Georgia mountains. I faced them across the outstretched body of their son. The ventilator hissed rhythmically, ten breaths per minute. I spoke first. Your son was in a terrible crash, I said. The ambulance crew could tell he was severely injured and called a helicopter. He reached us about three hours ago. He has several injuries, a collapsed lung, internal bleeding, but these aren't his most serious problem. His brain injury worries us the most. That’s when his mother interrupted me. She said, doctor, I don't know how to ask you this, but I must. My husband lost his job six weeks ago, I work, but my employer doesn't offer health insurance. Is my son going to get the care he needs? Momentarily taken aback, I replied, ma'am, you're at Grady Hospital, one of the finest trauma centers in the south, I swear to you, we will do everything in our power to save your son. I meant what I said that night, but I didn't tell her the whole truth. I didn't tell her that our best probably wouldn't be good enough, and that if her son survived he’d probably be disabled for the rest of his life. I didn't tell her that she and her husband would be billed for the helicopter flight, and the days or weeks to come in the intensive care unit, and that the total would probably reach a hundred thousand dollars, maybe a whole lot more. I didn't tell Should Be the Federal Government’s Responsibility” (9/16/08) her that she and her husband would empty their savings and mortgage their home in an effort to pay the bill, and that it wouldn't be enough. And that the coins put in a coffee can at the local diner wouldn't come close to covering the difference. I didn't tell her that the unpaid balance of her son’s bill will push Grady hospital closer to insolvency, closer to its own crash, and if Grady closes, north Georgia, a region of more than five million people, will lose its only level one trauma center, its only burn unit, its only poison control center, its only emergency psychiatric unit, and seven hundred and fifty inpatient beds. And that’s not all. If Grady closes, metro Atlanta’s private hospitals, already overburdened by population growth, will topple like dominos one after another. Ladies and gentleman, for me this debate is not an idle intellectual exercise, it’s about lives. Three hundred million American lives. I support this resolution for three reasons. First, because our failure to cover every American is a national disgrace. Second, because we’ll never achieve universal coverage if we don’t make health care in this country more affordable. And third, because the only way we can make health care more affordable and cover everyone is through a well-regulated health care marketplace, and to do that the Federal Government must be involved. Now let me be clear, the majority of Americans do not want a government-only health care system, but they absolutely want the government involved, as a Should Be the Federal Government’s Responsibility” (9/16/08) referee, as a cop, to make sure that everybody plays by the rules. The other side of this debate will try to convince you that rising health care costs are due to government interference. Well, they’ve got it backwards. The problem is not government interference with the health care industry, the problem today is health care industry interference with government. That’s why the business of medicine is booming. Record profits, huge executive salaries, bonuses, health care costs spiraling out of control year after year after year. But the caring side of medicine is failing. On the front lines, doctors, nurses, and other health care professionals are nearly as frustrated as you are. The nation-wide crisis in emergency care is a case in point. Every major challenge we face, ER’s packed with patients, dangerously long waits to be seen, a half million ambulances a year turned away to more distant hospitals, and fewer specialists than ever willing to take ER call. All of them are due to the fact that the economics of health care encourage hospitals to favor elective cases over emergency cases. Good for business, bad for patients. And it’s terribly expensive. Country music star Dolly Parton once quipped, you have no idea how much it costs to look this cheap. The same can be said about American health care. You have no idea how much it costs to run this poorly. We spend two trillion dollars a year on health care, and a trillion dollars is a lot of money. Put this in perspective, a million seconds ago was Should Be the Federal Government’s Responsibility” (9/16/08) last week. A billion seconds ago Jimmy Carter was inaugurated president. A trillion seconds ago was thirty thousand BC. For two trillion dollars we can take good care of everybody in this country and have a lot left over, and you don’t have to look outside the US for proof. If everybody practiced medicine as efficiently as they do in Rochester, Minnesota and Salt Lake City, Utah, Medicare could pay thirty percent less to doctors and hospitals, and everybody would get better care. But it won't happen on its own, because one person’s waste is another person’s revenue stream. That's why we need a cop on the beat, and the only cop with the clout to get the health care industry to play by the rules is the federal government. My side has given you several reasons to vote for tonight’s resolution, but the most compelling one of all is your own self interest, because a health care system that doesn't work for everyone may not work for you when the chips are down. Take it from me, an ER doc, no one can predict when a life threatening emergency may strike, but if it does, you’ll want your hospital to go the extra mile, not your ambulance.

### Moderator
Claim: Thank you. Thank you Art Kellermann. Our final speaker, speaking against the motion, is Michael Cannon. He is the director of health policy studies at the Cato Institute, which is the Should Be the Federal Government’s Responsibility” (9/16/08) nation’s leading think tank, formed around the philosophy of libertarianism, which can very crudely and primitively, simplistically be summed up as “live and let live.” But I suppose the question is, do you need insurance to follow through on that? Michael is arguing against, broadly and firmly against the notion of universal health coverage being the responsibility of the federal government. Michael?

### Scientific Advocate (SA)
Claim: Thank you. We do have a moral obligation to care for those who are in need of medical care, but that’s not where the disagreement lies tonight. Where we disagree is over whether universal coverage is going to help us fulfill that moral obligation, or as I will argue, make that moral obligation harder to fulfill. So, you’ve heard a lot of things about how wonderful universal coverage will be. You’ve heard that it will probably be all things to all men and women. They’ll make us taller and thinner and it’ll save us money. So let’s look at a couple of the actual likely effects of adopting universal coverage here in the United States. First off, it’s not going to save us money. Yes, other countries do universal coverage, and they do it on the cheap, or they do it for less money than we do, but there’s absolutely no way that can happen in the United States, and here’s why. Expanding insurance coverage means more people are going to go to the doctor, more people are going to use medical services. That costs Should Be the Federal Government’s Responsibility” (9/16/08) more money. The urban institute estimates that it would cost at least a hundred and twenty billion dollars. That’s at least, it’s going to cost a lot more than that. Now, with the government in control, it’s tempting to think that we would be able to ratchet that spending down over time so that we’re more in line with other, other nations. But with the government in control of the, whatever universal coverage scheme you can dream up, the industry is going to prevent the government from doing just that. Art Kellermann is right, the industry does have too much influence over government spending in the Medicare program. And they use that influence to prevent the government from reducing, from reducing spending, from eliminating inefficient spending, wasteful spending. They’ve done it for Medicare’s entire history. So although it’s tempting to think that we could do health, we could do universal coverage, and we could have, and we could save money on it in the process, we would have an easier time moving the uninsured to Switzerland than we would have moving Switzerland’s spending levels here to the United States. Now, you’ve also heard that universal coverage would improve the quality of care. We actually have some pretty systemic problems when it comes to quality here in the United States. I'm not a big proponent of the US health care sector. The experts tell us that if you have, the uninsured only get recommended--what the evidence says, is the best recommended Should Be the Federal Government’s Responsibility” (9/16/08) care about half of the time. But you know what, quality problems are so systemic that people in Medicare, in Medicaid, and people in the United Kingdom’s national health service, which is their universal coverage system, also only get quality, what the evidence says is best care about half of the time. Government, and then the reason is that government doesn't pay for quality, and it’s been lagging in the private sector in coming up with quality improving innovations. Now in the private sector we have the same quality problem, but I’ll have more to say about that in a moment. One big quality problem is that we have alarming rates of medical error here in the United States. Universal Coverage is not going to help to prevent these medical errors. It’s not going to help nurses read doctors’ chicken scratchings and avoid the errors associated with those. It’s not going to encourage physicians and other clinicians to wash their hands between patients so they're not passing on infections. Nor is it going to prevent errors by encouraging doctors to follow standardized protocols when inserting a central line. The same institute of medicine, I'm surprised this statistics hasn’t come up today, but I’ll bring it up, the Institution of Medicine, the commission where Dr. Kellermann served, estimated that eighteen thousand Americans die every year from lack of health insurance. I believe that. That seems plausible to me. The same Institute of Medicine, however, estimated that up to a hundred Should Be the Federal Government’s Responsibility” (9/16/08) thousand Americans die every year due to medical errors in hospitals. All universal coverage is going to do is bring more people into that system, broken system, it’s not going to do anything to fix that system. And yes, we might save the one, this one life over here, from this person who didn't have health insurance. We’d be ignoring these five deaths over here. Another quality problem that we have in the United States is we have alarming disparities in health outcomes. We have disparities between different racial groups of fifteen to twenty years in terms of life expectancy. And some Americans face mortality risks similar to what you see in Russia and sub-Saharan Africa. Universal coverage is not going to do anything to solve that problem. Sherry Glied, who’s the head of the Mailman School of Public Health at Columbia University wrote recently, quote, socio-economic differentials in health are large and growing, and appear to be growing, uh, in countries that have universal coverage as well as those that do not. End quote. Now, it’s true, universal coverage may save some lives. It may save this one life over here. So that seems to be something in its favor. But actually here the news isn't even all that good, because health economists tell us that if you have a dollar to spend on improving health, there’s absolutely no evidence that spending that dollar on universal coverage is going to get your more of an improvement in health than spending that dollar on any number Should Be the Federal Government’s Responsibility” (9/16/08) of other things, including clinics, reducing medical errors, improving nutrition, fighting poverty, or even improving education. So, ironically, to vote for universal coverage does not show how much, how much you care about your neighbor’s health, it actually shows how little you care about your neighbor’s health, because you're willing to forgot he added health benefits that might come from some of the, from spending that dollar on some of those other strategies. Now there is something very wrong with America’s health care sector, something that universal coverage will not solve. You can see what’s wrong, you can see what it is, I think, when you look at the Veteran’s Health Administration. Now I can't remember if this has come up already, if Professor Krugman mentioned the Veteran’s Health Administration. But this is hailed by people who support universal coverage as how, as exhibiting the superiority of government when dealing with the problems presented by health care. I think that the VA story is very important, but I don’t think it tells the story that supporters of universal, of universal coverage think that it tells. The VA has made impressive strides, using electronic medical records, to focus on preventive care, improving quality, avoiding medical errors. The reason is not some inherent superiority of government, the reason is really just two features of the way the VA is organized. They're called integration and pre-payment. If Should Be the Federal Government’s Responsibility” (9/16/08) anyone cares we can talk about what those mean later on. But those features are not unique to the Veteran’s Health Administration. They exist in private health plans all over the country, you know them as plans like Group Health Cooperative, Kaiser Permanente, and those plans are using health information technologies to reduce costs, improve quality, and reduce errors. Now why don’t you have electronic medical, electronic medical records, like you have electronic financial records? Why doesn't the hospital remember your medical history, your child’s medical history, your allergies, and these sorts of things? Well, the biggest reason is America’s pursuit of universal coverage. Medicare is America’s great experiment with universal coverage, and it’s also the largest purchaser of medical care in the nation. And Medicare actually penalizes doctors and hospitals if they use electronic medical records to reduce costs, or to avoid medical errors. Electronic records help avoid duplication, but Medicare pays for duplication. So, if you adopt those, you make less money. Health information technologies avoid, help to avoid medical errors, but Medicare pays for medical errors. So, if you adopt those health information technologies, you lose money. So, providers make less money if they do these things that are in patient’s interests. Meanwhile, supporters of universal coverage are trying to keep those private health plans that use these things from participating in Medicare. With doesn't Medicare stop Should Be the Federal Government’s Responsibility” (9/16/08) paying for duplication and errors? Because government resists change. So, I don’t think the VA success, the VA success has demonstrated government’s brilliance so much as how government actually impedes the support of quality affordable health care. Thank you.

### Moderator
Claim: Thank you, Michael Cannon.

## Round 2

### Moderator
Claim: Well, you’ve now heard all of the opening statements, and we’re at the point of being able to share with you the poll results we took among you, the audience, when you first arrived. And they’ll come up on the screen behind me. Before the debate began forty-nine percent of you were for the motion, twenty-four percent against, twenty-seven percent undecided, which you know means that if you three leave right now, you’ve won. Yeah… I think we’re past that point. John Stossel, Art Kellermann suggested that there’s a conflict between keeping people healthy and making money keeping people healthy. What about that?

### Scientific Advocate (SA)
Claim: There are conflicts always in making a profit and delivering service to your customers. And you get rich if you service your customers well. The hospital that keeps people healthiest gets a Should Be the Federal Government’s Responsibility” (9/16/08) reputation for doing a good job, and that’s how capitalism works, you get rich by doing well.

### Moderator
Claim: But I heard you also argue that you feel there would be much less innovation in the US system if we went, if there were not a profit motive behind development.

### Scientific Advocate (SA)
Claim: Totally. We take the benefits of the profit motive for granted all the time. The fact that I can go to a foreign country, stick a piece of plastic in the wall, and cash will come out. And I can give that card to a total stranger who doesn't even speak English, and he’ll rent me a car for the week. And when I get home Visa or MasterCard will have the accounting correct to he penny. But the government can't even count the votes accurately. And yet our instinct… …is to go to government.

### Moderator
Claim: Art Kellermann?

### Conspiracy Advocate (CA)
Claim: We had a lot of talking about cars earlier, and, I think everybody is familiar with the economic problems that GM is having right now, and actually I think GM’s cars are better than Trabant. But they're carrying about five billion dollars a year in health care costs. Several years ago the CEO at GM testified before Congress and said two billion dollars out of their bottom line every year Should Be the Federal Government’s Responsibility” (9/16/08) was just for drugs. Now meanwhile, Pfizer, the second largest pharmaceutical company in the United States, last year reported nineteen billion dollars in profit, thirty-seven percent profit margin. Now, I’m a big believer in market economics too but I don’t want our auto industry to wind up in Ontario, I’d like to keep a lot of it in Michigan. So I don’t understand, I mean I do think profit is good but I think when one industry can basically drive another one into the ground and harm our country, regulation is outta whack, and let me just—one other point. The FDA cannot take the cost of a drug into consideration when it approves a new drug, it just has to be better than nothing. That’s not by accident. Congress prohibits the FDA from considering cost-effectiveness of new drugs. That’s not the case in the UK, it’s not the case in other countries, it should not be the case here—

### Moderator
Claim: Paul Krugman, I’ll come to you in just a moment, Michael Cannon, against the proposition—

### Scientific Advocate (SA)
Claim: —reason you raised, you raised earlier, Art, is that the industry has way too much influence when the government gets involved, and it’s nice to think that we could have this wonderful universal Should Be the Federal Government’s Responsibility” (9/16/08) coverage plan and we could just get the industry out of it, we could just not have the industry be a part of it, we could…cut off their influence. But we know that the industry’s always going to be around, we know that there’ll always be drug companies and greedy private health insurance companies. And Republicans who will mess things up like they messed up FEMA and they mess up everything else. So you can’t say that universal coverage is this wonderful idea and we can separate out this part--this is an inherent part. Unless you’ve— all the rent- seeking from the industry, and all the buffoonery from the Republicans, unless you have a plan to abolish Republicans they’re part of your plan.

### Moderator
Claim: Paul Krugman—

### Conspiracy Advocate (CA)
Claim: That, that—

### Moderator
Claim: Paul Krugman for the motion—

### Scientific Advocate (SA)
Claim: Maybe we can put them in camps.

### Conspiracy Advocate (CA)
Claim: That came—

### Scientific Advocate (SA)
Claim: Death camps.

Should Be the Federal Government’s Responsibility” (9/16/08)

### Moderator
Claim: Paul Krugman for the motion, please—

### Scientific Advocate (SA)
Claim: I meant happy camps—

### Conspiracy Advocate (CA)
Claim: That came wonderfully into exactly what I was going to say, we have had Katrina used as an example and I thought to myself as I always do it must be wonderful to be a conservative because, you can take control of the government, make a mess of things and say see, that proves my point, isn’t that wonderful. And I would also add—

### Scientific Advocate (SA)
Claim: You can, you can be—

### Conspiracy Advocate (CA)
Claim: —since John Stossel— Since John Stossel has used vote-counting, you know, it’s not that the government’s, this particular government isn’t able to count the votes, it was sort of that they didn’t want to?

### Moderator
Claim: Michael—Michael Cannon.

### Scientific Advocate (SA)
Claim: But do you—what’s your plan to deal with Republicans, do you want to abolish them or are they part of your plan. Should Be the Federal Government’s Responsibility” (9/16/08)

### Conspiracy Advocate (CA)
Claim: Medicare has its problems, but has continued to function. We have a well-established system, it continues—Social Security, is a system that’s working with high efficiency. The point is to get this thing— It is. If you have—pay any attention it works fine. And if you—

### Scientific Advocate (SA)
Claim: If you pay any attention to Medicare you have to know that one- third of the money spent is wasted, that it rewards doctors—

### Conspiracy Advocate (CA)
Claim: And private insurance—

### Scientific Advocate (SA)
Claim: —for medical errors—

### Conspiracy Advocate (CA)
Claim: And private insurance? That’s the thing, I— Actually, can I just—I wanted to ask a question. And—

### Moderator
Claim: Please—please do—

### Conspiracy Advocate (CA)
Claim: —and I wanted to ask, actually two questions, to the audience. First, how many Canadians, would Canadians in the room please raise your hands.

### Moderator
Claim: We have about seven hands going up— Should Be the Federal Government’s Responsibility” (9/16/08)

### Conspiracy Advocate (CA)
Claim: Okay, not as many as I thought. Okay, of those of you who are not on the panel who are Canadians,, how many of you think you have a terrible health care system. One, two—

### Moderator
Claim: We see—almost all of the same hands going up.

### Conspiracy Advocate (CA)
Claim: Bad move on my part. I’ve got a selected--all right, I won’t try it. But I will say, that—

### Scientific Advocate (SA)
Claim: We should check their papers.

### Conspiracy Advocate (CA)
Claim: Well, we’ve got—no, that’s…

### Moderator
Claim: Sally Pipes—

### Conspiracy Advocate (CA)
Claim: —gotta be honest, and—

### Moderator
Claim: Let’s bring Sally Pipes into the conversation, she is against the motion.

### Scientific Advocate (SA)
Claim: I just wanted to talk a little bit about Medicare, remember when, in 1965 when Medicare and Medicaid came in, and the cost was about $3 billion, and it was projected to cost $12 billion in 1990.

Should Be the Federal Government’s Responsibility” (9/16/08) Well in fact it cost $107 billion, last year it cost $427 billion, it’s estimated in 2017 to cost $884 billion, the Medicare trustees way the program will be broke in 2019. There is no cost control in Medicare, it is completely out of control. I think we need to give vouchers to people on Medicare and put consumers and seniors back in charge of their health care. But the issue is, are—is everyone loving Medicare. The recent Congressional commission said, that one in three Medicare patients is having a very hard time getting a doctor, and I have talked to many seniors, who are having a hard time getting a doctor under Medicare. Because the reimbursement rates by the government for the 8000 procedures on the list are too low and docs say I’m not going to do it.

### Moderator
Claim: Sally Pipes, hold on just a moment because I want to come back to you for another question, I want to at this point tell the audience that in a couple of minutes I will be coming to you for questions and there are microphones being held by ushers toward the rear. And if you raise your hand, they will find you and then I will find you so just wave in my direction to get my attention. Sally Pipes and Michael Rachlis, you’re both born, raised, trained in Canada, but hearing you, Michael, argue for the proposition, and Sally Pipes hearing you argue against it, I’m—are you from the same country? Should Be the Federal Government’s Responsibility” (9/16/08)

### Conspiracy Advocate (CA)
Claim: It’s hard to tell. I—

### Moderator
Claim: No, but seri—but what about—

### Conspiracy Advocate (CA)
Claim: I—

### Moderator
Claim: —what about the Canada that Sally describes—

### Conspiracy Advocate (CA)
Claim: I think that, well, you’ve heard the other side say you can’t trust research. So, I guess that we just have to go on gut feeling and spin, is that right? So that I—

### Scientific Advocate (SA)
Claim: Did we say that—?

### Conspiracy Advocate (CA)
Claim: —I think that—

### Scientific Advocate (SA)
Claim: No, we did not—

### Conspiracy Advocate (CA)
Claim: Sally has—

### Scientific Advocate (SA)
Claim: Can we check the record—

### Conspiracy Advocate (CA)
Claim: Sally has mentioned some—well, disparaging the international Should Be the Federal Government’s Responsibility” (9/16/08) research, in fact, one of the people in the audience is one of the key people doing international research, maybe she can speak for herself, as to whether or not it is useless, but I feel that—

### Conspiracy Advocate (CA)
Claim: —I feel that the international research is valuable and it shows, that by and large, other countries are delivering the same level of care, the unfortunate thing that happened to your mother, Sally, I’m very sorry for that, could easily happen in the United States, it could happen in any other country. A family doctor, who doesn’t, you know, for a variety of reasons, take a particular complaint seriously, that stuff happens, the rate of medical error in all developed countries is about the same, although the studies have been done slightly differently, eight countries have done studies. In all countries, 5 to 10 percent of all deaths are preventable deaths that occur in hospital. So that—modern health care has some very serious problems and is—this country in fact is a leader in looking at quality in health care. Dr. Donald Berwick, the founder of the Institute for Health Care Improvement, is the person, the preeminent person in the world, on this issue. But—

### Moderator
Claim: Sally— what about that though— Should Be the Federal Government’s Responsibility” (9/16/08)

### Conspiracy Advocate (CA)
Claim: —but Canada doesn’t have problems with coverage, and neither does Germany or France, and we don’t have problems with affordability. We have second-order problems because we haven’t dealt with the quality issues.

### Moderator
Claim: Michael, let me give Sally a chance to respond—

### Scientific Advocate (SA)
Claim: Well, I mean if you look at the Canadian health care system, you know, it’s not free, as Michael Moore, Canadians pay dearly for the system through their taxes. What tax increases would we have to have here in America, to provide another $120 billion—

### Conspiracy Advocate (CA)
Claim: I think you could cut—

### Scientific Advocate (SA)
Claim: —for universal coverage—

### Conspiracy Advocate (CA)
Claim: You could cut taxes.

### Scientific Advocate (SA)
Claim: Well, I don’t

### Conspiracy Advocate (CA)
Claim: That’s what the Congressional Budget Office said in 1994, that adopting a single-payer system would save so much money on extra administration, and then— Should Be the Federal Government’s Responsibility” (9/16/08)

### Scientific Advocate (SA)
Claim: But—well—

### Conspiracy Advocate (CA)
Claim: —you could cover everybody.

### Moderator
Claim: Art Kellermann—

### Scientific Advocate (SA)
Claim: Well, you, you ration—

### Moderator
Claim: Sally—

### Scientific Advocate (SA)
Claim: —you ration care in Canada, and people— wait, and my mother is not a single example, there are thousands of examples through—in the mainstream media from the Toronto Star to the Globe and Mail, it’s all there. People—a woman stood up on Parliament Hill when Paul Martin was Prime Minister, and she stood there with her health care, Canada Health card, and she said what good is this Canada Health card, when I don’t have access to the health care system.

### Moderator
Claim: Art Kellermann. Our ER man.

### Conspiracy Advocate (CA)
Claim: First of all I heard some real interesting comments made from the other side earlier and I just want to say, y’all can’t make stuff up Should Be the Federal Government’s Responsibility” (9/16/08) ‘cause none of you are running for President.

### Scientific Advocate (SA)
Claim: Mike and I are ineligible—

### Conspiracy Advocate (CA)
Claim: Second thing. Sally, you mentioned about Medicare. You know, we’ve had a recent experiment with private health plan efficiency, private health plans have started administering Medicare. They’re getting paid an average of 12 percent more per enrollee, that’s nearly $1000 more per person than traditional Medicare administers the same program. This is going to add 8.5 billion to the cost of Medicare this year in 2008, and since 2004, those plans will have sucked an extra $33 billion out of Medicare trust fund, without improving the care to beneficiary, so, again, Michael, I think you’re right, we got a lotta people that have gotten their hands around the federal till, and have made federal government a cash cow. I think federal government needs to be a watchdog.

### Moderator
Claim: Let’s bring the audience into it because—

### Scientific Advocate (SA)
Claim: But—I want to agree with, I want to agree with Art. I want to agree with him about the—

### Moderator
Claim: This is Michael Cannon.

Should Be the Federal Government’s Responsibility” (9/16/08)

### Scientific Advocate (SA)
Claim: —about the, about how Medicare Advantage costs the taxpayers more. I want to agree that--and I disagree with Sally that I don’t think that we do any better in terms of health outcomes here in the United States. But those things don’t get you where you think they do. The fact that private insurance companies are ripping off the taxpayers through Medicare is problematic, but the alternative is to let the doctors in the hospitals do that because they’re the ones who’ve been doing that for the first 40 years.

### Conspiracy Advocate (CA)
Claim: I want to say one other thing—

### Scientific Advocate (SA)
Claim: And—no, I’m not done yet. So, and the fact that we don’t lead the—I don’t think we lead the world in terms of health outcomes but that just means that we’re doing poorly, other nations are doing poorly, no one is innovating in order to make those improvements in medical errors, except, you know, we got the Kaisers and the Group Healths out there that are actually doing this, and you just made an argument against having them participate in Medicare, you’re trying to keep them—those innovations out of a government program.

### Moderator
Claim: Art, hold your response to that to perhaps your summing up at Should Be the Federal Government’s Responsibility” (9/16/08) the two minutes because we—

### Conspiracy Advocate (CA)
Claim: Can I just add—

### Moderator
Claim: —do want to go to the audience and-- gentlemen. If you’re a member of the media we ask you to identify yourself by name and organization, otherwise it’s your choice. Sir? And remember, 30 seconds.

### Moderator
Claim: Isn’t the dirty secret that we cannot afford to have everyone have all the health care that they would possibly want, and so in America we ration it by price, and in other countries you ration it by lottery.

### Moderator
Claim: Paul Krugman, let’s hear from you on that—

### Conspiracy Advocate (CA)
Claim: Yeah, no, that’s definitely true. There is, although, it’s not clear that we’re really at the point where that’s the critical limitation, that’s—at this point, just eliminating health care that actually does no good at all would probably be enough to save a large amount, that’s what the Congressional Budget Office says, so it’s not a really a— in the very long run, what happens when we have the $30 million immortality treatment, that sort of thing, this becomes a big problem. Look, I just want to bring—one more Should Be the Federal Government’s Responsibility” (9/16/08) thing, we’ve been talking a lot about quality of care but there’s one other thing that is very important which is the financial ruin that often comes from medical expenses. And that is preventable and that’s only in America, the individual who is finan—the family that’s financially ruined. Every time I look at one of the studies that says well we can’t show that providing health insurance makes that much difference in health outcomes. First of all I don’t quite believe it but secondly, there is a tremendous difference in terms of not the medical side but the economic side and this is something again, there’s a risk, a fear, a terror of medical expenses, which happens among wealthy countries only in America.

### Scientific Advocate (SA)
Claim: I’m glad, Professor Krugman, that you’re letting some economics creep into your remarks tonight. I want to point out though that the AARP recently released a study that showed that bankruptcy rates are rising fastest, among those people who are covered by our only universal coverage program. Not only are they rising faster among that group than for other groups but for other groups, those bankruptcy rates are falling, how is that consistent with what you said about universal coverage protecting us from financial ruin—

### Conspiracy Advocate (CA)
Claim: But that’s the— No, I’m not talking about bankruptcy rates, I’m Should Be the Federal Government’s Responsibility” (9/16/08) talking about all kinds of people—

### Scientific Advocate (SA)
Claim: Well, what—

### Conspiracy Advocate (CA)
Claim: And you know, those are—

### Scientific Advocate (SA)
Claim: —give me another measure of financial ruin—

### Conspiracy Advocate (CA)
Claim: —the elderly, right? The elderly—

### Scientific Advocate (SA)
Claim: Give me another measure of financial ruin.

### Conspiracy Advocate (CA)
Claim: No, come on, there are—

### Moderator
Claim: All right, let’s go back to the audience, in the middle, you want to identify yourself.

### Moderator
Claim: Yes, I’m Betsy McCaughey from the Hudson Institute. I’m worried about seniors and what the impact will be of a Medicare- for-all system on them. In countries with Medicare for all seniors are denied treatments that seniors in the US can get, the thinking is that the public health dollars are better spent on young people because the benefits will be more lasting. For example two years ago the British National Health Service Should Be the Federal Government’s Responsibility” (9/16/08) decreed, that seniors with wet macular degeneration could not get the drug Lucentis until they had already gone blind in one eye, then they could get it to save the other eye. Why should seniors in the United States take that risk and support a Medicare-for-all system.

### Moderator
Claim: Sally Pipes?

### Scientific Advocate (SA)
Claim: Exactly. Well the thing is that in Great—in Britain there are other examples, Tarceva, the drug for lung cancer that is available here. It—you know, if the NIHCE, the National Institute for Health and Clinical Excellence, a government bureaucracy says, Tarceva is not cost-effective and therefore you’re too old to have it, you’re denied it. You can go out and pay for it in the market, but all of your services provided then under the National Health Service, are no longer available to you. Is this what we want, this is what we’re talking about in Congress right now with the CER, the Comparative Effectiveness Research. We want to do this in the United States, this is going to destroy the innovation that John Stossel was talking about, and it’s going to destroy our ability to live longer and healthier lives, it’s not what the American people want.

### Moderator
Claim: Sally Pipes is against the motion. Gentleman, on the right.

Should Be the Federal Government’s Responsibility” (9/16/08)

### Moderator
Claim: There are a lot of personal stories being told tonight. And I’m glad to say that I have health insurance. And the idea of increased wait times for a medical procedure, that terrifies me. But then I think about the 15 percent of America who have no insurance. And how long are their wait times. So basically like what I can’t wrap my brain around is, how can a system based on companies, that make a profit on denying our care be made responsible for paying for our care.

### Moderator
Claim: John Stossel.

### Scientific Advocate (SA)
Claim: Well, you’re right, the insurance companies have a conflict, and, the insurance company has to balance, they want to pay for nothing, they hope none of you ever get sick and if you get sick they don’t want to pay. But, of course if they do that, word gets out, and they don’t get any new customers, so that’s how they have to balance that.

### Scientific Advocate (SA)
Claim: You know—

### Scientific Advocate (SA)
Claim: That’s how all businesses balance that, and—

### Scientific Advocate (SA)
Claim: Or, or they wouldn’t if you were able to choose your insurance Should Be the Federal Government’s Responsibility” (9/16/08) company…

### Scientific Advocate (SA)
Claim: That’s the other problem, that you have to buy insurance here in New York, from a New York insurance company, and because the politicians always wanting to give you more have loaded it up with all these extra guarantees, they—you must pay for Viagra and in-vitro fertilization and acupuncture or hypnosis or pastoral counseling, I forget what’s all on the list that’s mandated—

### Conspiracy Advocate (CA)
Claim: Oh, okay, can I just—this is—

### Scientific Advocate (SA)
Claim: You’re not allowed to buy from Wisconsin where insurance costs a fourth as much.

### Conspiracy Advocate (CA)
Claim: The reason you have to buy from a New York insurance company is because New York has community rating, which means that an insurance company cannot turn you down if you have a preexisting condition. And if they throw it open, across the country, then, people who don’t have a preexisting condition, people who are healthy can go shopping, and it’s not some kind of crazy thing because they want people to have hypnosis.

### Scientific Advocate (SA)
Claim: Actually— Should Be the Federal Government’s Responsibility” (9/16/08)

### Conspiracy Advocate (CA)
Claim: It’s because they’re trying to protect people who would not otherwise be able to get insurance, and that gets at the irresponsibility of the arguments that are made so often—

### Moderator
Claim: Thank you, Paul Krugman—

### Conspiracy Advocate (CA)
Claim: —in this case—

### Moderator
Claim: —Art Kellermann.

### Conspiracy Advocate (CA)
Claim: There’ve been so many points out here that I wish we could address, one I want to talk about is waiting times, because you hear that all the time. The waiting times that matter, are the waiting times for things like, when you go to the ER and how quickly you see a doctor for a heart attack. How quickly you get stroke care. Whether or not if you’ve got acute or worrisome symptoms you can see your doctor that day or the next day or you end up having to be in an ER. We’re turning away one ambulance per minute in this country from overcrowded private as well as public hospitals in the United States. If you’ve got to limp around for two months on a bum knee until you get a new titanium knee, I’m sorry. That’s not going to kill you. You don’t get to me for 30 or 45 minutes because you’ve been diverted from Should Be the Federal Government’s Responsibility” (9/16/08) three hospitals, you’re going to die. That’s the waiting times that we need to worry about in the United States and it’s not going to happen if we ignore this problem.

### Moderator
Claim: Michael Cannon, against the motion.

### Scientific Advocate (SA)
Claim: Professor Krugman mentioned that community rating laws like you have here in New York are intended to help the sick obtain health insurance. The leading researcher in the country on insurance markets, specifically the individual market where you buy insurance directly is a man named Mark Paul, he’s at the University of Pennsylvania. And what he’s found after researching, what actually happens in insurance markets, is he’s found that those laws reduce—the community rating laws that Professor Krugman favors--reduce the number of people with health insurance, and they don’t provide health insurance to many more sick people, and the reason is that unregulated markets really do a remarkably good job of providing health insurance to people with expensive chronic conditions, provided they purchase health insurance while they’re still healthy. So these regulations—

### Conspiracy Advocate (CA)
Claim: Yeah. If they— Should Be the Federal Government’s Responsibility” (9/16/08)

### Scientific Advocate (SA)
Claim: And—yeah. And it’s expensive and difficult to do, but you cannot have an insurance market unless people do that, because no one’ll buy insurance until they need it. No— you can’t have a fire—a homeowner’s insurance market if people can buy coverage after their house burns down. That is the market’s way of encouraging people to do the right thing and pay into the pool while they’re still healthy.

### Moderator
Claim: Ma’am, right—a question from the audience, ma’am?

### Moderator
Claim: Yes, I have a question about America’s competitiveness, and how it’s influenced by these issues. Art Kellermann mentioned GM,…I was also thinking about another engine of growth which is entrepreneurs, in America, most new jobs are generated by entrepreneurs, not by big companies. And usually, entrepreneurs cannot offer health care because the rates are so prohibitive. So this in fact decreases our competitiveness. And this is just one issue along with the big companies, I mean, globalization’s not going to go away. I think it would be a relief to many sectors if health care wasn’t a drag on their profits— Should Be the Federal Government’s Responsibility” (9/16/08)

### Moderator
Claim: So your question is—

### Moderator
Claim: I’m looking at big business and how it affects globalization—

### Moderator
Claim: But you would like to know—

### Moderator
Claim: —but also—

### Moderator
Claim: But you would kind of like to know what—

### Moderator
Claim: Okay, I would like to know the pan—the, the two pan—the six panelists’, views on, how can we possibly keep going forward the way we are if we’re status quo, when we’re going to have huge competition from India, China, and other places—

### Moderator
Claim: Yeah—

### Moderator
Claim: —that can—

### Moderator
Claim: Well, I—

### Moderator
Claim: —out-compete us— Should Be the Federal Government’s Responsibility” (9/16/08)

### Moderator
Claim: —John, I think that’s right up your alley, that question.

### Scientific Advocate (SA)
Claim: We already have huge competition from China and India and Europe, these countries with universal care. And by and large we’re cleaning their clocks. America’s created 20 million new jobs while Europe created two. So—two million, so, yes, GM has to pay more for health care than steel, and that’s awful, but in these other countries, they have to pay huge amounts in taxes, and that’s even more crippling.

### Conspiracy Advocate (CA)
Claim: Point of fact, I think the United States created 23 million jobs when some other guy was President…and actually employment growth in Europe has been faster since 2000 than the United States, so, that’s a little bit out of date.

### Conspiracy Advocate (CA)
Claim: And I would like to add that—

### Moderator
Claim: Michael Rachlis—

### Scientific Advocate (SA)
Claim: I—

### Moderator
Claim: —for the motion— Should Be the Federal Government’s Responsibility” (9/16/08)

### Scientific Advocate (SA)
Claim: I think you’re cherry-picking times, you picked the 20 years…the United States has created—

### Conspiracy Advocate (CA)
Claim: I don’t know what—

### Scientific Advocate (SA)
Claim: —10 times as many jobs—

### Conspiracy Advocate (CA)
Claim: —that 20-year period—that 20 million figure refers to, I think that was a number just sort of plucked out of air.

### Moderator
Claim: Okay, let’s stop there—

### Conspiracy Advocate (CA)
Claim: I—

### Moderator
Claim: —getting off the topic, Michael Rachlis—

### Conspiracy Advocate (CA)
Claim: Yeah, that in all this talk about health care with traditional economic models, that really, that is one of the main reasons why you folks have not been able to make progress. That is, using traditional marketplace models, focused on that as your ideology to analyze health care, which is not in any way close to being a traditional economic market. And to apply some sort of economic… language the way we’re hearing from the other side, Should Be the Federal Government’s Responsibility” (9/16/08) to a system which is—where the supply side is massively regulated, for good reasons. You know, do you want to be able to—going to have to look up every single provider that you see to find out whether or not they passed their licensing exams or not? You know, I—the extension would—of this argument would be Milton Friedman’s one that, just absolutely no regulation whatsoever. But, that—

### Scientific Advocate (SA)
Claim: Fine with me—

### Conspiracy Advocate (CA)
Claim: —that doesn’t deal with health care where it by and large for key decisions, consumers can never be at the same information level as the agent who’s recommending those services—

### Moderator
Claim: Sally Pipes, you look like you’re dying to say something.

### Scientific Advocate (SA)
Claim: I’m just dying to say that, we got—a lot of the mess that we’re in in this country including part of the 46 million is because, federal government gave employers a tax advantage to provide health insurance. And as a result, people in America, 60 percent of people in America get their health insurance through their employer. If you lose your job or you quit your job, we don’t have portable health insurance. If we make a few simple tax changes, such as refundable tax credits or an income tax deduction, we Should Be the Federal Government’s Responsibility” (9/16/08) really need to focus on growing the individual market, so that people can buy insurance across state lines, people can get the type of insurance that fits their needs, we can grow the individual insurance market because competition will work. And when we have 1900 mandates on insurance across this country, it’s impossible for an insurer to provide a stripped-down policy which…two-thirds of the uninsured are in that 18-to-30 age bracket, and they don’t want to buy insurance with, as John said, in-vitro fertilization, alcohol rehabilitation. We can open up this market, and cover a lot of those people because of the 46 million uninsured, 17 million earn over $50,000 a year, and 10 million earn over 75,000, a lot are younger, they’re healthy, and they don’t want to pay $4,000 a year for insurance to cover things that they don’t need to care for—

### Moderator
Claim: Thank you, Sally Pipes, question down front, please—

### Conspiracy Advocate (CA)
Claim: Most—many of those folks have illnesses, and they cannot get insurance no matter how much money they pay—

### Scientific Advocate (SA)
Claim: But if we open up the market, new competitors would come into the market—

### Conspiracy Advocate (CA)
Claim: No, but— Should Be the Federal Government’s Responsibility” (9/16/08)

### Scientific Advocate (SA)
Claim: —and some would—

### Conspiracy Advocate (CA)
Claim: This—

### Scientific Advocate (SA)
Claim: —and they would be based on—

### Conspiracy Advocate (CA)
Claim: Health—

### Scientific Advocate (SA)
Claim: —on condition—

### Conspiracy Advocate (CA)
Claim: —health care is not a market like other markets—

### Scientific Advocate (SA)
Claim: Well, it’s not a right—

### Conspiracy Advocate (CA)
Claim: —but it’s gotta be closer—

### Scientific Advocate (SA)
Claim: —it’s not a right—

### Conspiracy Advocate (CA)
Claim: —to being a market like other markets—

### Moderator
Claim: Time out, too many people talking at once is not making sense. Michael, go ahead, Michael Cannon speaking against the motion.

Should Be the Federal Government’s Responsibility” (9/16/08)

### Scientific Advocate (SA)
Claim: Health care presents a lot of interesting challenges, and the question is not, oh, well, it’s special so therefore markets can’t do it. The question is, well, you know, markets and governments have advantages and disadvantages and, which one works best, which set of tools works best for this particular problem. I’ve always enjoyed hearing from proponents of universal coverage that the US has this market-driven, for-profit health care sector, you know, the government controls half of the money in our health care sector. And because of government tax policy, employers control another quarter of it. So, 75 percent of the money is controlled by someone other than the consumer, how in any way, is that a free market. I’m reminded of a favorite expression, expression of my brother’s, he likes to say, you know, you’re pissing on my shoes and telling me that it’s raining. What’s driving these costs and what’s driving these quality problems are those 75 percent. So—well, I’ll stop there.

### Moderator
Claim: Thank you, question down front—

### Moderator
Claim: I have a quick question for Dr. Kellermann, you mentioned the Mayo Clinic as a model of efficiency and I think we all recognize it as a model of great health care, what’s the impediment right now to having more Mayo Clinics in this country, why don’t we have Should Be the Federal Government’s Responsibility” (9/16/08) them if the market can provide that, and I don’t know that we could look anywhere— People come all over the world to Mayo Clinic, why doesn’t universal health care coverage provide that in other places.

### Conspiracy Advocate (CA)
Claim: The Mayo Clinic has a great philosophy. It’s very heavily focused on primary care, they’re very heavily focused on efficiency. You don’t have to be efficient to be successful in this country. I just have to talk you into getting all the tests that I want you to get, I need to talk you into getting the procedures you want. You know, we just talked about economics. Everybody these days is complaining about gas prices with good reason. But if we ran our oil industry the way we’re running our health care industry gasoline would cost $16 a gallon and one out of every six American cars couldn’t burn it. We can do better than that.

### Moderator
Claim: Question from the back there?

### Moderator
Claim: My name is Tony Meyer and I care about this issue too, and in 2002 I founded a company that today is one of the largest managers of defined-contribution programs for corporate America, and we work with General Motors and Ford and Chrysler and many other great American industrial companies— Should Be the Federal Government’s Responsibility” (9/16/08)

### Moderator
Claim: This had better be a question, not a commercial—

### Moderator
Claim: There is, there is, this is not an advertisement. My question, and Ms. Pipes, you just mentioned it, no one has talked about the fact that, we have a unique health care delivery system which is really managed by large employers, it’s unique in the world. Nobody’s talked about whether that’s a problem or a solution, should it be reformed, discarded, modified. I’d be curious what the panel thinks of that approach.

### Scientific Advocate (SA)
Claim: Well, and I did mention, I think it does need to be changed because if your employer—

### Moderator
Claim: Discarded.

### Scientific Advocate (SA)
Claim: Yes. I mean if your employer is paying about $15,000 for your health coverage, that might not be the kind of health coverage that fits you as an individual, you may not want that type, but if we open up the market, and give individuals the same tax incentive— Because if you go out in the individual market and buy insurance, you don’t get a tax break on that, but if you get it in decreased wages but through your employer, it’s cheaper and you—and you’re able to get it because you’re part of that Should Be the Federal Government’s Responsibility” (9/16/08) pool. So we need to, as John says, actually discard that model and move away from it. You know, we can’t move away from it overnight, but we can make some changes in the tax code, that will allow the individual market to grow, and we need— we don’t get our life insurance, we don’t get our long-term care insurance, our home insurance from our employer. As I said, this was a gift during World War II, and it was a terrible gift that has distorted in my mind a great deal of the health care system—

### Moderator
Claim: Paul Krugman.

### Conspiracy Advocate (CA)
Claim: Yeah, it’s not the system you would design if you were starting from scratch and it’s not the system we want to end up with. But it’s a system that at least did the basics of risk-pooling for a lot of people, it’s a system that did deal with the problems of preexisting conditions and people being screened and does somewhat reduce the problem of insurance companies, not to deliver care but to, who can do the best job of finding who really needs insurance so as not to give it to them. So it’s not—I have no brief with that system, but, the idea that what we need to do is scrap it and move to an individual insurance market which has never worked anywhere, it’s the most amazing thing, that what we have coming from the conservative side is the belief that, universal health care, which works all across the world, is Should Be the Federal Government’s Responsibility” (9/16/08) undoable. And that an individual market, which has never worked anywhere, is the answer to our problems, extraordinary leap of faith.

### Scientific Advocate (SA)
Claim: Are you familiar with Professor Pauly’s research on the individual market?

### Conspiracy Advocate (CA)
Claim: Yeah, I’ve seen some, but you know, we just, it—

### Scientific Advocate (SA)
Claim: Well, you—

### Conspiracy Advocate (CA)
Claim: —there just isn’t enough out there—

### Scientific Advocate (SA)
Claim: —you’ve seen some, that’s where reality enters the discussion—

## Round 3

### Moderator
Claim: Time is up for this section. Thank you very much to the audience for, actually, terrific questions. I want to remind you, just before we move to the summing-up section where each of the panelists will have two minutes, I want to remind you of how you voted when you came in if we can put the slide up again. Before the debate, 49 percent of you agreed with the proposition that universal health coverage should be the federal government’s responsibility. 24 percent of you were against that motion and 27 percent were undecided. In the next 10 to 12 minutes you Should Be the Federal Government’s Responsibility” (9/16/08) will hear a summing up and then we will vote one further time, and our first panelist to begin his two-minute summary, John Stossel.

### Scientific Advocate (SA)
Claim: Oh—okay. If you think health care is expensive now, wait till you see how expensive it is when it’s free. When it’s free there are no controls. I don’t think this side is saying the American system is a good system, it’s not a market. We’re spending other people’s money, government is already involved spending about half the money, third parties pay for seven out of every eight dollars, this is an awful way to pay for things. Think how it would work for your car insurance worked that way, if they paid for your gas and your oil you wouldn’t care what gas costs and people would sell you $100 oil changes. That’s what’s going on in health care under insurance companies paying, or the government. And employment-based insurance makes no sense when four out of 10 Americans change jobs now every year. Government is not the answer, we don’t have government steel mills or government airlines anymore because they were awful, and once they had competition they went outta business. Michael says medicine’s different, but, every profession says that. The truth is it—it’s true, you don’t—you’re not an expert, you don’t know which doctor’s the best. But you don’t know which car’s the best, you’re not car engineers. But Should Be the Federal Government’s Responsibility” (9/16/08) through word of mouth the good news spreads, the bad companies go out of business, the good doctors will take over, and we see this now, where there is a market, the tiny places, like cosmetic surgery, lasek eye surgery. The doctors give you their email addresses. Does your doctor do that? They give out their cell phone numbers, the waiting rooms are nice. And the prices are going down, while the quality is going up. The post office can never give us what FedEx can.

### Moderator
Claim: Thank you, John Stossel. John Stossel…John Stossel, speaking against the motion. Speaking for the motion in his summary, Paul Krugman.

### Conspiracy Advocate (CA)
Claim: In the course of this debate I actually felt…I don’t know whether the audience will agree but I actually felt that John Stossel in effect conceded, when he held up that Trabant at the end of it. Because that just shows, if all you can do is say Communism, Communism, East Germany— I don’t want us to move to East Germany. I just want us to move to France. Now, the… Look…government health care isn’t perfect. Actually, government health care isn’t the issue, government insurance isn’t perfect, so is private insurance. There are horror stories, the nature of health care, is that lots of bad things happen. You don’t generally seek health care, because you’re Should Be the Federal Government’s Responsibility” (9/16/08) feeling great. But we have extensive experience, we have Medicare, which is a system that is flawed but has actually shown slower cost inflation, than private health insurance over the past 40 years. We have the Veterans Health Administration which is our little island of true socialized medicine in the United States. And it does very well. And above all, what we have is a system right now, remembering what the proposition is, the motion is that the federal government should guarantee health care. Not that the government should run everything, not that everything should be under government control, not that we should nationalize the steel industry, which keeps on being run but as you know is not on the agenda or nationalize the auto company, but whether there should be a federal guarantee of health care for everybody. And that, I think, is something that American values, that our fundamental morality says is something we should be doing.

### Moderator
Claim: Thank you, Paul Krugman. And making her two- minute summary against the motion, Sally Pipes.

### Scientific Advocate (SA)
Claim: Although it would be nice if the federal government could solve all of our health care challenges, current events both at home and abroad show that it cannot. As a Canadian, I watched first- hand the promise of free health care, and I saw it devolve into the Should Be the Federal Government’s Responsibility” (9/16/08) reality of a high tax bill, and long lines for advanced care. As waiting lists grew over the years to more than four months in 2007, an increasing number of Canadians have traveled to the United States for treatment and paid out of pocket, whether it’s Mayo, the Cleveland Clinic, or UCSF system. The number of illegal private clinics in Canada has grown significantly over the last few years. The government is afraid to shut them down even though private health care is illegal in Canada, for fear of an immense outcry. In June 2005, the Canadian Supreme Court ruled, in a monumental decision, that the ban on private health care in Quebec is illegal. Quebecers are entitled to life, liberty, and the security of the person. Long waiting lists do not give you that security. Madame Chief Justice Beverley McLaughlin said, access to a waiting list is not access to health care. Claude Castonguay, chair of a Quebec Royal Commission on Health Care in the 1960’s recommended that Quebec adopt government health care. The Quebec government followed his advice, and they called him the father of Quebec Medicare, just like Tommy Douglas, the father of Medicare. This year he released a report, an official government report evaluating Quebec’s ailing health care system. His conclusion, it’s in crisis. He now urges legalization of private health insurance. Americans believe in freedom and personal responsibility, not big government. They don’t want big government controlling our lives. The question is, Should Be the Federal Government’s Responsibility” (9/16/08) who do you want to control your health care decisions? An HMO bureaucrat, a government bureaucrat, or you yourself? By supporting universal choice in health care, and empowering consumers, we will achieve universal coverage. Thank you.

### Moderator
Claim: Thank you Sally Pipes. I want to mention for the purposes of our radio broadcast that Sally Pipes is President and Chief Executive Officer of the Pacific Research Institute. Also you’ve heard from John Stossel, John Stossel an ABC News correspondent, co-anchor of 20/20, and author of The John Stossel Specials. And we heard from Paul Krugman, an Op-Ed columnist for The New York Times, and professor at Princeton and the London School of Economics. We’re next going to hear from Michael Rachlis, Michael Rachlis is a physician and health policy analyst, the author of Prescription for Excellence: How Innovation is Saving Canada’s Health Care System. Michael, your two minutes begin now.

### Conspiracy Advocate (CA)
Claim: Yes, I want to mention that, that there is virtually no flow of Canadians south of the border. The Canadians getting health care south of the border are, like, ninety-nine percent of them are like my daughter who had a catfish spine through her palm— people on vacation. That there is the waiting list issue, I mentioned that it is a problem in Canada, but other countries Should Be the Federal Government’s Responsibility” (9/16/08) with universal systems don’t have waiting list problems. It is not a problem of universal coverage. And in fact, in Toronto right now, because of public response to the concerns about waiting lists, if you need cataract surgery, if you need your knee replaced, if you need a hip replaced, phone one number, you can be seen in an assessment clinic within one week usually, and you can get your surgery within a month after that, and it doesn't cost you any money directly, because you pay it in your taxes, and the taxes in Canada as a share of GDP are almost as low as they are in the United States. And we’ve had surpluses for eleven years. I think what you're hearing from the other side are a whole series of anecdotes, and yet the overall research indicates that every other wealthy country in the world where you would feel comfortable visiting and living has a universal system. And I think what you really have to watch out for is what the New Yorker commented on April 20th, 1992, referring to then the first president Bush: The compulsion that drives President Bush to distort the facts about Canadian Health Care suggests that official American policy is in the process of becoming what conservatives in discussing the Soviet Union used to call a total ideology, a system blindly convinced of its absolute truth, and yet so fragile in its relationship to reality that it isn't capable of considering even the most obvious reform. Surely we should have learned by now what happens to ideological systems that Should Be the Federal Government’s Responsibility” (9/16/08) begin to deny facts that their people can discover for themselves just by crossing a border. Cross the border, come to Canada, anybody in the audience, contact me, I will show you the Canadian health care system, and then America should do universal coverage in its innovative fashion. Make health care a right, and then do it right.

### Moderator
Claim: Michael Rachlis summing up for the proposition. Summing up against the proposition, Michael Cannon, co-author of Health Competition: What’s Holding Back Health Care and How to Free It. He is the Cato Institute’s director of health policy studies. Michael?

### Scientific Advocate (SA)
Claim: The perception before we came in here, I was standing across from a man who was reading his program, and when he came to the part with my picture on it, he looked at the picture, he looked up at me, and he said, hey, that's you. And I said, yes, that's me. And he said, you're against universal coverage!? Because I think, and this look came over his face, the question that was forming was something like, what kind of a moral reprobate could be against universal health insurance coverage? And I know that I have a lot of family here tonight who are asking themselves the same question. My opposition stems from two beliefs.

Should Be the Federal Government’s Responsibility” (9/16/08) One is that people should have the right to choose their doctor, they should have the right to choose their health plan, and those things are often lost in system of universal coverage, almost uniformly. No, I think totally lost. And second, universal coverage is not going to make us healthier. We have serious problems here in the United States with rising costs, with low quality care, and we have health plans in the private sector that are trying to innovate with ways to reduce those costs, and to improve the quality of care. The only problem is, you can't choose them, because the government has said you can't. The only problem is that the government controls half of the money in our health care sector, and so the industry has, is able to block those innovations, because they want to protect their incomes. You can have a health care sector that guarantees universal coverage, or you can have a health care sector that continuously makes medical care better, cheaper, and safer, making it easier to deliver on that moral obligation that we have to help the less fortunate among us. You cannot have both.

### Moderator
Claim: Thank you, Michael Cannon. Finally, the last word goes to Art Kellermann. Art Kellerman is not a surgeon, as I incorrectly said before, Art Kellermann is an ER doctor at Grady Memorial Hospital in Atlanta, and a professor at Emory, summing up for the motion universal health coverage should be Should Be the Federal Government’s Responsibility” (9/16/08) the federal government’s responsibility. Dr. Art Kellermann.

### Conspiracy Advocate (CA)
Claim: Have you all heard the expression that there are no atheists in fox holes? I can tell you, in my experience, there are no libertarians in intensive care units. It’s widely said that Americans can pick their doctor. The fact of the matter is, if you're in a non-group plan, or you're in a plan that doesn't contract with these doctors over here, but you can over here, every day I see patients whose care is disrupted because their plan has shifted doctors, they didn't get the deal they wanted. We’ve surrendered an enormous amount of freedom in this country to the private insurance industry, and to the rest of the industry. We can collectively together do better. In just a few moments you're going to vote again, and the six of us care a lot about how that vote turns out. But that’s really not the vote that matters. The vote that matters is coming up on November the 4th, and I encourage every one of you to do your homework, and do your homework on the candidate’s positions on health care, because they are strikingly different, and they, to some degree, break down along the lines of the debate tonight, and it should make a difference in the choice that you make then as well as the choice you make tonight. I want to close by going back to the bedside of that family. I didn't tell that mother the whole truth that night, but by staying silent and withholding the truth I left Should Be the Federal Government’s Responsibility” (9/16/08) her with something we both needed, which is hope. Hope that her son would beat the odds. Sometimes we see young people come back from catastrophic injuries and do OK. Hope that Georgia and every other state in this country would develop efficient, effective regionalized trauma and emergency care systems so everyone can have access to life saving emergency care. And most important, hope that this great nation of ours, the United States of America, will soon finally do the right thing and cover the uninsured so no mother need ever ask again, will my son get the care he needs? Please vote for tonight’s resolution.

### Moderator
Claim: Well, we’re done, but for your part, but this was a really terrific debate, and I want to just, for all six, this isn't just Art’s applause now, but for all six…

So pick up those voting keypads, you may recall that when you came in here forty-nine percent of you were for the motion that universal health coverage should be a federal responsibility, twenty-four percent of you were against, and twenty-seven percent of you were undecided. So, you can begin the voting process, which you seem to have gotten down the first time quite Should Be the Federal Government’s Responsibility” (9/16/08) quickly. Number one you're for the motion, number two you are against the motion, number three you remain undecided, or became undecided. Anyone need more time? Everybody’s good? OK, I want to thank you, before we go to the results, I just want to thank the panelists, and especially all of you in the audience, because the questions were first rate, and moved the discussion into interesting places. I want you to also know that our next debate will be Tuesday October 7th, 2008. The motion is going to be “America is finally winning the war in Iraq.” Panelists for this motion will be Fred Kagan of AEI, he is widely seen as the architect of the surge; and also retired Four Star General Jack Keane, for the motion. Against the motion is Charles Ferguson, the writer/director of the Iraq War documentary No End in Sight, and Sir Malcolm Rifkind, the former foreign secretary and defense secretary of the UK, and a current member of Parliament. These debates that you are taking part in as audience members can also be heard on more than a hundred fifty NPR stations across the country, please check your local NPR member station listings for the dates and times of the broadcast. Also, copies of books by the authors are on sale in the lobby in plentiful supply. Learn more about their ideas in depth. And I am quite serious about that. Finally, we are pleased to announce that our December 2nd debate, where the motion is: “Bush 43 is the worst president of the last 50 years…” will… Not voting now please.

Should Be the Federal Government’s Responsibility” (9/16/08) Will be recorded for broadcast on BBC World News television. To accommodate for that taping we will be moving the debate to a larger space, Symphony Space theater at 95th and Broadway. This means that there will be more seats available, a limited number of tickets will be made available. And now to the results, a question of who won the room. Before the debate, for: forty-nine percent; against: twenty-four percent; undecided: twenty-seven percent. After the debate… Fifty-eight percent are for the proposition, thirty-four percent against, eight percent undecided. Thank you very much everyone for joining us this evening.
