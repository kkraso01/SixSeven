# Debate Transcript

Topic: Death Is Not Final
Motion: Death Is Not Final

Debate ID: 050714%20Death%20Not%20Final


## Round 1

### Moderator
Claim: I’m interested to hear what he has to say about this one, so let's please welcome to the stage Mr. Robert Rosenkranz.

Hi, Bob. How are you?

### Moderator
Claim: Good.

### Moderator
Claim: So I was just saying, you know, normally we're doing foreign policy and defense spending debates. And tonight we're going a little bit in a different direction with this discussion of the afterlife. So what's the thought behind putting this on the stage now?

### Moderator
Claim: Well, one of the things that kind of got me to think that this would be a very interesting debate is a sermon I heard in a Catholic church many, many years ago, in which the priest was challenging people to believe in an afterlife. And the argument he made was quasi scientific. He said, imagine a fetus in his mother's womb that's almost ready to be born, nine-month, full-term baby. And you're trying to convey to this baby what's about to happen, that it's going to have an incredibly painful experience going through the birth canal, that its ties to its mother through which it's getting all kinds of nutrients and all the oxygen is going to be severed. But not to worry, there's going to be a great life afterwards. There's going to be all kinds of experiences and sensory things and development and emotional growth and just an incredible world that you cannot imagine. And when you think about that, of course, you say, of course you could-- there's no way you could communicate that. And there's no way that the baby could understand it. And yet we all know it's true. So it kind of invites you to think, is it possible that there's something that we can't-- we can not imagine, that we don't understand, but nonetheless is true about life after death?

### Moderator
Claim: I mean, I want to ask you one point about the approach we're taking to this. But before we get to that, do you have a lot of these epiphanies in churches?

### Moderator
Claim: Well, I'm Jewish, actually. But--

You know, the Jews do have the highest resurrection rate in the world.

### Moderator
Claim: My question is, we're not looking at this is a religious debate, speaking of which, we're really taking a different cut at it.

### Moderator
Claim: No, of course. And that's what I think sort of makes it much more of a factually grounded and intellectually grounded argument, and it's the reason we're doing this, is to take it away from the questions purely of faith and try to do as scientific an approach as we can to this topic which obviously interests a lot of people.

### Moderator
Claim: Well, the great thing is we have four scientists debating tonight, so let's welcome them to the stage, and thank you to Bob Rosenkranz.

### Moderator
Claim: Thank you, John.

### Moderator
Claim: Okay. Now I can see. And I just want to actually invite one more round of applause to Bob Rosenkranz for making this all possible.

So the difference between going to heaven some day and getting hit in the head with a hammer right now is that going to heaven some day sounds so much better than getting hit in the head with a hammer right now. But at least with the hammer, you know that the hammer is real. Science can see the hammer. Science can weigh it and take its measurements and even cut it up into little pieces and put it into test tubes. But heaven, the afterlife, science cannot see that, not with a telescope, not with a microscope. So does that mean that heaven is not as real as the hammer? Or does it just mean that science and scientists don't know yet how to find heaven, how to look for it? Well, that sounds like the makings of a debate. So let's have it. Yes or no to this statement: Death is not final, a debate from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters, scientists all, but they divide on this issue: Death is not final. They will argue two against two for and against. We are at the Kaufman Music Center in New York City.

As always, our debate will go in three rounds, and then the live audience votes to choose the winner, and only one side wins. Let's meet our debaters and the team arguing for the motion, death is not final, please, ladies and gentlemen, welcome Eben Alexander.

And Eben, in a way, you are our founding story in this debate tonight. You are an academic neurosurgeon, 15 years on the faculty of Harvard Medical School. But in 2008, you got very, very sick. You went in a coma for seven days. Your brain effectively stopped showing signs of life in the higher functions. And you came back, and you said, "I was there. I saw it. I've seen the afterlife." In one word, what did you see? What was it?

### Conspiracy Advocate (CA)
Claim: Astonishing.

### Moderator
Claim: Astonishing. And if you had heard somebody, back before you had this experience, make that same sort of claim, what would you have said?

### Conspiracy Advocate (CA)
Claim: "no way," at least not until I knew all the facts.

### Moderator
Claim: We'll hear more of the facts from you tonight. Ladies and gentlemen, Eben Alexander.

And Eben, your partner is?

### Conspiracy Advocate (CA)
Claim: My very good friend, Dr. Raymond Moody.

### Moderator
Claim: Ladies and gentlemen, Raymond Moody.

And Raymond, you are also arguing for this motion that death is not final. You're a psychiatrist, and you have a medical degree, a doctorate in philosophy. You are described as "the founder of the near death experience." You coined that phrase in your book in 1975, "Life After Life," in which you looked at more than a hundred cases of people who had experienced clinical death and come back. You've been looking at this now for decades. But it's interesting to us to note that your curiosity in this whole thing was piqued not by religious conviction. What was it?

### Conspiracy Advocate (CA)
Claim: No, I'm-- I was not--

### Moderator
Claim: Can you just move a little closer to your mic.

### Conspiracy Advocate (CA)
Claim: Yes. I was not religious. I got interested in the afterlife question at age 18 when Plato convinced me, through his argument, that the afterlife question is the most important question of existence.

### Moderator
Claim: We're going to be hearing about Plato tonight?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: We're looking forward to it. Ladies and gentlemen, Raymond Moody. And that's the team arguing for the motion. And now the team to argue against this motion, "Death is not final," please, ladies and gentlemen, welcome Sean Carroll.

Sean, you are a physicist at the California Institute of Technology. Your research focuses on fundamental physics and cosmology, the study –of the origin and the evolution of the universe. You've written a lot of books, including "The Particle at the End of the Universe," which is about the quest to discover the Higgs Boson, which is a celebrity among particles. And you have described yourself as a naturalist.

So for the purposes of understanding where you're coming from, what does that term briefly mean?

### Scientific Advocate (SA)
Claim: A naturalist is one who believes there is one world, the natural world. And it is our job to deal with it.

### Moderator
Claim: And are you dealing?

### Scientific Advocate (SA)
Claim: Okay. So far so good.

### Moderator
Claim: Sean Carroll.

And, Sean, tell us who your partner is?

### Scientific Advocate (SA)
Claim: The talented and charming Steven Novella.

### Moderator
Claim: Ladies and gentlemen, Steven Novella.

Steven, you are also arguing against the motion that death is not final. You are a neurologist at Yale School of Medicine. You're the founder of the website, "Science- Based Medicine," cofounder of the New England Skeptical Society. We sense, you know, there's a theme running through this. You know, you-- The Skeptic's Guide to the Universe is your podcast. So you're doing all of this neurology. Why did you decide to put yourself out there as a skeptic?

### Scientific Advocate (SA)
Claim: Well, I had briefly considered a career in interpretive dance. but sadly, I had to conclude that my talents lay elsewhere. So I thought science skepticism was a good match.

### Moderator
Claim: The dance of skepticism.

### Scientific Advocate (SA)
Claim: The dance of skepticism. I'll work on that.

### Moderator
Claim: All right. Ladies and gentlemen, welcome to our debaters tonight.

And this is a debate. Our motion is "death is not final." And in this debate, we go in three rounds, and only one side will win. And that side will be chosen by you, our live audience. By the time this debate has ended, we will have asked you to vote twice; once before the debate and once again afterwards to tell us where you stand on this motion. And the team whose numbers have changed the most in percentage point terms will be declared our winner. So let's go to the first vote. If you go to these key pads at your seat, look again at the motion on the screens: Death is not final. If you are for this motion, push number one.

If you are against it, push number two. And if you're undecided, push number three, which is, by the way, a perfectly honorable position with which to start this debate. You can ignore the other keys. And if you push the wrong one, just correct yourself, and the system will lock in your last vote, and we're going to wrap this up in about 12 seconds. Okay, looks like everybody's done. So let's move on. Let's start this debate. Let's get on to round one. Round one, our motion is, "Death is not final." In round one, we have opening statements from each debater in turn. They will be seven minutes each. And here to speak first for the motion, Eben Alexander. He is an academic neurosurgeon who taught at Harvard Medical School. He is author also of the bestselling book, "Proof of Heaven." Ladies and gentlemen, Eben Alexander.

### Conspiracy Advocate (CA)
Claim: Thank you very much, John.

I've been an academic neurosurgeon for over 20 years, and I fully believed in reductive materialism, our modern conventional science. In fact, six years ago I would've been sitting over on that side of the stage with Steven and Sean. Now, at that time I believed that the brain creates mind and consciousness, that we have no free will, that it's birth to death and nothing more. Then something happened. I now know that those ideas are false. In November 2008 I was driven rapidly into coma due to a severe bacterial meningoencephalitis which I much later came to realize is the perfect model for human death, destruction of the neocortex, the outer surface, the human part of the brain. Sadly almost no one returns, much less recovers, from a case of meningitis as severe as mine. The last evidence of any activity in my neocortex was in the first hour, so in the emergency room and afterwards I demonstrated only very pathological reflexes including severe brainstem damage.

Given my gram negative bacterial meningoencephalitis, which I was found to have, and my descent into coma over three and a half hours, I had at best a 10 percent chance of survival at the very beginning. It only got worse. Mine was an absolutely lethal meningitis. My white cell count in my cerebral spinal fluid was 4,300 and a protein of 1,340. Both those numbers should be zero. In fact, the glucose in that fluid, normally 60 to 80, and maybe as low as 20 in a severe case of bacterial meningitis, went all the way down to one. None of the consultants in my case, from Harvard, UVA, Duke, or Wake Forest had ever seen that severe a case. My doctors never found a cause. The scan showed diffuse destruction of my neocortex with blurring of the gray-white junction over all eight lobes of my brain. No area was spared. Later in the week, off all sedation, my neurological activity was almost nil.

With what's called a glass glaucoma scale, which in everybody in this room would be 15 and a corpse is three, my scale was ranging from three to five. This was a very severe meningitis. On day seven, with no residual neocortical function, brain stem badly damaged, reflecting the deadly nature of my illness, my doctors recommended, because I was down to a 2 percent chance of survival by that point, with a best case scenario that if I survived I'd spend a month or two in the hospital, be transferred to a nursing home, and die in a coma months later, hence, they recommended just stopping the antibiotics. My journey deep in the coma began in a very primitive unresponsive realm, which I later called the "earthworm's eye-view," the best consciousness my brain could muster, soaking in pus. My prior neuroscientific view would've dictated that the next step would be one of no awareness at all. Yet, it was just the opposite, like the blinders coming off. I ascended into far more crisp, vibrant, ultra real realms of pure joy, love, and understanding, realms I called the "gateway in the core," far too rich and complex to fully describe.

Soon thereafter I started to return to this world, but with my brain so wrecked that I had no memory of words or language, nothing of Eben Alexander's life before coma, any religious concepts, et cetera, yet I knew the entire ultra-real odyssey that I had just been deep in coma, went so extensive it seemed to last for months, even though it had to fit within seven days of earth time. Words came back to me over hours and days, childhood memories over weeks, and knowledge of brain-mind consciousness of more than 20 years' experience in neurosurgery came back over two months. My doctors have no explanation at all for my full recovery. Other cases of medically inexplicable healing do occur in transcendental near-death experiences, like those of Anita Moorjani and Dr. George Rodonaia. In the 36 hours after emerging from coma, I was in and out of a delusional, paranoid, psychotic nightmare that was completely different, not even in the same ballpark, when compared to the ultra-reality of the deep-coma experience in the gateway in the core.

Those experiences deep in coma seem almost seem to weigh too real to be real. My doctor's believing that the brain creates consciousness, and knowing the destruction they had seen in my brain, had told me that I could not have had any such experience in the depth of coma, and therefore just to forget about it. I knew I'd experienced something and sensed that it had to do with the fundamental flaw in the models of consciousness and the-- and the role of the neocortex. Early on, I tried to explain all of this as a brain-based phenomenon based on my old paradigm, writing it up as a report for the neuroscience literature. It's important that when I was emerging from that coma, I saw six faces at the very end. And these were faces that were very important in helping me to realize that the entire coma experience happened between Days 1 and 5 of my coma, and not at the very end.

Over those weeks of recording my experience after coma, I also began to talk with my doctors and review my medical records, especially neurological examinations and the scans, and came to realize just how deathly ill I was and how there was no way that such an ultra-real crisp and vibrant experience could have happened in my physical brain. Modern neuroscientific ideas of the neocortex and consciousness would dictate that I should have experienced nothing at all beyond that earthworm's eye view. I wrote the entire experience down, 20,000 words that I wrote over six weeks, before I read anything about near death experiences. I have never read that literature before. Initially, I was very worried that the memories would fade. Those memories are as sharp today as when they happened. Memories of the delusional paranoid psychotic nightmare that occurred over those 36 hours after I came out of coma faded within weeks.

Very different origin. I had never read NDE literature before, and was shocked to find that the experience seemed hyperreal in over half of NDE accounts, and the memories do not fade like those of hallucinations, dreams, confabulations, or drug effects. People recount their own NDE stories to me by the hundreds, usually starting-- I'd never told anyone this before, but even from over 50 years ago, as if they happened yesterday, I came to see that the similarities in the NDE and afterlife literature far outweighed the differences. And the commonalities across cultures, beliefs, continents, and millennia indicate an underlying constant reality of that realm. Many of the petty differences are due to our being so restricted by our earthly language. This is not like we're describing a trip to Disneyland. Personal biases and religious beliefs might taint the telling of those stories. But the core similarities remain striking.

### Moderator
Claim: --I'm sorry. And thank you very much. Your time is up. Thank you, ladies and gentlemen. Eben Alexander. Our motion is Death Is Not Final. And here to speak against this motion, Sean Caroll. He is a physicist at the California Institute of Technology. He is the author of several books, including "The Particle At The End Of The Universe." Ladies and gentlemen, Sean Caroll.

### Scientific Advocate (SA)
Claim: Thanks, John. It's a pleasure to be here defending such a cheerful and uplifting proposition, as death is, in fact, final. Driving around the streets of Los Angeles, where I live, you can't help but notice these gigantic billboards telling us "All Men Must Die." Turns out they were advertisements for "Game of Thrones," but I thought that they were advertisements for-- our event here tonight. It's a similarly-- you know, not quit as happy message as we might like to accept. Fortunately, we can open Dr. Alexander's book. It begins with a quote from Albert Einstein. Einstein says, "A man should look for what is, not for what he thinks should be," to which I would like to reply, "Exactly." We human beings are not always perfectly rational. Let me tell this shocking news to you. We are bundles of cognitive biases. And one of the strongest biases we have is that we go easy on propositions that we would like to be true. What we should, in fact, do, is go especially skeptical on propositions that we would like to be true. And even I want it to be true, that death is not final. But we should hold something like that to an extraordinarily high standard of evidence. So, what are we actually being asked to accept? What should we expect the world to be like if death were not, actually final? For one thing, I would expect that the existence of souls persisting in the afterlife should be perfectly obvious. It should be just as clear that heaven exists as it is clear that Canada exists. But in fact, it seems that the souls persisting in the afterlife are kind of shy.

They don't talk to us, except sometimes they do talk to us. I would expect, also, that when people did have near death experiences, and really talked to other souls in the afterlife, that they would come back with consistent, interesting, non-trivial stories to tell. But in fact, when Christians have near-death experiences, they often say they've met Jesus. When Hindus have near-death experiences, they meet Hindu deities. There was a little girl who had a near-death experience, and she met a portly man wearing a red cap. She met Santa Claus. And we are told by some defenders of this that, well, Jesus dressed up as Santa Claus so as not to scare the little girl. Possibly, that is true. But we should be asking, are there other plausible explanations? I especially think that if we went and had a life after death and then came back to visit us, bringing some message back, that message would-- should be as useful as possible. We are told that, you know, people have after death experiences, and they come back saying, you know what?

Love is really important. I agree with that. But actually, I knew it already. What I would like to know is the cure for Alzheimer's disease. What I would like to know is something that I didn't already know brought back to us. But it seems that the souls in the afterlife tend to speak in platitudes. The story that we're told of life after death doesn't really hang together. What we have are personal testimonies like that from Dr. Alexander. So people say, with very sincere voices, that what they experienced was totally real. And I have no doubt in the sincerity of this testimony. What I'm asking is, is it possible that our brain is telling us that something was real, but that thing does not actually correspond to something that really happened. And when you ask it that way, the answer is obviously yes.

Our brains are fooling us all the time. Steve Novella, my partner, will tell us about the neuroscience behind this. But basically, our brains are not like video recorders or photo albums. They're more like little theaters. When we try to remember something, it's much like imagining something that hasn't happened. It's more like running a script than reviewing a tape. And that's why, when we dream, when we hallucinate, when we have a near-death experience, it is just as vivid as something that actually happened. In the legal community, they will tell you that eyewitnesses who tell you that-- have a certain sincerity and conviction that their eyewitness testimony is true, that conviction is essentially uncorrelated with now true it actually is. The vividness or reality of a memory does not tell us that it was really real. So what is going on? We had this informal idea that there is a soul that sort of is a blob of spirit energy that takes up residence near the brain and drives us around like a soccer mom driving an SUV.

But we've known for a long time that this picture doesn't make sense. Back in the 1600s, princess Elizabeth of Bohemia carried on a correspondence with René Descarteswho was trying to defend mind-body dualism. And Elizabeth demands, no, how could something immaterial like the soul affect something material like the brain or the body? Descartes was never able to answer that question. And these days, science has gone way beyond that. We know a lot more about what is happening. We can literally see memories being formed. We can see the chemical changes in neurons. So the soul is supposed to also have memories. How do the memories get from the neurons to the soul? We know that brains often have false memories in them. Does the soul in the afterlife carry those false memories, or are they somehow corrected after death? We even know the laws of physics by which the atoms, the electrons, the elementary particles in our brains behave.

We know the equations that the electrons that are responsible for chemistry obey. And there's no ambiguity in these equations. They could always be wrong. It is always possible to say, well, we just don't know what is going on. That's fine. But what we have is the evidence of every experiment ever done telling us that these equations are correct. To overcome that, we would need very, very strong evidence, just one experiment, telling us how the soul is pushing around the chemicals in our brain. But we don't have that. What science says is that life or consciousness is not a substance like water or air. It is a process like fire. When you put out the flame on a candle, the flame doesn't go anywhere, it simply stops. And that is what happens when we die. So we're faced at the end with two scenarios. One scenario says that everything we think we understand about the behavior of matter and energy is wrong in a way that has somehow escaped notice by every experiment ever done in the history of science.

And instead, there are unknown mechanisms that allow information in the brain to the transferred to blobs of spirit energy that persist after we die and can talk to the other blobs of spirit energy, but don't talk to us, expect sometimes they do. The other scenario says that physics is right and that people under stress sometimes have experiences that are not actually real. On the basis of rationality, it not a difficult decision to choose between these two options. On the basis of emotion, it might be difficult. But we need to have the courage to live life here in the actual world. Thank you.

### Moderator
Claim: Thank you, Sean Carroll. And here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate where our motion is: "Death is not final." We have two debaters, two against two, arguing for and against this motion. I'm John Donvan, your moderator. We have heard from the first two debaters and now onto the third. Here to argue for the motion, "death is not final," Raymond Moody. He's a medical doctor with a PhD in philosophy, author of numerous books on near- death experience, including, the seminal "Life After Life." Raymond Moody.

### Conspiracy Advocate (CA)
Claim: Thank you. Since 1965, I've had the honor of interviewing thousands of people from all over the world who had near-death experiences. And unless you've been hiding in a cave somewhere for the last 40 years, you've all heard about this, that people on the brink of death tell us that they leave their bodies, and they go into a beautiful light which they find very difficult to describe. And in that light say that relatives or friends of theirs who have already died seem to be there to meet them and to help them through this transition. And they have panoramic memory in which they see all of the events of their lives displayed around them in a sort of holographic panorama of which they witness instantaneously.

My assessment from 40-something years of working on this, and I will underline that word "assessment" is that in the words of the proposition, death is not final. But I want to translate a little bit to say that what I'm trying to say with that is that in my opinion, at death, personal consciousness is taken up into a more inclusive state of reality or frame of existence in a way that people who go through this find it very difficult to put into words. One of the most common things they say is, however articulate they may be, they say that this experience is ineffable, or indescribable. I want to emphasize here something at the very beginning. And please hear me out on this one. I have decided, or sort of assessed the situation, that there is a life after death.

However, I want to say anybody who tells you in the year 2014 that that is a scientific matter is not thinking clearly. In 2014, the question of life after death is not yet a scientific question. I am not a parapsychologist. And I think parapsychology is a pseudo science. So there's a different frame of reference to think about this, though. And that is that reason is a much bigger category than science. Scientific method is about, say, 400 years old. Reason itself is about 2300 years old, a much bigger institution that includes history and philosophy and literary theory and the law in addition to scientific thinking.

So what I am suggesting to you is that the solution to the afterlife question is not going to come initially from science, but rather from, I think, the whole area of critical thinking and logic. As I look back on the debate that-- on near-death experiences that's gone on for almost 2500 years now, what strikes me is that a big part of the problem is that the format of the debate is basically twisted. Since Democritus and Plato fought this out 2300 years ago, the way we've debated this is we say that some people look at these near-death experiences, and they take it at face value, as Plato did, and they say, well, this is an indicator of an afterlife. Other people Democritus being an example, said, as Democritus famously did, "There is no such thing as a moment of death," implying that therefore what he's getting is that these near-death experiences are just the patient's perception of the winding down process of the body.

The trouble with this whole debate is that that format of debate itself is incoherent. We can't keep debating it that way. Let me give you an indication of why. All of the elements that we think of as a near-death experience, getting out of the body, going into this light, seeing a panoramic review of one's life, seeing apparitions of the deceased occur very commonly, not just to people who almost die and are brought back, but rather to the healthy and uninjured bystanders at the bedside of someone else, shared death experiences, as I call these. As the person in the bed, it's fairly common that bystanders will say that they themselves leave their bodies and accompany their dying loved ones partway toward this light, or they see the apparitions of relatives and friends of the dying person come into the room.

So my question is, if the causation of these near-death experiences is the physiological distress and the events going on in the brain, why should the bystanders who are not ill or injured have identically the same experience? So I think that we're into a situation with this now where really the problem has sort of outgrown the format that we use to debate about it. In my opinion, we really are on the verge of breakthroughs in the genuine, and I will underline "genuine," rational investigation of the question of life after death.

And in that context, I think there are two people in history who have more than anyone else I think stated this afterlife question very clearly and the major problems that come with it, Plato being one, who said that, "Whenever we talk about the afterlife, there's always going to be the narrative aspect, a story, because we've got to have some sort of story just to get thought about this kind of thing started, but also we've got to have some sort of set of concepts to link the-- these narratives with the statement of what-- that there is life after death." I think that's coming. I think that we are on the brink of a breakthrough in rational study of an afterlife, but it's not going to come initially from science, but initially from the realms of logic and critical thinking. So thank you very much.

### Moderator
Claim: Thank you, Raymond Moody. And our motion is, "Death is not final," and here is our final debater against this motion, Steven Novella. He is an academic clinical neurologist at Yale University School of Medicine, as well as the host of the weekly science podcast, "The Skeptics' Guide to the Universe." Ladies and gentlemen, Steven Novella.

### Scientific Advocate (SA)
Claim: Thank you. Thanks, John. I want to say thank you to the Intelligence Squared Debate for inviting me here. It's an honor to be here. So I'm going to convince you that you need to vote against this proposition because if you vote for the notion that death is not final then you-- that by necessity means that you are voting against the conclusion, the scientific position, that the mind is what the brain does. The mind is a process of the brain itself. You would have to reject that in order to accept that the mind exists without the brain. Well, how sure are we? How confident are we in-- as a scientific conclusion, which is what we're here to talk about, that the mind is essentially the brain?

Well, we're very certain about that, and we're as confident of that as we are of anything in science. We have a mountain of neuroscience, countless experiments, that look for the neuroanatomical correlates of consciousness, of the brain functioning, of the mind. Everything that you think, feel, believe, is something that's happening inside the brain, demonstrably. But let's take that as a scientific hypothesis. If the mind is entirely the brain, then what must also be true? Well, then if the arrow of causation's going from brain to mind, then if we change the brain, that should change the mind. And if we damage the brain, that should damage the mind. And if we turn off the brain, that should turn off the mind. Well, if all of those propositions are correct, that strongly supports the notion that the mind is essentially the brain, and that is, in fact, exactly what scientists have discovered over and over again over the last one to two centuries of neuroscience.

I can give you-- I'm a neurologist, so I can give you tons of examples from my own personal clinical experience. But let me just tell you about one very interesting neurological phenomenon called Capgras Syndrome. This is a syndrome in which-- well, I'll give you-- I'll back up a little bit. So when you're looking at, let's say, the face of your wife or your spouse, what's forming on your retina is just shapes and shadows and colors and lines, but your brain has to construct that into an actual image. But then it also have to give meaning to the image. It has to tell you that these shapes are, in fact, a face. And then another part of the brain tells you, "That's not just any face. That's the face I know well. That's the face of my spouse, the face of my wife." Now, assuming, however, you have feelings about your wife-- let's assume that-- then-- there's also a connection between that part of your brain that tells you that that face is your wife to the limbic system. That's the emotional part of your brain. And that connects your emotions, your feelings about your wife to that image.

So, when you see your wife, those feelings are connected to it. Those are all circuits that are happening demonstrably in your brain. Now, in Capgras Syndrome, that last connection is broken by a stroke, by damage, by something. So, when someone sees their spouse, they recognize them as their spouse. But the feelings aren't there. So, what do people conclude when this happens? Well, it's interesting. When people have brain damage, it affects how their brain constructs their image of reality, because as my-- as Sean was saying, are-- we don't have a tape recorder in our minds, in our brains. We are constructing reality and image of reality all the time. It's a very active process. And when you-- when that process breaks down, then your construction of reality breaks down. So-- and you usually don't have insight into that, especially initially, because we tend to assume that our experience is a real, continuous experience. That's also something your brain constructs.

So, what do people conclude when they have this syndrome, that circuit is broken in their brain? They conclude that their wife, their spouse must be an impostor . That's the only explanation that they can come up with. There's, in fact, a documented case of a husband who murdered his wife because he was convinced that an impostor had replaced his wife, you know, with an exact-- you know, it makes no sense, but that's the only way his brain could make sense of its broken construction of reality. And there's endless examples of this. There's no limit-- there is no practical or functional limit that neuroscientists have encountered so far to the degree which we can mess with your mind by messing with your brain. Your-- your sense that you're in your body, that you control your body, that you separate from the universe-- basic fundamental things about your concept of yourself and your experience of reality are all things demonstrably happening in the brain, and we could turn it off like a switch. Now we actually have the technology to do that.

So, given the mountain of evidence that the mind is the brain, we wouldn't reject this easily. Do near death experiences provide such compelling evidence that there is mental activity outside of brain activity, that we need to reject the mountain of neuroscientific evidence that's growing every day, that tells us that the mind, in fact, is the brain? Well, I think the answer there is definitely no as well. There are-- as Sean said, there are stories-- anecdotes, compelling narratives. We're all about compelling narratives. That's what our brain does-- that people have had very unusual experiences. We don't doubt that they have had, you know, life-altering, unusual experiences. Whenever your brain is constructing reality in a different way that you're not used to, that's going to be a very weird, profound experience. It's going to be memorable. It's going to be amazing. Astonishing, even. We have no doubt about that. But it's demonstrably something happening in the brain. What we don't have are any documented cases of mental activity occurring when there could not be brain activity. Now, proponents will often say that, "Well, but the person remembers being, you know, in the emergency room, or they remember-- they have these memories that were forming while their brain wasn't functioning." But we don't know that. There is no case in which that's been documented. They easily could be forming their memories when they're coming out of their-- whatever state, whatever coma that they were in. Dr. Alexander even says he had a prolonged recovery. We have no idea what was happening in his brain during that period of time. When people are in a coma, there's still some break activity. There are animal experiments showing that sometimes even during an acute stress, there could be even a burst of neural activity. Who knows what kinds of astonishing memories are occurring there? We have a reality testing module in our brain, a circuit in our brain that says, "This feels real to me." And that testing module could break down. And then things-- you don't test reality. It just seems hyperreal. Every element of a near death experiment-- experience can be duplicated, can be replicated with drugs, with anoxia, with lack of blood flow, by turning off circuits in the brain.

Every single component is a brain experience that we could now reproduce. And we're zeroing in on the exact circuits in the brain which reproduce them. That's why you must vote against this proposition. Thank you.

## Round 2

### Moderator
Claim: Thank you, Steven Novella. And that concludes Round 1 of this Intelligence Squared U.S. Debate, where our motion is Death is not Final. Now we move on to round two. Round two is where the debaters address one another and take questions from me and from you in the live audience. Our motion is this: Death is not final. We have two teams of two arguing for and against this motion. We have Eben Alexander and Raymond Moody who have made a presentation based very significantly on the personal experience of Eben Alexander.

It's an argument based on one very, very compelling anecdote of a guy who's been there. He has seen it, and he is not a gullible guy and never was. He was trained as a scientist. He comes back saying that consciousness is something that is a lot bigger than the brain, that what he experienced could not be explained by brain activity, especially given the illness and the state of illness he was in when his brain was functionally nonfunctioning. They're also arguing that there are thousands and thousands of cases like this and that there is a consistency to these cases. At the same time, they say that science-- no, science cannot prove that the afterlife exists, but that through the use of reason and logic, we can get to that conclusion in a way that laboratory experiments cannot. The team arguing against the motion, Sean Carroll and Steven Novella, they agree with their opponents that science cannot prove that there is an afterlife.

But they also say that science can more or less tell us that there is not and cannot be an afterlife, that the existence of an afterlife would not fit in with everything else that we know about how the way the world works, that there are all sorts of other possible biological explanations for the experiences that people come back and describe and that psychologically, we're wired to want to believe in the story of an afterlife and that that wiring influences the kinds of accounts that come back. So there are a lot of ways to take cuts at the debate-- at this debate based on what we have seen so far. But I want to-- you know, we're going to talk about the power of anecdote, the validity of anecdote. We're also going to talk a little bit about what we know about brain function and the state of brain function. And I want to start with that point as the opening, as it's the thing that we most recently heard Steven Novella talk about. And I want to go to Eben Alexander. And this debate is not Eben Alexander on trial. We agree with that. But you're the one with the experience. You've had-- I think you also-- your partner, Ray Moody, did you have a near-death experience?

### Conspiracy Advocate (CA)
Claim: No.

### Moderator
Claim: No? Okay. I didn't, either, just for the record. Eben, your opponents are arguing that what you said you experienced can be explained by-- by what we already know about the brain; that as they put it, you had a real experience about something that was not real. And I think we all understand the logic of what they're saying. That could be the case, could it not be the case?

### Conspiracy Advocate (CA)
Claim: Well, I think the important thing to point out is I get asked to give a lot of talks at medical groups, neurosurgery and other surgical groups, physician groups, because they realize the power of the medical situation. And I think this is what certainly grabbed me and challenged me within weeks after my coma is my knowing mybrain mind consciousness came back, and I started to review the records to reveal just how sick I was. I think the problem is that any other reason for being in deep coma, I probably would have been stuck because usually if there's some part of the neocortex that's still working, you could make an argument that that part was part of the process of putting it all together. But I think the important thing to point out is, with my neocortex so badly damaged, it became very difficult to try and come up with a way to explain how this very rich, elaborate set of memories occurred.

### Moderator
Claim: So in answer to my question, there are-- you're arguing there really can be no other possible explanation, that you had a real experience about something that can only be real.

### Conspiracy Advocate (CA)
Claim: Well, it was a very real experience that had no way of occurring in my physical brain. Now, initially, I looked at all kinds of possibilities; could it have happened early going in, could it have happened coming out, was there some way that other structures in the brain or some part of brain was participating and generating this very long, elaborate journey? And yet that's where I kept running into trouble with it.

### Moderator
Claim: Okay. Let's bring it over to Sean Carroll then, where your opponents-- your opponent, Eben Alexander is saying that what he experienced can only be explained as a real experience. And Sean Carroll, why don't you respond to that?

### Scientific Advocate (SA)
Claim: Well, I think that Steven can talk about the specifics that might have been going on in the brain. But my emphasis is on weighing two different comprehensive pictures here. We have personal testimony from someone who says he experienced something, and it's very real and says that, well, we can't imagine that, even as a neurosurgeon, he just doesn't know what could possibly have been going on in his brain that would make that happen, therefore let's throw out all of the laws of physics. And I think that that is not nearly enough.

### Moderator
Claim: Stop right there. Stop right there. Eben, is that true?

### Conspiracy Advocate (CA)
Claim: No, that's not at all true. In fact, they still teach quantum mechanics, right?

### Scientific Advocate (SA)
Claim: They do. I could teach it right now--

### Conspiracy Advocate (CA)
Claim: Because I think it's important to point out, from my point of view, what drove the Founding Fathers at that field into mysticism was the fact that getting at the very depths of trying to understand subatomic reality they were led to believe the consciousness, the observing mind actually played a role in the unfolding of what was being observed.

And I think that that mystery, to my satisfaction, has not really been solved in a way that says that the concerns of people like de Broglie and Dirac, Einstein, Bohr, and others, that they were trying to understand how consciousness influenced them.

### Moderator
Claim: So is your point, for those of us who are just not as well steeped in the conversation that's already happening here--

Is your point that there is a kind of reality that you are saying is beyond science, the-- total of science that we know now? Let me ask Raymond. Raymond, can you move in just-- you need to be really right on top of that mic. Great. Thanks.

### Conspiracy Advocate (CA)
Claim: Well, I believe at some point science can be very useful at determining a lot of this.

### Moderator
Claim: But I'm going to-- and I'm going to move on because I don't want to belabor this topic, but-- but what Sean-- what Sean was saying to you was that you're basically saying there just cannot be any other explanation other than the one that I have, and therefore science really isn't relevant at this point.

### Conspiracy Advocate (CA)
Claim: I think that-- in my view, this is all about how understanding the true nature of consciousness, soul and spirit, has a lot to do with helping to take physics to the next level in terms of understanding--

### Moderator
Claim: Okay. Thank you. Sean Carroll.

### Scientific Advocate (SA)
Claim: The thing about Einstein, Bor, de Broglie, et cetera, the founders of quantum mechanics, is that they're all dead, and they have been dead for many decades. And we know what's going on much better now than we did back then. They were inventing quantum mechanics, and occasionally they toyed with the idea that somehow consciousness had something to do with the fundamental laws of quantum mechanics. Now we know better.

We know how laws of quantum mechanics help explain how electrons move in the brain, and there's nothing in there--

### Moderator
Claim: Take 15 seconds and tell us why quantum mechanics has been brought up by your opponent, why that has relevance here.

### Scientific Advocate (SA)
Claim: Well, it's-- I can only quote MIT physicist Scott Aaronson who says, as far as he can tell, quantum mechanics is confusing, and consciousness is confusing, so maybe they're the same.

### Moderator
Claim: Raymond Moody, let's bring you into the conversation.

### Conspiracy Advocate (CA)
Claim: You know, really, I think the end reality, what we're dealing with here is not a scientifically decidable issue, but a philosophical question. And what it's called is the mind-body problem, probably first articulated in the West by Pythagoras, but there have been many, many different theories of it. The one that's current in the neurosciences is called epiphenomenalism, which says, in effect, that there is no independent reality to what we experience as consciousness. But it's a secondary byproduct of the primary reality which is the brain and the electrochemical events going on in the brain.

In my opinion, that's a philosophical statement, really. And my answer is, I don't know. I think the mind-body problem is still unresolved.

### Moderator
Claim: All right. Let's go to your opponent, Steven Novella, who specializes in whether the mind is in the brain or not.

### Scientific Advocate (SA)
Claim: I think, you know, Dr. Alexander said that the experience that he remembers-- again, I don't doubt he has a memory of a profound experience-- that it could not have occurred as he was coming out of his coma. But you have no basis for that statement, I don't think, that you have no sense of time. Your brain also constructs your sense of time. And when your brain is only partially working, you can have experiences that are hyper-real, that are both bizarre, that it's hard for you to reconstruct. And then your memory struggles to sort of construct a narrative that makes sense. It takes these bits and pieces of things that were firing in your head when you were in this semi-conscious state, and it constructs a narrative out of it based usually culturally on your pre-existing beliefs.

You know, near-death experiences, whether,--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --as Moody said in a cave, in a cave

### Moderator
Claim: You're providing a lot of other ways that what Eben says could have happened-- could not have happened any-- okay, so.

### Scientific Advocate (SA)
Claim: Perfectly consistent with what we know about the brain.

### Moderator
Claim: I want to take that back to Eben then. So your opponent, Steven Novella has just laid out many, many scenarios in which you experienced could not-- could have been real to you, but not-- not real.

### Conspiracy Advocate (CA)
Claim: Well, I would say the--

### Moderator
Claim: --and what are your responses to his specifics?

### Conspiracy Advocate (CA)
Claim: Well, the interesting thing to me in looking back on it is the fact that, you know, I started for a very long time in what I call this "earthworm eye-view," a very primitive, coarse, unresponsive realm that had absolutely no kind of interactivity to it, and yet I remember that prolonged period. And that's what I said earlier is that the next step beyond that should have been one of no awareness at all, and yet what really happened was the blinders coming off and emerging into this far grander reality that was--

### Moderator
Claim: But, I mean, you--

### Conspiracy Advocate (CA)
Claim: --which was much crisper than my

### Moderator
Claim: --but your response-- your responses to your opponents' criticisms keep returning to, "What I saw, this is what I saw, this is what I experienced," and that's not a response to the point he made, that there are other ways in which you could have seen what you saw. So that's what I want you to do, is to respond to Steven Novella's, you know, two or three scenarios for ways in which what you experienced may have been generated by your ill brain.

### Conspiracy Advocate (CA)
Claim: Well, to have that be an explanation, one would want at least some part of the neocortex still in a state that could participate because all of our modern thinking in neuroscience--

### Moderator
Claim: During your recovery--

### Moderator
Claim: Let him finish. Go ahead.

### Conspiracy Advocate (CA)
Claim: --is that there really was no part of my brain-- I mean, the factors that showed me when it happened, which was between days one and five and not at the end on coming out of it, basically those are part of the experience itself that to me were very difficult to explain, because they showed that it happened when my doctors told me my brain was way too sick to manufacture anything.

### Moderator
Claim: Okay, so that's a very solid answer. He's saying his brain was flat. Nothing, nothing was going on, therefore, the kinds of experiences you are saying his brain could have generated, they could not have generated. It was shut.

### Scientific Advocate (SA)
Claim: Well, we don't know and he didn't give an answer to the question of when did those memories form? We don't know. They were not necessarily happening when you were at your worst. And when you were at your worst, there wasn't the kind of functional monitoring that we would've needed to know that your brain was not functioning at all. We don't know that. We saw anatomically, we had edema, swelling, and that certainly would have kept you unconscious, but you weren't getting an fMRI, a PET scan, or an EEG as far as I could see anything that you've written or said about it that would have documented zero brain activity. You can't say that. Nobody can say that. And even still, the memories that you have now were not necessarily formed when you were at your deepest part of the coma.

They could've been forming in the hours and days when you were coming out of the coma. Then you had a later delusional period, but at different points in time, different parts of your brain were working or not working, and you were constructing reality in a very bizarre way, in ways that we can reproduce with drugs and hypotension and, you know, with electromagnetic stimulation of different parts of your brain.

### Moderator
Claim: Is that valid, that the entire near-death experience, as described by thousands of people, can be recreated by drugs and putting electricity across the brain?

### Conspiracy Advocate (CA)
Claim: No, I would say that's not true at all. There are tremendous examples of people encountering souls of departed loved ones, learning information that they couldn't possibly learn in any other way. You had said earlier that there were no cases of any of these memories being generated when the brain was out, and yet there are examples of that, where the brain-- people under deep anesthesia, with complete circulatory arrest, things like that, where they do have some astonishing stories of getting information that it doesn't seem to be any other way that they could have gotten it. So those cases are out there.

### Scientific Advocate (SA)
Claim: But those cases are not controlled or documented, so, in other words we don't know that they couldn't have gotten that information any other way A lot of those cases I've read, that they're like cold readings, you're getting information that is either plausible or later was retrofitted to the scenario. It's all a lot of special pleading, the same kind of information you get from a psychic. It's not controlled scientific information. There are, in fact, attempts at putting controls in place like putting playing cards on top of a shelf that could only be viewed if you were actually floating above the ceiling. And to the extent that those have been done, no one has been able to demonstrate any information that could only have been obtained while they were extracorporeal, floating above their body. And, by the way, we could make you float above your body.

### Moderator
Claim: Okay. Raymond Moody, did you want to comment or-- I can go back to Eben.

### Conspiracy Advocate (CA)
Claim: Yeah, you can go to Eben.

### Moderator
Claim: Because I actually want to move on to a different point that was made, and that was, Sean Carroll, you were making the point that we're wired to want this to be true, we're wired to want to-- to shape strange events into narratives and into narratives that we particularly like, and my response to that is maybe that's true, but that doesn't necessarily mean that's what happened over here. And there's a little bit of an argument, ad hominem thing about it, is you're not a reliable reporter because you just want that to be true. And it's a little bit insulting almost to say, "You can't be trusted because you want everything to be happy." Respond to that.

### Scientific Advocate (SA)
Claim: Yeah, I hope it's not insulting. It's certainly not ad hominem because the message is that nobody can be trusted. I think that that is part of what science has taught us, that if someone makes an extraordinary claim, the very first questions we should be asking ourselves are, number one, is there a different, simpler alternative explanation? And number two, how would we know if our purported explanation were false?

How would we disprove it? How could we possibly test this idea? And I think that, you know, when you look at the bigger picture of how the universe works, how the laws of physics work, the enormous success of understanding matter, energy, the brain, life-- everything that we've had-- there's just an enormous presumption against the idea that somehow, through ways that there are no equations, no experiments, or no direct evidence to tell us, the information in our brains persists after we die and is there forever and talking to other people who died. So, it's just a matter of presumption. There's plenty of things that I would like to be true-- and I have been tricked into believing they're true. So, I know that I should be especially skeptical about them.

### Moderator
Claim: All right. Raymond Moody, you're the philosopher on the panel. And you've said that this essentially a philosophical question. So, take on what Sean Carroll has just said, from the philosophical point of view.

### Conspiracy Advocate (CA)
Claim: What I would say about what Sean says is I agree with it up to a point, in the sense that, yes, I love physics, too.

I was an astronomer from the age of seven and so on. And I accept there's a physical realm and so on. But that doesn't rule out that there could be a state of being that doesn't operate by physical principles. I noticed, Sean, when you were trying to think of some other realm, you were thinking in terms of energy or soul substance or whatever. But I'm talking about something entirely different. There's no inconceivability in thinking that everything that we know is true. And yet, there is a higher dimension or a higher domain of existence that sort of-- in which this one is included.

### Scientific Advocate (SA)
Claim: But this--

### Moderator
Claim: Sean Carroll.

### Scientific Advocate (SA)
Claim: --I mean, that's-- I think that's a perfect thing to have said in this debate, because it illustrates the difference here.

No evidence was given for this claim. No reason to believe it was given. All we are given is, "Well, maybe it's true and you can't absolutely disprove it." Maybe it is conceivable. We have laws of physics that tell us how the moon moves around the earth. And they work very well. It is conceivable that there are also angels living inside the moon, gliding it around in exactly the way that Newton's Laws tell us. But we don't take that seriously as an idea, because there's no need for it or evidence for it. So, the question is not is it conceivable that there are other realms. The question is, is the evidence in favor of that other realm so overwhelming that it causes us to dismiss the enormous successes of physics, chemistry, biology and neuroscience?

### Conspiracy Advocate (CA)
Claim: No. I would say absolutely not. It doesn't require you to dismiss the findings of science to –

### Scientific Advocate (SA)
Claim: Come over here to this side. We'll welcome you. We'll put your chair over here--

### Conspiracy Advocate (CA)
Claim: And yet, you know, I think it's entirely conceivable that there's some other domain of existence over this that some people gain access to it sometimes.

And I know hundreds and hundreds of them.

### Scientific Advocate (SA)
Claim: And how would we know if there weren't?

### Conspiracy Advocate (CA)
Claim: You know something? You're right about the false of viability problem, Sean. That's very big in the afterlife question. But I think the way that this is going to work out is that what we need to do is prepare people in advance, before they ever have a near death experience, in new ways of thinking about these things. You know, the standard-- the standard objection to mystical experience has always been-- as A.J. Ayer put it-- that if the mystic tells us that he can't possibly describe what he experienced, then he's got to admit that he's talking unintelligibly when he talks about it. And that's the problem that we can change, because I think it's--

### Moderator
Claim: But-- but Raymond-- but your argument said-- and I'm not taking sides on this, but my role in this, to some degree, is to push the arguments on both sides.

You were-- what you were saying sort of reminds me of the editorial to Virginia about Santa Claus, written in the 19th century, in which Francis Church wrote this editorial, said to the little girl, "Do you see fairies dancing on the front lawn? No, of course you don't, but that doesn't mean that they're not there." And I feel, to some degree, that's the argument you're presenting is-- "No, we can't prove it, but that doesn't mean it's not real."

### Conspiracy Advocate (CA)
Claim: What my argument--

### Moderator
Claim: And I just need you, again, to come close to the mic.

### Conspiracy Advocate (CA)
Claim: Yes. Yes. My argument is that when thousands and thousands of people whose judgment I trust and other-- in all other circumstances, a lot of medical friends--

### Moderator
Claim: Okay. Give us one example, because I know you've written about this, examples where people who were not the person lying in the bed, but other people--

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: --had an experience. And let the other side respond to that.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: And just lean into that mic.

### Conspiracy Advocate (CA)
Claim: And artist I met a couple of years ago, Jeff Olson, by name, a very well-known graphic artist, had a horrific car crash in which he lost his leg, he-- his wife was killed instantly, and he had a profound near-death experience.

As he was thinking about this, what am I going to do about this?" his doctor had not been informed about this. So he decided to write this story up, and then he wanted to use the name of his doctor. So he called the doctor and invited him to lunch. The doctor came and Jeff told him the store I have his near-death experience, whereupon the surgeon said, "Well, I've never told anybody this, but that night you were in the hospital I knew that you weren't going to die. Your wife was talking with me in the surgery room. And the--"

### Moderator
Claim: His dead wife.

### Conspiracy Advocate (CA)
Claim: Yes.

And so did the scrub nurse also had an experience of vivid sense of presence and seeing the-- so my point here is that it's not proof, but at a certain point, you know, where do you draw the line and--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --give people respect?

### Moderator
Claim: So you put an example out there where it's not simply about the brain activity of the person lying in the bed, but that the notion of an afterlife represented by this apparition, we are talking about ghosts now, and I'm sorry that sounded pejorative, but we are talking about something that a lot of people would challenge as incredibly implausible. But you’re making the argument seriously, so I want your opponents to respond to it seriously.

### Scientific Advocate (SA)
Claim: Well, we want to know what's really, really true, not just what seems to be true, what we want to be true. And, you know, again, our brains are narrative generating machines. It tries to construct a story that makes sense to us, appeals to us, stream-- puts everything together seamlessly. And you know, we can have what we believe-- we have memories of experiences that mean something to us, but don't really relate to reality. We know this is true.

If you accept that level of evidence-- and this is not about respect. I believe that people have these memories of these experiences. It's just about the interpretation of them.

### Moderator
Claim: Are you talking about the scrub nurse and the doctors?

### Scientific Advocate (SA)
Claim: Anyone. I mean, think about it.

### Moderator
Claim: But these scrub nurse and doctors were at separate-- met this woman at separate places, right, on the same night.

### Scientific Advocate (SA)
Claim: But all we have is a story constructed after the fact. We have similar stories about people being abducted by UFOs, seeing big foot, any weird kind of experience you can imagine. If you accept this level of evidence, then you have to believe every paranormal claim out there because we have that level of evidence for thousands of stories that are conflicting in mutually exclusive, often culturally dependent. It's simply not acceptable. And we know-- we know for a fact that the brain can absolutely manufacture those memories, come to absolutely believe a story like that, that's absolutely not true.

### Moderator
Claim: I want to go to audience questions. And while you're raising hands, I just want to ask very, very quickly for Eben Alexander, do we know that the brain can manufacture those experiences?

### Conspiracy Advocate (CA)
Claim: I would say the brain does not create consciousness. That is something a lot of scientists, those interested in neuroscience are far along that pathway. Now it's called the hard problem of consciousness. In fact, no neuroscientist on earth can give the first sentence to explain the mechanism by which the physical brain creates consciousness.

### Scientific Advocate (SA)
Claim: We don't have to know how the brain creates consciousness.

### Moderator
Claim: Steven Novella.

### Scientific Advocate (SA)
Claim: In order to know that it creates consciousness. That it creates consciousness, we absolutely know, just like we don't have to know how the earth generates gravity to know that it generates gravity. There's no question we have gravity even though we haven't untangled the deepest understanding of every possible thing. So yes, we don't know exactly how the brain creates consciousness, but the evidence can only lead to one interpretation, that it is consciousness. The consciousness is what the brain does, no question.

### Moderator
Claim: Eben Alexander.

### Conspiracy Advocate (CA)
Claim: As I said, no neuroscientist on earth can give the first sentence to explain a mechanism by which the physical brain gives rise to consciousness.

### Scientific Advocate (SA)
Claim: But not knowing the mechanism--

### Moderator
Claim: Is that-- is that true?

### Scientific Advocate (SA)
Claim: I don't-- I disagree with that because there are-- there's consciousness research. There are researchers who are doing a very good job of making progress of understanding consciousness as a neurological phenomenon. We certainly are not all the way there of understanding exactly what it is. It's a very difficult nut to crack. But that we are not at the-- but not knowing the mechanism is not the same thing as saying it's not possible, or it's impossible, or we need a nonphysical mechanism. We certainly don't.

### Moderator
Claim: Given that point, but is he accurate that we don't know the mechanism by which the brain gives rise to consciousness?

### Scientific Advocate (SA)
Claim: Well, it's not a black or white thing. We have some knowledge. We don't have complete knowledge about it. It's like saying, do we understand-- do we understand everything about genetics? No. But we know that DNA is the molecule of inheritance. That's not questionable.

### Conspiracy Advocate (CA)
Claim: But not one sentence. Give the first sentence of how you would trace from the physical brain that it gives rise to consciousness.

### Moderator
Claim: Let's go to some audience questions. Right down front here. A mic will come to you. I didn't explain this before. A mic will come to you. And if you can stand up, tell us your name, and then give birth to a perfect formed question.

### Moderator
Claim: Hello. Hi. My name is Arthur Kramer. My question is to the panel arguing for the motion. If a person was to take a strong hallucinogen, let's say LSD, and they were to have a very distorted experience, hallucinations, would you accept their version of reality, or would you just merely dismiss it as them having an experience because of--

### Moderator
Claim: That was a perfect formed question.

And very relevant. Which of you would like to take it? Raymond Moody.

### Conspiracy Advocate (CA)
Claim: Yeah, I think William James was kind of right about that, that whatever experience one has one can say that by definition almost there's some correlated state of the central nervous system. The question of reality is an entirely different question. Can I imagine that maybe by taking some substance someone could gain access to some other kind of reality? Yes, I can imagine that. However, I think it boils down to the particular, doesn't it? I think you have to look at a much broader set of information to make a-- but generally speaking, yeah.

### Moderator
Claim: I don't think this side needs to add to that. I think your side was in the question.

### Moderator
Claim: Yeah.

### Moderator
Claim: Sir. You were starting to stand up. Well, you too. I'll come back to you.

### Moderator
Claim: Richard Spencer. I've got a question for Eben and specifically about the issue of other people having experiences. Eben, in your experience, you seem to have met your biological sister who you had never met before or seen a picture of. And I gather from your book that you actually drew a picture of her or somehow had a picture done before you subsequently had an actual picture of who she was, which you learned later. I'd like you to describe that in a little bit and say if in fact you--

### Moderator
Claim: I'm going to pass on that question because it's not going to-- I don't think it's going to advance our understanding of whether science relates to this or not, but thanks very much. Ma'am in the center there. Is your book on sale in our lobby? I like always being able to say that.

### Conspiracy Advocate (CA)
Claim: I have no idea. It should be out there somewhere.

### Moderator
Claim: If you have-- if you have no idea, that's a no. It's downloadable. And the story that was just brought up can be-- can be read in the book in great and compelling detail. Ma'am.

### Moderator
Claim: Okay. Hi. My name is Eleanor. And I have a question for this side as well. I did read both of your books, by the way, which are super interesting. But it left me with a question which hasn't been answered yet, so why wouldn't everyone that experiences a death experience or a near-death experience have one of these experiences?

### Moderator
Claim: Right. It's about one out of ten or one out of eight, something like that.

### Moderator
Claim: Right. Why wouldn't--

### Moderator
Claim: --who comes back.

### Moderator
Claim: --more people have-- and why is there no mention of hell? It's all about heaven, which could be a good thing. But--

### Moderator
Claim: I think this side has an answer to that question.

Eben Alexander, would you like to take that?

### Conspiracy Advocate (CA)
Claim: Well, I think that, to me, is a very interesting question. The number out there is roughly 15 percent, 20 percent of people who have a medical situation that might lead to a near-death experience, about 15 to 20 percent seem to report them. That's a historical figure that I think is probably low because it comes from an era when we weren't asking people to volunteer that kind of information.

I think the actual number is probably higher. If I had just come back from my earthworm eye view, you know, that very prolonged initial phase, that very dumbed- down consciousness that I think was the best my brain could do, I would have had a hellish NDE. Turns out that hellish NDEs are probably, what--

### Moderator
Claim: Just remind people.

### Conspiracy Advocate (CA)
Claim: --3 or 4 percent.

### Moderator
Claim: NDE stands for near-death--

### Conspiracy Advocate (CA)
Claim: A near-death experience. And the hellish ones are quite rare by comparison, 3 or 4 percent. My own feeling is that that is because they're incomplete, that souls don't go in with quite the oomph and that exactly in my case, I went in with plenty of oomph and went through that phase and up into the much higher levels of ultra-reality.

### Moderator
Claim: I think the other side should get a crack at this question and why it's only one out of eight or one out of 10 people who have had these experiences,

### Scientific Advocate (SA)
Claim: Yeah, I mean, it’s perfectly compatible with the neuroscientific hypothesis of these experiences depends on what parts of your brain are working and not working at any given moment. What's the mechanism of your being in a coma or unconscious? Was it traumatic? Was it lack of oxygen? You know, we could put pilots in a centrifuge, spin them up until they pass out-- a lot of them have near-death experiences, too, they're not near death, but we're depriving their brain of blood flow-- you know, with similar numbers, very, you know, profound, memorable, vivid experiences. So it just depends on the particulars of what parts of the brain are working or not working.

### Moderator
Claim: And nobody's seeing hell, whew.

### Moderator
Claim: Some people have--

But there is hell.

Yeah,

### Conspiracy Advocate (CA)
Claim: There is-- as I said, 3 or 4 percent of people have hellish NDEs. I believe-- I believe there's actually a reality to that realm, to those lower spiritual realms, that you can see referred to back in the Tibetan Book of the Dead, Egyptian Book of the Dead. I mean, it's something that's been referred to for a long time.

### Moderator
Claim: Okay.

### Moderator
Claim: Depends on your amygdala activity.

### Moderator
Claim: Right down in front here. If anybody's upstairs, I apologize I can't see you at-- whatsoever. But if you'd like to ask a question, I see you come to the doors to the rear downstairs, I will try to call on you.

### Moderator
Claim: What is the one thing that you would need to know that would make you believe them, even a little bit?

### Moderator
Claim: So--

### Moderator
Claim: I just want to clarify that as a question to the side arguing against the motion. Steven Novella.

### Scientific Advocate (SA)
Claim: For me, you know, I'm open to evidence for anything. What I would need to see is some information that the people having the experience gained through no other mechanism.

So-- and there are experiments ongoing-- preliminary ones have been negative, there are bigger ones ongoing-- to see if people could, for example, look up on the top shelf and see a card that's placed there, that you could only see if you were actually floating above, near the ceiling, so that would be compelling evidence. I mean, it would need to be enough to-- that would be enough to me to at least take it seriously, but then to be - - to say that it's probably true, you need as much evidence as we have for the neuroscientific model which says it's not possible.

### Moderator
Claim: Steven Novella, could you be convinced? Is there any piece of evidence that would convince you that there's an afterlife?

### Scientific Advocate (SA)
Claim: I could be convinced of anything if the evidence were sufficient.

### Moderator
Claim: I'm sorry, I meant to ask your partner, but thank you for your answer. Sean Carroll, would-- could you be convinced?

### Scientific Advocate (SA)
Claim: Yeah, I think that-- you know, the idea that we could be convinced of another realm in addition to the natural world is obviously, "Yes." There's a million pieces of evidence that would help convince me. None of-- I mean, if this-- if there's a ghost in the room that could lift up that glass right now, then I would be convinced. For those listening on the radio, the glass is not moving, and it-- it never moves when you do this. And we live in a world that looks exactly like there's only the natural world.

### Moderator
Claim: But wouldn't you really kind of like those guys to be right? Wouldn't it be great?

### Scientific Advocate (SA)
Claim: Yes and no. I think that there is obviously advantages.

### Moderator
Claim: Now, what would be the disadvantages?

### Scientific Advocate (SA)
Claim: I don't want to die. I want to live after I die, maybe not for infinity years but for a few hundred thousand years I could amuse myself. Sadly, as a very wise philosopher once said, "You can't always get what you want."

### Moderator
Claim: I want to remind you, we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, arguing it out over this motion, "Death is not final." Let's go back to questions. Ma'am-- sir, right up there, if you could stand-- yes, thanks.

### Moderator
Claim: Oh, hi. Hi.

### Moderator
Claim: Could you step out just-- because it's a little dark where you are--

### Moderator
Claim: Yeah, sure.

### Moderator
Claim: --step into the light, ma'am.

### Moderator
Claim: Hi.

### Moderator
Claim: Move to the light.

### Moderator
Claim: I'm Andrea, hello. I wanted to ask a question to the pro side, which is what is your definition of "final," because in your description of what it was like in this what you called sort of a transcendental state you were feeling things but it didn't seem as if you could do anything, as if you were really talking to anyone. So I wanted to know what your definition of "final" is.

### Moderator
Claim: How will that help you vote on the motion seriously?

### Moderator
Claim: Because, you know, the motion is "Death is not final," so they have to convince me that there's something beyond when the body, you know, decomposes into the earth, so that doesn't end what we know to be life, so I wanted to know--

### Moderator
Claim: But I think-- I'm going to pass because I think that's the thrust of their entire argument is that, that-- unless I'm really missing your point, have argued is that "Death is not final." Am I missing something?

### Moderator
Claim: I just-- oh, I had hoped for some clarification on their definition of "final," but if it seems as if--

### Moderator
Claim: I'm going to pass on it because I think-- right down there. Okay.

### Moderator
Claim: I'm Michael, and, Dr. Moody, in your opening comments you said that we-- you believe we're on the verge of understanding through philosophy and logic this other realm. Can you elaborate on that?

### Conspiracy Advocate (CA)
Claim: Yes. I think that probably about one out of five people I meet socially-- and when the conversation develops, "So, what do you do?" "I write books on near death experiences"-- about one out of 10 people say, "Oh, I don't believe in life after death. When you're dead, you're dead." Then I go on and I ask them, "Well, how did you reach that conclusion?" Most of them say, "What are you talking about in the first place, life after death? It's just illogical." And you know, the sentence "There is life after death" is a self-contradiction, if you look up the words in the dictionary. And this may sound trivial, but this is really a major problem, because that-- it helps us understand why life after death is not yet a scientific question. Question is one of intelligibility. What does it mean? And the person, I think, who stated that point of view most eloquently was David Hume, who said, "By the mere light of reason it seems difficult to prove the immortality of the soul." Then he went on to say, "Some new species of logic is requisite for that purpose. And some new faculties of the mind that they may enable us to comprehend that logic." That sounds like a tall order, but it's not really that difficult. The trouble is that you have to stop thinking about stories for a while and beautiful narratives, and really get busy with some conceptual thinking. But when that's all said and done, I think that we do now have new ways of thinking about things that are illogical that will open up entirely new ways to investigate the afterlife question. This is not geared to the afterlife, per say. What somebody who wants to go through this pathway has to do-- first is to say, "What I'm going to focus here is on learning new logical principles and going through a process of learning." Then, as a corollary, much later down the road, this has implications for the afterlife question.

### Moderator
Claim: We're going-- we're going to book you in about seven years and see where that-- see where that process is. Let me go to more questions. Sir?

### Moderator
Claim: My name's Rob. My question is for the Against side. Thank you. How can you be so sure about your position when you base it upon what we now know in science-- and by the mere fact of what we now know, we're constantly evolving in science? So, how can you base-- be so sure about your position when science may learn things that we don't yet know?

Well, I mean--

### Moderator
Claim: That's a pretty-- that's a pretty good question.

### Moderator
Claim: That's a good question.

### Moderator
Claim: Yeah. Steven Novella.

### Scientific Advocate (SA)
Claim: So, as I said-- as I was saying, I'm a skeptic, so I'm in a perpetual state of doubt about everything. I need lots of evidence and logic to convince me. And all we could say within the scientific realm is what does the best evidence tell us today? Right now, we have lots of evidence that we could be highly confident in the conclusion that the mind is what the brain does. And we have no compelling evidence-- only narratives and really dubious evidence to-- against that proposition, against that notion, or for the notion that there is some consciousness separate from the brain. So, the scientific conclusion today is that the mind is the brain.

If new, dramatic evidence comes to light that changes that, I will happily move along with the evidence.

### Moderator
Claim: Sean Caroll, take a crack at the same question.

### Scientific Advocate (SA)
Claim: I think-- you know, it's a great question because there's this image-- like, when we're teaching high school and science, that it's a bunch of facts that are absolutely established, whereas professional scientists like to brag about the fact that-- like Steven just said-- that, you know, we're always skeptical and we're always ready to throw out everything. And both are true, but because there's some intermediate ground. There are many, many things that science does not understand, and we're hoping to get better at it. Many, many things. And there are also some things that science does understand and are not going to go away. This table is made of atoms. We will improve our understanding of what an atom is, what the elemental particles and fields are that make it up, how they interact. That is not finished yet.

We can do better. But a million years from now, our best scientific understanding will still say that the table is made of atoms. In my judgment, the current status of our scientific understanding, the parts that we're not going to give up, are enough to conclude that death is, in fact, final.

### Moderator
Claim: I want to remind you, we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, arguing it out over this motion-- death is not final. Did somebody come downstairs? He did. I see standing there. Again, I need you to walk to the light. Thank you. A little bit more just so that the camera can see you. Great. Terrific, thank you.

### Moderator
Claim: Hi. My name is Jessica. We've been talking a lot tonight about personal experiences and self-created memories of near-death experiences, whether those are real or just crafted by the mind. But I want to know what the against side has to say about admittedly self-proclaimed psychic mediums, or people completely removed from the situation that seem to have knowledge of events that they were not present for.

### Moderator
Claim: I think that's relevant because your opponents have actually brought up situations like that. So let's go ahead. Thanks for the question. Sean Carroll.

### Scientific Advocate (SA)
Claim: Yeah, I mean, I think that, again, there is evidence in favor of those kinds of things. There is other evidence against those kinds of things. And the kind of remote seeing or telepathy or telekinesis or clairvoyance that is being talked about here is in utter and complete violation with everything we understand about the current laws of physics. So, if something is seeing something, it has to be able to absorb photons. How does that happen? I think that there's, again, an overwhelming presumption that stuff that is in so flagrant violation with everything we understand about the fundamental way that matter and energy works better have amazingly good evidence in favor of it. And the evidence in favor of psychic phenomena comes nowhere near that standard.

### Moderator
Claim: Eben?

### Scientific Advocate (SA)
Claim: Even if we put plausibility aside, a hundred years of parapsychological research has not been able to produce one bit of compelling replicable evidence that shows that it's a real phenomenon.

### Moderator
Claim: So, Eben Alexander, that sounds like the most powerful salvo against your side yet. So what is your response to that?

### Conspiracy Advocate (CA)
Claim: My response is that the evidence for things like telepathy, precognition, remote viewing, out of body experiences, past life memories in children, the afterdeath communications is overwhelmingly positive evidence that it exists and is real. For those out there in the scientific--

--community who want to know more, I would urge them to check the book, "Irreducible Mind: Toward a Psychology for the 21st Century," 800 pages of very dense science data and analysis that shows the absolute reality of nonlocal consciousness in all of those forms. It shows that we have a long way to go in beginning to understand anything about consciousness and that the model that brain creates consciousness and that we can only know things locally with our connected senses is completely false and disproven by a lot of scientists, not just in that book, and those who participated in that, but in multiple other books.

And, I mean, for example, the afterlife experiments Dr. Gary Schwartz, that's a pretty powerful documentation of the power of mediums. There are--

### Moderator
Claim: Two sentences, what were they so we have something concrete for those of us who have not read the book, which is a lot of people.

### Conspiracy Advocate (CA)
Claim: I'm sorry.

### Moderator
Claim: Of Gary Shwartz’s experiments. Give a two-sentence example of what he did.

### Conspiracy Advocate (CA)
Claim: Basically, did a scientific assessment of mediums and their ability to work especially with--

### Moderator
Claim: And showed what? Established what?

### Conspiracy Advocate (CA)
Claim: Well, established that they could communicate and know things that only could be known by the departed relative.

### Moderator
Claim: Okay. So your opponents are saying that there are scientific experiment that's prove paranormal activity is valid, happens, it's real. Steven Novella.

### Scientific Advocate (SA)
Claim: Demonstrably not true. I mean, everything you said is the exact opposite of the truth. Schwartz's methodology was massively flawed. It's been absolutely picked apart by other scientists. He essentially allowed himself to be bamboozled by charlatans and by cold readers. He did not produce anything reliable, anything that I would consider to be credible scientific evidence.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: So that's the bottom line.

### Moderator
Claim: Yeah. Eben, do you want to respond to that, or should we move on?

### Conspiracy Advocate (CA)
Claim: Well, simply to say, I guess with this kind of thing maybe we're at a bit of an impasse because I think that his methodology was actually quite solid. I've met mediums who have convinced me very strongly they're absolutely real.

### Moderator
Claim: All right. There are moments in these debates where we reach impasse, and we move on, and we have just done that. Ma'am. Mic-- microphone is coming to you.

### Moderator
Claim: Hi. My name is Stephanie. So it feels like we are conflating two different questions, and one is whether the mind and consciousness come from the brain, and the other is whether there exists an afterlife. And I don't understand why the existence of an afterlife would show up in the brain. And so I'm wondering, for the--

### Moderator
Claim: I'm going to clarify you-- after you, and then move on. The argument that's being made by the team arguing against the motion is that life stops when the brain dies, and that's why those two things have become conflated. And I think it fits pretty-- together pretty well. Right down in front, ma'am.

### Moderator
Claim: You need the mic too.

### Moderator
Claim: My name is Jane, and my question is for the opposing side. We have energy while we're alive. Where does our energy go when we die?

### Scientific Advocate (SA)
Claim: It doesn't go away. It's up in your head. They're just not continuing to live. It's exactly the same place the flame goes when you put out the candle.

### Moderator
Claim: Does the other side want to--

Does the other side want to take on the candle argument or--

### Conspiracy Advocate (CA)
Claim: I would say it's more a question of the information, you know, than the energy. It's not a conservation issue around energy.

People often use that one to argue against a soul being able to influence the material world. I would say it's much more a question of the information, and especially when you-- as I said, when you-- for example, a very renowned skeptic and scientist, Carl Sagan admitted that past life memories in children, the evidence for that is overwhelming.

### Scientific Advocate (SA)
Claim: That's not true. Come on, Carl Sagan, please.

### Conspiracy Advocate (CA)
Claim: He said that in his book, in his book, "The Demon Haunted World," on page 302, he says exactly that.

### Scientific Advocate (SA)
Claim: I've read that book a hundred times. Carl Sagan did not believe in past lives. He did not believe in anything paranormal or supernatural. That is just not true.

### Moderator
Claim: Impass on Carl Sagan. Question down front.

### Moderator
Claim: Okay. Building on the past lives, I wanted to preface my question by saying I'm a student of Dr. Brian Weiss who is an expert in past life memories.

My question is actually for the against. I recently became aware of a study by a man named Dr. Kenneth Ring who had done research around near-death experiences for people who were born in this lifetime blind. And they described having experiences of seeing and describing color and describing paintings and the color of the carpet. How can you explain that? Is there some kind of brain mapping that happens, you know, that's inherently human that doesn't, you know, involve needing that particular sense?

### Moderator
Claim: Okay.

### Moderator
Claim: How can you explain that?

### Moderator
Claim: I that question. Go ahead. Who would like to take it, Steven Novella?

### Scientific Advocate (SA)
Claim: Yeah, I mean, I haven't read that particular study, so I don't have any detailed information about the specifics, or I'd certainly be interested in taking a look at it. But just the notion that somebody can explain something beyond their experience is not unusual. We are actually pretty creative, inventive people. You know, our human brains have no problem inventing things that we haven't directly experienced. So again, I would need to see details that could not be explained as a brain experience in order to find it compelling.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate where our motion is "death is not final."

## Round 3

### Moderator
Claim: And now we move on to round three. In round three, we will have closing statements by each debater in turn. They will be two minutes each. And remember how you voted at the beginning of the debate because immediately after their closing statements, you will vote a second time, and the team whose numbers have changed the most in percentage point terms will be declared our winner. On to round three, closing statements by each debater in turn. Our motion is "death is not final." And here to summarize his position supporting the motion that death is not final, Eben Alexander, an academic neurosurgeon and author of the bestselling book, "Proof of Heaven."

### Conspiracy Advocate (CA)
Claim: Well, I would like to go back to what Sean had said about how consciousness is very confusing to us as is quantum mechanics. And I would put out there, I think they're related. There's a reason why they're both so confusing.

And that's-- you can chuckle, but in fact, that's what drove brilliant people like Einstein and others into mysticism. And in fact, I would say that that mystery has only gotten much deeper over time. We have not answered that at all. In support of my claim earlier about brain damage allowing enhanced function, which really goes against the materialist model that Steven talked about earlier, I point out two very common examples in clinical practice; acquired savant syndromes, in which strobe brain trauma, autism, can allow super human mental function, something that's often seen, that certainly has no explanation from the brain makes mind model; and also terminal lucidity, in which demented elderly patients often have periods of great clarity, especially around the time that they are encountering souls of departed loved ones that are there to escort them over. And I would say that these very commonly observed phenomena really demand a much deeper model of consciousness than we get out of the materialist models.

I'll point out that Dr. Wilder Penfield wrote a book in 1975, "The Conscious Mind." He probably still holds the record for having stimulated the brain in awake patients more than any other neurosurgeon. And never once did he duplicate any kind of situation of free will. He concluded very strongly that the mind consciousness is not created in the physical brain. And I think it's important to point out that the pure materialism fails. It's a hard problem of consciousness and at the enigma of quantum mechanics, that the brain actually confines and limits consciousness, that science acknowledging consciousness, soul and the spirit becomes much stronger than the overly simplistic science of reductive materialism. Death of the physical brain and body is not final. Thank you.

### Moderator
Claim: Thank you, Eben Alexander. And that is our motion, "Death is not final." And here to argue against the motion, Steven Novella. He's a neurologist at Yale School of Medicine and founder of science based medicine.

### Scientific Advocate (SA)
Claim: So up until a couple hundred years ago, every culture in the world believed that there was a life energy. They knew intuitively, they sensed that there was something fundamentally different about living things from nonliving things, and they hypothesized that there must be some energy, some vital, spiritus, chi, whatever you call it, that fundamentally makes living things different than nonliving things. But over the next 100, 150 years, basically the 19th into the 20th century, we discovered biochemistry and genetics and developmental biology, and all different principles of biology, until essentially there was nothing left for the life force to do. We had explained everything that living organisms do, and we explored the blurry line between living and nonliving, and we realized that there is no fundamental difference there. It's just, as you get increased complexity at some point you cross this fuzzy line, and you're doing a process that we call "life." Well, we're kind of going through the same process though maybe a little bit delayed with consciousness. You-- we understand that the brain causes consciousness. We certainly don't understand a lot about how it is produced exactly. But we're making progress. Our research paradigms are working quite well, thank you, and we're making lots of progress. It's just as irrational, if you will, to hypothesize that there is some magical energy or some non-corporeal thing, stuff, that is consciousness, as it was 200 years ago to say that, "Well, because we can't explain life, then we need a life force." We don't need a brain force, a mind force any more than we needed a life force 200 years ago. The fact is that the neuroscientific community is progressing relentlessly with the paradigm that is materialist, reductionist. We're looking for neuroanatomical correlates of everything that the mind does, and that research program is very, very successful. And it-- how well an idea advances in science is more telling about how valuable it is, how true it is, than what our current state of knowledge is.

Our current state of knowledge is always going to be incomplete. It doesn't mean that our ideas are wrong or are weak. That's why you have to vote against this proposition.

### Moderator
Claim: Thank you, Steven Novella. And the proposition is, "Death is not final." And here to summarize his position in support of the motion that "Death is not final," Raymond Moody, he's a medical doctor and author of the book, "Life After Life," in which he coined the term, "Near-death experience." Raymond Moody.

### Conspiracy Advocate (CA)
Claim: First of all, I want to say that to me to this day the notion of life after death is very counterintuitive. I think as a nonreligious person I had no background in that. It never occurred to me, as a young astronomy buff, that there might be something beyond this. I've been through a process now of 40+ years that finally drove me into this situation where I'm sort of forced to say, almost against my will, that "Death is not final," there is a life after death.

Basically what happened to me was that hearing thousands of people with near-death experiences, hundreds of people with shared death experiences who had the identical experience we call a near-death experience, except they weren't ill or injured, they were simply there at the bedside of someone else who died, and I have seen joint transcendent experiences where, for example, a physician and a critically ill patient would have some sort of joint transcendent experience at the same time. That leads me to be forced almost into a position to say that I trust these people's judgment. It seems to me that they've been somewhere where I haven't been, and I can begin to put a little picture together of what they're talking about. So for that reason I would say I'm onboard. I think there is life after death.

So vote, vote, vote for the afterlife. And--

### Moderator
Claim: Thank you, Raymond Moody. Our motion is, "Death is not final," and here to summarize his position against the motion, Sean Carroll. He's a theoretical physicist at the California Institute of Technology and author of, "The Particle at the End of the Universe."

### Scientific Advocate (SA)
Claim: When I was about six years old, I had an emotional formative experience that apparently many other people share similar things. I was in bed, you know, going to sleep, sort of thinking about the day and so forth, and I started crying. I was just bawling uncontrollably, so much so that my mom heard me from her bedroom and came running in, saying, "What is wrong?" And I said, "Some day, our grandmom is going to die. And someday, you're going to die. And someday, I'm going to die. We're all going to die."And you know, she had to explain, "Well, yes." And so forth. And she had her own version of the story. And the reason I'm telling this story because even as convinced as I am that death is final, I have absolutely no desire to belittle the people in the room who disagree, who feel the other way. This is an incredibly important, central issue to our lives. I personally am convinced by the overwhelming scientific evidence from physics, from neuroscience, et cetera, that there is one world, the natural world. Biology is a process that can end. And death is final. And to me, that fact-- the finitude of our lives-- gives enormous poignancy and importance to the finite number of years that we have here on earth. Our lives here are not dress rehearsals. This is the act. This is the one performance that we get. That does not remove meaning or value from the lives we're leading now.

It gives-- it forces us to give meaning to everything we do, because we only have a finite number of things to do. If evidence came in on the other side, I would change my mind quickly, if the evidence was good enough. But I think that we're past the point where it's a scientifically interesting question. I think that we know enough to conclude that death is final. And personally, I think that that is okay. Thank you.

### Moderator
Claim: Thank you. Sean Caroll. And that concludes closing statements. And now it's time to learn which side has argued best. We're going to ask you to go again to the keypads at your seats and vote for the second time. And it will be the difference between the first and second vote by you, our audience members here in New York, that will determine our winner. The team whose numbers have changed the most will be the team that wins. Our motion is Death is Not Final.

Okay. Are we good? We can lock out the system.

### Moderator
Claim: Which numbers?

### Moderator
Claim: Oh, numbers are the same as before. If you are for the motion, push #1. If you are against the motion, push #2. And if you became or remain undecided, push #3. And you can ignore the other-- the other keys. The other numbers are nothing. I'll give it another 15 seconds. And my apologies for that. Okay. It looks like everybody's good. So, while we're waiting for the calculation to come in, I just want to say this. You know, Sean Caroll just made the point in his closing statement very, very brilliantly, about-- this is not a debate that in any way was meant to disrespect anybody.

And in fact, that would go very much against the spirit of Intelligence Squared, which-- it's goal is to raise the level of public discourse. And what I heard, not only from Sean Carroll, but from all four of these debaters, were four people who disagreed vehemently on something very personal, meaningful, and metaphysical. And yet, they did it in a respectful way. And I have to really give them a round of applause for the way they did that. And also, to everybody who asked a question, including the questions we didn't take-- it takes a lot of guts to get up in front of an audience and ask questions. Some of them were terrific and the other ones were just darn interesting. And I think it might sell some more books for Eben Alexander, but to everybody who got up and asked a question, thanks very much for doing it. I-- we would love to have you Tweet about the debate.

As I said at the beginning, our hashtag tonight is #afterdeath. That-- our Twitter handle is @IQ2US. And this was our final debate of our spring season. We-- this was Debate #91, I think, that we've put on since Bob Rosenkranz started this thing. And it was a new zig-zag for us. I think it went really well. It was very interesting. A little metaphysical for a night out in New York. I mean, if this is anybody's first date, you're probably-- it's probably going to stick for a while. We're doing a debate, though-- the National Constitutional Center-- Constitution Center in Philadelphia next month, our second time going there. And we're going to be looking at the question of whether independent political speech is the linchpin of our democracy, or is it its Achilles heel? We're looking at the question of the ability of individuals and organizations to influence campaigns through campaign spending and whether the Constitution actually presents that expenditure as a matter of the First Amendment. Tickets to that will be available through our website, wwwiq2us.org.

And we are going to be announcing our fall lineup soon. We'll be back here at the Kaufman Center, and the debates for that are in tonight's program. On the list of topics that we're considering, "Income inequality," "Assisted suicide," "Genetically modified food," "Cybersecurity," "Privacy," "Monogamy," "Climate engineering," "The private lives of public figures," and "Google Glass." So those of you who can't join the debate, of course we are on fora.tv and on NPR stations across the nation. Okay. So I have the results all in. Remember, we had you vote twice on this motion, "Death is not final," once before the debate and once again after the debate, and the team whose numbers have changed the most will be declared our winner. Here are the results. In the first vote, "Death is not final," 37 percent agreed with that, 31 percent disagreed with that, 32 percent were undecided. Those are the first results.

Now, the second vote-- remember, the team whose numbers have changed the most will be the winner-- in the second vote, the team arguing for the motion, their second vote was 42 percent. They went from 37 percent to 42 percent. They picked up 5 percentage points. The team against the motion, now-- 5 percentage points is the number to beat-- the team against the motion-- they went-- their first vote was 31 percent, their second vote was 46 percent. That's up 15 percent. The team arguing against the motion "Death is not final," has won this debate. Basically saying, "Death is final," sorry. Thanks very much, everyone. Thank you from me, John Donvan, and Intelligence Squared. We'll see you next time.
