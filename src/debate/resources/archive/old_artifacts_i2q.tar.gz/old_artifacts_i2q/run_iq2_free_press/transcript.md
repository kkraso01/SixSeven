# Debate Transcript

Topic: Freedom of the Press Does Not Extend To State Secrets
Motion: Freedom of the Press Does Not Extend To State Secrets

Debate ID: free-press


## Round 1

### Moderator
Claim: And I'd also like to introduce the man who, 50 debates ago, founded Intelligence Squared U.S., Mr. Robert Rosenkranz.

### Moderator
Claim: Welcome. This evening is special because it marks our collaboration with the Film Society of Lincoln Center, coordinated with the opening of their splendid new facility and their premier of a documentary about The New York Times, “Page One,” which has a nice feature about Intelligence Squared, actually. It's also very special for Intelligence Squared, for our mission to promote a higher level of public discourse in America and for all of our supporters and staff, for John Donvan, for our research head, Kris Kamikawa, for our executive producer, Dana Wolfe, and for me, because tonight we reach a landmark, which is our 50th debate. First Amendment reads, quote, "Congress shall make no law abridging the freedom of the press." But Congress did pass a law back in 1917 called the Espionage Act which applies broadly to national defense information. The law prohibits disclosing such information to persons not authorized to receive it, who have reasons to know it could prejudice national security or U.S. interests. The founders recognized that a free press is an essential antidote to an abusive government. But Congress recognized that a measure of secrecy is an essential attribute of an effective government. No reasonable person would dispute that matters like the movement of troops, the names of spies or the plans for building a nuclear bomb are necessary secrets which the press should not be publishing.

But no sophisticated person would doubt that governments can be tempted to use the guise of national security to protect the reputation and electability of its officials. And between these two extremes, there are abundant shades of gray in which the national security bureaucracy might be genuine in its concerns but overbroad in its actions. I saw this myself when, early in my career, I was a national security analyst at the RAND Corporation. All of us had security clearances. But some of our work was classified at such a high level that their authors could not read them. The tensions here are obvious. The press will want to err on the side of disclosure, the government on the side of secrecy. Well, how are the inevitable conflicts to be resolved?

What principles should be applied and by whom? Should the press publish what they like and take the risk of prosecution afterwards? Or should government be able to prevent publication in the first instance? And who exactly is the press? A tricky question in an era of bloggers and WikiLeaks. These are complex and important issues. We have an extraordinary panel with us this evening to help you decide. And it's my pleasure to turn the evening over to them and to our moderator, John Donvan.

### Moderator
Claim: Thank you.

### Moderator
Claim: John, thank you.

### Moderator
Claim: And may I just invite one more round of applause for Robert Rosenkranz for making this possible. So a major newspaper-- say a major newspaper of record gets a hold of some classified government material, say some leaked documents, some leaked government diplomatic cables and prints those documents. Well, what has that newspaper done?

Has it exercised its rights under the First Amendment, or has it betrayed the nation? And does the answer to that question depend on the consequences of publication? Well, let's argue that out. That's what we are here for. This is another debate from Intelligence Squared U.S. I'm John Donvan of ABC News. We are at the Skirball Center for the Performing Arts at New York University. And on this stage we have two teams of debaters, two tables, two members each. Arguing for the motion, “Freedom of the press does not extend to state secrets,” we have Gabriel Schoenfeld, who is author of “Necessary Secrets: National Security, the Media and the Rule of Law,” and his partner, Michael Chertoff, former secretary of Homeland Security and cofounder of the Chertoff Group. Arguing against the motion that freedom of the press does not extend to state secrets, Alan Dershowitz, the Felix Frankfurter professor of law at Harvard Law School and David Sanger, chief Washington correspondent for The New York Times.

Now, I just want to be clear because there's a negative in this motion. It can sometimes be tricky. “Freedom of the press does not extend to state secrets.” If you support this motion, you’re leaning more towards the side for secrecy. If you are against, you're leaning more towards disclosure and more towards the liberty or license for the press. So I just want to be clear about that because of the next thing I want to say. This really is a debate. There will be winners and losers in this debate. It's a contest in which you, our live audience, act as the judges. By the time the debate has ended, you will have been asked to vote twice, once before and once after, to tell us what your view is on this motion, “Freedom of the press does not extend to state secrets.”And the team that has changed the most minds in the course of the debate will be declared our winner. So let's go to your preliminary vote. If you go to those key pads at your seat, I'll state the motion again with the caveat that I put in, but I won't restate it because I think I confused everybody. “Freedom of the press does not extend to state secrets,” if you agree with this motion, press number one. If you disagree, number two, and if you are undecided, press number three. And if you think you made a mistake, just correct it and the system will lock in your last vote. So we do this in three rounds. The first round is opening statements, seven minutes each by each debater. Then we have a middle round in which they talk to each other and take questions from you. And then the third round are brief closing statements and then our final vote. So onto round one, opening statements by each debater in turn.

Our motion is "Freedom of the press does not extend to state secrets." And arguing for that motion, I'd like to introduce Gabriel Schoenfeld, senior fellow at the Hudson Institute and author of “Necessary Secrets: National Security, The Media and The Rule of Law.” And, Gabriel, you are also a chess player, I understand chess master at the U.S. Chess Federation?

### Conspiracy Advocate (CA)
Claim: That's right.

### Moderator
Claim: So you've come to play and to win?

### Conspiracy Advocate (CA)
Claim: Yes. And I can see far ahead as well.

### Moderator
Claim: Ladies and gentlemen, Gabriel Schoenfeld.

### Conspiracy Advocate (CA)
Claim: Ladies and gentlemen, welcome. The gravity of the issue we're debating here tonight cannot be overstated. At stake is nothing less than preventing a reprise of the kinds of attacks that befell our city and our country nearly 10 years ago. To keep our country secure, our government inevitably generates a great many secrets of many different kinds.

We cannot disclose all of the methods by which we track terrorists. We cannot publicize the vulnerabilities of our bridges and tunnels and buildings. We have an absolute duty to conceal things like the blueprints for nuclear weapons or the formulas for substances like aerosolized anthrax. But equally at stake is the character of our democracy. We live in an open society, and secrecy is antithetical to the democratic idea. Secrecy can be used as a cover for corruption and wrong-doing. And we depend upon a free press to keep us informed about what our government is doing in our name, including the things that it's doing in secret, or at least some of them. And indeed the foreign affairs pages of our major newspapers are filled with stories based upon reporting drawn from state secrets. And that's the way things are, and that's the way they ought to be.

But even as we have a press that we want to be delving into state secrets, it must do so under the rule of law. That is the press must be vulnerable to prosecution when it violates the laws governing secrecy. Now here, as Robert Rosenkranz mentioned, we run head long into the First Amendment. The First Amendment says that Congress shall make no law abridging freedom of speech or the press. But, of course, we live with numerous abridgments of free speech and free press, all widely accepted by the public and upheld by the courts. We can't libel one another. We can't engage in false advertising. And of course, it's forbidden to yell, "Fire"-- falsely yell, "Fire" in a crowded theater like this one. Now, Congress has enacted several statutes that criminalize the publication of state secrets. The Espionage Act was mentioned but one might also point to the Atomic Energy Act that makes it a crime to publish classified material pertaining to the design of nuclear weapons.

Or the COMINT Act which makes it a crime to publish classified information pertaining to cryptography, or code breaking, or the Intelligence Identities Protection Act makes it a crime to publish the identities of undercover CIA officers and other intelligence officers of the U.S. government. Now, these laws are all in obvious tension with the First Amendment, but no court has ever struck them down. And it is a statement of fact, ladies and gentlemen, the proposition under debate here tonight, the freedom of the press does not extend to state secrets, is inarguably true. Valid laws are on the books that criminalize the publication of certain state secrets. Now, does the existence of such laws mean that every time a journalist like my colleague here, David Sanger, publishes a state secret he should be prosecuted and marched off to prison? Absolutely not. That would be foolish in the extreme. That's why we recognize that our government is promiscuous with the secrecy stamp.

It marks lots of things secret that need not be. And back when I was an editor at Commentary Magazine, I myself published classified information and I would do so again. The real question raised by the proposition is whether the press can and should be prosecuted in those instances when it places the country in danger. Such danger is not purely hypothetical. Back in the 1970s there was a magazine called Counterspy that began to publish the identities of hundreds of CIA officers around the world. In 1975, it outed Richard Welch as the CIA Station Chief in Athens. And no sooner was his name disclosed that he was murdered by a Greek terrorist organization as a direct result of that revelation.

Today we have WikiLeaks which in the name of transparency has indiscriminately dumped thousands of secret diplomatic and military cables onto the Internet. Now, some of those documents are innocuous. And many of them without question help us better understand what our government is doing around the world and what other governments are doing, but some of them are outright dangerous. One WikiLeaks document, a U.S. Army document that they put on the Internet, describes the technical details of the jamming devices used by our soldiers in Iraq to scramble the signals that insurgents were using to detonate roadside bombs. Now, I ask you is there any reasonable person who believes it should be legal to publish the secret countermeasures used by our soldiers to keep from getting blown up on the battlefield?

Is there any reasonable person who believes it should be legal to publish blueprints for making nuclear bombs-- or should it be legal to give out the recipe for-- to publish the recipe for making aerosolized anthrax? Those are questions that I hope we will receive straightforward answers to tonight from David Sanger and Alan Dershowitz. If they believe those things should be allowed, I hope they'll fully and frankly acknowledge the costs, and if they think those things should be prohibited by law, well, then they'll be agreeing with the very proposition that they supposedly came here to oppose. Ladies and gentlemen, freedom of the press does not, cannot, and should not extend to state secrets. Not all government secrets warrant protection, but some clearly do. And if you in the audience agree with what Justice Robert Jackson once memorably said, that the Constitution of the United States is not a suicide pact, I urge you to vote for the proposition at issue here tonight.

Thank you.

### Moderator
Claim: Thank you, Gabriel Schoenfeld. Our motion is "Freedom of the press does not extend to state secrets," and here to speak against this motion, Alan Dershowitz, Harvard law professor and consultant to WikiLeaks founder Julian Assange's legal defense team. Alan Dershowitz is, as we all know, a great attorney and a celebrity attorney who's been played at least twice in the movies, you were played in "Reversal of Fortune" by the late great Ron Silver in the Klaus Von Bulow story, and in "American Tragedy, O.J. Simpson Trial," you were played by Richard Cox, but interesting, Ron Silver in that movie played Robert Shapiro, so was he upgrading the role or--

### Scientific Advocate (SA)
Claim: All I can tell you is "Reversal of Fortune," having been produced by son, Elon Dershowitz, who is in the audience, is a much better film.

### Moderator
Claim: Ladies and Gentlemen, Alan Dershowitz.

### Scientific Advocate (SA)
Claim: Thank you so much.

Thank you. It's a distinct pleasure to be arguing with two such distinguished people-- Gabriel Schoenfeld, whose book I reviewed for The New York Times, and reviewed very favorably. And I admire much of what he writes, but we disagree, and you'll hear the disagreements. And Judge Michael Chertoff, whose work as a public figure deserves all of our appreciation. He has helped protect us for so many years. And of course, my distinguished colleague who will be arguing on my side. The proposition is far too broad. “State secrets” encompass far too much. And even the criteria used by my opponent-- quote “places the country in danger”-- is far, far too broad. Let me start with a story that one of my dissident clients told me in the 1970s, when I was representing Soviet dissidents in the bad old days of the Soviet Union. The joke went around during Stalin's time that a dissident was arrested for the crime of calling Stalin a “fool.”And he came to court and he said, “I didn't commit a libel. I want to defend myself. I will prove that what I said is truthful.” And he said, “You don't understand. You're not being charged with libel. You're being charged with revealing a state secret!” And that's precisely the kind of state secret that we often seek to protect. Now, you don't have to be Stalin. Remember, everybody knows-- every newspaperman memorizes the famous quote of Thomas Jefferson that he made before he became a president. He said, “Were it left to me to decide whether we should have a government without newspapers or newspapers without government, I should not hesitate a moment to prefer the latter.” That was pre-presidential Thomas Jefferson. Now let me read you a quote six years into his presidency: “A man who never looks into a newspaper is better informed than he who reads them. And as much as he who knows nothing is nearer the truth than he whose mind is filled with falsehoods and errors.”Thomas Jefferson sought to censor the press. We all know that he opposed the Alien and Sedition Act. Of course he did, because that was federal legislation. But he supported state legislation that would have censored the press and protected him from embarrassment. Now, you just have to look in today's New York Times to see how foolish some of these state secrets that are protected tend to be. Finally, finally, the Pentagon papers are about to be declassified and released. I defended Senator Mike Gravel against the charges of reading the Pentagon papers-- what was it-- 40 years ago! And Daniel Ellsberg, in today's Times, I think aptly states the reason why the Pentagon papers were censored for so long. He said, “The reasons are very clearly domestic political reasons, not national security at all. The reasons for the prolonged secrets are to conceal the fact that so much of the policy making doesn't bear public examination. It's embarrassing or even incriminating.”You don't have to be as cynical as Ellsberg-- and Ellsberg is not one of my heroes. I agree with Gabriel Schoenberg's analysis of Ellsberg for the man. But the point is a very, very important one. Secrets get disclosed all the time. And the issue is not whether secrets will be disclosed. If you read The New York Times, if you read Bob Woodward, if you read Seymour Hersh, you understand the question is who decides which secrets are disclosed to whom? When? Secrets get disclosed. Bob Woodward has its sources. Why do people talk to Bob Woodward? Why do they give him classified information? Why do they give Seymour Hersh classified information? Because those are secrets that government officials want to have revealed. So the question is not “Should state secrets be subject to the First Amendment?”The question is, “Should the government-- the executive branch of the government-- be making the decision as to which secrets to withhold and which to reveal?” Secrets should be kept. And the primary responsibility for keeping secrets lies with those who have those secrets. If you look, for example, at how WikiLeaks got disclosed, the alleged culprit there is man-- a private named Bradley Manning-- who have never should have had access-- such easy access to the material that he disclosed. That was negligence on the part of the government. As Julian Assange, I think, aptly put it, “The best way to keep a secret is not to know it.” And if the government wants to keep secrets, they have to do a better job of preventing them from being leaked-- and not put the burden on the press. And by the way, I mean not only leaked WikiLeaks style, but leaked Bob Woodward, Seymour Hersh style, the kind of selective leaks that we've come to grow accustomed to. There are very limited numbers of secrets that deserve to be protected.

And they can be listed and catalogued. You listed some of them. I agree with some. I disagree with others. The names of troops, of the nature of weapons. But you mentioned a couple, for example, methods used to track terrorists, vulnerability of bridges. Those are very complicated. We have a right to know, at least in broad terms, what kinds of methods are being used, whether they're constitutional or not. We have a right to know if our bridges are vulnerable, not how they're vulnerable. These are very, very hard judgments. So you can agree with our side of the proposition while conceding that there are a limited number of things that should be kept secret. And I believe-- and here we have a real disagreement. You wrote in your book that you would prefer to leave this to the good judgment of prosecutors, the discretion of prosecutors and the common sense of jurors. What I would prefer to see is a complete starting from scratch with the Espionage Law of 1917. Scrap it.

It tells us nothing. And draft a very narrow statute that says you cannot disclose the nature of certain kinds of weapons. You cannot disclose the movement of troops. You cannot disclose the names of spies. That is not state secrets, broad general concept. That's a limited number of things that need protection, not protection from The New York Times because the Times won't publish them, but protection from Internet people who will publish almost anything without any kind of accountability. There must be a strong presumption in favor of freedom of speech and sunshine as the best disinfectant. The government says, "Trust us." No. Don't trust the government. The New York Times says, "Trust us." Don't trust The New York Times. Trust the process of checks and balances, whereby the government tries to keep secrets. The press tries to release the secrets.

That process is the best guarantee of liberty. Thank you.

### Moderator
Claim: Thank you, Alan Dershowitz. So here's where we are. We are halfway the open round of this Intelligence Squared U.S. debate. I'm John Donvan of ABC News. We have four debaters, two teams of two fighting it out over this motion, “Freedom of the press does not extend to state secrets.” You've heard two of the opening statements, and now onto a third. I'd like to introduce, arguing for the motion that freedom of the press does not extend to state secrets, Michael Chertoff is former secretary of Homeland Security and cofounder of the Chertoff Group. And after a long career in government, lived with the secrets, knows what some of them are. So just between us, because it's us here, you're going to share some of it?

### Conspiracy Advocate (CA)
Claim: You're not going to hear any secrets from me, John.

### Moderator
Claim: Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: Thank you, very much.

First, let me again thank you for inviting us to this debate. I think it's a critical issue for the country.

I'm delighted to be on the same stage with such distinguished scholars and authors. I think, though, if I'm not mistaken, that the other side has essentially conceded the proposition for which we are arguing, and that proposition is that freedom of the press has to give way to state secrets. Now, nobody is arguing that the proposition means everything that the government has in its possession is a state secret, nor are we arguing that simply having a single public official asserting that something is a state secret ends the analysis. But I think where the dispute has come down to is who actually makes the decision. Is it the government and the government process, which is what our contention is and our proposition is, or is it the press. Does the press get the final say? Now, I will agree with Professor Dershowitz that in the first instance, the right way to deal with this problem is for the government to control its own secrets.

And most of the time, the government succeeds in doing so. Although the press is constantly making the argument that as a matter of law, they ought to have access to those secrets. And those arguments are relatively routinely rebuffed. But the reality is that there are times people do leak secrets. And sometimes they do it for what they may conceive to be noble motives. Sometimes they do it for purposes of settling scores or personal advancement. And sometimes they do it perhaps because they want to hurt the United States. And in those instances, it is not enough to say that because the government has failed to keep the secret, the secret ought to become public and ought to be published widely. National security and human life cannot be the subject of a cat and mouse game. And so I would argue that actually the existing system, which does require freedom of the press to give way to genuine state secrets is pretty much the correct balance. How does that work?

Well, first of all, if the press wants to get a secret in the possession of the government, it's very difficult to do so. And there's a very strong presumption against simply open access to very significant classified material. But we do have cases where the material gets out. And there, I believe the law allows, if the facts are there and the intent is there, a prosecution to take place as a way of deterring somebody from publishing that secret. And that's in fact what the law basically is. There are statutes in the books that permit those prosecutions. When the courts have been confronted with those prosecutions, and those are relatively rare cases, the courts have upheld the principles of those prosecutions. Even in the Pentagon papers case, at least five of the justices and probably seven, indicated that there were instances where a prosecution might be appropriate even if not in that particular case.

And even with respect to prior restraint, the issuance of an injunction to prevent publication, most of the justices on the court have acknowledged in the case of a very strong and dangerous release of information, for example, the proverbial publication of information about the movement of a troop ship, it would be appropriate to rejoin the publication of that material. And that's because the courts recognize that in the government process, a combination of executive action, congressional action and judicial action is the best mechanism for balancing between state secrets and freedom of the press. Now, the press often argues we ought to be the judges. And the difficulty is that the press is sometimes a flawed judge of what is in the public interest. First of all, the press is not a monolith. As Professor Dershowitz pointed out, we're not concerned about The New York Times. We're worried about people who blog. But the First Amendment doesn't distinguish between The New York Times and The Wall Street Journal and al Manar, which is the news organ of Hezbollah.

Or extreme blogs on the right or the left. All of those are part of the press. Nor do we want to have the government start to license particular organs as organs that can be trusted and organs that can't be trusted. The fact is if we say that state secrets have to give way to the press when the press gets hold of them, then we mean it has to be any member of the press, a blogger, a Hezbollah journalist, somebody who works for a news organ run by the government of a foreign country. And I don't think any of us believe that would be prudent or safe. Is the press right even when we deal with the venerable institutions that we're so familiar with? Well, the press sometimes also makes mistakes. Several years ago, there was a publication by The New York Times. I know David Sanger knows about this, of information about a program that allowed the United States government to see what was going on in the financial transactions that were being executed through a program known as Swift.

And this was critical in tracking the flow of money that was used to support terrorist activity. Precisely one of the recommendations that was made by the 9/11 commission against the very strong request of the Bush administration, that material was published. And the original argument was, well, this is something people need to know about because it's potentially illegal or requires some kind of oversight. But what emerged after a period of time is it was completely legal and that there was nothing wrong about it, and nobody's privacy had been improperly invaded. Everything was done according to an appropriate process. And therefore, the public ombudsman of The New York Times had to write a retraction. He had to write a piece in the Times saying that while he had originally endorsed the publication of the Swift material, he had changed his mind, and it was not appropriate because it turned out that there was nothing wrong with it, and there was no powerful interest served in releasing that material.

And then he made an interesting and telling confession, that he had originally endorsed the disclosure because he didn't like the administration and the way the administration was treating the paper. And I suggest to you that that's the problem with having the press make the decision. The press is no more in a position to separate itself from its interests than anybody else. But unlike the organs of government which are accountable to the public and to each other, the press is accountable to nobody. And that's why I strongly urge you to support the proposition that we're advocating tonight. Thank you very much.

### Moderator
Claim: Thank you, Michael Chertoff. Our motion is "Freedom of the press does not extend to state secrets." And now here to speak against the motion, David Sanger, who is chief Washington correspondent for The New York Times and was part of the team involved in its WikiLeaks coverage, so you've, David, printed some secrets in your time.

### Scientific Advocate (SA)
Claim: A few.

### Moderator
Claim: A few. Well, I hope you're going to share those with us since the other guy wouldn’t. Ladies and gentlemen, David Sanger.

### Scientific Advocate (SA)
Claim: Thank you Thank you very much. And it's wonderful to be here and to be with such a great panel. In Schoenfeld's book, if you haven't read it, it's a wonderful accounting-- historical accounting of the tension between the press and the government. Michael Chertoff has done a fabulous work and we have talked over many years on many different subjects, and I agree with almost everything that my partner here had to say except when Alan Dershowitz declared that you shouldn't necessarily trust everything that you read in The New York Times. We’ll take that aside later on. I come to this as a practitioner, not as a legal expert.

And I come to this knowing that the tensions that we are discussing here today are as you've heard as old as the Republic. The New York Times among other newspapers had reporters embedded with Civil War troops, Union troops, and at one appropriate moment or another, several generals having read the reviews of their strategy, took those reporters and put them in the brig. I've been around more than a few government officials who have suggested to me over the years as we have debated various stories that we were getting ready to write that what was good for General Sheridan would be perfectly good today. I would argue that in fact it is impossible, it is impossible to separate out state secrets from what appears every day in The New York Times and other major newspapers around the world.

It is impossible because you cannot discuss the subject of whether or not we should have gone into Iraq, or how quickly we should get out of Afghanistan, or the issues surrounding cyber war that we deal with each and every day now, without daily venturing into territory that is classified somewhere and somehow. The problem is, as a reporter, I probably don't even know when much of that material is classified. And I can tell you as someone who went through the WikiLeaks material for many months before The Times and other newspapers published them that I was pretty surprised by some things that were stamped “secret.” I came into the office one day and asked if anybody knew why every American embassy that collects the morning news accounts that would appear in the Spanish press or the Chinese press and collates them and sends them off to Washington so that they would have a sense of what's appearing in those press reports each day.

Somebody on the way out the door, as they are putting that cable over to Washington, stamps “secret” on them. They had appeared in the newspaper that morning. What does that tell you early on? It tells you that you cannot have a system in which you keep state secrets from being published if almost everything is a state secret. And my friend, Michael Chertoff, points out that the press is a flawed judge of the national interest. That is absolutely true, but a better judge than the U.S. government because when you read the U.S. government's own regulations for what gets made classified, what that stamp goes on, the rules only discuss national security considerations. There is no category that makes the person who's got that stamp in the hand weigh a public interest.

Only the press can do that and only after the information is out. Now, there's a second issue around this which the other side pointed out, which is that only the executive, they said, really has the full knowledge to make those decisions. But in fact I think what you heard in the discussion of the constitutional origins of all of this is that the founders believed that to give the executive complete discretion in this area is to create a country that isn't like the America that we know. You would get Egypt under Mubarak; you would get the Chinese press today. And Americans feel that deeply. Just think about the criticism directed at The New York Times when we failed to go as deeply as we should have into the evidence concerning the justification for going into Iraq.

It would have been wonderful if we could have published more about what the U.S. government knew about whether weapons of mass destruction existed. Eventually, we were able to. But at the time we were doing that reporting, it was all deeply classified, except for those tidbits that the U.S. government decided to release to support its own case. Now, we are hardly indifferent, as reporters, to the question of what the consequences of these actions are. We live in New York and Washington. Our kids ride the subways. We have reporters who are out all across the world. Many have been kidnapped. A couple, unfortunately, have been killed. A wonderful photographer for The New York Times lost both his legs just a few months ago, stepping on an improvised land mine in Afghanistan. We know that the violent jihadists, who we write about each and every day, have no interest in a free press. And we're not here to side with them.

We are also not here to be propagandists for the U.S. government. And you don't want us to be. If you think, briefly, about some of the stories that we have held back on, we held back for a year on the story on warrantless wiretaps that President Bush authorized. Eventually, we published it. Congress decided to rewrite the law. We held back for three years-- on a story I worked on for some time-- about a secret U.S. government program to help secure Pakistan's nuclear weapons. We held the story because the government was fearful that if we published it too soon, we would be giving al-Qaeda or the Taliban directions into how to get to those weapons. And we published stories that are quite controversial including one earlier this year about Stuxnet, the computer virus that many believe the U.S. government had a role in developing. It was used against the Iranian nuclear program.

What possibly could be the interest in that? Very simple. If the U.S. government-- if any other government-- is starting off a cyber war, well, we are the country that is most vulnerable to that problem. And we could be subject to attacks in response. So, these are central policy issues. These secrets are not merely published because they are cool stories. They are published because there is a debate that the public has to conduct. Thank you.

## Round 2

### Moderator
Claim: Thank you. David Sanger. And that concludes round one of this Intelligence Squared U.S. Debate where our motion is “Freedom of the press does not extend to state secrets.” Now, keep in mind how you voted at the top of the evening. You're going to be asked to vote once again at the end. I'm reminding you that the team that has changed the most minds will be declared our winner. A couple of other things I just wanted to mention, in terms of this being a radio broadcast, there are some---- the only somewhat scripted moments of the evening will be some introductions that I'll make repeatedly, telling you again and again who I am and who our panelists are, and where we all are, and we know that. And every now and then I'll say, “We'll be right back,” but we won't really go anywhere. We'll all still be here. And between the rounds that we just took, the stations like to take a break. So what I'd like to do is ask you, when I raise my hand, to burst into such enthusiastic applause that people listening in their cars will think, “These people must be having a great time. I'm going to stay and listen to this.” And then we'll move on to round two. So let's go do that. Welcome back to this debate for the Intelligence Squared U.S. I'm John Donvan of ABC News. We're at the Skirball Center for the Performing Arts at New York University. Our motion is “Freedom of the Press does not extend to state secrets.” We have heard from both sides, the side arguing for the motion: Gabriel Schoenfeld and Michael Chertoff, who are arguing that a press that can publish state secrets without fear of prosecution actually endangers the nation.

The team arguing against, David Sanger and Alan Dershowitz, are arguing that yes, there are secrets that should be kept, but it should not be up to the executive of the U.S. government alone to decide which of those secrets are worthy of keeping secret. So we've heard opening arguments. And now, the two teams are going to be freer to debate each other and to address one another. And we'll take questions from you as well in just a few minutes. But I'd like to start putting to the team that is arguing for the motion-- and this is an argument for greater restriction on press freedom to publish secrets-- do you feel that the press can actually do its job, that your opponent, David Sanger who is with The New York Times, can do his job if he has to face fear of prosecution on a greater-- to a greater degree than he does now? Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: First of all, I respect David, and I certainly don't want to suggest he should ever put himself in harm’s way. But I think the answer to that is yes. Most of the issues which David has talked about can be written about without getting into matters that are state secrets.

First of all, there are times that information is declassified or becomes available from other sources and doesn't need to be entered into in great detail. But to give you an example of something that I would argue you shouldn't be able to do, is in the run-up to the bin Laden raid that resulted in eliminating bin Laden, obviously, it was a compelling public story. And the fact that we were going to be invading another sovereign country and taking military and fatal action against an individual who had not been tried or convicted was a big issue. I think it was a good idea, but others might have disagreed. And yet had that been leaked in advance, had it gotten into the hands of the press, I would argued it would be quite appropriate for the government to say to David Sanger, “If you publish that, we will prosecute you, and perhaps we will even enjoin you from publishing it.”

### Moderator
Claim: But your answer to my question is yes, he can do his job--

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: I want to come back to David as a practical matter because you are the one who's practicing. Can you respond to what you just heard?

### Scientific Advocate (SA)
Claim: Well, certainly the bin Laden raid raises a very good question and is one in which The New York Times has been very clear throughout the time that we went through the WikiLeaks material. Long before that, we have said, as you can see from the examples I cited earlier, that we do not publish stories about operations. We don't name dissidents who walked into the Chinese embassy and talked to American diplomats. Where do we draw the line? Information that is merely embarrassing as opposed to operational. So the U.S. government, during the midst of the WikiLeaks operation, asked us to withhold the information that the king of Saudi Arabia said in response to a discussion with an American diplomat about Iran's nuclear program, "Cut off the head of the snake." Now, why did they consider this to be particularly sensitive? No one was going to go put the king of Saudi Arabia in jail the way a Chinese or Saudi dissident might be put in jail for saying the wrong thing.

They considered it sensitive because it would make it more difficult to conduct American foreign policy if the king read his own words in The New York Times or foreign publications. And so that's the distinction that I think is critical, the one between an operational secret and embarrassment. And there is no place in the law that makes that distinction.

### Moderator
Claim: Gabriel Schoenfeld.

### Conspiracy Advocate (CA)
Claim: Well, I find that curious. Operational secrets-- what is the Swift program? But an operational program to monitor the finances of al-Qaeda that the Times published against the strong protest not only of the Bush administration but leading Democrats like Lee Hamilton of the 9/11 Commission. And the Times justification for it was always quite murky. Eric Lichtblau, the reporter, one of the two reporters who wrote the story, said in his memoir about it, "It was, above all else, an interesting yarn." What was the public interest that was served there?

The Times-- the ombudsman of the Times, as Secretary Chertoff pointed out, disavowed the story. So did the general counsel of the Times. So I don't think that in the final analysis we can just have a system where editors make the-- make such decisions without being subject, vulnerable to prosecution, not necessarily prosecuted, for instance, but vulnerable to prosecution.

### Moderator
Claim: Before we get into the weeds on the specifics of the cases, and we will do that, I do want to stay with the question of if you had to work under that threat of prosecution, what would it do to your ability to work? And maybe your colleague, Alan Dershowitz, would like to take this one.

### Scientific Advocate (SA)
Claim: Well, I can tell you that the greatest forms of censorship that take place today are not censorship imposed by the government. It's self-censorship resulting from fear of prosecution. I see that all the time, or fear of libel, other kinds of defamation lawsuits. So clearly it has an impact. But I'm not one who thinks that free speech is free or that it comes without costs.

In fact, I think we've heard a very clever debaters' point here tonight from our opponents, namely that if we concede that there are any conceivable state secrets like the plan to kill Osama bin Laden, then we can see the proposition. That's absolutely not the case. The proposition is state secrets. And I submit that you've conceded our point by changing the debate from state secrets to-- and I quote Judge Chertoff-- to "Genuine state secrets." And you also used a modifier, "Real state secrets." The problem is it's just too broad. Now, there are going to be problems. And The New York Times is not the only game in town. Judge, you mentioned, how about the Hezbollah press? They might publish it. Do you think American law is going to stop the Hezbollah press from publishing anything? So that's just a red herring.

### Moderator
Claim: Okay, Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: But, see, I think this is the point. The point is-- and I don't think we have to argue that simply calling something a state secret ends the analysis. What's important is whether it's in The New York Times or Hezbollah press or somebody else.

If they are in an area where they are dealing with material that is classified and sensitive, they have to make a judgment. Now, there's a certain amount of uncertainty. And I understand that may have a chilling effect. But that chilling effect is what imposes a sense of responsibility. And let me say, everybody in the world who exercises power and authority, lives with the possibility that if they guess wrong, they're going to wind up in trouble, including, for example, CIA agents who find themselves being investigated, and yet nobody says they should be immune from the possibility of investigation.

### Scientific Advocate (SA)
Claim: I just think you're wrong empirically. I think you're wrong empirically. It's not the fact that people are guessing wrong. Seymour Hersh isn't guessing. He knows he's not being prosecuted because he's revealing a secret that you-- not you personally-- but somebody in the administration gave him on the sly. They say that, "We know it's classified, but please print this because it makes us look good. And if you print it, you won't be prosecuted." The end result is that people only feel chilled when they release secrets that make the administration look bad.

When they reveal secrets that make the administration look good, they are not going to be prosecuted. I'll give you an example. I'm a supporter of the Obama administration. I think they handled the post-Osama bin Laden killing miserably. What did they do? They revealed the fact that they got computers. That was a victory lap. Nobody should have ever known that they got computers. They revealed the fact that they got telephone numbers of two guys in Osama bin Laden's phone book. Nobody should have revealed that. Why did the Obama administration reveal that? They were proud of it. But they didn’t reveal the pictures. Why didn’t they reveal the pictures?--

### Moderator
Claim: --but I haven't heard-- let me just say for the record, Alan, I have not heard from your side a refutation of their claim that David can't do his job without threat of prosecution. And so I mean, that point stays hanging out there and I think leans to their favor. David? David?

### Scientific Advocate (SA)
Claim: Let me just make one quick point.

### Moderator
Claim: No. Let David come in. Please.

### Scientific Advocate (SA)
Claim: Can I do the job? Yes. Can I do the job the way all of you want me to do the job? Probably not.

And that's because, as you said, there is uncertainty in the system. There's always going to be uncertainty in this system. But the uncertainty can't extend to the point where we are stopping from publishing something that may be published, as Alan points out, outside the country. It may be available in another form, maybe at a U.N. agency, maybe among international nuclear inspectors, and also was classified in the United States. And we simply will not know. We cannot know what is classified. You have to assume that almost anything on a sensitive subject like this is classified in some way. And so we have to roll that dice every single day. And we're willing to take that risk not for us, but because there is a broader readership and citizenship out there--

### Moderator
Claim: But Michael said if you roll the dice, and you're wrong, there are no consequences for you.

### Scientific Advocate (SA)
Claim: That's not true.

### Moderator
Claim: Okay. Now-- why not?

### Scientific Advocate (SA)
Claim: That's not true.

### Moderator
Claim: Why not?

### Scientific Advocate (SA)
Claim: I mean, there-- you laid out very clearly what the laws are and what the penalties are.

Now, as you may also point out and Schoenfeld does in his book, there has not been a successful prosecution under the Espionage Act against reporters. There have been against their sources. And part of this is because I think the government recognizes that once you start down that road, it's very unclear where you draw the line.

### Moderator
Claim: Okay, Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: I think that illustrates my point, which is, in fact, the proposition is correct. Freedom of the press does give way before state secrets. And the reason that we can accept that proposition is because we have built a structure that actually is quite protective even within the terms of that proposition. The reason that there haven't been prosecutions of journalists is because people weigh what will happen in a courtroom with a judge and a jury. And so when you do your job in a close case, if you feel you're acting in good faith, you can have a reasonably high degree of confidence that if it doesn't wind up in a prosecution, you can go to court, and you're going to wind up prevailing in front of a judge and a jury.

### Scientific Advocate (SA)
Claim: And that's the worst possible result because what it says--

### Moderator
Claim: Alan Dershowitz.

### Scientific Advocate (SA)
Claim: --is if The New York Times, if you're Seymour Hersh, if you're Bob Woodward, you have nothing to worry about. But if you're Julian Assange, and you're not working under the supervision of the government, if you're not somebody who has a constant relationship with the government, you have plenty to worry about. It gives the government far too much discretion to go after people who reveal information that is not something they want revealed. And I think, frankly, you're asking the wrong question. Can he do the job? That's a terrible criteria under the First Amendment. We can change it and say, could we have literature without there being sex? Of course we can. We can have Shakespeare. But that's never been the criteria under the First Amendment. Can you do your job? That shifts the presumption and the burden to the press to justify that it can do its job. The answer is, is there a constraint, a lawful and-- constraint on the way the press does its job, and I think the answer to that is there's far too much discretion in the government to decide who to go after for leaking and who not to, and that's very dangerous.

### Conspiracy Advocate (CA)
Claim: And actually I think Alan--

### Moderator
Claim: Gabriel-- let's let Gabriel

### Conspiracy Advocate (CA)
Claim: It may be dangerous for leakers but it certainly-- the historical record is not one of danger for the press. There's never been a successful prosecution of journalists as David Sanger just noted. And the one case, I'm wondering what you think about it, that where there was-- a prosecution was initiated, The Chicago Tribune case in World War II where the government-- where The Chicago Tribune published a front page story strongly suggesting that we had broken the Japanese naval codes, a leak that could have cost the lives of tens of thousands of U.S. servicemen. Now, there are plenty of people, journalists who think that there shouldn't-- that there shouldn't have been a prosecution, but, I mean, that seems to me almost madness.

### Scientific Advocate (SA)
Claim: Well, first of all there have been many, many prosecutions not under that particular statute but you've heard about shouting "fire" in the crowded theater. Do you know what the facts were of that case?

There was a guy who was handing out leaflets in front of a draft board, telling people to consider whether or not they might have a constitutional right to be a conscientious objector. And Oliver Wendell Holmes, in the worst analogy ever constructed by the legal mind-- turned that into shouting fire in a crowded theater. The analogy was handing out a leaflet outside of a burning theater, saying, “Please don't go in there, it might be unsafe to you,” and he turns out to be wrong.

### Moderator
Claim: Gabriel Schoenfeld.

### Conspiracy Advocate (CA)
Claim: You’re changing the subject, we're talking here about a disclosure that could have cost the lives if tens of thousands of people, should the government go after a newspaper in a case like that or in a case like the Swift case where real-time operational intelligence is jeopardized about people who are trying to blow up our subways.

### Scientific Advocate (SA)
Claim: Well, you know--

### Moderator
Claim: Wait, let's-- David Sanger.

### Scientific Advocate (SA)
Claim: Let’s take Gabe’s question right on because these are decisions we have to make every day. During the run up to the Iraq War, the Bush administration said repeatedly that they had made no decision and had no plans to invade Iraq.

The New York Times discovered over the July 4th holiday in 2002 that there was a very detailed plan to invade Iraq. And it published that fact with just enough detail to make it clear that in fact the Bush administration had put together a plan, but not quite enough detail to actually tell Saddam Hussein what that plan looked like. Now, there were many in the Bush administration at that time who were calling for the prosecution of The New York Times. I think The New York Times served an enormously important public interest there by making it clear to the public that no matter what government officials were saying in public to them, in fact they had a plan based on what we now know was fairly loose evidence, to invade a foreign country.

### Conspiracy Advocate (CA)
Claim: But isn’t--

### Moderator
Claim: Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: But doesn't that actually illustrate the point we've been making, that the restrictions in place do allow a judgment to be made about whether something will cross the line or not because--

### Scientific Advocate (SA)
Claim: We sure didn't know that at the time.

### Conspiracy Advocate (CA)
Claim: Well, sure, you did because you were able to predict that you have-- you know what the track record of the law is, you know that if a decision is made to prosecute, you're going to have a jury and a judge and you'll be able to make an appeal to them, and all of those allow you some freedom of movement, but not absolute freedom of movement. The flipside of it is to go back to the bin Laden case and maybe The Times wouldn't have published it, but there might be other news organs that would, if a news organ had gotten a hold of the plan to put SEALs into Abbottabad and they had been able to consider publishing that without any fear of being prosecuted or being enjoined, with absolute impunity, would that be where we want to see the United States? I suggest if you go back to the very quote that Gabriel made earlier about the Constitution not being a suicide pact, giving that absolute protection would be devastating for the United States.

### Scientific Advocate (SA)
Claim: I think there's an answer to that.

### Moderator
Claim: Alan Dershowitz.

### Scientific Advocate (SA)
Claim: If a newspaper learned about the fact that the SEALs were preparing to attack bin Laden, then that attack should have been aborted. You haven't been keeping your secrets well enough. You can't depend on a newspaper's discretion to put the lives of brave American SEALs at risk. So if you find out that a newspaper has that report, you have to abort. Sometimes

### Moderator
Claim: Are you saying, Alan, that the newspaper would have a duty to print that

### Scientific Advocate (SA)
Claim: Well, let me give you a story. Jimmy Reston didn't print the story of the Bay of Pigs invasion because he wanted to protect Americans and Cubans. The Bay of Pigs Invasion was a disaster for America and a disaster for Cuban patriots.

### Moderator
Claim: And what did President Kennedy say to them later?

I wish you had printed it.

### Scientific Advocate (SA)
Claim: And if The Times had printed that, we might have averted a disaster. You don't know in advance. Look, the SEALs thing might have gone wrong.

### Conspiracy Advocate (CA)
Claim: By that logic--

### Moderator
Claim: Gabriel Schoenfeld.

### Conspiracy Advocate (CA)
Claim: And by that logic, Professor Dershowitz, The Times should have published, if it had known in advance, that we were about to make the raid on bin Laden.

### Moderator
Claim: If--

### Conspiracy Advocate (CA)
Claim: Because it could have gotten wrong. And then we would have to abort the operation?

### Scientific Advocate (SA)
Claim: If in fact The Times learned that it was a bad plan and that it was an illegal plan, and they decided to publish it, and we had to abort it, that would be a very, very good example of the interplay between--

### Conspiracy Advocate (CA)
Claim: No, it would be--

### Scientific Advocate (SA)
Claim: --the press and the executive.

### Conspiracy Advocate (CA)
Claim: --an example--

### Moderator
Claim: Michael Chertoff.

### Scientific Advocate (SA)
Claim: I don't think--

### Moderator
Claim: Alan, let Michael-- let Michael get to that point. Michael Chertoff. Thank you.

### Conspiracy Advocate (CA)
Claim: I think it would be an example of taking away from the three branches of government the authority to make decisions about securing the United States, which was, in many ways, the reason the Constitution was formed-- was to make this effective and to hand it over to the press. And not probably just The New York Times. It could be any organ of the press. And the last point I have to make on this is that the press is so concerned about the possibility of chilling because an injunction or prosecution for leaking national security secrets. If you take copyrighted material from another news organ, and you publish it without permission, you can be sued, you can be prosecuted.

### Scientific Advocate (SA)
Claim: Not for the ideas, only for the words.

### Conspiracy Advocate (CA)
Claim: Right. Exactly.

### Scientific Advocate (SA)
Claim: Okay. That's different.

### Conspiracy Advocate (CA)
Claim: Does that-- and that happens from time to time-- does that cause The Times to enter into a state of paralytic hysteria?

### Scientific Advocate (SA)
Claim: I think you're missing-- briefly, I think you're missing my point.

### Conspiracy Advocate (CA)
Claim: They live with that threat of being

### Scientific Advocate (SA)
Claim: My point about-- about the Osama bin Laden is that The Times had learned about it. That would mean there is a real possibility that others would know about it. And that's an important decision for the government to know about.

### Moderator
Claim: It's like the canary and the coal mine, I assume?

### Scientific Advocate (SA)
Claim: Right. Well, no. It's-- you know, the risk-- the government shouldn't let The New York Times find out about secrets like that.

### Moderator
Claim: We have

### Conspiracy Advocate (CA)
Claim: Let's talk about how this would actually have played out.

Hundreds of people are involved in a military operation like that.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Thousands of people are involved--

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: --in other secrets. 2.5 million Americans hold security clearances. Eight hundred thousand of them--

### Scientific Advocate (SA)
Claim: That's the problem.

### Conspiracy Advocate (CA)
Claim: --hold top secret clearances. With populations of that size, you're going to have people who disagree with the government, people who might be deranged, people who are going to leak secrets. We cannot--

### Scientific Advocate (SA)
Claim: How many people do you think knew about the Osama bin Laden raid?

### Moderator
Claim: Let's go back to the--

### Moderator
Claim: All right.

All right, David Sanger. David Sanger, New York Times.

### Scientific Advocate (SA)
Claim: Dozens-- maybe hundreds knew about it. It didn't leak, and I'm very glad that it didn't. And The New York Times didn't have to make that decision.

### Moderator
Claim: Right.

### Scientific Advocate (SA)
Claim: How would this have played out in real life? I suspect with The New York Times, for all the reasons I've laid out before, would not have published that fact. But when the phone call was made to the White House to say, “We have heard this,” my guess is that what would have played out is exactly what Alan suggested. The operation probably would have been aborted, just for the fact that we made that phone call. And that tells you a little bit about how the system works in reality.

### Conspiracy Advocate (CA)
Claim: Well, you're surely not going to argue, David, that the purpose of giving the press immunity is to allow them to play a kind of red teaming on government operations.

### Scientific Advocate (SA)
Claim: Certainly not.

### Conspiracy Advocate (CA)
Claim: Because for example, with Swift, Swift was working perfectly well until we

### Moderator
Claim: Michael, just two sentences reminding people of what Swift was.

### Conspiracy Advocate (CA)
Claim: Swift was the program that allowed the U.S. government to track the flow of money to terrorists on a global basis, which was exactly what the 9/11 Commission recommended. And it was a very useful and important program. And it wasn't failing. And the revelation of the program ultimately led to it becoming much less effective.

### Moderator
Claim: And there-- were there issues of illegality of any kind?

### Conspiracy Advocate (CA)
Claim: And no issues of illegalities, The Times itself conceded. So there was a minimal public interest. This wasn't exposing criminality. What about the plans for weaponizing anthrax or for coming up with biological weapons? Would you take the argument that if we publicize those plans, that shows that the information is out there, therefore let's disseminate it widely so people can begin to cook up bacterial anthrax in their garage? I think the logic in this refutes itself.

### Moderator
Claim: Okay. Wait, we have to take a break. And when we come back, we'll take questions from the audience. Welcome back. We're an Intelligence Squared debate from-- let me do that again.

Can you give me another round of applause, because I-- We're back to this Intelligence Squared U.S. Debate. I'm John Donvan of ABC News. Our motion is “Freedom of the press does not extend to state secrets.” Debating for the motion, in support of the motion, Gabriel Schoenfeld and Michael Chertoff. Against, Alan Dershowitz and David Sanger. And I'd like now to go to our audience to ask questions that will move this debate along on the topic itself, which once again is “Freedom of the press does not extend to state secrets.” And if you just raise your hand, there's a woman in a black dress? If you can hold it about that-- that's perfect. Thank you.

### Moderator
Claim: So, is the against side saying that the press should never be prosecuted for any publishing of state secrets-- any state secrets? Is that the position?

### Moderator
Claim: That was a question the question, yes. David Sanger.

### Scientific Advocate (SA)
Claim: As a reporter, I would hope-- I would hope the prosecution wouldn't happen.

But the reality is that you have to establish a system in which the secrets that America is protecting are real secrets, like the bin Laden example that we were using before. But instead, we live in a system in which there are millions of pages classified each and every day. And you can't have a press that is living forever in the fear that the publication of any piece of data could lead to an equivalent prosecutorial discretion on this issue. And so if you're going to truly not devalue the point of the realm, if you're going to say there are some things that the United States really needs to protect, it's got to be a very, very narrow list. And that is not where the U.S. government is going. In fact, the amount of classified data expands dramatically every single year.

### Moderator
Claim: Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: Well, I think the answer to the question then was, essentially as the question you're asked, you can see that there obviously are occasions when the press should be prosecuted for publication.

### Scientific Advocate (SA)
Claim: For publication of--

### Conspiracy Advocate (CA)
Claim: Of state secrets. And the issue then becomes--

### Scientific Advocate (SA)
Claim: Or some state secrets.

### Conspiracy Advocate (CA)
Claim: And the argument that David makes is, but the problem is it's too hard because there's too much classified material. And yet the facts show that when it comes time to make the decision to prosecute, government historically, whether it be Republicans or Democrats, have been very, very conservative and cautious in actually prosecuting. And that tells me the system works, that in fact the government doesn't overreach on prosecution and that it is possible to have a workable system where people who are responsible journalists know where they can't go, like the bin Laden case, and the irresponsible ones, dare I say Assange, may find themselves in a different--

### Scientific Advocate (SA)
Claim: And who decides who's responsible and irresponsible on the basis of what criteria?

The issue is whether or not somebody should be punished for publishing state secrets. The answer to that is clearly no, not for publishing state secrets. If you want to have a list of things that can be published, that's a very different criteria. You yourself conceded all three branches of government have to be involved. At the moment, the legislative branch hasn't been involved. They have punted. They have simply said, broadly defined state secrets, the Espionage Act. That has to be scrapped. And if you want to have six, nine, four specific categories of things that can't be published, that's an interesting debate, and I think both of us would acknowledge. But not to punish people for violating state secrets - -

### Moderator
Claim: Gabriel Schoenfeld.

### Scientific Advocate (SA)
Claim: --that sounds like other countries which have--

### Moderator
Claim: Come in, Gabriel.

### Conspiracy Advocate (CA)
Claim: The legislature-- the legislature has not punted. We do have highly specific laws on the books. The direct question was put to you, Mr. Sanger, would you prosecute-- should the press be prosecuted when it violates those sanctions, when it violates those particular statutes?

If the press publishes, for example, the identities of an intelligence agent, CIA agent, do you believe that the press should be prosecuted? If the press publishes designs of nuclear weapons, as the Progressives tried to do in 1979, is there a basis for prosecution?

### Scientific Advocate (SA)
Claim: There may well be a basis for prosecution. But the judgment for doing that runs a much greater risk, which is the chilling effect risk. And there are certainly a very limited number of things for which I could imagine why the U.S. government would get in and truly seek to prosecute. The fact that they haven't tells you that they seem to know already that this is an unsustainable legal regime for the very reasons that Alan has laid out, that there is nothing in the law that distinguishes between that very narrow group of true state secrets which we can all put a list together and probably the list you could count on both hands.

And that vast majority of material that is covered under those very laws you described.

### Scientific Advocate (SA)
Claim: Can I ask a question of you? Would you be prepared to abolish the Espionage Act of 1917 with its broad characterizations and just limit prosecution to those particular statutes that you talked about, naming spies, naming intelligence? Then we have an interesting debate. The problem is the current statutory criterias, the worst of all possible worlds, it gives enormous discretion, and it gives the very government whose secrets are being released, the discretion and the power to decide not to go after The New York Times, they like them--

### Moderator
Claim: Michael Chertoff, do you want to answer the question?

### Moderator
Claim: --but to go after Assange, they don't like him.

### Conspiracy Advocate (CA)
Claim: Again, I mean, I hate to say it. I think that gives the whole game away. So if we agreed that the Identities Protection Act, if we agree the Communications and Cryptographic Act which are very specific--

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: --that those appropriate, that prosecutions are appropriate.

Then I think you've conceded that in fact state secrets ought to be sufficient to make the - -

### Moderator
Claim: Let's go to another question from the audience. Right in the center there. Yep. We did that. That's you.

### Moderator
Claim: Is the for side basically saying that the statement is correct that needs a big caveat of a wise judiciary system?

### Conspiracy Advocate (CA)
Claim: No. I think what the for side is saying is that the statement is correct in the context of the government system in which we operate. That's why saying, well, you know, this is-- we don't want to become like Egypt or Russia, that's not the context in which the proposition is offered. The proposition is offered in the context of our current system of government in which part of the protection for the press is not just, quote, "Freedom of the press in the First Amendment." But it is the structure of government that says if you actually want to take the step of prosecution, you've got to have an executive decision to prosecute.

You've got to judge who will consider Alan Dershowitz's arguments about whether the law is properly written, and you'll have a jury of 12 people like you who will make the final decision. And in that context the proposition, I think, makes the unassailable point that freedom of the press has to be balanced against and in some instances give way to state secrets.

### Scientific Advocate (SA)
Claim: And the worst possible solution is to give--

### Moderator
Claim: Alan Dershowitz.

### Scientific Advocate (SA)
Claim: --the very same government that is being offended the power to make that decision. And if you think you can count on juries, just remember how juries operated during the McCarthy period. Remember how juries operate during times of crisis. The First Amendment was built to protect the most unpopular, the most hated during the worst periods of our history. And discretion is not going to serve that protection.

### Moderator
Claim: Gabriel Schoenfeld.

### Scientific Advocate (SA)
Claim: --solid laws. We need-- let me give you the--

### Moderator
Claim: No, no, no. Let-- no, no. Gabriel-- Gabriel Schoenfeld.

Gabriel Schoenfeld, please. Thank you.

### Conspiracy Advocate (CA)
Claim: I have the microphone. I have the microphone.

Even if we take your suggestion, and scrap the Espionage Act, which I would have trouble trusting the current Congress to do a better job than the one that wrote it in 1917--

### Scientific Advocate (SA)
Claim: They couldn't do a worse job.

### Conspiracy Advocate (CA)
Claim: But even if we did that, and we had a new set of laws that somehow managed to enumerate the very complex set of things that have to be protected. It's not just a little list of six, by the way. You still-- if you had new laws, you'd still have juries, and you'd still have prosecutors using their discretion. That's built into our system. It's not a perfect system. Name a better one.

### Scientific Advocate (SA)
Claim: Let me tell you. Let me name a better one. We should have a rule that says you cannot, under any circumstances, publish the name of spies. And if The New York Times does it, they must be prosecuted. If WikiLeaks does it, they must be prosecuted. No room for discretion.

### Moderator
Claim: David, do you want those rules?

### Scientific Advocate (SA)
Claim: No prosecutorial discretion, period.

### Moderator
Claim: David Sanger, do you want those sorts of rules?

### Scientific Advocate (SA)
Claim: I'm sorry?

### Moderator
Claim: Would you want those sorts of rules spelled out so clearly?

### Scientific Advocate (SA)
Claim: I wouldn’t be happy with specific rules because I know that as situations evolve, you're going to discover that that list is going to leave both sides unsatisfied.

That's why we're dealing with an Espionage Act that was written in 1917 that we don't think fits the modern world. But it would certainly be better to have a very narrow list like that than what we are living with today. Because what we're living with today would allow the government of the United States under extreme circumstances, and I'm not saying it would happen in the current political environment, but you've got to think when you do this about a political environment into the future, in which they could prosecute for almost anything that you read in the national security coverage pages of The New York Times in each and every day. And when the law is written that broadly, it simply becomes devalued over time.

### Moderator
Claim: But as you have said, the government tends not to prosecute.

### Scientific Advocate (SA)
Claim: Fortunately, the government so far does tend not to prosecute. So you cannot-- you can't count on that, and that's--

### Conspiracy Advocate (CA)
Claim: It's a very high hurdle. It's a very high hurdle prosecuting a journalist under the Espionage Act.

And they have to show bad faith on the part of the journalist, intent to injure the United States.

### Moderator
Claim: No, no, no, no.

### Conspiracy Advocate (CA)
Claim: That's-- wait. Let me, let me finish. But I want to just return back to this question of the raid on Osama bin Laden. Which you say the Times would not have printed if it had known in advance, would not have wanted to jeopardize that example that the American forces. But just a few minutes before that, you were saying you were applauding the fact that the Times should have published in advance the Bay of Pigs operation. Which is it?

### Scientific Advocate (SA)
Claim: It's a very-- a very basic answer to that question. The Times did not publish the Bay of Pigs operation. And what happened was the president of the United States turned around later on and said, “Gee, I wish you would have.” The Times has not published many other operational cases like that. Is that always a good judgment? Not necessarily. The--The problem that we're dealing with here is that mistakes are going to be made on both sides, and the question is where do we want the law to weigh the errors? And the answer to my mind is we want to err on the side of disclosure. That's what the First Amendment is all about.

### Moderator
Claim: You don't want to err on the side of

### Moderator
Claim: --if you could stand up just--

Yeah, right there, that's right, thank you.

### Moderator
Claim: It seems to me that part of this argument is coming down to sort of, you know, if there is discretion, then there almost inevitably will be discrimination, sort of if there is discretion then it's hard to say even what the law is. I'm confused by this sort of hard line rule that you guys seem to be going over, this idea that disclosing the name of CIA agents is somehow maybe something that should be absolutely prohibited. But should it be prohibited even when the name is revealed by an employee of the White House? You know-- And on to Dershowitz, I'm sorry, I don't think the rule could be that firm, but on the other hand then there's this question of what is a secret?

After a White House employee has leaked the secret, is it still a secret? You said that--

### Moderator
Claim: Okay, all right, Michael Chertoff, that's a great question actually--

### Conspiracy Advocate (CA)
Claim: And I think that illustrates exactly why I think the current system works not perfectly but as well as you can have in human existence. The current system as you point out in the question recognizes that there's never an absolute. There are probably some times that you could reveal the identity of an agent when it's out there already, and you could argue that there's really no impact. There are other times when you're reviewing other kinds of information that would be terribly devastating or damaging, again, recipes for certain kinds of weapons or for the revelation of certain kinds of operational plans. And the key is in all of these situations what we do is we have a system for resolving a prosecution because we involve people like sitting in this room and 12 jurors in the box, and that is the protection that we have that in the end the law will be applied reasonably and a reasonable application of the law is the best defense.

A rigid application is one which is likely to wind up with exactly the kind of conundrum

### Scientific Advocate (SA)
Claim: --Well, here we really have a difference because I think you need

### Moderator
Claim: Alan Dershowitz.

### Scientific Advocate (SA)
Claim: --rigid application when it comes to the First Amendment. The First Amendment says, no, juries don't get to decide that because juries and the people like to ban things when they’re very, very unpopular. The Constitution prohibits that, just like the Constitution prohibits discrimination against the most absurd of all religions. And we can't have that kind of discretion. The rule has to be items can't be published, the names, that might be too broad or too narrow, if The Times publishes it, they can be prosecuted. If the White House publishes it, they can be prosecuted. And if WikiLeaks publishes it, they can be prosecuted. The same law has to apply to all. You're saying nobody is in danger because there is no prosecution. There is currently in Virginia a grand jury investigation directed against WikiLeaks and directed against Assange, not against The New York Times.

### Conspiracy Advocate (CA)
Claim: But isn't that a great example--

### Scientific Advocate (SA)
Claim: And the defense is going to be essentially--

### Conspiracy Advocate (CA)
Claim: Isn't that a great--

### Scientific Advocate (SA)
Claim: The Times published this, too. You're not going after them. Oh, no, you don’t go after The Times, we go after WikiLeaks because they don’t have the power--

### Moderator
Claim: Okay, Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: Alan, isn't that a great example-- I didn't want to bring up the WikiLeaks, but since you have I will.

### Scientific Advocate (SA)
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: Isn't that a great example of the fact that attributing ill motive to juries or to prosecutors or to the government omits the fact that there can be ill motive on the publisher? In the case of Assange, it's reported that his purpose in leaking the information as he told his associates is because he wants to make it impossible for the U.S. government to function by making it impossible for secrets to be held, so that people can’t have conversations. So he's motivated by ill will to the United States. Now, is this the man we want to trust if God forbid he got a hold of the bin Laden attack plan, do we want to trust him to exercise his judgment?

### Scientific Advocate (SA)
Claim: And do we want to trust--

### Conspiracy Advocate (CA)
Claim: Or would we rather trust people like those in this room?

### Scientific Advocate (SA)
Claim: No, do we want to prosecute-- or do we want to trust the prosecutor who misstates what Assange said and what his motive was, because he doesn't like Assange? "Assange, I don't like, we're going to go after him. Times I like, we're going to go after him." If you leave this to motive analysis, do we know what the motive of The New York Times is? Is it to sell advertising? Is it to be powerful? Is it to help the government? A motive analysis, to be limiting freedom of the press would mean the end of the First Amendment.

### Moderator
Claim: Okay, we're going to take a break. Our motion is "Freedom of the press does not extend to state secrets." We'll be back with this Intelligence Squared U.S. Debate in just a moment. Okay, we are back. Our motion is "Freedom of the press does not extend to state secrets." I jumped the gun. We are back at this Intelligence Squared U.S. debate. Our motion is "Freedom of the press does not extend to state secrets." We're taking questions from the audience. Sir, could you stand? Thanks.

### Moderator
Claim: Sure. First of all, thank you very much for being here. Obviously this is not a debate of absolutes-- it seems that the point of discretion keeps coming up over and over again.

So, framing the debate in discretion is a question of who do you really trust? When there can be abuses on both sides, who has the most information to make that decision? The press is a very broad category, ranging from very established newspapers to bloggers. So with all possibilities of abuse with government-- cover-ups, perhaps, or misinformation and trouble with information flow-- who has the most information to make the decision and where is the greater risk? As much as I love the First Amendment, I’d like to pose the question.

### Moderator
Claim: David Sanger.

### Conspiracy Advocate (CA)
Claim: Well, I think--

### Moderator
Claim: Michael, let me let David take that first--

### Conspiracy Advocate (CA)
Claim: Oh, sorry.

### Moderator
Claim: --and then I'll come to you.

### Scientific Advocate (SA)
Claim: Clearly, as any government official will happily tell you, they've got a wider range of information than the newspapers do. The reporter may be looking at a single document. WikiLeaks was the great exception-- it was 250,000 documents and four million words - - but usually, leaks are in dribs and drabs.

And the government would make the argument that they are in a much better position to judge. That would be a very convincing argument, if in fact, the government, when doing its classification, had to do in a serious, credible way, a measure between security risk and public's right to know. But the fact of the matter is-- as someone in the CIA said to me just last week-- no one ever got fired for stamping “classified” on a piece of paper.

### Conspiracy Advocate (CA)
Claim: You know--

### Moderator
Claim: Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: --I would say the question you're-- I'd like to actually suggest you come up and-- he's done a very good job of succinctly stating, I think the case for the proposition. In the end, there is going to be mistake and error and potentially ill will on both sides. What Dave is arguing is that because the initial process of classifying is less than perfect and can be overbroad, that means that we have to throw the whole system out and the press has to have, essentially, free run.

My argument is that instead of looking at only one part of the process, let's look at the whole process. If we come to the point of a prosecution, it's not just going to be the person who classified who is going to be part of that decision. It's not just going to be the prosecutor. In the end, it's going to have to be presented to a judge and a jury. There will be multiple of layers who have the opportunity to bring their judgment to bear on whether the decision to publish was right or violated the law. And that to me is the greatest protection of all. And-- because I have faith in the public and the courts and the entire process, I would rather trust that than Julian Assange to make that decision.

### Moderator
Claim: Another question from the audience. I'll let you take this one, Al. Sir, yeah. You just did that. Thanks. Yes. That's right.

### Moderator
Claim: I must say, the remark you made about if the press had got to know about the bin Laden, they could have the decision whether it was a good plan or bad plan, and then published it---- and then they would have to abandon the whole plan, I found that a little bit frightening, because like was made obvious just now, who has more information about that plan? I would think it was more--

### Moderator
Claim: But, sir, what would be your question to this

### Moderator
Claim: The question I--

### Moderator
Claim: Why are they wrong?

### Moderator
Claim: Yeah.

The question I wanted to ask is is this not more about-- not just state secrets but state security that we entrust the press with? When you hear-- when you read statements in the press about how vulnerable the New York underground is to terrorism, how vulnerable our water supplies are, do you not think that you're giving away--

### Moderator
Claim: Are you saying this discussion in the press is making the world more dangerous for us?

### Moderator
Claim: Yes.

### Moderator
Claim: Is that your question?

### Moderator
Claim: Definitely.

### Moderator
Claim: That’s the question. I'll let David take it, then you.

No, actually I told you you'd go next. Alan Dershowitz.

### Scientific Advocate (SA)
Claim: Well, I want to know if our water supply is vulnerable. I want to know if our infrastructure is vulnerable. I suspect there are enemies who already know that, and the issue about-- I think there's a lot of misunderstanding about what I said about the bin Laden raid-- I supported the bin Laden raid. I think it was legal. I think it was legitimate. I think we did a good job. I think we did a terrible job right after it in what information we revealed and what information we withheld. My only point was, if the United States government can't keep a secret like that, and if The New York Times learns about it, or Hezbollah learns about it, the press learns about it-- we have to really, seriously think about whether this is an operation you want to have go forward. What worries me most is the attitude I've heard from some of the questions-- the government knows more than we know. We, the government, know better. You hear that from every tyrannical regime in the world. The government knows better. We live in a system where the government has to be checked by the press, where the press is checked by the government, where we have confusion, uncertainty, we have no ability to really know in advance how it will come out.

We don't know whether it would be a good thing or a bad thing. In retrospect, it was a good thing that bin Laden was killed and that the press didn't reveal it. It might have come out differently. We don't know. What we need are rules. And the rules that we have now--

### Moderator
Claim: David-- Alan, you have made that point, and I want to get to what this man's question was to David. Does this sort of thing make the world more dangerous for us? This discussion-- he was talking more broadly about security. Everybody might figure out that the subways are vulnerable.

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: But he's asking, I think, whether the broad discussion and the divulging of secrets makes the world more dangerous.

### Scientific Advocate (SA)
Claim: And my answer to that would be, in many cases, it makes the world significantly safer, because the government is feeling some pressure, the U.S. government, to take a system that they may not have focused on entirely well and actually make it better. Let me give you an example that comes right from Mr. Chertoff's time when he was at Homeland Security.

President Bush would frequently laud the fact that imports into the United States go through nuclear detectors that were put at every port. And everyone knew, including many of the importers, that these nuclear detectors did not deal well with anything that was shielded. In other words, you could put through a lot of different material through the port of Los Angeles, and these detectors were frequently set off by kitchen tables, by Chinese toilets. Nuclear weapons, that was another issue. Now, at some point, many newspapers got around to writing about that. Did we put the United States at greater danger? No. I think in fact what we did was prod the U.S. government to move faster with the technology it needed to go get in place.

### Moderator
Claim: Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: But actually, that illustrates my point because factually, David, what actually happened was I testified about the fact that these were--

### Scientific Advocate (SA)
Claim: Eventually, you did, yes.

### Conspiracy Advocate (CA)
Claim: Not eventually, up front. And that's the point, to answer the question.

The government often itself will reveal, in a general sense, what the limitations are. In the case of these devices, it was that shielded material could not be detected. You had to add an additional device. Where I think there is a greater danger is if you get to a certain level of specificity. For example, if you want to talk about general vulnerability in the New York subway system, you can argue that that's not harmful. It's even helpful. If you want to say there's a particular location where a bomb would cause a crippling devastating blow to the operation of the system, that, I think, would make us unsafe, and that should be a state secret. And that's really what we're arguing for with this proposition.

### Conspiracy Advocate (CA)
Claim: And we should add that--

### Moderator
Claim: Gabriel Schoenfeld.

### Conspiracy Advocate (CA)
Claim: --the other side has not really addressed this whole very striking example of the Swift program, where the Times revealed an ongoing operational intelligence-gathering program directed at al-Qaeda's finances.

And it's true that the treasury secretary had mentioned that, in general terms, we were tracking their finances. But it certainly, until that story appeared in--

### Moderator
Claim: So you put this out three times. One chance to respond.

### Moderator
Claim: Absolutely.

### Moderator
Claim: Do you want to respond, was the Times wrong to report on the Swift program? Was anything gained from public interest?

### Scientific Advocate (SA)
Claim: The Times was not wrong to report on it because the Swift program had been written about in many forms over many years before and after al-Qaeda became a significant source and issue. That is the only way international transactions flow and get cleared. And it was obvious to anybody who had read anything in any detail about how international transactions are going that that's where they go through.

### Scientific Advocate (SA)
Claim: But let's assume for a moment--

### Moderator
Claim: Alan Dershowitz.

### Scientific Advocate (SA)
Claim: --that the Times was wrong. You didn't prosecute the Times. You don't have the guts to prosecute the Times. You will never prosecute the Times.

### Conspiracy Advocate (CA)
Claim: I actually do.

### Scientific Advocate (SA)
Claim: You were a bunch of bullies. You would go after--

### Moderator
Claim: You said you agree with that, Mike?

### Scientific Advocate (SA)
Claim: --only the weakest and the most vulnerable.

### Conspiracy Advocate (CA)
Claim: No, actually, I--

### Scientific Advocate (SA)
Claim: The First Amendment is not about The New York Times.

The First Amendment is about Drudge. The First Amendment is about extremist newspapers and magazines that are very unpopular. The First Amendment is about people who could never win a case in front of a jury. That's who the First Amendment's about. I don't worry about The New York Times. They can defend themselves. They knock down trees by the forest fulls. Governments don't go after--

### Moderator
Claim: All right. A couple more questions.

### Scientific Advocate (SA)
Claim: --newspapers like The New York Times.

### Moderator
Claim: Sir, if you can come-- you're in the first row without light. If you could come down to the steps, I'll take you second. You're wearing a white shirt, just so that you could come into where the TV lights can see you. Anybody on this side in the meantime? Yeah? You were half-hearted. I want somebody full-hearted. All right. Why don't you just-- can they-- can the camera catch that? You're good? Yeah. Okay, go ahead, sir.

### Moderator
Claim: Since we all have to vote at the end of this, I really want to come back to the specific language in the motion and how I should be interpreting this because I want both sides to really argue for the votes of those of us who believe that some states-- the freedom of the press does not extend to some state secrets.

So it seems to me that the side for is interpreting this to mean freedom of the press does not extend to some state secrets, and the other side is interpreting it to mean that all state secrets and is disagreeing with it. So which way is it?

### Conspiracy Advocate (CA)
Claim: Well, I-- as the proponents--

### Moderator
Claim: Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: --I think we say-- it does not say all state secrets. It says some state secrets. Or state secrets. You're right.

### Moderator
Claim: I'm looking for the word "some" there.

### Conspiracy Advocate (CA)
Claim: I'm sorry. I misspoke. But let me explain what I mean. We don't, as I said up front, we don't argue that everything that the government does is a state secret. We argue that some things are state secrets and that the reason the freedom of press has to give way is because there is a process for adjudicating what is state secrets that works, a process that requires, before there is punishment, that you go through a decision to prosecute, a judge winds up weighing in on it, and a jury winds up resolving it.

And that under that circumstance, existing set of laws that do inhibit freedom of the press for state secrets work and ought to be kept. I believe my adversaries are arguing the existing set of laws are too discretionary, and we ought to have a recipe list, and only things in the recipe list ought to be prosecuted.

### Moderator
Claim: So did that help you with your vote?

### Moderator
Claim: Okay. But they were agreeing with Michael.

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: Okay. Go ahead, Alan.

### Moderator
Claim: Alan, go ahead.

### Scientific Advocate (SA)
Claim: Well, no, I think-- I think the motion puts the burden on the proponents of the motion to justify the censorship of state secrets based on the term and the criteria "state secrets." We are opposed to that. We concede that there are certain pieces of information that if properly legislated, and if discretion is reduced, and if anybody publishes them, they should be prosecuted. We concede that.

But the broad criteria of state secrets, as reflected by the Espionage Act of 1917, is far too discretionary and far too broad. And the basic issue is, should there be a presumption in favor of publication? That's our position. Should there be a presumption against publication, that's their position.

### Moderator
Claim: David Sanger.

### Scientific Advocate (SA)
Claim: You know, I think the WikiLeaks trove goes a long way toward answering your question. Everything in the trove that was downloaded and released and would have appeared around the world, even if The New York Times and no other American newspaper touched it, because it wasn't being published in the United States initially, every one of those documents was marked "secret," 250,000 documents. And what did the second of defense, Robert Gates, say about the damage done from their revelation? Well, he said, it was a bit overblown. Was there damage? Sure. There have been several U.S. ambassadors who've had to be recalled. There's been a lot of embarrassment all around.

But the state has survived six months later. And we learned a lot about American diplomacy along the way that was pretty important, including some things that Julian Assange did not want the United States to conclude, including the fact that our diplomats write pretty nicely.

### Moderator
Claim: That cost was-- but that price was worth paying.

### Scientific Advocate (SA)
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: I wouldn't have come here to participate in a debate arguing for the proposition--

### Moderator
Claim: Gabriel Schoenfeld.

### Conspiracy Advocate (CA)
Claim: --that we should prosecute any, all state secrets. That would be an absurdity. I agree with our opponents here that the government wildly over-classifies and misclassifies, and that's a chronic problem. It's a problem that's not going to be reformed any time soon. But it means that there are categories of genuine secrets. That what we're talking about here. And what's ultimately at stake is that we live in a regime in which, in the final analysis, it's the democratic system, our Congress, the executive branch and the courts that get to decide which secrets are protected.

### Moderator
Claim: One more question. Sir, right in the front.

### Moderator
Claim: As someone who has actually published state secrets and been taken to court for it, I would like to-- and for purely political reasons, I find all of this, four guys dancing around the head of a pin. Michael Chertoff came closest when he said that some state secrets are worthy of protection, and others are not. And the question is really among you, who should decide that.

### Moderator
Claim: And I think you actually all agree that this is a debate about who should decide.

### Moderator
Claim: I think that's right.

### Conspiracy Advocate (CA)
Claim: The question is-- the question has been decided by our Congress, which has created a set of statutes, the Espionage Act and the other statutes I have mentioned, the Atomic Energy Act. And then the executive branch gets to carry out, enforce those statutes. And we live in a very liberal regime.

In our whole history we've never had a successful prosecution of a journalist, and only one attempted prosecution. So I don't think there's much of a chilling effect, but the basic principle is in place. Freedom of the press does not extend to state secrets because the government has the final word; the jury has the final word.

### Scientific Advocate (SA)
Claim: Thomas Jefferson once said, "The law should be so crystal clear that you should be able to understand it if you read it while running." And there is nothing vaguer than the Espionage Act of 1917. It gives the government total power to decide who to prosecute. Thus far, they have exercised their discretion during peacetime relatively well, during wartime very, very poorly, and the risks of greater prosecution during times of increasing crisis increase. We need to have rules of law, not counting on the discretion of prosecutors, the discretion of juries to protect our First Amendment. It's just too valuable.

### Conspiracy Advocate (CA)
Claim: If we want to have a debate about the Espionage Act, I would think we'd probably be in agreement.

It's a very vague act. It's

### Scientific Advocate (SA)
Claim: So would you favor its abolition? Would you favor its abolition?

### Conspiracy Advocate (CA)
Claim: --its reform. But I don't feel-- but I think it's very difficult to reform--

### Moderator
Claim: Very quickly.

### Conspiracy Advocate (CA)
Claim: --but I favor the basic principle.

### Moderator
Claim: Very quickly for Michael Chertoff.

### Conspiracy Advocate (CA)
Claim: I do think the questioner absolutely put the question that really is dividing us, which is who decides? And I would argue and I think our proposition will be at the end of today that it is the combination of Congress having passed the law, the executive branch making its decision to prosecute, and the judge and the jury, you people, deciding whether to convict or not. That's where the ultimate decision has to be made, not in WikiLeaks or in Julian Assange's living room.

## Round 3

### Moderator
Claim: And that concludes round two of this debate. Here's where we are. We are about to hear brief closing statements from each debater. They will be two minutes each. And remember how you voted before the debate because we'll be asking you right after these closing statements to vote again, and the team that has changed the most minds will be declared our winner.

On to round three, closing statements, our motion is "Freedom of the press does not extend to state secrets." And here to summarize his position against the motion, David Sanger, Chief Washington Correspondent for The New York Times.

### Scientific Advocate (SA)
Claim: Thank you, John, and thanks to all of you. This has been a really interesting discussion that I think has revealed in our discussion of the ambiguity of the current law why a statement as broad as freedom of the press does not extend to state secrets can't stand simply because we cannot really define terribly well what is a true state secret worth protecting. In 29 years as a reporter, I've learned that on two things we almost always get it wrong. Whenever something has been leaked to me and I read stories later on about who the leaker was, it's almost invariably wrong, which tells you people get the motivations wrong. But the second thing is my own estimate about what the effects are of publishing a given story is also almost always wrong.

It's very difficult as you go in and write something to know whether or not it is actually going to have a very deleterious effect. And that's why we have ended up focusing on the narrowest questions, the obvious, the easy ones, the names of CIA agents, operations that are about to be conducted. Those are the easy questions. The hard question is what do you do to make sure that the press in the United States can force the government to debate policy on the most important questions, whether or not we invade a country and have the right evidence to go do so, whether or not we use a new weapon, whether it is a nuclear weapon in 1945 or a cyber weapon in 2011, and think out ahead what the effects could be once we legitimize that form of war.

You cannot do that unless you have a bias in favor of publication, not just a bias among all of us, but a legal bias in favor of publication, one that will make sure that the republic holds together because we have made ourselves different by pressing for publication whenever there is doubt.

### Moderator
Claim: Thank you, David Sanger. Our motion is "Freedom of the press does not extend to state secrets." And, Gabriel, I just want to ask you a very brief question. Did I mispronounce your name at the very beginning of the debate because I thought I saw-- I got a look from you as I said it. Okay, I just-- I was going to correct it for the record at this point. Okay. Let me introduce you on this one now. Laughter dies down. And here to summarize his position for the motion, Gabriel Schoenfeld, author of "Necessary Secrets: National Security, the Media, and the Rule of Law.”

### Conspiracy Advocate (CA)
Claim: I agree with David Sanger on this last point, that we should have a system that has a bias in favor of publication-- including a legal bias-- and I think that's the system we have and the very vagueness of the Espionage Act actually has helped the press and created-- helped us create a free press, the freest press in the world. And I think there's room for reform, but our government leaks like a sieve, and the press publishes secrets all the time. But I'm just reminded of an episode that occurred in late 2009, when a New York Times reporter-- one of your colleagues, David Rohde, was kidnapped by the Taliban. And Bill Keller, the executive editor of the paper, made the executive decision to withhold that information from the public. And not only did The Times not cover it, but he got all of his industry competitors and all of the Internet to agree not to reveal that David Rohde had been kidnapped. And the idea was he didn't want to do anything that would endanger Rohde's life.

And of course, that was a speculative decision, because really, publishing information about Rohde-- the fact that he had been captured-- the Taliban knew he'd been captured. But they withheld the story. And I say to Bill Keller, “All honor to Bill Keller for that!” They protected the life of their guy. But when the decision involves non-journalists, it can't be. When it involves us. The people who ride the subway in New York. It can't be a voluntary decision up to Bill Keller. We-- and that's why we have laws on the books that in the final analysis, do allow for the prosecution of the journalists when they publish not just the random things that are stamped “secret” for no good reason, but the genuine, really hardcore secrets that place our lives in danger, including some of the things that your newspaper has published-- like the SWIFT story, once again.

### Moderator
Claim: Thank you. Gabriel Schoenfeld.

Our motion is “Freedom of the press does not extend to state secrets.”And here to summarize his position against the motion, Alan Dershowitz, the Felix Frankfurter professor of law at Harvard.

### Scientific Advocate (SA)
Claim: The proposition “Freedom of the press does not extend to state secrets” is far more dangerous than any of the state secrets that have allegedly been leaked during the 200 and some years of our republic. This is an extraordinarily dangerous proposition, saying that freedom of press doesn't extend to state secrets. That's where the other side has to add “genuine,” or “real,” or “some.” And I urge you to vote against this proposition, because if this proposition is passed, it sends an extremely dangerous message to the government-- that it continue business as usual. And the current situation is very clear. Anything that's published relating to national security today could be subject to prosecution. Why aren't they prosecuted? Because the government-- the very government whose secrets are leaked-- makes the discretionary decision not to prosecute.

That is the wrong body to trust to make the decision, whether to prosecute. What we need is specific, focused, legislatively enacted rules that say that no one-- not a favorable press, not an unfavorable press-- can ever, under any circumstances, reveal fact A, fact B, fact C. That has to be subject to judicial review. That then has to be subject to trial by jury. The point is you don't trust juries and prosecutors with broad, overarching criminal statutes when it comes to the First Amendment. You narrow, you limit, and then you give it to the jury. But the last institution that should be making the decision who to prosecute is the very institution that is criticized by these revelations. So I urge you-- I urge you-- do not support this proposition.

This proposition is dangerous to your liberty. Thank you.

### Moderator
Claim: Thank you, Alan Dershowitz. And our motion is “Freedom of the press does not extend to state secrets,” and here to summarize his position in support of this motion, Michael Chertoff, former Secretary of Homeland Security and co-founder of the Chertoff Group.

### Conspiracy Advocate (CA)
Claim: Well, we support the proposition because the proof of the pudding is that we've had hundreds of years of American history where these statues have not been, in fact, a tool to oppress or to run rampant through the First Amendment. I think that our adversaries have essentially conceded that there are a category of state secrets that ought to be protected. And what they are arguing is the existing structure is somehow not definite enough. But I just want to spend one minute talking about what the existing law is. Because in fact, I think it strikes the right balance, which is the context in which we advocate this proposition. We have the Communications Intelligence Act protecting the information about our top secret code breaking and code making communications activity, quite specific, very reasonable and very understandable.

That's what keeps us safe. We have the Intelligence Identities Act, keeping the names of intelligence agents safe as David acknowledges is appropriate and again part of the law. Even the Espionage Act, which has gotten the brunt of the fire power here, requires a finding by a jury beyond a reasonable doubt that there was intent to damage the national security of the United States, not good intentions, not accident, not negligence, but bad intent to injure the security of the United States. I would argue that's exactly the kind of specificity that is appropriate in defining the category of state secrets that we are arguing ought to be protected under this proposition. And in fact the message that will be sent will not be one that will chill responsible reporters. It will be one that will chill the Julian Assanges who want to publish things because they want to hurt the United States and then want to claim the First Amendment to protect them against the consequences of that kind of decision.

Thank you very much.

### Moderator
Claim: Thank you, Michael Chertoff. And that concludes our closing statements. And now it's time to find out which time has argued best. We're going to ask you once again to go to the key pads at your seat to register your vote. And we'll get the readout almost instantaneously. Remember, our motion is “Freedom of the press does not extend to state secrets.” If you agree with this motion, if you are in favor of greater restriction on the press where publishing secrets is concerned, you vote number one. If you are against the motion, that is, you support great lenient license for the press, number two. And if you are or became undecided, press number three. And we'll have the results in about 96 seconds from now.

So before I announce the results of the vote, first of all, I want to-- I really want to express my appreciation for this team of debaters and the level of debate and seriousness that they brought to this evening. And I also want to thank all of you in the audience who took part in asking questions. They were all good questions tonight, and we really appreciate that. So a few things that I also want to talk about. This has been our 50th debate, and the conclusion of our fifth series. And this season was sponsored and underwritten significantly for us by the American Clean Skies Foundation. And we really want to give our appreciation to them. And I'd like to do that with a round of applause. But this debate in particular was brought to you in partnership with the Film Society of Lincoln Center which is opening with the documentary “Page One: Inside The New York Times.” That's the inaugural presentation at Lincoln center's new Eleanor Hunan Monroe Film Center. And the film actually is-- I've seen it.

It's a documentary. It gives very, very excellent and intimate, behind-the-scenes footage of life in The New York Times during a year that-- which the industry as a whole was trying to figure out what the industry as a whole was going to do. It also includes a feature-- it features a clip from one of our own debates and a particularly excellent moment with The New York Times media writer David Carr who sat right at that table. And I won't give it away. You'll have to go see the documentary to see what he did. But it was excellent. And you can go in fact, if you take your ticket stub tonight to the film center's box office, you can see this documentary for free starting on June 17th. Dates for our fall season are posted on the Web site, and you can take a look at our home page. Make sure to have those dates saved to your calendar. We're looking at various topics, but they may include America post-9/11, the decline of men, entitlements, the Arab Spring and the question of whether the world is better off without religion.

Tickets will go on sale this summer. All of our debates can be heard on NPR stations across the country. And this debate in particular has been recorded for television broadcast on WNET's channel 13 and WLIW. Also, don't forget you can follow us on Twitter and become a fan on Facebook. And if you do so, you will get a discount on future tickets. Again, this being our 50th debate, I want to put out a special thanks to Robert Rosenkranz for kicking this whole thing off back in 2006. And getting to 50 is amazing, and all the credit goes to him. Well, actually, there's credit to be shared. I'd like to-- Dana Wolfe, our executive producer who stands up and tells me what to say at every instance, every word that comes out of my mouth was actually processed by her and fed into my ear. And all-- stand up, Dana. There you go. And all of the crew who has made this season possible.

So the results are in. Remember, our motion is, "Freedom of the press does not extend to state secrets." Before the debate, 39 percent were for the motion, 31 percent against and 30 percent undecided. After the debate, 46 percent were for the motion. That was up seven percent. 47 percent were against. That's up 16 percent. And seven percent remained undecided. The team arguing against the motion, "Freedom of the press does not extend to state secrets," has won this debate. Our congratulations to them. Thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
