# Debate Transcript

Topic: Abolish The Minimum Wage
Motion: Abolish The Minimum Wage

Debate ID: 040313%20minimum%20wage


## Round 1

### Moderator
Claim: I’d now like to bring to the stage the chairman of Intelligence Squared U.S., who brought this to the United States, who has staged them now for over six years in New York, and who has helped bring it here tonight. Robert Rosenkranz.

And what Bob and I usually do for a couple of minutes beforehand is talk about the purpose of doing this debate and the timing of this debate. And Bob, let me get right to the question: Why do this debate now?

### Moderator
Claim: Well, the debate is timely because President Obama in his State of the Union message made one of his centerpieces a policy suggestion, the idea of raising the minimum wage from the current $7.25 to $9.

### Moderator
Claim: And why do you think the president decided to do that now?

### Moderator
Claim: Well, increasing the minimum wage is very tempting for politicians, because it’s conferring a benefit and the government is not paying for it. So it seems like a popular thing to do. And besides that, the beneficiaries, at least the way he characterized them, are hard working people who are struggling to support a family on a minimum wage.

### Moderator
Claim: So if it is that attractive. Where is there a debate in this?

### Moderator
Claim: Well, the debate is really about second-order effects. Economists like to say there’s no such thing as a free lunch, and if we raise the minimum wage, it has consequences; it means that people who go to McDonald’s are going to have to pay more because those costs are going to be passed along to consumers. It means that companies that hire minimum wage workers are going to make smaller profits; invest less in their businesses, and spend less.

But the biggest argument, I think, is sort of, Economics 101. If you raise the price of teenage labor, there’s simply going to be less demand for it; and if there’s less demand, it means fewer kids get on the bottom rung of the economic ladder, fewer kids learn how-- the demands of the workplace and responsibility of showing up. And those are the real cost of a rise in the minimum wage.

### Moderator
Claim: All right. So there I’m hearing basically the argument for abolition. What is the other side?

### Moderator
Claim: Well, I think what the other side is going to say is that the effects that I’m talking about are relatively modest in the way they’re going to play out, and the benefits outweigh those costs, and the people who do benefit from this are deserving, hardworking people.

### Moderator
Claim: All right. Let’s bring our debaters to the stage, and thank you, Bob Rosenkranz.

### Moderator
Claim: Thank you.

### Moderator
Claim: Thank you. I’d just like to invite one more round of applause for Bob Rosenkranz for making all of this happen. Two bits, 25 cents an hour. That is what the minimum wage paid back in 1938. That is 1/29th of what it pays today. And whether you’re working a job to get through college, or whether you’re greeting customers at a super store to make ends meet, at some point that minimum has been or is going to be your wage. And how well has that worked out for the economy, this 75-year experiment? Well, it sure sets up a good debate, so let’s have it. “Yes” or “no” to this statement: “Abolish the minimum wage”? A debate from Intelligence Squared U.S. I’m John Donvan; I will be moderating. We have four superbly qualified debaters who will be arguing for and against the motion, “Abolish the minimum wage.”Our debate goes in three rounds, and then the audience votes to choose a winner, and only one side wins. Our motion is, “Abolish the minimum wage.” And let’s meet the team. Arguing first for the motion, ladies and gentlemen, welcome James Dorn. James, you are the Cato Institute vice president for academic affairs; you are also editor of the Cato Journal. You have in the past referred to a potential minimum wage hike as, quote, “a case of zombie economics.” That’s a phrase you borrowed from Paul Krugman, who used it an article. For audience members who are not familiar with your work, if Paul Krugman is at one end of the spectrum, where does that put you?

### Conspiracy Advocate (CA)
Claim: Well, I work in the Cato Institute, so that puts me at the opposite end of the spectrum. I think the minimum wage is zombie economics.

### Moderator
Claim: All right. Thank you, James Dorn. And your partner is?

### Conspiracy Advocate (CA)
Claim: My partner is the great rapper Russell Roberts.

### Moderator
Claim: Ladies and gentlemen, Russell Roberts. Russell, you are also arguing for the motion, “Abolish the minimum wage.” You’re a research fellow at the Hoover Institute; you are host of the podcast, “EconTalk,” and a former George Mason University economics professor. And the word rapper came up; in fact, you wrote and produced-- co-wrote and co-produced a rap song on economics that sounds something like this. Wow.

### Conspiracy Advocate (CA)
Claim: It’s called “Fight of the Century.” How many people have seen that? We actually-- with John Papola, we produced two of them, two rap videos. And I want to make it clear on the record I’m not singing in either one of them. 6.3 million people have viewed them on YouTube, or maybe a few less than that, because people have kind of seen it 4- or 500 times.

### Moderator
Claim: You’ve gone viral. Ladies and gentlemen, Russell Roberts. Our motion is to abolish the minimum wage, and we have two debaters here to argue strenuously against it. First, let’s welcome, ladies and gentlemen, Jared Bernstein. Jared, you’re a senior fellow at the Center on Budget and Policy Priorities; you are former chief economist to Vice President Biden. You are now known as one of the top progressive economists in Washington, D.C., but before you were invited to the Obama administration you were on a different career path, one that informs your work today. Tell us what it is.

### Scientific Advocate (SA)
Claim: Well, I was also a rapper. No. I was social worker in New York City, and as I’ll comment later throughout the discussion that was where I first learned how important the minimum wage is to low income working families.

### Moderator
Claim: So social work and economics--

### Scientific Advocate (SA)
Claim: Very much-- very-- I mean, if I had my way, every economist would have to be a social worker for a couple of years before they got to be an economist.

### Moderator
Claim: Okay. Thanks very much. And your partner is?

### Scientific Advocate (SA)
Claim: My partner is my old friend and wonderful policy analyst, Karen Kornbluh.

### Moderator
Claim: Ladies and gentlemen, Karen Kornbluh. Karen, you are also against the motion, “Abolish the minimum wage.” You started your career as an economic analyst; you worked, actually, with Alan Greenspan. You were also an ambassador to the Organization for Economic Cooperation and Development. You got started in politics working for a senator named Barack Obama. You have been described as “Obama’s brain,” a phrase that you’re tired of hearing, and you were the chief architect of the 2008 Democratic Party platform. And, actually, I understand that you got your start in the public side of this based on something that your dad did?

### Scientific Advocate (SA)
Claim: Yes, my dad was involved in local politics. He served in a couple local positions in New York City.

### Moderator
Claim: This was before Take Your Daughter to Work Day?

### Scientific Advocate (SA)
Claim: Yes, yes, yes. I was very lucky he could take me to work. I got to see a lot of fascinating meetings and somehow decided to work with politics anyway.

### Moderator
Claim: The meetings were that fascinating?

### Scientific Advocate (SA)
Claim: That fascinating.

### Moderator
Claim: All right. Ladies and gentlemen, Karen Kornbluh. So our motion is “Abolish the minimum wage.” And we-- as I said before, what we do is we have you vote two times, once before the debate and once again after the debate, and the team that has changed the most minds will be declared our winner. It-- we’ll just have you go to the preliminary vote now. If you agree with the motion at this point, push number one; if you disagree, push number two. I’ll put it in a different way: if you’re for the motion, this team, push number one; if you’re against the motion, this team, push number two. And if you’re undecided, push number three.

And you can avoid-- you can ignore the other keys, they’re not live. And if you push the wrong button, just correct yourself and the system will lock in your last vote. While you’re doing that, I just want to, once again, thank WAMU for partnering with us on this Intelligence Squared U.S. debate. So, it looks like everybody's complete. Interestingly, that always turns out to be a very complicated process in New York. There's a--

There's a lot of-- so that was pretty impressive. So remember how you voted. We'll vote a second time after you've heard the arguments. So onto Round 1, opening statements from each team, each debater in turn. Our motion is, “Abolish the minimum wage.” And here to speak first for the motion, Russell Roberts. He is a research fellow at the Hoover Institution. He is host of the award-winning podcast “Econ Talk.” He blogs at “Cafe Hayek” and is a former professor of economics at George Mason University.

Ladies and gentlemen, Russell Roberts.

### Conspiracy Advocate (CA)
Claim: We need to abolish the minimum wage. And there's only one argument that matters on this issue, and it's the moral argument. Does the minimum wage make the world a better place? And does it improve or hurt the lives of the poorest American families and the workers who are in those families? Now, those Americans with the least education and the lowest skill levels have struggled tremendously over the last three decades. They find themselves in competition with machines, computers, automation, with foreign workers. Their job opportunities have shrunk. Their standard of living is mediocre at best, but the minimum wage is the wrong way to help those people. It attacks the effects of economic change rather than doing anything about the underlying causes. And by doing so, it hurts the people that we're trying to help.

You don't need a special theory of the labor market or a degree in economics to understand that making workers artificially more expensive makes it harder for them to find work. Now, those who support the minimum wage will tell you it's necessary to create a level playing field between employers and employees, that workers need the bargaining power that they are-- that they're missing, and the minimum wage makes that up. But in reality, most of us don't need that extra help. 95 percent of workers who are paid the hourly wage, which is about 75 million Americans-- 95 percent of those make more than the minimum wage already. And that includes my cleaning lady, who I pay over two times the minimum wage. Now, why do I do that? Because I'm an incredibly nice person. Well, that's what I like to think. But I really know better, because I'm an economist. The reason I play my cleaning lady almost $20 an hour is because if I don't, she doesn't show up. She has other alternatives that she will turn to if I don't meet her market wage. It is those alternatives that protect her from the greed of employers.

And alternatives force employers to treat employees well and most of us don't need legislation to protect us in the labor force. But the minimum wage does boost the salary of about 3.5 million Americans. About half of those, 1.7 million, are young people, 16 to 24. They get helped by the minimum wage as do those who make a little more than that, because it boosts the attractiveness of those workers relative to what it would otherwise be without the minimum wage. But those artificially high wages, that boost in wage discourages employers from hiring other workers who are low-skilled and have little experience. This is particularly tragic today, when the unemployment rate among 16-to 24-year-olds is 16 percent. And for African Americans-- young African Americans, it's over 29 percent. Almost one in three. Now, many who support the minimum wage will argue that somehow you could raise wages artificially and there'll be no net effect on employment.

But who believes that employers don't respond to incentives to higher wages and try to find ways to save costs? That's why employers replace workers with machines. That's why they send factories overseas. And that's why manufacturing employment has been falling steadily in recent decades, not just as a proportion of the total, but in absolute numbers, because fewer and fewer low-skilled workers who used to do those jobs are needed to produce the goods that we still make and manufacture. And by the way, the U.S. manufacturing sector, in output terms, is thriving. But in employment terms, it's struggling. And those are the places that people without a college degree used to find a good job. Those opportunities are shrinking. Why would artificially increasing the wages of workers, especially those who don't go to college and who don't finish high school-- why would artificially increasing those wages make those workers better off?

Why would it have no effect on their employment? Consider my favorite exemption to the minimum wage: the internship. The internship is a very special kind of violation of the minimum wage. You pay zero. You're allowed to pay zero. You're allowed to pay less than the minimum wage as long as it's zero. How strange is that? But we all understand that, for our kids, that's a glorious thing. It's what's needed because their skills aren't often worth $7.25 an hour, and we want them to get that experience at the bottom of their-- at the beginning, at the bottom of the economic scene, so they can get the experience, and the mentoring, and all the things that come with being in the workplace. And thank goodness that there is a special exemption for zero. Does anybody think that if we got rid of that, there'd be more opportunities for young people? Others justify the minimum wage by saying the effects are small-- the employment effects. Small? When you lose your job or can't find one, the effect isn't small, it's 100 percent.

So it's nice to give 1.7 million young workers a raise, but what about the 3.4 million unemployed workers 16-to-24, last month, who can't find work? We're increasing the wages of 1.7 million and making it harder for 3.4 million to find work, twice as many. I don't accept that tradeoff. That's a tragedy. I reject it. It's a bad bargain. The irony of the minimum wage is that it reduces the bargaining power of the people at the bottom end. It reduces the number of opportunities they have while increasing the number of people who are trying to find them. The best argument for the minimum wage is that our school system is a failure, so we have to do something to help those at the bottom. But this is the wrong way to fix it. It's an additional barrier to the least skilled workers of America, making it harder for them to find work, those who have the least education, the least ability, the fewest connections, the ones who desperately need that first job to start their career. I beg you to consider that the best intentions don't always lead to good results. Abolish the minimum wage.

Let young people and the least skilled have a better chance of getting the experience they need to thrive and prosper. Thank you very much.

### Moderator
Claim: Thank you, Russell Roberts. Our motion is "Abolish the minimum wage." And now here to speak against this motion, Jared Bernstein, he is a senior fellow at the Center on Budget and Policy Priorities, also served as chief economist to Vice President Joe Biden, and executive director of the White House Task Force on the Middle Class. Ladies and gentlemen, Jared Bernstein.

### Scientific Advocate (SA)
Claim: Well, I'm glad to see all of you here and that you've chosen this over other D.C. options you had tonight. You could be looking at the cherry blossoms or seeing the Nationals play, but you've come to talk and debate the minimum wage, so you're my kind of people. So I'm glad you're here. Here is my main point. Luckily, for our side, strongly against abolishing the minimum wage, almost everything you just heard from Russ is shown to be false by a large body of compelling research.

So let me start with my main point. Abolishing the minimum wage would be a terrible policy mistake that would needlessly hurt millions of low wage workers. It's not a policy, this idea of abolishing the minimum wage. This policy is nowhere near the current agenda. In fact, as you've heard, the current debate asks whether the minimum wage should be increased. Now, it is true that during the Republican primary, Michele Bachmann and Herman Cain endorsed the idea in the Republican primary of abolishing the minimum wage, but that idea of abolishing a policy that's been in place since the 1930s, helping low wage workers, is about as far out of the mainstream as you can get, and let me explain why. Now, this gray hair I have, I got through a lifetime, as was mentioned earlier, of analyzing social and economic policies, beginning as a social worker in New York City with the poor, and I worked my way-- I don't want to say up, sideways, wherever it is I am now-- to whatever it is I'm doing today.

And, you know, over those decades, I focused on two things, what's gone wrong in our economy and which policies could help give less advantaged folks a shot, a fair chance? It's through that simple agenda that decades ago I became interested in minimum wage policy. As globalization, and technological change, and a lot of other stuff that we can talk about throughout the evening have evolved, economic growth no longer reaches working families the way it used to. And the further you go down the pay scale, the less growth you're likely to see. The minimum wage partially helps offset that problem. And, in fact, you will be hard pressed to find a policy that does what it sets out to do, raising the pay of low wage workers, more effectively or more efficiently. And importantly, and this is why I stressed it when I started, and we'll have lots of time to get into this, I hope, reams of high quality research shows that it does so with the minimum of the type of side effects that you heard Russ emphasize.

Consider this, just start here with a little commonsense thought experiment. The American minimum wage, as you've heard, has been in place since 1938, 75 years ago. It has been raised 22 times. Nineteen states now have their own minimum wages above the federal level. If this policy was so damaging, as damaging as Russ claims, that it needs to be abolished, how could it be that citizens and legislatures in 19 states decided not to abolish it, but to raise it above the federal level? If it was anywhere near as damaging as our opponents claim, how could the minimum wage not only have survived this long, but have flourished and expanded? The answer, once again, is because it's widely understood and accepted by mainstream economics, policymakers, and perhaps most importantly, low-wage workers themselves, who overwhelmingly support the policy-- that's very important, I'll come back to that-- as doing what it's supposed to do, steering a bit more of the economic growth their way.

Now, to do what our opponents advocate, to get rid of the minimum wage, would figuratively take the wage floor out from under millions of low-wage workers, many of whom-- and Karen will emphasize these points-- depend on the minimum wage to support their families. It's very misleading to say that this is just a teenagers’ issue. It's not. For these reasons, as you've heard, the president has proposed an increase in the federal-- in the federal minimum wage. Now, that's what we ought to actually be debating. I firmly believe that economists can and should have good, robust debates about that kind of a proposal-- should the minimum wage be increased or not? But that's not what we're arguing about. That's not what you're voting on on the resolution. Our opponents think that America should have no minimum wage at all. To me, a better question than that-- than the one on notice tonight, should be-- should the minimum wage be abolished? The better question is why anyone would even suggest such a bad idea? So, why would you-- why would you even think that? And I think the answer comes down to two factors. First, common misconceptions, ones that should have been banished by the research.

And second, because of a laissez-faire market ideology that trumps common sense and empirical evidence. Now, a word about this evidence. There's probably no question that's been analyzed more carefully by economists than this one, about the impact of the minimum wage on low-wage workers. And the conclusion is that it raises the pay of low-wage workers without hurting their jobs prospects. Of literally thousands of estimates on the impact of the minimum wage on job impacts of affected workers, the vast majority find that the benefits to low-wage workers-- the benefits to low-wage workers-- exactly the opposite of what's-- of what Russell claims-- the benefits for low- wage workers far outweigh any costs in terms of reduced hours or job loss. Now, recall that I mentioned all of these states with their own minimum wage levels exist. That's provided something that minimum wage researchers have found very rare in economics-- pseudo-experimentation. The best way to test the impact of an intervention like this is to compare places that are as like-- as-- in terms of economic variables as you can find.

Yet, one has the economic intervention and the other doesn't. These studies, this pseudo-experimentation, comparing states and places across borders, have consistently found results, job loss effects, that hover around zero. Sometimes a little bit below. I will grant the other side that. Sometimes slightly negative, sometimes slightly positive, but hover around zero.

So we have here a simple policy that for 75 years, has been doing what it's designed to do with little fanfare and minimal, if any, negative side effects. Abolishing it makes absolutely no sense at all. Thank you.

### Moderator
Claim: Thank you. Jared Bernstein. Thank you, Jared Bernstein. And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion, “Abolish the minimum wage.” You have heard two of the opening statements, and now onto the third.

Debating in support of the motion, to abolish the minimum wage, the vice president for academic affairs at the Cato Institute, editor of the Cato Journal, and professor of economics at Towson University. Ladies and gentlemen, James Dorn.

### Conspiracy Advocate (CA)
Claim: Good evening. It's a pleasure to be here. I hope you will keep an open mind and vote for abolishing the minimum wage. Jared gave some evidence-- there was just a new study out by David Neumark, written for the NBER, National Bureau of Economic Research, one of the foremost research organizations in the United States, with top scholars. He refutes much of what Jared just said. Actually, the preponderance of evidence is in favor of the fact that the minimum wage does destroy jobs. Why? Because if anybody believes in the law of demand, it means when prices go up, there's less of it that people buy. And nobody's ever disproven the law of demand, not even Jared.

Nobody in Congress has disproven the law of demand. So, I think we should keep that in mind. Hong Kong never had a minimum wage. I've been over-- I've been visiting China since 1988, every year, just about. Hong Kong started to develop in trade in 1938 and it was just a bunch of shanties and everything. Hong Kong rose up to be one of the most prosperous places in the world without a minimum wage. So the minimum wage is neither necessary nor sufficient for prosperity; what prosperity requires is opportunities. The minimum wage destroys opportunities. I had a friend of mine, his mother was working at a department store up in New Hampshire. After the kids grew up, she was making close to the minimum wage. The minimum wage went up, she lost her job. She enjoyed this job; it changed her whole life. And she was denied the opportunity to go back and offer her labor services at the pre-minimum wage; that is, the wage that she was agreeing to work at freely.

The minimum wage interferes with individual freedom and economic freedom. And that's what's wrong with the minimum wage to a large extent. It reduces-- it reduces-- it doesn't increase workers' bargaining power because it makes it illegal for the worker to offer her labor services for less than the minimum even though she's willing to do so because that's a better opportunity for her. And it makes it illegal for the employer to hire that worker. Also, it should be obvious that if you increase the wage rate above the going market wage rate, if it's only a little bit above, it's not going to have much of an effect. But if it's quite a bit above, as happened in New York State in the early 2000s, then it led to a about 20 percent decrease in the unemployment rate in New York State for teenage workers aged about 16 to 24 without a high school diploma. They kind of cut off the bottom rung for the ladder. They couldn't get in the market.

There was a surplus. There's lots of jobs when the wage rate is lower; when if goes higher, there's fewer jobs. But many workers want to get those jobs at the minimum wage. The government promises people a minimum wage, but the politicians can't keep that promise because there's two sides to the market. The employers will not hire as many workers when the wage rate goes up. And in the short run, there may not be much unemployment. But in the longer run, as Russ pointed out, the employers will substitute skilled workers for unskilled workers. They might use a computer and have one worker rather than ten, or they may substitute labor-saving devices. And there's lots of evidence to show this. Just an article in the Wall Street Journal over the weekend, woman was running-- she runs bakeries, cupcake bakeries. She hires-- she has about ten young workers working for her. She said because of the anticipated increase in the minimum wage and the indexation, that she's going to replace those ten workers with some tablets and a skilled worker to run the operation so that they can order using the tablets.

Another person that owns some restaurants and so forth, he's going to go to use his new app called Squared, which basically makes it easier to clear checks and process credit cards. And he will displace about 30 out of his 75 workers, he said in that interview. So this is a reality. The woman that lost her job in New Hampshire, that's not just a statistic, that's a personal story. We can play games with statistics. And there's a preponderance of evidence, as I said, that the minimum wage has these detrimental effects. In fact, Neumark in his study, after looking at all these other studies, said his conclusion has not changed. And it's a very, very rigorous study. What else happens? Employers use temporary workers rather than full-time workers. They might make one worker do the job of four because after all, there's a surplus of labor now.

There's unemployed workers that are looking for these jobs so they can just, you know, lay somebody off and make the other workers work that much harder. It also destroys jobs, jobs that used to be done in the United States. When I was a kid, they had elevator operators in Buffalo, New York. You won't see those anymore. You might see them in Argentina. They don't have baggers at the grocery stores. Those have become full-time jobs, in many cases, unionized. And it slows job growth. There was just a new study out by Texas A&M showing that the minimum wage has slowed job growth, which we should expect. How do you explain these huge unemployment rates among black male teenagers that are, you know, over 30 percent? In Spain, they have a very rigid minimum wage. And the unemployment rate there is 26 percent, the national rate. The unemployment rate among younger workers-- unskilled workers who are typically younger workers, is double that. How do you explain that?

The minimum wage, also, by the way, does not reduce the poverty rate. Poverty rate has actually increased a little bit because of the minimum wage. Doug Adie and other people have looked at that; Neumark as well. And if you can't get a job-- because, remember, the law-- what does it do? It increases the wage rate, but if you don't get a job, your income is zero. That's what a lot of people don't understand. The difference between the wage rate, which is the price, and income, which is the price of labor times the hours worked. If you can't get a job, your income's zero. So we found that the people that this affects are low skilled workers in low income families, and that's why the poverty rate is affected.

Okay, so--

### Moderator
Claim: James Dorn, I'm sorry, your time is up.

### Conspiracy Advocate (CA)
Claim: Okay, so--

### Moderator
Claim: Thank you very much. Our motion is "Abolish the minimum wage." And our final speaker here to speak against the motion to abolish the minimum wage, Karen Kornbluh.

She is the former U.S. ambassador to the Organization for Economic Cooperation and Development and former policy director for then-Senator Barack Obama. Ladies and gentlemen, Karen Kornbluh.

### Scientific Advocate (SA)
Claim: Thank you, John. I want to return to the moral question that we started with because the moral question is all on our side. Let's talk about what would happen to real people in real families if the U.S. were to go down this untested and quite radical path of eliminating the minimum wage as our opponents urge. What I want you to understand is that roughly one quarter of all children in the United States, more than 17 million children, have a parent earning the minimum wage or just above. Another way to think about this, only-- almost one of three of those who benefit from the minimum wage, so they're just at the minimum wage or they're just above it, and so they're what we think that their wages are bumped up because of the minimum wage, are parents. One in three.

That means that today, a family with two kids that earns the minimum wage because of the low level of our minimum wage is still living below the poverty line at today's level of the minimum wage. These families, as Jared and I have actually studied, work more and more hours and yet still have to make terrible choices every day. They have to choose, "Do I pay for childcare or leave my little child alone? Can I afford healthcare? Can I afford to put anything aside in case I lose a job?" What our opponents are asking is to get rid of the minimum wage that keeps those families barely afloat today. How can they even consider that? I want to think beyond that family and what the implications of pulling out the rug under them would mean for the rest of us. First of all, let's think about the knowledge economy. Our opponents have been talking about teens and letting them work for less money, but we're talking about a knowledge economy where we want to compete for high-wage jobs, and the people who are going to take those-- the children growing up in those families are the ones who are going to be the human capital of our society going forward.

They're going to pay your and my Social Security. They're growing up in those families, earning those very low wages. They'd be worse off. There would be less to invest in those children. Social mobility in the U.S.-- the U.S. used to be the home where, if you were brought-- born into a poor family, you could make good. That's less and less true. The American dream is under more and more threat. We're behind every country-- this is OECD data. We're behind every country except the U.K. now in terms of social mobility. We're behind France in social mobility. So do we really want to go backwards, get further away from the American dream? No, I don't think so. I think we want to restore the American dream, not turn this country into a Dickensian nightmare. Inequality, closely related to social mobility-- inequality is approaching record levels.

And we think that half of the increase in inequality is a result of the falling minimum wage, half of the increase in inequality for those at the lower end. Then there's the issue of our economic recovery-- our fragile economic recovery. If the minimum wage - - if abolishing the minimum wage had any effect at all, it would surely take money out of the economy. In fact, it would act as a reverse stimulus. So let's think very carefully before we go down this road as a society. I'd like to bring up women, as the only woman on this panel. Over half of those who earn the minimum wage are women, and these women obviously already face disadvantages. If you look at the data, women are poorer than men at every age, and in old age the gap is tremendous because of the low wages that they earn. If we eliminate the minimum wage, this will especially hurt women. Now, can we afford the minimum wage? It's a big question. Yes, absolutely we can afford the minimum wage.

As Jared said, we've had it for over 75 years, hasn't hurt overall economic growth. The wealthiest Americans are doing extremely well. Corporate profitability is growing; as we know, the stock market just broke new records. But the families at the bottom end are not sharing in this increasing economic growth. We can afford to let them share a little bit of that. There's no evidence that the minimum wage costs jobs. There was a famous study two decades ago by Alan Krueger, now the chairman of the Council of Economic Advisers, and Berkeley's David Card. They studied New Jersey's fast food restaurants and they found a slight increase in employment as a result of the minimum wage being raised. And countless economists have poured in to try to refute this and they haven't been able to. They've done all kinds of studies. And as Jared said, there's just no evidence that employment is hurt. And this applies to studies not just carried out in the U.S., but those in the United Kingdom, Australia, and other countries. We heard about Hong Kong.

Let's talk about Hong Kong. Hong Kong is a city-state of 7 million people, smaller than New York City, where I grew up. I don't think we want to gamble the United States' economic future on an experiment in Hong Kong. In China, however-- Thanks. In China, however, the provinces actually have something like a minimum wage. It's a monthly floor. But in Beijing, they actually have a minimum wage, and guess what? The central government in China just decided to raise that wage across the country so that it will be 40 percent of the average salary, which is higher than we have - - what we're talking about that we have right now. I just-- I just want you to think about the maid who makes your bed in the hotel when you're out of town, the person who serves you that salad when you go to the fast food restaurant at lunchtime. Most of these people do not earn enough today to feed themselves, house their kids, and take care of their families. We-- they cannot afford to see their incomes fall.

The moral argument is absolutely on our side, to not pull the rug out of low-income families. Please vote no on abolishing the minimum wage. Thank you.

### Moderator
Claim: Thank you, Karen Kornbluh.

## Round 2

### Moderator
Claim: And that concludes Round 1 of this Intelligence Squared U.S. debate, where our motion is “Abolish the minimum wage.” Now we go on to Round 2, and that's where the debaters address each other directly and take questions from me and from you in our live audience here in Washington D.C. We have two teams of two arguing for and against abolishing the minimum wage. The side arguing for the motion, Russell Roberts and James Dorn, have said that the minimum wage actually should be abolished. It should be abolished actually because it hurts the people that it's trying to help, that it makes workers artificially more expensive, and that that is something that kills jobs. The team arguing against abolishing the minimum wage-- in fact, they're saying that it should be raised, say that few policies have worked better as designed, over 75 years, than this one. And they say they are making the moral argument, that to abolish the minimum wage would pull the rug out from under millions of American families who are depending on it.

I want to put a question to the side that is arguing to abolish the minimum wage in terms of impact. And either of you can take this question: if the minimum wage were abolished today, effective tomorrow, and employers could adjust wages, what do you think would happen? How many people would see their wages go down drastically and immediately?

### Conspiracy Advocate (CA)
Claim: Well, we can't answer that precisely.

### Moderator
Claim: Russell Roberts.

### Conspiracy Advocate (CA)
Claim: I certainly wouldn't abolish it tomorrow. I'd want to phase it out. But as I said earlier, about 3.5 million workers today earn the minimum wage or less. Some of those, by the way, are-- about a million of them are in the food service business. And many of those make tips that boost their wages higher than what they're listed in the data. But it's about 3.5 million workers. So some of those would have lower wages. And the real question is, what else would employers do? What else would happen in the workplace if workers didn't have to be paid a legal minimum?

And I think there'd be a lot more opportunity for those 3.4 million unemployed 16-to 24-year-olds that have had the rug pulled out from under them, because we have a policy in place that makes them expensive. And I think that's a terrible mistake.

### Moderator
Claim: Russell, in the very short term-- I'm just trying to-- I'm trying to hone in on the point that Karen Kornbluh is making, that she says it would pull the rug out from people who depend on it now. Is that-- is that accurate? Do you think that-- you're-- I think you're talking about a longer-term process, where employers adjust, but in the short-term, would a lot of people be hurt very quickly?

### Conspiracy Advocate (CA)
Claim: Well, I don't know. I think some employers would take advantage of the change in the law to lower wages. And they would have lower income. The question is, what's the right way to help people who have low skills or who are struggling for all kinds of reasons, many of which are not their fault? We have a horrible school system. We ought to fix our school system instead of trying to help people through this artificial method. If the artificial method worked, I'd be-- it'd be great. It'd be great. When Karen says we can afford it, we can afford it, this group, because we all make more than the minimum wage.

And I would guess that most of the people in this room-- because 95 percent of the American workforce does earn more than the minimum wage, it would have very little effect on us. It's the people that we don't see, people who have the toughest time finding work, who are punished by this good intention-- well-intentioned law.

### Moderator
Claim: All right. Jared Bernstein.

### Scientific Advocate (SA)
Claim: Yeah, I'm going to respond to that. First of all-- and I think we have a disagreement about the numbers. 3.5 million hourly paid workers?

### Conspiracy Advocate (CA)
Claim: That's correct.

### Scientific Advocate (SA)
Claim: Correct. You're leaving out at least 2 million salaried workers. Salaried workers are not exempt from the minimum wage, so that number is wrong. Here's--

### Conspiracy Advocate (CA)
Claim: What's the source of that--

### Scientific Advocate (SA)
Claim: Here's-- let me finish.

### Conspiracy Advocate (CA)
Claim: What's the source for 2 million? Because the BLS doesn't collect that data.

### Scientific Advocate (SA)
Claim: Oh, absolutely. No, no, no. This is-- this is from the current population survey.

### Conspiracy Advocate (CA)
Claim: Okay.

### Scientific Advocate (SA)
Claim: Look--

### Moderator
Claim: Don't you wish you hadn't asked or--

### Scientific Advocate (SA)
Claim: Russ Roberts--

### Conspiracy Advocate (CA)
Claim: They don't collect the hours data in

### Scientific Advocate (SA)
Claim: Russ is a friend of mine. I like Russ. But--

### Moderator
Claim: So we've got the whole ad hominem thing worked out right away.

### Scientific Advocate (SA)
Claim: You know there was a "but" there. No, I like Russ a lot. But I am a-- I am aghast to hear Russ say, “how many people would this hurt? Who would this hurt? How would it hurt them? I don't know.” That's what he just said, "I don't know." You cannot, in my mind, in good faith, in this economy, in any economy, talk about abolishing the minimum wage and not know what its impact is going to be. That's way, way too reckless. Now, the idea that workers are hurt by this the way Russ and Jim have argued is belied by research that looks very carefully at changes in minimum wages across different economies and different groups. Now, I don't want to get-- I don't know if we want to go there now, but we need some time to explain, I think, to the audience, what the research actually shows. You can't just say, "Black unemployment is high, and we have minimum wages, therefore high minimum wages cause high black unemployment," because we've had periods when we've raised the minimum wage in the 1990s, we've raised the minimum wage in 1996, black unemployment came way down.

So I'm not saying that it came way down because we had a higher minimum wage. I'm saying there are a lot of moving parts. And the best research compares the impact of the minimum wage controlling for those moving parts. And that's what we've been citing.

### Moderator
Claim: James Dorn.

### Conspiracy Advocate (CA)
Claim: May I respond to my friend?

### Moderator
Claim: Let me have--

Let me bring in James Dorn, and then you guys can be friends later.

### Conspiracy Advocate (CA)
Claim: Yeah, two points. If there's an excess supply of labor, low-skilled labor, and they can't get jobs, yeah, the minimum wage will come down. But the competition will be among the workers. The workers that have lower valued alternatives, they can't get a job at the minimum wage, they will not have an opportunity to get a job. I think that's a very important point. Their wages will not stay low forever. Most of these workers are young. They will be in, they will get good work habits, they will learn things. The employers will eventually pay them more as their productivity goes up. You don't want to put the cart before the horse. When you go to get a job, okay, the government can increase the minimum wage, give you a raise.

But if your skills haven't changed and anything else, that's not going to-- that's not going to happen.

### Moderator
Claim: I want to take-- I want to the point that I think you're making to Karen Kornbluh. And your opponents are basically saying that they acknowledge that people who are making the minimum wage would rather be making the minimum wage than less. They acknowledge, I think-- Russell acknowledged that some people would be hurt immediately in their pocket books. But they're also saying that lots of people are not on the minimum wage. They're not working so the policy doesn't do anything for them and that it's-- more than half of poor people between the ages of 60 and 64 do not work. That policy does not nothing for them. And I want to have you respond to that piece of their argument.

### Scientific Advocate (SA)
Claim: Thank you, John, because I made the moral argument, but I think it's really important to get the economic argument right. And I think the economic argument sounds like it's on their side, but it's absolutely not. It's-- I like them both very much as well. I think good economics says that you have to make sure that you're not-- that you're actually looking at causality and that you're taking account of all of the variables. And what the economic studies really show is that there are a lot of other things that affect unemployment and that produce unemployment or employment. And those have to do with the overall state of the economy, has to do with education. And it's just overly simplistic--

### Moderator
Claim: But I'm--

### Scientific Advocate (SA)
Claim: --analysis to say that-- that the minimum wage actually produces unemployment even

### Moderator
Claim: But I'm actually bringing to you a different part of their argument, which is not the part of the argument where they're saying that it reduces employment. It's the part of their argument where they're saying it does no good for people who are not employed as a policy. Number one, it expenses businesses as opposed to the taxpayer to help this sector of society. And number two, it doesn't do anything for people who don't literally have jobs.

### Scientific Advocate (SA)
Claim: I think what we need to focus on, though, for those people-- and they've said it again and again, and I absolutely agree, and we can all go out agreeing on this, is, we need to improve our education system. We need to get access to vocational education.

We need to get access to higher education. That's what you need in a knowledge economy. And so I think we all agree on what we need to do for those people.

### Moderator
Claim: Russ Roberts.

### Conspiracy Advocate (CA)
Claim: I want to just say something general about the empirical literature on the minimum wage. There have been hundreds of studies done on both sides, actually hundreds have found that the minimum wage reduces employment. That was the consensus among economists until the Card and Krueger study in the 1990s. And that consensus has shifted somewhat. Now there are many economists who think that the effects are either small or minimal. Again, I would emphasize that small to me does not mean it's irrelevant. Small is still people's lives. But the point is that both--

### Moderator
Claim: Just to clarify, does that mean you're conceding their points on the trend of the study now?

### Conspiracy Advocate (CA)
Claim: Oh, no. The trend is definitely-- there are definitely studies in respected journals that show little effect of the minimum wage on unemployment. And there are just as many studies on the other side saying, no, those studies are wrong. Strangely enough, Jared and Karen, who I like very much--

Seriously, I've been on many panels with Jared. We have a good time. Those studies haven't convinced-- those studies that show that there have been serious losses of jobs, which Jim mentioned one of them, the Sabia, Burkhauser, Hanson study of New York workers, 20 percent drop in workers without a high school diploma. That's an incredible tragedy. They don't find that persuasive. The study wasn't done well. Strangely enough, we don't find the studies that find the other side persuasive as well. There's a big ideological gap between these two sides that we should be honest about, because if the studies were great, they would win. They would convince people. But the reason they don't convince people is that the world is a complicated place, as both Karen and Jared have said. There's a lot of things going on at once, and it's really hard to hold things constant. It gets a lot harder when the minimum wage affects a relatively small part of the population. So when 95 percent of Jared-- if I want to accept some of your salaried workers, some slightly smaller percentage of the workers earn more than minimum wage already, yeah, it's going to be hard to tease out the independent effect of that relative to all the other things that change in the economy at the same time.

So it's very hard to do. It's not persuasive to the opponents.

### Scientific Advocate (SA)
Claim: I think that's-- I think that's a very fair--

### Moderator
Claim: Jared Bernstein.

### Scientific Advocate (SA)
Claim: I think that's a very fair assessment of the literature. And, you know, you keep-- the other side keeps citing the work of David Neumark. I think David Neumark, he-- you've got--

### Moderator
Claim: Has everybody read the David Neumark?

### Scientific Advocate (SA)
Claim: No, no.

### Moderator
Claim: And his hundreds of studies.

### Scientific Advocate (SA)
Claim: So you've got-- you know, the-- I thought Russ described it well. You've got the Krueger and Card and a lot of other studies that showzero or slightly positive. David Neumark and others show slightly-- now, I recently corresponded with Neumark about this because we did a study at the Center on Budget-- we're doing a study. And we said, “David, what should we plug in to accurately represent the job loss effects that you, and our opposition, believe occurred?” Because we want to be fair, just like I thought Russ was pretty fair. And he said, essentially, a 10 percent increase in the minimum wage will lead to a 1 percent decline in the employment of teenage workers.

Now, if that occurs, that means that 99 percent of affected workers get a pay raise. Now, our opponents have consistently said, if 1 percent loses a job or loses hours of work, yet somehow 99 percent get a raise, it's a bad deal. That's just, I think, economically a very-- a very misleading

### Moderator
Claim: Let's hear from Jim Dorn arguing to abolish the minimum wage.

### Conspiracy Advocate (CA)
Claim: Yeah, I want to address Karen's point on the moral argument.

### Moderator
Claim: Can you respond-- would you respond to the point made? And I will come back to you on the moral argument--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: Only because I do want to explore that moral issue. But--

### Conspiracy Advocate (CA)
Claim: Yeah, okay, responding to that point. Most of these studies look at the short run, what happens in a very short period of time. And there's mostly modest increases in minimum wage that would lead to modest decreases in employment. And that shows up.

But if you look at the long run, longer period of time where businesses that are just making marginal profits, and they can't increase prices much, they're going to cut back on low-skilled workers. And all workers aren't the same. All teenagers aren't the same. Some are-- have better work ethics and so forth. So these are the workers that are going to be retained, and other workers are going to lose their jobs. And these workers that lose their jobs cannot come back and say, “Okay, I'd be willing to work at the wage I worked at before.” This is the thing that I dislike about the minimum wage: it puts government in between the employer and the worker. It politicizes the decision about employment. Instead of letting the worker who knows his or her alternatives best, come in and negotiate. Now, they might say the worker has no bargaining power. Well, if that were true, you could pay the worker anything you wanted. But if you pay workers too low, you see “Help Wanted” signs.

Employers want to hire workers, and they want to train workers, and they will spend money training workers. This happened in Hong Kong. You know, she points to Hong Kong. Hong Kong has been the number one economically freest country or region or special administrative region or whatever you want to call it in the world. China does not have a federal minimum wage. They have local minimum wages, and most of those local minimum wages, especially in the coastal areas, have been below the prevailing wage. The politicians there want to create jobs, and they know if the wage rate is too high, the official one, they won't create those jobs.

### Moderator
Claim: Jim, I want to-- the part of your argument I want to take to this side, which was very accessible to all of us, is the logic that he lays out that it's-- and to use the phrase that his partner used, if you "artificially make workers more expensive" then employers are going to adjust by not hiring them. That is a coherent logical argument, and I haven't heard you respond just to the logic of that argument.

### Scientific Advocate (SA)
Claim: Sure. That's a great question. Like any other theoretical notion-- and it is a theoretical notion; a very cogent one, as you mentioned. It has to be empirically tested. You can't in economics-- this is not science, this is social science. It's different. You have to test it. And the tests that have been applied have been, I think, very careful pseudo- experimental kinds of tests, especially more recently, where as much as you can is held constant. And what those tests find is that you don't get the results that Jim and Russ have predicted. So you have to ask yourself what else is going on. And the other things that are going on are what I call the "three Ps." There are three other ways that an increase in the minimum wage gets absorbed that have nothing to do with job losses: prices, productivity, and profits. Okay? Profits-- and as Karen mentioned, corporate profitability is soaring at an all time high while compensation, by the way, as a share of national income is at a 50-year low. Profits are redistributed somewhat when minimum wages go up to low wage workers.

I think that's a good thing, given the trends that Karen described. A very interesting and very positive impact is that you find that in the low wage labor market, a part of the economy that's fraught with turnover and vacancies, that goes down significantly. So productivity helps absorb some of the increase as well. And there's some price effects, too.

### Moderator
Claim: But my question that I put to the other side, the day after the minimum wage is abolished, what happens to the workers who are making minimum wage now? They keep their jobs, they make less money? That's what you see happening?

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: Okay. Russ Roberts.

### Conspiracy Advocate (CA)
Claim: Well, Jared and I agree on something very important, which is economics is not a science. That's good. It's a start. It's more like history with a lot of numbers. It's nothing like physics or the sciences. So to me, the word "social" in front of it, it's a very important qualifier. And I think the challenge is the empirical evidence that Jared's talking about, I view as very unpersuasive. And it's-- I know it's unpersuasive because it doesn't persuade the opponents.

No one reads these studies that are full of equations, and Greek letters, and lots of fancy statistical work, and go, "Oh, my gosh--"

### Moderator
Claim: But can they be persuaded?

### Conspiracy Advocate (CA)
Claim: "-- I've been wrong all my life." I don't know. It doesn't happen.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: In theory it could, but I-- everybody always says, "Oh, they left this out. They didn't do this right." They always have a reason, and that's because of the fundamental complexity of human society. So I want to ask instead of that-- those kinds of studies which I don’t think persuade even economists, and they shouldn't persuade you, I want to ask you to do the following experiment. If you decided to quit your job, you didn't like your job, you were bored, you wanted to try something else, and now you're going to go out in the workplace and find a new job, but the government passes a law that for you to be-- when you go to your new job, your new employer has to pay you, say-- let's pick a small-- relatively small number, 20 percent more than your current job. That's the law. So you've switched jobs, you’ve got to get 20 percent more, do you think that would be good for you or bad for you? You realize-- and my question is to my opponents, do you think that would make it harder for you to find work? They're arguing that, "Oh, empirically-- it's an empirical question. Empirically, it doesn't have any effect when you artificially raise people's wages."So you, you have no extra skills, nothing new, you come into the workforce, "Yay, the government's passed a law. You have to be paid 20 percent more than in your last job." Would you be happy? Would you be excited about that? I think you'd be scared. I would be. I think it's very difficult.

### Moderator
Claim: All right, I want to go a few more-- I want to go a few more rounds. I want to go to Karen Kornbluh to respond to that, and then I do want to get to that moral question that Jim Dorn wants bring up. Karen Kornbluh.

### Scientific Advocate (SA)
Claim: But before I respond to that, I just want to lay out another thought experiment, which is that if you are really serious, if you really thought that teenagers couldn't work at the minimum wage, and that it was keeping them out of the workforce, then what you might look at-- and some countries that have very, very high minimum wages have looked at this-- is a separate minimum wage for teens. We have a separate minimum wage for tip workers. I'm not saying those are something that I would-- that's something that I would endorse, but if you're really serious about a separate population needing to get entry, that's what you would do. I mean, we're very lucky. We have an easier case to make, because the proposition on the floor is abolishing the minimum wage.

You do not have to go to abolishing the minimum wage to address the arguments that our opponents have brought up even if you take them at face value.

### Moderator
Claim: Jim Dorn.

### Conspiracy Advocate (CA)
Claim: Yeah, I'll come back to this-- moral argument. If you think that people--

### Moderator
Claim: Just in terms-- everybody's very timid on the applause. There's the beginning, because it's a radio broadcast. You ever listen to “Wait, wait, don't tell me?” That's you. Okay? That's

### Moderator
Claim: But that show is funny.

### Moderator
Claim: Yes. Let's go listen to it now. All right. I would just want the laughter to stop so that I can get to Jim Dorn. Jim Dorn.

### Conspiracy Advocate (CA)
Claim: Now, I want to come back to this moral argument, because I think it's an important point. The question is whether individuals should be free to choose on their own terms, as long as there's not fraud involved and violence, to make themselves better off as they see it or whether the government should mandate a wage rate which may put you out of a job.

If the government says the employer has to pay you $9 an hour and you're only producing $5 a hour, you're going to lose your job. Now, why is the worker getting $5 an hour? Because he or she doesn't have very many good alternatives. They don't have much education. So the real way you want to increase their income-- you increase the wage rate, they lose their job, their income is zero. How do you increase their real income over time? They have to have a better education. They have to have work habits. They don't get any work experience if they can't find a job. And people do lose their jobs. There's lots of evidence on this. Douglas Adie did a very good study showing that when the real minimum wage rate, that is, adjusted for inflation, increased by 10 percent, he found that there was a almost four percent increase in the unemployment rate for low-skilled workers, in the long run, after firms made adjustments.

That's an economic-- that's what you'd expect from economic theory. The economic--

### Moderator
Claim: Yeah, but are you saying then that more people would be working if there were no minimum wage?

### Conspiracy Advocate (CA)
Claim: Of course.

### Scientific Advocate (SA)
Claim: So, let me-- let me--

### Moderator
Claim: Jared Bernstein.

### Scientific Advocate (SA)
Claim: --refine. Jim and Russ talk a lot about freedom-- interferes with workers' freedom. This is bad for workers. Workers don't want this. So everybody's had a chance to do a thought experiment except me. So here’s the thought experiment. Imagine a poll that asks a bunch of low-wage workers, “Would you support abolishing the minimum wage?” Okay? Do that little thought experiment and see if that interferes with workers' freedom. In fact, 90 percent of Americans earning less than 24,000 a year support raising the minimum wage. So go ask them about abolishing it and see what they say about their freedom to choose.

### Conspiracy Advocate (CA)
Claim: Well, ask this lady that lost her job in New Hampshire.

### Scientific Advocate (SA)
Claim: Okay. Now, listen, Jim. If you're going to find one case of one person who loses their job and say, “We should abolish the minimum wage,” you're nuts.

### Conspiracy Advocate (CA)
Claim: No, there's--

### Scientific Advocate (SA)
Claim: It's that simple. I mean, it-- And I am not-- I am not saying-- I am not saying you can't find that lady. In fact, the research--

### Conspiracy Advocate (CA)
Claim: There's 3.4 million--

### Scientific Advocate (SA)
Claim: I agreed with Russ that the research shows there are small negative impacts from some studies. Some studies show small positive impacts.

### Moderator
Claim: Russell Roberts.

### Conspiracy Advocate (CA)
Claim: Yeah. And--

### Moderator
Claim: Well, to Jim, you were the one who was called nuts. Do you want to--

### Conspiracy Advocate (CA)
Claim: Yeah. I'll let Jim go first.

### Conspiracy Advocate (CA)
Claim: Yeah. I don't believe in ad hominem attacks. Obviously, it's an example. But--

### Scientific Advocate (SA)
Claim: But I like you.

### Conspiracy Advocate (CA)
Claim: --a personal example, it's something other than just a raw statistic. It's a human being. People should be free to choose. That's-- it's a free country. The government shouldn't be involved in this. It's--

### Moderator
Claim: Okay. And I'm going to--

### Conspiracy Advocate (CA)
Claim: --if the government--

### Moderator
Claim: --go to Russell-- okay? I'm only interrupting because you--

### Conspiracy Advocate (CA)
Claim: --wasn't involved, would we go down the--

### Moderator
Claim: --you have made that point--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: --and I want to--

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: --let Russell--

### Conspiracy Advocate (CA)
Claim: Yeah. I just want to say-- yeah, there's one person New Hampshire, and there's another 3.4 million who are younger than that friend of Jim's who don't have jobs right now, who want them, who aren't able to support their family and aren't able to get the meaningfulness out of life that a real job helps you achieve. Thank you for the applause, but you're not supposed to do that. Now, so I think, again, ask-- Jared makes a good point. Most minimum wage workers think it's a good thing. They won't if they lose their jobs, though. They're not experts in economics. They're not experts on thinking about how their businesses might respond. We're here to have a discussion and to think about these ideas. And again, ask yourself-- ask for your children, those of you who have children, would you want your child to go out into the workforce being only told they can only get a job if they can make at least $15 an hour or $20 an hour, or 25? $7.25, it turns out, not such a big hurdle, because 80 percent of teenagers are able to earn that anyway on top of it. So again, I would make the point, the minimum wage right now is fairly small and not as harmful as it would be if we raised it, for example, so we-- that is true. It's fairly small, but it's not small for the people whose lives are affected.

### Moderator
Claim: Karen, very quickly, because I want to go to questions. So, right after Karen speaks, you can start raising your hands. We'll bring mics to you. Karen.

### Scientific Advocate (SA)
Claim: Okay. So, I just-- sorry, Russ.

### Moderator
Claim: Karen Kornbluh.

### Scientific Advocate (SA)
Claim: But you did just undermine your point completely--

### Conspiracy Advocate (CA)
Claim: Great--

### Scientific Advocate (SA)
Claim: --because you just said that the current minimum wage is not creating problems. Your position is to abolish the minimum wage. Where our-- it's not-- the question on the table is not whether to raise the minimum wage, it's whether to get rid of it entirely at its current, low rate.

### Conspiracy Advocate (CA)
Claim: You're not quoting me quite accurately. I didn't say it wasn't causing any problems. I said the problems are relatively small and they're hard to measure. And as a result, it's relatively pleasant for most people because 95 percent of the people don't need it who aren't in the hourly-- who earn an hourly wage.

### Scientific Advocate (SA)
Claim: I just think that we have to be really, really careful. I mean, you guys have tossed around a lot of studies. I think if we know that at our current low minimum wage, we are not causing problems, why on earth, because of some abstract notion or some theory about economics that's not proven in the empirical literature, do we want to subject low income families to an experiment of throwing out minimum wage which is a support for them and their families?

### Conspiracy Advocate (CA)
Claim: Because every worker who earns-- whose productivity is under $7.25 an hour right now is having a very difficult time making their way in the world, especially young workers.

### Scientific Advocate (SA)
Claim: So that gets to the heart of the theory where I think Russ and Jim go wrong. What you just heard from Russ is a standard econ 101 theory, which is, workers are paid their marginal product. They are paid what they contribute to their firm's value at the margin. Now, if you believe that, you know very little about the actual labor market.

### Moderator
Claim: Let's go to some questions. Ma'am, right in the middle there. So a mic will come to you down this side, and if you could just tell us who you are. I was going to stay stand up, because often we televise, but the-- we can't see you stand up on radio so it doesn't matter. And remember, make it terse and questioning.

### Moderator
Claim: I was actually wondering--

### Moderator
Claim: Wrong word.

### Moderator
Claim: My name is Emmy. I was wondering if you-- if both sides could speak to what role ballooning tuition costs, particularly for college and university, play in this debate? Do we abolish the minimum wage when you consider that you have a workforce that has an increasing amount of debt as they enter initially into the work force, assuming they take on college or university education?

### Moderator
Claim: Okay. Does that change your argument at all, that issue? I'm going to the side that's arguing for abolishing.

### Conspiracy Advocate (CA)
Claim: I guess what she's saying is that you have to have a minimum wage for all these college graduates that can't get jobs. Well, they won't get a job if the minimum wage is above the market wage.

### Conspiracy Advocate (CA)
Claim: I would have a slightly different perspective on this.

### Moderator
Claim: Russ Roberts.

### Conspiracy Advocate (CA)
Claim: I think part of the problem we have with education right now is that we've subsidized it, which is a lovely idea. And as a result, it's pushed up tuition, and it's allowed colleges to raise their prices, their tuition a great deal. And as a result, many students have borrowed have a lot of money. And as a result, they're in big trouble. And especially in a downtime of economic growth when economic growth is so mediocre.

### Moderator
Claim: Okay. I just-- it's getting a little bit off the minimum wage issue. Fair enough? But that's why I stopped you. Karen Kornbluh to respond.

### Scientific Advocate (SA)
Claim: Yeah, I do think this is really tied to the minimum wage issue because we have to remember that we live in a knowledge economy. And a country's human capital is what it competes on. And so what we need to do to be competitive, to have productivity, to have the American dream again, to have people earning high wages and being able to support their families is investing in people's education. And so we have a big problem in this country in terms of K-12, and we have a big problem in terms of--

### Moderator
Claim: Okay, for the same reason, Karen--

### Scientific Advocate (SA)
Claim: That's what we should adjust and not the minimum wage.

### Moderator
Claim: All right. I'm going to step in. But your opponents made the very same argument at the beginning. And I was surprised when you said that you had the moral argument on their side because they were not saying "damn the poor" in any way. They were saying that they feel that the tool, the minimum wage, doesn't function correctly. And I've been wanting to get to that moral argument, but I was hoping somebody in the audience would actually bring it up.

### Scientific Advocate (SA)
Claim: Oh, no. So what I was saying is that I think the moral argument is on our side because those families need the minimum wage to support their kids. What they were saying is that somehow the minimum wage hurts those families and keeps them out of the workplace. I think the way you deal with people who are out of the workplace is you get education and training.

### Moderator
Claim: Okay. But they're saying the same thing.

### Scientific Advocate (SA)
Claim: They're saying they care about the same people, but they're saying that the minimum wage hurts them. I'm saying the minimum wage helps them.

### Moderator
Claim: Okay. Right again in the center. I know that's a pain with the microphone. I'll go to the wings after this. But you win. So the mic's coming to you. Just wait for it so that the radio broadcast can hear you. Oh, I'm sorry. You don't know who I'm talking about, do you? Obviously. You can stand up. Don't-- because I'm making eye contact. Then the microphone will find you. There it is. Great.

### Moderator
Claim: Hi. I'm a business owner in--

### Moderator
Claim: Can you bring the mic--

### Moderator
Claim: Hi. I'm a business owner in Washington, D.C. where the minimum wage is $8.25 an hour. And I love the idea of worker freedom. When I think of one of my workers living in Washington, D.C., on roughly $16,000 a year, they didn't take much in vacation, they'd have the freedom to choose, say, between rent or food or, you know, maybe healthcare.

So my question goes to the notion of a living wage. If we don't pay our workers a living wage, then what we're asking is for the rest of the population to subsidize our businesses to bring those people up to a level where they can survive. And I'd just like the--

### Moderator
Claim: the taxpayer, you mean, yeah.

Okay. The side arguing to abolish.

### Conspiracy Advocate (CA)
Claim: The living wage isn't by the taxpayer. I think it's usually a proposal to just have a higher minimum wage that would be able to support a family more easily. What kind of business do you have? I'll repeat it for those-- since you have the mic.

### Moderator
Claim: I have a consulting business.

### Conspiracy Advocate (CA)
Claim: You have a consulting business. And your workers are paid-- you said you have some that are paid $8.25 an hour?

### Moderator
Claim: No, I said that's the minimum wage in Washington, D.C.

### Conspiracy Advocate (CA)
Claim: So none of your workers earn the minimum wage.

### Moderator
Claim: No.

### Conspiracy Advocate (CA)
Claim: No. There are some who do, though, and that's very hard on them, and that's no doubt about it. Right now there's a proposal with the city council of Washington to increase the minimum wage for special stores that have large footprints. This would be stores like Costco and Home Depot and super Wal-Mart. There are very few of those in Washington, D.C. But they want to raise it to 11-something an hour. The Washington Post came out the other day and said it's a horrible idea because Costco will leave. They won't be able to make a living, unfortunately. They have a lot of profit, but at $11.25, it's not clear they'll be able to keep that store in Washington. And The Washington Post thinks that's a bad idea. I do too. I think it's a bad idea to-- especially to pick out special stores.

### Conspiracy Advocate (CA)
Claim: What?

### Moderator
Claim: Ma'am, I need you to not debate with the debaters. But the question--

### Conspiracy Advocate (CA)
Claim: Sorry.

### Moderator
Claim: That's okay, no.

### Conspiracy Advocate (CA)
Claim: Afterwards, I'm happy to talk some more.

### Moderator
Claim: I want Jared Bernstein to debate with the debaters. Jared Bernstein.

### Scientific Advocate (SA)
Claim: Thank you. If-- first of all, again, these are empirical questions. If I communicate nothing to you tonight, that would be the thing that I'd want to leave you with. You can't make the assumptions that our opposition does about what happens with living wages or minimum wages.

And this has been studied, again, fairly carefully, not as much as minimum wages, but living wages have not been found to have the distortionary effects that Russ suggested. I do think the questioner gets into a very important point that we haven't touched on yet. If you abolish the minimum wage, and it falls a lot-- because by the way, if it doesn't fall a lot, then it can't possibly have the problems that they're suggesting. That was the point Karen made. But if you abolish the minimum wage, and it falls a lot, you will collect fewer payroll taxes. You will have to pay more in food stamps. You will have to pay more in unemployment insurance. You have to pay more in welfare benefits. And it is very much a transfer of the burden of poverty to the taxpayer in ways that minimum wages and living wages help to mitigate.

### Moderator
Claim: Jim Dorn. Jim Dorn.

### Conspiracy Advocate (CA)
Claim: Well, I would take just the opposite position. The American dream for most of our grandparents and maybe some of our parents and so forth, was to come to the United States from countries that had repression and so forth. There were no minimum wages. They could get a job. They learned how to speak English. They got on-the-job training, and their families were made better off over time. Immigrants coming over here now, if they're low skilled, they're not going to have that opportunity. And teenage workers without a high school degree that might be going to work and getting a job, these people aren't going to get jobs. The Card-Krueger study did not-- did not look at people that actually lost their jobs from smaller establishments. It was-- they did a survive on franchise restaurants. And they didn't take into account the people that actually lost their jobs. Now, these marginal firms don't make a lot of profits. They're making a normal return on investment over the longer period of time. And if they have to pay a higher wage rate, they're going to either fire some workers, or they're going to have less to reinvest in the firm to expand it. Other workers who-- sure, some workers gain, they keep their job, but other workers will lose their job and either go in the shadow economy or eventually end up on welfare maybe.

So I want more opportunities for workers. And the government, just by saying you're going to pay a higher wage, as if there's no effects, is nonsense. It's like the law of gravity. The law of gravity operates even though leaves may blow up in the wind. The law of demand operates. And when prices go up, people buy less, especially in the long run when they make substitutions. It's just common sense.

### Moderator
Claim: Let me interrupt you to go to a question down here. What does this body language say? You can kind of lean back and--

### Conspiracy Advocate (CA)
Claim: I'm comfortable. I don't see any fruit. I hear the applause, but I don't see any fruit, so I'm feeling pretty good.

### Moderator
Claim: All right, good. Sir.

### Moderator
Claim: If the goal of the minimum wage is to help low-income earners, which everyone, I believe on both sides has said is a laudable goal, should we as a society make an effort to make that more direct and clear and increase something like the earned income tax credit and make the transfer of wealth direct and clear.

### Moderator
Claim: For people who don't know what the earned income tax credit is, take one sentence to explain what it does.

### Moderator
Claim: I believe it is something with, when you have a job, and you have income, you get money back on taxes.

### Moderator
Claim: Okay, if you're below a certain--

### Moderator
Claim: Threshold.

### Moderator
Claim: --level of income, okay. Let's take that to Karen Kornbluh first, then we'll come back to this side.

### Scientific Advocate (SA)
Claim: Yeah, the earned income tax credit is a terrific thing. It's for workers who are low income, but I'd say two things about the earned income tax credit. One is we're debating our budget deficit, and I think we just have to be realistic. I'm not sure we're going to increase the earned income tax credit dramatically right now. And I don't think we want to get rid of the minimum wage and rely on that. Secondly, I do think there are a lot of people who just want to earn a living. You know, they may appreciate the extra help from the earned income tax credit, but they would like to work for a salary that allows them to support their families. And so I don't think we should underestimate how much people want to get their living from their job.

### Conspiracy Advocate (CA)
Claim: I would just say there are a lot of policies I would prefer to the minimum wage. The earned income tax credit is preferable to the minimum wage. Improving our school system is preferable to the minimum wage. And I certainly agree with Karen that people like to stand on their own two feet, and I would emphasize, once again, that the minimum wage makes it harder, not easier.

### Moderator
Claim: We're in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, arguing out this motion, "Abolish the minimum wage." Right down front here. The mic is coming up from behind you.

### Moderator
Claim: It-- my name is Daniel. It seems like the pro side is arguing that with no minimum wage it's better for the entire economic system, but I wonder, without a minimum wage, where you have an environment where people can make 50 cents, $1, $1.50 an hour, if that could lead to other economic problems like poverty, which could lead to increased crime?

### Moderator
Claim: Do you not feel that they've actually answered that question? I-- no, seriously. I don't want to take time on it if-- I-- to me, it's the crux of their whole argument answers your question, but if you would like to take it, either side?

### Moderator
Claim: They're saying it would--

### Moderator
Claim: I mean-- oh, go ahead.

No, no, I-- put to this side actually. James Dorn.

### Conspiracy Advocate (CA)
Claim: I think most establishments already pay more than the minimum wage. And if the-- if the wage rate dropped for some workers, the lowest of the lower skilled workers, yeah, their wage rate may go down in the short run, but they'll have a job. And their wage rate's not going to stay at a low level forever if they work hard. That's the point. You're pricing these-- the politicians are pricing these people out of the market in the name of doing good. It's a feel-good policy, and the empirical evidence-- the preponderance of empirical evidence supports the idea that raising the wage rate arbitrarily will reduce jobs more so in the long run. There's just a ton of evidence. So it's not just based on the evidence, it's based on common sense, and just looking-- observing reality. You--

### Scientific Advocate (SA)
Claim: I'm sorry. You've got to look at the evidence, and we-- the planners of today's event, I think wisely, decided we shouldn't use PowerPoint. That's a-- that's too bad in an evidentiary but I support--

### Moderator
Claim: That's because they were trying to be funny.

### Scientific Advocate (SA)
Claim: And it's the radio, too, you know? Graphs don't work as well on the radio. But what I have here in front of me is a graph that I'll show to anybody afterwards and-- that just frankly contradicts this notion that particularly Jim but Jim and Russ have hit on all night, common sense, common sense-- no. It's not common sense because there are lots of different ways. And I articulated them. You mistakenly said, "These guys think nothing happens when you raise the minimum wage." I gave you three good Ps as to the different things that happen. So the dynamics of the economy are such that the questioner is exactly right. You would not find a great deal of increased employment because the minimum wage is not currently a disemploying mechanism within the economy, but what you would find is a ton more poverty.

And you have to consider this in the context of the EITC, Mr. Questioner over there, because if you take a minimum wage that's $7 an hour and you apply a 40 percent EITC to it, you're adding $2.80.

### Moderator
Claim: You know, again, please don't use the term "EITC."

### Scientific Advocate (SA)
Claim: Oh, the Earned Income Tax Credit, a wage subsidy for low wage workers, if you apply the current wage subsidy to a $7 minimum wage hour, it's 40 percent at the max, that's $2.80. Apply that to a $3 wage, which may be where it's going to fall-- Russ doesn't know, but it could be. Now you're talking about one-twenty-- $1.20 subsidy to that wage. So it's a $2.80 subsidy at the current minimum wage level. If that falls by half then the subsidy falls by half.

### Moderator
Claim: All right. I want to go to another question, way up on top. Sir, if you stand up, again, you'll be seen-- there you go.

### Moderator
Claim: So if-- I know we're on radio, but if you could imagine a graph that shows the distribution of what wages would be without a minimum wage, my guess would be the $7 or $8 minimum wage is close to the low end and that most people would make more than that in the absence of a minimum wage. So if that's the case, then changes to the minimum wage are going to not have much effect, because most people are above that. So the thought experiment would be if the minimum wage were, say, $0.50 an hour, and we're talking about abolishing it, I guess we would probably agree that that would have no effect, because--

### Moderator
Claim: Okay.

### Moderator
Claim: --no one would be making that wage.

### Moderator
Claim: I need you to zero in on the question.

### Moderator
Claim: So, the question really is is that-- do you-- do both have to believe that's the case, so that we're at a level where it's kind of irrelevant whether it's there or not? And that if it were much higher, if it were $20 an hour, $25 an hour, where most people are making more, would we actually be at a point where the-- where it's relevant and abolishing it or not would make a difference.

### Moderator
Claim: So, is your question this: are we at a level, if the current minimum wage is $7.25 an hour, that it's so low that abolishing the minimum wage would not actually affect--

### Moderator
Claim: Well, I'm not saying--

### Moderator
Claim: --what most people are making?

### Moderator
Claim: --that it would have no effect, but it has minimal--

### Moderator
Claim: Little.

### Moderator
Claim: --effect, right because it's close to where the minimum would be. And so, the

### Moderator
Claim: All right. Let me go to Russell. Well, do you want to go first? Karen Kornbluh.

### Scientific Advocate (SA)
Claim: One quick thing. We think that the minimum wage also affects those who earn just above the minimum wage, that it props up wages just above. So if you look at the people who earn at the minimum wage or just above, as I said at the beginning, we have one quarter of all children in the U.S., more than 17 million kids, who have a parent who earns at the minimum wage or just above who we think would be affected.

### Conspiracy Advocate (CA)
Claim: Well, I agree. It does--

### Moderator
Claim: Russell Roberts.

### Conspiracy Advocate (CA)
Claim: --prop up the minimum wage for-- and it has a bigger effect on the people who just earned it. And that's part of the reason why Wal-Mart, which pays more than the minimum wage, favors the minimum wage, because it makes their competitors more expensive. It raises the cost to other firms that are smaller and won't-- can't afford to pay as much as Wal-Mart does. So, I agree with the questioner, though.

The level is relatively small, which means it's hard to measure. And the harm is relatively small. But as I started off by saying, for the people who can't find work, it's not small. For the people who aren't worth it, it's very tragic.

### Moderator
Claim: One more question. All right. Sir?

### Moderator
Claim: Hi. My name is Charlie Edelman Risking oversimplification--

### Moderator
Claim: That's our mission here.

### Moderator
Claim: --it seems to me that the side arguing for the motion is arguing in favor of workers' individual freedom. The side arguing against is arguing for government protection. What elements of the minimum wage debate, isolated from arguments against hours working on the job versus overtime, healthcare benefits, you know, what elements of this debate make it unique, compared to other labor versus business arguments?

### Moderator
Claim: That's a really good question. That's really good. In other words, are we just having the same old argument over and over again? Is this just libertarian versus progressive government argument or is there something else going on, in terms of the minimum wage? Is that what you're saying?

### Moderator
Claim: Exactly.

### Moderator
Claim: All right. It's a really interesting question, actually. Who would like to take that on first? James Dorn.

### Conspiracy Advocate (CA)
Claim: Well, with the minimum wage, there are only so many jobs to go around. It's the old lump of labor fallacy since the wage rate is not allowed to go down if there's a surplus. So you're stuck. And the employers have a lot more power to dictate certain things to workers. They would have more flexibility and more freedom for both the employers and the workers if you got rid of the minimum wage. And I think if you got rid of it, the wage rate wouldn't change that much, because we're pretty close to the-- where the market wage rate would be. That's why politicians don't have large increases in the minimum wage. They can get the political brownie points, a feel-good policy, where most people think that the minimum wage is a good thing. That's why they don't increase it by a lot. When they have increased it by a lot, for example, in New York State, the study that was done-- I pointed to earlier-- it led to fairly significant decrease in employment. It is-- also the empirical evidence, it's just not common sense.

There's a lot of empirical evidence on our side of the argument. So, I think Jared is unfair to mention that-- he doesn't mention anything about this most recent NBER study, which is much more sophisticated than the John Smith study that they like to cite.

### Moderator
Claim: Jared Bernstein, the guy you called “nuts” just said you're unfair.

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: So you're even now.

### Scientific Advocate (SA)
Claim: Ad hominem attack!

### Moderator
Claim: You're even now.

### Scientific Advocate (SA)
Claim: Look.

### Moderator
Claim: Jared Bernstein.

### Scientific Advocate (SA)
Claim: I find the other side's argument on this point just horribly muddled. I'm echoing something Karen said earlier. I just don't get it-- I'm not trying to be cute here. I really don't get the logic that says-- it certainly relates to the last question. It's really a small deal. It doesn't really affect many people. But dammit it should be abolished, because it's a big problem and it causes all this unemployment. And you’ve heard them all night, talk about the damaging unemployment effects of the minimum wage. Yet somehow, it's-- at the same time, this de minimis policy. Those both can't be right. They're logically inconsistent.

And I think the reason-- getting to the question, and it was a good question, to me, it's Congress's way of saying, “We're not going to let the market drive wages down on our lowest-wage workers to privation-level wages. We don't want to be Hong Kong. We don't want to be Mexico. We don't want to slide down the”-- In economics terms, we don't want to slide down the demand curve the way our opponents would like us to. Now, the reason to think that's a bad idea is if it has the negative job loss effects, if it actually distorts the economy in ways that our opponents worry about and claim.

### Moderator
Claim: Let me let Russell Roberts--

### Scientific Advocate (SA)
Claim: But research says it does not.

### Moderator
Claim: Russell Roberts.

### Conspiracy Advocate (CA)
Claim: So horribly muddled, that's in between, I guess, nuts and unfair. It's not too bad. There's a subtlety here, and it's a nice rhetorical flourish here. But I think the argument is that when we say it's relatively small, we're not saying it's unimportant, we're saying it's difficult to measure.

It's difficult to tease out the independent effects when many things are happening at the same time. So as a result, when some states are doing well, they raise the minimum wage, and therefore it's hard to figure out what the independent effect is of what's going on underneath. But my question for you is, since you reject the logic that we made, and you say it's only an empirical question, I'd like to know why you think employers over the last 30 years have relentlessly punished not deliberately, but through their actions, have relentlessly punished low-skilled workers because they are relatively unattractive compared to workers outside the United States and automation. Do you really think that work-- that employers don't respond to economic incentives?

### Scientific Advocate (SA)
Claim: Employers have not consistently punished--

### Moderator
Claim: Jared Bernstein.

### Scientific Advocate (SA)
Claim: Oh, sorry. Did you want--

### Moderator
Claim: No, I'm just doing this for the radio so--

### Scientific Advocate (SA)
Claim: Sure, yeah.

### Moderator
Claim: --they know who's talking.

### Scientific Advocate (SA)
Claim: Sorry. Thank you.

### Moderator
Claim: Jared Bernstein. Jared Bernstein.

I need to say it when they're not laughing, and when we're not talking.

### Scientific Advocate (SA)
Claim: I'm going to hear that in my head now for the next week.

### Moderator
Claim: I’ll say it one more time. Jared Bernstein.

### Scientific Advocate (SA)
Claim: Did he say that, or I just--

Employers have not relentlessly punished low-wage workers. In fact, in the 1990s, a period when the minimum wage was increased in 1996, the unemployment rate among low-wage workers fell to the lowest it had been in 30 years. The national unemployment rate fell below 4 percent. That was the time of welfare reform. And hundreds of thousands of low-wage, poorly-educated single moms came off welfare, got into the labor market. And with the complimentary boost of the minimum wage and a higher EITC, poverty rates fell very steeply. So, you know, I think you're fundamentally wrong. I'll tell you why employers fight against the minimum wage, because it cuts into their profits.

### Moderator
Claim: And that concludes Round 2 of this Intelligence Squared U.S. debate where our motion is “Abolish the minimum wage.”

## Round 3

### Moderator
Claim: And here's where we are. We are about to hear brief closing statements from each debater in turn. They will be two minutes each. This is their last chance to try to change your minds. Remember, you voted before the debate.

You will be asked to vote again after closing statements. And the team whose numbers have changed the most in percentage terms will be declared the winner. Onto Round 3, closing statements from each debater in turn. Our motion is "Abolish the minimum wage." And here to summarize his position against the motion, Jared Bernstein, a senior fellow at the center-- Jared, you can do this one sitting down. That's okay. I've-- let me finish my introduction of you. Jared Bernstein.

Let me finish the introduction. Jared Bernstein, a senior fellow at the Center on Budget and Policy Priorities.

### Scientific Advocate (SA)
Claim: For my closing statement, I'd like to get away from the dueling studies and statistics which I'm sorry we have assailed you with, and I apologize to my friends on the other side if I got a little rambunctious. I clearly feel this passionately. But I'd like to get away from that, and I'd like to bring a bunch of other people up here on the stage with me, so to speak.

The almost 90 percent of Americans earning less than $24,000 a year who support raising the minimum wage, okay? I don't hear an argument from the other side as to why they're wrong and to why they would support, in the interests of their freedom, abolishing a minimum wage that 90 percent of them support. 80 percent of Americans between 18 and 30 support raising the minimum wage. Ten to one among unemployed workers support raising the minimum wage, ten to one. Now, earlier Russ said something about nobody's mind being changed. That's actually not true. It's true that a lot of people's minds don't get changed. But in fact, this research that we've been talking about, particularly these experimental designs where you can really make pretty fine granular comparisons have changed some minds. The Economist magazine now supports increasing the minimum wage. They didn't used to. Bloomberg News, Cranes New-- Cranes New York business is very much a business, a journal; the Costco CEO, the Starbucks CEO, even Mitt Romney.

Mitt Romney, during the Republican said we should index the minimum wage to inflation, not abolish it, index to-- which by the way makes sense from-- I think he was speaking like a business guy. What you don't want to see is these surprise increases along the way. You'd like to see it indexed. And that, by the way, is part of the president's proposal. So, yes, raise the minimum wage, index the minimum wage. Vote against-- vote no on abolishing the minimum wage. It is a cruel, far out of the mainstream idea whose time has not come and never will.

### Moderator
Claim: Thank you, Jared Bernstein. Our motion is Abolish the minimum wage,” and here to summarize his position in support of this motion to abolish, Russell Roberts, a research fellow at the Hoover Institution.

### Conspiracy Advocate (CA)
Claim: In September of 2011, the governor of American Samoa traveled 7,000 miles to testify for five minutes in front of Congress. He begged Congress to stop increasing the minimum wage in American Samoa, a process that had begun in 2007 and was scheduled to increase until it reached the U.S. minimum of $7.25. In 2009, employment on American Samoa fell 19 percent. That's because employment in the tuna canning industry, which was a third of their jobs, had fallen 55 percent. The governor of American Samoa who came to testify blamed that collapse on the minimum wage. And here's a quote from him, his testimony, "We are watching our economy burn down. We know what to do to stop it. We need to bring the aggressive wage cost decreed by the federal government under control. Our job market is being torched, our businesses are being depressed. Our question is this: How much does our government expect us to suffer?” I have the same question for those two support the minimum wage here in the United States. How much do you expect the least skilled among us to suffer? Congress did stop increasing the minimum wage in American Samoa, thank goodness.

They should have the same compassion for workers here in the United States and abolish the minimum wage here. Right now, there are people within a few blocks of where we're sitting who cannot find work simply because their skills are not worth $7.25 an hour. Why would you condemn those men and women to a wage of zero? Why would you cut off the bottom of the economic ladder and deprive a human being of the chance to begin a life of honest work? There are desperate people among us, people who have nowhere to turn, whose job prospects are poor. Why make their lives worse? It's not just about the money. It's about giving people a chance to find meaning and satisfaction from standing on their own two feet. Give the least skilled among us the chance they deserve. Abolish the minimum wage.

### Moderator
Claim: Thank you, Russell Roberts. Our motion is "Abolish the minimum wage,” and here to speak against the motion to abolish, Karen Kornbluh. She is the former U.S. ambassador to the Organization for Economic Cooperation and Development.

### Scientific Advocate (SA)
Claim: Thanks so much, John. Thanks for moderating this. I want to say a few things. One, abolishing the minimum wage would hurt real people and real kids. A third of those who would be hurt are parents. One-tenth are single parents. More women than men would be hurt; 55 percent of those who benefit from the minimum wage are female. The average minimum wage worker contributes fully half of her or his household's entire income. Minimum wage laws do not seem to affect employment very much. Studies suggest that other factors, such as the overall state of the economy, how local industries are doing, matter a lot more for employment than the level of the minimum wage does. Several states have minimum wages above the federal minimum. There are no signs that the higher rates lead to higher unemployment. Abolishing the minimum wage would hurt inequality, it would make it worse. And it would hurt social mobility. It would make it harder for children of low-income families to get ahead.

This is very personal for me. My grandmother was a single parent. She raised four kids. Fortunately, she had the minimum wage. At that point, it had become the law of the land. And she was able to send her kids to school. I'd like the single mom of today to have the opportunity to keep her family together, get her kids through school. We should restore the American dream. We should not undermine it. We should not abolish the minimum wage.

### Moderator
Claim: Thank you, Karen Kornbluh. That's our motion, "Abolish the minimum wage." And here to summarize his position in support of the motion to abolish, James Dorn, vice president for academic affairs at the Cato Institute.

### Conspiracy Advocate (CA)
Claim: Markets don't lead to privation; markets lead to prosperity. Historical evidence shows this. A Mexican immigrant came over to the United States not too long ago. He couldn't get a job because he was illegal probably.

But he did get a job eventually in San Francisco at below minimum wage at a Chinese laundry. He worked there for a couple years, then he went to Georgia. He worked in the slaughter house at a little bit higher wage rate. And now he owns a chain of Mexican restaurants in Georgia. He had a dynamic and had a dream to come here to find an opportunity. If he would've obeyed the law and the employer obeyed the law, he would've never had that opportunity. A friend of mine was making $0.72 an hour when he first started work. That was his first job. He rose up and became a very, very successful businessman. He said that first job gave him work habits and a lifelong dream of basically being his own boss, making his own decisions, not relying on the government to increase his wage. The minimum wage decreases opportunities for low skilled workers in low income families. We need to abolish the minimum wage, not increase it. There's a better way to help the poor than the minimum wage.

### Moderator
Claim: Thank you, and that concludes our closing statements and Round 3 of this debate, and now it's time to learn which side you feel argued the best. We're going to ask you again to go to the keypads at your seat to register your vote. We're going to get the readout on this almost instantaneously. Reminding you, if you're for this side, you push number one. If you are for abolishing the minimum wage, you push number one. If you are against, push number two. And if you became or remain undecided, push number three. And you can ignore all of the other keys, and just correct an incorrect vote, and it'll be-- it'll lock in your last vote. So again, it looks like that worked really well. So I just want to say a couple of things. First of all, just the quality of the debate that we heard here tonight, you know, I-- you know, any jokes about oversimplification aside, the fact is that what we aspire to at Intelligence Squared is actually a fair, and nuanced, and intelligent debate.

And I really have to congratulate these debaters for bringing that tonight. I want to applaud both sides. It didn't-- it did not get ad hominem, and it was really very respectful, and it actually is clear that you all know and like each other. So we appreciate that you did that. Also, for those of you in the audience who asked questions, there was not a clunker question, and there were some really excellent ones, so I want to thank you as well for those questions. I also would like to thank WAMU for partnering with us on this debate, and definitely you'll be able to hear this debate and several of our other ones coming up on WAMU throughout the season. We'd like you to tweet about this debate, as I said, at the beginning. Our twitter handle is @IQ2US, and the hashtag for this debate is #minimum wage. Our next debate will be-- we'll be back in New York on Wednesday, April 17. The motion is this, "The GOP must seize the center or die." everybody jump on a plane now.

### Moderator
Claim: Sorry? You want to come back, and I'll debate that one as well? Arguing in support of the motion for the GOP to reconfigure is David Brooks, an op-ed columnist for the New York Times; Mickey Edwards, a former Republican Congressman from Oklahoma. Arguing against that motion, Laura Ingraham, host of the "Laura Ingraham Show"; and Ralph Reed, chairman and founder of Faith and Freedom Coalition. We will-- I'm happy to-- very happy to say that we will be back in Washington next month actually. Thank you. And in that case we'll be doing a partnership with the McCain Institute for International Leadership. McCain Institute has been running a series of terrific debates and discussions for the last several months. And we are hugely honored to be partnering with them on that. The motion in that case-- we're going to be looking at the issue of how spending cuts will affect national security. We're doing it on the 22nd of May, and the motion language is this, "Cutting the Pentagon's budget is a gift to our enemies."If you would like to hear more about our future debates, and if you'd like to throw ideas at us, we are very open to them, our website is www.IQ2US.org. If you can't watch live, of course, I've mentioned WAMU NPR stations across the nation. We have a podcast. Our New York debates are live streamed on FORA.tv and broadcast on PBS stations across the nation, so you can check for listings on-- airtimes-- dates and airtimes on that. Jared Bernstein. No. I think I'm the one that's going to hear it. All right. We have asked you to vote twice on this motion, "Abolish the minimum wage." You have heard the arguments. You have voted twice. The team that has changed the most of your minds in terms of percentage points moved will be declared our winner. Here are the results of the preliminary vote.

Before the debate on "Abolish the minimum wage," 21 percent were for the motion, for abolishing the minimum wage; 58 percent were against; 21 percent were undecided. Those are the first results. Now the second results-- we're going to go first to the team that is arguing for the motion. Their second vote is 26 percent. That went from 21 percent to 26 percent. They picked up 5 percentage points. That's the number to beat. The team against the motion, their first vote was 58 percent. The second vote was 67 percent. They went up 9 percentage points. That's enough to make them the winner. The team arguing to abolish the minimum-- the team arguing against the motion to abolish the minimum wage has been declared our winner. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
