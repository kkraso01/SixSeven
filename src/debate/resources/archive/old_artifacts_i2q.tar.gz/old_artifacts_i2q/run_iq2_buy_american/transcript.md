# Debate Transcript

Topic: Buy American/Hire American Policies Will Backfire
Motion: Buy American/Hire American Policies Will Backfire

Debate ID: buy-american


## Round 1

### Moderator
Claim: Well, thank you all for coming. This is really exciting for us. This is a new venue, and it’s thrilling for us to be downtown in such magnificent space as this one. We have, of course, our new voting system which may have some flaws to iron out. We have a new relationship with Bloomberg Television that’s going to be televising these debates in addition to our longstanding relationship with National Public Radio, where these debates are heard in nearly two hundred radio markets around the country. We have a new relationship with Newsweek magazine that’s going to be publishing a Point/Counterpoint of what Rosenkranz Foundation-Intelligence Squared U.S. goes on this evening. So my role in these proceedings is really to frame the debate, to say why it is we thought this was an interesting topic and why there’s a reasonable amount to be said on both sides. So, as taxpayers, Americans have funded about seven hundred and fifty billion dollars for the stimulus package, another seven hundred and fifty billion or more for TARP, to relieve the situation for financial institutions.

And at a time of record unemployment doesn’t it make sense that these funds are used to the maximum extent possible to create jobs for Americans? Why not require that the institutions that receive this money hire American workers? Why not, that the state governments and others who are expending these funds buy American products? But let’s consider second order consequences. If we protect high cost domestic producers there’s a cost to that in the form of higher prices for everyone else-- every consumer, every state and local government. And then think about the third order effects – the reactions of foreign governments. We impose a tax, a tariff on tires, the Chinese retaliate with a tariff on chickens-- real world example of the last week or so. Well, which of these is most important-- the immediate benefit of U.S. job creation or the cost to U.S. consumers and the risk of retaliatory response from our trading partners? The future of the global Rosenkranz Foundation-Intelligence Squared U.S. economy may depend on getting the answer right and we have an extraordinarily able group of panelists this evening who I think are going to shed some light on this important issue and it’s my pleasure at this point to turn the evening over to John Donvan.

### Moderator
Claim: Thank you, Robert, very much. And this is the beginning of our fourth season and Robert Rosenkranz is why this is happening. So on this evening I just want to invite one more round of applause for Robert Rosenkranz. Welcome to another debate from Intelligence Squared U.S. I’m John Donvan and I will be moderating the six people you see here on the stage with me at the Skirball Center for the Performing Arts at New York University. We have two tables, six debaters, three against three.

We’ll be debating this motion: Buy American/Hire American Policies Will Backfire. And here, our debaters arguing for the motion that Buy American/Hire American Policies Will Backfire, Jagdish Bhagwati, University Professor, Economics and Law at Columbia University; Douglas Irwin, Professor of Economics at Dartmouth College; and Susan Schwab, former United States Trade Representative. Arguing against the motion we Rosenkranz Foundation-Intelligence Squared U.S. have Leo Gerard, International President of the United Steel Workers; John R. MacArthur, President and Publisher of Harper’s magazine; Jeff Madrick, Senior Fellow at the Schwartz Center for Economic Policy Analysis at the New School. Now, this is a debate so let’s remind ourselves of what the stakes are. There will be winners and losers tonight. This is a contest. This is a contest of ideas and persuasion and perhaps wit and humor, facts. But you in the audience play a crucial role in this contest because you are the judges. We are polling you both before and after the debate to establish where you stand on our motion. I will be reporting them in just a little while, once we’ve had the first results tabulated. But once again, to remind you, our motion is that Buy American/Hire American Policies Will Backfire and we would like now to go to our vote for the final time. If any of the members of the audience still would like another chance to vote, if you put your hands up I’ll know that the answer to that is yes. And it looks like no. So everybody has, everybody has voted. So the results are being tabulated. We will have you a vote once again at the end of the debate and the side that has changed the most minds, who has moved the largest percentage into their camp in the course of the evening will be declared our winner.

Rosenkranz Foundation-Intelligence Squared U.S. Let’s get to the debate. Speaking for the motion first, I’m sorry, I thought I had something out of the order. Speaking for the motion first, Douglas Irwin, a professor at Dartmouth College. Free Trade Under Fire is the title of his latest book and those four words will tell us why he is here to argue for the motion that Buy American/Hire American Policies Will Backfire. Douglas Irwin.

### Conspiracy Advocate (CA)
Claim: Well, I apologize if my voice is a little bit gravely but I used up most of it yesterday when I achieved a childhood dream of seeing the Green Bay Packers play at Lambeau Field. And I learned, aside from the fact that Green Bay can lose a game they’re supposed to win, I learned that you can get very funny faces on people’s faces when, very funny looks on people’s faces when you amble up to them in Green Bay and say, So what do you think of them Buy American provisions? It doesn’t, it doesn’t work so well. It’s a real conversation stopper. What I’d like to do is remind you of the proposition before you tonight and that is whether Buy American provisions will backfire. In fact, they’ve already backfired so you have little choice but to vote for the affirmative. First of all, what is Buy American? Buy American Rosenkranz Foundation-Intelligence Squared U.S. is a provision in federal legislation that mandates the purchase of U.S. made products in government contracts. Now, in some sense, who could be against Buy American? I want people to buy American products. I want a strong and healthy and vibrant American economy. I want good jobs and good wages for American workers. I think we can all agree on those propositions. But that’s not the issue. The debate here tonight is about the means to that laudable end. Buy America may sound like it’s a good idea, but the more you think about it, it’s actually counterproductive.

Let me give you a specific example of what Buy America is. In the economic stimulus bill that we talked about earlier, that John Donvan mentioned-- it was passed by Congress earlier this year-- one section requires the use of American made steel in all stimulus related construction projects unless it costs more than twenty-five percent above foreign suppliers. Now, this is a good deal for the American steel industry but it’s a bad deal for the rest of us. By raising the cost of construction projects our nation can afford fewer of those projects. That means fewer jobs will be created with the limited amount of money we have to spend. If we have to pay a twenty-five percent premium for steel that leaves less money for all the other projects. In fact, this is not a trivial matter.

Rosenkranz Foundation-Intelligence Squared U.S. Picture in your mind for a moment the Bay Bridge in San Francisco. There’s a lot of steel in that bridge. California had to repair the bridge a few years ago and the Buy America provisions were enforced. The domestic steel bid came in at, guess what?, twenty-three percent above the foreign bid. Now, why it wasn’t twenty-four percent above, I don’t know. But that added four hundred million dollars to the cost to repair the bridge. That’s almost half a billion dollars for one project. Now, what can you do with half a billion dollars? Instead of paying inflated prices for steel you could repair roads, build new bridges, build new schools, invest in green technology, provide health care for children or even perhaps reduce the fiscal deficit that is literally bankrupt... bankrupting the state of California. That’s more than just paying more and getting less. The real problem is this: Buy America is a bad jobs creation program. Steel is very capital intensive so when we increase production we don’t hire a lot of new workers.

There are about a hundred and fifty thousand steel workers in the United States. There are seven million construction workers. There are 1.5 million unemployed construction workers. Construction is really labor intensive. So if we spend more taxpayer money on steel we can afford fewer construction projects that will employ more construction workers who really Rosenkranz Foundation-Intelligence Squared U.S. need the jobs. So why do we give U.S. steel producers a twenty-five percent handicap against foreign suppliers and other bidders? Well, they were the only industry that was powerful enough to get it into law. It’s corporate welfare, pure and simple.

What percent of the steel sold in the United States is made in the United States? Seventy percent. They control seventy percent of the market and they want more and they want the taxpayer to pay for it. Buy America has already backfired because it creates bureaucratic red tape that has forced state and local governments to delay starting infrastructure projects and therefore, delay getting people back to work. In Perkins, Oklahoma they’re planning on building a new waste water plant for fifteen million dollars. It was shovel ready. The government came in to give them another 1.5 million in free stimulus money. But it wasn’t free. It came with Buy America and other pieces of red tape and it raised the cost of the project even more than the town would be getting from the federal government. So now the town has to go out and borrow more money to get the project going. And this is not an isolated example. Here’s a news article from last week’s Wall St. Journal how Buy America can hurt U.S. firms, and it talks about how, various ways in which U.S. firms cannot bid on Rosenkranz Foundation-Intelligence Squared U.S. municipal projects here in the United States because they may make components that are sent for final processing in Canada.

They come back from Canada, and it’s called a Canadian product even though a lot of the value added is made here in the United States. And that just doesn’t make sense. Many think that Buy America is aimed at China. Well, we aimed at China but we hit Canada and now we’re shooting ourselves in the foot. Canadian governments are boycotting U.S. firms in their infrastructure projects and costing us jobs here in the United States. So in sum, Buy America is not a good idea. It raises the cost of-- It sounds like a good idea but it’s not a good idea. It raises the cost of infrastructure projects. It pads the bottom line of the steel industry. It reduces the number of construction workers we can employ with our precious tax dollars and when other countries employ their own buy local provisions our exporters will be cut out of their lucrative market, those lucrative markets abroad and will lose even more manufacturing jobs here in the United States.

I’m sure you’ve heard of the saying, What’s good for GM is good for America. Well, we know that’s not true. And what’s good for the steel industry, its workers and its executives is not good for America, either, necessarily. So Buy America is Rosenkranz Foundation-Intelligence Squared U.S. costly corporate welfare. It’s already backfired. Please vote affirmative. Thank you very much. JOHN

### Moderator
Claim: Thank you, Douglas Irwin. And now to argue against the motion that Buy American/Hire American Policies Will Backfire, Leo Gerard, who is the son of a miner from Canada. And now that he is International President of the United Steel Workers, when he steps up to that microphone he has eight hundred, fifty thousand union members standing behind him. Leo Gerard.

### Scientific Advocate (SA)
Claim: Thank you very much. I have to tell you that I’ve discarded a lot of my notes because I want to correct the previous speaker. The fact of the matter is that China did win the bid for the Bay Bridge and the fact of the matter is that the Bay Bridge is now almost eight months behind schedule and that the steel that came from China won’t hold the weld. And they’re not sure if they’re going to have to rip it all down and rebuild it, so that, if we talk about what that represents in lost dollars and productivity, it’s way more than the number that Doug used. Let me then go back to my notes. The fact of the matter is that three trillion tax dollars per year are spent by the federal government in federal procurement. And no one is saying that it’s simply, that you get the money that comes from Rosenkranz Foundation-Intelligence Squared U.S. tax dollars and you use it to buy Chinese goods.

And then the fact of the matter is this has gone through the roof since the passage of NAFTA and PNTR. And what we’ve done is we’ve lost, in our manufacturing base from 1949 to ’69, manufacturing was twenty-eight percent of the economy of America and we were the world’s largest creditor nation. By the time we got to the end of last year manufacturing was nine percent of the economy and we have now become the world’s largest debtor nation. The fact of the matter is, if we don’t start buying products that are made here, what we’ll end up doing is borrowing Chinese money to import Chinese parts and have laid-off workers. And the fact of the matter is that Buy America stimulates the economy, creates good jobs, makes the industrial economy work and if the industrial economy works then we need engineers, innovation and we need the other pieces that make that economy hum.

There was all kinds of yelling and screaming, when the Buy America provision was made public in the stimulus bill, like this is something new. There’s been Buy America provisions since 1930s. And the fact of the matter is that they’ve been good for creating jobs. If we go back to the period from 1994 when we abandoned, in a much more aggressive way, Rosenkranz Foundation-Intelligence Squared U.S. industrial manufacturing in America, in that period of time America has accumulated a 6.5 trillion dollar trade debt. We’ve had twenty-five years in a row, exacerbated since 1994, of year after year after year record breaking trade deficits. This year people will say, Yeah, well, the trade deficit’s falling down. It’s probably going to come in around five hundred billion dollars and we’ve had a huge drop. That’s simply because there’s no purchasing power and we’ve had the collapse of the credit markets.

There can be an argument made that a large part of the economic collapse that we saw is because there was too much money in the wrong direction. And the fact of the matter is that, that money, making its hands into a much, much smaller group, led to an inability of us to sustain. And we’ve, over the last fifteen years, gone to personal debt that is unsustainable. All of that because we’ve abandoned the idea of not only making things in America, but buying things that are made in America. I won’t spend too much time, but if we look at what’s going on in most of our trading partners, in the E.U. and spend time with China... I never heard a word in America when French President Sarkozy said that they’re going to stimulate their economy and they’re going to stimulate their auto industry on the condition that every taxpayer dollar of Rosenkranz Foundation-Intelligence Squared U.S. French currency that’s invested in France is going to go to prop up the French auto industry and the French auto industry had to commit to no layoffs.

Surprisingly, the European economy is bouncing back faster than ours. I didn’t hear a word. I didn’t hear a word when in May the Chinese government said that their stimulus program was going to be steered and directed towards not just Buy China-- there is a slight difference-- Buy Chinese. I didn’t hear a word here. Think of the auto industry. I’ve only ever driven a North American car, big three. I’ve never had a bad one. But for some reason, we’re prepared as a society to tolerate a deficit in automobiles between South Korea and Japan of forty-five billion dollars a year. If a billion dollars equals thirteen thousand family-supporting jobs, just in the auto sector, year after year after year, we can’t get into their market. They have a view that buying a Japanese car in Japan is a good thing.

China has recently announced that it intends to dominate the world in renewable energy products. A company called Suntech Power Holdings said in an interview that to build market share-- this is what’s coming from China-- to build market share it’s selling solar panels on the American market Rosenkranz Foundation-Intelligence Squared U.S. for less than the cost of materials, assembly and shipping. This is a decision made in China. And we’re saying that we want to be the leader in renewable energy but we don’t have a program to stimulate demand or to buy renewable energy products that are made in America. Having said that, I see that my time is up. But keep in mind that in order to do that China cheats on its currency, it manipulates its cost of production and we sit back and say that it would cost us jobs if we did the same thing.

### Moderator
Claim: Leo Gerard, thank you very much. I just want to make the request to-- back on cell phones, if anybody still has their cell phone turned on as a result of the voting exercise, to turn it off now because I’ve been told it might be interfering with the radio waves might be interfering with some of the audio in the room. So I’ll just listen to everybody’s phones sing for a second while that happens. And again, for newcomers, I want to explain that we have opening statements of seven minutes each. That will be followed by a round of head to head debate in which I’ll ask questions and you’ll ask questions. And at the end of the evening we’ll have summary statements of two minutes each, after which you will vote once again. Are all of the cell phones off? It looks like they are. To resume, the motion here is that Buy Rosenkranz Foundation-Intelligence Squared U.S. American/Hire American Policies Will Backfire. And our next debater is going to argue in the affirmative. He thinks that Buy American will backfire, not surprisingly, because he is one of the world’s pre-eminent economists and has long argued that globalization is the world’s most powerful force for social good. From Columbia University, Jagdish Bhagwati.

### Conspiracy Advocate (CA)
Claim: Thank you very much. Let me just begin first by emphasizing a point which Doug Irwin made, but in relation to a story. When I was a student at Oxford one of my professors actually told me that he’d gone to Whitehall to advise and he was surprised to find that while he thought economics oversimplified things, that in fact, people in Whitehall were working with even more simplistic models. They usually thought X led to Y and they stopped there. Y leading to Z, Z leading in turn to X. All of that was completely beyond them. They were extremely oversimplifying. The problem, I think, with Mr. Gerard is, I think, as Doug was pointing out, and with the opposing side basically, is that you think that Buy America will create jobs in the steel using sectors, for example, or in the steel industry.

First, in fact, X affects Y. But what does that do to the rest of the system? Because you are then opening up a whole series Rosenkranz Foundation-Intelligence Squared U.S. of additional effects which are actually going to overwhelm the initial primary impact. And that’s essentially what we need to focus on. What are these additional effects? One, of course, is that downstream industries typically become more uncompetitive. We know when President Bush put on the steel tariffs in ’92 the effect was, in fact, to price out a whole lot of steel using industries, including autos, which indeed, there was a famous study which shows that about two hundred thousand jobs may have been lost while we gained a few basically through protecting steel. So that’s point number one. The second point is that you get out of this, and still, even if we didn’t have this problem we would have the problem of retaliation. And I would say it’s not tit for tat retaliation necessarily. It’s also monkey see, monkey do kind of imitation. While we do something others do the same thing.

If you look at the 1930s it was exactly spreading and diffusion of all kinds of trade barriers, starting out from the Smoot- Hawley, et cetera. And this, I think, led to essentially what we in economics call a nuclear winter, basically. There was a chaotic outbreak of all kinds of trade barriers. That came home to roost in turn, on our export performance, on everybody’s export performance. And I think this is something we need to remember, that as we go into this, policies like Buy Rosenkranz Foundation-Intelligence Squared U.S. America, that is what we are going to get into. We already see that, as Doug was pointing out, in a variety of fields. And I’m sure Susan will pick up that theme. The large numbers of actual actions which we already see by way of diffusion of these kinds of tariffs.

And we are actually the biggest traders in the world. Every state has export industries. I’ve been looking at that. You have basically, therefore, a lot of your jobs at stake. And those are going to outweigh the few jobs you may save through Buy America provisions. I think this is, if you look at Buy America, if you know a little bit of history-- I know just a little bit and Doug knows much more-- but Buy America, when did it first get passed in this country? It has to be in this country, obviously, if it was Buy America. It was 1933, right after the Depression, the great And that’s what set the stage. And I think we are now re-enacting that after this current crisis. So beware, is all I say. Caveat emptor, if you want, feel inclined to be working for the other side. Then I think we also got the argument, to look at the negative arguments produced by Mr. Gerard in his interesting comment, he said, Well, manufacturers are important and we need to support them. And he’s not the first one to have said that.

Rosenkranz Foundation-Intelligence Squared U.S. There has been an anti-de-industrialization movement in England, about twenty years ago. There was also a Berkeley movement called Manufacturing Matters. And I think Mr. Gerard is really harking back to it. And this is a case where you assert that manufacturing is some sort of massive externalities. And I would simply say, I’ll just quote my old teacher, Professor Solow, who is Nobel Laureate and the father figure on the Democratic side. I’m a Democrat. He said, I know there are lots of industries in massive externalities. But there’s a four dollar worth of marginal, social marginal product and the private margin product is one, one dollar. And he said, My problem is I don’t know which ones they are. And the problem is, and compounded by the fact that the lobbies know where the externalities are. And I think this is the problem.

It’s not that we don’t believe that there are externalities, but for Mr. Gerard to assume that they are necessarily in steel or in manufacturers more generally has never been proven. And I don’t think any Democrat would support that view. In fact, what we do is essentially to argue that we must support broader policies like R&D support and so on, but not go into specific activities cause that’s exactly the wrong way to go and it gets captured by, by several people. And I think this is Rosenkranz Foundation-Intelligence Squared U.S. what we need to worry about. Finally, I would just touch on one thing which drives, I think, the union movement. And I can understand their fear because I can easily produce models being a theorist also, aside from an activist on these issues. One can easily produce models where international trade actually affects your workers, that in fact the fear is, on the part of unions, that trade with the poor countries produces paupers in the rich countries.

Now, a lot of work has been done on this. Actually, there’s very little evidence of this. In fact, there are studies, including my own with Bob Lawrence at Harvard, which show actually that the pressure on our wages, which is a real problem and, you know, as a Democrat I’m entirely sympathetic to the problem. That has been brought about by extremely acute labor saving technical change, by the fact that the unionization has also gone down for reasons which don’t have much to do with globalization or trade. Given that, I think a lot of us have argued with empirical evidence that trade with poor countries, trade with emerging countries has actually kept the consumption cost of workers’ wages down. So it, in fact, it has moderated the--

So I will pick up the argument later.

### Moderator
Claim: Jagdish Bhagwati, I’m sorry, your time is up.

Rosenkranz Foundation-Intelligence Squared U.S.

### Conspiracy Advocate (CA)
Claim: So I will pick up the argument later.

### Moderator
Claim: I want to help, ask you to help with a little piece of radio production. At this point on the NPR broadcast they take a break. And then we come back again to the broadcast and it’s very helpful if it’s refreshed with a round of applause from all of you. So I’d like to ask you to do that. Welcome back to another debate from Intelligence Squared U.S. I’m John Donvan, your moderator. The proposition we are debating here is: Buy American/Hire American Policies Will Backfire. We have six panelists, three against three. And next to speak against the motion: Buy American/Hire American Policies Will Backfire, John R. MacArthur, known as Rick. He is President and Publisher of Harper’s magazine, the oldest continuously published monthly magazine in America and also one of the most progressive. Ladies and gentlemen, Rick MacArthur.

### Scientific Advocate (SA)
Claim: I have totell you that I wrote a book about NAFTA, called The Selling of Free Trade. That’s why I’m here, not because I’m publisher of Harper’s magazine. But may I make a cheap debater’s point right at the outset and say that Professor Irwin has already veered off the proposition. This is a, Rosenkranz Foundation-Intelligence Squared U.S. the question I thought that was put was, Buy American policies, not the Buy American provision in the legislation that just passed six or eight months ago. And if we’re going to discuss this broadly we have to talk about tariffs versus free trade, protectionism versus free trade. That’s what we’re really talking about here. I would also add that, I hope we can come back to Smoot-Hawley because Smoot-Hawley is a canard, as it is acknowledged by many, many mainstream economists who say that it had little or no affect on exacerbating the Great Depression.

But there’s a reason why Thomas Carlyle called economics the dismal science. I happen to think it’s because he understood intuitively that it was not a science, and that it’s not a science because you cannot conduct a controlled experiment in economics the way you can in hard science, in real science. And as a non-science, we have to turn back to the great theorists of free trade and the anti-protectionists like David Ricardo and Richard Cobden and understand that they, in the early 19th Century, could not imagine a world where anybody with money and labor could plug into a power source anywhere in the world and make virtually anything. These theorists, to whom Professor Bhagwati, Professor Irwin and many of their colleagues cling with religious fervor, with-- I might even say-- Marxist fervor, Rosenkranz Foundation-Intelligence Squared U.S. because Ricardo had a great influence on Marx, is what distorts the debate.

As then MIT economist Paul Krugman, who was and still is a partisan of free trade, noted in a 1991 book called Geography and Trade, the quote: The tendency of international economists to turn a blind eye to the fact that countries both occupy and exist in space, a tendency so deeply entrenched that we rarely even realize we are doing it, has, I would submit, had some serious costs. These lie not so much in lack of realism-- all economic analysis is more or less unrealistic-- as in the exclusion of important issues, and above all, important sources of evidence. Now, let’s admit, on the protectionist side, that Buy American policies are indirect tariffs, indirect subsidies, whatever you want to call them.

And there are many statistics to support the protectionist model. I don’t pretend they’re definitive any more than my economist friends can make the argument that their statistics or their studies are definitive because they’re not scientific experiments. But since we’re talking about protectionism versus free trade, essentially, we can site some spectacularly successful protectionist schemes, Mexico, poor, beleaguered, exploited Mexico in the ‘50s, ‘60s and ‘70s, had a program called import Rosenkranz Foundation-Intelligence Squared U.S. substitution, a nice way of saying, or a technical way of saying, buy Mexican. And Mexico enjoyed the highest growth rates in its history, through the ‘50s, ‘60s and ‘70s, of, roughly, I think averaging about 7 percent. Just to give you a more specific recent example, we still have a 25 percent tariff, import tariff on pickup trucks in the United States. That’s why, Toyota, until very recently, was still manufacturing pickups at their NUMMI, joint operating plant in Fremont, California, in their joint operation with General Motors. That’s what kept Toyota in the game, was the 25 percent tariff on imported pickups. It’s probably not a coincidence that in 1945, the average US tariff on dutiable imports was 28 percent. And in the same year, manufacturing employment which as you all knows pays better than working at Wal-Mart, manufacturing employment as a percentage of total US employment was 35 percent. It’s also likely not a coincidence, that in 2008, the average tariff on dutiable imports was 4 percent—by the way these are Professor Irwin’s numbers— and in the same year manufacturing employment as a percentage of to—total US employment, was just under 10 percent. Now. Again, this is anecdotal evidence, I don’t pretend it’s scientific, but in 1979, the year in which manufacturing employment peaked in the United States, the median weekly earnings for all US workers in 2009 dollars, was $716.47. In the second quarter of 2009, the median weekly Rosenkranz Foundation-Intelligence Squared U.S. earnings for US workers, was $734, just slightly above, so we can make the argument that a pro-free trade, lower-tariff economy has possibly contributed to the stagnation of wages, I think we can say anecdotally, that because manufacturing employment has declined, and manufacturing jobs pay better than service jobs generally speaking, this has contributed to the stagnation of wages. Now, this is not only happening in the, labor-intensive traditional assembly-line jobs. Business Week just had a cover story called “America’s Manufacturing Crisis” in which they talked about, the crisis in high-tech manufacturing. And the causes of this manufacturing decline in American high- tech, quote, “are numerous, complex, and a long time in the making.” That’s from Willy Shih, a Harvard Business School professor who used to work at IBM, and used to run Eastman Kodak’s Digital Consumer Products Union. And then, Business Week goes on, to paraphrase they say two decades of unconstrained outsourcing to Asia have hollowed out much of America’s base of supplies, factory managers, and skilled technicians. US private capital markets meanwhile are loath to tie up their billions in factories and machinery. In the boom years from 1994 to 1999, when then economy surged 26 percent, US manufacturing capacity went up by 44 percent. Okay? But from 2002 through 2007 when the US expanded by 17 percent, manufacturing capacity rose a paltry 5 percent.

Okay. And I’ll just say that, it’s no coincidence that permanent normal trade relations with China were passed, in 2000. JOHN

### Moderator
Claim: Rosenkranz Foundation-Intelligence Squared U.S. Rick MacArthur, your time’s up.

### Scientific Advocate (SA)
Claim: Okay. And I’ll just say that, it’s no coincidence that permanent normal trade relations with China were passed, in 2000. JOHN

### Moderator
Claim: Thank you. Our next debater Susan Schwab was to any of our international trading partners the face of US trade, holding as she did the post of United States Trade Representative in the George W. Bush administration, that is a Cabinet-level position. She saw firsthand government thinking on trade and she also influenced it, and now at the University of Maryland, she is here to argue, that Buy American, Hire American policies will backfire, Susan Schwab.

### Conspiracy Advocate (CA)
Claim: Thank you, and thank you very much for inviting us here today to debate this very timely and very interesting and very complicated topic. I’m going to start by talking about Hire American policies, which is part of this debate although no one’s talked about it yet and I’m going to make quick work of that, because quite frankly Hire American restrictions are un- American. They are discriminatory, they reek of discrimination, they deny us the very diversity that has made the United States, as competitive as we are. Immigrants built this nation and all Rosenkranz Foundation-Intelligence Squared U.S. you need to do is look at some of the companies that were founded by immigrants or children of immigrants the employ millions of Americans, including Google, Intel, eBay, Yahoo, Proctor and Gamble, duPont and even US Steel. Buy American? Buy American sounds like motherhood and apple pie, and, unfortunately, Buy American policies hurt America, and hurt Americans. And we have history to point to and we have, the fact that the United States has to export to grow, to point to, and the fact that the risk of retaliation is very, very real indeed, let’s start with history. Rick mentioned Smoot-Hawley, well, guess what. In the Smoot-Hawley Tariff Act we raised our tariffs, it was perfectly legal under the international trading system at the time. It ultimately prolonged and deepened the Great Depression. No country, no country has ever reached or sustained a level of prosperity with economic isolationism as their policy, with trade protectionism as their policy, with buy national policies. In fact if you look at the 1990s the countries that grew the fast in the 1990s, were countries that opened their markets, followed our lead by the way, opening our markets. They grew three times faster than the countries that did not open their markets. 95 percent of the world’s population, meaning the world’s consumers, live outside of our borders. Those are our customers and if anyone thinks that we Americans have enough money to buy our way to recovery, and to future competitiveness without Rosenkranz Foundation-Intelligence Squared U.S. exports, you’ve got another thing coming. Half of GDP growth, more than half of global GDP growth going forward over the next five years, will come in the advanced developing countries. The bulk of global economic growth will come outside the United States. And if you’re talking about stimulus packages and quite frankly, Rick, this debate is about Buy American policies, meaning the government telling us, that it will not buy foreign goods whether they are higher quality, whether they are better priced. $3.5 trillion will be spent in the next several years, by other countries on stimulus. Globally. We need a piece of that. And if you are a Caterpillar worker in Illinois, if you work for G.E., if you work for any of the major manufacturers in the United States that sell to these countries, you want a part of that action. China is going to be spending the vast majority of the $550 billion it’s putting into stimulus, on infrastructure. That is business for American exporters. India is going to be spending anywhere from $20-$70 billion in roads construction. Now. This issue, this canard, of—that we don’t manufacture anything, is utterly absurd. Some of you may be surprised to know that the United States remains the single biggest manufacturer in the world, bar none. $1.7 trillion in manufacturing outputs, China is a distant second, at $1.3 trillion, with Japan and Germany following up to the rear. One in six manufacturing jobs depends on exports, 6 million US jobs depend on manufactured good Rosenkranz Foundation-Intelligence Squared U.S. exports. And if you look at US economic growth you discover, that our manufacturing is in fact 20 percent of our GDP, not 9 percent. And it continues to grow, our manufacturing output. Yes, our manufacturing employment, because of productivity enhancements, technology, has not kept pace. But if you look for example at a company like UPS that tells us for every 40 new packages that are shipped overseas, they hire a new American worker. Those are high-paying blue-collar jobs, Fed Ex, exactly the same kind of statistics. And in many cases you’re talking about, these are Teamsters who are going to be hired. Retaliation, retaliation is not some myth, retaliation is very, very real, not only did we see it after…Smoot-Hawley, we saw it after the Buy American language, it is not coincidence, that within six weeks of the Buy American legislature on the stimulus package moving through the United States Congress, it is not coincidence that the Chinese suddenly decided to let their provinces favor local companies, because before that a lot of Americans were starting to make a lot of money in those markets. We need access to those markets, and we need to be exporting to stay competitive. The folks who are telling us, this isn’t going to happen, they are ignoring the fact that the Canadians have already retaliated, the Chinese have already retaliated. The US Chamber of Commerce estimates that for every 1 percent of this global stimulus bonanza that is out there, that we lose because of Rosenkranz Foundation-Intelligence Squared U.S. retaliation, we lose 175,000 jobs. That eclipses the, what, eight, 9,000 jobs that the Petersen Institute has told us could possibly be created in the steel industry in the United States, and Doug has already talked about how that has hurt other workers in construction and so on. So let me close…as follows. One, remind you, there is zero evidence that buy national policies create more jobs than they sacrifice, and in fact the data is very, very compelling the other way, trade isolationism kills jobs, it does not create jobs. Buy American sounds good. And the issues that are being raised by the other side in many ways are legitimate issues. But Buy American policies and trade isolationism will not solve any one of the problems that they are describing. Buy American sounds good, good sound bite, bad policy, hurts America, hurts American jobs, thank you.

### Moderator
Claim: And finally, speaking against the motion, “Buy American-Hire American Policies Will Backfire,” Jeff Madrick, a business journalist and visiting professor at the Cooper Union, in the mid- 1990s he predicted The End of Affluence with a bestseller that went by that very name. His latest book, The Case for Big Government—the title alone tells you much about his political take on the world, as he argues now against the motion, ladies and gentlemen, Jeff Madrick.

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S. Thank you, thank you, I’m delighted to be here. I was once a free-trader myself, as was Philip Verlager who I see had a letter in the New York Times just Sunday saying he was once a free- trader. Worked for the Petersen Institute, decided it was totally unrealistic. Enough is enough. I’m a little tired of people who keep telling us—not these people. That wasn’t aimed at you, that, uh— Little tired of being told time and again, that being worried about free trade is an oversimplified point of view. I’m a little tired of being given simplistic examples, of where buying, say, steel in the US, will raise construction costs and therefore cost American jobs. I’m tired of being told that empirical studies invariably show that free trade will create—has almost no effect on jobs in the US, and you know I better tell you the truth about that, because, I have a whole bunch of things to say, I’m not going to get to them, and I’m going to forget some. The fact of the matter is, despite what Professor Bhagwati said, and despite his own studies, most studies find a direct negative impact, from free trade on wages, and on the creation of jobs. Most studies. Not by wide-eyed progressives from the New School, but by mainstream economists. Most studies, so let’s get the facts straight. I want to go down this list because this is too important, I’m afraid, to Rosenkranz Foundation-Intelligence Squared U.S. leave to economic theorists. I believed in Ricardian economics, I still do. Exchange is the key to economic growth. You have something I want, I want something—I have something you want. It leads to economic growth, but it is a narrow idealistic theory, in a very complex world. First, Buy America is not illegal. China agreed to the very terms we are citing in this stimulus bill. That’s number one. It is not illegal, neither by the way are the tariffs on tires. Not illegal, they agreed to it, in the international agreements. Number two. The fiscal policy becomes necessarily ineffective when 20 to 30 to 40 percent of every dollar we spend, to pump up our economy in a recessionary emergency, leaks overseas. We’re not saying all—we should not have exports and imports, nobody on my teams thinks we shouldn’t have export growth, and even import growth. Nobody I know believes that. But we do want effective fiscal policy and that is what we are talking about in the narrow sense. Will there be a trade war? Darn it, I am tired of these scare tactics, I’m tired of claiming there will be a repeat of the 1930s. Is China up in arms against this policy, I suspect China is now willing to talk a little bit, because they see maybe President Obama is ever so slightly serious about imposing rights he was given in international treaties into which China agreed. Is China not pushing its tires, a surge in tires here? Of course they are. And that was a response, another issue. Let’s stop isolating this economic theory Rosenkranz Foundation-Intelligence Squared U.S. from the real world. China subsidizes, all kinds of countries subsidize, all kinds of countries push exports. We have to begin to realize that. Let’s look at what’s happened, and I’m skipping as you can tell a little bit, let’s look at what’s happened in America since free trade. Don’t think this side of the podium is fighting an uphill battle. They won. They’ve won for decades. Tariffs have come down significantly. And where does America stand in terms of wages, you’d think, judging by what some of them said, we’re doing great. The median male worker in America today, makes less than the median male worker after inflation did in the 1970s. Think about that. That stagnation probably never occurred in American economic history before. We did some numbers on this, it’s pretty stun— I’m not going to go into those because, my time is running low, maybe we’ll get to it in the Q-and-A. Frank Levy, and Peter Temin, mainstream economists, at MIT, are alarmed, that annual earnings of all workers, not just males, male and female, all races, all ethnicities, plus fringe benefits, which people often say are left out by—people like Robert Lawrence often make this case—plus fringe benefits haven’t been keeping up with productivity since roughly the late 1970s. Wages are supposed to keep up with productivity. What’s going on, is free trade part of this? I think it is part of it. Is it all of it, no, is it most of it, it may not even be most of it. But it’s probably some of it and we’ve gotta start Rosenkranz Foundation-Intelligence Squared U.S. thinking about that. I have to say one other thing about economic theory while I’m going through this litany. There is a very strong emphasis on keeping wages down in America, you may have noticed, every time wages go up the Federal Reserve in the good old days, that was before the crisis, would try to push wages down because it was going to be inflationary. A very important theory of why economies grow, has been thrown aside. That is economies grow because American workers, and the immigrant workers who come to America make enough money to support demand so the companies can grow. And then companies invest. All through American history, wages rose inexorably. In America, median wages, average wages, rose, and were a source of economic growth. That stopped somewhere in the 1970s. And we better start thinking about it, what am I thinking, what am I talking about? Not full-scale protectionism, not the end of exports and imports. But a serious, committed, complex…not simple theory, of why economies grow, but a complex analysis and approach to dealing with a high dollar. With high debt in America. With trade inequalities. With industrial policies and export subsidies overseas. And an attempt, and I think interestingly, the other side did not use its strongest argument. Free trade, our buying from overseas, helps those poor countries, where wages are really low. I think as decent human beings we should all be for them, look what’s Rosenkranz Foundation-Intelligence Squared U.S. happened. It hasn’t gotten to them for the most part. It hasn’t gotten to them in nearly the amount it should. We’ve got to think much more broadly about this issue, thank you.

## Round 2

### Moderator
Claim: Thank you, Jeff Madrick, and that concludes opening statements in this debate. I’m John Donvan, your moderator for this Intelligence Squared US debate, our motion is “Buy American-Hire American Policies Will Backfire,” we have six panelists, three arguing for the motion and three against, now before the debate we polled our live audience here on where they stood on this debate, and I now have the results and we’ll report them and once again, the motion is, “Buy American-Hire American Policies Will Backfire,” before the debate, 57 percent of you agree with the motion, 20 percent of you were against the motion, and 23 percent were undecided. We will poll you again at the end of the debate and the side that has moved the most votes, that has changed the most minds will be declared our winner. Now on to Round 2, in Round 2, the debaters speak directly to one another, they can question one another, they will also take questions from us, myself and you in the audience will have the opportunity in just a minutes, we have ushers with microphones. If you raise your hand, catch my attention, we will get a microphone to you, I urge you again, please, to resist the Rosenkranz Foundation-Intelligence Squared U.S. temptation to make long speeches. And if you are a member of the press, we would prefer that you identify yourself. Doug Irwin of Dartmouth College, you are arguing for the motion that Buy American will backfire, you actually went as far as saying it has already backfired. I heard your opponent on the other side, Rick MacArthur, and his colleagues, argue repeatedly that Buy American works, and buy our own stuff works for lots of other countries who are doing it already, that’s why they do it. Rick MacArthur cited Mexico, it has worked for Mexico. If it works for Mexico, why not make the argument that it works here as well.

### Conspiracy Advocate (CA)
Claim: Well I wouldn’t Grant the premise that it worked for Mexico, in fact, what did that lead to. Huge debt crisis in 1982, huge collapse of the growing middle class, huge economic problems which is one reason why they chose to embrace economic openness after the early 1980s. But actually, Jeff Madrick raised an important point too. There’s been tremendous economic growth in India. Tremendous economic growth in China. The biggest change in the globe has been happening in those regions, where there’s hundreds of millions of people moving into the middle class. They’re able to do that because of trade openness. And yes—

### Scientific Advocate (SA)
Claim: They’re able to do that because it’s a mercantilist policy, Doug.

Rosenkranz Foundation-Intelligence Squared U.S.

### Conspiracy Advocate (CA)
Claim: Oh, so China—

### Scientific Advocate (SA)
Claim: They’re able to do that because they subsidize their market, they’re able to do that because they manipulate their currency. They’re able to do that because of the article that the CEO of— Chinese CEO of Suntech Power says that they’re going to sell their products in America, at lower than the cost of production.

### Conspiracy Advocate (CA)
Claim: The issue—

### Scientific Advocate (SA)
Claim: And they get away with it because—

### Conspiracy Advocate (CA)
Claim: Excuse me, Leo.

### Scientific Advocate (SA)
Claim: —bec—I’m not finished, let me— and they get—

### Conspiracy Advocate (CA)
Claim: Well, I wasn’t finished either.

### Scientific Advocate (SA)
Claim: Well—

### Moderator
Claim: Well—

### Scientific Advocate (SA)
Claim: I was told I could interrupt you when you were wrong, Doug.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Squared U.S. I’m glad Leo Gerard of the Steelworkers Union jumped in because one of the points that was raised by your opponents, as you argue against this motion, that Buy American will backfire, they raise the argument that, steel products from abroad may be better and may be cheaper, and why should Americans have to pay more for their steel if they can get it better and cheaper abroad.

### Scientific Advocate (SA)
Claim: Well, first of all it’s certainly not better and in some cases it is cheaper, but I come back to the point that Doug raised about the Bay Bridge. We have red lead in steel, that we’ve had to ship back because, we banned red lead in America 30 years ago because of its health hazards. So we—

### Moderator
Claim: Could—can you explain what that is for people that don’t know the term, very quickly—

### Scientific Advocate (SA)
Claim: Red lead is the most toxic form of lead, they used to be put in pipes because it’s malleable. You can maneuver it. We banned it because red lead is so dangerous. And we pay a price for doing that, we pay a price for clean water, we pay a price for all those things in the kind of society that we want. We found that China was shipping steel pipes with radiation in it because they were Rosenkranz Foundation-Intelligence Squared U.S. doing it from melted pipes with radioactive material in it, and shipping it. We found that, as I said this, and I…

### Moderator
Claim: But that—that’s an argument that you can buy junky stuff abroad.

### Scientific Advocate (SA)
Claim: Well, that—

### Moderator
Claim: And,—

### Scientific Advocate (SA)
Claim: —well that’s—but Doug, there are, that’s the argument, that we have a set of laws and rules and we’re a rules-based trading system, but we’re the only one right now playing by the rules.

### Conspiracy Advocate (CA)
Claim: You know, I—

### Scientific Advocate (SA)
Claim: And, and if we’re a rules-based trading system they ought to be playing by the rules too—

### Moderator
Claim: Let me hear from the side for the motion in response to that.

### Conspiracy Advocate (CA)
Claim: Well— There’s nothing which prevents you from applying safety standards and we are doing that all the time. So the fact that some Chinese imports or any other Rosenkranz Foundation-Intelligence Squared U.S. imports, including our exports, get caught in the safety net doesn’t mean that Buy American is good. I mean that’s simply a non-sequitur.

### Scientific Advocate (SA)
Claim: But what it does—

### Conspiracy Advocate (CA)
Claim: The issue being—I’m sorry—

### Scientific Advocate (SA)
Claim: —is that—what it does is it adds costs because we have rules, now you come to us and say, well your costs are higher.

### Conspiracy Advocate (CA)
Claim: —Leo—

### Scientific Advocate (SA)
Claim: But we have rules—

### Conspiracy Advocate (CA)
Claim: —Le—

### Moderator
Claim: —Susan Schwab—

### Conspiracy Advocate (CA)
Claim: Leo, and I’m, and I would note, Doug never got a chance to finish what he was saying—

### Moderator
Claim: I’m glad you’re standing up for him—

### Conspiracy Advocate (CA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S. I got that. No, I mean the point is, we can get off on this long tangent about Chinese trade policies, first of all, that is not the issue at hand. The resolution talks about Buy American policies, Hire American policies, will backfire. They will backfire, they have backfired, that’s what we’re voting about. But in terms of China, I have taken on Chinese trade practices, and we’ve got legislation to do that. We took six cases against the Chinese in the Bush administration, we won or settled every one of those cases, got rid of illegal Chinese subsidies, we managed to get the markets where they were artificially closing them.

### Scientific Advocate (SA)
Claim: But—

### Conspiracy Advocate (CA)
Claim: There are—I’m sorry. There are statutes for anti-dumping, there’s statutes for countervailing duties, there are lots and lots of statutes. Buy American legislation does not resolve any—

### Scientific Advocate (SA)
Claim: But you’re not—

### Conspiracy Advocate (CA)
Claim: —single one of—

### Moderator
Claim: Jeff—

### Conspiracy Advocate (CA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S.—the issues, excuse me—

### Scientific Advocate (SA)
Claim: And the problem with that is dumping—

### Conspiracy Advocate (CA)
Claim: —but the other side’s been talking back—

### Moderator
Claim: Jeff Madrick from the other side—

### Scientific Advocate (SA)
Claim: Dumping goes on, subsidies go on in this recession, by all reports I’ve heard. China is really pushing out the exports as, uh, uh, as, and some of the practices are open, this is part of what I mean— This is what I’m talking about about this oversimplification. That, and I have great respect for…Jagdish who I consider a friend, but, to say that we can handle these issues in the International Labor Organization, or through agreements we make with China, disregarding the reality of the world, I am—we’re not even close to fighting a trade war. The, we’re—it’s not even close. China needs us, we need them, we’ve got to start dealing with the reality of what’s happened to wages in America. And Doug, things have become extremely imbalanced in this world you’re describing of China and India—

### Moderator
Claim: Let’s let Doug Irwin in now—

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S. Extremely imbalanced—

### Conspiracy Advocate (CA)
Claim: That’s great—

### Scientific Advocate (SA)
Claim: —and in fact—

### Moderator
Claim: Doug Irwin of Dartmouth College.

### Conspiracy Advocate (CA)
Claim: I’m actually one of the few trade economists who believes the trade deficit has become a problem. So the question is how do you deal with it. Buy American will not deal with it, it’s not the right approach. Why do we have a huge trade deficit with China. What do we do with our dollars in the United States. 70 percent of US GDP is consumption. 70 percent. What is the share of consumption in China. 30 percent. They are a high-savings country, we are a low-savings country. We are a high- consumption country, they’re a low-consumption country. That is the ultimate source—

### Scientific Advocate (SA)
Claim: Yeah— Rosenkranz Foundation-Intelligence Squared U.S.

### Conspiracy Advocate (CA)
Claim: —of the trade deficit—

### Scientific Advocate (SA)
Claim: —you know—

### Conspiracy Advocate (CA)
Claim: It’s not unfair trade practices, it’s not all this other stuff—

### Scientific Advocate (SA)
Claim: You know, one way to get to—

### Conspiracy Advocate (CA)
Claim: We have to save more as a country, and China has to—

### Scientific Advocate (SA)
Claim: I—

### Conspiracy Advocate (CA)
Claim: —consume more.

### Scientific Advocate (SA)
Claim: And—you know, and Doug is

### Moderator
Claim: Jeff, let me bring in your colleagues, we haven’t heard from them

### Scientific Advocate (SA)
Claim: As long as you give me a chance—

### Moderator
Claim: No, sorry, Rick, Rick MacArthur, come on in.

Rosenkranz Foundation-Intelligence Squared U.S.

### Scientific Advocate (SA)
Claim: Well I never got to— I ran outta time so I wasn’t able to make my main argument which has to do with what kind of a country you want to live in. Obviously, using tariffs and Buy American provisions are artificial methods that you install in an economy to, we hope, maintain wages at a relatively high level so we can run a civilized society, we haven’t had one exchange yet about the exploitation of cheap labor in China or Mexico. And when I talk about when I have arguments with my friends in the economics departments of these various universities, I have to ask myself if they’ve ever met a factory worker, have they ever talked to a steelworker or to an autoworker or to an electrical worker who’s lost their job, because the United States has been pursuing pro-buy foreign policies for the last 15 years, that’s what we have now with NAFTA, and the Permanent Normal Trade Relations with China. These are, as Professor Bhagwati will be the first to acknowledge, preferential trade agreements, not free trade agreements, and, something has to be done on our side to compensate for these tremendous advantages, given to foreign manufacturers. Yes, some of it is low-end manufacturing but not all of it is low-end manufacturing. And in order to redress this tremendous trade imbalance there are various methods at our disposal. Tariffs, Buy American provisions, et cetera, et cetera. But to go on talking as if there is a free trade system in place Rosenkranz Foundation-Intelligence Squared U.S. that’s being threatened is preposterous. If you look at NAFTA and PNTR they’re much closer, and this is a corporate lawyer who first explained it to me when I explained to him how the labor market works between the United States and Mexico and the United States and China, it’s more like a labor racketeering agreement. That is a conspiracy to fix the price of labor as low as possible, certainly to benefit certain, uh, shareholders in certain American corporations, but not to benefit American workers or to defend—

### Moderator
Claim: Rick, let—

### Scientific Advocate (SA)
Claim: —what we used to call the American way of life—

### Moderator
Claim: I want to cut in—

### Scientific Advocate (SA)
Claim: If you want to keep driving wages down, yes, let’s keep pursuing a non-Buy American policy, and let’s—

### Moderator
Claim: So, so—

### Scientific Advocate (SA)
Claim: —keep outsourcing—

### Moderator
Claim: —so this critique seems to say to the side arguing for the motion Rosenkranz Foundation-Intelligence Squared U.S. that free trade as you describe it is a farce.

### Conspiracy Advocate (CA)
Claim: Well, let us note again, you’re going to come back and remind everyone what this debate is actually supposed to be about, Buy American, Hire American. But, the other side is meandering, I want to go in that direction and talk about trade agreements because what Rick has been saying about trade agreements, just isn’t borne out by the facts. If you look at the free trade agreements, and, forgive me, Jagdish, I know you hate free trade agreements. If you look at the agreements that we’ve negotiated, you find that US exports to our trade agreement partners have gone up 40 percent faster, than our—

### Scientific Advocate (SA)
Claim: They are fake exports—

### Conspiracy Advocate (CA)
Claim: 40 percent—

### Scientific Advocate (SA)
Claim: Madam.

### Conspiracy Advocate (CA)
Claim: —faster—fake exports? Go talk to G.E. and Caterpillar—

### Scientific Advocate (SA)
Claim: Jeff—

### Conspiracy Advocate (CA)
Claim: —and, UPS—

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S. Soviet Union—Susan, Jeff, Susan, Jeff—

### Conspiracy Advocate (CA)
Claim: Let me finish a thought—

### Scientific Advocate (SA)
Claim: Point of order, you gotta really—

### Conspiracy Advocate (CA)
Claim: Let me—let me finish the thought—

### Scientific Advocate (SA)
Claim: You can’t say this.

### Conspiracy Advocate (CA)
Claim: You can, you had—

### Scientific Advocate (SA)
Claim: Well this is not true—

### Scientific Advocate (SA)
Claim: like to respond—

### Scientific Advocate (SA)
Claim: Utter nonsense.

### Moderator
Claim: I’ll let you respond—

### Conspiracy Advocate (CA)
Claim: Let—let me just, let me just finish—

### Scientific Advocate (SA)
Claim: I—I want in on this, okay— Rosenkranz Foundation-Intelligence Squared U.S.

### Moderator
Claim: Do.

### Conspiracy Advocate (CA)
Claim: I can say it because it is a fact and in fact if you just look at the trade agreements that we negotiated during the Bush administration US exports have gone up 80 percent faster to those countries than the rest of the world. NAFTA. NAFTA was raised, this—I know this debate’s not about NAFTA, but— And I didn’t negotiate NAFTA, NAFTA went through during the Clinton administration. But you know what? If you look at the statistics in the 10 years before NAFTA and the 10 years after, you discover, that the 10 years after NAFTA passed, US unemployment was lower, US employment was higher, US economic growth was higher after NAFTA. So all of this, these scare tactics—

### Moderator
Claim: Ohhh.

### Conspiracy Advocate (CA)
Claim: —um, excuse me, do not…

### Moderator
Claim: All right, your—

### Conspiracy Advocate (CA)
Claim: —reflect reality—

### Moderator
Claim: Rosenkranz Foundation-Intelligence Squared U.S.—your opponents are conferring and they want to speak, I first want to get the process of questions from the audience and I will come to that—you on that point, before we get to the questions, I just want to get it moving. If you raise your hand, I’d like to move a microphone over to you. If you go up the aisle, gentleman in the blue shirt, you will be next, I want to give you a chance to respond to what Susan Schwab just said—

### Scientific Advocate (SA)
Claim: Oh, very quickly the, you’ve heard the—

### Moderator
Claim: Rick MacArthur—

### Scientific Advocate (SA)
Claim: —you’ve heard the expression industrial tourism I’m sure. The surge in exports from United States to Mexico are fake exports, it’s us sending components to Mexico for assembly, and we’re counting those as exports and they come right back into the United States for sale. We’re even at the point now where we’re, we’re sending oranges to Mexico to be packed, and then shipped back into the United States, we’re calling those exports, they’re fake exports, they’re not—there’s no added value to speak of in those exports. And the people who used to do those assembly jobs, those relatively low-paid assembly jobs, have lost their jobs. More than half a million, probably a million if we count honestly, Rosenkranz Foundation-Intelligence Squared U.S. since NAFTA was passed, and this is a government statistic. So, instead of having somebody making $10 an hour or $11 an hour packing oranges in Florida, it’s now being packed for $1.30 an hour in Mexico, we’re counting that as an export when it’s not an export.

### Moderator
Claim: Leo Gerard, you’re—

### Scientific Advocate (SA)
Claim: The—

### Scientific Advocate (SA)
Claim: It’s a phony export.

### Moderator
Claim: Leo Gerard of the steelworkers—

### Scientific Advocate (SA)
Claim: Two—couple of quick points. And I could give Susan the point that our exports have gone up, but our imports, more than doubled. So we—when we signed—we could do NAFTA. When we signed NAFTA we had a slight trade surplus with Mexico. 10 years after NAFTA we’ve had record trade deficits year after year with Mexico. When we did PNTR trade with China was relatively in balance, only a couple of hundred million dollars either way. We’re now setting record trade deficit with China, China’s trade deficit year over year, is 70 percent of our overall trade deficit.

Rosenkranz Foundation-Intelligence Squared U.S.

### Conspiracy Advocate (CA)
Claim: Today we have a—

### Scientific Advocate (SA)
Claim: What—let—

### Conspiracy Advocate (CA)
Claim: —manufactured—

### Scientific Advocate (SA)
Claim: Let me finish—

### Moderator
Claim: —let him finish, Susan.

### Scientific Advocate (SA)
Claim: And the one thing that we were told, we need to get trained for these high-tech computer jobs, well you know what? We’ve now got a deficit in advanced-technology products, so the high-end jobs that we were told we would train for are gone.

### Conspiracy Advocate (CA)
Claim: National Association of Manufacturers has shown us—

### Scientific Advocate (SA)
Claim: They’re the multi-national spokesmen—

### Conspiracy Advocate (CA)
Claim: —that US trade balance with our FTA partners, is now in surplus—

### Scientific Advocate (SA)
Claim: Oh, that’s craziness—

### Conspiracy Advocate (CA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S.—in manufactured goods.

### Scientific Advocate (SA)
Claim: Well—

### Conspiracy Advocate (CA)
Claim: If you look—

### Scientific Advocate (SA)
Claim: Susan—

### Conspiracy Advocate (CA)
Claim: I’m sorry, let me just—

### Moderator
Claim: I’m going to stop this because we have a dispute over the facts at this point that can’t be settled here—

### Scientific Advocate (SA)
Claim: They love cheap labor—

### Moderator
Claim: —and I want to go to the gentleman—

### Scientific Advocate (SA)
Claim: They love cheap labor there—

### Moderator
Claim: —in the blue jacket. Gentleman in the blue jacket.

### Scientific Advocate (SA)
Claim: It can— Rosenkranz Foundation-Intelligence Squared U.S.

### Moderator
Claim: On our motion that—

### Scientific Advocate (SA)
Claim: —it can be settled—

### Moderator
Claim: —Hire American, Buy American policies with backfire, and please stand up, sir—

### Scientific Advocate (SA)
Claim: We’ve got a trade surplus, how did we end up with a trade deficit. AUDIENCE MEMBER (male) Thank you.

### Moderator
Claim: Mr. Gerard. AUDIENCE MEMBER (male) As a Colombian manufacturer, I would be on the side of the protectionists…a hundred percent because if not, we’ll be run out of business. The fact is that one of the US manufacturers, with 1 percent of its yearly production, would run us out of the whole mark—of the whole Colombian market. So we think that it’s dangerous for us, and we think that the policy of subsidies does exist in the United States which it doesn’t in Colombia, and as such, I should be a protectionist. To be intellectually honest however—

Rosenkranz Foundation-Intelligence Squared U.S. Sir, I need you to get to a question, please. With respect— AUDIENCE MEMBER (male) Just very briefly, I have—

It was—I really need you to get to the question— AUDIENCE MEMBER (male) I have no doubt, that it’s good for our country to sign a free trade agreement. So, the question to, Mrs., Trade Representative—

Schwab, Susan Schwab— AUDIENCE MEMBER I’m sorry, is, why, if I think you believe that what I’m stating is true, why has it not been signed.

### Conspiracy Advocate (CA)
Claim: Do I answer that now—

### Moderator
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: The Colombia-US free trade agreement was, uh, signed over two years ago, three— close to three years ago now. It would benefit both countries, the independent International Trade Commission has told us that US exports would go up to Colombia, Colombia’s exports would go up to the United States. In fact, because Rosenkranz Foundation-Intelligence Squared U.S. Colombia has preferential access to the US market now, US exports would go up to Colombia even faster than Colombia’s exports to the United States, but Colombia would derive new foreign direct investment. We made all of these arguments on Capitol Hill. The Democratic leadership reached an agreement with the Democratic leadership in 2007 to add special labor and environmental protections to that agreement, after it had been signed and was very grateful that the government of Colombia was willing to incorporate that in the agreement. And lo and behold, the Democratic leadership in the Congress decided they just didn’t want to move the legislation. And a legislative process that has worked for the United States since 1974, was turned on its head, when the Speaker of the House refused to allow a vote on the Colombia Free Trade Agreement when we knew the votes were there, in the House and in the Senate to pass it.

### Moderator
Claim: In two sentences—

### Conspiracy Advocate (CA)
Claim: John, can I—

### Moderator
Claim: —what’s the lesson related to our motion tonight?

### Conspiracy Advocate (CA)
Claim: It—well, this— Rosenkranz Foundation-Intelligence Squared U.S.

### Moderator
Claim: Perhaps none.

### Conspiracy Advocate (CA)
Claim: The—well, I mean the,—

### Conspiracy Advocate (CA)
Claim: Actually there is. It’s that—

### Conspiracy Advocate (CA)
Claim: No, this is a—

### Conspiracy Advocate (CA)
Claim: They’re right, there isn’t—

### Moderator
Claim: Doug Irwin—

### Conspiracy Advocate (CA)
Claim: —free trade in the world, because Colombia has very high tariffs against our goods, and we allow them duty-free access to our market. So it’s very much unfair and the Colombia FTA would’ve evened that play—leveled that playing field.

### Conspiracy Advocate (CA)
Claim: I can answer that question now, sorry, now that I’ve thought about it—in terms of Buy American, here we’re talking about Buy American this, Buy American that. Our trading partners, Canada, Europe, are negotiating free trade agreements with Colombia, so that they can have preferential access and lock our guys out, that’s what’s happening— Rosenkranz Foundation-Intelligence Squared U.S.

### Scientific Advocate (SA)
Claim: And not signing.

### Moderator
Claim: Question from the—

### Scientific Advocate (SA)
Claim: You know, I just have to cut in here because I’d love to hear Jagdish Bhagwati on bilateral trade agreements. And this may be a little too theoretical but bilateral trade agreements are anathema to true free-trade theorists for the most part. They do not— It’s not about comparative advantage. It’s about political bullying and political favoritism and all the FTA’s are going to do is exactly what Susan said they’re going to do. They’re going to bring in uncompetitive FTA’s, and we’re going to have a trade war in that sense, and I have the sense that—

### Scientific Advocate (SA)
Claim: John, I just want to…go back to—

### Moderator
Claim: Yeah, go ahead, Leo—

### Scientific Advocate (SA)
Claim: —I want to go back to the point that I was cut off making, a minute ago. That,—

### Scientific Advocate (SA)
Claim: Well—

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S.—when Susan made that point that all of the trading agreements that we’ve negotiated are all in surplus.

### Conspiracy Advocate (CA)
Claim: No, no, that’s not what I said—

### Scientific Advocate (SA)
Claim: I can’t make—I can’t do the math.

### Conspiracy Advocate (CA)
Claim: That’s not what I said—

### Scientific Advocate (SA)
Claim: We’re in fact running, a $6.5 trillion accumulated trade debt since 1994. We’ve been setting record trade deficits year after year, and including in the last four years, a trade deficit in advanced-technology products. The— when we lost the industrial base of America, we lose the creativity and the innovation and the engineering all of the stuff that takes us to the next level. And right now we’re hollowed out to the point where, Jeff Immelt, that Susan referred to at G.E., has now publicly said that we’ve gone too far with this, we’ve outsourced too much, and we’ve gotta go back and rebuild the manufacturing base and America needs an industrial strategy that will favor America. Jeff isn’t a left-wing trade unionist by any stretch of the imagination.

### Scientific Advocate (SA)
Claim: Can I—

### Conspiracy Advocate (CA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S. He also doesn’t—

### Moderator
Claim: I’m going to go up to the gentleman in the middle, and I really want to hear a question. AUDIENCE MEMBER (male) I have one… I would like to ask the question to the side that is arguing for the motion, do you—I’m right here.

For the motion that Buy American will backfire. AUDIENCE MEMBER (male) Sorry—hi. I was wondering if you’re okay with the fact that the overwhelming majority of our economy is driven by consumerism. If you’re not okay with that, then wouldn’t it be a plus for us to then instill some sort of Buy American, Hire American policies. If that’s a no, then wouldn’t that lead to an economy that’s more reliant on consumerism, as it already is overwhelmingly. In the context of that, I’d like to say to Professor Irwin—

I’m going to stop you there ‘cause I want it to be— AUDIENCE MEMBER

—one question and you’ve actually got several clauses in there— Rosenkranz Foundation-Intelligence Squared U.S. AUDIENCE MEMBER (male) No, no, in the context of that I would like—

—I’m, I’m going to stop you, sir— AUDIENCE MEMBER (male)—to say that you’re—

Jagdish, can you take that question, please— AUDIENCE MEMBER (male) I’m sorry, that, also there’s—

### Conspiracy Advocate (CA)
Claim: Um—

### Moderator
Claim: Go ahead, go ahead.

### Conspiracy Advocate (CA)
Claim: There’s somebody talking, I—?

### Moderator
Claim: Yeah, I’m asking him to— I don’t mean to be rude—

### Conspiracy Advocate (CA)
Claim: Maybe he’s answering the question—

### Moderator
Claim: —I just want to move it along and it was multi-part and it’s too complicated— Rosenkranz Foundation-Intelligence Squared U.S. AUDIENCE MEMBER (male)

Go—

### Conspiracy Advocate (CA)
Claim: I couldn’t quite get at what exactly the, he was driving at. But let me just get back very quickly to Jeff Madrick’s question— free trade agreements, I totally disagree with what Susan said, I don’t know whether it’s kosher to disagree. But, I mean, the preferential trade agreements are between us as a major power, with little guys in different parts of the world, relatively except for South Korea. And if you look at any—

### Conspiracy Advocate (CA)
Claim: Australia—?

### Conspiracy Advocate (CA)
Claim: —free trade agreement—

### Conspiracy Advocate (CA)
Claim: Singapore—

### Conspiracy Advocate (CA)
Claim: —it’s about that big, it consists of all kinds of atrocities being perpetrated on the smaller countries. And I think it pretends to be a trade agreement but is actually a trade—a non-trade agreement and I think, we need to get away from these Rosenkranz Foundation-Intelligence Squared U.S. altogether, and get back to the multilateral trading system.

### Conspiracy Advocate (CA)
Claim: I think we have a—

### Moderator
Claim: Another question from the audience—

### Conspiracy Advocate (CA)
Claim: It— we apparently have a—

### Moderator
Claim: —gentleman in the white shirt, please. Right behind you? AUDIENCE MEMBER (male) I’ll try and keep it short. I believe that America’s a capitalist country, and capitalism rewards people who are more efficient, and people who can give you more for less. So, if these foreign countries can produce steel, like Pasco in Korea can produce steel better than US Steel or Nucor can, then why are we going to reward mediocrity, why are we going to reward the inefficiency of the American system, when we can get—when we should get incentives to the American companies to become as efficient as these foreign companies—

### Scientific Advocate (SA)
Claim: Who—

### Moderator
Claim: Let’s give that question to the Leo Gerard of the steelworkers—

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S. The problem with that question, is it’s living in facts that were probably from the 1970s and early ‘80s. And the fact is—

### Scientific Advocate (SA)
Claim: —the—well… By the time we got to the economic collapse of last fall, last year…American steel was the cheapest of any major industrial country and American steel sold in America, was cheaper than Chinese steel sold in China. And the reason for that is that China doesn’t have sufficient raw material. But China went…think about this if we talk about a sort of a level playing field. From two thousand and three, roughly late 2002, to 2007, China went from being able to produce 150 million tons of steel, to 500 million tons of steel. In a traditional system using traditional finance, they could’ve never generated enough profits and they could’ve never accessed enough capital markets to make that kind of investment to do that to their industry, in a period of roughly five years. That was done because they got subsidies, they got cheap money, they got free land, they got no enforcement, they got free transportation, they got export subsidies, when they exported stuff to us they got the money back, and they generated that, and it’s a mercantilist system, I’m not angry at China— Rosenkranz Foundation-Intelligence Squared U.S.

### Conspiracy Advocate (CA)
Claim: I would be

### Scientific Advocate (SA)
Claim: I’m not angry at China—

### Conspiracy Advocate (CA)
Claim: I—

### Scientific Advocate (SA)
Claim: —they decided to do that so they could grow their steel industry, we decided to punish our steel industry, and reward those that take jobs offshore with giving them tax breaks.

### Conspiracy Advocate (CA)
Claim: It is…

### Moderator
Claim: Okay, the side for the motion wants to respond to that—

### Conspiracy Advocate (CA)
Claim: But we pay a lot of subsidies too—

### Moderator
Claim: Jagdish Bhagwati—

### Conspiracy Advocate (CA)
Claim: —at usually the state and local level. They are up to huge amounts, people like Mayor Bloomberg even announced with great glee that we managed to attract industry to New York, and all the governors compete for it also. So I think actually, we don’t have clean hands either, so you know, for us to say, others are Rosenkranz Foundation-Intelligence Squared U.S. subsidizing and we are not—

### Scientific Advocate (SA)
Claim: I was just dealing with the steel question—

### Conspiracy Advocate (CA)
Claim: —doesn’t make any sense—

### Scientific Advocate (SA)
Claim: —he asked—he asked me a steel question, I don’t think we ought to subsidize each other at all.

### Moderator
Claim: Okay, I want, I—

### Scientific Advocate (SA)
Claim: Can I just ask, what do you mean, capitalism is…who told you capitalism is efficient. What do, I’d like to hear him, may—could, you pretend you’re defending your doctoral thesis. And I’d be happy to argue that capitalism can be enormously inefficient, it can tend towards monopoly, it can tend towards monopolistic practices. We’ve just been through a supposed—

### Moderator
Claim: I agree—

### Scientific Advocate (SA)
Claim: —boom—

### Moderator
Claim: I agree— John, it’s a wonderful thesis question but we ought— Rosenkranz Foundation-Intelligence Squared U.S. AUDIENCE MEMBER (male) Well, I really said that—

Come on, sir, let’s move on— AUDIENCE MEMBER (male)—is where we are—

—to the—

### Scientific Advocate (SA)
Claim: And at what cost—at what cost—

### Moderator
Claim: —as you—

### Moderator
Claim: John, please—

### Scientific Advocate (SA)
Claim: Yeah, thanks.

### Moderator
Claim: As you rise I want to remind you that we’re in the Q-and-A section, of our… Intelligence Squared debate—

### Scientific Advocate (SA)
Claim: We’re just in the A section—

### Moderator
Claim: —I’m John Donvan, your moderator… Rosenkranz Foundation-Intelligence Squared U.S. The motion is that, Hire American, Buy American policies will backfire, ma’am, your question, please. AUDIENCE MEMBER (female) We’re at NYU at the moment that happens to have a very modern little faculty, with global faculty, global students. And I think they know something. America is a big, complex influential place. It’s the epicenter of financial crisis, it’s in the middle of political and social change. And I think America needs to tell it to the world. I was wondering if the opposition have admitted from the start that they’re at most only half-right in this debate, or will they defend the Hire American policy.

### Scientific Advocate (SA)
Claim: Are they—

### Moderator
Claim: The question is were you—

### Scientific Advocate (SA)
Claim: You know, I’m intri—

### Moderator
Claim: —you’re, you’re not just talking about Buy American but Hire American—

### Scientific Advocate (SA)
Claim: Yeah, I’m intrigued, you seem to think that that America—

### Moderator
Claim: Jeff Madrick—

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S.—the implication of what you’re saying is that the credit crisis was somehow caused by people who don’t believe in market processes. The credit crisis was caused, I think, most believe people, or at least in large part, was caused, because of lack of government intervention, and because of the inefficiencies, and unfairness, of unfettered free markets. The free trade policies— AUDIENCE MEMBER (male) You’re off the topic!

I’m not off the topic, that’s what she just asked— AUDIENCE MEMBER (male) No she didn’t. Have some constraint and listen.

Can I just— AUDIENCE MEMBER (female) Yeah—

### Moderator
Claim: Jeff, you can take it.

### Scientific Advocate (SA)
Claim: I believe you’re wrong, sir, and I’m going to continue. Okay?

### Moderator
Claim: But Jeff—

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S. The point is that we—America is responsible for much of that credit crisis, because it believed in free-market theory. Now, free trade theory, is a precise analogy to efficient market financial theory. It argues that all these markets in the world work very efficiently like this fellow has said. If Korea makes something efficiently why shouldn’t we reward them. Well, their wages are very low, but are they making something, are there more incentives, should we have an incentive battle? So, are we—do we argue that, trade is good? I think all three of us argue that trade is good. Do we argue that it’s become unbalanced, that this is tipped over far too much, that evidence of wages in America doing so poorly, is clear. That’s what I—

### Conspiracy Advocate (CA)
Claim: Can I get back to the question?

### Moderator
Claim: Please do. Fair enough, fair call.

### Conspiracy Advocate (CA)
Claim: Let me just say that, I’m myself an immigrant, okay? I don’t think I’ve done much harm to this country. I think Mr. Gerard, a great…you know, description that you were a Canadian—

### Scientific Advocate (SA)
Claim: I don’t think I’ve done much harm either— Rosenkranz Foundation-Intelligence Squared U.S.

### Conspiracy Advocate (CA)
Claim: That you were a Canadian and I— Maybe you’ve done harm to this country but I— I think you should defend it yourself. But I do think, that this country as Susan, you know, eloquently pointed out has done enormously well, as a result of immigration. And I think—

### Scientific Advocate (SA)
Claim: No, no—

### Conspiracy Advocate (CA)
Claim: —to indulge in, you know—

### Scientific Advocate (SA)
Claim: Listen, this is

### Conspiracy Advocate (CA)
Claim: —hiring aliens last, firing them first, the sort of movements which are going on, are extremely un-American and also extremely inefficient. We have really prospered on the… I mean—

### Scientific Advocate (SA)
Claim: No, no, I want to—

### Moderator
Claim: All right, Leo…Leo Gerard—take that on.

### Scientific Advocate (SA)
Claim: I don’t know where this argument came from, that I don’t know anyone who’s against immigration. But what— Rosenkranz Foundation-Intelligence Squared U.S.

### Scientific Advocate (SA)
Claim: —what I am against, what I am against, is when Microsoft will want to bring in engineers from India, that will work for $12,000, while they’re laying off computer engineers that were getting paid $60,000.

### Conspiracy Advocate (CA)
Claim: Well—

### Scientific Advocate (SA)
Claim: And want to use the visa system to do that. I don’t think—

### Conspiracy Advocate (CA)
Claim: Um—

### Scientific Advocate (SA)
Claim: —I don’t think that that’s right. Now I’m all for, obviously, as you are—

### Conspiracy Advocate (CA)
Claim: Yeah—

### Scientific Advocate (SA)
Claim: I’m all for the ability to come here, and work within the system that is but don’t use me to come in and drive down wages of computer engineers or anyone else.

### Conspiracy Advocate (CA)
Claim: Yeah, but let— Rosenkranz Foundation-Intelligence Squared U.S.

### Scientific Advocate (SA)
Claim: That’s the argument—

### Conspiracy Advocate (CA)
Claim: —let me just explain one thing in contradiction of that—

### Scientific Advocate (SA)
Claim: And by the way I haven’t done anything wrong, I haven’t damaged anybody.

### Conspiracy Advocate (CA)
Claim: Well, I’m glad you say that—

### Moderator
Claim: Jagdish Bhagwati—

### Scientific Advocate (SA)
Claim: Yet.

### Conspiracy Advocate (CA)
Claim: Uh— I hope you’re able to persuade others about— in this audience— when Intel, Bill Gates, et cetera, go out and get people from say India, the vast majority of those people are fantastically able, they’re trained at the best institutions—

### Scientific Advocate (SA)
Claim: Absolutely—

### Conspiracy Advocate (CA)
Claim: —in the country. So we are going out and looking for enormous talent.

### Scientific Advocate (SA)
Claim: Rosenkranz Foundation-Intelligence Squared U.S. Absolutely and we should pay them—

### Conspiracy Advocate (CA)
Claim: But, I am—

### Scientific Advocate (SA)
Claim: —enormous salaries—

### Conspiracy Advocate (CA)
Claim: —a professor as you know, and in every class there is a tail of about 30 percent, who really should never have been admitted but somehow managed to get in.

### Scientific Advocate (SA)
Claim: Um…

### Conspiracy Advocate (CA)
Claim: Everywhere. I’ve taught at MIT, I’ve taught at Columbia—

### Scientific Advocate (SA)
Claim: Where—

### Conspiracy Advocate (CA)
Claim: —everywhere it’s the same, but, I would just say one thing. Which is that there are people, who could be employed but who are kind of at the bottom end, they’re not really comparable to the kinds of people we are going out and getting. And so I think the nation prospers by having those people come in, create jobs, because it’s not a given number of jobs that we are talking about.

Rosenkranz Foundation-Intelligence Squared U.S. And I think the other people will find their own way, in jobs which are more appropriate to their qualifications—

### Scientific Advocate (SA)
Claim: But that’s, that’s illegal immigration—

### Moderator
Claim: And we’ll take another question from the gentleman who’s standing with the microphone— AUDIENCE MEMBER (male) Yes. Let’s stipulate that the effect of impeding lower-cost goods, is higher prices for goods, tires, pickup trucks, et cetera, in fact that is the purpose of protectionist policies on their face is to, prop up prices, in turn, propping up wages. What is the—and this is the three gentleman on that side. What is the ethical—

I just want to point out, you’re addressing your question to the team arguing against the motion— AUDIENCE MEMBER (male) Okay, sorry, that’s right—

—that Buy American will backfire— AUDIENCE MEMBER (male) Against the motion, that’s correct. What is the ethical justification, for transferring money from the broad American population, to workers in specific industries, which is again Rosenkranz Foundation-Intelligence Squared U.S. inarguably the cost of im— the effect of impeding lower-cost imports.

### Scientific Advocate (SA)
Claim: The problem with your question, I’ll keep it short so that the others can get a chance.

### Moderator
Claim: This is Leo Gerard speaking.

### Scientific Advocate (SA)
Claim: The problem with your question is you don’t get to the point of how did we so-called end up with lower cost. If we end up instead of paying a living wage we’re paying less than a living wage, if we’re giving cheap money and extra subsidies, if we’re giving tax dollars to export credits when they export, if we’re not enforcing safety standards, if we’re not enforcing environmental standards, you could send me anywhere and give me those rules and I can develop the cheapest product. But what’s the moral right. And in this case what we’ve been doing, what we are doing today, is we’re taking American dollars, and we’re sending them to…

### Scientific Advocate (SA)
Claim: That is the same kind of argument—

### Moderator
Claim: Jeff Madrick—

### Scientific Advocate (SA)
Claim: —that was used against labor unionization, throughout American economic history. What is the ethical argument for raising wages above some supposed, and I would argue hypothetical market rate of wages. The fact is, the assumption behind—and I see you smiling there. The assumption, behind your comment is that these markets work very well, reflect cost, that people without labor unions to continue that analogy, will always get what they’re worth, and everybody will do well. It’s just not unfortunately the way it works, it works maybe in your classroom. But it doesn’t work in the real world, and along—

### Conspiracy Advocate (CA)
Claim: Can I——

## Round 3

### Moderator
Claim: And that concludes round two of our debate. Robert Rosenkranz, I just want to say, you moved this thing downtown and it really gets spicy. We’re Rosenkranz Foundation-Intelligence Squared U.S. now in the home stretch and in a very short time you, the audience, will be deciding who has won this debate. But I want to recall that at the beginning we asked you whether you agreed or disagreed with our motion that: Buy American/Hire American Policies Will Backfire. At the beginning fifty-seven percent of you agreed with the motion. Twenty percent disagreed and twenty- three percent were undecided. In just a few minutes we’ll be asking you for a final time and your response is going to determine the winner. But first we want to start round three, closing statements. In this case, two minutes each for each speaker. Each speaker has a short summary statement. It’s their last chance to change your minds. Our motion, once again, is: Buy American/Hire American Policies Will Backfire. And speaking against our motion and summing up, Leo Gerard, International President of the United Steel Workers. Leo.

### Scientific Advocate (SA)
Claim: My point is... My point will be very brief. That during the period of time that we’ve adopted the philosophy that the other side is defending – and you can’t defend that without talking about the issues of trade overall. And during the period of time that we’ve entered into that blind drive to that kind of a trade and investment ideology and manufacturing, America has gone from being the world's largest creditor nation to the world’s largest debtor nation. Wages of average Americans have Rosenkranz Foundation-Intelligence Squared U.S. stagnated and fallen, that the industrial strength of America has gone from being sapped, uh, at twenty-eight percent at one time, now down to nine percent.

We’ve had an accumulated trade debt that no one on the other side has tried to defend, of six and a half trillion dollars. Some of you in the room may know what a billion is. How many of you know what a trillion is? Think about this: A billion seconds is roughly the nineteen...late 1950s. A billion minutes ago, Christ was on earth. A billion hours ago we lived in caves. And in the period since 1994 we’ve accumulated a six and a half trillion dollar trade debt. We’ve hollowed out our economy to the point now where you’ve got the Chinese will probably raise at the G20 whether or not we should move to another form of currency because the American dollar is not sustainable. I think that the way we do that is we develop a strategy that’s going to rebuild the American industrial base and we have to do that by focusing, not just on subsidies but innovation, creativity and demanding that our trading partners level the playing field. And we’re not going to be able to win against unfair trade and we shouldn’t pretend we can.

### Moderator
Claim: Leo Gerard, your time is up. Thank you very much. Summarizing for the motion: Buy American/Hire Rosenkranz Foundation-Intelligence Squared U.S. American Policies Will Backfire, here is Douglas Irwin, Professor of Economics at Dartmouth College.

### Conspiracy Advocate (CA)
Claim: Well, first of all, just in terms of the proposition before the house, I think they have backfired. I think that’s demonstrable. I think you have no choice but to vote affirmative. But let me make some major concessions to the other side. I think what you’re hearing is things we’ve heard in the 1980s. We’ve actually even heard them in the 1950s and beforehand-- and that is that economic change is very hard and very painful and we should do something to address that. I happen to think that the remedies they’re suggesting are wrong, will backfire and actually don’t really address the underlying problem. We’ve talked about the declining share of workers in manufacturing. Manufacturing is a victim of its own success. A century ago a third of the work force in the United States was in agriculture. Now it’s about two percent. Why? Because the productivity of the American farmers is absolutely astronomical. The same thing has happened with American factories. They’re churning out stuff and we just need fewer workers. They’re much more capital intensive as productivity. Think about Manchester, New Hampshire. I’m from New Hampshire. If you’ve ever been to visit Manchester-- lovely city, huge brick building, over a mile long, former textile mill. Not a single shoe, not a single textile made there anymore.

It’s a thriving city.

Rosenkranz Foundation-Intelligence Squared U.S. It wasn’t always thriving and it went through some very difficult times. But it made that change. It had to. The jobs actually were stolen by the south, not by a foreign country. And then they left for the south for other countries. Jeff Madrick said, You know, I’m tired of hearing about people saying trade doesn’t, you don’t lose jobs. Actually, I’ll give you a copy of my book, because in one of the chapters I say, First thing, trade destroys jobs. Trade also creates jobs. But there’s no denying that trade destroys jobs and certainly in poor, competing industries. But it creates jobs elsewhere. The question is the balance. Guess what? Technology destroys jobs. What’s happened to all the bank tellers? What’s happened to all the secretaries? Do we stop technology? No, we have to adjust to it and become a better society for it. I do believe the trade deficit is a problem. But it’s not mercantilism of China or what have you. China is very poor but their savings rate...What was the personal savings rate in the United States?

### Moderator
Claim: Douglas Irwin--

### Conspiracy Advocate (CA)
Claim: Zero.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Squared U.S. Douglas Irwin, your time is up.

### Conspiracy Advocate (CA)
Claim: But they can save in China. Thank you.

### Moderator
Claim: Summarizing against the motion that: Buy American/Hire American Policies Will Backfire, John R. MacArthur, known as Rick MacArthur, President and Publisher of Harper’s magazine.

### Scientific Advocate (SA)
Claim: Very quickly, there are lots of anecdotal examples of de- automation in outsourcing, by the way, Professor Irwin, where products that used to be made on automated assembly lines in the United States are now being made by hand in Mexico and China. But I’ll put that aside and just say that I finally get to my main point, and get away from the statistics, and point out to you that Japan and China don’t believe in free trade any more than I do. And if we don’t start buying American soon or doing something, installing some kind of compensatory tariffs, Buy American provisions-- and I’ll acknowledge to the other side that the tariff such as it is has been corruptly applied throughout the decades and the centuries that we’ve had it. But that generally speaking, there has to be some kind of compensation for American policy that has favored the production of things that used to made here by cheap labor in foreign countries where you Rosenkranz Foundation-Intelligence Squared U.S. cannot organize a union and you have no Environmental Protection Agency.

But even if you don’t feel an ethical obligation to your fellow citizens or to the poor workers working for thirty cents an hour in China or a dollar twenty-five an hour in Mexico, even if you have no concern, ethical concern about them, I urge you to come over to our side, vote for our side out of enlightened self-interest. Because if we don’t do something to compensate for these pro- cheap labor, pro-outsourcing policies we’ve been pursuing for the last twenty years particularly-- but really since the war-- we’re going to end up with a political vacuum that will be filled not by a nice, civilized businessman like Ross Perot, but by a very ugly rightwing populist. It’s already brewing in the United States. And if you don’t hurry up and do something about it, there won’t be any discussion about free trade anymore. There’s going to be only discussion about how to shut the doors to immigration and how to keep the labor unions from organizing immigrants, for example.

### Moderator
Claim: Thank, thank you, John MacArthur.

Summarizing for the motion in this Intelligence Rosenkranz Foundation-Intelligence Squared U.S. Squared debate where our motion is: Buy American/Hire American Policies Will Backfire, Jagdish Bhagwati, university Professor, Economics and Law at Columbia University.

### Conspiracy Advocate (CA)
Claim: Let me first focus on Buy American provisions because that’s really what the motion is about. And there I would just simply say that while immediately you see that you’re saving some jobs, you’re losing many more because of the downstream effects, retaliation effects, diffusion or protectionism effects. By the time you’ve added it up, you’re losing far more than you’re gaining. And I think it’s just being penny wise and pound foolish. And that’s the fundamental point we need to understand. The second point relates to the more general issue of protectionism which has come up from the other side. I think certainly, Mr. Gerard, and I think to some extent, the other people on the other side, have been focusing on the fear that trade has actually putting downward pressure on the wages of our workers. As a Democrat, I’m certainly concerned about it and I think most people are concerned about it. I mean, these are the bottom thirty percent of our society and we ought to worry about them. The only question is whether protectionism is the answer. And I think what is going on basically is that massive technological change is going on, and I think we need to worry about that and how to adapt to that. And if we don’t do that we’re not going to get an, Rosenkranz Foundation-Intelligence Squared U.S. appropriate answer to the problem.

You take acute technological change going on assembly lines. Entire assembly lines are wiped out. If you’re going to see, you know, take your child to see Charlie Chaplin’s Modern Times and they say that he goes berserk on the assembly line and they say, Can you take me to see an assembly line? Well, you can but you won’t see Charlie Chaplin there. You will see five people in a cage up there. So what has happened is that large numbers of jobs have been lost and you’re getting more volatility as a result, for the unskilled workers. And we have to really rethink the whole issue of how we accommodate the institutional change to be able to support workers, but protectionism is not the answer.

### Moderator
Claim: Thank you very much. Summarizing his position against our motion, Jeff Madrick, Senior Fellow at the Schwartz Center for Economic Policy Analysis at the New School. Jeff Madrick.

### Scientific Advocate (SA)
Claim: Thank you. The first narrow motion, Buy American/Hire American will not have a reverse impact. It’s a rather small issue. What it will do is allow our stimulus to work effectively. That is our first priority. The way it’s now structured, our stimulus to get ourselves out of this recession, will leak badly Rosenkranz Foundation-Intelligence Squared U.S. overseas. That’s the principle issue. The opposition has talked about how it will inevitably cost jobs that use simple, people over there think it will save jobs in the near term. But if you thought about it for a second or two you’d realize there are second, third and fourth order effects. The fact is that both theory and most empirical studies suggest that more jobs are lost than the opposition is acknowledging. In fact, on balance the theory says a significant portion of jobs or wages are lost in this kind of situation.

In balance, the whole wage package may be higher but the distribution of those wages changes. Now, free market theory is very compelling. It is a simple and pretty ideology. For the most part, the opposition has put forward this theory. And I think, judging by some of the questions, many of you believe it out there-- that efficient markets exist. I’m a little surprised I hear so much out there, given the financial crisis because we were told time and again that bonuses made sense, that securitization made sense, that even some people-- like Alan Greenspan, and to some degree, Ben Bernanke-- told us high house prices make sense. They resorted to the same kind of thinking that is behind this idea that we just let markets work and sort it out. The way to respond to change is through active government working with business, active incentives. And this kind of argument has Rosenkranz Foundation-Intelligence Squared U.S. diminished our ability to do that in America.

### Moderator
Claim: Thank you, Jeff Madrick. And finally, speaking for the motion: Buy American/Hire American Policies Will Backfire, here is Susan Schwab, former U.S. trade representative.

### Conspiracy Advocate (CA)
Claim: But the other side has sort of been bobbing and weaving about the topic on the debate. So I’m forced to address just a couple of issues here on the ethics of open trade. The fact that there have been six hundred million people brought out of poverty in China and India, in part because they have opened their markets over the last two decades, I think is a very strong positive note, how important trade can be and they’re potential new customers of ours. We remain the single largest manufacturer in the world. We want to be selling those turbines, those earth movers, that transportation equipment, the aircraft. It’s very, very important.

And we care as much about U.S. jobs as the other side. However, not a single solitary one of the arguments that they have made would create a single job. And in fact, if you look at the proposition here, the proposition here would destroy-- Buy American/Hire American policies we have been able to show, without question-- would destroy more jobs than it would create. It sounds patriotic. In fact, Buy American/Hire American Rosenkranz Foundation-Intelligence Squared U.S. policies hurt America, hurt Americans. There is zero evidence of any country ever using economic isolationism and buy national policies to achieve and sustain economic development. Someone mentioned Japan. I remember twenty years ago, thirty years ago these same folks were telling us the Japanese were going to wipe out all our manufacturing. We are still, by far, the largest manufacturer in the world. We are the largest exporter in the world. There are millions of U.S. jobs that depend on these exports and that includes exports that we can and should and will be making to foreign countries that have stimulus packages. Clearly, the vote has to be on which side has convinced you that the policies will create more jobs and more opportunities for Americans. Clearly, that is a vote in the alternative because Buy American policies have and have already failed.

### Moderator
Claim: Thank you, Susan Schwab. And that concludes the debating portion of our program. It is now time to learn who has won this debate. We want to ask you to take out your cell phones again and turn them on, briefly. It works the same way as before. You text to the number 99503. For the motion you vote IQYES. If you’re against the motion you vote IQNO. If you remain undecided or became undecided, you vote IQUNDECIDED. And I’ll give you a couple of minutes cause I hear the phones just starting up. The instructions are Rosenkranz Foundation-Intelligence Squared U.S. clear to everyone, I assume. Yeah. Is anyone not done? All right, a lot of people still. Okay. What’s happening? It says you already voted? Is anyone else having that problem, that it’s coming back to you that you voted already? Sorry? It said to call back, leave a message? Yeah. All right, and if you can shut your cell phones down again. To the individuals-- and I think it’s just a few-- for whom it’s glitching, we apologize. We will smooth it out. Okay? So Dana, I’m assuming we’re locking it out? Okay. Voting is over. So we’re going to have the vote in just a moment. But before we do so, first of all, once again, this was a very zesty conversation. I really want to thank both, both of our panels. Looking forward as series four continues, I want to point out that our next debate will be next month-- Tuesday, October 6th. The motion will be: America Cannot and Will Not Succeed in Afghanistan and Pakistan. We are still booking this,. and here’s who we have booked so far: Panelists for the motion are retired U.S. Military Intelligence and Army Special Forces Officer Patrick Lang and Ralph Peters, a retired Army Officer and author; against the motion are President of the New America Foundation and author of The Bin Ladens, Steve Coll. And he is one of the Rosenkranz Foundation-Intelligence Squared U.S. authors of the U.S. Army’s Counterinsurgency Field Manual, Retired Officer and President of the Center for a New American Century, John Nagl and former Assistant Secretary of Defense for Asia, James Shin. All of our debates will continue to be heard on more than a hundred and ninety NPR stations across the country and to that point, when I announce the final results, the second vote results, I’m going to raise my hand and ask you to applause to give us a rousing conclusion to our radio broadcast.

But we are also on television throughout this season, on Bloomberg Television. You can watch all of the fall debates on Bloomberg and read about them also with our other partner, Newsweek. The results of this debate and the content of the debate will be summarized and analyzed in the next edition of Newsweek. Books by tonight’s panelists and DVDs of past debates are on sale in the lobby but Jeff gets a free one from Doug, right?

### Moderator
Claim: That would be unfair.

### Moderator
Claim: Ah heh.

### Moderator
Claim: I should have read it, though.

### Moderator
Claim: Rosenkranz Foundation-Intelligence Squared U.S. All right, is everybody settled down? And I have the results in and our concluding numbers are these: When you came in and voted beforehand, fifty-seven percent of you were for the motion, twenty percent of you were against and seventy-three percent were undecided. After the debate, seventy-two percent are for, fourteen percent against, fourteen percent undecided. The side arguing for the motion wins. Congratulations to that team. Thank you for me, John Donvan, for Intelligence Squared U.S.
