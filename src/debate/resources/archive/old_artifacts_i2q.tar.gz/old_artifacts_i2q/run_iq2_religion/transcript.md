# Debate Transcript

Topic: The World Would Be Better Off Without Religion
Motion: The World Would Be Better Off Without Religion

Debate ID: religion


## Round 1

### Moderator
Claim: We are now in our fifth season. We've done more than 50 of these debates. And we're delighted to have all of you here. But they all happen because of one man, Robert Rosenkranz, who is the chairman of the Rosenkranz Foundation, who brought Intelligence Squared to the city and to this country, in fact. And so I'd like to welcome him to make opening remarks and set the frame for what we're actually talking about here.

### Moderator
Claim: Bless you for coming. Intelligence Squared is primarily known as a public policy debate series, so I'd like to start the evening by sharing with you the reasons we wanted to do a debate about religion. America has always incorporated complex ideas about religion in its political culture. Creationism is invoked in the most famous words of our founding documents, "We hold these truths to be self-evident, that all men are created equal, that they are endowed by their creator with certain inalienable rights."The First Amendment to the Constitution begins with the ringing words, "Congress shall make no law respecting an establishment of religion." But note these words do not banish religion from the public square. Indeed, many of the original 13 colonies had official state religions which the amendment protects from the actions of Congress. Nor is there any constitutional issue when the president, in his role as commander in chief, hires ministers and rabbis and priests to perform religious duties as member of the Armed Forces. Tonight's debate should prove equally complex. Proponents of the motion might cite the violence perpetrated in the name of religion while opponents will counter that most warfare throughout history was totally or primarily about territory and economic advantage.

Proponents might cite the absence of proof for central religious beliefs, indeed, the repugnance of some of them, while opponents emphasize the utility of faith and ritual and helping believers cope with the challenges of life. But both sides are likely to concur that every well-ordered society needs some key moral principles and that every thoughtful person needs a sense of meaning and purpose in life. The key question for tonight's debate, the complex question, is whether those central needs can be better met in a world with or without religion. We have a very outstanding panelist group tonight with us. And it's my privilege at this point to turn the evening back to John Donvan and to our great panel.

### Moderator
Claim: Thank you. Thank you.

And I just-- I would really like to invite one more round of applause for Robert Rosenkranz for making this all possible. True or false, the world would be better off without religion? That's what we're here to debate, another verbal joust from Intelligence Squared U.S. I'm John Donvan of ABC News. We are at the Skirball Center for the Performing Arts at New York University. The world would be better off without religion. Two teams will argue that proposition from opposite sides, one for and one against. And only one team will win. You are live judges. You, our live audience, will be the judges. Let's meet our debaters. They include on the team arguing for the motion, the great-great-grandson of Charles Darwin, author and filmmaker, Matthew Chapman. By his side and on his side, a philosopher who takes a humanistic view of ethics, master of the new College of the Humanities, A.C. Grayling. them, and here to argue against the motion is one of the most influential conservative thinkers in the nation, president of the King's College, Dinesh D'Souza. And his teammate is the rabbi of Sinai temple in Los Angeles, California, David Wolpe. So this is a contest. It's a debate. And you, our audience here at the Skirball Center, will decide the winner. By the time the debate has ended, we'll have asked you to vote two times, once before and once again at the end. And the team that has changed the most minds, the team that has moved its numbers the most will be declared our winner. So let's go on to the preliminary vote. You have a keypad at your seat on the right hand side. And our motion is, again, "The world would be better off without religion." And if you agree with this motion, and it's a negative, without, if you agree with this motion, means you want less religion, push number one. It's these guys. If you disagree with this motion, push number two.

And if you're undecided, push number three. You can ignore the other numbers. And if you made an error, just correct it, and the system will lock in your last vote. So remember, we're going to let you know at the end of the debate what that baseline number is, and we're going to have you vote a second time after the third round. We go in three rounds, opening statements, a middle round where you're involved, and the debaters address one another directly, and then a closing round of short summary statements.

So let's get started. Onto round one. Our motion is, "The world would be better off without religion." And here to speak in support of the motion, A.C. Grayling, Anthony Grayling, philosopher. Put that on your business card, I guess. But it's true. In addition to your current position at the New College of the Humanities, the number of books that you have written on philosophy is now approaching three dozen? And I understand that as an undergraduate at the University of Sussex, you decided you needed more college, more university.

So simultaneously, you pursued a second Bachelor of Arts degree up in London, so you did college twice at the same time? Is that-- what else did--

### Conspiracy Advocate (CA)
Claim: Yes, it's true. It's crazy.

### Moderator
Claim: What did you do in your spare time?

### Conspiracy Advocate (CA)
Claim: Yeah. It's crazy, but it's true.

### Moderator
Claim: Ladies and gentlemen, A.C. Grayling.

### Conspiracy Advocate (CA)
Claim: Thank you. John, thank you very much indeed. I must begin by asking you, if I may, to focus on what the proposition is before us. We're not here to discuss the existence of God. We are not here to discuss whether it's rational, irrational to have faith. We're here to discuss a sociological phenomenon, a man-made phenomenon, religion. You can see the difference. You might call in question whether or not gods and goddesses. But you can't call in question whether or not there is religion. There's plenty of it. History is full of it, and it exists around us all the time today. By the way, I say that religion is man- made advisedly.

There are very few women indeed in the upper half of hierarchies of the world's religions, which perhaps has something to do with the point. Now, religions are very diverse in nature. They have different interpretations of their deities. They say different things about what we can wear and what we can eat and when, how many wives we can have, what rituals we must follow. Despite the fact that they all take the view that they've got the right story, they differ from one another quite dramatically in a number of respects. And this is why, through the course of history, they've burdened mankind with a huge number of conflicts and a great deal of divisiveness. But I'm not going to bore you by rehearsing the story of crusades and inquisitions and the rest. It's a very familiar matter. Although it is, of course, in the interests of apologists of religions to try to forget them. Rather, I wanted to talk about things that religions have in common with one another rather than the things that divide them. They have two things in common with one another.

Most of the time in history, and among many of the orthodox manifestations of religion today, they are similar to one another in-- most of them, giving second-class status to women and being hostile to gays, in being very opposed to most kinds of progress, especially scientific progress. The reason being, of course, that they take it that they received the truth a long time ago, anything between one and 3,000 years ago. And so things that are challenging and are new and offer us different views of the world, they find unpalatable. And so they tend to be very traditionalist, very conservative and rather retrogressive. And that explains a great deal of the social policy and political endeavor that the religions engage in. That's one thing that they tend to have in common with one another.

But another thing they have in common with one another, a very important point, is that they share a structural feature. In fact, they are-- the religions are paradigmatic of a certain kind of organization, what I call a monolithic ideology, a one-size-fits all, top- down, totalizing ideology which says we've got the right story, and you've got to sign up for it.

If you don't sign up for our story, if you don't agree, you are going to pay a sanction of one kind or another. And during the course of history, those sanctions have sometimes been very terrible. It's in this respect in which religions in history and in their orthodox manifestations now, plus in all their manifestations, tend to share with other kinds of totalizing ideologies. So that's why it's no great surprise that Joseph Stalin, for example, was educated in the seminary. What those totalitarianisms share is very, very common. inquisition in Spain in the 15th century and Stalin's Soviet Union in the 20th century say the same thing, "We've got the answer, you've got to agree, and if you don't, you're in trouble."So they have these two features, and the second of them, the structural feature, the idea of being in charge of the truth or of possessing the right story about life in the universe is very opposed to the enlightenment outlook on which our modern Western liberal democracies are based, the enlightenment of the 18th century taught us to think that there isn't one right answer for everybody. It taught us pluralism, taught us individual autonomy, it taught us liberty of conscience, it taught us democracy. Democracy is about people having a conversation, the great conversation of society in which we negotiate with one another about how we go forward, how we organize ourselves in society, and that's very different indeed from thinking that there is one great ruler, one monarch, whether in the sky or on the ground, who tells us what we should do, and that we mustn't think for ourselves, but we must all be orthodox, and indeed this ethical point is a very important one.

There are those people who think that you can't have religion-- you can't have morality without religion, and of course, that isn't true. Everything good about religious morality, loving your neighbor, kindness, concern for others, responsibility as a member of the community, is shared by nonreligious ethical outlooks also. They're very common to all the great ethical theories. I'm an atheist and a humanist, and those values matter deeply to me. If you look at ancient Greek philosophy for example, a dominant strain of thought for nearly 1,000 years before Christianity came to command the mind of Europe, and you see that those values were shared by those thinkers, not because they thought they were told them by a deity but because reason and human experience had offered it to them. And the final point is this. People say, "What's wrong with moderate religion?" you know, those nice folks who go to church on Sundays and who take part in their neighborhoods. And here's the problem with that, moderate religion is religion where people do a little bit of cherry picking.

They take the best bits of the religion, and some of the more embarrassing, or difficult, or awkward, or rebarbative bits they leave to one side. I know very, very few Christians who give away all they own to the poor, who take no thought for tomorrow, who turn their backs on their families if their families disagree and families are going to disagree if they do give away everything, who don't marry, who stay celibate. I find very few Christians actually live the New Testament morality, they cherry pick. Unkind people would call that "hypocrisy." At the other end of the scale, however, are those who take their religion extremely seriously, the extremists, we call it them. The point about the extremists is that they are the most honest of the people who have a religious view because they commit themselves to what their tradition tells them, and they stay closest to the text. Now, if that's real religion, that's honest religion, the world is very much better off without it.

And if the world is much better off without the true and the honest form of religion, why not put the hypocrites in with them, too? Thank you.

### Moderator
Claim: Thank you. Thank you, Anthony Grayling. Our motion is "The world would be better off without religion," and here to speak against the motion, David Wolpe. He's the rabbi of Sinai Temple in Los Angeles, California. Newsweek Magazine named you-- what is this, the way it was phrased, the number one pulpit rabbi in America.

### Scientific Advocate (SA)
Claim: I hope we're not voting on that tonight.

### Moderator
Claim: I just want to-- I mean, do they have playoffs or--

### Scientific Advocate (SA)
Claim: Oh, yes. Yeah, stadiums, playoffs, National league, American league.

### Moderator
Claim: All right. Ladies and gentlemen-- this pulpit is yours--

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: --David Wolpe.

### Scientific Advocate (SA)
Claim: The caustic and brilliant philosopher at Columbia University, Sidney Morgenbesser, was once sitting in the back of a lecture where the English philosopher, J.L. Austin, said that we know that two negatives make a positive, if I say I will never not miss you, it means I'll always miss you.

But he said there's no language in which two positives make a negative. And from the back of the auditorium Morgenbesser said, yeah, right. Now, I'm going to offer you two positives. I hope not only that they will add to a positive but that you will approach this not in that skeptical frame of mind but at least open to the possibility that there's a lot about religion that you don't hear. You will never see a headline that says religious man feeds hungry man. But it happens all the time. In fact you might be surprised to know what the largest aid organization in the world is. It’s called World Vision, with over 40,000 people in over 100 countries. That’s more than CARE, Save the Children, the worldwide operations of the United States Agency for International Development all combined.

And if you didn’t know that, it’s because the good that religion does is sort of oft interred with its bones, but you hear about every depredation, every sin, every bad thing. And yet today, all over the world, there are millions of religious aid workers who are sustaining people in places that you’ve never heard of and never visited. Right before this conference, both Dinesh and I were in Mexico in Puebla at the Festival of Ideas, and I rode back to the airport with Nicholas Kristof from the New York Times and we were talking about this issue. And he said, “You know, everywhere I go, I see religious aid workers, day after day, year after year, and the difference,” he said, “between religious aid workers and others is they stay.” They don’t go when the crisis is over. And this parallels my own experience when I was in Haiti, helping a friend rebuild an orphanage.

Almost every person I met was a religious aid worker. I remember going to the market in Haiti and I met this man, and I said to him, “What are you doing here?” And he said, “Well, I’m a Mennonite, and I and my group are building homes in the rural areas outside of Port-au-Prince.” So I said, “Why are you doing this?” He said, “Well, I’ve been here for about five or six years, and I came because my son was sent by the church community 20 years ago. And after 15 years of watching my son do this, I thought it’s time for me to go.” This story could be duplicated again and again and again. And, in fact, if tomorrow you took religion out of the world, the world would be tremendously impoverished in terms of the way in which people who are in trouble get help. Evangelical organizations were the first ones on the ground after the tsunami in Indonesia, and that story could be repeated again and again throughout the world. That’s point one.

Here’s point two. The Oxford Handbook of Religion and Health is about to come out in 2012, the Second Edition. In case you won’t find the time to read it, I’m now going to save you the time. This is a handbook that anthologizes over 3,000 studies from the New England Journal of Medicine, JAMA, Lancet, all peer-review journals that are not particularly sympathetic to religion. And this is what it says. Religious Americans give more to charity, volunteer more, participate in civic processes more, attend more meetings, are more likely to vote, to volunteer, less likely to drink, divorce, do drugs. They are much more inclined to be optimistic and feel meaningful about life. They’re less inclined to depression, less inclined to suicide, less inclined to suicidal thoughts. They are much more helpful in their communities. If you want to measure altruism and empathy, the best measure is not age, gender, income, education. It’s whether you’re involved in a religious community.

I’ll give you one study at the University of Miami. They studied people who’d been diagnosed with AIDS, whether they turned to religion or away from religion. Those who turned to religion, several months later, had lower viral loads, lower CD4 counts. They were healthier than those who didn’t. In fact, religion, if you’re part of a religious community as measured by attending services and reading Scripture and praying, it adds on average seven years to your life if you’re a white American male, 14 years if you’re an African American male. Now, the dean of this research, Harold Koenig at Duke University says that he has to point out to you that you may spend those seven years in church, but nonetheless, you have to decide what you want to do with the time. Still, you have the time to do it. All of this is a way of emphasizing that religion and being part of a religious community does enormous good.

I see it day after day, week after week. The little nameless, unremembered acts of kindness and of love about which Wordsworth wrote, that’s what religious people do and in part because it’s a system that encourages goodness, which is why when a religious person does something wrong, people get particular upset. “How can he do this?” He’s supposed to be religious. Every time someone complains about the synagogue, the call begins as follows: “How, in a synagogue, could you…” which is a way of saying you’re supposed to aspire to be better. And that’s exactly right. Mother Teresa was once tending to the wounds of a leper in Calcutta. And wiping the separating wounds from this sick and dying person. And a journalist who'd been following her around for several days said to her, "I wouldn't do that for a million dollars." And without looking up, she said, "Neither would I." It's true.

Many people of all different beliefs and no beliefs do good in this world. But if you want to find an organized system that encourages people to be better, to transcend themselves, that seeks to make the world colorful, kind, compassionate, giving, good, a system that often fails but at least aspires to that, not in little enclaves of this class or this school, but worldwide, consistently, the only one we have ever had is religion. The world without it would be a poorer, sadder and crueler place. Thank you.

### Moderator
Claim: Thank you, David Wolpe. And here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan of ABC News. We have four debaters, two teams of two, fighting it out over this motion, "The world would be better off without religion."We've heard from the first two speakers, and now onto the third. Speaking for the motion, Matthew Chapman. He is a writer and cofounder and president of Science Debate, and in a sense is our real renaissance man tonight. You've also directed films, written books, written magazine articles. You were particularly fascinated by a case I also covered of the Dover School Board wanting to push back against the theory of evolution. And you wrote extensively about that. Of course, you do have some vested interest in your-- it's on your mother's side, your great-great-grandfather?

### Conspiracy Advocate (CA)
Claim: My great-great-grandfather on my mother's side, yes.

### Moderator
Claim: All right. So you have some sparkling DNA walking around tonight as you come to this argument. Ladies and gentlemen, Matthew Chapman.

### Conspiracy Advocate (CA)
Claim: Thank you. I am not a professional like these guys, so I'm going to read my notes. I apologize. Religion makes two big claims: God really exists, and religion makes us behave better.

But does religion make us behave better? To partially answer that question, let me read you a verse or two from the Bible. Deuteronomy, Chapter 25, Verses 11 and 12. "When men strive together one with another, and the wife of the one draweth near for to deliver her husband out of the hand of him that smiteth him and putteth forth a hand and taketh him by the secrets, then shalt thou cut off her hand." Roughly translated, this means that if you're in a fight, and your wife tries to help you by grabbing your opponent's balls, you should chop her hand off. It's there. I mean, I can show you. I know it's kind of cheap to poke fun at the Bible because it's so easy, but-- but there is-- there is a serious point here, which is that far from making us behave better, religion often complicates and distorts morality.

By any reasonable standards, hacking bits off your wife is far worse than her squeezing your enemy's nuts. The thing is that in almost any holy book, you can find something that will validate just about anything. And afterwards, you don't have to defend the humanity of your actions or take responsibility because God told you to do it. Believe it or not, there's more atheism up here than faith. A.C. Grayling and I are atheists. David and Dinesh are too, except when it comes to their own religion. Every other religion, they're atheist about. This is why religion is divisive. Everyone on earth wants food, water, shelter, love, for their children to grow up to be happy and in a peaceful world. These common desires are so profound they ought to make war an absurdity, a violence against self. Religion, however, makes everyone an infidel to someone.

But we're no longer ignorant, isolated tribes who think the earth is flat and don't know what lies around the corner. We have photographs of our planet from space. And most of us have met people of many races. We know our world and who we share it with. And we also know that critical worldwide problems will require worldwide unity. In this context, religion's continuing assistance, insistence that my God is better than yours is disastrous, which leads me to credulity. There are literally thousands of gods available. Which one you believe in is really just an accident of birth. If David and Dinesh had been born in Afghanistan, they'd both be Muslim probably. Or they'd be dead. Like most people-- like most believers, however, they have faith in their inherited gods. They haven't tested the rest because there's far too many of them.

How then do they know that their god exists and the other gods don't or that their god is better than the other gods? Because they've been told by an authority figure. And here's how he did it. He said, our God is supreme, but he's invisible. We have no proof he exists. But if you have faith, if you make a big effort to believe in him, you will believe in him. It's fantastic. They take the weakest point of the argument and make it a condition of entry so you overlook it. But if, in the most important area of your life, your philosophy no less, the first thing you learn as a child is that faith is absolutely essential, and evidence absolutely isn't, how can this not affect the way you think about everything? You've been brain washed to be credulous and submissive to authority. This affects many aspects of life, including the functioning of democracy and the understanding of science, both of which demand that you insist on evidence, question everything and take nothing on faith from anyone.

Here's an example. Evolution through natural selection over billions of years is one of the best supported theories in science. But 40 to 50 percent of Americans believe the earth is only six to 8,000 years old and that God made us as we are now. Nearly 50 percent-- I mean, it's really extraordinary. It's unheard of in any other culture except Muslim countries. I've written widely on this subject and met creationists of all types. Often, they have-- I'd say usually they have no idea what evolution is. But they dispute it with passion from a religious standpoint, faith over reason. Evidence infuriates them, as does science itself. And this antipathy to science has slowed down stem cell research, continues to harm the health of women and girls and contributes to cynicism about scientific issues like global warming.

But none of this captures the human suffering caused by religion. I grew up next to my gay uncle and his partner. When I was nine, I discovered they faced long prison sentences if their homosexuality was revealed. This was justified by Leviticus 20:13. And the verse was often quoted by both politicians and the clergy. "If a man lieth with a man as he lieth with a woman, both of them have committed an abomination. They shall surely be put to death." This barbaric verse is still used by Christians, including Catholics and evangelicals. And violence is only its most obvious consequence.

I end where I began. Religion claims to provide morality. But as can be seen in its divisiveness, its homophobia and in its almost universal subjugation of women, it just as often deforms morality. The question isn't whether religion can sometimes do good. Of course it can and has.

The question is, can we come up with something better that does not depend on dangerous and childish faith and thousands of competing gods? Can we persuade people that it's possible to live a good, peaceful and happy life guided only by human conscience and modern knowledge? When people who believe in martyrdom and an afterlife will soon get weapons of mass destruction, I think we have to, that we can and that we will. And that's why I ask you to support the motion that "the world would be better off without religion." Thank you.

### Moderator
Claim: Thank you, Matthew Chapman. This is our motion, "The world would be better off without religion." And now here to speak against the motion, Dinesh D'Souza. He's the president of the King's College. He is a leading conservative thinker in the country from a very young age, starting in his college years. As a young man also, he was an advisor to President Reagan. You've also written a lot of books. Now, your opponent has written three times as many books as you.

But I hate to tell you, Anthony, that Dinesh has written about five times as many best sellers as you have. So I think you trump on that. Ladies and gentlemen, Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: Thank you. It's my peculiar fate in this debate to be speaking last and therefore to have to digest the statements of the other speakers. I must say this puts me an odd position. I feel a bit like the mosquito in a nudist colony. I'm not sure where to begin. I guess I'll begin by noting that there were two definitions that have been advanced by the other side that actually I think help our case. The first one is the idea that people who have religious beliefs are hypocritical. But notice that in making this accusation what was being alleged is that religious believers have ideals higher than they can live up to.

And this is advanced as hypocrisy, in other words, holding up to a standard and falling short of it. Now, that is actually not hypocrisy. If you read the Bible, Jesus doesn't call people hypocrites because their ideals are too high. He calls people hypocrites who pretend to be one thing and are really another. The problem with the Pharisees wasn't that they had high principles, is that they didn't have principles but they pretended to be something they weren't, so we've seen a subtle shift in the meaning of hypocrisy, a shift that is advanced by the atheist side, why? To basically pull down the moral ideals that we hold up that are higher than ourselves. That I would suggest is a very bad thing. Now, Matthew made the argument that religion is a function of where you're born. If you were born in India, you're going to be a Hindu-- actually I was born in India, I was raised Catholic, but never mind-- that your religious identity is formed as a result of where you're born.

If you're born in Afghanistan you're a Muslim and so on. Well I think this applies to all our beliefs. Let's say for example that somebody born in Oxford, England is more likely to subscribe to the theory of evolution than someone born in Oxford, Mississippi. Somebody who is born in New York City is more likely to have formed Einstein's theory of relativity than someone born in New Guinea. Now what does that say about whether evolution and relativity are true? Nothing. The fact of your birth is irrelevant to the merit of the idea, so there's a kind of sleight of hand here, you have to judge the ideas by their own merits. Now, would the world be better without religion? You can't answer that question without looking to see what religion has done in the world, but you've got to compare it to what the world would be like without religion.

There's been some allusion to the boring crimes of religion, but let me suggest that those crimes, even the worst of them, are infinitesimal compared to the crimes of atheist regimes that are far greater in magnitude, far longer in duration, and actually are still going on. If you consider, for example, a tragedy like the inquisition, a crime, I admit it, and yet over 400 years the Spanish Inquisition killed fewer than 2,000 people, 2,000. The Salem Witch Trials I heard about when I came to America, and then my wife and I a few years ago went to Salem, Massachusetts, it's a really interesting place-- I do want to report, the witches today are doing great, most of them are tourist guides-- but if you pick up one of their brochures, the number of people killed in the Salem Witch Trials, 19, 19. Now, is that 19 too many? Yeah, or if you want to add it up, 2,019. But while the atheists cry inconsolable crocodile tears over the crimes of religion, they ignore the vastly greater crimes of atheism.

Now, am I talking about Stalin in Russia and Mao in China? Not even really, that's just the tip of the atheist iceberg. If you dig deeper, there is a massive procession underneath. In the Soviet Union alone, starting with Lenin you continue through Brezhnev, Andropov, Chernenko, a procession of Soviet dictators, but what about Ceausescu and Fidel Castro, Kim Jong Il, Pol Pot, I mean, Pol Pot is such a junior league atheist people don't even mention him. And yet in the aftermath of the Vietnam War, his Khmer Rouge regime in the space of about three years managed to kill two million people, two million. Even bin Laden in his wildest dreams has not even come close, but who should parachute into the discussion at this critical moment but Richard Dawkins in his book, "The God Delusion," and he goes, "Wait a minute. We've got to make a crucial distinction here."You might've had some tyrants who killed-- who happened to be atheist, but they didn't kill in the name of atheism. The Christians killed in the name of Christianity. Now, Richard Dawkins is a respected biologist, and I think here you begin to see the problem, when a biologist is allowed to leave the laboratory. Why? Because evidently the poor man knows no history, all you have to do is crack open the collected works of Karl Marx, and you will see that the atheism is not incidental, it's not some add on, it's intrinsic to the whole ideological scheme, Marx famously calls religion, the opium, a kind of drug of the masses. And his point is you’ve got to get rid of religion in order to establish the new man and the new Utopia freed from the shackles of traditional religion and traditional morality.

Often when we think of secular society, we think of Europe. But Europe isn’t really secular. Europe is a product of 2,000 years of Jewish and Christian civilization. Even today if there’s a famine in Rwanda, while much of the world ignores it, the European countries, the Western countries begin to send to food and aid, Doctors without Borders, the Red Cross. My point is this is the result of a religious training and a religious habit of mind that remains. Nietzsche once said that if we get rid of God, we’ve got to get rid of shadows of God. In other words, the ideas that Judaism and Christianity brought into the West and into the world, those will begin to erode as well. Dostoevsky said a long time ago, “If God is not, everything is permitted.” And Dostoevsky’s point is that when we get rid of transcendence, when we create a world without religion, we license terrible calamities.

So, in the names of the thousands and hundreds of thousands, perhaps millions of souls who have died, I would say from their point of view, the world would have been a lot better off if it had religion. Thank you.

## Round 2

### Moderator
Claim: Thank you, Dinesh D’Souza. And that concludes round one, opening statements of this Intelligence Squared U.S. debate. We’ll be right back. Okay, so we’re going to do one of our spontaneous bursts of applause by you. To begin our second round, I just want to allow the crew to remove the lecterns. All right. Let’s all clap. Our motion is “The world would be better off without religion.” This is a debate from Intelligence Square U.S. We’re at the Skirball Center for the Performing Arts at New York University. I’m John Donvan. We have two teams of two arguing out this motion. One team, A.C. Grayling, Anthony Grayling and Matthew Chapman, arguing the world would be better off without religion.

They make the argument that religion has been a burden for mankind, that it imprisons the minds of those who participate in it, keeping them within a narrow range of ideas, discouraged from thinking, believing in things that they say are evidentially not evidential, that are not real, also that religion divides us historically in ways that have had terrible consequences. The team arguing against the motion that the world would be better off without religion, who are saying explicitly the world would be better off-- is better off with religion, Dinesh D’Souza and Rabbi David Wolpe. They are arguing that a world without religion would be a very, very bleak place, in part because of the absence of the sorts of goods that manifestly are carried out in the name of religion around the world, and that in places where godlessness has been established, terrible things, terrible crimes have been committed in the name of godlessness, or, more accurately, in the absence of the name of God. We’re going to go onto round two now.

This is the round where the debaters address one another and also take questions from me and from you in the audience. We’re going to revisit some of what’s been said already and also get into some new areas. And I want to start with the side arguing for the motion, the side that’s arguing that we would be better off without religion. What does it say about the many billions of humans who embrace religion that they do so given your argument that it is destructive to them and that it is limiting to them and that there is a delusion in it? What do you say about them? Why are they doing that? Anthony Grayling.

### Conspiracy Advocate (CA)
Claim: Well, first, of course, Matthew is right to point out that the religion that anybody has, tends, on the whole-- in much more than 95 percent of cases to be the religion of your parents. And so, it’s a traditional thing. People are brought up in the religion of their father, and it’s historical.

### Moderator
Claim: Can I just want to ask you to go closer to the microphone-- and you can address the answer out to the audience.

It doesn’t just have to be in my direction. And if you could start again.

### Conspiracy Advocate (CA)
Claim: But you asked me the question.

### Moderator
Claim: I know that. But know that my eyes are boring into the side of your head.

### Conspiracy Advocate (CA)
Claim: Okay, so I repeat the answer, which is, of course, religion is pervasive in history at its traditional-- it’s handed down from parents to their children so it remains the case that it’s a very potent force in society. But if you look at the trend in the developed and advanced and educated countries of the world, mainly the Western countries, since the 17th and 18th century, enlightenment and the growth of science, you see the numbers are plummeting. They are plummeting even here in the United States of America. You look at the few polling data and it points out to us that the number of people who self- identify as not having a religious commitment or agnostic or atheist is increasing all the time, especially among the young. So the trends are setting in the right direction.

### Moderator
Claim: All right. Let me take that to the other side. And in the argument made by Anthony Grayling and also earlier by Matthew Chapman is that that religion kind of gets kids early when they'll believe anything.

And then it's set. And then it's set and hard to move off. And I want you to take that point on.

### Scientific Advocate (SA)
Claim: Sure. Remember, we also get kids early with habits like brushing your teeth, learning the mathematical tables. Now, here is the point. I think that as a practical matter, we all learn our ethical values from our parents. I learned what I would call “crayon Christianity” from my parents. But the fact of the matter is that's my parents' beliefs. When I became a teenager, when I went to Dartmouth, that set of beliefs got battered, and crayon Christianity became no Christianity at all. So it was in adult life that I had to go back to the ideas that had been bred in me as a child and ask, which of my parents' beliefs do I agree with?

### Moderator
Claim: But do you think you're typical? You're--

### Scientific Advocate (SA)
Claim: I do.

### Moderator
Claim: You went to Dartmouth. You're a very bright guy.

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: And brushing your teeth, those are scientific experiments that have determined-- but they're arguing a somewhat different point, that there are lots of people who may not be able to do the critical thinking that you do.

### Scientific Advocate (SA)
Claim: Well, I think we're making a deep mistake here because just to say we learned it from our parents misses the thrust of why billions of people in the world continue to do it long into old age. In other words, religion delivers practical benefits. It gives us the hope of life after death. You might say that's an illusion, but you don't know. None of us knows what comes after death. We all have to die in any case. Either we die with despair facing annihilation, or we have the hope of something else. That's a practical benefit. Second, religion is a mode of transmission of morality. You might say there is morality that comes through Kant or Nietzsche or Heidegger.

But no one teaches their kids morality that way. People learn their morality--

### Moderator
Claim: All right. Dinesh, let me bring it over to Matthew Chapman and bring him into this. And if you can respond to some of what you've heard here.

### Conspiracy Advocate (CA)
Claim: Well, I just think it's a distortion of what you actually see in life, which is you see people who grow up in cultures. They become addicted to their particular religions. They disagree with all kinds of other religions. Even you, you started as a Catholic. You end up as an evangelical. Does that mean that you then say the stuff in the Catholic part of it was actually wrong, and you were mistaken about that? I think all of this is frankly delusional and that even if you could remove all of the bad things about religion and keep all of the good things in religion, none of which can't be performed by people who don't believe in God because they can. But even if you could remove all of the bad things from religion, and you ended up with a character who is like Father Christmas, a nice harmless sort of person, would you want to find out that the president of the United States was a devout believer in Father Christmas?

Not me.

### Moderator
Claim: All right, let me take this-- Let me take this to-- I want to take it to David Wolpe because the issue of whether there's a credulity here that people believe suggests that people's minds aren't growing.

### Scientific Advocate (SA)
Claim: So I want to say, first of all, it's so interesting that the side that's quoting the Bible is that side and the side that has actually provided evidence of any kind is this side. So let me give you another piece of evidence as opposed to the generalities. In their Encyclopedia of Wars, okay, the Encyclopedia of Wars, Charles Phillips and Alan Axelrod, they chronicle over 1700 serious conflicts throughout history. Do you want to know what percentage actually reduced to religious wars? Seven percent.

### Moderator
Claim: David, David, I--

### Scientific Advocate (SA)
Claim: The reason I'm saying this is because it's not about credulity. No, it's not about credulity.

The idea that people who are religious are religious because of some psychological deficit, but people who are not religious are not religious because they reason their way to the lack of religion, not only slights the idea that religious people are capable of thought, but also tries to sort of railroad into this belief that you should condemn it without actually looking at all the statistics, the ideas, the history that we cited. And that sort of slighting of the religious belief makes me think that your argument might not be as sound as you think it is.

### Moderator
Claim: A.C. Grayling.

### Conspiracy Advocate (CA)
Claim: Can I come back to that? I hear a certain kind of incoherence on the other side there. Firstly, if you're religious, you live longer, that puzzles me. I mean, isn't heaven meant to be a nice place? It's always been--

### Moderator
Claim: Moses was like 800 years old or something like that.

### Conspiracy Advocate (CA)
Claim: Yeah. And then Dinesh says that one reason why people stay religious into old age is because they're thinking about life after death. Well, that was Bernie Madoff's mistake. He promised returns in this life.

So you know, religion. I'm afraid the things that most people are brought up in a religious tradition, and those people who escape religion do it because they look at the facts, they look at the evidence, they look at the morality. They look at the teachings. They look at the world around them, and they recognize that there is something very divisive and very distorting here. Look at small children even in kindergarten, all races and ethnicities and backgrounds and classes and religions. They don't know that. We have to work very, very hard to divide them and tell them what tribe they belong to and what religion they belong to. And that's where the source of the trouble comes in our world--

### Moderator
Claim: All right, Dinesh D'Souza.

### Conspiracy Advocate (CA)
Claim: --from division.

### Moderator
Claim: Dinesh D'Souza to respond.

### Scientific Advocate (SA)
Claim: A.C. said earlier that the defining feature of religion is hierarchy and exclusivity. And I think that on both these, he's giving a very narrow and ethno-centric definition. First of all, Christianity is the only religion in the world that considers another religion, Judaism, to be wholly true. Hinduism considers all other religions to be wholly true.

There's no sense in the Eastern religions of this hierarchy of this exclusivity. So we're seeing here not an attack on religion, but on a very slice of religion, perhaps fundamentalist religion. I think the deeper point here is this: And that is that the religious guy and the nonreligious guy are both responding to the world as it is. Charles Darwin became an atheist not because he discovered evolution. It wasn't facts. It was when his daughter, Annie, died. And Charles Darwin said, "If there's a hell, lots of the lovely people I know would be in it. I can't bear that kind of a doctrine." You, Matthew, in your article in Slate magazine talked about nuns or teachers who beat you on the ankles and people-- people who stuck their hands down your pants. My point is, in many cases, we're not dealing with facts. We're dealing with wounded theism. Many times when we heard the word "atheism," we're dealing with a person who is angry with God or angry maybe with the representative, the self-appointed representative of God.

That's not real atheism. They too are conducting, if you will, an ideological war, otherwise they wouldn't--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --be here.

### Moderator
Claim: That's an interesting point. Matthew Chapman, are you angry with God?

### Conspiracy Advocate (CA)
Claim: How can you be angry with somebody that doesn't exist? I'm angry with Dinesh because he's making these preposterous statements about my--

### Scientific Advocate (SA)
Claim: Well, I didn't put my hand down your pants.

### Conspiracy Advocate (CA)
Claim: --great-great-grandfather-- that are simply not true. His atheism didn't come solely from the fact that his daughter died. It was a very slow process of seeing how the theory of evolution was in conflict with the Bible. And I think the point I would make is, let's give the religious people that at some point in history, religion was helpful, that it did make people do better things. But that the texts that the religions are based upon are archaic, absurd, cruel, open to interpretation.

And frankly, there are better ways of conducting yourself in life. There are. And people like myself and Anthony here, we don't find a problem with being moral without God.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: And I don't buy in argument that we've inherited it from Christianity because if you look at the sort of evolutionary world, empathy and cooperation, compassion clearly existed before God decided, for some unknown reason,

### Moderator
Claim: Let me take it to David Wolpe to talk about this question of the text. And you're in an interesting position because in 2001 you gave a talk in which you actually questioned the literal truth of the exodus story. So you are not-- you are already not tied--

### Scientific Advocate (SA)
Claim: I'm not a literalist, no. But what I find very interesting is that the leap that Matthew's making-- he says these texts have cruel things. There are better ways to behalf. But we're asking not would the world be better off if you rewrote the Bible, but would the world be better off without the influence that religion has on religious people.

And I tried again and again to say this is what religious people do. This is what religious people do. This is what religious people do only to get back, "But look at the terrible text." And I want to say, in response to what Anthony said, I have the exact opposite experience. I actually think that if you believe that people are fundamentally good, and if you leave them alone, they're just going to be good, then you've never visited a playground, because my experience is when a new kid comes to the playground, the other kids don't go, "Oh, look, a new child. Let us embrace him and share our toys." Actually, children have to be socialized to good. They do. And it takes a lot of work. If any of you are parents, do you have to tell your kid, "Don't share so much, don't be so nice." No, quite the opposite. And that work is difficult work and constant work and that's what religious communities do.

Do they ever do harm? Of course they sometimes do harm. Are there texts I don't like? Of course, but the coda to this is, this idea that religious people are thoughtless automatons that follow what the text says, does violence to everything I know about religious training, about religious leaders, about religious people, and by the way about the fact that we're having a debate like this tonight.

### Moderator
Claim: Let me go to the other--

### Conspiracy Advocate (CA)
Claim: I would like to--

### Moderator
Claim: --all right, very quickly.

### Conspiracy Advocate (CA)
Claim: --because I think what he's saying is this is the viewpoint of a rabbi who does work in an affluent community in Los Angeles. Both these men are very sophisticated. The people I met in Pennsylvania, who 50 percent of them believe in creationism and are fundamentalists, are people-- these people, they ignore. They're saying we ignore their sophistication. I'm saying they ignore the fact that most of the world is fundamentalist and takes a barbaric view of many of the text.

### Moderator
Claim: And if there were no religion, what would be happening in Pennsylvania?

In other words, what's the harm in the Pennsylvania situation, where the school board wanted intelligent design taught as an equal alternative to evolution, you've got to specify what the harm is there.

### Conspiracy Advocate (CA)
Claim: Well, the harm is absolutely enormous, I mean, 50 percent-- I mean, just to be practical about it-- 50 percent of the growth of the American economy since World War II has come from science and technology. And this anti-scientism is gradually eroding America's ability to produce enterprising, educated--

### Moderator
Claim: Okay, I want-- that's a new point that I want to take to this side, the argument that religious thinking and religious strictures limit science, Galileo into the future. Go ahead. Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: First of all, if you want to make a list of the 200 greatest scientists of all time from Newton, Copernicus, Kepler, Pascal, Gassindi, Boyle, the list goes on, you find that the vast, vast majority of them were religious believers.

Moreover, it's not an accident that science did not develop universally. It developed in Western civilization. Why is that? Because in Western civilization, there is an embedded religious idea, and that is the idea of the rational cosmos. The Muslim philosopher Al-Ghazali denies that the universe operates by laws. He says, "Everything happens because Allah wills it at every given moment," that's why science didn't develop in the Muslim world. It's the sense of the whimsical, the miraculous universe. The point I'm trying to get at here is that on the basis of, I would say, a one percent minority of religious rednecks, we have an indictment of all the world's religions as a whole.

### Moderator
Claim: Right.

### Scientific Advocate (SA)
Claim: Nothing could be more crude and shameful than to imply that Athens and Jerusalem which have given rise to Western civilization, that have shaped our philosophy, our economy, separation of powers, checks, and balances, when Thomas Jefferson, who--

### Moderator
Claim: All right, Dinesh, I want to cut you off to let Anthony Grayling--

### Conspiracy Advocate (CA)
Claim: Yeah, sorry, I mean there are two things, Dinesh, with great respect to you, you are the most tremendous rewriter of history I've ever come across in my life. You don't seem to be conscious of the fact that when Christianity became dominant in Europe in about the third, fourth century A.D. it looked at its sundial, the perusing of the second coming of the Messiah hadn't happened, they needed some extra ethics. The ethics of the New Testament and the Napoleon epistles are very thin, they're the stuff I talked about earlier, give everything away, don't get married, don't bother about tomorrow. Where did they get it from? They got it from Greek philosophy. Most of European culture, and that means culture of the West, is deeply rooted in classical antiquity, in the thinking of Socrates, and Aristotle, and the stoics. That is where our European outlook-- our cultural outlook comes from.

Conceptions of justice, of ethics, of a democracy, they all come from the pre-Christian state of Europe.

Christianity was an oriental religion that erupted into Europe and changed the course of European history, and derailed it for over 1,000 years. People couldn't build a dome like the Dome of Maxentius in Rome because they'd lost the understanding of simple engineering. Wasn't until Brunelleschi's Dome in Florence in the 15-- 16th century that that was possible. So we're looking at a phenomenon here where religion did to our forefathers, did to the history of our culture exactly what Matthew says it's doing again to the prospects for science and progress in our contemporary world.

### Moderator
Claim: All right. David Wolpe.

### Scientific Advocate (SA)
Claim: Very briefly, Anthony, I think actually you're the victim of a very parochial education because long before Christianity, Judaism enunciated all the ideals that you say did not actually come from religion. In 50 BCE, when Hillel was asked to summarize all of Judaism, he said that which is hateful to you, don't do to others. And the sages of Judaism were killed by the Roman Empire, not be a religious empire, as opposed to Socrates who was killed by the Athenian polity that you idealize.

They killed their own sages. In Judaism, we venerated them. And they’re actually the ones who ceded Christianity and gave us the morality that you claim came from the Stoics.

### Moderator
Claim: Anthony.

### Conspiracy Advocate (CA)
Claim: Can I tell David just a quick little anecdote about a conversation I had with a cab driver in London. Cab drivers in London are very interesting folk. I asked this man if he’d read the Old Testament. He said he hadn’t. I said, “Do you remember any stories from the Old Testament.” He thought for a moment. He said, “Yep, I remember something about a woman being turned into a pillar of salt,” and I took this to be evidence of some domestic disorder in his own family and wishful thinking. I said to him, “Do you remember that story, you know, God didn’t like the homosexuals in Sodom so he was going to destroy everybody there? Somebody pointed out to him that there might be a righteous person. He sent the angels to tell Lot to get out of the city. The citizens wanted those two angels, the handsome young men. And Lot said to them, ‘You can have my daughters instead.’ When they finally left the city, what happened to his two daughters?”They didn’t have husbands, so they slept with their father and became the--

### Moderator
Claim: All right, we see where you're going.

### Scientific Advocate (SA)
Claim: I know the story. By the way, actually you also are the victim of an inadequate Biblical education I think because Sodom was not destroyed because of homosexuality. Read the book of Ezekiel. It was destroyed because of the cruelty of the people of Sodom, their immorality, and I really-- I think with all due respect that to cite London cab drivers, pithy though they may be as the demonstration that Judaism didn’t actually create the morality of the West, may be a little thin.

### Conspiracy Advocate (CA)
Claim: the demonstration. And Sodom was destroyed no matter what reason you give to it.

### Moderator
Claim: I want to go to questions from the audience. I want to move onto your questions and recall that I’d like you to be very terse and to really ask a question that’s on our motion that moves it forward. Before we get to it, get all ready for that, I just want to take one - - move things in one more direction, to this thought. I want to rephrase what David Wolpe has been saying, is that religion organizes-- religion has the capacity to organize the best in us, to do good things, and to transcend ourselves.

And what he paints is a bleak world without that. So, it’s undeniable in places like Africa, et cetera, that the enormous amount of work is done through organized religion. And that’s on everybody’s mind, so I’d like you to take that on.

### Conspiracy Advocate (CA)
Claim: Well, we can share it. But most people are religious, so it’s not surprising that most people who are out there doing good things are religious. It’s the same argument I would make about scientists. Most scientists were Christians. Well, most everybody was Christian. So, of course, most of the scientists were Christians.

### Moderator
Claim: So you’re saying there’s no cause and effect between--

### Conspiracy Advocate (CA)
Claim: I don’t think so. There’s lots and lots of people who do good things and organize--

### Scientific Advocate (SA)
Claim: I’ll challenge that on the basis of this book right here by the sociologist Arthur Brooks. It’s called “Who Really Cares?” And it’s the careful study of philanthropy in America. So it’s comparing like with like.

It divides America into four groups: religious conservatives, religious liberals, secular conservatives, and secular liberals. And it looks at generosity, not just in terms of money, but also in terms of time, and not to religious causes but to so-called secular causes. Turns out that the most charitable people in America, by far, are the religious conservatives. The second most charitable are the religious liberals. The third most charitable are the secular conservatives, and the last are the secular liberals. Now, what’s particularly poignant about this is the secular liberals in America are the richest. They earn the most money, but they give away the least. So it is not the case that this is a generic matter of people who happen to be religious. The point which David Sloan Wilson made in a recent book is that evolution narrows the circle of our sympathies to our kin or to people from whom we can get something.

But when you do things in service to God, you’re much more likely to help the stranger or the outsider.

### Moderator
Claim: All right. A very quick response from the other side if you want, Anthony Grayling.

### Conspiracy Advocate (CA)
Claim: Okay, I just want to make the point that there are plenty of non-religious people involved in charitable endeavors and they don’t stay on afterwards because they don’t have an extra agenda. And I just want to quote to you--

### Moderator
Claim: You mean proselytization?

### Conspiracy Advocate (CA)
Claim: Yeah exactly. And I don’t-- I just want to--

### Moderator
Claim: Anthony, can you be explicit about that.

### Conspiracy Advocate (CA)
Claim: Yes, sir, because I don’t think that they’re staying on because they haven’t got anything to proselytize about. They don’t want a return for their investment. George Bernard Shaw said-- very, very quick quote-- he said when he gave up religion-- escaped religion as a teenager, he said that moment was the moment when I felt the dawning of moral passion because people who don’t take a box out of the frozen food warehouse of morality, you know, there it all is, are people who have go to think about their responsibilities and about their relationships to other people. They've got to be people who think about the diversity, how different people are from one another. You know the golden rule, "Do unto others as you would have them do unto you," George Bernard Shaw said, no, under no circumstances should you do to others what you'd like them to do to you because they may not like it.

And that's a very good insight. It means see them for what they are in their individuality and personality and base your morality on a genuine understanding of what it is to be human in a human world.

### Moderator
Claim: All right. I'm going to go to questions. And if I turn down your question, please don't take it personally. It'd just be my judgment that it might not be on point. Right in the middle there, yeah. Yeah. You just pointed to yourself. And if you could stand up and tell us your name.

### Moderator
Claim: Hi. My name is Elizabeth, and my question to those who are for the motion is, how are the harms of religion different from those of nationalism or racism? And for those against the motion, how are the good things from religion different from the good things that come from secular charities or community organizations or--

### Moderator
Claim: Okay.

### Moderator
Claim: --being involved with your family?

### Moderator
Claim: Okay. I'm going to-- good questions, which are really one question that I think we all see. And I will let this side go first. This side for the motion. Matthew Chapman.

### Conspiracy Advocate (CA)
Claim: Well, I think the difference is that even the mistakes of people who are acting out of nonreligious motives are mistakes based on reason. And that most of the horrors of religion are mistakes based out of superstitious fear and delusion. And I cannot see how delusion can be healthy to a society. I just can't-- I can't see it. Not all of these religions can be true because they all contradict each other. So some of them are delusional. How can this be healthy? It's divisive. It's nonsensical. And I am not saying that atheism has come up with the perfect solution. But there has to be a better way than this.

### Moderator
Claim: Do you know what it is?

### Conspiracy Advocate (CA)
Claim: I think it's secular humanism. It's atheism.

### Moderator
Claim: Okay. All right. David Wolpe, do you want to respond? You can either respond to what's just been said or to the question which was a variation.

### Scientific Advocate (SA)
Claim: I mean, the frustration that I repeatedly am having in this debate is that we're arguing theory against the world.

The world is that there are millions and millions and millions of people who, by their own testimony, although the other side may not believe it, say they're doing good because they believe there is a transcendent purpose in their doing good. Therefore, they'll do it tomorrow, next week, next month, next year. It's not a club that's going to dissolve. They're not going to go away. They're not going to stop doing it. And they're going to teach their children to do it. And what we hear on the other side, to a great extent is, that's bad because it's delusional. And the question is not actually would the world be better off if everybody had the same scientific ideology? Would that be a better world? The world-- the question is, what would it be like if religion were gone? What would it be if you just, all of a sudden, sucked that motivation from these countless people who do good? And that's what I want to know.

### Conspiracy Advocate (CA)
Claim: I'd like to propose an--

### Moderator
Claim: Matthew Chapman.

### Conspiracy Advocate (CA)
Claim: --experiment, if I may, which is I would ask the audience, how many of you out there do good things, do charity, visit people in hospitals, take care of friends?

And could I see a show of hands of anyone who's involved in charitable endeavors, helping people, taking care of animals, giving money to charity, whatever it is.

### Moderator
Claim: I hope the rapture happens right now because--

### Conspiracy Advocate (CA)
Claim: There we have--

### Moderator
Claim: --I'm going to know who's telling the truth.

### Conspiracy Advocate (CA)
Claim: Now-- now I would like to see a show of hands of how many of those people did that because they feared religion or religious authority.

### Scientific Advocate (SA)
Claim: Feared?

### Conspiracy Advocate (CA)
Claim: Well, or were-- or were--

### Scientific Advocate (SA)
Claim: Here's-- here's my question.

### Conspiracy Advocate (CA)
Claim: Okay. I haven't-- no, I haven't-- I haven't finished yet.

### Moderator
Claim: Hold on for a second, David.

### Conspiracy Advocate (CA)
Claim: I haven't finished yet.

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Or-- I mean, we saw no hands there, or who did it because they thought that by doing good action it would get them into heaven. Let's see a show of hand on that.

### Scientific Advocate (SA)
Claim: Didn't say that, either.

### Conspiracy Advocate (CA)
Claim: Now--

### Moderator
Claim: David, David, David--

### Conspiracy Advocate (CA)
Claim: Now let's see a show of hands from people who do these good things simply because they have a human empathy towards people who are suffering.

### Scientific Advocate (SA)
Claim: I think we have a biased pollster here in the audience, you know.

### Conspiracy Advocate (CA)
Claim: I don't think so. I mean--

### Moderator
Claim: All right. We get it.

### Conspiracy Advocate (CA)
Claim: --people do good things--

### Moderator
Claim: Let David respond to that. David Wolpe.

### Conspiracy Advocate (CA)
Claim: --for other reasons than religion--

### Moderator
Claim: Matthew, let David come back.

### Conspiracy Advocate (CA)
Claim: --the majority here.

### Scientific Advocate (SA)
Claim: The reason that that's not persuasive, shall we say, is first of all, very few religious people will tell you it's to get into heaven. It's because it's what God expects them to do. That's first of all. In other words, you do it because other human beings are created in the image of God. And if you take that out, then our link is a species link. But if we're all children of the same God, then you are my brother and sister, and that's why you do it. It's different. It's not because you are afraid of God. And second, people's self- reported charitable doings, although obviously everyone here is completely honest. People's self-reported charitable doings are a lot less reliable than survey after survey after survey.

And the way that the surveys were answered by Putnam, by Brooks, by Koenig, by respected sociologists, the way that he answered them is by asking you to raise your hand. Now, I want to ask you seriously, how many of you believe that all these sociologists and psychologists are cooking the data, and how many-- you don't have to raise your hand. And how many of you believe that whether you like religion or not, the truth is that it does make people much more inclined to be self-sacrificing in this world. And if you don't believe it, then all I can say is, I know a world without religion that you can look at. I'm from that world. It's called Hollywood.

### Moderator
Claim: All right. Let's go to another question. Right down in the front row there. No, the gentleman. You'll probably notice a male-female pattern in my selection, the next question you know who should raise their hands.

### Moderator
Claim: Thank you so much for this evening. I think it's a great debate, and I truly enjoy it.

I am Muslim, okay. So definitely, my question will go to you guys. Great point that you make, but I will make it quick. The thing is that religion is really the question for me today because is it the misuse of religion that's really bringing all this drama and all the chaos that we really talk about, or is it really religion itself? Because if I have a weapon, right, and I use it against you, and in this day today, we go to court, I will take the person on his character and take him to court and take him to jail, not the companies that make the weapons or the owner of the company. But I will take the person on his own act. So it could really--

### Moderator
Claim: I think you started with the question.

### Moderator
Claim: Okay.

### Moderator
Claim: Which was, is it religion, or is it the way that some people are using it or misusing it? That's a terrific question. Let's go to this side. Matthew Chapman.

### Conspiracy Advocate (CA)
Claim: Well, I mean, that, to me, is the entire problem.

If you look at any religious text, it can be interpreted in any way and give you an excuse to do anything. These gentleman here, I'm sure they're very nice people, and they look at it in the most benign way. I've heard Rabbi Wolpe over there say that the whole process of religion is that you take all these complicated books, and you filter them through human consciousness and out comes something that makes sense. I agree. And when you filter them out, what you get is humanism. Jefferson did the same thing with the Bible. He took out everything that he thought was contemptible or had nothing to do with the origins of religion. He got 48 pages. I say you could bring it down to one page that said-- or one phrase which would be "Do unto others as you do-- as you would have done to you." It is as simple as that. And all of those texts--

### Moderator
Claim: So Matthew, your answer to his--

### Moderator
Claim: Your answer to his question is, it's not just how religion gets used. The problem is religion itself.

### Conspiracy Advocate (CA)
Claim: The problem is the ancient texts that are infinitely interpretable for any purpose.

### Moderator
Claim: Okay. Dinesh, do you have somewhere new to take this response?

### Scientific Advocate (SA)
Claim: Well, yeah. First of all, Jefferson, who was a man of the enlightenment, not a very devout Christian, as you point out correctly. But when Jefferson was asked, "What is the source of our rights?" he could have said the social contract. He could have said the enlightenment. But no, he said it's the creator. He could think of only one source. One word about the texts. I think the point that Rabbi Wolpe and I are stressing is that the way to interpret the text is to look and see whether the people who revered the text do the things in the text. So, for example, he read a passage from Deuteronomy about chopping off people's arms or removing their genitals. So I ask you, how many religious people are going around without arms or genitals? No one who is Jewish or Christian reads the texts that way. So there's a form of, you might say, atheist fundamentalism in taking the text in so literal a way that no Christian-- I mean, there was a debate that between Paul and the early apostles about which aspects of the ancient law should apply to Christians.

It was settled 2,000 years ago that Christians would not follow the Old Testament in a literal way. And even the guys in Dover aren't doing that. So in a way, I think these guys are charging an imaginary dragon.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: You're trying to hold us accountable to texts which were, in a sense, not taken as literal 2,000 years ago.

### Moderator
Claim: In the fourth--

### Moderator
Claim: And we have

### Moderator
Claim: I want to move on. And fourth row, you can-- in your closing remarks, you can--

### Moderator
Claim: My question is a little bit more broad. It's that, isn't religion basically a fear of death and ultimately your ultimate judgment and the selfish belief that humans are so important that we should have the right to live forever?

### Moderator
Claim: Well, you guys are going to say yes to that, I'm pretty sure. So I'm going to go over this way. Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: I think your question is echoing an argument in Sigmund Freud that religion is wish fulfillment. We all-- but life is tough, we have diabetes, we have the gravedigger, we would like to have another life, and so religion is made up to accommodate that wish. Now, I think that actually that theory doesn't square with what religion actually holds, and here's why. Certainly it explains heaven. Heaven is a good example of wish fulfillment. But remember that all of the major Abrahamic religions also have hell. Now, think about that. Hell is a lot worse than diabetes. Hell is a lot worse than death. Why would we make that stuff up? The bottom line I'm trying to make is that that diagnosis of religion as expressing wish fulfillment runs headlong into the actual facts that religious people actually sometimes fear a fate far worse than anything that life can offer them.

### Moderator
Claim: Okay, let's go to gentleman-- yeah, I'm looking right at you, thank you. If you can rise a mic will come to you.

If there's anybody in the part of the auditorium that's not lit, I want to confess I can't see you, if you really truly want to ask a question, if you come down the steps a little bit and I'll be able to see you, I'll try to call on you. I can't promise it, but I'll try to call on you. Sir, go ahead.

### Moderator
Claim: Dinesh, this is specifically for you.

### Moderator
Claim: Can you tell us who you are, please?

### Moderator
Claim: Robert Shillman

### Moderator
Claim: Thank you.

### Moderator
Claim: How could you possibly give a speech leaving out the Holocaust, Bosnia, Turkey, and the Armenians, how could you quote that ridiculous book which has been disproved when you take out the money that has been given to the religion all of the numbers shift the other way. You're sitting here systematically making up statistics to try and convince us that it's a good thing. And I'd love just your response.

### Moderator
Claim: Okay, I'm going to-- Dinesh, I don't-- I don't want you to-- I just think that's going to turn into a circle that doesn't get us further on our motion, so I'm going to move on to a different question. Really? Okay, let's do that-- can we do that show of hand things-- the show of hands thing? All right. Make it very quick though, please.

### Scientific Advocate (SA)
Claim: I want to focus on the Holocaust. I would recommend to you this book, "Hitler's Table Talk." It's edited by the prominent historian, Hugh Trevor-Roper, and it constitutes direct notes of Hitler's comments authorized by Bormann between 1941 and 1945. In the early 1930s when Hitler was coming to power, he wanted to win over the Bavarian Catholics and the Lutherans in Germany and so he invented what he called a Nazi Christ, not a Christ who was killed but a Jew killer. And he tried to sell that to the churches which didn't go for it. This book records page after page of Hitler's loathing and hatred for Christianity.

He regarded the church as the most dangerous opposition to the Nazi regime, and I could read for an hour quotations from Hitler's mouth about his hatred for Christianity. My point is what the atheists will put up on their websites are quotations from the early 1930s, the Mein Kampf where Hitler says, "I'm doing the lord's work." This was part of a propaganda campaign to win over the churches that was unsuccessful. Hitler was a hater of Christianity. I've never called Hitler an atheist, he was a certain kind of a pagan.

### Moderator
Claim: Okay, okay, all right, everybody happy? All right, good. I just don't feel that it really moved our topic about whether religion is good or bad. Ma'am, sitting on the stairs because you came all the way down--

### Moderator
Claim: Which one?

### Moderator
Claim: Sure, yeah, yeah.

### Moderator
Claim: All right, hi, my name is Katherine, and it seems today that there seems to be a disconnect between the two sides. One side argues that religion only creates good and perpetuates charity and civic engagement while the other says that it's a system of discrimination and religious doctrine creating hate.

I have a feeling that the truth is somewhere in the middle. However, my question is this, how do you get the benefits of civic engagement without the discrimination, or is it even possible to disentangle the two within religious doctrine?

### Moderator
Claim: Is that more of a question to this side? Sounds like it.

### Moderator
Claim: Sure.

### Moderator
Claim: Sounds like it, yeah. David Wolpe.

### Scientific Advocate (SA)
Claim: Well, I mean, it is certainly true that good and bad are mixed in every society, in every organization, in every human being, and the question you ask is a metaphysical question, that is, "How do you get only the good and not the bad?" I don't know that, that's possible to do in anything. There's no charity that has not been subject to corruption, and to misappropriation of funds, and to people doing cruelty, and I don't know that you can wash religion away, and actually the essence of the debate is does religion do bad sometimes, absolutely, but if you measure the good in which religion does in the world and, as I said, the unadvertised good, the small good, the constant good, then what do you get in a world without it?

And the essence of the debate is whether, in fact, that world’s going to better or worse. I think it’s almost undebatable.

### Moderator
Claim: Any response from this side on that?

### Conspiracy Advocate (CA)
Claim: Yeah, I think the response is that you have to notice that most of the advance countries of the world are secular constitutionally, like this one, or functionally secular like my own United Kingdom. And the point about those societies is that they organize welfare, education, defense, infrastructure, and they do this not in the name of one or another religion but in the name of society generally. So when you look at the benefits, you look at the rational application of our ideas about how a society should flourish and advance and what the needs are of the members of that society, the post-enlightenment world, the world since the 18th century, the world which has been putting to work the ideas of scientific rationality has made a vast improvement to the lives of most individual people.

When you think of the poverty and you think of the ill health and you think of the divisiveness of societies before that time and compare them to the society of today-- and notice this. In every city of the world, there are millions of acts of personal kindness and cooperation between people, far outweighs all the conflict and difficulty there is in the world. And it has nothing to do with their ideologies or religions or anything else. It’s just a fact about us. As social animals, we need one another and we care about one another. Here’s a very simple example. You’re walking down the street, so you see somebody ahead of you. A big pile of bricks on a wall are just about to topple on that person’s head. What do you do? Your instinct is not to say this is going to be interesting. Your instinct is to call out to them and say, “Watch out!” And you do it not because you’re an evangelical or a Jew or a Muslim but because you’re a human being and that’s another human being.

### Moderator
Claim: All right. Another question.

### Conspiracy Advocate (CA)
Claim: I would like to add though, I think--

### Moderator
Claim: Matthew Chapman.

### Conspiracy Advocate (CA)
Claim: --it’s absurd to say that secular people advertise and religious people don’t.

Religion is a constant process or advertising. Every good deed religious people do is taken along with a banner showing whatever religion did it. Doctors without Borders makes no claim to having any religion, nor does it claim to be atheist--

### Moderator
Claim: I mean, do you really think that accusation is fair?

### Scientific Advocate (SA)
Claim: Can I do a poll now of the group? Let me ask you, how many of you had heard of the largest aid organization of the world that I mentioned at the beginning? How many of you had heard of it? Now how many of you had heard of Doctors without Borders? I rest my case.

### Moderator
Claim: All right. Let’s move-- can I take a poll on should we stop doing polls? Show of hands. Sir, you’re up.

### Moderator
Claim: Sure, thank you. This is a question for Matthew--

### Moderator
Claim: Could you tell us your name, please?

### Moderator
Claim: Frank Roberts

### Moderator
Claim: Thank you.

### Moderator
Claim: This is a question for Matthew and Professor Grayling. For the question of the evening is would the world be better off without religion, but my fear is that the question is in and of itself somewhat disingenuous because it keeps it-- religion seems to be this theoretical thing up here.

And I’m wondering if we can ground it to more practical examples. So my question is would you be willing to say in public that the world would be better off without Jews, or the world would be better off without the Civil Rights Movement, a movement that we know was based in a kind of radical black Christianity. So, my question to you is, again, rather than asking would the world be better off without religion, is it more so a question of whether or not we think that religion is problematic or has been misappropriated, et cetera, et cetera, et cetera, but it seems like the very question of whether the world is better off is problematic?

### Moderator
Claim: Wait, can you zero in-- because I know that you can because-- zero in to the one point that you want to ask.

### Moderator
Claim: The one point that I want to ask is, is the very term of the question somewhat disingenuous because we know that we would never say that the world would be better off without religious people--

### Moderator
Claim: All right. So you’re asking would the world be better off without religious people, and is that what you’re arguing?

### Conspiracy Advocate (CA)
Claim: No, I think we’re arguing the world would be better off without religion.

We’re-- the point is--

### Moderator
Claim: But I think the point of his question is that--

### Conspiracy Advocate (CA)
Claim: I understand his question exactly, and it’s a deep point of principle that in all these kinds of debates, it’s not about individuals. This is not about people. This is not about human beings. We understand why human beings are religious. They’re brought up to be religious, or they’re not told enough about the history of their religion. They’re given the most updated version of it, and so on. So it’s not about attacking individuals. It’s about attacking ideas. It’s about attacking ideologies. It’s about attacking conceptual frameworks which act like spectacles that make people see things in a particular way. That’s the argument. It’s not saying that we would like all Jewish people or Muslim people or Christian people taken as individuals not to be there. No. What we would like them is to be free from those distorting ideologies.

### Moderator
Claim: We’re being-- I want to point out we’re being live-streamed also on Slate.com. And we've asked viewers and readers of Slate to submit questions. And I have one that I find quite interesting to put to the side arguing for a world with religion.

Dan Riley in Portland, Oregon, says, "Would a world in which Hinduism or Islam or Norse paganism were the only religions still be preferable to a world without religion?" in other words, he's kind of-- if there weren't Christianity and Judaism, but there were one religion motivating people, but it wasn't your favorite. Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: I'll make my own case hard by looking solely at Islam because it is such a controversial subject in our world today. I would submit that the world would be vastly worse-- the Muslim world would be vastly worse if it wasn't for Islam. Let's look at why that's the case. First of all, you have to look at what was there in the Bedouin culture before Mohammed. Rape, pillage, concubinage. Mohammed actually was a moderate in limiting the number of wives to four and by basically saying that you had to treat the four wives equally, giving them all the same gifts and so on.

Mohammed essentially ensured that the entire Muslim world, for the most part, you'd have people with one wife. Polygamy is very rare in the Muslim world for that reason. So the bottom line of it is that Islam was a vastly civilizing force, not to mention the introduction of a cosmopolitan civilization with a history, a philosophy and a distinctive architecture, not to mention great Islamic philosophers and thinkers. Even the great Jewish scholar Bernard Lewis has a great appreciation for the civilizing influence--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --of Islam in the world.

### Moderator
Claim: A clear answer to that question, so I want to go to the other side to see if you respond to that.

### Conspiracy Advocate (CA)
Claim: Well, I just--

### Moderator
Claim: Anthony Grayling.

### Conspiracy Advocate (CA)
Claim: --have in mind what Gautama Buddha said to his followers. He said, "Don't make me a god, and don't turn this into a religion. It's a philosophy. It's a philosophy of compassion. It's a philosophy of authenticity. It's a philosophy about living respectfully and responsibly.

Don't make it a religion, and don't turn me into a god." And the thing is that even if it was just the Norse gods and paganism or the Olympian gods, somehow or other, it would cease being that thing that the Buddha wanted a philosophy to be, and it would become something that admitted, you know, all its extremes, including the hypocrites on one side and the extremists on the other.

### Moderator
Claim: Okay. Ma'am, you were patient before when it was almost your turn. So try again. There is the mic. And if you could stand up and tell us your name, please.

### Moderator
Claim: Hi. My name is Meitha and I'm a student at NYU. My question is sort of a clarifying question for both sides. You've been referring to religion and to the acts of religious people. I'm wondering if you see religion as a social organization versus religion as a personal individual instance of faith as distinct and having distinct effects, or do you see them as inseparable?

### Moderator
Claim: And can I refine your question to take it more to our motion? And you tell me if this is fair. In a way, are you asking, should we get rid of the organizations and the churches and the synagogues and the panoply and the various kinds of hats that different faiths wear to establish themselves and to promulgate their rules? Is that what you mean?

### Moderator
Claim: Essentially, yes, yes.

### Moderator
Claim: Okay. I want to ask the side arguing for a world without religion if that's what you're talking about. Are you talking about--

### Conspiracy Advocate (CA)
Claim: --yes, I think--

### Moderator
Claim: --the organization.

### Conspiracy Advocate (CA)
Claim: I think we were thinking about more or less organized collective practice of doctrine and morality. I mean, people do-- the thing about the word "religion" it's like sort of grandmother's underpants. You know, it's huge and baggy and saggy. It's got so many things in it. We talk about football, is this religion or tennis is our religion. And so our meaning is something that obsesses you and takes you over. The idea of one person believing that there are fairies at the bottom of the garden, and that that's person's religion is a bit of a stretch of the word.

You want to look at the paradigm. And the paradigms are Judaean and the Christianity and Islam and Hinduism.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: And they are collective practices.

### Moderator
Claim: Is there a religion without the organization, Rabbi Wolpe? David Wolpe.

### Scientific Advocate (SA)
Claim: No.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: I mean, there is personal religious experience, but what we're talking about today is the social organization of religion and what religion does in the world, not so specifically what it does for individuals. So I would--

### Moderator
Claim: Okay. Sir, right down in the front row, plaid shirt.

### Moderator
Claim: Thank you. My name is Mike. I-- approaching the holidays, and we're talking a lot about charity. And the argument you are making is that religion is very charitable. Charities are often scrutinized because of their overhead. I've been to the Vatican. And--

How do you reconcile the-- the obvious--

### Moderator
Claim: Plunder.

### Moderator
Claim: --fluidity of funds that are being collected versus what is given out. And to be honest, if I-- = how would you convince me to give my money to you when I can give it to charities that are--

### Scientific Advocate (SA)
Claim: I'm not going to give it to the Vatican, I promise.

### Moderator
Claim: --charities without as much overhead.

### Moderator
Claim: But David Wolpe, I think the question they're saying that religions can get very involved in earthly things and bog down in the-- or Dinesh, do you want to take the question? Yeah.

### Scientific Advocate (SA)
Claim: I think in the case of the Vatican, the wealth of the Vatican is in priceless treasures, tapestries, the ceiling of the Sistine chapel, art. Now, let's remember-- let's remember - - hold on a second. It's not the Vatican's bank balance. It's the Vatican's treasures.

And let's remember that it was popes, the Medici popes and so on, who commissioned those paintings. If it wasn't for Catholicism, we wouldn't have the Sistine chapel. Not only that-- not only that, but in a study of achievement, the social scientist Charles Murray asked this question: Why, at the top of the Gothic Cathedral are there gargoyles that have been detailed and carved in a way that no one can see them? And when the people who did those were asked why they were doing it when no one could see it, they said, we are carving for the eyes of God. The point being that transcendence introduces a new perspective. Sub specie aeternitatis. The perspective of eternity. And so in a sense, your orientation is different, you act differently. And I'm not defending accumulations of wealth. I concede, religion, like any human institution is susceptible to corruption, a little bit like politics or anything else. But I'm saying on the balance, I think it would be wrong to think that we would be better off as a civilization as a culture, it's not all Athens.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: It's a combination of Athens and Jerusalem.

### Moderator
Claim: Let me take the other side on that question as a balance. Anthony Grayling.

### Conspiracy Advocate (CA)
Claim: The church commissioned a lot of art because it had the money. And even artists have to eat. And we’ll notice that after the medieval period, the time when the great Gothic Cathedrals were built, soaring up to heaven with their wonderful spires and crockets, that was a time when people were taught that this life is short and nasty and brutish, and you've got to hang in there. And if you didn't sin too much, you might have a bit of a shorter time in purgatory. And the Renaissance, the rediscovery of classical antiquity and its love of things human and things natural reintroduced not just devotional art but landscapes, picnics, portraits of ordinary people, paintings of still lives, a celebration of this world and all the joy and pleasure that there is to be had in this world, a humanistic perspective.

### Scientific Advocate (SA)
Claim: Was it not Thomas Hobbes who said life was nasty, brutish and short? It wasn't a religious. It was a philosopher.

### Conspiracy Advocate (CA)
Claim: I was quoting him.

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: One more question, right in the center there. Microphone will come in.

### Moderator
Claim: All over the United States today as far as I can tell, we're seeing churches-- the organized religious institutions shutting down or closing down or contracting, in particular churches and synagogues, as far as I can see personally, in great numbers. Does that bespeak, in your view, and in your view, a decline in the views of Americans towards religion as something that they do not want in this country?

### Moderator
Claim: So in other words, are Americans beginning to vote with the other side more.

### Scientific Advocate (SA)
Claim: Should I take a poll?

### Moderator
Claim: No, no, no, no. Good one.

### Scientific Advocate (SA)
Claim: The-- look, in--

### Moderator
Claim: David Wolpe.

### Scientific Advocate (SA)
Claim: In survey after survey after survey, Americans still pronounce themselves overwhelmingly religious, overwhelmingly religious, 80 percent, 90 percent.

It is certainly true. And by the way, and don't discount economic downturn because that also has a profound effect on religious institutions and other nonprofits as it does on the-- on the rest of the economy. I think that you find both trends at the same time. I think that this is a complicated-- you need Balanchine to choreograph this. It's complicated. At the same time as people's religion is still high, their sense of religious affiliation and how they want to express their religion shifts very much. And so I don't think that you necessarily are seeing a decline in people's sense that there's something transcendent, something greater than themselves. But some organized religions, and not all, Mormonism is growing, some evangelical groups are growing, some religions but not all are declining.

### Moderator
Claim: Pew reported that 10 percent of the American population is made up of former Catholics, which I find astounding.

### Scientific Advocate (SA)
Claim: That is astounding.

### Moderator
Claim: Always I--

### Scientific Advocate (SA)
Claim: Are they Jewish now, are they--

### Moderator
Claim: --they have all that unbridled guilt running around in this society as well.

### Scientific Advocate (SA)
Claim: Maybe I should do the Vatican--

### Moderator
Claim: Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: Well, I do think it's-- there was an expectation in the '60s and '70s that the world was becoming secular. Europe was seen as being the automatic vanguard of this and the assumption was that as people become more affluent and educated they will automatically become more secular. It's turned out not to be the case. America has not gone the way of Europe, and in fact if you look at any other culture, we're not seeing this automatic secularization. If you meet a Hindu Ph.D. and a Hindu janitor they're just as likely to be religious. There's no difference. Same in Islam. So I think that it is the disproof of the secular assumption that has in a sense brought out this aggressive new atheism because the atheists thought they were winning anyway, they were winning by default.

I think the European case is anomalous. It was not an attack on religion. It was an attack historically on an oppressive alliance between throne and altar. It was a political rebellion against a particular manifestation of religion in that society and the rest of the world is not going that way at all.

### Moderator
Claim: Matthew Chapman, is there an advance of atheism or actually a bit of a retreat?

### Conspiracy Advocate (CA)
Claim: I-- sadly I don't see much of an advance in atheism, and as for the churches emptying out, I think it's rather like the corner stores being taken over by Walmart. You have the little churches and then you have the big mega-church. And you have churches now where 20,000 people go to pray, evangelical Christian. So you know I'm sure there's some diminution of religious attendants but I don't see a huge surge of atheism unfortunately.

### Moderator
Claim: Okay, and Anthony Grayling.

### Conspiracy Advocate (CA)
Claim: I think Dinesh might be guilty of a tiny bit of wishful thinking there because the trend is towards more secularism.

In fact, what's happened since 9/11 when the very violent religious activism brought religion back into everybody's point of focus again, is that the volume has gone up. People think that religion is resurging but actually it's because the volume has gone up in the debate. Literally thousands, literally thousands of books of a religious nature are published every year in the United States of America and in Britain. You don't have to walk into a Barnes and Noble to see shelf after shelf of them. About half a dozen books which are by Dawkins and Christopher Hitchens and Sam Harris and Daniel Dennett, about half a dozen books have been published attacking religion and putting the atheist case, and all hell breaks loose. But by the way hell was sufficiently banned by the Episcopalian church-- back in the 1920s. I don't know whether you know this but they're trying to reinvent themselves, but anyway it broke loose because half a dozen books had come out attacking the religious standpoint. And what had happened was this, before 9/11 religion went sort of by default.

If I met a religious person, I would you know pussyfoot around, few eggshells. Somebody once said, you meet a Christian, it's like meeting somebody who's had a recent death in the family, which is a bit sort of apropos. So you wouldn't say anything-- and they probably at a dinner party wouldn't come out with their religious mission statements.

### Moderator
Claim: Anthony.

### Conspiracy Advocate (CA)
Claim: But after 9/11 they did start to do it. The gloves have come off. The debate is now out in the open. And that's why it all sounds so noisy.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate. And here's where we are. We are about to hear brief closing remarks from each debater in turn. The closing remarks will be two minutes each. This is their last chance to change your minds. Remember, after this we're going to ask you to vote again. And very quickly we'll have the results in a couple of minutes to declare our winner. On to round three, closing statements by each debater in turn. Our motion is this, "The world would be better off without religion." Here to speak against the motion in his closing remarks, David Wolpe, rabbi of Sinai Temple in Los Angeles, California.

### Scientific Advocate (SA)
Claim: I'm not going to read to you from the article in Skeptic Magazine that appeared in the most recent Skeptic Magazine which is as anti-religious a magazine as you can find saying that it is not possible to sustain that religion causes violence in the world, that, that is in fact not true and none of the statistics support it. But I do encourage you to take a look and read it and instead I'm going to end with a story. I'm a rabbi. So Rabbi Hugo Gryn was a rabbi in England for many years but he and his father were in Auschwitz when he was a child. And Hanukkah came around. And his father took the precious margarine ration and instead of using it for food he used it to light the Hanukkah candle. And his son protested and said how can you do this? Don't you understand that this is food? And his father said to him, “Listen, my child, we have learned that you can go three weeks without eating. You can go three days without drinking, but you cannot go three minutes without help.”Now we’ve been accused of being too sophisticated to participate in this debate. Right. Real religious people are simple-minded. But I want to tell you that there are people all over this world, who, whether you think of them as simple-minded or not, the hope of their lives, the purpose of their lives, the good that they do is dependent not in fact on evolutionary pressures alone but on that candle, on the idea that God not threatens them, not is going to send them to hell, but that God created them in God’s own image, that they are precious, that they are sacred, and so are other human beings. And they wouldn’t live three minutes without that hope. And if you vote for the motion, then you’re suggesting that the world would be better if the hope were taken away from them. It isn’t, and you shouldn’t.

### Moderator
Claim: Thank you, David Wolpe. motion is “The world would be better off without religion,” and here to speak in support of the motion, A.C. Grayling, philosopher and author of “The Good Book: A Humanist Bible.”

### Conspiracy Advocate (CA)
Claim: Thank you. It seems very unkind to say that, but alas, it’s just basically true that the religious outlook on the world has its roots, its origins in the beliefs, the superstitions of illiterate goatherds who lived up to 3,000 years ago. And however much religion reinvents itself and however much it tries to make us forget its history and however much it obscures the fact that it depends upon proselytizing very small children for its survival, despite all that, we have an opportunity to think again and afresh and to recognize that in order to live with the kind of hope, with the kind of responsibility, with the kind of love for our neighbor, which is essential for a world of peace.

We’ve got to do that hard work of choosing our morality, choosing our ethics, thinking about the principles of which we live, not borrowing it, not inheriting it, not having to conform to a set of doctrines about these things and a set of rituals which people very, very, very long time ago depended upon to do their thinking for them, but to think afresh, start again, and look at this world as a place where reason and human experience have to be our best, because they are in fact our only guides.

### Moderator
Claim: Thank you, A.C. Grayling. Our motion is “The world would be better off without religion.” And here to summarize his position against the motion, Dinesh D’Souza, president of the King’s College in New York.

### Scientific Advocate (SA)
Claim: Rabbi Wolpe and I have been laboring under a tremendous disadvantage in this debate. Both our opponents have a British accent. Now, I was raised in India, and I come from a small part of India called Goa, which was a Portuguese colony for many years.

And I’d always assumed that my Christianity was the product quite honestly of the Portuguese Inquisition. The Portuguese came to India with a sword in one hand and a Bible in the other. And lots of people converted. They were extremely persuasive. So I’m very alert to the dangers of religion. On the other hand, I once asked my grandfather, a historian, about this. And he said that the fact of the matter was that tons of Indians flung themselves into the arms of the missionaries. They wanted to convert. Why? And my grandfather’s answer was that if you look at history, it was because of the ancestral-- not religious, but cultural caste system. Most of the Indians were relegated to the lower caste.

And the fact of the matter is that if you were at the bottom, an untouchable, let’s say, there was no way to get out. There was no way to move up. No amount of merit could help you. And so, even though the missionaries might have been greedy and irredentist, the fact that they preached an idea of universal brotherhood, of love, of compassion, inspired people, ennobled their lives. And that’s why they became Christians. A world without religion would in fact be a grimmer, harsher, meaner world. Religion, for all its flaws, gives us a kinder and gentler world. And that’s why it’s better to have a world with religion in it. Thank you.

### Moderator
Claim: Thank you, Dinesh D’Souza. Our motion, “The world would be better off without religion,” and here to summarize his position in support of this motion, Matthew Chapman, writer and co-founder of Science Debate.

### Conspiracy Advocate (CA)
Claim: The world would be better off without religion because it is better off without religion. If religion made people behave better, markers of social dysfunction, drug addiction, ignorance, teen pregnancies, violent crime would be much lower in highly religious societies.

In fact, the opposite is true. To quote my friend, Austin Dacey, "In post Christian Europe, entire nations have been plunked into endemic health, sky rocketing education and hopelessly low rates of violent crime." This was a disadvantage to the English. And I'm not-- I'm American. Forgive me for using America by way of comparison. I am an American. I love America. However, 90 percent of Americans believe in God. But we have by far the largest prison population on earth. Drug addiction is widespread. Gun violence is grotesque. Our education system produces kids whose math and science skills are far lower than in secular countries while our rate of teen pregnancy is far higher. And in a country so rich and Christian, it's amazing how many people live in abject poverty. Religion is a rational, morally confusing and divisive. It still exposes young children to the ghastly concept of hell. It still denigrates women.

It still fosters homophobia. And "religious" gave us 9/11. Making no reference to God, science has, among many other things, rid us of the plagues, smallpox and polio, dramatically reduced infant mortality, doubled the average length of a burdened life and is coming to understand how the brain works, including its capacity for empathy and moral decision making. All this progress, all this beautiful knowledge, all this alleviation of human suffering in 100 years. Religion has had thousands of years to prove its supernatural effectiveness. It hasn't. We think it's time to try a safer and more enlightened way. So I hope you will support our position that the world will be better off without religion.

### Moderator
Claim: Thank you, Matthew Chapman. And that concludes our closing statements. And now it's time to decide-- to decide which side you feel argued best.

Let me just say that again so that it comes out. And now it's time to find out which side you feel argued best. We're going to ask you to again to go to the key pads at your seat and to vote on which argument you felt was better presented. Push number one if you are with this team, the team that's arguing that "the world would be better off without religion," number two if you're with the team that argued against that proposition and number three if you remain or became undecided in the course of the debate. And we'll lock those in. Ignore the other keys, and you can correct your vote, as I said earlier. And we'll have the results practically instantaneously. Our producer, Kris Kamikawa, is backstage working on them and will bring them out to me.

So before we move forward, I just want to thank-- I want to thank our debaters for the quality of our argument and the spirit of fairness that they brought to this.

And I really feel that they might not have agreed with each other, but they heard etch other, and that's the essence of what we're trying to do here. So thank you for that. And I also want to say that the questions that we got tonight were some of the best we've ever had in a debate. The question from Slate, from everybody here, even the gentleman with the question that I wanted to veto. The audience's veto of my veto was a good call. I think that went into a good-- a good place. So thank you to all of you for your participation and for the questions that you asked. So this concludes our fall season, but we're starting up again right after New Year's. We start a new season of five debates from January through May. And we are setting them up now. And I just want to let you know what's coming up, what's booked so far, what's cast in iron at this point. On January 10th, the UN should recognize a Palestinian state, will be our motion.

And our debaters will include, arguing for recognition, Hanan Ashwari who has long been a player in the story of the peace process. She was the first woman to be elected a member of the PLO's executive committee, very frequent guest in the old days on "Nightline." And we're very, very happy that she's coming in for that. And arguing on the other side, Aaron David Miller. He has served six secretaries of state on Arab-Israeli negotiations. And the rest of the slots on that debating panel are yet to be filled. On February 7th, our motion is going to be obesity is the government's business. And we have booked Paul Campos. He is the author of "The Obesity Myth." And he is trying to fight society's fear of body fat. March 13th, this motion we go internationally. And every season we do something from the east, or try to. And this time a focus on China. In an interesting way we think China does capitalism better than America. And our debaters in that include Ian Bremmer who is a founder of a global political risk consultancy.

New York Magazine says his career makes Mozart look like an underachiever. And on April 17th, the motion will be "When it comes to politics, the Internet is closing our minds." We'll include Jacob Weisberg who is a pioneer in online publishing, chairman of the Slate Group, and our partner in this whole process, and Eli Pariser who is the former executive director of MoveOn.org. And May 8th, we booked this before the news caught up with it. But the motion on May 8th is "Ban college football." Our debaters will include Buzz Bissinger who is a writer and acclaimed author of Friday Night Lights. And Malcolm Gladwell who has compared football to dog fighting and who is the author of Blink. So our full lineup of debaters will be put together fairly soon. You can come to our Facebook page. And if you join our Facebook page, you'll have a discount on future tickets. We're also on Twitter and on NPR stations across the nation.

You can check the local listings for when it'll air on NPR and WNYC here in New York. And we'll also be on public television, this particular debate as well. So again I want to thank you all. And we're-- We'll do a very-- a very brief countdown. I'm going to guess from 60 seconds or so to the-- even faster. Thank you, Kris. All right. So we have the final results. We asked you to vote before the debate and once again after the debate on where you stood on this motion and on what team you felt argued their position best. And the team whose numbers changed the most is our winner. The motion is this: "The world would be better off without religion." And here is the result. Before the debate, 52 percent were in support of the motion. 26 percent were against, and 22 percent were undecided. After the debate, 59 percent support this motion. That's up 7 percent. 31 percent are against it. That's up only 5 percent. And 10 percent are undecided. That's down 12 percent. That means the side arguing for the motion that "The World Would Be Better Off Without Religion" has carried this debate. Our congratulations to them. Thank you for me, John Donvan and Intelligence Squared U.S. We'll see you next time.
