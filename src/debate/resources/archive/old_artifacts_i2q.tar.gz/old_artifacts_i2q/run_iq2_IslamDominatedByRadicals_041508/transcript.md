# Debate Transcript

Topic: Islam Is Dominated By Radicals
Motion: Islam Is Dominated By Radicals

Debate ID: IslamDominatedByRadicals-041508


## Round 1

### Moderator
Claim: I’d like to introduce Robert Rosenkranz, who is Chairman of the Rosenkranz Foundation which is the sponsor of Intelligence Squared and he will frame tonight’s debate. Bob.

### Moderator
Claim: Thank you, Robert. Thank you very much, and welcome. Well, my task this evening is to frame tonight’s debate, and I frankly find it a bit challenging. Unlike most of our debates, which speak to policy, this one is about facts. Islam has some one and a half billion adherents. Muslims in America seem quite well integrated into our society. Arabs account for only twenty-five percent of all Muslims. The majority are found throughout Asia. But the radical Islamic movement in the Arab world, their doctrines of jihad, holy war, their tactics of terror – that’s what sort of shapes our view. Well, is this view distorted? The polling data is not reassuring. Consider the following examples. In Pakistan, Indonesia, Morocco and Egypt between seventy-three percent and ninety-two percentbelieve that the U.S. goal is definitely or probably to weaken and divide Islam. In the same countries, only nine to twenty-three percent believe that the goal of the U.S. war on terror is to protect itself from terror attacks. In those countries, around twenty percent of those surveyed supported Al Qaeda’s attacks on Americans and more than seventy percent agreed with such Al Qaeda goals as deterring U.S. support for Israel pushing Western values and Western militaries out of Islamic countries and affirming Muslim dignity by standing up to America.

And it’s astonishing to note that only between two and thirty-five percent of those polled identified Al Qaeda as behind the 9/11 attacks. In contrast, twenty to thirty-eight percent identified the U.S. or Israel as the perpetrators of 9/11. And to end on a deeply confusing note, in Egypt eighty-eight percent agree that groups like Al Qaeda that use violence against civilians are violating the principles of Islam, yet sixty percent believe that suicide bombers are often or sometimes justified. Well, what are we to make of all of this? From a geopolitical standpoint, are the radicals the only ones who matter? Does their organization, intensity and violence effectively intimidate more moderate voices? Are we engaged, in Samuel Huntington’s formulation, in a clash of civilizations? Or is that precisely the characterization that the radicals hope to provoke? I’m confident that tonight’s panel can shed some light and it’s my pleasure to turn the evening over to our long-time radio host, and the host of NPR’s All Things Considered – Robert Siegel.

### Moderator
Claim: Thank you, Bob. Thank you. And I’d like to welcome you to this, the ninth debate of the second Intelligence Squared U.S. series. The resolution that’s being debated tonight is: Islam is dominated by radicals. And I’m going to give you a brief rundown of the evening. Members of each team will alternate in presenting their side of the argument. Presentations are limited, strictly limited, to seven minutes each. When opening arguments are complete, I’ll open up the floor to brief questions from the audience, and after the Q&A session, each debater will make a final two minute summation. And finally, you will vote on tonight’s motion with the keypad that’s attached to the armrest of your seat and I’ll announce your decision on which side carried the day.

Let’s begin, though, with a pre-debate vote. I’d like you to pick up the keypad that’s attached to the armrest on your left. And, for audience members sitting along the aisle to my right, your keypad is attached to the armrest on your right side, next to your neighbor’s. Has everybody found their keypad? Shall we take a vote on whether you’ve found your keypad? Good. Now, tonight’s resolution is: Islam is dominated by radicals. After my prompt, press one to vote for the motion, two to vote against the motion and three if you are undecided. You may begin voting now. And I will be informed of and reveal the results of your vote later in the evening. I’d like now to introduce the panel, and please hold your applause until all six of our panelists are introduced.

For the motion, first, the Vice-President at the Foundation for Defense of Democracies, Daveed Gartenstein-Ross; Senior Fellow in the Center for Religious Freedom at the Hudson Institute, Paul Marshall; and Professor in the practice of Journalism at Georgetown University School of Continuing Studies and former Wall Street Journal reporter, Asra Nomani. Against the motion, Assistant Professor of Creative Writing at the University of California, Riverside, and Fellow at the University of Southern California Center on Public Diplomacy, Reza Aslan; Professor of History at Columbia University, Richard Bulliet; and Director of Communications for the Muslim Public Affairs Council, Edina Lekovic. Those are our six panelists. First, opening statements to be delivered from the podium and the order of presentation begins with Paul Marshall, speaking for the motion – seven minutes. With one minute left you’ll hear me say, “one,” which will be a warning.

### Conspiracy Advocate (CA)
Claim: Good. Okay, thank you very much for inviting us all this evening and thank you for being here. We in favor of this motion argue that Islam is dominated by radicals. What do we mean by radicals? We mean those who are striving for a political order representing a reactionary version of Islam that denies legal and civic equality to men and women and also denies it on the basis of religion. It also denies freedom of speech and freedom of thought. We believe such trends, such people, currently dominate world Islam. Let us be quite clear about what we are not arguing. We are not arguing that Islam itself is inherently radical. Like any other movement, Islam takes different forms at different times. Also, we are not arguing that most Muslims are radical. Most are not.

But what we are saying is that it is the radicals who have their hands on the levers of power. They are, to pick a word, the hegemonic. They’re the most powerful driving force. They’re tending to set the direction and shaping the future of Islam in the modern world. They do this not because they have superior numbers, but because they are extremely focused in what they want. They’re clear about it. They are often well organized. They’re often very well funded, often by Saudi Arabia and they are very, very committed, being quite willing to often kill themselves and to kill other people, especially Muslims. So this is what we’re arguing. To illustrate this I just want to show some of the trends which we have seen in the world in the last twenty-five to thirty years. Some twenty-nine years ago, of the major Muslim countries in the world only one-- Saudi Arabia - maintained that its political and constitutional order was a reflection of what it regards as original Islam and that it has accepted no foreign or infidel accretions.

Saudi Arabia was, and is, one of the world’s most repressive states. Many, many examples could be given but I just mention one recent incident when three Saudi intellectuals sent a petition to the king – a petition asking for a gradual move towards a constitutional government. They were charged with using – I quote – un-Islamic terminology. The un-Islamic terminology they used in their petition included the word human rights and democracy. So we have the situation of Saudi some thirty years ago. Then in February of 1979, the Ayatollah Komeini overthrows the Shah and establishes a draconian regime in Iran, which also since then has become one of the most repressive regimes in the world.

It bars anybody who is not a Muslim from having any authority over a Muslim. It bars Muslims who do not support the regime’s version of Islam from running for political office. One other example: In Iran, if you kill someone who is a member of one of the non-listed religions, non-recognized religions – say, such as the Baha’is – there is no punishment. To kill a dog, a cat or a Baha’i is the same thing. It is no matter of the law because they have no legal status. They do not religiously and politically exist. Similarly, for sexual relations between a non-Muslim man and a Muslim woman, the penalty for the non-Muslim is death. And of course, the penalty for homosexuals of whatever religion is death. A new proposed penal code has been presented to the Iranian Parliament which would institutionalize its current practice that it would require with no possibility of reprieve, annulment that the penalty for heresy or for apostasy-- leaving Islam-- is death.

Article 112 of this, this penal code also emphasizes the law will be extraterritorial. This means, incidentally, if this law is in fact passed, under Iranian law Barack Obama should be executed as an apostate. With the development of Iran next door to them, the Saudis redoubled their own efforts to export their own version of radical Islam. They proclaim themselves, on many occasions, the Muslim Vatican-- a very un-Muslim term-- and now, by most best estimates, spend some three billion dollars exporting their radical version of Islam around the world. That’s somewhat more, that’s about three times as much as the Soviet Union used for ideological purposes at the height of its power. If one travels to a moderate Muslim country, such as Indonesia, or if you travel throughout Africa, you will find Saudi-funded mosques, Imams, lectures, sermons, students, books, videos, fatwas propagating its own reactionary version of Islam. The Iranians seek to do the same. One result of this, though there are homegrown radical movements, with this organizational push behind them, one sees the growth of radical Islam throughout the world. Some examples: when Pakistan was founded it was not founded –

…as an Islamic country. The Ali Jinnah – the man who founded the country-- said, whether you’re a Muslim or you’re a non- Muslim is no matter of the state. But now they have introduced blasphemy laws, which include the death penalty, particularly used on religious minorities. In Sudan, the government has instituted laws and propagated genocidal wars against the south in Darfur, killing some two million and two hundred and fifty thousand, respectively. In Nigeria, some fifty thousand people have died in conflict over the introduction of radical Islam. We see this phenomena repeated throughout the world and one could give very many more examples. One sees it even in, growing in Malaysia and Indonesia – historically very moderate countries. One result is that in Freedom House’s rankings of the world’s twenty un-free countries, the majority now are Muslim.

Okay, the crucial confluence of ideas is not between the West and the Muslim world –

…it is within the Muslim world. Thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …as an Islamic country. The Ali Jinnah – the man who founded the country-- said, whether you’re a Muslim or you’re a non- Muslim is no matter of the state. But now they have introduced blasphemy laws, which include the death penalty, particularly used on religious minorities. In Sudan, the government has instituted laws and propagated genocidal wars against the south in Darfur, killing some two million and two hundred and fifty thousand, respectively. In Nigeria, some fifty thousand people have died in conflict over the introduction of radical Islam. We see this phenomena repeated throughout the world and one could give very many more examples. One sees it even in, growing in Malaysia and Indonesia – historically very moderate countries. One result is that in Freedom House’s rankings of the world’s twenty un-free countries, the majority now are Muslim.

### Moderator
Claim: Paul Marshall, thank you very much for your opening statement, in support of the motion--

### Conspiracy Advocate (CA)
Claim: Okay, the crucial confluence of ideas is not between the West and the Muslim world –

### Moderator
Claim: Islam is dominated by radicals.

### Conspiracy Advocate (CA)
Claim: …it is within the Muslim world. Thank you.

### Moderator
Claim: Thank you. Now the first opening statement opposed to the motion: Islam is dominated by radicals. The speaker is Reza Aslan.

### Scientific Advocate (SA)
Claim: There is something peculiar about the way that this debate tonight is being worded. The idea that we could, from our comfortable perches here in Manhattan, pass judgment on the beliefs and practices of a billion and a half people in every corner of the world. And despite Mr. Marshall’s comments, we’re not here to talk about whether Saudi Arabia or Iran is dominated by radicals. We’re here to talk about whether Islam is dominated by radicals. So I suppose it’s not surprising that a large percentage of people in this room would believe that Islam – unquestionably the most eclectic, the most diverse religion in the history of the world – is dominated by radicals. After all, no field work or research is necessary to come to such a conclusion – just turn on your television, watch your nightly news. Now, of course, we’re not children in this room. We all recognize that the purpose of commercial news is to sell commercials – which, by the way, is why I only get my news from NPR, Robert.

### Moderator
Claim: Thank you, yes.

### Scientific Advocate (SA)
Claim: And what sells commercials, of course, is violence and terror. You all know this. So then if there are violent protests about, let’s say, against deliberately provocative cartoons of the prophet Mohammed in a Danish newspaper, that’s a story. However, if a racist politician in The Netherlands makes a movie – we’re talking about Geert Wilders here-- makes a movie comparing the Koran to Mein Kampf and requesting its abolishment in the entire country and no protests erupt, the lack of protest is not a story. There is simply no story.

Similarly, if the Pope makes some controversial comments about the prophet Mohammed and there are mass protests on the street, that’s a story. If the Pope goes to Turkey and no mass protests erupt, it’s not that the lack of protests is a story. There is no story. And I can tell you because I was there with CNN. Of course, much of this debate tonight – and in…and indeed, much of the debate about Islam in general is based not only on the media but on firsthand anecdotal evidence provided by, quote/unquote, insiders. And I’m sure you’ll hear plenty of that tonight from Asra and Daveed. How the experiences of the colleagues for the motion in confronting radicals in their own communities has given them the knowledge necessary to judge the beliefs and practices of a billion and a half people, I’m not sure. I will say that if I based my views of Catholicism on the stories that I hear from my former Catholic friends and on the media reports about Catholicism, I’d pretty much have to assume that Catholicism is dominated by sadistic pederasts.

But of course that’s not true. So then I suppose the real question here is why do we keep asking pundits and politicians and writers and public intellectuals what Muslims think? Why don’t we just simply ask Muslims themselves? This is, after all, not so arduous a task. In fact, the Gallop organization – the most trusted polling organization in the world-- has already done the work for us by conducting the largest, most comprehensive poll of the Muslim world ever done. According to that poll, a mere seven percent of the world’s Muslims – not Arabs – seven percent of the world’s Muslims believe that the attacks of 9/11 were justified. Now, more interestingly, Gallop went a little bit further and actually asked those seven percent why they believe the attacks were justified.

And the responses fly in the face of conventional wisdom. For example, in Indonesia – the largest Muslim country in the world, and frankly, quite a pluralistic and successful democracy-- not a single respondent, not a single respondent in Indonesia cited the Koran as justification for the attacks of 9/11. Indeed, seventy- four percent of Indonesians, eighty-six percent of Pakistanis, eighty-one percent of Bangladeshis and eighty percent of Iranians said that attacks against civilians were, quote, never justified-- never. Now, please compare that to forty-six percent of Americans who said the same. In fact, the Gallop poll found that in all Muslim countries the majority of those Muslims who, quote/unquote, support violence or what we can refer to as radical views or tendencies do so for markedly secular – that is, political – reasons.

Robert Pape found similar tendencies in his comprehensive study of suicide bombing. He found that ninety-five percent of all suicide terrorism is, quote, not driven by religion as much as by clear strategic – read, political – objectives. In short, when we talk about radicalism in the Muslim world we are talking about political radicalism, which after all, in a globalized world is not that odd. Why are these political goals so often couched in the language of religion – and in this case –

…the language of Islam? Well, it’s because in every society religion holds the most currency with the masses. In every society religion provides a powerful language to create simple collective identities and to urge collective action. In every society the language of religion has the power to distill the most complex sociopolitical issues into the simplest of choices – good versus evil, us versus them. As I say, this is true of every society, ours especially. And if you don’t believe me, I suggest you ask Karl Rove. Thank you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …the language of Islam? Well, it’s because in every society religion holds the most currency with the masses. In every society religion provides a powerful language to create simple collective identities and to urge collective action. In every society the language of religion has the power to distill the most complex sociopolitical issues into the simplest of choices – good versus evil, us versus them. As I say, this is true of every society, ours especially. And if you don’t believe me, I suggest you ask Karl Rove. Thank you.

### Moderator
Claim: Thank you, Reza Aslan, for that opening statement. Now, speaking in support of the motion: Islam is dominated by radicals, Asra Nomani.

### Conspiracy Advocate (CA)
Claim: So I would say assalamu alaykum to all of you, but according to the prayer book that I was handed when I went on the pilgrimage to Saudi Arabia, I’m not allowed to say this peaceful greeting to those who aren’t Muslim. When I see that headline: Islam is dominated by radicals, I don’t hesitate in believing it to be true. The opposite side wants to suggest that we can’t tell you stories from the trenches. But it is, in fact, in the trenches where we know what is happening, that we know that the radicals are, in fact, intimidating, silencing and paralyzing the moderates. I know it from my lifetime in the Muslim community and I know it from stories and anecdotes, sure, and historical and country cases. When I was given this proposition I asked my mother – a grandmother, who has taught me my Muslim prayers, who is teaching her grandchildren the prayers – I said, Do you think that Islam is dominated by radicals? You can dismiss her as an anecdote. You can dismiss her as somebody who isn’t pundit enough but she’s got her finger on the pulse of what’s going on in our communities. And she didn’t hesitate in saying yes. For the last thirty years that I have known, since the exportation of Wahabiism from Saudi Arabia to the far reaches of our Muslim world, I know that our community is dominated by radical ideology.

I know that it is an ideology that has taken root in countries from Pakistan to states in Nigeria to provinces in Indonesia with laws that put women in second class status, that give women criminal punishments because of sexual crimes. In each instance you could say that there’s a political purpose. But at the end of the day it is done in the name of Islam. I don’t stand up here and condemn my faith. I fight for it every single day. I fight for a progressive interpretation of our faith. But at the end of the day our religion, our institutional Islam out there in the world-- from my home town of Morgantown, West Virginia to Islamabad, Pakistan to Indonesia to Riyadh, Saudi Arabia – we are controlled and dominated by radical ideology. The moderates don’t want to lose their status. They don’t want to lose their place in the community. They don’t want to lose their invitation to the potluck dinner parties and wedding halls that they get to go to.

It’s an issue of social dynamics. At the end of the day it isn’t worth it to them to take on the radical ideology because there’s too much at stake. You risk your own safety and then you risk your social standing. I know this as a woman in the faith. I know that what we are struggling with is a situation where more mosques in America than in the 1990s are putting women in separate sections. Two-thirds of mosques in America versus half in the 1990s have women separated. And you could argue that that’s not radical ideology. But at the end of the day it is part of a continuum of an interpretation of Islam that takes a literal read that says a woman is sexual temptation, that a woman is sexual distraction. You take that interpretation and it isn’t that long that you have to also add up to an interpretation that says that you can’t be friends with the Jews and the Christians, that violence is acceptable.

Why do I know this? Because I’ve heard it from my pulpit. I’ve heard it from the sermons that are downloaded on college campuses across this country and across the world. There is an exportation of this ideology. We may watch our borders, we may check the visas of people who come into this country but I know that there is an ideology that says that a woman is half the witness of a man in criminal cases, that that is law in countries of our, of our religion, that there is interpretation that says that a woman gets less inheritance. When we put women-- half of our population, in particular-- in second class status around the world, you can call it anything you want. But I consider it unacceptable and I call it radical ideology. It’s unacceptable to have tradition become religion with female genital mutilation. It’s unacceptable to have honor killings, as we are, from Canada to Texas to Turkey. You can call those anecdotes but it’s a trend.

It’s a trend that’s happening because our Islam of today is dominated by radicals. We don’t have mosque leaders who are keeping that kind of ideology in check. We are, in fact, having leaders who accept preaching from the pulpit that says that we cannot imitate the dis-believers, that we cannot say assalamu alaykum to those who are not Muslim. At the end of the day what I want you to know is that I stand up for Islam as a faith. I stand up for the principles just like every other religion. But like Judaism and Christianity have evolved so that there is a continuum in institutional religion, so that there is a reform synagogue along with the orthodox synagogue, our mosques are defined by an institutional puritanical interpretation that to me is very radical and very unacceptable. And I encourage you to vote to support this motion because we need a truth telling. We need to be honest.

We need to not cower in the face of political correctness. A lot of you may have hesitation because you think that if you vote for the motion you are voting and condemning Islam. I don’t stand here before you saying that that is at all on the table. We can stand up for religion that is not dominated by radicals, but we can accept the fact when it is. And in our day, in the trenches in the Muslim world from a mosque just a few blocks away from here to Seattle, Washington to Dubai, we are facing a momentum where the leadership is one that accepts radical ideology and the moderates don’t stand up against it. So I encourage you to vote for the motion and understand that it’s a vote for truth. Thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: We need to not cower in the face of political correctness. A lot of you may have hesitation because you think that if you vote for the motion you are voting and condemning Islam. I don’t stand here before you saying that that is at all on the table. We can stand up for religion that is not dominated by radicals, but we can accept the fact when it is. And in our day, in the trenches in the Muslim world from a mosque just a few blocks away from here to Seattle, Washington to Dubai, we are facing a momentum where the leadership is one that accepts radical ideology and the moderates don’t stand up against it. So I encourage you to vote for the motion and understand that it’s a vote for truth. Thank you.

### Moderator
Claim: Thank you, Asra Nomani. And now, an opening statement against the motion from Edina Lekovic.

### Scientific Advocate (SA)
Claim: I will bid you assalamu alaykum, because that is what my faith teaches me and that, regardless of who is in the pulpit, is what the book teaches. When we consider the question of whether Islam is dominated by radicals we have to look in terms of absolute numbers and in terms of prominence and in terms of symbols. Saying that Islam is dominated by radicals is much like saying, is as absurd as saying that America is dominated by murderers. Certainly they exist within our society and certainly radicals exist within the fold of Islam. But do they dominate? Absolutely not. Based on the polling data that Reza shared with you and based on so much other data that exists out there, the people on the Muslim streets, both in the West and in the, quote/unquote, Muslim world, are striving for freedom, for freedom of speech, for democracy, for technology, for those very things that they admire the West for.

That is what their faith is pushing them to do. Now, Islam is dominated, if you will, by scholars, by average people more so than anyone else, who are struggling to understand Islam in a 21st Century context and who seek to foster inclusion of Muslims on the international stage and who want nothing more than to be understood and to be respected, as that same poll showed over and over again. To point to Saudi Arabia over and over again, I will hand that to the other side. Saudi Arabia is no, by no means the shining glory of any part of the Muslim world. But pointing to pockets in no way reflects the overall picture, the overall reality. Looking in a pocket or in many pockets in no way represents the overall cost to, the overall character of the people and it is the people who define the faith and who define their global community.

The reality is that the moral – You know, when we look at where this radical threat lies-- I travel across this country and around the world. We can fight anecdotes with anecdotes. When I was in Malaysia a few years ago talking to youth on the streets there, their single goal was to be understood. They wondered why Americans didn’t understand them and why Americans thought that they were all terrorists. When I traveled to Egypt it was the same. When I traveled even to Bosnia, to the former Yugoslavia where my parents are from, it was very much the same. The lack of understanding on both sides of the issue has in many ways been fueled by media perceptions as we have described here earlier. The reality on the ground is this: radicals are failing in their attempt to dominate. Radicals, those who make up Al Qaeda and its various branches, are on the run. They are in decline. Their messages are not reaching the audiences that they seek to convert and to brainwash as much as they used to.

And that, to me, is an important symbol of the rise of moderation, the rise of the middle, the rise of those who dominate this faith. Even those in Al Qaeda – Ayman al-Zawahiri, who recently released a tape – they have had to change their tactics because they are receiving criticism from within the Muslim community. They have had to respond to criticism about targeting civilians and have had to answer these questions to the very people that they are trying to recruit. And if we look even at the reality in the, quote/unquote-- and I say again, quote/unquote-- Muslim world, look even to Pakistan, where we saw that the radicals indeed killed Bhutto. But what did the people do in response? They elected a secular government. They responded in a different way. The people on the ground are the ones who are defining the face and the nature and the character of the faith and of the global Muslim community.

And again, what do they want? That’s what we have to remember. They do not want death and destruction. They want hope, they want economic ability, they want education and they want a seat at the table. If we also look to the, where the war against radicals is taking place, it’s almost entirely in the Islamic world, between mainstream societies and governments on the one hand and radical minorities on the other hand. Just look at what Muslim scholars and Muslim leaders have been able to achieve in the last few years and then we’ll ask ourselves, Why haven’t we heard about it? In 2005 Jordan’s King Abdullah convened an international Islamic conference of two hundred of the world’s most leading Islamic scholars from fifty different countries. Those scholars unanimously issued a ruling on three fundamental issues – the validity of all interpretations of Islam, the eight legal schools.

They forbade the declaration of apostasy between Muslims and they further provided pre-conditions to issuing fatwas, since they have become such a currency on the international market and have lost their meaning entirely. That’s one example. Another is that a hundred and thirty-eight Muslim scholars joined together to affirm freedom of expression-- scholars from around the world – and to condemn the negative reactions to the Danish cartoons – and which resulted, I think, interestingly, of the fact that there was very little, if – very little reaction to the most recent Danish, episode, if you will, of the film Fitna. And those same scholars reached out to the Pope to establish a historic Muslim/Catholic forum…

…seeking opportunities for dialogue that they could do on an international scale at the level of leadership and that could also be modeled for their citizens and their countries and for the faithful among them who wanted to see something different take place. Internationally recognized leaders are calling for integration, for tolerance and for advancement. And their reach is ten times wider at least than that of Al Qaeda or any of their associates. Just consider those, even in Turkey, which has recently elected a new government but has taken the lead in ushering in a historic re-examining of Islamic material to cater to the contemporary world. That is just one among countless examples of people who are working day in, day out to re-emerge as the dominant force within their faith and who are crying out for attention on the world stage. Just consider this last example, which is that, what –

Where do the cameras turn? That’s the question.

Precisely.

Right.

Sure—

Absolutely, but let’s consider also where that comes from, let’s consider the kind of US support that Saudi Arabia also gets in, you know, in reciprocity.

Now in no way …do I place any sort of validity or endorsement on the Saudi ideology. Is it out there, are there’s Korans out there that we fight problems with, absolutely. But even the Saudi people would disagree in large part with what their government is doing, and there is no foundation whatsoever for the kinds of, you know, of distorted perceptions of faith that they’re spreading on the ground. And that in no way represents the global reality of Islam. Again, looking at pockets and trying to turn them into global realities, we have to recognize and reinforce the majority. So that is—and that’s precisely what has happened since 9-11 which is the point that I was trying to make, that’s where the reemergence is taking place.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …seeking opportunities for dialogue that they could do on an international scale at the level of leadership and that could also be modeled for their citizens and their countries and for the faithful among them who wanted to see something different take place. Internationally recognized leaders are calling for integration, for tolerance and for advancement. And their reach is ten times wider at least than that of Al Qaeda or any of their associates. Just consider those, even in Turkey, which has recently elected a new government but has taken the lead in ushering in a historic re-examining of Islamic material to cater to the contemporary world. That is just one among countless examples of people who are working day in, day out to re-emerge as the dominant force within their faith and who are crying out for attention on the world stage. Just consider this last example, which is that, what –

### Moderator
Claim: I’m sorry. We’ll have to hear the last example later. Thank you very much.

### Scientific Advocate (SA)
Claim: Where do the cameras turn? That’s the question.

### Moderator
Claim: Edina Lekovic. Thank you, Edina Lekovic, for that statement in support of the motion: Islam is dominated by radicals. A couple of questions from me. Quickly, first for Paul Marshall. Uh, if, as you argue, uh, Islam is dominated by radicals, uh, why aren’t Indonesia, Malaysia, Bangladesh, uh, uh, or for that matter, hundreds—tens of millions of Muslims in India, all knuckling unto, uh, under to jihadist movements, and creating Islamic revolutions in those country, why don’t—why haven’t we seen more Islamic revolutions.

### Conspiracy Advocate (CA)
Claim: Because most Muslims don’t like the radicals’ agenda. But—

### Moderator
Claim: They’re not dominated by it—

### Scientific Advocate (SA)
Claim: Precisely.

### Conspiracy Advocate (CA)
Claim: Well, no, I think if people have guns, if they have intim—if they intimidate people, if they’re organized, if they have funding, if one sees even in Indonesia the increase in radical movements, radical Islam— radical imams, who were not there 10, 20, 15 years ago. When you see in Indonesia the destruction of hundreds of churches, where 10 years in Indonesia, 20 years ago you wouldn’t— would never have seen that, people coexisted. So even in places like Indonesia, in places like Bangladesh, in places like Malaysia, even though most of the people don’t want it, you have the growth of radical movements, and they often win, because they intimidate and scare other people—

### Scientific Advocate (SA)
Claim: Paul Marshall—

### Moderator
Claim: Okay, more—

### Scientific Advocate (SA)
Claim: Paul Marshall knows that those churches are primarily Chinese- owned, and the Chinese form a socioeconomic community in Indonesia that has been at great odds with the majority Muslim population there and that a lot of those churches are not religious violence. It’s ethnic, social violence, but more importantly, again, you know, here we go, we’re—we’re talking about this idea of, of domination—

### Conspiracy Advocate (CA)
Claim: By the way, most of the churches are non-ethnic Chinese.

### Scientific Advocate (SA)
Claim: The majority of Christians in Indonesia are Chinese. Are of Chinese ethnicity—

### Conspiracy Advocate (CA)
Claim: And you—

### Scientific Advocate (SA)
Claim: It is—

### Conspiracy Advocate (CA)
Claim: that Laskar jihad does not justify its attacks that way, it, it’s—

### Scientific Advocate (SA)
Claim: No, no, of course not—

### Conspiracy Advocate (CA)
Claim: —it’s just not a general religious war against Christians—

### Scientific Advocate (SA)
Claim: But lots of—but again they don’t dominate—

### Conspiracy Advocate (CA)
Claim: It’s just the primary group responsible for, for that violence—

### Scientific Advocate (SA)
Claim: But that’s the point—is that, they do not dominate either the discussion about Islam in Indonesia, or the society of Indonesia or the government, we’re talking— there’s one country in the world—

### Conspiracy Advocate (CA)
Claim: I agree with you and Edina that they don’t dominate the discussions, the conferences, when people—

### Scientific Advocate (SA)
Claim: Then what do they dominate—

### Conspiracy Advocate (CA)
Claim: —get together—

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: —but those don’t have much effect.

### Scientific Advocate (SA)
Claim: No, what, what—

### Conspiracy Advocate (CA)
Claim: The people— people with professors, every time.

### Scientific Advocate (SA)
Claim: What do they dominate—

### Conspiracy Advocate (CA)
Claim: They dominate actions. What I thought was really—

### Moderator
Claim: Asra Nomani—

### Conspiracy Advocate (CA)
Claim: —interesting—what I thought was really interesting was that, Edina, you even talked about the moderates reemerging as the dominant force in the faith, an acknowledgement that they are not the dominant faith—

### Moderator
Claim: —I want to hear Edina answer the question from Asra Nomani—

### Conspiracy Advocate (CA)
Claim: I would like to just make the point that, talk is great to point out, this is not a popularity contest of what Muslims mostly think. I mean this is about our institutional faith, if you ask me. When we talk about whether Islam is dominated by radicals, domination to me is, do they have leadership in our communities, and are they taking action that is representative of a violent strain of Islam and I’d say yes.

### Moderator
Claim: Asra Nomani, thanks, and Edina Lekovic— Let me ask you a specific question—

### Scientific Advocate (SA)
Claim: Sure—

### Moderator
Claim: —by the way you spoke of Saudi Arabia as a pocket that we shouldn’t take as representative any more than murderers in America should be representative of American life. Wouldn’t you concede that the role of Saudi Arabia, and Iran for that matter, on the global stage, is far disproportionate to their numerical position in Islam, they have influence beyond their own borders, right—

### Scientific Advocate (SA)
Claim: Absolutely, but let’s consider also where that comes from, let’s consider the kind of US support that Saudi Arabia also gets in, you know, in reciprocity.

### Conspiracy Advocate (CA)
Claim: But what does—

### Scientific Advocate (SA)
Claim: Now in no way …do I place any sort of validity or endorsement on the Saudi ideology. Is it out there, are there’s Korans out there that we fight problems with, absolutely. But even the Saudi people would disagree in large part with what their government is doing, and there is no foundation whatsoever for the kinds of, you know, of distorted perceptions of faith that they’re spreading on the ground. And that in no way represents the global reality of Islam. Again, looking at pockets and trying to turn them into global realities, we have to recognize and reinforce the majority. So that is—and that’s precisely what has happened since 9-11 which is the point that I was trying to make, that’s where the reemergence is taking place.

### Moderator
Claim: We have much more to come, we still have two opening statements yet to hear, and we’re going to resume those now, speaking for the motion, “Islam is dominated by radicals,” is Daveed Gartenstein-Ross. Daveed.

### Conspiracy Advocate (CA)
Claim: It’s important before you cast your vote in this debate to think carefully about the resolution, and to think carefully about the way that we defined it. As we said in our very first speech, we support the proposition that Islam is dominated by radicals, and we define radicalism in relation to human equality. In the Muslim world, is there belief in equality between religions? Is there belief in equality between genders? Is there support for basic freedoms, like freedom of speech, and freedom of religion? The other side has not addressed these issues. Instead they’ve changed the subject, speech after speech, and defined this resolution only with respect to violence. There’s a reason that in neither of our previous two speeches, did we talk about violence, I’ll talk about it a little bit here because they’re bringing it up. But they haven’t refuted any of our basic arguments about how human equality is not being met in the Muslim world. We’ve talked about it in two different ways, we’ve talked about equality in terms of freedom of religion, and we’ve talked about equality of gender and they’ve said not one word on it. Their last speech, I have to say, is a little late to do so. The reason this is important, is because we need to understand the severity of the problem. The reason we need to understand this, is because, if, in fact, the Muslim world is dominated by moderates and neo-progressives who are going to usher in a new era of prosperity and freedom, then there’s not much that we in the West need to do about it. But if on the other hand, radicals are ascendant, then we need to play a bigger role, and we need to put greater emphasis on this corner of the world. So the way we think about it fundamentally matters, and it matters to those who are suffering under totalitarian systems. Now, look at the key areas of the debate. Look at freedom of religion. This is something that affects people. In 14 Muslim countries, right now, it is illegal to change your religion, in eight of these countries, it is punishable by death. That is, you cannot convert out of Islam in these countries. That does not support equality between religions. This is supported also, by anti-proselytism laws, laws that prevent people from other faiths from propagating their own faiths, while at the same time Saudi money goes out throughout the entire globe, propagating a Wahabist version of Islam. This also is supported by anti-blasphemy laws. Laws that are used to suppress people who have a view of religion that does not conform with the very stringent view that a state might have. Now they have a couple of arguments here. One argument they made is polls. Now unfortunately, their argument about the polls which is trying to give you a broader view, only deals with violence. Well let’s talk about polling a little bit. One recent poll, by Policy Exchange that was undertaken in Britain back in 2006 shows that a shocking 36 percent of British Muslims between the ages of 16 and 24, said that someone who converts from Islam to another faith, should be punished by death. That’s within the West, you get a 36 percent support for this. Now, 36 percent obviously is not a majority. But what it shows, is the hegemony, as we framed it, of radicals, the fact that these ideas are seeping into the West, where people are familiar with Western customs, Western freedoms, and have had a chance to live in them. Now, the odd—but, and another thing about the polls incidentally, is they’re not necessarily as benign as the other side makes them out to be. For example, a recent poll conducted by Pew found that 15 percent of Indonesians support—believe that violence in defense of Islam is justified. Well 15 percent isn’t a whole lot. But when you look at Indonesia which is the world’s most populous Muslim country, you’re talking about 25 million people. I find that number to be a bit disturbing. And it’s out of line with what you’d find comparably Christians saying, in terms of whether defense of their faith is justified, whether violence is justified, in terms of defense of Christianity. Now, that is relevant to assessing whether this resolution is correct. Now, moving on to other arguments that they made, Edina says, don’t look at pockets, people define the faith. Well that’s non- responsive, because from the very first speech onward, we have said, that the majority of Muslims do not support radicalism. Rather, it’s that radicals enjoy hegemony, via institutions, via the propagation of the faith. And Edina actually gives up the game in her speech, because she concedes that Saudi Arabia is radical. Remember, folks, we’re not talking about Al Qaeda here. The question is not whether Muslims support Al Qaeda, it’s not whether Al Qaeda has hegemony, it’s radicals. And Saudi Arabia today, is the biggest country in terms of propagating a view of Islam. And one reason that Reza, uh, feared that I might talk about my view from the trenches, is that in a previous incarnation before I was in counterterrorism, I was working for a Saudi Arabian charity and actually got somewhat radicalized by them, it’s in—in a book that you can read somewhere or other. But the point is that, I’ve seen Saudi propaganda from the inside. And Saudi propaganda does take root. If you look at countries— and this is something that Paul talked about in the very first speech. If you look at countries from Bosnia to Indonesia to Somalia, countries that for a long time had a very moderate practice of Islam. As Saudi money has gone in there, and as you’ve had these institutions, these mosques, these charitable organizations, the practice of Islam has fundamentally shifted. Things are not gonna get better on their own. Because, look at the price of oil. Saudi Arabia is the world’s biggest exporter of oil, in addition to the being the world’s biggest exporter of radical ideology. And the price of oil is skyrocketing. Over $100 a barrel, you have Hugo Chavez and others talking about how it should be $200 a barrel. That’s not unrealistic. And with this power, with this oil money, you’ll see these radical ideas continue to take shape. Saudi Arabia is a powerful country. In conceding that Saudi Arabia is radical, they fundamentally concede that this debate is not about Al Qaeda. It’s about the radical institutions. And those radical institutions are indeed taking foot. She says look at the Muslim scholars. She says that they affirm freedom of expression, and condemned the riots over the Danish cartoons. But look at what the Organization of the Islamic Conference did, the OIC. In response to the Danish cartoons, they—

—pushed for a ban in the UN. They said that there should be a new law to prevent cartoons like that coming up ever again. These are cartoons that were published in the West. And the Islamic countries believe that it’s their right to make sure that the West alters its precept of free speech, to conform with norms that would be more suitable. That is why we’re saying, that radicals have hegemonic power, and that’s why you should vote for this resolution.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —pushed for a ban in the UN. They said that there should be a new law to prevent cartoons like that coming up ever again. These are cartoons that were published in the West. And the Islamic countries believe that it’s their right to make sure that the West alters its precept of free speech, to conform with norms that would be more suitable. That is why we’re saying, that radicals have hegemonic power, and that’s why you should vote for this resolution.

### Moderator
Claim: Thank you, Daveed Gartenstein-Ross, for that opening statement in support of the motion and now speaking against the motion, “Islam is dominated by radicals,” Richard Bulliet.

### Scientific Advocate (SA)
Claim: Good evening. I think we can agree with most of what our opponents have said. Just not with the proposition. We can agree that Saudi Arabia is not a place that most of us would particularly want to live. Saudis like to live there. But they have a version of Islam, that is repugnant to many Americans, we can agree with that. We can agree that, Saudi Arabia, both privately and publicly, puts a lot of money into trying to spread their version of Islam, this is what Mr. Marshall referred to as striving for a political order that represents a reactionary version of Islam—yes. Saudis are trying to do that. There are some other groups, around the world who are trying to do that. And some of them get money from the Saudis. We’re not going to deny that. We’re not going to deny that women in many Muslim countries face what Asra said was an unacceptable situation. Yeah, they do. Many others don’t, but many do. Nor are we going to claim that religious equality or enjoyment of human rights as we understand them in this country are universal in the Muslim world. We’re not going to complain—to…raise an issue on any of this. But that is what the proposition is. Proposition is, the radicals dominate Islam. Now we’ve heard other words like, hegemony. After all, as Daveed just said, 36 percent of British Muslims think that apostasy deserves death, and that’s hegemony—well, not by my count. 36 percent is 36 percent. You want a majority if you want hegemony. The fact that in Britain, virtually all of the Muslims come from one particular, rather benighted part of Pakistan—and do not in any way, by any measure, represent a cross-section of the Muslim world— should also be taken into account. See, the problem is, and let me go back to Mr. Rosenkranz’s very opening remarks. He was talking about numbers that showed that in Muslim countries around the world you have a lot of people who are anti-American. We do, yeah. Well, you know…that I don’t think is un-understandable. But the question is whether that has anything to do with Islam. Or whether that is objecting to American policies. Now, if you want to say that anyone who objects to US government actions is by definition a radical, well then maybe you get somewhere but even then I don’t think so because, what has not been talked about here, is the fact that most of the countries in the Muslim world, are not governed by Muslim regimes. They’re governed by autocratic dictatorships. Most of the political activity of Muslims, that gives rise to strong political statements has to do with opposing living under totalitarianism. Most of the people in the Muslim world, have not, nor did their parents, nor will their grandchildren in all likelihood, had any opportunity, to participate in or choose the government under what they live. Now, the fact of the matter is, that when they object to autocratic rule, two things happen. One is, that they fall back on their religious faith, and say, well, Islam can help us against this autocracy, the second one is, they say, who is supporting the dictatorships that we live in. Lo and behold, say it’s the United States. So that when you have Muslims objecting to US policies, it’s more frequently that they are objecting to the support the United States gives to autocratic rule, whether it is in Egypt, or in Saudi Arabia, or in Pakistan. This is the crux of the matter in the Muslim world. You don’t have…most Muslims in the Muslim world are not sitting there trying to decide whether they want a Saudi, conservative, Puritanical version of Islam, or whether they want, you know, Reza Aslan to be the Muslim pope, I mean this is not— This is not where the debate is, it isn’t about what Islam is like.

Good debate, yeah. What it’s about, is a billion people, two-thirds of whom do not live in democratic systems, and who are looking to their tradition and their faith tradition, to try to work for a better life, and a more participatory role, in the polities that they live in. And they find that, Islam is satisfying to them as a political option. It isn’t the option that most of us would choose but we do know that in this country, we do have many Americans, who feel that religion is part of their political life. Unless I miss my guess, this accounts for a big chunk of the Republican party. But we sort of say, well, okay, here in New York we don’t particularly like to talk about those people, but—

—nevertheless, the fact of the matter is that these people find satisfaction in their turn to religion as an effort to stand up against autocracy, and they find that the American support for autocrats is reprehensible. And they discover that in the American way of things there will be enormous publicity given to anything negative about Islam, not just by the American press, but because the various autocrats will feed the American government and the American press negative things because they’re trying to protect the privileged position that they have set up over the last 50 years of totalitarian rule. And therefore I would say that, if there’s anything that’s dominating in the Muslim world, not dominating in Islam but dominating in the Muslim world, it’s dictatorship. Not radical Muslims.

### Conspiracy Advocate (CA)
Claim: Good debate though.

### Scientific Advocate (SA)
Claim: Good debate, yeah. What it’s about, is a billion people, two-thirds of whom do not live in democratic systems, and who are looking to their tradition and their faith tradition, to try to work for a better life, and a more participatory role, in the polities that they live in. And they find that, Islam is satisfying to them as a political option. It isn’t the option that most of us would choose but we do know that in this country, we do have many Americans, who feel that religion is part of their political life. Unless I miss my guess, this accounts for a big chunk of the Republican party. But we sort of say, well, okay, here in New York we don’t particularly like to talk about those people, but—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: —nevertheless, the fact of the matter is that these people find satisfaction in their turn to religion as an effort to stand up against autocracy, and they find that the American support for autocrats is reprehensible. And they discover that in the American way of things there will be enormous publicity given to anything negative about Islam, not just by the American press, but because the various autocrats will feed the American government and the American press negative things because they’re trying to protect the privileged position that they have set up over the last 50 years of totalitarian rule. And therefore I would say that, if there’s anything that’s dominating in the Muslim world, not dominating in Islam but dominating in the Muslim world, it’s dictatorship. Not radical Muslims.

## Round 2

### Moderator
Claim: Richard Bulliet, thank you very much for your opening statement. Before the panelists put questions to one another I have a couple of questions, and first, Richard Bulliet. Would you agree or disagree with the statement that Muslim clergy worldwide is dominated by people who would want to see Islamic law imposed in their societies and would prefer to live in a society under Islamic law, do you think it’s true or false or no way of knowing.

### Scientific Advocate (SA)
Claim: Oh, I think that’s false, I held a conference a number of years ago, exclusively devoted to Muslim political activists, held it in Iman, Jordan. And one of the issues that we were supposed to discuss was the idea of an Islamic republic. There wasn’t a single person there.

### Conspiracy Advocate (CA)
Claim: They were Muslim political activists—?

### Scientific Advocate (SA)
Claim: Yes they were, they were from the Muslim Brotherhood, they were from the Dawa party, they’re from the SCIRI party. They were from a whole series of Muslim political parties in the Middle East.

### Conspiracy Advocate (CA)
Claim: Mm-hmm.

### Scientific Advocate (SA)
Claim: And none of them supported the idea of an Islamic republic.

### Conspiracy Advocate (CA)
Claim: Hmm.

### Conspiracy Advocate (CA)
Claim: And you believe that from a group whose message was the Koran is our Constitution—

### Moderator
Claim: Daveed Gartenstein-Ross.

### Conspiracy Advocate (CA)
Claim: I mean, the Muslim Brotherhood is very clear on what their goals are. Hassan al-Banna, talked about this,

### Scientific Advocate (SA)
Claim: It was in the 1930s—

### Conspiracy Advocate (CA)
Claim: —Islamic state, and—

### Scientific Advocate (SA)
Claim: Yes, but—

### Conspiracy Advocate (CA)
Claim: —their motto remains, the Koran is our Constitution—

### Scientific Advocate (SA)
Claim: You’re mistaking the 1930s or the 1950s with the Muslim Brotherhood today—

### Conspiracy Advocate (CA)
Claim: Okay, Mohammed

### Scientific Advocate (SA)
Claim: —talks about pluralism primarily.

### Moderator
Claim: I have a question for Daveed Gartenstein-Ross, before—you’ll goad each other in just a moment here and I’ll—

### Conspiracy Advocate (CA)
Claim: Okay—

### Moderator
Claim: Okay, Daveed Gartenstein-Ross, you seem to cite as evidence of the fact that Muslims are dominated by radicals, the desire to see restrictions in Europe on freedom of speech that included cartoons that Muslims deemed blasphemous. In Europe, in Britain for that matter, there are laws that restrict incitement to race hate, which we find a violation of our First Amendment, do you believe that laws that ban punishment of racist or anti- Semitic or anti-Islamist images or literature—that to support such laws is a mark of an extremist, or in the context of Europe, is it a part of the way in which the law has developed there that has not created fascist societies in France, Italy and Britain recently—

### Conspiracy Advocate (CA)
Claim: Well, you have to parse some of those laws, I mean there’s the racial incitement laws which is one thing, and I don’t have a problem with racial incitement laws. Then there’s vilification laws. Vilification laws are adopted in some countries, France and Italy are examples. Most countries in Europe do not have it, including Britain. I do think—in terms of those, it’s debatable as to why a country would have it, whether it’s evidence of radicalism. But I think saying that every country in the world should adopt a certain law to limit speech in the case of religion, is evidence of radicalism—

### Moderator
Claim: But if a religious movement pressed for universal laws that would ban degrading images or comments about their faith, would you take that as per se a mark of extremism on behalf of that faith—

### Conspiracy Advocate (CA)
Claim: Not—not per se a mark of extremism, I agree with that but I think that contextually I would define it as such, it looks like Paul has something he wants to—

### Moderator
Claim: Paul Marshall, you have something to add—

### Conspiracy Advocate (CA)
Claim: Yeah, depends what the government is, you have through the Organization of Islamic Confernce an effort going on, since about 1999, to repress through the international system, to repress speech it says is critical of Islam, or blasphemous. Pakistan has been big on this, Iran has been big on this, the Saudis have been big on this. Remember, example, brief example I gave before is Saudi democracy activists are accused of blasphemy. In Iran, Akbar Gangi, the major dissident, was accused of insulting Islam. Domestically these repressive regimes use charges of blasphemy to squelch the opposition, basically they say, we represent Islam, you criticize us, you criticize Islam, you’re a blasphemer. When these regimes try to pushy this into the international sphere I think it should be strongly opposed.

### Scientific Advocate (SA)
Claim: But when you have autocratic regimes—

### Moderator
Claim: And Richard Bulliet—

### Scientific Advocate (SA)
Claim: —that ban parties that use religion and so forth, you don’t object to that. The Egyptians will not allow a religious party, the Turks, you know, through constitutional court, they’re now trying to ban the governing party there, I mean…

### Conspiracy Advocate (CA)
Claim: I don’t like that either—

### Scientific Advocate (SA)
Claim: A governing—a governing party by the way which calls itself Islamist and yet, has brought seven years of unprecedented economic growth, has brought Turkey closer to the United States and Israel than it’s ever been before, has given more freedoms and rights to minorities, and ethnic minorities than it has ever been before, but— They want to say that it’s okay if you’re a woman, and you want to go to college, you can put a scarf over your head, and, because of that, they’re seen as anti-democratic, as violating secularism, as, you know, again this awful world Islamist. So, you know, it’s not so easy to just kind of tag the Muslim Brotherhood or the AKP as though the Muslim Brotherhood by the way is one entity. According to something that was written in the 1930s, you know, by Hassan al-Banna—

### Conspiracy Advocate (CA)
Claim: Well, I’ll quote the current guardian if you want.

### Scientific Advocate (SA)
Claim: You can—

### Moderator
Claim: Well, we can quote them as we go on through the evening. We can quote all of the Muslim Brethren before we’re done, but now, I’m sure you’ve all been wondering what the person next to you really thinks about all this. And now you’ll learn because I’m ready to announce the results of the pre- debate vote. Before you were moved by the speakers, you were asked your opinion of the motion, “Islam is dominated by radicals.” 46 percent voted for the motion, 32 percent against, and 22 percent were undecided. Now we’re going to continue with the discussion section of the evening. I’m going to ask each of you if you have a question for an individual on the other side. And again, we’d like to hear a question put to the person on the other side and first I’m going to ask Paul Marshall, do you have a question for one of your adversaries here.

### Conspiracy Advocate (CA)
Claim: Yes, Professor Bulliet. In arguing, you opposed our use of the word “hegemony,” and said when, say, 30 percent or so of British Muslim youth want to kill someone who rejects Islam, or believes they should be killed, you said that’s not a majority, hegemony equals majority. But, would you not agree that in the regimes we’re talking about, if one is talking about Egypt, or Saudi Arabia, or a vast number of other countries, the majority of the people may oppose something. But surely you would agree that currently the Saudi Arabian government is hegemonic, the Iranian government is hegemonic in terms of what shapes that country.

### Scientific Advocate (SA)
Claim: Oh, I agree—

### Moderator
Claim: Richard Bulliet.

### Scientific Advocate (SA)
Claim: Yes, I mean—

### Conspiracy Advocate (CA)
Claim: No, just stop there—

### Scientific Advocate (SA)
Claim: The British— The British government isn’t, however, in that category. If you are going to say that the government in any autocratic state, whether it is Saudi Arabia, or Iran or Egypt, or Tunisia, or any of the other myriad autocratic states where the government calls the shots, yes. The government does call the shots and therefore you could say that the government has a dominating or hegemonic role but if you want to go down that route, then you find that most Muslims in the world aren’t living in those states that you’re worried about. They’re living in states that are governed by nationalists, secular, or self-proclaimed secular autocracies, so, you know, you can’t just single out Saudi Arabia and Iran, and say, this is the whole of the law and the prophets—it just doesn’t work that way.

### Moderator
Claim: Question asked and answered, Reza Aslan, do you have a question for the other side, someone on the other side.

### Scientific Advocate (SA)
Claim: Yes, I’ll ask this question of Daveed. I want to remind Daveed first of all that, according to Freedom’s House definition of democracies, the United States wasn’t a democracy until 1960. But in that regard, Rice University two years ago did the most comprehensive study of American religiosity ever done. And in that study they found that not only do a third of Americans, one out of three refer to themselves as evangelical Christians, but 46 percent, that’s almost half of American Christians, believe that the Constitution and American laws should be changed in order to match Christian law and Christian values, so—

### Moderator
Claim: Your question.

### Scientific Advocate (SA)
Claim: —I imagine your response would be— No, do you or do you not then believe that America is under the “hegemony”…of evangelical Christians. So therefore we are dominated by radicals, correct?

### Conspiracy Advocate (CA)
Claim: Well—

### Moderator
Claim: Daveed Gartenstein-Ross.

### Conspiracy Advocate (CA)
Claim: —that would be a very relevant and interesting question if this were a different resolution. In the end the resolution isn’t whether the US is dominated by radicals or not. Now—

### Scientific Advocate (SA)
Claim: No, I’m just curious about your answer—

### Moderator
Claim: Only get one question, yes—

### Conspiracy Advocate (CA)
Claim: I mean, looking at the specifics of it, it was 46 percent of 23 percent, I think, I don’t know, that seems to be about, 11 and a half percent, my math could be a little bit off, you kind of went on for a little while there. But what I will say is evidence of hegemony, is when—

### Scientific Advocate (SA)
Claim: No, no, 46 percent of 300 million, not—

### Conspiracy Advocate (CA)
Claim: 46 percent—

### Scientific Advocate (SA)
Claim: —46 percent of 100—

### Conspiracy Advocate (CA)
Claim: —of 300 million think that—well, I’d have to see the study, and one thing that I can say is that I think that in the evangelical community, which I’m a part of, there’s a lot of push-back against— I mean you were, you’re going on and on about the AKP, and I actually agree with you on the AKP, I don’t think they should be banned. But there’s a— there’s disagreement here but, I don’t think they should be banned—

### Conspiracy Advocate (CA)
Claim: No, no, no, I just like Turkey.

### Conspiracy Advocate (CA)
Claim: Okay—

### Moderator
Claim: The AKP is the Turkish—

### Conspiracy Advocate (CA)
Claim: The AKP is just—

### Moderator
Claim: —Islamist Party—

### Conspiracy Advocate (CA)
Claim: But, with respect to the United States, within the evangelical community there’s a lot of push-back against religion simply being pushed out of the sphere, the public sphere, 100 percent, that’s the way the First Amendment has been interpreted for some time. And I would say that some of the disturbing poll results are not evidence of radicalism but instead, this push- back—

### Scientific Advocate (SA)
Claim: So it’s not hegemony—

### Moderator
Claim: The question—the question is answered—

### Scientific Advocate (SA)
Claim: Actually it wasn’t.

### Moderator
Claim: And—well, it’s,—

### Conspiracy Advocate (CA)
Claim: Actually it was, Reza, but I appreciate your—

### Scientific Advocate (SA)
Claim: It is a sign of hegemony or it is not a sign of hegemony.

### Conspiracy Advocate (CA)
Claim: Um—

### Scientific Advocate (SA)
Claim: 46 percent wanting to—

### Conspiracy Advocate (CA)
Claim: Well actually I answered it—

### Scientific Advocate (SA)
Claim: —to enforce Christianity—

### Conspiracy Advocate (CA)
Claim: which is that the question is not relevant. And I don’t know what way they’d wanna do it, I haven’t seen the poll results, I can’t judge.

### Moderator
Claim: Thank you, Daveed Gartenstein-Ross. A question now, Asra Nomani, you can put a question to one of the opponents of the motion.

### Conspiracy Advocate (CA)
Claim: Well, Edina said earlier that to suggest that radicals dominate--as is our proposition there--Islam is like saying that murderers define America. So, 22 countries are the number of countries that declare that Islam is the state religion. Of those, 14 say that conversion of Islam is illegal. The good professor suggested that in fact we are correct that, Islamic law in Saudi Arabia and all of these other countries suggest inequity. So my question to you, thank you—

### Moderator
Claim: Good point.

### Conspiracy Advocate (CA)
Claim: —is…the laws are defined by ideology that— represents inequity. Most of the countries are governed by Islamic states, in the name of Islam. How do you then argue that, there—the excuse is autocracies, that the equivalent is as if murderers were running America.

### Scientific Advocate (SA)
Claim: These countries are not the—the leadership does not even proclaim to be running the country in the name of Islam. Again—

### Conspiracy Advocate (CA)
Claim: Well, they have Islam as their state religion—

### Scientific Advocate (SA)
Claim: If I can answer—

### Conspiracy Advocate (CA)
Claim: —under Islamic law.

### Moderator
Claim: You’ve asked the question. The answer?

### Scientific Advocate (SA)
Claim: The Islamic law has been on the books for a period of time in these countries. The leaders who are coming into the leadership, are dictators who are following upon the heels of dictators, and who are supported by international forces. The fact that these laws exist on the books, are indeed still problematic. No one on our side is denying any of that, these realities certainly exist on the ground. However, we have to look at where they are enforced and when they are enforced. Because even where Islamic law— and we try to take Sharia and turn it into, as if it’s “the” Sharia, that it’s a one-size-fits-all Sharia that exists in all of these countries, nothing could be further from the proof. There is different shapes and sizes and flavors of Sharia that exist in these different countries. So we cannot pretend that they are all the same. So, in these situations, in some of these countries, even those rules around apostasy have long been unenforced. We have to look at where this rise has come from. And a lot of it, in my mind, is a very reactionary action that has taken place. And again, in no way defines what is taking place on the ground with the people, I do not know why we are once again, over and over again denying the realities of the people on the groined who make up the dominant force within Islam.

### Conspiracy Advocate (CA)
Claim: Because this is not a homecoming queen contest.

### Scientific Advocate (SA)
Claim: And no one said it was.

### Moderator
Claim: Edina Lekovic, it’s your turn to put a question to any of the three supporters, movers of the motion.

### Scientific Advocate (SA)
Claim: Well, my question is for Paul Marshall. Last week, General Petraeus testified before Congress and said that the Iraqi people are turning on Al Qaeda, and that they are fighting them, and that this is resulting in a reduced presence of Al Qaeda in Iraq. And that this is a—and we see this as a rare glimpse of success in our war policy. And pundits, and scholars, including journalists who have been on the ground, in some of the very countries that we are talking about, have also said that these— Al Qaeda being the prime example, but other radical groups on the ground, that their influence is also declining. Do you dispute that fact.

### Conspiracy Advocate (CA)
Claim: Okay. Just one quick comment, Edina, you are being very unfair. As you know, I was on my honeymoon last week, and did not pay too much atten—

### Scientific Advocate (SA)
Claim: I’m very jealous—

### Conspiracy Advocate (CA)
Claim: …the only person who didn’t pay too much attention to what General Petraeus said. But the… I would be, I wouldn’t have enough knowledge of on the ground in Iraq to dispute that. But it may well be the case that sort of more radical forces, not just the Al Qaeda types, but the Mahdi army and these other groups, that the Iraqis are sort of getting fed up with them and resisting them. This may well be the case. And, obviously, I would regard that, I think most of us would regard that as a good thing. But it would not, for me, make a difference in terms of my overall view of dominant trends in the Muslim world, in Africa, Asia—south Asia, southeast Asia and so forth.

### Moderator
Claim: A question now, from Daveed Gartenstein-Ross for one of the opponents of the resolution.

### Conspiracy Advocate (CA)
Claim: All right, I’m going to ask it to Reza since we seem to be the two boxers of the bunch. And it will—my question will not go on and on and on, rather, it’s—

### Scientific Advocate (SA)
Claim: And I’ll—

### Conspiracy Advocate (CA)
Claim: —somewhat to the point—

### Scientific Advocate (SA)
Claim: And I’ll actually answer it.

### Conspiracy Advocate (CA)
Claim: Touché—

### Moderator
Claim: You both set a very high standard for this event—

### Scientific Advocate (SA)
Claim: It’s really impressive.

### Conspiracy Advocate (CA)
Claim: So, I’m interested actually in your answer. You talked about the polls on violence during your first speech. My question is, first of all do you still find the raw numbers disturbing, I talked a bit about the Pew study on Indonesia, 15 percent equates to 25 million people who support violence in the name of the religion. And then second, do you find it disturbing, regardless of whether they name religion as one of their motivating factors for it, which was one of the points that you made as well.

### Scientific Advocate (SA)
Claim: Actually what you said was 15 percent of Indonesians would resort to violence in defense of their religion, I can’t believe it’s as little as 15 percent. I would be shocked if it were less than 50 percent. Religion in every culture including ours, is not just beliefs and practices, it’s identity. And if someone were coming to my country to attack me, attack my identity, you’re damn right, I would resort to violence to deflect that attack. Now, you made the point that, we would assume that, ask a bunch of American Christians that same question and of course it—the number would be much less than 15 percent. I think you’re right. However, let’s ask a bunch of Christians—

### Conspiracy Advocate (CA)
Claim: But, pugilistically, when Andres Serrano’s—

### Scientific Advocate (SA)
Claim: Why don’t we—

### Conspiracy Advocate (CA)
Claim: —Piss Christ came out, Christians weren’t rioting on the streets. Whereas with the Danish cartoons you had over 100 people killed throughout the world.

### Scientific Advocate (SA)
Claim: Yeah, actually Nigerian Christians were massacring with machetes Muslims, just as Muslims were massacring Christians. But let me just say, it may be right that, you’re not going to get similar numbers of Christians if you ask let’s say Americans, but ask that question of Guatemalans. Ask that question of people in San Salvador. And I think you’re going to get a different answer. Religion is who you are, if who you are is under attack, you fight back, period, whether you’re a Christian, or whether you’re a Muslim. The reason that we—there are so few Americans who feel that way is— I mean saying that my religion is under attack because I can’t pray in my classroom, is not being under attack.

### Conspiracy Advocate (CA)
Claim: As opposed to there being cartoons ridiculing your religion?

### Scientific Advocate (SA)
Claim: Yeah, as a matter of fact, yeah, as that’s—

### Conspiracy Advocate (CA)
Claim: As a—oh, as a matter of fact, so you do think that it’s okay to riot in response to, you think that that’s okay—

### Scientific Advocate (SA)
Claim: I think it’s perfectly okay to protest those cartoons.

### Conspiracy Advocate (CA)
Claim: And to kill people?

### Scientific Advocate (SA)
Claim: No, but that’s—

### Conspiracy Advocate (CA)
Claim: Over 100 people died.

### Scientific Advocate (SA)
Claim: No, no, no, but that’s different, what you’re saying is, should I act in defense of my religion—

### Conspiracy Advocate (CA)
Claim: Clearly, to commit acts of violence, it’s not act in defense of religion—

### Scientific Advocate (SA)
Claim: Should I act—should I act violently—

### Conspiracy Advocate (CA)
Claim: It’s commit acts of violence, that’s what the survey said—

### Scientific Advocate (SA)
Claim: Should I act violently in defense of my religion, absolutely. If the—if what that means is, that it’s my identity, that people are on the ground attacking me—

### Conspiracy Advocate (CA)
Claim: And this goes to show why Islam is dominated by radicals—

### Scientific Advocate (SA)
Claim: It’s sort of— No. It’s a very…

### Conspiracy Advocate (CA)
Claim: No, no.

### Scientific Advocate (SA)
Claim: It’s just, it’s a—

### Conspiracy Advocate (CA)
Claim: Sorry, dude, I got the last applause line.

### Scientific Advocate (SA)
Claim: It’s a very superficial and unsophisticated view of religion to think that what we’re talking about here is if someone is offended by something about their religion—

### Conspiracy Advocate (CA)
Claim: So the people—

### Scientific Advocate (SA)
Claim: —then they’ll react with violence—

### Conspiracy Advocate (CA)
Claim: —who died should yield to the fact that—

### Scientific Advocate (SA)
Claim: When people act—

### Conspiracy Advocate (CA)
Claim: —they’re unsophisticated—

### Scientific Advocate (SA)
Claim: When people are acting—

### Conspiracy Advocate (CA)
Claim: —in their knowledge that they died.

### Scientific Advocate (SA)
Claim: When people are asked, would you resort to violence to defend your religion, I guarantee you that the people in Indonesia who answered that question, were not talking about being offended, they were talking about actually defending their lives and livelihood which by the way is a very real thing, when you see the war on terror being understood—

### Conspiracy Advocate (CA)
Claim: It’s also very real in Indonesia—

### Scientific Advocate (SA)
Claim: —not just in the Muslim world—

### Conspiracy Advocate (CA)
Claim: —four islands to be directed

### Moderator
Claim: One last

### Scientific Advocate (SA)
Claim: —as an attack on Islam, this isn’t just Egyptians or Jordanians or Iraqis who think this. These are British non-Muslims who think this. Around the world, the majority view is that the war on Islam is a war against Muslim identity, it’s a—

### Moderator
Claim: War on terror—

### Scientific Advocate (SA)
Claim: It’s—I mean I’m sorry, the war on terror, is a war against Muslim identity, this is a—

### Moderator
Claim: On that note—

### Scientific Advocate (SA)
Claim: —very real issue.

### Moderator
Claim: I think—

### Scientific Advocate (SA)
Claim: So if I’m asked…are you—would you react if someone were to violate your beliefs, in defense of your beliefs—

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: —then we’re not talking about being offended.

### Moderator
Claim: But Reza, you were asked—

### Conspiracy Advocate (CA)
Claim: That’s not what we’re talking about—

### Moderator
Claim: —and you’ve answered the question. And we have one last question from a panelist for the other side from Richard Bulliet.

### Scientific Advocate (SA)
Claim: Yeah, I’ll—I think we’ve gotten too serious, we’ll move on to some whimsy. So this is for Daveed. You finished your, your talk with, what struck me as an absolute absurdity, namely that the price of oil is somewhat equatable to the dominance of radical Islam. And it made me think, gee… if we can only solve our energy problem, will radical Islam go away? Because, you’re making a remark— The only person who has ever really pursued this in print was Dan Pipes in his first book, saying that, radical Islam is purely a product of oil prices—I think it’s an absurdity.

### Conspiracy Advocate (CA)
Claim: Well, it—well, okay, the way you frame it it is, but that’s not what I said. What I said, going off Edina’s remarks that Saudi Arabia is radical, is I talked about how the fact—how I used to work for a Saudi charity that did propagate radical material. So I’ve seen this firsthand, and can say that Saudi charity, Saudi institutions, Saudi imams, make a difference throughout the world. And the reason why they’re so widespread, is indeed because Saudi Arabia has a lot of money to spend, due to its oil revenues. The point I was making was simply that oil revenues aren’t going to dry up any time soon. Rather, the price of oil is skyrocketing. And as a result, these institutions are out there, far more than they were before. That goes to the point of hegemony. That goes to who has the power—

### Scientific Advocate (SA)
Claim: Oh, that—but let’s—

### Conspiracy Advocate (CA)
Claim: —who has the money, who’s installing the imams. And indeed—

### Scientific Advocate (SA)
Claim: That goes to the point—

### Scientific Advocate (SA)
Claim: —of whether the Saudis are trying to export—

### Scientific Advocate (SA)
Claim: —their form of religion. And we’re perfectly willing to grant, the Saudis are trying to export it, but you haven’t demonstrated that the efforts the Saudis are making, are actually succeeding. All you’ve done is saying that they’re doing it—

### Conspiracy Advocate (CA)
Claim: Okay, but we actually talked about that, Paul talked about that in the very first speech. Where he talked about the changes in Islam, in places like Indonesia, in the Balkans, in Somalia, look at Somalia. Where you have a war wracking the country, where the group formerly known as the Islamic Courts Union, now known as the Alliance for Reliberation of Somalia, managed to conquer the country, impose Islamic law in which people were arrested for watching Pretty in Pink, in which a karate instructor who had female students was arrested, where people were arrested for watching the World Cup. That stuff was unheard of in Somalia 30 years ago. And now—and today, that is the reality on the ground. So I can say for a fact, that yes, this oil money and this dawa, is making a difference, and it’s making a difference in the way that affects people’s lives.

### Moderator
Claim: Okay. You’re probably wanting to get in on this conversation— And now you can join in this civil discourse on the question of whether Islam is dominated by radicals. We have microphones out in the audience, and if you’d like to raise your hand, the people bearing the microphones will find you. I’d like you to please not start to ask a question until we do have a microphone in front of you, and make your questions short and to the point. And if you are member of the press, please identify yourself as such. I’m a little bit blinded by the light, so I’m trying to see— Up in the left, yes, question—

### Moderator
Claim: My name is James Taranto and I am a member of the press—

### Moderator
Claim: Good—

### Moderator
Claim: —I’m with The Wall Street Journal. I—this question is for any or all on the side for the motion. Has the—to what extent has—or on the whole let’s say, has, have the political changes in Iraq over the past five years strengthened or weakened the domination of Islam by radicals.

### Conspiracy Advocate (CA)
Claim: In—

### Moderator
Claim: This is Daveed Gartenstein-Ross, you want to answer that?

### Conspiracy Advocate (CA)
Claim: Okay, sure. I think that the changes in Iraq have had both effects. On the one hand, I think the Iraq war has clearly been a rallying point for radicals, and whether that’s justifiable or unjustifiable is something that people can decide on their own. But clearly, it’s been a great recruiting ground for Al Qaeda and others. The flip-side of that is that, we had some discussion before of the anti-jihadist movements that are there, things like the Sakwa movement. And those have had a cognizably good impact. I think on the whole, uh, the fighting there is something that is energizing of radicals in the Muslim world without a question. And that’s not going to stop regardless of the Sakwa movement.

### Moderator
Claim: Where is our next question coming from, on the right.

### Moderator
Claim: First of all I think this has been addressed on, pretty much one level, “Islam is dominated by radicals” has a multitude of meanings. Not just political, and I was very moved at what Miss Nomani said, talking about the—how women were treated in this religion. And, I don’t know obviously, I’m not an expert on the Muslim religion, but I do know several women in New York who go to mosques and are placed in separate areas who cannot go out with a man or be seen with a man without a chaperone. And any union has to be…has to be validated by the head of the mosque.—

### Moderator
Claim: Question—

### Moderator
Claim: —I think, I think—and this, my question is to Edina. What do you think of the absolute bare-bones question of, as I say, microcosms grow into macrocosms, of bare-boned questions of human rights in that issue.

### Scientific Advocate (SA)
Claim: Bare-bones questions of human rights, well… Okay. When it comes to the issue of women in mosques, what we see— I can speak again anecdotally and I can speak empirically, it’s a matter of what the audience would like to hear. When it comes to anecdotal things, you said something about the union of marriages, in any church the union of two people must be sanctified by that, by that religious institution. On the question of chaperones, there is, it in many ways, is a product of culture than of religion. There is what has been practiced by my family for generations is what is then being practiced. I think this question of religion and culture and the weaving of the two, is one of the central questions that we face within the global Muslim community today. And the reality is that Islam looks and feels and tastes different, no matter where you go. Regardless of who is in power, because of the question of culture and of identity that we are considering here. Is there a very real—

### Moderator
Claim: Including on the subject—

### Scientific Advocate (SA)
Claim: Yeah, is there a very real—

### Moderator
Claim: —particularly about the women.

### Scientific Advocate (SA)
Claim: Is there a very real problem, when it comes to the treatment of women in mosques and in human rights issues, absolutely. Is it the dominant force for Muslim women and their lives? I would argue with that point. Because I, based again on my travels, on my experience, and on my interaction with the data that’s out there, there are just as many women who are, when they have an education, when they have access… And that’s, again, we have dividing lines, we can’t separate the question of human rights, when there is a lack of education, where there is poverty, where there are these surrounding issues, it is not simply a matter of, of, you know, of religious teachings. Because, there are, you have the Benazir Bhuttos. You have the women heads of state in Bangladesh and Pakistan and Indonesia and other places. You have Queen Noor of Jordan and Queen Rania, you have these other examples that exist out there, and they are just as much role models for Muslim women as are the problems that they are facing. These are both—these are two sides of the same reality, but absolutely, there’s a very real problem on the ground, and it’s one that is being faced by NGO’s, by civil society groups, and by women themselves on the ground. And that’s what I— that’s what I’m really trying to put the attention on here. Is that there is an active fight taking place on the ground. An active fight.

### Conspiracy Advocate (CA)
Claim: And there has to be a fight because— There has to be a fight, I want to just make the point again—

### Moderator
Claim: Asra Nomani—

### Conspiracy Advocate (CA)
Claim: —there has to be a fight because the leadership is dominated by radicalism.

### Scientific Advocate (SA)
Claim: And by patriarchy—

### Conspiracy Advocate (CA)
Claim: In— yes, patriarchy is a form of radicalism if you ask me—

### Scientific Advocate (SA)
Claim: As it is in other parts of the—

### Conspiracy Advocate (CA)
Claim: Sure, but—

### Scientific Advocate (SA)
Claim: —non-Muslim world—

### Conspiracy Advocate (CA)
Claim: Right, but unfortunately, our society, our Muslim society is defined right now by a patriarchy that, the Christian and Jewish societies have evolved beyond.

### Scientific Advocate (SA)
Claim: You’re confused—

### Conspiracy Advocate (CA)
Claim: Oh, I’m sorry. I’m sorry, I didn’t just get censored in Dubai because I wanted to talk about women’s rights. Oh, I’m sorry, the mosque up the street didn’t tell me that I couldn’t pray in the main hall, because that’s not what a woman’s supposed to do. Oh, I’m sorry, those men that surrounded me—

### Scientific Advocate (SA)
Claim: Orthodox synagogues—

### Conspiracy Advocate (CA)
Claim: Excuse me—

### Moderator
Claim: Reza—

### Conspiracy Advocate (CA)
Claim: —orthodox synagogues are a portion—

### Scientific Advocate (SA)
Claim: Catholic churches—

### Conspiracy Advocate (CA)
Claim: Excuse me—

### Scientific Advocate (SA)
Claim: —women can’t become priests—

### Conspiracy Advocate (CA)
Claim: They’re a portion of—

### Scientific Advocate (SA)
Claim: —they can’t serve, you know—

### Conspiracy Advocate (CA)
Claim: They’re a portion of the Jewish community but the end of the day—

### Scientific Advocate (SA)
Claim: Absolutely, patriarchy’s—

### Conspiracy Advocate (CA)
Claim: —orthodox—

### Scientific Advocate (SA)
Claim: —everywhere.

### Conspiracy Advocate (CA)
Claim: —orthodox ideology is what defines our communities. Two out of three mosques in America do not even allow a woman on the board. That is a statistic—

### Scientific Advocate (SA)
Claim: But, from where—

### Conspiracy Advocate (CA)
Claim: —that is—

### Scientific Advocate (SA)
Claim: Whose statistic is that, it’s very—

### Conspiracy Advocate (CA)
Claim: That’s the Council—

### Scientific Advocate (SA)
Claim: —easy to throw these things out there—

### Conspiracy Advocate (CA)
Claim: —Council on American-Islamic Relations who are, consider themselves the NAACP of the Muslim world fighting for women’s rights. I mean this is the reality. We can talk politics, we can talk all sorts of, you know, dictatorships, ultimately, we’re dealing with bullies in the community who want to push their radical ideology—

### Moderator
Claim: Asra Nomani, but it would be—one could infer from what you’ve said that, a hundred—at the start of the last century that all of Western civilization was dominated by extremists.

### Conspiracy Advocate (CA)
Claim: And have we not gotten at least some movement where we have churches now, where we have women as priests. Where we have Catholic women who are—

### Scientific Advocate (SA)
Claim: And they’re still fighting—

### Conspiracy Advocate (CA)
Claim: —fighting for the right to—

### Scientific Advocate (SA)
Claim: They are fighting—

### Scientific Advocate (SA)
Claim: We have mosques where women are imams, so—

### Conspiracy Advocate (CA)
Claim: Oh, really.

### Scientific Advocate (SA)
Claim: Very small percentage—

### Conspiracy Advocate (CA)
Claim: I’d love to go to them, in China, in some rural areas, oh, I’ll take a trip there but, I don’t think—

### Scientific Advocate (SA)
Claim: Oh, no, in the United States—

### Conspiracy Advocate (CA)
Claim: Oh, really, Reza, tell me where I could go—

### Scientific Advocate (SA)
Claim: Absolutely, there’s a Zaytuna Institute, the only seminar—

### Conspiracy Advocate (CA)
Claim: Right—

### Scientific Advocate (SA)
Claim: —in the United States—

### Conspiracy Advocate (CA)
Claim: Right—

### Scientific Advocate (SA)
Claim: —trains as many women—

### Conspiracy Advocate (CA)
Claim: Right—

### Scientific Advocate (SA)
Claim: —imams as—

### Conspiracy Advocate (CA)
Claim: Women imams to teach—

### Scientific Advocate (SA)
Claim: —as it trains male imams—

### Conspiracy Advocate (CA)
Claim: —the women. You know, because they’re acceptable for the sisters, but at the end of the day, they’re not good enough for the men—

### Moderator
Claim: Another que—

### Conspiracy Advocate (CA)
Claim: And that to me is unacceptable.

### Moderator
Claim: Another question from the audience. Here, sir.

### Moderator
Claim: I’d like to ask about Islam, from the standpoint of its own historical context, rather than from the prism of our absolute, individual standards or mixing the Muslim apple with the Christian orange if you will, which doesn’t take us very far. If we begin, say 950 years ago, when Islam was arguably the intellectual capitol of the world, since then there’s clearly been a trend of insularity and anti-intellectualism in the past thousand years, assuming that is true, what has been the trend in terms of tolerance, and radicalism, and in particular, not just the last thousand years but the last 100 and last 50 years.

### Moderator
Claim: Dick Bulliett—

### Scientific Advocate (SA)
Claim: You can handle that, Dick—

### Scientific Advocate (SA)
Claim: I’d like to ask about that, it—you made a statement then you said, “assuming that to be true.” Well, that’s a big assumption. You’re talking about 950 years, you’re talking about roughly the year 1100. Right? Okay. It is a commonplace—the history of Western culture, that Europe was behind at one point, and then at a certain point Islam stagnated and became backward, whereas Europe leapt ahead, and created the modern world.

### Moderator
Claim: Thanks to Islam, in large part.

### Scientific Advocate (SA)
Claim: In large part, based on borrowings in one way or another from Islam. But the notion that Islam stagnated is contrary to historical fact in certain ways. In particular, over half of all the people in the world today who are Muslims, are the descendants of people who converted to Islam after this alleged period of stagnation. Islam’s greatest success, in terms of the growth of a faith community, was in the period when Europeans are claiming that, uh, that Islam was stagnant. What happened in that period, was that you had an enormous, and very complex, interaction of Islam with communities in all parts of the world… east Asia, southeast Asia, south Asia, Africa, Europe, Eastern Europe and so forth, and Islam became immensely richer and more complex, through this interaction. Now, some people say, well, Europe was open to all sorts of new ideas, but in fact Europe was open—was open to its own new ideas. There’s not a single major idea in European history that actually came from anywhere except Europe. Because Europe has been a kind of closed—or Euro-American society—been fairly closed to the conceptual life, the spiritual life, so forth of other parts of the world. Islam is remarkably open. And, so I think it’s a question of, if you say that all that counts, is who gets rich, and who wins wars, and who’s able to set up an imperialist system, then you have one argument. But if you’re talking about the notion of stagnation, Islam certainly did not stagnate in that period. This was a period of enormous growth and development of complexity and intercommunal cross-fertilization.

### Moderator
Claim: We have time for another question from the audience, and, somewhere in the, somewhere in the back, I can’t see.

### Moderator
Claim: Hello.

### Moderator
Claim: Hi.

### Moderator
Claim: So according to a 2007 Pew study, over 60 percent of Muslims in America identified as moderate, and I was hoping that—

### Moderator
Claim: Identify as, excuse me?

### Moderator
Claim: Moderates. So I was hoping that Asra can elaborate a little bit on it, why again are…why is Islam dominated by radicals?

### Conspiracy Advocate (CA)
Claim: Because—

### Moderator
Claim: Asra Nomani.

### Conspiracy Advocate (CA)
Claim: Like I said before, I mean this is not a conversation about the majority of Muslims. We’re talking about whether Islam is dominated. Dominated to me means institutional Islam, it means the people who are running our mosques, the people who are running our—our organizations. It means, this establishment that it call Wahabism Incorporated, that is basically not just, you know, a pocket, an empty—an empty anecdote. It is an empire out there in the world that is defining our community. This isn’t a popularity contest about whether we want moderate expression of Islam or not. This is about who’s running our communities. And I can tell you that institutional Islam is representing a radical ideology that may not represent what most of Muslims believe, but at the end of the day, it’s not worth the trouble for most Muslims to battle them. I can tell you from the trenches, the struggle to battle that kind of institutional Islam is painful. You lose status, you get death threats, you get all sorts of abuse. And this is what happens whenever you challenge the authorities, and right now the authorities represent radical Islam.

## Round 3

### Moderator
Claim: Closing statements from all six panelists now, two minutes each, and then we’ll have you vote on these arguments that you’ve heard, starting with a panelist against the motion, “Islam is dominated by extremists,” Reza Aslan.

### Scientific Advocate (SA)
Claim: I guess the question has to be once again, what exactly are these radicals dominating—Asra Nomani has said that they’re dominating action, that is demonstrably false, because that would mean that what we’re seeing in every country in the Muslim world is this radical, collective action, which of course takes part in political violence, in terrorism, which is simply not true. I mean that’s demonstrably false, that is not the majority of the actions that we’re seeing. Paul Marshall has said that it is the states that dis—Islam is, or radicals are dominating, that again is demonstrably false. Besides the fact that one third of the Muslim world lives in democracy, the—besides the fact that, of the most populous Muslim countries in the world, Turkey, Malaysia, Indonesia, Bangladesh, Lebanon, Senegal, these are all quite successful democratic states—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: —and that in those countries that we do see a real sort of movement of political, one could even say radical Islam, they’re all in response to secular autocracies in which the mosque is the only free space in society, and the only opposition is religious opposition. Daveed has said it’s the institutions that the Muslims are radical in, this again is demonstrably false, the Iman Declaration, 170 of the world’s leading clerics and scholars representing every single sect and schism of Islam came together, issued fatwas out—outlawing violence in the name of Islam, outlawing calling anyone a takfir or an apostate, the same thing happened in the Mecca Declaration a year after that, the same thing happened earlier in this year with the king of Jordan. So in every single one of these issues, the idea that something is being dominated is demonstrably false. So we can talk about our sort of visions of what Islam brings up, you know, the visions of warfare and them. But the—

I guess the question has to be once again, what exactly are these radicals dominating—Asra Nomani has said that they’re dominating action, that is demonstrably false, because that would mean that what we’re seeing in every country in the Muslim world is this radical, collective action, which of course takes part in political violence, in terrorism, which is simply not true. I mean that’s demonstrably false, that is not the majority of the actions that we’re seeing. Paul Marshall has said that it is the states that dis—Islam is, or radicals are dominating, that again is demonstrably false. Besides the fact that one third of the Muslim world lives in democracy, the—besides the fact that, of the most populous Muslim countries in the world, Turkey, Malaysia, Indonesia, Bangladesh, Lebanon, Senegal, these are all quite successful democratic states—

### Moderator
Claim: Thank you—

### Scientific Advocate (SA)
Claim: —fact is when you think about it in its historical sense and its factual, objectifiable—

### Moderator
Claim: Reza—

### Scientific Advocate (SA)
Claim: —observafiable sense, it just doesn’t make any sense—

### Moderator
Claim: Thank you, Reza Aslan, for your closing statement, Paul Marshall, arguing in favor of the motion.

### Conspiracy Advocate (CA)
Claim: Okay, yes, we do argue it is a question of institutions, who is controlling organizations. Course one of those major and the most powerful of those organizations, is states. Though not just them. We’ve spoken not just about Saudi Arabia, we’ve spoken about Iran. Compared to the situation of 30 years ago, whereas a— with a radical Islamic regime you basically, just had the Saudis, at least a large one. Then you had Iran. Then you’ve had Sudan. Then you’ve had radicalization in Pakistan which has continued. You’ve had events in Somalia. You’ve had events in Nigeria. If you look at places where more radical movements are not per se the government, but are increasing influencing it, and are more powerful and have established themselves as the opposition, we see this in Egypt. We see this in Algeria. We see this in Malaysia. We see this in Indonesia. And in each of those countries we see an increase—

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —of violence. So in each of these settings, compare the situation 20 years ago, and the situation now. If you look at movements amongst Muslims, say amongst the Palestinians, amongst the Chechnyans, around Kashmir, in the Philippines, in Thailand, in Lebanon… You’ve had movements that are opposing the government. Usually it was in terms of national liberation or political freedom or access to resources. Now in each of those a shift towards a more radical Islamic emphasis. We see this across the board, in setting after setting. It is now more radical than it was then. Of course there’s a push-back, from Jordan. I’ve been involved in some of these conferences. Similarly with Turkey, similarly with Morocco, with Indonesian organizations. But they cannot mask—so far, I hope they will—but so far they cannot mask the power, the resources, which are arrayed against them. Currently, in the war of ideas—

Okay, yes, we do argue it is a question of institutions, who is controlling organizations. Course one of those major and the most powerful of those organizations, is states. Though not just them. We’ve spoken not just about Saudi Arabia, we’ve spoken about Iran. Compared to the situation of 30 years ago, whereas a— with a radical Islamic regime you basically, just had the Saudis, at least a large one. Then you had Iran. Then you’ve had Sudan. Then you’ve had radicalization in Pakistan which has continued. You’ve had events in Somalia. You’ve had events in Nigeria. If you look at places where more radical movements are not per se the government, but are increasing influencing it, and are more powerful and have established themselves as the opposition, we see this in Egypt. We see this in Algeria. We see this in Malaysia. We see this in Indonesia. And in each of those countries we see an increase—

### Moderator
Claim: Thank you—

### Conspiracy Advocate (CA)
Claim: —within the Muslim world, the radicals are winning.

### Moderator
Claim: Paul Marshall. And now, a closing statement from Edina Lekovic.

### Scientific Advocate (SA)
Claim: In the war of ideas, the moderates are the ones who have regained the ground since 9-11, both in internationally recognized leaders, and in the feelings and the sentiments of the people on the ground. And it is those people on the ground, 1.3 billion of them, who dominate and define the religion of Islam. As do the recognized religious leaders who are, as we mentioned, time and again, pushing for a new form of tolerance, and more and greater dialogue with other religious institutions as well as state powers. Let us not confuse Islamic states, for—and misunderstand them as anything other than the two-thirds of them that are dictatorships. The argument on the table is not whether the Muslim world is ruled by dictatorships. It most certainly is. But that is not the question on the table, the question is whether Islam itself, and therefore, the global population of Muslims, are dominated—

### Moderator
Claim: One—

### Scientific Advocate (SA)
Claim: —by radicals. Radicals are failing in their attempt to dominate. The moral bankruptcy of the militants as well as their abject failure in socioeconomic terms has strengthened the leaders of moderate, predominantly Muslim nations, just like Turkey, like Indonesia, like Malaysia, in their struggle against religious radicalism and backwardness. Let us remember again the people on the ground who make up the dominant force within Islam, and who have wrestled back control over their faith and are continuing to do so. Are they the absolute, at—the 100 percent at this point, absolutely not. But they make up the dominant side and they say, according to Gallup, that the most important thing that Westerners can do to improve relations with their societies, is to change their negative views toward Islam, and respect Muslims and Islam.

In the war of ideas, the moderates are the ones who have regained the ground since 9-11, both in internationally recognized leaders, and in the feelings and the sentiments of the people on the ground. And it is those people on the ground, 1.3 billion of them, who dominate and define the religion of Islam. As do the recognized religious leaders who are, as we mentioned, time and again, pushing for a new form of tolerance, and more and greater dialogue with other religious institutions as well as state powers. Let us not confuse Islamic states, for—and misunderstand them as anything other than the two-thirds of them that are dictatorships. The argument on the table is not whether the Muslim world is ruled by dictatorships. It most certainly is. But that is not the question on the table, the question is whether Islam itself, and therefore, the global population of Muslims, are dominated—

### Moderator
Claim: Thank you, Edina Lekovic, for that closing statement against the motion, now with a closing statement for the motion, “Islam is dominated by radicals,” is Asra Nomani.

### Conspiracy Advocate (CA)
Claim: “Regain the ground,” “wrestled back our communities,” I don’t think so. A Christian or Jew cannot go into Mecca, because you’re banned. A woman cannot travel in…to Mecca, because of the laws of the land that say that she has to have a chaperone. The men in our community have decided that in fact their radical version of the ideology allows them to, to retain power. You can call it an autocracy, you can call it dictatorships, you can call it anything you want, but it is radical and it is dominating our communities. Just look at the example of the South, in the 1930s let’s say. Civil rights… Let’s exchange the words of our proposition. The South was dominated by white supremists at that time. Would they have been the majority? Maybe not. But they controlled the churches, they controlled the cops, they controlled the laws, they controlled the power structure.

### Moderator
Claim: One—

### Conspiracy Advocate (CA)
Claim: That’s what we’re talking about. Our laws, our power structure, our cops, our clerics, are all on the payroll of an ideology that is radical. And it’s an issue of great pain to me as a Muslim, it’s an issue of great sadness. It breaks my heart that this is the reality and the truth, and it’s an ugly truth. But, I challenge you, to accept it, because even though it’s ugly, it’s only when we’re honest about it that we’re actually gonna be able to change the world so that this reality, where Muslims regain the ground and take back our communities, will actually happen one day. It hasn’t happened yet. And, I can only hope that it will happen. But right now, we are not, we have not won the war, and the struggle continues, and I assure you that we are in the struggle.

“Regain the ground,” “wrestled back our communities,” I don’t think so. A Christian or Jew cannot go into Mecca, because you’re banned. A woman cannot travel in…to Mecca, because of the laws of the land that say that she has to have a chaperone. The men in our community have decided that in fact their radical version of the ideology allows them to, to retain power. You can call it an autocracy, you can call it dictatorships, you can call it anything you want, but it is radical and it is dominating our communities. Just look at the example of the South, in the 1930s let’s say. Civil rights… Let’s exchange the words of our proposition. The South was dominated by white supremists at that time. Would they have been the majority? Maybe not. But they controlled the churches, they controlled the cops, they controlled the laws, they controlled the power structure.

### Moderator
Claim: Asra—

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: —Nomani, thank you. And now Richard Bulliett, your closing statement.

### Scientific Advocate (SA)
Claim: I have some problem squaring what Asra has just said, with what Paul Marshall started with. He started by saying, that…Islam is okay, most Muslims are okay. Like, nothing against Islam, nothing against most Muslims. But that, the people who are dominating are those who are striving for a political order that represents a reactionary version of Islam. Now we get to Asra, who just says that it’s true there are these dictatorships, these are totalitarian states, these are the autocracies, and autocracy is radical. And therefore radicals dominate Islam, well, but that radical…you know, that isn’t the radical that Paul’s talking about. There is nothing in the government of Syria or the government of Egypt or the government of most of the other autocracies in the Muslim world, that is in favor of striving for a political order that represents a reactionary version of Islam. In fact, most of these governments are—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: —dead opposed, to this sort of version of Islam. They’re trying to have what they call secular nationalist states, you can talk about the Baath party in Syria, you can talk about the Tunisians, you can talk about virtually every country except Saudi Arabia and Iran. But, you can’t get away with the idea of saying that, radicals dominate Islam because all—all autocrats are radical. That may be true. But that’s very different from saying that, what’s dominating Islam, which is the proposition of your team, is a particular version of Islam. We can agree, that autocracy is the besetting problem of Islam in that many of the reactions that you have, come as reactions to autocracy, and, just one word on the women. Every Muslim political group I know that is striving to find elections in the Muslim world, believes that all women should have the vote equally to men.

I have some problem squaring what Asra has just said, with what Paul Marshall started with. He started by saying, that…Islam is okay, most Muslims are okay. Like, nothing against Islam, nothing against most Muslims. But that, the people who are dominating are those who are striving for a political order that represents a reactionary version of Islam. Now we get to Asra, who just says that it’s true there are these dictatorships, these are totalitarian states, these are the autocracies, and autocracy is radical. And therefore radicals dominate Islam, well, but that radical…you know, that isn’t the radical that Paul’s talking about. There is nothing in the government of Syria or the government of Egypt or the government of most of the other autocracies in the Muslim world, that is in favor of striving for a political order that represents a reactionary version of Islam. In fact, most of these governments are—

### Moderator
Claim: Richard Bulliett, thank you very much for your closing statement and now, the last of the closing statements, from a supporter of the motion, “Islam is dominated by radicals,” Daveed Gartenstein- Ross.

### Conspiracy Advocate (CA)
Claim: In this debate we’ve defined hegemony in two ways. We have defined it as being hegemony over institutions, and hegemony over states. Now, Richard Bulliett in his last speech finds a contradiction, in that he says that the autocratic governments aren’t actually Islamic. Now, here’s a statistic that Asra put forward previously in the Q&A, which is important. About one billion of the world’s Muslims live in Muslim-majority countries. There are 22 countries, in which Islam is declared the state religion. A look at the numbers shows that about 602 million Muslims—that’s 58 percent of those living in predominantly Muslim countries—live in places where Islam is the state religion.

So, the autocracies are indeed enforcing Islam. That’s one thing that they’re doing. But it’s not just the autocracies. It’s the institutions. The institutions are important as well. And their argument, as Bulliett expressed in his last opening speech, is that for all the reasons given to you by the other side, vote against the motion, it comes down to a question of what hegemony means. And the only person on this side who tried to defend—to define hegemony, is Richard Bulliett.

### Moderator
Claim: One—

### Conspiracy Advocate (CA)
Claim: Who said hegemony requires a majority. Well, by that logic, everyone on that side has talked about how the US is a hegemon. Does that mean that the majority of people in the world are then Americans? Of course not. The fact is here, that if you look at where power is, power is in the hands of those who are trying to enforce a particularistic view of Islam. Look at the institutions, look at the anti-apostasy laws. Look at anti-blasphemy laws. Look at the prohibition on evangelism. Look at prohibitions on free speech. This is not a pretty situation. And it’s important to recognize where the power lies. That’s what we’re asking you to do. We’re asking you to vote for the resolution, to identify the challenges that all of us, all debaters acknowledge, lay ahead. And that’s why I would like you to vote for this resolution. Thank you.

In this debate we’ve defined hegemony in two ways. We have defined it as being hegemony over institutions, and hegemony over states. Now, Richard Bulliett in his last speech finds a contradiction, in that he says that the autocratic governments aren’t actually Islamic. Now, here’s a statistic that Asra put forward previously in the Q&A, which is important. About one billion of the world’s Muslims live in Muslim-majority countries. There are 22 countries, in which Islam is declared the state religion. A look at the numbers shows that about 602 million Muslims—that’s 58 percent of those living in predominantly Muslim countries—live in places where Islam is the state religion.

So, the autocracies are indeed enforcing Islam. That’s one thing that they’re doing. But it’s not just the autocracies. It’s the institutions. The institutions are important as well. And their argument, as Bulliett expressed in his last opening speech, is that for all the reasons given to you by the other side, vote against the motion, it comes down to a question of what hegemony means. And the only person on this side who tried to defend—to define hegemony, is Richard Bulliett.

### Moderator
Claim: And thank you, Daveed Gartenstein-Ross for your closing statement, and thanks to all of you, it’s now time for you to decide who carried the day. Once again, please pick up the keypad that is attached to the left armrest of your seat. Wait for my prompt. After my prompt, press “1” if you are for the motion, and again, the motion is, “Islam is dominated by radicals,” “2” if you are against the motion, or “3” if you are undecided. Please cast your vote now.

We’re waiting for the bytes and the bits to tally up, and I just want to—we’ll wait for the results in a moment, I want to thank the debaters first of all, and also the audience for your good work. And before I announce the results of the audience vote, before I announce the results of the vote I want to take care of a few things. The final Intelligence Squared US debate of the season, will be on Tuesday, March 13th, here at Asia Society and Museum—

### Moderator
Claim: May 13th—

### Moderator
Claim: Tuesday, May 13th excuse me. We don’t use that on the broadcast, do we, so I don’t have to repeat that. It’ll be on Tuesday, May 13th, here at Asia Society and Museum, and the motion to be debated is, “We Should Legalize the Market for Human Organs.” But they’ll—

### Moderator
Claim: Can we come back to that—

### Moderator
Claim: —there’ll be no organs actually legalized during the— That’ll be moderated by the way by my colleague, NPR’s Michele Norris, and the panelists for the next debate are, for the motion, professor of law at George Mason University Lloyd Cohen; the director of transplantation and professor of surgery at SUNY Upstate Medical University, Amy Friedman; and resident scholar at American Enterprise Institute, Sally Satel. And against the motion the panel will be, the team will be, James Childress, professor of ethics at the University of Virginia and director of the Institute for Practical Ethics and Public Life; professor of surgery at Harvard Medical School and Director of Medical Affairs of the Transplantation Society, Frances Delmonico— Excuse me. And David Rothman, a professor of social medicine. I have the results but I can’t read it because I’ve lost my voice. And also— historian David, Rothman, of Columbia University. So… Here are the results. First I—before I tell you the results— An edited version of tonight’s Intelligence Squared US debate will be heard locally, on WNYC, a wonderful NPR member station, AM 820, on Sunday, April 27th at 8 p.m. Those debates are heard on more than 150 NPR stations across the country, please check your NPR member station listings for the debates and times of broadcasts out of New York City. After the debate, 73 percent of you said you agreed with the motion, that Islam is dominated by radicals. 23 percent were against, and 4 percent remain undecided. So congratulations to the team for… UA big swing. Copies of books by the way by our panelists are on sale upstairs in the lobby, and you can also purchase DVD’s from previous debates here tonight. Thank you very much.
