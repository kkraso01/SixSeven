# Debate Transcript

Topic: Science Refutes God
Motion: Science Refutes God

Debate ID: 120512%20science%20god


## Round 1

### Moderator
Claim: I want to bring to the stage-- what we like to do is just take a little bit of a moment to frame this debate and the question of why we're doing this debate and its relevance. And to do that, we always bring to the stage at this point Robert Rosenkranz, who is the chairman of Intelligence Squared U.S. and I'd like to bring him out now. Robert, why this debate? Why does this one intrigue you, in particular? Because I know it does.

### Moderator
Claim: I kind of got interested in this topic by reading a book about science. It was by the astronomer royal of England, a man called Martin Rees, and the book was called "Just Six Numbers." And it was about six physical constants that were imprinted in the early universe, in the first 100 millionth of a second after the Big Bang. And these constants express ideas like the strength of gravity, the strength of the bond that keeps the nucleus of atoms together, the uniformity of that initial fireball. And if any of those six numbers was much larger or much smaller, we would really not have a universe; either stars and galaxies wouldn't have formed, or there'd be no elements as complicated as carbon and oxygen, or the Big Bang would've been succeeded by a big crunch into a black hole in which all matter would've disappeared.

And when you think about this, or at least for me, I thought, could this be just chance or is there some uncanny intelligence at work in this early design?

### Moderator
Claim: And for the-- what we're doing here tonight, why is this not-- you know, this has been going on for a long time, this conversation, why is this not just the Scopes Monkey trial all over again?

### Moderator
Claim: Well, because I think this conversation should be much more sophisticated than when dealing with the literal truth of something in the Old Testament. And, in addition, of course, science has moved on so much since that time. So I think this is going to be a very-- a much more subtle and interesting debate than that one might have been.

### Moderator
Claim: I'm sure it's going to be, because we're going to bring out our debaters so that you can meet them, and we'll let the debate get started. Thanks very much. Robert Rosenkranz. Two of you are in the dark, and I don't mean that metaphorically. I'm--

### Moderator
Claim: Let there be light.

### Moderator
Claim: All right. In fairness, we have to let the other side do the same thing. I just want to invite one more round of applause for Robert Rosenkranz for making this possible. Newton invented calculus, and he believed in God; Max Planck was the father of quantum physics, also a believer; Copernicus, the solar system, he had the faith; and Galileo and Francis Bacon and Pascal, they all believed. What they also all had in common is that none of them was born within 150 years of us. Today, three out of every five scientists, knowing what they know, said that they can't really buy into the concept of God. Science refutes God, they would say. Really? So then what about the two out of five scientists who do believe in God and they actually know the same stuff? It sounds like the makings of a great debate, so let's get on to it.

Yes or no to this statement: science refutes God. A debate from Intelligence Squared U.S. I'm John Donvan, we have four superbly qualified debaters who will be arguing for and against that motion, "science refutes God." Our debate goes in three rounds, and then the audience votes to choose a winner, and only side wins.

On the side arguing for the motion "science refutes God," Lawrence Krauss, a theoretical physicist and director of the Origins Project at Arizona State University. His partner is Michael Shermer; he is a founding publisher of Skeptic Magazine, and a columnist for Scientific America. On the side arguing against the motion that science refutes God, Dinesh D'Souza; he is the bestselling author of "What's So Great About Christianity?” and director of the documentary, "2016: Obama's America." And his partner is Ian Hutchinson. Ian Hutchinson is the professor of nuclear science and engineering at Massachusetts Institute of Technology. Let's meet our debaters. Our motion is, "Science Refutes God." And welcome first to argue in support of the motion, Lawrence Krauss. Oh, that was confusing.

### Conspiracy Advocate (CA)
Claim: I'm eager.

### Moderator
Claim: You are eager. So, Lawrence, I first want to chat with you just-- just a moment. So I want to tell folks, you are a theoretical physicist. Your research interests have included partial physics, dark matter, neutrino astrophysics, which is kind of easy stuff for all of us. You also-- you like to push buttons, and you wrote "Forget Jesus: The Stars Died So That You Could Be Here Today," which doesn't sound very polite.

### Conspiracy Advocate (CA)
Claim: Do you think that's provocative?

### Moderator
Claim: Slightly, yeah.

### Conspiracy Advocate (CA)
Claim: Well, I think provoking people and ridicule and satire is incredibly important in the world today. Nothing should be above ridicule because it gets people to think and least of all, religion.

### Moderator
Claim: And your partner is?

### Conspiracy Advocate (CA)
Claim: Michael Shermer.

### Moderator
Claim: Ladies and gentlemen, Michael Shermer. Michael, you are the founder of Skeptic magazine and the Skeptics Society. You were not always skeptical on this issue. You, as a teenager, were a born-again Christian, and then you switched to the other team. You're what my eighth grade nun would call "a very brazen and naughty boy."

### Conspiracy Advocate (CA)
Claim: Well, I'd be happy to talk to her about it for you if you like, but--

### Moderator
Claim: She passed on, which I think would go to the other side.

### Conspiracy Advocate (CA)
Claim: Well, I was a born-again Evangelical. I went knocking on doors to doors to tell people about Jesus. And then later when I became a born-again atheist, I went back to those same houses and knocked on their doors… I was wrong.

### Moderator
Claim: All right. Our motion is "Science Refutes God." We have two debaters arguing against this motion. I'd like to introduce the first, ladies and gentlemen, Dinesh D'Souza.

Dinesh, you're a best-selling author and the director of "2016: Obama's America," the second highest grossing political documentary of all time. You have debated this issue a number of times. You've been on stages arguing against atheists a lot. And a lot of times they say that science refutes god, but you came out with a book called "God Forsaken." And the way you turn this argument on its head, how?

### Scientific Advocate (SA)
Claim: Well, I think science is a-- can be a tool to help us understand God. And so far from science refuting God, I see science as a wonderful instrument for helping us learn about the world and thus learning about its creator.

### Moderator
Claim: And your partner is?

### Scientific Advocate (SA)
Claim: My partner is Ian Hutchinson.

### Moderator
Claim: Ladies and gentlemen, Ian Hutchinson. Ian Hutchinson, you are a professor of nuclear science and engineering at MIT. Your contributions to science include, and I take this from your biography online at MIT, they include, "The First Observations of Polarized Tokamak Electron, Cyclotron Radiation and Development of Diagnostics and Thermal and Nonthermal Electronic Distributions Based On It." So you're that guy? What are you doing here?

### Scientific Advocate (SA)
Claim: Well, I guess that is the question, isn't it?

But most seriously, I am a scientist, and I'm also a Christian. I think both are very important parts of the way that we understand the world. And I think that's why this debate is so important.

### Moderator
Claim: All right. Ladies and gentlemen, our live audience, act as our judges. We ask you before the debate has ended to vote twice, once before you've heard the arguments and once again after you've heard the arguments. And the team whose numbers have moved by the highest percentage will be declared our winner. So we would like to register the preliminary vote. If you go to the key pads at your seat, set of numbers one through three, and if you agree with the motion at this point, Science Refutes God, we want you to push number one.

If you disagree, push number two. And if you are undecided or agnostic, push number three. And if you feel that you've pushed a number in error, just correct it, and the system will lock in your last vote. And we're going to hold the result of this first vote until the end of the debate. When you vote the second time, we'll compare the two numbers. And again the team whose numbers have moved by the highest percentage will be declared our winner.

All right. So on to round one, opening statements from each debater in turn. Our motion is "Science Refutes God." And here to debate first in support of this motion, Lawrence Krauss. He is the director of the Origins Project and professor of physics at the school of earth and space exploration at Arizona State University. He is an-- also an author of the best-selling book, a-- let me do that again so that it's clean for the radio broadcast because I really want to help you sell this book.

### Conspiracy Advocate (CA)
Claim: Yeah, you bet. You can take all the time you want.

### Moderator
Claim: He is also the author of the best-selling book, "A Universe From Nothing." Ladies and gentlemen, Lawrence Krauss.

### Conspiracy Advocate (CA)
Claim: Thank you. I actually wore this t-shirt for the subject of the debate. And it's the center of the debate. And it's clear. The motion is science refutes God. And Michael and I have the distinct advantage here of arguing in favor of the motion because in fact we have evidence, reason, logic, rationality, and empirical methods on our side, whereas the opponents have vague hopes and fears, and they're arguing in favor of a motion that's hanging on for its existence by mere shreds of emotional and ideological spaghetti, much like this type provided by the flying spaghetti monster, one of the equally irrational gods which science provides no support for.

But I first want to begin by clarifying the nature of the motion, because the motion isn't science disproves God. It's science Refutes God. And that's very important because you can't disprove a notion that's basically vague and unfalsifiable. I could not-- there's no way to disprove the notion that God didn't create all of us 15 seconds ago with the memories of the amusing comments we heard before that. There's no way we can disprove that, okay. And that's really important to recognize that those kind of unfalsifiable notions are unfalsifiable, as I say. But we can ask, is it rational to expect that that's likely. And tonight I want to emphasize that 500 years of science have demonstrated that God, that vague notion, is not likely. It's irrational to believe in God.

Now, to refute God means refuting several claims. Onethat are all based on faith, not evidence. One, that God is necessary, two, that there is evidence for God; and three, that that belief is rational. And the point is that the progress of science has shown over and over and over again that the answers to all those three questions are no. No, no, no. Now, my own scientific field is cosmology. And that's the study of the origin and evolution of the universe as a whole. And it's where science and religion sort of confront each other. And creation myths have abounded throughout human history, and science confronts those creation myths. And we'll talk about that, I'm sure, at some point in the debate. But I want to point out that our opponents, I'm pretty sure, are going to argue first that one aspect of science that supports perhaps the belief in God is this notion that the universe is apparently fine-tuned for life. I hear that a lot, and because it was fine-tuned so life could exist. That is a remarkable and, in fact, cosmic misunderstanding, because it's the same kind of misunderstanding that led people to believe in special creation for life on earth before Darwin.

It looked like everything was designed for the environment in which it lived. But what Darwin showed us was that a simple proposition, namely that there's genetic variation among a population combined with natural selection meant that you didn't need supernatural shenanigans, that in fact all the diversity of life on earth could arise from a single life form, by natural law. And he didn't know-- what he showed was it was plausible, based on the evidence-- he didn't know about DNA. He didn't know about the details of genetic replication, but he showed it was plausible. And as I'll say, that's where we're at now as far as the understanding of the universe is concerned. Now, our-- my opponents, I suspect, will argue the universe is equally fine-tuned for life, and they-- in fact, they will point out that certain fundamental parameters in nature, if they were different, we couldn't exist.

Or they may boldly assert that, in fact, certain of these parameters are so strange and unnatural that they must have been established with malice aforethought to ensure our existence. This too is an illusion. Just as bees need to see the color of flowers but they're not designed to do it, if they couldn't see them, they couldn't get the nectar and reproduce. So what we're seeing is a version of cosmic natural selection. We would be quite surprised to find ourselves living in a universe in which we couldn't live. In fact, that might be evidence for God. But I want to point out that in fact the universe isn't particularly fine-tuned or conducive to life. Most of the universe is rather inhospitable to life. And in fact-- perhaps the biggest fine-tuning problem in my own field of cosmology, something I'm, in fact, very proud to have proposed in a sense is that the energy of empty space is not zero. The weirdest thing you can imagine, that empty space weighs something, but remarkably the energy of empty space is 120 orders of magnitude smaller than we would naïvely predict.

And if it were much bigger than we measure, it's true that galaxies couldn't form, and planets couldn't form, and Intelligence Squared Debates couldn't happen. So the universe appears to be here because Intelligence Squared is here. Now, that suggests religion perhaps, but the point is not that that claim of fine tuning is ridiculous because, in fact, if the energy of empty space was zero, which is a-- by far a more natural value, the universe would be a better place for life to live in. We all thought it was zero when I was a graduate student, because that was a natural value. If it was zero, the universe would be a better place. In fact, you can show the value that it has now makes the universe the worst of all possible universes to live in for the future of life. So, so much for a universe created for us. Now, once Darwin had removed the apparent need for God in evolution of life, the last bastion for God was the creation of the universe, how you can get something from nothing. And what-- we're in a remarkable situation of being in is precisely the same situation that Darwin existed in 150 years ago, namely, we have a plausible explanation of how a universe could precisely come from nothing.

If you asked, "What would be the characteristics of the universe that came from nothing by natural laws?" it would be precisely the characteristics of the universe we observe, and it didn't have to be that way. It could have been another way. And by nothing-- and it-- the-- my opponents will say that by nothing, I'm not talking about nothing, but I'm talking about nothing, no particles, no radiation, no space, no time, and even no laws of physics. Our-- my opponents might argue that the multiverse, which our universe might have spontaneously been created in, was created by physicists because they don't like God, because it's eternal and exists outside our universe, those same characteristics that God is supposed to have. But it wasn't created because we don't like God, although I don't like God. It was-- we'd been driven to it by measurements. In fact, I don't even like the multiverse, but I've learned to force my beliefs to conform to the evidence of reality.

That's where science differs from religion. There do remain deep philosophical and seismic questions that are unanswered, but God is not required or useful to explain any of them. And, therefore, to conclude, science has taught us that we don't need God to create a universe, that there's no evidence for God, that the specific sides of the claims of those who require God disagree with empirical evidence, and it's irrational. Science refutes God, so clearly you should vote for our side. Thank you.

### Moderator
Claim: Thank you, Lawrence Krauss. And that is our motion, "Science refutes God." And here to speak against the motion, Ian Hutchinson. He is a professor of nuclear science and engineering at MIT and the author of "Monopolizing Knowledge: The Scientist Refutes Religion Denying Reason Destroying Scientism."

### Scientific Advocate (SA)
Claim: Thank you for the opportunity to be with you tonight and to explain why science does not refute God. Let's agree that this motion is not about whether, for example, the latest sociological theories disprove the gods and goddesses of ancient Greek mythology.

No, it's about whether modern natural science exemplified by things like physics, chemistry, biology, geology, and so on rule out thoughtful theism. The god I'm going to discuss is the God of Christianity, because I'm a follower of Jesus, but my side's job is not to convince you of the truth of Christianity, although I think it is true. Our job is just to show that Christianity's God is not refuted by science. Now, obviously there are some religious beliefs that are ruled out by science, for example, the belief that the earth is stationary and orbited by the sun, moon, and stars. That is disproved by science, and perhaps prior to the 17th century, most Christians held a belief like that, as did most other people. But that stationary earth belief is not in the least central to the Christian message and doctrine.

To establish the motion, what our opponents have to do is to show that some central tenet of what Christians believe about God is impossible or at least highly implausible in the light of science, and that's a tall order. Actually, they can't even come close. But let me dispense with a couple of the most plausible sounding arguments. I'll illustrate one common argument from the writing of an MIT colleague, Alan Lightman, who wrote in the Salon magazine last year, he said, "The central doctrine of science is the view that the laws of nature are inviolable." He said, "Science and God are compatible as long as the latter, God, is content to stand on the sidelines once the universe has begun."Now, I certainly shall not shrink the God that I advocate down into a deistic, non- interventionist first cause. No, the God I'm interested in is personal and active in the world. So the question is, "How do I answer Alan Lightman?" It's straight forward. The presumption that the laws of nature are inviolable is just not a doctrine of science. Alan and a lot of other people are just wrong about that. Science's method and its program is to describe the universe insofar as it is repeatable and follows universal laws, but science hasn't got the slightest need to extrapolate that method and program into a presumption that everything that happens must be so describable. And the majority of the scientific heroes of history did not make that presumption.

Great scientists like those that were recited before, Newton, Boyle, Dalton, Faraday, Maxwell, were Christian believers who saw their science as compatible with a God who is active in the world and, on occasion, works miracles that go beyond the laws that they were discovering. So the notion that for science to function, or in order to be a successful scientist, it is necessary to believe in universal laws, is indisputably disproved by history. A second frequent critique of belief in God is that it is based on irrational faith rather than evidence. And this, of course, is a fallacy. Belief in God is often highly rational. The universities that were established between, say, the 14th and the 18th centuries, were places of explicitly religious rationality and learning.

Actually, evidence is just one type of reason for belief in God, and there is a loss of evidence for Christianity. But what the critics mean, I think, is-- they're saying there's no scientific evidence for God. And that goes to the heart of this question and the myth that science has somehow refuted God. Actually, there are some things we've learned about the universe through science that are highly suggestive of a creator, but for the sake of argument, suppose that the scientific evidence for God were non-existent. Would that mean that science refutes God, or would it even mean and support the more modest claim that there's no evidence for God? Not at all.

God is mostly not a scientific question, and so the evidence for God is mostly not scientific. If you insist that scientific evidence is the only type you will count, then you put out of business not just religion, but a vast range of other human knowledge, like history, or the law, or politics, or philosophy, or literature. There's no scientific way to prove that Caesar crossed the Rubicon; there's no scientific way to judge the justice of a verdict; there isn't even a scientific way to detect a true thought. But all of these things are real cognitive questions whose answers are important and often indisputable. And questions about God are usually of the same type, not scientific.

About 50 years ago, Yuri Gagarin became the first human in space. Soviet President Nikita Khrushchev told the Communist Party, anti-religionist, "Gagarin flew into space but he didn't find any God there." Well, what a silly argument. But most of the arguments behind the view that science has refuted God are of much the same type. If science, in its endeavors, fails to detect God, so what? Thoughtful Christians don't believe that God is a natural phenomenon or a law of nature to be established by scientific investigation. Science, for all of its power, is utterly incompetent to refute God.

### Moderator
Claim: Thank you, Ian Hutchinson. a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two arguing it out over this motion: "Science Refutes God." You have heard two of the speakers so far, and now onto the third. "Science Refutes God." And here to speak in support of the motion, Michael Shermer. He is the founding publisher of Skeptic magazine, executive director of the Skeptics Society, a monthly columnist for Scientific American and the author of "The Believing Brain." Ladies and gentlemen, Michael Shermer.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you. I'm going to start off with a thought experiment. Imagine you're a hominid on the plains of Africa 3.5 million years ago. You're a tiny little Australopithecus afarensis, little brain. Your name is Lucy. Thank you. A lot of people in the Midwest don't get that. what? Not that Lucy, the other one. And you hear a rustle in the grass. Is it a dangerous predator, or is it just the wind? If you think that the rustle in the grass is a dangerous predator, and it turns out it's just the wind, you've made a type one error in cognition. A false positive. You thought the wind was connected to something, and it wasn't. A was connected to B, and it wasn't. So that's a false positive. But that's relatively harmless. But if you think that the rustle in the grass is just the wind, and it turns out it's a dangerous predator, you're lunch. Congratulations. You've just been given a Darwin award for taking yourself out of the gene pool early before reproducing. And we are the descendants of those who are most likely to make type one errors, false-positives, versus type two errors, false-negatives. That is to say, why can't you just stay in the grass and collect enough data to get the answer right? And the answer is that predators don't wait around for prey animals to collect more data. That's why they stalk and sneak up on their prey animals, so they can't get enough data.

So we evolve the propensity to make snap decisions and make one kind of error more likely than another kind of error. And that kind of error, that false positive, that's superstition. That's magical thinking. That's assuming A is connected to B. It's a true pattern, and it isn't, and you're wrong. That's the basis of finding false patterns like gods. Now, what's the difference between the wind and a dangerous predator? The wind is an inanimate force. A dangerous predator is an intentional agent. And his intention is to eat me, and that can't be good. So what we also do in addition to finding these meaningful patterns is infuse in them agency. That is, it's alive. It's real, it has intention, and its intention is not good, so I better assume it's real. And this is the basis of animism and spiritism and polytheism and monotheism and the belief in angels and aliens and demons and spirits and poltergeists and gods.

Gods are invisible agents who run the world, who control things, who create these patterns, who are these patterns that we use to explain things. All cultures everywhere in the world have created god beliefs. Gods with these intentional-- that are intentional agents. So my question tonight is not like in my book, why do so many people believe in God, here is a theory, which I just outlined for you.

But for tonight, I want to ask, what's more likely, that our opponents here happen to pick the right God and the right religion among all the-- about 10,000 different religions and about a thousand different gods the humans have constructed socially, anthropologically, psychologically in the last 10,000 years. 10,000 different religions, a thousand different gods.

Our opponents agree with us that 999 of those gods are false gods. They are atheists like we are atheists. What I'm asking you to do is just go one God further with us. So here's what happened. About 5,000 to 7,000 years ago, these small bands of hunter- gathers began to coalesce into chiefdoms and states. As long as the numbers are small, informal means of behavior control and moral enforcement operate quite well. As soon as the numbers are too large for these informal means, shunning, making people feel guilty, gossiping about them, making them feel embarrassed for their bad behavior, as soon as the population are big, there's too much opportunity for free riding and for cheating the system and taking advantage of it and getting away with it.

So two institutions evolved, government to set up a set of rules, and everybody gets a copy; and religion in case you think you got away with it, you didn't because there's an eye in the sky that those all and sees all and keeps track of this. So this is the second part of how humans construct religions and gods, because we need it for moral enforcement. It just so happens, by contingency and chance, religion and government was the first on the scene.

Now, what's happened in the last several centuries, since the enlightenment, in addition to the trajectory that professor Krauss outlined for you, science displacing religion as the primary means of explaining how the world works, something else has also happened. We've slowly but ineluctably replaced religion as the primary source of our morals and came up with the clever idea that you actually have to have a reason why you have certain moral principles, and we're going to write certain laws. You actually have to give evidence for why you think this is a good law or a bad law or a good moral principle or a bad moral principle.

And that has been the trajectory of the enlightenment since about 200 years ago. And so again, what's more likely, that one of them happens to be the one true religion, and the one true God, and all those others that have been constructed are false gods or that, as we can clearly see, anthropologically, socially, psychologically and so on, this is what people do to get along. They construct religions. They construct moral systems and so on. We now know that we can do this without gods. In fact, we do it quite well without gods. Northern European countries do just fine with much lower rates of religiosity than we have. It is possible to do it, and that is what we've been doing.

Now, I want to finish with just one comment on the resurrection since Ian brought that up. Let me just-- leaving aside the scientific evidence for this, just think about what it is that is being said here. They are monotheists. They believe that there's just one God and that Jesus is God manifest on earth. And he is your savior, and you accept him for redeeming us for sins we never committed. Somebody else in the past committed them. So as I understand this, God sacrifices himself to himself to save us from himself. If that sounds as incomprehensible to you as it does to me, I urge to you vote for our side. Thank you.

### Moderator
Claim: Thank you, Michael Shermer. And our motion is "Science Refutes God." And now our final debater speaking against this motion, Dinesh D'Souza. He is the best-selling of many books including, "What's So Great About Christianity." He's also the director of the documentary "2016: Obama's America." And a former policy analyst in the Reagan White House. Ladies and gentlemen, Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: Thank you very much. How would one go about refuting the idea-- establishing the idea that science refutes God? First of all, you'd have to show that belief in God was, if not impossible, unreasonable. And, therefore, you'd have to show that all the people in the world who believe in God are also being unreasonable and that science has established this not at some point in the future, but has established it already. Science has refuted God right now. Now, on the face of it, this is such an odd and difficult and preposterous enterprise. Why? Because actually the questions to which God is the answer are really fundamentally not scientific questions.

Here is what I mean. Here we are as human beings. We're thrown into the world. And we can't help if we're curious, if we're thoughtful to say, first of all, why is there a universe? Second, what's our purpose? What are we doing here? Third, what's going to come after? We're going to die, but what next? Now I ask you, what are the scientific answers to those questions? And in fact, the answers are, from science, don't have a clue, don't have a clue, and don't have a clue. Why? Because none of those questions is amenable to being decided empirically. Science can show how we got a universe but not why. On the question of what our purpose is here, science is completely silent. Moral issues are in a way outside the province of science. Why? Because science deals with what is, and morality is what ought to be.

And finally, under the question of what comes after death, what possible empirical evidence can science provide on either side of that question? So because science is in no position to refute God, what we get from the other side is pop psychology. And we've been getting pop psychology from atheists for several hundred years. It's an effort to explain why people believe instead of providing any kind of a real refutation. You remember a few decades ago Freud basically said that God and religion could be dismissed as wishful thinking, "We wish for a better world and so we make one up." Well, that would kind of explain Heaven which satisfies wishful thinking, but it really wouldn't explain why major religions have invented Hell. Who would wish for that? Hell is a lot worse than diabetes or the suffering we have in this life.

And then you've heard here people like Richard Dawkins say, "Well, belief in God depends on where you're born. If you're born in Afghanistan you're going to be a Muslim. If you're born in Tulsa, Oklahoma, you're likely to be a Christian." Michael Shermer alluded to that a little bit when he talked about multiple gods. But the sociology of the origin of belief says nothing about the truth of a belief. I'm sure that people who are born in Oxford, England, are most likely to believe in Darwin's theory of evolution than people who are born in Oxford, Mississippi. I'm sure people who are born in New York are more likely to believe in relativity than people who are born in New Guinea. What does that say about whether evolution or relativity is true? Nothing. The genesis of a belief, how you came to it, has nothing to do with whether or not that belief can be sustained as a matter of argument. The reality is, and we keep hearing a lot about Darwin because the last good argument against God came out in 1850-- in the 1850s, science has made a whole bunch of discoveries since then but they point in the opposite direction.

And, therefore, what you find very often from atheists is now highly complicated defensive maneuvers to account for things that atheists resisted all the way. When the discovery of the big bang came-- this, by the way, was at a time when most scientists believed the universe was eternal, the steady state universe was the prevailing doctrine of American and Western science-- so it came as a shock that the universe had a beginning. Why? Because, in a way, it wasn't just that matter had a beginning, but space and time also had a beginning. In other words, this was something that the ancient Hebrews had said thousands of years ago and without conducting a single scientific experiment. By the way, this is not the same as other cosmologies. Other ancient cosmologies posited the universe being fashioned by a kind of carpenter god who made it out of some preexisting stuff, but the ancient Hebrews said, "No, first there was nothing, and then there was a universe."By the way, that's almost identical to what Lawrence Krauss said, "First, there was nothing, no particles, no energy, no laws, and then there was the universe," completely consistent to what-- with what Christians believe, and exactly said by the ancient Hebrews thousands of years ago without doing a single experiment but solely on the basis of, "God told us." And the astounding fact is that 2,000 years later, modern science, after climbing round and round the mountain, has arrived at the top only to find a bunch of theologians who have been sitting there for centuries. Now, the fine-tuned universe is-- has become now a tremendous embarrassment to atheism. Why? Because ultimately it shows that the laws and constants of nature are fine-tuned, not only for the existence of life, but specifically for human life.

I want to note that this is an argument completely immune to Darwinian attack. This is not about whether the horse, the dog, and the wolf had a common ancestor. Let's remember that evolution, powerful theory as it is, is not a theory of life. It is only a theory of transitions between life forms. It's not about the origin of life, it's simply about how life form A gave rise to life form B. And the fact is that there have to be certain conditions, self-replicating cells, an old universe, an old earth that are necessary for evolution to take place. In other words, the fine-tuned universe is a precondition of Darwinian evolution itself. We are living at a time when religious believers do not need to be afraid of science; they should, as I do, embrace science and welcome science because correctly understood, far from pointing away from God, science thrillingly points to God. Thank you.

## Round 2

### Moderator
Claim: Thank you. Dinesh D'Souza. And that concludes round 1 of this Intelligence Squared U.S. debate, where the motion is "science refutes God." Now, keep in mind how you voted at the beginning of the evening, remember we're going to ask you to vote again at the conclusion and the team that has changed the most minds at the end of the debate will declared our winner. Now we go on to round two, where the debaters address each other directly and also take questions from you in the audience and from me. We have two teams of two, they're arguing out this motion: science refutes God. Lawrence Krauss and Michael Shermer are arguing for the motion, and they are basically making the argument-- number one, they're saying they are not arguing that science disproves God, but that science makes the possibility of the existence very, very unlikely. They point out, their argument, that the universe is so badly designed, actually, for human life, that it's highly unlikely that anybody would've thought this up.

They also say that God is a human creation, that this is established in history, psychology, anthropology, and that in the past God was the answer to a question that science has now answered more and more successfully. The team arguing against the motion, Dinesh D'Souza and Ian Hutchinson, are making the argument that belief in God, number one, is very rational; number two, that there is evidence for the existence of God, it's just not evidence that one would call scientific. That, in fact, science is not capable of answering the kinds of questions that God answers, such as, "Why are we here?" The "why?" questions, where do we go afterwards? They also say that the arguments being made on the-- by the other side, that are based on social sciences like anthropology and psychology, are pop science; and therefore, I believe, to be disqualified.

So we're going to take questions from you and from me, but I want to start by actually getting to something I'm very curious about, and that's the issue of miracles. I want to put to this side, you in particular, Ian Hutchinson, who is arguing against the notion that science refutes God, what is a miracle if not a violation of the laws of physics? And is that what it is, in addition to all of its other implications? Does it not violate the laws of physics? And if it does so, how does-- how is that even possible? And how does that fit into this argument?

### Scientific Advocate (SA)
Claim: So what we call the laws of physics, from a Christian point of view, are the way that God normally orders the universe. It's the normal behavior of things around about us. And Boyle, who was one of the founders of the Royal Society, wrote a whole a book about what nature is, and what he advocated was that what we mean or should mean by "nature," is the normal course of events. Now, of course, miracles are not the normal course of events. And, by the way, it didn't take science to tell us that; you know, people in the first century knew that people don't rise from the dead when they've been hung on crosses, and people knew that women don't bear children unless, well, you know what.

You know, this is not something that modern science has been necessary to tell us. So, yes, miracles are abnormal events; usually, abnormal--

### Moderator
Claim: Why does science not refute those things? As in--

### Scientific Advocate (SA)
Claim: It is simply not the case that you have to presume that the laws of nature are universally inviolable; it is simply not necessary to do science to do that.

### Moderator
Claim: Lawrence Krauss.

### Conspiracy Advocate (CA)
Claim: That's ridiculous. In fact, it's ridiculous to the science that you do. When you do science, you're presuming that the results of an experiment in your laboratory apply in another laboratory.

The fundamental claim that-- if you just-- miracles in your particular religion-- it's kind of remarkable that these violations of the laws of nature only occurred before video cameras and Intelligence Squared and the internet, and that you have these remarkable violations of the laws of nature in a book, which I was really surprised to hear Dinesh call a scientific document, the bible. I hope he really didn't mean that. St. Augustine would be very upset with you, because he said the Bible wasn't scientific. But these violations of the law of nature-- laws of nature only occurred at a time when there was no evidence for them--

### Moderator
Claim: But, Lawrence--

### Conspiracy Advocate (CA)
Claim: And you believe them.

### Moderator
Claim: Lawrence, but is there a logical argument, again, that you can make against miracles? Not the "I didn't see them and nobody's seen them lately" argument. But is there a logical argument you can make against them?

### Conspiracy Advocate (CA)
Claim: Our logic is determined by nature, not by what we'd like. And nature has told us that miracles don't happen. That's it. It's not what I want or what I think should be rational. It's, do they happen? And there's no evidence that they've ever happened.

### Moderator
Claim: Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: I think we have here a deep fallacy. And the fact that it remains a fallacy shows that what is being called science is actually hiding behind a philosophical principle. It was the philosopher Hume who pointed out 200 years ago that from no amount of empirical generalizations, however large, can you draw a general law that is true as a matter of logic. What I mean is, it doesn't matter how often you measure something. Let's say you measure the speed at which this pen falls down. You can measure it a million times. But you don't know that on a star ten light years away or in some other condition where you haven't measured it, that if you drop this pen, it will fall at the same speed. Science presumes it. It doesn't prove--

### Conspiracy Advocate (CA)
Claim: We measure. I'm sorry. We measure it.

### Scientific Advocate (SA)
Claim: Let me finish it. Right. But you can't measure it always and everywhere. And you haven't measured it 10,000 years ago. You're assuming that--

### Conspiracy Advocate (CA)
Claim: Yes, we have.

### Scientific Advocate (SA)
Claim: --10,000-- No. You're assuming that 10,000 years ago it happened at the same speed. And your measurement is based on that. So Hume's point is this: Science provides general propositions based on experience, but he said we should always be willing to accept new experience that proves the opposite. A good example of this in Western philosophy--

### Moderator
Claim: Before you go to the example, let me let Michael Shermer come in and respond to where you've gone so far with that.

### Scientific Advocate (SA)
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: Right. So like a popular thing in Skeptic magazine, there's psychics and people that can telekinetically move objects with their mind or so on. And there's an example of this where there's a man who can move the cursor on his computer just by thinking about it. Now, it turns out he's a quadriplegic, and he has a chip in his brain that enables him to do this. But if you don't know about the chip, it looks like a miracle. Once you know the technology, it's no longer miraculous. This is Arthur C. Clarke's third law. Any sufficiently advanced technology is indistinguishable from magic. I contend that there's no such thing as the supernatural or the paranormal. There's just the natural, the normal and the stuff we haven't explained yet. And when something unusual like that happens, we should go searching for the mechanism behind it. Is there a chip in the brain? So if it's true that, say, God heals cancers or whatever due to prayer, this should be a measurable thing because this is what we--

### Moderator
Claim: But what about Dinesh's point that just because something has happened 10,000 times and that that's your case, that it's always going to happen. And he's saying logically, you don't actually know that it's always going to happen just because it's happened 10,000 times.

### Conspiracy Advocate (CA)
Claim: Okay. Fine, fine, fine.

### Conspiracy Advocate (CA)
Claim: say that in fact that's very important. Science-- I agree with you in that. Science could only prove was wrong, not something that's absolute true. So you're right. If I drop a ball a million times, and it falls, I, in principle, could imagine an experience where it wouldn't. But it's highly likely it's going to fall the next time. But you use the keyword, "experience." We wait then for an experience that contradicts the known laws. So if tonight when I looked up at the sky, the stars rearranged themselves that I am here in Aramaic or ancient Greek or whatever you want, then I might say, you know, there's something to it. But the point is there's been no-- there's been no experience that violates the fact that the laws have existed throughout all time.

### Scientific Advocate (SA)
Claim: Lawrence, you haven't had such an experience.

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: But there are probably people in this room who have. So the question fundamentally comes down to what counts as empirical. And in science, of course, what counts as empirical are things that we can do experiments on, we can do repeated observations. So science depends upon reproducibility. But if we were to reduce some phenomenon to a reproducible behavior, we would have reduced it not into an explanation, a definition of what a miracle is. We would have reduced it into magic, or we would have reduced it in a new law of nature. So it's in the nature of miracle that it can't be reduced into scientific form. And in the end, science becomes essentially powerless to say, one way or another, whether a miracle--

### Conspiracy Advocate (CA)
Claim: --a miracle that happened, and tell me one that happened that you can show happened.

### Moderator
Claim: Let's let Michael Shermer answer.

### Conspiracy Advocate (CA)
Claim: But even so, even if there was one, aren't you curious as a scientist how God performed the miracle, what forces of nature she used and so on to make it happen?

### Scientific Advocate (SA)
Claim: Of course. And so, for example, so we would say, as Christians, for example, that--

### Conspiracy Advocate (CA)
Claim: Thank you.

### Scientific Advocate (SA)
Claim: --the big bang, the creation of the universe, was a miracle. Why was it a miracle? Because it used no known law of nature. It was in a sense supernatural. The universe.

### Conspiracy Advocate (CA)
Claim: But that's just because you didn't understand it.

### Scientific Advocate (SA)
Claim: But you haven't-- see, here is the thing. When we talk about experiments and reproducible things, you're talking, for example, let's take, for example, are there beings on other planets, right? It's an empirical question. Right now.

### Conspiracy Advocate (CA)
Claim: In principle, it's an empirical question, yes.

### Scientific Advocate (SA)
Claim: Empirical question. Right now, there is no evidence that there are creatures in outer space.

### Conspiracy Advocate (CA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: Therefore, have you refuted that belief?

### Conspiracy Advocate (CA)
Claim: No. But it's not an illogical one like the notion that--

### Scientific Advocate (SA)
Claim: You haven't refuted it because--

### Conspiracy Advocate (CA)
Claim: What?

### Scientific Advocate (SA)
Claim: You haven't refuted it because you haven't produced--

### Conspiracy Advocate (CA)
Claim: It doesn't require me to suspend the laws of physics in order to believe it.

### Scientific Advocate (SA)
Claim: But if I were to believe in creatures in outer space, I wouldn't be irrational, would I?

### Moderator
Claim: No, no, but you've got to respond to the point he just made. It would not require suspension of the laws of physics in order for you to believe there are creatures in outer space.

### Scientific Advocate (SA)
Claim: Right. And I would say that--

### Moderator
Claim: But miracles do.

### Scientific Advocate (SA)
Claim: No. Miracles simply say that the laws of physics are incomplete, that the laws of physics are generalizations that reflect the limits of human knowledge. These aren't nature's laws. They're Newton's laws. And it took an Einstein to modify them.

### Conspiracy Advocate (CA)
Claim: So when the sun stood-- so these biblical scientists who thought that the sun went around the earth because that's what they thought when they were writing, when the sun stopped in the sky, of course, had the sun been going around the earth, that would be fine. But we now know that actually the earth goes around the sun. And the fact that the sun moves in the skies and the fact that the earth rotates. So had the sun stopped in the sky, the stopping of the rotation of the earth would have produced forces which would have destroyed all life on the planet. But that somehow doesn't violate the basic classical physics. But-- and every now and then, that's possible?

### Scientific Advocate (SA)
Claim: Who are these biblical scientists you're talking about?

### Conspiracy Advocate (CA)
Claim: Well, you know, the horn blowing, the sun stopping.

### Scientific Advocate (SA)
Claim: The people who thought that the earth was the center of the universe and the sun went around it were Christians who, like non-Christians, were taught by scientists. That's where they got the idea. They weren't biblical scientists. They got it from you guys.

### Moderator
Claim: Wait, Ian, I think I hear a serious question. I didn't mean it that way. I didn't mean it that way. I think I hear an interesting challenge, in that Lawrence is saying that if a miracle were to occur, that it has ripple effects and a broad-- it doesn't just affect the people who are witnessing the miracle.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: But if-- for example, if the earth stopped because the trumpets are blowing, on the other side of the earth, you know, some tribe doesn't know what's going on, but suddenly the earth has stopped for them too. How do they explain it?

### Scientific Advocate (SA)
Claim: So in the 18th century, as science really got going, people thought that there were deterministic laws of physics and that once you understood the initial conditions, you could solve those laws and the result was absolutely determined. I think Lawrence will agree that what science has found out in the 20th century is that that is simply not true, that there is, in the universe as a whole, as we discover it by science, some deep uncertainties, some undefined behavior which, in the end, cannot be considered to be deterministic. In other words, a deterministic universe in which there's no room for God to operate is simply not the way we think about the universe as physicists these days.

### Moderator
Claim: Michael Shermer.

### Conspiracy Advocate (CA)
Claim: Let's say, Ian, that petitionary prayer actually works. Again, as a physicist--

### Moderator
Claim: Petitionary prayer, you mean, I would like something to happen, and you pray for it.

### Conspiracy Advocate (CA)
Claim: Petitioning to the deity to, say, cure my cancer or whatever. And it happens. Wouldn't you be curious to know how the deity or whatever it is reaches into the world, stirs the particles, reconfigures the DNA so the cancer cells quit replicating so rapidly and so on.

And the moment you figure that out as a scientist, it would no longer be a miracle. It wouldn't be supernatural. It would just be part of nature. It's like, so if I recant this prayer six times between 10:00 a.m. and 11:00 a.m., this is the effect. It's a measurable, determined thing. That's just now incorporated as part of science.

### Scientific Advocate (SA)
Claim: Well, let's be clear that it's never been a religious position that if we have a natural explanation for something, that means that God is absent or that God didn't do it. It's always been a biblical viewpoint that even on things which we know are part of nature, God can be considered to be active in those things. So while this discussion on miracles is interesting in itself, one shouldn't be misled into thinking that the only place that God can act in the world is through those things which are so extraordinary that

### Conspiracy Advocate (CA)
Claim: John, I just want to correct an error that-- I mean, I don't think you

### Moderator
Claim: Lawrence Krauss.

### Conspiracy Advocate (CA)
Claim: --so I want to just make it clear. The laws of physics are deterministic. The Schrödinger equation which is the basis of quantum mechanics is a second order differential equation, and, therefore, the laws are deterministic. Our observations aren't deterministic, but the underlying laws are deterministic. Nothing's changed in 400 years. And so it's really important--

### Scientific Advocate (SA)
Claim: --there’s no way the universe isn't deterministic.

### Moderator
Claim: –it’s governed by quantum mechanics.

### Moderator
Claim: Just one thing, because we got into four syllables, and I'm not that smart. Just give us a working definition of the word "deterministic." You mean--

### Conspiracy Advocate (CA)
Claim: You start with an initial condition for the equations of quantum mechanics, and the evolution of the system is determined unambiguously--

### Moderator
Claim: It has to happen.

### Conspiracy Advocate (CA)
Claim: It has no uncertainty. Your measurement of the system has uncertainty, but the evolution of the underlying system is completely determined.

### Scientific Advocate (SA)
Claim: You know, I'll accept the slight correction--

### Conspiracy Advocate (CA)
Claim: Good.

### Scientific Advocate (SA)
Claim: --that-- but the point, nevertheless, remains exactly the way I said it, which is that the universe is not deterministic.

What science does is try to explain the universe by deterministic laws, and by looking at the world and trying to say, "How is it completely reproducible and in accordance with these universal laws?" And what it finds out is that no matter how hard we try, we're actually unable to have a complete description of the universe of that type. And this was such a shock that even as great a scientist as Albert Einstein was repelled by it--

### Conspiracy Advocate (CA)
Claim: That's wrong.

### Scientific Advocate (SA)
Claim: --and that's why he said, you know, "God doesn't play dice with the world," because he just could not abide it. But I would say by and large the majority of physicists today think that Einstein was probably wrong and that actually there is inherent large--

### Moderator
Claim: All right. One quick response and then we'll move on.

### Conspiracy Advocate (CA)
Claim: Yeah, I guess what I want to say is it's not-- we don't have a complete description, we do, quantum mechanics as far as we can tell is a complete description. We have a complete description of the probabilities.

We know with 100 percent accuracy if you perform the experiments that were described in the paper under your name, that with a distribution, the results will occur with a different-- with that distribution exactly. And, of course, because they did, you were able to write your paper.

### Moderator
Claim: So to the side-- excuse me-- to the side against the motion that "Science--" the motion that "Science refutes God," is it your position that there are certain things that science can know and then there are certain things that science can't know, therefore, it doesn't refute God? But what is in this world-- Dinesh, you talked a little bit about this universe of things that science can't handle, explain, such as why we are here-- that-- how large is that category of things that we can't know, and is science just irrelevant to that category of knowledge?

### Scientific Advocate (SA)
Claim: There are some questions in which Christians and religious believers are making factual claims, "God made the universe." It's a factual claim. Either he did or he didn't. There is life after death. We may have no way to find out, but that's a factual claim, either there is or there isn't. "The resurrection happened," either it did or it didn't. Now, religion also makes moral claims, "This is how you should live. This is a happy life," and so on, so religion operates in two domains. The second domain is untouchable by science. Science can try to give accounts of how morality originated, but that's not the same thing as what you should and shouldn't do.

### Moderator
Claim: Well--

### Scientific Advocate (SA)
Claim: So--

### Moderator
Claim: --but just be more clear about that distinction.

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: But we want to go straight to the other side about that.

### Scientific Advocate (SA)
Claim: Well, science can say that we evolved a desire for cooperation out of Darwinian evolution, but that doesn't say if there's a famine in Haiti if I should give money or no. So in other words the content of morality is unaffected by science although science can give an account of the origin of morality.

### Moderator
Claim: But not the-- what is actually right or wrong.

### Scientific Advocate (SA)
Claim: Yeah.

And the other thing is--

### Moderator
Claim: Let me-- before you move on, let me go to Michael Shermer on that.

### Conspiracy Advocate (CA)
Claim: Well, so where do we get our morals from? It can't be from the Bible because almost nobody obeys certainly not the Old Testament. And most of the New Testament-- I mean, death penalty for adultery, there goes half of Congress. I mean, nobody-- nobody is going to do this, right? So we pick and choose. We cherry pick from the Holy Book based on something else, something else that's happened that I referenced in my opening statement of there's been this other change that's happened, this secularization of morality. That is, you have to actually have good reasons for why you hold certain moral principles, and you should be able to articulate them. And so that's been the changer. So even if you and I both listen to the still small voice within to decide what's right or wrong, Dinesh, I'm claiming you're not getting it from the Bible and I'm not either, we're getting it from somewhere else. I think we've evolved this propensity to have moral emotions, and then culture tweaks them, and we've been getting progressively more moral.

### Moderator
Claim: But how-- what's telling us what is actually right or wrong?

### Conspiracy Advocate (CA)
Claim: But I think science does tell us what's right and wrong--

### Moderator
Claim: Lawrence Krauss speak.

### Conspiracy Advocate (CA)
Claim: I think science does tell us what's right and wrong in a real way.

### Moderator
Claim: Really?

### Conspiracy Advocate (CA)
Claim: Yeah, we have learned-- for example, the scientific facts that certain animals can suffer, for example, affects our decision of whether-- of how we should treat those animals, whether we should eat them or not eat them, or the scientific evidence that certain people of certain colors don't have different intellects, different capabilities has changed the way we deal with other humans.

### Moderator
Claim: But if--

### Conspiracy Advocate (CA)
Claim: Science has determined the way we behave in the modern world.

### Moderator
Claim: And science is telling us what's right or wrong.

### Conspiracy Advocate (CA)
Claim: Yeah, I think so because it's telling us how the world actually works.

### Moderator
Claim: Ian Hutchinson.

### Scientific Advocate (SA)
Claim: I don't think it's the case that it tells us right or wrong. I think science does often inform us in ways that help us to implement our morals and our ethics more effectively, more fairly, more accurately, and more truly. But in the end it cannot tell us whether it's right or wrong to do something because categories of right and wrong aren't scientific categories.

### Conspiracy Advocate (CA)
Claim: Well, the Bible certainly doesn't tell us, either.

### Scientific Advocate (SA)
Claim: Well--

### Conspiracy Advocate (CA)
Claim: Where do you get it from?

### Conspiracy Advocate (CA)
Claim: Yeah, where do you get it? I mean, does God-- does God speak to you and tell you?

### Scientific Advocate (SA)
Claim: I'll answer that.

### Moderator
Claim: Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: First of all, we don't get, none of us, morality from the Bible. It's not like I read the read the Ten Commandments and went, "Oh, stealing is wrong, wow. Didn't know that before. Killing is wrong, incredible." I already knew that.

### Moderator
Claim: Exactly.

### Scientific Advocate (SA)
Claim: How did I know it? I knew it because of what Adam Smith calls the impartial spectator, the voice of conscience. So it is the contention of religious believers that the voice of conscience has been implanted in us by God. Now, you say it comes from evolution, and we say it could have been implanted in us by God through evolution. Now, just to say that science tells us facts doesn't mean that science changes our morality. If I were to step on a stage and stomp on a dog, there'd be a universal wave of revulsion in the audience, although presumably the matter would be more controversial if it were a cat, but-- science-- my point is science can tell us the dog feels pain. But the idea that we shouldn't cause pain to others, that's a moral proposition.

Science is merely altering the fact which puts that moral principle into motion. So we have widened our circles of morality based upon new facts, and science can provide those, but science isn't actually telling us what's right or wrong at all.

### Moderator
Claim: I want to go in a moment to you in the audience to take questions, and when we do, I just want to remind you what our format is. We'd like you to raise your hand, I'll call on you, a microphone will be brought to you, we really need you to wait for the microphone so the radio broadcast can hear you, and hold it about this distance, a fist distance from your mouth. We'd appreciate it if you could tell us your name, if you could really ask a question that's on this topic of science refuting God, and if you can be terse.

So while we're getting set up for that, I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, arguing it out over this motion: science refutes God.

To the team that is arguing for the motion that science refutes God, I want to ask you somewhat of a personal question. Can a scientist believe in God and still be a functioning scientist?

### Conspiracy Advocate (CA)
Claim: Absolutely, there are-- there are-- there are functioning scientists who can believe in God; there are functioning scientists who are pedophiles-- there are functioning scientists who are-- no, I'm serious, I mean, the point is scientists are human--

### Moderator
Claim: Woah, woah, but that was a-- that was a-- that was a very, very, very rough grouping that you just did.

### Conspiracy Advocate (CA)
Claim: Well, in the Catholic church it's not so different, but--

### Moderator
Claim: I don't know. I don't know in the spirit of this thing, if you want to step back from that.

### Conspiracy Advocate (CA)
Claim: Okay, but what-- yeah-- okay, but what I want to point out is that people can believe-- people are not fully rational. The point is--

### Moderator
Claim: No, I'm asking-- the question is, "Can you be a good scientist and believe in God?"

### Conspiracy Advocate (CA)
Claim: As long as you don't take the God into the laboratory. As a very famous biologist said, "When I go in the laboratory, I become an atheist, because when I believe-- when I twiddle the knobs in my experiment, I don't believe there's some angel affecting the results of the experiment, and if I believe that in laboratory, why should I believe it outside?" Some people choose to believe it outside; the minute they take it into the laboratory, they stop being good scientists.

### Scientific Advocate (SA)
Claim: But that--

### Moderator
Claim: Ian Hutchinson.

### Scientific Advocate (SA)
Claim: That's actually quite-- That's actually quite contrary to history. I mean, what got modern science going in the first place was a belief in the faithfulness of God, of a creator who'd made a rational creation. And a good case can be made that the reason why science as we know it, modern science, grew up in the west, was in part because Christianity, in its philosophical and theological viewpoints, including the belief in God and God's faithfulness, served as a kind of hospitable environment in which that science could grow up. So it's actually not the case that the scientists of history had to say to themselves "I'm going to become an atheist when I go into the lab." Many of them went into the lab precisely because they were not atheists.

### Moderator
Claim: But I get the sense, though, that the other side is arguing that as science progressed, as the years went by, the more that science developed, and the more that scientists knew, the more tempting atheism became for them because of the volume and because of the discoveries, and because they found inconsistencies. What about that? Do you want to take that, Dinesh D'Souza?

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: They learned-- they knew too much after a while is--

### Scientific Advocate (SA)
Claim: I think there's a presumption that science explains the material world, and science does it with material explanations--

### Moderator
Claim: Just-- do you agree with that? Yes or no?

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: Yes, okay.

### Conspiracy Advocate (CA)
Claim: Physical causes have physical--

### Moderator
Claim: Exactly.

### Moderator
Claim: Okay. Go on, Dinesh.

### Scientific Advocate (SA)
Claim: So it is a presumption of modern science, not a proof, but a presumption that's beyond the material world, there is nothing. So take, for example, the fact that as humans we experience consciousness. We know that there's something in us, consciousness, that can't be reduced simply to materialism.

### Conspiracy Advocate (CA)
Claim: How do you know that?

### Scientific Advocate (SA)
Claim: Hold on a second. No, no. Hold on a second. When you say, how do you know that? You're presuming that it is. Do you agree that the cause of consciousness is not known?

### Conspiracy Advocate (CA)
Claim: The fact that something is not known does not imply it's God. You better not get back on--

### Scientific Advocate (SA)
Claim: Right. But neither-- so consciousness is an immaterial thing that may have a material explanation. And the keyword is "may." And yet you as a scientist believe it does.

### Conspiracy Advocate (CA)
Claim: I don't believe anything. I just want to learn how the world works--

### Scientific Advocate (SA)
Claim: --you just said that all causes are material.

### Conspiracy Advocate (CA)
Claim: I'll wait for the experiments and the theory.

### Scientific Advocate (SA)
Claim: Ah, okay. So in other words, in other words, you're presuming--

### Moderator
Claim: Ah.

Watch out.

### Scientific Advocate (SA)
Claim: I'm simply saying, as a scientist you are closed off to the possibility of nonmaterial explanations. True or false?

### Conspiracy Advocate (CA)
Claim: No. I told you if the stars moved around today, I'd be really thinking there's some intelligence in the universe. There's just never been such an observation. So until there is, I'll assume the reasonable logical thing, since there's never been such an observation, there's unlikely to be one. That's all. As a scientist, I can say what's likely and what's unlikely. I don't believe anything. I can say, is this likely or unlikely. That's all.

### Moderator
Claim: Dinesh.

### Scientific Advocate (SA)
Claim: I think this is very important because throughout your book, you-- this is called ”A Universe from Nothing."

### Conspiracy Advocate (CA)
Claim: Can you hold it up?

### Scientific Advocate (SA)
Claim: I have it right here. I recommend it.

### Moderator
Claim: What's the name of your book?

### Scientific Advocate (SA)
Claim: It's a very useful primer on the limits of science. Here’s why.

### Conspiracy Advocate (CA)
Claim: Absolutely, the universe.

### Scientific Advocate (SA)
Claim: So to quote a sample line, and there are many like this. You say "getting something from nothing." And then you say, "This is how our universe could have arisen." And then you say, "I stress the word could here because we may never have enough empirical information." Next page you say, "These are useful operational efforts to describe how our universe might actually have originated." Here's my point. You're invoking "coulds" and "mights" and "maybes" to provide a refutation. Now, even if you were successful in saying that I have an alternative possibility to God, you haven't refuted God. You've simply given an alternative possibility.

So you have all these qualifications in the book, but then when you step up here, you act as a science that's demonstrated that the universe did in fact come from nothing, whereas you say, it never did. You have not made that demonstration, and you admit it.

### Conspiracy Advocate (CA)
Claim: I was up there, I said it was plausible. And plausible is remarkable because everything that's you've talked about in terms of religion is implausible. So the point is that just like with evolution, a simple plausible assumption appears to work is remarkable and worth celebrating. And so the reason I say "could" and "might" is because I'm honest. And also because I haven't presumed the answer before I asked the question.

### Moderator
Claim: Let's go to some questions from you in the audience. Right, gentleman in the blue shirt. If you could state your name.

### Moderator
Claim: Thank you. My name is Gerry Ohrstrom. And my question is directed to the panelists opposing the motion.

Could you respond to Michael Shermer's assertion that in fact each of you are atheists 999 times over, and your adoption of Christianity is merely a happenstance of the culture in which you grew up. And does that itself not strain the credibility of your faith itself? Could you respond to that?

### Moderator
Claim: Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: Well, first of all, in my case, that is flatly untrue because I was born and raised in India. And the majority of religion of India is Hinduism. The second largest faith are the Muslims. And then you have the Jains and the Sikhs. So from a very young age, the Christianity in which I was born was problematic and had to be measured against other possibilities. But once you begin to study the other religions, you discover something very interesting, and that is that the-- there are shared propositions of the different religions that point to core truths. One scholar described it very well.

It's sort of like you have a mountain, and the top of the mountain, you have God. But no one can see him. And you have little rivers of knowledge pouring down. And some of the waterfalls may begin higher or lower. And you can look at the different religions of human attempts, flawed, to apprehend the same reality. These attempts will disagree on certain particulars, but agree on many fundamentals. So I don't see the other religions as wrong. I see all of us in the human enterprise to try to gain knowledge that seems beyond the reach of the empirical.

### Moderator
Claim: Ian, is your answer complementary?

### Scientific Advocate (SA)
Claim: I completely agree, but I wanted to expand on it just a little bit. And that is to say that it's not a problem for Christians that this-- the idea that there is a universal religious impulse-- which we agree on. I mean, there is basically a universal religious impulse in humans. Because what Christians say is, if there is a god with whom we can have a meaningful relationship, then we would expect precisely that everyone would have such a religious impulse built into them.

And so when we look around and we see different religious view points, we recognize the universality of that. So I don't--

### Moderator
Claim: But you think the other religions have got it wrong?

### Scientific Advocate (SA)
Claim: Well, I mean "got it wrong" seems to me a rather unhelpful way to look at it.

### Moderator
Claim: I mean, it's pretty direct.

### Scientific Advocate (SA)
Claim: Of course-- of course, you know, Christians think that Jesus was the son of God.

### Moderator
Claim: But and the reason I put it that way is I think that your opponents' point and the questioner that he was bringing up is it's an accident of your birth-- particularly in your

### Scientific Advocate (SA)
Claim: You know, it happens not to be the case for me. I didn't grow up in a Christian family. So--

### Moderator
Claim: All right, Michael Shermer.

### Conspiracy Advocate (CA)
Claim: Just to clarify the point just briefly. So you just eloquently described the geography of religious beliefs of India. When Lawrence goes to lecture in India, he doesn't discover that they do physics differently in India. They do physics everywhere around the world the same. There's just one physics. There's not, you know, Indian physics and Australian physics and so forth. There's just one physics. That's the larger point.

### Scientific Advocate (SA)
Claim: You're right. And that's because science limits itself to asking questions of very particular type, to asking how questions rather than why questions and asking questions about the reproducible behavior of the world and so on and so forth. So yes, of course, science is universal, and that's one of the most attractive things about it, and that's why I'm a scientist. But that doesn't mean it has a grip on everything.

### Conspiracy Advocate (CA)
Claim: But it's more than universal. It changes. And I think, you know, Dinesh pointed out that--

### Moderator
Claim: Lawrence

### Conspiracy Advocate (CA)
Claim: --science is wrong. But the fact that we changed our minds makes science-- gives science progress. Different from religion.

### Moderator
Claim: front row here. And if you could stand up, ma'am. Thanks.

### Moderator
Claim: My name is Jane, and I'm an Upper West Sider.

And I find it interesting that we have a debate here about does science refute God. And I-- my question is posed to both sides for and against the motion. I have yet to hear anyone really give us a clear description of what they think God is. We keep throwing around this term "God, God, God."

### Moderator
Claim: Well, this side has made clear-- you don't really need the question to this side, I don't think, unless I misunderstand your question.

### Moderator
Claim: No, I just-- I'm hearing religion. I'm hearing religion, different religions, different beliefs. But I need to hear some kind of opinion or an argument for what your God is. How do you define your God. How do you define your God?

### Moderator
Claim: Let's do it very quickly and

### Scientific Advocate (SA)
Claim: I thought I'd been pretty clear about the god that I was talking about. And I said that it was the god of Christianity.

### Conspiracy Advocate (CA)
Claim: And for me, the god I was talking about, for which there's no evidence, is the fact that there's intelligent, guiding purpose to the universe. That's a vague deism. The-- because that's the most charitable God I can imagine, that obviously the god of the major world's religions is obviously in contradiction with everything we know.

### Moderator
Claim: But that's the god you're saying doesn't exist.

### Conspiracy Advocate (CA)
Claim: That's the god I'm talking about.

### Moderator
Claim: Okay. Let's move on. Sir.

### Moderator
Claim: Hi. Matthew I don't have any particularly exciting qualifications of being here, I'm sorry to report. My question is to Dinesh. And it relates to his point about ancient Hebrews and also his latter reference that we're instilled with some form of morality. So on these guys, the same guys who, for example, thought that it was okay to stone a woman to death, the--

### Moderator
Claim: You know what? I-- I don't want to get into a discussion--

### Moderator
Claim: Well, the point I'm trying to make is, were these the guys we should really have listened to all along in any instance?

### Moderator
Claim: It's really off the topic of the clash I feel between science and God. I-- so I, with respect, want to move on to another question. Sir. Yeah.

### Moderator
Claim: I want to address Mr. Krauss, as far as the likeliness of-- unlikeliness of scientific event. In order to say that the likeliness of universe came in from nothing without intelligent design, you have to throw out the basic laws of conservation. You have to imagine that the universe is infinite, at the beginning, at the very first nanosecond of creation. Isn't it easier and isn't it more likely physically to assume that, that first particle, the mass, the matter, the energy, the intellect is the same as that mass, that energy, the matter, the intellect of the whole universe is?

### Conspiracy Advocate (CA)
Claim: Okay, let me-- I think I can interpret your question. And--

### Moderator
Claim: I need-- if you do--

### Conspiracy Advocate (CA)
Claim: --try and interpret it in a way and if I--

### Moderator
Claim: Can you restate it?

### Conspiracy Advocate (CA)
Claim: And if I misrepresent it, you can tell me, but I think you're trying to say that somehow in the creation of the universe we have to violate conservation laws and we have to assume things that are unreasonable, that the creation of the universe violates the laws of nature.

### Moderator
Claim: No, no, no, no, no, no, no, no.

### Conspiracy Advocate (CA)
Claim: I was trying to make it sensible, but, okay.

### Moderator
Claim: No, what I've just tried to say is--

### Moderator
Claim: Okay, I can give you 10 more seconds to--

### Moderator
Claim: Okay, all I was trying to say is in order to say that it was created from nothing, we have to violate the--

### Conspiracy Advocate (CA)
Claim: Oh, yeah, no, and that's a-- it's a great question. It came from nothing. You appear to have to spout nonsense.

But the amazing thing, the amazing thing, which is what's worth celebrating, is that we've discovered, for example, that you can have a whole universe full of 100 billion galaxies, each containing 100 billion stars and the total energy of the universe can be zero. And, in fact, when we go out and measure the total energy of our universe, it's consistent with zero. You don't have to violate anything to get something from nothing. And that was a surprise to scientists, but it's the case. And it didn't have to be the case.

### Moderator
Claim: All right. I want to move on. And I want to assume again I'm not that smart a guy situation. I just hear we're a big zero just there.

### Conspiracy Advocate (CA)
Claim: Yeah, it's a big zero, we are.

### Moderator
Claim: I don't think I like that very much. Right in the center there, the scarf, please.

### Moderator
Claim: Can you explain the creation of an orchid, and, as scientists, do you believe that you will ever be in a place where you will be able to create an orchid?

### Moderator
Claim: Why do you feel that an orchid-- are you saying that an orchid needs to be a godlike creation?

### Moderator
Claim: I could think-- you know, it's just a simple-- really simple question, and--

### Conspiracy Advocate (CA)
Claim: Well, we have an-- we have good answers to that.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: I mean, the evolution of flowering plants is there in coevolution with insects. There's a reason why orchids and other flowers look like insects, to mimic insects so that the real insects try to mate with them and move the pollen around. And so what we perceive as aesthetically beautiful or so on, of course, looks very different to the eyeball of an insect. It has a different worldview, in that sense, because evolution selected for it to do a certain thing. Otherwise it wouldn't look that way.

### Moderator
Claim: But were you you actually create--

### Moderator
Claim: --I just want to-- were you referring to the beauty of an orchid or just the existence of an orchid?

### Moderator
Claim: The existence getting at

### Conspiracy Advocate (CA)
Claim: Yeah, in fact, actually I would say--

### Moderator
Claim: Lawrence Krauss.

### Conspiracy Advocate (CA)
Claim: And it's scary, and you might not like it, but the universe isn't here so you could like it, no, I mean, I know-- so I'm going to tell you something and I think it's likely. In fact, my friend, Craig Ventor, would create organisms by putting together the appropriate genome of those organisms. And I suspect for better-- hold on-- for better--

### Conspiracy Advocate (CA)
Claim: --for better or worse we'll be able to put together molecule by molecule the genome of something that will reproduce and produce an orchid. We'll have life where there wasn't life before. That is scary, and you might-- and we have to understand what we're doing when we're not yet capable of doing that, but we will be one day, and unless we accept that possibility we won't be able to as a society determine what constraints we should put on ourselves so we have a sense of a policy. But we will do it.

### Moderator
Claim: Need some morality on that one. I want to move on. Right down in front here.

### Moderator
Claim: I'm sorry, would you mind standing up?

### Moderator
Claim: Oh.

### Moderator
Claim: Thanks.

### Moderator
Claim: Hi, I'm Lorelei. So quick question for either side, what would change your mind to go to the reverse?

### Moderator
Claim: What would change your mind?

### Moderator
Claim: Yes.

### Moderator
Claim: How could the other guys convince you?

### Moderator
Claim: What would have to happen.

### Moderator
Claim: I think--

### Conspiracy Advocate (CA)
Claim: A large cash deposit in my name-- a Swiss Bank under my name, $10 million.

### Conspiracy Advocate (CA)
Claim: The same thing that's caused me to change my mind--

### Moderator
Claim: Lawrence Krauss.

### Conspiracy Advocate (CA)
Claim: --all the times I've been wrong. And I've been wrong many more times than Dinesh, I'm sure. A single shred of evidence, that's all.

### Moderator
Claim: Other side.

### Scientific Advocate (SA)
Claim: You know, I'm not even sure I could be persuaded unless we changed the meaning of what science is because coming back to the previous question, how would you measure the beauty of an orchid scientifically? I think, really, science sets itself out, in a way, to fail. And don't forget the motion is "science refutes God," not that, you know, "there is no God," but that science refutes God.

### Conspiracy Advocate (CA)
Claim: Well, in a way we do measure beauty. The marketplace of people that buy flowers, essentially, determine how the breeders create them, based on the ones that most people find really beautiful. There actually is a measurable way for that.

### Moderator
Claim: All right. That was a great question, by the way. Thanks a lot. On this side.

### Moderator
Claim: Hi, my name is Mike. I live on the Upper West side; I'm not from here, obviously. This is a question to Ian and Dinesh. Is there an observed phenomena for which the religious explanation has progressed ahead of the scientific explanation in terms of plausibility?

### Scientific Advocate (SA)
Claim: I'll answer that.

### Moderator
Claim: Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: If you look at the bible, it is not a science manual; it doesn't claim to make scientific proofs. In fact, what's interesting about the bible is it doesn't make proofs at all. The bible doesn't even attempt to prove God; it doesn't try to prove that Jesus is the son of God; it asserts things.

Why? Because for the most part, what the bible is doing is it's in the province of revelation. Now, you'll notice that neither of us have ever in this debate appealed to the bible to support any argument that we made. We have argued on the basis of reason alone. Now, the bible does make certain claims about the world and about man. So, for example, the bible doesn't say that God made man out of nothing, but it does say that God made the universe out of nothing; it says that it made man out of some other stuff. Now, so the Bible says God created the world and God created man, but the bible doesn't say how.

So that's where science comes in. Science can, and the scientific answer often changes, attempt to give explanations that actually don't refute the bible. You could refute the bible by showing that, actually, the universe has always existed and doesn't require any explanation whatsoever.

You could show that God didn't make man out of the clay of the ground, but, as Richard Dawkins said," aliens brought man from outer space." So you can actually refute propositions that are stated in the bible--

### Moderator
Claim: Let me--

### Scientific Advocate (SA)
Claim: --but I think Ian's right that no central proposition has ever been refuted, let alone today.

### Moderator
Claim: Lawrence has had his head in his hand listening to this.

### Conspiracy Advocate (CA)
Claim: Well, I mean, I-- you know, you don't really want to-- you don't really want to go here, Dinesh. So I would say, for example, we refute the bible by arguing that creating day and night before you create the sun is pretty silly.

### Scientific Advocate (SA)
Claim: Well, Lawrence, in that case-- here's the problem: you have a fundamentalist reading of the bible that has--

### Scientific Advocate (SA)
Claim: --hold on-- that maybe-- that is maybe subscribed to by 3 percent of Christians and 100 percent of atheists.

### Conspiracy Advocate (CA)
Claim: But you just gave a fundamentalist-- no, but you just gave-- You just-- that-- why I brought that up, because I thought you were essentially repeating a fundamentalist assertion that, somehow, the bible makes some scientific claims that are substantial. And the whole point is you don't want to go there, because you and I know that a fundamentalist interpretation of the bible leads to nonsense. We both agree about that, right?

### Scientific Advocate (SA)
Claim: We both agree that there are fundamentalist factual claims that are so-called "creation science" that are nonsense. We agree on that.

### Conspiracy Advocate (CA)
Claim: So that-- so that case is science refutes those claims.

### Scientific Advocate (SA)
Claim: Absolutely.

### Conspiracy Advocate (CA)
Claim: Okay. Well you just answered this question.

### Moderator
Claim: We are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, debating this motion: science refutes God. Ian Hutchinson wants to pick up--

### Scientific Advocate (SA)
Claim: Well, I do want to come back and try to answer this question. And the import of that question was that theology as such has made no contribution to human knowledge or development; and that's a claim that Lawrence has made in his book, okay?

### Conspiracy Advocate (CA)
Claim: In the last 500 years or so, yeah.

### Scientific Advocate (SA)
Claim: Yeah, so the last 500 years. And I just want to make one comment on that. If you said-- just as an example, if you think about the Reformation; the Reformation probably brought about the biggest transformation of human learning, knowledge, of the entire recorded history. And what caused the Reformation? Well, I guess Luther. Oh, what was Luther? Hmm, a theologian.

### Scientific Advocate (SA)
Claim: And I can add to this. So right now, when we deal with war, all western war is conducted according to the principles of the just war. That's why, for example, after 9/11, when America was bombing Taliban targets, we were dropping food to feed civilians on the enemy side. Now, where does the idea that you can kill combatants but not civilians come from? Did science teach us that? Nonsense.

### Moderator
Claim: Question

### Scientific Advocate (SA)
Claim: --It comes straight out of Christianity, the principles of the just war that guide the knowledge of how we act today.

### Moderator
Claim: Question over on the far side, please.

### Moderator
Claim: Hi. My name's John. And earlier in the debate, we were talking about how science can prove or establish what is right and wrong. My question for you, Mr. Krauss, is how does science tell us that the publishing of the man before his death went publish-- when pushed in front of the train is right or wrong. Do you understand?

### Conspiracy Advocate (CA)
Claim: Well--

### Moderator
Claim: I don't. So--

### Moderator
Claim: Earlier in the debate we were talking about how science can tell us what is right or wrong.

### Moderator
Claim: Yeah.

### Moderator
Claim: My question for Mr. Krauss is that how can science tell us that the publishing of the picture of the man before his death when pushed in front of a train is right or wrong?

### Conspiracy Advocate (CA)
Claim: I know. Yesterday's--okay, well, you know, we-- we've got to step back for a second. And my point was that--

### Moderator
Claim: Lawrence, is this going to take us in a relevant direction?

### Conspiracy Advocate (CA)
Claim: I think-- I'll try and answer in 10 or 15 seconds. And you can decide.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: The point is--

### Moderator
Claim: I might decide in advance.

Ten seconds.

### Conspiracy Advocate (CA)
Claim: Precognition. The point is that you can't decide what is right or wrong unless you know the consequences of your actions. Science determines the consequences of your actions. So a precursor to determining to what's right or wrong is to know how the world really works.

For example, if you thought the person was pushed on the train would be hit by the train and then get up and walk away, you'd have very different actions. And so that's what I mean by ultimately understanding how the universe works as a precursor to making decisions to making moral decisions.

### Moderator
Claim: Okay. 21 seconds. Sir, right down here. Can you stand up and wait for the microphone, please. You will be our youngest ever questioner. There is no pressure on you whatsoever.

### Moderator
Claim: My name is David. And I'm a student at Collegiate school. And I would like to know, from a-- the side for the motion, whether-- what your stance would be-- or what you would say to somebody that has a spiritual experience, not really--

### Moderator
Claim: Let's let Michael Shermer take that question.

### Conspiracy Advocate (CA)
Claim: Yeah. So we get this a lot. You know, how do you explain this or that? I think people's experiences are real, absolutely. I think most people don't just make up stories, although some do. Most people when they experience what they describe some miraculous, fantastic spiritual experience that they've had, they really mean it.

Now, so the question is, what does it represent? Something out there in the world or something inside the brain? Well, we now know enough about neuroscience to know that the brain does generate a lot of these kind of spiritual experiences, near death experiences, out of body experiences, sense presences, hallucinations, delusions. There's whole books about this. And so the experiences are real. What we want to know as scientists is what do they actually represent. I mean, we know we can replicate these in the lab by doing certain things and causing people's brains to have these experiences. So most likely, the what's more likely question, that it's out there or that it's in here. The overwhelming evidence is that they're in here.

### Moderator
Claim: Good question. And I want to actually take it to the other side. Michael is basically arguing that some of those things that you're talking about it's your brain talking to you but not in the way that you think it is. Dinesh D'Souza.

### Scientific Advocate (SA)
Claim: Well, hallucinations, yes. I mean, if someone said that they saw a UFO, I would say, how do you know? And they might say, well, I was with my buddies. We were sitting outside our trailer park. We were drinking beer. And I would say, well, yeah, I probably won't believe that. But we're talking here about an experience that has been had by perhaps 90 percent of people in the world from the beginning of time. That's a different standard--

### Moderator
Claim: What experience do you mean? Having a sense of spiritual--

### Scientific Advocate (SA)
Claim: Well, having a sense of some experience of God.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: Right? So I would put the likelihood this way. If we went to a village, and there were a hundred people in the village, and 95 of them said that they knew a guy named Bill, and there were 5 percent of the guys who said, nah, and three of them thought that the other 95 were lying or made him up, which is more likely? That there is a Bill and yet 95 percent of people are hallucinating or is it that there is a Bill, and 5 percent just don't know the guy.

The universality of the experience-- the universality of the experience of God puts a heavy burden of proof on the other side to show that the mass of the human race not in some incidental but a central aspect of their lives. Remember, people invest money in religion. They go to church. They leave inheritances. They follow the credos of religion, that they are all hallucinating?

### Moderator
Claim: Who said "wow"? Do you mind turning your "wow" into a question if we bring a mic to you? You don't mind?

### Moderator
Claim: Sorry? Or, you're right, that was just your guffaw. Okay. All right. I would love to So right behind you.

### Conspiracy Advocate (CA)
Claim: The quick answer is that there are Bills, and we've seen Bills.

### Moderator
Claim: Michael Shermer.

### Conspiracy Advocate (CA)
Claim: So the that's different than an invisible God that may or may not exist.

### Conspiracy Advocate (CA)
Claim: And the point is when you say the experience, you mean a personal-- some internal perception that God exists. And-- and the fact that something is maybe relatively universal suggests that we may be programmed to believe in certain things. But it doesn't mean-- because that doesn't mean they exist just because as Michael was talking about earlier, our evolutional history programs us to have certain tendencies.

And there's no doubt-- you'd be crazy to suggest that humans don't have a tendency to be religious. That would violate evidence of reality. So the fact that humans have a tendency to be religious is not-- or a belief in God is not proof that God exists. It's just proof that humans have a tendency.

### Moderator
Claim: Okay.

### Moderator
Claim: Hi. My name is Linda Drum. My question is for this side.

### Moderator
Claim: The side arguing against the motion.

### Moderator
Claim: Yes. We have had many gods as civilization began. They've been taken away as we've been able-- as science has been able to explain something like fire. We had the god of fire, science came along and said, well, it's not really God. You do this. You rub two sticks together, we understand the process behind it, so therefore it's not a god. It's science.

My question to you is this. You keep talking about Christianity. I understand that religion and God are intertwined. But can you separate the two? And if you can, can you say, why is it necessary to believe in God? Aside from religion, why is it important that we believe in God?

### Moderator
Claim: I'm going to pass on the question again because I don't think it moves us on this topic of science. But it was actually a great question. And makes me think we should have a debate on that they topic. Ma'am, right there. All right, yes.

### Moderator
Claim: Hi.

### Moderator
Claim: Just wait for the mic, please. Thanks. Thanks a lot.

### Moderator
Claim: I'm loud, but-- if-- if you-- do you believe that your Christianity is absolute and true, or do you feel that you need to make a leap of faith there? And is a leap of faith scientific?

### Moderator
Claim: Well done.

### Scientific Advocate (SA)
Claim: So can I take this one at least to begin with?

### Moderator
Claim: Ian Hutchinson.

### Scientific Advocate (SA)
Claim: Yes, I think faith is an important topic that we haven't touched on. And humans make decisions on the basis of incomplete evidence all the time during our lives. And it's people who act boldly and with determination and commitment who are the people who, in the end, are most successful in life. They act on the evidence that they have, even though that evidence is incomplete. And that is, as far as I can see, an explanation of what is-- or at least part of what is meant by faith. Faith is that same principle of acting on the evidence we know, even though it's not complete, applied to matters of the spirit.

### Scientific Advocate (SA)
Claim: If I can add a big thought to that, it is-- you ask if its scientific, and I would say no. Faith is not scientific. But faith is completely rational. Why? Because where empirical evidence can't go, it's not unreasonable to believe on faith. Let's say, for example, you're making any kind of a decision, whether to invest in Brazil or whether to propose marriage. You bring in all the evidence you can. And yet if you're asking the question, will I make money? Or what will life be like with this woman over the next 30 years? You're never going to have a full answer. Now, you can say, "I'll be an agnostic and wait for the data to come in." But the data will never come in. She'll marry someone else, and you'll both be dead. So you put in all the knowledge you can, and the leap of faith is a completely rational bridge from knowledge to action.

### Moderator
Claim: Lawrence Krauss.

### Conspiracy Advocate (CA)
Claim: As I said, in science we talk about likely and unlikely. In science, of course, and in life, we do, I agree, make decisions based on incomplete evidence. But the wonderful thing about science, the thing that makes science so much better than religion is our faith is shakable. I am proud of the fact that there's something I can believe with all my heart to be absolutely true and the minute there's a bit of evidence that shows it isn't true, I throw it out like yesterday's newspaper. In fact, that's the one thing I recommend, I hope every student has in their experiences sometime in their life, something that they profoundly believe in to be true based on faith shown to be wrong because that opens their mind. And that's what science does that religion doesn't.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate.

## Round 3

### Moderator
Claim: Where our motion is "Science refutes God." And here's where we are. We are about to hear brief closing statements from each debater in turn. Those statements will be two minutes each.

And, remember, the audience, you voted before the debate, and this is their last chance to change your mind before you vote a second time to pick the winner. On to round three, closing statements. Our motion is, "Science refutes God." And here to summarize his position against this motion, Ian Hutchinson, professor of nuclear science and engineering at MIT.

### Scientific Advocate (SA)
Claim: Although it is incompetent to refute God or religion, science is very important. It's our way of finding out about the regularities of the universe and this amazing natural world in which we live. And I think both sides can agree that we deplore the widespread ignorance of science. And we want Americans of all persuasions to understand science better.

And if you share that viewpoint, then here's why you should vote against this motion. Claiming more for science than is warranted by its competence does not promote science; it damages it. Talking as if science is all the real knowledge there is, that-- as this scientistic motion does, alienates from science people who know better than to accept such an unjustified metaphysical extrapolation. It alienates intellectuals, particularly from other nonscientific disciplines, and so gives rise to the culture wars that have roiled the academy for the last few decades. And it alienates nonintellectuals whose opinions are more intuitive and practical but who know that their life is more than some reductionistic description in terms of atoms and molecules.

People who make aggressive anti-theistic claims on behalf of science are not acting as science's champions; they are bringing it into disrepute. They are confusing science with scientism, perhaps for their own polemic purposes. And they are in the end misrepresenting science to the public, and, therefore, I urge you, whatever may be your religious beliefs, to vote against this erroneous motion.

### Moderator
Claim: Thank you, Ian Hutchinson. Our motion is "science refutes God," and here to speak in support of the motion, Michael Shermer. He is the founding publisher of Skeptic Magazine and a columnist for Scientific American.

### Conspiracy Advocate (CA)
Claim: When I was a Christian and I matriculated at Pepperdine University, I was in what I call the "bubble." I was in the bubble where everybody around you believes. And in that bubble, the Christian worldview like any other worldview is internally consistent. It's inherently logical. It's reinforced by everybody around you until you step outside of the bubble.

What happened with me is I went to graduate school and I started to study social psychology, anthropology, psychology, and beliefs, and so on. And there I realized that none of those arguments actually make sense in and of themselves, the arguments for God's existence. What became clear to me is that what happens is, is you arrive at beliefs for non-rational, non-smart reasons, and then you back into it after the fact with rational reasons to justify it. We call this the "confirmation bias." And so for me I think there's overwhelming evidence that I've given you tonight that there's good anthropological social science reasons why people believe in God that, that doesn't prove there's a god, that it proves that we create gods in our heads. In addition to that, I don't think there's any evidence to support that there actually is a god out there separate from our beliefs.

But finally my final point is this, is that I don't even think it's possible for there to be a God, at least not a supernatural God in this way, if God is supernatural, that is, outside of the space and time, there's no way for us to know it. Therefore, whatever God is, it would have to be a natural being or at least some kind of a being that reaches in to stir the particles, and if he does, then we should be able to measure it, because that's what we do as scientists. We measure the motions of particles. And so far we have no evidence of that. So, therefore, I think that the most we could hope to find would be some kind of a natural being, in which case it would just become part of science, and that would be the end of the whole God concept. So if you agree with me that the evidence points in that direction, that we constructed gods and not vice versa, I would urge you to vote on our side for the proposition that "science refutes God."

### Moderator
Claim: Thank you, Michael Shermer. And that is our motion, "science refutes God." And here to summarize his position against the motion, Dinesh D'Souza; he is the bestselling author of "What's So Great About Christianity?" and he is the director of "2016, Obama's America."

### Scientific Advocate (SA)
Claim: If science refutes God, you'd expect the one person who would know that would be Charles Darwin. Charles Darwin has supplied modern atheism with perhaps the strongest argument against God, evolution. And yet, when Darwin published his evolution theory, the Harvard botanist-- the American botanist Asa Gray wrote Darwin a letter in which he said, "As a Christian, I was very inspired upon reading your book, because I have read in the book of Genesis that God made the world and God made man, but there's no information about how this might've occurred. And when I read your book, I understood not only why God made humans, but why there's so much suffering in the world. Evolution helps to account for the reason why there's suffering both for humans, but also in the animal kingdom."Darwin was so thrilled at receiving this letter that he published it in future editions of "The Origin of Species." So, in other words, for Darwin, what actually caused him to lose his own faith, which he did, had nothing to do with evolution. According to Darwin's biographers, and there are many of them, Darwin lost his faith because he lost one of his daughters, Annie. It was a terrible, unexpected death, and Darwin blamed God for it and turned against God. It was the issue of suffering, not science, that turned Darwin against God.

Now, we're debating here has science refuted God? And at some senses, we've been talking past each other. If I take a pot of water and put it on the stove, what am I trying to do? I'm trying to make a cup of tea. Now, Lawrence Krauss would come along and say that the molecules are heating up, he could give a full scientific account of what's going on, but he would've completely missed the purpose behind what I'm doing. The scientific explanation doesn't refute the purposeful explanation, it coexists alongside it, and so it is with God. Thank you.

### Moderator
Claim: Thank you. Dinesh D'Souza. "Science refutes God" is our motion, and here to summarize his position in support of this motion, Lawrence Krauss. He is a theoretical physicist and director of the Origins Project at Arizona State University.

### Conspiracy Advocate (CA)
Claim: Human beings were clearly programmed by evolution to impute intentionality to the world around them. Meaning and purpose was infused in all everyday events to make sense of a dangerous, difficult, and uncaring world, so we had rituals behind the sun, the moon, the planets, the wind, the earth, the oceans, in all societies. The rise of our physical understanding has slowly caused us to do away with those many gods; we no longer have Mars, the god of war, Poseidon, the Greek god of the sea, Thor, the god of storms. As Michael has said, everyone here, or maybe everyone, is now an atheist with respect to those gods, and there's a reason for that. Science has taught us that instead of capricious beings, there's an order to nature, and that order does not appear to involve a divinity.

There's no need for a divinity; laws of nature describable bymathematics make predictions that allow us to-- not only to predict the future, but control it, without the need for any supernatural shenanigans. And, in fact, it amazes me that asking the question, "Is God necessary?" is somehow an evil thing. When we stop asking questions, that will be an evil thing. Science has taught us also that we want to believe, in the words of Fox Mulder. And we should be skeptical of those desires. As the physicist Richard Feynman told us, the easiest people to fool are ourselves. As scientist, we have to train ourselves to be skeptical of wanting to believe. And we should try and overcome our natural tendency to assume special significance to events. And human being are also inevitably programmed to ask, "Why?" as we've heard it. But the "Why?" question is ill-posed, because it presumes purpose; it presumes the answer to the question before you ask the question.

What if there is no purpose? Does there need to be purpose? And science tells us there's no evidence of purpose. So the "Why?" question is ill-posed. Our opponents want to keep the clock from ticking by avoiding the evidence of reality; and, therefore, science, by telling us there's no need for purpose, has refuted the need for God, and that's why you should support our position.

### Moderator
Claim: Thank you. Lawrence Krauss. And that concludes our closing statements. And now it's time for you to judge which team has voted-- now it's time for you to judge which team has argued best. We're asking you, again, to go to the key pads at your seat that registered your vote, as it did at the beginning. And we're doing to get the read out almost instantaneously. As before, if you are with the motion, for the motion, push number one. If you're against, push number two. And if you're undecided, or became undecided, or remain undecided, push number three.

And we'll keep the voting open for about another 20 seconds, everybody okay with that? Okay, we're going to lock out the voting. Oh, wait, I got somebody-- somebody's still working on it. Indecision is a terrible thing. We're good? Okay. Yeah, okay. All right, first of all-- first of all, I want to thank this panel of debaters for being so energetic, honest, intelligent. They brought it all. Thank you. also want to thank everyone who asked a question. The questions were really terrific tonight. Also, the folks who asked questions and I didn't take them, there's no dishonor in that; I appreciate that you had the courage to get up and do this, so thank you to everybody who got up and asked a question today. The people who have been tweeting, you can keep going. If you want to tweet afterwards, our twitter handle is @IQ2US and the hashtag for this event is #scivgod, that's S-C-I-V-- as in versus-- God, all in one word. So to everybody who enjoyed themselves, we want you to know that we do this every month and it's always this good, although we do all different kinds of topics, but we get very, very smart people up here on the stage to do this, to engage, really, to pay each other the respect of listening to each other's arguments, if only to demolish them, but they do it, they listen. They listen and that' a rare thing, and it lets you have the opportunity of really hearing two sides well-articulated.

So want to talk a little bit, very briefly, about next season. We're going to be back here at the Kaufmann Theater, we'll be debating nuclear Iran; genetic engineering; America's dollar policy, whether we need a strong dollar or not; the future of the Republican Party; and the Food and Drug Administration, where we're going to be looking at the issue of whether the rules that are in place for safety are actually hazardous to the health of Americans. Our first debate is coming up on Wednesday, January 16th. The motion that we're going with is "Israel can live with a nuclear Iran." In support of that motion, James Dobbins; he's a former assistant secretary of state and a special envoy in the Clinton and Bush administrations; he's now a director at RAND. His partner will be Reuben he's a senior military affairs analyst for Haaretz, the Israeli newspaper; he was also once a fighter pilot in the Israeli air force.

Against the motion he's the director of studies at the Institute for Policy and Strategy and a former Israeli intelligence officer. His partner is Jeffrey Goldberg, the award-winning journalist and national correspondent for the Atlantic. All journalists appear to be award-winning-- Said the three-time Emmy award winning-- If you can't-- if you can't be in the audience for that, as you know from your participation tonight, there are a lot of ways that people out there can watch us, and you can, too. You can watch the live stream on FORA.tv or listen to the debates on NPR, here in New York City that's on WNYC. And you can also watch them on WNET, the world digital channel, starting in January, on PBS stations across the nation.

Okay. The results are coming in now. Okay. I just needed to digest. And I want to put my glasses on for this. Okay. So it's all in, I have been given the results. Remember, the team that changes the most minds is declared the victor. And here it is: before the debate, 37 percent agreed with the motion, 34 percent were against, and 29 percent were undecided. So those are the first results. Remember, the team that has the highest percentage change is declared the winner. In the second vote, let's go first to the team that was arguing for the motion. Their number went from 37 percent to 50 percent. That's a 13 percent increase. So the team arguing against the motion has to do better than 13 percent. Let's see how they did. Before the vote, 34 percent, the second vote, 38 percent, that's up 4 percent. It's not enough. The team arguing for the motion, "science refutes God," has won the debate. congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
