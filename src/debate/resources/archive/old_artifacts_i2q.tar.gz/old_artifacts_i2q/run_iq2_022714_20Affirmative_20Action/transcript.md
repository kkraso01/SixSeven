# Debate Transcript

Topic: Affirmative Action On Campus Does More Harm Than Good
Motion: Affirmative Action On Campus Does More Harm Than Good

Debate ID: 022714%20Affirmative%20Action


## Round 1

### Moderator
Claim: So Nick, as I say, it's our first time here. How did this end up happening?

### Moderator
Claim: So I was actually up here speaking at a Federalist Society conference about intellectual diversity in the legal academy. And a student came up and suggested that we bring IQ squared up here. And the more that we thought about it, the more we thought it was actually kind of a perfect fit for the IQ2 mission.

### Moderator
Claim: And why is that?

### Moderator
Claim: Well, so a premise of American law is the same premise as IQ2, which is that the best way to get to truth is to hear zealous advocates on both sides, and so it was sort of a natural affinity between American law and what IQ2 is trying to do.

### Moderator
Claim: Let's talk a little bit about the timing then. I mean, the topic has been around for a long time and has gone through many ups and downs and iterations. Why revisit this topic now?

### Moderator
Claim: So, a couple of reasons, one is there is a pending Supreme Court case called Schuette, and so people are watching that one closely. It will be interesting to see how that turns out. This case suggested that affirmative action might not be just constitutionally permissible but actually constitutionally required. That was sort of like a novel suggestion in the case below. Now the Supreme Court is considering that. Then a second reason is one of our debaters, professor Sander, has just advanced kind of a new argument, which is that affirmative action actually harms the people it's intended to help. And that's quite a controversial argument, obviously, and surely, and certainly not everybody buys it. It will be very interesting to see whether that argument ends up having some traction. So I'll be watching for that in particular.

### Moderator
Claim: All right. So we have a lot of good reasons for this to be happening now, and we have some spectacular debaters.

You know some of them, and you'll meet some others. So let's welcome them to the stage and thank Nick Rosenkranz.

### Moderator
Claim: Thank you.

### Moderator
Claim: Thank you. And as we set many down and launch, I'd just like to ask for one more round of applause for Nick Rosenkranz and for the Intelligence Squared organization for bringing this up here.

We stand now at the half century mark in a social experiment that has involved virtually every American whether or not she or he has wanted to be involved in it: Affirmative action. It was 1965 that President Johnson signed an order instituting affirmative action in government hiring.

The idea was to make things right, to correct the legacy of minorities, and at that time in particular, African-Americans being denied a seat at the table, a remedy that then and ever since has been controversial, but no more so than when it has been applied to the question of who gets accepted into America's elite universities or not. In university admissions, the debate and the argument has been that affirmative action has mostly achieved and is mostly achieving its goals, or that it is not. Well, that sounds like the basis for a debate. So let's have it. Yes or no to this statement: Affirmative action on campus does more harm than good, a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Harvard Law School's Ames Courtroom. We have four superbly qualified debaters, two against two, who will argue for and against this motion: Affirmative action on campus does more harm than good. Our debate goes into three rounds, and then the audience here at the Harvard Law School votes to choose the winner, and only one side wins.

Our motion again, "affirmative action on campus does more harm than good.” Let's meet the team arguing for the motion. Ladies and gentlemen, please let's welcome Gail Heriot.

And, Gail, you are a member of the U.S. Commission on Civil Rights. You are a professor of law at the University of San Diego law school. In 1996, you co--chaired the campaign for proposition 209. That was a California proposition that banned race and gender- based references in Republican education and in state hiring. It passed very famously. But voters may once again get the chance to vote on its key provisions. And my question to you, very briefly, if they are given the chance to vote again, seeing what they've seen now, do you think that voters will uphold it a second time around?

### Conspiracy Advocate (CA)
Claim: I think they will.

### Moderator
Claim: And do you think it's going to be a close call?

### Conspiracy Advocate (CA)
Claim: I hope that it is not close. But direct democracy is a tricky business. You never know.

### Moderator
Claim: All right. Ladies and gentlemen, Gail Heriot. Thank you. Gail, your partner is?

### Conspiracy Advocate (CA)
Claim: My partner is the very talented economist Rick Sander.

### Moderator
Claim: Ladies and gentlemen, Rick Sander.

Rick, welcome. You are also arguing for this motion: Affirmative action on campus does more harm than good. You are professor of law at UCLA. And in 2004, you published a controversial study that asserts that black law students are actually hurt by affirmative action. And to test out this theory, you filed a request for the records of the State Bar of California because you wanted their data on race and grades and test scores. But they wouldn't give it to you, so you had to sue for its release. The California Supreme Court said yes in 2013. So have you seen the data?

### Conspiracy Advocate (CA)
Claim: Not quite yet. The court said that there is a public right for academics or anyone in the public to seek this data. But they also said that there have to be privacy safeguards with that, and we're still trying to work those out.

### Moderator
Claim: Timeline on this?

### Conspiracy Advocate (CA)
Claim: I'd say between one month and seven years.

### Moderator
Claim: All right. Thank you.

### Conspiracy Advocate (CA)
Claim: We a proposal to the bar.

### Moderator
Claim: Thank you, Rick Sander. That's the team arguing for the motion. And now the team arguing against the motion: Affirmative action on campus does more harm than good. We have two debaters arguing. First let's please welcome Randall Kennedy.

Randall Kennedy, this is a hometown crowd for you. You are the Michael R. Klein professor of law at the Harvard Law School. You are the author of six books, including "Sellout: The Politics of Racial Betrayal.” You're the author of a book with the N word in the title.

And most recently, you are the author of "For Discrimination: Race, Affirmative Action and the Law.” You've been described as being something of an iconoclast. And it's been said that your classroom, like your books, can be contentious. So is it your intent to push people's buttons?

### Scientific Advocate (SA)
Claim: Sometimes.

### Moderator
Claim: How about tonight?

### Scientific Advocate (SA)
Claim: No.

### Moderator
Claim: No, okay. And your partner is, Randall Kennedy?

### Scientific Advocate (SA)
Claim: My partner is Ted Shaw of the Columbia University Law School.

### Moderator
Claim: Ladies and gentlemen, Ted Shaw.

And, Ted, you're also arguing against the motion that affirmative action on campus does more harm than good. You are professor at the Columbia Law School. You've been involved in two landmark Supreme Court affirmative action cases. You played a key role in drafting the admissions policy upheld in-- upheld in Grutter vs. Bollinger . You were lead counsel for Black and Latino intervenors in Gratz vs. Bollinger. And in 2003, writing for the majority in Gruder.

Back then Justice O'Connor on the Supreme Court had predicted that 25 years from now racial preferences would no longer be needed. That would put us 14 years away now. So, Ted, is that possible?

### Scientific Advocate (SA)
Claim: Well, I always wondered where that number came from. But in any event, after Justice O'Connor left the bench, she and one of her former clerks authored an article which-- in which she repudiated that statement.

### Moderator
Claim: So the 25 years is off.

### Scientific Advocate (SA)
Claim: Well, I'm not sure it was ever on. It was always dicta anyway. But she doesn't believe in it any more.

### Moderator
Claim: All right. Ladies and gentlemen, Ted Shaw. And thank you, Ted Shaw.

Our motion is, affirmative action on campus does more harm than good. And in this debate, there will be a winner and a loser. You, our live audience at the Harvard Law School, will have the chance to choose our winners by voting twice; once before you hear the debate and the arguments and once again afterwards. And the team whose numbers have changed the most will be declared our winner.

Let me turn off my phone. And while I'm doing that, Randy, I just wanted to say, I think you should pull up-- just for the sake of the microphone, to pull up to the table. That distance is great. So you helped me cover my phone faux pas. Thank you. So let's get onto the first round of voting. The motion is this: Affirmative action on campus does more harm than good. If you go to the key pads at your seat, we want you to tell us now where you stand on this motion. Push number 1 if you agree with this motion, push number 2 if you disagree, and push number 3 if you are undecided. If you push the wrong button, just correct yourself. The system will lock in your last vote. And the other keys are not live. And remember, you're going to vote a second time. And the team whose numbers have moved the most in percentage point terms will be declared our winner.

So our motion is "affirmative action on campus does more harm than good.” Let's start with round one. Round one, opening statements by each debater in turn. They will be six minutes each. Gail, you can step to the lecturn. And up first to argue for this motion, "Affirmative action on campus does more harm than good," Gail Heriot, a professor of law at the University of San Diego and a member of the U.S. Commission on Civil Rights. Ladies and gentlemen, Gail Heriot.

### Conspiracy Advocate (CA)
Claim: Thank you. Good evening, ladies and gentlemen. Rick and I are here to make a very narrow point, race preferential admissions policies are doing far more harm than good. The very large preferences that are now routinely employed by colleges and universities produce fewer, not more, black scientists, black engineers, and black medical doctors. They produce fewer black college professors and very likely fewer black lawyers.

We are talking epic policy failure. Before I get too far, let me say that we are not here to argue against outreach, outreach is not the source of the problem, nor are we here to argue that colleges and universities should consider only academic indicators like the SAT in evaluating applicants. There are lots of ways to measure talent, though I would say that race is not one of them. But let me get back to my main point. Race preferential policies don't work. How can that be? How can giving minorities a friendly leg up produce fewer minority professionals? Well, let me explain. One consequence of widespread race preferential policies is that underrepresented minorities end up distributed among colleges and universities in patterns very different from their white and asian counterparts. When the highest school on the academic ladder relaxes academic standards in order to admit more minority students, the schools one rung down must do the same if they are to get minority students.

The problem is thus passed down to the third rung on the ladder, which responds similarly. As a result, underrepresented minority students are concentrated at the bottom of most selective schools. The problem is not that there are no academically gifted minority students, but there are not currently enough at the very top tiers to satisfy the demand. And efforts to remedy that problem end up causing credentials gaps up and down the pecking order.

For example, we learned in connection with the University of Michigan Supreme Court litigation a decade ago that Michigan granted preferences to underrepresented minority students equivalent to an entire letter grade. That is, African-American and Hispanic students with a straight B, 3.0, average were treated the same as Asian and white students with a straight A, 4.0, grade point average, all other things being equal.

This is no tiebreaker in otherwise close cases. The preferences are very large, and since 2003 they've gotten larger. The problem is that entering credentials matter. Students whose academic credentials are well below the average for the college and university they are attending will usually earn grades that are similar, while some students outperform their entering credentials, just as some students underperform theirs. Most students will perform in the general range that their academic credentials suggest, and anyone who thinks otherwise is engaging in wishful thinking at student expense. No serious supporter of affirmative action denies this. The strongest evidence of backfire comes from science and engineering. Contrary to what some people think, college bound African-American and Hispanic students are just as interested as white students in majoring in science and engineering, actually a little more so, the numbers suggest.

But these are difficult majors and many students of all races abandon that ambition. African-American and Hispanic students jump ship at much, much higher rates than do whites. It's not surprising that those students, again, of any race, who give up on science and engineering disproportionately have lower entering academic credentials. But what some do find surprising and what is key to the argument that we're making this evening is that four in-depth published studies by researchers at Dartmouth, the University of Virginia, and Duke, among others, and also one unpublished study so far by Rick, here, all demonstrate that part of the effect is relative.

An aspiring science major who attends a school where she's in the middle or towards the top of her class in entering credentials is much more likely to persevere and ultimately succeed than is an otherwise identical student, same entering academic credentials, who attends a school where her academic credentials put her towards the bottom of the class. Put differently, preferences hurt, they don't help. The difference is not trivial, ladies and gentlemen. We would have a lot more science and engineering minority students graduating with that degree if we engaged in race-neutral admissions policies-- or at least did not give so great a preference to students. A similar study by Stephen Cole and Elinor Barber shows that minority students who attend colleges, whether entering credentials put them at the bottom of the class-- do not aspire to go on to graduate school and to become college professors in the same numbers as their identical-- identically credentialed minority counterparts who are attending somewhat less elite schools. And the reason should be obvious. Students who get good grades in school tend to like school, in part because they correctly note that they're good at it.

None of the results in any of these studies have been controversial. No one has rebutted any of it. The only mismatched study that's received any kind of criticism is Rick's initial study of law school management-- law school mismatch, where data is hard to come by. But some of the very same people who criticized that study are the ones who are actively trying to prevent him from getting more, better data.

That speaks volumes.

### Moderator
Claim: Gail Heriot, I'm sorry, your time is up. And thank you very much.

### Conspiracy Advocate (CA)
Claim: That speaks volumes.

### Moderator
Claim: Thank you, Gail Heriot. Our motion is Affirmative Action on Campus Does More Harm Than Good. And our next debater is going to speak against this motion. He's Randall Kennedy, the Michael R. Klein Professor of Law at Harvard Law School and author of the book "For Discrimination: Race, Affirmative Action, and the Law.” Ladies and gentlemen, Randall Kennedy.

### Scientific Advocate (SA)
Claim: I disagree with the proposition and ask that you vote against it.

I will argue that affirmative action advances key valuable goals of most institutions of higher education in America. My partner, Theodore Shaw, will address some of the charges made against affirmative action, such as the claim that it hurts its intended beneficiaries. Let's be clear about what we defend. We defend conscious efforts to ensure the presence on our campuses of students affiliated with groups that, in the absence of special efforts, would be excluded or consigned to a negligible, isolating status. We do not feel obligated to defend all affirmative action programs across the United States. We do not support stupid affirmative action. But we do support the sensible affirmative action that has been the characteristic sort practiced on campuses across much of AmericaIncluding admissions policies, that, under certain circumstances, select certain candidates over others with superior conventional credentials, such as standardized test scores and grades. Educational institutions have a wide array of goals that are advanced by affirmative action. All seek to create excellent environments for teaching and learning. Their leaders insist that racial and other sorts of diversity are essential to realizing the pedagogical mission that they envision. They maintain that racial diversity acquaints students with unfamiliar perspectives and sentiments, and that it assists in preparing students for an increasingly cosmopolitan country and demand world. This belief is held not only by academic administrators.

It is also held by the executives who head many of the nation's leading business firms, the executives who submitted amicus curiae briefs to the Supreme Court several years ago in which they strenuously argued in favor of affirmative action programs on campus and convinced the court, in the words of Justice Sandra Day O'Connor, that the educational benefits of diversity are not merely theoretical, but real. Some educational institutions see it as part of their mission to do what they reasonably can to assist and rectifying past racial wrongs, aware that mere cessation of invidious racial discrimination will often fail to undo the lingering effects of oppression in the past. These institutions engage in affirmative action to assist racial minority candidates who, though qualified in absolute terms, might otherwise lose out in competition for admission with those advantaged by racial or other sorts of illicit, but deeply entrenched privilege.

Some educational institutions see it as part of their mission to correct or offset invidious discrimination that constitutes an invisible headwind that impedes racial minorities, women and others who still face pervasive societal bias. These institutions make special efforts to identify talent, that in the absence of affirmative action would go unrecognized or underappreciated.

These programs have served to encourage students and prospective students who might otherwise have been discouraged, mistakenly believing that the monopolies of the past were unchangeable. You will hear much from our adversaries about the supposedly dysfunctional side of affirmative action. I urge you to keep in mind that affirmative action has supplied a tremendous incentive that has prompted thousands to elevate their sights and pursue ambitions that they would not have otherwise pursued. This point strikes home with me with special force because I am one among those many thousands. Some educational institutions see it as part of their mission to facilitate racial integration. They seek to do this for the purpose of making it conspicuously evident that pathways to leadership and upward mobility are accessible to all. One group that has pressed this point with notable vigor are leaders of the armed forces.

They have repeatedly argued that racial diversity in the officer corps of the military is essential as a matter of national security and that at present, the military cannot achieve an officer corps that is both excellent and racially diverse unless the service academies use race conscious recruiting and admissions policies. That affirmative action supports the educational missions of institutions of higher education, that it supports their ambition to assist with the task of correcting past and present injustices, that it facilitates racial, gender, class and other sorts of needed integration is more than enough to justify its continuation. Please join with me in supporting affirmative action. Please vote against the proposition that it does more harm than good. Thank you.

### Moderator
Claim: Thank you, Randall Kennedy. And a reminder of where we are.

We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two fighting it out over there motion: Affirmative action on campus does more harm than good. You have herald the first two opening statements and now onto the third. Debating for this motion that affirmative action on campus does more harm than good, let's introduce Richard Sander. He is a professor of law at UCLA school of law and co-author of the book "Mismatch: How Affirmative Action Hurts Students It's Intended to Help, and Why Universities Won't Admit It.” Ladies and gentlemen, Richard Sander.

### Conspiracy Advocate (CA)
Claim: Thanks very much, John. So you've been told that truth is going to emerge from vigorous, zealous advocacy on both sides. And at my peril, I'm going to depart from that a little bit to try to suggest a little bit of a nuance because it seems to me that when we pose the question as an empirical one, is it doing more harm than good, rather than a moral one, is affirmative action right or wrong, we sort of take on the hats of social scientists.

And if we're going to approach it scientifically, we need to be candid about certain things. So let me try to introduce some candor. Let's compare law school and medical school. Now, we're going to get more into the Q and A about the actual merits of law school mismatch, but assume that I might, for the moment, that if you compare two students who go to different law schools, one with large preferences to one without, the one who receives large preferences is two or three times more likely to fail the Bar exam. That event happens after the student has graduated from law school. And students who fail the bar, as one scholar put it, "Are marooned.” The law school is no longer interested in their fate, and they've kind of given up on them as alumni contributors. Let's compare that with medical school. Medical school, there's also something like the Bar exam. It's called the National Boards. That's taken halfway through medical school, up to the second year. If a student fails the National Boards, then at many medical schools, they're put in an academic support program.

There's an effort to try to remediate and to try to help that student succeed. And there's some evidence that that works. So that means that affirmative action might be beneficial if we sort of provide the right institutional support to go with it. That generally is lacking. So that's one reason why, on balance, I think there's a harm. Another example is when we think about science mismatch, as Gail brought up. As she said, there are now four peer reviewed studies that show very clearly that if you receive a large preference into a college or university, you're 50 to 75 percent more likely to drop out of your science career on your way to getting a BA. And frequently, people drop out of college altogether. That has been shown to happen when you have a very large preference. What we don't know enough about, because we don't have enough data yet, is what happens with the small preference. Suppose the size of the preference is not equal to 300 SAT points, but the equivalent of 50 SAT points.

It's possible that smaller preferences don't cause that much of a mismatch effect and that the other positive effects of affirmative action like having a more challenging atmosphere and having peers who are really talented might outweigh. So I think we need to admit that there are tradeoffs. There are balances. We're not talking about something that's completely good or completely bad. It's a mixture.

So why do I think that, on balance, you should vote for the proposition? First of all, there's no longer any reasonable doubt that very large preferences have negative consequences. That's now been shown in about 20 different peer-reviewed studies by over 20 different academics. And when Ted presents rebuttals in his next remark, listen carefully for when he cites peer-reviewed published studies because those are the things that we're going to care about. We're going to care about studies that have gone through a process of actually being evaluated by other scholars and have been published in a reputable scholarly journal.

That research overwhelmingly shows direct negative effects from large-scale preferences. And when I say, "Large," I mean really large. The typical beneficiary of a preference-- well, the typical African-American student at an American law school has credentials that put them at below 99 percent of the white students. So the median black student has lower credentials than 99 percent of the Anglo and Asian students. That's a large preference.

Second, there have been a host of carefully done studies that have shown other sorts of really troubling side effects of affirmative action. For example, when the University of California implemented race-neutral policies after Prop 209, we saw this really interesting jump in the takeup rate by black and Hispanic students admitted to Berkeley and UCLA and some of the other elite campuses. Now, why would the enrollment rate of accepted students jump? We'd like to know more about that.

But a plausible explanation is that these students found it really attractive to attend a school where neither they nor anyone else thinks that they were admitted with a racial preference. So think about the implications of that.

Third, colleges and universities are locked into a pattern of institutional dishonesty. I don't think college leaders are intrinsically dishonest people, but the prevailing ideology of affirmative action makes it difficult and even hazardous for them to speak out about these issues or to really look at the effect and critically examine the effect of the programs that they're operating. To show this, consider the fact that the U.S. Commission on Civil Rights, on which Gail now sits-- I think at least one of these reports came before Gail was on the commission--two reports to the commission have shown significant mismatch effects and have raised very troubling issues about it. Neither of these reports has ever been acknowledged by a higher education leader in America.

There have been no task forces appointed. There's been no investigations undertaken. The reports have simply been ignored.

There's a pattern of institutional unwillingness to deal with uncomfortable facts. That suggests that there's a need for reform. Finally, we have almost no transparency about what goes non-higher education. Schools do not provide information, unless they're forced to, about their actual admissions practices. They don't provide information about outcomes. When data comes out, it's either because of a lawsuit or because someone trusted as a reliable insider decides to write about the problem. That's what I did when I got access to data on how law school preferences actually worked. So we had this pattern of problems that suggest a crying need for reform. That's why I urge you to support the opposition.

### Moderator
Claim: Thank you, Rick Sander.

Our motion is "affirmative action on campus does more harm than good.” And here to speak against this motion, Ted Shaw. He's a professor of professional practice in law at Columbia Law School. And he's former director, counsel and president of the NAACP Legal Defense and Educational Fund. Ladies and gentlemen, Ted Shaw.

### Scientific Advocate (SA)
Claim: Thank you. I urge you to vote against the proposition that affirmative action does more harm than good on campus. First, let us define what affirmative action is. It is a conscious attempt, a conscious attempt, to admit students from groups that have been underrepresented to campuses and universities at selective institutions, we can talk about preferences. We can use a lot of loaded terms, but that is the essence of affirmative action. We talk about harm. What kind of harm are we talking about and to whom?

This discussion has proceeded-- this debate has proceeded focusing almost exclusively on African-American students on campus, which echoes the reality-- the continuing reality in our country, which is that most of the heat when it comes to issues of race is felt along that traditional black-white line even while the country has always been multiracial and diverse. There's lots of affirmative action that has existed and continues to exist in our colleges and universities quite aside from the issues of race impacting African-Americans. Of course, historically there was a great deal of affirmative action in this country for white males. Even today, although almost no one talks about it, there is affirmative action for males generally because women in many instances are outperforming men academically.

And colleges and universities concerned about having gender balance on campuses have quietly placed a thumb on the scale when it comes to male applicants. There are differences between performances on standardized tests and in GPA for that matter among ethnic and racial groups that we don't talk about a whole lot. Generally speaking, white students are being outperformed by Asian and Asian-American students on standardized tests. Does that mean that white students who are not admitted to institutions of higher education because they-- or they should not be admitted, rather, because they are being outperformed? No.

Colleges and universities don't simply take students in rank order and admit them solely on the basis of test scores and GPA. No one talks about stigma being visited upon women who have been beneficiaries of conscious efforts to open up opportunities in higher education. No one talks about stigma being visited upon white students who may have lower GPAs than Asian-American students or lower test scores. The only stigma conversation is the stigma with respect to African-Americans, people of color but particularly African-Americans. And I submit to you that that fact reflects that we continue to struggle even in 2014 with the age-old rumors of intellectual inferiority of African-Americans.

Some people won't say it, but I submit that those rumors persist. Now, there are tremendous differences between students who are educated in poverty impacted inner city urban high schools and students who attend privileged high schools. So it's important for us to understand that affirmative action, when it is done correctly-- and as my colleague, Professor Kennedy, indicated, we don't support what he calls "stupid affirmative action," there are instances in which it hasn't been done correctly, and I'd be glad to talk about those instances-- but when it's done correctly, what we're talking about is choosing among qualified students. And the question isn't whether or not or it is solely a question of whether or not students all have the same credentials.

The question is whether or not institutions can choose among qualified students, so this shouldn't be a surprise that African-American students who attend schools that are academically challenged may not have the same criteria, nor should it be a surprise that given a long history in this country in which even today, right now as we stand here, nine out of 10 days of African-American presence in what's now the United States has been spent under Jim Crow, segregation or slavery-- shouldn't be surprised that there are still differences that we're struggling to overcome. So, mismatch theory, stigmatization-- I often think about the fact that, like Professor Kennedy, I am unapologetically a beneficiary of affirmative action. Would I have felt more comfortable in the public housing project-- I grew up in the Bronx-- knowing that I didn't get the benefit of affirmative action, but I had my integrity intact? I don't think so.

## Round 2

### Moderator
Claim: Ted Shaw. Thank you very much. And that concludes Round 1 of this Intelligence Squared U.S. debate, where our motion is "Affirmative Action on Campus Does More Harm Than Good.” Now we move on to Round 2. And in Round 2, the debaters address one another directly, and they take questions from me and you-- from you in our live audience. We have heard arguments from both sides.

Now, the side arguing for this motion: Affirmative Action on Campus Does More Harm Than Good, Gail Heriot and Richard Sander. First of all, they told us what they're not arguing. They're not arguing that all forms of affirmative action are not-- are doing more harm than good. They're fine with things like outreach. But it's the mechanism, they say, of racial preferences, that they call "misbegotten.” They argue that it backfires and hurts those that it is meant to help, that minority students can find themselves boosted into an academic pool in which they're in over their heads, and that they fail-- therefore, that they become discouraged.

And that if they fail, it means that racial preferences, as a tool, have failed. Although they say that universities do not want to admit this-- and will not share the data on this.

The side arguing against the motion, Randall Kennedy and Theodore Shaw, they did not directly address the argument put forward by the other side, but they're taking another crack at this. They're basically telling you that affirmative action has done more good than harm. They're saying that the case for good comes from not only the impact of affirmative action on a wider student body of the experience of greater diversity, but that, also, in the sense that symbolism of affirmative action, in itself, encourages people who might never have attempted to get into an academic-- high academic setting-- to reach for something they may not have believed in before. They argue that this struggle is not over, that the issues and the deficits-- social and economic deficits that affirmative action were meant to address linger on today.

So, those are basically the two arguments in there. I want to work through and revisit some of all of this, but work through a little bit, step by step, and take to the side that's arguing against this motion-- since you did not address the main point that your opponents made-- the mechanism by which they say that affirmative action and large-- large preferences-- actually, I'd like to ask you one more time to define what you mean by "large preferences," Gail. You said we would be graduating more engineers and more scientists from minority groups, except that we're not, because we're giving them such a great preference. What is a great preference?

### Conspiracy Advocate (CA)
Claim: Well, I think the example from the University of Michigan is a good one. That was an entire letter grade on the GPA-- or alternatively, 300 points on the combined SAT.

### Moderator
Claim: Okay. So, I just want to make sure that we all know what it is we're talking about and what this disagreement is-- might be about on this issue. So, I want to go to the other side-- maybe take it to Randall Kennedy. So, your opponents are arguing that there's this-- there's this dynamic by which a minority student who is not-- who is not as academically prepared-- perhaps as measured by SAT scores or GPA, or this high school of his origin, shows up in a place where he's up against some tough competition, and it kind of breaks him, breaks his spirit.

He drops out. He changes out of the sciences. He never graduates whatever it is. That that's a dynamic-- that that you can see the psychological rationale that's being put forward there. I don't know if you want to take that on, or the numbers, or what, but if you could respond do it.

### Scientific Advocate (SA)
Claim: Sure. I'd be happy to respond. And there are a couple of responses. First, my adversaries make reference to studies that posit the mismatch thesis, which has been posited for a long time. Maybe there's something to it. In fact, I think in some instances, there are. We should not accept this, however, as an uncontroversial proposition. The fact of the matter is that there are people who have studied the same phenomena that disagree very much with Professor Sander and others who have made the sort of claims that you've heard.

You've heard the claim, for instance, that affirmative action actually decreases the numbers of black lawyers. There are other people who have studied the data and have come to a very different conclusion. So, the empirical situation is itself-- you know, it's controversial. It's not clearcut.

Furthermore, I'm willing to stipulate, for the sake of argument--I'm willing to stipulate that what they say is true. So let's stipulate that. I'll give them that. Then the question becomes, what of it? My opponents have a certain strange solicitude.

They want to save the-- they want to save African American and Latino students from getting the invitation to selective institutions. No one is forcing anyone to attend these institutions. If they don't want to go, they don't have to go. So-- but I think that there are-- but why would we not allow people the opportunity to advance themselves if they, you know, so desire and if these institutions believe that it is in their interest, their institutional interests, to invite these students to come?

### Moderator
Claim: Let me take that to-- who would like to take that?

### Conspiracy Advocate (CA)
Claim: I'll take it.

### Moderator
Claim: Okay, Rick Sander.

### Conspiracy Advocate (CA)
Claim: So we may be able to resolve this debate and just come to agreement. I will agree with Randall that I withdraw all my objections to affirmative action if colleges and universities will adopt the following practice: When they accept someone for admission, they also provide a detailed statement of how that student's credentials predict their performance. If they're an engineering applicant, tell them the chances, tell them the past record of students with identical credentials who have actually achieved an engineering degree at that school. If they want to go to law school, tell them, what are the chances that a student with their credentials has passed the bar on the first attempt and what their GPA has been on average. If that information is provided, then you're right, all that affirmative action is doing is increasing the range of opportunities. What's wrong with that? The problem is the schools don't do that. They do not provide transparent. They actually actively counter measure. They actively conceal. They won't disclose data on what they're doing. They tell students that everyone has the same chance of success.

Everyone is equally qualified and will have the same outcomes. These things are manifestly not true. So students are accepting offers based on dramatic information-- misinformation.

### Moderator
Claim: Bring it to--

### Conspiracy Advocate (CA)
Claim: And you don't have to take my word for it. There was actually a study done at Duke where a professor looked at the information that the university had internally and went to students and said, okay, if you have this information, what would your enrollment decision be? And they made different decisions.

### Moderator
Claim: Ted Shaw.

### Scientific Advocate (SA)
Claim: Well, first, I invite you all to look at studies that have been done by Richard A. Burke of University of Pennsylvania, David E. Ho of Stanford University, Richard Brooks, later of Yale but now at Columbia Law School, and other studies, many other studies. Look at Claude Steele's stereotype threadwork.

These propositions that our adversaries have articulated today are challenged. They are very much being contested. But even if we acknowledge, as we must, that there is a gap between performance on standardized tests, does that acknowledgment then lead us inevitably to the answer that affirmative action is doing more harm on campus than good? You know, the issue of presence of students of color who have been underrepresented and excluded from these institutions until there were conscious efforts to admit them is much bigger than test scores. We're talking about the integration of campuses. We're talking about equal opportunity on campuses. And if we want to look to evidence, look to the President of the United States, the attorney general, the CEO of American Express.

Look to the two Supreme Court justices who are at-- one African-American, one Latina. Look to African-Americans, look to Latinos who are graduated within the last couple of generations from selective institutions, including this one. And there's massive evidence of the success of what we call affirmative action.

### Moderator
Claim: All right. Let's take that point to Gail Heriot.

### Conspiracy Advocate (CA)
Claim: Well, first of all, no one has ever rebutted the studies that I cited, not anyone. The only report that's actually been taken on by some of the scholars is Rick's, as I said. And again, some of those same scholars are the ones who basically said the database isn't good enough and then tried to prevent him from getting access to the California database. As I said, that really speaks volumes. And, sure, there are plenty of people who have benefited in some way. I don't know whether any of the people that you listed are among them because I don't know what the counter factual is.

I suspect that you and Randall would have been very successful even without preferences, assuming that you got preferences. And I don't know that. One interesting thing is that there's one bit of evidence from--

### Moderator
Claim: Let me just stop you. In 1950, these guys would have done as well as they have done in 1980, 1990, 2000? Is that-- if there were racial preferences in any-- in their lives?

### Conspiracy Advocate (CA)
Claim: They claim to be the beneficiaries of racial preferences. If that's so, it may well be that they--

### Moderator
Claim: But are you saying that they would have-- I think-- I just want to clarify. You're saying in the absence of racial preferences that they would have done as well. I just-- okay.

### Conspiracy Advocate (CA)
Claim: Yeah, they may have.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: And my point I was making earlier. One kind of interesting shred of evidence here-- and I-- it's just a shred, but I find it rather interesting. First lady Michelle Obama actually did a senior thesis on the issue of how blacks at Princeton integrate into society.

And one of the things that she found, she polled, I believe it was, 400 black alumni at Princeton. Her response rate was really not-- not very high, so I'm not claiming this is a very scientific report, but it's interesting. She actually found that before Princeton and after Princeton-- that was her comparison-- that black students felt that they were just as comfortable with whites on athletic basis, I believe on several social bases. When it came to comfort with-- with whites on an academic basis, they actually became less comfortable after Princeton than what they were before, which was an interesting result.

### Moderator
Claim: Ted Shaw or Randy, if you have-- Randy hasn't had a shot in the bit, so if you'd like to speak, or you can pass all.

### Scientific Advocate (SA)
Claim: Go ahead.

### Moderator
Claim: Ted Shaw.

### Scientific Advocate (SA)
Claim: Well, a couple of things, one, Gail, I-- it's a wonderful thing if nobody's ever rebutted you. That seems to me to be different from what my experience in academia is generally with studies, but I'll check it out.

### Conspiracy Advocate (CA)
Claim: Not rebutted me, but the studies, the studies.

### Scientific Advocate (SA)
Claim: More importantly, though, to be clear, I didn't claim to be the beneficiary of preferences. That's a loaded term. Use that term, the debate is over. I claim to be a beneficiary of affirmative action, and I restate that. I am, unapologetically, the light of opportunity did not shine in neighborhoods like the one I came from, in areas like the area I came from until people consciously took action to do it. It didn't happen serendipitously. And it doesn't mean that I or people like me are not qualified. So I appreciate you saying I would have made it anyway. I don't-- I don't accept that. I mean, I'd like to think that maybe it was true.

But the fact is that what that does is obscure the structural inequality that has existed in our country and that's built into our country. And we still have not rid ourselves of that structural inequality.

### Moderator
Claim: Rick Sander, do you want to respond, or would you like to move to another question?

### Conspiracy Advocate (CA)
Claim: Well, I would just say, if you look at the debate on law school mismatch, which, as Gail says, has been the most contested one, it's interesting. I mean, I published my initial study. The data was limited. My analytical abilities were probably limited. There were about 20 critical studies published in response. But none of these were published in peer-reviewed journals. A debate was joined, new articles came out. If you look at the - - sorry, where the dust has settled eight years later, there are now four peer-reviewed studies that have been published that all find strong evidence of law school mismatch. They all find roughly the disparity in chances caused by large preferences that I mentioned before.

There have been zero studies, zero peer-reviewed studies published on the other side. And the most recent critique was actually withdrawn when the author admitted that her results cannot be replicated. So if you look closely at this, you see a pretty overwhelming pattern.

Now, I would slightly modify Gail's statement that there are many good studies that say that preferences can have net positive effects. But when those studies are examined, they're generally focusing on secondary outcomes like graduation rates. The things that we're talking about with mismatch are things like learning, competition, grades, attrition from a science track and so on, things that are directly related to mismatch. Graduation rates, for example, are more manipulable by university policies. A law school or college can decide they want to get their graduation rate up to 97 percent.

So if you look at some secondary outcomes, I think the debate is more mixed, but it really is overwhelming how on the literature of primary mismatch effects, it's essentially undisputed.

### Moderator
Claim: Randy Kennedy.

### Scientific Advocate (SA)
Claim: First, you know, the proposition was affirmative action on campus does more harm than good, 99 percent of the discussion has been about racial affirmative action. Of course, affirmative action's broader than that. Women have certainly-- including white women, have been beneficiaries of affirmative action. It's interesting that that doesn't seem to factor very much into the discussion. I would like very much to take Professor Sander up on his comment about how he would withdraw his objections if more information was presented about, you know, what happens with a student with this background getting into the school. I take you up on that.

Now, in taking you up on that, which you have implicitly said I take it, is that actually with more information you are fine with affirmative action. And, in fact, in your comments you said over and over again, you're not really so much against affirmative action, you're just against excessive affirmative action. Audience, I want you to be very attentive-- I want you to be very attentive to the disjunction within the side of my adversaries, because one speaker is totally against affirmative action and speaks in terms of laissez-faire, you know, "Let the chips fall where they may--" of course, we know where the chips will fall-- that is one speaker, that seems to be Gail's position--

### Conspiracy Advocate (CA)
Claim: No, I--

### Scientific Advocate (SA)
Claim: Gail's position-- Gail's position seems to be, "Let the chips fall where they may. No-- let's not have race be involved at all.” Professor Sander's position seems to be considerably different.

His is more of, "Well, there's too much affirmative action.” His is a tweaking position.

### Moderator
Claim: All right. Let me stop you because Gail objects to your characterization of her position.

### Conspiracy Advocate (CA)
Claim: Actually I would be absolutely delighted if we just disclosed, because I think that would do a world of good. I would be very happy. I think that's a much better solution than waiting and having the debate go on for decades here. If we could-- if we could disclose, and we could do that starting today, and do it honestly, I think that would go a very, very long way to solve the problem because I think students would catch on and they'd do the right thing. So if we could decide on behalf of every law school and every medical school to do that today, then, man, we're in business, and we might as well quit early and go out and have a beer.

### Scientific Advocate (SA)
Claim: Great. So we have-- we have affirmative action. You find that affirmative action just more disclosure?

### Conspiracy Advocate (CA)
Claim: I'm satisfied with that debating for 20 years, you know. It's a good-- it's a good compromise if we actually could do it now.

But I think actually if you paid attention to the mismatch literature, you're going to get more and more persuaded to our side.

### Moderator
Claim: Let me bring in-- let me bring in Rick

### Conspiracy Advocate (CA)
Claim: So, you know, I mean, it's not a bad thing if we end up agreeing by, you know, 7:00. If--

### Moderator
Claim: It's terrible for a debate, though.

### Conspiracy Advocate (CA)
Claim: We're arguing that affirmative action does more harm than good, not that it has to do more harm than good. We're saying that if you fix it, it could work pretty well. And you started out basically acknowledging that you're against stupid affirmative action. So in a way the scope of the agreement, the debate here, is "What's stupid affirmative action?" And that goes to this issue about kind of, you know, what do we mean by preferences or what do we mean by affirmative action? I mean, I hear what you're saying, Ted, that racial propositions is a loaded term, right?

And I try not to use-- I think we use a bunch in my remarks-- the preferences received by legacies are much smaller on average than preferences based on race. Excuse me. Preferences received by women are virtually nonexistent. I mean, that's always been a big theme of affirmative action, that is that women are under the tent as well. But historically that has been very small. I mean, there have been important things in terms of trying to expand the path of access for women. But in terms of actual admissions preferences, that's been a-- it's been, essentially, a trivial phenomenon. And class has not been a significant subject of preferences, okay? The typical college gives something like 20 or 30 times the amount of weight to race as they do to class-- if they consider class at all. So, one of the reasons that race keeps popping up in the mismatch literature is because that's where the really large preferences are, and that's where the problem seems--

### Moderator
Claim: But your-- one of your of opponents stipulated that maybe you're right. Maybe you're right, in terms of the dynamic you're describing in the mismatch-- but that even given that, the good outweighs the harm. Their point being that the message that affirmative action sends is so enormous and powerful that not only do universities want to embrace it, regardless of even the fact that you're right. But even if that harm that you're describing is real. And I want to ask you, what's wrong with that formulation? Why is the harm that you're describing-- that your side has stipulated to-- weigh heavier than that other good?

### Conspiracy Advocate (CA)
Claim: Because the pervasive tendency of selective institutions is to grossly go overboard. The focus of what schools do, the way that they set their goals is not based on how much of a preference should we use to maximize the width of the pipeline, to sort of maximize the aggregate beneficial social good? It's, how do I have enough cosmetic diversity in my entering freshman class so that I'm not going to get hassled?

That's the way the university presidents are usually thinking about this. And that is totally the wrong question. They ought to be thinking about what the effects are. And so, because we're in this mindset where we're asking the wrong questions, or setting it up to do things that it's not well-engineered to do, we end up getting preferences that are whatever are needed to achieve those cosmetic goals. And it ends up causing more harm than good.

### Moderator
Claim: In the overall scale of things, the--

### Conspiracy Advocate (CA)
Claim: If you look at--

### Moderator
Claim: Okay. So the--

### Conspiracy Advocate (CA)
Claim: preferences of professional schools-- or at the top 200 select schools.

### Moderator
Claim: Okay. The reason I ask you is that to some degree, both sides have been slicing the salami here, but I want to put the salami together. And you're saying that your argument, the harm that you're describing overall, is-- causes-- as it's operating, causes more-- is more harmful than the large good that the other side is proposing. You're saying "Yes.” So, I just want to bring--

### Conspiracy Advocate (CA)
Claim: If you look at-- if you look at three big things that keep coming up--

### Moderator
Claim: I-- I got to go to the other speakers--

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: Ted Shaw.

### Scientific Advocate (SA)
Claim: So, well, one thing, Rick. I mean, I thought I heard you say that you got me-- and you didn't use the term "preference" very much.

But then you went on to use it repeatedly.

### Conspiracy Advocate (CA)
Claim: Racial preference, right.

### Scientific Advocate (SA)
Claim: Right. Okay. So, but be that as it may, we're talking about scholastic institutions in which African American students-- again, where most of this heat is being felt-- I think we've acknowledged that, right? We're talking about percentages of maybe three, four, five, low single digits in many of the institutions. You know, selective law schools, et cetera. It's a lot of fuss, given how few African Americans exist at these institutions. Now, having said that, the proposition is one that says that affirmative action does more harm than good. And if-- I mean, I find it strange that your study focuses on-- I mean, there's a point to be made, I suppose, but I'm not sure where it takes us.

Your study focuses on where the students change majors out of the sciences into something else. So what? Lots of students change majors. You may say that black students may change at a higher rate of minority students, but that's not the end of the world. The reality in this country-- unfortunately, I became aware of this some time ago-- is that even if we look at graduation rates, generally speaking-- of all students-- they're not where most of us would like to see them be, you know? There are a lot of white students who change majors, who drop out, who don't finish. There are a lot of reasons that people may not finish in four or five years of college or take longer. Some of them are economic, et cetera. There are a lot of variables, as you know, that are in play here. And some of them disproportionately may affect students of color-- who are disproportionately poor, for example, and come from different backgrounds.

So, it's much more complicated. But the proposition that affirmative action does more harm than good is an extraordinary proposition, given the work that still remains in front of us, with respect to desegregating and integrating our institutions and American society, notwithstanding the Age of Obama.

### Moderator
Claim: Okay. I want to let Gail let respond to that, because she hasn't had a chance to speak. And immediately after that, I want to start going to questions from the audience. And to remind you, just raise your hand, a microphone will be brought to you. Stand up, state your name, ask a question. Gail, go ahead.

### Conspiracy Advocate (CA)
Claim: I guess I have a number of comments here. First of all, on the disclosure issue that we were talking about a little bit earlier, the U.S. Commission on Civil Rights proposed that law schools disclose these issues. It must have been something like seven years ago.

What happened? We got absolute deafening silence from the law schools. Nobody was willing even to mention it. This was a nonstarter. I doubt very much that we can get law school deans to disclose this. But again, as a compromise matter, I would think that's pretty good if we could do that right now. Otherwise I'd just like to convince you that the mismatch literature is in fact correct. I very much doubt that most people consider it more important to have more ivy league grads who are black than it is to have more black doctors, more black scientists, more-- more black engineers. I feel like I'm standing here with a key, and here is the key. Here is how we can get many more black doctors, many more black engineers, many more black scientists, more black lawyers, more black college professors. And I just need someone to take that key and unlock the door. But it's hard. It's hard.

### Moderator
Claim: Okay. Here we are. We have two-- I just want to do this for the radio broadcast. A reminder of where we are. We have two teams of two debating this motion: Affirmative action on campus does more harm than good. On the side arguing for the motion, Gail Heriot and Rick Sander; on the side arguing against the moment-- the motion, Randall Kennedy and Ted Shaw. We are in the middle of the question-and- answer section. And tonight's debate is being broadcast worldwide on our website, iq2us.org and on fora.tv. If you're watching on the live stream, we want to hear from you too, so send us your questions on Twitter or Facebook using the hash tag "affirmaction" so we don't miss it. And be sure to include your city, your state, your first name and your college if you're a student. So let's go to some questions. If you just raise your hand, I will find you. Right down in front, sir. And just wait till the microphone reaches you. From your right side, it'll be coming in. If you can just tell us who you are so--

### Moderator
Claim: Charles Fried. And I'd like to ask two--

I'd like to ask two back-to-back, extremely short questions. I would like to ask--

### Moderator
Claim: You're so breaking our rule, but I'm going to give you a pass on that.

### Moderator
Claim: I'm going to Richard and Gail what they think this country would look like today if, 40 years ago, and for the last 40 years, there had not been any affirmative action. And I'd like to ask Randy and Ted what this country will look like 40 and 50 years from now if we continue having affirmative action the same way we do now.

### Moderator
Claim: Rick Sander. Would you like to take it, Gail? You started to speak.

### Conspiracy Advocate (CA)
Claim: Well, I guess I'd like to say something, and that is one thing I think that we--

### Moderator
Claim: I'll let you both answer that tersely and then the two of you as well.

### Conspiracy Advocate (CA)
Claim: There'd be more black doctors, there'd be more black engineers, there'd be more black scientists and more black college professors if we did not use these very large preferences. Again, we're not against outreach. We're very much for outreach.

But the kind of preferences that are being practiced have been very much counterproductive.

### Moderator
Claim: Rick Sander.

### Conspiracy Advocate (CA)
Claim: I think that in the early years, in the 1960s and '70s, it was important to do whatever we could. We had to convince minorities that the doors that had been closed were now opening. So I would set aside that period. But if you want to see what would be the effect now or in recent decades, look at the effect of Prop 209 in California. Californians adopted a ban on the use of race in college admissions. The result of the University of California was a dip in-- a substantial dip in minority enrollments at the most elite schools, a temporary dip in black enrollment at UC as a whole. But within four or five years, the schools had launched enough outreach efforts to reverse that and to be above their pre-209 minority enrollment levels.

In the meantime, students had cascaded to less elite institutions and they were completing science degrees at a much higher rate. They were graduating at a much higher rate. They were especially graduating in four years at a much higher rate. They had higher grades. So the overall effects of this quasi national experiment are resoundingly positive.

### Moderator
Claim: All right. Let me go to the other side. And your-- this is your chance not to rebut this but to respond to the question.

### Scientific Advocate (SA)
Claim: Yes. I think it was an excellent question from Charles Fried. And my response is that if we continue to have affirmative action as we presently have it, we will continue to see the further desegregation of strategic institutions in American life. The fact of the matter is that in institutions like the one we're situated in right now, in many other elite institutions in American life, we are just seeing-- we are just seeing the fruits of desegregation.

We still have a long way to go. And I hope that affirmative action will continue, and it seems to me that in over the next half century, we will continue to see what we have been seeing for the past 40 or 50 years, which is a much fairer, a much better American life. So it does not--I'm not bothered whatsoever by the prospect of a continuation of affirmative action as it is characteristically practiced now.

### Moderator
Claim: And Ted Shaw.

### Scientific Advocate (SA)
Claim: So, first, in order to answer that question, I think we'd have to have-- and I know you've been engaged in these discussions for a long time. We would have to have a discussion about the legal basis for affirmative action that exists now, you know, the remedial and the diversity legs.

My hope would be that there would come a time, within the period that you identified, where it wouldn't be necessary to consciously put a thumb on the scale in order to achieve that kind of diversity. But with respect to the remedial leg which basically the Supreme Court has thrown under the bus, but nonetheless, the jurisprudence is so convoluted that we still have a subterranean discourse about that, that when race no longer is a cause for unearned privilege or unearned disadvantage at the moment of birth or through life, then I'd be more than happy to let it go, not to talk about it any more. I long for that day to come.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: But we're not there.

### Moderator
Claim: More questions? Ma'am.

Thanks. Can--I'm not sure if any camera can find you. Maybe if you came out to the center aisle.

### Moderator
Claim: My name is Danielle Kim. I'm a student at the Harvard graduate school of education. I beg to make the point that Asian Americans also face significant racism in society today, yet they're at an enormous disadvantage in gaining admission to highly selective colleges. So under affirmative action, do you believe that Asian Americans have an equal opportunity to succeed?

### Moderator
Claim: Could I ask you if you would be willing to rephrase that slightly differently and ask if under current policies Asian Americans are harmed?

### Moderator
Claim: Yes.

### Moderator
Claim: Would that work for you?

### Moderator
Claim: Absolutely.

### Moderator
Claim: I’d just like to plug it into our actual motion.

### Moderator
Claim: Do you believe that Asian-Americans are harmed under current affirmative action policies?

### Moderator
Claim: Randall Kennedy.

### Scientific Advocate (SA)
Claim: It all depends on what sort of Asian-Americans we're talking about. I think that some Asian-American groups, they may be harmed.

So, for instance, Japanese-Americans, Chinese-Americans, I think actually face a somewhat different footing in the competition for admission to selective universities than people from other parts of Asia, the Mnong, Filipinos, others. I think it's a complicated scenario.

### Moderator
Claim: Do you care?

### Scientific Advocate (SA)
Claim: I'm sorry?

### Moderator
Claim: Do you-- do you care? I'm not being facetious. In terms of your saying, you know, maybe some people will be harmed, the current theme, but for the larger sake, the system should largely operate as it is for the--

### Scientific Advocate (SA)
Claim: Oh,--

### Moderator
Claim: --future. Do you care that there are harms to somebody who-- in the category you just described.

### Scientific Advocate (SA)
Claim: As far as I'm concerned, in our discussion of this, it's not, frankly, about individual individual harm, so long as it's not invidious, so long as it's not, trying to stick it to a group because of group membership. What we should be interested in are policies that overall will advance--

### Moderator
Claim: But--

### Scientific Advocate (SA)
Claim: --the purposes of these institutions.

### Moderator
Claim: But the angst in all of this comes from the fact that everyone experiences it as an individual on all sides--

### Scientific Advocate (SA)
Claim: Uh-huh.

### Moderator
Claim: --of the equation. So why do you discount-- I think I may be putting too many words in your mouth by saying, "Discount." But why do you diminish the impact on the individual?

### Scientific Advocate (SA)
Claim: Oh, I wouldn't diminish it so the person who's feeling this angst-- I understand that they're feeling the angst. They ought not. The fact of the matter is that we have all sorts of social programs that disadvantage people in various ways. We have all sorts of things that happen, you know, when-- we have all sorts of things that happen and that disadvantage people or, you know, when people face disaster in the middle of the United States-- let's say that there's been a flood, and Uncle Sam comes to me and says, you know, "We want you to pay more in taxes to help these people out," that's a political decision that's being made.

I might not like it. I might feel that the pinch is being put on me. I don't think that's a good thing, but I'd do it because I'm part of the United States of America and all people - -

### Scientific Advocate (SA)
Claim: --hold it, all people ought to contribute to social missions that are worthwhile.

### Moderator
Claim: I'm--

### Scientific Advocate (SA)
Claim: Social missions--

### Moderator
Claim: I'm making the mistake of starting to be the debater with you, and I only was looking for clarification to your question, so I'm going to stop but let the other side come back.

### Scientific Advocate (SA)
Claim: The social mission of trying to overcome racial injustice in America is a social mission that ought to enlist all comers.

### Conspiracy Advocate (CA)
Claim: I think we'd like to make--

### Moderator
Claim: Rich Sander.

### Conspiracy Advocate (CA)
Claim: --two short comments. One is that we've generally disavowed the idea that we ought to make contributions based on race. And it's this very narrow focus on race that leads us into this bind because the logical implication of having large racial preferences for blacks, Hispanics, and American Indians is that there should be a large racial penalty for Asian-Americans.

And I don't think it exists everywhere but it exists in enough schools to be really repugnant. And if we focused affirmative action more on pipeline questions, more on "Who is having difficulty getting access?" then there would be dramatically more focus in this whole discussion on class, which is generally ignored by universities and not on race. And if we were focusing more on individual characteristics, we wouldn't have this bind of treating Asian-Americans the way we used to treat Jewish Americans.

### Moderator
Claim: Gail?

### Conspiracy Advocate (CA)
Claim: I guess I don't have a whole lot to add--

### Moderator
Claim: Okay, then I'm-- well, I--

### Conspiracy Advocate (CA)
Claim: --a little bit.

### Moderator
Claim: No, no, I thought you were waiting for something to say, and we have very little time, so I'd like-- very quickly-- because I'd like to get in one more question.

### Scientific Advocate (SA)
Claim: Very quickly on this, I think that this is a thorny and difficult question although I agree with what my colleague, Randy, said about breaking down Asian-Americans as a group.

But my starting place in dealing with this question includes two points. One is that nobody, nobody has an absolute right to be admitted to these institutions. Keep that in mind. We're choosing among people who are qualified and they have different backgrounds, different qualifications or levels of qualifications. But nobody has an absolute right. Secondly, I point to what Bok and Bowen said in "The Shape of the River," the analogy they gave-- you know, you're in a parking lot, you know, of a big mall during the holiday season and you see the handicapped spot. You can't find a spot. You see that spot. You say, "You know what? If that spot wasn't there and they weren't giving that preference to handicapped people, I'd have been in that store and I'd be out of there.” And you wouldn't in all likelihood. There aren't enough, I contend, African- Americans at these selective institutions to really account for the large numbers of others who don't get in and think that they didn't get in because African-Americans got in.

### Moderator
Claim: One more question, right down front, thanks. Mic's coming from your left side.

### Moderator
Claim: My question is for Gail. You mentioned that--

### Moderator
Claim: just tell us your name, please.

### Moderator
Claim: Oh, my name is Rina Johnson You mentioned that your ideal system would be if the universities gave students information and then they would-- I think the term you used was "do the right thing"-- on an individual level, does that mean maybe going to a less prestigious institution with fewer resources and job opportunities just so that you maybe perform better in comparison to your classmates?

### Conspiracy Advocate (CA)
Claim: I mean, I didn't say that was my ideal system. I'm not really quite sure what my ideal is. But what I did say is that, yes, if schools were to disclose what the success rate for students with that particular set of academic indicators and students were able to decide for themselves whether or not they wanted to take the risk, I think that's a tremendous improvement over what we have now.

And, in fact, that's exactly what the U.S. Commission on Civil Rights recommended that law schools do. And I voted for that report. And what's tragic I think is that schools don't want to disclose it. They don't want to tell students, I am not at all confident that even though as a group we're able to come to a possible settlement. I don't think you're going to get Harvard or any other law school to sign on to it. And that's a tragedy, I think.

### Moderator
Claim: I just got the signal that we can stretch for one more question. Sir, right down-- over here, thanks. Make it a doozy.

### Moderator
Claim: Hi. My name is Alex Sullivan. So, it seems to me that this side has made the case that affirmative action, in its current state, is ineffective, or does more harm than good. And I think they've been quite compelling to that end. So, my question would be to the opposition, do you think that affirmative action, if we accept this motion that-- as they put it, that in its current state, it does more harm than good, do you think that in its current state, that it's not the case, that you're-- are you arguing that-- the ephemeral concept of affirmative action is, in its-- like, in its end, a good in its own end? Or are you saying that in its current state, everything is fine, we're good? Currently, we can just continue on as is?

### Moderator
Claim: Okay.

Except for stupid affirmative action, as you've made clear. Randy Kennedy.

### Scientific Advocate (SA)
Claim: I think that improvements can always be made. And I think that the point about disclosure is a fine point. Again, I stated from the outside that-- does affirmative action have difficulties? Does affirmative action have problems? Does affirmative action have risk? Does affirmative action have costs? Yes, it does. There's always a question of-- compared to what? I maintain that affirmative action-- even with its blemishes, even with its many blemishes-- has been better for our country, for our institutions of higher education, than the most likely alternative, which was nothing.

### Moderator
Claim: And because your opponents have the last word in the next round, Rick, I'll give you the last word in this round, if you would like to take it.

### Conspiracy Advocate (CA)
Claim: No, I'm fine.

## Round 3

### Moderator
Claim: You want to pass? Ladies and gentlemen, that concludes Round 2 of this Intelligence Squared U.S. debate, where our motion is Affirmative Action on Campus Does More Harm Than Good. And remember, we had you vote just before you heard the arguing begin. We're going to have you vote again immediately after this upcoming round. And remember, the team that has changed your minds the most or moved most of you to their side in percentage point terms, will be declared our winner. But first, on to round 3, closing statements.

From each debater in turn, uninterrupted, they will be two minutes each. First, to summarize her position in support of this motion, Affirmative Action on Campus Does More Harm Than Good, Gail Heriot, professor at the University of San Diego School of Law and member of the U.S. Commission on Civil Rights. Ladies and gentlemen, Gail Heriot.

### Conspiracy Advocate (CA)
Claim: Thank you. This should not be a liberal or conservative issue-- and it didn't used to be. No less a liberal icon than Supreme Court Justice William O. Douglass-- made an eloquent plea on behalf of color-blind admissions policies back in the early 1970s. My personal favorite among the liberals on this issue was California Supreme Court Justice Stanley Mosk. As a Superior Court judge, and later as California Attorney General, Mosk stuck his neck out for civil rights on many occasions, back in the 1940s, when it wasn't so popular, back when it could be a career killer. Mosk called race-preferential admissions "the sacrifice of principle for the sake of dubious expediency.”Little did he realize just how dubious that expediency would turn out to be. Though maybe he should have. The research that we have been talking about today was not a bolt from the blue. The University of Chicago Sociologist James Davis had concluded in the mid-1960s that college students who receive preferential treatment would have gone on to better careers, had they attended somewhat less elite institutions. He wasn't writing about affirmative action. Back in those days, it was most legacies and athletes that were getting the preferential treatment. But if it does not work for legacies and athletes, why would it work for anybody? I am happy to stipulate that everyone involved in this experiment meant well, and I know it takes a lot of courage to acknowledge that a strategy that you've put your heart into just isn't working. But this is not an ideological point.

Racial preferences don't work. We have lost precious time. Let's not make it worse by ignoring the evidence. I urge you to vote in favor of the motion.

### Moderator
Claim: Thank you, Gail Heriot. And the round of applause for that-- Our motion is Affirmative Action on Campus Does More Harm Than Good, and here to summarize his position against this motion, Randall Kennedy. He is professor at Harvard Law School and author of the book, "For Discrimination." Ladies and gentlemen, Randall Kennedy.

### Scientific Advocate (SA)
Claim: A good illustration of the way in which affirmative action has been helpful is attested to by-- or is suggested by the actions even of people who say that they are against affirmative action.

Couple of examples: Ronald Reagan. Ronald Reagan says he was against affirmative action. But candidate Ronald Reagan was asked, if you become President of the United States, "What will you do when it comes to appointing someone to the Supreme Court of the United States?" Ronald Reagan said, "If you make me President of the United States, I will appoint a woman to the Supreme Court." And he did. Was that affirmative action? Yes, that was affirmative action. And in fact, when he appointed Sandra Day O'Connor, there were people who said, well, you know, what about this? You said that, you know, gender and race and that sort of thing shouldn't matter. He said, to his credit, "we simply cannot have a Supreme Court of the United States that has a male monopoly. It's just illegitimate. There's something not right about it."There is a reason why every presidential candidate since the cabinet-- since the cabinet of John F. Kennedy has had people of color in it. No matter what their ideological persuasion, Presidents made sure racial minorities in the cabinet because they understood it would be illegitimate in the eyes of the citizenry to have a racially or gender homogenous cabinet. The same thing goes for the strategic institutions in American life, including our campuses. It will simply not do in this day and age to have campuses that have discreet groups who've been disadvantaged excluded from them.

### Moderator
Claim: Randall Kennedy, I'm sorry, your time is up. Thank you very much.

Our motion is, affirmative action on campus does more harm than good. And here to summarize his position supporting this motion, Richard Sander. He is professor at UCLA School of Law and co-author of the book "Mismatch." Richard Sander.

### Conspiracy Advocate (CA)
Claim: Well, I hope, Gail and I persuaded you that we're approaching this not as an ideological matter but as one of pragmatism. I care deeply about these issues. I have worked on civil rights issues most of my adult life. I have an African-American college-age son and a first grade daughter who goes to central Los Angeles schools, in a school that's-- half free lunch. I care deeply about these issues. And part of what informs my perspective is that when I look at higher education leaders, when I look at the folks that I know and have worked with, I see them as people who also have goodwill and are committed to racial justice and are not feeling beholden to affirmative action as something that they have to do for greater racial equality.

They feel lots of other pressures. But I'm very confident that if we reform affirmative action, they will try to find new ways to expand opportunity. That's exactly what's happening in California under Prop 209. There's been much closer collaboration between colleges and the K-12 pipeline since Prop 209 passed. There's been much greater focus on class-based affirmative action. Those things happen when you restructure the incentives. And what I'm arguing for, I think what Gail is arguing for, is that we need to restructure the incentives that are behind the current preference system. I want to mention one other problem that's deeply embedded in our current structure, and that's the problem of social mismatch. When you use very large racial preferences to create racial diversity, you open up a credentials chasm that's an invitation to feelings of alienation and isolation among the group that's benefited.

And it's an invitation to negative stereotyping among the group that's in the majority. It's been shown that if you reduce social mismatch, if you bridge that gap some, you actually increase social interaction. We can do a better job of figuring out where students end up in college and producing not only good outcomes for them but for their campuses.

### Moderator
Claim: Thank you, Rick Sander. Our motion, affirmative action on campus does more harm than good, and here with the last word, to argue against the motion, Ted Shaw, professor at Columbia Law School and former director of counsel and president of the NAACP legal defense and educational fund, ladies and gentlemen, Ted Shaw.

### Scientific Advocate (SA)
Claim: So let me thank our worthy adversaries for their participation in this discussion. Let me start by saying that there is stigmatization of African-Americans in America.

There has always been stigmatization of African-Americans in America. And it hasn't been the consequence of affirmative action. It's part of our long history, our struggle with what's been this country's greatest demon. And the great irony in my view is that some people conclude from that horrible history that as a consequence we should not think, talk, or do anything consciously about race. They equate in a way that says that there is symmetry race conscious measures aimed at including people with invidious racial discrimination that is based upon superiority and inferiority.

Much of this discussion, whether intentionally or not, echoes as I said earlier the rumors of inferiority which continue to exist in this country. It is in my view an inexplicable statement to say that in 21st century America African-Americans ought to go to lesser institutions and there'll be more, therefore, of them coming out as doctors, physicians, lawyers, scientists, et cetera. I don't get that argument. And I think it is just factually wrong. It isn't about whether we see race. The question is, having seen it, how do we treat one another, whether we include one another or whether we exclude one another.

### Moderator
Claim: Thank you. Ted Shaw. that concludes round three of this Intelligence Squared U.S. Debate. And now it's time to see how persuasive these debaters have been. We're going to ask you again to go to the keypads at your seat and vote for the second time. Again, if you agree with this motion after having heard the arguments, "Affirmative action on campus does more harm than good," push number one on your keypad. If you disagree with the motion, push number two. If you became or remain undecided, push number three. And we're going to lock it out in about 15 seconds. And then we will have the results in about a minute and a half. So while we're doing that and waiting for the results to come, the first thing I want to say is not only has it been a pleasure for us to be here but it's been a pleasure for Intelligence Squared U.S. to be on-- to be in association with four debaters who brought to this stage not only the passion but also the decency and the civility to respect one another's views on something that can be very deeply personal.

It stayed always civil and intelligent and informative, so I just want to invite a round of applause to all of them for the way that they did this. And on that theme, as Nick Rosenkranz mentioned at the beginning, we came here because a student approached him after he was making a presentation and invited us to come up here. And he was with the Harvard Law School Federalists Society, but from that point on his partner in bringing us here and in making arrangements and in helping us get on the stage was the American Constitution Society. Two organizations that don't normally hang out at the same clubroom really worked together to put this together for us, and we think in itself that embodies the kind of spirit of what we're trying to do. So we want to thank and congratulate both of those groups for doing that. love to have you Tweet about this debate. Use the Twitter handle, @iq2us. Our hashtag is affirmaction. Our next debate is next week, March 5, at the National Constitution Center in Philadelphia. The motion is "The president has constitutional power to target and kill U.S. citizens abroad." Supporting that motion, Alan Dershowitz, the Felix Frankfurter-- I knew I was going to hear that-- professor of law at Harvard Law School, Michael Lewis, a professor at Ohio Northern University's Pettit College of Law. Then on March 12 we will be in New York debating the motion, "Russia is a marginal power." The debaters include a political risk strategist, a former deputy national security advisor, and journalist from The Economist and London's Mail on Sunday. We want to encourage you to watch the live stream of any of these on iq2us.org or fora.tv and listen to these debates on NPR stations across the country, including here in this neighborhood.

And you can go to Twitter and Facebook for our-- to see what our upcoming debates are. And we are very, very open to taking ideas on topics. So if you have anything, please check-- kick it in. Okay, so I have the results now. Remember we had you vote once before the debate and once again after the debate. And the team whose numbers have moved the most in percentage point terms will be declared the winner. The motion is this, "Affirmative action on campus does more harm than good.” Here are the results, before the debate 22 percent of you agreed with the motion, 48 percent were against, and 30 percent were undecided. So those are the first results. The teams now need to move those numbers. Let's look at the second vote. On this motion, "Affirmative action on campus does more harm than good," the team arguing for the motion on their second vote, it's 36 percent. They went from 22 percent to 36 percent. They've picked up 14 percentage points. That is the number to beat.

Let's see the argument-- the side arguing against the motion, in their first vote it was 48 percent. Their second vote is 55 percent. They pulled seven percentage points, but that is not enough. The side arguing for the motion, "Affirmative action on campus does more harm than good," has won this debate on our rules. We congratulate them. And thank you from Intelligence Squared and me, John Donvan. We'll see you next time.
