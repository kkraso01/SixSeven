# Debate Transcript

Topic: For A Better Future, Live In A Red State
Motion: For A Better Future, Live In A Red State

Debate ID: 101813%20red%20state


## Round 1

### Moderator
Claim: I’d like you all to welcome to the stage now Mr. Robert Rosenkranz.

So Bob, very briefly, for those who don’t know yet, Intelligence Squared U.S., why you brought it here?

### Moderator
Claim: Well, I thought the meta problem we have here in the American policy world is excessive polarization. The public discourse in this country really needed a form where people could listen to ideas that they disagree with, have to confront facts that might be inconvenient, and

Upper East-- Upper West side of New York at a time when-- just before Obama came into Office. And Karl Rove was one of the panelists, and actually a majority of the undecided voters voted with the Karl Rove side.

### Moderator
Claim: Yeah and our point being there that what we put into the forum that night was four debaters that had to argue the point, and the audience really went along with the concept that “I’m going to listen tonight.” And Karl Rove began that evening-- he took a beat and he said “Well the Upper West side of New York. It’s great to be among friends.” And the audience fell down and he kind of had them listening after that, and he made very compelling arguments.

### Moderator
Claim: Another great example was one we did on the resolution “Global Warming is not a crisis” and the audience came in very much opposed to that motion, and ended up after listening to the arguments in favor of the motion. So quite a surprising result, and this debate took place at a time when Al Gore was assuring us that the debate is over.

### Moderator
Claim: And what’re your thoughts on today’s motion?

### Moderator
Claim: Well today’s motion-- I really want to call a lot of attention to the language. It was pretty deliberate. For a better future, live in a red state. So it's not merely about which model of state governance is most in accordance with your policy preferences or predilections. It's really about where you choose to live. And I mean I know countless people whose policy predilections would be blue state, but who choose to live in red states. And that dichotomy between how you vote with your mouth and how you vote with your feet is part of what should encourage people in the audience here to think twice.

### Moderator
Claim: All right, everyone. So you're going to have the chance to think twice as we welcome our debaters to the stage. Thank you, Bob Rosenkranz, and let's give them a round of applause.

### Moderator
Claim: Thank you.

### Moderator
Claim: So as we move forward from this point, we'll be recording for the radio broadcast, and because of that I'll be doing certain things like telling you over and over again that my name is John Donovan and what our motion is that's to help in the radio broadcast as they come and go from breaks. So just that you know that I haven't lost it. And the other thing is there will be points where I'll actually literally ask for your applause to happen spontaneously, and-- for example, when I introduce each of the debaters in a moment, but I'll encourage that applause by doing one of these. It, again, would help with the radio broadcast and, as I said before, communicates to the audience that you're all here. And I'd like to start that by asking for a round of applause one more time for Robert Rosenkranz for bringing all this here. Somewhere over the rainbow skies are red, reflecting back the warm glow of happiness of the red states that lie beneath them across the U.S. South and up through the west and the Midwest. Those states that seem to be close to reaching certain American conservative ideals of governance, states where taxes are lower, regulations are lighter, unions are weaker, frackers are freer, and gun rights are a given. What's not to love about life in a red state?

Unless you are a blue state type. The red state/blue state divide. It's a little bit artificial. It's a little bit oversimplified, but we know what we mean when we use the term. So let's have it out right now. Yes or no to this statement: "For a Better Future, Live in a Red State," a debate from Intelligence Squared U.S. I'm John Donovan. I am proud to be here with the Philanthropy Roundtable as our partner. We have four superbly qualified debaters, Americans all, but they are divided on his motion. Two against two, they will argue for and against it: "For a Better Future, Live in a Red State.” Our debate goes in three rounds and then you in the audience vote to choose the winner and only one side wins. Our motion is: "For a Better Future, Live in a Red State.” Let's meet our debaters. First of all, ladies and gentleman, on the side arguing for the motion, they are for the red states. Let's welcome Hugh Hewitt.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: And, Hugh, you are a professor at Chapman University Law School. You are host of the radio show that is named after you, "The Hugh Hewitt Show," and you are on the for side of this debate. You are for the red states, but you live in California, a blue state. So, have we booked the wrong guy?

### Conspiracy Advocate (CA)
Claim: Right guy, wrong wife. I married a Marine Corps brat who grew up on Camp Pendleton and wasn't leaving.

### Moderator
Claim: All right. Ladies and gentleman, Hugh Hewitt. And Hugh, your partner is?

### Conspiracy Advocate (CA)
Claim: The undefeated, untied, and always charming, Stephen Moore.

### Moderator
Claim: Ladies and gentleman, Stephen Moore. Stephen, you are also arguing for the motion: "For a Better Future, Live in a Red State.” You're a member of the editorial board and a senior economics writer for the Wall Street Journal. Steve, you are based in Virginia, a state that actually went for President Obama in 2012, but we're going to call it a red state. It has a Republican governor, a Republican majority House, the Senate with the Republican tie-breaking vote. So, question to you is if you were forced to leave Virginia and had to move to a blue state, which one would it be?

### Conspiracy Advocate (CA)
Claim: Well, it's a little unfair question, because on a day like today with the beautiful view of the ocean, how could I not say California?

### Moderator
Claim: Oh, you're just playing to the crowd here. Ladies and gentleman, Steve Moore. Our motion is: "For a Better Future, Live in a Red State.” We have two debaters arguing against it, they are for the blue states. First, ladies and gentlemen, let’s welcome Gray Davis. Gray Davis, the 37th Governor of California, you have also served as lieutenant governor, state controller, state assemblyman, you have spent most of your life in California. Your family moved here from New York when you were a kid, you went to Stanford, but I’m going to ask you the same question that I asked Steve, if you had to move out of your comfort zone into a red state, which one would it be?

### Scientific Advocate (SA)
Claim: Well first of all I agree with Steve, why wouldn’t I live in California, such a fabulous place, but I just came back from Sea Island Georgia where we had a family reunion, that’s a beautiful state, great golf, great people so I-- be somewhat under duress but if you’re forcing me to leave I’d say Sea Island, Georgia.

### Moderator
Claim: All right, we have one vote for Georgia, ladies and gentlemen Gray Davis. And Gray Davis, your partner is?

### Scientific Advocate (SA)
Claim: My partner is the esteemed Michael Lind, who will dazzle us with facts and argument.

### Moderator
Claim: Ladies and gentlemen, Michael Lind. And Michael, you are also arguing against the motion for a better future to live in a red state, it means you’re arguing for the blue states. You are co-founder of the New America Foundation, you are also policy director of its Economic Growth Program and Next Social Contract Initiative. You are a fifth generation native of Texas, and you have already said that when it’s all over, you’re going to go back there to retire, but being a blue state kind of guy, I just want to know why would you do that to yourself?

### Scientific Advocate (SA)
Claim: Well in the words of the late Molly Ivins I dearly love the state of Texas, but consider it a harmless perversion to be discussed only among consenting adults.

### Moderator
Claim: Ladies and gentlemen, Michael Lind. Thank you, here they are our four debaters. Now this is a contest, it’s a contest of ideas and there will only be one winner because you our live audience will be given the task of choosing the side that has argued the best. By the time the debate has ended, you will have been asked to vote twice, once before the debate and once again afterwards, where you stand on this motion: for a better future live in a red state. And the team whose numbers have changed the most in percentage point terms will be declared our winner. So let’s go to our preliminary vote, go to the key pads at your seat, and I will remind you how it works. If you are at this point disposed to agree with this side, the side that’s arguing for the red states, the side that’s arguing, for a better future to live in a red state, you push number one. If you’re with this side, the side arguing against the motion, which means that they are for the blue states in this argument, push number two.

If you’re undecided, which is a perfectly honorable and reasonable position to be in, push number three and you can ignore all of the other keys. And if you push the wrong one just correct your vote and it will record your last vote. And it will lock out in about 10 seconds. Okay, so and how it will work at the end, we’ll have the second vote and it takes about two minutes to tabulate the results. Onto round one, opening statements from each of our debaters in turn. They are six minutes each. Our motion is this: for a better future live in a red state, and here to speak first for the motion, Steven Moore, who can make his way to the lectern, Steven Moore, a member of the editorial board and senior economics writer for the Wall Street Journal, ladies and gentlemen, Steven Moore.

### Conspiracy Advocate (CA)
Claim: Thank you, ladies and gentlemen and thank you so much, John, for the opportunity to come to this great event and debate this important topic. It’s wonderful to get out of Washington D.C., which I call American’s only work free drug zone and lately actually it has been a work free drug zone-- So let me make a few points about why this is such an important topic and why for a better life you should move to a red state and I would start with one observation, which is that over the last 20 years we’ve seen in America the biggest shift in wealth in the history of this country. We’ve also seen a massive change in population of where people are living and this has had profound impact in terms of where the growth is in this country and where it’s not happening, and so if you look over the last 20 years there’s been about 30 to 40 million people who have moved addresses, moved from one state to another and over that same time period about two trillion dollars of wealth and income have moved from one state to another on that.

This according to Travis Brown who has written a great book about how money walks, and if you look at those statistics and you look at where people are moving to and where people are moving from it is incontrovertible that people are leaving blue states and they are moving to red states. Now some of this of course is due to things like weather, people are moving away from the north east especially as we become an aging society and are moving to states like Florida, and Georgia, and North Carolina and South Carolina, no question about it weather has a big impact here. But it’s happening all over this country. Not just moving to better weather states. In fact if you look at the statistics, an amazing statistic about California-- and I agree with Gray Davis, what a wonderful state this is-- how do you screw it up so much? You know how does the state get so screwed up that people have actually started to move out of this wonderful paradise? Over the last five years one million jobs, roughly-- these aren’t exact numbers, but roughly one million jobs have been lost in California, and over that same time period one million jobs have been gained in the state of Texas.

That’s an amazing statistic. You want to talk about a transfer of wealth and politic power it’s leaving California, it’s going to Texas. Now I would submit to you that people are not leaving places like Los Angeles and San Diego to go to Houston for the weather. They’re not doing that, right? They’re moving there because that’s where the opportunity is, that’s where the jobs are. That’s where the kind of free enterprise systems flourish. And by the way just to continue with this Texas-California comparison, because I think we’ll make this a lot throughout the debate because Texas is a prototypical red state, and California is a prototypical blue state, the poverty rate is California is not 40 percent higher than it is in Texas, which is amazing. People are always bad mouthing Texas, “Oh they don’t even have plumbing in Texas” and so on, the truth is Texas is actually getting very rich, California not so much so.

Second point to make that you should all ponder. We are all living through, right now, what I call the biggest kind of political, cultural, and economic divide in this country perhaps anytime since the civil war. And what you’re seeing-- to put it very simply if you look at the last few elections is that the red states are getting redder, and the blue states are getting bluer. And there is absolutely no question about it. If you look at what’s happened, for example, in the Southern states every election for the last four or five election cycles they get more and more Republican, for better or worse, and that’s also true of the blue states. I hail from the state of Illinois; I love the Chicago area; I love the State of Illinois. What has happened in Illinois over the last 25 years is one of the great tragedies of our country. Illinois has gone to the pits in just about every single area. It has huge unfunded liabilities. High unemployment rate, the dingbats in Springfield just raised the income tax rate by 67 percent.

One of my favorite kinds of modern politicians Mitch Daniels, a couple years ago when he was governor was asked about what it was like being a neighboring state of Illinois, and just put it so well he said “To be a neighboring state of Illinois in Indiana is like living down the street from the Simpsons.” I thought that is a great way to put it. And so we are seeing incredible dysfunction in these blue states, and it’s a tragedy by the way. And then you ask the question “Why are people moving from blue states to red states?” And I would submit to you the answer is very clear from the evidence why people are moving. The two biggest factors, according to all the academic and economic research, are number one: if a state is a right to work state, that is that they do not force unions in their state, and allow every worker to have the right to choose whether they want to join a union or not, those states are flourishing. And one of the fun things about working at the Wall Street journal, we talk to business owners all the time, big and small, from the corporate fortune 100 companies to small entrepreneurial companies, they always tell us when they’re talking about setting up a new plant or a new warehouse the first question they ask about a state where they’re going to locate is “is it a right to work state?”Because it it’s not a right to work state it’s simply, they just take it off the list. No matter how many other kind of incentive systems they might have to move there, if you’re not a right to work state you’re just not in the game to get these new enterprises. By the way people are always talking about America losing its auto industry, and auto jobs. You know America’s not losing its auto jobs, it’s just the auto jobs aren’t in states like Ohio and Michigan anymore. The auto jobs are now in the South, right? And that’s partly because of the fact that those are right to work states. The second factor that matters a whole heck of a lot is whether a state has no income tax, or low income taxes. And we find this to be highly predictable for where people move. And so for example in this great country of ours there are nine states that have no income tax.

States like Texas, states like Florida, states like Tennessee, states like Wyoming, states like Nevada, states like Washington. Those states over the last 10, 20, 30 years no matter what kind of period you want to look at, have been producing about two to three times a many jobs per year as the nine or 10 states that have--

Okay let me just make one more point--

No I can’t even--

If you don't want to live in a place like Detroit--

--get to a red state.

### Moderator
Claim: Steve Moore, your time is up. Thank you very much.

### Conspiracy Advocate (CA)
Claim: Okay let me just make one more point--

### Moderator
Claim: Stephen Moore, I’m sorry, we got to--

### Conspiracy Advocate (CA)
Claim: No I can’t even--

### Moderator
Claim: We're--

### Conspiracy Advocate (CA)
Claim: If you don't want to live in a place like Detroit--

### Moderator
Claim: --Stephen Moore, Stephen.

### Conspiracy Advocate (CA)
Claim: --get to a red state.

### Moderator
Claim: Thank you. Yeah. In fairness to Stephen, the reason that happened is that-- right. Our timers were blown out when the power shortage happened, and he couldn't see where he was going. So you actually got about six minutes and 23 seconds, because I did let you go on a little long. Are they functioning now? Because if they go out again, I would just want to ask our debaters if they fail, would you like a one-minute warning from me if these timers fail? I can do that for you. Okay.

But right now it looks like they've just come back again. Our motion is: "For a Better Future, Live in a Red State," and our next debater against the motion is Gray Davis, the 37th governor of California. He is currently of counsel a Loeb and Loeb, LLP, and a senior fellow at the UCLA School of Public Affairs. Ladies and gentleman, Gray Davis.

### Scientific Advocate (SA)
Claim: Thank you, John. Bob Rosenkranz, thank you. Intelligence Squared, thank you so much for hosting this. And I want to welcome my esteemed colleagues both for and against this proposition. As Steve indicated, this red state/blue state deal is really not so much about geography as it is about a state of mind. And those of us in the blue states have a different idea about economic development. We believe John Kennedy had it right when he said, "A rising tide will lift all boats," because we try and provide economic opportunity for everybody, and we do that with four simple ideas.

One, invest in education. Invest in infrastructure. Protect the environment and have a stable safety net. We think that all makes economic sense. We think it is morally the right thing to do. And the numbers prove that we are right. If you look at the top 10 states by average income, nine, nine are blue, one is red. If you look at the top 10 states by gross domestic product, eight are blue, two are red. If you look at the bottom 10 states by gross domestic product, nine are red, one is blue. Beyond just economics, if you live in a blue state you're going to live longer, you're going to be healthier, you're probably going to have a college degree, and you're going to have more opportunity.

Now, let me talk a little bit about California, which is definitely a blue state, but was not before 1992. But today it is really a blue state. Despite what our critics say, these are indisputable facts. California has more Fortune 500 companies headquartered than any other state, 54. California is the leading manufacturing state by far in America, both by jobs and total dollar output; in 2011, $230 billion. California is the largest agricultural state in America by dollar output. California created more jobs last year than Texas, and more jobs in the last year than anyone in the nation. Most importantly, people believe in California and they invest their dollars. California gets more direct investment from other countries than any other state.

And this is the statistic that's going to blow your mind. On venture capital, that's people putting their money in start-ups, in 2011, the last year we have statistics for, California got more venture capital than all the other 49 states put together, and it got more money from foreign countries investing in California. So, people are putting their money where they think they can get the best return and they believe that best return is in California. My point is, to live well, to be healthy, to have more opportunity, to be better educated, you want to live in a blue state. Vote no on the proposition that someone has to force you to move to a red state to live well.

### Moderator
Claim: Thank you, Gray Davis. And here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donovan. We have four debaters, two teams of two, fighting it out over this motion: "For a Better Future, Live in a Red State.” You have heard two of the opening arguments and now onto the third.

Here to debate for the motion: "For a Better Future, Live in a Red State," host of the nationally-syndicated radio talk show, "The Hugh Hewitt Show," and a professor at Chapman University Law School, ladies and gentleman, please welcome Hugh Hewitt.

### Conspiracy Advocate (CA)
Claim: Thank you, John, and I agree with the governor. Thank you, Bob, for sponsoring Intelligence Squared. I love the format. Thanks to the Philanthropy Roundtable for hosting us today and to my colleagues, both the wrong and right-- It’s good to have you here, I have both the disadvantage and advantage today, my disadvantage is that I’m a talk show host and that means five days a week, three hours a day, 15 segments a day, 75 segments a week I do this. Six minutes is an extended commercial break, it’s not a segment. My advantage, however, is I have a book coming out on the very last day of this year called “The Happiest Life” and I have spent the last year immersed in the details of the emerging science of happiness, begun 15 years ago by my colleague Dennis Prager with the book “Happiness Is A Serious Problem” and now most recently by Arthur Brooks of the American Enterprise Institute, in his book the “Road to Freedom, “ happiness is quantifiable.

You can figure out what makes people happy and what makes people happy is more to be found in the red states then the blue states. Now I present that to you in a way that I think many of you will know or be familiar, because many of you share in common with me a friend, Dr. Jack Templeton. Jack likes thought experiments, right? You’ve been in those thought experiments with Jack where you reframe the question. Here’s how I’m going to reframe it for you, if your son and daughter approaches you and says “Mom, Dad, my company, the government, the military, has come to me and said I’m getting moved one more time.” They’re in their 20s. “And they’re going to drop me into a blue state or a red state, I get to pick blue or red. I don’t get to pick the city, I don’t get to pick the state, I don’t get to pick rural or urban, I don’t get to pick suburban or where in that state, I just get to pick blue or red, what do you think?” It’s kind of a Rawlsian construct, right? You don’t know where they’re going to end up just red or blue. Four reasons to say to him son or daughter, red.

Number one, when you get there, you’re going to want to buy a house, California is 200 percent above the median cost in the average house in America. California is below that median. New York is 150 percent. Highest mortgage debt is in California, highest mortgage debt is in the District of Columbia. You want your child to be able to buy a house and begin that American dream, send them to a red state. Number two, you’re going to want them to have kids, right? You want to be grandparents. Everybody wants to be a grandparent, I just became a grandparent; it’s a great thing. Guess where the fertility is? Guess where people are actually having families and babies, the top 10 most fertile states are red. The 10 least fertile states are blue. I want to read that blue list to you, because it really is blue, Rhode Island, Vermont, New Hampshire, Maine, Connecticut, Massachusetts, Michigan, New Hampshire, New York, they’re going to way of Russia and Spain, they will not be there in 10 years because they’re not any children. But more importantly-- actually that’s just an indication of other things. Volunteerism is spread out evenly across red and blue states, but not charitable giving. As you will know nine out of the 10 most charitable states in the union are red.

Now of course we got Utah and Idaho and we’ve got the Mormon tide to drive them that way but the other seven are not. They are, however--what’s that an indication of? Religiosity and not merely checked off religiosity, but genuine confirmation of religious belief. Red state advantage huge on charitable giving. Number three though when you get there and you have these kids and you got your grandchildren, they’re going to have to drive around a lot, they’re going to have actual practical things to think about in the course of their lives. Number one, think about the number of times you’ve pulled into a gas station, the number of times over the life of your child is making that red, blue state decision, they’re going to pull into a gas station. It’s a good proxy for the practical cost of living, gas prices are phenomenally lower in red states, and there are reasons for that, proximity of refinery, production of the basic materials, bigger in red states. Red states are energy productive. When I was talking to Steven beforehand and he said you take the economics and I’ll take the social stuff.

We didn’t really say where energy would fit, I thought maybe he would talk about energy production, but then I began to think it’s really proxy for the willingness to go and grow with what you’ve got to make it better and then finally those grandchildren of yours are going to need to be educated. Who’s doing the best? Now Michael Lind is a very experienced and savvy debater and he will throw statistics at you that will not make sense, that’s what they do from that side. But you listen very carefully to his statistics about education because he cannot defeat this one from the national education assessment study. The most underprivileged kids when it comes to education are African Americans and Latinos. The most important manifestation of educational success is bringing the bottom to the middle. The most important element of that is math and the most important grade is eight. That is the turning point where the skill set transfers over into the employment probability and possibility of those children. In the NEAS, the state that is now number two that has made the most progress over the last decade is Texas for blacks and for Latinos, they have rocketed up.

Do you know what state is number 49? This one. Why is that? It’s because education, innovation is occurring in the red states. Why is that? Because they are not in the death grip of special interests that prevent the exploration of the new and the effective. That’s why if you had to pick where your grandchildren were going to be educated and you could not guarantee that they’re going to a private but they are going to go into a public school. You would pick a red state. If you were a grandma or grandpa who wanted to give them the best advantage of an exploding opportunity in the education arena. Now as I warn you again, Michael will come up and bring up SAT scores or ACT scores, and I will give him that, they’re higher in the blue states. You’ve got some legacy investments in the blue state. You’ve got some wonderful cultural advantages. You might be thinking “I want my grandchild to live in San Francisco.” No you don’t get to pick that. This is Rawlsian. They’re just going to go red or blue. And if you really want to think that through you’re going to pick red every single time. Thank you.

### Moderator
Claim: Thank you Hugh Hewitt. Our motion is “For a better future, live in a red state”, and here is our final debater. He will be speaking against this motion, Michael Lind, the co-founder of the New America foundation, where he is policy director of the Economic Growth Program, and the Next Social Contract Initiative. Ladies and gentlemen, Michael Lind.

### Scientific Advocate (SA)
Claim: I think I’m a pretty good debater, but I’m not as good at lowering expectations as Hugh Hewitt. The motion is “For a better future, live in a red state”. As a native Texan I would love to endorse this motion. Texas does indeed lead California and much of the rest of the country in a number of indices. It’s number on when it comes to barbeque. It’s much better than that pork based stuff they have eastwards. It’s number six when it comes to housing affordability, and I suspect this will come up again and again and again. Because one of the issues among us is the relative importance of housing affordability as opposed to personal income taxes and business taxes in explaining migration.

So that’s the good news. Here’s the bad news for the state of Texas, and why it is not indeed surpassing California, New York, and other leading blue states, and probably will not do so within my lifetime: Texas is number one in uninsured adults. It is number 50 in high school graduates. I defer to Hugh on the rapid progress of African Americans and Latinos in Texas. That’s coming from a very, very low base, let’s face it. When it comes to uninsured children, Texas is number two. We heard a lot about fertility in Texas, and that’s true in the south and southwest in general, for ethnic and religious reasons. Texas on a scale from one to 50 is number 49 when it comes to prenatal care for pregnant women. So yes more women are pregnant, but they get absolutely abysmal prenatal care compared to most of the blue states.

Just a couple more points on what Stephen raised. He said that $2 trillion has moved across state lines in the last 20 years. Well the average GDP in the U.S. annually is 14 or 15 trillion if I’m not mistaken, so by my off the envelope calculations, that’s less than one percent of GDP over the last 20 years. This is not a terribly strong argument for their side if you ask me. The amount of migration from Texas-- from California to Texas is also very easy to exaggerate. Texans move to California just as Californians move to Texas. Between July of 2011 and July of 2012 a grand total of 22,000 more Californians moved to Texas than Texas moved the other way. The number was 17,000 surplus for Texas and New York. We’re talking about less than 0.01 percent of the US population in every case.

What is more, the lower your income, the less likely-- the more likely you are to move from California to Texas. Now why is this important? It undercuts the thesis that high progressive income taxes are driving out Californians. Because if that were true you would expect to see an exodus of rich Californians. What you’re seeing instead is an exodus of working class and lower middle class Californians and we know why. There are two factors. There’s the push factor, which was the housing bubble in California. It took place almost exclusively in blue states, mainly because rich people, after the tech bubble bottomed out, were looking for new and safe assets. And they had more confidence in the economic future of property assets going up in places like California, in New York, in Florida than they did in Texas and the south. So by dramatically raising the cost of living in the blue states that did force out a lot of working class people.

Often-- not to the south and Texas and the Great Plains, but to states neighboring. For example a lot of the working class people who have moved for housing affordability, have gone to other blue states like Oregon and Washington on the west coast. They’re just cheaper than California. And you see a similar spill over affect elsewhere. The poll factor that is creating so many of these jobs in Texas is the energy industry. And if you look at the red states in general, where this is taking place. It's in this energy corridor where thanks to fracking from the Bakken shale up in the Dakotas all the way down to Texas to the Eagle Ford shale, you see a tremendous explosion of energy. It lowers energy prices. It helps manufacturing, all of that. That is an accident of geography plus regulatory and technological factors. If the blue states who have energy resources like California and New York, were actually to, with some environmental safeguards to emulate these red states, you would see enormous amounts of wealth pouring into the blue states on top of their advantages.

So, we agree on many things. One of the things we agree on is that the south in particular has been gaining population ever since World War II, thanks mainly to air conditioning and to retirement-- that will continue indefinitely. The basic question, I think, is not which states are picking up the most people or the most footloose corporations, but where are you most likely to have health care, to have decent education, to graduate from high school, and to have quality of life if you're an ordinary high school educated working American? And in that case I think the answer is clear. You would rather be in a blue state than a red state. Thank you.

## Round 2

### Moderator
Claim: Thank you, Michael Lind. And that concludes round one of this Intelligence Squared U.S. debate where our motion is: "For a Better Future, Live in a Red State.” Keep in mind how you voted at the beginning of the debate.

We'll be asking you to vote again at the end of the debate, and reminding you again that the team that changes the most minds will be declared our winner. Now on to round two. That's where the debaters address each other directly and answer questions from you in the audience and from me. We have two teams of two arguing for and against this motion: "For a Better Future, Live in a Red State.” Hugh Hewitt and Stephen Moore are arguing for the red states. They argue that we already see the evidence that the American population is making this decision with its feet, because of the big shift in population since World War II, but more recently and increasingly, a large shift in wealth going to the red states. They say the reasons people are moving, they're moving for the right to work. They are moving attracted by lower income taxes, by the ability to buy homes, that there are indicators like fertility, which is on a rampage in the red states, and that all in all the message is the dynamic is moving very much in the favor of the red states.

The team arguing against them, Gray Davis and Michael Lind, argue by bringing forth a set of statistics that show us a snapshot of all sorts of advantages already accruing to residents of blue states. Blue states have higher average income. People in blue states are living longer. They are more likely to have a college degree, and to be healthier, and they dispute the notion that people are moving to the red states for benefits, such as lower income taxes. Texas and the southern states, you just heard, offer air conditioning, and that may be what's drawing people more than the lower taxes, because the portion of the population that's moving to these states wouldn't actually be benefiting from lower taxes, because they're just not paid enough. So I want to take a question to the side that's arguing against the motion for the blue states. This is a tricky debate, because both sides are coming at us with dueling statistics and it's a fairly easy thing to pick and choose, but as I did just point out, you presented, Gray Davis and Michael Lind arguing for the blue states, a snapshot of several ways in which already if you're in a blue state you're better off for various reasons, but your opponents, I think, are arguing about a dynamic as opposed to a snapshot.

They're arguing that everything you say may be true, but that the trend is going in the direction of the red states. And I want to ask you, Michael Lind, to take that on.

### Scientific Advocate (SA)
Claim: Yeah, two points about the trend. First of all, the question before the audience is not whether it will be better to live in a red state 30 or 40 or 50 years from now as a result of present trends, but right now. The second aspect is, what we're really talking about is the southern model versus the northern model. That is, the Great Plains have nine million people. The county of Los Angeles has nine million people. This is largely certain Midwestern states and the south. The low wage, low public service, low tax southern model, including states like Texas, that's been the model since before World War I. A hundred years ago there was a big achievement gap on all of these same statistics between the southern states and the northern states, the so-called blue states.

There is still a big achievement gap. It's been closed somewhat by growth of the south, partly because of federal investment and desegregation in the last century, but-- so that's-- I would turn it into a question to them, what date are we talking about? Because if it's 2013, you get a different answer to the question than in 2035. For you to believe that another 100 years of low wage, low tax smoke stack chasing luring companies from other states, which Mississippi has been doing for a century, is going to do any better than it has done in the last century.

### Conspiracy Advocate (CA)
Claim: Well look, you’re hearing a lot of dueling statistics here, but we as economists believe in something called revealed preferences. This is a core tenant of economics, which is you don’t have to ask us, you know, which is a better state to live in? You don’t have to take Hugh’s word for it or my word for it or Governor Davis’s for it, just look at where people are moving.

If you were right, people would be moving to the blue states, but they are not and you may be right that you have all these wonderful things in blue states that make them a wonderful place to live, but you know what? People don’t want to live in those states anymore, you’re seeing for every one person that’s moving to the states that you’re defending, four people are moving to the states--

### Moderator
Claim: Steven, how would--

### Conspiracy Advocate (CA)
Claim: So this is just an incontrovertible fact: people are moving there. Now does-- Gray Davis is right. California has unbelievable assets, you’re exactly right, your university system, you have an incredibly well educated work force. You have the best weather, beautiful mountains, beautiful beaches, beautiful women, I mean what’s not to like about this state? But the truth is, you know, it’s getting screwed up and people have been leaving; businesses have been leaving. You go to Nevada, you go to places like Reno, I mean Reno is-- you know this Governor, Reno is filled with businesses that used to be in California, you talk to the business owners and it breaks my heart, I had to leave a third generation California business because I can’t operate there anymore and I think that’s really--

### Moderator
Claim: Steven, though just very briefly to the point that Michael made, the difference between today and 2040, in what way-- is your argument talking about today or is your argument talking about 2040, or it sounds like you’re actually talking about both?

### Conspiracy Advocate (CA)
Claim: I think-- here’s my argument, you are exactly right, this a north versus a south phenomenon, and you know what’s happening in America today? We are witnessing the rise again of the South. There is no question about it, and in fact if you want to go to a place where the future is happening, you don’t go to Detroit, you don’t go to Albany, you don’t go to New York City, you don’t go to Los Angeles; you go to places in the South and it’s very likely that in my opinion in 10 years-- in 10 years’ time because of the huge growth of no income tax states, the entire South within 10 to 12 years will be a no income tax region. Now how in the world-- how in the world are the North going to compete against that?

### Moderator
Claim: Let’s bring in Gray Davis.

### Scientific Advocate (SA)
Claim: I want to make two points. First of all, people vote with their feet, all the panelists here live in a blue state.

Even Steve’s tenuous connection with Virginia, I would argue Obamacare in Virginia, they’ve got two democratic senators and New York and D.C. are blue. California has 38 million people almost as many people as Texas and New York combined, that’s 38 million people voting to be here. Secondly, the future, California is the future. Do you have an iPhone? Do you use Google search? Google is 14 years old and the iPhone is maybe 10 years old. Twitter, six, Facebook, six or seven. We have great technology companies, because in this state we take a different view towards the future. In the east where I was born after you’re educated you want to join a company; in California, you want to start a company. So when I gave the commencement address at Columbia Law School, my alma mater, I got a nice note from the dean that said “Would you look at my speech for the incoming first year of students?” Great speech, last sentence, “My six year old daughter”-- the dean says, “thinks Mr. Google is infallible.”My only suggestion to change was, tell those first year students that Google is only three years older than your daughter, and those students are going to see breath taking change, most of which is going to come out of Massachusetts and California.

### Moderator
Claim: Hugh Hewitt, what do you do with Gray Davis’s statement in his opening remarks that California has more fortune 500 companies than any other states to date? Does that impress you?

### Conspiracy Advocate (CA)
Claim: No, because trajectory is all that matters here. Not static snapshots, in fact, the Governor and Michael remind me of Steelers fans, just wait until the 70s, they’re always ready for the 70s to come back. And to argue these statistics, you’ve got to project forward, and we’re not just doing statistics. I would point out for the purposes of the debate, Michael conceded the most important statistic which is homeownership, the affordability index for families, he also attempted to make the argument, I wanted to point it out so that the audience contest it that he doesn’t really think that matters.

I’ve never met a young couple for whom the acquisition of their first home did not matter. Texas is making that happen for people. The one statistic that I’m going to hope Steve responds to, because I actually don’t know how to respond to it, that the Governor has on his favor is that venture capital is flowing in. I believe that’s because information workers here are not unionized and they do not have to worry about the right to work, the advantage of the South, so that they go and do Google and the center of gravity will be up there. On the other hand I think that creates hyper-wealthy super classes, not the sort of people that you want-- that will benefit from ta thriving middle class such as you would find in Texas and the energy states.

### Moderator
Claim: Let’s let Michael Lind actually come in and respond to that.

### Scientific Advocate (SA)
Claim: Yeah well I didn’t mean that housing and affordability is not important. But the point is the one time once in a century housing asset bubble that took place in the blue states, in Britain, in Spain, and the various parts of the world, that greatly inflated the cost of living in the blue states for macroeconomic reasons, which had nothing to do with policy one way or another.

As the housing sector deleverages, you’re going to see a decline in relative housing, not in point tower neighborhood, you know, not in the most desirable part of California, not in Central Park West, but in other blue states. So what you seem to be suggesting is “Yes we’ll accept these other legacy features of which are detrimental in the blue states-- I mean the red states, worse educational outcomes, worse health outcomes and all of that, but you get bigger houses.” If that’s going to be your argument that is a tragic trade off, where you have to trade cheaper housing for worse health care and worse education. You shouldn’t have to trade that.

### Moderator
Claim: But Michael in terms of a dynamic, in terms of education, your opponents pointed out that, in Texas for example, that the scores are rising among minority students. That in fact things are moving in the right direction very rapidly, and that in the blue states the reverse is happening. Now that’s a compelling argument.

### Scientific Advocate (SA)
Claim: That’s not the case in general across the blue states, and certainly not across the red states. They cherry picked one statistic. If you look at graduation rates, for example, in terms of education. The number of blue states with percentage of adults 25-34 with a college degree, the top are Massachusetts, North Dakota, a red state with energy, Minnesota, New York, New Hampshire, California, Iowa, etc. Only North Dakota is a red state. Of the bottom 10 there are only two blue states in the bottom 10.

### Moderator
Claim: All right so Stephen, is your side’s education argument undone?

### Conspiracy Advocate (CA)
Claim: Look you have to then defend the schools in the inner cities, right? I mean how do you explain the abysmal schools in Detroit, in Chicago, poverty in New York, in Boston, I mean the inner city-- and this is really I think one of the fundamental flaws of their argument. If the blue model worked then Detroit wouldn’t be bankrupt right?

Because there are no republicans in Detroit. It is a city that for 50 years has been ruled only by liberal Democrats. And one of the things I had warned you of is that if you want to move to these blue states, you know, one of the things that they have in those blue states that we haven’t even mentioned yet, is gargantuan unfunded liabilities in their pension. You want to talk about the legacy cost, look at the legacy cost of these blue states. So if you were to move from a red state to a blue state, you are basically condemning yourself and your kids to have to pay a huge amount of your taxes just to pay for the cost of the last 20 or 30 years for retired public workers where you get nothing in return for your tax dollars.

### Moderator
Claim: You’re saying the blue states are doomed, essentially?

### Conspiracy Advocate (CA)
Claim: I absolutely-- I think-- look, the blue states either have to change or die.

### Moderator
Claim: Become red.

### Conspiracy Advocate (CA)
Claim: They are like East Berlin, they are like East Germany, and they’re like--

### Moderator
Claim: Again it’s the trend question, Gray David.

### Scientific Advocate (SA)
Claim: Yeah, listen I believe you have to prove your worth every day. And I give my opponents credit for pointing out some modest increases in performance in Texas and other states, but in California 33 percent of the residents have a college degree, in Texas 25 percent.

Talking about the future, the future is being invented in Silicon Valley, it is not being invented in the southern states, in the plain states, and it’s because of great research universities. Alan Greenspan told me “You have something no other state has. 13 research universities. Cal Tech, Stanford, SC, 10 UC campuses. Those states create whole new economies. Invest in those states.” I raise the research and credit from nine to 13 percent, and to 20 percent if you use the universities. That is why there’s just a bubbling cauldron of academic innovation marrying up with venture capitalist and entrepreneurs that keep California current and at the leading edge.

### Moderator
Claim: Hugh Hewitt-- lets--

### Conspiracy Advocate (CA)
Claim: You know what they don’t have-- just one quick thing. What they don’t have-- You’re actually right. There is a lot of entrepreneurial high tech stuff, you know what’s disappearing rapidly from California is manufacturing, and that’s because--

### Scientific Advocate (SA)
Claim: We are the leading manufacturing state in America by jobs, and the leading factory state by--

### Conspiracy Advocate (CA)
Claim: You’re losing them by droves.

### Scientific Advocate (SA)
Claim: --by $230 billion dollars. You’re talking about infinitesimal change. We are a colossus here, not perfect. Sometimes great, sometimes a failure, but little incremental achievement here does not substitute the extraordinary impact that technology has had on our life and technology is driven largely by the blue states, Massachusetts and California.

### Moderator
Claim: Hugh Hewitt.

### Conspiracy Advocate (CA)
Claim: I want your vote, and I want your vote based on this thought. When Stephen illustrates, perhaps a little bit over the top with the North Korean explanation, but what he illustrates-- what he's talking about is the inability of California to change its institutions. They're not doomed. They are bankrupt. They are functionally bankrupt. And the inability to change is because there are super majorities in the state legislature and this occurs in New York and in Massachusetts and other doomed blue states to bankruptcy.

Doomed to bankruptcy. Illinois,

### Moderator
Claim: Hugh, why is that their blue state-ness?

### Conspiracy Advocate (CA)
Claim: Because they've done deals with public employee unions that cannot be paid for. They've written checks that cannot be paid for, except three generations down the road; there are scores, hundred, thousands of six-figure retirees at the age of 50 in California, governor, and I'm sure you can speak to this. It wasn't your fault. You inherited a lot of it, but you've got prison guards walking around at six figures that people have to pay for and the lifespan, and Michael, one quick response, we don't have to worry about those uninsured, right? Didn't Obamacare fix that?

### Moderator
Claim: Michael Lind.

### Scientific Advocate (SA)
Claim: Actually, Obamacare--

### Conspiracy Advocate (CA)
Claim: They took it out of the system. They could log on.

### Moderator
Claim: Let's hear from Michael Lind.

### Scientific Advocate (SA)
Claim: Well, I'm not here as a partisan Democrat or a defender of the president. I am a defender of the interests of the ordinary people of the red states who are overwhelmingly working class and poor.

What we have heard from Stephen is that if you are a wealthy enough person to be concerned about progressive income taxation, it's better to live in a red state. If you're a business whose business model is not based on R&D and it's also not a locally-based thing like Starbucks that has to be done there, but it's a footloose business that depends on nonunion labor, like labor-intensive chicken plucking, for example, in that case you'd be better off in a southern red state than in a northern or western blue state. I agree. That's why Arkansas leads the world in labor-intensive chicken plucking. But that is not your typical 21st century business.

### Moderator
Claim: Let me take you something--

### Scientific Advocate (SA)
Claim: One more point about the taxes.

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: If you are poor in Texas, you pay 12 percent of your income in taxes, because Texas, like other southern states, relies heavily on regressive payroll-- regressive property and sales taxes. If you're rich in Texas you pay 3 percent. Now, what kind of society is it where the poor people pay four times as much of their income as the rich people?

It's a libertarian ideal. If you want to get rid of all taxes on the rich and on inheritances and have nothing but a flat tax, but that has a cost, too, in addition to housing--

### Conspiracy Advocate (CA)
Claim: But, Michael, you just said that the middle class people are moving to Texas. So, if it's so horrible there in Texas with the taxes, why do they move there? And the answer to that question, by the way is J-O-B-S. That three-letter word that Joe Biden always talks about. Jobs are in those states, and that's where--

### Moderator
Claim: Let's hear-- I want to hear Michael-- it's a great question, actually, and I want to hear Michael's answer to it, too.

### Scientific Advocate (SA)
Claim: Yeah, and the answer to that is F-R-A-C-K. They are not moving.

### Conspiracy Advocate (CA)
Claim: All right. I have to address that.

### Scientific Advocate (SA)
Claim: You are not seeing California and New York and Massachusetts emptying out to go to the flourishing business districts of Arkansas and of Mississippi.

### Moderator
Claim: All right. Just one second, Stephen. If you took out the energy sector from the red states, what do you think you would be left with?

### Scientific Advocate (SA)
Claim: Well, we have had studies since the crash of 2009. This was reported recently in "U.S.A. Today.” The largest contributions to income in the red states in the last few years have come from two things, energy--

### Moderator
Claim: My question was slightly different.

### Scientific Advocate (SA)
Claim: --and federal food stamps for poor southern states.

### Moderator
Claim: My question was slightly different. If you took out the energy sector, what would happen to the flow of population toward the red states away from the blue states?

### Scientific Advocate (SA)
Claim: Well, we saw this when the Texas energy bubble burst in the early 1980s, and there was a reversal to the Midwest.

### Moderator
Claim: Okay, I want to go to Stephen Moore. Stephen Moore.

### Conspiracy Advocate (CA)
Claim: First of all, Michael, thank you. This is the first time in about five years I've had a liberal talk about how great fracking is, because you are absolutely right. Fracking is changing America overnight. We tripled our energy resources overnight, because of this incredible American ingenuity. Now I am not going to let the two of you get away with saying it's just happening in these states-- these red states, because they have energy resources, because guess what, ladies and gentleman? Guess what state other than Texas has the most energy resources of any other state?

### Moderator
Claim: California.

### Conspiracy Advocate (CA)
Claim: California. California does. California has five billion barrels of oil in the Monterey shale.

What is different about Texas than California? I wrote an editorial about this a few weeks ago. Texas is proud to be an oil and natural gas state. California is embarrassed by it. If that's how you create jobs, why in the world, governor, won't you allow fracking? Why isn't the state going full speed ahead? California used to be the second most energy producing state in the country. It has been surpassed by North Dakota and other states because they choose not to do it. Texas-- I mean the state of California, to give you a sense of how crazy they are in Sacramento, they actually passed a cap and trade bill, which is basically putting a tax on your own industry. Now I don’t care what your opinion is on global warming, whether you think it’s going, you know, the greatest apocalypse for the earth, there’s nothing California can do to change the global temperature--

### Moderator
Claim: I know Gray Davis is going to want to respond to that and I’m going to let you in one second. I want to go to-- I have one more question then I want to go to audience questions after that and I just want to remind you if you raise your hand and if you can stand up and just tell us your name, it can be first name, it’s fine with us.

A microphone will be brought to you or I might ask depending on where you’re sitting, because of where our cameras are located to go to a stand in the aisle. So Gray Davis, if you’d like to respond to that?

### Scientific Advocate (SA)
Claim: Yeah, two things, we dropped all the way from second to fourth, Steven so we’re still in the top five. The governor has come out in favor of fracking done responsibly, so has Obama, this is a great opportunity to rid of ourselves of dependence on the Middle East and whether you’re Republican or Democrat, you should be for responsible exploitation of our natural gas and oil resources and that’s what we’re doing in California, but I do want to make this point: that why do so many people live in blue states? Are they all misguided? Are they all getting it wrong? They’ve lived there because they have more opportunity, they make more money, they’re healthier, and they enjoy their lives more.

Do we have high taxes and regulation? Yes, but the outcomes are positive otherwise people would move so a margin-- a little .9-- .009 percent people moving here, moving there are just white noise. The fact is blue states are the makers, red states are the takers. Almost every red state in America gets more than 100-- no, I don’t mean that in a negative sense, I mean that in the sense of Romney, because Romney was talking about who takes, who makes the blue states produce GDP, the red states get more money back from the federal government than they send to Washington. For example, Texas ranks 11th in money back from the federal government, California, 32nd. We make it on our own.

### Moderator
Claim: And so those statistics actually hold up in terms of where the federal dollars come and go. So I want to go to Hugh Hewitt, your opponents have now depicted the red states as states that depend on one industry, energy, which if it were gone would blow up the whole thing and that it’s depending on a sort of flow of federal dollars that come more into the red states and the red states the other way.

So they’ve taken two reasons that the red state vision you’re depicting is a little bit of a fantasy or is running on fumes-- without both of those things it’d be a different world. I’d just like you to respond to those points.

### Conspiracy Advocate (CA)
Claim: Sure, I’m amused by the idea that we can’t count energy, that’s like saying engines don’t matter to cars. They’re there, they’re fixed and they will be there for a very long period of time. It’s like saying California greatest advantage, which is its coast, its extraordinary coast, its harbors, its ability to tap into the Pacific Rim which they have not damaged. In fact Governor Davis did quite a lot to advance international trade, that’s its natural advantage and they use that. They do not use their energy but I don’t think we can penalize states that use their energy resources and I’ll also say this, the states which are technically blue but operationally red, Michigan, Pennsylvania, and my home state of Ohio are in fact going to become red over the next 30 to 40 years, which are a time frame that I think we’re talking about the future, we think of our children, our grandchildren.

I think you look out there and you see that they become energy producing states. Their governors are adopting free market enterprise solutions, and that they will be the future because they’re going red not blue and those under class that you worry about Michael, rightly, are going to have greater opportunities to advance under what Arthur Brooks put forward as earned success but you’re saying--

### Moderator
Claim: So you’re saying that you don’t want to entertain the hypothetical question of what the red states would be without energy because the energy is there?

### Conspiracy Advocate (CA)
Claim: Well, because your kid has to actually move my framework, you got to pick a place to live, you got to go. We don’t remove the energy boom that Steven refers to accurately as the most transformative single event in the economy of the last 50 years. You can’t factor it out for the purposes of the debate.

### Moderator
Claim: And Gray Davis’s point also on where federal dollars come and go, Hugh?

### Conspiracy Advocate (CA)
Claim: Well that’s a variable, federal dollars will not be there for much longer unless we want the country to go as bankrupt as California is.

### Conspiracy Advocate (CA)
Claim: Just one quick point about oil and gas--

### Moderator
Claim: Steven Moore.

### Conspiracy Advocate (CA)
Claim: Just a really quick point, Michael, if you take the oil and gas sector out of the U.S. economy over the last five years, guess what?

There’s no recovery at all-- I’m exaggerating a little bit but about 90 percent of the growth of the U.S. economy is due to the oil and gas sector, and by the way that’s under a president who hate fossil fuels. I mean the ultimate irony of this president is he will have presided over the biggest oil and gas boom in the history of this country. So how can you take the oil and gas boom out? I mean one other quick thing, you know, in New York, we’ve been talking about a lot of California-- in New York, Governor, they did actually pass a ban on fracking. And you know what, the Marcella shale goes into New York, upstate New York in places like Syracuse and places like Rochester that really need those jobs. So in Pennsylvania what they’re doing is the drilling down, they’re going horizontally--

### Moderator
Claim: Stephen.

### Conspiracy Advocate (CA)
Claim: --underneath New York--

### Moderator
Claim: Stephen.

### Conspiracy Advocate (CA)
Claim: --And they’re taking out all their oil and gas and love it--

### Moderator
Claim: Stephen I just need-- Stephen I need you to be interruptible more. Because you’re vivacious, and energetic and it’s great, but I-- it’s just in terms of the clock if we had the big clock you would have many more Stephen minutes right now than Michael Lind minutes, so let’s let Michael then respond please.

### Scientific Advocate (SA)
Claim: I’m glad to find a point of consensus among us. But you seem to have discarded the theory that you had for most of this debate, which is that the key to economic growth is low personal income taxes on business, rather than regulations that allow fracking. So I’m glad that we agree on this. We will continue to disagree about whether absence, the-- geographic accident of energy resources in your state border, the traditional southern low wage, low tax, low investment model is going to lead to prosperity or another century of Southern stagnation.

### Moderator
Claim: Let’s go to some questions from the audience and--

### Conspiracy Advocate (CA)
Claim: But wait, John that’s like absent air, that-- absent-- that’s the whole thing is the ability to go get it.

### Moderator
Claim: Hugh-- do the radio thing, 30 seconds go.

### Conspiracy Advocate (CA)
Claim: If you say absent energy you are creating a world that does not exist. Everything depends on-- energy is freedom, it’s everything.

### Moderator
Claim: Gray very quickly.

### Scientific Advocate (SA)
Claim: Yes Hugh was talking California banking, Hugh you’re about five years behind the time.

All the rating agencies have upgraded California. Jerry Brown’s got a lot of credit for taking a $26 billion deficit-- I created about $10 billion and it got worse in between-- and eliminated that through $11 billion worth of cuts, economic recovery, and the $6 billion temporary tax that the people voted on themselves. So he’s gotten high marks for getting us out of the mess. He will keep us out of the mess, because there is no more frugal a man. When I was his chief of staff, I came into his office, I said “By the way this hole in your rug is a little unseemly.” About this big, there was a hole in the rug. “So I’ve asked general services to fix it.” This is the 70s. He said “You did what?” “Well the governor can’t have a hole in his rug.” He said “Do you understand this hole has saved us $600 or $700 million. People can’t come in here and pound on my desk and say, “Give me money for mental health, give me money for this” if we have a hole in the rug.” So I guarantee you while Jerry Brown is governor California’s finances are going to be just fine.

### Moderator
Claim: Ma’am your question?

### Moderator
Claim: Yes Linda Childers. If you were going to start a foundation would you locate it in a red or a blue state?

### Moderator
Claim: What a great question. That’s sort of the “Where would you send your kid?” question, but with some money behind it. Let’s take it to Hugh Hewitt first.

### Conspiracy Advocate (CA)
Claim: First I’d ask Adam Myerson, my old friend, about that. But my guess is that you want-- if you were going to start it you would probably go to a blue state, to an intellectual capital. I want to be very honest here. That’s not the proposition before us, but I think you would want to go to one of the great intellectual capitals. There are some contenders in the red states, but I think probably they are overwhelmingly located in Los Angeles, San Francisco, Washington D.C., and New York.

### Moderator
Claim: I have to say I have to congratulate you for not just taking that and turning a point into is, but for sometimes conceding that the other side has advantages is really in the spirit of what we’re trying to do here, so it was great to not hear just hear a talking point. I just want to say thanks.

### Moderator
Claim: It’s nice that we can make that concession.

### Moderator
Claim: So you’ve been working with Fox lately right?

### Conspiracy Advocate (CA)
Claim: Just one really quick point, I don’t know about setting up a foundation, but if you’re someone with wealth you sure as hell don’t want to die in a blue state, or they’re going to take 10 percent of your money. So die in a red state.

### Moderator
Claim: That would be such a great motion. “If you ought to die”

### Conspiracy Advocate (CA)
Claim: If I have it right “Live it in a blue state, but before you die move to a red state.”

### Moderator
Claim: Let’s hear a response from the other side on the foundation question. Gray Davis?

### Scientific Advocate (SA)
Claim: Well, I just want to invoke the wisdom of Hugh and rest my case. Set it up in a blue state.

### Scientific Advocate (SA)
Claim: I have nothing to add to the deathbed migration theory of the foundation factor.

### Moderator
Claim: I still congratulate Hugh Hewitt for saying what he said. Are there are any other questions. Yes ma’am please go ahead. I’m sorry mic’s not. One more time.

### Moderator
Claim: Heather, who admits to living in Manhattan. The question is for Michael and your contention that what we’re seeing is no different than the historical difference between Northern and Southern states for the blue and the red states. Jonathan Haidt in his book “The Righteous Mind” makes the point-- and he’s a liberal democrat-- that “The great problem with the liberal project is that it starts with very good intentions, but never sees the unintended consequences cost” in human capital and economic consequences of these projects.

Is it not the case that what we are finally seeing is over the time of the progressive project in these blue states, well intended as they may be, that those chickens are finally coming home to roost, and that is what is making the difference between the red and the blue states?

### Moderator
Claim: Michael Lind.

### Scientific Advocate (SA)
Claim: Well I think there are deep flaws within the progressive liberal project as there are within the conservative project and the centrist project, but I don't think that explains the difference. The real difference-- it goes back to the fact that we haven't raised yet, which is this has really been two countries for most of its history. You had the slave states and then later the segregation of states, and they just fell behind. In 1900 the difference in per capita income between the south and the north was greater than between Czarist Russia and Victorian Britain.

And we've become a much more integrated nation state since then, but you just have a long way to go. And my concern, as a native of the red states, is that the south in particular can get trapped in a permanent semi-developed status if it has an essentially parasitic strategy of trying to use low taxes and anti-union laws to lure businesses from old, more developed parts of the country. We saw what the textile industry-- this can work for a time. In the 20th Century, the Carolinas, other southern states, lured the textile industry, which was actually created in Massachusetts in the northeast. Once you have a global economy there's always a Mexico. There's always a China. And then with China wages go up you lose factories to Vietnam and Thailand. So I don't think any states of the union in the 21st century can count on a race to the bottom where we have lower wages than you do. I think all of the states have to have a race to the top.

### Conspiracy Advocate (CA)
Claim: This is one of my fundamental disagreements-- to Michael and that kind of left-wing thinking. They think it's worse to have, you know, no job at all at $14 an hour than a lot of jobs at $9 and $10 an hour. And I just disagree with that.

### Scientific Advocate (SA)
Claim: I don't think that.

### Conspiracy Advocate (CA)
Claim: I think one of the problems with, you know, the effects-- I think California just raised its minimum wage. There are a number of blue states that are raising their minimum wage. What they're essentially doing is pricing out of the market low-wage jobs.

### Conspiracy Advocate (CA)
Claim: They're going to have higher unemployment rates and, by the way, when you do that what you do is you take away the lowest rungs of the economic ladder, because we all started-- I don't know about you, Hugh, but my first job was a minimum wage job at $2.60 an hour, but that was maybe one of the most valuable jobs I had. I just disagree with that philosophy.

### Moderator
Claim: Ma'am, do you--

### Conspiracy Advocate (CA)
Claim: There's no such thing as a bad job.

### Moderator
Claim: Ma'am, do you feel that your question was just addressed?

### Moderator
Claim: I'm to the other side.

### Moderator
Claim: All right. Your question was are the chickens coming home to roost for the blue states, and Michael started with that but moved in a different direction. I think it's a great question and I'd like to take it to you, Hugh.

### Conspiracy Advocate (CA)
Claim: Well, I will answer the question with a question, which I will direct to the governor. Governor, is the California Teachers Association a force for the good? Are you going to run for a public office again?

### Scientific Advocate (SA)
Claim: No. I'm not going to run for public office again, so-- I will be honest. I think we all can remember a teacher or a professor in our lives that sparked our imagination, that helped set us on a different course of action. I remember speaking to my history teacher, who was also my baseball coach when I was in the tenth grade, and I wasn't making the baseball team. I didn't think he even noticed me and he came up to me and he says, "Gray Davis, you could actually make something out of your life if you just had a little drive and ambition, but you're such a happy-go-lucky kid, I just don't know what's going to happen to you. But if you just get your act together things could be fine. Here's my home number if you have any problems with your homework. Call me.”

### Moderator
Claim: And he was a union member?

### Scientific Advocate (SA)
Claim: Wait a minute. No, no. He was not in the union.

### Moderator
Claim: Oh, he was not? Okay.

### Scientific Advocate (SA)
Claim: No union at the school.

### Moderator
Claim: I just wanted to keep it on point.

### Scientific Advocate (SA)
Claim: But my point is I was so blown away that someone was taking an interest in me outside of my family that I understood the power of mentorship and the power of someone believing in you, and there's no substitute for that.

### Moderator
Claim: Okay, but it doesn't actually answer the question.

### Conspiracy Advocate (CA)
Claim: Oh, it did. Yes it did.

### Scientific Advocate (SA)
Claim: I'll tell you. Teachers are very important. Associations and unions obviously fight for better members, for better pay and better conditions. Sometimes I agree with them. Sometimes I didn’t. My first year I put in the high school exit exam, the academic performance index. In August of my first year, teachers’ unions were running commercials against me saying “We thought this guy was for education. We don't think he is.” I raised the amount of money that went into education by 30 percent. No governor ever has done that. No governor will be able to do that again. So, I rest my case. So I understand the difference between helping education, telling every kid that they can get better, measuring their progress, and paying the price for it with teacher unions.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two debating this motion: "For a Better Future, Live in a Red State.” Sir.

### Moderator
Claim: I'm Frank Baxter, a fourth generation--

### Moderator
Claim: Sir, actually, you're one of the folks-- we would appreciate it if you could-- because of where our camera angles and the light, sorry, if you wouldn't mind just going down the aisle towards where that gentleman is standing and then we will-- the camera can see you and you can start again and thank you for that.

### Moderator
Claim: Thank you. I'm Frank Baxter, a fourth generation Californian, and I think that with other Californians, that it’s a wonderful place to live if you’re rich, live on the coast. If you’re poor and live in the Valley where the unemployment rate is 30 percent, where less than half of the children statewide graduate from high school, where we pay the lowest amount per pupil of any state except Mississippi, where we’re cutting back--

### Moderator
Claim: Sir, could you just go to a question, thanks.

### Moderator
Claim: And the question is, are the blue states a good place for the elite, but where the poor people are oppressed?

### Scientific Advocate (SA)
Claim: I want to handle that.

### Moderator
Claim: Gray Davis.

### Scientific Advocate (SA)
Claim: First of all, ambassador, I want to commend you because you have done more to start charter schools in south central Los Angeles-- On a bipartisan basis and you know when I was governor we were very close together for more charter schools to make sure they got money out of construction bond issues, and to give them opportunities to succeed so my point is good people will find ways in which to improve a challenge educational system and it doesn’t mean that you have to move to a red state. If you’re good-- you can do it in a red state but--

### Moderator
Claim: But Governor, I’m only interrupting because we have very limited time and I want to keep on point but his question was is the state better for the elite then for everybody else’s? Is California set up that way?

### Scientific Advocate (SA)
Claim: I mean obviously elites will do well wherever they are, but California and other blue states work very hard to see that children, minority children have advantages, have extra training afterwards, after school programs, and there is evidence that the gap between minority students and majority students is closing. It’s a constant struggle, you have to be ever vigilant, but progress has been made. Is it a difficult challenge? Yes, but I don’t think it’s unique to blue states and it’s not unique to red states.

### Moderator
Claim: I was going to ask your partner, Michael Lind, is that phenomenon unique to blue states and then I want to go this side.

### Scientific Advocate (SA)
Claim: No, and part of the problem with this debate is we have to limit ourselves to state borders. If you actually look at a county by county basis what you have is very affluent blue cities including blue cities in Texas like Austin and Dallas and Houston, which are increasingly liberal and very, very affluent. Of course it is the case that as areas develop then the middle class and the working class sometimes get forced out because of the cost of living.

That is not necessarily a bad thing, because it’s better than not developing at all. And in fact I think there’s good inequality and bad inequality. Good inequality is when the wealthy elite is there because they’re entrepreneurial and they’re inventing something. Bad inequality of the kind that’s all too familiar in the South is because of a lack of bargaining power on very low income people who have very little leverage compared to their employers. So you know there’s a downside to northern California being the head of the tech industry with billionaires driving up prices and then driving out the middle class, but I would rather be in a state that has that problem than in the other kind of state.

### Moderator
Claim: Okay, I want to take-- I’ve let this side answer two speakers in a row. You can have two speakers in a row if you want but I’m interested in your answer to the same question. Is California an example of a state that’s very, very-- it’s great if you’re rich and it’s not so great if you’re not? Hugh Hewitt.

### Conspiracy Advocate (CA)
Claim: Absolutely it is, the agony of the urban core in California is pronounced. That agony is everywhere in every urban setting but it is more pronounced in the super cities.

I’ve spent Thursday morning last with Father Gregory Boyle who has been running Homeboy Industries in south central Los Angeles for 24 years I believe. He’s buried 183 gang kids over the course of his ministry. It is a tough, tough place to be poor, it is a wonderful place to be rich.

### Moderator
Claim: Steven Moore, do you want to take it on or move on to--

### Conspiracy Advocate (CA)
Claim: My statistics show this and by the way unfortunately it’s not just happening now in blue states. You know we are now in the fifth year of recovery, the most animated feature of this recovery is the rich are getting richer and the poor are getting poorer. Exactly the opposite of what the president wanted to have happen. By the way, I have nothing-- there’s nothing at all wrong with people getting rich. Someday I want to be rich myself, but you know the fact is that this has been a dreadful, dreadful recovery for low income people and that’s because we have adopted kind of liberal blue state policies on a national level that have reduced opportunities for those at the bottom.

### Moderator
Claim: So it sounds like for the purposes of this debate on that point, this is a wash. That none of the red states nor the blue states are better off in this regard.

### Conspiracy Advocate (CA)
Claim: Hold on, I just want to make this quite clear--

### Moderator
Claim: Steven Moore.

### Conspiracy Advocate (CA)
Claim: But the blue states make it worse because they take Obama’s policies and then add on to them like when California raised their minimum wage. When you raise your minimum rage, you hurt your lowest skilled workers, so you make your poorest workers poorer.

### Scientific Advocate (SA)
Claim: We raise our minimum wage--

### Moderator
Claim: Gray Davis.

### Scientific Advocate (SA)
Claim: Because we’re trying to lift all votes. You may think it’s cool to live on $9 an hour, but we’re trying to allow to be a little better than that.

### Scientific Advocate (SA)
Claim: Economic literature shows that if there are bad effects, they are slight compared to the greater income the people with the new minimum wage have. It is simply not the case. Conservatives and Libertarians for 30 years have argued there would be mass unemployment if you raised the minimum wage-- the US raised the minimum wage every few decades. The mass unemployment has not materialized. The mass unemployment we have now, and the weak recovery is not the result of George W. Bush, under whom it started, nor is it to be blamed on Barak Obama. We had the greatest Global depression in fact since the 1930s.

We call it the recession. This is a global phenomenon that we’re working out over many years. And I just think it’s just kind of petty and partisan to blame it on one president who is being stymied in Congress by filibusters and--

### Conspiracy Advocate (CA)
Claim: He didn’t invent the minimum wage, but the pernicious effects of the minimum wage on the underclass are pronounced. And that is where it’s most devastating.

### Moderator
Claim: Sir? Wait, wait. Ma’am, I’m moving on to other audience members with respect, just so that we can bring in some other voices. Can you tell us your name?

### Moderator
Claim: Yeah I’d like to-- Paul Marrow I’d like to ask a question that’s a little bit different play on the previous question. I’m from Utah where we have a very strong middle class statewide. And as my wife and I were driving in from Long Beach airport to here we got to kind of this hilly area is, and she says boy you don’t want to live on this side of the hill, do you?

You want to live on this resort side of the hill. And so for me, I want to ask specifically does a strong middle class play into your motion? What does the middle class have to do with your motion?

### Moderator
Claim: Can I rephrase your question?

### Moderator
Claim: Please.

### Moderator
Claim: And with your agreement to “The middle class has a better shot in a red state in a blue state.” If we were to rephrase it that way. In which state does the middle class have a better shot at staying middle class, or--

### Moderator
Claim: I would like the panelists to address the importance of a middle class. And whether you’re going to find the middle class more so in a red state or a blue state.

### Moderator
Claim: That’s how I wanted to hear it. Hugh Hewitt.

### Conspiracy Advocate (CA)
Claim: Absolutely it matters, and I default to the Catholic middle class in the 50s and 60s that wrote his wonderful book about. And how it provided structure, opportunity, and growth for legions of people.

And the red states have, as I pointed out in my opening remarks, the greatest amount of volunteerism, the greatest amount of generosity, the greatest amount of those indicators of community that would provide the guard post for the development of a middle class. Because we all project upon our children their success, our success, but what we’ve got to really think about is someone who’s rising, and where will they be nurtured if they are indeed in the lower class attempting to move to the middle. And I believe the rest states provide the greatest opportunity.

### Moderator
Claim: Why, Hugh? Why?

### Conspiracy Advocate (CA)
Claim: Because they have the greatest number of churches. The greatest number of volunteers, because they have the greatest civic involvement. They are not elites dictate to underclasses, they are middle classes prospering together.

### Moderator
Claim: Other side, let me go to Michael Lind first, and then I’ll come to you Gray.

### Scientific Advocate (SA)
Claim: Yeah, if you look at the states which have the lowest extremes of inequality, the biggest middle class relative to the rich and the poor, they tend to be great plain states. Where simply there aren’t that many rich people, and there aren’t’ that many poor people, they’re largely rural.

Many of them were settled by Germans and Scandinavians with a communitarian sense of the local public sector. So I don’t think you can make the percentage of the population the main criterion, because the great plains, apart from the ones with recent energy development, have been losing population. People have been moving away from that towards blue states, and some red states, which are more unequal. I think the problem-- the problem is also in opportunity as your economy becomes more complex you get more of a class system. You get more and more rich people and you get some who fall by the wayside.

### Moderator
Claim: Michael I’m not sure how you’re answering the audience member’s question.

### Scientific Advocate (SA)
Claim: So if you want to live in a state in which the majority of the people around you are middle class, and you don’t have extremes, then you should probably go to Nebraska or North Dakota or South Dakota or something like that. That is not, I think, the typical red state model that we’re thinking about, which is more of the southern model of low taxes. Because those states, remember, were quite progressive in the 19th and 20th centuries and they have public banks in some cases.

### Moderator
Claim: We have time for one more question. I’m sorry can you be very brief because we’re almost out of time? Thanks.

### Scientific Advocate (SA)
Claim: I would argue that the blue state model is more inclusive and more concerned about everyone having an opportunity to achieve their dream. America is all about believing you can do something, and giving the opportunity to achieve it. It’s both in the interest of middle class, the underclass, and the rich for the middle class to do well. They’re the glue that holds society together. The better they do, the more are more investors. There are better stakeholders. I tried to help that by creating merit scholarships. You didn't have to be poor, but if you tested in the top 10 percent of your class in public school you got $1,000 scholarship every time you did that. I think we all agree education is the passport for a better life. We have to rethink how education can impose less debt on people. Maybe by using online education in a blended fashion, but middle class folks are very important in the blue state model to be responsive to your question.

### Moderator
Claim: Right down front here. Sir, you're fine where you're standing. That's-- we can see there.

### Moderator
Claim: Manny Goldstein I've got a question for Governor Davis, but first I want to chastise Hugh Hewitt.

### Moderator
Claim: I can't give you time to chastise Hugh Hewitt. Please members.

### Moderator
Claim: I'll give you my two minutes. Go ahead.

### Moderator
Claim: We just don't have the time and we're very strict. Sir, I need you to ask a question.

### Moderator
Claim: Right.

### Moderator
Claim: Thanks.

### Moderator
Claim: There's a lot of literature now about the hammerlock, which public service unions have on public policy and legislation in California. Forget about the pension problem. Is that something that California is going to cope with or not cope with?

### Moderator
Claim: I'm going to pass on that question, because it doesn't-- I don't think it helps us understand the difference between the states directly enough. Ma'am, right here. And if you-- I just want to check whether the camera can see you.

### Moderator
Claim: Call a state red or--

### Moderator
Claim: Ma'am, just one second, because we would like the live stream to see you. Is that going to be okay? If you could step out to where that gentleman is. Thank you.

### Moderator
Claim: Calling a state a red or a blue state is defined by the governments and the elected officials, but this is not cast in concrete. We've seen a tremendous change in the state of Wisconsin, for example. So, let's call them purple states, the ones that kind of flux back and forth and aren't predictable necessarily. Virginia is a little bit in that position right now.

### Moderator
Claim: So what is your question?

### Moderator
Claim: So how do we move states one direction or another? What's the key for elected officials to woo voters?

### Moderator
Claim: Again, I think that what you're asking is already built into our motion, so I'm going to go on-- it's not that it's a bad question, it's just that we're trying to talk about, which place would you want to live in? I don't want you to go into it, please, because we don’t have the time. But afterwards you can chat. One more question, and I say that with respect, because I do think it's a very valid issue. Sir, and again, if you could go down that aisle. Thanks. If you could go back just to where that gentleman is.

### Moderator
Claim: Am I okay now? Farther, okay.

### Moderator
Claim: It's just-- you see that camera out to your right is trying to see this. Thank you.

### Moderator
Claim: I forgot my question.

### Moderator
Claim: I'm sorry.

### Moderator
Claim: I want to talk about dependency. Folks who are receiving welfare in general, we're talking about happiness. If you're highly dependent on the government it's hard for many Americans to understand how you can be happy. Could you comment on red states versus blue states and dependency and welfare? Thank you.

### Moderator
Claim: It's not a question. I mean it's a question could you comment, but--

### Moderator
Claim: Which is better? Which states are better, blue states or red states, to reduce dependency?

### Moderator
Claim: If-- in other words, if you're living in a life where you are dependent, which state offers you the better chance to become independent?

### Moderator
Claim: Yes.

### Moderator
Claim: Okay. Thank you. Okay.

### Conspiracy Advocate (CA)
Claim: Well, I guess my response would be is that a trick question? Look, California has the highest welfare benefits. It used to. I don't know the last few years, but for the last 20 years or so California has had the highest welfare benefits and they've had incredibly high dependency on welfare. We saw in the 1990s one of the great social experiments in this country where states started-- and, by the way, red governors, states like Tommy-- you know, Tommy Thompson and John Engler, they really changed the welfare system, put in place common sense reforms like time limits and work for welfare requirements and getting people back into school, and boy did that work. And one of the things that's discouraging is a lot of blue states are moving away from those policies and put-- I mean, you've got a lot of blue state politicians who actually think it's a stimulus for the economy to put people on food stamps, and I'm not making this stuff up. They think it's good for the economy to put more people on food stamps.

### Moderator
Claim: All right. Both your opponents want to speak. Gray Davis and then Michael Lind.

### Scientific Advocate (SA)
Claim: There are 26 states that refuse to participate in the health care exchanges that Obama is setting up under Medicare-- under Obamacare, Affordable Care Act.

Of those 26 states, all but three receive more money from the federal government than they send to the federal government.

### Scientific Advocate (SA)
Claim: In fact, here's a list of the top 10 and the vast majority of this is actually going to poor people, because there are more poor people proportionately as part of the population in red states, particularly in the south, than there are in the blue states. New Mexico, Mississippi, Alaska, Louisiana, West Virginia, North Dakota, Alabama, South Dakota, Virginia. Some of this is farm aid, a majority of it means tested welfare and anti-poverty aid. So if the question is where are benefits at the state level more generous, anti- poverty benefits are more generous in blue states, which tend to be wealthier in general.

### Moderator
Claim: Steven Moore.

### Scientific Advocate (SA)
Claim: If you ask where the people in need of anti-poverty programs are they’re disproportionally in the red states. They have more poor people.

### Conspiracy Advocate (CA)
Claim: It’s funny how blue and red hear differently, I heard your question as being in what category of state blue or red will a poor person have a better chance of not-- of becoming not poor and I believe that that is simply a function of where jobs are created and jobs are being created overwhelmingly in red states, and so if you are poor and you don’t want to be poor, if you want to embrace earned success which is in the happiness research the most important thing, read Arthur’s book “The Road To Freedom.”

## Round 3

### Moderator
Claim: That concludes round two of this Intelligence Squared U.S. debate where our motion is “for a better future live in a red state.” And now we move to round three and in round three we will have closing statements by each debater in turn. They will be two minutes each. This is their last chance to try to change your mind. Remember how you voted before the debate? Right after this, we’re going to ask you to vote again and the team whose numbers have moved the most in percentage terms will be declared our winner. Our motion is for a better future live in a red state and here to summarize his position against this motion, Gray Davis, the former governor of California.

### Scientific Advocate (SA)
Claim: Well, I very much appreciate this debate being held here and I thank all of you for attending and all the participants. Clearly blue states offer opportunity, longevity, better health care; more things are possible. Do we have problems? High taxes, regulations, yes; everything is a mixed bag. Everything has a flip side, but if your son or daughter or grandchildren are looking for a way to help change the world to make an impact on society, to reach their highest potential, they have the best opportunity in the blue states of the north east, the mid-west, and the far west. Steven said to me privately what he said publicly, he said “my God, why would anyone live in a state other than California?” Steven, I wholeheartedly endorse that sentiment.

### Moderator
Claim: Thank you, Gray Davis. Our motion is for a better future live in a red state and here to summarize his position in support of the motion, Steven Moore, an editorial board member and senior economics writer for the Wall Street Journal.

### Conspiracy Advocate (CA)
Claim: One of the great, great-- Thank you, one of the great, great, things about our country is, we are 50 states, you know, and you can choose where you live based on the policies that you agree with and it’s a wonderful thing by the way that you can move to California where you may have the policies that Michael and the Governor like or you can move to a red state and choose those. I would make the case that those are states that believe in kind of more of a free enterprise, free market system, but you can all choose. Many of you in this room live in blue states, but I would make just a couple of quick points. Just one statistic to think about, each and every day in America for the last 30 years, 1,000 people every day have been leaving blue states and they’ve been moving to red states.

And I would submit to you that that is prima facie evidence that more opportunity, the very kind of opportunity you were talking about Governor, the kind of jobs that you were talking about, Hugh, those are being created in red states for one reason or another. The energy revolution or the fact that they have lower tax rates or less regulation or right to work, I think they all contribute to that so people can choose where they live and one of the things that we need to do in America, by the way, is get rid of a lot of federal policies and let states decide about health care, let states decide about welfare and work roles and so on and let these ideas flourish, but I would submit to you all if you think about America’s future and you really have to ask yourself this question, where is the future going to happen, America? Is it going to happen in Detroit? Is it going to happen in New York? Is it going to happen in Newark? Is it going to happen in Chicago? Or is it going to happen in places like Salt Lake, in places like Atlanta, in places like Kansas City, in states-- in places like Austin, and I would submit to you the future is going to happen in the places where the free enterprise system is flourishing. The free enterprise system is the goose that lays the golden eggs. That’s where you want to be.

### Moderator
Claim: Thank you, Steven Moore. Our motion is for a better future live in a red state and here to summarize his position against this motion, Michael Lind, policy director of the New America Foundation Economic Growth Program.

### Scientific Advocate (SA)
Claim: Thank you, where is the future going to happen, is Steven Moore’s right question to ask. In the last couple of years, Stanford University in conjunction with Google has driven hundreds of thousands of miles with its self-driving robot cars, which were the result in turn, of a competition sponsored by the federal government in conjunction with this leading California research university. I am from the red states, I like the red states; I would like to see California, New York, Massachusetts cut down to size. I frankly-- I would, personally. I do not think in my lifetime I’m going to live long enough to see Salt Lake City, Atlanta, and even Austin, my hometown, be competitive when it comes to nanotech and breakthroughs in robot technology and world class finance.

Now that’s not necessarily the test, but if you paint this picture of California and Massachusetts and New York, which have lead the economy for much of the 20th century and still do, in many high tech sectors, being emptied out as though they were East Germany, and people are fleeing like boat people and so on, I just think that’s a very misleading picture. There are real trends, and it’s not a matter of good and bad on both sides, but I think that blue states for the foreseeable future will not merely surpass the red states, but will continue to provide a model, because the revealed preference, as Hugh Hewitt says, is the fact that when they move to red states like Texas, the overwhelming number of new migrants are going to blue cities. Cities that vote liberal and vote democratic. Like Dallas, Austin and Houston, which as a result of this migration have become much more liberal than before the people moved there.

### Moderator
Claim: Thank you Michael Lind. Our motion is “For a better future, live in a red state,” and here to summarize his position in support of this motion, Hugh Hewitt, professor at Chapman University Law School, and host of the Hugh Hewitt show.

### Conspiracy Advocate (CA)
Claim: John, thank you you’ve been an excellent moderator, very fair and rigorous, and thank you Governor and Michael, great and worthy opponents. And thanks to Stephen who actually made the case that I think we were done after round one. I really would like your vote, and I really would because I think it would send a message. Let me tell you in 1998, the year that Governor Davis was elected, we passed one of our propositions, Prop 10, which put a 50 cent per pack tax on cigarettes. And then that money goes back to the counties, to the boards that spend it on children 0-5 to improve their health and their readiness to learn. I’ve served on my Orange County prop 10 board for 15 years. The problems are staggering.

The amount of dysfunction in the urban core. The falling behind. The inability health problems. The onset of adult diabetes in children under the age of 12 is epidemic. Learning disabilities, autism is skyrocketing. Here’s the difference between red and blue: blue states have sclerosis. They cannot innovate, they are in the grips of special interests that have vested interests that refuse to allow them to do things that are necessary. Red states believe in innovation, and I’m glad we brought up Scott Walker, who took an enormous amount of heat for attempting to change the basic paradigm of his state. In order to make these pressing new problems, which are global and transformative, you have to have political systems that will move, and will be nimble and will try and innovate and experiment. You need freedom. And the freedom that I’m talking about, the freedom that Stephen Moore writes about all the time, the freedom that we all share. Everyone wants all states to succeed. Right, I’m not against the blue states, I’m just trying to simply that if blue states want to succeed they will adopt red state measures and red state flexibility and mostly red state freedom. Thank you very much.

### Moderator
Claim: Thank you Hugh Hewitt. And that concludes our closing statements. And now it’s time to learn which side you feel has argued the best. We’re going to ask you again to go to the keypads at your seat and register where you stand on this motion after hearing all of the debaters present their arguments. The motion is “For a better future, live in a red state.” If you agree with this motion, if you agree with this team, if you are with the team arguing with the red states push number one. If you disagree, if you are with the team that effectively is arguing for the blue states, because they’re arguing against the motion push number two. If you’re undecided, if you became undecided, or remain undecided, push number three. And you can ignore all of the other keys, they are not live, and we will have the results in just about two minutes. While we wait for that to happen I have a few things that I would like to say. First of all as Bob Rosenkranz said at the opening our goal at Intelligence Squared US as a philanthropy is to raise the level of public discourse, and we count on the debaters to bring a style and a tone of argument to our stage in order to meet that goal.

And these four debaters just did that excellently. I really want to congratulate them for doing that. Secondly on the whole matter of audience questions, I know it’s very, very tough to get up in front of a microphone and even tougher if the moderator says “That’s really not on point,” so to all of those people to whom I had to say that I sincerely, actually congratulate you and honor you for getting up. It's just that we try to squeeze it into this very narrow format. So, my apologies with respect. There was nothing wrong with any of those questions, and some of them might actually sponsor some pretty good debate topics for us in the future. So, thank you to all of the people that asked questions. And finally, we'd like to thank the Philanthropy Roundtable for inviting us to put on this debate as part of your annual meeting. Thank you. We would love it if there are Twitterers in the crowd to tweet about this debate. Our Twitter handle is @iq2us. The hashtag for this debate is #redstate. Also, for those of you who might be in New York later on this fall, we have a pretty busy season coming up on a range of topics. On October 30th we will be debating the global job market. The motion that night: "Let Anyone Take a Job Anywhere.” On November 14 we are debating this quote, unquote: "The Constitutional Right to Bear Arms has Outlived Its Usefulness.” On December 4 we are debating: "Don't Eat Anything with a Face.” All of these will be live-streamed, by the way. So if you can't get to New York you can watch them. If you're in Washington, D.C., on November 20, we are partnering with the McCain Institute. We’re debating NSA surveillance. Tickets for all of these debates are on sale now and for more information or to join our mailing list go to our website, www.iq2us.org.

And as I said also at the beginning our debates are on NPR stations across the country. So, all right. You have voted twice. The results are in. Our motion is this: "For a Better Future, Live in a Red State.” The way this works, you voted twice. The team whose numbers have moved the most in percentage point terms between the two votes is declared our winner. Here is the result of the preliminary vote on the motion: "For a Better Future, Live in a Red State.” Fifty-four percent of you agreed with this motion at the outset. Twenty-four percent were against. Twenty-two percent were divided. Those are the first results. Remember, you voted again. The team that's changed the numbers the most in percentage point terms is the winner. Let's go to the second vote. The team arguing for the motion, their second vote was 73 percent. They went from 54 percent to 73 percent. They picked up 19 percentage points. That is the number to beat. Let's go to the team against the motion. They went from 24 percent to 23 percent. They lost 1 percent.

It means the team that's arguing for the motion: "For a Better Future, Live in a Red State," has carried this debate. Our congratulations to them. Thank you from me, John Donovan, and Intelligence Squared U.S. We'll see you next time.
