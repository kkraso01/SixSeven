# Debate Transcript

Topic: No Fracking Way: The Natural Gas Boom Is Doing More Harm Than Good
Motion: No Fracking Way: The Natural Gas Boom Is Doing More Harm Than Good

Debate ID: frackingaspen


## Round 1

### Moderator
Claim: All right, ladies and gentlemen, we're going to begin, and I want to ask you to welcome our debaters to the stage. now I'd like to introduce the chairman of the board of Intelligence Squared U.S., Mr. Robert Rosenkranz.

### Moderator
Claim: Well, thank you all very much for being here, and I want to just start by thanking Aspen Institute, especially Kitty Boone and Walter Isaacson for inviting Intelligence Squared to participate in the Ideas Festival. We've been broadcasting these debates monthly on National Public Radio for six years, mostly from New York, with occasional debates in D.C. and Chicago, and it's very special for us to be here in Aspen. We believe that debate remains one of the best vehicles we have, not only for promulgating ideas, but for testing those ideas with rigor. And we enjoy proving that debate is not a lost art.

We think you'll find it special to see how debate can raise the level of public discourse in an engaging and competitive format.

My role this evening is to frame the debate. "Why is this subject important? What are the principal arguments on each side?" Hydraulic fracturing, or fracking, is used to extract natural gas locked up in shale rock. The process involves pumping millions of gallons of water and tons of chemicals under very high pressure into rock formations nearly two miles under the Earth's surface. The environmental concerns are obvious. Accidents can happen anywhere along the line, especially during pumping operations or in disposing of wastes. Aquifers can be contaminated by methane and fracking fluids. Some highly toxic chemicals might percolate into groundwater. Large quantities of methane, a powerful greenhouse gas, might be emitted.

There's even concern that fracking might induce earthquakes. Would you trust the oil industry to take proper precautions? How can they justify taking these kind of environmental risks?

Well, what are the counterarguments? Put simply, cheap and abundant natural gas is Viagra for the limp U.S. economy. Shale already provides nearly a quarter of our natural gas. It's projected to support 870,000 jobs by 2015. By reducing electric bills, it will put more than $900 a year in the pockets of the average household. The geopolitical benefits are equally dramatic. By reducing oil imports and pressuring oil prices down, we reduce the power and leverage of such oil exporting troublemakers, as Venezuela and Russia, Saudi Arabia and Iran.

There's also a strong environmental argument in favor. The real world choice is burning gas and burning coal. Per unit of energy, coal creates twice the carbon emissions as gas does. The U.S. has reduced its carbon emissions far more than Europe has done, and natural gas is the reason. Tonight's debate is about the inevitable trade-offs between risks and rewards. Clearly, the risks are real and it is reasonable to be concerned about them. But the benefits are real, too. Which argument should prevail? It's up to you to decide. And to help you do that, we've assembled an outstanding panel of experts. It's now my privilege to turn the evening over to them and to our moderator, John Donvan.

### Moderator
Claim: Thank you, Robert.

### Moderator
Claim: Thank you.

### Moderator
Claim: And I'd just like to invite one more round of applause for Robert Rosenkranz, and for the American Clean Skies Foundation for underwriting this event, and for the Aspen Institute.

For all of them, a round of applause. Thank you.

So, what if you could take a volcano and turn it upside down so that instead of that huge explosion going up into the sky, it goes down into the earth, and once it's down there, it releases this huge ocean of energy that could heat our homes for decades to come? Wouldn't that be great? Or would it? I'm John Donvan of Intelligence Squared U.S. Get ready for a debate-- not on the upside-down volcano-- because it is a metaphor, a flawed one. It does not exist-- but on the principle of technologies that works in a similar way. It is called “fracking.” And it is a debate because fracking actually is getting at an enormous amount of natural gas energy that this nation does need. But at the same time, it is feared that fracking could be having enormous and terrible toxic consequences, destructive to the environment and destructive to the communities.

We have four superbly qualified debaters-- two against two-- who will be arguing for and against this specific motion-- No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good. Our debate will go in three rounds. Then, the audience votes to choose the winner. And only one side wins.

On the side arguing for the motion: Deborah Goldberg, a managing attorney with the environmental law firm Earthjustice. Her partner is Katherine Hudson. She is the Watershed Program director of Riverkeeper, a clean water advocacy group based in New York. On the side against, Joe Nocera. He is an award-winning journalist and op-ed columnist for “The New York Times.” And his partner, Susan Tierney, a former assistant secretary for policy in the U.S. Department of Energy. now going to re-introduce everyone, because what we just did was for our television broadcast. Now, we're going to do a little bit for our radio podcast. And I appreciate the applause. It's very, very good for our transitions, so thank you. And if you don't applaud at one point, I'll raise my hand. That's me saying, “Please applaud again.” Our motion is-- No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good. Let's meet our debators and welcome first Deborah Goldberg. Deborah is a managing attorney at Earthjustice, the world's first and largest non-profit environmental law firm. Deborah, you've worn many different hats. But now that you're in this field, I understand the way you came through-- it had something to do with birds.

### Conspiracy Advocate (CA)
Claim: That's right. My love for birds is what woke me up to the risks that climate change poses for bio-diversity. And I got involved in fracking because we’re not going to be able to deal with climate change unless we end our addiction to fossil fuels.

### Moderator
Claim: All right. Thank you very much. Your partner is Katherine Hudson. Ladies and gentlemen, Katherine Hudson. Katherine, you are an avid outdoors woman. You ski, you rock-climb, you sail on the Hudson River. You spent nearly 25 years in New York State government, working in the Environmental Protection Bureau of the Attorney General's Office and also the Departmental of Environmental Conservation. So, it sounds like you've been in this all of your life. But at one time, you were actually a probation officer?

### Conspiracy Advocate (CA)
Claim: That's right. It was a bit of an unusual start for me. But I found myself working as a probation officer in New Brunswick, New Jersey. And it is actually what pushed me to go to law school, because I realized that I wanted to be part of the system-- I thought I could make a difference if I was-- and not on the receiving end of the system.

### Moderator
Claim: Thank you very much, Kate Hudson. Our motion is No Fracking Way: The Natural Gas Movement is Doing More Harm Than Good, and here is, arguing against the motion first, Joe Nocera.

Joe, you are an award-winning journalist working for the New York Times now with the Op-Ed page after writing for them for a long time. In April of 2011, you went to the Op- Ed page and since then some of your columns on energy have brought down fire upon your head. You've been referred to by climate progress as a member of the climate ignorati.

### Scientific Advocate (SA)
Claim: Yes I have.

### Moderator
Claim: You've been denounced by Robert Redford.

### Scientific Advocate (SA)
Claim: Yes I have.

### Moderator
Claim: So, did you see all of this coming your way when you took this stance?

### Scientific Advocate (SA)
Claim: You know, when I first started writing about energy issues in the Op-Ed page I was surprised-- I was not surprised that people were disagreeing with me. I kind of expected that. But I was surprised by the vehemence of it. The only time I've ever been accosted in a grocery store for a column I wrote was after one of my fracking columns.

### Moderator
Claim: All right. We'll see what happens here tonight. Let's meet your partner. Also arguing that the natural gas boom has been a good thing for the country is Susan Tierney. She is the managing principal at Analysis Group, where she consults on energy, economics, and environmental issues.

She has been in government for the State of Massachusetts and was also an assistant secretary for policy at the U.S. Department of Energy during the Clinton Administration, and you-- interesting thing, you were an art history major.

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: So are the art historians doomed if they're all going into energy? Or do you still believe?

### Scientific Advocate (SA)
Claim: What it means is that I was a pretty mediocre artist and so then I thought well, art history, that's kind of right, and then I was a pretty mediocre art historian, so I did whatever anybody in that circumstance would do. I became a policy wonk.

### Moderator
Claim: I hear from your brother you're a good debater.

### Scientific Advocate (SA)
Claim: Only because we did it around the breakfast table.

### Moderator
Claim: All right. We'll find out more.

So, our motion is this. No fracking way. The natural gas boom is doing more harm than good. You our live audience will choose our winners by voting on that motion, both before the debate, and once again when the debate is completed.

So let's go to the first vote. There's a keypad at your seat on the right-hand side. This is a tricky motion because if you're for the motion you're against fracking and I want that to be clear to you. You've heard where they're coming from. If you're for this side, if you're for this side, if you're for the motion, no fracking way, press number one. If you are with this side, against no fracking way, it means you support fracking, push number two. If you're undecided, push number three. And if you made a mistake just correct it. The system will lock in your last vote. And what we'll do is we're going to hold that result for you. Does the buzz buzz mean that you're confused? Are there any questions? No? Everybody's good? Okay. So what we're going to do at the end of the debate, we'll reveal both of the numbers and the team whose numbers have changed the most in the course of the evening will be declared our winner. So, onto round one. Our motion is No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good and here to speak first for the motion, Kate Hudson.

She spent nearly 25 years in New York State government serving in the Attorney General's office and in the Department of Environmental Conservation. She is now the watershed program director at Riverkeeper, a member-supported clean water advocacy group. Ladies and gentleman, Kate Hudson.

### Conspiracy Advocate (CA)
Claim: The motion before us tonight is No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good. Yes, the gas boom is doing more harm than good, but why? What is going on? Simply, the gas companies are rushing forward in the face of too many unknowns and too little control. In essence, these companies are engaged in an uncontrolled experiment, which is resulting in extreme and, in some cases, permanent harm to people, communities, and the environment that cannot be compensated for by any possible benefits.

What my partner, Deborah Goldberg, and I will be talking with you about tonight is what those harms are that are being faced across the country because of the natural gas boom: the health risks for individuals, the impacts to the environment, and the costs for local communities. And why, in the face of the unknown, in the face of the harms, gas companies are so intent on rushing forward hoping to figure it out along the way.

Well, what exactly is fracking? Deborah and I use the term fracking to refer to the entire cradle-to-grave process of natural gas extraction, from site preparation through transmission to end uses. The process begins with cutting access roads through the existing landscape and stripping a site about the size of five football fields to serve as a multi-well pad. Then the drilling rig will arrive, along with thousands of truckloads of equipment, water, sand, and chemicals that will be used to drill thousands of feet into the ground and miles horizontally.

This is followed by the actual fracturing of the well which involves repeatedly, for a month or more, forcing two to eight million gallons of water and hundreds of undisclosed chemicals underground, under pressure, to fracture the rock, allowing the gas to escape. Then something must be done with the large quantity of contaminated wastewater, up to several million gallons per well, that will come back up along with the methane now released from the shale. If not properly handled, the methane may find its way into nearby drinking water wells. It may also be released into the air either intentionally or as a result of leaks. The methane gas that is captured is then processed and forced through gathering lines and into high pressure pipelines that will need to be constructed from numerous wellheads for hundreds and thousands of miles to the place where the gas will be burned, permanently carving up the landscape and communities that lie in between.

To give you a clearer idea of how this fracking process is impacting people and communities, imagine that you'd go home tonight and find out that your next-door neighbor has signed a lease with a gas drilling company without asking you. What can you expect from this industrial activity going on next door? Even though you didn't choose to lease, you will be exposed to the same risks of contamination to the water you drink and the air you breathe as your neighbor. You will be subject to the same threat of leaks and spills of the fracking wastewater, which contain known carcinogens and radioactive material. Fracking-related spills occur on average once every three days in Colorado. Moreover, the industry has no safe disposal plans for this waste. Much of it is currently injected into underground wells, but this practice has been linked to earthquakes, and there's growing evidence that these wells are leaking. The gas well itself, and associated processing compression in storage tanks, will leak toxic and smog- forming air pollutants.

The once pristine air in fracked parts of Wyoming is now worse than the air in Los Angeles because of this. The few studies we do have show increased risks of cancer and respiratory diseases in gas land communities linked to these releases.

Like your leasing neighbor, you will be unable to escape noise that can sound-- the constant day and night truck traffic, estimated by New York State at 4,000 truck trips per well. There will be 24/7 noise that can sound like a jet engine, and glaring lights all night long during the drilling and fracturing of the well over the next month or more. You will also potentially have gas pipelines cross your property whether you agree to it or not, and you will be subject to the same increase in your taxes as your drilling neighbor when your town has to repair the road damage caused by the heavy truck traffic that comes with fracking that will tear apart your rural and suburban streets, and when your town has to meet the increased demands for community services from transient drill crews.

Proponents argue that the economic benefits outweigh these risks so far. But what are the supposed benefits of this industrial activity almost literally in your backyard, or down the street from your children's pool? The economic benefits for you will be limited. There will be access to cheap natural gas at least for a little while, but it won't last for very long because the amount that can be forced out of the earth is limited and will run out. But even more important, it will not remain cheap, because the industry will be doing everything it can to increase the price of gas, including exporting America's gas to other countries where they can triple-- yes, triple the price-- on the U.S. market today. The drilling will bring jobs, at least while the drill rigs are in town, but not very many and not for long, and these gas industry jobs are some of the most life- threatening in the country.

Oil and gas workers are seven times more likely to die on the job than the national average. And fracking can destroy businesses that could sustain local economies into the future after the fracking boom is over, like agriculture, recreation, and tourism.

What is clear is that gas companies are not willing to wait. The natural gas boom is moving forward as a large uncontrolled experiment with every individual, family, and community who has not signed a lease being forced to participate without their consent. Whatever transitory benefits fracking may provide is outweighed by all of the harms that it currently brings. But even more important, there are some harms that simply cannot be compensated for. If you can no longer live in your home or continue to work your family farm, if you lose your health, the health of your child, if you lose your life as hundreds of oil and gas workers have.

If you lose access to drinkable water or breathable air as individuals in communities across the fracking states have, there is no good that can outweigh such harm.

Until we have a much better understanding of the processes and the true risks, until there are mandatory rules in place to control these risks and eliminate the extreme harm, and until the industry actually follows those rules, the only defensible course of action is a cautious one. The only reasonable and fair answer is, "No, no fracking way."

### Moderator
Claim: Thank you, Kate Hudson. Our motion is No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good, and now here to speak against the motion is Joe Nocera, he is an op-ed columnist for the New York Times and a regular business commentator on NPR's "Weekend Edition Saturday," an award winning journalist, and a bestselling author. Ladies and gentlemen, Joe Nocera.

### Scientific Advocate (SA)
Claim: Thank you. In Kate's opening statement, there's one word that she didn't use, and that word is "coal."We're going to use that word a lot on our side of the ledger tonight, because part of the case for natural gas is it's the best single way to diminish our use of coal. And coal is without question the most environmentally hazardous fuel that we have in America. You know, Fred Krupp from the Environmental Defense Fund was in Aspen not very long ago, and he did a panel on fracking, and he said, you know, "I'm a realist. I'm also an environmentalist. Fracking is here, and we have to regulate it.” It's not that impossible. We regulate banks. We regulate children's toys. We regulate automobiles.

We do regulate banks, actually. But when it comes to gas, we are in the golden age of gas, that's what we're in. It's not like we have a little bit of gas that we're busy trying to extract here and there, and it's going to run out tomorrow.

We have something on the order of 2,000 trillion cubic feet of gas. We use about 24 trillion cubic feet a year. So, we have about an 80 to 100-year supply right now. That means, among other things, that gas is incredibly cheap. Right now it's in the two-dollar range. It probably-- yes, it probably will go up to the four or five-dollar range, which still makes it much cheaper than most other fuels and makes it very competitive with coal. Gas has-- cheap energy is an enormous boon for the country, just cheap energy across the board.

It increases our GDP. It has enormous ramifications well beyond jobs. Natural gas also has the ability to be a transformative fuel and a bridge fuel as we think about moving to renewal. Excuse me, one second. So the economic benefit is one kind of benefit.

A second kind of benefit obviously is the energy security benefit. I'm going to read something from the Wall Street Journal that ran just a few days ago. "America will halve its reliance on Middle East oil by the end of this decade and could be completely rid of it by 2035 due to the declining demand and the rapid growth of new petroleum sources in the western hemisphere. Shale rock is one of those sources." Now, who made this projection? It was OPEC itself.

Think about a world where you don't have to worry about cartels, you don't have to worry about being dependent on our enemies for oil, a world where foreign policy is not dictated by our need for oil. The ability of the United States to have its own resource once again in a way that we never thought we were going to is a tremendous gift that's been handed to us, and fracking is the way that we're taking advantage of it.

Now, the third aspect that I want to talk about is the environmental benefits, which is real and which is happening now. As recently as 2009, 45 percent of the power generation in the country was coal, 23 percent was natural gas. Today, it's about evenly split.

There is a rush to natural gas and away from coal. This is a great thing for the country. Natural gas has half the CO2 emissions than coal, 90-- coal has 90 times more sulfur dioxide, five times more nitrogen oxide. Coal is the dirtiest fuel we have. And so, if facilities could switch to natural gas, it has the potential to transform the country.

You know, in Europe, where they like to think of themselves as extremely environmentally sensitive, their emissions are actually going up because they're building more coal fire power plants. In America, our emissions are flat and going slightly down, according to studies. And a large part of the reason is because we're having this rush to natural gas.

The same is also true of China, of Mexico, of Russia, and of a handful of other countries that are relying on other sources than gas. We have-- what we actually have is a minute and 31 seconds.

Oh, I am?

I have actually made my case.

I'm good.

I don't need seven minutes.

### Moderator
Claim: You're going to get 20 seconds more for the water drink.

### Scientific Advocate (SA)
Claim: Oh, I am?

### Moderator
Claim: Yes, Joe. Go give him the water. It's clean water.

### Scientific Advocate (SA)
Claim: I have actually made my case.

### Moderator
Claim: You're good?

### Scientific Advocate (SA)
Claim: I'm good.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: I don't need seven minutes.

### Moderator
Claim: Drink water. Thank you. Joe Nocera.

So, a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. Debate. I am John Donvan.

We have four debaters-- two against two-- fighting it out against this motion: No Fracking Way: The Natural Gas Movement is Doing More Harm Than Good. You have heard from the first two debaters. Now, onto the third.

Deborah Goldberg is a managing attorney at Earthjustice, an environmental law firm that provides legal representation at no cost to more than a thousand clients, ranging from large national groups like the National Resources Defense Council, to small community coalitions. Ladies and gentlemen, Deborah Goldberg.

### Conspiracy Advocate (CA)
Claim: To start, I'd like to bring the focus back to the motion that we've been asked to debate. We aren't here tonight to decide whether or not fracking is a gift or if it's a Trojan Horse. We are here to decide whether or not the natural gas boom is doing more harm than good. So, what characterizes a boom? It's big. It's sudden. And it blows a lot of smoke. And the natural gas boom is doing all of that to an extreme.

It's too much. It's too fast. And the hype is just over the top.

So, why do I say that it's too much? The most serious health and environmental impacts of fracking are largely due to very intensive gas development. We have 500,000 gas wells in this country, nearly 3,000 in one county, 11 compressor stations belching carcinogenic air emissions in a tiny town of only two square miles. Our bodies and our ecosystems can absorb a certain amount of abuse and still bounce back. But at a certain point, it's just too much, and the insults overwhelm the resilience.

Take Pennsylvania, for example. In the beginning, Pennsylvania was letting the frackers take their wastewater, which is contaminated with very high levels of salt, to sewage treatment plants, where it was diluted with the sewage, and then discharged into rivers and streams.

In short order we had a water quality violation in the drinking water supply for 350,000 people. And what's more, Pennsylvania realized that if they continued to let the frackers take that amount of wastage through its treatment plants, they would salinate every freshwater stream in the state in a period of two years.

The same dynamic operates on a global level. Our atmosphere can absorb a certain amount of greenhouse gas emissions. But if we release too much, the climate warms to a point of catastrophic change. And the natural gas boom is taking us to that tipping point, because the way that fracking is done now releases very large amounts of methane into the air. And methane is a very potent greenhouse gas, almost 72 times as potent as carbon dioxide, depending on the time frame that you look at.

A recent study showed that the leakage from fracking is about four percent of production and the scientists recognized that at that level gas loses its entire climate advantage over coal when it's burned for electrical power.

The intensive development isn't really even good for the industry. Right now the industry is losing money on every dry gas well that's drilled. But it's even worse for solar, wind, and other clean energy sources, because they are displaced when the price of natural gas drops so low.

The boom is not only too big, but it's way too fast. It is out ahead of the science. We do know as a result of lots of public pressure that some of the chemicals that are used in this process are toxic, but there are many chemicals that have never even been tested as to their toxicity, and we have no clue what they're going to do to our health or environment, in the short or the long term.

We don't know where the wastewater that stays down below-- and that can be as much as 90 percent of the waste water in the northeastern shale-- is going to migrate in 20, 30 years or more.

The development is also way ahead of the protections that we have. Instead of doing science and getting the safeguards before we move forward, we are flooring the accelerator and we're responding to crises. When you move too fast you cut corners and you have accidents, and that's particularly troublesome when you're talking about climate change, because the single most important factor for the social and environmental impact of climate change is the speed at which it progresses. We move too fast with climate change and we don't have time to prepare or to adapt, and so the climate scientists are telling us that we have to address the most potent greenhouse gases right now as fast as we can, and on that list is methane.

The hype and the hoopla is clouding our vision and making it impossible for us to hear the facts. There are hundreds of millions of dollars being spent to ensure that this industry can continue to operate without the science and without the protections we need. $320 million spent on lobbying the federal government in just two years. As a result, what we are hearing now is not how we're going to end our addiction to fossil fuels, but instead, a hundred years of gas. Now, a hundred years of gas is based on extracting every molecule of gas from all of our reserves, even those that we haven't actually discovered yet, when it is well known that only about 10 percent of those reserves tend to be economically feasible to develop.

And if we switch our power plants over to gas and our transportation systems over to gas, and our heating and cooking systems, and then on top of that we export liquid natural gas to other countries, how long is that abundant resource going to last? And at what price to our health and environment?

The boom mentality produces magical thinking. The idea that this industry is going voluntarily to abide by a golden rule or a golden age of gas is just a fairy tale. This industry fights every protection we try to put in place, federal and state, often when it's even in its economic interests to comply. What all this means is that we are in the middle of an uncontrolled experiment. If we get this wrong, there is no turning back.

And so we need to take the opportunity now when, we have a glut and we are not desperate for gas, to do the science and get the protections in place before it's too late and the natural gas boom that looks so exciting now goes bust in the face of the next generation.

### Moderator
Claim: Thank you, Deborah Goldberg. Our motion is No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good. And now our final debater speaking against this motion, Sue Tierney. Sue is a managing principal at Analysis Group, where she consults to businesses, government agencies, nongovernment organizations. She's a former assistant secretary for policy at the U.S. Department of Energy, and is a current member of the Secretary of Energy's Advisory Board. Ladies and gentleman, Sue Tierney.

### Scientific Advocate (SA)
Claim: Good evening, everybody. Joe told you about the upsides of the natural gas boom, and Deborah and Kate told you about some of the risks.

I just want to start by saying if it were only as simple as my opponents tell you, then life would be pretty easy. Let me tell you why their position, that the costs of developing natural gas are simply not worth the benefits, is wrong.

First, what they didn't tell you is that there is absolutely nobody in the United States, no entity, that could actually introduce this proposition and make it so. There are hundreds of millions of decision makers in our energy system. If we rely on a regulated market, consumers and suppliers all around the country, every one of you is making energy choices every day, they don't have the authority to completely stop this, no single state could stop this, nor could the federal government. On the consumer side, Americans tend not to think very much about energy.

What they think about is getting to their job or getting to the shop where they hope to find lots of options, whether they can power their computers, or keep their homes warm or cool, and it's those realities that people don't think about energy that much. That makes this a really hard issue to deal with. Everybody wants energy 24/7. They want it pretty cheap. Many say they'd like it to be clean, and many really suffer when prices go up. That's the reality, and that makes this issue very gray and not as black and white as my opponents would tell you.

Deborah and Kate have set up in some sense a false dichotomy. They make it seem as though natural gas is evil and so everything else is pure. We know that that's not the case. Surely we should be developing more wind and solar power. I'm sure everyone in this audience agrees with that. Right now, seven percent of America's energy supply comes from renewable energy; most of that is from the Roosevelt-era hydroelectric facilities, those gigantic projects, none of which we would be able to build again for environmental impact reasons.

The other major portion of renewables right now comes from biofuels such as ethanol, with its own problems from an environmental impact point of view. Wind and solar are expected to grow, but even if they're 10 times as much as they are today, we're still talking about a long way to go and a small portion of the supply, and I hope we get there. It's very hard.

But these and every other energy choice are really pretty hard and very complicated. Why else would Japan be restarting its nuclear plants so soon after the Fukushima disaster? It's because they need energy. Why else would Pennsylvania be opening up its shale gas resources for development?

They'd like some jobs and economic benefits associated with it. And, in fact, why are coal states fighting so hard against the U.S. EPA Air Toxics Rules that would reduce the amount of coal burning in coal fired power plants? Surely the coal industry has something to do with that, but also there are a lot of jobs in that state tied to coal.

So what has clean cheap gas provided for us in this pretty gray landscape so far? Joe told you about how natural gas is taking market share from coal in the power sector right now. In 2012 alone, Southern Company, which is one of the biggest owners of a coal fired power plant fleet in the country, expects to generate almost half of its power from natural gas. That's three times the amount from gas as it was five years ago. And this is astonishing. Coal has dropped from 70 percent of its fleet to 30 percent of its fleet-- of power generation.

Now, certainly in a compartmentalized way, Americans often get really agitated about energy choices, but it's usually when it hits their backyard, as Kate and Deborah have told you. Unfortunately, every form of energy is in somebody's backyard. Many communities are split about shale gas. Absolutely that's true. Of course, some communities are split when they think that there's going to be a Wal-Mart coming because it affects the quality and tenor of their life in those areas. But think about it, every type of energy facility that you can think of has split communities, whether it's a wind farm in Cape Cod, the power lines across the Midwest to tie the America's Saudi Arabia of wind to the people using wind in other parts of the country, nuclear plants, the case for shutting down existing coal plants, splits communities apart. These splits typically come down to jobs versus the environment, and that's surely the case here.

Where I do agree with Kate and Deborah is that shale gas development does have important environmental and community impact. Should we regulate natural gas development more? Absolutely we should. Is regulation improving? Absolutely it is. Colorado and Pennsylvania are the prime cases for advancements that are leapfrogging for best practices. The federal government is, too. Should we drop the so-called Halliburton loophole, which exempts water injections associated with hydraulic fracturing from the Safe Drinking Water Act? Why not? Wouldn’t that provide a lot of more public trust than we have right now? Should we tighten up emissions of methane from the whole process? Absolutely we should. But do we think that the United States should take shale gas off the table? No. That's unrealistic. It's not even sensible.

If we somehow-- someone in the United States could decide to do that, because it did more harm then good, what would we get?

We'd probably get a little bit more renewables, maybe a little faster. We would get a lot more coal use, and we'd have mountaintop mining, we'd have coal ash piles, some of which have recently spilled into rivers, we'd have much higher CO2 emissions that contribute to global warming, and we'd have unhealthy levels of mercury emissions and other toxic chemicals. There's a solution to all of these issues. There are best practices. There should be much more aggressive attention to this. What I really wish is that people would stop demonizing this fuel, because it makes it impossible to find sensible solutions in the middle. There are sensible solutions in the middle. We should be working on enabling those to develop over time. Our main argument is that the two principal sources of energy in the United States, coal and oil, are much more damaging to the environment than is natural gas, and that's for the communities where those are used as well as to the nation as a whole.

Thank you.

### Moderator
Claim: Sue Tierney, your time is up. Thank you very much.

### Scientific Advocate (SA)
Claim: Thank you.

## Round 2

### Moderator
Claim: Thank you. And that concludes round one of this Intelligence Squared U.S. debate where the motion being argued is No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good.

Now we go on to round two, where the debaters address each other directly and take questions from me and from you in the audience. We have two teams of two members each here arguing against this motion. Team arguing against fracking, the team that says essentially, "No fracking way," Katherine Hudson and Deborah Goldberg, we have heard them say that getting the price-- the price to be paid for getting the gas out of the ground is just too high, that it is an environmental threat, that it will ruin communities, that it is more expensive than it seems, that, in fact, the harms will outweigh the benefits that were laid out by the other sides.

And they're basically saying that the boom is getting ahead of science, that we don't know what we're getting into. The other side, Sue Tierney and Joe Nocera, the defenders of fracking, the enthusiasts, are saying, "Yes, there are risks involved, but they're manageable. Regulations can be put into place." They compare it to coal. Against coal, natural gas they say looks pretty clean, that if you look at this thing as the national security matter, as a jumpstart to an economy that needs it, that having this stuff underground and being able to get at it is an enormous gift that's dropped into our laps.

So we're going to go through some of that now and explore some of what they were talking about in the debate. And I want to go first to the side that's arguing to-- the supporters of fracking. Your opponents have made this statement that the boom is getting ahead of science and implicitly saying, "Until we know a lot more, particularly on the environmental issue, the impact, we should slow down to stop." And you're saying the opposite. So take on the science issue and the not knowing and whether that is a signal to stop, either one of you, Joe or--

### Scientific Advocate (SA)
Claim: Well, first of all, I think we do know a lot. In any kind of boom, it is correct. Industry goes in, and the environmentalists have done a great favor to the country because they've gotten on top of the fracking issues early-- but we do know that there's methane leakage, and there's science going on right now to figure out what that leakage is and how to make the well casings better. And that's one of a dozen examples where the issue of the chemicals-- you can go to websites now and see some of the-- most-- all of the chemicals. Certain states have passed laws that demand that the chemicals be revealed. So, what's basically been happening over the last four or five years, you have cases like in New York State-- which stopped fracking until they could study it. And now they're getting ready to open it up in a small way, in a safe way. It can be done.

### Moderator
Claim: All right. Deborah Goldberg, you’re opponents say we do know a lot about science.

### Conspiracy Advocate (CA)
Claim: Well, let me be very clear either right from the start that neither of us have argued that it should stop right now. What we have argued is that the boom is the problem, that it's going much too fast, and it's outstripping both the science and the protections. So, we think that what-- for example, what New York has done, makes a great deal of sense, is stop for a while, when it's not necessary, we have a glut coming from other places-- and take a look at what the impacts are-- and figure out what needs to be done.

### Moderator
Claim: But to Joe Nocera's point, where he says, actually, we-- refuting you and saying that we actually do know a good amount now, can you take that on?

### Conspiracy Advocate (CA)
Claim: Well, we learned, we have learned more recently. But the fact of the matter is, there's a great deal that we don't know. And the reason that we don't know that is that the industry has done everything in its power to keep us from getting the data that we need in order to really do the study. So, for example, I just submitted a Freedom of Information request to New York State Department of Environmental Conservation, asking them for the results of water quality studies that they had done in connection with oil and gas development in the state.

And what they told me was, “We don't have any. We don't ask for that.” So, how are you going to do serious science if you don't have a baseline test of the conditions? And additional studies during operation? And follow-up afterwards? You know, we are learning something because of public pressure, but there's a long way to go.

### Moderator
Claim: All right, Susan.

### Scientific Advocate (SA)
Claim: John, yeah. I'd like to weigh in on this one. One of the things that the debate about what we know about the science focuses on is the question of how much methane emissions are leaking from the entire life cycle, from the production well all the way to the consumers' burner tip. And we actually-- there's a great deal that we know about that. We don't know everything. We should know a whole lot more. Deborah pointed out--

### Moderator
Claim: So, what-- what does that mean, then? Is Deborah right?

### Scientific Advocate (SA)
Claim: We lack--

### Moderator
Claim: We should know a whole lot more, is that we should slow things down until we know a whole lot more?

### Scientific Advocate (SA)
Claim: No. We should not slow things down, but we should absolutely insist on better measurements. We should measure what is a baseline for conditions prior to drilling--

### Moderator
Claim: So, why not slow things down more? If you're conceding that more work actually needs to be done, why not pause? What's the harm in pausing?

### Scientific Advocate (SA)
Claim: There are a number of different harms. One of them is the multi-billion dollar contribution that lower natural gas prices have provided for the United States economy. Another reason is the development of chemical jobs and industries that are coming back to the United States because natural gas is a feedstock that's supportable. The greenhouse gas emissions that have been reduced in the last three years because of-- when you take aside and account for the effects of the economy having crashed, there are much lower greenhouse gas emissions.

### Moderator
Claim: All right. So, Kate Hudson, your opponent's saying that the benefits train has left the station.

The good stuff is happening and to slow down the program would cause those-- those list of harms she just went through.

### Conspiracy Advocate (CA)
Claim: I think that the benefits that have just been recited are questionable. For instance, luring the petrochemical industry back into this country, is that really what we want? Or shouldn't we instead be trying to move towards a green economic future for our children, rather than having-- a fossil-fuel based industry come back?

### Scientific Advocate (SA)
Claim: Well, it's a big country. We need lots of different kinds of jobs. Of course we need green jobs. We need other kinds of jobs, too.

### Moderator
Claim: Are you in mid-sentence or--

### Scientific Advocate (SA)
Claim: I'm speechless.

### Moderator
Claim: Because of the-- so, go ahead, Kate.

### Conspiracy Advocate (CA)
Claim: No, I want to actually go to the subject of jobs, because one of the characteristics of the extraction industry is the boom and bust. And what is happening already is that there is-- when the rigs come into town, there are lots of jobs that come up. Truck drivers, they need a lot of truck drivers. They frack the wells and they leave. And then the economy busts. And the record is that those economies are in worse shape than before the extraction industry came into town.

### Moderator
Claim: Sue Tierney.

### Scientific Advocate (SA)
Claim: What our opponents are saying is that when we look at a microscope about the impacts on localities, there are-- there are-- there are tremendous challenges that's going on in those communities. I don't think Joe or I would say that that's not the case. But every person in this audience drives a car, whether it's a Prius or something else, and there is extraction going on for getting that oil somewhere.

Coal mining is all over the country and Colorado is an example of a state where they've said the environmental benefit of a natural gas fired fleet of power plants outweigh the risks and the harm. So there are tradeoffs and compensations across these areas. The wind farms, you want to talk about disrupting areas-- by the way, I'm a huge fan of wind farms. I'm in favor of wind. I'm probably one of the few people who is very eager to say that, but as a result of that there are lots of community impacts in a variety of different places that people are talking about.

### Scientific Advocate (SA)
Claim: I have a question for the side that's arguing against fracking. I'm just interested in clarity on the positions you have staked out and it doesn't-- you don't necessarily have to be agreeing with each other, but I feel as though you're not necessarily, because Kate Hudson is saying having the petro chemical industry retake root here, particularly in new parts of the country, is not a very attractive idea.

At the same time, Deborah, you're saying well, we're not against fracking, we just want fracking to be good, to work beneficially and without harm. So, is this team against fracking, against the petro chemical industry, you know, working here? Or is it not?

### Conspiracy Advocate (CA)
Claim: I think that we are not saying stop everything all at once and I don't think Kate is saying that either. We know that we need some natural gas, probably to keep the lights on for a while. The really big problem is that the focus on this industry and the power and wealth of this industry is actually derailing the attempts that we have been making in the past to put a price on carbon, for example, to move ourselves to an energy-- an economy that would actually be sustainable in the future. So, neither of us are saying that there aren't advantages in some situations between putting in a gas plant, say, instead of a coal plant, if we really knew what the lifecycle methane emissions were.

And both of our opponents have admitted that we don't. And we actually--

### Scientific Advocate (SA)
Claim: But John, let me talk about the methane emissions and what we know about the science there. There has been one study by Cornell University that looks at the methane emissions and has concluded that the methane emissions that are associated with the entire lifecycle of natural gas make it worse than coal. The study has been tremendously critiqued by peers for a number of ways in which that study does not rely on what people know to be the case about emissions. For example, the intergovernmental panel on climate change suggests that you use a hundred-year warming potential, an element that you would use to calculate how much global warming potential there is from a fuel.

The Cornell folks have used something very, very different than that, which greatly increases the harm that methane would show relative to coal emissions. There are two or three other technical reasons where the peer critiques have said these all exaggerate the emissions. Most of the reasonable science has said and there's a tremendous body of evidence on this, that coal-- when you combust coal at a power plant it will have twice as much emissions of greenhouse gas, including methane, than coal.

### Conspiracy Advocate (CA)
Claim: May I respond to that?

### Moderator
Claim: Yes, please.

### Conspiracy Advocate (CA)
Claim: So there's not one study, but there is a variety of studies, and they rely on estimates of emissions that have information that comes principally from the industry. I know of only one study that actually went out into the field and measured the emissions from the gas well, and that study showed that our methane emissions are about four percent of production.

Now, I agree that we could reduce those if we had better regulations in place, but the industry is out there fighting those regulations. We just had a new EPA rule that was designed to address the emissions from the fracking system, and there was a new rule put in place that would decidedly make it better in terms of methane emissions because they would put the gas pipelines in before they actually let the gas go, and the industry successfully delayed the implementation of this green completion system for another three years.

### Scientific Advocate (SA)
Claim: But John, I really--

### Moderator
Claim: Let me bring Joe Nocera in, and Joe, let me put the question to you, because you're a journalist. You're paid to be cynical about things.

Are corporations-- you made the point that you think the environmentalists are actually the ones who have squeezed information out of the corporations. Is that because that is the dynamic. In other words--

### Scientific Advocate (SA)
Claim: No. I think--

### Moderator
Claim: The corporations are--

--in other words, your--

### Scientific Advocate (SA)
Claim: No, I think--

### Moderator
Claim: --but the corporations are dodging and weaving?

### Scientific Advocate (SA)
Claim: I think the dynamic is actually pretty different. I think the dynamic is that industry began as-- fracking was not started by Exxon or Shell. Fracking was basically a bunch of small companies who really developed the technology as innovators often do and then the big boys came in. The environmentalists correctly said, "This needs to be cleaned up, and it needs to be regulated, and it needs to be looked at more closely." And what has happened is that the objections and the rising concern has basically caused industry, especially the big guys, to say, "You know what? We really would like to be on the right side of this, and we are going to try and get there."And there have actually been-- you know, Shell, one of the big oil companies, they recycle most of the water that they inject in the well. There are lots of things like that going on. Now, part of the problem is that you can't rely on industry best practices. You have to regulate it. And part of the problem is that the regulation is mostly done by the states, not by the federal government. And so you're sort of dependent on appropriate state regulation. Pennsylvania, when they began, didn't regulate it very well. They've learned a lot. They are regulating it better. It is getting better in Pennsylvania.

### Moderator
Claim: Kate Hudson, Joe Nocera paints the portrait of the situation getting better in terms of both government regulation stepping up and companies fessing up, what about that?

### Conspiracy Advocate (CA)
Claim: Well, I would like to point out that one of the reasons why we're stuck with state regulation is because the oil and gas companies lobbied their way out of at least a half dozen federal environmental laws and requirements, and so now it's with the states.

And I'm not particularly impressed by the example of Pennsylvania, which the communities in that state and the environment in that state suffered greatly while the state played regulatory catch-up. And it is still the case that the industry is given a tremendous break. In addition to that, at the state level, across the country, there are not enough regulators to police that. So even if you had half decent regulations, you don't have the staff to put in the field to make sure that those regulations are being complied with.

### Moderator
Claim: Just-- I assume that where this side draws the line though, because you've said now a couple of times you're not against fracking, you're against the pace-- the enthusiasm-- so do you see a future where fracking happens and the Marcellus Shale, the area that is now, at least in the east coast, the most controversial large area covering Pennsylvania and New York state, do you see a future where the regulation that you're asking for is so effective and the science has been so checked out that if we do go ahead and have 80 years of fracking in that area and that's okay with you?

### Conspiracy Advocate (CA)
Claim: Eighty years of fracking is not okay. We need to get off of fossil fuels a lot faster than that.

### Scientific Advocate (SA)
Claim: Okay, so--

### Moderator
Claim: Okay, Joe Nocera.

### Scientific Advocate (SA)
Claim: Okay, so-- so you want a situation where all jobs are green jobs, and you don't have a petro- chemical industry because they're bad guys, and you have a situation where you want to-- let's assume you could shut down fracking tomorrow, let's assume that, and your vision is that the consequence of that would be that this would cause a rush to renewables, but that's not what would happen. It would cause a rush to coal. The market is buying energy based on its price, and one of the reasons renewables have had so much trouble is because they have a hard time competing with coal.

Coal is the hardest thing to compete with because it's cheap. So you think that-- what you're trying to avoid, I understand, is another 100-year cycle of fossil fuel, and that's admirable, but it's also unrealistic, and what you have with natural gas is a fuel that is cleaner than coal and maybe could help you get to renewables. And I--

### Moderator
Claim: But if it is such a great boon, are they right that basically the-- we're in a world right now where the price of energy up until very recently has been seen as so egregious that there has been much more effort put towards looking at renewables, and if we suddenly enter into the 1950s again-- won't go that far, but if we suddenly get to a place where the price drops tremendously, we’re going to stop the push to find alternatives.

### Scientific Advocate (SA)
Claim: No, we're not. The states-- 37 states in the United States have adopted portfolio standards which require renewable energy to be entering the market really almost at any cost, and they are pushing that envelope forward.

That is helping to reduce the costs of renewable energy. That is a fantastic thing--

### Moderator
Claim: Yeah, but, Sue, their argument is if we have this sustained period of really relatively less expensive energy, that, that push will fade, and come back again in 80 years when it's too late.

### Scientific Advocate (SA)
Claim: Well, I agree with Joe that if there is a moratorium on natural gas development, unconventional gas around the United States, we're going back to coal.

### Moderator
Claim: Yeah, but that's not the answer to the question.

### Scientific Advocate (SA)
Claim: It is the answer to the question whether you like it or not. It is the answer to the question. That is what will happen in the United States.

### Moderator
Claim: Right, but will there be a drop-off in looking at alternative-- trying to develop alternative measures?

### Scientific Advocate (SA)
Claim: No, there are policy triggers that are pulling renewable energy development into markets around the country. That is the case.

### Moderator
Claim: Okay, a question I want to put to this side. Joe Nocera’s opening remarks talked about a part of this. We haven't touched on it yet at all. National security, the ability to, you know, have our own private, in oilfield terms, "Saudi Arabia" right in our own pocket, right in our own country.

We don't have to deal with these folks anymore. We can try to realize the fantasy of energy independence, and that this is something that we've been dreaming about for 40 years, that you don't just walk away from that. And your side basically-- you seem to shrug at that and not treat that as really, really great. So I'd like to know why you think that that's not necessarily germane.

### Conspiracy Advocate (CA)
Claim: Well, I would say first of all Joe was very careful to talk about national-- or energy security and not energy independence, and I don't think that most economists and energy experts think that what we want is independence in the sense that we aren't going to do any trade on energy issues with any other country. What they are talking about is we want to be doing that trade with people who are our friends. And part of what has happened because we've been so focused on gas-- and again I really object to the idea that the alternative is, "Stop it now or 100 years."That is not what we're-- that's a straw man-- that's not what we're arguing here. But what we have done is we have ceded a lot of the industry that is developing, for example, photovoltaic solar energy, to China. And so if we are not going to actually speed up our development of the renewable energies here, and instead we're going to be diverted into a 80 years of gas, then we are going to be at a point sometime when we don't have the resources-- the renewable resources, and we're going to be importing them sometime. That's not energy security.

### Scientific Advocate (SA)
Claim: The reason--

### Moderator
Claim: So in other words you're saying it's-- you think it would be a very, very short lived bubble of benefit in terms of energy security?

### Conspiracy Advocate (CA)
Claim: I don't actually see where the energy security is going to come ultimately if, in fact, the goal of the gas companies, which has been made clear by 15 applications that have been made to the federal government, to export the natural gas to the European and Asian markets, where they can get four to five times as much money for the gas as they can in the domestic market.

So once we start exporting that gas, how is that helping our national energy security right now?

### Moderator
Claim: Sue Tierney.

### Scientific Advocate (SA)
Claim: The geopolitics of natural gas and oil are pretty compelling when you look around at a lot of different areas of the world. Parts of Western Europe have been held hostage by getting natural gas across pipelines crossing the Ukraine from Russia, and that has created tremendous problems so that the ability for them to be able to get natural gas from friendly areas is a very compelling story. Same is true for China. China actually has a very large shale gas deposit. They are very interested in learning the knowhow in the United States associated with this technology.

If China is able to use natural gas, they may not build as many Soviet-style nuclear reactors. They may not have challenges with the Middle East oil problem, which is-- that their own internal demand is driving.

### Moderator
Claim: Joe Nocera.

### Scientific Advocate (SA)
Claim: The thing that-- you mentioned China and you mentioned the solar industry moving to China, and I think it gets to the point that you don't really want to sort of deal with, which is cost. Solar is moving to China because it's cheaper, and solar is cheaper-- and the problem renewables have and have had is that they're in this constant struggle to get the cost down to where it's cost-effective to use, and it's cheaper in China. That--

### Scientific Advocate (SA)
Claim: I was on the board of one of the now bankrupt solar energy companies, Evergreen Solar. It was more cost effective to build the next manufacturing facility and then ship the panels back to the United States to meet the solar market because of China's subsidies for the industry.

So manufacturing is moving to China, but the United States' demand for solar is not going to mean we're not going to get solar back. We will get solar panels back.

### Conspiracy Advocate (CA)
Claim: Right, but the question was, energy security. And the concern was being at the mercy of a country that isn't really aligned with our interests. And I think that we would mostly agree that unless things change very much, China is not the one that has completely bought into our value system. And so, we are-- we're not going to get the energy security. We may get the cheaper panels, but we are going to be dependent on a hostile country.

### Moderator
Claim: All right. I want to go to questions from the audience now. And the way it will work is that you raise your hand. A microphone will come to you. I need to tell the folks that are in-- that are not in the lit area that I can't see you. So, if you can't see your wristwatch-- read your watch-- I can't see you.

So, if you want to ask a question, step forward and come to the edge of the light, and I'll try to take your question. And again, if you arrived late, I want this to be a question-- not a debate. These guys are the debaters. Just ask a question that's on our point, and that's terse, and that really helps move things along that's on our topic. Start, right there.

### Moderator
Claim: The question I have is to reframe the debate a little bit. Our concern is pollution of our groundwater and our environment with fracking fluids. Joe, you had mentioned that everyone knows what's in it. I would take issue with that. Many of the chemicals are trade secrets. How can we allow that? Why can we not develop a safe-- to use the term loosely-- fracking fluid and use that more exclusively?

### Moderator
Claim: Sir, do you mind just telling us your name?

### Moderator
Claim: Phil Rodman.

### Moderator
Claim: Thanks very much.

### Scientific Advocate (SA)
Claim: So--

### Moderator
Claim: Sue Tierney.

### Scientific Advocate (SA)
Claim: Full disclosure would be a marvelous thing. I think Joe and I would agree that that should be the case. There is a very narrow piece of the fracking fluid that is what we would call “intellectual property.”In other words, if you could put all the ingredients out there and allow fracking and transparency on that issue, that should be the case.

And your second point was-- I don't remember. Sorry.

### Moderator
Claim: Why can't we come up with a safer solution?

### Scientific Advocate (SA)
Claim: Oh, there are many, many green completion approaches. Environmentally friendly fluids. So, they are on the marketplace, they can be used.

### Moderator
Claim: Why don't we use it?

### Scientific Advocate (SA)
Claim: We should.

### Moderator
Claim: Let's go to the other side for a response, so that-- Deborah, Deborah Goldberg.

### Conspiracy Advocate (CA)
Claim: Well, I mean, there are a lot of things that we could do and we should do. But they're not happening. And this huge resistance to that is happening. And so, you know, there's a great deal of talk about this disclosure system that was created by the Groundwater Protection Council and the industry. And they're not disclosing everything. For the most part, they're disclosing only what is regulated as hazardous under our worker health safety issues.

There are a couple of states that have now said that you must disclose everything to the Agency. But they are not disclosing everything to the public. And transparency remains a huge issue. You know, the Secretary of Energy Advisory Board Subcommittee on Fracking-- on which Sue Tierney served-- talks about transparency in a much broader way, so that we get the data about our water quality, and get the data about our air quality. None of this is available to the public right now.

And we are involved litigation-- this very minute-- to try and get the court record from a case involving public health unsealed so that public health professionals in Pennsylvania can actually see the allegations and use them as part of a database to help prevent and treat health problems in Pennsylvania. And we're fighting the industry--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --to try to get that transparency.

### Moderator
Claim: Do you want to respond or--

### Scientific Advocate (SA)
Claim: I just want to mention the Secretary of Energy Advisory Board was unanimous in saying that there should be better disclosure, much better transparency.

There must-- much better regulation in all the ways that I just--

### Moderator
Claim: But every time you say that, it sounds to me like you're giving them the argument, because they're talking about the present-day situation.

### Scientific Advocate (SA)
Claim: I-- and we need to move forward on that. Stop demonizing natural gas as part of that. And the more that people are moving to the sides of the room-- no one is finding any middle ground on this.

### Moderator
Claim: Sir, and-- yes, sir? If you could, again, just state your name. Thanks. As a model of a question, that was fantastic. Thank you very much. Do what he did.

### Moderator
Claim: My name is Dennis Kreutz Why is not the solution-- and I'm coming from this with some experience-- slow it down, get the science right, have the industry profit when gas prices are four or five or six dollars instead of two dollars?

Why is not that the solution to this whole debate?

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: I have one answer for that, which I think is very compelling to me. In the period from 2006 through 2011, when we had dozens and dozens of coal plants being proposed around-- new ones around the country that would lock in large new coal plants for another 50 or 60 years, the changing price of natural gas relative to coal killed those projects. There's a lot of credit given for environmental opposition to those plants and I will give them some credit, but at the end of the day it was natural gas projects that killed those.

### Moderator
Claim: Okay. Right there. Also, if you have a sense that you're involved in this issue in a way that would be interesting to the rest of us, if you're working for an environmental organization or an energy company, share that with us when you introduce yourself. Thanks.

### Moderator
Claim: My name is Erin Griffin. My question has to do with water usage. As Colorado and the southwest are projected to become drier as the climate warms, do you think that diverting millions of gallons of water into natural gas wells is an appropriate use of a resource that's already becoming more precious?

### Scientific Advocate (SA)
Claim: So, John, let me try this. I'm on the Natural Climate Assessment study right now on the impact of a changing climate on the energy sector. You're absolutely right that places will be drier. There will be more pressure on energy supplies. But I want to give you the water use for different fuels. Biofuels, ethanol, 5,000 gallons of water per mmbq of energy. Coal, 23 gallons of water per mmbq of energy. Conventional gas is two and shale gas is two.

### Moderator
Claim: And how much is wind?

### Scientific Advocate (SA)
Claim: Wind is wonderful, and we'll quintuple it. We'll do 10 times the amount and we still will have a little bit.

### Moderator
Claim: Is it true, though-- I'm just trying to go back to sixth grade science when, you know, it rains and then the water evaporates and goes up and becomes a cloud again, and then it rains and comes back to earth and it's a circle, but that in this process once the waste water has truly been used to the point where it can't be recycled, that it's stored under, you know, stored in wells well underground in perpetuity. So that water is taken out of the sixth grade circulation. Is that-- permanently. Is that true?

### Scientific Advocate (SA)
Claim: Yes, that's true.

### Moderator
Claim: Is that worrisome?

### Scientific Advocate (SA)
Claim: Around the country for decades and decades, underground injection has been the water treatment process of choice.

There are parts of the country where that cannot work because of the geology underground. Pennsylvania's an example where there are very limited areas to be able to do that.

### Moderator
Claim: So I want to know if the quantities of water that essentially are being taken out of circulation in a broad sense is significant. We understand that it can impact at a local level, but in a broad sense, are we talking about a significant amount of the Earth's water? I’m putting that to the side arguing against fracking.

### Conspiracy Advocate (CA)
Claim: I haven't really looked globally. The answer to that question is how much fracking do we do? It varies a great deal, you know, on a local basis, and that's where the water consumption takes place. So, for example, in the west we do have major problems with drought. We have forest fires right now. It's projected to get much worse. In the east we have a lot more water than we have in the west, and the water contamination issues are more serious from our perspective than the water quantity, but on the other hand, if you look locally at, you know, head water streams where we have native trout, you can back up your truck into one of those streams and you can drain it dry and that has happened in Pennsylvania.

So I can't say I really have the answer to your question, but--

### Scientific Advocate (SA)
Claim: The country--

### Moderator
Claim: Joe Nocera.

### Scientific Advocate (SA)
Claim: The country has historically, in other forms of energy production, oil, for instance, set aside land and said thou shalt not drill here. And, you know, New York is doing the same thing with its watershed and it doesn't seem to me unreasonable to say yes, fracking is a good thing for the country, but it has some risks and therefore there are certain places we won't do it. That seems like a completely reasonable approach.

### Conspiracy Advocate (CA)
Claim: I would agree. But to me that means that you're agreeing with us that we need to scale back. Because we have--

### Scientific Advocate (SA)
Claim: That's actually saying you would do it surgically where you know you want to protect things, such as the unfiltered water supply of New York City, which is the way it's supported there.

### Conspiracy Advocate (CA)
Claim: And it's great that we found this common ground, because that isn't what the industry is saying in New York.

### Scientific Advocate (SA)
Claim: We are not the industry.

### Conspiracy Advocate (CA)
Claim: I know that. Thank goodness.

### Moderator
Claim: There. In the center. Microphone will come in-- yeah, thanks, very much.

### Conspiracy Advocate (CA)
Claim: Can I just--

### Moderator
Claim: Yeah, sure, Kate Hudson,

### Conspiracy Advocate (CA)
Claim: I just wanted to say that I think that the picking out special places that will be protected from fracking has some serious environmental justice issues around that. So the cities, the people who live in New York City, their drinking water will be protected, the other people in other parts of New York City, their drinking water will not be protected? I think that's--

### Scientific Advocate (SA)
Claim: Actually--

### Conspiracy Advocate (CA)
Claim: --I think that’s a policy question.

### Scientific Advocate (SA)
Claim: Most of New York--

### Moderator
Claim: Sue Tierney.

### Scientific Advocate (SA)
Claim: --City's water supply, as you know, comes from the aquifers upstate. So we're talking about all of New York City

### Conspiracy Advocate (CA)
Claim: No, she's talking about all of New York State, right? The-- you know, we do want to see every community protected, not just ones that have a huge amount of political power in down state. And we don't want to be in a situation where the industry is going into the most economically depressed, most politically powerless areas, and that's where people are not only unable to make a living, but they're now being asked to shoulder disproportionate burdens on their health just to keep food on the table.

### Moderator
Claim: Could you stand up for us? Thanks.

### Moderator
Claim: My name's Baron Bixler And I am just wondering if you could comment on whether you think that the post-9/11 national-- I guess stance on security issues of national security vis-à-vis the Middle East and more recently the great recession has provided the fracking industry with a convenient political backdrop of which to put forth its agenda--

### Moderator
Claim: Okay.

### Moderator
Claim: --to develop.

### Moderator
Claim: All right, I think that question is like a big softball to you guys. So you-- can swing at it?

### Scientific Advocate (SA)
Claim: I'll say.

### Moderator
Claim: Take a swing? Kate Hudson?

### Conspiracy Advocate (CA)
Claim: No, I think that the-- I'm not sure actually whether it's 9/11 itself. I think that the using of the national security energy independence argument to support moving forward with natural gas is playing off of the concerns that the nation has had around 9/11, but I think as we talked about, we think that that is not actually very realistic. And so--

### Scientific Advocate (SA)
Claim: The country has been trying to-- every president in my memory practically has talked about the importance of weaning ourselves from OPEC oil which-- and yet here we are finally in a position to actually do something about it because we have our own resource that-- a resource that we really didn't even know we had 20 years ago. And so 9/11 may have spurred the urgency to do this. I mean, my goodness, we have invaded countries, and we have-- our entire foreign policy towards the Middle East is consciously or subconsciously about oil. And so the idea that we can change the way we think about other countries, the way we can deal with foreign policy, because we no longer have to sit around and worry about whether they're going to give us our oil or not seems to me like a wonderful thing.

### Moderator
Claim: Kate Hudson.

### Conspiracy Advocate (CA)
Claim: The vast majority of the oil that we use in this country is used for the transportation sector.

Natural gas is not going to replace that. Natural gas can be used-- power sector, but not for the transportation sector.

### Scientific Advocate (SA)
Claim: She's wrong.

### Conspiracy Advocate (CA)
Claim: Well, let me just pick up on Kate's--

### Moderator
Claim: Actually, just a moment for the other side to respond to because I want to hear what they have to say. Sue Tierney.

### Scientific Advocate (SA)
Claim: Every thoughtful well documented study that looks at how the United States will transform and decarbonize its economy includes shifting more of the transportation sector to electricity and natural gas, putting carbon capture and sequestration on natural gas facilities, but there is a role for fossil in that decarbonized world, and oil is about this much and it's in the aviation sector.

### Scientific Advocate (SA)
Claim: You know--

### Moderator
Claim: Well, let me--

### Scientific Advocate (SA)
Claim: There is--

### Moderator
Claim: Well, let me let Deborah come-- Joe, let me let Deborah come back because she--

### Conspiracy Advocate (CA)
Claim: But I was just going to say that Joe recognized Fred Krupp as somebody who he thought was reasonable and authoritative.

And the Environmental Defense Fund has recently done a study, looking at the climate impacts of shifting from coal to gas, and I will tell you that they do find, they do agree that we would do better, assuming that our methane emissions don't rise to the level of four percent, but they absolutely disagree that if we shift our entire transportation system from oil to gas, that we are going to have net climate benefits over as much as 100 years. So I think we can agree that there might be a small part. There's natural gas buses in New York City. There might be small amounts, but shifting the whole sector over is just a non-starter.

### Moderator
Claim: Joe Nocera.

### Scientific Advocate (SA)
Claim: Let me say two quick things about that. First of all, what EDF has actually said is that if methane leakage can come down and, the idea that we can't have any technology to make things better seems to me pretty unreasonable. Technology does make things better, and the idea that we're always going to be stuck even if in fact, if we are today, at four percent methane leakage, is not necessarily the way it's going to play out.

Secondly, it's already happening. Not only are buses fueled by natural gas in cities, but large trucking companies are beginning to convert to natural gas, and large energy companies are beginning to think about putting natural gas stations on the interstate highway.

### Moderator
Claim: All right, question down in the front row. Sir, could you stand and tell us your name and if you're affiliated with the--

### Moderator
Claim: Arnie Togan I've written a lot of legislation, and I've helped with a lot of legislation and I just want to congratulate you on the scare tactics that you used, because believe it or not it helps us write our legislation. An example of it--

### Moderator
Claim: Sir, can you-- can you just bring it to a question for them?

### Moderator
Claim: Okay, I just wonder if stopping this process is the answer.

### Conspiracy Advocate (CA)
Claim: That's not what we have advocated. So I would say, "No," once again.

### Moderator
Claim: Another question. I'm sorry that I'm tending towards the right there, did you have your hand up? Yep. Yes, she did. Okay, yeah. I mean, all right, I'll come back to you. Go ahead, sir.

### Moderator
Claim: My name's Kevin Alt and an engineer in the oil business. I have fracked wells in Pennsylvania, fracked wells Texas, Oklahoma, New Mexico. You give the impression that the science has to catch up. Do you have any idea how long we've been fracking wells?

### Conspiracy Advocate (CA)
Claim: We have been fracking wells not for shale gas for many decades, but the shale gas fracturing, which includes two technologies used together, the horizontal drilling and the hydraulic fracturing, has been used, seriously, only for about a decade, and it's the impacts of the shale gas drilling that are driving all that opposition, because we are not prepared for the volume of the wastewater, and we have nobody out there in the federal government and in many states that are looking cumulatively at all of the impacts.

### Moderator
Claim: So it's about wastewater?

### Conspiracy Advocate (CA)
Claim: It is wastewater. But I'm sorry, I don't understand the question.

### Moderator
Claim: I-- you actually did ask the question, but I can't have you debate. But do you want to ask a follow-up question?

### Moderator
Claim: Yeah, you--

### Moderator
Claim: Okay.

### Moderator
Claim: --you said first that it's about methane leakage. Wastewater is handled efficiently coming out of all the wells. And again, Pennsylvania will adapt very quickly to this. So I-- this is not a wastewater question, and it's not a wastewater management question.

### Conspiracy Advocate (CA)
Claim: Where is the wastewater going that's coming out of the well?

### Moderator
Claim: Into water disposal wells.

### Conspiracy Advocate (CA)
Claim: In Ohio.

### Moderator
Claim: In Pennsylvania as well.

### Conspiracy Advocate (CA)
Claim: There's one commercial well that takes shale gas wastewater in all of Pennsylvania and - -

### Moderator
Claim: But there’s lots of private wells.

### Conspiracy Advocate (CA)
Claim: They-- they're not taking this--

### Moderator
Claim: Sir, I'm going to end this because-- not because I don't think it's a legitimate point but I just don't want you to be the debater. That's their job here--

### Scientific Advocate (SA)
Claim: Because it's so much fun when you are.

### Moderator
Claim: Good evening, I'm Kathy LeMieux- Rodman. I thank you all for being here. It's been a wonderful presentation. Joe, this is for you and Sue. I was on the board at EDF for many years and watched legislation for coal and for many years how the lawyers handled scrubbers and a lot of other work. It was wonderful.

Joe, you bring up the question of national security. If you look backwards at where we've come with environment extraction, anything taking anything out of the earth has plus and minus, but there's short term and long term gain. My question to you is, as a journalist, would you address the issue of water as national security over the next 100 years, because as we pollute our water, we don't have water to drink, that's going to be an issue, and, Sue, with all you're doing, all your analysis--

### Scientific Advocate (SA)
Claim: Okay, but water is going to be one of the central issues of the century that we live in. There's no question about that, and there's also no question that we have to work hard to avoid polluting our water, and that's why I advocate that there are areas that we shouldn't frack, and I also think-- this is why I also-- on this side of the table, we're not saying, “Frack horribly.” We're not saying, “Hey, let's put the worst wells in we can and let them leak and damage the environment.” What we're saying is if you do it responsibly, if you do it in a regulated way, you minimize the possibility. You don't eliminate it. You don't eliminate all risk.

### Moderator
Claim: Okay. Right down in the front there.

### Moderator
Claim: I thought I understood the question that we were going to vote on before I came in here. But as this is continued, it seems to me we're talking about matters of degrees. So, when we do cast our votes, are we voting for no fracking, with this red sign that says “None”?

Or are we voting for some degree of fracking that's controlled-- but it sounds to me like you're both saying the same thing, with different, different degrees of

### Moderator
Claim: All right. Let me--

First of all-- first of all-- to clearly clarify, we're not saying “No fracking at all.” We're-- the motion says that the cost-benefit analysis-- it's a judgment on the cost-benefit analysis as opposed to immediately making a policy decision. That said, where is the-- where is the disagreement between these two sides?

### Conspiracy Advocate (CA)
Claim: Well, I was worried about that actually, when we were going into this, because it seems to me that we're probably much closer than the organizers of this event might have thought. So, we're trying to make for a lively debate--

### Scientific Advocate (SA)
Claim: I don't-- I don't agree. I think-- I-- I think that--

### Moderator
Claim: He doesn't agree with you already. Thank you. Joe.

### Scientific Advocate (SA)
Claim: The people on this side believe that the issues of the economic benefits, the security benefits, and even the environmental benefits make fracking-- the benefits far outweigh the costs. And that is our view. And I don't think you’ve said anything that really has changed our minds on that. The issue we're-- do we care about having it done right? Yes, we do. Do we think the benefits are tremendous for America? Yes, we do. And--

### Scientific Advocate (SA)
Claim: We think the benefits would still be there--

### Moderator
Claim: Sue Tierney.

### Scientific Advocate (SA)
Claim: --if we added 50 cents to the price of natural gas to cover these things? Yes. The benefits are huge.

### Conspiracy Advocate (CA)
Claim: But I would say--

### Moderator
Claim: Kate Hudson.

### Conspiracy Advocate (CA)
Claim: --that the question here is not whether we can do it right at some point in the future, but whether we're doing it right now. Right now--

## Round 3

### Moderator
Claim: All right. I have to say, that concludes Round 2 of this Intelligence Squared U.S. debate. Thank you. And now we go on to Round 3. And Round 3 is where each of the debaters has a last chance to persuade you to their point of view or to persuade you that they've actually presented the better argument. Our motion is this: No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good. Each debater gets two minutes to summarize his or her position. And speaking first, against this motion, Joe Nocera, an Op-Ed columnist for “The New York Times.” You can applaud. Let me do that again.

### Scientific Advocate (SA)
Claim: You don't have to.

### Moderator
Claim: I'll do that again. And speaking against the motion, Joe Nocera, an Op-Ed columnist for “The New York Times.”

### Scientific Advocate (SA)
Claim: On some level, I gave my closing argument about two seconds ago.

I do feel that it's clear that natural gas has reduced emissions. It is demonstrably better than coal. It is offering us the possibility-- wonderful possibility-- to wean ourselves from Mideast oil. And it's been incredibly economically beneficial for the country to have gas plentiful and cheap. I want to say-- I really want to end on, on this spot. Our opponents-- I want to think about it this way.

When you're arguing against fracking, you're not arguing for a future of renewables. You may think you are, but you're not. You're arguing for the status quo. You're arguing for a world where coal is still the dominant power generation, where oil is still the fundamental fuel that we use to transport ourselves.

You know, all the problems that we have today that have been brought about by the way we use energy are still with us. And so, what I would ask the other side to think about is, what does the future look like if we don't have fracking? What does the future look like if we don't have this wonderful source of natural gas, this abundant source of gas that we've been given. I don't think the future looks all that well-- all that good. Thank you very much.

You don't have to.

### Moderator
Claim: Thank you, Joe Nocera. Our motion is No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good and here to summarize their position in support of this motion, Kate Hudson, watershed program director for Riverkeeper.

### Conspiracy Advocate (CA)
Claim: Having heard what our opponents have said here tonight, you might think we should not be concerned about the impacts of fracking. In their view, any problems we have now will be fixed with golden rules, more regulation, and hopes of improved technology. I think of a few reasons to remain concerned. One, there will always be accidents, spills, mechanical failures, and human error. Two, the gas industry has consistently fought enforceable rules and there is insufficient state and federal staff to ensure compliance with what rules do exist. Three, the idea that the industry as a whole will comply with voluntary best practices-- as I think our opponents have acknowledged-- in the face of falling gas prices, is unlikely.

Given the continued risk of harm and all of frackings costs weighed against its limited benefits for most, it is beyond dispute that the natural gas boom is doing more harm than good. Simply ask the mothers of children who attend the Red Hawk Elementary School in the Front Range town of Eerie, Colorado.

Last fall there were children who stayed home from school with intestinal and breathing problems due to the hundreds of oil drill rigs-- gas drill rigs in the region. Then, the industry insisted on locating gas wells a few hundred yards from the school and a short distance from a school playing field. Parents and children joined together to protest the new well and the town put a temporary moratorium on new permits, but that does not apply to the already permitted elementary school site. So this summer, as drilling takes place, teenage boys will have football practice in the shadow of operating drill rigs. The families of Eerie make it clear, if this uncontrolled experiment, which is the natural gas boom, is allowed to continue, homeowners, farms, schools, and hospitals whose neighbors agree to lease will have no choice. But we have a choice now. The shale gas boom is doing more harm than good and we urge you all to say-- to vote no fracking way.

### Moderator
Claim: Thank you, Kate Hudson. And that is our motion, No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good, and here to summarize her position against the motion, Sue Tierney, former assistant secretary for policy at the U.S. Department of Energy.

### Scientific Advocate (SA)
Claim: I was-- I was also secretary of environmental affairs in Massachusetts, head of the environmental police, head of environmental regulation. I came into this field because I grew up in southern California and couldn't stand the fact that we couldn't see the mountains from where I lived. I went into energy because it seemed to me it was an unbelievably complicated world in which you had these environmental impacts, which were so compelling, and yet you had everybody using cars and a variety of things. In the 30 years that I've been in the energy and environmental fields, I have never seen more polarizing and demonizing discussions as now exist on shale gas, and I saw nuclear plant debates, I saw transmission line plants, everything.

This is one where the science and the information is-- the gap between what we know and what people say we know is wider than I've seen in any other field. The reason I bring this up is this polarizing part of it makes it impossible for the two sides to find the middle ground, and that's why this issue is we need to stop demonizing this particular fuel, because if we do that we kill it and we kill not only the benefits that Joe just described, but we get back to coal. And that is the reality that we face and I urge you, for that reason, to vote against this proposition.

### Moderator
Claim: Thank you, Sue Tierney. motion is No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good, and here to summarize her position in support of the motion, no fracking way, Deborah Goldberg, the managing attorney at Earthjustice.

### Conspiracy Advocate (CA)
Claim: I'd like to close with two of my favorite quotes from my opponents. In February of this year, Joe Nocera wrote, "How much methane leaks into the air as a result of fracking?" Incredibly, nobody knows. In May of this year, Sue Tierney said on NPR, "Fifty years from now, are we really going to be wondering if we really screwed up because we went on this big gas boom? You really wouldn't want to be F-ing that up," and I agree. We don't know, and we really don't want to be messing that up.

And that means we need to scale back, slow down, and resist the boom mentality. We have to scale back. We do not have to drill hundreds of thousands of wells just because we can. We don't have to drill near elementary schools, and we can protect our state forests and our parks.

We need to slow down. We need to take the time to let the science catch up with the practice and the safeguards catch up with the science, and we need the resources to ensure that the rules we have in place are vigorously enforced. There's no rush. The gas has been there for millions of years. It's not going away. Finally, we have to ignore the advertising slogans on both sides, the demonizing goes on on both sides, filling the airways, and stop living in a fantasy world of endless fossil fuel consumption without consequences. We need to restart the conversation about putting a price on carbon, and we need to develop a real meaningful energy policy, not “all of the above.” That's no policy at all. Does that make sense to you?

Do you want to limit the intensive gas development and the breakneck speed of fracking until we answer the open scientific questions and put policies in place to ensure that we are not messing up? Then you should vote for us, because you recognize, as we do, that until we have those safeguards in place and until we have that information, we have nothing but an uncontrolled experiment and the natural gas boom is doing more harm than good.

### Moderator
Claim: Thank you very much, Deborah Goldberg. And that concludes Round 3 and this Intelligence Squared Debate. And now it's time to find which side you feel has argued best.

We're going to ask you again to go to the keypads at your seat. Remember, we had you vote at the beginning of the debate on where you stood on this motion, No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good." You've heard the arguments. We want to ask you to judge which side presented their arguments best. If you agree that this side presented the best arguments, the side that is for the motion, but that means that they are against, in a broad sense, fracking, push number one.

If it’s the other side, which takes the opposite position, push number two. And if you are undecided or became undecided, push number three. And we'll lock in the results in about 10 seconds, and in about 90 seconds we'll have the numbers for the two comparisons. So while that's being tabulated backstage, I just want to-- I really want to thank these debaters for doing what we asked them to do which was really bring good arguments to the-- and also just by point of comparison, it's our first time in Aspen, and, you know, as a rule, audience questions can be a sort of tricky area to go to.

Tonight, this audience was spectacular in the questions, not just in the format, but really you moved things along, you put very, very interesting things into this debate, so I want to give yourselves a round of applause for that. did really good. So just a few things to say, we want to again thank the Aspen Institute for inviting us down to this year's Ideas Festival, for letting you see what it is that we do back in New York at Intelligence Squared U.S. Thank you very much for the American Clean Skies Foundation, for their underwriting support for this, and making it all happen. And if some of you are New Yorkers or going to New York, we want to let you know that this fall-- what we intend to do with our series of debate topics is to try to follow the ebb and flow of the dialogue that's taking place in the presidential election, and keep-- you know, bounce off what's actually happening in that debate by exploring the issues in more depth in our own debates. And so the motions that we're working on now will be announced in several weeks, and also who the debaters will be. So we have a website, IQ2US.org. You can go look to that. You can buy tickets there and keep in touch with us. And if you get to New York, please do come.

Also, in mid-October, we're going to be on the road again. We're going to be going this time to Chicago. This'll be our second annual Chicago Ideas Week.

If you're in New York, I should say, our-- we're changing locations. We're going to the Kauffman Center, which is near Lincoln Center. We can be seen on public television in New York and also here and around the country on the 220+ NPR stations. We also have a podcast that is on iTunes. And we have a newsletter. You can sign up for our website. So again, thank you very much for the debaters and for your participation.

And now we have the results, and we'll find out what happened. So remember, before the debate we asked you to vote on this motion, No Fracking Way: The Natural Gas Boom is Doing More Harm Than Good. If you're for the motion, it means you're saying, "No fracking way." If you're against the motion, you are disagreeing with "No fracking way." So before the debate, 38 percent of you were for the motion "No fracking way," 53 percent were against. After the-- I'm sorry-- I'm sorry, it's a split. I'm going to start this again.

Before the debate, 38 percent of you were for the motion, 38 percent, against, evenly split, and 24 percent were undecided. After the debate, 53 percent of you are for the motion "No fracking way," that's up 15 percent, 42 percent are against, that's up only four percent, five percent are undecided, that means the team arguing for the motion "No fracking way," has won this debate. Our congratulations to them. Thank you from me, John Donvan of Intelligence Squared U.S., and we'll see you next time.
