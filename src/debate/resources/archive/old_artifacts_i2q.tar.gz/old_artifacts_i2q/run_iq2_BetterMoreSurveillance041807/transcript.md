# Debate Transcript

Topic: Better More Domestic Surveillance Than Another 9/11
Motion: Better More Domestic Surveillance Than Another 9/11

Debate ID: BetterMoreSurveillance041807


## Round 1

### Moderator
Claim: “Intelligence Squared U.S.” “Better more domestic surveillance than another 9/11” A another 9/11”

### Moderator
Claim: . And to begin the program, I would like to introduce Robert Rosenkranz, chairman of the Rosenkranz Foundation, the sponsor of this evening’s debate.

### Moderator
Claim: Well, thank you for that polite applause. It’s really my pleasure and honor to, uh, to welcome you all tonight, this is the seventh debate in our inaugural series of public policy debates, “Intelligence Squared,” I’m the chairman of Intelligence Squared, which is an initiative of the Rosenkranz Foundation. Uh, as Chris said, these proceedings are, uh, produced for radio by WNYC, and broadcast nationally through NPR. We’re also thankful to our sponsor, the Times of London. Well, to what extent should we trade privacy for security? Our society’s one that values civil liberty so highly that in the words of Justice Cardozo, um…if a constable blunders, the criminal goes free. But what is that saying, it’s that the need to incentivize the constable to follow the rules is more important to our society than justice for the individual criminal, or compassion for his victim. Um…but, we also value security a great deal also. Uh, 9/11 presented an unprecedented type of threat. It’s clear that there are terrorists out there who will inflict the, the… deadliest kind of means at their disposal, to, to create grievous harm for civilians here. And, uh, the traditional legal framework of dealing with soldiers or dealing with criminals, uh, was never created with that kind of threat in mind. So it’s, it’s sort of self-evident, uh, that the lines that were drawn prior to 9/11 must be drawn differently. But the question is how differently. And one would expect a lively national debate on an issue of this kind of importance, it’s very timely. Um… In the news recently has been scrutiny of international banking transactions. Uh, wiretaps without warrants. Just in the last week or so, there’ve been proposed renewal and revisions of, of FISA, the Fed— Foreign Intelligence, uh, Surveillance Act. But the debate on these kinds of issues has been somewhat clouded by a, a,…general skepticism I would say of the Bush administration both in terms of its competence and judgment. And, uh, our hope tonight is really to transcend, uh, partisan bickering, transcend ideology, because getting the trade-off between privacy and security right, demands reasoned discourse. And our lives may depend upon it. So, uh, it’s now my real pleasure to turn the evening over to the stellar panelists that, uh, uh, that Dana Wolfe our executive producer has put together this evening. Our moderator is Chris Bury, who’s known to you all from ABC News “Nightline.” He’s reported extensively on national politics and policy issues including the intelligence community. He anchored “Nightline” from Afghanistan, from CENTCOM war headquarters, and in a network first, from the Fort Meade headquarters of the National Security Agency. He’s earned five Emmy Awards for his work on “Nightline,” received Columbia University DuPont honors for his reporting on “World News Tonight,” so I’m pleased to add the au—hand the evening over to Chris Bury.

### Moderator
Claim: Thank you, Bob, for that kind introduction. And I’d like to thank you as well for your considerable efforts to raise the substance, elevate the substance and the tone of public conversation on, on matters of public policy, we’re all grateful for that, thank you. Now I would like to welcome you officially to the seventh Intelligence Squared U.S. debate. I’ll give you a brief rundown of how things are gonna go this evening. First the proposers of the motion will start by presenting their side of the argument, “Better more domestic surveillance than another 9/11.” The opposition will follow. Each person will get a maximum of eight minutes, and we’ll go back and forth between the two sides. Each speaker will get a notice from me with one minute to go. And debaters, when you get that one-minute warning it really is time to wrap things up, because when your time has come, it is my job to cut you off with all the mercy of Robespierre at the guillotine. Not to be rude but because this is a radio broadcast and we’re gonna try to keep the trains, uh, running on time here. Second, when all speakers are finished with their opening remarks, I’m gonna follow up and try to get you going with some civil exchange. And then we’re gonna open up the floor to the audience, and for audience members, uh, we’d ask you to keep your questions short and, uh, to the point, you may wanna direct them at an individual panelist or you may want to direct them at one particular side of, of the argument. We ask that you refrain from giving speeches, we just don’t have the time. After the Q-and-A, each debater will make a final statement, lasting not longer than two minutes. And after the final closing argument you will vote on tonight’s motion, with the keypad which is attached to the arm-rest of your seat. Finally I will announce the results of the audience vote, and tell you which of these sides has carried the day. For those of you who have attended previous debates, you probably had one of those little cards, and let me see if I, if I have one here, you’re probably used to this. Um, tonight we’re gonna try something new, and, uh, vote with an electronic system. And, uh, I think Diebold made it so there shouldn’t be any problem at all… But we will ask for your patience because, uh, this is a virgin attempt at this electronic system. And so, uh, let’s find a—here we go, the— it looks like a little calculator, does everybody have… located this, it should be on the side of your… arm-rest, so, see if you can find these… All right, everybody have ‘em? So before we hear the arguments from our panelists, let’s see how you feel on the question right now. So pick up the keypad…and after my prompt, you will press 1 if you are for the motion, “Better more surveillance than another 9/11,” press 2 if you are against that motion, and press 3 if you’re undecided. And you may begin voting now. Everybody got that, 1 if you’re for, 2 against, and 3 undecided. And I don’t see any panic from the control room so we’re hoping that…it—it’s going to work. Let me introduce our distinguished panel of guests tonight. For the motion, on my far right, spatially speaking, only, author… columnist for National Review Online and resident fellow at the American Enterprise Institute, David Frum.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Senior fellow at the Foundation for Defense of Democracies, and contributor to National Review Online, former federal prosecutor Andrew C. McCarthy. And to my immediate right, professor of law at the University of California at Berkeley School of Law, and former Deputy Assistant Attorney General in the Office of Legal Counsel of the US Department of Justice during 9/11, John Yoo. On my left, an unusual position for him, sometimes, former Congressman, occupant of the 21st Century Liberties Chair for Freedom and Privacy at the American Conservative Union, columnist and radio show host, the honorable Bob Barr. To Mr. Barr’s left, author, professor of law at the George Washington University Law School, and legal affairs editor of The New Republic magazine, Jeffrey Rosen. And on my far left, professor of law at New York Law School, and president of the American Civil Liberties Union, Nadine Strossen. So let’s start the debate and arguing for the opposition, David Frum, please take the podium—

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you, thank you all, and thank you to the Rosenkranz Foundation for their important work in…making civil conversation really a reality in which we can all participate. Like to tell you a little story to begin. Uh, about two months after I started work at the White House in two—2001, there was a rap on the door, not a midnight rap, a daytime rap. Uh, my wife, um, went to answer the door, um, and there on the step was an agent of the FBI. Uh, showed her his badge, and asked if he might come in and ask a few questions. Our neigh—next-door neighbor, he told her, had just, uh, been hired into a sensitive position in the federal government, and as part of the security check on the next-door neighbor he wanted to ask a few questions. So he asked my wife, uh, had we noticed anything unusual about them, did they seem to be living within their means, uh, did they, uh, conduct themselves responsibly and respectably in the neighborhood and— She was a little embarrassed because these were new neighbors, we did not know them well but to the best of her ability she gave ‘em a clean bill of health. But jogged by this, she said, you know, we haven’t had them over, we really should. So— So she invited the next-door neighbors over a few weeks later and they came and we poured tea and gave them cake and eventually my wife congratulated, um, them on, on the husband’s new job with the federal government. He said, what are you talking about, he said I’m—I’m still at Sibley and Austin, I’ve always been at Sibley and Austin. And what we realized, was, that the FBI had meant to come to their house… to ask them about me. Tonight’s motion, is “Better—better more domestic surveillance than another 9/11,” and the question is, more than what? And my answer is, more than that. Now, none of us are here to argue, none of us are here to argue for limitless domestic surveillance. Um, the three of us on the affirmative side of this debate have a deep and abiding commitment to privacy and liberty. Um, my colleague, Andy McCarthy, has been a federal prosecutor, his job is to defend and uphold the US Constitution, the greatest liberty-affirming document in world history. My colleague John Yoo, was on the front line to defend all—all of our liberties, and liberties of people all over the world, against, uh, totalitarian conspiracy. Not only that but in our private lives, Andy McCarthy is a conservative in New York, and John Yoo is a conservative at Berkeley, California. We understand, believe me, in the most intimate possible way, the importance of free thought, free expression, privacy, and the ability of human beings to speak their mind in debate and conversation, without fear of punishment or consequence or an overbearing state. But…here’s the question for today. Should we have more surveillance than we had when those FBI agents were knocking on the wrong door…at, uh, a level of surveillance that made possible the tremendous catastrophe we know as 9/11, or should we continue with the path we’ve been following since 9/11, toward, not a police state, not a nightmare regime in which you have no privacy. Is anyone in this room as a concrete matter afraid to speak his or her mind? I very much doubt it. But, um… That’s just because your listeners are so cranky. Uh…we, we are here— Uh, we are here to uphold…a new level of surveillance, that is, uh, that is not made up of new techniques, it is made up of very familiar and traditional techniques, as my partners will argue, that is not onerous, that is not burdensome, that leaves all legitimate freedoms and privacies intact, and that is abundantly worth it, and in fact has proven over the past half- decade, has proven in the acid test of experience its merit. You know, 9/11 is beginning to be a little while ago. But the recent terrible events of—at Virginia Tech, um, Technical institute—the, the Virginia Tech University, remind us, remind us of the reality of danger and fear, uh, of—that we all experienced in those terrible days. Now if we cast our minds back, back to that time, I think many of us will remember, we expected more of the same. We dreaded more of the same. And that was one of the reasons that, uh, the—the sniper attacks in Washington were able to paralyze a great city. Because we were ready for something dreadful, something even more dreadful. And on American soil, it has not happened. But that does not mean that the threat is not real, in fact, if you sound the roll of world events since 9/11, you will be reminded how very, very real it is. In December of 2001, gunmen attacked the Indian parliament, and, uh, attempted— well, hoped, hoped to kill in fact very senior officials in the Indian government. They did kill a number of parliamentarians and some ci—uh, civil servants, and some security guards, and very nearly succeeded in triggering a nuclear war, between India and Pakistan. We remember the bombing in Bali, uh, whi—which took so many lives of, uh, Indonesians and Australians, and others who were, who were visiting that, that beautiful place. The Madrid Atocha railway station bombings. The bombings in London in 2005. Just this past year in 2006, attempted bombings, very serious attempted bombings, in Toronto, and in Germany, and tragically a successful bombing in Bombay, successful of course from the point of view of the terrorists. These—the, the threat, the threat of mass-casualty terrorism, um, at the hands of people guided by a totalitarian ideology, remains a real threat. But here’s the good news. What we notice as we look back on this half-decade of terrible atrocities, is a dwindling level of sophistication, behind each of these attacks. Uh, that the Atocha attack was much less sophisticated than the 9/11 attack, the London attack in 2005, less sophisticated than Atocha, and the attacks attempted this past summer were less sophisticated than those of 2005. The terrorists are finding it harder to coordinate, they’re finding it harder to communicate with each other, they are under crushing international pressure. Now…one of the ironies about this is, we don’t…entirely understand how this is happening, even inside our own law enforcement agencies. Here’s one way to think about how a terrorist attack proceeds. If any—if any of you have been in a toy store recently I’m sure you’ve seen those toys, where you drop a ball bearing, uh, through, uh, into a little slot and it whizzes and rolls and it catches the little teeter-totter and it goes through a basketball hoop, and it proceeds over many, uh, feet of track until finally it emerges out the other end. And there are a series all along the way of little switching points, and that’s the game, to watch the ball jump and hop and skip and move past these various obstacles. Think of a terrorist plot as like that ball bearing. It starts, and it rolls and it unfurls. And it has to pass—

—pass through a number of switching points. If you can make each of those points just slightly more difficult, you stop the plot in just the way the earth’s atmosphere stops the meteorites, without any of us ever being aware of it. It is that level of in—of in—of intensified surveillance of illegitimate activities, that has complicated the life of the terrorist, not—and has not made terrorism impossible, has not in any way lessened their desire to do people harm, but that has made—that has broken up their ability to communicate with one another, that has made it more difficult for them to move money, and has made it much more difficult to strike, and especially to strike inside the United States. You know, all of us here, are people—are, um, are people who love liberty. Who prize liberty, and who use liberty, as we are using it tonight. But we are also citizens of great cities in the Western world. And we are all potential casualties of attack. And the liberties we are using are the very thing, the very thing that inflames and provokes those who would attack us.

We are here—

—to defend that liberty, by defending the higher level of surveillance seen since 9/11. Thank you—

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —pass through a number of switching points. If you can make each of those points just slightly more difficult, you stop the plot in just the way the earth’s atmosphere stops the meteorites, without any of us ever being aware of it. It is that level of in—of in—of intensified surveillance of illegitimate activities, that has complicated the life of the terrorist, not—and has not made terrorism impossible, has not in any way lessened their desire to do people harm, but that has made—that has broken up their ability to communicate with one another, that has made it more difficult for them to move money, and has made it much more difficult to strike, and especially to strike inside the United States. You know, all of us here, are people—are, um, are people who love liberty. Who prize liberty, and who use liberty, as we are using it tonight. But we are also citizens of great cities in the Western world. And we are all potential casualties of attack. And the liberties we are using are the very thing, the very thing that inflames and provokes those who would attack us.

### Moderator
Claim: David Frum—

### Conspiracy Advocate (CA)
Claim: We are here—

### Moderator
Claim: —thank you very much—

### Conspiracy Advocate (CA)
Claim: —to defend that liberty, by defending the higher level of surveillance seen since 9/11. Thank you—

### Moderator
Claim: Thank you, David. And arguing against the motion, Bob Barr.

### Scientific Advocate (SA)
Claim: I promise…not to use the example that David gave us, of how easy it is for the FBI to screw up something as simple…as interviewing the right person for a federal job, security clearance… as, as clear an example of why we should not entrust yet additional secret surveillance powers to the government, I promise not to make such an example. Better more domestic surveillance than another 9/11? I don’t know how to put it quite delicately enough, and not just no but hell no. The government doesn’t need it…the government has shown it doesn’t deserve it...the government has not justified it, the government will abuse additional domestic surveillance power, as sure as we are sitting here this evening. And the people of this great land, and those who lawfully visit this country as well, cannot afford it. Now why can’t we afford it. Many of us here, many of you all may be here this evening, because you have a particular privacy concern. A particular category of information, that you believe ought to be, or, continue to be, private, from government snooping. From government surveillance. Or, you may not have a particular category of such information yourself, but others might, and you support them, in maintaining the secrecy, the privacy, the privilege, of maintaining that information for themselves. But I suspect that deep down, at least most of us are here this evening, because we understand that privacy is more than simply the sum total of individual aspects of information that we wanna retain private. Ayn Rand, that great philosopher, who just two years ago I believe it was we celebrated centennial of her birth…and that great proponent of freedom, put it perhaps best, when she wrote, in 1943, in the middle of World War II, in The Fountainhead, that “privacy is the essence of civilization itself. Yes, it is that important. Civilization is the march of mankind…toward a realization and an acceptance of and a protection of, the basic right to privacy.” I think our founding fathers understood that, when they crafted the Bill of Rights.

They didn’t feel the need to mention, in each one of those, this is a privacy right. But just look at them, and you see the importance of privacy, embodied in… the foundation of the First Amendment. Were it not based on a notion that we have a right to the privacy, of our religious, political views for example, there’d be no reason to have the First Amendment. The Second Amendment…so much in the news these days, also is founded in essence on the notion of privacy. If we, as preachers of God, did not enjoy the inherent right to the privacy of our being, of our property, then there would be no reason to have a Second Amendment which is designed to implement the protection of those ideas, those properties, those persons. The right to the privacy, the right to have your ideas, your privacy, your property, your person free from unwarranted government intrusion is indeed the essence of civilization. That’s why it’s so important that we address this issue. The question, “Better more domestic surveillance than another 9/11”…look at what we’re talking about here, we’re not talking about the legitimate function of government in a national security context…to gather intelligence on foreigners, foreign intelligence. What we’re talking about is our government surveilling us. And they ought to be held, and the Fourth Amendment requires them to be held, to a very high burden. Why? Because our founding fathers recognized…that if we allowed the government to intrude into our lives, other than in those areas where it has an articulable, legitimate need to pierce that sphere of privacy that surrounds each one of us, if we allow that, then we are not free. Think back. This question also talks about another 9/11. Fear, of course the driving force for virtually every effort by the federal government and indeed by state and local governments, since 9/11, to justify whatever expanded government power it is that they seek. We’re talking about another 9/11. Well, let’s think about 9/11. Did 9/11 happen, did those awful… terrorists succeed on 9/11 in this very city, and in our nation’s capital, and in that field in Pennsylvania, did they succeed because the government was not able to increase its surveillance of…those of us in this country, no. Those terrorists succeeded because of a series of tragic… mistakes and blunders by government. Our government didn’t use the tools that were already available to it. It could’ve stopped those terrorists at any number of points along their horrible journey. There were laws, repetitive laws, on the books, at the federal and the state level, to have stopped them from gaining access to the information that they needed. From gaining access to—access to the tools whereby car—they carried out…their horrible deeds. It wasn’t because the government lacked…sufficient power to surveil Americans. It is a false premise. And what has the government done since then, and what is it even doing now. I guarantee you, if this question, “Better more domestic surveillance than another 9/11,” is answered by the American people, not just here this evening, but writ large…then you will never, ever see the end of government surveillance power. Sort of like being a divorce lawyer, something I do not do. No matter how much you concede to the other side—

—they always want more.

So it is with domestic surveillance. Even today, this administration, which has violated the laws limiting…its ability to conduct domestic surveillance, it wishes and is seeking legislation to gain even more access to our private lives, and, get this. The final irony. To grant immunity for past violations of the law. Better more domestic surveillance than another 9/11, not on your life. Thank you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: —they always want more.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: So it is with domestic surveillance. Even today, this administration, which has violated the laws limiting…its ability to conduct domestic surveillance, it wishes and is seeking legislation to gain even more access to our private lives, and, get this. The final irony. To grant immunity for past violations of the law. Better more domestic surveillance than another 9/11, not on your life. Thank you.

### Moderator
Claim: Bob Barr, thank you. For the motion, Andrew McCarthy.

### Conspiracy Advocate (CA)
Claim: Thank you very much. Um, pleasure to be here this evening. My, uh, FBI story is a little bit different from David’s. It’s more along the lines of what the FBI was up against. My brother, who lived in the Bronx, was applying for a job with the FBI, uh, and the knock we got on the door was from one of the neighbors who told him that the Feds had been by, but not to worry – he didn’t tell ‘em nothing. Um, that, of course, was back in the 1990s, uh, before there ever was a, uh, George W. Bush Administration to bash. Uh, and during that time the United States managed to stop exactly one terrorist attack by something other than dumb luck. That was the spring 1993 Jihadist conspiracy against New York City landmarks, right here in Manhattan. How did we stop it? The FBI had a confidential informant who infiltrated the conspiracy. Now, think for a moment about how intrusive that is. Our government sent a man right out into radical mosques to meet with worshipers.

All of them were Muslims. Several of them were American citizens. He prayed among them, he entered their very homes, he tape recorded all of his conversations. And following the government’s instructions, he lied to them about who he was and who he was working for. And he did that precisely to trick them, uh, in order to get them to compromise their most deeply held secrets and plans. And you know what? Neither the Fifth Amendment nor the Fourth Amendment had a thing to say about it. It’s been the law of the United States for decades that such investigative techniques do not implicate our privacy and due process interests. Um, as a result of that there were no court orders for those tactics, no judicial supervision, uh, no supervision of any kind for the most intrusive tactics imaginable.

And had those tactics not been used, thousands of New Yorkers would have lost their lives in those attacks. That’s not me conjuring up a nightmare scenario. That’s not me trying to tap into your fear. That’s a case that actually happened, right down here in Manhattan. Uh, it’s the kind of investigating that didn’t happen before 9/11, when nearly three thousand people were killed, and didn’t happen in connection with most of the completed atrocities that were the subjects of the trials that took place in the 1990s. And the Executive Branch, without judicial supervision and without much Congressional oversight to speak of, has intercepted and electronically eavesdropped on enemy communications in every war in the history of the United States since it’s been technologically possible to do so.

It’s a simple fact. You cannot get good actionable intelligence, the intelligence that saves lives, without monitoring what people are saying to each other and without watching the bad guys to see who they speak to so that you can map out these organizations. That’s just common sense. The most dangerous conspirators are generally speaking the most insulated conspirators. It takes wiretapping to ferret them out. In the 1930s, uh, the government got Al Capone on tax evasion. That’s all they could come up with. Uh, but in the 1990s the government got John Gotti on about twenty-five homicides. How did they do it? They listened to what he was saying. They bugged his conversations. Today, of course, we’re not talking about Mafia hits. We’re talking about mass murders of our citizens – not just law enforcement but national security. All of our liberties are precious. On that, uh, I think every panelist here is in agreement, as David said before.

But none of our liberties is worthy of the name unless we can secure the country. And all our liberties are valuable but none of them is as valuable as the collective right to life that belongs to all of us collectively together in our national community. To protect that right we have to do surveillance. We’re fighting an enemy that does not have a territory to defend. It does not have a treasure that we can destroy them by taking. Our only, only defense is surveillance – finding out who they are, trying to figure out what they might strike next. And stopping them is far more important than prosecuting them. Prosecutions become cold comfort when the death tolls start to climb into the hundreds and the thousands. And we’ve seen that. That’s not a scare tactic.

Against such daunting risks privacy interests fretted over by our friends on the other side are frankly trifles.

What difference does it make if the government has information that your phone company, your bank and every private, uh, vendor that you deal with, uh, not only has but is warehousing and data mining, targeting you. Uh, but unlike the government, not targeting you so that they can protect you. The government’s ability to access such information may make the difference between life and death. And in the national security context, that access is now subject to various judicial hurdles and Congressional oversight, which our law has never imposed on prosecutors and agents who investigate such insignificant, relatively speaking, crimes as gambling. Common sense tells us that under the current threat this is the kind of investigating that government not only should be able to do but must be able to do.

If you don’t think so, ask yourself about the security you willingly subjected yourself to without any court search warrant the last time you got on a plane or entered a public building or tried to carry a bag into Yankee Stadium or even if you’ve had the experience of entering the offices of the American Civil Liberties Union. We had a trial here in New York about a year ago and it came out during the trial that visitors to the ACLU’s New York office, uh, are confronted when they come in with big signs on the wall that say, “Your bags are subject to search.” Why do they do that? It’s a reasonable balancing of our minor, of minor intrusions to protect ourselves and the people we care about. That’s what the Fourth Amendment has always been about – reasonableness. If there’s a valid basis to believe people could be drinking and driving the police can set up sobriety checks and stop motorists randomly. When the police arrest somebody, they’ve always had the ability, uh, to search them to make sure that they’re not armed.

If you work in a regulated industry the government can compel you to provide information and even do spot checks. None of this requires a judicial warrant, none of it requires probable cause and there are thousands of searches like this, countless searches, taking place in this country every day, uh, and this has been the case for years and years without any discernable, uh, suggestion that the Constitution has been shredded or that our core freedoms have been jeopardized. The thing all the exceptions I’m talking about have in common, besides being reasonable restraints on our freedom, is that none of them is nearly as important as protecting our national security – the safety of us all collectively. We’ve done a lot of talking about civil liberties these last six years.

But the conversations I remember the best, uh, are the ones that I had with, uh, victims of terrorist attacks, like the World Trade Center attack or, uh, the two hundred, uh, mostly Muslim Kenyans and, and the people in the surrounding area, uh, who were, uh, victimized by the bombing of the U.S. embassy in 1998 in Nairobi. The threat we’re facing is not hype. It’s, it’s flesh and blood real. And the fundamental rights of these victims – the vi…the right to life, the right to liberty, the right to pursue happiness – have been stolen from them by our enemies in a way that can never be compensated. Those are our most essential civil liberties and the only way we can protect them is by enduring comparative trifles in order to let the government do the thing that we needed to do, the only thing we really needed to do – uh, which is protect us and save lives. And that’s why you should vote for the motion.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: But the conversations I remember the best, uh, are the ones that I had with, uh, victims of terrorist attacks, like the World Trade Center attack or, uh, the two hundred, uh, mostly Muslim Kenyans and, and the people in the surrounding area, uh, who were, uh, victimized by the bombing of the U.S. embassy in 1998 in Nairobi. The threat we’re facing is not hype. It’s, it’s flesh and blood real. And the fundamental rights of these victims – the vi…the right to life, the right to liberty, the right to pursue happiness – have been stolen from them by our enemies in a way that can never be compensated. Those are our most essential civil liberties and the only way we can protect them is by enduring comparative trifles in order to let the government do the thing that we needed to do, the only thing we really needed to do – uh, which is protect us and save lives. And that’s why you should vote for the motion.

### Moderator
Claim: Andrew McCarthy, thank you very much. Against the motion, Jeffrey Rosen – to the podium, please. Don’t worry, I’ve got a clock here.

### Scientific Advocate (SA)
Claim: No, no, I’m, I, I want my own. That ominous one is an Orwellian, uh, and appropriate note for the evening. Congressman Barr has argued eloquently that more domestic surveillance of American citizens would not have prevented 9/11. I’d like to offer two additional reasons to try to persuade you to argue against the motion, “Better more domestic surveillance than another 9/11.” Uh, the first has to do with effectiveness. It’s possible to protect privacy and security at the same time. Possible, in other words, to reduce the risk of terrorism without dramatically increasing the surveillance of American citizens. And the second has to do with abuse. Uh, Mr. McCarthy talked about the comparative trifles, the minor incursions on privacy that were necessary since 9/11 to protect us.

But in fact, history shows that every time the government has asked for and been granted broader powers of surveillance it has not directed those expanded powers against suspected terrorists but instead has used them to conduct dragnets – ineffective dragnets – that have menaced the privacy of innocent citizens without making us safer. What do I mean when I say that it’s possible to protect privacy and security at the same time? I have in mind the evolution of a surveillance technology that, uh, some of you may have read about – and we can call this the naked machine, because this is more or less what it is. This is the high tech, three dimensional millimeter imaging machine that was initially used at a Florida airport a couple of years ago to, uh, detect contraband. It can identify not only metal, uh, but anything that’s buried under clothing, ceramics or plastic.

This is a very effective, uh, X-ray machine. The only downside is that it shows us completely stark naked. Now, the people who designed this machine came up with a simple programming shift. They found that it’s able to maintain the pictures of the ceramics or the plastics and the contraband, but to take the pictures of the naked body and scramble it, uh, scramble the anatomically sensitive regions into a nondescript blob. Now, obviously, this wonderful alternative – the blob machine as opposed to the naked machine – is, for many of us, an act of mercy, uh – especi…especially for those of you this evening who are intellidating. You can in…invite each afterward to co…come by and check out the blob machine – much safer than, uh, the naked machine. Uh, and it’s also a silver bullet technology. It provides just as much security without any threat to privacy.

It shows, in fact, that it’s possible to, uh, protect our security without any, as it were, domestic surveillance. Now, I’m convinced that all of the laws and technologies that have been proposed since 9/11 can be designed in ways that look more like the blob machine than the naked machine. And it’s, uh, surely willfulness that has led the other side to resist these well- designed laws and technologies, uh, for badly designed ones that menace privacy without making us safer. Let me try to, uh, persuade you by giving an example of the evolution of one of the most controversial and important surveillance programs since 9/11. This is the program that was originally known as total information awareness. In its original incarnation the government proposed to unite a lot of information that’s held by public and private data bases – uh, magazine subscriptions, consumer records, internet browsing – to unite that with public arrest records and then to conduct vast data mining that would try to predict whose travel patterns resemble those of the nineteen, uh, 9/11 terrorists and to stop those people at airports.

Now, what was wrong with this system? It wouldn’t have worked and it posed grave threats to privacy. But aside from that, Mrs. Lincoln, it was an excellent system. Why would it have been ineffective? Well, if you imagine that the next attack looks nothing like the last one. It, it takes place, God forbid, on a train rather a plane – then modeling the travel patterns of the 9/11 people will lead to the arrest of a lot of retired businessmen in Florida who take flying lessons but will miss all the real terrorists. And given the huge numbers of false positives, the nation’s airports would be brought to a halt. The second problem is privacy.

The comparative trifles that Mr. McCarthy so sneeringly dismissed would have allowed the government to store in a centralized data base all sorts of, uh, records that it could then use to menace its enemies, just as the Nixon Administration did when it went after the tax returns of Vietnam protesters and threatened them with prosecution. Now, the evolution of total information awareness is a positive story and one that, uh, very much supports our side because, uh, because of the opposition of a bipartisan coalition of libertarian conservatives like Congressman Barr and civil libertarian liberals like Professor Strossen. The system was refined. First, the government was prohibited from sharing information with law enforcement agents unless there was evidence of a serious crime or a violent terrorist act, avoiding that kind of discriminatory menacing of political enemies. And second, the government abandoned the foolish idea of trying to predict future attacks based on the patterns of past ones and instead merely confirmed that people are who they say they are at the airports – a more modest goal, the one that makes us safer.

What initially began as a naked machine technology evolved into a blob machine one and across the range of laws and technologies we can tell a similar story. So the tradeoff that the other side falsely presents you with need not exist. Now, what about the abuse? Uh, it’s clear that every time the government has been granted new authorities it’s abused them – not to, uh, focus on suspected terrorists but instead to menace innocent citizens. And this is not a surprise because the essence of the Patriot Act, which was not a minor change in American surveillance laws, uh, but a significant one in several respects. The government used to only be able to engage in warrantless searches in secret without notifying the people whose data was being searched if they could prove in advance that the target was a suspected spy or foreign terrorist.

But because of the changes in the Patriot Act the government is now able to engage in secret warrantless surveillance of anyone’s data merely by asserting that the data is relevant to a terrorism investigation. Should we be surprised when the FBI, uh, using this new authority issued not a couple of carefully chosen national security letters but, according to the Inspector General’s recent report, a hundred and forty thousand national security letters in the past three years? And according to his report’s most of those letters were not for suspected terrorists but for people who had nothing to do with terrorism. And should we be surprised that that data was not a trifling threat to privacy but was stored in a centralized data base and kept for twenty years?

Should we be surprised that people who visited Las Vegas during a false terrorist threat had their hotel records and gambling records stored in that centralized data without their knowledge because of this foolish and misguided program? Or that the FBI, which couldn’t even get David Frum’s address right, was so inept that it didn’t keep records of the national security letters that it issued and therefore didn’t know when it was getting the right or wrong data? How could you possibly trust the government with expanded authority when it used the authority that was given so recklessly? The government’s approach to this, uh, pro…problem is much like that scene out of Midsummer Night’s Sex Comedy, where Woody Allen suddenly comes up to Mia Farrow’s window on a flying bicycle and says, Hop on. And she’s sort of skeptical and she says, Um. And he says, Trust me. It’s me, Andrew. Hop on. She’s still skeptical. He says, Trust me anyway. This –

…is the government’s approach to this problem – Trust me anyway. And we’ve seen too much of their abuse of this power since 9/11 to continue and engage in this trust. So we are saying not that it’s not important to take the terrorist threat seriously but we need meaningful oversight focused on genuine terrorists, which, while protecting the privacy of innocent citizens. We can do that through law, we can do that know…uh, through technology. We have in our hands the ability to protect privacy and security at the same time. What we need now is the will. Thank you very much.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …is the government’s approach to this problem – Trust me anyway. And we’ve seen too much of their abuse of this power since 9/11 to continue and engage in this trust. So we are saying not that it’s not important to take the terrorist threat seriously but we need meaningful oversight focused on genuine terrorists, which, while protecting the privacy of innocent citizens. We can do that through law, we can do that know…uh, through technology. We have in our hands the ability to protect privacy and security at the same time. What we need now is the will. Thank you very much.

### Moderator
Claim: Jeffrey Rosen, thank you very much. And arguing for the motion, John Yoo.

### Conspiracy Advocate (CA)
Claim: I’d like to thank the, uh, Rosenkranz Foundation and Intelligence Squared for giving me the opportunity to escape the People’s Republic of Berkeley and to visit a more conservative city, like New York. I, uh, understand that many of you, according to The Washington Post, are here on dates. I think this is a wonderful idea. Uh, uh, I, uh, it’s really remarkable to me cause the last date I had was in the first Reagan Administration. I do have to say, though, I find it surprising that many people would think that the voice and appearance of Bob Barr would be an aphrodisiac. First, let me, uh, directly engage with Jeff’s point. If there are things that the government can do to increase security without reducing privacy we should have already done them. I think at some point, though-- and I think we’re at that point now – you reach a trade-off. It’s not unusual to security policy. Every government decision involves a tradeoff.

When we decide to reduce greenhouse gases by having higher mile per gallons, uh, requirements for cars, we know a certain higher number of people will die on the highways because the cars will be lighter. Government decisions always involve tradeoffs and it’s possible to have tradeoffs that go the wrong way. We have had periods where civil liberties were greater than they are today and we have suffered as a result. So, for example, the wall that many of you may have heard about, which prohibited the FBI and the CIA from pooling their information about terrorist networks is the one thing that the 9/11 Commission found that directly led to the 9/11 attacks. Because we knew the names of two of the 9/11 hijackers inside the country, the agents who worked for the intelligence bureaus were unable to communicate that information to FBI agents inside the country who could tried to locate them because of rules that were set up to protect civil liberties.

Similarly, when we have tried to put Al Qaeda members on trial before 9/11-- and Mr. McCarthy was one of the prosecutors who did that – again, for civil liberties reasons, we turned over massive amounts of information to the defense teams. One of those was a list of all the co-conspirators of one of the Al Qaeda suspects. If you think about it that was a list of every single person at the time we thought was a member of Al Qaeda. That list was found in Africa after the bombings in Yemen, when our agents went out to try to find out who was responsible. I’m not saying that we should go all the way over to security or all the way for civil liberties but there is a balance. And there is a tradeoff. And having more civil liberties can have a cost of security, just as increasing security can have a reduction in civil liberties. Also let me admit that in past wars the government has reduced civil liberties. But I would say, if you place it in historical perspective those reductions of civil liberties are far greater than anything we’re experiencing today.

In 1798, the first war we fought as a country, it was made a crime to criticize the government during the war. In the Civil War, President Lincoln, on his own authority, detained thousands of American citizens in military detention without any recourse to civilian court and had many of them tried by military judges. In World War I it was made a crime and people were prosecuted for criticizing the war effort, for arguing that people should not obey the draft. In World War II President Roosevelt detained over a hundred and twenty thousand loyal American citizens. He initiated military courts, some of who, which were used to try American citizens. He ordered the warrantless wiretapping – not just of communications going in and out of the country, but every communication inside the United States – against a clear statute and Supreme Court precedent at the time, over a year and a half before Pearl Harbor.

I think, if you compare those measures that have been taken in wartime in American history in the past, the reductions of civil liberties we have today are nowhere near as large of a magnitude. Take, for example, the political system. We have had two Presidential election – well, one Presidential election during, uh, this post-9/11 period. We have had several Congressional elections. Political control of Congress just switched in the last election. We have had outpourings of new political speech through new methods and means. For example, uh, people I wish never existed – bloggers. This did not exist before 9/11. Are we really in such a serious civil liberties crisis if bloggers are able to use this new medium to say, uh, I think, quite incredible things?

Take the detention policy that I’m sure, uh, the other side is going to talk about. These are always slippery slope arguments. How many American citizens have actually been detained since 9/11 in military detention? It’s not the thousands or hundreds of thousands from previous wars. By my count, it’s two. How many citizens of other countries in the United States – permanent resident aliens – have been detained as part of the post-9/11 program? Again, it’s not thousands and not hundred thousands. I think, again, that number is two. Take the NSA Surveillance Program that we’ve all heard about. Again, this is a program that every President in war has used-- sometimes without judicial supervision, often without Congressional authorization, often without the knowledge of anybody – in order to gain information on pending attacks. So when you try to take into account these factors – the gains of security, which I think we’ve had and a loss of civil liberties – how should you think about this problem?

Let me make – just close by making just a few points. First, have the expanses… expansions in government power been worth it? I would say, Yes, look at the results. There have been no attacks since 9/11. And it’s not because of luck. I think as even the 9/11 Commission Report, the Silverman-Robb Report have, uh, said, as the administration and members of Congress have said – these expanded surveillance powers have resulted in the capture or prevent, capture of Al Qaeda members inside the United States and the prevention of plots. Since 9/11 the United States has succeeded in capturing or killing two-thirds of Al Qaeda’s leadership at the time of 9/11. Again, that’s not just through luck. Second point: Are civil liberties being permanently reduced? I think many thoughtful people would say, Yes, there’s a tradeoff, but I would be worried if we reduce civil liberties in wartime in a way that once the war is over civil liberties are permanently reduced.

There is no way for me to tell you what’s going to happen once this war is over. But if you look at past American history wartime has not produced a significant permanent reduction in civil liberties. Actually, if you look at the historical record, after war we usually as a society experience our greatest growth in civil liberties. The Civil War saw the passage of the Reconstruction Amendments and –

…the Emancipation Proclamation. World War II was followed by the Warren Court. The last point: complacency, I think, is the real enemy. Even having this debate is a show, a sign of the confidence we have that our system is working. But we should be aware that we’re fighting a different kind of enemy, a non- nation state that conceals its activities as normal civilian communications, as normal civilian travel. The hard thing is how, as a society do we fight that, fight a war against an enemy who is not following the rules of war and tries to disguise itself as one of us. I’ll close by saying I think so far we have made a successful balance between civil liberties and security. We have reduced attacks and threats on the country. I think those gains have been worth it. And the question is, I think, for all of us today, is whether we would feel comfortable reducing the amount of government powers and by doing so, give up some of the security we’ve bought at such a, I think, dear price since 9/11. Thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …the Emancipation Proclamation. World War II was followed by the Warren Court. The last point: complacency, I think, is the real enemy. Even having this debate is a show, a sign of the confidence we have that our system is working. But we should be aware that we’re fighting a different kind of enemy, a non- nation state that conceals its activities as normal civilian communications, as normal civilian travel. The hard thing is how, as a society do we fight that, fight a war against an enemy who is not following the rules of war and tries to disguise itself as one of us. I’ll close by saying I think so far we have made a successful balance between civil liberties and security. We have reduced attacks and threats on the country. I think those gains have been worth it. And the question is, I think, for all of us today, is whether we would feel comfortable reducing the amount of government powers and by doing so, give up some of the security we’ve bought at such a, I think, dear price since 9/11. Thank you.

### Moderator
Claim: John Yoo, thank you very much. And against the moment, Nadine Strossen.

### Scientific Advocate (SA)
Claim: Thank you very much. Andy, uh, I hate to burst your bubble but the reason why the ACLU is required to submit those who seek admittance to, uh, some kind of I.D. procedure is because we are only tenants in the building and our strenuous objections were not well received by the landlord. And I have to tell you, just to illustrate how, uh, counter-productive or at least unproductive these kinds of pseudo-security measures are, um, ACLU lawyers were so distressed that we were subjected – you don’t have Constitutional rights against a private landlord. They were so, uh, distressed that they were subjected to those measures that they would sign in, uh, under names such as Osama bin Laden and Mohammed Atta and had absolutely no problem. Uh, stupid security. Uh, Bruce Schneier, one of the leading security experts in the country, uh, says that what we have seen post-9/11 is security theatre, not real security.

Uh, I also feel that since we’ve had two FBI, uh, stories from, uh, David and from Andy that I will tell my own FBI story – uh, namely, the former FBI Special Agent who is now working for the ACLU as a policy counsel, who, uh, did our, uh, extremely detailed analysis of the recent report by the Office of Inspector General about the massive abuses and fabrications and misuses of the national security letter, uh, and the lies that have been told about this to the public and to Congress. And, uh, this gets to the fundamental point of trust that has been raised on both sides here. Not, I don’t mean to condemn the FBI as an institution or condemn particular individuals. I’m talking about human nature and political nature and official nature – the reasons why our founders had the genius of creating a system of checks and balances. And we are not saying that there should not be any monitoring or any surveillance at all. We are simply saying it should be done pursuant to the checks and balances that exist in the Constitution but have been, uh, completely ignored in so many post-9/11 measures.

I, I welcome the pi…spirit of co…collegiality in this program. And so in that spirit I’m going to begin my argument against – or I should say, continue my argument-- against the domestic spying and, uh, Big Brother type approach that the other side has been advocating by quoting someone whose policies they are defending – none other than President George W. Bush himself. In the President’s very first public statement on that infamous date of September 11th, he hailed our nation as the brightest beacon of freedom in the world. And he vowed that no one will keep that light from shining. Well, ever since then the ACLU has been working very hard to help the President keep that vow. It would be tragic if we let the terrorists terrorize us into abandoning the very ideals that they attacked.

And that is the key reason why you must vote no on tonight’s resolution, why more domestic surveillance is not better than another 9/11. Indeed, with more surveillance of the type that has been proliferating since 9/11 – namely, surveillance that is unjustified, unwarranted, unchecked – not to mention un- Constitutional – with more of this kind of surveillance the terrorists don’t need another 9/11 to accomplish their goals. Of course, on that dreadful date thousands of people were horribly killed but their tragic deaths were not the terrorists’ goal. Rather, they were a means to another broader goal – to terrify all of us and to sabotage our country’s democratic ideals of liberty and justice for all. Sadly, the terrorists have made great strides toward that goal through the original 9/11 attacks – actually, more accurately, through our own government’s reaction to those attacks. That key point was well captured by some satiric but apt definitions from The Nation magazine’s online dictionary of current political terminology.

Here are its two definitions of Patriot Act – sad but true. The first one is: the pre-emptive strike on American freedoms to prevent the terrorists from destroying them first. The second is: the elimination of one of the reasons why they hate us. In my limited time I can’t respond to all of the, uh, misguided, misleading statements you have heard tonight from my – with all due respect – to my opponents. Um, but I’m going to start by briefly listing some of the major reasons for rejecting these kinds of measures. Uh, first, I want to reiterate that we are not opposing, uh, surveillance per se but only surveillance that is not carried out in accordance with the Constitution’s precepts.

Many leading law enforcement and national security experts confirm that such Constitutionally appropriate surveillance is at least as effective as the illicit post-9/11 measures. And let me quote one of them, who has been very outspoken – Judge William Webster, who was Director of both the FBI and the CIA under Presidents Reagan and Bush I – criticizing the sweeping post- 9/11 measures. He said, From 1981 to 2000 the FBI prevented more than one hundred thirty terrorist attacks. We used good investigative tech…techniques and lawful techniques. We did it without all the suggestions that we’re going to jump all over people’s private lives. We don’t need to go in that direction. Uh, second, the Constitutional standards-- in particular the Fourth Amendment’s core requirement of individualized suspicion – uh, that is designed to preserve both safety and individual liberty. In contrast, too many post-9/11 surveillance programs are just overly broad, dragnets, fishing expeditions. And that means by definition, they are doubly flawed. On the one hand, they’re sweeping in too much information about too many completely innocent individuals, and on the other hand, they are failing to hone in on the dangerous ones. As many critics have put it, the government is trying to find a needle in the haystack, by adding more hay to the stack.

Uh, my next point is that by state-voting civil liberties, we are ignoring the more effective measures that would in fact, according to national security experts and counter-terrorism experts, be more effective as well as consistent with civil liberties. Uh, since our opponents have referred to the 9/11 Commission report, I have to say that I, uh, read that report completely differently, out of 41 specific recommendations of steps we should take to prevent another 9/11, almost none of them have anything to do with increasing the government’s surveillance power. And unfortunately, according to, uh, the report, with letter grades that was issued a couple of years after the initial recommendations, the government got D’s and F’s on most of the very significant, concrete recommendations, so we have not exhausted those, uh, alternatives that would help to make us both safe and free. Unfortunately, the government now has gone in the opposite direction, uh, and if we increase this kind of surveillance, uh, we are going to have the worst of both worlds.

Because we will all be less free, but not more safe—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: Uh, my next point is that by state-voting civil liberties, we are ignoring the more effective measures that would in fact, according to national security experts and counter-terrorism experts, be more effective as well as consistent with civil liberties. Uh, since our opponents have referred to the 9/11 Commission report, I have to say that I, uh, read that report completely differently, out of 41 specific recommendations of steps we should take to prevent another 9/11, almost none of them have anything to do with increasing the government’s surveillance power. And unfortunately, according to, uh, the report, with letter grades that was issued a couple of years after the initial recommendations, the government got D’s and F’s on most of the very significant, concrete recommendations, so we have not exhausted those, uh, alternatives that would help to make us both safe and free. Unfortunately, the government now has gone in the opposite direction, uh, and if we increase this kind of surveillance, uh, we are going to have the worst of both worlds.

### Moderator
Claim: Nadine Strossen—

### Scientific Advocate (SA)
Claim: Because we will all be less free, but not more safe—

## Round 2

### Moderator
Claim: Thank you very much. And thank you to all our panelists for their opening arguments today. I’m now ready to announce the results of the pre-debate vote to see where this audience stands coming into tonight’s debate. Before the debate, 41 percent of you voted for the motion…37 percent voted against the motion, and 22 percent were undecided, rounding up all those numbers. So we’re ready to begin the Q-and-A portion of the program. The idea is to, uh, mix up some of your questions, some of my questions, and someone on each side of the auditorium will come to you with a microphone so please stand if you want to ask a question. We ask again that you please make your questions brief and refrain from, um, giving, uh, speeches. Members of the press, if you’re here tonight, please identify yourselves and your news organization, and members of the audience, you can opt out of, uh, that requirement. Mr. McCarthy, I’d like you to, um, engage on a point, maybe with, with Bob Barr. You said that in an era of terror, that surveillance is the best defense that the country has. If in fact the war on terror is a war that is not finite, but a war that may last for decades, if not centuries, should the government’s power…in such surveillance be open-ended, and I’d like a quick response and if, Bob, you wanna pick up on that very point.

### Conspiracy Advocate (CA)
Claim: Well, of course it should because…the purpose of the power is to prevent attacks, and as long as the threat of attack exists, it would make no sense to get rid of the power.

### Moderator
Claim: So this is not a wartime power, you’re talking about permanent surveillance—

### Conspiracy Advocate (CA)
Claim: It’s a threat-time power, it’s an asymmetric war, uh, fought by a terrorist threat, and these measures are designed, uh, as much to thwart the threat as they are to prevail in the ultimate war.

### Moderator
Claim: Bob?

### Scientific Advocate (SA)
Claim: The current administration defines this war as unending, that is, perpetual. It defines it as entirely global, that is, the streets of Baghdad are as much a field for the commander-in-chief to operate in as the streets of Atlanta, Georgia, nor your—or New York City. And this administration believes that a President can don that mythical commander-in-chief hat whenever he or she feels like it, and therefore, trumps any other power in the Constitution or law. That is the great danger here. The greatest tool…to— with which the government ought to be equipped to avoid another 9/11 is not domestic surveillance, which is the topic at hand this evening, but better, more consistent gathering of foreign intelligence, and tearing down the walls between one agency and another that pre—have prevented and continue to stand in the way of effective use of that intelligence, that foreign intelligence.

### Moderator
Claim: John.

### Conspiracy Advocate (CA)
Claim: Chris, can— I just wanna take issue with the underlying premise of your question and, and Bob’s response which is there’s no reason to think the war on terrorism is going to be endless. Uh, there have been many wars between nation-states and terrorists before, and they have ended. Uh, there’ve been wars in, uh, the United Kingdom, Italy, Germany, with terrorists, and they have all come to an end. I think the problem is that we call it the war on terrorism so we think we’re at war with everyone who uses terrorism as a tactic, which is not the case, we are at war with the Al Qaeda terrorist organization, and organizations that help it. And when we defeat that organization the war will come to an end.

### Conspiracy Advocate (CA)
Claim: May I have one—one sentence? I mean I want—because I think what Bob—Bob Barr said is very important, notice he said he’s for enhanced foreign surveillance. But the moment this—that terrorist actually enters the United States, that’s when the surveillance must stop. Because, I guess then you stop being dangerous.

### Scientific Advocate (SA)
Claim: He’s not saying that it has to stop—

### Scientific Advocate (SA)
Claim: No, no, no, nobo—nobody’s—

### Conspiracy Advocate (CA)
Claim: That—

### Scientific Advocate (SA)
Claim: —saying that, David—

### Conspiracy Advocate (CA)
Claim: You want more, more—

### Scientific Advocate (SA)
Claim: Nobody’s saying that—

### Conspiracy Advocate (CA)
Claim: —more surveillance up to the point—

### Scientific Advocate (SA)
Claim: I didn’t say foreign surveillance—

### Conspiracy Advocate (CA)
Claim: No more

### Scientific Advocate (SA)
Claim: —I said foreign intelligence.

### Conspiracy Advocate (CA)
Claim: Well, we’re—

### Scientific Advocate (SA)
Claim: None of us is saying—

### Scientific Advocate (SA)
Claim: That’s the key—

### Scientific Advocate (SA)
Claim: —no surveillance, we’re just saying subject to what kinds of oversight and what kinds of protections to make sure, that not only is it consistent with individual liberty but also—

### Conspiracy Advocate (CA)
Claim: The opposite of—

### Scientific Advocate (SA)
Claim: —that it’s promoting of national security—

### Conspiracy Advocate (CA)
Claim: The opposite of more is less.

### Scientific Advocate (SA)
Claim: But the exact—

### Scientific Advocate (SA)
Claim: No, that’s not true.

### Scientific Advocate (SA)
Claim: The balance that we’re—

### Scientific Advocate (SA)
Claim: It’s more targeted which means it will be more effective—

### Moderator
Claim: Okay. May—now—

### Scientific Advocate (SA)
Claim: The, the balance that—excuse me, the balance that we’re arguing for is precisely the one that prevailed before the Patriot Act, and we’re not taking issue with all of the Patriot Act, but with those provisions, mostly those dealing with national security letters and warrantless searches, that allow surveillance in secret, merely by asserting that it’s relevant to terrorism. The small reform that we’re arguing for is to restore the pre-Patriot Act requirement that the suspect has to be a suspected spy or terrorist or his associate. And the administration, in rejecting that simple reform, uh, has opposed sunset provisions, and made clear that it wishes these changes to be perpetual, so John’s notion that these will evaporate is inconsistent with the administration’s—

### Conspiracy Advocate (CA)
Claim: But my, my ears—

### Scientific Advocate (SA)
Claim: —determination to change domestic surveillance law forever—

### Conspiracy Advocate (CA)
Claim: My ears are ringing at this phrase “targeted.” Because, I will agree with you that many of the things the US government does including those bag searches, are stupid, and pointless. Um, but the rea— precisely the reason, that ev—that everybody’s toiletries and magazine reading is on display when you enter an airplane, is, in order to avoid targeting. Uh, that what—what—what the federal government has done since 9/11 is have a very conscious decision, they’re going to play—to use a sports analogy, they’re going to play the me—they’re going to play the players, they’re not going to pay—play the ball, and so we have—

### Scientific Advocate (SA)
Claim: David, we’re not—

### Conspiracy Advocate (CA)
Claim: —this vast, untargeted—

### Scientific Advocate (SA)
Claim: No—

### Conspiracy Advocate (CA)
Claim: —project, precisely because organizations like the ACLU have opposed things like—

### Scientific Advocate (SA)
Claim: I’m sorry—

### Conspiracy Advocate (CA)
Claim: —the Trusted Traveler program—

### Scientific Advocate (SA)
Claim: —you completely misunderstand our position, it depends what the basis is for targeting. Individualized suspicion, based on what you do, not racial profiling based on who you are.

### Conspiracy Advocate (CA)
Claim: But the ACLU—

### Scientific Advocate (SA)
Claim: And I have to say—

### Conspiracy Advocate (CA)
Claim: —is opposed to the Trusted Traveler program, right—

### Scientific Advocate (SA)
Claim: —law enforcement officials have agreed, that demographic profiling is as ineffective as it is violative of individual rights, because—

### Conspiracy Advocate (CA)
Claim: There’s as many law enforcement—

### Scientific Advocate (SA)
Claim: —the terrorists can get around the profile very easily—

### Conspiracy Advocate (CA)
Claim: There’s—there’s as many law enforcement officers who disagree with that as dis—as disagree with it.

### Scientific Advocate (SA)
Claim: Well, uh—

### Conspiracy Advocate (CA)
Claim: And your flat statement that the Fourth Amendment requires individualized suspicion is just wrong.

### Moderator
Claim: Okay, before we get too deep into the woods… of the, the Constitution, um, I know we have some folks who, uh, have some questions, so, uh, if you’re ready, there’s somebody with a microphone standing by, so, uh, who do we have. A young woman in…in the back right there. Oh, I’m sorry, no, go ahead, if you—

### Moderator
Claim: No, no, I’m sorry—

### Moderator
Claim: Whoever gets the microphone first, please, you’re on.

### Moderator
Claim: How do we know—how do we have proof that someone’s a terrorist until they commit a terrorist act?

### Moderator
Claim: Would you like to direct that to—

### Moderator
Claim: Jeffrey Rosen—

### Moderator
Claim: —one side or one panelist—

### Scientific Advocate (SA)
Claim: Uh, foreign intelligence law since it—the, uh, law was passed in the 1970s presumes that, uh, there’s a level of suspicion that stops short of probable cause that someone’s committed a crime, but makes pretty clear that we think of this as a really bad person. And, uh, this was a balance that no one suggested, uh, caused 9/11, and what’s so interesting about the other side is their, uh, failure to say that that standard is too high. There’s no evidence that anyone wasn’t the object of a FISA warrant because there wasn’t a high enough degree of suspicion. They’re—they wanna completely throw out individualized suspicion, and have hundreds and thousands of warrants for, uh, people who just happened to show up at the airport. So this is not a subtle, uh, uh, uh, distinction, and we’re convinced that by resurrecting that simple requirement— You could even broaden it a little bit, if you wanna talk about the technical details, there’ve been thoughtful civil libertarians who have said, you could have probable cause that someone’s a suspected spy or terrorist, or his or her associates. At least some connection to an identifiable, dangerous bad guy.

### Scientific Advocate (SA)
Claim: And—

### Scientific Advocate (SA)
Claim: It’s the dragnet searches that are, uh, threatening and, and the other side has provided no justification—

### Scientific Advocate (SA)
Claim: And the

### Moderator
Claim: Let’s let the other side, John had a point here.

### Conspiracy Advocate (CA)
Claim: First of all, I think it’s a great question because, under the current law within the United States, as Jeff said, you need to have probable cause that someone’s a terrorist before you can slap a wiretap on ‘em, and it shows a fundamental confusion between how we think of terrorism. I think the other side thinks of it as a crime, and as best handled through the standard criminal justice system which is this probable cause approach. Makes a lotta sense when as a society, we are willing to accept the harms of terrorism and retrospectively, after it occurs, then try to use a law enforcement system. What 9/11 showed us is that, our government is trying to act prospectively to stop terrorist attacks before they occur. And in order to do that we cannot rely on a system which says, prove to me that this person is already a terrorist because of criminal actions they have already engaged in, because at that point, usually, as we saw in 9/11, they are already dead, and there’s no one to hold responsible in the criminal justice system—

### Scientific Advocate (SA)
Claim: And as—as John himself knows, that is absolutely not the standard, it is much watered down, as Andy said, the court has not applied the strict Fourth Amendment probable cause requirement in this context but required just some basis for suspicion. And let me tell you, the opposite danger, not only to individual rights but to national security, the FBI has been complaining bitterly about this sweeping National Security Agency, uh, intercepts because it has led to countless hours of wasted time, tracking down, quote, leads, that lead nowhere, to dead ends, so again, the notion of honing in on somebody, as to whom we have some basis for having suspicion, is more effective from the security point of view, as well as from an individual rights point of view.

### Conspiracy Advocate (CA)
Claim: Nadine is again demonstrating the difference between a law enforcement mind-set and a criminal justice mind-set. Uh, if you wait until you have probable cause that someone is an agent of a foreign power, you have waited too long. Uh, and that may be what the, the standard is in the criminal justice system, that may be what’s appropriate in the criminal justice system, but the Fourth Amendment has never required that, what the Fourth Amendment requires, is that searches be reasonable. And if our goal is going to be to stop terrorist acts, rather than to bring people to justice, that has to be the standard that we deal with, and we have to do with an intelligence mind-set, which is far different from the criminal mind-set, when the FBI investigates a crime, they expect to bat about .900. They expect that most of the time when they conduct an investigation they’re gonna get their man, uh, and they’re gonna successfully prosecute him. Intelligence doesn’t work that way. If you hit one for 15, you’re probably doing well. But it’s chasing the needle in the haystack that intelligence is about, and if you’re gonna apply criminal justice standards to that task, you’re finished because—

### Scientific Advocate (SA)
Claim: How about three—

### Conspiracy Advocate (CA)
Claim: —you can’t prevent anything—

### Scientific Advocate (SA)
Claim: —how about three out of 153,000—

### Moderator
Claim: Let’s move off this point—

### Scientific Advocate (SA)
Claim: —to use the NSL numbers—

### Moderator
Claim: —just for a few seconds, we have another question, yes sir, from the audience right there on the, on the end, yes. There you go.

### Moderator
Claim: Yes, sir—

This is a question for the, uh, people against the motion, would you—I—any of you feel the slightest bit differently about this proposition if you either trusted the administration or felt that they were competent in the performance of their duties?

### Scientific Advocate (SA)
Claim: We took exactly the same position as did Bob Barr with respect to the, uh, last so-called anti-terrorism act under the Clinton administration. Um, and I do have to say that the opponents here are, uh, completely ideologically neutral and very diverse. Um, libertarians, civil libertarians join forces with a lot of, uh, conservative organizations that really are committed to reducing government power over our private lives. And, it’s because the impulse of government is necessarily to increase its power, regardless of, uh, what their politics are. We had a long litany from John Yoo about, um, past administrations including some human rights heroes in other contexts, Franklin Delano Roosevelt, Abraham Lincoln— In a wartime situation, they all react the same way which is to expand their power to the con— constitutional limit, and beyond, and in 20/20 hindsight, we look back and we see that none of those measures did anything, to add actual protection to our national security.

### Moderator
Claim: Nadine, what about the common-sense argument, advocated by the other side that, Americans are more than willing to give up some liberties whether they’re going to a Yankee game or whether they’re going through the airport security, do you see a fundamental difference between that and surveillance on the part of the, of the government.

### Scientific Advocate (SA)
Claim: I think the common-sense argument, speaking for myself and also it’s actually reflected in constitutional doctrine is that, no freedom is absolute except probably the freedom to think and to believe which stays entirely within your heart, head and soul, but, in acting in the real world, no right is absolute. It’s just that government has a heavy burden of justification. It has to show that the restriction is gonna be effective in actually making you safer, and that nothing that is less violative of your rights would be as effective. And, think about it. Of course, most of us would be willing to give up some liberty if that was the price to pay to bring about security. But how many of us would be willing to give up liberty, without gaining security in return? Is that common sense? Or to give up more liberty than we have to, in order to get the same amount of security.

### Conspiracy Advocate (CA)
Claim: Well, how about this proposal. What if we were to say, why don’t we let, not only people choose, but let each person make their own individual choice about how much they personally were prepared to do. For example, if you wanna fly, um, you can have a shorter line if you’re prepared to let the airline know more about you, and a longer line if you’re prepared to know— We could each make our choice. And civil liberties un—groups, have consistently fought and fought and fought, when airlines—American Airlines has been promising this now for three years. And we could each—we could let the market decide, and you could be in the long line, and I’m happy to let them know how long I’m—I’ve been in my present abode and how many kids I have and I’ll go in the short line.

### Scientific Advocate (SA)
Claim: And I have no illusion, as somebody who flies a couple hundred thousand miles a year and has no desire to die, uh, that way, I have no illusion that that would do anything other than save me time. I have no illusion that would make me safer. How many of the 9/11 terrorists had valid ID’s. How many of them would’ve sailed through, uh, and been treated as trusted travelers themselves—

### Conspiracy Advocate (CA)
Claim: They—they had—they had fake driver’s licenses, many of them—

### Scientific Advocate (SA)
Claim: Yeah—

### Conspiracy Advocate (CA)
Claim: —under, uh, under—

### Scientific Advocate (SA)
Claim: And those would—that would’ve been enough to get them there, every security expert says that this is false—gives us a false illusion of security, it—

### Conspiracy Advocate (CA)
Claim: You’d have to give ‘em a little bit more than a driver’s license, you’d have to give ‘em a whole battery of information, and the airlines, under the threat of litigation—

### Scientific Advocate (SA)
Claim: Ask any teenager about how easy it is to get a false ID.

### Conspiracy Advocate (CA)
Claim: Okay, so the point is, you don’t—your answer is, no, we will not let people make that individual choice, we will not allow airlines and their customers as private actors to say, let’s, let’s put this to a truly personal individual trade-off test.

### Scientific Advocate (SA)
Claim: But we’re not talking about market choices, you can’t opt out of a database with 100,000 people in it. And obviously people react, uh, intuitively to the place where the security hits them, so if they have to wait a little longer they’ll make the trade-off.

### Scientific Advocate (SA)
Claim: The so-called security.

### Scientific Advocate (SA)
Claim: But what we’re talking about here, are fundamental changes in laws and technologies that make it impossible to escape from dragnet and ubiquitous surveillance, and, and transform the very nature of society. And this is something just as in, in environmental law, where, uh, market choices are completely inadequate, and that’s why constitutional values, whether or not you think that this stuff is required by the Constitution, or implicated.

### Moderator
Claim: But Jeffrey, doesn’t that argue for what the proponents are, are saying, that the technology has changed so much, and you have government agencies who are mining hundreds of thousands of communications, uh, in, in literally nanoseconds, doesn’t that make it, um, almost impossible for probable cause, warrants, uh, and, and court orders to, uh, to get at this information.

### Scientific Advocate (SA)
Claim: It makes it easier, you don’t have to show up at a magistrate’s, uh, office and read, uh, a warrant in person, you can e-mail or BlackBerry a request, to a secret court which could grant it immediately. Or you could have programmatic warrants that would say, this broad category of person looks suspicious. There is great familiarity in foreign intelligence surveillance law in dealing with broad, uh, categories of data mining and so forth. What’s unprecedented about the Patriot Act, and what the previous question smoked out is that, much of the Patriot Act was actually proposed by the Clinton and Bush administration after Oklahoma City, and opposed by the same heroic bipartisan coalition led by my, uh, colleagues, that are less successful after the, uh, uh, 9/11. But it would be, uh, they provided no reason for why that framework wouldn’t be just as effective, you could have broad surveillance, it just wouldn’t be unlimited, and the unlimited surveillance is ineffective, and threat—it threatens privacy—

### Moderator
Claim: We’ve got about five minutes left in the Q-and-A so we have some questions, yes, sir, right here—

### Moderator
Claim: To, to—this is really addressed to the, the panel against the motion. What, what seems to be missing in your argument is a lack of, of, of addressing the nature of the threat. The threat seems to me…is that our terrorists today have technology too and they have technology that…affects the existential nature of our society. And don’t you believe, that there should be at least some moderation in your point of view and flexibility, relative to the threat that you’re confronting. So that it’s one thing to protect, uh, individual rights, when a relatively limited threat exists. But when you’re talking about an existential threat to the nation…to millions of people, don’t you have to suspend, at the very least, this firm, rigorous approach? That’s my question—

### Scientific Advocate (SA)
Claim: Uh, the, the, the threat to our, to our nation at the time the Bill of Rights was drawn up and adopted by this nation, was far greater than the threats we face today, I dare say, we faced at the time, the very protections against unlimited government intrusion that are embodied for example in the Fourth Amendment, uh, were such that the very existence of our nation was clearly threatened by the greatest military power on the face of the earth, not a handful of cells but a military power that could wipe us off the face of the earth as a sovereign nation, that is Great Britain. In the face of that overwhelming threat, our founding fathers in— understood that the answer to your question is no, government should not, even facing the most dire threat to this nation, allow…or the people should not allow government, even facing that level of threat, to invade their privacy without a sufficient reason. And indeed, there is great flexibility, that you mention, already embodied in the Foreign Intelligence Surveillance Act. Great flexibility. There is tremendous flexibility built into the Patriot Act, already. And yet the other side is arguing by the terms of the question here this evening…is that insufficient, and should government have, essentially unfettered power. And the answer to that, should be no, the same as it was no in the 18th century when these very precious mechanisms for guaranteeing our, our inherent rights were crafted.

### Moderator
Claim: John, I think I’d like you to respond to that because you were instrumental in crafting the administration’s legal opinion on that very point about whether the President could go beyond the foreign intelligence surveillance court, and without any warrants at all, eavesdrop not only on the foreign…agents, but on people inside the United States.

### Conspiracy Advocate (CA)
Claim: There—there are two things going on here. First of all, with the Patriot Act, which is not the focus of your question, focus of your question. There is a system of secret courts and secret evidence that issues secret warrants for secret wiretaps. That system was created was created in 1978. The Patriot Act amended some of those provisions, but the basic structure is one that we’ve been happy to live with, for almost 30 years. And so, this claim that the Patriot Act was this huge revolution I think is, is mistaken. The second thing I would say is, in terms of the ability of the President to go beyond the Patriot Act, that’s based on history, as I said. Every President—and as Andrew said, every President from Woodrow Wilson on, used exactly those same authorities, when confronted by a foreign attack or foreign threat, we’re not arguing here for unfettered power, we’re not arguing that these powers ought to be used in peacetime, we’re not arguing that these powers ought to be used to catch common criminals. I’m—I actually personally don’t think any evidence from those, uh, surveillance programs should be entered into court in any kind of criminal prosecution—

### Scientific Advocate (SA)
Claim: So, do you—

### Conspiracy Advocate (CA)
Claim: They are there, to try to prevent a future attack. And it seems— and this is really David’s key point. It seems weird, right? If you’re outside the United States and you’re a terrorist, the NSA has unlimited ability to track—you don’t have to go to court and get a warrant, to O—to surveil Osama bin Laden, if Osama bin Laden were to move to the United States, then, a whole system of court-ordered procedures are required under the other side’s framework. That is a perverse—

### Scientific Advocate (SA)
Claim: But that’s not—

### Conspiracy Advocate (CA)
Claim: —and exactly reverse incentive—

### Scientific Advocate (SA)
Claim: Let’s not exaggerate—

### Conspiracy Advocate (CA)
Claim: —to one we should be creating—

### Scientific Advocate (SA)
Claim: —court-ordered procedures from a court that has almost never denied anything the government has asked for in a secret proceedings which also has the power— and the government has the power to engage in surveillance before getting a court order, but John, the most striking thing in your answer, was your statement that these ex— To quote John Ashcroft, had a different view, he described the Patriot Act as giving the government sweeping, new surveillance powers, that was his exact quote. I can give you a citation—

### Conspiracy Advocate (CA)
Claim: I’m not defending Ashcroft—

### Scientific Advocate (SA)
Claim: Okay—

### Conspiracy Advocate (CA)
Claim: —uh, today—

### Scientific Advocate (SA)
Claim: Well, he had a different view of the scope of the—

### Moderator
Claim: But didn’t you work for him?

### Scientific Advocate (SA)
Claim: And, and—

### Conspiracy Advocate (CA)
Claim: I—I did, but it wasn’t pleasant—

### Scientific Advocate (SA)
Claim: And, and—

### Conspiracy Advocate (CA)
Claim: And I certainly would never have been promoted, to speechwriter.

### Scientific Advocate (SA)
Claim: Um, and, and, and you—and you know that the government has shown that it has used most of those sweeping new powers in ordinary criminal cases, uh, fraud, gambling, drug crimes. I’m not condoning any of those crimes, but, isn’t it interesting to hear you say, that you oppose the way it has mostly been used in fact?

### Conspiracy Advocate (CA)
Claim: I don’t think it’s—the NSA wiretapping program has not been used to prosecute garden-variety cri—I mean I could be—

### Scientific Advocate (SA)
Claim: We’re talking about the Patriot Act. Remember the NSA went beyond—

### Conspiracy Advocate (CA)
Claim: See, that—that’s what I’m trying to make clear that—

### Scientific Advocate (SA)
Claim: —and around and underneath the Patriot Act—

### Conspiracy Advocate (CA)
Claim: Most of you, I thought you all just said the Patriot Act was something, most of which you supported, some of which you didn’t, but I thought we were talking about the NSA wiretapping program where there is a very clear distinction about what that evidence can be sought for and it’s not to be used for criminal prosecutions and as far as I know, has yet to—it never has been used for criminal prosecutions—

### Scientific Advocate (SA)
Claim: We—we don’t know what it’s been used for because it’s been entirely secret and the government has refused to tell us what it is.

### Conspiracy Advocate (CA)
Claim: Well, wait—

### Scientific Advocate (SA)
Claim: But we do know that the evidence from the national security letters has been used in ordinary criminal prosecutions, in fact the Inspector General found that there’d been at most two terrorism-related convictions, but about 30, which was out of 140,000 letters, only 30 other criminal convictions, for crimes that had nothing to do with terrorism. I have to say, the gentleman earlier asked, would you give up nothing. I would make a deal with John, he says, uh, give us this broad, warrantless surveillance power, but we can only use it, uh, for intelligence and we can’t introduce it in criminal prosecution, I would take that deal. That’s a deal that the Germans have struck, they allow broad, uh, intelligence powers, but it can’t be used for prosecutions, and for me, that’s an example of the thoughtful balancing of privacy and security, that allows us to have both at the same time but, but every time the administration has been presented with this deal, it has been, uh, completely adamant, it’s refused to, uh, make those sensible trade-offs, and that’s why you have to vote against their position—

### Moderator
Claim: Just, just about 20 seconds left, and it, it sounds on the face of it like a reasonable deal.

### Conspiracy Advocate (CA)
Claim: It’s the law of the United States, it’s long been the law of the United States that if agents are searching for a legitimate reason, if they have lawful reason to be searching what they’re searching, uh, you can use the evidence even if it’s not what they were looking for in the first place. Now I’m not saying that it’s not a— the possibility of a reasonable compromise. But the suggestion that it’s an unreasonable position not to wanna negotiate that is, is, is—I, I just have to disagree with that.

## Round 3

### Moderator
Claim: Andrew, thank you very much, and that ends the discussion…portion of our evening. And now we’re gonna have the final remarks from our panelists, beginning with the side opposing the motion. And panelists for this, if you’d just please stay, um, seated. You’ll each have, uh, two minutes to make your closing statement, and we’ll start speaking against the motion, Bob Barr.

### Scientific Advocate (SA)
Claim: Thank you. I had the opportunity in April of 2000 to testify, before the House Intelligence Committee, on the issue of whether or not the National Security Agency or NSA engaged in or should engage in, electronic surveillance of US persons within the United States without court order. My position was that the Foreign Intelligence Surveillance Act which is the law of the land, required warrants in such instances. There was another gentleman that testified that very same day on the very same issue. General Mike Hayden. At the time, head of the NSA. Now, another star on his shoulders, four on each side, head of the CIA. He testified, that day, according to the Foreign Intelligence Surveillance Act, if in fact our government deems it appropriate or necessary to conduct electronic surveillance…of a US person in this country, the government is required to, always has, and will, secure a court order. Because that is the law of the land and the NSA obeys and abides by the law of the land. Strange. That law, in its operative parts remains the law of the land today. Yet that same man, now takes a very different attitude. There’s been no declaration of war…what has changed is simply the perception that now, because of 9/11…the President can order those under him to violate the law because he deems it appropriate and necessary in his perception of his role, as commander-in-chief. Fact of the matter is, folks, we are a nation that has a Bill of Rights, it cannot be and should never be allowed to be trumped by those seven words that the President serves as commander-in-chief. The Bill of Rights is the Bill of Rights. It prevails.

### Moderator
Claim: Bob Barr—

### Scientific Advocate (SA)
Claim: In the sense of privacy that it protects, ought not to be frittered away, by granting the government yet more power in addition to the vast power that it already has. Thank you—

### Moderator
Claim: Thank you for your closing remark. And in his final rebuttal arguing for the motion, David Frum.

### Conspiracy Advocate (CA)
Claim: I want you to notice as you think about how you’re going to vote, the, both the abstract and the radical character of the arguments of the people on the other side. They’re abstract, in that they have not given you one example of what you yourselves as individuals ought to be afraid of. What is this tremendous incursion. Now I ask you to think about this to think, do I feel less free to speak my mind. Do I feel that there are thing—that there are secrets that are important to me, that are more in danger of exposure now than they were before. And then I ask you to consider, how many terrorist attacks have there been on US soil since 9/11, and what is the terrible record, through the 1990s, from the first attack on the World Trade Center in 1993, to the—to the attack in 2001. Uh, I want you also to notice how radical their claim is. We are not debating that better limitless surveillance, better surveillance at the sole discretion of the President, better lawless surveillance. What we are saying is, better the higher level of surveillance that has prevailed since 9/11, than this risk. Better, more. They have—they have—uh, they, their argument, is…complete—is, is not modulated, it is not balanced, it is to say that, nothing, there is to be, there is to be no more. I sometimes think, as I, as I’ve been listening to this argument, what would they have said, had they been present at the introduction of the stop sign. They would’ve looked at it and said, this is the first step on the slippery slope toward the total abolition of motion. No one will ever be able to go anywhere ever again. Um…uh…the, the—what we are debating here, is more and less. We are debating balance. Um, I think that, when we identify, as we surely will, specific problems and abuses that have appeared since 9/11, they ought to be fixed. Of course they ought to be fixed, and that is why this original Patriot Act was sunsetted, that is why, uh, Congress, uh, has oversight powers, of course they—those things must be addressed. But what—we must do this with an understanding of danger. We must ask ourselves, when we look back at that world before 9/11, when people—

### Moderator
Claim: David—

### Conspiracy Advocate (CA)
Claim: —the same agency were not even allowed to talk to each other about what they knew. Is that what we wanna return to?

### Moderator
Claim: David Frum, thank you.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: And against the motion, Jeffrey Rosen.

### Scientific Advocate (SA)
Claim: We don’t need lectures on radicalism from the other side. This was the administration, led by our, uh, distinguished opponents, who argue that the President has the unilateral authority to ignore or reinterpret laws including the Foreign Intelligence Surveillance law, with which he disagrees, because it infringes his power as commander-in-chief. Uh, and this is the administration that has indeed used the broad and sweeping, new and radical powers that it’s been granted, which were a warrant for unreviewed, uh, limitless surveillance by the FBI, in ways that have nothing to do with terrorism. Uh, they are the radicals, our position is the traditionally conservative, uh, position. We really wanna resort the law as it was, uh, before the Patriot Act, we’re willing to engage in the kind of sempr—sensible compromises that came out, uh, in the debates, we are not uncompromising at all in this regard. But we want to avoid a transformation in American, uh, liberties from which the country might never recover. Uh, David Frum asked for an a—a specific example, uh, I’m happy to provide one and to close with one and that’s the example of Britain. Britain, the cradle of Western democracy, was the country that wired itself up in the 1990s, with so many surveillance cameras that it now resembles the threat—uh, the set of The Truman Show. Uh, this was defended as a way of stopping IRA terrorism, but the cameras are now used for very different purposes. They’re used to charge a car tax for every car that comes into the city, and recently we learned, microphones have been set up in city centers, to have ominous voices warning people when they’re getting drunk in public. I—I was, uh, I experienced a society that had microphones and surveillance cameras, and that was, uh, in Warsaw in 1988 right before the Berlin— the fall of the Berlin Wall. Uh, and the British public is indifferent to statistics showing that there is no connection between the spread of the cameras and the decline and prevention of violent crime, or terrorism. So these things are indeed small incursions, and even free societies can transform themselves incrementally, in ways whose effects are only beginning to be understood. And in a world where it’s possible to track people from door to door, and to, uh, store that in ubiquitous databases, ubiquitous surveillance that might make it possible to see where it get up in the morning and which subway I take and—

### Moderator
Claim: Jeffrey—

### Scientific Advocate (SA)
Claim: —where I end up going to work, uh, is not, uh, an Orwellian possibility, but a very real probability, and we ask you to resist it by voting against the motion.

### Moderator
Claim: Jeffrey Rosen, thank you. And his closing thought for the motion, Andrew McCarthy.

### Conspiracy Advocate (CA)
Claim: With due respect to the other side, what you’re hearing is radical. Um, we now have increased surveillance. We’ve had it since 9/11, I don’t think it’s sweepingly increased surveillance, but it’s certainly increased surveillance beyond what we had in the 1990s. What they’re telling you, is better another 9/11 than increased surveillance. Now, this is New York. Ask yourself, what have you been going through for the last five years, six years, um, whether it’s keeping you up at night that, uh, the government is, uh, uh…frittering away with, with your personal information or whatever else is that, uh, that is the grave concern here. And ask you, ask yourself, if that’s anything like what 9/11 was like. And whether in a million years, you would ever, ever wanna go through anything like that again, uh, if you could instead, uh, deal with the kinds of, uh, trade-offs between liberty and security that we’ve had in the last six years. That’s not even a contest. And to say that it is, that’s about as radical as anything I can imagine. Now one of the, one of the, last thing I’d like to address is, this idea of perfect security and, and, risk of error. Investigation whether it’s law enforcement or, or, uh, national security, is a human process, and we are not going to be able to repeal human error. There are going to continue to be errors, there are gonna continue to be, uh, roguish acts by people who are rogues. Rogues are gonna be rogues, no matter what the rules are. When you change the rules, when you, when you, uh…clamp down on what your agents are able to do, what you’re actually clamping down on, are the good-faith people who you didn’t need to worry about in the first place. Um, these powers are in place because they’re needed, uh, to ferret out potential threats, because there is no perfect security, we can line—we can wire the whole place up with cameras and, uh, and bugs and the like—

### Moderator
Claim: Andrew.

### Conspiracy Advocate (CA)
Claim: —but we can’t prevent every attack.

### Moderator
Claim: Thank you. Andrew McCarthy, thank you. And her closing thought, Nadine Strossen.

### Scientific Advocate (SA)
Claim: I’m afraid that Andy has not understood our position at all. Our position is that more surveillance of the sweeping, random, mass, dragnet type we are complaining about, and security experts are complaining about post-9/11, is not going to prevent another 9/11, and in fact not only is it ineffective, but it is actually counterproductive to the security goal because it is deterring and diverting resources for measures that the com—and security community has a consensus would be more effective. Let me give you a couple specific examples. The mass gathering of data about all of our communications. The government tells us it’s gonna engage in data-mining. Sounds really impressive, doesn’t it. Of course we would like to believe it would work. Well you know who knows that it doesn’t work? Security experts and computer experts. Let me quote one. Professor Farley at Harvard University, who is a Science Fellow at Stanford’s Center for International Security. Complaining, from a security perspective, about the NSA domestic spying program, he says it is based on a false assumption, that you can work out who might be a terrorist based on calling patterns. But guilt by association is not just bad law, it’s also bad mathematics. Security theater, not real security. And, you know, we put in place understandably, the Patriot Act, NSA, domestic spying, shortly after 9/11, government officials to their credit wanted to do something to at least make us feel more secure. But you can’t do anything meaningful, until you have looked at what the actual causes were, of that horrible catastrophe on 9/11. And that kind of analysis was not done until much later, by the joint intelligence committees of both houses of Congress, and by the Bipartisan Citizens Commission. And they did not recommend the kind of mass surveillance measures that have been advocated by our proponents. And in fact, again, the common-sense, concrete steps that all of us blithely assume have been taken, have not in fact been taken. Uh, John Yoo said, well, we’ve already done all of that, well, that’s not what Tom Kean—

### Moderator
Claim: Nadine—

### Scientific Advocate (SA)
Claim: —thinks, uh, the chair of the 9/11 Commission. He says it is scandalous that police and firefighters in large cities, still cannot communicate reliably in a major crisis. We oppose—

### Moderator
Claim: Nadine Strossen—

### Scientific Advocate (SA)
Claim: —the resolution, because it is bad for security, and freedom.

### Moderator
Claim: Thank you. And now, batting clean-up for the proponents, John Yoo.

### Conspiracy Advocate (CA)
Claim: Well, um, first I wanna apologize for the lack of rhetorical skills on at least my part, that should not prevent you from voting for our side in the debate. I’ve just admired the rhetorical gifts of everyone else on the panel, and that—from what I can tell that consists of calling the other side radical and exaggerating what they actually wanna do in the real world. Um, clearly I’m not an expert at this, I did not get the note about the dark suit, which is really the only thing I noticed listening to everybody’s discussion. Uh…two things, one is I think the other side fundamentally confuses war versus crime. Ask yourself this. If the Soviet Union had carried out the 9/11 attacks in exactly the same way, exactly same people, would we not be at war? And would we not be justified in using wartime measures to try to stop Al Qaeda from carrying out a second attack. Why does the fact that they are not a nation-state require us to go back to criminal justice in the pre-9/11 world? The second thing I’ll just say is, it’s an empirical question whether the, the security of our country has gone up in response to the increased surveillance measures, I think it has. There’s the person who wanted to blow—blow up—blow up the Brooklyn Bridge, there’s too many B’s there, so I’m not good at this. The guy who wanted to blow—blow up the Brooklyn Bridge was caught only because of these new measures. The guy who wanted to carry out terrorist attacks in Florida and Southeast Amer—uh, the United States who fled the country. He was only identified, and an alert went out only because he was identified using expanded surveillance techniques. So there’s still more we can do. One thing I would like to do as—end as we began. I think the FBI’s utterly incompetent, it’s because, they try to do drug-dealing, white-collar crime which I’m sure is of interest to many of you in New York, and all kinds of other things, and counter-terrorism. The reason we keep them all together is out of civil-liberty concerns, I would say let’s get rid of the FBI, create a real national security counter-terrorist agency and let the states and the plo—the states control drug crimes, white- collar crimes, and get the FBI out of the job of trying to do bank robberies and kidnappings. I think that makes no sense. That’s an improvement we can make, but would require you to vote for our side.

### Moderator
Claim: And right on time, we like that. That concludes the closing arguments, now it’s time for you, the jury, to vote once again. So, look for that keypad, the thing that looks like a calculator, uh, on your arm-rest, this thing, uh…right here. And, uh, we’re not gonna confuse you by changing the code, at this…late stage. You may be confused enough, I don’t know. So, after my prompt, please press 1 if you are for the motion, press 2 if you are against the motion, or 3 if you are undecided, 1 for, 2 against, 3 undecided, please go ahead and press your buttons now. We need a little “Jeopardy” music here, da-da-da… I wanna thank the debaters and audience for their participation tonight. And before I announce the results of the final vote, to see who has swayed whom, we need to take care of some business. First, the next Intelligence Squared U.S. debate will take place on Wednesday, May 16th here at the Asia Society and Museum. The motion to be debated next month is, “Beware the Dragon—A booming China spells trouble for America.” Sounds like a good one, unfortunately the debate is sold out. But, the good news is that, packages for the fall 2007-spring 2008 series are on sale right now, on-line and by phone. So avoid disappointment and buy those series packages now. Um, tonight’s debate by the way can be heard locally, on WNYC AM-820 on Friday, April 27th, at 2 p.m., and some point after that it will be heard on hundreds of NPR stations across the country, no exaggerations. Um…copies of some of the panelists’ books are for sale, uh, upstairs in the lobby. And, uh…I think, David, you’ve got a book out, right? And, uh, John has got, uh, a book, and Jeffrey, so, at least three of our… War by Any Other Name, is that it, something like that—

### Conspiracy Advocate (CA)
Claim: Just the white one. Buy the white one.

### Moderator
Claim: So, um, if you wanna help out our panelists in another way, uh, buy their books upstairs. You can also purchase DVD’s from previous debates here tonight, or from the Intelligence Squared U.S. website. And finally, please be sure to pick up—it sounds like we’re selling things here, doesn’t it? Uh, please be sure to pick up a copy of tomorrow’s edition of the Times of London, and the Times Literary Supplement, as you leave the auditorium, but I think those are free. And now, what we have all been waiting for, after our debaters worked so hard to sway you, um, you decided…after the debate…39.5 percent were for the motion. So a—a bit of a, uh…uh, a bit of a movement, toward your direction. Um…after the debate, 55.6 percent were against the motion. So, um… that’s… And undecided…this shows you how good our panelists were, undecided, less than 5 percent. So. Congratulations… Which means that, uh, those against have carried the day. So our sincere—sincere appreciation for you to being a wonderful audience, and thank you, panelists, we appreciate it, thanks. Thank you.

### Moderator
Claim: Well done.
