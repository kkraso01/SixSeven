# Debate Transcript

Topic: Organic Food Is Marketing Hype
Motion: Organic Food Is Marketing Hype

Debate ID: organic-food


## Round 1

### Moderator
Claim: Welcome everyone to another debate from Intelligence Squared US, I’m John Donvan of ABC News, and once again I have the pleasure and the honor of serving as moderator for the six debaters you see sharing the stage with me at the Skirball Center for the Performing Arts at New York University. Six debaters, three against three, will be debating this motion, “Organic food is marketing hype.” Now, this is a debate. This is not a panel discussion or a seminar. It’s a contest. One team will win and the other will lose, and you in our live audience, several hundred of you, will be acting as our judges. By the time the debate has ended, you will have voted twice, once before and once again after you have heard their arguments to tell us where you stand on this issue. The team that has changed the most minds over the course of the debate will be declared our winner. So let’s now go to our preliminary vote. If you go to the keypads on the right arm of your chair, there a bunch of numbers but you only need to pay attention to 1, 2 and 3. Our motion again is, “Organic food is marketing hype.” If you agree with the motion, please press number 1, if you disagree, press number 2, and if you are undecided at this point, please press number 3. And if you feel that you have made an error, just correct it and the system will lock in the last vote that you recorded. So what we’re going to do is tabulate those votes and after opening remarks I will share with you where the preliminary votes stands at that point.

And so on to the debate. Round one: opening statements by each of the debaters in turn, seven minutes each. And we begin-- first I’d like to introduce Lord John Krebs, known just to us as John Krebs on this side of the pond, here in the colonies. John Krebs-- you can make your way to your lectern. John Krebs was chairman of Britain’s Food Standards Agency, which is like our Food and Drug Administration, the FDA, except it was just the F, not the D. And John, you were not chairman in 2009. You had left the board, but it made a very-- it sent a thunderbolt to the system when it came up with a study of a comparison-- nutritional comparison between conventional and organic food and concluded what?

### Conspiracy Advocate (CA)
Claim: That there was no difference in the health benefits.

### Moderator
Claim: Which rolled like thunder through the movement. Ladies and gentlemen, John Krebs.

### Conspiracy Advocate (CA)
Claim: Thank you very much, John, for those words of introduction. And I should emphasize to all of you, do feel free to applaud at any time during my seven minutes.

I start off with a disadvantage because, as Bernard Shaw said-- George Bernard Shaw-- we are two nations divided by a common language. So I hope that you will understand what I am saying even though I am speaking the English that occurs on the other side of the pond. Let me explain first of all where I’m coming from in this. As the former head of the Food Standards Agency, I am not anti organic, absolutely not anti organic. But what I am is pro accurate consumer information, I am pro healthy eating, and I am pro scientific dispassionate analysis of the facts. I’ve got no vested interest. It makes no difference to me whether or not you eat organic food, but I do sometimes get angry about the marketing hype.

And let me give you a for instance. Just last week I was watching a television show about diet and health, and on the show there was a woman who was working for a low income, and she had three children, and she said to the interviewer, “I feel really guilty because I cannot afford the organic food to feed my children a healthy diet.” And that made me really cross, because she didn’t need to buy organic food to feed her children a healthy diet, although-- according to the surveys-- six in ten Americans who buy organic food believe they’re getting a healthier option. And they are paying for it, because when you go shopping, if you buy organic food, you spend $1.60 for every dollar you would have to spend buying exactly the equivalent food produced conventionally. So, is it worth paying the extra for health benefits? The answer is a plain, straightforward, simple “no”.

Why do I say that? I say that because I’ve scrutinized the evidence. Now if you look at the evidence, you have to ask yourselves two questions: who is saying it, and why are they saying it? And of course, if you listen to the organic sector that has a vested interest, they will pick and choose the evidence that supports their case, and no doubt we’ll hear that later on this evening. But I prefer to believe those groups of people who are independent, impartial, objective groups of scientists put together by official agencies to study the evidence with no side one way or the other. And it’s not just the U.K. Standards Agency that John referred, but at the last count, in eight different countries where the federal or national agencies have looked at this issue, in every case they have come to the same conclusion: there is no health benefit of eating organic food when compared with conventional food. Furthermore, and this is a really important point, in the U.K. we have an advertizing standards watchdog, and a few years ago they penalized our two major supermarket chains for advertizing and claiming that organic food is healthier, and they were stopped.

Those supermarket chains were stopped from making that claim. And note this: they did not come back with a legal challenge. Why did they not come back with a legal challenge? Because there was no case to defend. There was no evident to support their case that would stand up in a court of law. So what are the supposed benefits, health benefits of organic food? Some people think that it’s more nutritious, that it may contain more of those essential micronutrients, vitamins, or antioxidants that are supposed to protect us against cancer. But when you look at all the evidence together, sometimes organic food does contain more, sometimes it contains less, but taking the picture in the round, there is no-- absolutely no-- consistent difference. What about safety of food? Because some people say, “Well maybe I ought not to take the risk. Organic food is more natural. It’s safer.” And indeed in Britain 70 percent of the baby food sold is organic because parents are worried about what they’re feeding their children. Well what are these safety issues? One thing that people are concerned about is pesticide residues. Maybe the vegetables or the fruit that’s been sprayed in a conventional farm leave tiny residues on the surface that you may eat when you consume those vegetables. Well two things to note. First of all, organic farmers also use pesticides. They just use a different set of pesticides. But secondly, and more important, those residues are they-- when they are present-- in such minute quantities that they are harmless relative to the natural dangerous chemicals that occur in all the food you eat. How many of you have ever drunk a cup of coffee? Raise your hands.

Okay. Quite a few of you have drunk a cup of coffee. Well let me tell you, in that one cup of coffee there are more carcinogens that you would get in all the pesticide residues in eating conventionally produced or organically produced fruit and vegetables for a whole year.

So if you’re worried about potential carcinogens in your food, don’t drink that cup of coffee. But of course, you don’t need to worry, because these chemicals may have the potential to be dangerous, but they are in such a low level in the food that you don’t need to worry about it. But in a way, this is missing the point, because you can argue hither and thither about how much of this chemical is in the food, how much of that pesticide residue is present, how much of this vitamin, and so on. What really counts is looking at the health outcomes. So, are people who eat organic food healthier than people who don’t? And that’s a pretty difficult question to answer, but there is one study that’s looked at it, and it’s an extremely large study. It’s called the Million Women Study. It’s being carried out in the U.K., and it’s called the Million Women Study, because it involves at least one million women who over a long time period record everything about their lifestyle, including what they eat, and subject themselves to a variety of health measures, including suffering from diseases. And that study shows that there is no difference in the health outcomes for women that eat organic food and women that don’t eat organic food. It doesn’t really matter to me whether you eat organic food or not. It’s your lifestyle choice. It doesn’t bring you any benefit. But what does matter to me is when poor people, like that woman I saw on television, feel guilty because they’re not feeding their kids organic food. Just because of the marketing hype, they feel guilty, and that, to me, is an outrage. So, I urge you to vote for the motion at the end of this evening.

### Moderator
Claim: Thank you, John Krebs.

Our motion is “Organic food is marketing hype.” And now to open arguments against this motion, I’d like to introduce Urvashi Rangan, who is director of technical policy for the Consumer’s Union.

That is the organization that puts out “Consumer Reports.” And, Urvashi, your specialty there is labeling, and in particular when it comes to organic, you tell the rest of us whether if it’s organic on the label if it’s really organic in the jar.

### Scientific Advocate (SA)
Claim: That’s right. It’s been part of my job for 10 years there, educating consumers about what organic means and what it doesn’t, and allow them to make informed choices about the foods they buy.

### Moderator
Claim: Ladies and gentlemen, Urvashi Rangan.

### Scientific Advocate (SA)
Claim: Thank you. Good evening everyone. I’d like to address a few things that John brought up in this resolution, and the first thing is the resolution is not about whether organic is healthier or not. That’s not what we’re debating today. We’re also not debating whether it’s more nutritious. What we’re debating is whether it’s marketing hype or not, and that is what we’re trying to judge by the end of this debate. John brought up a few things that I’m going to address, including pesticide residues and sort of dismissing any level of harm whatsoever. And if you’re eating carcinogens in one thing, why not eat it in everything? That is simply a dangerous-- dangerous theory. And as a toxicologist for “Consumer Reports,” I have to say that we barely understand what one chemical does at one point in time. We have no idea what the multiple exposures to low-level pesticides--

--chemicals, drugs, heavy metals does to anybody, and so, as a mother of two, and as many people are, if you have the health of somebody else’s hands in your hands and you’re responsible for them, you want to take extra measures to figure out what you’re putting in their bodies, too. I’ll leave that now and I’m going to launch into our side of the case, which is that “Consumer Reports” has been deciphering labels since 1936. Our sole mission is to educate consumers about marketing hype, what it is, what it isn’t. And for many years, I have to say in my last 10 years rating labels we’ve come across a lot of labels that are marketing hype.

Natural: very few standards, no verification. Hypoallergenic: also marketing hype, no standards. Fragrance-free, free range. All of those labels are marketing hype. They have no standards. They have no verification. Those are our two most important criteria when we’re rating labels, and those don’t meet any of them. On the other hand, organic food meets those criteria. It does have a comprehensive set of standards behind them, and it is verified. We don’t consider that to be marketing hype, and therefore we think you should vote against this resolution. So, let me give you some more examples of marketing hype. Wonder Bread, wonder brains. They had that out for a while. FTC took action against that, that they can’t call it that. Maybe some of you recall the Smart Choices label program, a big green check mark that was industry sponsored, ConAgra, Pepsi. You found it all over, including Fruit Loops, full fat mayonnaise, a couple other things. That’s also marketing hype. Not such a smart choice. And one other one: the United Egg Producers used to have a claim called Animal Care Certified. Sounds really lovely like the animals were cared for, but it could have been used on eggs that came from chickens stuffed in the battery cages where they couldn’t stand up, put into towers of battery cages where all their poop and excrement basically rained down through the cages onto the floor, contaminating the ground, moving into the ground water: could be labeled Animal Care Certified. They stopped doing that, but, again, that’s another example of what’s marketing hype. Incidentally, organic production doesn’t allow chickens to be stuffed in those battery cages, and it’s just one of the reasons why organic offers a benefit over conventional. Let me jump into five other big reasons why organic does carry more value, and first of all just to set the stage, Congress passed an act in 1990, the Organic Food Production Act. The USDA runs the National Organic Program. We have certifiers and inspectors accredited by the USDA.

This is a public program. Everybody can participate in it. And, it is subject to accountability, it is subject to inspection itself. This is a credible labeling program. I don’t think we’re really wasting this much energy over something that is just simply marketing hype. But let’s get into five big reasons why organic offers benefit over conventional production. First of all, organic animals eat a diet free of poop. Can you believe that? Why am I saying that? Am I a nutball? But no, conventional agriculture and conventional farming in this country actually picks up chicken litter from the bottom of the chicken coop, filled with poop, excrement, whatever that chicken ate-- including mammalian byproducts, cow brain, blood meal-- and guess what? Animals eat that in conventional production. It also can include garbage, plastic roughage pellets, and this is the stuff that we freely-- in face, we call it a rich protein supplement. I mean, this is a protein considered useful for animal feeding. It’s not allowed in organic production. It’s just one reason why organic offers a benefit. Second, organic is free of antibiotics; they cannot be used. Antibiotic resistance is a huge growing public health problem in this country.

We feed antibiotics to animals every single day. We wouldn’t do that with humans. We wouldn’t feed humans antibiotics every day. Why do we do it in conventional agriculture? Number two reason why organic offers a benefit. Third, we feed animals-- chicken broilers in this country-- things like arsenic, if you can believe it. These are toxic heavy metals that we actually feed the animals. They act a lot like antibiotics. They help them grow better, they help prevent disease. And yet, the arsenic goes from their poop into the ground, it seeps into the ground, and the problem with conventional ag is people don’t think it moves anywhere. But it does. It moves into the ground, into the groundwater. We create big pits of manure that go up into the air and contaminate it.

These things are controlled for in organic production. Two last things. Organic doesn’t allow the use of most synthetic pesticides. It’s true, as John points out, that some pesticides are allowed, but one report estimates that about 60 percent of the pesticides that are out there are classified as a known, probably, or possible carcinogen. If you can have food that doesn’t have those things, why wouldn’t you want to eat healthier? Why wouldn’t that offer a benefit? But remember, this isn’t a debate about whether you would buy it, but rather whether it is truly a measurable difference and whether it offers a credible alternative to consumers who are buying it, and whether or not consumers who buy organic are currently being deceived in the marketplace. We would say no, and therefore we urge you to vote against the resolution. Finally, I’d like to talk about synthetic fertilizers. We actually compost human waste in this country and we put it onto conventional crops. That’s right. What you put in your toilet can get composted and get put onto the food that we eat, and that’s how it gets fertilized. That is a prohibited method in organic production. You may not use human sludge as compost. It comes with a number of problems, including heavy metals. And finally, synthetic fertilizers rape the soil. And organic promotes it, and Chuck will be talking a little bit more about that. Thank you.

### Moderator
Claim: Our motion is “Organic food is marketing hype,” and now to speak for the motion, the only actual farmer in the debate tonight. I’d like to introduce Blake Hurst, who is a farmer in Missouri. He raises corn and soybeans and flowers along with his family. He’s done it all of his life. He’s also a writer who is published in the “Wall Street Journal” and the “Weekly Standard” and other magazines. I’m interested Blake, is it harder to farm or harder to write?

### Conspiracy Advocate (CA)
Claim: I can’t make any money at either one.

### Moderator
Claim: Ladies and gentlemen, Blake Hurst.

### Conspiracy Advocate (CA)
Claim: I’m used to not making much money. Only tonight did I learn that I was a rapist. This will come as a surprise to my family and friends, who don’t think much of me, but think more than that. If you’ve ever driven through the Midwest on a summer evening, your windshield becomes covered by bazillions of sticky glutinous gobs of insect guts. Your windshield wiper can cause a wreck because it just smears the stuff around, making your windshield as opaque as the directions for assembling a Christmas present. The bugs are corn borer moths. Corn borers cause corn to drop ears, corn stalks to fall over. They also damage the husk of the corn, making it vulnerable to a soil-borne pathogen called aflatoxin, which causes liver cancer in humans. The insecticide Bt produced by corn grown from genetically modified seed causes corn borers to swell like a balloon and to explode. I find this very satisfying. I imagine pops, like a string of firecrackers, like popcorn on a hot stove, as all across my fields corn borers explode. Bt corn of course disqualifies my crop as organic, even though a nearly identical pesticide is available to organic farmers. And aflatoxin I should point out is completely natural. Of course, we’ve on our farm lost our chance to be organic some 50 years ago. We have a picture-- we have a picture of my grandfather standing in front of a corn crib. He’s wearing a faded blue work shirt, overalls turned white from repeated washings, a broad-rim straw hat, and he’s carrying two ears of corn, one the before year and one the after, then after had a nitrogen applied to it, artificial raping nitrogen. The after year was much bigger. Grandpa is grinning widely because he’s celebrating a record yield.

I should probably point out that our farm has manure as a fertilizer source and at the time planted lots of legumes in long rotations: all practices recommended by the advocates of organic farming, usually writing in a sort of a tone of breathless discovery. Yes, Virginia, people were thinking about soil fertility long before the “Oprah” show covered “Food, Inc.” When commercial fertilizer became available, yields went up, costs went down, including environmental costs, as we use less resources to produce the same amount of food. When this happens in other industries, it’s generally seen as a good thing. The father of the organic method was Sir Albert Howard, a British agriculture scientist. He taught that disease, whether plant, animal, or human, is caused by unhealthy soil, and the secret to good health is farming organically. According to Howard, “The war in the soil is the result of a conflict between the birthright of humanity, fresh food from fertile soil, and the profits of a section of big business.” That sentence could have been written a week ago and would have been just as unrealistic now as it was in 1949 when Howard wrote it. You’ll notice then, as now, the farmer is strangely absent from this narrative. Tools of big corporations bought off by seed corn caps and glossy advertisements, we’re only practicing industrial agriculture because we’re tools of the man. The truth is better captured by that picture of my grandfather smiling from year to year as he celebrates a record yield. You may find this bloodthirsty battle using chemical warfare, genetic manipulation distasteful. It’s clear that our opponents here tonight do so. They imagine farming as a holistic walk with nature as we reap her bounty with hardly a mark left on the landscape and a utopia as we discover that connection to soil has been lost because of the application of science to food. According to them we can walk back our dependence on petroleum, lose our addiction to chemicals and laboratories and be one again with nature. Rarely has so much nonsense received so much attention from so many outstanding minds.

Organic production requires its own set of environmental trade-offs. Organic food takes more land than conventional farming for the same amount of food. Organic farming leads directly to more, not less, soil erosion because conventional farmers disturb the soil less. Organic rules are arbitrary with some practices clearly forbidden because of political pressure instead of science. Some of the most environmentally costly practices conventional farmers use are approved for the organic farmer as well. Some of the practices most important for food safety are not available to organic producers. Hunger is the darkest factor of all and always closer than we expect, particularly in the parts of the world that are most likely to farm organically, although they don’t call it that. Nature doesn’t care whether we’re hungry or well-fed. We wrest what we can from her reluctant arms each year, and in order to have an adequate supply of food, we have to use all the tools available to us. That’s the truth. That’s the truth of this multi-front war we call farming, and as inconvenient as it may be to the critics of the present food system, that’s the way it will always be. Eating organically is trendy, edgy, and advocated by all the right people. Organics consumers shop as a form of conspicuous self-congratulation, a chance to pat themselves on the back for their social conscience, and to enjoy the superiority over the coupon-clipping bourgeoisie shopping at Wal-Mart, though organic consumers should know this: her choices have costs, real costs: environmental costs and costs when it comes to world hunger. According to the United Nations Food and Agriculture Organization, there are a billion hungry people in the world. Every time someone purchases organic food, more water and more land are used to produce that food than to produce the same amount of food on my farm.

That’s the reason why you should vote in favor of the motion. Organic food is fashionable, cool, an attitude, a chance to identify yourself with beautiful actresses instead of old farmers in overalls. But mostly, organic food is marketing hype. Thank you.

### Moderator
Claim: Thank you, Blake Hurst. So here is where we are. We are halfway through our first round opening statement by each side at this U.S. Intelligence Squared debate. I’m sorry, I’m going to rephrase that because this needs to be right for the radio broadcast. I said U.S. Intelligence Squared, and I’m going to reverse that. We are halfway through the opening round of this Intelligence Squared U.S. debate. I’m John Donvan as moderator. We have six debates, two teams of three, who are fighting it out over this motion: “Organic food is marketing hype.” You have heard three of the opening statements, and now on to the fourth. I would like to introduce Jeffrey Steingarten, who is a bestselling author and food critic for “Vogue” magazine. One of his more famous books is “The Man Who Ate Everything.” I apologize, Jeffrey, I have not read the book. Is it autobiographical?

### Scientific Advocate (SA)
Claim: I’m referring to a very famous other person.

### Moderator
Claim: Well let me recommend the book and introduce once again. Ladies and gentlemen, Jeffrey Steingarten.

### Scientific Advocate (SA)
Claim: Thank you. I started-- well I didn’t start out-- I started out as a lawyer and not as a food critic or a writer, and if this were a court I think I would ask the judge to exclude most of the previous testimony on the grounds that it was totally irrelevant to the proposition.

To say that organic food is a marketing hype I guess means that all organic food is a marketing hype, that everything about organic food is a marketing hype.

That doesn’t do you any good-- it doesn’t do the other side any good to show that there is an advertisement that shows healthy people by eating organic food, if they actually are. I doubt they’re eating the food on the set-- photographic set. So that’s marketing hype as well. I remember when I was on the FDA-approved advisory committee right at the beginning, and we were given advisory powers, and one of the things that we were given was BST, bovine somatotropin, to increase cows’ milk production. And everything we were fed, except from one-- well you know, from the Center for Science in the Public Interest, was total hype. Monsanto hired the farmers who sat in their offices, working with their computers. Monsanto put overalls on them and everything, and they talked about how they knew that their cows were happy, producing all this extra milk. We know that cows overproducing get mastitis and then there is pus, if I can use the word pus, in the milk. No one wanted to use the word pus. And maybe pus is not bad for you, but I thought it was--

The FDA was so afraid that we were going to vote against it, so they combined two committees, also the Animal Husbandry Committee, all of whom were supported by the agriculture department or by industry, for example, Monsanto.

So that was lopsided and have always been lopsided, so much so that the other side was emboldened to move that it should be a crime for a milk producer to announce that there was no bovine somatotropin hormone in his milk because that would be marketing hype since there’s no difference. The forces against good food are very powerful in this country and it’s enough to make you paranoid.

With all possible respect, our last speaker-- okay, I’m not going to say that you sounded like Dick Cheney, okay? But--

--but he talked about farming as a multi-front war and that you have to wrest from nature that, you know, these kind of little rewards you, these little, you know, corn cobs. I know four or five farmers, and I’ve spoken to them all in the last few days so that I would be able to learn all about farming.

There’s one that I’ll nickname Farmer Al who grows some of the best peaches in the country. They’re organic and they’re in northern California. And it took a while for Al to start switching from non-organic to organic peaches. They’re better now. He was so mellow about it, about how you have to use this in order to avoid that pest. And I asked him whether he used Round-Up on his weeds. He said, “Oh no, we just manage the weeds.” Just as long as they’re not--

--just as long as they’re not higher than about that, they won’t threaten the plants, the weeds won’t and also scattering eggs of predators to the pests and so on and so forth. Al’s peaches are more expensive. There’s no doubt that organic food is on average more expensive, so our next speaker, I believe having read some of what he’s written, are going to say, as the farmer did, that it’s almost a crime with all the people starving to devote any resources to some kind of elite food. Now, I know that the best vegetables that I’ve ever tasted were organic, and they were grown on Dan Barber’s property-- he doesn’t own the property; Rockefeller owns the property-- but the property near his restaurant. Conventional agriculture is not feeding the world.

To say that organic agriculture could never feed the world is sidestepping the fact that organic-- that conventional agriculture is not feeding the world and it’s dependent upon oil selling at $45 a barrel, it’s dependent upon steady climate, and it’s also dependent upon relatively available water.

Okay.

### Moderator
Claim: Jeffrey Steingarten, I’m sorry, you’re time is up.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: Thank you.

Thank you, Jeffrey Steingarten. Our motion is “Organic food is marketing hype.” And now here to speak against the motion-- I’m sorry, I’ve skipped a page. Now here to speak for the motion, I’d like to introduce Dennis Avery, who is director of the Hudson Institute’s Center for Global Food Issues, who was for some time an agricultural economist who worked for the State Department and writes extensively on food policy. Ladies and gentlemen, Dennis Avery.

### Conspiracy Advocate (CA)
Claim: To measure the depths of my sins, I’m holding up a book written by my son, Alex Avery. It’s entitled “The Truth about Organic Foods” and it traces the history of the movement from Germany in the 1920s on to our organic farming today, and the tragedy that organic farming doesn’t live up to the hype. The people who are buying it and consuming it and offering it to their families truly want to do the best possible thing, as speakers tonight have said, and I certainly don’t disagree with that. But this is not just an unfortunate failure to live up to the billing. It is now a serious international concern, because we are about to enter the biggest farming challenge the world has ever seen. We will have, by the year 2050, between 8 and 9 billion people. I expect that instead of 1.5 billion affluent people, science, technology, and trade will give us 7 billion affluent people. And if the Chinese reach half of the pet saturation that we have in this country, that will mean another 250 million companion cats and dogs; none of them vegetarian.

We will need to double world food production again. We will need to triple the yields on the best farmland, because that not only gives the highest yields and the least erosion, it displaces the fewest wildlife species. The Great Plains had 60 million bison, 100 million antelope, 3 billion prairie dogs. That’s three species. The poor land has more, far more, species. We are farming 37 percent of the land area now. If we produce for 2050 by simply extending the borders of the fields we’ll be farming 80 percent of the land area. And if you think conventional farming isn’t feeding people now, just wait. And the organic farmers can’t do this. The key is nitrogen. The Earth had 1.5 billion people before we got nitrogen fertilizer. We would still be at 1.5 billion people were it not-- that might be better. You might think you prefer that, but you aren’t going to get there with zero population growth movements, and you aren’t going to get there with meatless Mondays. You’re going to have to triple the yields again on the best farmland. Plowing itself is a danger. Summer of ’07, 12-inch rainfall in southeastern Minnesota, second- largest concentration of organic farmers in the country. They not only had flooding; they had mudslides.

Whole hillsides sloughed off. Sandy loam hills should not have been in anything but no- till farming. No-till cuts erosion by 65 to 95 percent. It doubles soil moisture. It’s the most sustainable farming system ever developed. And organic farmers can’t use it because you have to have herbicides to kill the cover crops so you can plant what you really want to grow. They can’t kill their cover crops. And the yields over all are about half as high. We had a famous study that came out in the summer of 2007 from the University of Michigan, which has no school of agriculture. The lead author was a fully- qualified geologist. And they said organic farming can feed the world and more.

You’re entitled to believe that, but they made a fairly serious mistake in the paper. They talked about one study in which green manure crops had put 1,500 milligrams per acre of nitrogen into the soil and that 66 percent of this nitrogen had been delivered to the seedheads of the crops. That doesn’t happen. Everybody agrees that nitrogen fertilizer puts a higher percentage of its nitrogen into the crop seeds. Thirty-three percent is the accepted figure. On green manure crops it’s 20 percent. The different between 66 percent and 20 percent is starvation for half of the humans, or the destruction of wildlife habitat on a scale never yet seen in this world.

This is not truth, and it is not a favor to you or to the population of the rest of the world to tell something about organic farming that is demonstrably false. We will have to turn high-yield farming into higher-yield farming. Thank you very much.

### Moderator
Claim: Thank you, Dennis Avery. Finally, with our motion “Organic food is marketing hype,” to summarize his position against the motion I’d like to introduce Charles Benbrook, chief scientist at the Organic Center, which makes you the only person who has the word organic on your business card. The Center produces science with the goal of aiming to persuade all of us to go organic. Ladies and gentlemen, Charles Benbrook.

### Scientific Advocate (SA)
Claim: Thank you, John, very much. First of all, I think I need to start with an apology to my esteemed colleagues on the pro side of this debate, because I’m actually going to speak to the motion. Tonight we’re debating whether organic food is marketing hype, and the way that I understood this-- and I think probably most of the people on our side-- is that we’re talking about the companies and the farmers that grow organic food and sell it to people. They put claims on the label. There is advertizing, there’s lots of information on websites. I think we all have a pretty good idea on how companies market products and deliver information to consumers. And in the United States, as you know, there is a number of laws and regulations that govern what is marketing hype and what’s not. Urvashi spoke to some of that. We’ve all heard the saying one aspirin a day helps prevent heart attacks.

That’s kind of amazing that it does, but in large clinical trials, people that take an aspirin a day have a statistically significant lower risk of heart attack, and so the FTC and the FDA have allowed that claim on-- in advertising for aspirin. But if you heard an aspirin a day prevents heart attacks, that of course would be marketing hype. To claim that it will prevent goes over the line into marketing hype. So, how do we judge whether the claims that are made or the information that’s passed on by organic food companies crosses this line into misinformation or materially misleading information, which is a standard in the FTC guidelines? What the government says-- now, think about the last time you went to the supermarket. You can’t walk down any aisle without leading labels that say they have reduced this or low that or a good source of this or promotes heart health or promotes eye health or good for your cholesterol, heart healthy, etc. All of these claims that either promote a food product because there’s more of something that’s good or less of something that’s not good for you, like saturated fat or cholesterol or salt, embedded in those claims are at least a 25 percent difference in the level of the nutrient. This is applied fairly universally across the entire food system. So, whenever you see these labels that says it’s, you know, a good source of lycopene-- you’re buying a tomato product; lycopene is a nutrient in tomatoes-- and it says a good source of lycopene, you can trust that the company has done testing that shows that there’s at least 25 percent more in their product compared to others. So, as we go through the evening, keep in mind that if there is solid scientific evidence that one food product, whether it’s conventional or organic, has higher or lower of a particular nutrient that’s good or bad for you buy a Good or bad for you, by a 25% margin that the government allows a labeling claim to be associated with that.

Now, how is organic food marketed? What are the principle claims? And benefits? Well, number one, of course, is organic farmers may not apply toxic synthetic pesticides. It's just a blanket prohibition. The products that they can apply encompass all of those that post any risk to humans or the environment. It's true organic farmers request use natural products like copper fungicides, sulfur is used to help protect diseases. Natural insecticide, Bacilus thuringiensis that Blake talked about, it's how Monsanto and other biotech companies have found a way to move the capacity to produce this natural insecticide into the corn plants. And so without a doubt the reduction in exposure and risk from pesticides is the most common claim that you read. And there is no question that organic farming reduces pesticide risk. It's laughable for anybody to argue that it doesn't. You know, American agriculture, apply rounds, a billion pounds of pesticides a year. Some are not terribly hazardous, including Glyfosate which Blake will use on some of his genetically engineered crops. But there are several other pesticides, especially insecticides to do pose significant risk. And the fact that we're all exposed to pesticides, even before we're born, does play a role in our public health. Do you all know that the average baby born in America has like 200 chemicals in its blood the moment it’s born from the exposures to its mother? About one out of eight babies are born with a diagnosable birth defect?

About a quarter of the couples in America are having trouble having babies. They need some help in getting pregnant and carrying a pregnancy to term. The scientific literature is loaded with thousands of papers that demonstrate a connection between exposure to pesticides and these adverse health outcomes. To say that there are no risks for pesticides and no evidence, I mean if you don't-- if you don't believe in science, fine. Go ahead and make that statement. But you can't claim that you read the scientific literature. That-- you know, it's just the way it is. Another of the major claims that are made, and marketed, if you're shopping in the livestock part of the aisle, in the dairy or eggs or beef, livestock and organic farms have to be given ample space to carry out natural behaviors. They have to be raised in an environment where they can stay healthy without their daily dose of antibiotics, which Urvashi spoken out. They have to be given access to outside, unless it's 20 below and the weather would be dangerous for them. But they have to be raised in a much more humane way. That's built right into the rules; all organic farmers have to do it. If you care about how animals are cared for, if you care-- it's great that we can buy cheap bacon and eggs done cost much. If you do care how animals are cared for, organic agriculture with the only system of agriculture backed up by solid rules that require sound animal welfare: one of the reasons that we hope you'll vote against the motion.

## Round 2

### Moderator
Claim: That concludes round one of this Intelligence Squared U.S. debate. The motion being argued is “Organic food is marketing hype.” We now have the results of where you, the several hundred of you in our live audience stood on the motion before the debate began.

The motion is organic food is marketing hype. We asked you to vote, tell us whether you stand for, against, or undecided on this motion. Here are the results. Before the debate, 21% of you are for the motion, 45% against, and 34% undecided. That's where things stand at the beginning of the debate. We'll ask you to vote once again when the debate has concluded. The team that has changed the most minds will be declared our winner. Now on to round two: it's our middle round. And it's where the debaters address each other directly and also take questions from you in the audience and from me as well, as moderator. I'd like to begin with a question to the side that's arguing for the motion that organic food is marketing hype. In your critique of those who support and believe in organic food and organic farming, there is just-- there are these intimations of elitism that people who like organic food are people who use words like “intimations,” for example.

That it's just a little bit snobby and a little bit snotty. In fact, the research shows that the majority of people who buy organic food in this country are at the higher end of the educational scale. I want to ask you, are you saying that all of these well educated people are actually rather stupid? Are they missing the point? John Krebs.

### Conspiracy Advocate (CA)
Claim: You're absolutely right that people who purchase organic food tend to be from the wealthier sections of society simply because it's more expensive to buy. And that's, you know-- you folks that buy it, you can afford it. There are plenty of people out this in this country who couldn't afford to do it. Does it mean that you're stupid? Absolutely not. But it means that to some extent, you have bought in to what I claim is marketing hype. If I can just go back to Urvashi's opening comment, it is absolutely marketing hype that the claim that organic food is healthier for you, and that's why the advertising regulator in the U.K. stamped down on the two major retailers that made this claim, as well as on the organic producer body, the soil association who was making the same claim.

It was hype. There was no case to support it. And it was banned. If that isn't a straight forward piece of hype, exaggeration, implicit deception, I don't know what is.

### Moderator
Claim: Jeffrey Steingarten.

### Scientific Advocate (SA)
Claim: I wonder how long you conducted the million-- the lady study. Was it six months or six weeks, was it two years?

### Moderator
Claim: Jeffrey, what's your point? Why are you raising that?

### Scientific Advocate (SA)
Claim: Many of the toxins in pesticides, herbicides could take years and years.

### Moderator
Claim: What about that, John Krebs? Do you think it's too soon to know?

### Conspiracy Advocate (CA)
Claim: The million women study is still going on. It's been going on now for about eight years. It will continue for another probably 15 or so years. So we're looking at long term effect and no effects have shown up so far.

### Moderator
Claim: Urvashi Rangan.

### Scientific Advocate (SA)
Claim: I think we're talking about elitism but it's really that organic food costs more. Organic food costs more to produce, and there are a couple reasons for that. One is that it's incredibly physically labor intensive. You've got to-- as Jeffrey pointed out, you have to pull the weed. You can't just spray a chemical on it. It's harder to do. So there is no question that organic food is harder to produce. But the other major factor that has not been mentioned today is the amazing subsidies that all of our taxpayer money goes to to support cheap food production to subsidize late crops on corn and soy, and the myriad of ingredients that stem from that that end up in processed foods, hence creating cheat processed foods. Organic doesn't get subsidies. That's why between that and what it does, it costs more.

### Moderator
Claim: Blake Hurst.

### Conspiracy Advocate (CA)
Claim: Beg to differ-- of course, organic qualifies. Same subsidies that I do, subsidies are tied to the ground. They don't ask how you produce the crop. My question-- I guess I would like to ask, you talked about fertilizer raping the soil.

How does the soil know the difference between-- I mean nitrogen, you look at your periodic table. There it is, it appears. When I apply nitrogen on some of our acres for manure, when I apply some nitrogen from some of our acres, commercial fertilizer, how does the soil know the difference?

### Moderator
Claim: Charles Benbrook.

### Scientific Advocate (SA)
Claim: I'll speak to nitrogen. One of the major problems around the world, back in February 23, those of you that read the “Wall Street Journal,” there was a remarkable story about how the subsidies in India for nitrogen fertilizer started back in the Green Revolution days have actually led to such excessive nitrogen fertilizer use in India, that what happens when you put extra nitrogen on ground, you stimulate microbial activity in the soil. And those microbes, they eat your organic matter, in effect, which degrades your soil quality. And the “Journal,” it was a very interesting and hard hitting story. And it was just a week after in “Science Magazine,” there was a major research report that Dennis may have seen about China and how there is this major problem in China about the acidification of soils from too much nitrogen. In America, in the Midwest, less than 35% of the nitrogen that gets applied winds up supporting the growth of that corn plant. And the rest, some of it goes into the water and some of it volatizes into the environment. Organic farmers, on the other hand, nitrogen is expensive to them because they don't have access to these cheap commercial sources of readily available nitrogen fertilizers. They have to get their nitrogen the old fashioned way with cover crops and legumes and compost. It's dear to them and it’s valuable. And they use it much more carefully. They don't need as much to support the same amount of growth. They don't pollute the water. They don't contribute as much to global warming. And they improve the quality of the soil and it's these sorts of win, win, wins that are why even the USDA acknowledges that organic farming is better for the environment. And that's one of the claims.

### Moderator
Claim: Dennis Avery of the Hudson Institute.

### Conspiracy Advocate (CA)
Claim: There is a new set of products on the market from Arcadia Biosciences. They're actually the product of a-- a research mistake at the University of Alberta. They were trying for drought tolerant crops and instead, they got nitrogen-efficient crops. Rapeseed, rice and wheat; you can now put on half as much organic nitrogen, get in effect what we thought of as a full crop, with very little left in the soil to leach into the nearby streams. Can we hope that the organic farmers will, at some point, recognize this benefit and help protect the water with nitrogen efficient biotech crops?

### Scientific Advocate (SA)
Claim: What does that have to do with how organic food is marketed in the United States? what's the point?

### Moderator
Claim: I want to ask Blake Hurst, because you're our only farmer possibly in the room. I think there may be some farmers in the audience, but certainly on the panel. In terms of just the reality check that you can provide to us, a guy who gets his hands in the soils, what have you heard tonight that is the most out of touch with what really happens in the real world?

### Conspiracy Advocate (CA)
Claim: I get this idea that-- Jeffrey says that conventional farming is not feeding the world, so his solution is to produce less food? I mean this idea-- it is, indeed--

### Scientific Advocate (SA)
Claim: Totally wrong. If you're growing corn--

### Moderator
Claim: Let's let Blake answer that question.

### Conspiracy Advocate (CA)
Claim: Yeah, well give me your example.

### Scientific Advocate (SA)
Claim: If you're growing corn on two pieces of land, farmers told me this, two pieces of land, one conventionally and one organically, the conventional plot will produce more corn.

If you have less than a modern culture, the number of calories produced on the organic piece of land, which is what we care about, the number of calories on the organic land will be greater than on the conventional land.

### Conspiracy Advocate (CA)
Claim: What's your source for that?

### Conspiracy Advocate (CA)
Claim: That's impossible.

### Conspiracy Advocate (CA)
Claim: I would like to know the source.

### Scientific Advocate (SA)
Claim: Charles can tell you. I'm not a scientist.

### Moderator
Claim: Tell him Charles. Charles Benbrook.

### Scientific Advocate (SA)
Claim: This is an important point. On Blake's farm, we were speaking on the right over here. You'll be getting out in the field pretty soon to plant corn, right? In the next couple weeks that corn will germinate in 10 days. It will grow vigorously capturing solar radiation, pulling up nitrogen from the soil, and producing a crop for about 90 days. After 90 days it goes into synapsis. It has to dry so he can get his combine in, and really, from the second week in August, maybe the third week in August, that field really isn't growing anything more. Organic farming is based on a much more diverse set of crops. Organic farmers are going to get a cover crop on to the corn ground as soon its harvested so that that fall solar radiation is captured and supports biomass which support microorganisms in the soil. So the way that organic farmers can and do produce more per acre is they produce multiple crops. They integrate livestock and often fish with their crops. And they're using that solar radiation in the early spring and the late fall when it's not as intense in the summer. If you drive through the Midwest, our greatest agriculture regulation, it's only producing a crop for about 90 days of the year. And there are at least six weeks in the spring and fall when it could be growing something. And something is growing on all the organic farms. That's how--

### Moderator
Claim: John Krebs is also a scientist can respond to that.

### Conspiracy Advocate (CA)
Claim: Another way to--

### Moderator
Claim: Dennis, I'm going to led John Krebs respond.

### Conspiracy Advocate (CA)
Claim: I have a simple question to Jeffrey. If indeed organic production is more efficient, produces more yield per hectare than conventional, why is organic food more than expensive? Who is making all this extra money? The reason it's more expensive is because you get less per hectare.

### Scientific Advocate (SA)
Claim: No, because it is-- first of all, there is industrial organic, the farming about which I don't know a lot.

### Conspiracy Advocate (CA)
Claim: Sorry, could you say that again? What?

### Scientific Advocate (SA)
Claim: Why is it more expensive?

### Conspiracy Advocate (CA)
Claim: No. What were the two source of organic? You said there is industrial organic and there is something else organic. A smaller scale?

### Scientific Advocate (SA)
Claim: There is industrial organic.

### Conspiracy Advocate (CA)
Claim: When we're talking about marketing hype are we talking about the system organic are or we taking--

### Scientific Advocate (SA)
Claim: Yeah, we're talking about healthy organic.

### Conspiracy Advocate (CA)
Claim: Just a minute. No evidence that it's healthier.

### Scientific Advocate (SA)
Claim: Yes, I know. I was just trying to get you.

Did it work? The reason it's more expensive because it involves a lot of hand labor. You have to hire in the-- in the northeast you have to hire either migrant laborers or you have to build them houses. The best apple farmer in this whole area builds houses for her laborers, and then sends them to school, sends the kids to school. I guess the farmers are not in that position. But there is a lot of hand work. You can't have a combine coming through and doing whatever a combine does. Plus also, I understand that this whole tillage argument-- I have been told that organic farming does not require tilling. Is that true or do you know--

### Conspiracy Advocate (CA)
Claim: No, that is not true. It's bare earth farming. Organic farming is bare earth farming.

### Moderator
Claim: Dennis can you respond to Charles' point that he made about essentially that an organic farmer is working a more diverse range of-- working the soil in more diverse ways by introducing different crops and its interaction with livestock?

### Conspiracy Advocate (CA)
Claim: It's certainly working in more diverse ways. And I want to compliment the organic movement for having been concerned from the beginning with the health of the soil.

Unfortunately, unfortunately they aren't using it very well. And the point he made about the corn getting its growth in the first 90 days means that the organic farmers are starving their corn for part of that 90 days. They are not getting what that field could produce because the organic nitrogen is slow release.

### Moderator
Claim: Urvashi, do you want to come in on this?

### Scientific Advocate (SA)
Claim: It is a strange argument. And what I guess I want to-- I want to zoom out a little bit and talk about genetically modified crops. The U.N. has issued two reports actually, one just recently and one a few years ago. That for Africa and Eastern Europe, organic agriculture is the answer for those areas for maintaining the sustainable food production supply. The second thing that also has--

### Moderator
Claim: Why? What is this logic of that? Why is organic the answer for those areas?

### Scientific Advocate (SA)
Claim: It resides within many of the reasons we're talking about, sustainable production, jobs, less pesticides, less inputs. Those things cost money. While our opponents are reporting the miracles of genetic modification, and pesticides, and how wonderful they are, what most consumers don't know is that those things were not required to be tested for how well they work or how safe they are before they got out on the market.

And those are the aspects that the U.N. is considering when they make those reports available and anyone is free to read those reports.

### Moderator
Claim: Blake Hurst.

### Conspiracy Advocate (CA)
Claim: Of course there is long and extensive testing for-- what the National Resource Council says--genetically modified seed is tested before it goes on the market. How many of you have bought genetically modified seed? How many of you have toured Montsanto's laboratories? How many of you know the process that it goes through?

### Scientific Advocate (SA)
Claim: I have.

### Conspiracy Advocate (CA)
Claim: The point I'm making is that that's blatantly untrue. As to the point of whether it works or not, I guess that is the that's the consumer-- because the NRC says that there is no conceptual distinction, that's the National Research Council, your government, no conceptual distinction exists between genetically modification of plants and microorganisms by classical methods or by molecular techniques that modify DNA and transfer genes. There is no difference. It's just a faster and more effective way of improving crops. The biggest mistake the organics standard made was not accepting genetically modified seeds. Absolutely.

### Moderator
Claim: I'd like to go to the audience for some questions. How this works is that if you raise your hand and I find you, I'll ask you to stand up. If you're a member of the news media, we'd prefer that you tell us that fact, who you work for. You'll be given a microphone. And hold the microphone about that far from-- one fist away from your mouth so that the radio can pick you up. I just have a question before we get there. What strikes me about this debate is that the tone here is as bitterly partisan as anything that's happening in Washington. And I'm curious about why that is. And it's on both sides. It's also from all of us here in the hall. There is a nasty feeling to this issue. And I'm curious about why-- we're talking about food.

What we eat. I want to hear from one panelist, nominate yourself on each side, about why are we there? In this topic? Charles, you're nodding. You represent the organic center. Why?

### Scientific Advocate (SA)
Claim: The organic food industry-- it actually deserves the word industry, now accounts for about 3% of our food supply. It's not threatening the profits of Cargill and ADM and Craft and General Mills in the marketplace, yet, but it is in the world of ideas. And with all due respect to John Krebs, the science is strongly lining up behind organic farming. It is more nutrient-dense. There are 70 or 80 studies that have reached that conclusion. To just dismiss them that they're not there, you know, you can do it. But if you read science, it's there. So I think organic food and what this whole area represents, it worries the conventional agriculturist to that people are going to start to ask questions about how our food is grown and what's in it, and how it might be contributing to the fact that we Americans spend more than any nation in the world on healthcare, but our health across a number of measures really doesn't stack up that well. And I think it's a lot about what we eat.

### Moderator
Claim: John Krebs, do you want to-- not just respond, but to take on my question.

### Conspiracy Advocate (CA)
Claim: Well, as I said at the beginning, you would expect those with organic on their business card to play the claim that organic food is better for you. Not surprising, Chuck, well done. But why is this such a divisive issue? It's a divisive issue because it's a side show from the real problems that we face which are first of all about feeding the growing world population as Dennis said. And second of all, for those of us who are lucky to live in an affluent society, to eat a healthy balanced diet and secure our own health.

Organic food is a complete side show to both of those issues. Those of us who care deeply about those issues are very frustrated by the repeated claims of the organic sector explicit or implicit that they will solve these problems.

### Moderator
Claim: So it sounds like each side thinks the other side is actually doing harm here?

### Conspiracy Advocate (CA)
Claim: Exactly.

### Moderator
Claim: Not just disagreeing but doing harm. Gentlemen, right there you could rise and hold the mic close to you, and please make it a brief question. Thank you.

### Moderator
Claim: One of the points that Mr. Avery made was that we need to significantly increase food production. And I'd like to just suggest that in making fun of meatless Monday, you are asking a question about the concerns of livelihood of millions of people. 1.7 million people who died of heart disease, diabetes, stroke, and cancer last year because of easily attributed to a number of academic studies to their eating meats. My question is, wouldn't reducing meat production significantly reduce overall agricultural production requirements?

### Moderator
Claim: I'm going to pass on the question with respect because it's really-- I don't think it's on our topic of organic food and marketing hype. It's a question about meat versus vegetables, I believe.

### Moderator
Claim: If the question is about subsidy, we're talking about how people are not getting access to make an even playing field for organic foods. And meat is a huge--

### Moderator
Claim: I think we're off topic. But with respect, thank you. Yes, right there. Thank you.

### Moderator
Claim: I am a member of the media. I work at Martha Stewart Living, and I worked on cookbooks. But I have a question. One of the things that hasn't been addressed here at all tonight is the question of flavor. We're talking about marketing hype. It's hard to get away from the fact that an organic banana tastes like a banana, or an organic peach takes like a peach. And, you know, that’s less and less true of conventional produce.

### Moderator
Claim: So what's the question? No, but it's better organic, which is good.

### Moderator
Claim: The question is where is-- you know, where is the hype if we're really looking at flavor?

### Moderator
Claim: Are you actually-- your question really is, does an organic taste food better, and isn't that one of its benefits?

### Moderator
Claim: Yes.

### Moderator
Claim: Right? Okay. Fair question.

### Moderator
Claim: I guess that's what is the question.

### Moderator
Claim: Fair question. Fair question.

Yeah.

### Scientific Advocate (SA)
Claim: John, believe it or not, this question actually is germane to the debate.

### Moderator
Claim: I agree that it is. I just want the other side to answer it.

I'll come back to it, though.

### Conspiracy Advocate (CA)
Claim: I have been privileged to watch a program taped by a couple of comedians who perform primarily in Las Vegas who conducted a number of blind taste tests on the street in Las Vegas. And nobody could tell the difference from nothing. I grew up on a farm. Our tomatoes, during the height of the growing-- of the harvest season, were wonderful. The rest of the year, we didn't get tomatoes except out of cans. This whole freshness thing, fresher tastes better. If your organic is fresher, it may taste better. But that's apart from its being organic.

### Moderator
Claim: Charles.

### Scientific Advocate (SA)
Claim: I think--

### Moderator
Claim: Charles Benbrook.

### Scientific Advocate (SA)
Claim: I think this is-- I really appreciate this question because it's very important. The organic food industry has not claimed that organic food tastes better. And the reason that-- they know it does sometimes, but they don't have the systems in place and the ability to guarantee a consumer that it's always going to taste better. And it's an example of where the industry has not gone over that line to hype its products. Now, there're some consumers out there that are convinced that it always tastes better. And maybe to them, it does. But I actually think the organic food industry has been fairly responsible in not getting beyond the science and beyond what they can guarantee.

And I think that they deserve a certain degree of respect for this. And they certainly deserve your vote to this motion because they haven't gone out of their way and made claims. Now, some people say-- you know, some consumers-- the woman that John spoke about, being guilty about not eating organic food. That's a shame. You know, all mothers should feed their kids lots of fruits and vegetables, organic or conventional. But you can't hold that against the industry that's trying to be responsible in telling people about what the true benefits are and they are significant.

### Moderator
Claim: Okay. So we're in the question-and-answer section of this Intelligence U.S.-- we're in the question-and-answer section of this Intelligence Squared U.S. debate. I'm John Donvan of ABC News, your moderator. And we have six debaters, two teams of three, debating this motion, "Organic food is marketing hype." We're going back to the audience for questions. Gentleman in the blue shirt.

### Moderator
Claim: Hello. This question is for Dr. Rangan. You talked about the fact that-- or you claim there was a fact that organic food could be verified, and there were standards for organic food. My understanding is that's not true, that the standards are for organic farming and that there's a difference between process and product and that the standards do not say anything about the products. It's just the process by which the product is obtained. So my question for you is, if I gave you an apple, and you had to do an analysis to determine whether it was organic or not, and it was a scientific analysis, presumably a chemical or physical analysis, what exactly would you do to verify that it was an organic apple?

### Scientific Advocate (SA)
Claim: Yeah, your point is well taken. It is production. It's the Organic Food Production Act. And it's about production. And the seal is on the food, and it is about what goes into the production of that apple or that orange. And just incidentally, there's also a whole scientific advisory board that reviews and approves materials that are allowed and printed in processed foods as well as in fresh foods. So there is a whole framework around that. And that's what we're here to talk about today. That is the foundation of what it is. How would you test for a food that was organic? You might look for genetic modification. That's prohibited.

### Moderator
Claim: If it's a banana, we can taste it.

### Scientific Advocate (SA)
Claim: In fact, your point goes-- it's very difficult to test for whether something's organic or not. If it had prohibited residues, you might know that it wasn't. But the point is-- and that's why there is so much recordkeeping involved. There is so much work involved for a farmer to become organic because the whole paper trail of what went into that farm has to be documented. Everything that went into the particular jam that was processed has to be documented. Those things aren't required for conventional agriculture.

### Moderator
Claim: John--

### Scientific Advocate (SA)
Claim: And the materials used are restricted. And--

### Moderator
Claim: John Krebs to respond.

### Scientific Advocate (SA)
Claim: --that is the framework that exists.

### Conspiracy Advocate (CA)
Claim: It's a very interesting question. When I was head of the Food Standards Agency, we started sponsoring research to develop such tests. And such tests can be developed because this is a bit of technical chemistry. The isotopes of carbon and nitrogen that come from chemical fertilizers are different from the isotopes out of manure or compost. But the organic movement strongly opposed this, and they said it was a complete waste of money to develop these tests. They never said why they thought it was a complete waste of money. But I thought I had a pretty good idea that a lot of the produce that's on sale as organic is not actually genuinely organic.

And I think it would be a good thing if the regulators did use tests like that and really showed what was on sale in the shops.

### Scientific Advocate (SA)
Claim: Well, John, I think you should speak for the U.K. on that because there's a lot of us that follow what goes on in the United States. The organic label has meaning in this country.

### Moderator
Claim: Let's go back to the audience for questions.

### Conspiracy Advocate (CA)
Claim: Does the regulator carry out the tests?

### Scientific Advocate (SA)
Claim: No.

### Moderator
Claim: Ma'am, can you see me looking at you?

### Scientific Advocate (SA)
Claim: They enforce the rules.

### Moderator
Claim: If you could stand up, yes, and we'll bring a microphone. And if-- it'll be handed down to you. You don't need to work your way up. Question, please, now.

### Moderator
Claim: Yes, question. Thank you. My question is that for people who are interested in sustainably produced agriculture, there's some consumer concern that the rise of industrial organic agriculture, which was touched on briefly, has sort of called into question the rigorous standards that are in place for determining whether something is organic or not. And I was hoping the panel could speak to that. How rigorous it is and if--

### Scientific Advocate (SA)
Claim: I know people--

### Scientific Advocate (SA)
Claim: I know people who have compared factory chicken production in the conventional way of doing it and in the organic way of doing it. Now, it's still about factory chicken production. But it is, number one, the chickens don't have to have access to the outside. They have to have been outside. If you have something that passes the organic tests, it gets the approval of a certifier, who is also certified by the Department of Agriculture, there was nothing you're going to have to fear about the food. Raising animals in a humane way-- I go to the green market twice a week.

There are people who raise animals in a conventional humane way. But most conventional agriculture does not do that. And I would say that the organic movement should receive-- that's why you have to pay more because it--

### Moderator
Claim: But ma'am, are you--

### Scientific Advocate (SA)
Claim: And we're getting very bad karma by eating this--

### Moderator
Claim: Ma'am, are you asking do we know-- are you asking do we really know how rigid the rules are and whether they're being followed?

### Moderator
Claim: Yes.

### Moderator
Claim: You're asking--

### Moderator
Claim: Some of the regulations are in place in organic-- when people buy organic, they assume that--

Excuse me, can we pass her a microphone?

### Moderator
Claim: I'll repeat it for her. Oh, I'm sorry. You want to--

### Moderator
Claim: Sure. When people are--

Can we pass the microphone?

Yeah, sorry. My question is, when you're buying organic, you're assuming certain things about the production of the food. And when things are produced on farms that can be considered factory farms when they're such large scale, can the standards be scaled up to some of the sizes of farms that we're seeing?

### Moderator
Claim: Okay. I'm going to let Blake take the question, but I don't quite understand it, so if you could rephrase it.

### Conspiracy Advocate (CA)
Claim: Well, yeah. There's a whole lot of-- I mean, at what size does my farm get too big to be moral? I mean, what size farm is immoral? When do I become industrial?

### Moderator
Claim: Confined animal feeding operations.

### Conspiracy Advocate (CA)
Claim: I think it's useful to point out that if we're talking about the chickens being indoors or outdoors, the reason we get flu every year is from Asia where most of the chickens and ducks are still kept outdoors and they are wandering up and down the street of the village, and it is the interaction between humans--

### Scientific Advocate (SA)
Claim: But that's in Asia.

### Conspiracy Advocate (CA)
Claim: --and those animals that we get the Asian flu. We get cholera from hogs.

We had-- this is historic. Most of our epidemic diseases have come about through this close interaction of people and animals, and modern confinement production is protecting you from those diseases.

### Moderator
Claim: Okay, Urvashi, so we're talking about--

### Scientific Advocate (SA)
Claim: Okay. I'm sorry, Dennis, that is just garbage.

That is not the case.

### Conspiracy Advocate (CA)
Claim: So you--

### Scientific Advocate (SA)
Claim: I'm sorry. Confined animal feeding operations-- I don't know if anybody's heard about lagoon pits of poo the size of a great lake that exists, and these are bacterial cesspools for lots of viruses. The H1N1 was a mixture of bird, pig, maybe something else. We have huge hog farms in North Carolina. We have huge problems with bacterial problems down there from the poo pits. This doesn't just come from China. We've got the problem right here with industrialized agriculture in this country.

### Moderator
Claim: Gentleman with the beard.

### Moderator
Claim: Hello.

### Moderator
Claim: Could you stand up, please?

### Moderator
Claim: Sure, hi. Mr. Hurst, you really caught my attention when you said that organic agriculture should stop aligning itself with celebrity actresses and start talking to farmers. Michael Jackson, Ray Charles, Brittany Spears, Beyonce, Christina Aguilera--

### Moderator
Claim: All right, all right, I need a question.

### Moderator
Claim: --Mariah Carey-- my question to you is, should we really be thinking twice and flipping the question around to say, is chemical food marketing hype? Those names I read by the way to give you some context are Pepsi spokespersons that I have seen on television in my lifetime. Thank you.

And Pepsi is made from corn.

### Conspiracy Advocate (CA)
Claim: Was there a question?

### Moderator
Claim: Yes.

### Moderator
Claim: Well, his question was, is conventional farming marketing hype, and given that actually your team has claimed a superiority in several areas for conventional farming, I think it's a fair question.

### Conspiracy Advocate (CA)
Claim: Okay, yeah.

Well, then, of course, the answer would be no.

### Moderator
Claim: I love a pithy answer. White shirt? Right behind you. This is our last question. The part of the marketing that I'm interested--

Can you stand up, please?

### Moderator
Claim: Sure. The part of the marketing that I'm interested in hearing about is the health oriented marketing that could be either viewed as hype from the one side or not from the other. And what I had a hard time following was the notion that on the one side that defended organic food, organic farming, there was a listing of 80 scientific papers that proved the health benefits of organically produced food. And on the other side there was a lack of trust in the scientific data. So I was hoping that we could actually talk just briefly about one, just pick one of the 80 that says there's no doubt that there are health-related benefits to organic food, and then just ask the other side why that's not accurate.

### Scientific Advocate (SA)
Claim: Sure. The "British Journal of Medicine" published a study about two years ago that showed that children born to mothers who consume predominantly organic milk and meat during pregnancy with its elevated levels of conjugated linoleic acids, which are a heart healthy fat, had lower-- the children had lower levels of eczema. It was really the first time an actual health benefit in humans from consuming organic food has been proven and published in a peer review journal. And, of course, this is for any health problem. So many different things affect health. It's very unusual to be able to trace a disease or-- to a single part of our lifestyle. So that's one study that came out, and it hasn't been refuted.

### Moderator
Claim: All right. Let's hear the other side respond.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Did you say that was the first that's come out after 80 years?

### Moderator
Claim: No, no. He said it's one that's come out.

### Scientific Advocate (SA)
Claim: A study proving a health benefit in humans, when I said before that there're 80 studies, those are studies comparing the nutrient levels in organic food to conventional food. Now, there're a lot of people that feel eating more nutrients really doesn't make you any healthier, but you got to wonder why the U.S. government is spending so much time and energy trying to get us to eat more fruits and vegetables.

### Moderator
Claim: John Krebs.

### Conspiracy Advocate (CA)
Claim: Well it’s very simple. In that study as in many others, it’s very difficult to tease apart the contribution of different factors. There’s no clear proof in that study that the benefits that Chuck has alluded to were to do with eating organic foods, because there are a lot of other differences between the comparison population. So we still don’t have any evidence that organic food is healthier food for you.

### Moderator
Claim: And that concludes round two of this debate.

## Round 3

### Moderator
Claim: And here’s where we are. We are about to hear closing statements from each debater. They will be two minutes each and it’s their last chance to change your minds and from the audience vote before hand, we know where you stood for before the debate began. Here’s what we have. Our motion is “Organic food is marketing hype.” Before the debate, 21 percent of you were for this motion, 45 percent were against and 34 percent were undecided and we’ll ask you to vote again shortly and we’ll ask you in that way to pick our winner as this debate concludes just a few minute from now. But now onto round three, closing statements from each team in turn. Speaking first against the motion, organic food is marketing hype, Charles Benbrook, chief scientist at the Organic Center.

### Scientific Advocate (SA)
Claim: Thank you, John. As I said before, this is about the claims or the positive attributes that are used in labeling and advertising, educational material on websites to convince consumers to buy more organic food. That’s what we’re talking about. The claim that is most common and most known to Americans is about the reduction, significant reduction in pesticide use and risk that’s associated with organic farming; that’s kind of a no- brainer.

Organic farmers don’t apply any of the dangerous pesticides that we have a huge program in the EPA to deal with. And they don’t use any of the pesticides that are causing all the problems with bees. They don’t use any of the herbicides that are castrating male frogs and feminizing them all throughout the Midwest. They just don’t use them at all; it’s prohibitive. And that prohibition is embodied in the regulations. In terms of animal drugs and in particular, antibiotics and growth promoting hormones, hormones that push animals to produce more quickly, organic farmers can’t use them. It’s against the rules and that’s again, embodied in the standards. So when a company promotes organic food as better for animals, this is one of the reasons. The other claim that is ubiquitous is that organic farming is better for the environment. The U.S. Department of Agriculture has agreed with us. Organic farmers build soil; they add humus to the soil; they reduce greenhouse gasses; they reduce the loss of nitrogen into the groundwater. They promote bio-diversity; they don’t kill bees; they don’t kill frogs; they don’t kill beneficial insects. And again this suite of benefits are embodied in binding, enforceable regulations that a part of the rules. So please don’t buy into the arguments of the other side that because organic farming can’t feed the world and all these other claims, that you should vote for this motion.

### Moderator
Claim: Thank you, Charles Benbrook. Our motion is organic food is marketing hype and summarizing his position for the motion, John Krebs, principal of Jesus College, Oxford and former chairman of the U.K.’s Food Standards Agency.

### Conspiracy Advocate (CA)
Claim: I just want to make two points very briefly. First of all, we haven’t really discussed what is organic food? When I was head of the Food Standards Agency, I asked to meet with the organic food sector. Ten people turned up and I said okay, I just want to talk to one of you. It turned out there were 10 different certification bodies for organic food in the U.K. and they all disagree with one another. No one body would allow the others to represent their view because they didn’t agree on what organic food was. So it’s one thing to say that there are standards that are followed, but those standards are completely different depending on who you talk to. So we should be clear that organic food means different things to different people. And let’s go back over these questions about marketing hype, because whether or not their explicit claims might be made by the organic producers and organic marketers, they are certainly claims that people who buy organic food believe and accept. And those claims are either that it’s better for you or its better for the environment. We’ve heard nothing this evening that really provides me with convincing evidence of either of those claims. Okay you may get more bio-diversity on an organic farm, but if we’re going to feed people with organic food, we need to turn more land into agriculture and do away with our natural parks and wildlife reserves. Is that tradeoff worth making? I don't know, but we haven't heard any evidence for it this evening. Do pesticides pose a risk? Well, remember that organic farmers use insecticides, including one called Rotinone which is known to cause cancer in rats, is one of the most dangerous pesticides if you're worried about carcinogens in your food. So if you're worried about pesticide risk, don't eat organic food, don't eat conventional food. In fact, starve to death. Thank you.

### Moderator
Claim: Thank you, John Krebs.

our motion is “Organic food is marketing hype.” We're in the closing statement section. And speaking against the motion, Jeffrey Steingarten: best-selling author and food critic for Vogue magazine.

### Scientific Advocate (SA)
Claim: First of all, I assume that one of my debate partners, team partners, will be able to refute the one example given of a danger of something that's used in organic food. There may be a lot of people in America who disagree about what organic food should mean. But we have a law. It's very hard to read it, and it's long. And it's very exacting. There have been issues about whether it's enforced strongly enough. But that would mean we shouldn't have speed limits because some people that I know exceed them. There's no doubt about the environmental dangers of conventional agriculture. You may have read that in the Gulf of Mexico there is a dead zone, and it changes in size every year. It appears to come from all the nitrogen that is dumped into the Mississippi River for a thousand, 2,000 miles all the way from Chicago. And it gets into the Gulf of Mexico, and it deprives plants and fish of oxygen. The size of the dead zone two years ago was about the size of New Jersey in the middle of the Gulf of Mexico. There is no doubt to me that conventional agriculture is doomed. The only question is how soon. There is-- conventional agriculture requires lots of water, an even, steady climate, a monoculture and none these conditions--

### Moderator
Claim: Your time is up. Thank you very much.

Our motion is “Organic food is marketing hype.” And summarizing his position in support of this motion, Blake Hurst, a farmer and vice president of the Missouri Farm Bureau.

### Conspiracy Advocate (CA)
Claim: The longest term study and the go-to reference, if you look up organic yields, was done at the Institute. They had two organic plots, one which used manure as a fertilizer source. We don't have enough manure to fertilize all the acres that are in crops today. We would need 5 billion-- 5 billion more cows in order to produce enough manure to use that much fertilizer. The other crop used a long rotation of using legumes and corn two years out of five, where legumes, in order to produce the nitrogen for the corn or the cash crop the next year. So there you have it. That's the final point. Organic food in any given year can produce the same as conventional food. But over that five- year period, it only produced 60 percent as much. 60 percent as much. Two years ago, we were at a 30-year low in food stocks and cereal grain stocks. Countries were banning the export of rice even here in the U.S. They limited the amount of rice you could buy because of the short supply. They were trying to cut down on hoarding. We can have food problems. We can't solve them. We can't have hunger problems. We can't solve them with organic production. We Americans take a plentiful supply of food for granted. And we've forgotten that the history of the world is a long search for food security. We have to remember that the history of agriculture is not a long crime, not a sort of industrial fall from grace, but rather the greatest success story the world has ever seen. The advances in farming and the application of technology to production of food have made us better fed, safer, healthier and richer.

Those are very good things, and we should give thanks for our good fortune. And that's why you should vote in favor of this motion.

### Moderator
Claim: Thank you, Blake Hurst.

Our motion is "Organic food is marketing hype." And summarizing her position against the motion is Urvashi Rangan who is director of technical policy for the Consumers Union.

### Scientific Advocate (SA)
Claim: Thank you. Our opponents have just been off topic this entire evening, and the resolution is not about yield and how much organic yields versus conventional. Does it yield more or less? It's not about whether organic feeds the world or not. That's not the resolution. The resolution is whether it's marketing hype. John on the other side, brought up, it doesn't offer health benefits. It doesn't, so therefore it's marketing hype. It was never designed to be a healthier food product for you, the human being. It turns out there are some inadvertent benefits about being healthier to the environment. And that's what it was designed for. And it turns out when we're better to the environment, and we're better to the animals that we raise, and we don't soak these animals and the ground they're on with drugs and chemicals and heavy metals, it turns out that might be better for us too.

And that is in fact why organic is not marketing hype. It began as something that was positive for the earth. And my opponents did not refute not a single of my first three points in terms of poop being fed to animals. John, the U.K. closed up all the loopholes with animal feed with mad cow. We didn't do that. And so organic offers that tangible benefit. We mitigate those exposures in organic food production. Secondly, with antibiotics, we have a big problem with the resistance of bacteria at antibiotics. Our opponents had no response whatsoever to that point. There is a tangible danger associated with conventional production.

And we feed animals heavy metals. Just today, the inspector general of the USDA came out with a report showing residues of heavy metals, chemicals and drugs in meat. It's there. It's in the meat. Organic doesn't use those things. And therefore, organic is not marketing hype. We urge you to vote against this resolution.

### Moderator
Claim: Thank you, Urvashi Rangan.

Our motion is "Organic food is marketing hype." And summarizing his support for the motion, Dennis Avery, director of the Hudson Institute, Center for Global Food Issues.

### Conspiracy Advocate (CA)
Claim: Bruce Ames, University of California Berkeley, one of the most knowledgeable cancer researchers in the world, tested pesticides, tested first synthetic pesticides and found about half of them caused cancer in rats at high doses. He was applauded by the organic movement. Then he started testing natural compounds and whether they caused rat-- cancer in rats at high doses. And about half of them did. And this is where Dr. Krebs got his point about the 46 carcinogens in the coffee. And the actual reality is that 99.99 percent of the carcinogens that you ingest are from Mother Nature. They're there mostly in the plant foods that we eat and consume and brew. And there if you're eating organic food at all this additional expense, you might be reducing your exposure to cancer by something on the order of 1/10,000 of 1 percent. I was a little surprised to find that we were also here tonight to discuss the pig poo in the waters of the state of North Carolina.

But since I have in fact analyzed the data on that particular question, I can tell you that there has been no change in the water quality in North Carolina since they started growing hogs down there. There is a problem with the water quality below the cities because the sewage treatment plants don't deal adequately with the people poo.

### Moderator
Claim: Dennis Avery, your time is up.

### Conspiracy Advocate (CA)
Claim: Not the pig.

### Moderator
Claim: Thank you very much. And that concludes this intelligence squared U.S. debate.

And now it is time to learn which side has argued best. We are asking you in the audience to choose our winner. We're asking you to go to the keypad, to the right of each seat. Our motion is “Organic food is marketing hype.” If you agree with the motion after hearing these arguments, press Number 1. If you are against the motion, you disagree after hearing these arguments, push Number 2. If you remain or became undecided, push number three. And we will have the readout on these results almost instantaneously. Before we announce the results of the votes, I just want to-- first of all, I want to thank-- this is different from other debates that we've had in some ways.

And I really want to thank the panels for making it so spirited and so interesting, so thank you to all of you.

So I want to let you know that our next debate will be on Tuesday, May 8th. The motion is “Obama's Foreign Policy Spells America's Decline.” Panelists for the motion are Andrew Card, former Chief of Staff for President George W. Bush, and Dan Senor, a former Pentagon and White House advisor. Against the motion we have Wesley Clark, a retired four star general who served as NATO's Supreme Allied Commander, and French philosopher and bestselling author, Bernard Henri Levy. And individual tickets are still available by visiting our Web site and out front at the Skirball box office.

You can make sure to become a fan of Intelligence Squared U.S. on Facebook and then you can receive a discount on our upcoming debates. We would also like to announce that for the first time Intelligence Squared U.S. is going on the road. We will be in Washington, D.C. for our first ever debate outside of New York City on Tuesday, June 8th, at the Newseum. The motion there will be “The Cyber War Threat Has Been Grossly Exaggerated.” I expect to see all of you on the shuttle on the way down.

Our guests there will include top cyber security experts including the former Director of the NSA, retired Vice Admiral Mike McConnell. And you can tell all of your friends in Washington, D.C. the tickets are on sale now through our Web site. All of our debates can be heard on more than 220 NPR stations across the country. You can also watch the spring debates on the Bloomberg Television Network. Airdates and times can be found in your program. And don't forget to read about tonight's debate in the next issue of "Newsweek" and to pick up a current issue on your way out. One more round of applause, I want to thank the people who asked the questions, including those who did not get answers.

So the results are in. Before the debate, on the motion Organic Food is Marketing Hype, before the debate, 21 percent of you were for the motion, 45 percent were against the motion, and 34 percent were undecided. After the debate, 21 percent remained for the motion, 69 percent are against, 10 percent are undecided. The side against the motion wins.

Congratulations to them. Thank you from me, John Donvan, and from Intelligence Squared U.S.
