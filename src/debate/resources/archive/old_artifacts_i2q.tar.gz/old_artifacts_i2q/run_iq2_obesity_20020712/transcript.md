# Debate Transcript

Topic: Obesity Is The Government's Business
Motion: Obesity Is The Government's Business

Debate ID: obesity%20020712


## Round 1

### Moderator
Claim: Throughout the evening, because we're broadcasting for radio, I'll be doing a number of formal repetitions of particular phrases that's might become tiresome to you. But just so you know, I'll be telling you again and again what my name is, for example, when we come back from breaks and in a couple situations I may ask you to break spontaneously into applause to come back from a break. So you'll know that it's spontaneous because I've told you to do so. I would like to introduce with great respect and appreciation the founder of Intelligence Squared U.S. who has made all of this possible and who will be framing the debate for us tonight, Mr. Robert Rosenkranz.

### Moderator
Claim: Well, thank you very much, and thank you for joining us this evening. Now, I have a day job, and it's running an insurance company. We cover some 8 percent of the U.S. work force for long-term disability and serious workplace injuries.

So we see, first hand, that obesity is a major factor in driving claims costs, particularly those related to serious traumatic injuries. The most obese have substantially higher incident rates of diabetes and chronic heart disease as well. But does this necessarily mean that lower weight produces better health outcomes for everyone? Do the moderately overweight need to go on crash diets or otherwise modify their eating habits? When the government defines terms like "overweight" and "obese," do those particular weight levels have any demonstrable connection with health outcomes? The first lady has made childhood obesity her signature issue. But interestingly, the administration does not want to join the debate tonight. We're disappointed that the current surgeon general was required to withdraw from the debate, but delighted that her predecessor, David Satcher is with us.

He was actually the first to sound the alarm over obesity. So this brings me to the crux of tonight's debate. If obesity is indeed a serious public health issue, what, if anything, should the government do about it? Well, at a minimum, it can stop doing harm. Farm subsidies are targeted at producers of corn syrup and beef, for example, but not at producers of fruits and vegetables. School lunch programs are festooned with regulations that fly in the face of nutritional common sense. Aside from its sins of commission, can the government actively make things better? Should we embrace ideas from Britain to treat parents of obese children as abusive or neglectful and then haul them into court? Do calorie disclosures and requirements for healthy menu choices really change eating habits?

Indeed, are there any government obesity programs that in fact produce measurable health benefits in a cost effective way? As usual, the issues tonight are complex. Fortunately, we have some outstanding panelists to shed light on them. And it's my pleasure to turn the evening over to them and to our moderator, John Donvan. Thank you.

### Moderator
Claim: Thank you. Thank you. And I'd just like to invite one more round of applause for Robert Rosenkranz. Yes or no to this statement: Obesity is the government's business. We all eat, but do we do it wisely and well? Well, obviously not. So who is supposed to fix that? Well, that's what we're going to have out here tonight. This is another debate from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters, two teams of two, who are ready to get started.

We'll have three rounds of debate, and then the audience will vote to choose the winner, and only one side wins. And as we go into it and meet our debaters, ponder this thought: At one point in our history, the surgeon of the general of the United States raised the alarm about the number of Americans who were underweight. That was Dr. Hugh Cumming. He was the sixth surgeon general, and it was 1925. And he certainly thought it was the government's business that Americans were getting too few calories. So what happened? How did we get to this world where Americans are getting too many calories? Our motion is, "Obesity is the government's business." And arguing for this motion, I'd like to introduce this team first, first Dr. David Satcher, who is the 16th surgeon general of the United States. And Dr. Satcher, you were the first to raise the alarm in 2001 about the obesity epidemic.

And I want to just ask you very briefly, at that point, did you see us reaching this point where the numbers are where they are today?

### Conspiracy Advocate (CA)
Claim: Well, it was sort of a surprise when we saw what had happened over a 20-year period and the direction that we were going in terms of increasing obesity. So we didn't know how long it would take to begin to turn what we call the epidemic around.

### Moderator
Claim: Thank you, Dr. David Satcher. And your teammate, Dr. Pamela Peeke, you started out life as a critical care doctor, and then you went back to school to learn nutrition. Motivated by what?

### Conspiracy Advocate (CA)
Claim: I became a Pew Foundation scholar in nutrition and metabolism because in medical school, I learned nothing. I didn't have a minute of nutrition taught to me. Yet here I was in the critical care unit where people-- where people's lives were at stake. I had to keep them alive with food. And I was the most clueless person of all. I went back to school.

### Moderator
Claim: Thank you. And welcome to our team arguing for the motion. Our team arguing against the motion that obesity is the government's business includes Paul Campos. He is a modern-day version of the Renaissance man. He is a Shakespeare scholar, a law professor. He's at the University of Colorado as well as a practicing attorney in certain times. But you're here because of a book you wrote called, "The Obesity Myth" in the mid-2000s, which was motivated, you've said before, by an interesting confluence of events, the Monica Lewinsky scandal and the use of the word zaftig in the public culture to describe her, all of which led you into a new field. How?

### Scientific Advocate (SA)
Claim: Yeah, I was a-- sounds improbable, but I was a-- I was doing a conference on the Clinton impeachment when it was taking place, and a speaker dropped out on me, and I had to fill in the gap in the program. And so I was looking at the media coverage of the Clinton impeachment to see if there was something interesting to say about it.

And I did a lexis search, and I found that there were more than 100 news stories that used the phrase "Monica Lewinsky" and the word "zaftig." And I was very struck by that, because, of course, as I have discovered in talking about this over the years, the vast majority of Americans don't know what zaftig means. This audience probably has a relatively high percentage of people who know what that word means. But most Americans don't. And yet Monica Lewinsky was being identified as both fat and Jewish, which I thought was kind of interesting by the use of that word. And so I started looking at the weight that-- the role that weight obsessionalism played in the Clinton impeachment. And here we are today.

### Moderator
Claim: Thank you. And your-- your teammate, John Stossel, John Stossel, well known as a journalist, a gadfly, a libertarian, a contrarian and omnivore, I presume.

### Scientific Advocate (SA)
Claim: A what? Yes, yes. Omna.

### Moderator
Claim: That might have been too personal. Relevant to this debate, John, you have likened those who would want to regulate the diet of Americans to the prohibitionists of the early 20th century, the moral being what?

### Scientific Advocate (SA)
Claim: That they mean well, but that they do more harm than good.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: And it reminds me of what Mencken said, that they have the haunting fear that someone somewhere may be happy.

### Moderator
Claim: Ladies and gentlemen, the team arguing against the motion. So our motion is obesity is the government's business, and this is a debate. It's a contest. At the end, there will be a winner and a loser. And you, our live audience here at the Skirball Center, will choose the winner. By the time the evening has ended, we will have asked you to vote twice; once before the debate and once again at the end. And the team whose numbers have changed the most will be declared our winner. So let's go to the preliminary vote. If you go to the keypad at your seat, our motion is, "Obesity is the government's business." If you agree with the motion, push number 1. And if you disagree, push number 2.

And if you're undecided, push number 3. Ignore the other keys. And if you push the wrong button, just correct yourself, and the system will lock you in. And what we're going to do is we're going to hold the result that we just registered to the end of the debate. We'll release the two numbers together, the starting number and then the concluding number. And as I said, we go in three rounds. So onto round one. Our motion is "Obesity if the government's business." In round 1, the speakers speak uninterrupted for seven minutes each. And speaking first for the motion, "Obesity if the Government's Business," I'd like to introduce the 16th surgeon general of the United States. He has also served as assistant secretary of health and as director of the Centers for Disease Control and Prevention, Dr. David Satcher.

### Conspiracy Advocate (CA)
Claim: Thank you. Well, we contend that obesity is definitely the government's business. My favorite story I think about policymakers is a story about a man who was traveling across the country in a hot air balloon, and at a certain point he realized that he was lost, he had no idea where he was, so he decided that he would lower the balloons and see if he could see some recognizable landmarks. So he lowered the balloon, couldn't see anything that he recognized, no Golden Gate bridge, no Washington Monument, so he had no idea where he was. So he kept lowering the balloon, and when he got to about 30 feet above ground he saw a man working in the field. So he yelled out, "Where am I?" and the man stopped digging in the field, and he said, "Well, you're in a hot air balloon about 30 feet above ground." the man in the balloon said, "You sound like a scientist. Do you work in science?" And the man on the ground said, "My goodness, I am a scientist. But how in the world did you know that?" Said, "Well, I knew that because what you told me is technically correct but it is of absolutely no use to me right now." Well, not to be outdone, the man on the ground said, "Well, you sound like one of those policymakers from Washington or somewhere." And the man in the balloon said, "I am. I'm an outstanding policymaker. I'm a leader. But how did you know that?" And the man on the ground said, "I knew that because you're in the same position you were when we met, you don't know where you are, you don't know where you're going, and now you're blaming me." Well, let me say that I spent nine years in government, five as director of the CDC, and as you've heard, four as surgeon general and assistant secretary for health, and I have to tell you, I would trade nothing for those nine years.

They were rich years. The people with whom I worked were special. So I am very excited about the role of government in dealing with a problem like obesity. Let me just say a few of the things I was involved in. In 1996, while director of CDC, we released a very interesting report on physical activity. It was actually released as a surgeon general's report, and basically what we showed in that report on physical activity was that there was a dramatic decline in physical activity among the American people, including schools no longer requiring physical education, K through 12. And so we expressed a lot of concerns about the sedentary lifestyles of American people and the implications of that.

In 1999, I represented the United States at a world conference on health promotion and disease prevention. And at that conference for the first time I released the surgeon general's Prescription which I'm sure many of you are familiar with, but among the things on that prescription was the recommendation for regular physical activity, at least 30 minutes a day, at least five days a week, but also a recommendation that the American people consume at least five servings of fruits and vegetables per day. There were other things on the prescription, even one having to do with mental health and the need to have some planned strategy for dealing with stress. We didn't really understand at that time the relationship between things like physical activity and depression, the fact that physical activity is a major intervention for reducing depression. Then in 2001, as surgeon general and assistant secretary for health, I released the surgeon general's Call to Action to Prevent and Reduce Overweight and Obesity.

That report, among other things, pointed out that between 1980 and the year 2000 there had been a tripling of overweight and obesity among children in this country and a doubling among adults. So we did sound the alarm, and even though I was former director of the CDC and we are very selective at what we call "epidemics," usually reserved for infectious diseases, we declared that overweight and obesity was an epidemic in this country. We didn't realize at that time that the same thing was beginning to happen all over the world. In that report of the surgeon general on overweight and obesity, we especially expressed concern about the changes in the maps throughout the country, where you could actually map the increase in overweight and obesity in various states, whereas in 1990, 15 percent was almost the high.

By the year 2001, it was 25 to 30 percent of the American people who were obese. What we know about overweight and obesity from a population perspective is very important, I think, to this debate because what we know is that it has increased dramatically, but also that it is clearly associated with an increase in chronic diseases, especially what we call Type II diabetes, or increases in what we call BMI, the way we measure body fat, directly related to an increase in Type II diabetes. And, as you know, Type II diabetes increases the risk for cardiovascular disease and even renal disease.

So we were concerned about what was happening in this country. We were concerned about the implication of these rising rates of overweight and obesity. We were also concerned about disparities. We have declared the goal of eliminating disparities in health in this country, especially among different racial and ethnic groups. And what we observed, of course, was that this epidemic was disproportionately impacting African Americans and American Indians. So, American Indians also have the highest rate of Type II diabetes. And African Americans have the highest mortality rates from Type II diabetes. So we were very concerned about the impact that this was having on eliminating disparities in health. We were also concerned about what was happening in children. I think this was really critical. What we found was that children, by increasing overweight and obesity, were now getting what we previously had called adult-onset diabetes.

We were seeing it in children. We were seeing hypertension in children. Pediatricians were expressing great concerns.

Thank you.

### Moderator
Claim: Dr. David Satcher, your time is up. Thank you very much.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Our motion is "Obesity is the government’s business.” And here to speak against this motion, John Stossel. He is host of the Fox Business Network program, known as Stossel. He has received 19 Emmy Awards. And prior to joining Fox, he spent over two decades at 20/20 on ABC News as an anchor and a correspondent. Ladies and gentlemen, John Stossel.

### Scientific Advocate (SA)
Claim: Thank you. I apologize for holding my hand up. I had hand surgery, and the doctor’s tell me hold it up so it doesn’t get inflamed, so I’m not saluting or doing anything weird like that. So, Dr. Satcher, I hear you and it’s a problem that people have less physical activity. And it would be good if we ate more fruits and vegetables.

And it’s terrible that more people have diabetes, but obesity is the government’s business-- that’s a separate issue. It’s a powerful assumption in that, but behind it is the assumption that everything good should be encouraged by government and everything bad discouraged. And at first that sounds like common sense, but everything is arguably, to some degree, helpful or harmful. So, this is a formula for totalitarianism. I mean, why is totalitarianism if not the view that everything falls within the purview of the state? Mussolini said that-- “everything within the state, nothing outside.” Okay, that’s over the top. I’m not saying that government is like a fascist regime, but it’s becoming just as invasive. It spent $3.8 trillion. It’s going broke. The philosopher Thomas Hobbes started using the term “Leviathan” to refer to a powerful central government to which we give up some rights.

And he thought Leviathan was a good thing. But he assumed that its function was protecting us from violence. He never imagined that Leviathan would plan our meals. And the founders of this country never imagined that. They started the country with this. This is the Constitution and the Declaration of Independence. Together it’s this thin. This is what they thought we needed, and this is what made America prosperous. Now, this isn’t everything we should have. We need pollution control rules. They didn’t think about that. But government has gone much further. We now have an agriculture department that spends $145 billion a year. Government runs public housing, a war on drugs, a welfare state. It subsidizes farmers and, by doing that, does harm, as Robert Rosenkrantz said, making people fatter. It runs school lunches. It subsidizes students, Indians, researchers, volunteers, small businessmen, rich businessmen, polices the world and polices our home and our jobs, our bedrooms.

And now food too? Well, yes. But if it weren't already doing all-- trying to do all that stuff and doing it badly, it could better do what it's supposed to, protect us from criminals and terrorists. And America wouldn't be going broke. But look, I have lost that argument. We libertarians have argued that we're in the minority. I understand that. Most of you disagree. Most of you want more government. You like the minimum wage. You like the EEOC to protect us against discrimination, Title 9 to protect us against gender discrimination, rules against sexual harassment language being used in workplaces, the ADA to protect disabled people, laws against prostitution and online gambling. And in the name of health and safety, you support laws requiring motorcycle helmets and OSHA to protect the workers, and the CSPC to protect kids from dangerous toys, and the whole alphabet soup of agencies that keep growing in Washington.

And my debate partner, Paul, he agrees with that. He says government ought to intervene in these areas. But even he says not obesity, because obesity is different, and government sucks at dealing with it. But he's the obesity expert. I'll let him explain that. All I know is that government keeps growing, and that is dangerous to our freedom. Now the president wants to spend another 300 million or so of your dollars to pay for his wife's healthy foods financing initiative. And of course, that's in addition to all the stuff we already have, the "let's move" campaign, the task force on childhood obesity, the school lunch program, the council on fitness and so on. What's the result of all that stuff? Since they created it, they spent a lot of your money on it, people are fatter than ever. And that's just what the Feds spend.

The states and localities spend even more. I mean, New York City now bans bake sales in schools. How much has that helped? My colleague, Mike Huckabee when he was governor of Arkansas, he required every school to measure every kid's body mass index. Dr. Satcher mentioned that. It's a measure based on the height-weight ratio. It's a terrible measure. I mean, BMI index says that George Clooney and Tom Cruise are overweight and Arnold Schwarzenegger is obese. It just mismeasures people, but it's required now in Arkansas. For every kid, they get a report card that doesn't just give their arithmetic score. It tells the parents what their BMI index is. The result? Well, I don't think it's helped them teach arithmetic because the teachers are distracted. But the kids are just as fat. It's made no difference in obesity in the schools. Some states say, we ought to have some taxes, taxes on bad food. And intuitively, this makes sense. Let's tax candy and, oh, then they'll eat less candy. They'll eat more fruits and vegetables.

So Illinois did that. Six percent tax on candy. But what's the result? It's just confusing. What is candy? They decide, okay, a Hershey bar is candy, but a Kit Kat bar, that's food because it's got flower in it. So this enriches the bureaucrats and the lawyers, but it doesn't help anybody lose weight. In New York City, the government requires calorie counts now to be posted in restaurants. And that makes sense. Information is good. So NYU did a study of that and found that, yes, adults say they were influenced by the calorie postings. But then they checked the receipts, and they found the people ordered slightly more calories. Government can't make us thinner. Government can't control our personal behavior in that way. And even if it could, we're spending $3.8 trillion going broke.

We couldn't afford to do this even if it worked. We don't need government to do this. There are only two ways to do things in life: voluntary or force. Government is force. We need some force to keep us safe. But voluntary is better. And voluntary abounds. We have plenty of diet information. All these diet websites, books on nutrition, TV shows like The Biggest Loser, diet gurus are celebrities. That's enough. We don't need government taking our money, and we don't need government force.

### Moderator
Claim: Thank you, John Stossel. So here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters arguing out this motion: "Obesity is the government's business." You have heard the first two debaters. And now to introduce our third. To debate in support of the motion that "Obesity is the government's business," here is WebMD's chief lifestyle correspondent, a professor of medicine at the University of Maryland and former Pew Foundation scholar in nutrition and metabolism, Dr. Pamela Peeke.

### Conspiracy Advocate (CA)
Claim: Obesity is the government's business. You hear from the opposing side that we're looking at a nanny state or food policing. Au contraire, that's not what we're looking for at all. Voluntary? We give you voluntary. That's what we're looking for. I wear many hats. I'm a physician first, and I hail from the front trenches, face to face with my patients and as chief lifestyle expert for WebMD's 90 million members, click to click with my cyber folks. This is where I practice high-tech touch. I set up a discussion group asking, is obesity the government's business? It lit up like Kyoto at nighttime. It was fabulous. The bottom line was, yes, obesity is the government's business for leadership, education, protection, options, opportunities, infrastructure.

No sidewalk, no walk. No park, no play. No bike path, lots of accidents. Bottom line, what they said was, "No blame, no shame. No tax, no bans." They drew a line in the sand. And Dr. Satcher and I agree with that. Obesity is the government's business.

I'm going to flip now to my public health hat. Government cannot solve the obesity problem alone. A problem as large as obesity, pun fully intended, requires all sectors of society to bring our thinking to the table. So I argue for government private sector partnerships. Shouldn't be just the government at all. When we initiate a voluntary campaign or an effort, we want to be able to offer people options and opportunities because if there is no choice, there can be no moderation.

We're in New York City. I love this place. And although you just heard that some of what you're doing isn't working so well, I say, forget all that. You have programs here, for instance, Mayor Bloomberg has joined with 500 other mayors with the "let's move cities and town" campaign to be able to work, drill down into the neighborhoods. What we can do to be able to improve physical activity as well as nutrition. In addition, the "fresh" program, food retailed expansion to support health programs. Say that three times. The food retail expansion to support health program has set up 14 supermarkets in food deserts. This was a private-public collaboration, a partnership that worked. We now have fresh produce out there. And that's really important.

Of course, we have so many other measures that have taken place. Good grief, we have play streets. We've taken quiet streets and turned them into play yards because we have nothing else out there. We're using what we can. We're doing what we can. At the national level, obviously we're looking at prevention now. The national prevention and health promotion strategy to stop disease before it starts. Million hearts campaign. Let's Move actually celebrates its second anniversary this month alone. And it's been reaching out to everyone from REI for outdoor, you know, to a beverage industry for clear on calories so you can begin to understand what's going on in those labels. Is it perfect? Absolutely not. Is it voluntary, and does it touch people's lives? Hell yeah. I'm on the board of America on the Move, and we're moving. We have corporate sponsors. We do private, public sponsorships all year long. We do this in neighborhoods, in states all across this country. We touch people.

Exercise is Medicine, I am their national spokesperson, a collaboration of the American Medical Association as well as the American College of Sports Medicine.

And here we see again trying to show people that there are simple, small steps, literally, that you can take to be able to help yourself, voluntary, nothing stuffed up your nose. We're not going to the tax and ban place. We're not food policing. We're reaching out asking people to hold our hand and say, come on. We can do this together. Is it sloppy? Yeah. Are we perfect? No. We're about as perfect as the people who create them and implement them. We're human. We're getting there.

I'm going to switch over to my last hat for my seven minutes as a researcher. Guess what? The National Institutes of Health is public funding. $32 billion to save your lives, to do the work we do.

It's interesting, when I began my work there as a senior scientist, I went to the clinical director's office, and above the office there was a sign that said, "In God we trust," and there was a little sign below it that said, "Everyone else must show data." Fairly straightforward. We wanted to see some good data here. And so in our laboratory we showed the connection between chronic stress for instance and the buildup of that toxic fat deep inside your belly which increases your risk for heart disease and diabetes. We showed for instance that it's not about ELMM, "Eat less, move more." That's so important, however, so much bigger. We forgot the mind. What about stress? New research has just been published showing that children who are stressed, and you know what that's about, in their childhood, at home, at school, eat more, and that's that stress-fat connection that we talk about so often. What are we doing about that?

We have a new science called, "epigenetics," we're trying to look at how we can literally change gene expression, how we turn on and off genes, by simply doing easy things like if I eat an apple every day on a regular basis I get that gene expression and therefore I'm able to what? Have an increased or decreased vulnerability toward obesity. Or I could just do what so many people do, that nocturnal ménage à trois every night, you know what I'm talking about, you, Ben, and Jerry. All together in bed watching the tube, hanging out, doing it. Doesn't work, all right? What's that gene expression looking like? All right. So here we're looking at something that's a brand new phenomenon, something we love to call "secondhand obesity." What we're looking at is virally, families, what's going on with them? How are we touching kids? It's so much bigger than demonizing sugar. It's so much bigger, so much bigger than saying the government's just too fat.

What we're saying is, putting our hand out, we're trying to say, "Educate, bigger brain, better choices, obesity is the government's business."

### Moderator
Claim: Thank you, Pamela Peeke. And that is our motion, "Obesity is the government's business." And now here, our final debater against the motion, Paul Campos. He is professor of law at the University of Colorado in Boulder, and author of "The Obesity Myth: Why America's Obsession with Weight is Hazardous to Your Health."

### Scientific Advocate (SA)
Claim: Thank you. I think that the fundamental difficulty here is that, despite the great courtesy of the organizers of this debate to invite me, I'd like to start by pointing out that this debate is framed in completely the wrong way. To have a motion that says, "Obesity is the government's business," essentially begs the question because using the term "obesity" frames the debate as one which is about the supposedly pathological state of people who have a body mass index of about 30 if they're obese or above 25 if they're overweight.

And that in itself essentially tells us that we ought to think about those states as being per se bad and in fact a diseased or a quasi-diseased state. Imagine if this debate were framed as, "Eliminating body diversity is the government's business." I think that would sound a lot different, but in point of fact there is really-- there is no practical distinction between those two motions. The assumptions at work here are that a narrow range of body weight is normal for human beings and that outside that range a variation is the product of poor lifestyle. Furthermore, it's assumed in the framing of this issue that by reforming poor lifestyle either voluntarily or quasi coercively, you can eliminate abnormal body weight. This is all wrong.

There's nothing normal about normal body weight. It's not normal statistically. It's not normal epidemiologically. The overweight category of BMI 25 to 29.9 does not, in fact, feature increased overall health risk, so there isn't even a correlation there between increased health risk and the pathologizing of that body state. The vast majority of people, and I'm going to say this about 27 times tonight, cannot intentionally modify their body mass in a long term fashion successfully. There is no better established proposition empirically in all of medicine than that. In other words, people, as you all know-- well, I shouldn't say "all of you," but many of you know from personal experience-- find it extraordinarily difficult to change their body weight in a significant long term way voluntarily. Government intervention in this area, and my partner, John Stossel is quite correct in saying that.

In comparison to him, I am almost a Stalinist in my enthusiasm for government intervention, although I think he did overstate a couple of my positions. I won’t get into those because that’s beside the point. But in fact, even though I am generally enthusiastic about various forms of government regulation that fill him with dread, I am in fact utterly opposed to government regulation in this area because I think government-- the same as-- obesity as government’s business is almost a kind of dream scenario for a Libertarian. Because a Libertarian could not come up with a better example of government dysfunction than of the notion that we’re supposed to make people thinner, mainly because-- well, for a bunch of reasons, which I want to go through quickly right now and then come back to later.

Here I want to emphasize first of all that we do not know an enormous number of things that we would have to know if we were going to have a rational policy that was based on the notion that we were going to make everybody have a BMI between 18.5 and 24.9, the so-called normal range, which for an average height woman would be between 108 and 144 pounds, outside of that supposedly pathological. Here’s what we don’t know. We don’t know how to produce significant long-term weight loss. We just don’t. We don’t know if such weight loss would be beneficial. This hypothesis has not been tested for the very good reason that since we don’t know how to produce it, we can’t test the hypothesis. We don’t know to what extent, if at all, the generally weak associations between obesity and increased health risk are products of a causal relationship as opposed to markers for other things like, for example, dieting, weight cycling, diet drug use, eating disorders, stress, stigma, and lower socioeconomic status. We don’t know why weight went up among Americans in the 1980s and ‘90s. We don’t know why it was stable in the 1960s and ‘70s. We don’t know why it has plateaued over the course of the last 10 years.

We don’t in fact know whether people are more sedentary today than they were 40 years ago. We just don’t have the data on that. We just have a few very indirect markers for that, such as the amount of mandatory gym periods in school, but we don’t have any direct measurement of how active people were 40 years ago. We don’t know whether people consume more calories today than they did 40 years ago. Again, the data is not available. People often-- you know, when that’s pointed out to them rather rudely by someone like me, the reaction of public health officials tends to be something like, “Well, it’s just common sense,” right. But see, common sense is what you invoke when you don’t have data, right. That’s why we have these academic institutions, right, so that we don’t just rely on common sense. We actually try to have some evidence for our propositions. Here’s what we do know. We do know that public health interventions designed to produce weight loss do not produce weight loss. This hypothesis has been tested.

It’s been tested in situations where we have had intense public health intermediations that are much more intense than those that we could produce on a population-wide scale. And those interventions do not produce weight loss, either in adults or children. We do know that labeling bodies as diseased is stigmatizing, and we know that stigma is very bad for health, as are stress, weight cycling, and eating disorders, which are other things that are produced by this kind of labeling. We do know that risk factors that are associated with obesity, like, for instance, hypertension, can be addressed cheaply and successfully through inexpensive drugs that work quite well and increased physical activity, which is beneficial for people of all shapes and sizes whether in fact it produces any weight loss, which it usually doesn’t. Finally, what I really would want to emphasize here above all is that healthy lifestyles don’t eliminate body diversity, which is found among people with a wide variety of body types, many of whom fall outside the phony, so-called normal range.

And so, what I would advocate more than anything else is that we ought to focus on a harm reduction, not weight reduction. We’ve already had some indications tonight of the notion that we don’t want to stress people. Here’s a suggestion. Stop telling them that their bodies are pathological because that’s very stressful. That’s not good for people. And if you say that you don’t want to stigmatize obese people but you just want to stigmatize obesity, I would suggest that that is a protocol that’s not going to be successful. Thank you.

## Round 2

### Moderator
Claim: Thank you, Paul Campos. And that concludes round one of this Intelligence Square U.S. debate. And remember, we had you vote in the beginning, and we’re going to ask you to vote again at the end. And the team whose numbers have changed the most will be declared our winner. Now, onto round two where the debaters will address each other directly and take questions from me and from you in the audience and from Slate readers who have submitted questions and from people watching on ForaTV, we have two teams of two here arguing out this motion: "Obesity is the government's business."On one side, arguing in support of this motion, David Satcher and Pamela Peeke. They are arguing that we have a national emergency underway, a record of weight gain among Americans that threatens to bankrupt the health care system and to break the health of those who are obese, but they also offer hope in the role of government as-- in its ability to offer leadership and protection and infrastructure in support of the actions of those individuals who do want to lose weight. The side arguing against includes John Stossel and Paul Campos. They are arguing in a two-pronged attack. One is, they're basically saying the research is wrong that says that obesity is killing us. And the research is wrong that suggests that we even know how to lose weight. They're also saying basically that whenever Uncle Sam attempts to govern the health of an individual, Uncle Sam always gets it wrong.

So there's a lot to talk about there and a lot to explore. And I want to go first to the side arguing in support of the motion. What your opponents have left hanging out there repeatedly is the notion that government's track record already is terrible, that over the last 20 years, 30 years, as government programs have been put into place, we've just gotten heavier. So take that on. What-- what is the evidence that in fact government can have an impact on obesity of individuals? David Satcher.

### Conspiracy Advocate (CA)
Claim: Well, I think the evidence is related to several things. First, we had a very interesting study funded by NIH in the late '90s, early part of this 2000.

And basically showed that if we could get people to be physically active and to change their diet, even if they lost only five to 15 percent of their weight, we could dramatically decrease the risk for diabetes, in fact almost 60 percent reduction among African- Americans and American Indians in the onset of Type II diabetes, by getting people to change their lifestyles and to be more physically active and to consume diets with less saturated fats and sugars. So I think we do know, from that study, that it's possible to help people change lifestyles. And I did say help because Pamela is correct, there are a lot of people in this country who do not have access to healthy lifestyles. And it is in fact a responsibility of government to make sure that everybody has the opportunity, everybody has access to the opportunity for healthy lifestyles.

### Moderator
Claim: But the point of the question goes not just to the theory behind it, but the track record of the government.

### Conspiracy Advocate (CA)
Claim: The track record that I mentioned was the one dealing with African-Americans and American Indians in terms of reducing--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --the risk for diabetes mellitus.

### Moderator
Claim: Let me go to the other side. Paul Campos, would you like to respond?

### Scientific Advocate (SA)
Claim: Yes. In fact in that study--

### Moderator
Claim: Paul, can you move just a touch closer to your mic?

### Scientific Advocate (SA)
Claim: Yes, right. And it's a study that Dr. Satcher was citing there, there was an average of 2.3 kilograms of weight loss, which is about four pounds. The difficulty with citations to the notion that a small amount of weight loss is going to greatly reduce the risk of Type II diabetes is that a couple things, one, you can't-- you cannot disentangle the amount of weight loss that is produced, which is generally quite small, from the beneficial effect of the lifestyle intervention. The way that you would want to test that, to say, well, let's look at the people who've lost weight and compare them to the people who didn't lose weight if they all engage in the same lifestyle intervention. Is there a dose response that is related to the weight loss? And the answer is no, there isn't. In those studies, the people who engaged in the same lifestyle changes but didn't lose weight had the same reduction, on average, in Type II diabetes risk as people who engaged in the lifestyle changes and did in fact lose some weight.

So to me, that's really compelling evidence for the notion that focusing on weight in that context doesn't make any sense. I'm all for focusing on, you know, lifestyle changes. I think it's good to encourage people to be physically active. But there's a lot of evidence that physical activity in and of itself is beneficial. But what there's not evidence of is that either physical activity changes are going to produce significant long-term weight loss. Again, they don't in the vast majority of people, or secondly, that the weight loss is necessary for the purposes of getting the benefits of the increase in the--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --in the activity levels.

### Moderator
Claim: I want to go to Pamela Peeke. You're on the side with the two doctors. Your opponents are basically saying-- they're blowing up conventional wisdom here--

### Conspiracy Advocate (CA)
Claim: Mm-hmm.

### Moderator
Claim: --by saying this-- you're not quite saying it, but you're suggesting, Paul, that there's not a whole lot of point in reducing your calories and exercising more if your goal is to lose weight.

And that just flies in the face of everything that even you stand for in your work, Pamela. So take that on.

### Conspiracy Advocate (CA)
Claim: I will be more than happy to take that on. Apparently Paul is not aware of the national weight control registry. This is an ongoing study, almost 20 years old, which has been sponsored by the University of Colorado as well as Brown University, my colleagues, Dr. James Hill and Rena Wing. The cohort right now is over 10,000 people, including people who have bariatric surgery as well. And these people are known as the successful losers. And actually, Paul, you actually are too, because of your own weight loss as you noted in your book. You qualify because you had to have dropped at least 30 pounds and kept it off for at least a year. And the grand majority of these people have kept off approximately 60 pounds for almost six years or longer. And this is on the average in a very large cohort. So are these mutants?

Freaks? What are they? These people have determined that they will keep this weight off by utilizing very simple things. And this has been published in extensive literature. One of the most interesting things we found was that the number one predictor for being able to keep weight off and do this well is to have a healthy breakfast every morning. They are physically active. Are they part of the Olympic camp? No. They basically get out. And the number one favorite thing to do is walk. And in most of the government interventions, all we're asking people to do is not drop weight so much. That's not where we're going. Losing weight, I'm a physician. People lose weight and do really stupid things to lose weight. That's not where we're going.

### Moderator
Claim: So you're talking--

### Conspiracy Advocate (CA)
Claim: We're going to health.

### Moderator
Claim: You're talking--

### Conspiracy Advocate (CA)
Claim: We're going to health, and we're going to fitness.

### Moderator
Claim: Pamela.

### Conspiracy Advocate (CA)
Claim: And that's what we saw in this study.

### Moderator
Claim: So you're emphasizing information, encouragement and education.

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: I want to ask John Stossel, what's wrong with the government through schools emphasizing education information and encouragement?

### Scientific Advocate (SA)
Claim: Because Pamela said that's all voluntary and talked about public-private partnerships being voluntary. But government isn't voluntary. It said we have a voluntary tax system. But try not paying your taxes and see if it's voluntary. Men with guns will come and make you pay for the dumb programs that they keep creating that don't work and that Paul says make people miserable. And keep growing.

### Moderator
Claim: But John, what would be the harm of-- of spending money in a school to put this on the curriculum and keep it on the curriculum?

### Scientific Advocate (SA)
Claim: Because the schools can barely teach reading, writing and arithmetic.

### Moderator
Claim: David Satcher.

### Conspiracy Advocate (CA)
Claim: Well, I think a couple of things. The goal of these programs is to help children develop lifetime habits of physical activity and good nutrition.

We also know, by the way, that children who develop good eating habits and regular physical activity do better academically. They perform better on standardized exams in math and reading. They are more disciplined in school. So the benefits of healthy lifestyles go far beyond losing weight. Now, Paul quoted the statistics about weight loss versus decrease in diabetes. The goal is to decrease fat. And sometimes you can decrease fat and increase muscle and not lose weight. But you still reduce the risk of diabetes. I think you know that as a runner.

### Scientific Advocate (SA)
Claim: So let them learn that from Pamela's TV show and from Richard Simmons. We don't need government.

### Conspiracy Advocate (CA)
Claim: Excuse--

### Conspiracy Advocate (CA)
Claim: Here's the problem.

### Moderator
Claim: Pamela Peeke.

### Conspiracy Advocate (CA)
Claim: Yeah, that's nice for people who do have cable TV. Unfortunately, many people don't have Discovery Channel. So for those poor people out there who have no access, what are you going to do? You just assume they're going to catch it on the tube. Oh, no. You're not supposed to be watching TV because if you watch TV too long, you get this big.

So, I mean, you're going round and round. Why not just sit there? Why not do what Alice Waters did in Berkeley, the Martin Luther King middle school? She built a garden. She had the kids grow stuff.

### Moderator
Claim: All right. Paul Campos.

### Conspiracy Advocate (CA)
Claim: Kids who grow and eat it.

### Moderator
Claim: Paul Campos. Again, just--

### Scientific Advocate (SA)
Claim: Well, I just-- I love Alice Waters' cooking, I'll tell you. I think it's awesome. But I think her social policy is rather questionable because she wants everybody to be like they're an upper class white woman in Berkeley. And that's just not going to happen, right, for all kinds of reasons. Now, what I'm going to emphasize here is that the government's theory seems to be something along the lines of, people are fat because they have not been given the information that it is more desirable in this culture to be thin rather than to be fat. I don't think that's correct. I think this information is-- is not exactly a state secret. It's been widely disseminated.

### Conspiracy Advocate (CA)
Claim: Well, let's be clear, though.

### Moderator
Claim: David Satcher.

### Conspiracy Advocate (CA)
Claim: It's not the information. It's the opportunity to act on it.

I think what Pamela described in terms of in the inner cities of the country—you don't have sidewalks, you don't have safe places to be physically active, you don't have access to grocery stores, so what you're talking about is the opportunity--

### Conspiracy Advocate (CA)
Claim: That's absolutely right.

### Conspiracy Advocate (CA)
Claim: --to leave--

### Moderator
Claim: Tell me the government's role in creating those opportunities. Are you literally talking about building sidewalks,

### Conspiracy Advocate (CA)
Claim: Yeah, in some--

### Moderator
Claim: The government--

### Conspiracy Advocate (CA)
Claim: Look at what Louisville did. It changed the zoning laws so that within so much area you had to have grocery stores and you had to have parks and playgrounds, so the government can, in fact, produce the opportunities for people to have access.

### Moderator
Claim: Did people lose weight in Louisville when that happened?

### Conspiracy Advocate (CA)
Claim: Well, I think it's too soon to say they lost weight but they clearly increased healthy lifestyle, but, believe me, the fixation on weight is not ours.

### Scientific Advocate (SA)
Claim: Oh, really?

### Conspiracy Advocate (CA)
Claim: The fixation here is on healthy lifestyles.

### Scientific Advocate (SA)
Claim: What was your report called, Dr. Satcher, your 2001 report? Was it a report on healthy lifestyles?

### Conspiracy Advocate (CA)
Claim: No, the first ever surgeon general's report was on smoking and health and it was on cancer, but that wasn't the focus. The focus was on getting people to stop smoking.

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Scientific Advocate (SA)
Claim: So are you in favor of getting people to stop eating?

### Conspiracy Advocate (CA)
Claim: Getting people to stop-- getting people to eat-- to engage in healthy lifestyles.

### Scientific Advocate (SA)
Claim: Well, I'm all for engaging in healthy lifestyles, but I'd like to point out that--

### Conspiracy Advocate (CA)
Claim: That's the role of government.

### Scientific Advocate (SA)
Claim: --one of the most interesting things about this debate is that if you had a time capsule, everything that's being said by the advocates of the government's position here was said almost literally word for word in the 1950s. Remember-- some of you may remember-- President John Kennedy-- I don't remember it actually, but I've read about it-- initiative for the president's council on physical fitness, right?

### Scientific Advocate (SA)
Claim: I remember that.

### Scientific Advocate (SA)
Claim: John remembers it, right?

### Moderator
Claim: I remember that, you had to throw a softball 100 yards and do pushups--

### Scientific Advocate (SA)
Claim: That's right, all that kind of thing, you know, that we're all and, you know, for being healthy in that way. John Kennedy was actually a wreck physically but they hid that quite successfully at the time because-- but anyways, that's another story.

The thing is, it's really striking, if you looked at the literature, the government officials were saying in the 1950s the same thing they're saying today, they're saying, "Americans are getting horribly fat, and it's going to cause this huge health crisis, and if we don't do something about it, the Russians are going to just come in and push us over and takeover--" "-- and it's, you know, the terrorists within," and all that stuff, and nothing that was ever predicted took place. But this is one area I have found in terms of government policy and social hysteria and moral panic where data simply doesn't move anything because people have such a fixation with the desirability of weight loss that you can talk all you want about how we ought to have healthier lifestyles, but what people really want to do is make people thin.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: No, we don't want to make people thin.

### Moderator
Claim: Pamela for just one second.

### Conspiracy Advocate (CA)
Claim: We don't want to make people thin. And I don't know where this came from. Apparently there's a fantasy land going on over there. "Thin" is a four-letter word, okay? I don't know what it means.

All we care about is healthy and fit. Come on. Let's get real here for a minute. Fifty years ago, if you were 10 or 15 pounds overweight it was a crisis, you know, you couldn't get out of your size four, whatever. Today I'm a physician and I don't make fun of this stuff. I'm a compassionate physician because I have people sitting in front of me and they're in pain. And do you know what? They don't have 15 to 20 pounds to drop. They have 100 and 150. It's changed. It's changed from 1950. And I'll tell you what, they'll never get within spitting distance of an ideal body weight, so you know what I do today? I've changed the game. I think it's head south, just start moving down, five percent, 10 percent, pick up healthy lifestyles, small steps here. That's all you need to do.

### Moderator
Claim: But, Pamela, what does that have to do-- what does that have to do with the government's being--

### Conspiracy Advocate (CA)
Claim: It has everything to do with the government--

### Moderator
Claim: Make the case.

### Conspiracy Advocate (CA)
Claim: --because they don't have resources. Where are the play yards? Where are the parks? Where are the bike paths?

### Moderator
Claim: Okay. Let me take that to John Stossel. Let me just take that to John Stossel.

### Conspiracy Advocate (CA)
Claim: I just want to say, though--

### Moderator
Claim: We haven't heard from him. All right, go ahead, very quickly.

### Conspiracy Advocate (CA)
Claim: It would be very interesting to find these studies that Paul is quoting saying that obesity was a major problem in the '50s. There's no such study. We looked at every--

### Scientific Advocate (SA)
Claim: Forty percent of the American population was, quote, unquote, "overweight," in 1958, 40 percent, so apparently if there's been an epidemic, we've had an epidemic for a long time.

### Conspiracy Advocate (CA)
Claim: But overweight-- I want to be clear about "overweight," because I know you've written, saying that people who are overweight are healthier. Many people who are overweight are athletes who are muscular or people who work out, so we admit it in our books, we acknowledge that the BMI is not reliable in people who are muscular, who are athletes, and who work out. So I think that's a distortion.

### Moderator
Claim: John Stossel, I've been asking the other side for specifics on what the government can do. They're talking about building parks, playgrounds, sidewalks, to give people the chance to get physically fit, particularly in communities where we know those things are at a deficit. Take that on.

### Scientific Advocate (SA)
Claim: My understanding is that there are just as many or more parks, playgrounds and sidewalks as there have ever been. People can exercise if they wanted to. And John, you talked about they’re responding to this national emergency. That’s the justification for government, and I think you’re right. And that always is. The crisis is the friend of the state. But there-- the specialists always have emergencies. It’s terrorism or global warming or Y2K. Remember, the planes were all going to crash, and the killer bees were coming up from Mexico, were going to sting us all to death, and Bird Flu and plastic bottles. It’s endless. It all requires government to intervene, to raise your taxes and to limit your freedom.

### Moderator
Claim: Pamela Peeke. John says there’s plenty of sidewalks and parks.

### Conspiracy Advocate (CA)
Claim: John. John, where the hell do you live?

### Scientific Advocate (SA)
Claim: Right here in New York City.

### Conspiracy Advocate (CA)
Claim: Honey, listen, get out of New York-- get out of New York and live, right. Go out to the hinterland. Go out to places where people don’t have these--

### Scientific Advocate (SA)
Claim: The hinterland is one big park.

### Conspiracy Advocate (CA)
Claim: Very seriously, John. I mean, really, what we’re looking at is the ability to be able to give people options. We keep telling people to go out and do whatever. Eat less, move more. You give them food deserts. You don’t give them anywhere to move that’s safe. And then what do you have? Where is that obesity? Do I see a lot of obesity out here? I don’t think so. Again, go to the hinterland. John, keep looking. It’s up there somewhere.

### Conspiracy Advocate (CA)
Claim: You don’t have to go to the hinterland. There are many areas in this city and surrounding cities where it’s not safe to get out and walk in the street. It’s not safe. There’s no safe place.

### Scientific Advocate (SA)
Claim: It’s safer than it used to be. Crime is down.

### Conspiracy Advocate (CA)
Claim: I’m sorry.

### Scientific Advocate (SA)
Claim: It’s safer than it used to be. Crime is down. And obesity is up.

### Conspiracy Advocate (CA)
Claim: And it’s down in great part because of the same leadership that’s now saying that we’ve got to change the way we direct food to people.

### Moderator
Claim: I want to move a little--

### Conspiracy Advocate (CA)
Claim: We’ve got to intervene to make sure that people know what they’re eating.

### Moderator
Claim: I want to move to another part of the argument that Paul Campos has put out there, where he’s basically challenging the scientific underpinnings of the argument that you’re making. I mean, Dr. Satcher, you said that you’ve talked about-- you’ve discussed the association between obesity and diabetes. You didn’t-- causation-- you said an association. But Paul Campos, you’re saying that even that association doesn’t exist.

### Scientific Advocate (SA)
Claim: No, the association exists, but the relationship is complex, right. I mean, the notion-- do we know that diabetes causes obesity? How do we know that obesity doesn’t cause diabetes?

### Moderator
Claim: Do we know?

### Scientific Advocate (SA)
Claim: Right, we-- in other words--

### Conspiracy Advocate (CA)
Claim: We don’t know-- we don’t know the cause of breast cancer. That doesn’t mean we don’t screen for it. We do know the association.

### Scientific Advocate (SA)
Claim: Well, yeah, but David, I don’t think--

### Conspiracy Advocate (CA)
Claim: In public health, we deal with associations.

### Scientific Advocate (SA)
Claim: Do you want to just perform mastectomies on women who don’t have breast cancer so they can avoid getting breast cancer?

### Conspiracy Advocate (CA)
Claim: I don’t get the connection.

### Scientific Advocate (SA)
Claim: The connection is--

### Conspiracy Advocate (CA)
Claim: Okay, Paul, Paul.

### Moderator
Claim: Pamela Peeke.

### Conspiracy Advocate (CA)
Claim: Whoah, whoah, whoah, whoah, whoah. In our laboratory, in the laboratories of many of our esteemed colleagues around the country, we’ve made it very clear that excessive visceral adiposity, a lot of fat deep inside your belly, is highly associated with a pro- inflammatory state, which increases the risk of diabetes, coronary vascular disease and cancer, period. I have that much literature to back up.

### Scientific Advocate (SA)
Claim: Yes, that’s right.

### Conspiracy Advocate (CA)
Claim: And you know what? You can get rid of visceral body fat--

### Moderator
Claim: Paul, let her finish.

### Conspiracy Advocate (CA)
Claim: In addition, Paul, the information that you presented showing that overweight is okay by me is actually wrong. And that has been refuted by at least two pooled meta- analyses publishes in Lancet and the New England Journal of Medicine by my colleague, Dr. Walter Willett from Harvard and by leading epidemiologists around this country basically refuting your--

### Moderator
Claim: Okay, let’s-- great. Paul, go ahead.

### Scientific Advocate (SA)
Claim: Yeah, well, first of all, visceral body fat can be very effectively dealt with through changes in activity levels. It’s not going to--

### Moderator
Claim: But are you conceding that there’s a relationship between visceral body fat and--

### Scientific Advocate (SA)
Claim: There is a correlation between visceral body fat and increased health risks. That’s quite true, but the notion-- look, again, I want to emphasize the willingness to talk out of both sides of the mouth on this issue is just astonishing to me. You have people coming here and say obesity, obesity, obesity, right. We have this huge crisis. And then I point out this is a bunch of nonsense. And then it gets flipped around into, “Well, we’re not really talking about obesity. We’re talking about lifestyle.” This isn’t called, you know, “Is lifestyle the government’s business?” This doesn’t have a picture of a lifestyle on the front of it, right.

### Moderator
Claim: David Satcher.

### Scientific Advocate (SA)
Claim: It has a picture of a--

### Moderator
Claim: Come on, just wait a moment. David Satcher.

### Conspiracy Advocate (CA)
Claim: Now, let’s be fair. Obesity is an outcome, in many cases, of unhealthy lifestyles. It’s not that simple. We differ in terms of metabolism. There’re some people who can eat a lot of calories and not gain a lot of weight. There are other people who gain weight easily. So everybody’s not equal.

We’re not stigmatizing people who are obese. Read the surgeon general's report, clearly says this is not about appearances. It's about health. And the way to improve health is to change lifestyles. That's what the report says.

### Moderator
Claim: All right. I'd like to go to the audience for some questions now. And reminding you of the point I made earlier. We'd like you to be terse, on point, a question that leads us to the discussion of government involvement with this issue of obesity and to really make it a question. And there's a gentleman right in the middle. Yep. I pointed to you. And if you can stand and state your name, and try to follow the rules.

### Moderator
Claim: My name is Mel Zolkins First, one sentence statement. The function of our government-- one of the functions is to promote the general welfare, unquote. So now the one sentence question to Mr. Stossel is, what does that mean to you?

### Moderator
Claim: Wait. Wait, wait, wait. Wait. Wait. Stand up. I-- I'd like you to-- we can get John Stossel going way off on this one. And I'd like you to focus that question more to the topic if you can. And I think you can probably do it with four or five words. So give it another shot.

### Moderator
Claim: I'll leave that up to you.

### Moderator
Claim: All right.

### Moderator
Claim: You know what I have in mind, obviously.

### Moderator
Claim: All right. But it would be so charming if you said it.

### Moderator
Claim: You can say it better.

### Moderator
Claim: John Stossel, the gentleman is asking whether you feel that the government's responsibility for the social welfare includes the health of the individual. Do you-- and your opponents have talked about the enormous amount of government money that's spent on funding research that is saving people's lives. That costs money. That's taxes. Looks like it has a benefit. Is that the government's business?

### Scientific Advocate (SA)
Claim: Well, they mention the NIH and basic research. And there is a better argument to be made that that does promote the general welfare.

But if the general welfare means the obesity police or the lifestyle police, then there is no limit to what government can do. Then they can reach into every crevice of your life. They can ban the dinner you're about to have. They can ban fat--

### Moderator
Claim: John, really?

### Scientific Advocate (SA)
Claim: --and ice cream.

### Moderator
Claim: I mean-- I need-- this as a neutral journalist. I need to know what you're talking about when you talk about the--

### Scientific Advocate (SA)
Claim: You used to work at ABC. You can't be a neutral journalist. Sorry.

### Moderator
Claim: I know. I know, I need to be more fair and balanced, John. But-- John, I just want to know, when you're talking about these police telling us what we can eat for dinner, where is this-- you know, I know you're talking about a slippery slope. I can see that. But where-- be more detailed about this fear. I mean, where do you see this happening? You're talking about in terms of-- the discussion of soda taxes, issues like that. Is that what you're talking about happening?

### Scientific Advocate (SA)
Claim: Well, that's part of it. I mean, Thomas Jefferson said it's the natural progress of things for government to grow and liberty to yield.

Government always grows. It starts with information. It moves to taxes. Then it moves to limits on what you can consume. And now that we have Obama care and the government says we're going to pay for your health care, then that's an argument to say, we have the right to have exercise police come into your home and make you improve your lifestyle.

### Conspiracy Advocate (CA)
Claim: You start off by quoting--

### Moderator
Claim: David Satcher.

### Conspiracy Advocate (CA)
Claim: --Lincoln, so I'll quote Lincoln who said that it is the role of government to do for people what they cannot do for themselves. And that's what we're talking about here.

### Scientific Advocate (SA)
Claim: People can't lose weight for themselves?

### Conspiracy Advocate (CA)
Claim: Not if they don't have safe places to be physically active, not if they don't have access to fresh fruits and vegetables.

### Conspiracy Advocate (CA)
Claim: And they can't be biggest loser because they don't own a TV.

### Moderator
Claim: Another question from the audience.

### Scientific Advocate (SA)
Claim: Well, that's going to be helpful.

### Moderator
Claim: Sir? Oh, I meant a little farther back. Striped sweater. Thanks. If you don't mind stating your name.

### Moderator
Claim: My name is Noam Gerber.

And I was curious how would you respond to the idea that the government's role is to protect the collective rights of the citizens which overarches the protection of every one of our individual rights, and that the increase in obesity which represents that bridge represents a threat to our society, for example, the increase in rising costs of Medicaid which we all have to put a-- which we all have to contribute to.

### Moderator
Claim: Okay. So I want to say that John really just answered the first part of your question, I think in terms of overall responsibility. But you're asking about whether-- whether in fact we're looking at a cost benefit between obesity on the one hand and the costs of treating people who would be ill with the diseases that this side is talking about. Am I right? So I want to take that to Paul Campos.

### Scientific Advocate (SA)
Claim: Well, couple things. First of all, if you're concerned about rising medical costs, which you would be in favor of if you believe that obesity kills people, then much obesity is possible because what drives medical care costs through the roof is an aging population, all right?

That's where the health care costs get spent, right? In an elderly population, supposedly obese people are all going to die before they get to be old, right, which is, of course, nonsense. But if you really did believe that, that's what would drive down health care costs. Secondly, and I think more fundamentally-- and I just want to repeat this again. We cannot make fat people thin, okay? So even if it was desirable from a social perspective to produce a society that did not have a lot of fat people in it, you cannot do that in a developed economy, right? We have a situation in this country where we somehow got it into our heads that everybody can be within a certain narrow range of body mass if they have a healthy lifestyle. That's-- there's absolutely no reason for believing that that's true or that it's in any way necessary. So I mean, I'll tell you what, you know what really would reduce health care costs more than anything else? I can do a back of the envelope calculation right now. We can reduce healthcare costs by $1.7 trillion a year out of the 1.9 trillion that we spend by just having everybody be between the ages of 20 and 29. would drive health care costs down to the floor, right? But nobody is suggesting that we do that. And this is the same thing. It's suggesting that we have a population that is going to be completely above--

### Moderator
Claim: Okay. Both your opponents want to speak.

### Conspiracy Advocate (CA)
Claim: That's a great question--

### Moderator
Claim: David-- David Satcher.

### Conspiracy Advocate (CA)
Claim: --that you raise. Let me just say that 80 percent of Medicare costs-- and Medicare is the most expensive program that government supports in terms of health. 80 percent of their costs are due to preventable diseases. And certainly, half of that is related to obesity and Type II diabetes. There's no question about it. So it is true that the government has a self-interest to try to help people to develop healthy lifestyles. And we're not even talking about obesity. We're talking about the benefits of healthy lifestyles generally. Less diabetes mellitus, which is a major driver of costs of Medicare and other health programs.

### Conspiracy Advocate (CA)
Claim: Can we quit saying that we're trying to aim for turning fat people into thin people? This is-- just end it now, please.

### Moderator
Claim: Well, Pamela--

### Conspiracy Advocate (CA)
Claim: This is ridiculous.

### Moderator
Claim: But Pamela--

### Conspiracy Advocate (CA)
Claim: We're going for healthy, and we're going for fit. We don't want life spans. We want health spans. We want the highest quality of life we can have. And if you started out at 250 pounds, and you're a 5'4" woman, and right now you're 180 and a happy camper, God bless you. So long as you're fit and happy. And we're also forgetting the head in this whole thing too. We're not science fair projects here. We forgot our heads. The stress factor here, of course we talked about stigma. No one wants to stigmatize. I'm a physician. I see this every day. I feel that pain and that-- and I feel that compassion as I try to help someone go south from 250 or whatever. What we're going for is health--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --and fitness.

### Moderator
Claim: All right. I'm going to stop you because I think you made your point on that. No, no, no. I-- I didn't mean that at all that way. I was going to ask for clarification. What are you looking for when you say it's not to get from heavy to thin, and you did answer it. In the third row here, just down front.

### Moderator
Claim: Hello. My name is Jennifer Sogus I'm an urban planner, and public health researcher here in New York City at transportation alternative. And I come from a school of thought that I appreciate Dr. Peeke that you spoke to a play street such as one of my signature programs at Transportation Alternative. I come from a school of thought that has proven that when people do not have access to playgrounds and sidewalks and bike lanes, that they are less physically active and that they are more overweight. So my question pertains to a particular piece of legislation on the table right now around transportation funding which, as written, prohibits federal funding from being spent on walking and biking and transit infrastructure. So my question to all of the panelists is, what is the role of government in funding or not funding things that encourage or discourage people from being physically active?

### Moderator
Claim: I'd like John Stossel to take it on first.

### Scientific Advocate (SA)
Claim: I don't understand what you're talking about. The highway trust fund is already taken from drivers who pay the gas tax. And something like 20 percent of it is used for things like bike paths. So it's already being spent on these things. Our government is spending $3.8 trillion. You want them to build grocery stores now? I mean, government can't even count the votes accurately, and you want them to fix lifestyle problems? This is a mistake.

### Moderator
Claim: Let's go to David Satcher.

### Conspiracy Advocate (CA)
Claim: Well, I think we ought to be clear. You know, we are the government, and it is the role of government to create the conditions in which people can be healthy. That's how we define public health. That's how the Institute of Medicine defines public health. It is the role of public health to create the condition.

It's a collective effort to create the conditions in which people can be healthy. And that's what we're talking about.

### Scientific Advocate (SA)
Claim: But aren't there more opportunities to be healthy now than ever before? Per capita income, a bicycle is cheaper than it used to be. There are more soccer leagues than there ever used to be. There's more awareness of physical activity.

### Conspiracy Advocate (CA)
Claim: Oh, I'm so sorry, did you forget about the fact that in the grand majority of schools across this country physical education is all but eliminated, it's gone?

### Scientific Advocate (SA)
Claim: Well, let's get rid of government schools--

### Conspiracy Advocate (CA)
Claim: And so we have--

### Scientific Advocate (SA)
Claim: --and we'll have better school.

### Conspiracy Advocate (CA)
Claim: --and then in addition, John, in addition, John, for soccer, I'm sorry, that costs money. You have to have money to buy those soccer clothes. You have to have money to join the league. And those kids don't have it. So let's just see now. We eliminated recess. We don't have physical education. And now we don't have after school. And where do they go? To the tube, they just sit there.

### Scientific Advocate (SA)
Claim: I just have to disagree--

--New York City any kid can join a soccer league and if he doesn't have money the equipment will be given free. There's plenty of charities around to pay for that.

### Conspiracy Advocate (CA)
Claim: Let me remind you that schools are supposed to be the great equalizers in this country. In other words, kids come to school, some of them come from communities where they have adequate places to play, access to fresh fruits and vegetables. Other children come from homes where there's no place to play safely, no access to fresh fruits and vegetables. At school at least they should be helped in developing lifetime habits of physical activity and good nutrition.

### Moderator
Claim: I want to go to another question, but I want to tell folks who are in the darker area that I can't see you and the same is true on the sides, so if you want to ask a question you might take a stroll down toward the front. In the-- I'm pointing-- yeah, yeah.

### Moderator
Claim: Hi, I'm Chandra Turner We've talked a lot about healthy lifestyle, but what I want to know is what is the government's role beyond just promoting this healthy lifestyle that we've all kind of anecdotally realized that isn't working, what about the government's role in junk food in schools? What about the government's role-- in taxing foods?

### Moderator
Claim: Okay.

### Moderator
Claim: What about the government's role in-- what's the other thing--

### Moderator
Claim: Labeling products?

### Moderator
Claim: --the fast food industry--

### Moderator
Claim: Yeah.

### Moderator
Claim: --the packaged food industry, the-- all of the junk that our kids are getting constantly? What is the role there? We haven't talked about that at all.

### Moderator
Claim: Can I ask you a specific--

### Moderator
Claim: --suggest-- I mean, a specific recommendation you would want to see, for example, with junk food, would you want to ban it? Would you want to label it? Would you want to tax it? Would you want to change the formulation? Forced by the government? Which of those things are you talking about?

### Moderator
Claim: Kind of all of the above.

### Moderator
Claim: Okay, I want to--

--I want to ask--

### Moderator
Claim: --seriously--

### Moderator
Claim: John Stossel, you're going to get your chance.

### Moderator
Claim: --I mean, I-- when I think about the role of government, that's what I want to know, all the things that haven't been done yet.

### Moderator
Claim: Yeah, okay.

### Moderator
Claim: What can be done, and what is the government's role in that?

### Moderator
Claim: David Satcher.

### Conspiracy Advocate (CA)
Claim: Yeah, I think it's an excellent question. The government's role can be put into three categories. One is this assessment where you really monitor the health of the population, and you give us this kind of information that we can act on.

The second one is assurance that everybody has access to the opportunity to lead healthy lifestyles. The third one is policy. And you're right, it is the responsibility of government to develop guidelines for healthy eating. The Nutrition Act that's just passed is an effort to say, "If we're going to have free breakfast, free lunch in the schools for 40 to 50 percent of the children, we must make sure that those lunches are healthy, that they have adequate fruits and vegetables," I agree with you. The third role of government is policy development, and that policy is made in such a way as to make sure, number one, we have the information that we need, we’ve got to have labels on the foods so we know what we're getting, and also you've got to make sure the children who are receiving these lunches are getting healthy foods.

### Moderator
Claim: Okay--

### Conspiracy Advocate (CA)
Claim: That is the role of government.

### Moderator
Claim: I want to let the other side respond to that, but I want to take a quick break-- artificial break for radio-- which will take all of eight seconds.

And then I'm going to raise my hand and ask you to applaud. And that'll be the atmospheric moment in the radio broadcast and it'll be chance for all of your hands to be heard by the nation. So if you could do that, I'd appreciate it, just a round of applause. Thank you. We are back at this Intelligence Squared U.S. Debate. I'm John Donvan. Our motion is "Obesity is the government's business." We have heard the side arguing for the motion just recently make the case the government does have a very activist role to play in affecting and amending what people eat, in particularly, children. I want to let the other side respond to that argument. John Stossel.

### Scientific Advocate (SA)
Claim: Dr. Satcher, I think you're confusing intention with results. It's nice that we have this good intention, but government doesn't get the results. Some schools now have banned vending machines. A University of Pennsylvania study-- banned vending machines that sell unhealthy food. They studied it.

They found the kids eat just as much junk food, no difference in weight loss. You earlier said that, you know, the schools are supposed to be the great equalizer. They are supposed to be, but government schools are more segregated than private schools. It doesn’t work. Government fails.

### Moderator
Claim: David Satcher.

### Conspiracy Advocate (CA)
Claim: Well, well, I don’t agree that governments fail. Now, the study that you’re talking about, I don’t think anyone, even the ones who carried it out would see that as a conclusive study. What they said was to date, we don’t see the evidence that changing the vending machines--

### Moderator
Claim: We’re going to keep doing more of it.

### Conspiracy Advocate (CA)
Claim: We are going to keep working to help children develop lifetime habits of good nutrition and physical activity. I think that’s our responsibility. And that’s what the schools have to do.

### Moderator
Claim: Paul Campos, arguing against the motion.

### Scientific Advocate (SA)
Claim: There-- I mean, I think there’s a major misunderstanding here about the way that society works in regard to the things that people eat and how many calories they have.

I mean, I’ve just spent the last three days on the upper west side of New York, and I’m surrounded by nothing but the most incredibly high caloric food that you can imagine, which, thanks to the neuroses of your mayor, are now made evident to me every time that I walk into a store because it says right there how many calories there are. And so I go into this place where it’s filled 100 percent by upper class white people looking at these little cupcakes that have 545 calories in them, so it’s like a nuclear bomb of calories, right. But is that going to cause obesity in that group? No. Guess why? Because they’re going to, you know, buy it and then slice it into eight little pieces and then eat it in a super neurotic way and then go to the yoga studio for two hours, right. Now, the notion that that kind of a social structure can be altered through these kinds of informational government interventions is just-- again, there’s no data to back it up. Now, I understand the theory that if something hasn’t worked, you can keep doing it until it does work, right.

That-- one of the classic, you know, definitions of insanity, but that seems to be the government program here. Again, do you think--

### Moderator
Claim: All right, let’s let Pamel--

Let’s let Pamela Peeke-- oh, David Satcher. David Satcher.

### Conspiracy Advocate (CA)
Claim: It’s amazing that the same thing was said about tobacco, the effort to get people to stop smoking, you know. Go back to the ’60s and the ‘70s. It’s not working. There’s no evidence. To date, we can point to millions and millions of peoples whose lives have been saved because of the efforts to get people to quit smoking.

### Scientific Advocate (SA)
Claim: Smoking is a behavior. Obesity is not a behavior.

### Conspiracy Advocate (CA)
Claim: You’re wrong, wrong, absolutely wrong.

### Scientific Advocate (SA)
Claim: Oh, absolutely wrong? Is that why-- tell me, Pam. Tell me, Pam, why are people fat? Why are people fat?

### Conspiracy Advocate (CA)
Claim: Was it magic? It was behavior.

### Scientific Advocate (SA)
Claim: Because I’m a upper-class white person who has the privilege of modifying my weight to an extent that most people don’t.

### Conspiracy Advocate (CA)
Claim: And you cut your cupcake into 13 pieces.

### Scientific Advocate (SA)
Claim: Except, you know, right now, Pam, I weight about 185 pounds, which is supposed to be rather high in the overweight range. So, apparently, I might drop dead right on the stage right now because according to Dr. Walter Willett, that-- to be overweight is very, very dangerous.

If that doesn’t happen, I suggest that people think about the possibilities that are actually available to people in this culture. And I would especially want to emphasize that if you think that the biggest problem that poor kids have in this country right now is that they don’t get enough information about how much calories is in the junk food they eat or they don’t have enough play spaces to play outside, you’ve got a really bad conceptualization of what actually--

### Conspiracy Advocate (CA)
Claim: You’re off-topic, Paul.

### Moderator
Claim: All right, there’s a gentleman-- the gentleman in the far corner. Thanks, if you could stand up.

### Moderator
Claim: Hi, my name is Darrell Baxter and my question is for the panelists for the motion, Mr. Stossell pointed out earlier that the government does get involved in certain programs such as subsidizing the corn subsidies. And also, Dr. Satcher pointed out earlier with the nutrition program, and I recall reading the article where there was an exception in the nutrition program where I think it was pizza and tomato sauce are considered vegetables. So, my question is to the extent government actually got out of the business of causing obesity through subsidies and so forth, what impact would that have on affecting dietary consumption?

### Moderator
Claim: David Satcher.

### Conspiracy Advocate (CA)
Claim: It’s a great point and a great question. And I think that’s exactly what’s happening. I think government is beginning to change the way we spend our money relative to foods, with children especially. Look at the new nutrition act and the difference that it represents from what we’ve seen in the past in terms of the way children eat in school. So I think we are-- the government is responding to the studies that we’ve been talking about, showing how these foods are affecting lifestyles and therefore resulting in ill health, especially Type II diabetes, even in children. So, you’re right, we, the government, have been at fault in many ways in terms of what’s going on in this country, in terms of subsidies as you pointed out. And hopefully we are making the changes that we need to make.

It is the role of government to continue to learn and to grow and to change. And that's what we're seeing now.

### Moderator
Claim: Sir, in the-- yes.

### Moderator
Claim: My name is Larry Parks. I host the Larry Parks show on cable access. And about a year ago I did a show, “Are they poisoning you?” where I addressed these issues. And the question I'd like you to address is, how do you know if you get the government involved in this that it won't become politicized. In the show, I say, are you being poisoned, really attacked the food pyramid which was-- came out of government and Walter Willet who both sides have mentioned, the folks you'd know he's a medical doctor, heads the nutrition department at Harvard University. He wrote me that they get their people, the food industry gets their people on the committees to make the recommendations. So Dr. Satcher, you say you want healthy foods. How do you know all this won't be politicized? And the recommendations, rather than being consistent with good health, or rather consistent with profits of food companies?

### Conspiracy Advocate (CA)
Claim: This is a great question. And to be honest with you, I don't know, since everything becomes politicized. You know--

### Moderator
Claim: You bet.

### Conspiracy Advocate (CA)
Claim: As surgeon general, what I said was that I'm not a politician. I speak to the American people based on the best available public health science. But believe me, there were a lot of political pressures on me every time I did a report. But the fact of the matter is, the surgeon general's report is based on the best available public health science. It has to be approved by the NIH. It has to be approved by the CDC. It has to be approved by HHS. So government is imperfect. And it's up to us to continue to make it more perfect, a more perfect union. But it's up to us to continue to push the government--

### Moderator
Claim: Paul Campos.

### Scientific Advocate (SA)
Claim: I think it's really important to keep in mind that scientists are people just like everybody else and that science is a deeply politicized activity because it can't avoid being politicized given that it's about power and social policy and all the things that are political all the way down. I think when we look at the food industry, one thing that people ought to keep in mind is that the food industry loves the obsession that Americans have with weight. The food industry makes enormous profits from selling people food that is supposed to make them thinner, right? The diet foods have a significantly higher profit margin than regular foods because diet foods can be sold as a kind of magical elixir that's going to cause this weight loss if you buy something, which it doesn't have something in it that it's supposed to have in it, but which is supposedly then-- which has a substitute of something else. So for instance, a fat-free Fig Newton has more calories in it than a regular Fig Newton.

Because the sugar that's substituting for the fat in the fat-free Fig Newton is more caloric. But the fat-free Fig Newton will cost more. So the food industry loves all this stuff, loves the fact that we're obsessing on these issues and trying to supposedly find a magic cure for our supposed obesity epidemic because that's one of the main sources of its profit margins. And so it encourages this kind of social hysteria.

### Moderator
Claim: Okay. Right here in the--

### Conspiracy Advocate (CA)
Claim: Well, the way to get the price down is to make more of it, right? Isn't that what happens with-- happened with computers and everything? So in time, we ought to be able to get the price of Fig Newtons down.

### Moderator
Claim: Thank you. Well, blue sweater. Okay.

### Moderator
Claim: Hi. My name is Sandy Schaefer, I'm a plus-sized aerobics instructor. And I just wanted to make one statement that--

### Moderator
Claim: But very brief, okay?

### Moderator
Claim: Yes, very-- very brief.

### Moderator
Claim: You get a sentence.

### Moderator
Claim: All right.

### Moderator
Claim: Okay.

### Moderator
Claim: As the word "obesity" is ramped up, so is the bullying of fat children.

So my question to you is even though you say you're talking about fit, you still have the word "obese," and you're still targeting children and fat children specifically. And they're now being bullied more and more, and it seems to be with government approval. So how do you speak to that?

### Moderator
Claim: Okay, I'm going to pass on your question. I'm going to let that stand as a-- as a darn good statement. Just over on the corner up there with the-- you have the white card in your hand. You still need to let the mic come to you.

### Moderator
Claim: Thought this would be loud enough--

### Moderator
Claim: No, the radio won't pick you up. That's the problem.

### Moderator
Claim: In a public school where 95 percent of students receive government assistance, whether we call WIC or welfare, essentially it's free lunch. The lunchroom has machines filled with overpriced Doritos, chocolate chip cookies, Cheetos, et cetera, which many of the students purchase, often in lieu of their available free lunch that was paid for by my tax dollars.

Is there data regarding specifically the percent of urban welfare recipients how they spend their money and where they spend their money on food?

### Moderator
Claim: What are you getting-- what do you want to get at though? You want to say that there is an absence of data to know whether it's working?

### Scientific Advocate (SA)
Claim: I think she's suggesting it's not working, that they have a free lunch, but they spend $4 on the vending machine junk. You can't manipulate people as well as we think you can.

### Conspiracy Advocate (CA)
Claim: Actually, there's a-- there is a fantastic study that just came out in the journal of sociology. And it basically showed that when you have all of this at school, and you have another option, many of these kids are going to what they're used to at home. And so what they're not going to do is, you know, come from a home where they're eating trash and drinking trash and back and forth, and then suddenly magically come to school and go, wow, asparagus, bring it on. They're just not going to do this.

What you're talking about is a reward system in the brain that's been hijacked. And you're looking at consistent behaviors on the part of these children. This is one of the reasons why--

### Moderator
Claim: But Pamela, let me bring it back to our motion. So what's the government's role in this?

### Conspiracy Advocate (CA)
Claim: Well, the government's role in this, you know, is a bit more complex. You're looking at a child and controlling that child and offering options there. But you haven't talked to the parents. What we need to do now is bring in the family. If you don't have the family as a unit in this, then this is going nowhere fast.

### Conspiracy Advocate (CA)
Claim: And the government--

### Moderator
Claim: Am I not looking at a child to receive tax-- whose family receives tax funds-- sorry, tax- generated funds and brought their money to school and spent it on a machine instead of on their healthy lunch? And by the way, 25 out of 28 students in my class, which is 95 percent free lunch, have cable TV. I don't have a TV.

### Moderator
Claim: Paul Campos.

### Conspiracy Advocate (CA)
Claim: Yeah, but what you're talking about is-- they may have the money. They haven't made the connection.

### Scientific Advocate (SA)
Claim: Look--

### Moderator
Claim: Paul Campos.

### Scientific Advocate (SA)
Claim: Again, this has been studied.

There have been intense government intervention such as, for instance, the pathway study was based on the notion we're going to educate the kids, we're going to educate the parents about healthy eating habits and better physical activity. We're going to do all these wonderful things that the government is advocating that we do. And what those things did was that they produced some improvement in terms of lifestyle modification, but they did not produce weight loss. There is no evidence that telling parents of children, of fatter children, that this kind of food is-- has more calories in it, and this has less and this is more nutrient rich, and that is less or whatever, is going to produce thinner children. And I want to get back to Sandy Schaefer's point because I think it is an absolutely crucial one. Right now, what we are creating is a machine essentially for stigmatization and bullying, right, because the government is just broadcasting this message 24/7, that if you're a fat kid, you have something wrong with you, and you have something wrong with you that happens to be your fault because you could modify it.

### Conspiracy Advocate (CA)
Claim: Paul, that's not just the government.

### Conspiracy Advocate (CA)
Claim: No, no, no, no. We're talking about the media. Bring it on through the media. You look at those magazines. You look as those shows. You look at the fantasy world everyone lives in. That was going on a hell of a lot longer before any government intervention showed up.

### Scientific Advocate (SA)
Claim: Right. But now you're exacerbating it.

### Moderator
Claim: I'm going to-- I have time. I have time for one more question. I thought Sandy did it really when she said it the first time. In the aisle, since you came all the way down, sir. Can you step forward just a little bit? Thanks. A little bit more. That's great. Thank you.

### Moderator
Claim: My name is Sakon Sharob If we take a step back from the debate and look at the economics of it, maybe the government side could tell us why, out of all actors, government itself is the best actor to step in and solve this problem, if there's a problem in the first place? Dr.--

### Moderator
Claim: Okay. Let's take that question quickly. David Satcher. Why the government?

### Conspiracy Advocate (CA)
Claim: I think the government is the only actor. Remember who the government is. Public health is the collective efforts of a society to create the conditions in which people can be healthy.

Government calls upon all of us to work together to solve the problem. It does it through public-private partnerships. So it's not either/or. We're not saying the government does this, and nobody else. We need all hands in. But if the government does not do its job, it will not get done because government has the resources, and nobody else does, to monitor the health of the population. Government has the resources to make policies so that we can have an idea what people are eating and what they are exposed to in terms of information.

### Moderator
Claim: Very quickly.

### Conspiracy Advocate (CA)
Claim: So I think the government has a role that only the government can play. But it doesn't mean nobody else does.

### Moderator
Claim: Very quickly, Paul Campos.

### Scientific Advocate (SA)
Claim: Yeah, I'd like to point out something. The health of the American population is better now than it's ever been before. I mean, all this talk of like a huge health crisis overlooks the fact that in fact not only is the life expectancy the highest it's ever been and continuing to increase at a steady rate, but all-- the rates of almost all the major diseases are significantly lower than they've been before.

### Conspiracy Advocate (CA)
Claim: Life expectancy may be up. Health span is down. The quality of life is decreasing significantly.

### Scientific Advocate (SA)
Claim: Yeah, because people who are 90 are not very healthy.

### Conspiracy Advocate (CA)
Claim: We're keeping people alive who are grossly disabled by these diseases.

## Round 3

### Moderator
Claim: All right. All right, ladies and gentlemen, that concludes round two of this Intelligence Squared U.S. Debate. And here's-- we are about to hear brief closing statements from each debater, in turn. Their closing statements will be two minutes each. And remember we had you vote before the debate. Immediately after these closing statements, which are their last chance to win this thing, we are going to ask you to vote again, and the team whose numbers have moved the most will be declared our winner. So on to round three, closing statements by each debater in turn, our motion is this, "Obesity is the government's business." And here to speak against the motion, John Stossel, Emmy Award winning host of the weekly Fox Business Network Show, "Stossel."

### Scientific Advocate (SA)
Claim: So you talked about Medicare, and it's true, it's eaten us alive. That's what's going to make us go broke fastest. So you're saying that because we have socialized medicine, which everybody loves, we have to give up our freedom and invite government to come in and control more of our lives?

I don't think it's any coincidence that this biggest push for more food regulation comes at a time when Congress is obsessing about paying for everybody's health care. When government pays, it's drawn into your personal life, and this is not a good thing. It's not true that only government can do these things. Free people can control their own lives. Government will propose to control you because you eat too much. Will they next try to ban skydiving and extramarital sex? How about another try at prohibition? That might save money. You’re going to have the government teach poor people to serve asparagus when we have a $3.8 trillion spending already? and transportation alternatives? I'll give you money. But you want government to build more bike paths? My local councilwoman is giving out free bike helmets to encourage bicycle use. You know, my neighborhood is where Jerry Seinfeld and Sting live.

I say to her, "Why would you spend public money?" "This isn't public money. It's free. It's a government grant." It's not free. Some people say, "Well, it's just information." And information's good, but it's not free. These calorie counts which haven't worked, they raise the price of food a little because it costs restaurants money to post that. And they also-- all this information distracts you from other information that might be more important. This happens all the time when government intervenes. You ever look at a birth control pill label? I happen to have one here. Look at this thing. Tiny fine print, both sides, the result is nobody reads it. It doesn't make us safer. This is what government gives us.

### Moderator
Claim: John Stossel, your time is up. Thank you very much. Our motion is "Obesity is the government's business," and here to summarize his position in support of this motion, David Satcher, the 16th surgeon general of the United States and director of the Satcher Health Leadership Institute.

### Conspiracy Advocate (CA)
Claim: Well, let me say that I have seen government at its worst and I've seen government at its best. I know government is not perfect. I grew up in Alabama at a time of segregation and discrimination. I was a teenager when George Wallace, running for governor, came to town and said that he would deputize every white man in Alabama before he would see one black child go to the University of Alabama. I've seen government at its worst. But I've also seen government at its best. I've seen government protect children from lead. As a medical student I saw babies coming into emergency room with toxicity from lead. Many of them died. That was in the '60s. In 1978, the government regulated the lead content of house paint, and we've seen a dramatic decline in lead poisoning in children. I've seen government at its best.

I've been involved in the eradication of polio, and all over the world, and recently learned that last year for the first time not one child in India suffered from polio. And only three countries in the world have polio, a total of less than 700 cases in the world. Government at its best is "We, the people." Government is the collective efforts of a society to create the conditions in which people can be healthy. So that's what we see as government. We believe that there is no substitute for individual responsibility. Let's make that clear. It's why I wrote the prescription. But individual responsibility can only take place in an environment where there is equal opportunity, there is equal access to the opportunity for a healthy lifestyle. It's our contention that obesity is the business of the government because it is the business of the government to create those conditions. Thank you.

### Moderator
Claim: Thank you, David Satcher. Our motion is "Obesity is the government’s business.” And now, here to summarize his position against this motion, Paul Campos, who is author of “The Obesity Myth” and professor at the University of Colorado Law School.

### Scientific Advocate (SA)
Claim: Thank you. I was watching the Super Bowl with my father who’s a retired physician and oncologist actually. And we were getting bombarded, of course, with erectile dysfunction ad drug advertisements. And they-- all of them have this tag line that’s legally required, right. “Ask your doctor if Cialis is right for you,” right. So after about, you know, six of these, my father turns to me and says, “How the hell do I know if Cialis is right for you?” Okay, and the point was, you know, significant in two ways. One, first of all, he’s an oncologist. He doesn’t know anything about the pharmacology of erectile dysfunction drugs, right, just because he’s a doctor, right. But the more profound point is that you would think that the question of whether Cialis is right for me is a little bit more socially complex and it could be answered by a doctor, right.

You’d think there would be at least one other person who would have an opinion on that question besides a doctor, right. The point of that story really is that what is now called erectile dysfunction used to be called being 50 years old, right. In other words, we take a completely natural process and we pathologize it. We turn it into a disease so that it could be treated through pharmacological intervention. And what’s really going on here, and I know that our opponents are not in any way intending this, but intention, you know, we know the road to hell is paved with, right. What’s happening is that all this talk about lifestyle intervention is something that the pharmaceutical industry loves because they know that that stuff doesn’t work. And the point of all this discourse is to soften up the regulatory pipeline for the next generation of diet drugs. That’s where the real money is, and that’s why we’re hearing about obesity, obesity, obesity all the time.

Oh, we’ll get kids to eat fruits and vegetables. Alice Waters will make asparagus for everybody, and we’ll make lots of bicycle paths, and then kids won’t be fat. But they will be anyways. Until then, what will we need? Drugs. And that’s what I would suggest this is really at the bottom line all about.

### Moderator
Claim: Thank you, Paul Campos. This is our motion, "Obesity is the government’s business.” And speaking last in support of the motion, Dr. Pamela Peeke. She is WebMD’s chief lifestyle expert and also assistant clinical professor of medicine at the University of Maryland.

### Conspiracy Advocate (CA)
Claim: As the Discovery health correspondent, I was filming my show in South Central L.A. at the National Body Challenge where we take families and we try to teach them everything we can as physicians about being healthier. It’s not just about dropping weight but being healthier. This was a small little house. It was 97 degrees in the middle of summer. There were no sidewalks. Or what was there was scary-looking.

And we were asked to go out and take a little walk. And I looked near the front door, and there was a golf club sitting there. Now, the closest golf course was probably about 100 miles away. So I asked what was that sitting there for. And the mother looked at me and she said, “That’s to beat away the dogs, the feral dogs that are running all over the place from the drug lords who are either jailed, dead or MIA and just so we can get to our car.” And I said, “You have a dog yourself. Where do you walk it?” “We have to drive three-four miles away to a small park, and that’s what we do.” So I went out, and I took a walk with them because my producers told me to. And we went outside, and I took the fastest walk of my life. And as we were coming around and we were being filmed, of course, the producers were in a car and I was on the sidewalk or whatever was out there, I noticed the dogs coming. They were about three blocks away, totally freaked me out.

And I realized, wow, let’s break into a run. You’re walking so well. Let’s run. And so we did, and I ran for my life. I suddenly realized as we sat in there, as they ran into the house, and the kids were crying by this time because they were scared, they said, “Where’s the cookies?” It feels good. And the grandmother looking at me, saying, “No, we just learned something different. Let’s just pray.” And I looked around and I said, wow, obesity is the government’s business because it’s not really obesity, really, at the end of the day. Wow, health, the fitness to be able to live and survive-- that’s really what it’s about.

### Moderator
Claim: Thank you, Pamela Peeke. And that concludes our closing statements. And now it’s time to learn which side has argues best. And now it’s time to learn which side has argued best. We’re asking you again to go to those keypads at your seat to register your vote. Again, our motion is this: “Obesity is the government’s business.”If you agree with the motion, this side’s arguments, press number one. If you disagree, this side's arguments, push number two. If you remain or became undecided, push number three. And we'll have the results of that vote in about one minute and 45 seconds. And so while we're waiting for that, I just wanted to say a couple of things. One, I wanted to thank these panelists for the level of integrity and intelligence and honesty they brought to this thing. And also, you in our audience for the questions that you brought up and for your boisterousness and liveliness, and it was clear you were there with all of us, so thank you to all of you for your participation. A couple of things about our organization, Intelligence Squared. We are delighted that this was a sellout. We've been delighted since Bob Rosenkranz set this thing up to see it grow and grow.

This is our 58th debate tonight. The audiences just keep getting bigger. We appreciate that you're here and that you made it down. Please tell your friends we're going to keep going and keep getting bigger and better. And to that end in fact, last week-- we do a podcast based out of this. And last week, Forbes magazine published a list of the top five podcasts that will change the way you think. And we were number two on that list. And we're delighted. And you know, it's a scary thing to change the way you think. But you've experienced it. It's not so frightening. And our next debate is on March 13th. Our motion is this: China does capitalism better than America. And supporting the motion, speaking in support of the motion, Orville Schell who is director of the Asia Society Center on U.S.-China relations. And his partner will be Peter Schiff who is an investment advisor and a former economic advisor to Ron Paul.

Speaking against, Minxin Pei, who is a professor of government at Claremont McKenna. And his partner is Ian Bremmer, founder of the Eurasia Group, a global risk consultancy. So we'll have the results in just a moment. I just want to say that, for me, in this debate as a person with a very slight tendency to overweight, I-- which to me was the elephant in the room tonight. I-- I had an interesting experience today. I've been reaching-- I did a great deal of research for this debate as I usually do. I had a sheaf of stuff I've been carrying around with me. And I'm a New Yorker, but I now live in Washington. So I flew up today, and I checked into one of those hotels where when you check in, they give you a cookie. Like a great big, giant chocolate chip cookie. And I looked at the cookie, and I looked down at my sheaf, and I have decided that I'm going to carry a sheaf with me everywhere I go from now on because I was able to say no to it. So to all of those who wrote stuff that got into that research, I appreciate it.

So we'll have the results-- oh, they're coming out now. So what I'm going to do is read the two sets of numbers and declare our winner. Remember, the side that has changed its numbers the most in the course of this evening will be declared our winner. Our motion is this: "Obesity is the government's business," and here are the results. Before the debate, 55 percent supported the motion. 19 percent were against, and 26 percent were undecided. After the debate, 55 percent remain in support of the motion. That has not changed at all. 35 percent are against. That is up 16 percent. 10 percent are undecided. The side against the motion, "Obesity is the Government's Business" carries the debate. Our congratulations to them. And thank you from me, John Donvan of Intelligence Squared U.S. We will see you next time.
