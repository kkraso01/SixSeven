# Debate Transcript

Topic: The Constitutional Right To Bear Arms Has Outlived Its Usefulness
Motion: The Constitutional Right To Bear Arms Has Outlived Its Usefulness

Debate ID: 111413%20guns


## Round 1

### Moderator
Claim: So let's begin now by welcoming to the stage, Mr. Robert Rosenkranz. Hi, Bob.

### Moderator
Claim: Good evening, John.

### Moderator
Claim: So, Bob, we've done debates on gun control issues before. We did a debate where the motion was Guns Reduce Crime. We're visiting it again, but we're phrasing it specifically a different way. Why is that?

### Moderator
Claim: Well, let me start by just sort of saying what this debate is and isn't. It's not about whether the Second Amendment should be repealed. That's just a political impossibility. And it's not about whether the Second Amendment gives us an individual right to bear arms. The Supreme Court has decided that. So this is more of a debate about the historical context of the amendment itself and whether it has outlived its usefulness.

### Moderator
Claim: And the team that's arguing for the motion, in terms of putting it in historical context and reflecting changing times, in fact, I'm assuming that's what they're going to be arguing.

### Moderator
Claim: Well, the world was very, very different when this amendment was passed. It was a world in which state militias were relevant. It was a world in which there were no professional police forces so that the only kind of defense against violence was self- defense, and it was a world in which it was plausible to think that an armed citizenry was a bulwark against tyranny. We had just been through the Revolutionary War, after all.

### Moderator
Claim: And in what ways has the world changed that might make that irrelevant now?

### Moderator
Claim: Well, those who see the amendment as rooted in an historic anachronism are going to feel like we should have the most restrictions we can against gun ownership that the constitution would permit. The other side is going to say no, this is not a historic anomaly at all. This amendment enshrines the ability of Americans to defend their security at home, and 47 percent of all Americans do have guns at home and see it as essential to their-- the security of themselves and of their families and those people feel very strongly that this is an amendment that embodies values, such as self-reliance, such as independence, and such as kind of collective responsibility for public order that the founders embraced and which they embrace, too, and which are relevant to this day.

### Moderator
Claim: And our four debaters have really-- some of them have been living this topic for a long time and, as you'll learn, they've been ground-- they've provided some of the groundbreaking thought between-- behind how some of this has actually been argued in the courts. They've actually been players in this debate for some time. So, Bob, thank you very much for bringing this and bringing them to the stage, and let's welcome them to the stage now.

### Moderator
Claim: Thank you, John. Thank you.

### Moderator
Claim: Thank you. And I just want to invite one more round of applause for Bob Rosenkranz for doing this for us. This is Intelligence Squared U.S. I'm John Donvan, and sometimes a regular ordinary guy gets to have his name go down in history in a very big way, and it happened to a guy named Dick Heller, who happened to be working in security in a government building in Washington, D.C., when he sued the government of Washington, D.C., over a law that prevented him from legally owning a handgun. And it went all the way to the Supreme Court and Dick Heller won. It was District of Columbia versus Heller and it was the landmark gun rights case of all time where the Supreme Court ruled only in 2008 that the constitution guaranteed to every American a personal right to bear arms. And if it is that obvious, then perhaps people who aren't happy with how that has turned out might want to argue that perhaps that right never should have been put into the constitution in the first place.

And what a debate that would be, as we are about to find out. Yes or no to this statement: The Constitutional Right to Bear Arms Has Outlived its Usefulness. A debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufmann Music Center in New York. We have four superbly qualified debaters-- two against two. Americans all, but they're divided on this motion: The Constitutional Right to Bear Arms Has Outlived its Usefulness. As always, our debate goes in three rounds. And then our live audience in New York City votes to choose the winner. And only one side wins. Our motion, again, is The Constitutional Right to Bear Arms Has Outlived its Usefulness. Let's meet the team arguing for the motion, trying to convince you that The Constitutional Right to Bear Arms Has Outlived its Usefulness. Let's welcome, first, ladies and gentlemen, Alan Dershowitz. Alan, you're a professor at Harvard Law School. You've played parts in these cases. The Pentagon Papers, Bush v. Gore, the WikiLeaks investigations, the defense of OJ Simpson. We have heard about those cases. But on the back cover of your recent memoir-- you just came out with a memoir called "Taking the Stand," you quote Noam Chomsky, who says, "Dershowitz is not very bright and strongly opposed to civil liberties." And you quote him. So you've given the whole thing away to the other side here?

### Conspiracy Advocate (CA)
Claim: Well, my high school teachers said the same thing. And so-- I think you guys have to give me a little break. These guys are all smarter than I am, so there

### Moderator
Claim: All right. Ladies and gentlemen, Alan Dershowitz. Give him a break. And Alan, your partner in this debate is?

### Conspiracy Advocate (CA)
Claim: My partner in this debate is the very, very distinguished professor, Sandy Levinson, who's just written his own great book.

### Moderator
Claim: Ladies and gentlemen, Sandy Levinson. great book is called "Framed: America's 51 Constitutions and the Crisis of Governance." He's a professor of law at the University of Texas and a professor of government, there, too. In 1989, Sandy, you wrote an article in the Yale Law Journal that is really credited with reshaping the entire debate over gun rights in this country, which was not much of a debate up to that point. So this whole thing is your fault?

### Conspiracy Advocate (CA)
Claim: Well, if I get an obituary in the New York Times, when the time comes, no doubt that article will be the lead.

### Moderator
Claim: Well, I hope you're not thinking about that right now. Ladies and gentlemen, let's welcome Sandy Levinson. Our motion is The Constitutional Right to Bear Arms Has Outlived its Usefulness. And here to convince you to vote against this motion-- I want to introduce, ladies and gentlemen, David Kopel. And David, you're research director at the Independence Institute, co-author of the first law school textbook on the Second Amendment. And in the case of District of Columbia v. Heller, the landmark Supreme Court gun rights case, you were a member of the oral argument team. You are also a member of the NRA. You are also a member of the ACLU. How do you put dinner parties together?

### Scientific Advocate (SA)
Claim: The trick is you make the pre-dinner prayer optional and that makes the ACLU folks happy. And then you have a lot of sharp knives around, and the NRA people are content.

### Moderator
Claim: All right. Thanks very much. David Kopel, ladies and gentlemen. And David, your partner is?

### Scientific Advocate (SA)
Claim: My partner is the genial genius, Eugene Volokh, perhaps the most important First Amendment scholar in the United States today.

### Moderator
Claim: Ladies and gentlemen, Eugene Volokh. Eugene, you're a professor of law at UCLA. The reason that you were just referred to as a genius is that according to the Tuscaloosa News Profile done in 1981, when you were 12 years old and you were a sophomore at UCLA, the newspaper reported that your IQ was 206. And you recoiled earlier when I told you I was going to bring that up, so I thought maybe we could talk about your credit score instead.

### Scientific Advocate (SA)
Claim: On a good day it's better than that.

### Moderator
Claim: Ladies and gentlemen, let's welcome Eugene Volokh and all of our debaters. Now, this is a debate. It's a contest of ideas. And our motion is The Constitutional Right to Bear Arms Has Outlived its Usefulness. And by the time this debate has ended, we will have asked you, our live audience in New York, to vote twice on this debate, because you will be the judges of the winners. Before the debate, we will ask you to vote before the debate and once again after the debate. And the team whose numbers have changed the most in percentage point terms will be declared our winner. So, let's go to the keypads at your seat and we'll be getting on to Round 1 in just a moment. Let's go to these keypads at your seat and we'll have you vote your position as you come in off the street. The motion is The Constitutional Right to Bear Arms Has Outlived its Usefulness.

If you agree with this motion at this motion at this point we want you to push number one, and if you disagree, push number two, and if you're undecided, push number three. You can ignore the other keys. And we're going to lock this out in just a minute and just to repeat this, at the end of the debate, same thing. We have you vote another time and the team whose numbers have moved the most in percentage points from this starting point will be declared our winner. Onto round one. Opening statements by each debater uninterrupted. They are seven minutes each. The motion is: The Constitutional Right to Bear Arms has Outlived Its Usefulness, and here to persuade you to vote for this motion, let's welcome Sanford Levinson, ladies and gentleman. You're a professor of law, as well as professor of government at the University of Texas, Austin. So, ladies and gentleman, let's welcome arguing for the motion, Sanford Levinson.

### Conspiracy Advocate (CA)
Claim: Thank you. I want to begin by repeating a point that Bob Rosenkranz made. This is not a debate about policy. As it happens, I can't completely speak for my colleague, Professor Dershowitz, but I would very much oppose, for example, a federal law banning guns independent of the Second Amendment, because it is very, very clear that there is a critical mass of Americans who would be vehemently opposed to that. It would just add to the divisions in the country and it would increase the number of criminals in the country, because just as with drug laws and gambling laws and the like, there is no reason to believe that such a law could generally be enforced. Most enforcement requires a willingness to comply with a law that one regards as relatively legitimate, and this law would not be regarded, I think, in that capacity.

It's also true with regard to a number of other gun control statutes that are proposed that I have distinctly mixed feelings about, many of them on a variety of policy grounds, but fortunately we're not here to debate that. Nor do I think we are here to debate the one true meaning of the Second Amendment, as interesting as that topic is, and about which indeed I have written. Rather, I want to emphasize the topic that is in front of us, The Constitutional Right to Bear Arms has Outlived Its Usefulness. Now, one reason I relish this statement of the question is that I'm one of those relatively rare people, I will admit, who actually believe there should be a new constitutional convention, because I believe that a number of provisions of the constitution have outlived their usefulness.

I wouldn't even say that the Second Amendment or the right to bear arms is the one that has most outlived its usefulness, but I'm really quite happy to argue that in 2013 the kinds of considerations that led to the placement of the Second Amendment in the Bill of Rights, which Bob Rosenkranz summarized, I think, very well, have outlived their usefulness. So, if we were going to have a debate in 2013 about what substantive rights, as well as what structures the Senate, bicameralism, presidential veto and stuff like that, what would a 2013 or 2015 constitution look like? Would it include a substantive right in the United States constitution to bear arms?

And I would argue that the answer is no. Let me also emphasize that this is a different question from whether state constitutions should include a right to bear arms. Eugene has written one of the definitive articles showing, I don't know what the current number is, but I think it's over 40, state constitutions do protect a right to bear arms, and that raises a very, very important question of whether we need to have that in the United States constitution as well. Let me give you two principle reasons why a constitutionalized right to bear arms instead of a right to bear arms that would simply be fought out in the political process, and all of us know that the political process today is tilted either legitimately or illegitimately, that's the topic of yet another debate that we need not have this evening, generally in favor of the rights of gun owners.

So, let me give you the two reasons why I think the Second Amendment has outlived its usefulness in the 21st century. The first reason is precisely that it is anti-federal. That is to say, one of the anomalies-- sometimes very difficult to tell the players without a scorecard-- in the debate about gun rights. There are many people who define themselves as conservatives who rail against a rampaging national government that believes in one-size-fits-all solutions to national problems. Well, this is not necessarily what Heller decides, but it is what the Supreme Court decided two years later in the McDonald case, where it held that every state in the union has to toe a single line.

Louis Brandeis spoke very eloquently of states as little laboratories of experimentation. Most states have chosen to experiment in favor of gun rights. There are some states-- or cities-- very dense cities, like Washington, D.C., that would prefer different experiments. Or in New York itself, one can well imagine a particular policy for the great cities of New York and a very different policy for upstate New York, where there are far, far more hunters than is the case in Manhattan, say. And one of the things that a single national constitutional amendment-- as interpreted by the Supreme Court-- does is to stifle that kind of federalism. And I think that's a mistake.

But there's a second real problem with constitutionalizing the right to bear arms in the 21st century. As Mr. Rosenkranz suggested, the right to bear arms-- or the Second Amendment-- had a kind of cosmetic value until 2008. It's not that people didn't write about it. I wrote about it. Eugene wrote about it. A number of people found it very interesting. But it played remarkably little role in actual American law. Beginning with Heller, it does play a role. But what does that mean? It means that you turn over decision-making power to a group of federal judges who are highly divided, who have no expertise in this area, and who make often quite remarkable-- even unreasoned-- distinctions.

Thus, for example, in Heller, Justice Scalia says that Dick Heller is protected, which I think is a perfectly plausible argument, but he suggests that Martha Stewart is not, because she actually lied to an FBI agent and is thus a convicted felon. I don't think judges should be making those kinds of decisions. I think legislators should.

### Moderator
Claim: Thank you, Sandy Levinson. Our motion is The Constitutional Right to Bear Arms Has Outlived its Usefulness. And now here to try to persuade you to vote against this motion-- let's welcome Eugene Volokh. He is the Gary T. Schwartz professor law at UCLA and founder and co-founder of the Volokh Conspiracy, one of the most widely read legal blogs in the country. Ladies and gentlemen, Eugene Volokh.

### Scientific Advocate (SA)
Claim: All right. Thank you very much for having me here. And it's such a great pleasure to be on the same panel with David, and Alan, and Sandy. They're all top scholars and I also reckon all of them as friends of mine.

And so let me start with something I think we all agree on, on the panel. And I think probably virtually everybody-- perhaps everybody in the audience agrees on too, and that is that there's a basic human right to self-defense. And there are, of course, debates about the particular boundaries of that right. But there's a core to that right that every state in the union recognizes. I'm sure it's well-recognized outside the U.S. as well. If somebody is threatening you with imminent death, serious injury, rape, kidnapping, you're entitled to use force, even deadly force, in order to defend yourself if that is necessary. That is very broadly agreed on. And I think it's agreed on because it is a basic human right. So I think there's little difference about that. But then there's the question-- what does that right entail? And I want to argue that a right to self-defense, like other rights, entails the right, at least presumptively, to have the tools that are necessary to reasonably effectively defend yourself.

Let's take an example. The right to control whether you want to reproduce, whether you want to have children or not. Imagine somebody says oh sure, I'm all for that right, you can use birth control so long as it's the rhythm method. We wouldn't say that's a serious argument. We'd say it's a parody of an argument, right? We'd say well of course, the right to control your reproductive future involves the right to use tools that are reasonably necessary in order to effectively do that. That's not just for that right, it's also for speech. Your right to speak doesn't just mean the right to move your mouth, it's the right to use the internet, to use various other technologies that are reasonably necessary to effectively defend yourself. And guns are reasonably are necessary to effectively defend yourself. Our own bodies, you know, we sometimes can defend ourselves with that, but not when our assailant is armed with a gun or otherwise, and even if unarmed, if the assailant is sufficiently big, sufficiently strong, sufficiently ruthless, the only way we can effectively defend ourselves in many situations is with a gun, often not by shooting it. The overwhelming majority of all defensive gun users involve just threatening to use it.

Just a couple of thought experiments. I'm sure some of you live in places-- in houses where on the front lawn it says protected by armed patrol. I suspect few of you live in houses where on the front lawn it says protected by unarmed patrol. I would be willing to bet that. So in a sense really, those people who have the money to have armed guards, either personal bodyguards or people driving by, are already entitled to essentially take advantage of this technology to defend themselves. The right to bear arms gives people the ability to do that, even if they can't afford to hire someone. If they are their own armed guards, that's what the right to keep and bear arms allows people to do. And I think it's no surprise then that 44 of the state constitutions specifically protect a right to bear arms, and over 40 of them clearly in a way that's an individual right to bear arms, and this isn't just some weird anachronism. This dates back from the Pennsylvania constitution 1776 to the Kansas constitution in I think 2012, and several constitutions in the preceding couple of decades as well.

Now, some people may say well okay, fine. It's reasonable to say there's a presumption in favor of being able to have tools needed to defend yourself, but maybe it should be rebuttable. If there's solid enough evidence that banning guns or seriously limiting guns would protect us so much that that outweighs whatever loss to self-defense there may be, well, then we should do that. Well, interesting argument, but there is no such evidence. So, in 2004, the National Research Council appointed a committee of scholars, of criminologists. They put out this very nice report. You can read it for free online. The consensus was based on the existing studies there's no evidence that either extra gun ownership or extra gun restrictions would make people safer.

Centers for Disease Control in 2005, similar study, similar result. The other studies as well from New York's own New York University: James Jacobs, looks at can gun control work. His answer, not as an ideologue on this, is probably not, at least based on what we know. Now, of course, Sandy might say all right, these are all interesting questions, but why do they need to be resolved as a constitutional matter by judges? Well, one reason might be that we do have a tradition of resolving, indeed on a national level, questions of basic human rights as to free speech, as to searches and seizures, a variety of other things we have taken them off of the federalism process. We have set them up as human rights for the country as a whole, but still one could very reasonably ask this question as to whether this makes sense. Well, I think the answer to that you have to think practically, and you have to think about what is likely to be effective in our country given the political realities. And so for that you have to ask yourself, what do you want? If you're interested in gun control, what is it that you want?

Now, if what you want-- so you might want gun bans or handgun bans, or you might want modest gun controls, background restrictions on mentally ill people, limits on size of large capacity magazines. You have to decide what is it that you want. Now, if you want the former, if you want total gun bans or handgun bans, well, good luck to you with the war on guns that you're going to have to get, even if you can repeal the Second Amendment, even if you can persuade people the Second Amendment has outlived its usefulness. There are going to be lots of people you won't persuade. There are 300 million guns in the country. They're not just going away. Criminals will have access to them, and as Sandy pointed out, a lot of otherwise law-abiding people will become criminals because they will insist on retaining them. Aha, people say well, but that's not what we want, right? We want modest gun controls, that's what I always hear. Probably most people do want just modest gun controls, but if you want modest gun controls the Second Amendment in court already doesn't stand in your way. Courts have routinely upheld against right to bear arms challenges. There's a wide range of modest gun controls. To be sure, there's federal level in many states, though not so hard in other states, but that's a political constraint, not a legal constraint.

The Second Amendment is not a barrier to the enactment of those gun control-- some people think it should be. But as a descriptive matter, it actually hasn't been and isn't likely to be. But what's more, if you want modest gun controls, the Second Amendment is your friend. And any attempt to repeal it-- that is what your enemy would be. Because all of those people who have been assured, "Oh, I'm not going to take away your guns. Oh, if you think people are going to take away your guns, you're just paranoid"-- if there is, indeed, a move to repeal the Second Amendment, which I think is the implication of the conclusion that it's outlived its usefulness would be, that would turn that all-- make it all sound like lies and make people worry that indeed that's what's going to happen, that people will be coming for their guns. So if you want modest gun controls-- I'm not saying you should-- but if you do, you should be arguing that the Second Amendment has not outlived its usefulness. Part of its usefulness-- besides self-defense-- is precisely the assurance it gives to people that people are not coming for their guns, as so many people, including the president--

--have ensured them.--

### Moderator
Claim: Thank you--

### Scientific Advocate (SA)
Claim: --have ensured them.--

### Moderator
Claim: --Eugene. Thank you. And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters arguing it out over this motion, in two teams of two: The Constitutional Right to Bear Arms Has Outlived its Usefulness. We have heard two of the debaters. And now on to the third. Let's welcome to the lectern Alan Dershowitz. He is the Felix Frankfurter Professor of Law-- at Harvard, the bestselling author of 30 books, including "Taking the Stand: My Life and the Law." Alan Dershowitz.

### Conspiracy Advocate (CA)
Claim: Thank you. What a great and powerful argument. No wonder he is considered a genius. But let's think about his argument for a minute. The argument was really not so much in favor of the Second Amendment. It was in favor of the right of self-defense. You are right. We all agree. There should be a right of self-defense. So don't you agree with me that it would have been better if the Second Amendment had been written as "Everybody has the right of self-defense"-- then we could argue whether or not guns were necessary, what kinds of guns, what kinds of restrictions.

You would also then have to debate whether or not guns were permissible for hunting, because hunting is not part of self-defense. The Second Amendment reads rather differently. It starts out by saying "A well-regulated militia, being necessary to the security of a free state," then “the right of the people to bear and keep arms.” So, I think everybody would agree that the first clause of the Second Amendment, "well-regulated militia," has outlived its usefulness. We do not have militias, state militias. They are as anachronistic as the Third Amendment, talking about that we can't quarter troops. Now, that doesn't mean that I would want to amend the Bill of Rights. I don't want to amend the Third Amendment. I prefer to leave it there, because if you start amending the Third Amendment, Sandy will have a constitutional convention. And he'll have people who might start amending the First Amendment, and the Fourth Amendment, and the Fifth Amendment.

So I'm happy to leave all the amendments there, as long as we acknowledge that the Second Amendment, like the Third Amendment, has outlived its usefulness. My point is it would have been so much better if we had established the primary right in the Constitution, the right of self-defense. Then we would have nothing to debate. We would all agree there is a right to self-defense. We would then be able to debate what the derivative right is from the right of self-defense, just like we debate today as to what the derivative right of privacy is from the Fourth Amendment, the right of the people to be secure in their homes and places. But we have to distinguish between the primary right and the secondary right. The primary right should be the right of self-defense. Of course I throw the question to my distinguished opponents: are they conceding that the Second Amendment should be interpreted to abolish the right of hunters to own weapons that are useful only in killing animals and are not useful in defending one's home or oneself?

Should one have to demonstrate that one is using the weapon for self-defense? Would you rewrite the Second Amendment, if you had the choice, and abolish the term "a well- regulated militia," and say, instead, "The right of self-defense, being necessary to the security of a free state, the right of the people to keep and bear arms shall be infringed." It seems to me, from Professor Volokh's argument, that he would support such an amendment, or at the very least, if he had been a framer of the Constitution, he would have preferred an amendment which started out with the right of self-defense being essential. So I think you've helped defeat your own argument by creating-- a new basic fundamental right-- and then deriving the right that's in the Constitution from that fundamental right. And so, the question remains, what difference would it make? The difference is fundamental.

I agree with you. Basic rights should be recognized by constitutions. Virtually every country in the world today recognizes the right of self-defense. Four countries in the world, Mexico, Guatemala, Haiti, and the United States, I think, recognize the right to bear arms, so the vast majority of countries feel and believe that you can have a right of self-defense without necessarily having a fundamental right to bear arms. It seems to me that that's a relevant consideration, and I agree with my distinguished colleague that the lavatories of democracy should be allowed to operate. And we should not federalize this constitutional right. We should not be the only leading industrial country in the world that has as a fundamental right the right to bear arms.

What do the four countries that have a right to bear arms have in common? What does Mexico, Guatemala, Haiti, and the United States have in common? They all have extraordinarily high crime rates, extraordinarily high murder rates, extraordinarily high death rates. I don't want to get into the argument because I agree, all of us would agree here, the statistics cut both ways. You can make arguments in favor of the fact that guns cause death, other arguments that guns prevent death, but look at the reality in a common sense way. Look at the fact that we are a country infested with murder and death and gun injuries and suicide and accidents in the home. It cannot be a coincidence that the easy availability of guns in our country has nothing to do with high murder rates. That just can't be a coincidence. there are cultural differences. To be sure, Japan is not the United States, England is not the United States, but when you look at the crime rates in those countries and do all the comparisons you want, you can compare inner cities in one country with inner cities in another country and I know you can get all kind of data to support your conclusions, but at bottom the question really comes to what kind of society do you want to live in? Do you want to live in a society where we are forced to defend ourselves by guns, where the more the bad guys get guns the more the good guys have to arm and get guns? I’m reminded of the great episode from "All in the Family" where Archie Bunker gets to do an op-ed on television. And he says, "The way to solve the problem of airplane hijacking is very simple. Require everybody who gets on an airplane to have a gun. That way nobody will hijack an airplane." Do you want to get on a plane in which everybody has a gun?

And do you want to live in an America where everyone has a gun? If the answer to that question is no, let's acknowledge that the 2nd Amendment is anachronistic, has outlived its usefulness. Let's not abolish or amend the 2nd Amendment, let's construe it reasonably to permit gun control, to limit the ownership of guns to the right of self- defense, perhaps-- here I'm going to go further than you, perhaps also allow hunters to have limited access to guns. That's my position. Thank you.

### Moderator
Claim: Thank you, Alan Dershowitz. Our motion is: The Constitutional Right to Bear Arms has Outlived its Usefulness, and here to argue against this motion, David Kopel. He is research director at the Independence Institute, an adjunct professor at Denver University Stern College of Law, and associate policy analyst at the Cato Institute. Ladies and gentleman, please welcome David Kopel.

### Scientific Advocate (SA)
Claim: Thank you. Thank you. When I'm not in New York City, I spend just about all my waking hours in one particular case in a civil rights lawsuit in federal district court in Colorado where I represent 55 of Colorado's elected sheriffs who are suing against the unconstitutional extreme and highly immodest laws pushed down on Colorado by Mr. Bloomberg's successful lobbying last spring. In the United States Supreme Court I presented briefs on behalf of a very large national coalition of law enforcement organizations in District of Columbia versus Heller and McDonald versus Chicago. Included in that coalition are the two organizations-- national organizations of police trainers, the police who train the police. My clients, like the vast majority of law enforcement officers, according to every survey of law enforcement officers ever done, strongly support the Second Amendment and oppose laws which make it difficult for law-abiding citizens to own firearms for protection, because they believe that guns in the right hands substantially enhance public safety.

What's some of the evidence for this belief? Well, in the United States, when a burglary takes place against a home, 13 percent of the time, the victims are in the home. It's called a hot burglary or a home invasion burglary. In contrast, in England, the rate of home invasion burglaries is 59 percent. In the Netherlands, it's 45 percent. And this is because, in the United States, people can lawfully own guns for self-defense in their home and have them readily available for self-defense in an emergency, unlike in those other nations. Studies of working burglars in Pennsylvania, Massachusetts, Connecticut, and St. Louis have consistently found that burglars-- most burglars in the United States work quite hard, spend a large portion of their working day trying to make sure that there's nobody home because they perceive a very high risk of getting shot if they do come in when somebody is home.

And in fact, in the United States, the risk that a burglar will be shot exceeds the risk that he will go to prison. And if you think prison has some deterrent value against burglary-- and I certainly do-- then home self-defense has an even stronger protective value. The Centers for Disease Control is not a pro-gun propaganda organization. They conducted a national survey in 1994. They found that that year, there were 503 thousand defensive gun uses against burglars. Usually, without-- in the United States. Usually without a shot even being fired. And in 99 percent of those cases, when the victim confronted the burglar, the burglar decided it was time to leave work early. Now, if you look at when burglaries do happen against victims in the home, they frequently lead to not only a burglary, but to assaults against people in the home. If you simply take our 13 percent home invasion burglary rate and scale that up to the 45 percent rate of some other countries, that would lead to an additional half million assaults every year in this country. That, by itself, would raise the national crime rate by nine percent. Guns are not only useful against burglars and for deterring burglars, but for self-defense in general. This summer the National Research Council and the Institute of Medicine-- two federal research centers-- at the request of President Obama, put together an expert panel of the leading social scientists on firearms policy issues to provide recommendations for what future topics need to be researched, and also, on what topics has consensus been achieved among social scientists.

What they said in their report was that the social science is clear, that when a victim is attacked, using a firearm defensively leads to a lower rate of victim injury, to a lower rate of crime completion than any other protective strategy. It is the safest thing to do for the crime victim on a broadly-- broad-scaled statistical basis. And they also said the social science is clear, that guns are used at least for good, lawful, defensive purposes-- at least as often as they are used for criminal purposes. Of course the benefit to law enforcement of this is enormous, in the fewer victimizations; the fewer crimes, the fewer people they have to respond to and help so they can help other people.

Now, why is the Second Amendment necessary today? To protect people from local, bigoted governments. It was necessary in the civil rights era, when civil rights workers frequently had to arm themselves in the South for protection against the domestic terrorist organization known at the Ku Klux Klan, when local police were often complicit with the Klan. It's why the Deacons for Defense and Justice were formed in Bogaloosa Louisiana in 1965, to successfully provide armed protection to organizations such as the Congress of Racial Equality. It was necessary in Washington, D.C., where Dick Heller spent every day as an armed guard at the Federal Judicial Center and was not allowed by the D.C. City Council to use any firearm in his home, ever, for lawful self-defense against a violent home invader. It was necessary in Chicago, where Otis McDonald, a 70-year-old Korean War veteran received personal death threats from gangsters because of his anti-gang work.

And Chicago said, "Well, you can have a rifle or a shotgun." He knew how to use a rifle. He had been in the Korean War, but for his condition in the apartment he lived in with his physical strength and agility and the current status it was, the handgun was the right choice for him for self-defense, and the bigoted city council of Chicago would not allow him to use that, and that's why the Second Amendment was necessary, and it's necessary in New York City right now. If you have a handgun permit in New York City, you can go on a trip. You can drive from Brooklyn all the way to Seattle and lawfully carry that gun in your car in every state across the country and it's a good secure thing to have in case your car breaks down in the middle of the night someplace on a deserted road. But the New York City police department won't let you take the handgun out of the city. There is no rational basis for that prohibition. It is purely for the oppression of gun owners to the detriment of self-defense. It is a dangerous law and a Second Amendment lawsuit will likely be necessary to remove that.

I urge you to vote against this deadly dangerous proposition to vote for public safety based on the recognition that today the Second Amendment remains vitally necessary to the security of a free state. Thank you.

## Round 2

### Moderator
Claim: Thank you, David Kopel. And that concludes round one of this Intelligence Squared U.S. debate where our motion is: The Constitutional Right to Bear Arms has Outlived its Usefulness. Keep in mind how you voted at the top of the evening. Again, we are going to have you vote right after the arguments are concluded and the team whose numbers have changed the most in percentage point terms will be declared our winner. Now onto round two and round two is where the debaters address one another and take questions from me and from you in the audience. We have two teams of two. The motion is: The Constitutional Right to Bear Arms has Outlived its Usefulness. The team that's arguing for this motion that it's outlived its usefulness, Sandy Levinson and Alan Dershowitz.

We have heard them argue that number one they're telling you that they're not here arguing to ban all guns, they're not here arguing to repeal the Second Amendment, but they are arguing that the right to bear arms has no place in the constitution, that this should be left up to local governments and to states, that judges shouldn't be involved in making these policy decisions. They also are making the argument that the language as written really doesn't talk about a right to self-defense, that the right to bear arms is not the same thing as a right to self-defense, and if we want a right to self-defense, let's put it in the constitution, but right now it's just not there. The team arguing against the motion, David Kopel and Eugene Volokh are trying to get you to vote against this motion that the right to bear arms has outlived its usefulness. They say the right to self-defense is a basic human right and so is access to the tools needed to carry out and execute that right. They say clearly that they believe that guns do deliver that self-defense and went through several examples of that, but they also say that it needs to be in the constitution, because there's a bigotry at the local level against gun ownership and it needs the protection of a constitutional amendment much in the same way as civil rights have in the past.

So that's where the two sides stand on this basically. And I want to go to the side that's arguing against the motion, trying to convince this audience that the constitutional right to bear arms remains vital, has usefulness, and to bring to you something that your opponent, Alan Dershowitz, said, in which he said sure, you guys are arguing the right to self-defense. They concede that's a basic human right, but they also insist it's just not there in the language of the Second Amendment. It says right to bear arms, not the right to self-defense, and they say that's a difference. Which of you would like to take that on?

### Scientific Advocate (SA)
Claim: Real quick. The Second Amendment is the right to keep and bear arms. As Heller and McDonald say, it's the right to keep and bear arms for all lawful purposes, self-defense, hunting, target shooting, whatever.

It's not limited to self-defense. Certainly self-defense is the most important purpose of that right under Heller. That's what the Supreme Court said was the core purpose of the right, but the Supreme Court didn't say that was the only purpose of the right. The right is for all lawful purposes and modern constitutions, state constitutions say so more explicitly, but their point is the same as the Second Amendment.

### Moderator
Claim: Okay, so Alan Dershowitz, I think your opponent David Kopel is saying it's pretty obvious that's what everybody means by the right to bear arms.

### Conspiracy Advocate (CA)
Claim: Not at all. I think the Second Amendment historically gives the right of the people the right to use guns against their government. As Jefferson said over and over again, we need to have armed citizens in the state to make sure that there are no monarchies trying to take over. It was a right of revolution. There was no debate, as far as I know, about self-defense. It may have been implicit, but the Second Amendment's language and many of the people who are the strongest supporters of the Second Amendment are literalists.

They go to the original understanding. They look at the words-- why are you prepared to excise the first, whatever it is-- 10 words from the Constitution? "A well-regulated militia, being necessary to the security of a free state"-- are you prepared to concede that a well-regulated militia is no longer necessary to the security of a free state?

### Moderator
Claim: Uh, no.

### Moderator
Claim: David Kopel.

### Moderator
Claim: You want to--

### Moderator
Claim: David Volokh. All right. I'm sorry.

### Scientific Advocate (SA)
Claim: No.

### Moderator
Claim: Eugene Volokh.

### Scientific Advocate (SA)
Claim: No, I want neither. I want neither. So the-- I think, on this point, the court was quite right that if you look at the way the word "militia" was understood around the time of the framing-- and actually remains a legal definition of the term, although not a common lay definition-- militia meant the armed, adult-- at the time-- male citizenry, the times being what they were. And "well-regulated" meant basically well-functioning, well-trained. So, really, what they were saying is an armed, well-functioning citizenry-- well-functioning as a body that knows how to use its weapons-- is necessary to the security of a free state. And that because of that, because-- and this is a preamble that explains the rationale or part of the rationale for the right-- because of that, the government shouldn't be able to disarm the people. But--

### Moderator
Claim: Now there's-- was point to defend the state or to defend your own home?

### Scientific Advocate (SA)
Claim: The point was both. And that is one of the things that the court, I think, correctly

### Scientific Advocate (SA)
Claim: Here-- Alan, here's what you're overlooking. If you--

### Moderator
Claim: David Kopel.

### Scientific Advocate (SA)
Claim: --read things like Stephen Halbrook's, "The Founders' Second Amendment" and the other intellectual sources, very clearly they understood self-defense against a lone criminal and self-defense against a tyrannical government as the same thing, except the latter was larger in scale. It's all self-defense, all the way up, all the way down.

### Conspiracy Advocate (CA)
Claim: So, what does "well-regulated" mean? What you're trying to do is now say that everybody who owns an individual gun has to be a part of a regulated militia. They have to come to the green every day and march and--

### Moderator
Claim: Well, but they're not--

### Moderator
Claim: --they're-- but they're not saying that, Alan. They're not saying that.

### Moderator
Claim: No.

### Moderator
Claim: They're saying-- I think what you're saying-- and I'm not taking sides, but I just want to bring clarity to-- I think that's a straw dog. I think they're saying that implicit in the fact that the-- if there were a militia, that the guys have the guns in the house, and they could also defend their house. And they need to have them to use them, whether their purpose was a militia or not.

### Conspiracy Advocate (CA)
Claim: But we don't have a well-regulated militia now. We don't have any kind of militia now. So I think you're conceding that the first part of the amendment has outlived its usefulness. We win at least the first half of the debate, right?

### Moderator
Claim: David Kopel. And I'd like you to respond to what he just said.

### Scientific Advocate (SA)
Claim: Sure. Thomas Cooley, the great constitutional scholar of the latter 19th century, addressed your exact point. And he said that the interpretation you're following would defeat the purpose of the Second Amendment, because that would mean the government, by neglecting the militia, could thereby destroy the right to arms.

We might have more public safety if there were something to encourage more regulated, well-trained citizen defense patrols, for example, in communities. But that's up to the government--

### Conspiracy Advocate (CA)
Claim: Like the Ku Klux--

### Scientific Advocate (SA)
Claim: Wait--

### Conspiracy Advocate (CA)
Claim: Like the Ku Klux Klan?

### Scientific Advocate (SA)
Claim: Well, we can't force them to do that.

### Moderator
Claim: Let me bring in Sandy.

### Scientific Advocate (SA)
Claim: But this government's neglect does not destroy the underlying right.

### Moderator
Claim: Sandy Levinson. I want to return to this issue of the-- of the absence of an explicit right to self-defense in the Constitution. You want to-- you would love to draw up the Constitution all over again. You'd like to start all over. And if you did, would you write in whether it's an amendment or in the body of the Constitution-- would you write in a basic right to self-defense?

### Conspiracy Advocate (CA)
Claim: I would certainly consider it. It makes a lot of sense. But quite obviously, as I suggested in my opening remarks, it's a very, very capacious right. Does it extend to Martha Stewart, a convicted felon? And to me, it seems the answer should be yes. If Martha Stewart had knocked over a bank with a gun, I'm not sure that I would say she preserves her constitutional right to self-defense.

What about non-U.S. Nationals who live in the United States? You know, do they not bleed? Do they not have lives that are threatened? And then what about illegal aliens? The Fifth Circuit, as I'm sure Eugene and David both know, split 2-1 on whether or not a federal law that prohibits illegal aliens from possessing guns is constitutional. Their argument was that the point of the original Second Amendment-- and I think they're correct. I didn't do adequate justice to Bob Rosenkranz's initial introduction-- I think the historical origins of the Second Amendment really do have to do with citizen militias and organizing to overthrow corrupt governments. And the argument was that an illegal alien isn't part of the American community politically, which is certainly true. That doesn't mean that an illegal alien has no right to self-defense.

### Scientific Advocate (SA)
Claim: The right of the people to bear--

### Moderator
Claim: Eugene Volokh.

### Scientific Advocate (SA)
Claim: --arms throughout American history has had a self-defense component as well. We see that in the Pennsylvania constitution of 1776, which talked about the right of the people to keep and bear arms in defense of themselves in the states later on was more clearly even changed to each citizen defense of himself--

### Conspiracy Advocate (CA)
Claim: But that wasn't put in the U.S. constitution. They knew about that and they didn't put it in.

### Scientific Advocate (SA)
Claim: But they talked about the right of the people to keep and bear arms. What you're suggesting is that the Second Amendment-- you're suggesting the Second Amendment is obsolete in part because it used-- the framers used the term keep and bear arms there in a way that's different from the way that it was being commonly used in the coordinate state constitutions of the time. I think you're creating obsolescence of your own making. You're interpreting it in a strange way as saying well, it wasn't intended to deal with the self-defense, and now you're saying it's obsolete. Well, I'm saying it was intended throughout to deal with self-defense. It was also aimed at a means of deterring government tyranny, but the interest of self-defense has been always around, and if you look at court decisions of the early 1800s, all the time--

### Moderator
Claim: Eugene, let's let Alan Alan Dershowitz.

### Conspiracy Advocate (CA)
Claim: --focusing on the wrong words. I'm not denying that the right to bear arms might have some current relevance as part of a right of self-defense. What I am arguing is that prelude to the operative words of the amendment clearly have become obsolete, a well-regulated militia being necessary to the security. Now, the answer that David gives is you want the Deacons of Justice to be able to come and have an armed conflict with the Ku Klux Klan. Now I was in the south during the Civil Rights Movement. The last thing Martin Luther King wanted was to arm the people and the civil rights workers. He wanted to confront violence with peace, and a well-regulated militia would've included the Ku Klux Klan. They were the citizens. They were the ones who were worried about the government taking away their civil right to have a segregated community. And the answer that my opponents give is if the Ku Klux Klan is armed, then we ought to arm civil rights workers, and let's have a war. I think Martin Luther King gets the better of that argument.

### Moderator
Claim: I mean, Alan, David Kopel. I don’t hear them saying that or even coming close to implying that. Even though it's a great-- that was a great moment. But I want The point is--

David Kopel.

### Scientific Advocate (SA)
Claim: --those who want-- the majorities that want to oppress minorities like the Ku Klux Klan with local police connivance, they're always going to have arms and I applaud your presence in the south. You perhaps might not have been on the summer March from Mississippi to Memphis led by Dr. King where the Deacons for Defense were there and, in fact, were providing personal security for Dr. King himself.

### Moderator
Claim: All right. I want to move on--

### Conspiracy Advocate (CA)
Claim: And how did that end up for Dr. King?

### Scientific Advocate (SA)
Claim: Huh?

### Conspiracy Advocate (CA)
Claim: How did that end up for Dr. King? Not very well.

### Moderator
Claim: I want to move on to the--

### Scientific Advocate (SA)
Claim: The availability of a gun.

### Moderator
Claim: I want to move on to another--

### Scientific Advocate (SA)
Claim: I don't understand what you're saying. The assassins are going to have the guns. The question is whether people ought to be able to have guns to defend themselves.

### Conspiracy Advocate (CA)
Claim: The assassins have an easier time getting the guns when they're easily available in society.

### Scientific Advocate (SA)
Claim: How do you propose making it hard for an assassin in a country-- How do you propose making it hard for a political assassin who is willing to throw away the rest of his life essentially for his act, making it hard for him to get a gun in a country where there are 300 million guns.

### Conspiracy Advocate (CA)
Claim: That's the point. That there are 300 million guns. I want to live in a country where there are not 300 million guns.

### Moderator
Claim: All right. I want to stop this for a moment. I want to stop this. We are starting to turn into a gun control debate here, which is not precisely what we're doing. What we're trying to focus on is the function of this power being enshrined in the constitution or not, and I want to return to that by going to something that Sandy Levinson said where you basically were telling the other side that they don't really need to have this right enshrined in the constitution and protected, because the political process as it is is already tilting, I think was the word you used, towards increasing gun rights.

And I want you to take 30 seconds to push that point and then I'd like to hear the response from your opponents, because I think that they said the opposite.

### Conspiracy Advocate (CA)
Claim: Okay. Ninety percent of the American public, rightly or wrongly, but 90 percent of the American public thought that the Senate should at least take a vote on enhancing background checks. It never got to the floor of the Senate. Last night I think the NRA invited people before the debate to chime in with their views, and I was told before we came out that the current vote is something like 43,000 against the motion and--

### Moderator
Claim: You mean on the Intelligence Squared website?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: Yes, we were-- we experienced a blizzard of votes.

### Conspiracy Advocate (CA)
Claim: Right. And--

### Moderator
Claim: And it's 90-- it's 46,000 against the motion and 700 for the motion.

### Conspiracy Advocate (CA)
Claim: The strongest argument for substantive constitutional rights is when you believe that a vulnerable minority is likely to be victimized by what Americans learned to call "the tyranny of the majority." Whatever your views are on gun control, at least right now-- and throughout most of American history-- it is so wildly unlikely that the-- however many people own the 300 million guns-- because most people who own guns, I think, own multiple guns-- that they are comparable to Jehovah’s Witnesses, say, or some other vulnerable minority that they need the special concern of judges, basically, to make up public policy for the entire country.

### Moderator
Claim: Okay. Let's--

### Scientific Advocate (SA)
Claim: So--

### Moderator
Claim: --well, actually-- did-- I'd like to hear David-- from David on that--

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: --because you raised this point, that in fact, the constitutional amendment was required as a bulwark against the political process. And your opponent is saying that the winds are blowing so heavily in your-- in your direction, that that's not necessary.

### Scientific Advocate (SA)
Claim: Constitutional rights are not only for persecuted minorities. I don't think ABC, CBS, the New York Times, and the New York Daily News are comparable to Jehovah's Witnesses either. And it's very important that there be a strong First Amendment to protect them. And in Nebraska, where the right to arms is culturally strong, the Second Amendment is still necessary for exactly one of the issues you raised-- the right of legal permanent resident aliens to obtain concealed carry permits to carry handguns for lawful protection as law-abiding American citizens can do.

And unfortunately, there are in this large and diverse country just about anything that you can say is nationally popular is going to be nationally unpopular with some local group of people who don't celebrate diversity and respect all rights. And in places like New York City and San Francisco and Chicago, with their irrationally extreme anti-gun administrations-- absolutely the Second Amendment--

### Moderator
Claim: Okay. So, then what would--

### Moderator
Claim: look like without the Second Amendment? Everything else being equal. I know it's awkward, but everything else being equal, if the protection weren't there, where would we be in terms of gun ownership in this country?

### Scientific Advocate (SA)
Claim: People in Washington DC would have no right to defend themselves in their home against a violent home intruder, for example.

### Conspiracy Advocate (CA)
Claim: Even if they voted that way-- this is interesting. What you're--

### Moderator
Claim: Alan Dershowitz.

### Conspiracy Advocate (CA)
Claim: --in argument for diversity, that would deny the people of New York the right to show their diversity by saying, "We don't want to be like Montana. We would much prefer to have fewer guns." That argument is rejected in the name of diversity?

### Scientific Advocate (SA)
Claim: Diversity is not suppressing someone else's rights. That's no part of diversity. Diversity is respecting everyone's human rights fully.

### Conspiracy Advocate (CA)
Claim: And respecting them from a point of view of the majority prevails when you have different views, and different cultures, and difference societies, and different attitudes, and different approaches. And if the people of New York City have a different view from your view, why should they not have the right to express that view and have it implemented?

### Scientific Advocate (SA)
Claim: Because--

### Conspiracy Advocate (CA)
Claim: Isn't there a right to a gun-free society as well? Why don't we have that right?

### Scientific Advocate (SA)
Claim: Is there a right to--

### Moderator
Claim: Eugene Volokh.

### Scientific Advocate (SA)
Claim: Is there a right to a blasphemy-free society? Is there a right to a--

### Conspiracy Advocate (CA)
Claim: No, because blasphemy doesn't hurt anybody.

### Scientific Advocate (SA)
Claim: So, but the whole point of individual rights are that they are trumps on majority rule.

### Conspiracy Advocate (CA)
Claim: Sandy Levinson said, you need to have the right to blasphemy, otherwise the Jehovah's Witnesses would be prosecuted. The reason ABC and NBC have the First Amendment rights is we can't distinguish between them and the Jehovah's Witness handing out a leaflet. The basic right belongs to the Jehovah's Witness. The derivative right belongs to ABC--

### Moderator
Claim: --that's the only reason we have--

### Moderator
Claim: Hold on. Sandy Levinson is much too polite for this debate, so I'm going to-- I'm creating an opening for him and you're to step through, Sandy.

### Conspiracy Advocate (CA)
Claim: All right. I'm just a Texan. I think we ought to be aware that there's something strange. Again, what everyone's views are about gun rights in the United States-- there's something strange in referring to them as a human right, because-- and here's, I think, where Alan's point comes home-- it really is quite remarkable that among the roughly 190 countries or so that are currently in the U.N., there are a grand total of four that recognize some kind of constitutionalized right to bear arms. And you discover that the Mexican constitution allows reasonable regulation. So, it may be-- I mean, this is-- again, topic for a different sort of conversation-- it may be that there is something about American culture that recognizes that it is a right within the United States.

It's part of American exceptionalism that guns are treated much more seriously than anywhere else in the world, but human rights arguments really do have a universalistic overtone. We talk about intervening in foreign countries because they don't recognize human rights. So does David suggest that we invade--

### Moderator
Claim: But aren't they saying--

### Conspiracy Advocate (CA)
Claim: --one or another of the 108 countries--

### Moderator
Claim: Just for clarity on what they said. They didn't say that guns are the basic right. They said self-defense is the basic right.

### Conspiracy Advocate (CA)
Claim: But guns are necessary for self-defense. I think that's what David means.

### Moderator
Claim: Eugene Volokh.

### Scientific Advocate (SA)
Claim: I don't think American rights should be obsolete just because foreign countries don't agree with us on that.

### Conspiracy Advocate (CA)
Claim: No. I'm talking about-- no. I'm not making that argument. I'm simply talking about nomenclature that it's one thing to say we in America are committed to certain rights, some of which look very, very odd to the rest of the world. We could talk about hate speech in this context, and you and I both agree that hate speech is protected by the 1st Amendment.

Most countries around the world don't protect hate speech, and they're decent liberal countries who simply have a different understanding of what free speech means. All I'm saying is that an argument based on the particularities of American culture is very different from an argument based on human rights.

### Moderator
Claim: All right. David Kopel, would you like to respond to that?

### Scientific Advocate (SA)
Claim: The United States is unique with its exclusionary rule against illegally seized evidence being used in court. We have much stronger rules against the establishment of religion than most other countries do, but I think the fact that many countries have gone away from what was traditionally their respect for much of their history of the right to arms and of the right of self-defense, does not denigrate that right from it existing at all as a human right. As the United States Supreme Court said, the right to assemble and the right to bear arms are both found wherever civilization--

### Conspiracy Advocate (CA)
Claim: Which countries have moved away from the basic right of self-defense?

### Scientific Advocate (SA)
Claim: Oh, England.

### Conspiracy Advocate (CA)
Claim: England?

England. Self-defense. You mean to have it enacted stand your ground laws?

### Scientific Advocate (SA)
Claim: No. It means their guns laws are structured--

### Conspiracy Advocate (CA)
Claim: No, no, no. I'm talking about self-defense.

Great Britain common law provides for a fundamental right of self-defense. I challenge you to name one country that has abolished the right of self-defense.

### Scientific Advocate (SA)
Claim: England has gravely restricted it in practice. Fortunately under intense popular pressure they had some reforms a couple of years ago, which restored some of it, but they have the principle of proportionality.

### Conspiracy Advocate (CA)
Claim: Of course they do. That makes sense.

### Scientific Advocate (SA)
Claim: Well, no.

Not as it works in England, because if you're a woman and a guy who weighs 200 pounds more than you is beating you to death with his hands and fists, under English law you can only-- could only fight back with your hands and fists. You couldn't shoot that person, because then you, the victim, woman, would be escalating.

### Conspiracy Advocate (CA)
Claim: On the other hand, the NRA proposes a law whereby if you're in your car and can go from zero to 60 in one second, somebody comes over to you with a knife and you have the option of running away, you have the right to stand your ground, pull out your oozie and kill him in cold blood.

That's the NRA's position on self-defense. There are absurd NRA positions on self- defense. There are reasonable--

### Moderator
Claim: All right. Again, we're not debating--

### Conspiracy Advocate (CA)
Claim: I prefer the English rule to the Florida rule.

### Moderator
Claim: --the NRA's stance on gun control tonight, but we are-- this point did come up in terms of the constitutional issue. Your opponent-- speaking out to the side that's arguing that The Constitutional Right to Bear Arms has Outlived Its Usefulness, your opponent said well, you know, the constitution-- the amendment may be there, the right to bear arms may be enshrined in the law, but that doesn't mean that you can't limit gun control. That, in fact, the Heller decision specified all sorts of situations, guns in the hands of mentally ill people, felons, et cetera, that as it is your hands aren't tied, in fact, to effect gun ownership laws in the United States, and I just want to have you respond to that and then hear what your opponent says in response.

### Conspiracy Advocate (CA)
Claim: You know, I agree with that.

### Moderator
Claim: Sandy Levinson.

### Conspiracy Advocate (CA)
Claim: Most Americans, if you poll them, believe a) that there is some kind of fundamental individual right to own firearms, and b) that there ought to be reasonable regulation. So, the question is who ought to decide at the end of the day what counts as reasonable regulation? I believe precisely because there's so much difference-- good faith difference of opinion, that this is an America of the 21st Century, a subject for legislative resolution. You won't like some of the particular solutions, but that's what federalism and political diversity is about. But none of us on this panel is arguing that the state can never ever limit guns, and at least as a political preference, neither Alan nor I would support in the United States in the 21st Century a proposal to ban any and all firearms, but we're talking about reasonable regulation and who ought to make reasonable regulation.

### Moderator
Claim: But they're saying that the existing amendment does not-- is not an obstacle to reasonable regulation.

### Conspiracy Advocate (CA)
Claim: Well, but there's a tension here, because-- I mean, for the first 200 years of our history, the Second Amendment really played no role in American constitutional law, if you define that as judicial decisions, especially at the national level. It's only been in the last six, seven years that it's played any role. So, the debate, in part, as well, should the Second Amendment now really be invigorated so that five to four majorities of the Supreme Court will decide whether or not Martha Stewart should be able to have a gun for self-defense? And it appears, although Justice Scalia didn't offer even an iota of a reason-- that he said, "No, she doesn't get it." Or do you want these-- let's say, hashed out?

Either the Second Amendment really has some genuine bite to it or it's an expressive aspect of the Constitution--

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: --as it has-- as it was for roughly for the first 200 years of our history.

### Moderator
Claim: I want to give Eugene Volokh a chance to respond. But after that, I'm going to come for questions for you in the audience. And the way that will work is just raise your hand. I'll call on you. Well, a microphone will be brought to you. We will ask you to wait until the mic reaches you so that the radio broadcast folks and the folks listening on the live stream can hear you. I'll ask you to state your name and I'll ask you to ask a question that's focused on the topic tonight. Eugene Volokh.

### Scientific Advocate (SA)
Claim: So let me answer Sandy's point, and working, also, a point he made about the background checks failing in Congress. My colleague, Adam Winkler at the UCLA Law School-- I don't think anybody would think as a hardcore NRA-supporting, Second Amendment maximalist-- I think made a very good argument that the thing that probably most defeated background checks was the proposed ban on the so-called assault weapons, which are semi-automatic weapons that are really functionally not much different than other kinds of weapons. But they were singled out for specific prohibition. He said that poisoned the well, that after assuring people, "Oh, we're not going to come to take your guns," people said, "Whoa, they are coming to take our guns." And that caused people to dig on. You're talking about the functions of individual rights. One of the functions of individual rights is to provide enough of a detente in these kinds of social battles, especially culture war battles, that a side could say, "Look, we're confident enough they're not coming to take our guns, that if what is on the table is a background check, it might pass just as it has passed in the past "-- in the early 90s. So, so, that's actually one advantage that the Second Amendment-- so securing an individual right.

But more specifically, the call into question-- the quote is about the right to bear arms, specifically the right to bear arms being recognized as an individual right provides. If that were called into question, if that were repealed or people would say, "Well, we would repeal it if it weren't for our better political sensibilities," that's the sort of thing that would poison the well further. So if you want to actually get a background check passed, you're much better off with a Second Amendment respected and firmly recognized as part our Constitution, and then question and said to be something that's ripe for repeal.

### Moderator
Claim: Let's go to some questions from the audience. And right there on the end. Oh, let me just say one thing, because I need to do this for the radio broadcast. And I appreciate you waiting a second. Tonight's debate is being broadcast worldwide on our website, IQ2US.org and on fora.tv. And if you're actually watching the live stream, we want to hear from you, too, during this part of the debate. You can send us questions on Twitter or Facebook with the hashtag #gunsdebate, so we won't miss it.

And be sure to include your city, state, and your first name, at least. And I want to remind you that we're in the question and answer of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters-- two teams of two-- debating this motion: The Constitutional Right to Bear Arms Has Outlived its Usefulness. We're going to audience questions.

### Moderator
Claim: Thank you. This question is for those arguing against the motion. When you talked about self-defense being a great spectrum from against personal security and also against the tyranny of the government, and also talking about how the Second Amendment, in some circumstances, is anachronistic, can you let me know what it looks like today, in the 21st century, for someone to defend themselves with arms against the tyranny of the government?

### Moderator
Claim: David Kopel.

### Scientific Advocate (SA)
Claim: Well, to start with, it's normal defensive uses when you happen to be in a neighborhood that is politically powerless.

In Chicago, like a lot of places, there are some neighborhoods that have a very strong police presence and a strong deterrent effect, and there are other neighborhoods that, for whatever reasons, get essentially very little protection. And when the government steps aside so that the rapists and thugs can do to you as they will, that is a form of at least of misgovernment, so people being able to protect themselves matters there. And you can look at the United States, fortunately, we don't need to protect ourselves against government in the sense that we were doing in 1776, but you can look around the world at the various tyrannies that exist and people sometimes using guns successfully protect themselves. Now I would point out, every genocidal government of the last century has assiduously disarmed the intended victims of genocide beforehand, and you can say well, if you have handgun what good is that going to do you against a tank?

Well, they take the view, and they're the ones who are carrying out the genocide, they take the view that if there is any resistance, if even one of our-- out of 100 of our secret police were putting people on cattle cars gets shot, that could really mess up our genocide program.

### Moderator
Claim: David, let me interrupt you a second, because I feel that you maybe slipped the question a little bit, not overly. No, no. I'm not saying that to be disrespectful, because the part of her question you answered, which was-- her question was related to where in the modern world in the United States would there be a militia resisting its government, and you described a situation in which the government was absent and so it fulfilled the function the government wasn't doing. But she asked a different question. Is there a scenario you see in this country, I think, in this country where you would need to take up arms against that absent police force or any other force that represents the established government?

### Scientific Advocate (SA)
Claim: Not presently, but nobody in the United States in 1760 thought they'd have to be fighting the British 15 years later, and nobody-- no sane person in Germany in 1930 thought that the country would fall-- would within 30 years fall into the hands of genocidal maniacs.

### Conspiracy Advocate (CA)
Claim: Well, how do you explain the fact that the highest ratio of opposition to free availability of guns are in the communities that have been subject to genocide? The Jewish community, the African American community, and other communities that have been subject to genocide are the ones that are most opposed to vigilante people in America having guns. There must be-- either you're smarter than they are or they're self- interest is correct and you're wrong about genocide.

### Scientific Advocate (SA)
Claim: You are stereotyping those people. There's far more diversity--

### Conspiracy Advocate (CA)
Claim: I'm counting them.

### Moderator
Claim: There's--

### Conspiracy Advocate (CA)
Claim: I'm polling them. I'm saying majority wins.

### Scientific Advocate (SA)
Claim: And if you look at the public opinion polls of the black community, they support gun ownership as a principle. They support the Second Amendment and they actually have a favorable view--

### Conspiracy Advocate (CA)
Claim: At much lower ratio than White Anglo Saxon Protestants, right?

### Scientific Advocate (SA)
Claim: Blah, blah, blah. The point is--

### Conspiracy Advocate (CA)
Claim: Now that's an intelligent response.

### Scientific Advocate (SA)
Claim: So your point is blacks are pro NRA, but they're not as pro NRA as white people and therefore what?

### Conspiracy Advocate (CA)
Claim: Therefore it seems to me people know their own self-interests, and if you look at the ratio of people in various ethnic groups, I'm not stereotyping, as I say, I'm polling, you see that gun ownership favorability depends a great deal on cultural background, on background, historical background, and the very people that have been most subject to genocide are the very same people generally that seem to have a lower support for gun

### Moderator
Claim: Which has what to do with our motion?

### Scientific Advocate (SA)
Claim: Can I--

It has to do with his point about genocide.

### Moderator
Claim: Okay. What does your point have to do with our motion?

### Scientific Advocate (SA)
Claim: Can I offer a slightly different perspective?

### Moderator
Claim: Eugene Volokh.

### Scientific Advocate (SA)
Claim: I actually, and this is directly related to the motion. I’m not sure to what extent today private gun ownership in a country like America would be effective in stopping government tyranny.

There are plausible arguments that by making tyranny more costly it may make it less likely even if ultimately they get super-tyrannical they could crush all opposition. Plausible arguments to the contrary. But the question, recall, is whether the right to keep and bear arms has become obsolete. What I'm saying is, there used to be two main functions, one deterrence of government tyranny and one assurance of self- defense. It's possible that today the first function is not really achievable, but the second function is very much out there. I don't see the right as having become obsolete if one aspect of it, given changes in the structure of the military and the security apparatus and changes in modern weaponry, if that function is no longer usable, I'm not sure, but it may very well not be.

### Moderator
Claim: All right. I want to bring up another question. Very, very briefly, because I want to get in more questions.

### Conspiracy Advocate (CA)
Claim: I think we're dancing around the fact that--

### Moderator
Claim: Sandy Levinson.

### Conspiracy Advocate (CA)
Claim: --there are at least thousands, and maybe even a couple of million Americans who believe we do live in a tyranny, who are organized in militia movements.

And all of the focus on self-defense and the idea that the Second Amendment-- the original Second Amendment is historically anachronistic, with regard to "Oh, everybody believes the current United States is just wonderful," there are some people-- I don't agree with them, in terms of their own politics, but there are some people who don't think it's wonderful and who want to drill and know how to use arms against the possibility of engaging in armed revolt. Now, do you support that as a protected Second Amendment right? That should be constitutional?

### Moderator
Claim: Oh, I'm sorry. Eugene-- take--

### Scientific Advocate (SA)
Claim: That's an interesting question.

### Moderator
Claim: --15 seconds on this or--

### Scientific Advocate (SA)
Claim: I'm sorry. So--

### Moderator
Claim: --and the

### Scientific Advocate (SA)
Claim: --right to drill?

### Conspiracy Advocate (CA)
Claim: Militias.

### Scientific Advocate (SA)
Claim: I think probably would be-- I mean, if it initially--

if it's a conspiracy to actually engage in revolution? No.

### Conspiracy Advocate (CA)
Claim: No. Just to drill.

### Moderator
Claim: Yeah, why don't you stand up? Yeah.

### Scientific Advocate (SA)
Claim: Probably.

### Moderator
Claim: You're wearing a button. That makes me nervous. a mic will come down this side. Sorry. And can you tell us your name, or at least your first name?

### Moderator
Claim: Yes. Hello. My name is Lea. And I have a question for all of you, really, is why do you think the Second Amendment was intended to protect the rights of Americans to rise up against a tyrannical government when Article 1 in the constitution allows armed citizens in militias to suppress insurrections, not to cause them? The Constitution defines treason as "levying war against the government" in Article 3--

### Moderator
Claim: I'm going to stop you there, because you had a question mark after the--

### Moderator
Claim: I did.

### Moderator
Claim: --part.

### Moderator
Claim: I did.

### Conspiracy Advocate (CA)
Claim: You know, I think there's a deceptively easy answer--

### Moderator
Claim: Sandy Levinson.

### Conspiracy Advocate (CA)
Claim: --to your question. The 1787 Constitution did not include the Second Amendment. The Second Amendment, as Alan would emphasize, is part of the Bill of Rights that were added in 1791 at the behest of people who really were very suspicious of this new national government that was created by the Constitution.

And, you know, one could quote Emerson or Walt Whitman, that the Constitution contains contradictions. And you have put your finger on a very key contradiction--

### Moderator
Claim: Do you disagree enough with that to want to argue with it-- David Kopel?

### Scientific Advocate (SA)
Claim: The Supreme Court justice Story--

### Moderator
Claim: David Kopel.

### Scientific Advocate (SA)
Claim: --would disagree that there was a contradiction there, as he explained in his treatises. That insurrection is an illegitimate, violent act-- violent action against the government. But if the Second Amendment militias, led by their state governments, were ever necessary to overthrow a tyranny, that would not be an insurrection--

### Conspiracy Advocate (CA)
Claim: Like in the Civil War.

### Scientific Advocate (SA)
Claim: That would be--

### Conspiracy Advocate (CA)
Claim: Like the Civil War, right?

### Scientific Advocate (SA)
Claim: The-- let me talk, please. That would be a restoration of constitutional order. That's what Justice Story's viewpoint is. It would be a dictatorship that was the insurrection, that was lawless, that was at war with the Constitution.

### Conspiracy Advocate (CA)
Claim: So was the Civil War--

### Moderator
Claim: Wait, Alan, hang on--

### Conspiracy Advocate (CA)
Claim: --a legitimate

### Scientific Advocate (SA)
Claim: No, no.

### Moderator
Claim: Are you-- David, are you done?

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: Okay. What-- Alan.

### Conspiracy Advocate (CA)
Claim: So, was the Civil War legitimate or-- was it a legitimate insurrection or an illegal insurrection?

### Scientific Advocate (SA)
Claim: I have an answer to that.

### Moderator
Claim: Eugene Volokh.

### Scientific Advocate (SA)
Claim: Which civil war? Do you mean the civil war against the federal government or the civil war that was fought between 1775 and 1781, in the U.S.?

### Conspiracy Advocate (CA)
Claim: No. The one that we all refer to the "Civil War."

### Scientific Advocate (SA)
Claim: So, the answer is--

### Conspiracy Advocate (CA)
Claim: With a capital T, a capital C, and a capital W. A guy involving Abraham Lincoln. Remember that one?

### Scientific Advocate (SA)
Claim: So the answer--

### Conspiracy Advocate (CA)
Claim: Was that a legitimate insurrection? That was lead by state militias.

### Scientific Advocate (SA)
Claim: So the answer is--

### Moderator
Claim: Someone help me out here with the question.

### Scientific Advocate (SA)
Claim: --that we think the Revolutionary War was legitimate, partly because we were the ones on the winning side. But partly because we think it was a just insurrection; that we think the Civil War is illegitimate because it was an unjust insurrection. But to return to your question, it's an excellent question. But if you'll look at the framing era documents and the post-framing documents-- and for that matter, the pre-framing documents, Sir William Blackstone's Commentaries on the Laws of England-- it was understood that while, obviously, every government must be able to suppress revolutions against it-- and it will, whether it's a tyrannical government or not-- one merit that was seen at the time-- again, I'm skeptical about it today-- but without question, historically seen at the time in an armed citizenry is it would preferably deter tyranny, and if necessary, overthrow it, recognizing that if it fails, that they'll be hung-- hanged for treason. That was understood.

### Moderator
Claim: All right, sir.

### Moderator
Claim: My name is John Donahue. I thought I heard David Kopel say that you were more likely to be shot as a burglar than to go to prison, which must be wildly off, because tens of thousands of burglars are in prison, and very few people are actually shot by homeowners. But my question goes to the question of an anachronism in light of the experience of other countries similar to the United States. So for example, Australia, after experiencing--

### Moderator
Claim: Sir, I just want to ask you to zoom in on your question.

### Moderator
Claim: Yeah. So, to focus on Australia, in 1996, they had experienced a horrific mass murder.

And 12 days later, they decided to abolish all semi-automatic weapons and to abolish the right to use guns--

### Moderator
Claim: Sir, I'm sorry. rules. I need you-- not too much premise and just get to the question, please.

### Moderator
Claim: Okay. So the question is why, in light of the fact that their murder rate has dropped substantially since that time and is now about one-fourth or one-fifth the rate of the murder rate in the United States, do you parade these horribles as emanating from removing the Second Amendment if it seems as though the Second Amendment operates more in the way that Alan Dershowitz has suggested as an impediment to avoiding homicide?

### Moderator
Claim: My concern with that question is I think that one of the debaters here said that there's always going to be evidence on both sides on the impact and that we would just get into descending studies.

### Scientific Advocate (SA)
Claim: Well, the question was asked--

### Moderator
Claim: And it would be a wash.

### Moderator
Claim: Well, no, because we have other things that we want to get onto. So, I would like to move on to them.

### Scientific Advocate (SA)
Claim: Well, I just want to say for the record I'm not sure of the factual assertions behind that question.

### Moderator
Claim: Exactly right and these guys will say it is and you'll have studies and nobody here has read them. Sir? You were with us before, weren't you?

### Moderator
Claim: Yes I was.

### Moderator
Claim: How old were you last year?

### Moderator
Claim: Twelve.

### Moderator
Claim: You were 12 last year?

### Moderator
Claim: Well, 13, I think. I don't remember exactly.

### Moderator
Claim: You did a great question on our Israel debate, and you're with Collegiate School, right?

### Moderator
Claim: Yes.

### Moderator
Claim: This whole row. Welcome to our debate, guys. Thanks for coming.

So you have to be as good as you were last year when you were 12.

### Moderator
Claim: Okay. So my question is for the people who are arguing against the motion. And my question is if-- I think-- something that I'm a little unsure of in your argument that I think is a bit of a contradiction. You've argued that you're not going to be able to successfully impede the right-- the ability of criminals to gain weapons.

You used Martin Luther King at being politically assassinated as an example of that. Yet, you also sort of stated that--

### Moderator
Claim: Hey, just because you're 14 doesn't mean you can't zoom in on a question. So go for it.

### Moderator
Claim: If-- let's see-- how will having political assassins not being able to access guns be related to people able to defend themselves against burglars in their home? If a burglar is able to get a gun, isn't that something a bit different than a political assassin who's willing to throw away their life? And so--

### Moderator
Claim: Okay. Okay.

### Moderator
Claim: --this sort of self-defense situation.

### Moderator
Claim: Very quickly, David Kopel.

### Scientific Advocate (SA)
Claim: As your question recognizes, there's a wide variety of criminals with different intensities and motivation, and so a political assassin is sort of at the top of the scale in terms of long-term planning, and you can have other criminals who are much more casual.

So, one of the anti-gun control arguments is what you're referring to-- the futility thesis. That nothing you do is ever going to stop criminals from having guns, and that is true for many criminals who are determined to get guns. Can you at the margins of, you know, 1 percent or 5 percent, delay when they get the gun, or can you also have laws that say well, we can't really shut down the black market, but we can say that if you're a convicted felon for a genuinely violent crime and you're found carrying a gun, that there's going to be a severe sentence and that-- the studies do show that has some deterrent effect on them carrying guns. So I think you can't--

### Moderator
Claim: I want-- again, you know, I'm sorry to be stickler about this, but we'll wander all over and you're going to have to vote on this amendment language shortly, and that's why I'm trying to keep the questions focused on that. So, sir, I hope you're going to deliver for me. And it's a tough one, by the way. I don't think it's particularly easy to frame a question on this one.

### Moderator
Claim: Hi. My name is Fortuna. I have a question to David and Eugene. So, if you guys were to write constitution from scratch, what words would you put in place of the Second Amendment to properly represent the point of view you are defending?

### Moderator
Claim: Great question. And how-- language that you could come up with that would defend against these guys and give you what you want. Who would like to take that? David Kopel or Eugene Volokh?

### Scientific Advocate (SA)
Claim: I think Eugene is about to give you a quote, but the short answer is-- Modern state constitutions say it in modern language, and so any one of those recent ones, Wisconsin, for example.

### Moderator
Claim: You would take out that whole militia thing?

### Scientific Advocate (SA)
Claim: So let me read to you the 1998 Wisconsin provision, which was close backed by then state Senator Russ Feingold, not exactly the most conservative of conservatives. It says, "The people have the right to keep and bear arms for security defense, hunting, recreation, or any other lawful purpose."So that's what Senator Feingold was willing to say. I actually don't think that the preamble today-- the militia clause today-- is terribly helpful. If I had to re-write it, I'd probably end up-- I wouldn't worry about the possible political blowback that might cause even more infringement on this issue. I probably would--

### Moderator
Claim: Eugene-- just when you turn your head--

### Scientific Advocate (SA)
Claim: Got it.

### Moderator
Claim: --can you be careful of the mic?

### Scientific Advocate (SA)
Claim: So I probably wouldn't include it. And I actually wouldn't include hunting, recreation, or any other lawful purpose. I think that is something that could be left to the political process. But I think the people have the right to keep and bear arms for security and defense. I think Russell Feingold-- that's one of the few things that I'm going to agree with Russell Feingold on.

### Moderator
Claim: I'd like to see what the other side would say to that. Sandy Levinson.

### Conspiracy Advocate (CA)
Claim: Two quick things. I like state constitutions and their ability to experiment. One of the things I like about state constitutions is that with almost no exception, they're all easier to amend than the U.S. Constitution.

So, if the good people of Wisconsin should decide in the next 10 years that maybe this is too broad, then it's really very easy to amend the constitution. One of the problems with the United States Constitution is that it's next to impossible to amend, so that we are stuck with the language of 1787 or 1791, which you're happy to jettison. But which does involve, in fact, re-writing the history of the Second Amendment and re-writing what many people thought was the original meaning of the Second Amendment.

### Moderator
Claim: Right there, ma'am.

### Moderator
Claim: Hi. My name is Stephanie, and I have a question. Does the Second Amendment protect the right to bear unsafe or unregulated firearms as a product?

And what is the government's role in ensuring that firearms are safe to use, reduce accidents, and to-- the misuse of firearm products, especially for-- by young children and by minors?

### Moderator
Claim: Thank you.

### Moderator
Claim: Because when you mentioned Chicago, those are kids under the age of 21. Young people under the age of 21.

### Moderator
Claim: That was a very, very well-focused question. I'm going to-- I'm assuming it was to this side, arguing against the motion.

### Scientific Advocate (SA)
Claim: Those--

### Moderator
Claim: David Kopel.

### Scientific Advocate (SA)
Claim: Those things you mentioned are legitimate governmental purposes. And the question-- if-- in pursuit of those legitimate governmental purposes, what are the particular laws which advance them? And do those laws significantly harm the ability of law-abiding people to use guns for lawful purposes? And you can look at different laws on these subjects. And as I'd say, some fail the test and some pass the test.

### Scientific Advocate (SA)
Claim: And I should just say, not a single Second Amendment decision or state-- or decision under any of the 44 state constitutional rights to keep and bear arms contradict that or undermine the safety issue that you're raising. So, if, for example, a state court imposes liability because a gun is prone to misfiring or something like that, no constitutional problem. There's an interesting debate as to what the proper regulatory scheme for that is. But the Second Amendment is not an obstacle because--

### Conspiracy Advocate (CA)
Claim: Well, that's what you say. But just remember what--

### Moderator
Claim: Alan Dershowitz.

### Conspiracy Advocate (CA)
Claim: --David said. David said that he's going to mount a Second Amendment constitutional challenge to New York's law that prevents you from taking your gun out of the state. So, there's always the threat, if there's a constitutional amendment, that every regulation will be challenged. The NRA thinks everything is unconstitutional-- locks on guns, safety provisions for guns, making sure guns are stored properly. The NRA can make a constitutional argument against any reasonable regulation. I think every--

### Scientific Advocate (SA)
Claim: And so could--

### Conspiracy Advocate (CA)
Claim: --body has to--

### Scientific Advocate (SA)
Claim: --the ACLU.

### Conspiracy Advocate (CA)
Claim: --admit-- everybody has to admit that if there is a constitutional amendment, the presumption is against regulation. If there is no constitutional amendment, the presumption is in favor of regulation. That's why we ought not to constitutionalize this right. We ought to constitutionalize the right of self-defense, but not the derivative right of gun ownership.

### Scientific Advocate (SA)
Claim: Alan, this is like saying that the Fourth Amendment-- the problem with the Fourth Amendment is that every single criminal defendant can try to argue for reading it extra broadly and excluding all the evidence against them, and they do. And they lose.

### Conspiracy Advocate (CA)
Claim: They lose.

### Scientific Advocate (SA)
Claim: We judge the Fourth Amendment by how it's actually been interpreted, rather than by some possibility that maybe it's going to be over-interpreted--

### Conspiracy Advocate (CA)
Claim: This is just the beginning.

### Scientific Advocate (SA)
Claim: The Second Amendment? No. The right to keep and bear arms has been around-- as an individual right--

### Conspiracy Advocate (CA)
Claim: 10 years--

### Scientific Advocate (SA)
Claim: --since 1776, at the state level--

### Scientific Advocate (SA)
Claim: There are dozens-- there are dozens--

### Scientific Advocate (SA)
Claim: --of court decisions from the 1800s on to the 1900s into 2000s, interpreting it. None of them have had the effect of striking down any such laws.

### Moderator
Claim: Sir, could you come down just a few steps, so the camera can see you. You're a little bit of shadow. Just three steps. That's great, sir.

### Moderator
Claim: My name's Eric. So, my question is that-- so on the campus where Staten Island College now sits was Willowbrook where the state of New York interns the mentally ill children to die. If we believe that the right of self-defense is to protect vulnerable citizens, which you have all said, and given that in the press, TV news, and even here tonight we've demonized the mentally ill, is it not a violation of the civil rights of the mentally ill to bear arms?

### Conspiracy Advocate (CA)
Claim: I think it's a legitimate question. That is to say--

### Moderator
Claim: Wait. Are you saying is it a violation of their right to deny them the ability to bear arms?

### Moderator
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: Justice Scalia, without presenting any argument, announced in Heller that just as Martha Stewart can be deprived of her right to self-defense, it apparently was the case that all laws limiting the rights of mentally ill people, a notoriously accordion-like term, could be limited.

I presume that all of us agree there are some mentally ill people who shouldn't be allowed close to a gun. I would imagine that as a policy matter, not as a constitutional matter, all of us might well agree that there are some mentally ill people whom we would, in fact, allow to have a gun if we really do take self-defense very seriously. This-- what you might want is legislators, city councils, et cetera, to write very careful legislation and tell us which is which, rather than to leave this up to judges who, quite frankly, have no training whatsoever in discerning differences of level of mental illness, or have no training in trying to figure out what, if anything, the data actually support.

### Moderator
Claim: Would the other side like to respond?

### Scientific Advocate (SA)
Claim: Sandy, that's exactly what Justice Scalia's opinion does, is he basically says that in terms of gun bans for people who are mentally ill, that the Second Amendment as he interprets it, is not going to intervene and it's going to be left to the political process. Now, the Gun Control Act of 1968, the main federal law, is a lifetime ban on gun possession by anybody who has ever been found to be in the words of the Congressional statute, our laws, mentally defective. I think that that has reflected the somewhat prejudices of the time, and as Sandy has said, that there is-- there are some people-- mentally ill people on the whole are less violent than the general public. There is also a small subset of them who are dangerously violent and absolutely should be prohibited from possessing guns, but I would also-- I agree with you that the breadth of the current prohibition, I don't think, fully makes sense based on current understandings and social science.

## Round 3

### Moderator
Claim: So there's a touch of agreement on this. All right. And this concludes round two of this Intelligence Squared U.S. debate-- where our motion is: The Constitutional Right to Bear Arms has Outlived its Usefulness. Remember we had you vote just before the debate began and immediately after this closing round of closing statements we're going to have you vote a second time. The team whose numbers have changed the most will be declared our winner. On to round three, closing statements. Each debater will make a closing statement in turn uninterrupted. They will be two minutes each. Our motion is this: The Constitutional Right to Bear Arms has Outlived its Usefulness. And here to summarize his position against this motion to persuade you to vote against, Eugene Volokh. He's professor of law at the UCLA School of Law.

### Scientific Advocate (SA)
Claim: So, we've heard all sorts of things about death, about assassination, about futility. I want to end this on a cheerful note. I want to tell you about some good news. So, from 1993 on, the size-- the amount of guns in America increased from 200 million to probably about 300 million. Now, you might think that's good news or not, but that's not what I'm claiming is good news. Likewise, or since from the mid-- in the mid-'80s about 10 states, any law abiding adult could carry a gun concealed on his person just by getting a license, except for one of the 10, you didn’t even need a license. That state, it turns out, was Vermont. Now that number is over 40. During that time, and I'm not going to say-- I'm not making a causal claim here, I will tell you the claim I'm making in a moment. During that time, the homicide rate and the firearms homicide rate, basically fell by a factor of two.

The general violent crime rate and the gun violent crime rate basically fell by a factor of roughly three to four. I will tell you, the number-- it was so shocking, I thought it was just nonsense spread on the Internet. But if it is, it's spread on the Internet by the Bureau of Justice Statistics, so that gives it some special claim as nonsense goes. So-- I think it's probably not nonsense. The serious violent crime with guns against youths, age 12 to 17, fell by a factor of 20-- by 95 percent. Now, I'm not saying that the growing gun stock caused-- that's-- there's actually a hot debate about that-- I don't know what the right answer is. But it seems to have happened in spite of the growing gun stock. We'd think, if some of the arguments we've heard are correct, the result would have been vast amount of bloodshed. It hasn't been. Something worked. We don't know what. Nobody really quite knows what. But something has caused this tremendous and sustained decline of crime. We should be looking to see what that was. It wasn't gun control, maybe it wasn't gun de-control. It was something. That's--

### Moderator
Claim: Eugene Volokh.

### Scientific Advocate (SA)
Claim: --what we should be thinking about--

### Moderator
Claim: Thank you very much.

### Scientific Advocate (SA)
Claim: --and not guns.

### Moderator
Claim: Your time is up. Thank you. Eugene Volokh. Our motion is: The Constitutional Right to Bear Arms Has Outlived its Usefulness. And here to summarize his position in support of this motion, to persuade you to vote for it, Sanford Levinson, author of "Framed: America's 51 Constitutions and the Crisis of Governance" and a professor of government and professor of law at the University of Texas in Austin. Sanford Levinson.

### Conspiracy Advocate (CA)
Claim: All right. It's no surprise that my friend Eugene Volokh makes very, very powerful, eloquent arguments about the public policy of gun control. But that's not what we're debating this evening. The question is to what extent any particular policy should be constitutionalized, which at the national level, means that it's close to written in stone and impervious to any change in the future.

And I really do think when you vote, that ought to be the principal question you're asking, not whether you believe a particular policy in 2013 makes sense, because if you constitutionalize it, you also have to say, "It's going to make sense in 2023, 2033, and ad infinitum." Secondly, I think David Kopel used interestingly different language at different points in his argument. And he, too, has made very capable arguments. I don't know him so well as I know Eugene, so you shouldn't take anything amiss when I don't refer to him as my friend. I've known Eugene, you know---- since he was a child, almost. But--

### Moderator
Claim: He was very bright.

### Conspiracy Advocate (CA)
Claim: --at one point, David said that-- I think it was Washington's policy-- no rational person could agree with it.

### Scientific Advocate (SA)
Claim: That was New York City--

### Conspiracy Advocate (CA)
Claim: Oh, okay. New York-- it really doesn't matter.

### Moderator
Claim: These are uninterrupted.

### Conspiracy Advocate (CA)
Claim: Now, I really--

### Conspiracy Advocate (CA)
Claim: --don't think it's the case that you have to be a lunatic to agree with Michael Bloomberg. Maybe he's got the wrong policy. But it seems to me that the rationality test-- at least the way that lawyers use it-- really does require that you believe the other side is truly lunatic. But what was telling is that in his more recent comment, he said, in effect, that there are legitimate reasons for-- there are reasonable people who disagree. And--

### Moderator
Claim: Sanford Levinson, I'm sorry, your time is up--

### Conspiracy Advocate (CA)
Claim: --we can--

### Moderator
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: --disagree.

### Moderator
Claim: Our-- our motion is: The Constitutional Right to Bear Arms Has Outlived its Usefulness. And here to summarize his position against this motion, David Kopel, Research Director at the Independence Institute and Associate Policy Analyst at the Cato Institute.

### Scientific Advocate (SA)
Claim: Professor Dershowitz wants to re-litigate the constitutionality of the Civil War. Well, that settled, actually, the question that we have for tonight in our political process. As of 1850, the Bill of Rights, as interpreted by federal courts, was only a limit on the federal government and did not apply to the states. And then we had the Civil War, and the terrible violations of the rights of the freedman that happened after the Civil War, when the southern states abolished slavery in name, but tried to keep the freedmen in de facto servitude and subjugation by saying they could only have public assemblies when they got special permission, and by saying they needed special permission, if ever, that they could possess firearms for protection. And again, that was part of the Ku Klux Klan's strategy of disarming them. The country recognized that not only were the oppressions of the freedmen under these black codes-- the new slave codes-- human rights violations in themselves, but that the lack of civil liberty in the south had been one of the important causes of the war, because it led to the suppression of speech, criticizing slavery, and poisoned the political dialogue there.

And so, the country said we love diversity, we love the vastness of our country and the different state experimentations, but some experiments are so dangerous that they lead to catastrophe and we tried the experiment of saying we’ll just leave it up to state governments to protect civil liberties. That’s not enough. We need to set a national baseline on human rights and the 14th Amendment was enacted to make the Bill of Rights, including especially the First and Second Amendments, applicable to the states. The baseline of the Second Amendment does not outlaw all gun control, and it allows Montana to go much further in protecting gun rights than New York City does, but it says everywhere that there are American citizens every government must respect the baseline of the fundamental civil rights contained in our Bill of Rights.

That was New York City--

### Moderator
Claim: Thank you, David Kopel. Our motion: The Constitutional Right to Bear Arms has Outlived its Usefulness; and here to summarize his position for the motion, Alan Dershowitz, professor of law at Harvard Law School.

### Conspiracy Advocate (CA)
Claim: I ask you to vote for the motion based largely on what Professor Volokh has brilliantly argued. He has conceded that he wouldn’t include a militia in his model Bill of Rights. He also has conceded that he wouldn’t constitutionalize the right of hunting. By making those two arguments, he has conceded the basic proposition: that the Second Amendment the way it’s currently written is anachronistic and has outlived its usefulness. He would substitute another amendment for that, an amendment much like the one that he said was passed in Wisconsin. It seems to me that they have conceded away the basic argument, namely that the Second Amendment as written is anachronistic. What’s left?

What’s left is: do we really want militia groups that are armed today, and armed under the Second Amendment, to have the right to confront our government and try to conduct yet another revolution of the kind that we had back in the American Revolution and the Civil War? It seems to me the answer to that is quite clearly no. Sigmund Freud had a very famous statement back 100 years ago in which he said, “The first human who hurled an insult instead of a stone was the founder of civilization.” The First Amendment protects insults. It does not protect stones, it does not protect violence. We could live very comfortably with a First Amendment and without a Second Amendment. I don’t want to amend the Bill of Rights because I worry that other things could happen, but I do want to make it very clear that the Second Amendment with its emphasis on militias and hunting, and with no mention of self-defense has outlived its usefulness.

Therefore I urge you to vote yes and let’s begin a debate on whether we should have an amendment protecting the right of self-defense, not the right of guns.

### Moderator
Claim: Thank you, Alan Dershowitz. And that concludes our closing statements. And now it’s time to learn which side has argued the best. We’re going to ask you again to go to the keypads at your seat and to push the button that will register your vote. Remember the motion is this: The Constitutional Right to Bear Arms has Outlived its Usefulness. If you now side with this motion-- with this team, push number one. If you are against this motion-- if you’re with this team, push number two. If you became or remain undecided, push number three. And we’ll have the results in about 90 seconds from now.

So while that’s happening, what’d I’d like to do-- first of all is say that our goal in this debate was to touch on this topic, but in a way that maybe you’ve never heard it argued before, and to have it argued well, and I really think that we succeeded in doing that thanks to the spirit of fairness and decency-- all of these debaters brought to the stage. And as you could see me struggling with shaping this questions and to-- we’re not used to framing it this way so everybody who got up and asked a question, even if I didn’t take it, I appreciate that you got up and tried. I can obviously sense the passion that everyone in this room feels about this issue. So to everybody who asked a question and those who didn’t get to, I really want to thank you as well for getting up and moving that along. like to have you tweet about this debate. Use the twitter handle @IQ2US and #gunsdebate. You can join the 43,000 NRA members who have-- who have-- and we say welcome to Intelligence Squared U.S. We're glad to have you. We're glad you discovered us. Our next debate at the Kaufman will be on Wednesday, December 4th. The motion on that debate-- at that debate will be: Don't Eat Anything With a Face. For the motion, Dr. Neal Barnard. He's a clinical researcher who studies the effect of diet on health. His partner is Gene Baur. He is president and co-founder of Farm Sanctuary. Time Magazine calls him the "conscience of the food movement." Arguing against, Chris Masterjohn, who is a nutritional science researcher and proponent of the Paleo diet. Anybody on that? No, you don't have to raise your hand. Oh, you raised your hand. Okay. Let's all look. And Joel Salitan. He's the third generation alternative farmer who was made famous in Michael Pollan's bestseller "The Omnivore's Dilemma."Next Wednesday, November 20th, we're going to be in Washington DC in partnership with the McCain Institute. We're going to be debating this motion there-- "Spy on Me: I'd Rather Be Safe." Tickets for that are free. And if you get down to DC, come see us. And tickets for all of our remaining fall debates are available through our website, www.IQ2US.org. If you can't join our live audience, of course, you can watch us on the live stream, as I believe a lot of people were doing tonight. And you can listen to all of our debates, including this one, on NPR stations across the country. You can check your local listings for air dates and times, and you can hear yourself applaud. Make sure to visit our website for up-to-date information and follow us on Twitter and Facebook. Okay. And by the way, we're always open to ideas for debate topics, so you can send those in. We just-- you know, think of something-- in terms of something that's really vital and that really is a dichotomy of views, and send it in. And we're very interested in hearing those. Okay.

So, we have the final results in now. Our motion is this: The Constitutional Right to Bear Arms Has Outlived its Usefulness. The way we do this-- you've listened to the arguments. We had you vote before the debate and again after the debate. And the team whose numbers have changed the most in percentage point terms will be declared our winner. So, here are the results. Before the debate-- on the motion The Constitutional Right to Bear Arms Has Outlived its Usefulness-- 64 percent agreed with that motion. 18 percent were against. And 18 percent were undecided. Those were the first results. Remember, you have to beat the-- your starting number by more percentage points than your opponents. Here now are the results of the second vote. On the Constitutional Right to Bear Arms Has Outlived its Usefulness, the team arguing for the motion-- their second vote was 74 percent. They went from 64 percent to 74 percent. They picked up 10 percent. That is the number to beat. Against the motion, their vote-- now, their first vote was 18 percent. Their second vote was 22 percent.

That's up only four percentage points. It means the team arguing for the motion has narrowly won this debate: The Constitutional Right to Bear Arms Has Outlived its Usefulness. That motion is carried. All right. Congratulations to all of our debaters, and thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
