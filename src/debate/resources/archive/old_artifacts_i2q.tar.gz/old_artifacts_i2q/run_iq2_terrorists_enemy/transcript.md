# Debate Transcript

Topic: Treat Terrorists Like Enemy Combatants, Not Criminals
Motion: Treat Terrorists Like Enemy Combatants, Not Criminals

Debate ID: terrorists-enemy


## Round 1

### Moderator
Claim: Good evening. As we assemble tonight a few days after the anniversary of 9/11, it should be obvious that there are distinctions between terrorists and criminals as well as between terrorists and soldiers, just as there are distinctions between counter-terrorism and the criminal justice system and the laws of war. A major function of criminal law is to deter crime. The reason we allow an insanity defense in criminal cases is because the insane cannot be deterred. Obviously suicide bombers cannot be deterred either. Another function of criminal law is punishment: interrogations are conducted to link suspects with crimes that have already been committed so we can punish the guilty. When we interrogate suspected terrorists, the goal is to prevent attacks before they occur. In criminal proceedings, we would prefer to see a guilty man go free than to compromise our sense of fairness. That is why, for example, the most damning evidence of guilt cannot be used if it is obtained illegally. Turning to the laws of war, the Geneva Convention is in part a bill of rights for soldiers in uniform; but the convention equally protects civilians by making them readily distinguishable from soldiers.

Tonight’s resolution is about whether these distinctions should or should not make a difference. Are the substance and procedures of standard criminal practice consistent with our societal needs for intelligence and security? Do the Geneva Convention protections for soldiers in uniform apply to non-state actors, who are not parties to the convention and who blend with and deliberately target civilian populations? Finally, if we don’t treat terrorists like criminals, and we don’t treat them like soldiers, where do we look for constraints on our military, intelligence officers, and interrogators so that their actions are consistent with our societal values?

These are vexing issues, and we have an outstanding panel with us this evening to discuss them. So now I’d like to turn these proceedings over to our moderator, John Donvan.

Thank you very much.

### Moderator
Claim: Thank you.

I guess we’d like to invite one more round of applause for Robert Rosenkranz for making this all possible.

Well, welcome everyone to another debate from Intelligence Squared, U.S. I’m John Donvan of ABC News and again, it is my honor to be serving as moderator. As the four debaters you see sharing the stage with me at the Skirball Center for the Performing Arts at New York University. Four debaters, two against two, will be debating this motion: Treat terrorists like enemy combatants, not criminals. Now, this is a debate; there will be a winner and a loser, and you our audience will be serving as the judges. By the time the debate has ended, we will have asked you to vote twice, once both before the debate and once again after you have heard the argument. And the team that has changed the most minds, once we see where you stand on the motion, that team will be declared our winner. And as this is a debate, everything is fair and robust, we just ask these debaters to bring intelligence and wit and humor and charm-- I think you have that going for you as well. But mostly intelligence; we want this to be a high level, smart debate, and that’s why we have all of you here as well when you participate in the middle session. So, onto the voting to establish where you in the audience stand before the debate begins. You have at your seat, the keypad that will help you register your position on this motion. Treat terrorists like enemy combatants, not criminals. If you agree with this motion, push number one. If you disagree, push number two. And if you are undecided, push number three.

We will register this vote and at the end of the debate, the team that has changed the most minds when you vote again will be declared our winner, with the motion being, “treat terrorists like enemy combatants, not criminals.” So on to the debate, round one, opening statements by each debater in turn. They will speak for seven minutes each uninterrupted. Our motion is: “treat terrorists like enemy combatants, not criminals.” And I would like to introduce our first debater arguing for this motion, Marc Thiesson who is a columnist for the Washington Post. He’s also a fellow at the American Enterprise Institute, a former speechwriter for President George W. Bush. He came out with a book this year that was a stiff defense of the interrogation methods used by the CIA throughout the war on terror and it sold really, really well actually, Marc, congratulations to you. So a lot of people liked it, your critics don’t like it.

They-- I think Jane Mayer of the New Yorker calls it the bible for the torture apologist. Is that fair?

### Conspiracy Advocate (CA)
Claim: No, not at all.

### Moderator
Claim: Okay. Ladies and gentlemen-- I’m surprised you said that. Marc Thiessen.

### Conspiracy Advocate (CA)
Claim: Thank you, John.

I want to thank Mr. Rosenkranz for inviting Mike Hayden and I to the only debate we could possibly win in Greenwich Village. We just marked, as Mr. Rosenkranz said, the anniversary of September 11th, 2001. I’d like to start by asking members of the audience a question. With a show of hands, how many of you remember exactly where you were when the attacks of September 11th happened?

### Moderator
Claim: Let the record show it’s everybody.

### Conspiracy Advocate (CA)
Claim: Okay. I want you to think back to that time. I want you to think back to the scenes of burning rubble. I want you to think back to the shock that you felt at the ability of the terrorists to penetrate our defenses and launch such an attack like that in our midst. And the questions we were all asking. Who had attacked us? What do they want? Were there more attacks coming? If I had told you back then that we would go almost a decade without another terrorist attack, who would have believed me?

Very few, I think, a few. Most of thought it was going to be the first of many attacks. I was in the Pentagon on September 11th, 2001. I was blessed not to be not at the point of impact, but I was a few corridors down and I remember feeling the building shudder; I remember the smell of the smoke in the hallways. And the one thing I remember very distinctly is that the alarms never went off, the evacuation alarms. We all just sort of filed out of the building and went on out to the lawn and looked back at the broken and burning Pentagon.

But in the months that followed, the alarms went off a bunch of times as false reports of impending attacks, planes that were headed our way kept coming in. And every time, the whole building, we would all evacuate and go out on the lawn and look up at the sky, waiting for the attack that never came. Why did that attack never come? I would submit to you there are only two possibilities. Either the terrorists lost interest in attacking us again, or we found out what their plans were and stopped them from carrying them out. Mike Hayden and I will argue tonight that the latter is the case. We will argue that the reason that attack did not happen is because we abandoned the law enforcement approach to terrorism that failed to stop the 1992 World Trade Center bombing, that failed to stop the attack on the embassies in Kenya and Tanzania, that failed to stop the attack on the USS Cole, that failed to stop the attacks of 9/11. That we abandoned that approach and began to treat terrorists as enemy combatants and not criminals.

In those early days after 9/11, we knew almost nothing about the enemy who had attacked us. We did not know that Khalid Sheikh Mohammed was the mastermind of 9/11; he wasn’t even on our charts. And we didn’t know who his accomplices were. And unbeknownst to us, there were two terrorist networks out there, at large, planning new attacks. The KSM network that had planned and carried out 9/11, and the Hambali network which was a Southeast Asian terrorist that KSM had organized because he knew we’d be on the lookout for Arab men.

And those terror networks were in the advanced stages of planning a series of attacks including a plot to blow up high-rise apartment buildings in the United States using natural gas, a plot to repeat 9/11 in Europe by flying airplanes into Heathrow Airport in downtown London, a plot to blow up the U.S. consulate in Karachi and western residences in Karachi, an al-Qaeda cell that was developing anthrax for attacks inside the United States and a cell, the Garaba cell, the southeast Asians who KSM had tasked to fly an airplane into the tallest building in the west coast, the Library Tower in Los Angeles. We did not know any of this, not a word. We didn’t know who those people were, what they had planned. And then we started capturing terrorists. Abu Zubaydah, Ramzi Binalshibh, KSM, and they provided us information that allowed us to round up and dismantle both of those terror networks.

When KSM was captured and brought into custody, he was asked about upcoming attacks. You know what he said? I’ll tell you everything when I get to New York and see my lawyer. Ladies and gentlemen, our opponents tonight would have granted that request. And if we had listened to their advice, if we had told KSM you have the right to remain silent, there would be craters in the ground in Los Angeles and Karachi and London and other cities in this country because of the attack that we did not stop. This debate is about more than Miranda rights. The Obama administration had eliminated the CIA program, but at least they’re killing terrorists using predator drones, right? No, no, no say our opponents, that’s illegal too. The ACLU and Center for Constitutional Rights filed a lawsuit a couple weeks ago saying that because terrorists outside of Iraq and Afghanistan are criminals and not enemy combatants, we cannot kill terrorists in those areas using predator drones. So if you believe that we should not kill terrorists using predator drones, then vote for them.

The fact is that that program has killed half the al-Qaeda leadership and it is probably the only thing standing between us and another 9/11.

One final point, our opponents are going to try to turn this into a debate on waterboarding. I’m happy to have that debate. As John pointed out, I wrote a book defending it. But if they’re arguing about waterboarding, they’re losing and I’ll tell you why. It is a little known fact-- how many people think Barack Obama ended waterboarding? He didn’t. My debate partner Mike Hayden ended waterboarding. When Mike Hayden handed over the CIA program to Barack Obama, the techniques involved were the tummy slap, the facial hold, mild sleep deprivation and a diet of liquid Ensure. I’m sure the makers of liquid Ensure will be thrilled to know that their product is torture. Bottom line is, there is a wide area between waterboarding on one hand and telling KSM and other terrorists, you have the right to remain silent. So you can be against waterboarding and for the proposition, that we should treat terrorists as criminals, as-- before the proposition, we should treat terrorists as enemy combatants and not criminals. So finally I’d just like to ask you, keep in mind, if you would like to keep killing terrorists with predator drones, if you would like-- if you think that our first priority in the war on terror, when we capture a terrorist should be interrogating them for intelligence, not obtaining evidence for prosecution; if you want to continue the approach to counterterrorism that has prevented us from being struck again as we were on 9/11, then I ask you to vote for our position. If you would like to eliminate all those tools, I suggest you vote for the other side and find a safe place to hide. Thank you.

### Moderator
Claim: Our motion is “treat terrorists like enemy combatants, not criminals.” We have heard the opening statement by the side for the motion and now to speak first against the motion, I’d like to introduce David Frakt who is a Lieutenant Colonel in the U.S. Air Force Reserve JAG Corps.

That means he’s a lawyer in the military. He served as lead defense counsel at the Office of Military Commissions. He represented detainees at Guantanamo. His most famous case is that of the teenager who was released finally after you made the case that his interrogation had been conducted improperly. He went home. David, I know you did him-- it worked out well for him. Is it your view that works out well for the United States?

### Scientific Advocate (SA)
Claim: Absolutely. Anytime an innocent man is released, that’s a very positive thing. And I-- it wasn’t my advocacy that got him out. Actually the Department of Justice, after seven years, acknowledged that actually he was not an enemy combatant, and so he was sent home and it was a great day for America.

### Moderator
Claim: Ladies and gentlemen, David Frakt.

### Scientific Advocate (SA)
Claim: Thank you. It’s a privilege to be here and against such august opposition. I’m going to start by disagreeing, and it’s probably not a good idea to disagree with your host, but Mr. Rosenkranz made a comment in his opening remarks that the criminal justice is about punishing criminals after the fact. And that’s a notion I would like to disabuse our audience of because the criminal justice system is much more robust than that. It’s there-- our law enforcement and working hand in hand with intelligence, is there to detect crime before it happens, to infiltrate terrorist networks, to deter attacks. And we don’t have to wait for a crime to be completed before stepping in. we’ve seen it over and over again where the police or the FBI or New York, NYPD breaks up a terrorist cell or just discovers a plot in progress or conspiracy, and those people can be arrested.

They can be interrogated by law enforcement, and in those interrogations yield a lot of information. There’s this perception somehow that reading people Miranda rights automatically means that they’re never going to talk again. And it’s true that sometimes when advised to the right to an attorney and the right to remain silent, that people clam up, but not always. In fact quite often, they divulge a lot of information.

And so we’re able to charge people with attempting crimes, with conspiracies to commit crimes and put a lot of terrorists away. In fact, since 9/11 we-- the federal-- and talking only about federal prosecutions, over 400 terrorists have been locked up for an average of 20 years apiece. Now contrast that with Guantanamo, which started with-- or at its peak had 787 detainees. Of course-- and all of whom were at one time accused of being enemy combatants. The Bush administration ended up releasing over two-thirds of those when they realized they had no evidence against the vast majority of them. Another 100 were cleared for release before President Obama took over. Another 100 have been cleared for release now. So what’s the scorecard now? We have four detainees who have been prosecuted successfully in military commission: four convictions versus 400. The Obama administration after a year-long review determined that there were 35 detainees that should be tried in some criminal form and there’s another 48 that they say are too dangerous.

So we’re talking about 83 people, after seven or eight years that they’ve decided are really the bad guys. And this is the danger of simply labeling people with-- as enemy combatants. And you have to think about the implications of what is being proposed here because as a whole-- and Mr. Thiessen acknowledged it-- they want to go back to the program of the prior administration.

And what did that entail? It entailed locking people up indefinitely without charge, without access to courts, without access to counsel, subjecting them to a full range of interrogation techniques, many of which are abhorrent to American values. And they were not given the opportunity to defend themselves, to even find out what the basis for their detention was. And that’s the system that Mr. Thiessen would like to return to. And I think it’s a fundamentally un-American system. Terrorists are criminals, nothing more. It may be that they have particularly grandiose criminal plans. But by labeling them as combatants, we actually legitimize them. We elevate their status to a warrior status which is what they seek. And we engage in a war on their terms. And I don’t think that’s a good idea.

Let me pose a question. Mr. Thiessen posed a question to you and he talked about the fact that there hasn’t been any attacks as if this is proof that those methods, the illegal interrogation methods and treating people as enemy combatants worked and that’s the reason we didn’t have any attacks. Let me tell you why we didn’t have any attacks. And of course there were a number of attempted attacks. But the reason is because we entered into-- by treating terrorism primarily as a military problem, as a war, we started two voluntary, unnecessary wars, in Afghanistan and Iraq, and we presented the terrorists with hundreds of thousands of targets, American soldiers. And as bad as 9/11 was, and 3,000 people died on that day, but we have lost 5700 American service members dead.

Another 1100 coalition members dead in Iraq and Afghanistan and 39,000 American service members injured. It’s basically revived the Veterans Administration Hospitals because we have a whole generation of wounded warriors out there who have been fighting wars that really aren’t necessary.

And are we safer? That’s the question you really have to ask. Are we safer after eight years of this approach? Ask yourself this question. Are there more people in the world-- according to Mr. Thiessen, there were two little terrorist cells of al-Qaeda after 9/11. How many terrorists are there right now in the world or violent jihadists who are willing to strap a bomb to their bodies and kill Americans, or plant roadside bombs? We have essentially launched a global war-- and that’s what we called it, the global war on terror that the Islamic world interpreted it as a war on them and we have alienated tens and hundreds of millions of people unnecessarily. And we are not safer. We are not safer when we abandon our core values. And that’s ostensibly-- they use coded language but that’s what they’re talking about because they’re talking about not using law enforcement methods, not using traditional tools. They want a world of perfect security where no crimes are ever committed, where no terrorists attack. That’s never going to happen. And when you seek, strive for that, we end up with a police state. The safest country in the world is North Korea, but we don’t want to live in North Korea.

### Moderator
Claim: David Frakt, thank you very much.

At this Intelligence Squared U.S. debate our motion is “treat terrorists like enemy combatants, not criminals.” We have heard from the first two debaters arguing for and against this motion. Now our third debater to argue for the motion, I’d like to introduce Michael Hayden; he is a retired four star Air Force general and former director of the CIA. And Michael, when you took over the interrogation program of the CIA that had been in place, had just about been called to a halt under political pressure and other complaints, you decided to take a look at it again, commissioned your own review, which you undertook personally, and you concluded what?

### Conspiracy Advocate (CA)
Claim: I spent the whole summer of 2006 getting what I would call a graduate degree on the CIA Interrogation and Detention Program. I was a blank slate; I had no vested interest in what had gone on before. I could have chosen any course of action. At the end of the summer, I went to President Bush and said I wanted to make some modifications to the program, but as Marc has suggested, I could not in conscience, given my responsibility of the CIA to defend the republic, take this program off the table for him or for any future president. He needed this. In conscience I could not just say make it go away. It would have been a comfortable decision, John. It probably would have gotten credit in some circles, but it would have been immoral.

### Moderator
Claim: Ladies and gentleman, Michael Hayden.

### Conspiracy Advocate (CA)
Claim: Well, I think Marc and David have kind of teed up the question pretty nicely for us here. Are we a nation at war or are we not? Should we perceive ourselves to be at war or should we not? David said that our adversary in this thing out there, war or not, are criminals and nothing more. But if that’s the case, let me take you back almost a year to the day to the Horn of Africa, to Somalia, to American Navy SEAL, in a helicopter, a Seahawk, coming off a Navy carrier in the Indian Ocean, going after an individual named Sullah Nabhan at the time was the leader of al-Qaeda in Somalia, al-Qaeda in the Horn of Africa.

We killed him. We landed long enough to swab up portions of his remain to get DNA evidence that we had killed him. I wasn’t in the mission, I was out of government at this time, I wasn’t privy to the pre-brief. But I know what was asked by the field commander before he got on the helicopter. Sir, is this a kill or a capture? And it’s very clear from what happened, he was told this is a kill. No probable cause, no warrant, no court. Because we are a nation at war and Saleh Ali Nabhan was part of an opposing armed enemy force. I became an advocate; my epiphany that we are a nation at war took place about 10 minutes after 10:00, September 11th, 2001. It became clear to me at that point and I believe in few things more firmly than I believe in the fact that we are a nation at war. President Obama has said we are a nation at war. President Bush has said we are a nation at war.

In March of 2007, I went to the German residence to give a talk to all the ambassadors to the United States from the nations of the European Union. And Germany was in the chair of the E.U.; they were inviting these ambassadors in; they invited an American to come in and kind of be the lunchtime entertainment. Bob Gates was there at one point, Condi Rice at another; this was my turn and I decided to say something interesting. I decided to talk our European friends about rendition, detention and interrogation. I had a wonderful speechwriting staff at CIA, but this was a speech that I took a personal hand at. On page two of that speech, I simply said to our European friends, let me tell you what I believe, what my agency believes, what I believe my country believes. We are a nation at war. We are at war with al-Qaeda and its affiliates.

This war is global in scope and I can only fulfill my legal and moral responsibilities to the citizens of my republic by taking this fight to this enemy wherever he may be.

A year ago last August, August of 2009 I was in Phoenix. President Obama was addressing the VFW. He said quite clearly we are at war; we are at war with al-Qaeda and its affiliates. Now I know most of the American population doesn’t sense they are at war. I know that. The American Armed Forces know that we are. The American security establishment knows that we are. The American intelligence community knows that we are. You, your political processes have sent me, a career military officer, the director the CIA to war. You have told me to defend you. Do not take away from me the tools that I need to perform the service you demand. At some point in our conversation tonight, there will be a discussion here about we need to uphold the rule of law. I could not agree more. It just matters what model of law we are committed to upholding. Is this an issue best addressed through American criminal law or is this an issue best addressed through the laws of armed conflict? I submit to you that it’s only the laws of armed conflict that will keep you safe. This isn’t theoretical for me; this was real.

I had a meeting with my general counsel and his team at CIA about two years ago. I said to the team, our enemy is opening a new front. They are beginning to attack us, with attack in quotes, it’s a bit metaphorical. They are beginning to attack us in the American legal system. We have to best them in the legal system the way we are defeating them in the tribal region of Pakistan.

And I told my lawyers, I want you to lean as far forward and the hardest as you possibly can in terms of giving information to our court system. I want blood on the harness, you are leaning so far forward. We worked our tails off in those judicial processes, specifically habeas corpus. When we got a point where we could go no farther, one of the judges demanded that we provide not him, but the defendant, the name and the identity of the intelligence source we had used in order to determine that he was a member of al-Qaeda. I know you don’t live in the world I used to live in, but there is nothing that a director of CIA could do in those circumstances. You cannot let the world know that sources who risk everything, who risk all to work for you, will have their names revealed in the American judicial process, to the individual they have identified as al-Qaeda.

The Christmas attack is another little morality play. It really demonstrates the fallacy of treating this as a law enforcement matter. When Umar Farouk Abdulmutallab attempted to down an American aircraft, he was a member of al-Qaeda; he was an enemy combatant. It was an attack mounted from outside the United States towards and in the United States. And because of a law enforcement mentality, we sent a clean team in there. A clean team; that is somebody in the FBI who knew nothing of what Abdulmutallab had told us. After only 50 minutes of interrogation, every known al- Qaeda aircraft attack this country has involved multiple threats of attack: 9/11, 2006 from London, the Bojinka plot over the Pacific. And yet after 50 minutes, our instincts were so strong to the law enforcement that we allowed him to lawyer up.

That’s unconscionable. That’s a terrible decision. It is based upon a model that you know, he’s just a criminal and we just need to make sure we get him in jail. That’s not the objective here. The objective is to keep you safe.

### Moderator
Claim: Thank you very much.

Our motion is “treat terrorists like enemy combatants, not criminals,” and finally to speak against the motion, I’d like to introduce Stephen Jones who is an attorney from the Midwest, from Oklahoma I believe, managing partner of the law firm Jones, Otjen, and Davis. He has also defended a well-known terrorist, but not from the Middle East. He defended Timothy McVeigh, the Oklahoma City bomber. And you were a public defender in that role, so you were assigned to him and he to you. I’m curious, did you want that case when it came to you?

### Scientific Advocate (SA)
Claim: Well, I wasn’t the public defender; I wasn’t even on the panel; I was appointed as lawyer by the judges in the federal courts in Oklahoma City.

### Moderator
Claim: And did you want the case?

### Scientific Advocate (SA)
Claim: Well, when the judge or judges ask you to take a case, what you want or don’t want is not relevant.

### Moderator
Claim: Ladies and gentlemen, Stephen Jones.

### Scientific Advocate (SA)
Claim: First of all, let me tell you that I am a Republican and I voted for George Bush both times, and I voted for John McCain and yes, Sarah Palin, and I don’t apologize for that. I don’t think the argument here is political. I think the argument is constitutional and it basically boils down to how far we are willing to sacrifice our ideals, our history, our beliefs as a nation for security. And is that security real or temporary?

Has the target of our adversaries simply moved offshore, much like banking and investment, or is the target here? For various law enforcement agencies and members of the national intelligence establishment who have protected us and work long and devoted hours, there can be no criticism. But that’s hardly the issue, nor frankly is the ACLU the issue. The issue quite simply is whether we are a nation of laws, and there are three reasons, compelling reasons why you should vote against this resolution and vote no.

The first is that the United States of America did not happen accidentally. There was a political deal, a bargain. The bargain was this; that the twelve states that participated in the Philadelphia Convention would surrender some of their rights which they held very importantly, to a central government that they had no experience with. And in return for that surrender of their rights to that central government, that government would, as its first order of business, pass a series of amendments of the Constitution to restrict the power of that government which they had agreed to join. So the right, the freedom of speech, freedom of assembly, the right to petition, redress of grievances, the right to a fair trial, to due process, to protection against self-incrimination, to the assistance of counsel, to be safe and secure unless a warrant is issued by law enforcement to search it, the right to a public trial, the right to a speedy trial. For all of those, are in the first 10 amendments. And the bargain was redeemed.

And 100 years later, or almost 100 years later, that bargain was purchased and redeemed by the blood of more Americans who died in the Civil War than all the other wars. By the Civil War, President Lincoln’s address at Gettysburg and the passage of the 14th amendment, we as a nation reaffirmed the ideal which is due process of law, equal protection of all people under the Constitution. Not something that we always follow, and there have been black holes in our history, but that is our ideal; that is the American experience: a written Constitution that limits the power of government.

Secondly, the United States is, for millions, hundreds of millions of people in the world, their ideal. One of our presidents once referred to a letter by one of the early English governors, that United States is a city upon a hill. Well it is a city upon a hill and what makes us special is that we try, every day and in every way, most of us, to uphold those ideals. And if we were to surrender even temporarily those ideals, if we were willing to say, to these individuals who are charged, charged not convicted, charged with terrorist offenses, that we will be like Great Britain and Northern Ireland in the early ‘70s and we will suspend these basic rights, these things that our national experience have taught us, we would lose many of the allies, supporters, and people who in their hearts look at the United States.

And finally, having represented a terrorist-- and before 9/11, the Oklahoma City bombing was the greatest act of domestic terrorism in this country. 168 people dead, 19 of them children under the age of six. Eight federal law enforcement agents, over a billion dollars of uninsured damages, 500 people seriously injured and 30,000 who sought and received mental or emotional intervention because of their disturbances. But Tim McVeigh was tried and convicted before a jury in a federal court. He had lawyers; he got a change of venue; he got a severance; he got the money through the federal system to pay his lawyers, to investigate the case and bring witnesses to Denver, Colorado even in the last days of that trial, the G-7 summit was meeting in Denver. But in our country, our security forces, our law enforcement was able to provide both a fair trial for Tim McVeigh and protect the world’s leaders meeting five miles away.

Now, ladies and gentlemen, the courts are a sanctuary in the jungle; that’s what they are. They are to determine justice is blind; we don’t have a special court for people we call a terrorist. We don’t have a special criminal court for drug dealers; we don’t have a special criminal court for murderers or people who commit other crimes, whether serious or small. We have a federal judicial system and a state judicial system and then for the armed forces, the uniform code of military justice. Because 200 years national experience has taught us that our safety comes just as much from adherence to the rule of law as it does to the talents of our intelligence agencies and our law enforcement agencies.

The history of our country is on the side that Dave and I represent. And I urge you to vote no and to affirm the rule of law, regardless of how despicable persons may be. For in the final analysis the justice of a society is measured by how it treats its worst, not its best.

## Round 2

### Moderator
Claim: I’m John Donvan of ABC News. I’m host and moderator for this Intelligence Squared U.S. debate. We are at the Skirball Center for the Performing Arts in New York City at NYU. We’re on a stage surrounded by several hundred of you in the audience and on our stage, four debaters, two against two debating this motion: treat terrorists like enemy combatants, not criminals. The team arguing for the motion include a former CIA director and a speechwriter for the Bush administration, now an author. They are arguing that we are in a war and that in war for the sake for security and survival, we may need, we have to at times undertake unpleasant actions. It may even be the moral thing to do. Their opponents include two attorneys, one who works for the military and one who defended Tim McVeigh, and they argued that terrorists are nothing more than criminals. And to treat them as more than criminals actually does them a favor. We are now into round two and I want to at this point, invite you into the debate. In a few minutes I’ll come to you for questions but in this part of the debate, the debaters can address one another directly and also will take questions from me. And my first question is actually to the side arguing against the motion. Your opponents include a former director of the CIA, a speechwriter for the Bush Administration who wrote the president’s speech in which he discussed these issues and he was briefed, as he tells us extensively on how the system actually works and what it actually produced. And they are painting a very dire picture.

And my question to you, their opponents, is whether they may just know more than you do? David Frakt.

### Scientific Advocate (SA)
Claim: Well, I would hate to concede that, and I would note that I do have a top secret FBI clearance, but I did not get the opportunity to see much of the intelligence that would have come across the desk of general Hayden. I would hope that that intelligence did not come across the desk of Marc Thiessen. But-- but some of it somehow seems to have gotten its way into his book. So maybe we ought to be investigating that. But--

### Conspiracy Advocate (CA)
Claim: The person you'd be investigating is Barack Obama, who released it.

### Moderator
Claim: Back to David Frakt.

### Scientific Advocate (SA)
Claim: I'm sorry. One of the things that I want to--

### Moderator
Claim: Well, no, I'm asking the question in a serious way, that you-- so you hear the director of the CIA, said this was on me. This was my responsibility. Not that I love doing these things or any of us love doing it, but I saw the impact. And that's why I came to that decision.

### Scientific Advocate (SA)
Claim: I don't dispute that there is a possibility that some of the methods endorsed by the Bush administration may have worked at times. But what that boils down to is an “ends justify the means" argument. And that's the argument that we reject. Because there is-- you cannot achieve perfect safety. Might we have found that information without using enhanced interrogation methods? Might we have used it if we had prioritized our intelligence, gathering our law enforcement in other ways? They talk about plots that were foiled. They don't talk about all the blind alleys that they went down.

They don't talk about all of the lives that were ruined through false confessions that were wrung out of people in coercive interrogations. They don't talk about the people that were falsely accused and only years later were released with no apology, no compensation. So it's not entirely one sided. Yes, sometimes the methods may work. But if they're un-American, then we should not be doing them.

### Conspiracy Advocate (CA)
Claim: If you're going to debate about what constitutes appropriate interrogation methods, invite me back. I'd be happy to come. But that's not what this is about. This is are these or are these not enemy combatants. And if they are enemy combatants, do I have the right to hold them, consistent with the laws of armed conflict because they are a danger to you. The Geneva Convention doesn't require me to prove that they're a criminal. I simply have to have reasonable belief that they're enemy combatants.

### Moderator
Claim: But General, the implications of-- the implications of that decision actually in practice have to do with the most important and critical information, the rationale for even heeling to your position is to be able to interrogate them using certain methods.

### Conspiracy Advocate (CA)
Claim: No, no. The rationale, the primary purpose is to take the enemy combatant off the battlefield. And if you overcomplicate my taking them off the battlefield by capturing him, you will leave me with one other choice to take him off the battlefield, and that's to kill him. Now, do you want to create that box? If the American political process wants to create that box, the people who are left behind in the intelligence service will work in that box. But that is a far less noble box than continuing the war as we have traditionally fought wars. I was stunned--

### Scientific Advocate (SA)
Claim: Could I respond to that, John?

### Conspiracy Advocate (CA)
Claim: Wait. One comment.

### Moderator
Claim: Okay, one comment, and then David.

### Conspiracy Advocate (CA)
Claim: I was stunned that Stephen made the comment to follow American history.

When in American history have we had habeas hearings for enemy combatants?

### Moderator
Claim: David?

### Scientific Advocate (SA)
Claim: I think we need to be very clear about who we're talking about and define who we're referring to when we're talking about terrorists because from our perspective, we are not talking about people who were actually captured on a battlefield in Iraq and Afghanistan. There is no doubt that there is in fact an armed conflict going on in those places. And as a military attorney, as a judge advocate, certainly I acknowledge that under the laws of war, we do have the power to detain and remove from the battlefield people who are engaged in active conflict. The problem is that the war has been defined in such amorphous terms that there's a claim of a global battlefield, including the United States, and that anyone who essentially is against America, and mostly we're talking about-- their focus is on Islamic terrorists-- are enemy combatants. So a Major Hassan is a terrorist. But really, he's a criminal. People-- if you are in the United States, and you attempt to commit a crime, the United States really is not a battlefield. I reject that. And even if it you think it is, the Constitution does apply here.

So there is a limited group of people that, yes, if it's in an active war in a theater of war that they can be captured and removed from the battlefield. But the solution-- we have captured a lot of people. We do not screen them well. We sent people who were brought in for ransom without, you know, any back checking, fact checking, and packed them off to Guantanamo. And that's something that's unprecedented in American history.

### Moderator
Claim: Let me get Marc Thiessen into it.

### Conspiracy Advocate (CA)
Claim: I'd like to-- I'm not a lawyer. You have an advantage over us. But I'd like to enter some documents into evidence, right? The inaugural address of Barack Obama.

### Scientific Advocate (SA)
Claim: Objection

### Conspiracy Advocate (CA)
Claim: Our nation is at war –

### Scientific Advocate (SA)
Claim: Hearsay

### Conspiracy Advocate (CA)
Claim: That is a true statement.

The inaugural address of Barack Obama, our nation is at war against a far-reaching network of violence and hatred.

Please pass that to the other side.

Congressional authorization of use of military force passed by the House of Representatives 420 to 1, Senate 98 to nothing. We are at war. Supreme Court of the United States in the Hamdi decision. We are at war, we can hold people captured in the war as enemy combatants. And, my final piece of evidence, Osama bin Laden’s fatwa, which is entitled: “Declaration of War Against the Americans.” What part of war do you not understand? We are at war. The president, the Congress, the Supreme Court and the enemy all think we're at war, and you do not.

### Scientific Advocate (SA)
Claim: Well I suppose the problem that I have, Marc, is that I'm old enough to remember when Lyndon Johnson said we were at war with Vietnam and the legacy and the things that were done in the name of the declaration of war which was nonexistent. I regret to say that I'm old enough to remember what one of the presidents of my own party did in the name of national security in Watergate and when he tried to use the CIA and the FBI in the name of national security. I remember what happened in Iran Contra. And I remember the efforts made to assassinate Patrice Lumumba, and Premier Castro, Dr. Castro, and how that backlashed in this country, and I'm sorry. The powers of the federal government in the last 50 years destroyed any credibility when we were asked to believe people in power because frequently they know no more than what we can read in the Economist or the New York Times.

Now, that information may be subject to different interpretation. But General Hayden talked about when in history have we had habeas for enemy combatants. General, your argument is not with me; it's with the Supreme Court, the majority of whom my presidents appointed.

And they brought the argument three times that these people are entitled to habeas review. And if we look at our history, those things that we thought were good in a time of war because the national interest compelled it were wrong. And there is no greater example of that than the internment of 200,000 Japanese on the West Coast in World War II because we thought our national security required that we round them up, take them out of their homes and put them in detention camp because they had attacked Pearl Harbor. At least their Imperial Navy did.

### Moderator
Claim: All of which, at least I want to say to the other side, all of which at least go to the issue of violation of core US values that we say define us. Your opponents are saying, essentially, and I think they used the word “un-American.” That your position is so at odds with what we value, including, equal protection under the law. That what you’re doing is un-American. Can you respond to that?

### Conspiracy Advocate (CA)
Claim: Well I will tell you something about that, Stephen mentioned American history.

### Moderator
Claim: No no, I want the answer to his question.

### Conspiracy Advocate (CA)
Claim: No, I’m answering his question. Since the Revolutionary War, the United Stateshas held over 5 million enemy combatants. Until the war on terror, not one of them was given habeas corpus rights to petition their detention. The Geneva Convention, which regulates the conduct of war, nowhere in there does it say that you have a right to contest your detention in a war. My mother is here. And my mother was a prisoner of war. She fought in the Warsaw uprising in Poland against the Nazis. She threw Molotov cocktails at German soldiers. And she was taken into a prisoner of war camp in Germany that would make Guantanamo look like the Four Seasons. And she was not given the right to petition.

### Scientific Advocate (SA)
Claim: You would be referring to the Geneva Conventions that the Bush administration said did not apply.

### Conspiracy Advocate (CA)
Claim: Excuse me. Yes. Well this is the point. You want to give Geneva Convention rights to terrorists. Well you don’t even want to give them Geneva Convention rights because you don’t accept that it’s a war. But to take the argument to argument.

My mother followed the laws of war. She was in an army that carried its weapons openly, that did not target civilians, that wore uniforms or distinctive insignia. Terrorists do none of those things; they violate all of the rules of war, and so you want to get more rights-- if I understand your position you want to get more rights to people who violate the laws of war, than rights to the people like my mother who followed the laws of war never had.

### Moderator
Claim: It’s not that we don’t trust you, but I want to check all this with your mother. Is she here? Can you stand up for just a moment?

Is it all true? Is it all true, everything he says? Are you proud of Marc?

### Scientific Advocate (SA)
Claim: It’s ironic that I'm being accused of not understanding war. I have been awarded Global War on Terrorism Expeditionary Service Medal, two National Defense Service Medals, I understand that we are at war. My objection is to the conduct of that war in the way that we have particularly domestically, are operating and, yes, and I have freely acknowledged that we can detain combatants on the battlefield. Where there is a question about whether they’re-- what their status is, then they're entitled to a hearing under the Geneva Conventions. At a minimum, they are entitled-- all persons are entitled to humane treatment. And this is what we got away from in the early years of the Bush administration until the Supreme Court over time reigned in these abuses. But these are the abuses that they would like to get back to. And I think, Marc suggested that we want to broaden and expand rights, and you know actually that's not such a bad thing.

Over time history marches forward and human rights are expanded. And sometimes we extend those rights even to people whom we despise.

### Moderator
Claim: Actually, I’d like to hear from Michael Hayden.

### Conspiracy Advocate (CA)
Claim: David, we both served in the Air Force and I commend you for your service but it’s unfair to make that-- again, if you want to talk about what was done in terms of interrogation, again, it’s a separate debate. This is a legal concept. Which of the equally valued legal systems do we want to use? Domestic criminal law, or the laws of armed conflict? I think we have the right as a nation to use the laws of armed conflict because we were attacked by an opposing armed enemy force. And Stephen, I have to say, you have a broad suspicion of government, and you went back to Vietnam, and Gulf of Tonkin, and I think the historical record is quite clouded whether or not the Turner Joy was fired on by North Korean patrol craft. I don’t think that there is any dispute that we were attacked in New York City and in Washington.

### Moderator
Claim: Stephen Jones to respond.

### Scientific Advocate (SA)
Claim: I concede that point, but it’s not the historical accuracy of the initiating incident that’s at issue. It’s what we do about the incident after it’s happened.

### Moderator
Claim: I’d like to go to the audience for your questions now. And the way this will work, if you raise your hand, my system tends to be geographical, I start on the left and move to the right. A microphone will be brought to you. When the mic reaches you, if you could, stand up and hold it about this far away so the radio and television audience can hear you, we appreciate it, if you're a member of the news media we'd appreciate it if you'd just identify yourself and I just need to shade my eyes for a moment, to see. Okay, on the far side in the dark shirt. Again I urge you to ask a real question and to keep it terse and you’re not here to debate the debaters, you’re here to help them to debate with each other. Thank you.

### Moderator
Claim: Yes, I think that something has been left somewhat clouded in the discussion, and that is that we've debated here and heard a lot pro and con of whether they should be treated— captured and the way that they’re treated as criminals versus enemy combatants. What I haven’t heard is a clear definition of what the treatment should be when it is declared that they are enemy combatants. In other words are we looking at recourse under military commissions? Are we looking at a suspension of some of those concerns because of national security? I think for a lot of people, we’re uneasy as to the definition behind enemy combatant and the set of prerogatives that would set in if that were to prevail, and we are leaving an open mind on that. So perhaps people can clarify that for us?

### Moderator
Claim: Thank you. Marc Thiessen, I’d like to go to Marc because you just wrote a whole book about this.

### Conspiracy Advocate (CA)
Claim: Enemy combatants – when you capture someone who’s a member of Al Qaeda or the Taliban or is carrying, for example who tries to set his underwear on fire on a Detroit airplane and blow up a plane over Detroit that could’ve killed hundreds of people – our position is that that’s an enemy combatant. And that person, when you take him into custody, the first words out of your mouth are not, you have the right to remain silent. Because this is the problem with the difference between our approaches and practice, is that they believe, because they are lawyers and this is the world they live in, that the purpose of interrogation is to obtain evidence for a criminal trial. The criminal trial is a third order of interest for those who are involved with protecting the country. The first job is to get intelligence to stop another terrorist attack. So when, for example, the Christmas Day bomber is questioned for 50 minutes and then told he has the right to remain silent, you’re not going to get, even if he’s being incredibly cooperative, in 50 minutes you could not exhaust all the information. But the thing is that if you were trying to-- if you take the law enforcement approach to interrogation, patience is a virtue. You are trying to get evidence and you can take as much time as you want, build a relationship with the guy, you try to coerce them in an interview, try to co-opt them into giving you information, fool them into giving information. If you are trying to stop a terrorist attack, patience is deadly. This guy-- when the Christmas Day bomber was captured, he was supposed to be vaporized on that plane. As soon as Al Qaeda found out that he was alive and in U.S. custody, they started covering his tracks. They started shutting down e-mail addresses, they started shutting down camps where he was training, they started hiding operatives who he knows about, they started hiding safe houses and closing them down. So he takes three weeks to do-- and he’s even trained in interrogation resistance-- to buy time and use the legal system in order to buy his fellows on the outside time. We need to get that information quickly.

### Scientific Advocate (SA)
Claim: Okay. I’d like to respond to that.

### Moderator
Claim: I just wanted David Frakt to respond to this.

### Moderator
Claim: A little bit of an unclarity and that is that even after a lawyer is assigned, I believe that interrogation can proceed. Isn’t that correct?

### Conspiracy Advocate (CA)
Claim: But he doesn’t have to answer any questions. Once he has a lawyer, he’s not going to answer any questions.

### Moderator
Claim: I will tell you there were many people who did cooperate--

### Conspiracy Advocate (CA)
Claim: No, first of all, I will tell you who says this: Eric Holder. Eric Holder, after John Walker Lindh was captured in Afghanistan and brought over here, Eric Holder was being interviewed on CNN in 2002 and they said can they get tough with him in the interrogation and he said well he’s not going to tell you anything now that he has a lawyer and is in America.

### Scientific Advocate (SA)
Claim: Speaking from experience, people with lawyers and confess all the time. They confess even though they’ve been given their Miranda rights. So maybe you think Osama bin Laden, to use the most extreme example, is not familiar with the rule of Miranda?

I mean they use-- most of those of us who practice law daily in the courts of law know that many police detectives are just as skilled as the people you want to use enhanced detection, that the purpose of interrogation is not prosecution, it’s to gather evidence frequently on an intelligence basis whether it’s financial crimes or drug crimes, and that many thousands of defendants who are told they have the right to remain silent, spill their guts.

### Scientific Advocate (SA)
Claim: I’d like to get back to the question which was a good one and given that this was a motion that was proposed by our opponents, I thought that they would try to define it. But actually what we’re doing is constantly shifting back and forth because they say, well, we’re at war, so it’s enemy combatants. We acknowledge in the active battlefield and active theater of conflict in Iraq, in Afghanistan, those who are actively fighting against us are enemy combatants and can be treated under the laws of war. Now where it gets murky is when we’re talking about people here in the United States. And the prior administration’s policies were to treat Americans, American citizens as enemy combatants, American citizens were locked up in military prisons for years and before that case could ever go to the Supreme Court, they decided to drop it. So we have to differentiate between an active battlefield and what’s going on domestically. Now Mr. Thiessen says that membership, if we pick up someone who’s a member of Taliban or Al Qaeda-- I mean, these people do not carry membership cards. And we also have to distinguish between Al Qaeda and Taliban. The Taliban is a fighting force in Afghanistan and Pakistan. They just want us to leave. They are not terrorists. They're not launching international terrorist attacks. Al-Qaeda is.

I would argue that the Taliban was essentially the lawful military government and military force of Afghanistan at the time we attacked and therefore was entitled to Geneva Convention status protection as prisoners of war. But we did not afford them that.

Another thing that's important to talk about is when we say terrorist, what they're really talking about are suspected terrorists, people that they believe may be terrorists. Now, if someone tries to light their underwear on fire in a plane, yes, you have a pretty good indication that they're a terrorist. But it's usually not that clear cut. It's usually based on some intelligence from some source or method that we're not allowed to know about that they suspect someone. And in that case, to simply lock that person up, incommunicado for potentially for years, if I'm understanding what Marc is proposing, is problematic. And we have gotten a lot of the wrong people.

Now, yes, if we interrogate.

### Moderator
Claim: Wait, actually--

### Scientific Advocate (SA)
Claim: I have one point about interrogation--

### Moderator
Claim: Very quickly, because I have to--

### Scientific Advocate (SA)
Claim: We interrogate people-- yes, people have information. We may eventually get it. But why limit it to terrorists? Why don't we do that to every single person that's suspected of any crime? Why not drug traffickers because--

### Moderator
Claim: We'll come back to that because we're going to keep going in circles on the same territory, and I want to move it. And I bet we do come back to it. In uniform, the third row. I believe you're-- are you part of the West Point contingent?

### Moderator
Claim: I am, sir. My name is Captain Cinnamon Macer I'm a judge advocate for the U.S. Army, currently assigned to the United States Military Academy, the department of law. I do teach Constitutional and military law. We have some work that put us here this evening. Let me clarify first this comes in my personal capacity. I'm asking this question not anything to do with the army or West Point. I clearly acknowledge that you are more intelligent that I, that you have the access to information I never will.

My question comes in the fact that I'm assuming, aside from you, sir, that maybe you've never been deployed.

### Conspiracy Advocate (CA)
Claim: No, I have not.

### Moderator
Claim: I've been to Iraq. I've been to Afghanistan. Without fail, every time I interacted with an Iraqi or an Afghan, their single question to me was this: How do you explain Guantanamo Bay?

Let me ask you my question. My question is not whether we should treat them like enemy combatants or criminals, but whichever we decide, there are always consequences to a decision. And if you take it out and extract what-- the implication this causes for those of us who are fighting these wars, who do know we are a nation at war, so in the next year as I leave for my third deployment, possibly, when I get out there, or as I'm teaching my cadets, this is the way we do things because we're America, how do I justify us giving it the moral high ground?

### Moderator
Claim: And do you think we are?

### Moderator
Claim: Absolutely. We can't go around and champion ourselves as the land of the free and the just--

### Moderator
Claim: Michael Hayden.

### Moderator
Claim: In the case of vs. Bush, there was a--

### Moderator
Claim: I'm going to let them get to the question.

### Moderator
Claim: --something. May I finish?

### Moderator
Claim: No. I-- you're good. That's all you get, 30 seconds.

### Moderator
Claim: But the law says--

### Moderator
Claim: Ma'am, please. Ma'am, ma'am.

### Moderator
Claim: nations principles of--

--of law.

### Moderator
Claim: --please.

### Conspiracy Advocate (CA)
Claim: Yeah. First of all, captain, thank you for your service. I'm puzzled. I understand the image of Guantanamo. And we had serious questions inside the Bush administration about Guantanamo. As David suggested, we took about two-thirds of the prison population out of Guantanamo, not as David suggested, because we thought they were innocent.

We actually transferred them to third countries actually to kind of home of record with the assumption that they would then be held there or watched there so that they would no longer be a danger, all right? I guess if you believe we are at war and that these are enemy combatants, we've got to put them somewhere. I'm not wedded to Guantanamo. I understand the image issue. But our right to detain them, I think, is unarguable under the laws of armed conflict. And--

### Moderator
Claim: --to be held for eight years without trial or with evidence against you.

### Conspiracy Advocate (CA)
Claim: No. Captain, I'm sorry. You're the lawyer, and I'm not, all right? But nowhere does Geneva require us to try enemy combatants. I sat with-- in my last capacity as head of CIA, I had multiple visits from the president of the International Red Cross as we were trying to get closer to some of the things they were suggesting to us. He never suggested we had to try anybody. They did have-- as David knows, they have CSRTs, combatant status review tribunals, which is what happens within the military. It is the tradition of the military to ensure through this process, due process, that the individual you have is indeed the individual you believe them to be. I just don't understand what of this enemy is unlawful. And the unlawful combatant or unprivileged belligerent is the new phraseology. What does that give them rights that 6 million other prisoners of war we've held as a nation have not had?

### Moderator
Claim: Marc Thiessen, do you want to join your partner on this one, because I think--

### Conspiracy Advocate (CA)
Claim: I do want to, because I-- I thank you also for your service, but I think my answer to you is what you say is you should defend the other people in uniform who serve proudly at Guantanamo and keep this country safe. The fact is that most of those people are asking those questions because of misstatements, mistruths and lies that have been spread about Guantanamo Bay.

### Moderator
Claim: You mean the Iraqis are misinformed.

### Conspiracy Advocate (CA)
Claim: Iraqis, people around the world because people in-- these allegations go out there and, as my old boss, Donald Rumsfeld used to say, the truth goes around the world 30 times before-- lies go around the world 30 times before troops get their boots off. Every investigation into conduct at Guantanamo Bay has found these allegations of widespread abuse are false. Brigadier generals Schmidt and Furlow did a careful investigation. No, quote, no evidence of torture or inhumane treatment at JCF Guantanamo. They've made the inspector general A.T. Church, who I interviewed for my book, and who said he expected to find widespread abuse at Guantanamo said that when he investigated, conducted hundreds of interviews, interviewed detainees, interviewed everybody who had been there. He said we can confidently state, based upon this investigation, we found nothing that would any way substantiate detainees’ allegations of torture or violent physical abuse at Guantanamo. Now, I'll tell you something. We are also hearing from the other side that people there are the poor sheep herders and goat herders who have been wrapped up and taken to Guantanamo. The combat leadership of the Taliban today is made up of Guantanamo alumni. Just last week in Yemen, the Yeminis arrested a Guantanamo alumnus who was joining al-Qaeda in the Arabian peninsula. And the man who is one of the leaders of al-Qaeda in the Arabian Peninsula who sent the Christmas day bomber is a former Guantanamo inmate. These are dangerous, dangerous people.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: And even the Obama administration's review found 95 percent of the people who are there right now are either leaders or fighters for al-Qaeda and the Taliban.

### Moderator
Claim: Marc, thank you. David Frakt, do you want to respond? But I sort of feel the captain did your work for you on that question.

### Scientific Advocate (SA)
Claim: Well, I want to respond to a specific point made by Marc about this reports, investigations into detainee abuse at Guantanamo and the claim that they searched, and they didn't find anything. He referenced the Church report, the Schmidt-Furlow report.

When I was representing Mohammed Jawad, a teenage boy from Afghanistan at Guantanamo, a prosecutor by the name of lieutenant colonel Darrel Vandeveld turned over some discovery materials to me that showed that my then, at that point, 16 or 17- year-old client had been subjected to what was called the frequent flyer sleep deprivation program. And according to the Schmidt-Furlow report, they had discovered that there had been a frequent flyer sleep deprivation program. And during this program, detainees were moved, and in the case of my client, 112 times from cell to cell during a two-week period. He was moved constantly back and forth in an effort to deprive him of sleep.

And so-- but according to the Schmidt-Furlow report, this program had been stopped after a complaint by the FBI, it had been stopped in March of 2004. The only problem with that was that my client had been subjected to the program in May of 2004. And so I asked Colonel Vandeveld to continue digging, and he found additional records that showed that this program continued for at least another year. And dozens of other people were subjected to it. In fact, we had the person who ran the program. There was a major, who was an intelligence officer in the army, came to testify at Guantanamo in the hearing that-- in which I was representing a detainee and said this was standard operating procedure. The generals knew about it. Everybody was vetted and approved. So these investigations were white washes. They missed widespread abuses. I tried to bring this to the attention of the Department of Defense. I filed a report of a violation of the Law of Armed Conflict, as is my duty to do as a military officer. What did they do? Nothing, no follow-up investigation, I was never contacted.

### Moderator
Claim: So we have a very basic disagreement about what we think is happening inside the walls of Guantanamo.

You say that basically there have been very few undocumented violations and David is saying that these are whitewashed, that there's reports that say that.

### Conspiracy Advocate (CA)
Claim: I think that's a shocking thing to say about Admiral Church and those people who are-- you know, people who wore our uniform with honor-- hold on, no, you talked, now let me--

### Moderator
Claim: Marc, respond, please.

### Conspiracy Advocate (CA)
Claim: Okay, let me get a word in here, please.

### Moderator
Claim: Now wait, you've had no problem on getting the words in.

### Conspiracy Advocate (CA)
Claim: This frequent flier program you referred to, where for someone who's moved once every four hours roughly, two to four hours, what do you think these detainees in Guantanamo do all day? They're not busting rocks. They're not making a license plates. They sleep. They read the Koran. They play foosball. They play soccer. They eat whenever they want, sleep whenever they want. This is not torture. There is frequent flier. You may not like it. But I'll tell you something, people-- interrogation, interrogation techniques, even interrogation techniques under the Geneva Convention people would find shocking if you're not familiar with interrogation-- interrogation is not supposed to be pleasant. And you have in the case of some of these people who are at Guantanamo, people who are senior al-Qaeda leaders, senior Taliban leaders who have intelligence about the possibility of planned attacks against the United States and they have the responsibility to get them within the rules of law, and they did it. And these-- investigations were conducted, they were open, and they found no evidence of widespread abuse.

### Scientific Advocate (SA)
Claim: And that's because the senior al-Qaeda leaders were locked up in secret CIA ghost prisons in Eastern European countries and in Thailand and places that we were not allowed to know about, that's where the worst abuses went on, but there were plenty of horrific abuses at Guantanamo--

### Conspiracy Advocate (CA)
Claim: I'll come back.

### Moderator
Claim: --was the Director of the CIA.

### Conspiracy Advocate (CA)
Claim: I'll come back with a debate on interrogation techniques, just sign me up. To summarize the last statement, I believe the American armed forces are competent and capable of holding enemy combatants as prisoners of war consistent with the laws of armed conflict.

Discussion about that point or distraction from the basic question we have in front of us today.

### Moderator
Claim: Another question from the audience? And I just want to encourage you, again, the Captain's question was terrific, but please to keep the rhetorical flourishes to a minimum because they chew up time and the question was so good all by itself. In the front row, and then I'll start moving up after that. Could you-- so could you please rise just so the camera can find you?

### Moderator
Claim: Kayvon Afshari, CBS News. I do want to come back to David Frakt's fundamental point, and I'd like to get a response from Marc in particular. A lot of the guilt or innocence of these suspected enemy combatants is a lot more nebulous than that of Abdulmutallab, so I just want to know on a very practical level if we don't go through the criminal justice system, how do we know if they are terrorists?

### Conspiracy Advocate (CA)
Claim: First of all, it's not about guilt. You don't have to prove guilt. These are not criminal defendants. You have to have a reasonable belief that these people were captured in the war and that they are members of al-Qaeda or the Taliban and were conducting operations against us. The fact is, we have detained in the War on Terror well over 100,000 people. Only 800 made it to Guantanamo. Only 100 made it into the CIA program. So these are-- we're not just picking people up off the street and throwing them in Guantanamo. Were there some people that were sent there by accident, that we made a mistake? Our enemy doesn't wear uniforms. They don’t follow a chain of command is hard. There's some mistakes made, absolutely, and we had a process in Guantanamo that was set up to review the evidence against them and to make sure that people who were not-- didn't belong there were sent back. But the reality is that we got - - you know, if we-- the left always wants to get this debate onto the topic of abuse. This is a debate about keeping this country safe with the exception of one of our debaters.

### Moderator
Claim: Michael Hayden.

### Conspiracy Advocate (CA)
Claim: What's the judicial process you would use for killing the believed enemy combatant as opposed to capturing him?

### Moderator
Claim: Stephen Jones.

### Scientific Advocate (SA)
Claim: Well, I think, Marc, the problem that I have, and I think David is right, capturing people on the battlefield is different than arresting someone at the Detroit Airport for committing or attempting to commit what is clearly a violation of the federal criminal law, and cannot take that person consistent with the Constitution of the United States and Title 18, which is the Criminal Code, and try him other than in a federal criminal court according to the federal rules of criminal procedure and the federal rules of evidence and to maintain that you can--

### Conspiracy Advocate (CA)
Claim: You’re wrong.

### Scientific Advocate (SA)
Claim: Well, you’re wrong.

### Conspiracy Advocate (CA)
Claim: No.

### Scientific Advocate (SA)
Claim: We don’t have a separate criminal justice system for people that commit crimes in the United States. And it isn’t a question mark of politics or the Left or the Right--

### Moderator
Claim: Stephen, could you just stay with your mic please?

### Scientific Advocate (SA)
Claim: --or Bush versus Obama. It’s a question of the Constitution. It’s not political, it’s Constitutional and there’s one system of law in this country. Now I will concede that in a battlefield situation abroad or outside the United States, the line is blurry. But when you start saying that you’re going to arrest people and try them in a military tribunal for crimes committed in the United States against American citizens, I don’t think the American people will tolerate that.

### Moderator
Claim: Stephen--

### Moderator
Claim: This is an Intelligence Squared debate. I’m John Donvan of ABC and I’m serving as moderator as we debate this motion: “treat terrorists like enemy combatants not criminals.” We have two teams against two who are hashing it out. We are now going to Marc Thiessen to respond to the point just made.

### Conspiracy Advocate (CA)
Claim: First of all, ex parte quirin 1942, this is the Supreme Court: one who takes up arms against the United States in a foreign theater of war regardless of his position shall be regarded properly as an enemy combatant and treated as such. It doesn’t matter whether they’re a citizen or not. I would now assume that you now consider Franklin Roosevelt was a war criminal because of the military commissions for the saboteurs who were captured here are unconstitutional as well. And on top of that, military commissions that have been held outside of the Article Three court going back to George Washington. I assume he’s not a war criminal either. But again, you’re completely focused on the criminal justice system. I don’t care if we put Khalid Sheikh Mohammed on trial or not when we capture him. When Khalid Sheikh Mohammed is captured, I want to know what his plans for the next attack are. My question to you is you’re focused on where he’s going to be tried. I want to find out what he knows. When Khalid Sheikh Mohammed was captured, if you were the one who was responsible for getting the information, in the case he’s captured, he’s killed 3000 people just down the street from here. He admits to you that he has plans for new attacks in motion. Does Khalid Sheikh Mohammed have the right to remain silent?

### Scientific Advocate (SA)
Claim: Well of course he has the right to remain silent. The only difference between your position and mine is that you don’t think that he should be told he has the right to remain silent and I think it’s beside the point because of course he knows he has the right to remain silent.

### Conspiracy Advocate (CA)
Claim: So you’re saying-- let’s say we captured Khalid Sheikh Mohammed before the 9/11 attacks. Put aside the litany of attacks that he had in play. You would have allowed 9/11 to go on rather that to get him to give the information that he had.

### Scientific Advocate (SA)
Claim: Now Marc, let’s don’t defend the indefensible here.

### Conspiracy Advocate (CA)
Claim: It’s not the indefensible. Khalid Sheikh Mohammed killed 3000 people in this country. He had information, a plot to blow up the Library Tower in Los Angeles, blow up a marine camp in Djibouti, to blow up the consulate in Karachi.

These are real attacks. To commit, repeat 9/11 in London.

### Scientific Advocate (SA)
Claim: Well that may be true but I don’t want to take “The Weekly Standard’s” word for it or frankly your book. If all of that is true, then it can be presented to an American jury. An American jury will convict him and give him the death penalty.

### Moderator
Claim: What if the clock is ticking in the situation that Marc’s just described . You believe he knows about something that’s about to happen we’re five minutes away. Would it make a difference?

### Scientific Advocate (SA)
Claim: There’s a movie about that and I think that’s an over-dramatization of the issue. Those who look for a way to short-cut the system always first bring forward the most extreme example of what could happen. But the truth of the matter is those extreme examples rarely exist. Where they do exist, I believe the intelligence community and the law enforcement community have on numerous occasions shown the ability much better than politicians to protect individual security or, for that matter, national security.

### Moderator
Claim: David Frakt, you wanted--

### Scientific Advocate (SA)
Claim: Yes. I mean the whole ticking time bomb scenario is really a red herring. First of all, police, in the situation where there is an urgent public safety emergency are not required to give the Miranda warning. So-- but if your question is should we use torture in that situation? And that’s essentially what Marc is saying is that, you know, in order to prevent an attack, you have to be willing to do anything, whatever it takes. And that's where we have a fundamental disagreement. If we captured Osama Bin Laden, I would not torture him. Is that possibly going to lead to an attack that might have been prevented? It might.

### Moderator
Claim: Are you okay with that?

### Scientific Advocate (SA)
Claim: I am okay with it because it would be a great tragedy.

But it would be a greater tragedy to go down the road which we already went down of torturing, because that one attack may not be averted, but you are going to multiply the attacks for years to come because of the torture. And that is what we have done.

### Conspiracy Advocate (CA)
Claim: Again, I-- I'll come back and walk, if you like a debate on a different subject but as the only one on stage who has actually had the question in front of him as to whether or not it--

### Moderator
Claim: Except, Michael, that your partner brought these issues to the table himself in his opening remarks in talk-- in justifying and laying out several scenarios in which the actual methods did do it. I think they're relevant. I don't think it's-- it's not a vote on that, but I think it's germane to understanding what the motion means. And I'd like to see if Marc could respond to what was just said because this is where the rubber hit the road.

### Conspiracy Advocate (CA)
Claim: Well, actually, no. Let me finish, because the rubber hit the road on my car, all right? I'm the one who has to make the decision, okay? These are not easy decisions. There are conflicting values. There are moral responsibilities galore, okay? No one should trivialize it, and no one should throw bumper stickers at the difficulty of the decision people like me, people like Leon Panetta, have to make, all right? But I come back--

But I come back to the fundamental question, the American armed forces, the American intelligence community are capable of holding people, consistent with the laws of armed conflict. I feel as if we have gone through the looking glass in the last 30 to 40 minutes as we try to take people who are armed enemy combatants-- and David did not make the straw man that Iraq is okay to capture, it's not okay to capture and keep enemy combatants in Brooklyn, okay? What about Mali? What about Djibouti, what about Yemen? What about the horn of Africa? What about Pakistan?

That is where the enemy is. That is where the enemy is mounting an attack against our citizens. They are enemy combatants. And as God is my judge, I will use the full authority that the law of armed conflict gives me as long as my president and my Congress has given me that authorization.

### Moderator
Claim: And your partner, Marc Thiessen.

### Conspiracy Advocate (CA)
Claim: I would add to that to complete. We're not going to have time to debate all of the interrogation techniques. They were not torture. And I can walk you through it if you really want to.

### Scientific Advocate (SA)
Claim: I'd rather not.

### Conspiracy Advocate (CA)
Claim: Well--

Well, I'll tell you something. You said something, and this is – you’re sort of dismissive of the threat in a very sort of disturbing way. You said well, yeah, I've let the-- you basically admitted you had let the attack happened and treat him as a criminal rather than an enemy combatant. You know, you said earlier, when-- about my introductory remark, two little terrorist networks. Well, you know what? One of those two little terrorist networks killed 3,000 people down the street from here, 19 men with box cutters. This is a real threat. These people are out there every day trying to kill us. And I think it's really shameful to dismiss them as two little terrorist networks. Khalid Sheikh Mohammed was captured in Pakistan. You said unless he's in Iraq or Afghanistan, he's not an enemy combatant. So do you consider can a lead sheik Mohammed an enemy combatant, the master mind of 9/11, the man who commanded the operation, the operational commander of al-Qaeda? Is he an enemy combatant, yes or no?

### Scientific Advocate (SA)
Claim: How do you know that he is the mastermind of 9/11? What--

### Conspiracy Advocate (CA)
Claim: Oh, my God.

### Scientific Advocate (SA)
Claim: He has not been put on trial. And you don't want to put him on trial. And you are denying those 3,000 victims--

### Conspiracy Advocate (CA)
Claim: I'm not denying them anything.

### Scientific Advocate (SA)
Claim: You are denying-- you say it's not important to have a trial. I say it is important to have a trial.

### Conspiracy Advocate (CA)
Claim: It's not the first priority.

### Scientific Advocate (SA)
Claim: It is important to establish the truth of what happened and for people to get some closure. And it's important for these people to be punished. I do not in any way diminish the seriousness of 9/11. And I agree with General Hayden that these are difficult decisions. And I am not sure that I would want to be in the position he was in of having to make those.

But what I will tell you is that the oath that we take, that we both took as officers in the United States military is to defend the Constitution of the United States. It is not to defend the people of the United States. Because what we are defending are our values and our history. And sometimes, yes, it may cost lives. But you cannot achieve perfect security. And when you try to, by making shortcuts, you ultimately diminish us as a country. And it does not serve us in the long run.

### Moderator
Claim: Yes from the-- the blue jacket and white-- blue shirt and dark blue Blazer. Yep. Your colleague is tapping you on the shoulder.

### Moderator
Claim: Could you just wait for the microphone? And again, to keep it as a question and--

### Moderator
Claim: My name is Les Shelton, and my question is that-- comes from the fact that it seems that what was really most difficult is what is the definition, operationally of a person whose terrorist that talking how can we be sure that a terrorist on a bus in Pakistan and the whole bus is grabbed because they know a terrorist is on the bus. And how do we understand, as people listening to all this, how we can feel comfortable with the shortcut because nobody wants their ass burned. And the fact of the matter is we need to feel a bit more-- I need to feel a bit more comfortable about the selection process for applying these definitions is somehow rational. And I have to say that our legal system is one of the ways those things are done. But again, we have a group of people who say they're experts. And they know these people are. But we have a bad history. That isn't always the case.

### Moderator
Claim: Sir, can you cut to your question.

### Moderator
Claim: The question is how do we make this distinction so that all of us can feel more comfortable with what our government may be doing?

### Moderator
Claim: You mean the distinction who are the terrorists and who is not?

### Moderator
Claim: Yeah. You know, how to get the innocents off the bus.

### Moderator
Claim: How and who? I mean, there is also the question of who makes the distinction as well.

### Moderator
Claim: Yeah.

### Moderator
Claim: Let's take that to the side for the motion. Mike, go ahead.

### Conspiracy Advocate (CA)
Claim: It's a process. It's a rigorous process. I governed it while I was the director of CIA with regard to that portion of the war that CIA had responsibility for. To be clear, just being a terrorist doesn't get much interest from us. The authorization we have from the Congress and the authorization for the use of military force is against al-Qaeda and its affiliates. So it's not a global terrorist issue. We are at war with a select group of terrorists. President Obama has made that clear. The Congress has made that clear. President Bush has made that clear. We used same criteria to capture an individual as a terrorist that we use on the battlefield to kill. It is visual who is a terrorist. I am responding to the political processes of the American state. All three branches of government have said we are at war. I'm using the full authority given to me. I use it in the clearest conscience I have. Are mistakes made on the battlefield? Killing, capturing? Of course, they are. What-- you have very good men and women working very hard to apply absolute precision to their task. Now, I will admit that the processes of intelligence are a bit different than the processes of the judicial system. Again, as I mentioned in the one habeas case, we had to fold our tent and admit defeat because I could not, in conscience, tell the enemy combatant who the source of our information was. If I did that, I would quickly not have sources of information anywhere in the world. And so we had to make a serious tradeoff.

That's what I mean by putting this into a law enforcement template, rather than using a vigorous and consistent with the rule of law, law of armed conflict.

### Moderator
Claim: Thank you, Michael Hayden. Go ahead and take one more question. There is-- on the far aisle, almost near the top. Yes. Up seven steps.

### Moderator
Claim: Thank you. I think my question is for General Hayden. You and your partner have admitted that mistakes are sometimes made as to who does get picked up as a terrorist. In the civilian justice system, we say it's something of a cliché, that it's better for 100 guilty men to walk free than to convict an innocent man unjustly. What's your calculation in the war on terror? How many non-terrorists can be rendered off the streets of Toronto or Amsterdam to make it okay?

### Conspiracy Advocate (CA)
Claim: Obviously there's no precise answer to the question.

### Moderator
Claim: Michael Hayden.

### Conspiracy Advocate (CA)
Claim: We do the very best we can. And we review our data constantly. As I mentioned, to David's point-- and he’s nodding in agreement because he's familiar with the process. We have combatant status review teams even before we had the habeas process at Guantanamo. You go over the evidence routinely. It's required by our regulations. It's required by the regime that's in place at Guantanamo. I hope the audience is not demanding 100 percent certitude and 100 percent perfection before your intelligence services or your military services can act in your defense.

### Moderator
Claim: And that concludes round two of our debate.

## Round 3

### Moderator
Claim: We are about to hear closing statements from each debater. There will be two minutes, each. This is their last chance to change your mind.

You will be asked to vote once again immediately after they speak and to pick the winner in this debate just a few minutes from now. Our motion is "Treat Enemy Terrorists Like--" excuse me-- our motion is "Treat Terrorists Like Enemy Combatants, Not Criminals." And first, to summarize his position against the motion, Stephen Jones, who served as principal defense counsel for Oklahoma City bomber Timothy McVeigh.

### Scientific Advocate (SA)
Claim: As we have listened to the debate tonight, I think two or three issues have emerged sharply. The issue is not just about the treatment of individuals at Guantanamo Bay. The issue is larger and that is, what is the system we will use to adjudicate the guilt of those persons charged with crimes against the United States. And I say that the line is indivisible. By that I mean you cannot say, "We have one set of justice over here for these categories of crimes, that one rule of evidence, one rule of procedure, one rule of appellate practice, and over here we have an entirely different rule of evidence and a different procedure.” First, that leaves the intelligence community who are largely anonymous and many law enforcement officers and prosecutors unaccountable in the final analysis for the decision made. General Hayden has been very correct in telling you that there is not 100 percent perfection and there isn't. After all, the 9/11 Commission in its report talked about the system was blinking red, so our intelligence and many of our law enforcement officials and indeed political leaders knew of the risks and did nothing.

In the final analysis, accountability for responsible decisions has to be made somewhere, political process, the legal process, something done openly, but that is not what the argument is made by our colleagues to our right. Their argument is trust us, trust us, we'll get it right this time. Unfortunately history shows too many examples of not getting it right. That's why we have the rule of law.

### Moderator
Claim: Thank you, Stephen Jones.

For the motion to Treat Terrorists Like Enemy Combatants, Not Criminals, and summarizing his position for this motion, Marc Thiessen, a columnist for the Washington Post, a Fellow at the American Enterprise Institute, and former speechwriter for President George W. Bush.

### Conspiracy Advocate (CA)
Claim: We did get it right. In the period in the eight years before September 11th, 2001, al- Qaeda killed roughly 3,500 people in a series of attacks starting with the 1993 World Trade Center bombing, followed by the attack on our embassies in Kenya and Tanzania, followed by the-- or the attack on the USS Cole and culminating in September 11th, 2001. That was when we followed the law enforcement approach to interrogation. During that period of time, we prosecuted 29 people in connection with those attacks. If you think that is an approach-- and we didn't get the intelligence we needed to stop the September 11th terrorist attacks, in the period that followed we have not been hit again. So it's a very stark question; do you want to go back to the approach when al-Qaeda was mounting attacks of increasingly lethality, or do you want to follow the approach that we took which has kept this country safe for almost a decade? Our opponents are trying to wiggle out of it. They want you to-- focus you on waterboarding and the interrogation techniques. If they don't like the techniques we used, there's a wide line between waterboarding on one hand and "You have the right to remain silent," lawful techniques that can be used short of that.

Choose other techniques, but what their position holds, if you hold that a terrorist is a criminal and not an enemy combatant, we cannot kill them using predator drones outside of the war zones of Iraq and Afghanistan. We cannot kill them in Pakistan. We cannot kill them in Yemen. We cannot kill them in East Africa. There are terrorists plotting to attack us right now that Barack Obama would not be allowed to kill. And second, we will not be able to interrogate them effectively as we found out after the Christmas Day bomber, as we found out with the Times Square bomber. So this is a very stark question. Do you want to go back to the approach that led to 3,500 American people getting killed and we were not able to get the intelligence to stop the attack. Or do you want to follow the approach that kept our country safe for almost a decade.

### Moderator
Claim: Thank you, Marc Thiessen.

The motion is “treat terrorists like enemy combatants, not criminals,” and summarizing his position against this motion, David Frakt, a lieutenant colonel in the Air Force Reserve, JAG Corps who served as lead defense counsel with the Office of Military Commissions.

### Scientific Advocate (SA)
Claim: Our opponents seem to have valued American lives more than the lives of anybody else. They seem to forget about Madrid, about London, about Bali. The terrorists have not stopped. But simply because we’ve tightened security domestically and presented easy targets overseas, the action is moved overseas. We are not safer today than we were on September 12th, 2001. We are in a worse position because of our actions in the war on terror, our lawlessness and our abandonment of the rule of law. General Hayden talks a lot about the rule of law and serving it but that was not really our experience under the prior administration. Let me tell you about my personal experience. I was assigned to represent two detainees in Guantanamo.

Both had been determined to be enemy combatants in the combatant status tribunals that you heard about. But in fact, neither was an enemy combatant. One, Mr. Ali Hamza al Bahlul was, in fact, a terrorist. He was an Al Qaeda insider. He was a media advisor and created propaganda for Al Qaeda. He should have been tried in federal court for material support in terrorism. He was not an operational terrorist. He did not kill any Americans. He did not plot any attacks on Americans. The other was neither an enemy combatant nor a terrorist and, in fact, he was a child who had been tortured into confessing to something he didn’t do. A lot of mistakes were made. The rule of law was not observed. Over time, with the intervention of the Supreme Court, we gradually brought the pendulum back to something approaching equilibrium. But they’re advocating going back. I’m advocating going forward. So we urge you to vote against the proposition. Thank you.

### Moderator
Claim: Thank you, David Frakt.

Our motion is “treat terrorists as enemy combatants, not criminals,” and to summarize for the motion, our final speaker, Michael Hayden, former CIA Director and the country’s first principal deputy director of National Intelligence and the former director of the NSA.

### Conspiracy Advocate (CA)
Claim: As I predicted and somewhat feared, we’ve sidled into a discussion as to whether or not you are for or against the rule of law. I warned you that that was not the issue here, that there is plenty of law with the laws of conflict to govern our behavior and the American armed forces, the American intelligence community are quite capable and competent to function within that framework. I was taken aback a little bit by saying that the intelligence community is not accountable. Clearly Stephen has never been in front of the Senate Select Committee or the House Permanent Select Committee on Intelligence and to go through the openness that we share within the confines of those committees.

I was struck as Stephen said the system was blinking red and I think he was alleging some sort of incompetence. The attack still happened in the summer in September of 2001. The attack still happened not because the intelligence was wanting-- although certainly you can always use better intelligence. The act took place because the model we were using, the model in which we placed the intelligence which was a law enforcement model. The difference between now and 9/11 is that we are a nation at war and we are taking the fight to the enemy. There’s an office in CIA, most operational office that we have on our Langley campus, responsible for many of the things the current administration is taking credit for. You walk into that office you hit a bulkhead, a wall, and there’s a sign there saying today’s date and you walk by it, very often don’t recognize it but every now and again you catch it. It actually says today’s date is September 12th, 2001. It’s been up there for over eight years. When I was director and got in a car and drove down G.W. parkway to my home, it didn't feel like September 12th. It felt a lot like September 10th. That's an attitude that we adopt at our peril. Thank you.

### Moderator
Claim: Thank you, Michael. That concludes our closing statements. And now it's time to learn which side argued best. I'm going to ask you, once again, to vote. Go to those key pads at your seat that will register your vote. And we will get the readout and the results almost instantaneously. Our motion is “treat terrorists like enemy combatants, not criminals.” If you agree with the motion, push number one. If you disagree, push number two. If you are undecided or became undecided, push number three. And you can ignore the other numbers. And if you want to correct your entry, go ahead and do so, and it'll lock in the latest one. Yeah. It will be a while, no? Or did you did you get persuaded to go to the other side?

I think not.

### Scientific Advocate (SA)
Claim: I was undecided before, but I'm definitely against now.

### Moderator
Claim: I'm going to have the results in just a moment. I think we've locked out the system. And I just want to-- first of all, when I said-- when I was going to say the rubber hit the road, it's rare that we actually-- and I know that it's in your car. But that we actually came to a kind of moment I think of really essential truth about the difference between the two sides. And it was-- I applaud both sides for going to that point and for a very, very spirited debate from both teams today.

And the questions from the audience, including with the rhetorical flourish from West Point, we're quite good, quite on point and better than we normally get. So I want to thank you for those as well. This is only the first of our five-part debate series throughout the fall. Our next debate is going to be on Wednesday, October 6th. Our motion is Islam is a religion of peace. Panelists for this motion are Zeba Khan, a writer and an advocate for Muslim American civic engagement and Maajid Nawaz, a former member of a radical Islamist party who served four years in an Egyptian prison as a prisoner of conscience. Against the motion is Somali born Dutch parliamentarian who has a Fatwa on her head, Ayaan Hirsi Ali and Douglas Murray who is director of the Center for Social Cohesion, which is a London think tank that is focused on radicalism. Individual tickets are still available by visiting our website and at the Skirball box office. We also have outside DVDs of past debates and books by our panelists which obviously include Marc Thiessen's book. His mother did not buy all of them. There are more out there. Make sure you can become a fan of Intelligence Squared now on Facebook. And by doing so, you'll get a discount on our upcoming debates. All of our debates can be heard now on more than 220 NPR stations across the country.

And you can also watch them on Bloomberg television network. This debate starts running on Monday at 9:00 p.m. Visit Bloomberg.com to find your local channel. Intelligence Squared is now one of the most popular podcasts on iTunes. We are very pleased about that. So download, join the trend and listen to past debates of Intelligence Squared US.

All right. I now have the final results. We had you vote twice, one before the debate and once again at the conclusion. We asked you where you stood on our motion, which is “treat terrorists like enemy combatants, not criminals.” The team that has changed the most minds, that has moved the most percentage points will be declared our winner. Here is how it went. Before the debate, 33 percent of you were for the motion. 32 percent were against. 35 percent were undecided. After the debate, 39 percent for, 55 percent against, 6 percent undecided. The side against the motion wins.

Our congratulations to them. Thank you from me, John Donvan and Intelligence Squared U.S.
