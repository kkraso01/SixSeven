# Debate Transcript

Topic: Legalize Drugs
Motion: Legalize Drugs

Debate ID: 111412%20drugs


## Round 1

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hi, Bob. And what Robert does-- what Bob does is he frames for us, just in a couple of minutes, what the stakes are in this debate and what's-- what are-- the validity of the arguments on both sides. So let's start, Bob, just by asking why this debate now?

### Moderator
Claim: Well, it's very timely because, of course, Colorado and Washington have just passed referenda legalizing the recreational use of marijuana. Now, this topic is broader than marijuana. This is about all kinds of recreational drugs. But it's timely for that reason, and it's also timely because in recent years, both the left and the right have coalesced around the pro motion position.

### Moderator
Claim: And the side arguing for the motion to legal lies drugs, how strong an argument do they have?

### Moderator
Claim: Well, I think their best argument is that current policy has failed. And we'd be better off placing reliance on treatment, on rehabilitation, on education. That the costs of creating a criminal industry are huge, not only the obvious costs of enforcement, of prison, but we create a situation in which the leading role models in inner city communities are drug dealers in which a disproportionate number of black youth languish away in prisons.

### Moderator
Claim: And the team arguing against the motion, what's their best argument?

### Moderator
Claim: Well, I think their best argument is simply that the consequences of drug use are so severe that the government can't simply leave this is a matter of individual choice. In many cases, kids get hooked on drugs well before they reach the age of being able to make reasoned choices. And it's just simply not a matter where you can have a libertarian idea that this is-- that this is individual, because it affects so much else in society.

### Moderator
Claim: All right. So there we see it framed, the debate in front of us. And let's bring our debaters to the stage. Thank you, Bob Rosenkranz.

### Moderator
Claim: Thank you.

### Moderator
Claim: Thank you. And I just want to invite one more round of applause for Bob Rosenkranz for making this possible. We call it a war, and for 41 years, we have been fighting it, a war on drugs. The estimated costs so far, about 2.5 trillion dollars.

The results so far, mixed. So what does it say that voters in Colorado and Washington state recently went to the ballot box and decided to legalize one of the drugs we've been fighting all of these years, weed, pot, marijuana. What is that, is it treason, or is it a facing up to a certain social reality? Is this war worth continuing to fight on? And if so, what direction do we take it in? Those are a lot of questions. But they all boil down to the one that we're going to be debating here tonight. And here it is: Yes or no to this statement, legalize drugs. That is the motion on the table. A debate from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters who will be arguing for and against it, legalize drugs. We go in three rounds. Then the audience votes to choose the winner, and only one side wins. Meeting our debaters, on the side arguing for the motion, legalize drugs, Paul Butler, professor of law at Georgetown and former federal prosecutor.

His partner, Nick Gillespie, editor in chief of reason.com and reason TV.

The motion, "Legalize Drugs," arguing against, Asa Hutchinson, CEO of the Hutchinson Group and former administrator of the Drug Enforcement Administration. And his partner, Theodore Dalrymple, a retired prison doctor, now a fellow at the Manhattan Institute. Our motion is "Legalize drugs." Let's talk with our debaters as they come to the stage. Paul Butler, you are a Georgetown law professor. You are arguing for the motion, "Legalize drugs." After Harvard Law you clerked for a judge. You worked in corporate law.

You then became a federal prosecutor and worked for the Department of Justice. But then something happened that made you give it all up, and it changed the way you thought about the criminal justice system. What was that?

### Conspiracy Advocate (CA)
Claim: So somebody forgot to tell the police about all those credentials. And I got arrested for a crime I didn't commit. It was when I had the most high profile case as a prosecutor, I was prosecuting a U.S. senator, and, again, I got locked up. You can read all about it in the first chapter of my book, "Let's Get Free, a Hip-Hop Theory of Justice."

### Moderator
Claim: Commercials allowed. And your partner is?

### Conspiracy Advocate (CA)
Claim: My partner is Nick Gillespie.

### Moderator
Claim: Ladies and gentlemen, Nick Gillespie. Nick, you are editor-in-chief of the Libertarian Reason.com and Reason TV?

### Conspiracy Advocate (CA)
Claim: I'm guilty.

### Moderator
Claim: You have talked about the fact that you have used both legal and illegal drugs recreationally. Interestingly, you once lived on a street called "Stoner Avenue." You did not use illegal drugs while living there, which ruins the story a little bit. But what is your take seriously on recreational drug use? Is there a danger involved in them?

### Conspiracy Advocate (CA)
Claim: I'd say the only danger is that oftentimes you run out.

### Moderator
Claim: Our motion, "Legalize drugs," and the team arguing against the motion, first, ladies and gentlemen, Theodore Dalrymple. Theodore Dalrymple is your pen name. We'll say this just once. Your real name is Anthony Daniels, for people who like the specificity. You are a writer, a former prison doctor. You-- in prison you specialized in cases involving drug offenders, and you came away from that experience thinking that we have the relationship between crime and drugs wrong. In what way, Theodore?

### Scientific Advocate (SA)
Claim: Well, I'm going to say that we've got the relationship exactly the wrong way around. But it's always tempting for people to ascribe human misbehavior to an external factor when actually it's internal. So I don't believe in the causative relationship between drugs and crime and bad behavior, actually.

### Moderator
Claim: And your partner is?

### Scientific Advocate (SA)
Claim: Asa Hutchinson.

### Moderator
Claim: Ladies and gentlemen, Asa Hutchinson. Asa Hutchinson, you are a former administrator of the Drug Enforcement Administration. You were also a long term member of Congress. You had served two terms. You had just been elected for the third time when President Bush tapped you to go to the DEA. Why'd you make the choice to do that?

### Scientific Advocate (SA)
Claim: How do you say no to the president when he asks you to do something? You try to say yes. Jokingly, but seriously, what a great agency. And I wanted to bring not just enforcement efforts to DEA but also demand reduction efforts and cooperation with the rehabilitation community.

### Moderator
Claim: All right, ladies and gentlemen, our four debaters. Our motion is "Legalize drugs," and before the debate begins and again after the debate we're going to ask you to vote. That's two votes. And the team that has moved its numbers, changed most of your minds in the course of the debate, between those two votes, will be declared our winner. So let's go to the first round of voting now. Our motion is legalize drugs. If coming in off the street you agree with this motion, push number one. If you disagree, push number two. And if you're undecided, push number three. You can ignore the other keys. And you can correct a mis-keying. It'll lock in your last vote. Anyone need more time or want to admit needing more time? It's pretty straightforward. All right. So once again, we're going to hold the results of that vote till the end of the debate, until you've heard all of the arguments, all three rounds, and then the team that has moved its numbers the most after the second vote will be declared our winner.

So on to round one, opening statements from each debater in turn, they will be seven minutes, each. Our motion is "Legalize drugs," and here to speak first for the motion, Paul Butler. He is a professor of law at Georgetown, a former federal prosecutor, and one of the nation's most frequently consulted scholars on race and criminal justice. Ladies and gentlemen, Paul Butler.

### Conspiracy Advocate (CA)
Claim: Thank you. Good evening, ladies and gentlemen. My name is Paul Butler, and I represent the people. When I was a prosecutor, that's how I would start my opening statements. I put a lot of people in prison; I was a soldier in the war on drugs, and tonight I'm going to give you a soldier's perspective on why that war is a colossal failure.

Later, Nick will talk about how the war on drugs has compromised our democracy and made us all less free. And he'll also talk about what legal regulation of drugs would look like. Will you be able to go into Whole Foods and buy cocaine? Nick will tell you about the experiences of countries all over the world that have safely legalized drugs. As a prosecutor, I learned that as many people as I locked up, we weren't making a dent in the drug trade; we were actually making neighborhoods less safe. I was prosecuting a lot of 19- and 20-year-olds for nonviolent drug offenses. Locking up these young people with a bunch of hardcore rapists and murderers was like sending them to finishing school for criminals. When these kids came home, they had learned how to be really good bad guys. If we legalize drugs, we will stop the counter-productive practice of treating kids the same that we treat violent criminals, and we would all be safer.

Maybe my work as a prosecutor would've been worth the enormous social cost if it was getting drugs off the street, but we all know the war on drugs doesn't do that. No country has ever found a way to prevent people from using drugs.

The United States locks up more people than any country in the history of the world. We have 5 percent of the world's population and 25 percent of the world's prisoners. It costs us billions of dollars that we just cannot afford, and it's just as easy to get drugs now as it always has been.

What about drug addicts? It turns out that the small percentage of people who use drugs who become addicts, we know that treatment is a more effective solution than punishment for those people. Most of us are lucky, we don't have a crack head or a meth addict in our family, but everybody's got an alcoholic in the family; tobacco might be a close second, but I think we all agree that alcohol is probably the worst drug, right?

If you think of it in terms of dysfunctional families, laws, economic productivity, health problems, the people who commit crimes under the influence. But is the answer to make using alcohol a crime? Of course not. We tried that during Prohibition and it just did not work. All we did was create this illegal, violent market for liquor just like for other drugs now, and we didn't stop anybody who wanted to, from drinking, just like we don't stop anybody now from using drugs.

So I'm speaking based on my research as a law professor, my work as a prosecutor, and also, my life experience. Ladies and gentlemen, there's a lot of hypocrisy in the war on drugs, but I want to respect you enough to keep it real. Like most Americans, I have used illegal drugs. I wasn't introduced to them at my all-black public elementary school in Chicago, and at my Catholic high school, a lot more kids drink than smoke weed. The first time I was around a lot of people who used drugs was actually at Yale, where I went to college. And then at Harvard, where I went to law school. I'm glad I never got caught when I smoked pot, and I'm also glad that Barack Obama was not arrested and prosecuted for any of the times that he used cocaine and marijuana. My opponents are honorable men, and it makes me wonder if they really practice what they preach. As you listen to the good doctor Theodore, here's one thing you should keep in mind. He has actually prescribed heroin to addicts. He did it because he knows that addicts need to be treated, not punished. As a practicing physician, he understood that drug dependency is a medical issue, not a crime. And I read a profile of Mr. Hutchinson and he's a wonderful family man; I had the pleasure of meeting his wife, Susan. And I wonder what a father, a great father like Mr. Hutchinson would say if one his children called and said she was using cocaine.

Would he really say, "Wait a minute, honey," and whisper to his wife, "Quick, dial 911, tell the police they need to arrest out daughter; she needs to be prosecuted and locked up." Of course not, none of us would do that to our family or friends.

So my final point, ladies and gentlemen, is, respectfully, what is good enough for our children and our friends is good enough for African-Americans. We call it a war on drugs but it's mainly a war on black people; they're the people who get stopped and frisked. Last year in New York City, 50,000 people got arrested for marijuana possession, 50,000, almost 90 percent were black or Latino. That's not who really uses drugs. The National Institute of Health tells us that black people don't use drugs more than any other group. They're about 12 percent of drug users.

What about sellers? Most drug buyers report buying from someone of their own race. White kids in Scarsdale, they don’t have to go to the hood to buy. They get their weed and Ecstasy and Adderall from other white skids in Scarsdale. But who gets locked up for drug crimes? Almost two-thirds are black, 12 percent of people who do the crime, 60 percent of people who do the time. And that's selective prosecution, and it's devastated the African-American community. We have one black president and one million black people in prison. The book "The New Jim Crow" tells us that because of the war on drugs there are more African-Americans under criminal justice supervision now than there were slaves in 1850. Think about the catastrophic effect that has on families. In the black community, we have a lot of women and children who are doing time on the outside.

So, again, the most responsible way to deal with the problems of illegal drug use is to not punish people for using drugs. The reality is, for my opponents, this will never-- this is just a nice rhetorical debate. The odds are that their children will use drugs, and they will never be touched by the criminal justice system. The odds for African-American children are very different. And that just seems profoundly unfair. My friends, as a civilized society, we shouldn't punish people for being sick. We shouldn't put anybody in a cage based on what they put in their mouths. There's a better way. It's to legalize drugs.

### Moderator
Claim: Thank you. Paul Butler.

Our motion is "Legalize Drugs." And now here to speak against the motion, Asa Hutchinson. He is the CEO of the Hutchinson Group and a former congressman. He has served as administrator of the Drug Enforcement Administration and as the first undersecretary for the Department of Homeland Security. Ladies and gentlemen, Asa Hutchinson.

### Scientific Advocate (SA)
Claim: Thank you. What an exciting evening to debate an important subject for our country and for our future. Paul, great job in your opening remarks. An African-American who also happens to be in a leadership position in the United States attended the summit of the Americas in Colombia, South America. He said it is okay for us to debate the pros and cons of the war on drugs. But, quote, "I personally, in my administration, position is that legalization is not the answer," end quote. That was President Barack Obama. I happen to agree with President Barack Obama.

I agree that there are changes that need to be made as we look at how we enforce our laws. I agree that we need to have a robust debate about incarceration policies and what we are doing in our fight against illegal drugs and how much we're devoting to rehabilitation. All of those issues are appropriate to be on the table. So there needs to be changes. Paul mentioned that we need to reduce racial disparities in enforcement. That's why I have worked very hard to reduce the cocaine, the crack, and powder cocaine disparity that impacts racially across America. We've reduced that disparity. We've made a correction to the system. We need to reduce our incarceration rates. That's why I'm engaged on the Right on Crime initiative and initiatives that encourage our state legislatures to look at incarceration policies. And in Texas and in Arkansas and in South Carolina, they have reduced the incarceration rates for drug offenders, both to save money, but also to reexamine our policies.

I believe we need to improve alternatives to incarceration. That's why I've been a supporter of drug treatment courts that provide accountability with treatment so that it can be an effective treatment, and it has a great success story across America. So why-- why did the president take the position that legalization is not the answer? Perhaps he understood the success that we have achieved whenever we look at the fact that drug use has been cut in half over the last 30 years in our country. Did he want to preside-- and I know people-- I see some skeptical looks when I say that. That is in your program. That is part of the debate topic and the acknowledgment that, over the last 30 years, drug use has been cut in half in our country. And we have a president that says he does not want to see it go up on his watch.

Could it be that he does not believe that the United States ought to break its treaty obligations in which we've entered into and been a leader across the globe? And that is reason enough to vote against the proposition. Or perhaps he was thinking about his own daughters and his grandchildren, and would there be greater potential for them to be engaged in drug use that he might believe is harmful in-- whenever we continue to have it illegal in our country? And so the president made that decision both personally, he said, and with his administration. Let's look at the argument that's been presented. And first, I would say I've been introduced as a former administrator of the DEA. That is absolutely true. I'm also a front line prosecutor, a former prosecutor in Arkansas that's prosecuted cocaine cases and marijuana cases and on down the line, primarily of traffickers.

And my experience is just the opposite of Paul. In fact, when I went into a store recently to sign up for some exercise, the owner came up and said, "You put me in prison." I thought I was going to be thrown out of the place. But he looked at me, and he said, "I wanted to thank you for helping to turn my life around, because I was going down the wrong path of addiction. I was going down the wrong path of violation of the law, and it turned me around." And today he owns his own business. And so I've had a totally different experience as former federal prosecutor. They say the current model of prohibition is not working. Well, while that might appeal to the popular culture, it does not pass muster in close examination. In fact, drug usage is down over the last 30 years. Whenever you look at our war on poverty that president Lyndon Johnson proclaimed, what, 30, 35 years ago, whenever he proclaimed that, have we eliminated poverty today? Does that mean, because we have not eliminated poverty that we should stop fighting hunger? Of course not.

Well, we call it a war on drugs, which is not my preferred terminology. I believe it is an effort to save lives. It is our youth. It is our families, it is our communities at stake. How do you decrease harmful drugs in our community? Is it by legalization or is it by our present method of saying, let's improve the system. Let's make it better. But let's don't throw it out and say we're going to just turn off the spigot and make everything legal. Secondly, they talk about harm. If you believe that addictive and mind-altering drugs such as heroin, methamphetamine and cocaine are harmful, if you believe that they are harmful, then ask this question.

If you legalize, will it increase or decrease the use and the availability of harmful drugs? Now, if you believe that they're not harmful, I'm not sure I can win your debate. But if you believe they're harmful, ask the fundamental question, will it increase or decrease usage? Now, Paul made the point that you look at-- you know more alcoholics today than you do people who are drug addicts. But did ending prohibition on alcohol increase or decrease alcohol consumption in the United States of America? And if you increase drug usage, will it increase drug addiction, harmful reaction to it? They cannot show-- and I believe the burden is on them-- they cannot show that logically and over history, that if you decriminalize, if you legalize harmful drugs, the usage is going to go down. That has not been the experience in the Netherlands. It's not been the experience in the United Kingdom. It's not been the experience in Alaska. It has not been the experience in Canada. Usage has gone up.

And so, finally, in my opening, they ask me-- or Paul mentioned my family. Well, if my children came to me, and there was a drug issue, my first concern is, where are they getting those drugs? What is the availability? How can we shut that down? And as a parent, it would scare me to death to think that there is going to be easy availability, increased availability and that you can find heroin and methamphetamine just as acceptable in our society as alcohol. That creates a problem as a parent in my mind.

### Moderator
Claim: Asa Hutchinson, thank you very much. I have to acknowledge, I let you go over about 30 seconds because you were talking about your family and it just seemed that it would be so rude to step in and not let you finish. Nick, if you need an extra 30, you've got it.

### Conspiracy Advocate (CA)
Claim: Well, I'm going to try and channel the methamphetamine that Asa was talking about, so hopefully I'll need only about three minutes.

### Moderator
Claim: All right, well--

### Conspiracy Advocate (CA)
Claim: You know--

### Moderator
Claim: --before you start, because I want to introduce you, and I also want to tell our radio audience, a reminder of where we are, we are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion, "Legalize drugs." You have heard two of the opening statements, and now on to the third, debating in support of the motion, "Legalize Drugs," the editor-in-chief of Reason.com and Reason TV, he's the author of "The Declaration of Independents," T-S, and described as one of the foremost libertarians in America. Ladies and gentlemen, Nick Gillespie.

### Conspiracy Advocate (CA)
Claim: Thank you. I do want to point out in all fairness that being among the foremost libertarians in America means that myself and my coauthor, you know, that's basically it. you know, you've heard from a self described soldier in the drug war. You've heard from a general, a commander, former Drug Enforcement Administration personnel in the drug war. You'll hear from a medic in the drug war. I present myself simply as a conscientious objector in the war on drugs. Let me explain a bit of why I think we should legalize drugs. And the first-- I want to make two large points. First is, let's look at this war on drugs which is supposedly-- you know, the light is at the end of the tunnel, we're going to bring the troops home by Christmas. This is what Asa Hutchinson was saying, essentially, when he's saying, "Look, you know, it's been working pretty well these past 30 years. Drug use is down. If we get rid of the war on drugs, drug use will go up." So I want to talk about that. And then I want to address some of the things that Paul previewed for you. And, first and foremost, I want to make this statement. And half of you in this audience, if you are representative, are with me in your action in what economists call revealed preference.

You know, using drugs is not immoral. It is not addictive for 99 percent of people. And there's nothing wrong with it or to be ashamed about with it. Look, any program-- it's not a war on drugs, it is a war on racial, ethnic, and age-based minorities, because it's kids who get wrapped up in the war on drugs; it's not old people. Any program that has such disparate impacts as the ones that Paul was talking about should come under scrutiny regardless of its intentions and its champions. As a 2005 cost benefit analysis of the war on drugs, by the super conservative American Enterpriser Institute, which looked at the effectiveness, the conclusion by David Boyum and Peter Reuter was American drug policy has little to show by way of success for that $2.5 trillion that John mentioned at the beginning of the program.

And they claim it is surely reasonable to ask those who would maintain the status quo for some basis for believing the additional expense and suffering of putting hundreds of thousands of people a year in jail are justified. Another AEI scholar-- and AEI, you'll remember it from the Iraq and Afghanistan war, this is a think tank that has never met a war it doesn't like-- Mark Perry, an economist at AEI, has pointed out that between 1970 and 2010 annual spending on drug control has gone up 10 times, adjusted for inflation, while the addiction rate has remained flat. In other words, we have become the world's largest jailer nation without seriously getting better outcomes. The only other place where we stand for that kind of massive increase in spending with flat or declining results is public education, which is no model for any kind of program going forward. Across every conceivable front, the war on drugs is losing the battle for hearts and minds. A recent Rasmussen poll just-- you know, which is a right leaning pollster, 8 percent of people think we're winning the war on drugs.

A century of failure, because it starts with the 1914 Harrison Narcotics Act or Controlled Substances Act, has finally woken Americans up to the simple fact that prohibition exacerbates all of the social problems it is supposed to ameliorate. It doesn't make things better, it makes everything worse. Despite attempts to control-- to stem the supply of drugs, the amount and quality of drugs continues to go up while the inflation adjusted price goes down. As Washington State and Colorado were voting to legalize marijuana, Californians voted to change its mandatory sentencing laws that grew out of concern about drug crime because its prisons are choked by non-violent drug offenders while they have to let rapists and murderers out. The Rand Corporation and other think tanks have found no consistent correlation between a nation's legal regime towards drugs and use rate.

So in some countries you have lax drug laws and high use rates or low use rates. In places like America we have stern drug laws and high use rates. It's not clear what's going on; we do know in Portugal, which decriminalized all drugs, that use rates and addiction rates went down, because people got better information and they were more willing to come forward before they developed problems.

So, if you're concerned on the effects of drug use on a society, you should reject the failed policies pursued by often well-meaning, but seriously misinformed drug warriors, also known as the loyal opposition here. Well, such basic empirical scrutiny alone should convince all observers to consider an unconditional surrender in what is rightly called America's longest war. I want to make a brief case for what I call pharmacological freedom, or granting adult Americans the broadest possible rights to choose what substances we put into our bodies. And here is where I go into the meth round, because I'm running out of time. should be recognized. Pharmacological freedom should be recognized as a basic right. Over the past several decades, we have become a drug-taking culture, and we all believe in what DuPont used to advertise as "better living through chemistry." We take drugs to change our cholesterol levels, to change our work habits, to change our moods. None of this is going away, nor should it. We do all sorts of things to make ourselves look and feel better. To the extent that we might be able to use drugs that are currently arbitrarily deemed illicit, not just illegal, but illicit, by the government, the better. Ladies and gentlemen, if we don't have the right, literally, to change our mind through our personal choices, what rights do we have that are worth a damn? Now, drug legalization is not a scary prospect. It's not the radical change that its champions claim not its opponents fear. And let me-- as I'm winding down, how many of you have tried an illegal drug? Raise your hand. Anybody carrying? And if so-- okay. I'll talk to you later.

I think it was about 100 percent. For use, not carrying, okay. Because otherwise I think I see Asa hitting "911" under the table. Look, according to government statistics, fully 47 percent of Americans over the age of 12 have done so. A population that includes, at least, the last three presidents of the United States, which, granted, may constitute the strongest argument against using drugs-- but drug use is a normal phenomenon, very few people become addicts. So when we are talking about what drug legalization would look like, first off, it's all marijuana use. Vanishingly small people-- percentage of people use drugs other than marijuana. But let me just say, I'll close with-- there's not a single dimension across which pot is more dangerous than alcohol, which is pretty much all you need to know about a post- prohibition American society.

It would be a lot like today, except that you would have one or two more choices in your medicine cabinet, and about 400,000 fewer people a year would go to jail; police would be able to focus on actual criminals and Monday mornings would be a lot easier to face. So, please, think about legalizing drugs. Thank you.

### Moderator
Claim: Nick, for our radio audience, how many hands did you see up?

### Conspiracy Advocate (CA)
Claim: I think it was about 100 percent. For use, not carrying, okay. Because otherwise I think I see Asa hitting "911" under the table. Look, according to government statistics, fully 47 percent of Americans over the age of 12 have done so. A population that includes, at least, the last three presidents of the United States, which, granted, may constitute the strongest argument against using drugs-- but drug use is a normal phenomenon, very few people become addicts. So when we are talking about what drug legalization would look like, first off, it's all marijuana use. Vanishingly small people-- percentage of people use drugs other than marijuana. But let me just say, I'll close with-- there's not a single dimension across which pot is more dangerous than alcohol, which is pretty much all you need to know about a post- prohibition American society.

It would be a lot like today, except that you would have one or two more choices in your medicine cabinet, and about 400,000 fewer people a year would go to jail; police would be able to focus on actual criminals and Monday mornings would be a lot easier to face. So, please, think about legalizing drugs. Thank you.

### Moderator
Claim: Thank you, Nick Gillespie. And that's our motion, legalize drugs. And now, our final debater speaking against this motion, Theodore Dalrymple. He's a retired doctor who practiced in an inner-city hospital and a prison. He's also a prolific writer and he's a fellow at the Manhattan Institute. Ladies and gentlemen, Theodore Dalrymple.

### Scientific Advocate (SA)
Claim: Well, ladies and gentlemen, it's alleged by the proposers of this motion that the harms that arise from illicit drug taking, production, and distribution arise because of their illegality, and not because of their nature, and that, therefore, if we could only just go down to our local corner store to pick up crack, or or methamphetamine, or heroine, or LSD, et cetera, whenever we've run out, the harms would be eliminated and very much reduced. And, incidentally, Portugal has not legalized drugs, and no country has. Anyway, it is not so that the harms arise from illegality. In this country, about as many people now die annually from opioid poisoning as from homicide. Those people-- opioids are overwhelming prescription drugs obtained perfectly legally. About 15,000 a year die of these drugs. But the supply and demand of them arose suddenly in a matter of a handful of years. And it was all nice and above board.

There are now said to be 2 million addicts to these drugs, and all, as I said, created perfectly legally. And this is all within a decade, more or less a decade. Now, I suppose that our libertarian opponents would say that the problem here the control exercised over the supply by the mafia, the medical mafia, that is. And if only the drugs were really freely available on a truly open market, if only the medical mafia was sidelined, all would be well. Well, you can't expect me as a doctor really to agree with that proposition. This example shows that supply can produce a large and disastrous demand. Another example is the diversion on a massive scale of a drug called buprenorphine which is used very widely in France in the treatment of heroin addicts. And it's diverted to Georgia. That's the ex-Soviet Union republic of Georgia.

According to the Lancet, 250,000 people in that country, that is more than 1 in 20 of the population, are now addicted to the drug diverted from France, which again shows quite apart from casting doubt on how badly the addicts needed or wanted the drug in the first place, how a perfectly legal drug can create an enormous sudden and disastrous demand. Our opponents would have to allege that had buprenorphine been legally available in-- to the Georgians, none of this would have happened. In Scotland, as a whole, and in Dublin, more people are now dying of a perfectly legal drug, methadone, first developed to help the late Hermann Goering to get through the war without withdrawal symptoms from heroin, then from heroin. And this drug is used in supposed treatment of heroin addiction. So the legal drug is now killing more than the illegal drug.

So it's not true that the harms of drugs arise only from their illegality. We've seen that even if ever homicide in this country, every single one, with a result of the illicit trade in drugs, which is an absurd proposition, deaths from legally obtained opioids would equal to deaths from that trade. And that demand was created very, very quickly.

It's also alleged by the proposals that criminality is caused, more or less, by the illegality of drugs. And again, this is not so. In the prison in which I worked, I discovered that the heroin addicts who were imprisoned there and had committed-- they had committed between 50 and 200 offenses before they ever took heroin. Therefore, it will be more true to say that they were addicts because they were criminal than that they were criminal because they were addicts. This has been found elsewhere. And research shows that criminality is a better predictor of addiction than is addiction of criminality.

And this can be seen from the career of the writer William S. Burroughs, with which you might be familiar, who, as you know, shot his wife dead. He-- in my opinion, he was an even worse writer than he was a husband. But we don't have any time for literary criticism. The point is that he was fascinated by crime and committed criminal acts well before he became an addict.

In the hospital in which I worked, I once walked into the intensive care unit to find two drug dealers who had shot each other at close quarters, but with thorough British incompetence, had failed to kill one another. Well, what do you suppose that such people would be doing if they were not shooting at one another?

Would they have been doing remedial teaching, for example, or deciphering cuneiform script in the British museum? It's absurd. And criminal-- criminal gangs are not going to file for bankruptcy if drugs are legalized. They're going to change their activities. So making the importation or production, distribution, and sale of drugs would be dangerous, and it would not have the claimed benefits because the illegality of drugs is the occasion and not the cause of crime. And therefore, ladies and gentlemen, I ask you to vote against the motion.

### Moderator
Claim: Thank you, Theodore Dalrymple.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is "Legalize Drugs."Now we move on to round two. Round two is where the debaters address one another directly and take questions from me and from you in the audience. We have two teams of two arguing out this motion: "Legalize Drugs." The team arguing for the motion, Paul Butler and Nick Gillespie are arguing-- you've heard them say that basically partly it's a freedom thing that grownups have the right to put what they want in their own bodies as they do with the drug called alcohol. A lesson in history that criminalizing a drug is actually going to backfire. But beyond that, they say that the war on drugs, the embodiment of drugs as illegal costs in too many ways without a resulting drop in crime significantly, and that it disproportionately hits the African-American community in terms of people getting locked up behind bars simply for possession of drugs. The team arguing for the motion, Asa Hutchinson and Theodore Dalrymple, they're saying you cannot say that the war on drugs has failed, not when drug use among Americans has dropped 50 percent in 30 years.

They also point to the fact that drugs and crime and addiction go together. They point to prescription drugs, for example, which are legal. But their use is mired in crime and addiction. Those are some of the arguments we've heard presented. And we're going to work through some of them in more detail now. And I want to go first to the team arguing against the motion to legalize drugs. Your opponents have made the claim that the war on drugs as constructed really is a war on young black kids, that it is-- that the number of kids who are put in jail for drug possession, mere drug possession is just disproportionately high and has had terrible consequences on the community. And I want to know, does your side concede or refute that basic claim? Asa Hutchinson?

### Scientific Advocate (SA)
Claim: Well, I think it's an issue that has to continually be looked at. I think there was a disparity in penalties that impacted our African-American community when it came to crack and powder cocaine. We made a huge step forward. Congress passed a remedy to that. I think there's been some challenges with the mandatory minimums that's made-- we've made some corrections in that as well. But you look at methamphetamine, it's such a huge problem across all of the Midwest. That's predominantly a Caucasian drug. It-- and that's where the law enforcement is enforcing its efforts right now. So I don't concede the point at all. But I think we-- you look at the African-American communities, and we have significant amount in Arkansas. We have high poverty rates. We have high unemployment rates right now. We have many social problems that are impacted by the community. And it is reflected also in what happens in the drug world.

### Moderator
Claim: All right. Let's go to the other side. Paul Butler, do you want to respond to that?

### Conspiracy Advocate (CA)
Claim: Yeah. It's just not true. Asa makes it sound like blacks use drugs more than anybody else. And as anyone who's been to college or high school knows, it's simply not true. We really shouldn't be talking about legalizing drugs. We should be talking about re- legalizing them. For most of our history, drugs have been perfectly legal. You can go into a drugstore in the 1800s and buy opium. Coca-Cola started out with a cocaine derivative in it. So what made them become illegal? Nothing to do with public safety. It was all about race. First drug criminalized, opium. San Francisco, 1890, the concern was that Chinamen were using it to seduce white women, can trace it right down the line. Marijuana, Mexican field hands. It was making them lazy. With blacks, it was that Coke and ice. Negroes were running rampant in the South. So our war on drugs is about race through and through. It always has been, and it is right now.

### Moderator
Claim: But Paul, you're saying that is the sole motive for it?

### Conspiracy Advocate (CA)
Claim: I don't think that that's the only motive. But I think that when we look historically at how the drug laws have been used-- what happens to white people who use drugs?

### Moderator
Claim: Well, let me let the other side respond to

### Scientific Advocate (SA)
Claim: --methamphetamine that's predominantly a white drug that enforcement efforts across mid-America is directed at that. They're the ones that are impacted.

### Conspiracy Advocate (CA)
Claim: But why don't prisons look like America then?

### Scientific Advocate (SA)
Claim: That's not race based. That is across the board somebody who is engaged in methamphetamine production. That's who the prosecution's about.

### Conspiracy Advocate (CA)
Claim: But in--

### Scientific Advocate (SA)
Claim: I have a question for you that I would like to ask, Mr. Moderator, John, that we didn't really cover this, and that is how legalization would work. If it's legalized tomorrow, I would assume that we would be able to go down and get our methamphetamines.

### Moderator
Claim: Well, I actually do want to come to that question, because I think it's a terrific one, but I just want to have these guys respond to the point you were just making on the race issue--

### Conspiracy Advocate (CA)
Claim: Well, let me--

### Moderator
Claim: --and the methamphetamine

### Conspiracy Advocate (CA)
Claim: You know, I side with Paul in a sense that the origins of drug prohibition, and many of the continuum policies are inextricably and I think incontrovertibly linked to race or other out group stigma. LSD became associated with young people in the '60s. It was bad. There was legal effectivelyuntil 1967--

### Moderator
Claim: But weren't young people considered pretty cool in the '60s?

### Conspiracy Advocate (CA)
Claim: Not by old people, you know? And the same thing happened with ecstasy. How many of you-- I mean, if you're over 50, you had the opportunity to use ecstasy legally until 1986. It was then demonized as a youth drug, first, one that made you antisocial, then one that made you prosocial and you'd go out to a rave and have sex all night or dehydrate. But more importantly-- you know, well, hydration is very important, you know. It's the skin. More importantly, we need to dial back the hysteria. So, for instance, I just want to focus on one point that was being--

### Moderator
Claim: Nick-- Asa--

### Conspiracy Advocate (CA)
Claim: --wait, just--

### Moderator
Claim: No, no--

### Conspiracy Advocate (CA)
Claim: --methamphetamine, one-tenth of 1 percent of people in America report having used it in the past 30 days. Is the drug war edifice, all of the costs in money and in monetary and human terms, is it worth trying to stop that one-tenth of 1 percent of Americans--

### Moderator
Claim: Theodore Dalrymple, arguing against the motion.

### Scientific Advocate (SA)
Claim: I just want to make a small logical point. We are not actually discussing whether the laws are correctly applied but whether there should be any laws. And so actually it's not-- I mean, I know that it's very important for people in America, the way that they are applied, but the fact is that we're debating whether there should be any laws at all, not whether we should have present laws.

### Moderator
Claim: All right. Let's take Asa's question to you, Nick Gillespie. Asa Huntchinson, you were asking what does this new world look like where drugs are legalized?

### Scientific Advocate (SA)
Claim: May I frame it?

### Moderator
Claim: Sure.

### Scientific Advocate (SA)
Claim: So in terms of-- take heroin or methamphetamine, I would presume if it's legalized the state would be granting licenses so they can regulate the purity and the quality of the heroin and that the methamphetamine is quality stuff.

So if you regulate it, and you have to regulate it to tax it, so I am curious, one, is this not another government regime that's being created with a libertarian argument that you're creating? So you're creating more government by your libertarian approach, wanting to legalize drugs because they're going to have to regulate it and tax it-- so how's that going to work? I--

### Moderator
Claim: All right, Nick Gillespie.

### Conspiracy Advocate (CA)
Claim: --respectfully submit that I have never taken a drug strong enough for that argument to be convincing. But in Colorado, you know, the initiative that was passed for marijuana legalization was basically, I mean, it was out there, and it's a similar thing in Washington State, to treat marijuana like wine, beer, and alcohol. So it's not a question-- and, Theodore, I think your opposition is--

### Scientific Advocate (SA)
Claim: So it's licensed by the state.

### Conspiracy Advocate (CA)
Claim: --is a false-- yeah, well, it could be. That remains to be seen actually because each-- Washington State has about a year to figure out the technical implementation and Colorado has about six months, but it's not a choice between anarchy and, I'll ratchet it down, regulatory system, but there will be laws. There will be customs. There will be traditions. There will be advertising. There will be information available. And I-- the real question is about legalizing drugs. Do you consider alcohol to be legal? Let's have a regime that is very similar to that for currently illegal substances.

### Moderator
Claim: Let me step in and ask Paul Butler something. Paul, you made-- drew a distinction between treating addiction and punishing addiction, which suggests that perhaps unlike your partner you're talking about addiction as a problem that needs to be addressed by society. Do you split with each other on that? Do you think that it's this-- in other words, are you saying drug use is a problem?

### Conspiracy Advocate (CA)
Claim: Well, I think addiction is a medical issue, and I think Nick and I agree that only a small percentage of people who use drugs become addicted to it. So most people are able to use marijuana and other drugs recreationally and go to work the next day. Most people are also able to do that with alcohol. For the percentage of people who have substance abuse problems with it, we know, the good doctor knows, that's a health issue. Police, prosecutors, they make lousy doctors. Jailers make even worse doctors. So the way to treat that problem, the way to heal those people is to use what we know about, and not what we know about locking people up, because what we know about locking people up is, it doesn't work.

### Moderator
Claim: Dr. Dalrymple.

### Scientific Advocate (SA)
Claim: Well, I actually don't agree that addiction is a-- it's fundamentally a medical problem.

### Conspiracy Advocate (CA)
Claim: You think it's a moral problem?

### Scientific Advocate (SA)
Claim: I do, yes.

### Conspiracy Advocate (CA)
Claim: Wow.

### Scientific Advocate (SA)
Claim: Well, a moral problem and a social problem and psychological problem and a spiritual problem. It's only to a very small extent a medical problem. I mean, there are medical consequences, of course, but this is not what is important. For example, everything-- I think that everything you think about heroin addiction is actually wrong. For example, you probably think that withdrawal effects from heroin are very severe, they're not, they're trivial. And the overwhelming evidence is that, by far, the most suffering from withdrawal effects is psychologically induced; it's anticipatory anxiety, it isn't the-- and there's good experimental evidence about this. You think that it’s highly addictive, it isn't. Most heroin addicts go at it for about a year before they're ever actually addicted. You think that there's a connection-- I've described the supposed connection between crime and addiction.

The idea is that an addict goes out to obtain money in order for his addiction; there's no correlation in the amount of crime he commits and the amount of drugs he takes. And, actually, you find that they're all acquisitive criminals before they ever take heroin.

### Moderator
Claim: Let me ask your partner, Asa Hutchinson, a little bit of-- moving the discussion a little bit in a slightly more, perhaps, philosophical direction. Maybe that's the wrong word. But we've heard a few references to alcohol and to prohibition and to the notion that, I think, nobody is disputing that alcohol is a drug on the panel, and the nation did try, amended the Constitution, to outlaw alcohol consumption and decided it was a mistake. So, tonight everybody in the room can go afterwards and enjoy a glass of wine or a beer. What's the difference between alcohol and the prescribed drugs?

### Scientific Advocate (SA)
Claim: They're all problematic drugs subject to abuse. In our democracy, we make decisions on which ones to legalize and which ones not to. Those are decisions that are made. The debate question tonight, though, of course, is legalizing all drugs. And, again, I go back to the question, which relates to ending prohibition in the late 1920s. You ended prohibition on alcohol, use went up, availability went up, regulation went up, taxation went up, and you compare that to legalizing methamphetamine. You're going to have an opportunity for the state to regulate methamphetamine producers, you're going to have it available, because it's going to be legal, and it's going to be taxed, and so, the price will be set by the market place, which is regulated and taxed. And so, the question is, "Will you end crime? Will you end the cartels? Will you end the black market because you regulate methamphetamine?" Of course not.

There's going to be those that don't want to pay the taxes, just like they don't want to pay the taxes on cigarettes, and there's going to be a black market there, and you're going to have enforcement efforts, you're going to have criminals out there that are still bypassing the law, and so all of your hope of ending the DEA or ending law enforcement will not happen with legalization.

### Moderator
Claim: Nick Gillespie.

### Conspiracy Advocate (CA)
Claim: I think there's a major, kind of, conceptual error when we're talking about crime here. When-- we know that Mexican drug cartels are killing people on both sides of the border. When's the last time you heard about a Dos Equis shoot out? Where a beer distributor crossing the border--

### Scientific Advocate (SA)
Claim: Hundreds of times murders committed under the influence of alcohol.

### Conspiracy Advocate (CA)
Claim: The last time you heard about that sort of thing was during alcohol prohibition. And so, it's not that--

### Scientific Advocate (SA)
Claim: Are you going to have a black market for methamphetamine?

### Conspiracy Advocate (CA)
Claim: Sure. You know what? We already do. What would happen is, if we had a legal one, the other social harms would be reduced. I'm not a utopian, what I do believe is that not only would responsible individuals have a broader palate of things to make their life better, but also, many bad things would diminish. When we're talking addiction or substance abuse-- you know, I don't drink anymore, because I was a bad drinker; I tried my hardest to drink and drink and drink, I gave it up. If I had to admit that I was a criminal as well as having a substance abuse problem, I doubt that I would've gotten there quite as fast as I did, which was long enough.

### Scientific Advocate (SA)
Claim: A couple of small points. The murder rate in Mexico is now between a third and quarter of what it was in the 1940s. That might surprise you, but it is a fact. When we look at the murder rate during prohibition, it is, of course, perfectly true that it went up during prohibition. It went up by 35 percent. And it came down after prohibition was ended.

But in the same period before prohibition, the murder rate went up by 85 percent. And in six years between 1900 and 1906, the murder rates in this country went up by 325 percent. So I think that the relationship between violent crime and prohibition is probably not nearly as close as people imagine and that there was a secular trend in which it went up anyway. And you could even make the case that it slowed the rise in the murder rate. I wouldn't make that case. But it's not straight-- it's not as straight forward-- the world did not begin in 1919. And the murder rate went up both absolutely and relatively more before-- in the years before prohibition than during prohibition. And incidentally, Scarface got his scar before prohibition. And he didn't get it from plastic surgery.

### Conspiracy Advocate (CA)
Claim: So the reason that most people don't smoke isn't because smoking tobacco is a crime. It's because we know it's not good for us. That's the same reason why even a regime of legalization, the vast majority of us are not going to use heroin or meth. But it's public health that will be responsible-- the most responsible way for treating people who abuse those substances.

### Moderator
Claim: Paul, can I interrupt? I'm going to ask a question from something that Asa Hutchinson, your opponent said earlier, in which he reported that in the last 30 years, the use of drugs by Americans has declined 50 percent. And he sees that correlation being directly related to causation, that the drug war actually means that fewer men's use drugs. Are you impressed by that statistic?

### Conspiracy Advocate (CA)
Claim: I'm not, in part because we have to do our cost-benefit analysis. We have to ask if that's true, is it worth it? The costs have been 2.5 million people in prison, the costs have been one in three young black men with a criminal case, more African-American young men in prison than in college. The cost has been billions of dollars that we can't afford, money away from our schools, away from our healthcare system, going straight to prison. So especially if we understand that those are people who are locked up for using drugs. I don't have a problem. If you steal, if you rob, then yes, you should be punished. But when we're thinking about people who are locked up, 500,000 people, those are nonviolent drug offenders. And again, entirely selective. They're African-American and Latino two-thirds of them. There're some states where 80 to 90 percent of the people in prison for drug crimes are black. And we know that's not the reality of who's using drugs. That's selective law enforcement.

### Moderator
Claim: Asa Hutchinson, would you like to respond?

### Scientific Advocate (SA)
Claim: Well, first, to go along with my partner, that the issue is not our enforcement policies currently, but it's whether we're going to legalize all drugs. That's the issue before us.

### Conspiracy Advocate (CA)
Claim: How can you separate those?

### Scientific Advocate (SA)
Claim: Well, I think you can-- that's not the debate topic, how you separate those. But in terms-- if you look at Oxycontin, it's a white abused drug. If you look at LSD, it's a white abused drug. If you look at cocaine, it's-- you know, crack cocaine has minorities. You've got powder cocaine, that's white abused. You've got heroin that's across the board. You've got GHB, you've got ecstasy that was mentioned. So I just don't see the racial component to it. Obviously, I think as head of the-- former head of the DEA, we looked at enforcement policy. You've got to be careful.

You don't want to-- the south side of Chicago put all your enforcement resources on the crack distributor when you're ignoring the white guy coming from the suburb. That's wrong enforcement policies. You've got to balance those. But those are remedies within the current system. Legalizing it dramatizes the problem. You still have education issues, as you pointed out, where you have to spend dollars on education, probably even more because you've got more availability out there. You're going to have to spend money on the regulatory side. So all of those issues that are concerned about in society will only increase if you increase legalization.

### Conspiracy Advocate (CA)
Claim: Can I ask--

### Moderator
Claim: Nick Gillespie-- I'm going to let you speak, one second. After Nick speaks, I'd like to start coming to you in the audience for questions. So just remember, raise your hand. I have a little bit of difficulty seeing people who are towards the back and out of the bright lights, so you might want to come forward. If you raise your hand, I'll call on you, and I mic will come to you, and you can ask a question. Nick Gillespie.

### Conspiracy Advocate (CA)
Claim: I mean, I'd like too defer to the experience and the expertise of the opposition to legalization. But I'm left wondering what world we're talking about here. So they're talking about how bad Oxycontin is. Oxycontin is a prescription drug that is already legal and regulated. I don't see how that really has a lot to do with talking about a legalization debate. It's already legal. And here are the stats that are important. The government runs something called the National Survey on Drug Use and Health. And basically, 30-- in the past month use, they ask people, have you used this drug in the past 30 days, which is kind of a proxy for, you know, a regular user or a casual user. About 7 percent of people over the ages of 12-- 12-year-olds by the way, you know almost a hundred percent, they say yes to everything. But about 7 percent of Americans say that they've used pot in the past month. That by far-- by a factor of three or more, that's the most widely used illegal drug, or legal drug that's used illegally.

The next one is opioids, the prescription drugs that Theodore was talking about, which comes in at 2.7 percent. When you're talking about things like meth and heroin, one- tenth of one percent. Hallucinogens covering a wide range of things, five-tenths of one percent. Crack or cocaine, including crack, six-tenths of one percent. These are nonfactors. And as Paul was suggesting, if they're made legal, who out here is going to be like, finally, heroin is legal, you know? You know, let's go. Let's try it. No. Okay, that's not going to happen. It's about pot. And we all know that pot is not a dangerous drug, that pot is not a gateway anymore than mother's milk, you know, is the ultimate gateway drug because everybody who uses heroin started out with mother's milk. But it's about pot, and we need to focus on that.

### Moderator
Claim: I actually wanted to--

### Conspiracy Advocate (CA)
Claim: --it's not an issue then--

### Moderator
Claim: I want to hear the-- I want to hear your opponents respond to the notion of whether drug use overall would soar if it were legalized.

### Scientific Advocate (SA)
Claim: Well, no one can say with any absolute certainty.

### Moderator
Claim: Well, I know, but--

### Scientific Advocate (SA)
Claim: But all one can say-- I don't know what to say to someone who tells me that the deaths of 15,000 people a year is not really a problem--

### Conspiracy Advocate (CA)
Claim: --the incarceration of 500,000 people, you know, that's about how--

### Moderator
Claim: Let him make his point and--

### Scientific Advocate (SA)
Claim: Hang on. And 2 million people being addicted to it. So it is actually an important point that if you make something readily available, the use of it can increase catastrophically. Now, I can't, of course, say, that I know for a fact if methamphetamine were just available like everything else, or crack were available, you just went down and got it, of course not everybody would take it.

But I have an experience. And this was an experience working in Africa with some expatriates. And for various reasons I won't go into, alcohol became-- virtually free of charge. And the result was absolutely catastrophic. The increase in the consumption was enormous. And, of course, not-- in fact, the majority of people didn't take it to extremes. But 20 percent of people did.

### Moderator
Claim: Asa, your partner wants to join in on this point, I think.

### Scientific Advocate (SA)
Claim: I agree. I think logic tells you usage goes up. But recent information, Alaska, through a court case, decriminalized marijuana in the 70s. Usage went up. Parents were concerned, and they voted to recriminallize it in the '90s. That's a historic experience among our states. And so usage did go up, and parents recognized that and reversed the trend in Alaska.

This debate is not about marijuana. It is drugs, plural. And to be consistent in your philosophy of libertarianism, which my colleagues are consistent, they recognize it doesn't do any good to legalize one. You have to legalize all. And if you-- because that's the only way you're going to change the environment of enforcement, to change the environment of police and so on. And so the debate tonight is about legalizing all drugs.

### Moderator
Claim: All right. Let's go to some questions from the audience. I want to remind you that we are now in the question-and-answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two against two, who are arguing it out over this motion: “Legalize drugs," and, ma'am, right in the center, there. If you look to your right, there's a microphone coming down. If you could just stand up and tell us your name, thanks.

### Moderator
Claim: Hi.

### Moderator
Claim: Hi.

### Moderator
Claim: Patsy Cohn Paul Butler mentioned smoking, and I have a question, the laws in New York have gotten so much more stringent against smoking. You can't smoke in the parks, you certainly cannot smoke in a restaurant or a bar, and taxes on cigarettes have gone up significantly. So your argument would be that none of that affects people lowering the smoking rate, that, in fact, it's only health issues, and I would wonder what the statistics are on that.

### Moderator
Claim: All right, I'm not going to hold them to knowing the statistics, because they might not know, and it would just be embarrassing. But let's take on your larger principle.

### Conspiracy Advocate (CA)
Claim: So--

### Moderator
Claim: Paul Butler.

### Conspiracy Advocate (CA)
Claim: --I am concerned about this nanny state that the government is creating where we can't have-- it started with certain drugs, and it seems to be going down the road to trans fats, right, to smoking in parks, smoking tobacco in parks, and even big gulp cans of soda.

So if we buy this idea that people aren't responsible enough to make intelligent decisions for themselves, which my opponents don't seem to think people are, we ought to be concerned about these draconian laws, and we ought to especially be concerned about who they're going to be applied against. I guarantee you that white people-- very few white people in New York are going to be arrested for smoking in parks. It's going to be African-Americans and Latinos. That's the reality. We can't divorce the reality from this rhetoric.

### Moderator
Claim: Response from the other side.

### Scientific Advocate (SA)
Claim: Well, I think the--

### Moderator
Claim: Theodore Dalrymple.

### Scientific Advocate (SA)
Claim: --fact is that people stopped smoking in bars because there was a law against it and they did it on a certain day. They didn't suddenly realize that their health would be impaired by it. And interestingly, this happened throughout the world. My wife, who's French, said, "The French will never obey this law," but they obeyed it like lambs. And so-- and the reason, of course, is that smoking doesn't have the antinomian cultural meaning that taking drugs has, and that's why smokers will obey the law and others won't.

### Moderator
Claim: Sir.

### Moderator
Claim: I'd like to understand a bit--

### Moderator
Claim: Would you mind standing up?

### Moderator
Claim: Sorry.

### Moderator
Claim: And tell us your name.

### Moderator
Claim: My name is Bob Wyman. I'd like to understand a bit more, Mr. Hutchinson, the comments you made about that we can't legalize one without essentially legalizing them all, that it's not useful. But historically we have legalized one very major one, and that is alcohol. And then we have a-- sort of a regulation as well with cigarettes. And then there are the various legal drugs that doctors can give you. We've already gone down that path, and we've seen that, for instance, the legalization of alcohol didn't cause a tremendous explosion in heroin use. Why wouldn't legalizing just one more, say, going with heroin, that's a-- not heroin, but-- but going with marijuana-- got to pick the right one. Why wouldn't going one step further and thus removing the tremendous amount of people who are in jail for that and all the money that's going to the criminals why wouldn't that be used--

### Moderator
Claim: Yeah, Asa Hutchinson. Thank you.

### Scientific Advocate (SA)
Claim: Very good question, and I did not explain it well, so I'm glad you asked that. And you're right. We're a democracy so you could-- society could choose to legalize heroin if you wish or marijuana and pick one of them. But my argument would be generally people say, "Well, one of the reason we need to legalize, because you got to put the cartels out of business. And you've got to put the criminal elements out of business." Well, they're smart business folks, and they have diversified. So if you legalize marijuana, they're going to trade in cocaine, methamphetamine, and they will market those. And so if-- unless you legalize everything, the cartels are just happy as a lark. And even if you legalized everything, you're probably still going to have the black market they will deal in although it'll be tougher.

But the second point is simply that the debate topic is not just about marijuana, it is broad based legalization because-- well, that's the debate topic. And that's what we're trying to stick to.

### Moderator
Claim: Asa, if somebody wants to use any of the drugs that are currently illegal, aside from the fact that they're breaking the law, just in terms of the little bubble of their own life, is that anybody's business but their own? Is-- in other words, where is the social dimension to that use?

### Scientific Advocate (SA)
Claim: Well, the social dimension is-- and I hate to keep speaking of methamphetamine, but that's a real problem where I'm from-- and methamphetamine, you are manufacturing it, you've got children around, they're taking the methamphetamine and they're abandoning their kids for weeks on end. And so it's a child welfare issue that is extraordinarily harmful, endangerment of those.

It is environmentally unsafe. Now, you can say, "Well, if we get our nanny state involved where they regulate the-- and license the methamphetamine produces maybe you'll eliminate some of that." But you're still going to have the lack of productivity in the workplace through drug use, and people not showing up because of they aren’t having a good Monday morning, as my colleague was pointing out.

### Conspiracy Advocate (CA)
Claim: In your world, for somebody to get help, they have to admit that they're a criminal.

### Scientific Advocate (SA)
Claim: No, you can go get treatment any time you want to.

### Conspiracy Advocate (CA)
Claim: And admit that you've broken the law?

### Scientific Advocate (SA)
Claim: Well, of course, you know that if somebody has a problem with an addiction and they go into a clinic, they're not going to get arrested for it, they're going to get help, and they're going to get treatment. And that's the goal in the workplace too. If you do testing and you find a worker who has got an abuse problem, they're not sending them to the police, they're sending them to treatment. And that's the objective of the employers, and that's working well in the workplace. And all of that effort would be abandoned if you went through legalization. All of the sudden, you-- why would you drug test anybody?

### Conspiracy Advocate (CA)
Claim: That's a good question. Why do we now? Because most people who get drug tested, you get drug tested when you're applying for a job and that's it. It's a joke. It's a hurdle to weed out people who-- you know, on other grounds. The people--

### Scientific Advocate (SA)
Claim: They have random drug testing; they test pilots. And I'm glad for the testing of the pilots that fly our airplanes.

### Conspiracy Advocate (CA)
Claim: Of course. And what airline, what airline or trucking company, or whatever, is not going to regularly test people, because it puts them at enormous insurance risk? These things are handled and-- to talk about another market mechanism, we don't need-- and this is the libertarian in me speaking, we don't need the government to test and testify to the purity of methamphetamine, we will have fair trade methamphetamine-- you know, private certification agencies, just like with coffee or biodynamic wine or organic foods-- will spontaneously spring into being. And, just to follow up on one point, the reason why I'm stressing marijuana, it goes back to some things that Paul is saying, and I don't think that the other side is fully acknowledging, which is that we live in a world where school kids tell everybody who asks them, "You know, you can get drugs easier than you can get beer, any kind of drug you want." The use ratios are pot, very much--much less, prescription drugs, and these tiny vanishing statistical errors of things like heroin. Even if you double or triple the heroin use, it goes from-- one-tenth of 1 percent to three- tenths of 1 percent. I don't think that's a reason to hold everyone else hostage who can act responsibly.

### Moderator
Claim: I was going to go to another question, but do you want to dispute the numbers?

### Scientific Advocate (SA)
Claim: Well, in terms of the numbers, if you're looking at marijuana use in the schools, and the availability of it, I just come back to the fundamental question. If you legalize it, two things happen: one, the kids say, "If it's legal for my folks, how can it be harmful?" The government says it's legal now; that's a signal that it's okay and usage goes up because of that--

### Conspiracy Advocate (CA)
Claim: Nobody thinks that about tobacco. Nobody thinks tobacco is okay because it's legal.

### Conspiracy Advocate (CA)
Claim: Hate speech is legal, kids don't say, "Oh, now I can engage in hate speech." I think, you know, I, again, you know--

### Moderator
Claim: Wait, wait. Asa was-- were you in mid-flow? And then I'll come back to that, because –

### Scientific Advocate (SA)
Claim: No, I'm happy to take another question.

### Conspiracy Advocate (CA)
Claim: No, I'm just saying that, you know, fundamentally, look-- we don't live in a democracy, by the way; we live in a limited republican form of government which respects the rights of the minority. But I don't think anybody in America mistakes the idea that something is allowed with something being good. And if they are, then we really need to change the public education system because the kids are getting the wrong message.

### Moderator
Claim: But the point that Asa made that if kids see that they're parents are smoking dope or--

### Conspiracy Advocate (CA)
Claim: Or drinking--

### Moderator
Claim: All right, but make it drinking. You don't think that there's a lesson

### Conspiracy Advocate (CA)
Claim: No, actually, what I would suggest is that when you see your parents and other adults using a drug responsibly, and we need to keep coming back to this point, drug use does not equal drug abuse. Those are two very separate things, and we can deal with them. But when you see your parents having a glass of wine with dinner and acting responsibly around an intoxicant, you learn a very strong lesson there that is going to be much more beneficial to you than if you grow up in a teetotaler house and then you have the unfortunate experience of going to Yale and Harvard like Paul here.

### Scientific Advocate (SA)
Claim: I don't think kids are going to be seeing parents using heroin or methamphetamine or cocaine responsibly. I don't know if kids see the parents use marijuana in the home responsibly, does that increase usage, decrease usage? All I can say, as a parent, I hate to take that experiment.

### Moderator
Claim: Drug use does not equal drug abuse, statement of principle from the other side, from your opponents. So the side arguing against that, what do you make of that? Theodore Dalrymple.

### Scientific Advocate (SA)
Claim: Well, that may be perfectly true. But the fact is that it's also true that most drunk drivers get home perfectly safely. 99 percent of drunk-- I know, I'm afraid to say, because I've done it myself.

### Conspiracy Advocate (CA)
Claim: Have you ever drunk debated, though?

### Scientific Advocate (SA)
Claim: Yeah, well, you're making an assumption that I'm not now. But--

So, of course, it's perfectly true. But the argument about cigarettes, for example, one hears it all the time, most people who smoke cigarettes don't actually suffer from lung cancer.

I mean, I've heard-- I don't know how many times I've heard it, and it's perfectly true, that most people who smoke cigarettes don't die of lung cancer. But the fact is that most people who get lung cancer, and it's very nasty, smoke. And the fact is, again, that I don't think there's any real benefit to be taken from these drugs. And to equate the freedom to take drugs with the freedom of expression seems to me to trivialize what the freedom of expression actually is.

### Moderator
Claim: Ma'am, right against the wall, where the wall turns green. If you could state your name, please.

### Moderator
Claim: Hi. Diana Jiminez. I come from Mexico. And in the past six years, we've had 60,000 people dead in drug-related violence. The murder rate has gone down. But in drug- related violence, we've had, you know-- it's just been atrocious. My question is, legalizing drugs would do better for cartel violence or worse?

### Moderator
Claim: And your question is to either side?

### Moderator
Claim: Yeah, yeah. I want--

### Moderator
Claim: All right. Let's take it to this side. And I want to-- I'll go to Paul Butler, since that used to be your job, to a degree.

### Conspiracy Advocate (CA)
Claim: True. And if we listen to the leaders of the Latin American countries, they're calling for more responsible drug policies, including for us to consider legalization, because they know that the violence is sparked by the illegal market which is sparked by the enormous demand for drugs from the United States. So if we get rid of that illegal market, including by having drugs regulated like we regulate tobacco and alcohol now, we'll get rid of the violence. Again, that's exactly what happened during prohibition. Al Capone wasn't nothing but a drive-by shooter. And again, when we got rid of that illegal market, we got rid of the violence.

### Scientific Advocate (SA)
Claim: Well, to that point, the answer is absolutely no. Did the mafia end in New York City at the conclusion of prohibition? Rudy Giuliani, the former U.S. attorney, former mayor of New York, made himself famous by prosecuting the mob and the mafia. They existed long after the ending of prohibition. And to the lady's question about Mexico, do you think the legalization of drugs will put the cartel out of business? It might make them adjust, but there is alien smuggling which they're engaged in now. There's other activities. But you look at the cost to the United States, I think that would just be enormous. I met with president Vicente Fox whenever he was president. He was concerned not only about the cartels. He was concerned about the demand-- growing demand problem and usage in Mexico of his people. And that was a concern there. And so it's not just about the cartel. It's about drug use. I don't know of any Latin American country that wants to legalize all of the drugs, heroin, cocaine, down the road.

### Moderator
Claim: Can I-- Nick Gillespie, and then I'll come to Theodore.

### Conspiracy Advocate (CA)
Claim: Yeah, I mean, I just wanted to say very quickly, the mob moved into other illegal pursuits, prostitution, non-casino gambling, things like that. And to the extent that the cartels in Mexico might move into human trafficking, the fix there is to legalize immigration, not to try and wipe out cartels. That's what I'm saying. And the-- you know, the-- or the generational shift here might be the Kennedy clan. And I say this as a half Italian, half Irish, so I've got, you know, a foot in each camp here.

### Moderator
Claim: You're covered, yeah.

### Conspiracy Advocate (CA)
Claim: But the Kennedys went from having connections in the liquor business within a generation or two, to, you know, moving into politics.

### Moderator
Claim: Harvard and Yale again.

### Conspiracy Advocate (CA)
Claim: Not a good-- not a good progression. But the fact is, when you legalize broad swaths of economic activity where there is a supply and a demand, peace reigns and prosperity follows.

### Moderator
Claim: Theodore Dalrymple.

### Scientific Advocate (SA)
Claim: Well, I think the idea that Mexico, or, for example, Colombia would be a peaceful society if it were not for drugs is absolutely ludicrous. If one just takes the example of Colombia, there were two episodes in the 20th century in which the equivalent pro rata of the population of more than a million people were killed. That's twice. And the current civil war in Colombia started in 1964. I remember in 1979, really before the drug business, I remember looking-- looking in the South American handbook which was the kind of book that everyone used in-- who traveled in South America and it said of Bogota-- and I'm quoting from memory, so it might not be quite right. It said, "Try to look poor. Do not carry anything. Do not wear any jewelry. And if you can see without them, do not wear glasses."Now, let's say you wouldn't have that in a guide book to Switzerland. I mean, more likely, you'd have, "Do not flush the lavatory after 10:00 because you'll be arrested for disturbing the peace." And that's not a joke, incidentally. So the idea that these are-- I mean, I've seen another thing that--

### Moderator
Claim: Well, I think that you've made that point. Let me go to the gentleman in the corner. And mic will come to you. You know, if you wouldn't mind, you're in a purple light. And if you took a step three seats down you'll be in a-- in a non-purple light.

You just want to look good on television. Come out a little bit farther if you don't mind.

Could you-- step into the light, sir.

### Moderator
Claim: Take your shirt off--

### Moderator
Claim: There you go.

### Moderator
Claim: I've been waiting for you to say that.

### Moderator
Claim: So my sister is married to a--

### Moderator
Claim: What's your name? What's your name? You probably don't want to say now.

### Moderator
Claim: Sorry?

### Moderator
Claim: Justin Rohrlich

### Moderator
Claim: Okay.

### Moderator
Claim: My sister married a Dutch guy. And they were-- their wedding was in Amsterdam, about seven or eight years ago. And none of the Dutch people at the wedding could care less about pot. All the Americans there, including myself, the first thing we did was go to the coffee shops and smoke a bunch of pot. None of the people that lived there were interested at all because it seemed like, you know, they took the excitement out of it. It's been available--

### Moderator
Claim: So turn this into a question. Turn this into a question.

### Moderator
Claim: So it's been available to them their whole lives, and it seems to have taken some of the - - some of the thrill away from it. Do you think that that would hold true here?

### Moderator
Claim: Would pot stop being cool--

### Moderator
Claim: Yeah, you know, you take some of the coolness-- you know, if your parents are smoking pot--

### Moderator
Claim: Let me-- I'm going to take the question first to Asa Hutchinson. Would it take the thrill away and the attraction away?

### Scientific Advocate (SA)
Claim: Well, perhaps.

### Moderator
Claim: To legalize it, yeah.

### Scientific Advocate (SA)
Claim: I mean, sure, if becomes very common. But let's look more carefully. And I've been to the Netherlands, and I've been to the coffee houses. And-- but you know, you--

### Moderator
Claim: Where you drank coffee.

### Scientific Advocate (SA)
Claim: You've got to-- you've got to investigate carefully.

But the Dutch governments had second thoughts after years of expanding the cannabis cafes. I think they realized that it became a tourist Mecca for that purpose, and what you just described. And so the number of Dutch marijuana coffee houses dropped from almost 1,200 in 1997 to 782. And so they decreased maybe-- I don't think the-- I think the Dutch government-- and in fact many of them-- 73 percent of the Dutch towns do not allow cannabis cafes.

And so I think it was a mistake, the path that they went down. They recognized it. They've retreated from that both in terms of their reputation in the commercial enterprise but also I just think it's the direction that the Dutch towns did not want to go down. So I hope we can learn something from that. You talk about availability because it was available. I was actually going through a Dutch town with the chief of police, and I had people pulling on my sleeves-- I'm with the chief of police. I'm head of the DEA. And they're pulling on my sleeve saying, "Do you want some Ecstasy?" and I'm saying, "Hey, don't you know who I am, who I'm with?" And it doesn't make any difference, because it was available and was legal.

### Moderator
Claim: Paul Butler come in.

### Conspiracy Advocate (CA)
Claim: And so there are fewer coffeehouses because there's less of a demand. It turned out in Amsterdam, when they made smoking pot legal, fewer kids wanted to do it. It wasn't as cool. So, respectfully, Dr. Theodore and Asa, if you really want kids to stop smoking pot, you should go on TV yourselves and fire up a big juicy blunt.

### Moderator
Claim: We're being live streamed, and we have a question that's come in to us from Washington State via Facebook. Tom Glassman writes, "I’m someone who lives in Washington State." He asks, "Is the legalization of a drug, for example, marijuana, something that should be left to the states to decide?" Who would like to take that question on? Nick Gillespie.

### Conspiracy Advocate (CA)
Claim: Yeah, you know, this is a fascinating political question that the Obama Administration in particular is going to have to deal with because traditionally the democrats are at least over the past 30 or 40 years and Barack Obama and actually presidents in general assert the primacy of federal law over every matter no matter what, whether it's funding, or regulations, or whatnot.

I would actually-- I guess it's the second best answer to say that drug legalization should be left to localities or to states as opposed to a one size fits all federal solution. By the same token, I do actually think that pharmacological freedom, which includes what a friend of mine calls culinary freedom-- I mean, the right to ingest what you want is pretty fundamental and should probably be respected across the board rather than parceled out, but as a second best option, let's let the states and localities be laboratories of democracy--

### Moderator
Claim: Asa Hutchinson.

### Conspiracy Advocate (CA)
Claim: --and what happens to the experiments?

### Moderator
Claim: Asa Hutchinson.

### Scientific Advocate (SA)
Claim: No. Well, we're--

### Moderator
Claim: Addressing even the Washington State situation.

### Scientific Advocate (SA)
Claim: Whenever Arizona experimented and thought they ought to be engaged in enforcement of our immigration laws, President Obama's administration filed suit against Arizona, asserting the supremacy clause.

And so if you-- believing there should be a national standard for such an issue as immigration, I think they're going to have a difficult time not making the same argument in reference to the state's choices on marijuana or other drugs. So it's difficult in our society for states to make choices on that particular issue whenever you have an overriding federal law. I think there's going to be a lawsuit, and I think it'll be resolved in the courts.

### Moderator
Claim: Think we have time for one more question.

### Moderator
Claim: Hi, my name Tatiana Martushev. I'm in the health care profession. And I mostly deal with pain management. And I have a lot of clients who are getting treatment for cancer, and they actually tell me that their doctors say to them, "Listen, the best thing for you is actually just go buy some pot because it's actually much more effective in managing the pain, it's cheaper than the drugs, it's less destructive on their physical bodies than the medically prescribed drugs, and--"

### Moderator
Claim: And what is your-- what do you think of--

### Moderator
Claim: So my question is--

### Moderator
Claim: But actually what do you think of that answer?

### Moderator
Claim: Well, when you see people in that kind of pain, you really don't want them to be in that kind of pain, and if the drugs that are legally available aren't really helping them to eat, to manage their pain, et cetera, why not give them something that is readily available to them if they just walk down the street--

### Moderator
Claim: Okay.

### Moderator
Claim: --and pay someone?

### Moderator
Claim: Okay. Take the side arguing against legalization, Asa Hutchinson.

### Scientific Advocate (SA)
Claim: Well, I mean, any time a doctor or the American Medical Society says a patient needs something for pain management, I'll be the first one to sign up for it, I mean, in terms of supporting that position. Doctors in the medical profession should determine what's appropriate pain management and care.

At this point, the AMA has not approved that. Maybe they will someday, but they have not done that at this point. And so that's the answer. I don't think that relates to the overall debate question, but it's certainly an appropriate question to ask.

### Moderator
Claim: Other side, response?

### Conspiracy Advocate (CA)
Claim: I had a--

### Moderator
Claim: Paul Butler.

### Conspiracy Advocate (CA)
Claim: --a member of my family go through the same experience. He was dying of lung cancer, and his doctor told him that marijuana would be the best thing. He didn't live in a state where medical marijuana was available, and so our family faced the difficult choice of becoming lawbreakers, risking arrest and prosecution, or watching my relative live and die in pain.

### Moderator
Claim: Asa Hutchinson, just take 20 seconds to do one thing. You just said that you don't feel that that question relates to the motion, and you've said that a few times on a few questions. Why not? Why not, for example, the question of medical marijuana? Marijuana use for medical uses, which would require-- which would involve legalization of that particular drug. Why does that not relate to the motion?

### Scientific Advocate (SA)
Claim: Well, medical marijuana is a separate and distinct issue. Some states put medical marijuana on the ballot, which takes a doctor's prescription or authorization, and so that's not a legalization issue, it is a physician issue and pain management and doctor's care, and giving doctors the ability to prescribe marijuana if they believe that's beneficial, so it's really a separate medical issue versus the legalization across the board. You can decide they need it for pain management, that doesn't need mean that everybody should have marijuana.

### Moderator
Claim: And the motion does imply all drugs, we're not-- I just want to clarify.

### Conspiracy Advocate (CA)
Claim: Can I just ask, quickly, though, because these are lengths, I think, in some significant ways. But when you were the head of the DEA, did you support the federal government going in an raiding medical marijuana dispensaries in places like California where it was legal under state law to prescribe or to give a doctor's note for-- and if so, why?

### Moderator
Claim: I don't actually think that that is on point for the debate, so I'm going to pull that one. You can answer-- come up and approach him afterwards. I don't think it's on the question of whether we should legalize drugs or not. And I can take one very, very, very, very short question and short answer. Sir, mic is coming to you down left hand side. Could you stand up? Thanks.

### Moderator
Claim: My name is Now, that statistic you provided in the brochure, that 50 percent decrease in drug use, my question is: How can you say that that's a causal relationship based on the--

### Moderator
Claim: Okay. We get the question? Asa Hutchinson. Good question.

### Scientific Advocate (SA)
Claim: I mean, I think you can argue it either way, you can say that that's the result of education, it's a result of enforcement efforts. I personally believe that it's the result of all of our community efforts combined.

But the point is, you're not going to ever eliminate 100 percent usage of illegal drugs and addicting drugs. And the reason is we have young people, we have addictive personalities. The question is, what is the best way to keep the usage and the abuse at the lowest point for our society? And I think the present mechanisms, while we can tweak it, we can adjust it, we can change our enforcement policies, has worked pretty good in terms of keeping it-- a 9 percent level of use in the last 30 days for all of Americans. That's making some progress.

## Round 3

### Moderator
Claim: And that concludes Round 2 of this Intelligence Squared U.S. debate. And here's where we are. We are about to hear brief closing statements from each debater in turn. They will be two minutes each, and this is their last chance to try to change your minds.

Remember you voted before the debate and you will be asked to vote again right after these closing statements and to pick the winner. The team that has changed the most minds will be declared our winner. But, first, onto Round 3, closing statements by each debater in turn; they are two minutes each. Our motion is legalize drugs. And here to summarize his position against the motion, Asa Hutchison, former administrator of the Drug Enforcement Administration.

### Scientific Advocate (SA)
Claim: Thank you for incredible attention to this important topic. Today, as I prepared for this debate, I received a call from a family friend in Arkansas who is a grown mother, actually has two 30-year-old girls, and she said both of them are on methamphetamine and she simply asked, "What do I do about it?" And so I started asking questions, and one of them actually knew she had a problem and wants to get off; the other one just is going down this path, she's got a supplier, she's got a dealer. And, of course, I started thinking through, "How does legalization impact this very real tragedy that is destroying this home and this family?" And one of the 30 year old daughters has children being neglected. And I could not think of a system of legalization that would make this better, because this person that has a problem will never get the treatment necessary in order to get over that addiction unless they're confronted with it, and probably from a legal standpoint. It is that officer that will say, "Ma'am, you've got methamphetamine in your car. You need to get help. We're going to arrest you, or you're going to go to drug court. Something's going to happen. And that will change their life. Now, if it's not illegal, all that officer can do is say, ma'am, we're going to have to take your children away from you. But you've got a right to keep your methamphetamine. You've got a right to go get some more. You've got a right to continue your abuse pattern.

And this could be multiplied over and over again. Ladies and gentlemen, this is about legalizing drugs. If you send a signal to our youth of our nation, the next generation, as President Barack Obama wants to do, that it is illegal, then usage will stay at a modest level, hopefully a declining level. If you legalize it, usage will go up. If you believe it is harmful, then you should vote no on the proposition. Thank you very much.

### Moderator
Claim: Thank you, Asa Hutchinson.

Our motion is "legalize drugs." And here to make his closing statement in support of the motion, Paul Butler, Georgetown law professor and former federal prosecutor.

### Conspiracy Advocate (CA)
Claim: Thanks first to my great partner and my very worthy opponents. It sounds, though, like I was wrong about how Asa would respond to someone who he cares about who has a drug problem, because it does sound like he thinks the best thing to do is to call the police, because he said that's the only way that they'll get help. I just fundamentally disagree with that. I don't think that in order to get treated for a drug problem you should have to admit that you're a criminal. I agree with President Obama when he said, during the first campaign, that it's blind and counterproductive to lock up nonviolent drug offenders. If it worked, if it got drugs off the street, then maybe I'd support it. But we know that it just doesn't work. Clarence Thomas, before he became the first African-American on the Supreme Court, was a judge in D.C. And he said, when he would look out of the window of his chambers and see all these young black men filing into the criminal court in chains, he would think, "There but for the grace of God go I." My friends, the determination of who goes to criminal court in chains should not be so fortuitous. It should not depend so much on the color of your skin or how much money your parents make. As long as it does, we need to legalize drugs.

### Moderator
Claim: Thank you, Paul Butler. And that is our motion, legalize drugs. And here to make his closing statement against the motion, Theodore Dalrymple. He is a former prison doctor and the Dietrich Weissman fellow at the Manhattan Institute.

### Scientific Advocate (SA)
Claim: Well, ladies and gentlemen, first, let me just remind you that Amsterdam is by far the most violent city in Western Europe, with a murder rate between 2.5 and 3 times higher than that of Paris, for example. And the mayor of Amsterdam recently said that he wanted to reinstate the coffee houses because he had this idea that the one and a half people who go there to take cannabis every year, they would go rampaging through the streets if they couldn't get it. I don't think anyone would have said that about smokers, for example, who couldn't smoke in bars.

So this suggests that there's a big difference here, a cultural difference. To give you an idea of the-- the Utopianism that is behind this motion, let me tell you that the head of the drug agency of the United Nations once said that the drugs trade was corrupting West Africa. Now, if you can believe that, you can believe anything, because when I arrived in Lagos Airport, the first time I arrived in Lagos Airport, the customs officer said, have you brought any presents? I said, I don't know anybody in Nigeria. He said, "For me." And I soon got the general view. Crime is not caused by the illegality of drugs, nor is there illegality that causes the problems to which they give rise. If you vote for this motion, you're saying that the British were the heroes of the opium wars because they opened to the Chinese the freedom to take opium.

And which they then did on a famous or notoriously large scale. And they stopped actually when Mao Tse-Tung threatened to shoot them. If you believe that the British were liberating the Chinese, then you will vote for this motion. But remember that genies do not go back into the bottles when they are commanded to do so. So please vote against the motion.

### Moderator
Claim: Thank you, Theodore Dalrymple.

Our motion is legalize drugs. And here to make his closing statement in support of the motion, Nick Gillespie, editor in chief of Reason.com and Reason TV.

### Conspiracy Advocate (CA)
Claim: Let me suggest, contra the opposition, when you consider about legalizing drugs, that in fact it does increase your freedom to be allowed to take Lexapro, or to take Lipitor or to take LSD. It will not destroy you. I will not turn you into a fried brain, lesser son of Timothy Leary. It just might make your life a little more interesting, or it's an experience worth having.

The status quo in the drug war is untenable and destructive for all of the reasons that my partner outlined. It is always going to be prosecuted. The drug war is always going to be prosecuted against blacks in America, to bring it back to Dear Old Blighty, blacks in America and the drug war are what Australians were to the English in World War I. They are human fodder, and they will be ground up and used as-- their bones will be the basis for the next bunker. There is no way around it. The drug war has always been prosecuted along racial lines, along class lines and other discriminatory practices. That's not going to change. It's not going to get better in the second hundred years of drug prohibition.

More to the point, I want you to think about, as you think about legalizing drugs, recognize, “is use the same as abuse?”, because that's the underlying kind of premise of the anti-legalization movement, to say, you know, marijuana use might go up, so what? If it's not bad, if it's no different than taking a beer-- if it's not qualitatively different than having a beer or a martini, maybe that's not such a bad thing, especially because people who are high on pot are less antisocial and less destructive and less criminal in general than people who are hopped up on a cosmo-tini or something like that. In the end, the legalization movement is a movement for personal responsibility where we criminalize bad behavior but not arbitrary substances. So please, legalize drugs.

### Moderator
Claim: Thank you, Nick Gillespie.

### Conspiracy Advocate (CA)
Claim: Legalize more drugs.

### Moderator
Claim: And that concludes our closing statements. And now it is time to learn which side you feel has argued the best. We're going to ask you again to go to the key pads at your seat. And I'm going to restate the motion and see where you stand now after hearing the arguments. Our motion is, "legalize drugs." Push number one if you agree with the motion, two if you disagree, and three if you became or remain undecided.

Anybody need more time? Just call out. No? All right. So we'll have the results in about 45 seconds or a minute.

First of all, I just want to-- I just want to thank the level of debate we heard here tonight. I really appreciated that these two teams respected one another, appreciated one another. It was forceful but friendly. So congratulations to them for the way they did this.

And to all of the people who had the guts to get up and ask questions, and even the ones that didn't get through and people I didn't call on, thank you very much for participateding and a round of applause for them.

So this is our fall season. We have one more event in our fall season. And that will be coming up on-- December 5th, okay. Thank you. It's December 5th. Even in the room knew that but me. The upcoming debate is called the-- the motion is "science refutes religion." “God.” Boy, you people-- Can I sit there? And all of you come up here. Thank you. Science refutes God. And the team arguing for the motion includes Lawrence Krauss-- I'm back on script. Lawrence Kraus. He is professor of physics at the school of earth and space exploration at Arizona state. His partner is Michael Shermer who is the founding publisher of Skeptic magazine. And arguing against the motion that science refutes God, Ian Hutchinson, who is professor of nuclear science and engineering at MIT. His partner is Dinesh d’Souza, the best selling author of "What's So Great About Christianity?" tickets for this debate are available for our website, that is www.IQ2US.org. Our next season begins in January. Five more debates coming up. We start on Wednesday, January 16. That will be here at Kauffman. Topics and debaters are being worked on still, but they will be posted on our website next month.

If you can't be in the audience for any of those upcoming debates, there are a lot of other ways to catch them. I talked about some of them at the beginning, but you can watch the live stream on fora.tv. You can listen to the debates on NPR, WNYC here in New York. You can download them as a podcast or watch them on WNET and the World Digital Channel. Again, if you would like to tweet about the debate, we would love that. We read them all. The twitter handle is @IQ2US, and the hash tag for this debate was DrugDebate.

All right, so here come the final results. All right, so remember, we've asked you to vote twice, once before the debate, and once again after the debate, where you stand on this motion before you hear the arguments and afterwards, and the team that has changed its number-- the team that has changed its results by the largest percentage will be declared our winner. So here was the motion, "Legalize drugs."Before the debate, 45 percent agreed with the motion, 23 percent were against, and 32 percent were undecided. After the debate, let's go first to the team arguing for the motion. Their second vote was 58 percent, 45 up to 58 percent. That is a move of 13 percent. That's what needs to be beaten. The team against the motion, their first vote was 23 percent, the second vote was 30 percent. They've only gone up 7 percent. It is not enough. The team-- debate goes to the other side. Our winners, the team arguing in favor of the motion, "Legalize drugs." Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. where we like to say, "Think twice."
