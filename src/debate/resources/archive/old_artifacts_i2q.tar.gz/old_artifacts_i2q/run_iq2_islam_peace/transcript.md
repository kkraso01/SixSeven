# Debate Transcript

Topic: Islam Is A Religion Of Peace
Motion: Islam Is A Religion Of Peace

Debate ID: islam-peace


## Round 1

### Moderator
Claim: And now I would like to introduce the Chairman of Intelligence Squared U.S., who makes all of this possible, Mr. Robert Rosenkranz.

### Moderator
Claim: Welcome, and thank you all for coming. My task in these evenings is to frame the debate. And in this particular case I want to start by quoting George W. Bush often proclaimed that “Islam is a religion of peace” and it is one of the few things with which President Obama agrees. It is doubtless true that the vast majority of Muslims around the world live peacefully, and do not condone violent acts. Their secular concerns are dominant—making a living, raising families, educating their children. Their religion provides spiritual comfort, and a source of meaning, even transcendence, to their lives.

On the other hand, just today the New York Times reported that Faisal Shahzad, the Times Square bomber, said in court prior to sentencing “Brace yourselves, because the war with Muslims has just begun.” Certainly in the past decades the vast majority of terrorist activity has been undertaken in the name of Islam. In some respects, Islamism resembles the totalitarian movements of the first half of the twentieth century: the ruthless use of violence in pursuit of ideology and power by Hitler, Stalin and Mao. Just as most of their victims were their own people, most victims of Islamist terror have been Muslims.

History is replete with examples of violent minorities who have held sway over peace loving majorities. Perhaps the relevant question for this evening is what the majority of Muslims believe. But perhaps it is whether Islam, viewed as an ideological force, is in direct opposition to western interests and western values.

Should we respect Islam as a religion of peace, or should we accept Samuel Huntington’s view that we are engaged in a clash of civilizations? Or might this be a false dichotomy? Can we honor our own traditions of pluralism and free exercise of religion, and accept that for the vast majority of Muslims it is indeed a religion of peace, without compromising our ability to defend ourselves and our values against the ruthless few that wish us harm?

Well, these are subtle and complex questions, and we've assembled an extraordinary panel of experts this evening to explore them. It's now my privilege to turn the evening over to our moderator, John Donvan, but before I do so I'd like to invite a round of applause to congratulate him on his third Emmy Award.

### Moderator
Claim: Thank you, and I was going to ask for another round for Robert Rosenkranz, and there it is. Welcome everyone, to another debate from Intelligence Squared U.S. I’m John Donvan of ABC News, and once again it is my honor to act as moderator as the four debaters you see sharing this stage with me here at the Skirball Center for the Performing Arts at New York University-- four debaters, two against two, will be debating this motion: “Islam is a religion of peace.” Now, this is a debate. There will be winners and losers, and you, our audience, will be acting as the judges. By the time this debate has ended you will have been asked to vote twice, once before and once again after the debate, on where you stand on this motion, and the team that has changed the most minds will be declared our winner.

So, let’s go to the preliminary vote. If you go to the keypads on your seat, our motion is “Islam is a religion of peace.” If you are for the motion, press number one. If you are against the motion, press number two. If you are undecided, press number three. You can correct any mistake just by repressing, and ignore the other numbers. And we will present the results of both votes for you at the end of the evening, and that’s how we will know who our winner is.

So, opening round-- sorry, let me put it this way: round one is opening statements by each side, seven minutes in turn, and I would like to begin by introducing our first speaker for the motion “Islam is a religion of peace.” I’d like to introduce Zeba Khan, the only American on our panel and quite possibly the youngest debater ever to take part in an Intelligence Squared U.S. debate. Welcome, Zeba. I know that I first became aware of you when the Washington Post was running a reality game show to name America’s next pundit. They had 1,400 entrants, and what place did you come in?

### Conspiracy Advocate (CA)
Claim: They had 4,800 entrants, actually.

### Moderator
Claim: 4,800. And you came in…?

### Conspiracy Advocate (CA)
Claim: I came in second.

### Moderator
Claim: Second. Well, look where you are now. Ladies and gentlemen, Zeba Khan.

### Conspiracy Advocate (CA)
Claim: Thank you. I want to express my deepest gratitude to Mr. Rosenkranz and the Intelligence Squared forum for allowing me to speak tonight alongside such well-known and far more distinguished co-panelists. This is particularly an honor for me because, let’s be honest, I haven’t written a book, I’m not a regular on national T.V. or radio. What I have is my story.

I am a Muslim American woman born and raised in Toledo, Ohio by two very loving Indian Muslim parents. My sister, brother, and I were raised in a middle-class American home. We went to Mosque on Sundays, attended Sunday school classes, and prayed the community prayer with our community of Pakistanis, Lebanese, and Syrian Muslims. When I was in high school, our Mosque president was a woman, who did not wear a headscarf. And it may come as a surprise to some of you, but for the entirety of my life men and women have prayed side by side at our Mosque, and both can enter the prayer hall using the same door.

My parents are both very religious people, but they express their faith in different ways. My father emphasizes the devotional, and he tends to spend his time praying and reciting the Koran, whereas my mother emphasized the more constructive approach.

She uses community service and volunteering to express hers. But what they both share is fundamental Islamic principles. First and foremost, seek knowledge. They urged their children, all three of us, to question, to have critical minds, and to doubt. They wanted us to engage fully with our faith and to question everything. They lived out the Koranic commandments that there is no compulsion in religion, and also that God said, in the Koran, “I made you into many tribes so that you might know one another.” And as such, they enrolled me and my siblings in a Hebrew day school for nine years, where we learned Hebrew, read the Torah, and prayed in a synagogue almost every morning. They always wanted us to learn about other faiths, and they always made sure that we knew the difference, though, between Islam and Judaism. But they also made sure we also respected our Jewish sisters and brothers in faith.

My story is just one of 1.5 billion stories in some 57 countries. The Muslim population is one of the most diverse and eclectic in the world. We are Sunnis, we are Shias, and even in the Shia tradition there are Zaidis, Ismailis, Ismasheries There are numerous madhhabs, or schools of thought, and Sufi mystic orders. Like Christians and Jews, Muslims can be observant, nonobservant, performist, humanist, secularist, extremist, mainstream, and there are even some Muslims who consider themselves culturally Muslims but are actually atheists.

Now, the motion before you tonight is asking you to determine whether Islam is a religion of peace. And at first blush, that might seem a bit tricky to decide. After all, the Koran and the Hadith have verses in them that point to peace and justice and love. But there are other verses that are violent, are about violence and about violence against specific people. So how then do we reconcile these seemingly contradictory verses? How then do we decide whether Islam is a religion of peace? The only way to answer that question is to take an honest look at the people who practice the faith and how they interpret it. According to Gallup's ground breaking study on what a billion Muslims think, 93 percent of Muslims around the world are peaceful, mainstream Muslims. Seven percent are what Gallup determines as politically radicalized. And within that seven percent, there's a smaller percent that has succumbed to the use of violence. Any percent is too much. But we must remember that the violent minority of a minority are motivated by politics, not religion. As Gallup concluded, what distinguishes the politically radicalized Muslims from the mainstream Muslims is their politics, not their piety. Robert Pape, a University of Chicago political scientist, further confirmed this in his book, Dying to Win, in which he came to the same conclusion, that the actions of terrorists are politically motivated, not through religion. The Tamil Tigers, for example, which are predominantly a Hindu group, used and pioneered the use of suicide bombing, did so far secessionist reasons, not for religious goals.

Our opponents would have you believe that there is a take all, no winner clash between Islam and the West, and that Muslims who try to balance their Western values and Islam arrive at a state of cognitive dissonance and are left either mute or crazy by this internal struggle.

That distribution description doesn't resonate for me or for my family or for my friends or for my community, because those two aspects of our identity were never in conflict with each other and were never introduced to us as in conflict with each other. I didn't realize that there were people out there who wondered whether people-- Muslims like me existed or could exist until after 9/11.

Let me be clear. There are some horrifically violent criminals out there who twist our faith to justify their hate and their violence. But I am here to tell you they don't speak for Islam. Mohammad Hamdani a first responder who died on 9/11, speaks for Islam. Hassan Askari, a Brooklyn Muslim who stepped in on the subway and saved a complete stranger who was being physically attacked because he was Jewish, he speaks for Islam. Zainab Salbi, through her organization Women for Women International, has assisted forever a quarter of a million women across the world. She speaks for Islam. And the entire Muslim community of India, who, when the authorities asked them to take the militants who attacked Mumbai in 2008, said resoundingly and collectively no. We will not let the terrorists be buried with us.

The media and those who profit from the narrative of Islam versus the West are never going to tell you my story or the stories of these Muslims who constitute the vast majority of Muslims around the world. But just because you may not hear us, it doesn't mean we're not speaking out. And just because you may not see us on TV, it doesn't mean we don't exist. If you vote against the motion, I would argue you're voting against the moderate voices of mainstream Islam and telling the terrorists that you agree with their version. I urge to you vote for the motion. Thank you.

### Moderator
Claim: Thank you, Zeba Khan. Our motion is, “Islam is a religion of peace.” You have heard the opening statement in support of this motion.

Now to speak first against the motion that Islam is a religion of peace, I'd like to introduce Ayaan Hirsi Ali, a very, very well-known dissident, born in Somalia, fled to the Netherlands, where she was a member of the parliament, the Dutch parliament. Now she is in the United States, once again on a case of asylum because-- Ayaan?

### Scientific Advocate (SA)
Claim: Well, because I had to live with-- basically, I was afraid for my life.

### Moderator
Claim: Ladies and gentlemen.

### Scientific Advocate (SA)
Claim: In the 21st Century, in a free country.

### Moderator
Claim: Ladies and gentlemen, Ayaan Hirsi Ali.

### Scientific Advocate (SA)
Claim: Ladies and gentlemen, I am surprised by the motion itself. When I first heard it, it reminded me of the academic question, how many angels can dance on the head of a pin? And I think, well, if you do the salsa or the cha cha, not many. Why are we not having a motion on is Christianity a religion of peace, is Judaism a religion of peace, et cetera? Because those would be academic motions. Unfortunately, the motion, “Islam is a religion of peace” is not academic.

I respect and admire Zeba Khan. And I want to acknowledge the fact that you indeed are a demonstration of the assimilation of a Muslim individual, a Muslim woman into Western society, into an American society. But you come from a middle class family that was very eclectic and respected pluralism. I respect that very much, and I admire you for it. And I think you are an example to others.

However, I disagree with you that you represent Islam or that you speak for Islam. The problem that is inherent in Islam from the time of its foundation up to this moment is who speaks for Islam. And I’ll get to that later on. Is it Zeba Khan or is it Faisal Shahzad? He was also a middle class man, went to business school, married an American woman, had two children, lived just like you, like many of you. And yet, he made a different choice based on a combination of piety and politics. And that's what Islam is.

And before I go on, let me define the key terms of the motion. First, religion. The most common definition of religion you will find is the universal quest of humans in search-- in search of the sacred or the holy. That search is expressed intellectually. It's expressed in practice. It is expressed in fellowship. And you look at the religion like Islam, on an intellectual level it was expressed by the founder of Islam as a demolition of all other gods. Polytheism had to end, and all humanity had to be united under one God. From those of you who are familiar with history, and I think a crowd like this is, you know that no monotheistic religion can be a religion of peace. No monotheistic religion is a religion of peace, and definitely not Islam. Monotheistic religions know periods, lengthy periods of peace, but they also know lengthy periods of war.

In times of practice, yes, in Islam, you practice charity, you go to Hajj, you pray, all of that. But in terms of practice, there is also the expression, there is the concept of jihad.

And I find it a pity that Zeba Khan did not mention that concept, which is central to Islam's conquests and Islam's success. The founder of Islam, Mohammad, in his lifetime, conducted 65 campaigns of war that were all successful. And that militaristic history of Islam is well documented. Just go Google it. And if you don't find it on Google, go to all those former empires that were conquered.

The combination of a history of empire, of conquest, also leaves a legacy behind. And that legacy is the thrusting together of people of different ethnicities, languages, et cetera. So even if that empire declines, the likelihood, the likelihood of conflict, of war, is probable. It's high, especially where there is a fault line. That's where Samuel Huntington had a point. That history of militarism, combined with the legacy of empire, those two points alone belie the motion tonight, that Islam is a religion of peace, but that's not all. When empires decline, those who are defeated, and the Muslim Empire declined, those who are defeated sometimes themselves in a state of victimhood. That state of victimhood is exploited by the leadership or the self-appointed leaders of Islam. And what do you see? You see a number of people, and I concede it's a minority, who believe that Islam is under siege.

A mentality of victimhood tells those who are conquered, who are vanquished, that the problem was caused by external powers, not by us, and that systematic denial within Islam after the 19th Century to blame only outsiders exempts Islam from blame, from the explanation what went wrong. Yes, it was external, yes, Muslims were humiliated, yes, they were conquered, yes, they were colonized, but how much was also because of the flaws of Islam?

And that takes me to the point of absolutism. When the West went into its scientific revolution, why wasn't it Muslims? Muslims were the first scientists, arithmetic, logic, et cetera. They were great; why didn't they get into that scientific revolution? Why were they left behind? Was it only because of external factors or were there internal flaws? That combination of a status of victimhood and the absolutism-- the demand that you can never revise or reflect on the Koran, that you can never, never ever refute what Mohammad said, you can only follow his example-- that absolutism combined with that status of victimhood also enlarges the likelihood of conflict, and those two combined like the other two factors like--

Thank you. That belies the motion. I'll keep my last two factors for the time I have remaining, thank you.

### Moderator
Claim: All right, your time is up.

### Scientific Advocate (SA)
Claim: Thank you. That belies the motion. I'll keep my last two factors for the time I have remaining, thank you.

### Moderator
Claim: Thank you. are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two, fighting it out over this motion, "Islam is a religion of peace." You have heard from the first two debaters in their opening statements, and now on to the third.

I'd like to introduce Maajid Nawaz, who is director of the Quilliam Foundation, and he has an amazing biography, and several years back, would have been America's nightmare. He was a radical, he was imprisoned in Egypt while on a trip there, though he's born in the U.K., was in Egypt and tortured for being a radical, and something happened to you in prison, 180-degree turn--in one sentence, what was it?

### Conspiracy Advocate (CA)
Claim: In one sentence.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: You're talking about four years now.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Amnesty International. Well, I'll explain that and hopefully

### Moderator
Claim: Fair enough. Ladies and gentlemen, Maajid Nawaz.

### Conspiracy Advocate (CA)
Claim: Thank you. Can I indulge the audience and just ask for a round of applause for Zeba's mom, she's just over there, I think she did a wonderful job. To raise your daughter to speak Hebrew in the current climate is amazing and I applaud you.

So, ladies and gentlemen, thank you for giving me this opportunity. I want to begin by just stating what this debate is not about. This debate is not about making excuses for terrorism. Basically my career is to challenge extremism and terrorism in the West and also in Muslim majority countries. I've just flown right in from Pakistan where I've been building the foundations for the first nationwide social movement to challenge extremism and promote democratic values in Pakistan. And I'm proud to announce that just today we gained our 10,000th member on Facebook. So this debate-- this debate is not about making excuses for suicide bombers even inside Israel. We make no apologies and no excuses on this panel for terrorism, for extremism, and for people who kill innocent civilians, including inside Israel.

This debate acknowledges, we, on our panel, Zeba and myself, acknowledge that Muslims do need to speak out against extremism and to challenge it, and more Muslims need to do that more actively. We acknowledge that Muslims bear responsibility in reclaiming their faith from those-- the minority who have hijacked Islam and who have captured the public imagination in their definition of Islam. We acknowledge that, and I am in my own person a manifestation of that effort, as is Zeba in the way she was raised. So we acknowledge that as well. This debate, in fact, is an appeal. It’s not-- also, before I move to the fact that it’s an appeal, it’s also not a threat. So, we’re not going to argue here tonight that if you don’t vote for the motion, that somehow Muslims are going to rise up and attack you for insulting Islam. That’s not the case. This is an appeal. And it’s an appeal to your good sense and your good character and to what you know inside you. This is not a debate for Islam at all. This is a debate for peace. And we are not arguing for Islamic peace; we’re arguing for Islam to be-- with all other religions and beliefs and those that have no faith-- to be part of the effort to create peace in the world. So this is a debate for peace. It’s a debate, and I’m asking you all to vote tonight not for Islam, but to vote for peace and to help contribute the efforts of all of us around the world who are working for peace.

Because there are people like me who spent 13 years of our lives working to create hatred. I used to believe that Islam is not a religion of peace. In fact, I used to believe that Islam mandates war. I used to believe and propagate across the world in more than three countries that Islam mandates war and mandates the creation of a state that will have at its heart of its foreign policy a policy to create conquest. I called it jihad. I believed that Islam was not a religion of peace because I adopted an ideology at 16 years old and stuck with that until my imprisonment and after I was released from prison when I was 28 years old.

By that time I had established this ideology in Pakistan and in Denmark and contributed to its growth in Egypt.

But I learned in prison two things. One was what I’m appealing to you today and that was when people hold out an olive branch, it does work. People I’d considered my enemy, people I’d considered the enemy of my people, Amnesty International with their advocation of human rights that I believed was a tool to colonize the minds of Muslims, adopted me as a prisoner of conscience. And by handing me that olive branch, I recognized that there was goodness in the world and there were people who, regardless of the provocation they find in the world today, are still willing to fight for peace and are still willing to redefine the debate.

And that’s what I’m asking you to do here tonight. Because by redefining the debate, and by insisting that they would not allow my hatred to define for them the way in which they viewed me, they changed my heart. I went on and took that message forward and helped establish the world’s first counter-extremism think tank in the West, then went into Pakistan to establish the first nationwide counter-extremism movement in Pakistan. And as I said, we had 10,000 supporters before we’d even launched, of Muslims in Pakistan who are helping us to redefine the debate, who are not allowing the minority of extremists to hijack Islam, to monopolize its definition, and then define for us all that this should be a world of war, not just Islam as a religion of war, but as you heard from our co-panelists on the other side, all religions should be religions of war in their minds. Whether that’s because they want to fight or because they don’t believe in religions and they wish to challenge religions from that basis. And so I make an appeal to all of you tonight to help us redefine this debate.

And the second thing that happened to me in prison that helped me change my mind was that I had the opportunity-- I won’t say good fortune because it wasn’t really that-- but the opportunity to mix with some of the leading founding jihadists of the world inside an Egyptian prison, ironically built by the British. And what I learned was that I had been extremely arrogant. I had suffered from the failure that I saw here tonight in my respected colleagues’ presentation. I had failed to contextualize history, and when I was this young and angry 24-year-old who, yes, had grievances, who’d been stabbed at multiple times growing up on the streets of Essex, who had been falsely arrested on a number of occasions because of racial profiling-- I was a very angry young man. But I went to men in prison, who had been in prison since I was three years old, and then I met them at 24, and they had abandoned their previous terrorist ideologies and I had the arrogance to try and convince them that they had sold out, that they didn’t understand that true Islam was a religion of war. And they said to me, “Young lad, come and sit down. We’ll tell you a story or two.” And over the course of the four years, after having learned Arabic, after having memorized half of the Koran, after having studied the theology, though myself not being too much of a religious man, I came to the conclusion that Islam had been hijacked and abused and politicized by something that I now refer to as Islamism, the modern ideology that owes more to post World War I European fascism than it does to the traditions of Islam. And these former jihadists, among them the assassins of Egypt's former president, Anwar Sadat, who was killed in 1981, they had come to the same conclusions.

And so I appeal to all of you as my time runs out-- there is much more to say-- to vote to help us all to redefine this motion, to redefine this world, because only by refusing to accept the paradigms that we find imposed upon us can we refute change. And that's exactly how the civil rights movement in America tackled this issue when they were faced with such situations in the past. Thank you for your patience, and thank you for your time.

### Moderator
Claim: Our motion is, “Islam is a religion of peace.” And now to speak against the motion, Douglas Murray. He is a best selling author and founder and director of the Center for Social Cohesion, also a citizen of the United Kingdom, a member of the Church of England until recently. You said that your study of the Koran-- you said this in print-- made you an atheist.

### Scientific Advocate (SA)
Claim: That's right. I said Mohammad made me an atheist. The publisher said at the time that it's a pretty provocative headline. I said, “Well, get somebody to do the next one.” She said, “I could find a Catholic who could say Mohammad made me a Catholic.” I said, “How about trying to make a three-part article and get a third one of somebody saying Mohammad made me a Jew.” And that one would be the trouble.

### Moderator
Claim: Douglas Murray, ladies and gentlemen.

### Scientific Advocate (SA)
Claim: Well, thank you. Thank you. It's a great pleasure to be here tonight. I'm sorry to make this panel rather Brit-centric after my colleague Maajid. It isn't an attempt by us to have a British takeover of the old colony or anything like that. But I was coming earlier from my own fallen empire, going back to my friend and colleague Ayaan's comments earlier. And I was reading the paper, as I'm sure all of you were doing all yesterday. Maajid finished his comments by talking about the importance of changing paradigms. I'm not sure it is about paradigms. I think it's about facts. Here are some facts. In my newspaper earlier, the Times Square Bomber, of course, a man just up the road from here, who tried to kill thousands of people, only, by the way, didn't manage it because he set the 24-hour timing device at 7:00 a.m. instead of 7:00 p.m., 1900 hours was what it was meant to be.

If he had to have got that bit right, thousands of New Yorkers would have died earlier this year, again. I see further in the paper 12 suspects arrested in France in a network trying to recruit people to go in to fight American and other troops in Afghanistan. I turn to another page of the newspaper, in the city I had just flown off from this morning, a Muslim London Underground worker who was-- had written to his wife who was off to - - tried to become a martyr for Allah, as he said. He said, “More than anything I wish Allah to grant me martyrdom." Ladies and gentlemen, we have to look at facts. We should also, just quickly-- if I may refer something to the wording of tonight's debate, Ayaan's already mentioned it. But let me put it this way. You're, I'm sure, a liberal minded New York audience. At least I hope you are. We will see.

But I imagine that if the motion we had here tonight was “Christianity is a religion of peace,” we get to the Q and A, perhaps even before, and somebody would say if the other side were arguing for that, somebody would say, "What about the crusades, hmm? What about that?" Then there'd be some other Clever Clarks who'd say, “I-- what about that Florida pastor the other week? There was a nasty business. That's Christianity for you.” If we'd have had tonight Judaism is a religion of peace, the other side would try to argue that. Sure as anything, there'd be people popping up in the hall tonight saying, “Oh, there's this bit in one of the Old Testament books, really, really bad, all sorts of massacres going on. Why don't you talk about that?” There might even be people trying to say that religion-- the argument that Judaism was a religion of peace couldn't be argued because people would say look at what Israel is doing. And isn't that a direct and so on.

So let's not have a debate about Islam and whether or not Islam is a religion of peace without talking about the facts to do with Islam. It's an absurd situation we're in, where nothing that anyone does whilst being Muslim is any responsibility of Islam.

Yet anything anyone does whilst being a Christian or a Jew is the responsibility of all Christians, all Jews. Let's make this as straightforward as I can. Take the categorization that eminent scholars like Bernard Lewis and Ibn Warraq have made. Let's say Islam is a very, very complex thing. And the best way I can do this in the very short time I have, is say you have three Islams, Islam one, two, and three. Islam one, the Koran and the life of Mohammad and the Hadith. Islam two, the tradition of the Sharia. Islam three, what Muslims do now. The first of those things, Islam, the Koran and so on, is bad. It is bad. There is a lot of violence in it. And what's worse, the peaceful verses are superseded by the violent verses. The violent verses also sadly are more numerous in number. Then you've got the life of Mohammad. Again, a bad man, a very bad man. It happens to be that not a great role model if you look at it. Takes child brides, abuses a small girl, multiple wives, himself a warrior, himself a war criminal, himself beheads Jews. This, I would have thought, would be a signal of not great peacefulness.

Then you've got the tradition of the Sharia, again, not great peacefulness, still no schools of Sharia that people in this hall would want to submit to.

And thirdly, what Muslims do now. Thankfully, there is some hope in that one, because most Muslims, thank goodness-- I almost said thank God, but-- old habits die-hard. Most Muslims don't do what those texts say because they exercise their judgment as moral beings without having to refer to defunct holy books.

Now, look, I wish that Zeba and Maajid were the spokespeople of Islam. It would be lovely. Although in Maajid's case, it would have taken rather too long if everyone had to go 14 years of preaching the downfall of America and then said no, not so much. But we are where we are. Anyhow, I wish they spoke for Islam. It would be great. But the fact is that tonight, the organizers of this debate asked a number of clerics, none of them which showed, specifically they wouldn't show and debate against Ayaan Hirsi Ali. Myself, I don't think they cared. But no, it's very interesting. They will not debate. Time and again, Muslims-- the actual leaders of your religion will not debate this. And you are left with people-- now here, the reasons why of course is the leaders of the religion show such terrible-- terrible lessons. It is not a small thing. It's not as if it were a detail. It's not like a wacky Florida pastor. But you've got the largest Sunni state of Saudi Arabia, the most important Sunni state in the world, the most extraordinary closed prison of a society. It's not a detail. It's not a one-off nut job. The Shiite republic of Iran is what it is, led by the people it's led by. That is not an accident. It's not a detail.

The thing that worries me is that although tonight we hear from the panelists here about how Islam is a religion of peace, the fact is that the people who are making the decisions in the religion, the people who are preaching the religion, the heads of that religion, people like Sheikh Qaradawi who broadcasts anti-Semitic-- the most appalling filth every week on the main network, that is the faith that is speaking for you guys. I wish that Zeba, you were on every week on Al Jazeera, but you are not. Qaradawi is. The problem is that Islam is an unstable component, as a religion, an unstable component. A thousand years ago, the Mustabalites tried to reform the religion. They were wiped out. The fact is that Islam is many things, many, many things. But to say it's a religion of peace is nonsense. It's to ignore reality. It's to ignore very difficult but necessary facts, not paradigms, but facts.

To say that Islam is a religion of peace is to say something based entirely on hope. It's to elevate a hope into truth. And I hope, as you will note, history teaches us that's a very bad thing to do. Thank you.

## Round 2

### Moderator
Claim: Thank you, Douglas Murray. And that concludes round one of this Intelligence Squared U.S. debate. We have heard opening statements. We're going to move into round two. Remember how you voted in the beginning. We're going to move into round two, in which the debaters address one another directly. They will be taking questions from me and then questions from you in the audience. So, I just want to state where we are.

This is an Intelligence Squared U.S. debate. I am John Donvan of ABC News. We have two teams of debaters arguing out this motion: “Islam is a religion of peace.” The side arguing for the motion, Zeba Khan and Maajid Nawaz, have been arguing-- make the argument that the extremists do not define Islam. Take away the extremists, and you have a religion of peace. The side arguing against, Ayaan Hirsi Ali and Douglas Murray, argue it's not about extremists. It's inherent. It's inherent in the tradition. It's inherent in the scripture, and it's inherent in the history.

And so the question of the notion, Ayaan Hirsi Ali, of this not just being about extremists, you can see that there are extremists, but that's, you say, not the problem, what about your opponents, what about your parents, what about Muslims you know who do not adhere to a violent form of religion, are they-- if there's something about the faith themselves, are they embracing spiritually something that is morally an illusion?

### Scientific Advocate (SA)
Claim: Well, my parents and people like my respectful opponents here are ignoring the basic tenets of their religion.

When Mohammad, the founder of the religion, called out to all Muslims-- and that's how he won most of his wars, by saying, "I have been ordered and all believing men have been ordered to attack and kill and maim anyone unless they testify, unless all men testify to the fact that Allah is the one and only, Mohammad is his messenger, my father disobeys that. Well, Maajid Nawaz tried to obey that first and then stopped obeying it. But the fact that that scripture is there and that history of militarism is there belies the motion that Islam is a religion of peace.

The point I want to make is Islam is a religion, when you take the scripture, that can be employed to wage war, and Islam as a civilization has known periods of peace, but you cannot-- if you pay attention to that history, pay attention to the evidence-- continue to say that Islam is a religion of peace. No monotheistic religion is a religion of peace. No monotheistic religion is only a religion of war. It is both. But in Islam, and that's why we are debating it in the 21st Century, there are more occurrences of violence and war and strife and subjection of women then there are in other religions. And my point-- our point is, let's not deny it, because by denying it we don't solve the problem. Let's admit it and then as intelligent people take it from there. What is to blame on external factors, what is to blame on the inside?

### Moderator
Claim: Let me just hear opponent Maajid Nawaz, who was an extremist, now an anti-extremist, Maajid, respond.

### Conspiracy Advocate (CA)
Claim: So, forgive me for the assumption, Ayaan, it's a pleasure to be on the panel with you, by the way, but forgive me for the assumption, but do you speak Arabic? Have you studied Arabic grammar? And I'm asking for a purpose, which if you do give me the chance to explain I will, but that first of all just let me ask you that question.

### Scientific Advocate (SA)
Claim: I don't speak it as well as you do. And I want to know where the question is going before I give a full answer to that. If you want me to quote the Koran I will.

### Conspiracy Advocate (CA)
Claim: You may be surprised, I don't know if I speak well or not, but the reason I'm asking is that you just quoted hadith, of the prophet, and you actually really did exaggerate what he said, and I'll quote to you the exact hadith in Arabic and then translate it. Now, what you quoted was--

### Scientific Advocate (SA)
Claim: It’s actually the Koran, but go on.

### Conspiracy Advocate (CA)
Claim: Well, Hadith is

### Scientific Advocate (SA)
Claim: It’s chapter 2, 191 to 193--

### Moderator
Claim: Wait, just

### Conspiracy Advocate (CA)
Claim: Now, what you quoted and in the translation was, "Kill and maim," and you went on and explained. Now actually means "to fight." Now, I'm not saying that that's a good Hadith. What I'm saying is when we're translating, let's try and be accurate.

And that brings me to the point, and that is that I just thought of a word to describe this, and it's just come to me so thank you because I want to use it forever onwards, and that is suspended intelligence. There's a tendency when discussing Islam to suspend the tools that we have learned and studied, and that you have studied as well, that we use to analyze every other piece of scripture and literature in the world, and that is that we recognize that texts do not speak for themselves. We recognize that when we interpret scriptures and texts and books and poetry that they are contextualized, that we have methodologies to approach them, when we're reading Shakespeare, when we're reading anything. We recognize that there's a way to interpret text and there are schools of thought and differences over how to approach texts.

Now, if we contextualize Martin Luther, and say the Reformation was a good thing, despite the fact that he said, "Kill and slay the peasants wherever you find them," when they follow Thomas Muntzer-- when he was calling for not just breaking away from the papal authority but also for rebelling against the monarchies and the dictators that they found themselves in-- Martin Luther sided with the tyrants against Muntzer, and said, "Kill the peasants wherever you find them." Despite that, I'm prepared to say the Reformation was a good thing. And the reason I'm prepared to say that is that Martin Luther must not be judged by the standards of civilization that we, after an accumulation of thousands of years, have arrived at. He must be judged by the standards of civilization that were around during his time. And that's how society evolves.

### Scientific Advocate (SA)
Claim: I--

### Moderator
Claim: Hang on.

### Conspiracy Advocate (CA)
Claim: And we recognize that for every other faith and for every other piece of literature, yet when it comes to Islam somehow we want to suspend. But we learned about that and quote the

### Scientific Advocate (SA)
Claim: Yes, we read things in their context. I mean, you read Chaucer in context. Chaucer doesn't have followers, doesn't have 1.4 billion people who believe every, or are meant to believe

### Conspiracy Advocate (CA)
Claim: Sorry, I quoted Martin Luther not Chaucer. I suppose Martin Luther does have followers--

### Scientific Advocate (SA)
Claim: If you allowed me to speak, I would address your lesser point. I will get there I promise. You don’t-- we don’t have followers of Shakespeare who insist on, going to insist on following line-by-line everything Shakespeare did and believing everything he wrote. That’s because it’s literature. Actually what’s happening, Maajid, you put your finger on the problem. It’s not us that’s not applying the rigorous critical faculty. We’re applying it to the Koran as we would to any other work of literature. You’re not because you can’t. And the final thing is, Maajid, because Maajid knows very well that--

### Scientific Advocate (SA)
Claim: He is a believer and believers are not allowed to contextualize the text.

### Moderator
Claim: Is that true?

### Scientific Advocate (SA)
Claim: Because if you were allowed to contextualize, you would say some of the things that Mohammad did is crap. You would say some of the deeds--

### Moderator
Claim: Maajid, is it true that you cannot--

### Scientific Advocate (SA)
Claim: You cannot contextualize.

### Moderator
Claim: Maajid, is that true?

### Conspiracy Advocate (CA)
Claim: No, that’s not true.

### Scientific Advocate (SA)
Claim: What do you think of Mohammad taking a six year old as a bride? What do you think of that?

### Conspiracy Advocate (CA)
Claim: I don’t think that’s a particularly good idea. However, what I would say--

### Scientific Advocate (SA)
Claim: Glad to hear it.

### Conspiracy Advocate (CA)
Claim: There were many, many people in history that have done such a thing and what we’re talking about here is a failure to contextualize actions for the standards of their time. And I’ll come back to the point I made, because Douglas, you didn’t address it, despite your protestations--

### Scientific Advocate (SA)
Claim: I

### Conspiracy Advocate (CA)
Claim: Let me just ask you again. Martin Luther was a fundamentalist, wasn’t he?

### Scientific Advocate (SA)
Claim: Absolutely. If there were currently Lutherans, and there are Lutherans around. You meet them occasionally in Scandinavia and so on. Very nice people. nice people and peaceable guys they are by and large. If, however, there was a large proportion of Lutherans somewhere in Scandinavia that started blowing up non- Lutherans-- or no, sorry absolutely right-- started massacring peasants, do you think that people would say, hang on a minute, “Let’s not criticize Martin Luther. He did that by the standards of his time. We shouldn’t criticize his followers all that much. We shouldn’t point out that what he said.” No. We just say, “You know, don’t go and massacre peasants. Full stop. It was rubbish at the time and it is now.” It’s the same with the Koran.

### Conspiracy Advocate (CA)
Claim: You’re missing the point. You’re failing to judge--

### Conspiracy Advocate (CA)
Claim: I just wanted to point out, when we’re talking about the Koran and saying that we can’t contextualize it, that’s simply not true. That is a debate that’s hot in the community amongst Muslim scholars and amongst Muslims themselves. We’re debating that very question. Is the Koran a living document? Much like-- it’s similar in comparison to the Constitution and the debates that happen around that. The fact is scholars say that when you look at the Koran in Arabic, there can be two, three, four, five, six interpretations for every word. There’re only certain things in the Koran that scholars agree are concrete, like the concept of God, afterlife, things like that. But beyond that there is a wide, wide range of interpretation, which is why there is a history that not many people look at, and that’s part of the problem. That nobody’s actually looked at the history of debate within Islam about every sort of aspect that can come to mind.

### Scientific Advocate (SA)
Claim: I disagree with that. The reason I disagree with that-- it would be more accurate, Zeba, if you said the scholars that you find attractive say that. But there’s a bunch of scholars, a great number of following in Islam, take-- all of them are self-appointed by the way, because there is no higher education, there is no seminary of Islam, except the University of Al-Azhar, we know the products of Al-Azhar, but there are scholars like bin Laden who say we have to take--

### Conspiracy Advocate (CA)
Claim: He’s not a scholar by anyone’s measure.

### Scientific Advocate (SA)
Claim: Well he has the greatest following. He has the greatest following.

### Conspiracy Advocate (CA)
Claim: That’s not true.

### Scientific Advocate (SA)
Claim: The Islamic Brotherhood, Hassan al-Banna, when you to look at the Sunni Islam. When you look at the Ayatollah Khomeini in the 20th Century, the most influential guy of Shia Islam is another self-appointed scholar. Sheikh bin Baz, he has the greatest following. Sheikh al Qaradawi. Maybe these are individuals that are not attractive to you, but then it would be more accurate if you stated that. They are attractive to many Muslims, not thousands but in the millions, and what they say-- and that’s why they’re influential-- is they challenge every single Muslim individual, are you a true Muslim? If you are a true Muslim, you live by what the Koran dictates, you follow the example of the Prophet Mohammad.

### Conspiracy Advocate (CA)
Claim: Right. Their interpretation, though.

### Scientific Advocate (SA)
Claim: Those scholars insist on that, are far more influential, far more powerful than your soft- spoken, wonderful, cuddly scholars.

### Conspiracy Advocate (CA)
Claim: Ayaan, you just quoted bin Laden as a scholar. Hassan al-Banna as a scholar. Bin Laden, for those of you who don’t know, is an engineer, a qualified engineer. So you don't know him.

### Scientific Advocate (SA)
Claim: Why don't you define whose--

### Conspiracy Advocate (CA)
Claim: Don’t know his history. He's a qualified engineer who comes from one of the richest construction families in Saudi Arabia and was educated in the elite private schools of Switzerland and Saudi Arabia. Hassan al-Banna that you referred to was a school teacher. And in fact what you find common with all of the movements that you are worried about, and that I am worried about, and we're all worried about, are that they are founded by people who do not have a theological background. Now, for all we think about Al-Azhar, and they have very conservative views, what we don't find is that Al- Azhar produces the likes of bin Laden and Hassan al-Banna, or even Maududi, the founder of Jamaat-e-Islami Islam in the Indian subcontinent. Maududi was a journalist. Sayyid Qutb, the founder of modern day Jihadism, was a literary critic who came to America on a scholarship in the 1950s to study literature. He was not a theologian. So coming back to the point--

### Scientific Advocate (SA)
Claim: Why don't you name a number of scholars who are influential who are not--

### Conspiracy Advocate (CA)
Claim: Please, Ayaan, don't define for the whole world who a Muslim scholar is, because actually the people you referred to were not qualified theologians.

### Scientific Advocate (SA)
Claim: But don't you touch on the problem by admitting this? Don't you touch on the problem that is inherent in Islam after the death of Mohammad, that the problem of who speaks for Islam has not been resolved. It could be the two of you. It could be bin Laden. It could be al Qaradawi. It could be Faisal Shahzad.

### Moderator
Claim: Hang on. The question is, what does that have to do with Islam being a religion of peace? You're almost making the argument that Islam is what you want it to be, depending on how you behave. So if you behave peacefully, is it not a religion of peace to you.

### Scientific Advocate (SA)
Claim: That is a brilliant question. You can start by saying Islam is something to-- a different thing to 1.57 billion people. And from that general point, you can reduce it to what is it that unifies them? And ultimately, you will get to the Koran and the hadith. The Koran, the hadith, the day of judgment. The belief in the day of judgment, and if you take those three concepts, then it's far from a religion of peace because you look, first of all, not only at the content of the Koran-- in context, fine. I am willing to contextualize it. But what if other believes are not, and they're influential? What if I want to read Mohammad's practices simply as a matter of history, another great figure in history? But more Muslims, millions of Muslims don't want to do that and really want to follow his practices. What if more and more Muslims invest in the hereafter more than they invest in life? Then we have a problem. And that's why I ask you to vote against the motion, it cannot be only a religion of peace, because if it were only a religion of peace, if it were perfect, why would we have this debate, why would we--

### Moderator
Claim: Douglas, given the long run that Ayaan had, can you be 15 seconds?

### Scientific Advocate (SA)
Claim: Imagine trying to imply that the whole extremist problem is a misreading by engineers and literary critics. Unfortunately, that's simply not the case, hasn't been historically in Islam, and isn't now. Ayatollah Khomeini, who Ayaan mentioned earlier, was not a self- trained engineer, rich boy, like-- you know, unfortunately, and managed to hurtle a very developed, distinguished culture back in time in 1979, and hurtled this country back into the state it's currently in, under these cloaked dictators. The Grand Mufti of Egypt is not a self taught--

### Moderator
Claim: All right. We seem to be going-- and I don't need a list.

### Scientific Advocate (SA)
Claim: --that all Muslims should go and fight the Israelis

### Moderator
Claim: Maajid.

### Conspiracy Advocate (CA)
Claim: Sorry. On Khomeini. I acknowledge Khomeini is a trained theologian. And the fact is he came in the '70s, Douglas. And that proves something. What was he so famous for? Khomeini was recognized for bringing a revolution in Shiite theology. And what was the revolution? Those of you who have studied this will know that the revolution was, up until him, Shiites had been avowedly religiously secular, because they believed no one had the right to rule in God's name until the Messiah came, and let them wait for that Messiah until the end of time. Khomeini changed that and turned it on its head. And if that proves something, it proves one thing, and that is it was not in-- it was not consistent with Islamic Shiite tradition. What he did was a very modern revolution, influenced by his studies in Europe and influenced by modern European fascism. He broke from tradition, and that's why it was called a revolution. He was not a continuant of Shiite traditionalism.

### Scientific Advocate (SA)
Claim: It's the fault of the Europeans, in other words.

### Conspiracy Advocate (CA)
Claim: No, no. No one's saying it's--

### Scientific Advocate (SA)
Claim: Remember, the--

### Conspiracy Advocate (CA)
Claim: Come on--

### Moderator
Claim: I want to ask you something about reforms for Islam. Does Islam need reform?

### Conspiracy Advocate (CA)
Claim: It needs a renaissance. It doesn't need a reform. Reform in the sense-- and the reason I say that is because we have to be careful of our terminology. If we say reform as in Reformation, we're thinking of a Christian context where you had the Protestants and Martin Luther rejecting the Catholicism and the Pope. But the thing is in Islam, there is no Pope. There is no centralized authority. So there can't be a reformation in that sense. What there needs to be is a return to genuine Islamic principles which have been not studies, have not been enforced and were forgotten. So it's not exactly that.

### Scientific Advocate (SA)
Claim: A return to genuine Islamic principles is exactly what al-Qaeda is advocating.

### Conspiracy Advocate (CA)
Claim: No, that's not actually what they're-- no, that's actually incorrect.

### Scientific Advocate (SA)
Claim: A return, a rebirth--

### Moderator
Claim: I'm sorry, the radio cannot make sense of two voices. And I am talking now too at the same time. So I'm going to be quiet. I'm going to give you 20 seconds to make that point, and then I want to hear back. So a succinct 20 seconds.

### Scientific Advocate (SA)
Claim: When you look at the extremist-- the organizations that we've come to call extremist, where they're advocating, when they answer the question what went wrong, we had this empire, we lost it, how do we regain it? Their answer is a rebirth. Let's go back to the origins, a revival of it. Is that what you want, Zeba?

### Conspiracy Advocate (CA)
Claim: No. They actually co-opt the language for their own political purposes. Al-Qaeda is not calling for a return to Islam or to original Islam or anything like that. They're actually using Islam as a cover for their political grievances. When you look at and ask Muslims, ask 1.5 billion Muslims, when you look at the mainstream, they're 90 percent. They're peaceful and fine. When you look at the politically radicalized, when you ask them what do they fear most? They say Western domination and occupation. But when you ask mainstream Muslims what they fear, they say economic issues, unemployment.

There's a clear difference. And so they are not-- what we can determine from that is it's not religion because religiosity between the two is indistinguishable, how pious they are, indistinguishable. It's the one factor that makes the difference is what they focus on and their grievances against-- perceived grievances against the West.

### Moderator
Claim: Douglas Murray.

### Scientific Advocate (SA)
Claim: But don't we get back to one of the core problems which you still haven't addressed, which is the life of Mohammad and his teachings, which is as follows. If a Christian group decides to go back to the teachings of Christ, you know, the worst stuff they find is the Sermon on the Mount of Olive. They find one verse where Jesus is saying, I think in the Gospel of Matthew, to have said “I come not to bring peace but a sword.” But the rest of it is all love thy neighbor and all that sort of stuff. If you're a Christian group looking to go back to the sources of Christianity, you just find a lot of, well, hippie stuff, for a lot of modern people. So what is it about this religion we're talking about tonight that you say is a religion of peace, that when people go back to the origins, they find a founder who was violent, teaching violence.

### Conspiracy Advocate (CA)
Claim: See, this comes back to what you mean by people going back to the origins. And I refuse, as does Zeba, and as we're asking for all of you to do, is to refuse for Islam to be hijacked and monopolized by the Bin Ladens of this world who want to tell you what it means to go back to the original sources. Now, if that was the case, then I ask you why is it that in Bangladesh, where there was a free and fair election, the Islamist party lost roundly. They completely lost the elections. In Pakistan, where there were recent elections, the Islamist alliance in the north that came to prominence after the occupation of Afghanistan, they completely lost all their seats. So the Muslims in two of the most populous Muslim majority countries in the world, as like as is the case in Indonesia, whenever they have a chance to vote, they do not vote for the Islamist extremists. And time and time again in elections across Muslim majority states, they have proven that their interpretation of Islam-- and they are the majority-- is not the interpretation of Douglas, Ayaan and bin Laden. Now, I don't want to be in that camp.

### Moderator
Claim: All right. I want to take a little break and move on to the topic and the status of women in Islam.

I'm John Donvan of ABC News. This is an Intelligence Squared U.S. debate. We are at the Skirball Center for the Performing Arts in New York City. Our motion is “Islam is a religion of peace.” We have two teams of two. Arguing for the motion, Zeba Khan and Maajid Nawaz. And arguing against the motion, Ayaan Hirsi Ali and Douglas Murray. One of the-- here in the West, one of the issues that is very complicated for people in coming to terms with what they think Islam is, is the status of women in Islam. I'd like to go to Zeba Khan. Take that on. You know what I'm talking about.

### Conspiracy Advocate (CA)
Claim: The perception is that for a lot of people looking at the Muslim world in Muslim majority countries is that Muslim women are somehow-- they aren't-- they're subjugated, that they don't-- to a point where they are intimidated to ask for their rights and to demand them. But that's not the case. I mean, when you look at all-- when you look across Muslim majority countries, if you look at Iran, for example, where there is zero gender gap in education, by the way-- men and women enjoy the same amount of education. Obviously when you're at that level of education, you're aware of what your rights are and what you are demanding. And so in Iran and places like that, they are demanding their rights, they are pushing for them. In places like Afghanistan or Pakistan where the gender gap is larger, that gap obviously needs to be filled. But there are women who are pushing there as well. It's women that are stepping up and taking the lead on this.

### Moderator
Claim: Other side response? Ayaan Hirsi Ali.

### Scientific Advocate (SA)
Claim: Well, when I tried to define Islam as a religion, religion there is expression, you find in the Koran is expression after expression, verse after verse, and also in the Hadith, that women are subordinate to men, that they have a guardian-- they need to have a guardian, their testimony is worth half of that of men, they can only inherit half of what their brother inherits. When it comes to sexual offenses, women are the ones who get-- in reality, where Sharia is implemented, and that is not only the practical side of Islam but also the fellowship side of Islam-- everywhere where Sharia is implemented, and there are more places in the world today where Sharia as a family law is implemented and where it's not implemented on a political level, but in all of those places you see a subjugation of women. You see honor killings. You see women who are denied education. If you look on a global level, levels of illiteracy among women in the Middle East is appalling. That's not something that I'm telling you because I misunderstand Islam, but that is report after report, and the latest one is the United Nations, the UNDP Human Development Report that was first published in 2002 and was again published in 2003, 2004.

And if you follow these reports, this is empirics-- this is not something that I'm imagining-- the situation of women in the Middle East in Muslim countries is dire. And the principles that underlie it and the practices are Islamic, it's Sharia law in action. And the appalling-- the nightmare is women who have fled those countries who are now in the West-- American citizens, European citizens, are subjected to parts of Sharia law. And Zeba, I think that denying that-- not just as a matter of debate but, I then try to question, "Where does your solidarity lie as a woman who grew up in a free country, a free woman, and as vocal as you are, shouldn't you be more solidaire with them?”

### Conspiracy Advocate (CA)
Claim: I am.

### Moderator
Claim: Zeba Khan.

### Conspiracy Advocate (CA)
Claim: I am. But I don't want to-- I absolutely am and as all women should be and all human beings should demand the rights of equality. In fact, most Muslims want equal rights for the women in their societies, and just go to the research, go to the polls, go to the research and what it says. When you ask men, "Should women have equal rights?" majority in countries surveyed in the Gallup survey said, "Yes, they should have equal rights," including in Saudi Arabia.

### Moderator
Claim: Maajid Nawaz.

### Conspiracy Advocate (CA)
Claim: I want to acknowledge that there-- a lot more needs to be done and a lot more needs to be said about eliminating some of the practices that you referred to, Ayaan. And I recognize that there are practices in Muslim majority societies across the world that are repugnant not just to a Western mind but generally to any decent rational human being. But I'm going to approach this being a man, and the first man on the panel to call in on this question, I want to approach this from a slightly different angle, and that is this, that many of you in the audience are men, and if the law of average was to fall true, then you'd be probably around 50 percent. Now, how many of you would be comfortable with your spouse, your wife as your boss at the same time? And it may sound-- you know, it may actually be a truism because for many people in a marriage the boss is the wife, but - - the reason I'm asking that question is that even in times like today, many men find that uncomfortable, to be married to their boss, and yet Ayaan, who referred to these practices that were repugnant to us and said that they are sourced in Islam, the founder of Islam, the prophet, Mohammad, his boss-- his first wife was his boss. And many people don't know that. And so what I want to demonstrate by this point is that it's a complex matter. There are practices in Muslim majority societies that we need to reform, but it's too simplistic to trace them back to the life of a man who lived 1,400 years ago. And in many of these practices, what's quite revolutionary for his time, and in others was like every other man during his time.

The fact that he referred to-- Douglas refers to the fact that he had a bride that was underage, is something which we can now look back on and say, "That was an awful practice," but just as we look back on many things the Romans did and say that was an awful practice, just as we look back on many things Martin Luther did and say that was an awful practice, but we don’t judge these men by the standards that we have today.

### Scientific Advocate (SA)
Claim: Yeah, we do, we should. We should, Maajid, and may I say it’s a bit too cutesy to compare a man who raped a 9-year-old girl repeatedly with men being kind of, you know, kind of the wife, the bit of the wife being the master of the household and so on. A bit too cutesy. A bit too much of avoiding the issue, which is this. This is actually a very real concern which doesn’t just apply in mid-7th Century Arabia but today, here and now, in Britain, in my own country. We now have, thanks to an arbitration act put into law in 1990, whereby people can have civil disputes arbitrated under laws they can decide on. But we now have Sharia courts in Great Britain and Sharia courts in Great Britain are operated by people who are, actually, clerics, they are religious authorities. There’s one, well, Sadiqi in Leicester. Now this man runs a separate Sharia court. A couple of years ago it turned out that we found out about the sort of thing he was deciding, and sadly, again, it’s not reformist stuff, because when you go back to the Sharia, people take lessons from it and they make judgments like the following. Six women, six women who had gone to the Sharia court because they were being physically abused by their husbands, they were persuaded to drop the cases because this should be a matter between a Muslim woman and Muslim husband in a Sharia court. This should not be a matter for the police in Great Britain in 2008. That stinks.

What’s more, there had been another case. A local man, a local Muslim man, died.

His will was arbitrated by Sharia because that is what happens now in 21st Century Britain. And the arbitration of this man’s will gave half the inheritance to the daughters as to the sons of the man, because that’s what they have in the Koran.

### Moderator
Claim: Maajid said that he agrees with you that this stuff needs to change.

### Scientific Advocate (SA)
Claim: Yeah, the point is that when you look at the courts that are doing this, when you look at the religious authorities, when you look at the clerics the judgments they’re making, those are the kind of judgments. I wish that Maajid would get some clerics on his side who could set up rival Sharia courts that didn’t decide that women were second class citizens but sadly at the moment that is the case.

### Conspiracy Advocate (CA)
Claim: But Douglas, the irony was, as you know well, the person who came out most publicly in support of those regrettable Sharia courts in the U.K. was the Archbishop of Canterbury. And we at Quilliam opposed their creation, and actually many Muslims in Britain do oppose them because it raises a question. Islam has never had a clergy. It’s never had a pope. And so when you try and institute Sharia courts as law, the question arises, whose Sharia do you follow? Now that’s an internal debate that’s going on and raging and that I am part of in Pakistan for example, because there isn’t one version of Sharia and everything you’ve referred to is bad. We condemn these practices. The fact is we can’t call them-- we can’t be reductionist, essentialist, simplistic, and call it Sharia because there isn’t on Sharia as you well know, just as there isn’t one reading of Shakespeare.

### Moderator
Claim: I want to move on and when we come back we’re going to take questions from the audience.

All right, so we’re going to take questions from the audience now and if you raise your hand, what I’ll do is I’ll take a cluster of questions and then start presenting them to the panel. And I just want to remind you, if you get a microphone, please stand up and hold it about two-fifths away from your mouth so that the radio can pick you up. And please keep it as terse as possible. Right against the wall there, and blue shirt here, and eyeglasses. Three.

So, you get 30 seconds to ask your question. It makes me nervous that you’ve got something written down on a piece of paper.

### Moderator
Claim: Under 30 seconds. I promise.

### Moderator
Claim: All right. Go ahead.

### Moderator
Claim: Zeba, in your opening remarks you said that Islamic terrorists are motivated by politics, not religion. Considering that Islamic terrorists make up the majority of suicide terrorists in the world today, what’s happening to Muslims politically that isn’t happening to any other major religious group that can account for the disproportionate amount of terrorism coming out of the Islamic world?

### Moderator
Claim: Bingo. That was a good question.

### Conspiracy Advocate (CA)
Claim: Yeah.

Yes, that was a great question.

### Moderator
Claim: You’re number-- I’m going to take the questions and then you’re going to--

### Conspiracy Advocate (CA)
Claim: Oh, sorry.

### Moderator
Claim: Yes, yeah, I’m ready for you. Oh, I’m sorry. There, with the microphone.

### Moderator
Claim: Thank you. This has to do with the Muslim community’s reaction to suicide bombing. You stated there’s 1.5 billion Muslims and yet the silence of this community on suicide bombing, the justification, the rationalization, the wiggles from the community, from the religious community, from the Muslim states, Arab states and Muslim states, is something that, in the West, we find puzzling. How would the panelists react to that?

### Moderator
Claim: Thank you. And third question?

### Moderator
Claim: I hope this isn't too naive, but if religion is-- if Islam is not a religion of peace, is it possible for it to become one?

### Moderator
Claim: Well, I think that's a great question, actually. I was trying to get at that with the reform issue, but I just think you put it far more eloquently. So I'm going to take all those questions because I thought they were all good. Zeba, do you want to take the response to the first one, basically, why is the preponderance of terrorism-- the question you were saying-- is committed by Muslim extremists; why are we not seeing that happening from other groups?

### Conspiracy Advocate (CA)
Claim: So what I don't-- I can't say is-- I know that it's a complicated question. And so you have history involved. You have different factors that contribute to the answer. What I can say for sure, just based on looking at the studies that come out, is that the level of religiosity, the level of piety, of violent terrorists compared to mainstream Muslims is virtually there's no difference. So it's literally when you ask them how practicing they are, how often do they attend services, things like that, it's literally the same. So that can't be the distinguishing factor. What we do know, as I mentioned earlier, is when you ask them-- the one big difference is when you ask them what they fear the most, and they say their perceived idea of Western domination, which is very similar to what we hear from our opposition, a perceived fear of Islamic domination. And so when you compare that to the mainstream who just want to get a job and--

### Moderator
Claim: Would the other side like to respond to that question as well, or to the answer that you heard? And if not, we'll move on.

### Scientific Advocate (SA)
Claim: We'll-- I'll move on.

### Conspiracy Advocate (CA)
Claim: Can I just add something?

### Moderator
Claim: Sure. Nawaz.

### Conspiracy Advocate (CA)
Claim: I think just to add something, that it's-- the preponderance has a lot to do with the spread of a certain ideology that I refer to as Islamism that has arisen in the post-colonial context and that was exported to the Middle East through geopolitics. Now, what happened was that there was a need for a cause to resist against colonialism. And Britain was a secular liberal country. The cause of the ideology that the Arabs adopted, who were resisting initially, was Arab socialism, Baathism. And that morphed into Islamism, which owes much of its origins to Arab socialism.

And so what we find is that the spread of this ideology, pretty much like how post World War I Europe, with the identity crisis that emerged after the Weimar Republic led to the growth of fascism in Europe, with fascism in Italy, Naziism in Germany and totalitarian Stalinism in the USSR.

We see the same thing playing out post empire in the Middle East. So what it's related to is the spread of this ideology that has hijacked the minds of many young Muslims. And yes, Muslims need to do more to challenge this ideology. We are trying to convince them of that. But this is a very modern phenomenon. And I remind you, Khomeini is a modern phenomenon, and he created a revolution where he flipped Shiite theology on its head, as are the others, bin Laden, Sayyid Qutb, they are all modern phenomenon.

### Moderator
Claim: Okay, Maajid, you have awakened the other side on this topic.

### Scientific Advocate (SA)
Claim: Yes, because what--

### Conspiracy Advocate (CA)
Claim: Should have kept my mouth shut.

### Moderator
Claim: Ayaan Hirsi Ali.

### Scientific Advocate (SA)
Claim: Maajid, what you are saying is Islamism is invented by the British, Islamism has nothing to do with Islam. External, external, external, those poor Muslims who are seduced with the Koran and the activities of Mohammad, their own culture, their own convictions, their own history, they have-- you know-- they are only the victims. Ideas inspire. Ideas unite. Ideas people bring together. And Mohammad succeeded first and foremost in uniting a disparate Bedouin desert Arab group of people. And they unified, and they conquered. And when it worked, it was all Islam. When Muslims were successful, when they conquered lands, it was all great. It was Islam. Now that we are faced with this problem, it's Islamism. It was created by the British Empire. I just want for the other side-- I don't think we will ever be able to address this issue if we systematically refuse to acknowledge, and that is what that side of the panel is doing.

### Moderator
Claim: No. Ayaan--

### Scientific Advocate (SA)
Claim: --to-- let me finish it.

### Moderator
Claim: Yep.

### Scientific Advocate (SA)
Claim: --to systematically-- systematically refuse to acknowledge the flaws of Islam. I grew up as a Muslim. I left Islam. Why did it do it? Because I couldn't hide away from the blemishes. And I believe we can improve that. I can believe we can inspire young Muslims and the youth bulge-- there are millions and millions of young Muslim men under the age of 30.

That in itself is a source of violence.

### Moderator
Claim: I want to--

### Scientific Advocate (SA)
Claim: We can inspire them if we can only acknowledge that part of the problem is us, not just the British empire.

### Conspiracy Advocate (CA)
Claim: I'm not saying it's the fault of the British. If I was going to say that, I would have joined a very successful British law firm--

### Scientific Advocate (SA)
Claim: What has Islamism got to do with Islam?

### Conspiracy Advocate (CA)
Claim: I'm saying to you I would have been a lawyer, and I would have gone on with my life. I'm taking responsibility for that, and I'm trying to get others to take responsibility for the growth of Islamism within Muslim mind and challenge that. So no one's blaming the British, and no one's--

### Scientific Advocate (SA)
Claim: Islamism is not Islam.

### Moderator
Claim: The second question was on the topic of-- and you almost got to it in your last answer, Maajid. But the second question is where is the clear-cut, broad condemnation of terrorism from Muslim leaders?

### Conspiracy Advocate (CA)
Claim: So there have been many, many such fatwas or pronouncements against suicide bombings. In many cases, they're not reported. There does need to be more. However, I'll give you an example of why, in some cases, there aren't more. Now, recently, we at Quilliam publicized a fatwa by Dr. Tahir-ul-Qadri against terrorism, no ifs, no buts condemnation of suicide bombing and terrorism that Douglas-- always a pleasure to speak with you on the panel-- supported and was quoted in the press as supporting Dr. Tahir-ul-Qadri’s fatwa against terrorism. Now, the reason why there aren't many more such examples, though there are quite a few, is because prior to Dr. Tahir-ul-Qadri issuing this fatwa, his colleague, who was also from the same way of thinking, was assassinated in Pakistan, was killed by a suicide bomber in a mosque where all the congregants who were praying were also blown to smithereens because he had the guts to simply give a sermon in that mosque condemning suicide bombings.

And so this is why many people are scared, because it takes guts, I tell you, to go into Pakistan and try and challenge these extremists. That's a country that doesn't have much rule of law. It's a country that's struggling against the so-called Pakistani Taliban from taking over a third of their country. And they're fighting that fight on the front lines. And there are those who are brave enough just to give a speech to condemn terrorism, and they're blown to smithereens in their mosque while praying.

### Scientific Advocate (SA)
Claim: Maajid.

### Conspiracy Advocate (CA)
Claim: And surely, they're religious people. They were praying in a mosque. You did support that fatwa.

### Scientific Advocate (SA)
Claim: I did. It's the only time I've ever done a book review of a fatwa. The-- I'm sorry to say, Maajid, you seem to have just proved our point.

### Scientific Advocate (SA)
Claim: Yes.

### Scientific Advocate (SA)
Claim: Am I--

### Conspiracy Advocate (CA)
Claim: Please explain.

### Scientific Advocate (SA)
Claim: Is it-- I mean, this is a very important and a very interesting question why more people don't stand up. I much admire Tahir-ul-Qadri for that fatwa, as I have other people who have stood up. For the number of times I have spoken behind closed doors and so on, and you say, why aren't you saying anything, they say because if I do speak up, I'll be killed. Well, I address you again, ladies and gentlemen, to the motion.

### Conspiracy Advocate (CA)
Claim: I'm sorry. Sorry. Hang on. Hang on. How on earth-- how on earth does fear of being killed in Pakistan by a minority faction of extremists prove Islam is not a religion of peace?

### Scientific Advocate (SA)
Claim: Well, let me put it this way-- let me put it this way then.

### Conspiracy Advocate (CA)
Claim: It takes-- no, sorry. Sorry. I've got to-- because really, what you just said is really quite absurd. And I've got to clarify. It takes one person to kill all of us here, one person in a suicide bombing. Now, if we were scared of saying what we're saying now because of that one person, it doesn't mean all of us love war and hate peace in any way whatsoever. It means we all fear that one person who could walk through that door with a suicide bomb jacket strapped to his chest.

### Scientific Advocate (SA)
Claim: But Maajid, if we were discussing--

### Conspiracy Advocate (CA)
Claim: That's an absurd argument, Douglas.

### Scientific Advocate (SA)
Claim: here tonight, does anyone think that when a Quaker said, I am quite fearful about speaking up against certain things, and I say-- come on, this only happens with Islam. There is no other major faith in the world today--

### Conspiracy Advocate (CA)
Claim: For that to be true--

### Scientific Advocate (SA)
Claim: Where it is the case that people are fearful of addressing religion because they're afraid they'll be killed.

### Conspiracy Advocate (CA)
Claim: For that to be true--

### Scientific Advocate (SA)
Claim: It's only Islam. And we're saying there's a reason.

### Scientific Advocate (SA)
Claim: I'm afraid of being killed by apostates. And many of you who came here tonight came under unusual circumstances. I am not in government. I am not a powerful person. I am a citizen. I mean, just a normal ordinary--

### Moderator
Claim: Can you explain what you mean by unusual circumstances?

### Scientific Advocate (SA)
Claim: Unusual circumstances. You went through metal detectors to come to a debate in New York.

I mean, talk about

### Conspiracy Advocate (CA)
Claim: That's because it takes one person to get through those metal detectors and blow us up.

### Scientific Advocate (SA)
Claim: Let me finish. Let me finish.

### Conspiracy Advocate (CA)
Claim: It doesn't mean the majority of people are terrorists.

### Scientific Advocate (SA)
Claim: Let me finish. Let me finish. The people that I am protected against, and you as an audience, too, the individual who wants to kill me because I am an apostate of Islam is in inspired to do that from the scripture of Islam, the example of the prophet Mohammad, the clergy that preached to him and the reward he will get in the hereafter that is promised in the Koran. All of that is Islamic. The sooner you admit that--

### Conspiracy Advocate (CA)
Claim: I'll tell you what he's inspired by--

### Scientific Advocate (SA)
Claim: --the sooner I can get rid of my bodyguard.

### Conspiracy Advocate (CA)
Claim: He's inspired. I'll you what he's inspired by--

Right.

### Moderator
Claim: wanted to have the last word on this point because I want to go back to the young lady's question.

### Conspiracy Advocate (CA)
Claim: Sure. So I He's inspired by the very same interpretation of Islam that you have. He's not inspired by Islam. He's inspired by your interpretation of it that is Bin Laden's interpretation of it.

### Scientific Advocate (SA)
Claim: I'm sorry--

### Conspiracy Advocate (CA)
Claim: And I'm got to say one last thing.

### Scientific Advocate (SA)
Claim: No. Wait, wait, wait.

### Conspiracy Advocate (CA)
Claim: nothing.

### Scientific Advocate (SA)
Claim: No, no, no, no.

### Conspiracy Advocate (CA)
Claim: The thing is you're not the one-- the only one on this panel, I have an al-Qaeda death threat on my head, too, because I'm saying what I'm saying. And what I am saying is that-- and I've been attacked in Pakistan physically for saying this-- what I'm saying is, enough to extremism, enough to terrorism, let's separate Islam from extremism and disempower the minority of extremists who are trying to hijack a good faith.

### Scientific Advocate (SA)
Claim: Of course, I mean, one of the points about it there is that one gets death threats. I mean, it's just an unfortunate thing

### Moderator
Claim: I think Zeba and I are going to leave

### Scientific Advocate (SA)
Claim: I think it speaks for itself. I hope no one threatens the chair.

### Moderator
Claim: Can you repeat the question that I liked so much?

### Moderator
Claim: If Islam is not a religion of peace, is it possible for it to become one?

### Scientific Advocate (SA)
Claim: My answer is yes, on condition that first of all Islam is not a religion of peace, and I hope that we've demonstrated here tonight that it's not.

Can it become a religion of peace? Yes, if a number of conditions are met.

### Moderator
Claim: But what is it, for all of the people who practice it peacefully?

### Scientific Advocate (SA)
Claim: But let me complete the condition--

### Moderator
Claim: But what is that faith that they're practicing, then?

### Conspiracy Advocate (CA)
Claim: --and not only practice it peacefully, but we--

### Moderator
Claim: That's the part that I'm not finding in your explanation.

### Scientific Advocate (SA)
Claim: Why are we having again, over and over again-- first of all, in my view no monotheistic religion because there is that divider between "We" and "They" and because when that unified-- when there are so many factors within every monotheistic religion that make it inherently aggressive, it's not only Islam, but there are a number of factors that in the 21st Century combine-- again, there is the history of militarism and the awareness of that, there is the victim status, there is the youth bulge, let's not forget that, there is the revival of that theology, the revival of the example of the prophet Mohammad, the investment in the hereafter. And you say a lot of people practice their religion in peace. What we know is that a lot of people are passive and actually not practicing their faith, are not practicing Islamic scripture--

### Conspiracy Advocate (CA)
Claim: Who are you to say who's practicing--

### Scientific Advocate (SA)
Claim: Let me finish-- let me finish--

### Conspiracy Advocate (CA)
Claim: --their faith and who's not?

### Scientific Advocate (SA)
Claim: --let me finish,

### Conspiracy Advocate (CA)
Claim: It's not for you to decide. I'm the Muslim, you're not.

### Scientific Advocate (SA)
Claim: But let me finish. Let me finish. You are not practicing-- you are not practicing, let me---

### Conspiracy Advocate (CA)
Claim: Really? Are you

### Scientific Advocate (SA)
Claim: No, but let me say, you are not practicing--

### Moderator
Claim: Let's hear what she says

### Scientific Advocate (SA)
Claim: wait a minute, I want to finish.

### Moderator
Claim: Please, let's hear what her point is.

### Scientific Advocate (SA)
Claim: You are not practicing Chapter 2 of the Koran, verse 191 and 193, "And slay them wherever you find them, and drive them out of places whence they drove you out, for persecution of Muslims is worse than the slaughter of the nonbeliever."

### Conspiracy Advocate (CA)
Claim: Chapter 2, "Let there be no compulsion in religion."

### Scientific Advocate (SA)
Claim: You are not-- you are not--

### Conspiracy Advocate (CA)
Claim: Chapter 2, "Each community--"

### Scientific Advocate (SA)
Claim: Yeah, okay, what is that-- okay, great, I love that.

### Conspiracy Advocate (CA)
Claim: "-- which has given direction as it follows, all of you compete in the performance of good deeds."

### Scientific Advocate (SA)
Claim: Which proves my point

### Moderator
Claim: This could go on for a long time--

Let me one person speak at a time and you will come back--

### Scientific Advocate (SA)
Claim: That proves my point. If you read the peaceful--

### Moderator
Claim: Start again because I was talking.

### Scientific Advocate (SA)
Claim: That proves my point. If you read from the Koran and you say it's a religion of no compulsion and you believe that that verse is practiced by a person like you, you will concede that there are other Muslims who will read the verse that I just quoted and be inspired to engage in acts of violence. And, by the way, the verse that you just said, it has a latter part that says, "Except for the unbeliever--"

### Conspiracy Advocate (CA)
Claim: Sure, I'm sure every

### Moderator
Claim: Let's after this.

### Scientific Advocate (SA)
Claim: well, my last point was that it is both, it's not just a religion of peace, it's also a religion of war, and both verses prove that.

### Moderator
Claim: Okay, do you want to respond to that, Zeba, or do you want to--

### Moderator
Claim: Okay, Douglas.

### Scientific Advocate (SA)
Claim: And that is an important one. Ayaan and I and people who make some of the points we make are often accused of taking bits of the Koran out of context. But I think you've just seen a very good example of it from the other side. I'm not saying that that isn't a good verse to live one's life by. One cannot just simply quote the verse about there being no compulsion in religion as though it doesn't have a follow on--

### Conspiracy Advocate (CA)
Claim: And you can't quote the other ones either without context.

### Scientific Advocate (SA)
Claim: It has a follow on.

### Scientific Advocate (SA)
Claim: --as though it doesn't have a follow on, and as Ayaan has just showed you, it has a follow on.

### Conspiracy Advocate (CA)
Claim: Yeah, so do those ones, as do those ones.

### Scientific Advocate (SA)
Claim: So I think this gets back to the very important question the lady halfway back there made which is whether or not this can be a religion of peace. I believe it can be, and when I said earlier there are three types of Islam I identified. There's the first one, the scriptures, the light from Mohammad and so on, bad. Second one, Sharia interpretations, bad. But, thirdly, the way Muslims live their lives today in this country and countries like it, that is our source for hope, and the source of hope for that is they individually use-- like many people do really, I'm not a religious person. Ayaan isn't either. But we recognize the fact that people of religious faith have the right to that faith, should practice that faith, should have no fear of practicing that faith. There's no problem with it. But it's a private matter, and one which people come to very strange private arrangements about.

And I just wanted to add this, which is that if those people are going to be able to reform that faith into a religion of peace you’re talking about. Then, yes, we would be the first people to encourage that. But if we’re going to have that debate, as I hope we’ve shown tonight, it has to start with honesty.

### Moderator
Claim: Let’s do one more round of questions. Dana, do we have time for one more round? Yeah. So I’m going to do it again. I would love to hear from an audience member who is a member of the Muslim community if you feel like speaking. And not that I’m profiling but I saw a lot of blond people raising their hands. And again, I realize it’s a complex world.

### Scientific Advocate (SA)
Claim: That kind of profiling is allowed.

### Scientific Advocate (SA)
Claim: Jihad Jane was blonde.

### Moderator
Claim: All right. I’m going to take someone from the left. Yes, blond person, you can go. Anybody from the-- yeah, okay. Okay, go ahead. And then on the right side, yes. Okay. Ma’am, I see you. Yep. And again, remember the way that great question was phrased? That’s how you do it.

### Moderator
Claim: So for those in favor of the motion, my question is-- what she just read from the Koran. You didn’t agree with it and clearly you’re interpreting the religion as you will and in a very peaceful way, which is great, but do you ignore those parts? How do you react to it? You said there were multiple ways, just like we interpret the Constitution, there are multiple ways of interpreting what the Koran is saying. I just want to know exactly how you interpret that chapter she just read to us.

### Moderator
Claim: Thank you.

To that end, I happen to be Roman Catholic but my wife is Israeli and my son just went through his Bar Mitzvah. There is some pretty spicy stuff in Leviticus. I had no idea.

### Scientific Advocate (SA)
Claim: But then Catholicism went through the reformation and enlightenment.

### Moderator
Claim: I’m from Pakistan. I’m a Muslim from Pakistan and I just want to comment on the suicide bombings. There’s one almost every week and if you feel that as a nation, after being destroyed repeatedly since 9/11, we would still be sympathetic to extremist sentiments when our, you know-- two of my students were killed in suicide bombings.

### Moderator
Claim: What is your question?

### Moderator
Claim: My question is, I want you to consider what the value of the socio-economic, cultural factors, political dictatorships, what role do those factors play in making young people susceptible to extremism?

### Moderator
Claim: Do you not feel that Maajid covered that in his remarks, because I feel that he did?

### Moderator
Claim: Well I don’t think maybe the audience understands.

### Moderator
Claim: Let me put it on hold then. And then the third person?

### Moderator
Claim: I have a question for Ayaan Hirsi Ali. I’m a Muslim woman and she was referring to the subjugation of women. This has to do with the subjugation of women. I’m from India and my question is, if women are not educated, you know, in a lot of Muslim countries, that’s the problem. Women are not educated. And when they’re not educated, they don’t know what their rights are and so they’re not going to demand their rights. That’s the whole point in not educating half the population. But my question to you is, what does that have to do with Islam, because according to my understanding of the Koran the first word that was revealed of the Koran to the Prophet Mohammed was read. That has to do with education. And the Koran--

### Moderator
Claim: So, can you give me a question in one sentence?

I know you can, so go for it.

### Moderator
Claim: My question is, what does this have to do with Islam? Because the Koran doesn’t say that, according to my understanding. Does it say educate men, do not educate women? No where in the Koran have I found that.

### Moderator
Claim: Let’s take that last question first, Ayaan.

### Scientific Advocate (SA)
Claim: Thank you so much for that question. I completely agree with you that women in the Muslim world today-- not all of them, but most of them-- are denied education. The reasons that are given by those who do the denying are Islamic. They refer the concept of guardianship, so the guardian has the authority to decide whether he sends a girl to school or not, and for how long she goes to school. The main reason in Muslim countries where girls are sent to school-- Muslim communities where girls are sent to school, the main reason for pulling them out at the age of menstruation is the fear, the terror, that they might lose their virginity. That modesty, sexual modesty that is demanded of girls, which at first it preceded Islam, was a tribal Arab culture, elevated to religion in Islam, where people find, within the Koran, that-- and the hadith, that insistency on her virginity, on her being a virgin on the night of her wedding, that is one of the main reasons that is given. And if sexual emancipation were to occur within the Muslim world-- and I want to challenge a guy like Maajid Nawaz to take the forefront as a man by saying that you value a partner, a human being, more than her hymen. That would revolutionize Islam completely. That would-- it would take-- girls would go to school. They would be independent. They would be able to articulate what their rights are.

And, more importantly, they could make Islam a religion of peace because they would bring their boys up to be employable, to be educated, and to pronounce suicide killings and martyrdom-- uneducated mothers, uneducated mothers are mothers whose children, whose boys, bad guys can take advantage of it.

### Moderator
Claim: We're at the point where normally we move on to our third round. We have these two questions standing out there. And I'm going to extend it, with everybody's acceptance, a few minutes of this section tonight. Nobody seems to be leaving, and no one's asleep. So Maajid, if you can be very brief to that, and then I want to get to the last question.

### Conspiracy Advocate (CA)
Claim: Well, actually, to be honest, I value a can of Diet Coke more than a hymen. I mean, really, everything's more valuable to me than a hymen, and especially a woman. So I really don't understand the point of your question there. But allow me to say, however, that every Muslim questioner from the audience today is not a true Muslim. And every one of you may be a Christian is not really a Christian. And any of you who may be a Jew is not really a Jew, because I have the absolute monopoly of defining all three of those religions for all of you. And, really, the passages that-- I'm saying this because of the first question. And that is, the passages that were referred to about fight them wherever you see them. Now, the thing is really, the founding fathers of this great country who wrote the Constitution believed in slavery and were practicing slavery. Now, does that mean that we're going to define the whole of America and its Constitution by that practice, or are we going to contextualize that practice and say that when they founded this country, slavery sand abolishing slavery was not at the forefront of their minds, but later on, it was abolished, and that's an achievement for this country. It's not something that defines this country.

And so likewise these passages, yes, they can be used, and they are used in a problematic way. And it's our responsibility, not just as Muslims, but as decent human beings, to go out there and challenge the abuse of these passages. But we must not forget that as if with every other document in history, it had its context, and it was abused.

And now when we have gone ex post facto, we can look back to that and judge it with a very civilized standard that we've arrived at and say that was wrong. Now, perhaps--

### Moderator
Claim: And let me put the question-- let me put that--

### Conspiracy Advocate (CA)
Claim: I may be defined

### Moderator
Claim: I want to put the question as it was phrased to Zeba, which was how do you filter out--

### Moderator
Claim: Right, exactly. How do you filter that out?

### Conspiracy Advocate (CA)
Claim: So how do I interpret is what you're asking. Despite what our opposition says, I do have that right. And basically, I look at my faith-- I'm sorry. Who asked the question? I look at my faith and the way I was raised with core Islamic principles, which is how my family raised me, and that I determined as an adult were correct, which is compassion and tolerance and plurality and strength and diversity, because we are a diverse population. There are as many interpretations of Islam as there are people. And so the other point I want to make to that is that there are clergy and clerics who do stress this. I mean, if you look at 2005 at the Imam Message, where 200 Muslim scholars from 50 countries addressed a reemphasis of Islam's core values of compassion, mutual respect, acceptance, freedom of religion. There is precedent for this not just for me as a layperson but from the clergy as well, to reassert these lost-- in some areas, lost values.

### Moderator
Claim: Douglas Murray.

### Scientific Advocate (SA)
Claim: This is a very, very complex one. But it has to be said. Maajid has just given the comparison of the founding fathers, and there has to be some clarity about this. This country rightly reveres your founding fathers. But you don't think that their word was immutable or unchangeable.

### Conspiracy Advocate (CA)
Claim: No.

### Scientific Advocate (SA)
Claim: You don't believe-- I don't know. I don't think that anyone in this room who criticized Mr. Jefferson now here tonight, will be declared an anti-American apostate who can be fit for slaughter.

The problem that our opponents have to address, they have to address it, is that a religion which is based on the idea that the Koran was dictated direct by God to Mohammad and that therefore if you are criticizing the Koran or throwing out a bit or pulling it apart, like most Christians and Jews-- most Christians and Jews have come to that stage where pretty much you pick a mix with your holy scriptures. And it's quite a good, humane way around it. But with Islam, if this is the revealed word of God, revealed, it has to be said, as it was shown again earlier tonight in a particularly obscure and unreadable dialect, which-- if it was meant to be understood by the whole of the world, it's a bad place to start. If this were the case, then, as I say, we come back to this problem. Founding fathers did-- said many great things and did some bad things. But you are not committed as Americans not to criticize the bad things they did. And this is a problem our opponents are going to have address.

## Round 3

### Moderator
Claim: And that concludes round two of our debate. So here is where we are. We are about to hear brief closing statements from each debater. They will be two minutes each. And this is their last chance to change your minds and to respond to some of what's been said over the last hour. You will be asked to vote, once again, and to pick the winner, just a few minutes from now.

But first on to round three, closing statements. Our motion is, “Islam is a religion of peace.” And speaking first against the motion, Ayaan Hirsi Ali, a resident scholar at the American enterprise institute and a critic of fundamentalist Islam.

### Scientific Advocate (SA)
Claim: Islam is not a religion of peace. And I woke up to the facts on the 11th of September, 2001. Perhaps I should have woken up to the facts earlier. But I admit that I did that then at that time. Talking to people of my faith, Islam, and my friends, and discussing with them, I remember all kind of fallacious arguments.

But I remember one consistent thing, and that was to exempt Islam from any criticism. It was culture. It wasn't Islam. But a religion is born in a culture. And if that culture is not peaceful, then that religion is not peaceful. I was told it's politics. We've heard it tonight many times. It's not religion. But Islam not only has a pious dimension but it also has a political dimension, a complex system of laws, a political philosophy on how society should be organized. And if you look at that political system, it's anything but peaceful. What emancipated me from the order to submit my will completely to Allah, which in practice means the concentration of power in the hands of a few, was to learn to think critically, the enlightenment.

Vote against this motion and open up the flaws of Islam for debate in order that Muslims, those who are not yet emancipated, may take charge of their own reason, of their own faculty. Vote against the motion that Islam is a religion of peace and toss-- toss that fallacy into the trashcan of history. Thank you.

### Moderator
Claim: Thank you. Ayaan Hirsi Ali. Our motion is Islam is a religion of peace. Now to summarize her position for the motion, Zeba Khan, writer and advocate for Muslim American civic engagement.

### Conspiracy Advocate (CA)
Claim: Thank you. Faisal Shahzad, the underwear bomber, and the group of young men that were picked up in Pakistan, all of them were for violence and trying to attack our country and learning how to attack our country elsewhere.

But the one thing that the media consistently forgets to mention or conveniently forgets to mention is who turned all of them in. It was Muslims. It was their families, because that is a Koranic principle, that you stand up for justice, even if it's against yourself. And in this case, someone's son or several people's sons, the underwear bomber's father who was Nigerian and not American, did this, turned him in, and sent word to the authorities. And a Senegalese merchant was one of the first unreported, but was one of the first people to see the Times Square attempted bomber.

Our opponents have a very simplistic outlook on this-- on the world and what's currently at stake. They see it being Islam versus the West. But the truth is it's not. It's between moderates and extremists of all kinds. And I urge you to vote for the motion because the overwhelming majority of Muslims, the facts are clear, they are peaceful, they're mainstream, and they condemn violence against civilians and have no interest in terrorism, which is consistently as the woman in the audience said, are attacking Muslims, mainstream Muslims every day, brutally, and oppressing them because we don't accept their version of Islam. I'm asking for your help for-- as other people, as people of reason and of people of a moderate voice to support us as we fight them and we are fighting them, although we don't hear it as often in the media, which focuses on violence and fear. But the fact is, Muslims have always been fighting them.

### Moderator
Claim: Zeba Khan, your time is up.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Thank you very much. Our motion is, "Islam is a Religion of Peace" and here to summarize his position against the motion, Douglas Murray, bestselling author, founder, and Director of the Center for Social Cohesion.

### Scientific Advocate (SA)
Claim: Thank you. Well, thank you for a very enlightening, I think, debate tonight. I think we on this side made it very clear that we don’t think there's a fight between Islam and the West or Islam and civilization or anything else like that. We've made a very clear set of points tonight, and one of those points, which I hope people bear in mind, is we have said repeatedly that it is in Muslims and their critical faculties, Muslims and their behavior, Muslims and their faith that we have hope. And it is in people like you that we have hope for the future, and if the motion were that Islam a century from now could be a religion of peace and people would be quoting Zeba and Maajid and seminal moments like this and that they had learned-- well, that would be terrific, but at the moment, tonight, you're being asked to vote on whether Islam is now a religion of peace, is Islam a religion of peace? I think it is very clear that it is not. This does not mean-- of course, it doesn't mean that Muslims are all violent. We would never make that point. We never have made that point, nor does it mean that there isn't hope in the future, nor does it mean that we have to have continual clashes until the end of time, but it means we have to start by being honest. We have to be frank about what we see in Islamic history, in Islamic conquests, and in Islamic script. We have to be frank about that.

In societies which Islam dominated, conquered, and subdued the peoples in the Middle Ages, people who were not Muslim were sometimes allowed to remain in those societies but they were allowed to do so only by having second class status. I would ask you tonight, ladies and gentlemen, not to be dhimmis, not to have second-class status, not to vote for things because you think it's polite or because you think you have to say them but because you think they're true. On that basis, the idea you could vote for the motion tonight is absurd. Islam is palpably, demonstrably, evidently not a religion of peace. Vote against this motion. Thank you.

### Moderator
Claim: Thank you. Our motion is, "Islam is a Religion of Peace." And our final speaker to argue for the motion that "Islam is a Religion of Peace," Maajid Nawaz, Director of the Quilliam Foundation and formerly a member of a radical Islamist party.

### Conspiracy Advocate (CA)
Claim: Thank you. Right. So I'm not going to ask you to be polite. I would dread to think that that's why you'd vote for the motion. In fact, what I'd like to do is give you four reasons to vote-- basically four reasons why the panel's arguments are incorrect and four reasons then to vote for the motion. And as for the failure of the panel, I think number one is that there's a failure to contextualize. As I've tried to say time and time again, there's a failure to contextualize history and texts and sources, and there's an intellectual suspension that occurs when discussing Islam that simply doesn't occur when discussing the Constitution or any other piece of literature or writing. Secondly, there's a failure to disclose. And as we've heard from the panel, both of them-- and there's nothing wrong with this, by the way-- both of them are not believers of any faith, and that's their perfect right to do so, but they've made it clear their real agenda is with all religions. And I think we have to be honest with ourselves, that actually religions can and have historically played much good and have come to much good in the world, including the Reformation despite the fact we have to contextualize it. Thirdly, there's a failure to nuance, and as we've heard, gross generalizations about Islam by quoting isolated passages are being made. And fourthly there's a failure to be honest. And that honesty is in refusing to recognize that a vast majority of Muslims where there have been democratic elections have refused to turn in the extremists, as the examples I've cited in Bangladesh and Pakistan.

Now, please vote for the motion, and the reason I'd say that is reclaim Islam, don't let the minority hijack it. Yes, even for those of you who are not Muslims, reclaim it, because it's a faith like all other faiths that does need to be redefined in current times. Secondly, vote for peace. This is not a vote for Islam. It's a vote for peace. And I'm sure all of us want peace. And thirdly I'd say help the confused Muslims in the world, the factions, the minority, the young minds, like I was, who are confused, help them make up their minds by giving them guidance, by giving them an olive branch and voting for peace tonight.

And finally, I’d say that even if you’re unsure, even if you think that Islam is not a religion for peace, I would ask all of you hear tonight to vote as we heard the admission from the panel, it can be a religion of peace, so vote for what you’d like Islam to be. If you’d like Islam to be a religion of peace, then vote for it.

### Moderator
Claim: Thank you. And that concludes our closing statements, and now it’s time to learn which side you feel has argued the best. Sorry?

### Moderator
Claim: Okay, yes. Now it’s time to learn which side has argued best. We are asking you again to go to the keypad at your seat that will register your vote. We’ll get this read out almost instantaneously. Our motion is “Islam is a religion of peace.” If you agree with the motion, push number one, if you disagree, if you’re against the motion, push number two. If you’re undecided, push number three and we’ll have the results in about a minute.

Before we get there, I just want to say this has been probably the most spirited debate that we’ve ever had and I thought it was conducted mostly with respect and with honesty and I want to congratulate all of our panelists for coming out here. I want to thank all of you in our audience. The questions were all excellent, including, ma’am, the one I didn’t get to. I apologize. It was a time issue. But the questions were terrific and I want to thank all of you for coming through the metal detectors, which were a metaphor in a way for the situation that we’re in and the reason that we’re debating this topic. But you should give yourselves a round of applause for being here for taking part in this tonight. I want to let you know that our next debate will be on Tuesday, the 26th of October. The motion then is, “Big government is stifling the American spirit.” Panelists for the motion are former Texas Senator and vice chairman at UBS Investment Bank, Phil Graham, and Art Laffer, a former Reagan economic advisor who’s known as the father of supply side economics.

Against the motion, NYU Stern Business School professor, Nouriel Roubini and Laura Tyson who is a professor at the Haass School of Business at the University of California at Berkeley and a member of President Obama’s economic recovery advisory board. Individual tickets are still available. You can get them by going to our Web site and also upstairs at the Skirball box office.

Intelligence Squared is now on Twitter. You’ll find us at twitter.com/iq2us. You can follow us for announcements and interesting links and you can-- video of this debate you can find by following those links. You can use #iq2us and also you can tweet about what you thought about tonight’s debate and its results. And you can become a fan of Intelligence Squared U.S. on Facebook, and by doing so receive a discount on upcoming debates.

All of our debates as we’ve talked about are heard on more than 220 NPR stations across the country. Remember, as you stand, to turn your cell phones back on or you might miss important calls. You can also watch the debates on the Bloomberg Television Network. This debate will start airing next Monday at 9:00 p.m. It will be repeated through the week at that 9:00 p.m. time slot. Visit Bloomberg.com to find your local channel.

Intelligence Squared is now one of the most popular public affairs podcasts on iTunes, and you can download that and listen to past debates at IQ2US.

All right. It’s all in now. I’ve been given the results. Remember, the team that changes the most minds is declared our winner and here it is. Our motion is Islam is a religion of peace. Before the debate, 41 percent were for the motion, 25 percent were against and 34 percent were undecided. After the debate, 36 percent are for the motion and 55 percent against, nine percent undecided. Decides against the motion wins. Congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. End Time: ()
