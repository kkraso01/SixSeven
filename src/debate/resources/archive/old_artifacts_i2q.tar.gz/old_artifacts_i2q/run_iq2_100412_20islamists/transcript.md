# Debate Transcript

Topic: Better Elected Islamists Than Dictators
Motion: Better Elected Islamists Than Dictators

Debate ID: 100412%20islamists


## Round 1

### Moderator
Claim: All right, so ladies and gentlemen, let's get started. And to get to the "why now" about this debate, I'd like to welcome to the front seats of this stage the chairman of the board of Intelligence Squared U.S., Mr. Robert Rosenkranz.

### Moderator
Claim: Good evening, John.

### Moderator
Claim: Good evening. So what is at the heart of this particular debate tonight?

### Moderator
Claim: Well, I'm reminded of a quotation I always liked from John Kenneth Galbraith. He said that politics is the art of choosing between the unpalatable and the disastrous. And that indeed is the choice that we face in the Middle East, and it's the subject of this debate.

### Moderator
Claim: So we're looking at elected Islamists versus dictatorship. On the dictatorship side, what's the pro and the con on dictatorship?

### Moderator
Claim: Well, the pro of dictatorship is a lot of these dictators are fairly reliable allies of the United States.

The con is that they are greedy, that they stay in power with repressive means, intrusive security services, secret police, violence against dissent.

### Moderator
Claim: And the pro and con of the Islamists?

### Moderator
Claim: Well, the pro of the Islamists is simply that they are elected. And democracy is, of course, a core value of ours. But we think of democracy as liberal democracy. And what we see in the Middle East is what I might call-- what Fareed Zakaria called "illiberal democracy." That's democracy without freedom of speech, without free exercise of religion, without a clear rule of law and so forth that really represent our core democratic values.

### Moderator
Claim: And let's go to the "why now." Why now for this debate?

### Moderator
Claim: Well, John, two words: Egypt and Syria.

### Moderator
Claim: All right. Ladies and gentlemen, that's Robert Rosenkranz. Thank you, Bob. And that's the shape of our debate. you can just come through the side. And a round of applause once again for our debaters. And I'd just also like to invite one more round of applause for Robert Rosenkranz because he made all of this possible. Look what happens when we add three little letters of the alphabet together. I, S, as in sugar, M as in money, -i-s-m, ism. You take that word, and you'll pin it to some perfectly delightful and innocent sounding nouns, and you can end up in the middle of a political argument. Social, socialism; active, activism; sex, sexism .

You get the idea. When this happens with religions, it turns a religion into a political movement with a political agenda. And then you really have a debate as we do tonight, another debate from Intelligence Squared U.S. I'm John Donvan. Welcome. Our motion is this: "Better Elected Islamists Than Dictators." We have four superbly qualified debaters who have lived this issue for years from well before Arab Spring. And they will be bringing to you their arguments for and against this motion. Let's now meet our debaters. First, Reuel Marc Gerecht is a senior fellow at the Foundation for the Defense of Democracies. And your partner is Brian Katulis. He is a senior fellow at the center for American progress. "Better Elected Islamists Than Dictators" is our motion. And the team arguing against this statement, Zuhdi Jasser, who is president of the American Islamist Forum for Democracy. And your partner is Daniel Pipes who is president of the Middle East Forum. Our motion is "Better Elected Islamists Than Dictators." And let's meet our debaters one by one. Let's welcome first Reuel Marc Gerecht. That was one of those applause lines. The warmth of your reception overwhelms him, but I just want to do it one more time. Let's meet our debaters. Let's welcome first Reuel Marc Gerecht. And, Reuel, you are a senior fellow at the Foundation for Defense of Democracy. You are a former media specialist at the CIA's Directorate of Operations, now the National Clandestine Service.

You also have the distinction of having been on the very first panel of our Intelligence Squared series six years ago when the motion was, "We Must Tolerate a Nuclear Iran," and you were against that motion. In the '90s, you wrote a book about your own story. You wrote it under a pseudonym about your own story about getting smuggled into Iran. And for our radio listeners who do not realize that you're over six feet tall, question is "How does somebody so big sneak into Iran?"

### Conspiracy Advocate (CA)
Claim: Painfully. I was two inches taller back then.

### Moderator
Claim: On your side, also arguing for the motion, "Better Elected Islamists Than Dictators," Brian Katulis. He is a senior fellow at the Center for American Progress. You have been studying, Brian, the Middle East since your days as undergraduate. Actually you lived in Amman, Jordan, as did I a long time ago, but you were a Fulbright scholar. I was just a journalist. In the '90s you also lived in the West Bank, the Gaza Strip, and you were in Egypt doing work for the National Democratic Institution for International Affairs, and considering your breadth of experience and the depth of your experience as actually having lived there, did you ever see back then that something like Arab Spring could actually coalesce and happen?

### Conspiracy Advocate (CA)
Claim: Absolutely. It's like watching gravity take place. You have a young population there, and what we're seeing right now is the start of something that's going to unfold for years to come.

### Moderator
Claim: It was always going to happen.

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: All right. Our motion is, "Better Elected Islamists Than Dictators." And here to argue against that motion, I'd like to introduce Zuhdi Jasser. Zuhdi is a doctor. He specializes in internal medicine and in nuclear cardiology. For 11 years you were a medical officer in the U.S. Navy. You're a devout Muslim and founded the American Islamic Forum for Democracy in response to the attacks on September 11. Zuhdi, you are not the first person in your family to become a political activist. Where did the inspiration come from for you?

### Scientific Advocate (SA)
Claim: Well, it really came from my grandfather. My mom really used to say-- says actually frequently that it's in my genes. He was a businessman who was active and prolific in writing columns in Syria and was in and out of house arrest for doing so. And now we know the rest of the story of what's happening in Syria.

### Moderator
Claim: And you come by this honorably. Your partner.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Daniel Pipes, ladies and gentlemen. And, Daniel, you are president of the Middle East Forum. You founded it back in 1994. Now, you were set off to be a quiet college professor. You actually have two degrees in medieval Islamic history from Harvard. You wrote a book on colloquial Egyptian grammar. And academia beckoned, and yet, somewhere along the line you got into the Islam-watching game. What happened?

### Scientific Advocate (SA)
Claim: To put it differently, the university didn't want me. The university didn't want me because, as I like to put it, I have the politics of a truck driver.

### Moderator
Claim: All right, ladies and gentlemen, Daniel Pipes and all of our debaters. So this is a debate. This is a contest. These debaters are here to try to persuade you of the power of their arguments. And you, our live audience, will act as the judges. By the time the debate has ended, we will have asked you to vote two times, once before the debate and once again afterwards debate-- after the debate on the language of this motion, "Better Elected Islamists Than Dictators." Let's have the first vote happen now. As you come in off the street, before hearing any of the arguments, we want to know where you stand on this motion, "Better Elected Islamists Than Dictators." If you agree with it, push number one. If you disagree, push number two. If you are undecided, push number three. You can ignore the other keys. And if you push a key by mistake, just correct yourself and the system will lock in your last vote. Okay. That was a piece of cake. We will hold that result until the end of the debate when we have you vote a second time on the power of the arguments that have been persuaded. And the team that has changed its numbers the most in the course of the evening will be declared our winner.

So on to round one, opening statements from each of our debaters in turn. And speaking first in support of the motion, "Better Elected Islamists Than Dictators," Reuel Marc Gerecht. He is a senior fellow at the Foundation for Defense of Democracies. He served as a specialist in the CIA's Directorate of Operations and is the author of several books, including "The Wave: Man, God, and the Ballot Box in the Middle East." Ladies and gentlemen, Reuel Marc Gerecht.

### Conspiracy Advocate (CA)
Claim: It's a pleasure to be here. Last time I did IQ Squared in London, I actually laughed so hard during the debate, I pulled a muscle on stage. I will endeavor to be more restrained this evening. I also notice that it's impossible they didn't give me a glass of wine. In London you could actually drink wine will you did the debate.

So let me just say, one, it's an honor to be here with Daniel Pipes. I read Daniel's dissertation-- I think it was over 30 years ago now-- on slave soldiers, which actually is a very important and unappreciated part of Islamic history. Daniel and I have actually debated this issue years ago, when a little book I put out called "Islamic Paradox" came out. So it's good to be here with him again.

And let me sort of restate the resolution. I think what Daniel and Zuhdi are really saying is that better dictatorship forever than allow the Muslim common man, woman to elect Islamists in a free vote. Now, that's a pretty, I think, ironic position for them to take, because what they're essentially saying is they want to perpetuate the political systems which have allowed Islamic fundamentalism, including its most radical offshoots, jihadism, most famously al-Qaida, to actually grow stronger.

It is no accident that Islamic radicalism has grown enormously during the period of dictatorship, secular dictatorship, throughout much of the region. It has been jet fuel for that cause. The societies that have been ruled by dictators and kings with ever coarsening, I think, rigor have very-- have harmed their societies, have caused, more or less, an ethical collapse.

I mean, a good personal anecdote of this is when I was in Cairo and I was a student there at the American University of Cairo in 1980. I can say that not a single woman at that school was veiled. And that was a good thing, because they were babes. I mean, they were hot. I've never seen so many beautiful women in one spot.

And 20 years later, I think it's fair to say, under Mubarak, that probably 20 percent, or even more maybe, were veiled. Now, why is it the social composition of that school hasn't changed at all, these are women of the elite. Why would women of the elite actually start veiling themselves? Because they should be the ones who should embrace the dictatorship because it has allowed them certain social liberties that would not exist under an Islamist system. I think the answer to that is that they were protesting. They were protesting the political order. They were protesting the social order. They were protesting the ethical order, that it had become disgusting.

And I think if you-- it's interesting to then- to look North and look at where, I think, Daniel, and perhaps Zuhdi too, would once upon a time have said were the best hope for the Islamic world, and that would be Turkey.

All right? Because Turkey really had the model that everybody in the foreign policy community on the left and the right really liked. That was the model that you would have enlightened dictatorship. You have someone like Mustafa Kemal Ataturk. He would come in and, through force of arms, literally, change the society, create the social basis for a more liberal order, and, boom, down the pike you would have liberal democracy. Now, guess what's happened in Turkey? You haven't seen the triumph, actually, of liberals yet in the ballot box. For the last almost 10 years, you've seen the Islamist party win. As the elections became ever freer, as the generals moved off, guess who became the dominant party, the AKP, the Justice and Development Party, which is an Islamist-- I think Daniel would call it an Islamist party.

So what that ought to tell you is that under no circumstances are you going to create a liberal order in the Middle East without bringing along the faithful. You cannot have a dictatorship who will take the traditions of the past and will take the ulama, the religious scholars, and throw them in the dust bin or throw them in jail.

The only way you're going to get a more liberal order in the Middle East is through people of faith. It is through the fundamentalists participating in the system that you're actually going to develop the jousting ethic that is going to allow liberals to have greater chances. It's only through them participating that you're going to have people become responsible for politics. Now, Daniel – another good book that Daniel wrote was actually about conspiracy. And if all those who know the Middle East at all, you know that the Middle East is hobbled by conspiracy. It's known as toovtdie In Persian, they call it toovtdie jewy conspiracy mongering, searching for conspiracies. It is literally, as Daniel would tell you, it's a cancer on society. Now, why do they have that? They have that because the political order is dictatorial.

It is what-- everything that is important that happens happens, as the Iranians say, pushte powde it happens behind the curtain. Only by people becoming responsible, by having, as they say in the Arabic and in Persian, masuliat can you drive away conspiracy, can you create a more healthy order. There's no way you can have that under dictatorship. You are always going to have dependent people. You're always going to have people who are ridden with conspiracy. So if you want to create that order, perpetuate that order, what Daniel is in fact saying is he's going to create an order, there's going to be more conspiracy. It is you have to bring in some type of Democratic system and allow these people to evolve. And they might also say evolution is not possible with Islamists. Well, we know, at least looking in the case of Iran-- and we don't know yet what's going to happen in the Arab world. We don't know what's going to happen in Egypt. We don't know what's going to happen in Tunisia. But we can tell that in Iraq under a theocracy, under a dictatorship, there has been a profound change that you have fallen revolutionaries everywhere.

I do not have time to go into the number of them, but it is an ocean. It is a tidal wave of people who were once hard core Islamists who have abandoned the faith or who have evolved their faith and have become pretty profound Democrats, if not liberals. They still exist in the dictatorial society. But they are-- you have seen the explosions in 2007. You saw them in 2009. You saw it in 1997, Mohammed Akbi So I suggest to you if you want to see evolution, you cannot be in favor of-- create a dictatorship which can only promise you stagnation. Thank you.

### Moderator
Claim: Thank you, Reuel Marc Gerecht.

Our motion better is "Better Elected Islamists Than Dictators." And here to argue his position against the motion, Daniel Pipes. He is president and founder of the Middle East Forum which publishes the Middle East Quarterly and sponsors Campus Watch, Islamist Watch and The Legal Project.

He's the author of 12 books. And his biweekly columns are read around the world. Ladies and gentlemen, Daniel Pipes.

### Scientific Advocate (SA)
Claim: Thank you, John. And let me return the compliment to Reuel. I learned much from his books on Iran and particularly the book that was alluded to before his entry, his smuggling-- being smuggled into Iran. He has certainly got us off to a rousing start. Now, the good news, ladies and gentlemen, is that we basically agree on the fundamentals. None of us like dictators. We all want liberal democracy. None of us like conspiracy theories. So the question is not one of principle. The question is really one more of tactics. How do we achieve liberal democracy in the Middle East? And as you've just heard, the argument for elected Islamists is that this flushes out the system, and you have responsibility, and you have progress. I will argue the opposite case, not because I'm against responsibility and progress but because I think that the Islamists, whether elected or not, whether violent or not, Islamists of any sort whatsoever are barbarians, are totalitarians, are far worse than dictators.

You're not going to look to me to find an apologetics for dictators. They're execrable, they're horrible, they're brutal, they're miserable. But the Islamists, elected or not, are even worse.

One can distinguish between those dictators who are greedy. In fact, Robert Rosenkranz used that very word before. They're greedy. They're interested in their own welfare. They have huge amounts of money stored away. They invite Mariah Carey in to sing their birthday song. They keep pet lions in their backyard. They have lots of cars and planes. It's the good life. They're greedy.

And in the pursuit of this greedy goal, they are going to harm you if you get in their way. But if you don't get in their way, they'll leave you alone. They don't have a vision. They don't particularly cooperate with each other. And they often do cooperate with us because they don't have any particular hostility towards us so long as we don't get in their way. Now, that's bad. There's no apology from me on that. But the ideological dictators, be they fascist, communist or Islamist are far worse because they wish to impose their vision. They wish to create a global hegemonic state, in this case, Caliphate, another case, an international communist state or Nazi state. They have a vision for the new human being who they will redo. And if you get in their way, they will-- even if you don't get in their way, if you disagree with them, they will be brutal with you.

And if dictators are bad and kill thousands, ideological dictators, Nazis, communists and Islamists kill millions and even tens of millions, tens of millions. Mao, Stalin, Saddam Hussein and so forth. These are people with a vision how they're going to change society. So I argue that we're better off with plain old greedy dictators who can evolve, who do evolve if they're pushed, who are not that terrible to their population, who we can work with. We're far better off with them than we are with the ideological ones. So in short, the motion that's before us, "Better--" if you agree with this motion, "Better Elected Islamists Than Dictators," you are in effect saying that you also agree with the idea that the motion, "Better Elected Nazis Than Dictators.” Adolph Hitler was elected, was he not? These are the same people. These are totalitarianists.

These are people who will limit freedom for a much longer period of time. Now, it's true, as Reuel pointed out, that in 1980, one did not see the Islamist surge in Egypt that one does today. No question. And I agree with him that the dictatorship was part of it. I wish that our government and other Western governments had pushed Hosni Mubarak to open up. And I believe we could have had a quite different outcome had we done so. We were irresponsible in being his colluders, his accomplices. We should have been pushing towards civil society. We should have been pushing towards voting and freedom of expression and minority rights and independent judiciary and loyal opposition. We should have been doing all those things, and we didn't. And thus we have the terrible results we have. So my first premise, my first guideline for American policy is always deal with dictators and push them in the right direction towards an open society.

Secondly, always support our friends. We do have friends. We do have people who agree with us. Be they the demonstrators in Iran in June of 2009 who were against the dictatorship of the Mullahs or the people in Tahrir Square last year who were against Mubarak. If you listen to them, they're in favor of the things we have. They want democracy. They want civil society. They want responsibility. And it is our burden not only to help them materially but to help them morally, to work with them, to always, always help them. Even though they're far from the corridors of power and will not achieve-- will not reach rule any time soon, they are the hope for the Middle East. They are the ones who can pull the region out of its current mire, and we must always support them.

So one, work with dictators, but push them towards civil society and democracy. Two, always help the liberal elements. And three, always, always, always oppose the Islamists. They are our worst enemy. And whenever they come in, they are our enemy, and they are the enemy of the subjects that they rule over. And Reuel mentioned Turkey. Yeah, Turkey has become Islamist, as he mentioned. For the last 10 years, one sees a Turkey which was always imperfect under the other parties, has under the AKP become far more dictatorial than it had been for, far more hostile in its foreign relations with state actors, states on its peripheries, has the largest number of journalists in the world that are in jail and the like. So in short, if we want to get to liberal democracy, which we all agree upon, the thing to do is to work with the dictators and improve the dictators and slam the door on the totalitarians and the ideological dictators.

Work with the greedy dictators and slam the door on the ideological dictators who will put the region into even worse shape than it is today. Thank you.

### Moderator
Claim: Thank you, Daniel Pipes. A reminder of what's going on. We are halfway through the opening statements of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two fighting it out over this motion: "Better Elected Islamists Than Dictators." You have heard two of the opening arguments, and now onto the third. I'd like to introduce Brian Katulis. He is a fellow at the Center for American Progress. He has served as a consultant to numerous government agencies, private corporations, non-governmental organizations, on issues related to the Middle East and South Asia. Ladies and gentlemen, Brian Katulis.

### Conspiracy Advocate (CA)
Claim: Thank you. It's really great to be here tonight, and I can promise in this debate we're not going to talk about the debt, I'm not going to talk about my grandmother, I'm not going to talk about your tax rates, we've got a really juicy topic.

And I'm going to break it down into three main points, why you should vote in favor of the proposition and not against us. Number one, no dictatorship can maintain the status quo that we see in the Middle East right now. A vote for the proposition would be a vote to accept reality. A vote against the proposition is a vote to stick your headiu in the sand. Although I suspect much of the debate tonight will focus on the Middle East and North Africa, it's important to note that this region of the world actually represents a minority in the vast Muslim world. It's about 20 percent of the entire population of Muslims in the world. Six in 10 Muslims actually live in the Asia-Pacific region. Muslim majority countries like Indonesia and Malaysia have activist Islamist political parties and systems that work. So the debate over whether Islam and democracy is compatible is the persistent charm of an irrelevant question, one that's no longer relevant.

In the Middle East right now we're in the very early stages of a transition that I think will last for years. And a year and a half into these uprisings we've only seen four leaders fall out of about 19 or 20, depending how you add them up. And you've seen only serious infighting in the five or six countries, but you look at the crushing demographic political and economic conditions that these countries face, no dictator can hold that back. And I think you look at the political dynamics in places like Egypt and Tunisia, it's quite natural to see why Islamists did very well for reasons that were well explained. They were suppressed, and the debates in these societies were pushed to the dark corners of the mosques. And that debate was radicalized, and, yes, there is a threat from radicalized Islam. But it is the consequence of dictatorships, the very thing that if you vote against the proposition you will be voting in favor of that and continuing that sort of system.

It's simply not sustainable. Number two, elected Islamists will change in response to the politics. And I think tonight we'll talk a lot about statements that elected Islamists will say. What I'm focused on are the people, and I lived over there, and I understand that the basic needs, basic security, jobs, and other things will drive politics, maybe not in the early stages, maybe when things get a little rough they'll be a little ideological, but, by and large, Islamist politicians will be politicians, and we will need to support this long effort to actually push them to face the same pressures and constraints that other politicians face around the world. And the open debates that we have like the open debate we're having here tonight in Intelligence Squared, I think this forum is phenomenal. I've watched it now a number of times. And these sorts of open debates expose the voices of fear, expose the voices of hatred and demonization in ways that I think clarify.

And this is what these societies in the Middle East are just starting to experience. So, again, a vote for the proposition is a vote for the possibility of change in these societies. A vote against it, it's for the status quo, which, as we said, is unsustainable and has harmed us. Now, I hope we get into this debate over a liberal democracy. You talked about it a little bit early on. And certainly we shouldn't be naïve. There's a very real risk that if we simplistically define democracy as the ballot box and going to the ballot box, you could see Christian minorities, other religious minorities, women see their rights suffer. But my argument, again, against that and against the arguments of one man, one vote, one time, which is often brought up, is that that threat in the context of this debate tonight, the proposition you have to vote for or against, there's an inherent contradiction there, because if the biggest threat resulting from elected Islamists is a dictatorship that imposes upon the human rights and basic rights of individuals, you've got a dictatorship.

So at the core of the argument of our opponents tonight is that contradiction we need to deal with. Third point, elected Islamists, not dictators, will defeat the radical ideologies of groups like al-Qaida. Now, I think we've done a damn good job over the last three or four years going after al-Qaida, and I know that's a debatable proposition among a lot of people. But I think the targeted strikes and other things, that's a separate debate, which I hope Intelligence Squared has. But if you look at what's going on ideologically in the battle of ideas, al-Qaida, over the last three decades, essentially, has tried to build its ideological platform on two core pillars. Number one, tapping the popular discontent with dictators. Number two, anti-Americanism. That's a combustible mix, and breaking that, and having the people in the region break that, I think, is extremely powerful.

The fact that al-Qaida and its affiliates had virtually nothing with the removal of leaders in places like Egypt and Tunisia and the widespread calls for political reform and the battles that are still going, I think, is telling. The fact that Ayman Zawahiri, the head of al-Qaida, wrote a book attacking the Muslim Brotherhood for actually participating in democratic politics is telling. Looking ahead, it seems that al-Qaida's popular appeal, I think, will remain low, given that many of the protesters are out there supporting democratic reforms. People are going to the ballot box, the very thing that radical jihadists are opposed to.

So I'm going to close up here. I must say that we're faced with a great opportunity here. The popular uprisings in the Middle East. And, again, we'll probably focus on that, because it's the hot topic, and it's the most uncertain, and Reuel and I agree that there's no clear path forward. And I think we're probably going to have a couple of steps back.

We're going to see these countries fight with this all along. But tonight, if you vote against this motion, your vote is essentially saying-- remember those good old days when Muammar Gaddafi was in power in Libya? Remember those good old days?

Remember when he repressed and killed thousands of his own citizens, when he actually used the veil of Islamism at different times and passed laws in the name of Islam to try to establish his credibility? Remember Muammar Gaddafi used terrorists who actually bombed airlines and killed hundreds of Americans around the world, setting off the sorts of things that I think we're debating here tonight. Remember that? Then vote against the proposition. A vote for the proposition, is it a clear, certain proposition that we're going to see liberal democracy appear? I can't guarantee you that. But I actually think it's a better pathway forward than sticking with dictatorships. Thank you.

### Moderator
Claim: Thank you, Brian Katulis. Our motion is, "Better Elected Islamists Than Dictators." And our final debater against the motion, Zuhdi Jasser.

Zuhdi is the founder and president of the American Islamic Forum for Democracy. He is also a doctor and a former medical officer in the U.S. Navy. Ladies and gentlemen, Zuhdi Jasser.

### Scientific Advocate (SA)
Claim: Thank you, John. It's a privilege and honor to be here. And thank you, Mr. Rosenkranz, for your vision and this wonderful platform. Daniel covered the history and the choices before us in the Middle East. I'll give you a deeper, more personal analysis of, really, one of the terms that I think has been thrown around here quite a bit, but, yet, it doesn't seem that our opposition understands, which is Islamism. And this motion, I cannot tell you enough, as a Muslim and as an American, how important it is that we not get this wrong, because we're sitting right now at a tipping point in the Middle East, and if we get this wrong and we start to think, "Well, the Islamists are better than the dictators," we're going to then usher in even worse totalitarianism and dictatorship.

You know, one of the old sayings was that hope springs eternal. And certainly one of the American concepts we've always had is that we want to be hopeful; we want to see progress. But I'll tell you, as a Muslim, I'm insulted at people who believe that Islamism is progress for me as a Muslim, that somehow the theocrats and those with robes that memorize their scripture, that somehow know how to run democracy, when, in fact, it's an illusion. I think one of the things our opposition hasn't even begun to tell you is how they can trust one word that the Islamists tell them. They're deceptive theocrats who will do anything to monopolize and control our societies.

And I think one of the things our opposition seems to be doing-- and if you vote for this motion, you'd be basically voting for the fact that, somehow, they want you to believe that we support dictators. And that's not why I'm on this side. I'm on this side of this equation because Islamists are not better than dictators, because we have been sentenced to two evils in the Middle East: Islamic fascism and secular fascism.

They both supported one another. They fed off one another. They're one and the same. And for our opposition to tell you that, somehow, boom, the dictators exit stage left, and what you're left with is a spring that you can plant new plants and soil, and somehow that the Islamists, that somehow they come out of reform, is just hogwash. The Islamists are a product of dictatorship, as, actually, they said. So now, all of a sudden, we're going to put our hope for reform into not only people the people that came out of that environment, but people that have thrived in monopolizing and feeding off of a dictatorial mindset. But add one more very important component, a sense that they have a mandate from God, a sense that they know our faith. They know Islam, and they know how to put into place Sharia or Islamic law, and they will do it not only for their country, they'll do it for the 56 other countries in the OIC, the Organization of the Islamic Cooperation, and they'll thus do it for the world.

This is far more dangerous than a simple dictator. So you need to understand what Islamism is if you're going to vote for or against this motion. And once you understand that Islamism is no different than what our Founding Fathers fought against when we fought against theocracy in this country, you'll realize that fighting against theocracy is the only way to achieve liberty. And I as a Muslim who loves my faith and loves my scripture, if I want to see our societies-- I mean, listen, my family fought against dictatorship in Syria. We understand what it is. And you see it today with over 30,000 killed and hundreds of thousands of displaced. But American influence-- please don't underestimate the influence that America can have if we try to tip this equation one way or the other. And if you believe that there's a third pathway for Muslims and for all those minorities and women and others in the Middle East, then you must vote against this motion.

You must vote that Islamists are not better than dictators. They come from the same cloth. And Islamists actually-- actually are dictators on steroids. You know, ultimately, I think we have to remember that if you're going to vote with the opposition for this motion, you're going to believe that somehow you can have hope with Islamists. Forget what they say, forget what they believe. Forget what the mantra is of the Muslim Brotherhood. Forget what they are saying from their pulpits, what they are saying from the government. Forget that the OIC just last week gave us directions on how to deal with our own First Amendment that it's too critical of Islam and Muslims. Forget the fact that women have less and less rights the more the clerics get in control. Forget the fact that the minorities are ousted, the fact that the Jewish population and Coptics and others, the more Islamists get in control, the more minorities vacate the premises in those countries.

Somehow we need to divorce ourselves from the reality of what Islamists do and say that they're a gateway into a future of hope for the Middle East. That's certainly not a gate that I want to walk through. And it's certainly, I don't think, a gate that the people that are giving their lives in the Arab revolutions, in the Arab Spring, which are really just convulsions against dictators, the people that are marching on the streets are not doing that to be handed over to Islamists. And if they did-- if you vote for this motion, you are basically telling them that, okay, this dictator, this theocrat, because he uses religious language, is better for you. And we're going to help them. And by the way, if you believe in American credibility and soft power, American soft power in the Middle East is lower than it's ever been. The reason Secretary Clinton had tomatoes thrown at her car a few months ago was because the people of the Arab Spring saw us helping out the Brotherhood, saw us basically cozying up to the Islamists. And the Islamists did not win that election. They only got 25 percent of the vote, and then there was a runoff.

So remember the elections, that's the other part of this motion. We have to also look at what it means to be elected. The non-Islamists are divided into so many parties that the majority, 75 percent of Egypt and a majority of Tunisians did not vote with the Islamists the first time around. But then when a runoff happened, they ended up voting between the Islamists or the old dictators, and they wanted some kind of change shall and they ended up voting for the Islamists. So that's the other thing is, if you want to resign them to just two choices, both of which none of us want, I think ultimately you must vote for. If you want to give them a third choice, a third path, that being of liberty, I believe you should vote against. And you'll not see the Egypt Islamist President Morsi, for example, criticizing terrorist groups like Hamas or Iran or Saudi Arabia, even though he may give flowery language of parliamentary democracies and talking about women's rights, et cetera.

But yet when push comes to shove-- just a few years ago, he was a truther, a conspiracy theorist. Just a few years ago-- and just actually a few months ago, he's already met with the heads of Hamas and other radical Islamists. So this is a guy who's consolidating his power, not only in Egypt, but globally. Islamism is what pushes him to consolidate power globally. And I think this is why you should vote against the motion. Thank you.

## Round 2

### Moderator
Claim: Thank you, Zuhdi Jasser. And that concludes round one of this Intelligence Squared U.S. debate. So now we go on to round two. And round two is where the debaters address one another directly, and they take questions from me and from you in the audience. Our motion is this: "Better Elected Islamists Than Dictators." Arguing for the motion, we have Reuel Marc Gerecht and Brian Katulis. They have been arguing that you need to bring these guys into the political process because, number one, it's happening anyway.

Dictators are in free fall. They're doomed. These people are the political process. They represent the faithful. The faithful represent this community. And that once in power, they will evolve the responsibility of having to serve the needs of people and clothe and shelter them, will cause them to evolve, to separate into factions, and that their societies will gradually open. The side arguing against the motion, Daniel Pipes and Zuhdi Jasser are arguing that Islamists are-- cannot be reformed, that they are intolerant, they are barbaric, they are totalitarian, far worse than any dictator, that they are deceptive and will do anything they can to stay in power. I want to put to the side arguing for the motion a premise that has been brought up by your opponent, Daniel Pipes, essentially saying that the-- and these-- this team is clearly not pro-dictator. They're not celebrating dictatorship. They don't like it. They're talking about a lesser of two evils. And in making that argument, they make the case that at least dictators can be worked with.

It's a single individual, I assume is part of your argument. The U.S. may have leverage over dictators in some cases, that they can be worked with, and change can come about that way. And I'd like the side arguing against them in support of elected Islamists to take that on. Reuel Marc Gerecht.

### Conspiracy Advocate (CA)
Claim: Yeah. It's pretty hard to find an instance where you can find the United States successfully encouraging a dictatorship to evolve liberally in the Middle East. Daniel said, "I wish we had." Well, of course I wish we had. I wish we had taken the Shah-- had we put more pressure on him so he could have evolved and developed elections so you wouldn't have had a revolution. I mean, I just have to say this, Daniel's premise is that by the mighty hand of the United States, we're going to discover these hidden liberals in the Middle East. And suddenly, through America's nurturing, these liberals are going to come forward and defeat the people of faith.

I just don't-- that's not the Middle East I know. It makes no sense whatsoever. You cannot import into the Middle East liberal ideas and liberal codes of justice, Swiss legal codes and create liberals. It has to come organically.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: It has to be through the ballot box.

### Moderator
Claim: Daniel Pipes.

### Scientific Advocate (SA)
Claim: But we did do that. We did that in Turkey, for example. We pushed the Turks away from the autocracy that they had in the '40s towards the pretty good democracy of the 1990s. And we've done it around the world. I grant you--

### Conspiracy Advocate (CA)
Claim: And who won the election?

### Moderator
Claim: Marc, let him finish.

### Scientific Advocate (SA)
Claim: --we've done it less in the Middle East than elsewhere. But let me mention, for example, South Korea or Taiwan or Brazil. There are many places around the world where we have done that. And we didn't do it in Egypt, and that's a big mistake we made. But Brian suggested that we're advocating for stagnancy. But I think you heard me loud and clear. And Reuel just quoted me. I wanted to push-- today I want to push in Algeria and Morocco and Saudi Arabia, I want to push.

I want them to open up.

### Moderator
Claim: But I think they're saying that-- that in this case in the Middle East, they cannot be pushed.

### Scientific Advocate (SA)
Claim: Of course they can.

### Moderator
Claim: Are you saying that they cannot be pushed successfully?

### Conspiracy Advocate (CA)
Claim: No, I think you can push. But let's just take Turkey. I mean, Turkey is the ideal. They elected an Islamist party. I mean, what would you have done differently in Turkey? As you just said, the 1990s created a more liberal order. Guess what happens? The people freely vote and bring in the Islamists. So I don't see-- if Turkey's not going that way, how is Egypt, which is far less Westernized, which has been much farther from the European tradition.

### Moderator
Claim: Brian, hang on a second. Zuhdi Jasser.

### Scientific Advocate (SA)
Claim: Yeah, you continue to use the old paradigm as if somehow all we have is to look backwards. And I think if there's any message from the Arab Spring, it's please stop looking backwards at the old and look at the new in that the Arab Spring was a grassroots revolution. It wasn't about the old either clerics or the dictators. There are new choices there. This was a Facebook revolution, YouTube revolution, Twitter. It was about communications on the ground.

The Islamists then hijacked the revolution. And now you want to hand it over to them as if there're no liberals on the ground. And I think it's insulting to the Middle East population to say that there're no liberals--

--that there're no liberals on the ground. I've read hundreds of those leaders and scholars. But they've just either been in jail or suppressed by both of the ones you want us to believe.

### Moderator
Claim: Brian Katulis.

### Conspiracy Advocate (CA)
Claim: Well, I think the notion that we could work with dictators today in 2012 and pressure them and things like this, it's quaint to me. It sounds like the Cold War. It sounds like a 20th century idea that worked back then but doesn't understand statecraft as it is today, doesn't understand power as it is today. And I think we see this on full display with our colleagues here who are debating against this motion. Zuhdi equated fighting against theocracy with fighting against elected Islamists. And I’ve got to tell you, there's a big gap between those two. And I also got to tell you that I think when I listen to them present their arguments, not only do they think that the people of the Middle East are foolish and will just listen to elected Islamists and reelect them blindly, I think they think you're foolish tonight because I think the biggest argument that could be made is---- and it's not about the leaders or what Morsi says and what he might not say-- when I see Egypt today, Egypt after Mubarak is an Egypt where there're multiple centers of power that are competing for this. And they're fighting with each other. And, yes, Islamists did well in the first round of elections. But guess what? I actually think in the next round of elections you're going to see even more competitive space here. You stick with dictatorships, you don't let Islamists go out there and make fools of themselves in the way that I think elected democracies open up that space--

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: --then we're going to have the same old, same old.

### Moderator
Claim: Daniel Pipes.

### Scientific Advocate (SA)
Claim: You see an Egypt that's got lots of contending centers of power. I see an Egypt where the Coptic population is increasingly being repressed, murdered, emigrating as it never has before. I see a population where women are being repressed as they never have been before.

I see a country where the Sharia, a medieval law code, is being dredged out and applied. And you call us "quaint"? You're advocating for a medieval code.

### Conspiracy Advocate (CA)
Claim: Can I--

### Moderator
Claim: Let me let Marc address that.

### Conspiracy Advocate (CA)
Claim: Yeah, I mean, one, the Sharia has been the rule of law for much of the Egyptian population all over the place for decades now.

### Moderator
Claim: Wait, can you-- one sentence, on what do you mean by that.

### Conspiracy Advocate (CA)
Claim: In the sense that the central governing structure had collapsed. It wasn't there. I mean, one reason the Islamic fundamentalists were to come-- able to come in and have such growth is because the social order from the central government, it just basically ceased to exist and also because there are a lot of Egyptians out there who don't have a problem with much of the holy law. And I don't think you get to take the holy law, as tried-- as you tried to do in other places in the Middle East, and just suddenly throw it-- Ben Ali tried to do it, just take it, throw it away-- you have to have it organically evolve.

There is no other way, and I think you will. I mean, you suggest with Mubarak that you could have nudged him. But every time we tried to nudge Mubarak-- and the American government did try to nudge Mubarak-- he would say, "If not me, then the Islamists."

### Scientific Advocate (SA)
Claim: So, Reuel--

### Moderator
Claim: Zuhdi Jasser.

### Scientific Advocate (SA)
Claim: --the way to make that organically evolve is not for the United States to side with the Islamists. The way to make it evolve is to side with the liberals that want Democratic change that speak out against theocracy. I mean, actually, I think what you've all been ignoring from-- if you're for the motion, what you're ignoring is the fact that the Islamists you want us to support are byproducts of these dictators. The fact that Mubarak housed the Brotherhood, Al Azhar University flourished under him, the Wahabis flourished under the monarchy of Saudi Arabia, Hamas had headquarters under Assad and Syria. So to say that somehow these people just sort of accidentally got along pretty well with dictators until their revolutions happened, and now that the Islamists found a way in, they're finally turning over the dictators that used to feed them for so long.

In fact, it's the third path. If you really want liberal democrats to rise, you can't as the most powerful country--

### Moderator
Claim: Let me ask this side, something that Zuhdi just said, he said that these Islamists, that you want us to support. Is that accurate? You want us to support Islamists?

### Conspiracy Advocate (CA)
Claim: It's absolutely incorrect. We're not saying vote for these Islamists. We're saying, "Vote for the possibility of competition in these politics." And that's an oversimplification right there. And I think it's an oversimplification to say that this current U.S. administration supported Islamists over any other thing. They've supported the openness and people having a voice in their own debates.

### Moderator
Claim: Is there a distinction-- let me go to this side-- if people will vote for Islamists, is that the will of the people being expressed?

### Scientific Advocate (SA)
Claim: I don't believe so.

### Scientific Advocate (SA)
Claim: You can't know what the will is. Sayid Ibrahim said in the Wall Street Journal-- he said, "please give us four or five years until we have elections because the liberals need time to get infrastructure, to get institutions, and the people that would get legs now are only more of the old. And the Islamists came out of Mubarak and all the dictators before--

### Conspiracy Advocate (CA)
Claim: make a quick response to that.

### Conspiracy Advocate (CA)
Claim: My old friend and teacher, Olivier Roy, made the-- I thought the pithy remark where he said, "If France had to wait for the development of a democratic culture, France would still be a monarchy." The notion that you are somehow going to push off into the distance four or five years, and you get to four or five years, another four or five years, that you're going to have suddenly liberals become strong and the dominant party I think isn't serious.

### Moderator
Claim: Daniel Pipes.

### Conspiracy Advocate (CA)
Claim: Ayman Nour couldn't win an election in Egypt right now if the CIA had paid every single Egyptian $5,000.

### Moderator
Claim: Daniel Pipes.

### Conspiracy Advocate (CA)
Claim: It wouldn't have happened.

### Scientific Advocate (SA)
Claim: I find it curious that Zuhdi and I are celebrating-- let's call them the liberals, the moderns, in Egypt and the rest of the Middle East, and you two are denigrating them and ignoring them. These are the hope. Why don't you put your faith in them? 'Why do you put your faith in people who have a code and a vision that is as antithetical to ours as could--

### Moderator
Claim: I don't think-- let me just-- let me just clarify something. I don't think I hear them saying-- that's why I asked the question before, that they're putting their faith in the Islamists, but that they're putting their faith in the openness of the process, which is different.

### Scientific Advocate (SA)
Claim: Brian just said that when the Islamists come to power, they moderate, to which I would say, "Yeah? Tell me about Iran." Where's the moderation in Iran? I see no moderation.

I see, in fact, a more vicious government--

### Conspiracy Advocate (CA)
Claim: Well, Iran came to power through a revolution. It was a revolution against the Shah. I mean, it was a complete, total overthrow, in fact, within a very short-- the thing that you would want to ask in Iran is, have the individuals who initially supported Khomeini, who supported the idea of theocracy, had an enormous change? You have. You can't find a halfway intelligent cleric who actually supports the idea of--

### Scientific Advocate (SA)
Claim: That's very nice, Reuel. But, in fact, we have a government headed by one of Khomeini's lieutenants, namely Khamenei, who has a government that-- I think you'd agree with me-- is at least as vicious as Khomeini's.

Where is the moderation? Where have these people improved?

### Conspiracy Advocate (CA)
Claim: No, but they didn't-- they haven't arrived. They have stopped elections. The evolution would have been in 1997 and 2009. Each and every time, they've stopped it. Now, if--

### Moderator
Claim: Daniel, let him finish. Daniel, let him finish.

### Conspiracy Advocate (CA)
Claim: If, in the future-- we have to get there first. What you're doing is closing down the option. You're basically saying, "You don't get to have the right to have a democratic process." And by the way, the Western democratic process, if you recall, was not terribly pretty. It was really ugly, took a long time. They'll have to go a really long distance before they actually have as bad a time as we did.

### Moderator
Claim: All right. Daniel Pipes.

### Scientific Advocate (SA)
Claim: I would like to point out that Brian argued that the nonviolent Islamists are the antidote to the violent Islamists, that al-Qaida had not much of a role, had no role in Egypt and Tunisia.

Well, what about Syria? I believe al-Qaida has a role there. And if not al-Qaida itself, al- Qaida types. What we see in Syria is the bringing in of violent Islamism, and--

### Conspiracy Advocate (CA)
Claim: Which is the result of a dictatorship. If I take your formula-- and I respect your formula. I don't agree with it. But if I take your formula, Zuhdi and Daniel, you got to rely on the goodwill of Bashar al-Assad to sit down with secular liberals and give up power and actually open up the political system. That's your formula right now. You've been relying on that for years.

### Scientific Advocate (SA)
Claim: I'm going to rely on the goodwill--

### Conspiracy Advocate (CA)
Claim: And the al-Qaida elements which I'm worried about in Syria, in the opposition, are the product of decades of that dictatorship that you're arguing for tonight.

### Moderator
Claim: All right. Zuhdi Jasser.

### Scientific Advocate (SA)
Claim: I'll tell you the reality-- I'll tell you the reality of this motion. The reality, Brian, is, in this motion, for example, in Syria, you had the SNC, the Syrian National Council that was really a conglomeration of expatriate Islamist that got together.

And the question is, this is relevant to America, because do we tip towards those Islamists or do we tell the Syrians on the ground, who were a majority non-Islamist a year ago, that they will get the backing of America and the West, true defenders of freedom that will not push their oppressors, the new oppressors instead of the old oppressors. And that's what Islamists are. And our opposition, I think, one of the things you're forgetting-- I've yet to hear from them one example of Islamists that have moderated, whether it's the Taliban or the Wahabis in Saudi Arabia or the Islamists in Iran. Every one of them seems to dig their heels in more and more.

### Moderator
Claim: Okay. Here is their chance. All right. Brian Katulis, go ahead, sir, Brian.

### Conspiracy Advocate (CA)
Claim: Yeah, I started out my presentation talking about the vast majority of Muslims living in South Asia. Indonesia, the number one largest Muslim country in the world. Prime examples of where Islamists ran as political parties and they failed.

They failed. And their populations actually voted them out. You have-- they are weakened, because they didn't deliver, and I think the central premise that you guys have is that elected Islamists don't change or morph, or somehow don't become like other politicians. Well, guess what-- they do, when you actually have open systems. We see this in Turkey too. And I think there-- steps forward and steps backward on Turkey's democracy, but by and large, Turkey, I think, is a much more sustainable proposition than what Daniel was talking about back in the Cold War era, back in the 20th century. We're in the 21st century.

### Moderator
Claim: Okay, can--

### Conspiracy Advocate (CA)
Claim: We've got to deal with these realities.

### Moderator
Claim: Daniel, Daniel, I--

### Scientific Advocate (SA)
Claim: Jumping up and down here.

### Moderator
Claim: All right, go ahead then. Go ahead. I have a question, but you go ahead.

### Scientific Advocate (SA)
Claim: Turkey, the first five years under Erdogan and the AKP was very careful because it was the military, and they didn't want to make any missteps. And now that they've gotten rid of the military, oh, they're going with guns blazing, and they're investigating, and they're enjailing, and they're indicting.

And there are hundreds of people who have nothing to do with any kind of conspiracy are put away for life. You name it. This is an increasingly authoritarian government. So I stick by our position which is that the Islamists, when they get to power, whether in Iran or Turkey or Egypt or Tunisia, just get worse with time. And you mischaracterized our position. It's not that Assad will be having negotiations with the liberals in Syria. It's that we will be advocating for the liberals. We will be pushing Assad. We have enormous power, implicit in this motion is U.S. policy. What do we want the United States government to do? And the worst thing we want the United States government to create space for the liberal, free minded modern people to enter in. And you're saying you want the U.S. government to invite the medieval types to come in.

### Moderator
Claim: But does creating that free space-- does creating that free space continue on some level of support for dictatorship, to create space for the liberals?

### Scientific Advocate (SA)
Claim: No. Look, take Mubarak. He was there for 30 years. No way do I want to help Mubarak. I want to push Mubarak. Or take an actual government today. I want to push the Algerians. I don't want to help the Algerian government. I want to open up Algeria. I want the liberals, the moderns in Algeria to have more of a voice. That should be our role. That is the American role through history, is we are the advocates of democracy understood as liberal democracy around the world. Let's do it in the Middle East, not just in South America and Africa and South Asia and East Asia. Let's do it in the Middle East too.

### Moderator
Claim: Reuel Marc Gerecht.

### Conspiracy Advocate (CA)
Claim: I think that's all great and fine, and we should support liberal democrats everywhere. I'm-- you know, I've been in favor of covert action programs all over the place. But I just don't see that you've got the traction. And I don't see if you go to Mubarak-- Mubarak made a real hobby out of squashing liberals like he made a hobby of squashing everybody else.

And Mubarak says, no, I don't want to do that. And what's the United States going to do? All right. Take the money away. Take the money from the military, and then he says, all right, you're going to weaken me. The Islamists are coming. You've already said the Islamists did come. So I don't think you can create liberals in the Middle East out of sand. There has to be a process, an evolution. In the West, liberals were not born overnight. They came into being. It was-- I don't want to go through Occidental history here. It was a very ugly process. What he is saying is that, no, you don't get to have that process. We had that process, but no, not you. Muslims don't get to evolve. You have to be born liberals now.

### Moderator
Claim: Zuhdi Jasser.

### Scientific Advocate (SA)
Claim: Reuel, I'm sorry, you're living in this academic bubble that is so far removed from the reality on the ground that, you know, the reality on the ground is, as a Muslim, the Islamists never want debate, never allow debate.

They suffocate liberal movements. And if you even look-- let's take Turkey. The secretary general of the OIC is Turkish. Give me one statement that man has made criticizing any other Islamic regime, Islamists from Iran to the Taliban, et cetera, to the Saudis, the Wahabis, not one, because together they seek a neocaliphate. They seek Islamic hegemony around the world. And the Islamists don't allow debate. I can tell you this from experience, and it's no better than the dictators. And actually, American influence, if we want to help the liberals, and if they see us saying, oh, well, the Islamists are a little better, they're going to throw us aside and say, geez, there the Americans go again caring not about us.

### Moderator
Claim: Zuhdi, Daniel, your partner likened Islamists to Nazis. Do you agree with that? And I want to bring that to the other side, Nazis. They can't be reformed, and they're all the same. Can you take that on? Brian Katulis.

### Conspiracy Advocate (CA)
Claim: Oh, absolutely not. I mean, especially elected Islamists. And again, we're at the early stage of an experiment here in many of these countries.

But just look at the facts. Look at countries that are Muslim majority. And again, I hate to bring up Indonesia again. But bring that up again, and they change. They morph, they modify. I see it in Egypt already. And again, we're in the early stages. It's hard to game this out. But you have different strands of Islamism even within the Muslim Brotherhood, which we paint Islamists. And this is sort of like a nice tactic people like to do is lump 1.6 billion Muslims all together and talk about sort of political Islam in some sort of way and make us believe that these people, the constituents, are fools and that they'll just blindly follow some sort of theology here.

### Moderator
Claim: And you're saying not all Islamists are the same.

### Conspiracy Advocate (CA)
Claim: They're not at all, and modify--

### Moderator
Claim: I want to bring that point to the other side. Zuhdi Jasser.

### Scientific Advocate (SA)
Claim: I mean, John, the issue is, Brian, Indonesia was never Islamist to prove your point. I mean, President Wahid has been-- who is now passed away, but wrote a book called "The Illusion of the Islamic State," in which he, as a previous president, had the---- the bully pulpit of his presidency to fight against this Islamism, the identity principles of Islamic state, principles of Sharia, et cetera. And still to this day, the Islamist movement in Indonesia is very potent, but they've never been in control. If they were in control, that might prove your thesis. But your thesis is that somehow we should allow them to tip towards Islamism because that's the pathway to some type of better system. And they are Nazis. Why? Because this is a supremacist idea. Look at the-- what this country came out of. I think you're forgetting American history. Our history was that Christianity reformed and separated church and state, not through really a simple process. It was revolutionary with hundreds of thousands dying in Europe for the enlightenment and then the American Revolution. Do you think that the Islamic world is going to separate mosque and state in any less violent type of a revolution? It's going to be major. And the Islamists aren't going to just sort of hand it over.

### Moderator
Claim: Reuel.

### Conspiracy Advocate (CA)
Claim: I'm not sure I followed that at the end.

There are Islamists out there who are hell on earth. And I can't think of a single good Islamist. It's impossible. That's really not the point. The point is how you bring about--

### Scientific Advocate (SA)
Claim: We rest our case.

### Conspiracy Advocate (CA)
Claim: --how do you bring about a political system where you have evolution, where you have some chance-- if you are going-- you're not going to get a situation-- and I think we've seen that since the Arab-- great Arab revolt started. You're not going to get a situation where liberals are going to win an election. People of faith are going to win the election. Islamist parties are going to win the elections. So you're going to have to take that as a given. You're not going to be able to have the United States come in there and dictatorially essentially say-- I mean, Kissinger made the great line, "Democracy is great, but I really want to know who gets to win." You don't get to know who gets to win. You've got to go through the process. You have to set up a system where you have a jousting ethic. Fundamentalists have to fight with fundamentalists.

In Egypt, the Nour party of the Salafis is absolutely morally repugnant, all right? No doubt about it. But they are actually in the process of collapse right now because they haven't figured out how to handle the pressure of democracy yet. The Muslim Brotherhood is having serious internal debates because they haven't figured out how to handle-- this is all new terrain for them. That's what we want. We want them to fight it out. It's not going to produce something pretty in the short term. But what they're suggesting, having dictatorship and somehow having the United States, oh, I'm going to create a liberal here and a liberal there and a liberal here, it makes no sense.

### Moderator
Claim: All right. I want to let Daniel Pipes respond but in a-- But I just want to-- before I say that, after Daniel's response, I'd like to go to questions from you in the audience. And the way that will work, if you raise your hand, and you catch my attention, and I can pretty much see everybody, I won't be able to take questions from upstairs.

So if you want to ask one, you should come down. There will be people in the micro-- in the aisles with microphones. Stand up, please. Tell us who you are. And hold the microphone about a fist's distance from your mouth for the sake of the radio broadcast.

I urge you to ask a question that is actually a question. I'll have to stop you if you're debating with the debaters. But I'm fine if you state a very, very short premise to your question. But when I say very short, I mean in 17 words or less. Daniel Pipes.

### Scientific Advocate (SA)
Claim: Thank you, John. I think what this difference boils down to is that our opponents do not apologize for Islamists. You just heard it. I can't think of a single good Islamist we just heard. And we sure don't apologize for dictators, Assad, Mubarak and the rest. So nobody likes anybody. The difference is you just saw Reuel scornfully, "Liberals, we're creating liberals. Liberals, we're creating liberals."We think that this is the hope of the future. We think they do exist. We saw them. We saw them in Tunisia and Egypt and Syria. We see them throughout the region. We believe they're the hope. And so we're trying to find a way to build them. They have given up on the liberals and are willing to go with the-- they're not happy about it, I gather, but they're quite ready to go with the medieval totalitarian order, medieval style totalitarian order. Well, no thanks. Let's be hopeful. Let's try for a better Middle East. Let's work with the people who have a decent vision of the future.

### Moderator
Claim: All right. Let's go to some questions.

### Moderator
Claim: My name's Barbara Arfa of the New York--

### Moderator
Claim: I'm sorry?

### Moderator
Claim: Barbara Arfa--

### Moderator
Claim: Thank you.

### Moderator
Claim: --of New York City. I understand the premise of those of you who are speaking for the motion.

And it's very enticing to believe that the Islamists will morph. What I don't understand is how will they morph if there's so much violence that once they begin to change they are in tremendous danger of being killed by other Islamists? There's so much murder, so much violence as part of that culture, aren't they afraid to morph?

### Moderator
Claim: Perfect question. This side. This side. Brian Katulis or Reuel Marc Gerecht. Brian Katulis.

### Conspiracy Advocate (CA)
Claim: Look, I think they have a greater possibility to morph now than if they were facing Saddam Hussein who killed hundreds of thousands of people, more possibility in places like Tunisia to morph than they did in Libya under Muammar Gaddafi, when you had organized mass murder.

And let's be clear about this. I want to stress this. The transition in the Middle East is in the very early stages, sorts of violence that we saw and we've been talking about, that killed our ambassador in Libya, those extremists that killed him and murdered him, those sorts of things-- we need to recognize that those threats have not been completely eradicated. We also need to recognize that the large protests against those extremists in Libya would never have actually happened under Muammar Gaddafi. We need to recognize that there's a space there, that I'm not in favor of elected Islamists or liberals or anything. I'm in favor of systemic change that has legitimacy. And I think this is a key distinction between what Reuel and I are saying and what the other team is saying. We can't implant this.

We need to recognize the reality that because of the dysfunction caused by dictatorships for decades, you're going to have this first early result. And, yes, there's still going to be violence and risks, but I actually think it's less than what we saw in terms of the hundreds of thousands killed by the dictators in these countries. And I actually think the more that you have popular reaction of the sort that we saw in the streets of Benghazi against those murderers, you have I think a possibility then to push them and further marginalize them in that debate.

### Moderator
Claim: Other side, do you want to respond?

### Scientific Advocate (SA)
Claim: Yes.

I think--

### Moderator
Claim: Zuhdi Jasser.

### Scientific Advocate (SA)
Claim: I think, again, one of the core things that they're missing, and if you are for this motion you're missing the fact that Islamism cannot be morphed. We have a Muslim Liberty Project where we have youth that work with us from the young ages of 15 to 30, and we realized that we had to do it at a young age because once an Islamist looks at the world through an Islamic lens, that governments and everything should be looked at through Islam and through cleric and through Imams, not through reason, not through independence, not through the separation of mosque and state, and that their identity doesn't come from a national liberal identity but through a faith based Islamic state, they are done.

You can't reform them away from that.

### Moderator
Claim: Zuhdi, when--

### Scientific Advocate (SA)
Claim: And that's what we've got.

### Moderator
Claim: --when millions of people vote for an Islamist party, what are they voting for?

### Scientific Advocate (SA)
Claim: They're voting for a whim, they're voting for this sense that morality will come when corruption was before them. Why did the-- some of the Palestinian populations vote for the terrorist, Hamas, when they had Fatah? They saw Fatah as corrupt. So this binary equation has created two evils that fed off of one another, and elections are not democracy. Democracy is about principles of freedom and liberty, of representing the minority, and--

### Moderator
Claim: Would you want to discourage an election if you felt that Islamists were going to prevail in that election?

### Scientific Advocate (SA)
Claim: No, no, I mean, and we fought communism without preventing the communist party from existing, et cetera, so I wouldn't want to outlaw. I think you can--

### Moderator
Claim: No, no, no, no. My question isn't really that. My question is are the paradox of these-- of encouraging a democratic election and then the election produces results that are anathema to you, do you go back a stage and wish that you hadn't had the democratic election?

### Scientific Advocate (SA)
Claim: No. I think it should at least-- they shouldn't become our allies-- we should at least make a stance that just because they were elected doesn't mean that we have to share their vision or treat them any differently than we would a dictator.

### Moderator
Claim: Okay. Another question. Right down front. Just wait for the mic, sir. It's on its way.

### Moderator
Claim: Okay.

### Moderator
Claim: And just-- I just want to give the camera a second to catch up with you. Okay, go ahead.

### Moderator
Claim: The name is Russ, hi. Mr. Pipes, you had said that part of the whole process and as, basically, U.S. involvement, that democracy is part of our job to spread. It's what we do. I'm kind of wondering why a 236-year-old system should be superimposed over thousands of years of a system that's already existed there and why it's our job to do that.

It seems to me that we have always been able to effect change through the back door and not through the front door. By giving them popular culture, by giving them the things that we embrace as a country and that we love, you work through the youth of the countries that we're talking about--

### Moderator
Claim: Can you wrap to a question on this? I think you do have a good one here.

### Moderator
Claim: Well, I guess the question really is, is the answer not necessarily to, you know, try to go through the front door and work on changing the leadership in those countries and getting them to change their minds, but rather in the up-and-coming youth of those countries by giving them all the things that have changed other countries, like Russia and Japan and-- you know, popular culture.

### Moderator
Claim: Daniel Pipes.

### Scientific Advocate (SA)
Claim: Thank you, Ross. I don't think American popular culture these days is particularly politically liberal or democratic. But I accept the basis of your point, which is that the United States is-- has unique instruments of influence, including its popular culture, beginning in the 1920s, which nobody else ever had before, and we have the most of, including its financial clout, including its military, its extraordinary range of tools. So here we are, as Americans, saying, "Well, how should we use these tools?" And our side is saying, let's use them with the goal of bringing to office people who think as we do, who believe in democracy, et cetera, liberal democracy. And this has been our career. Woodrow Wilson came up with the 14 points 100 years ago.

And we had in Japan and Germany and Austria and Italy and other countries, we forcefully imposed it, and look, it worked. It can be imposed. In Tiananmen Square in 1989, they had a version of our Statue of Liberty as the representation of what they sought in freedom. We are-- the United States is the symbol of freedom, of liberty, of democracy. We are that. And it is something particularly noble about this country.

### Moderator
Claim: Let me take this to the other side.

### Conspiracy Advocate (CA)
Claim: I'm enjoying Daniel being the neocon. I'm enjoying this enormously. You know, the--

### Scientific Advocate (SA)
Claim: That's very snide.

### Conspiracy Advocate (CA)
Claim: No, I agree with him. For me, that's a compliment. You know, I have to say this. It's not a question of imposition. I mean, what we're talking about here is, in fact, people in the Middle East have absorbed, profoundly, western ideas.

They haven't, by any means, absorbed them perfectly, ideally, to the level that we would like. But one of the things I'm arguing is, in fact, the idea of popular sovereignty has been absorbed through a wide body politic, including the faithful, including within those that we call Islamic fundamentalists. If you can-- when I was in Najaf in Iraq and I was having discussions with one of the elder sons of Grand Ayatollah Hakim, and we were discussing what democracy was, I mean, he understood to be, in his own conception, ma'ruf, that it something that was sacred, that popular sovereignty was sacred. Now, in the next breath, he said, "I don't know where the red lines are." He had no idea where they are. We have red lines, too, in democracy, whether they be about abortion or other issues. We're not quite sure where certain issues in our ethics collide, where we don't want to compromise. They have, for the very first time, this problem.

It is great that an elder son of one of the senior clerics in Iraq has this problem. That's where you want to take this. And it's not a question of imposition. It's a question of they, themselves, taking the imports that they have voluntarily taken in and trying to figure out how they work out a more humane society. In their case, it's easy, given where they came from with Saddam Hussein, because they could screw up for a long time and it would still be more humane than what they had before.

### Moderator
Claim: All right. I want to remind you that we are in the question-and-answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two arguing this motion: "Better Elected Islamists Than Dictators." Right down in front, ma'am.

### Moderator
Claim: Thank you. Dr. Ahmed, the author of "In the Land of Invisible Woman." I've lived in Sharia law in Saudi Arabia, and I'm of Pakistani heritage.

So to my colleagues, I'd like you to say, "Better elected Islamists," comment on Pakistan's 65-year history where it's advocated to be the world's first Muslim democracy where there is no functioning democracy unless you are an Islamist sympathizer. Please comment on that. But-- and let me also add--

### Moderator
Claim: Wait, wait, I'm--

### Moderator
Claim: Let me add, as a Muslim woman and someone who's lived and has friends and relatives in the Middle East, I'm offended that you think there are no innate liberals.

### Moderator
Claim: Brian Katulis.

### Conspiracy Advocate (CA)
Claim: Actually, I didn't say that there are no innate liberals. And I lived and worked for five years in the Middle East. I go to Pakistan frequently. I talk to them all of the time. They're fighting that struggle. And I'll tell you right now, Pakistan's at an interesting moment that everybody's negative about Pakistan and what's going on. There's an interesting dynamic that's been underplay there. And you've seen this. And I was there in 2009 when there was Sufi Mohammed, the head of Pakistani Taliban group, extremist group.

He said that courts are un-Islamic. He said that elections are un-Islamic. And this was at a time, a territory called Swat, about an hour outside of Islamabad, was taken over by those very same extremists. And I was on the ground there. And the national outcry against Sufi Muhammad and the national protests against a video of a woman being beaten in that very same territory, the liberal and democratic response was there. And you saw it in the previous elections in 2008, the MMA. You know it very well, an Islamist party that said that they were going to ban cable television in northwest frontier Pakistan. You know what? You know what a lot of men love watching WWE wrestling in Pakistan. These parties tried to rule theocratically and by a basis of religious ideology, and they failed.

They were voted out in the ballot in 2008. And as you know, not end of story, not end of story at all, because Pakistan is at a dangerous place. But yes, there are liberals there. And they are fighting against those radical Islamists. They are going to have an election. Guess what? Next year. And they are having an open debate. That did not exist under Zia. That did not exist under the dictators that ruled, the military dictators that quite frankly were backed by the United States, like these gentlemen want us to do.

### Moderator
Claim: Let's hear from these gentlemen.

### Conspiracy Advocate (CA)
Claim: And that did not exist at all.

### Moderator
Claim: Daniel Pipes.

### Scientific Advocate (SA)
Claim: We don't want to back the dictators. Can I make it any clearer? We are not arguing for dictators. We are not arguing to extend their rule. We are arguing that we can influence them in a positive direction. I would love to see the dictators gone. I have an idea on who can replace the dictators.

### Moderator
Claim: Again, right up against the rear wall there. Yeah, thank you. Yeah, yeah. Sorry. I was going to say the guy wearing the black shirt, but that would be like--

### Moderator
Claim: I'm black shirt, I'm just wearing one. My name is Ben. I'm an Englishman in New York, like the song. I have a-- my heart is with Brian and Reuel, but my head at the moment is with Daniel and Zuhdi. Reuel you made a passing reference to France. And that got me thinking, the French-- the French spring of 1789 was followed by 200 years of war, revolution and genocide.

### Moderator
Claim: I'm getting worried on this question.

### Moderator
Claim: Yes. And I'm coming to the question.

I'm getting excited, actually.

I hope so.

### Moderator
Claim: There are decades to go.

### Moderator
Claim: So I'm not going to go through the full 200 years. I've just-- how are you-- are you-- are you convinced that we can somehow avoid a repetition of that pattern in the Middle East?

Because you planted those doubts in my mind by saying that.

### Moderator
Claim: Reuel Marc Gerecht.

### Conspiracy Advocate (CA)
Claim: I think the best answer to that is, and the simplest one is, revolutions are bad. You don't want to have a revolution. You don't want to have the violence that comes with a revolution. What you want to have is the transition that goes through elections. You want to avoid, at all cost, the triumph of the military men, the militarists, the-- I would say in the Middle East, the real danger in the Middle East still in most places is not the Islamists. It's actually still the military. In that you want to have folks become responsible for their faiths as quickly as possible.

There's only one way you do that. There's only one way people become responsible, and that is through elections. It is process of elections. I mean, take Iran. Iran has just - - they've had controlled elections. But the simple fact of having controlled elections in Iran has inspired people to actually take them seriously. There was a promise in the Islamic-- when the Shah fell, there was the Islamist strain under Khomeini, and there was also the democratic strain. They are in constant tension. And I would argue that actually the democrats have done far better in at least taking the intellectual train.

### Moderator
Claim: But this does not make you an Iran fan.

### Conspiracy Advocate (CA)
Claim: No, I'm--

### Moderator
Claim: To the Daniel's point is that nobody likes anybody.

### Conspiracy Advocate (CA)
Claim: No, I'm not a fan of Iran. All I'm telling you is that it the Iran case is very interesting is because it shows evolution. It shows, as we saw in the Soviet Union and Eastern Europe, you can have lots of fallen communists. The notion that Daniel is suggesting that in fact Islamists stay as they are is false. It's all depending upon the political circumstances.

No one stays as is.

### Moderator
Claim: Zuhdi Jasser.

### Scientific Advocate (SA)
Claim: I think the central fulcrum of their argument is somehow that the voting booth, that the election process, that once these citizens enter a voting booth, they somehow become liberals or democrats when, in fact, it's a mobocracy that they're advocating for, that somehow 50 percent-- we learned in this country we had to have a civil war and a civil rights movement until we understood what liberal principles were from our own Constitution. So somehow they're telling us that elections are going to evolve this without a revolution. And the Islamists will actually entrench it more. And I think again, you are insulting Muslims to assume that the collectivist concept of Islamism, that somehow all Muslims must think alike, have the same political party, have the same aspiration for the state, that there's no left to right, that we are all part of this brotherhood party, which is Islamism, is somehow freedom for Muslims or otherwise we insult Islam.

There are a majority of Muslims that don't Islamists, don't want it on our back and reject the entire notion.

### Conspiracy Advocate (CA)
Claim: I agree with that, and I don't know where that-- I agree with that, and I don't know where that straw man is sitting. The chair's not here. I mean, that-- I agree with that notion.

### Scientific Advocate (SA)
Claim: is the straw man.

### Moderator
Claim: All right. I haven't gone to the back yet. The woman in the red dress. Would you mind - - can you see that-- I know it's dark back there. Would you like her to step into the light a little bit?

### Moderator
Claim: I just like the idea of the woman in red.

### Moderator
Claim: Yeah. Or walk toward the light, ma'am. Thank you.

### Moderator
Claim: Couple years ago there was a debate on IQ Squared about how radical Islam taken over Muslims, the Muslim religion. And the debate people here voted that it had which I thought was interesting. Not knowing a lot about it, it seems as though at the fulcrum of the issue, question for you is, will elected Islamists actually allow any evolution into democracy happen, or will they suppress it?

That seems to-- because I think we all like the idea. It's just, will it practically happen?

### Moderator
Claim: Okay. That's a question for this side for the motion. Reuel Marc Gerecht.

### Conspiracy Advocate (CA)
Claim: We don't know until it happens. I mean, you can't know this in advance. There is no way right now that we can be certain that you're going to have many elections in Egypt and Tunisia and where else democracy spreads to. That is going to be, you know, trial by error or by experiment so-- but unless you get there, you'll never know. So you have to go down that path before we can even answer that question. Now, I can give you a religious discussion of this, how I think on the Shiite side and the Sunni side, how Western ideas about democracy have penetrated that can give you some hope there. But I-- we just don't know until it happens.

### Scientific Advocate (SA)
Claim: Reuel doesn't know. Reuel doesn't know, but I do.

### Moderator
Claim: Oh, Daniel, you could have just left it there. It was perfect. I was trying to help you out by going to another question. But go ahead. All right. I'll go to another question unless you really-- all right. It landed so well. Sir, yeah, thanks. A mic will come to you, halfway up the aisle.

### Moderator
Claim: Hi, my name is Patrick McGinnis. I just wanted to return to Mr. Pipes comment, suggestion about America's place in this process. I think, you know, I would be very happy if America could through its intervention bring about liberal democracy in the Middle East, and maybe in a time of American hegemony that would've been possible, but our nation building efforts in the Middle East over the past 10 years have been very difficult. So based on the experience we've had, I guess I'd like to return to what you said and put it in a practical context.

### Scientific Advocate (SA)
Claim: Yes, the effort's in Iraq and Afghanistan have been, will have been, I believe, failures, you can come back in five, 10 years to Iraq and Afghanistan, you'll see the barest traces of the vast American engagement there. It will have been a failure, so, yes, I agree with the premise of your question, but I'm not calling for invasion and putting in rulers and so forth. I'm accepting the fact that there are autocrats. And I'm saying, "Okay, let's use our influence in a constructive way to make it easier for our kind of people who are there to gain in strength to be important and eventually to lead the Middle East out of the mire in which it is today," but I'm not calling for invasions.

### Moderator
Claim: Right, so--

### Conspiracy Advocate (CA)
Claim: And I'm all in favor of that because I spent five years of my life in the Middle East working with liberals, with people pushing for human rights, working for women's rights in the West Bank, in Gaza, in Egypt, across the region.

And I'm in favor of it, and I think it's a nice idea. And I was against the war in Iraq, but the reality is-- and this is what we're debating tonight is that good intentioned Americans who want to go in peacefully and try to orchestrate the politics of these places won't produce the sorts of results that you expect. What you need is the rough and tumble, the jousting that Reuel talks about. We can help. We were trying to help with the tools of, "How do you organize?" and I think this is a fundamental struggle in the next wave of Egypt because there will be a next wave. The Islamists swept in this first round of elections. There's still a lot of uncertainty about the constitution, but there'll be another round of elections. And I do believe that American, European, and other organizations have a role to actually support these groups to become better organized. That's not what we're arguing. We're not arguing for elected Islamists. We're opening-- we're arguing for open politics in these places, and it doesn't come by invading these countries, and it doesn't come by simply trying to negotiate with some of these dictators and say, "Please open up."It comes through an organic process, a political process, that what Reuel and I are saying that in the first waves are likely going to lead to elected Islamists-- but that's not going to close off the debate. It's going to open it up and lead to multiple centers of power in these countries.

### Moderator
Claim: Another question? Sir, down in front.

### Moderator
Claim: Like to--

### Moderator
Claim: I-- we just need to get the mic to you, thanks.

### Moderator
Claim: I'd like to bring you back to the agreement--

### Moderator
Claim: Can you just-- would you mind identifying yourself? Thanks.

### Moderator
Claim: Okay, Constantine Canacledes I'm with Scholars for Peace in the Middle East.

### Moderator
Claim: Thank you.

### Moderator
Claim: Both sides indicated that they agreed that both choices of elected Islamists, dictators, were heinous, they were totalitarian, et cetera.

There was a distinction made early on, and that wasn't addressed, that the same repressive regimes can operate, but one tends to operate local and local- regional, and as the against side indicated that there is a vast globality of vision and intent on the part of Islamists, that they have a vision that goes far beyond the periphery and the boundaries of the state-- nation and state. And that wasn't addressed, and so I'd like this side, pro side, to address, "Isn't that a valid distinction that, that would suggest a far greater potential for ill on a global level from Islamic fundamentalists and elected Islamists and--

### Moderator
Claim: Can I restate the question and--

### Moderator
Claim: Yeah.

### Moderator
Claim: --make sure that I'm understanding what you're asking? You're saying-- you're asking about the point that dictators are working from one state. Islamists are a part of a global worldwide aspiration to control many, many states--

### Moderator
Claim: A mission, yeah.

### Moderator
Claim: --and you want the side arguing for the motion to address that?

### Moderator
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: I think it's highly likely that if you have more than one election, that what you're going to see-- and you always see it with democratic politics, is that your aspirations become much more localized. And I don't think that you're going to see any Caliphate. I think the notion of that is a bit farfetched. I think it runs against the most successful Western export to the Middle East which is nationalism which has profoundly affected even Islamist movements throughout the area. So I don't think that's a big problem. Now, you could find common purpose. It's entirely possible that you will have Islamists in one country look fondly and affectionately at Islamists in another country and seek to support them. That's--

### Scientific Advocate (SA)
Claim: What's the OIC? What's the OIC, then? What is that?

### Conspiracy Advocate (CA)
Claim: It's a mess. I mean, the--

### Moderator
Claim: Wait, wait, wait. Term of art. Explain the OIC.

### Scientific Advocate (SA)
Claim: The Organization of Islamic Cooperation is 56 countries that share nothing other than the fact that they have majority Muslim countries and also the fact that they rejected the U.N. Declaration of Human Rights, and many of them say they signed in, which they did, but then they signed the Cairo Declaration that talks about blasphemy laws, apostasy, et cetera. So it's based out of Saudi Arabia, and they don't seem to be critical of one another.

### Conspiracy Advocate (CA)
Claim: Well, that's because the primary-- the OIC is really about them saying, in a rather childish way, you know, "Here we are; here we are. Notice us. We're not the West, et cetera, et cetera." The OIC is-- has been, in the past, sort of a concoction of dictatorships that, virtually, the only thing they could agree on is how much they dislike the United States, how much they dislike the Israel, and other, you know, less concealed forms of anti-Semitism.

It's-- I don't really see that the OIC actually has anything to do with the democratic process. It has a lot to do-- it's sort of like an Islamic version of the United Nations, which I don't recommend. I don't think it's a moral paragon. Most of the time, it's not very serious.

### Moderator
Claim: Let me-- we have to wrap-- we have to wrap up this section. And I just want to bring up a topic that I thought would come from the audience, and it didn't, and we don't have much time, so I want to ask it very quickly to this side. We haven't heard very much about the issue of women's rights. You all acknowledge that, at this point, most Islamist movements are not friendly to women's rights in the way that we would understand it. And I want to ask this side, you know, where do you draw the line on that? Where do you say, you know, it can be open and it can be evolving, but in the meantime, in the short term, this abuse of women's rights just cannot be tolerated?

### Conspiracy Advocate (CA)
Claim: It's a red line, and I think we see the dictatorship of Saudi Arabia as one of the worst offenders of women's rights. And I think you see the places that have-- again, Muslim majority countries, Malaysia, Indonesia, and other places with Islamist parties-- respect for women's rights, like everything else.

In places like Morocco too, where you have space for a discourse and a debate about this. And in Morocco, they had Mudawwana, a code to improve the status of women's rights. So a big debate is happening here. And I don't believe, for a moment, that the rights of women under Saddam Hussein were a lot better than what we have today inside of Iraq. I don't believe that at all. And I think there's a fight that women, as long as they can go back to the ballot box, as long as there are institutions there, as long as there's accountability in the system, as long as women have a voice in those debates, I believe that you'll see, eventually, a more sustainable and legitimate foundation for women's rights in these countries.

### Moderator
Claim: Fifteen seconds.

### Scientific Advocate (SA)
Claim: I have to say, when the dictator, when Mubarak wants to control the women in his population, he uses the Islamists. When the Saudis want to control the women in their population, the Islamist Wahabis are the ones that they use to do that. So now all you're doing is you're elevating the judges and the teachers from their positions to run the whole country. I'm sorry; I'm not going to-- you know, I think we need to vote against the motion, as a result.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate, where our motion is, "Better Elected Islamists Than Dictators." And remember, this is-- we're now going to go to closing statements, and this is their last chance to persuade you of the power and the quality of their arguments. But before that, I want to remind you that you voted beforehand. Immediately after the closing statements, you will be asked to vote again, and the team whose numbers have moved the most will be declared our winner. But first, on to round three, closing statements. They will be two minutes each. And speaking first, against our motion, "Better Elected Islamists Than Dictators," Daniel Pipes, president of the Middle East Forum.

### Scientific Advocate (SA)
Claim: Thank you. The word checkmate in chess comes from Persian, "shah mat," which roughly translates to the shah, meaning the king, is defeated. Now, there was a Shah who was actually defeated in 1979. He was thrown out by Khomeini and the Islamists. And what's so striking, in retrospect, is how many westerners greeted this event with rapturous excitement. For example, the deeply influential French philosopher Michel Foucault called Ayatollah Khomeini a saint. In this country, Jimmy Carter's ambassador to the United Nations, Andrew Young, made a little less of a statement, called him "some kind of saint." Well, look how things turned out. Iran is today the rogue state along with North Korea, par excellence. It's government is despised by three quarters or more of the population.

It is the leading terrorist state in the world, terrorist sponsoring state in the world. Its nuclear plans make it the single greatest menace to world peace today. So looking back to 1979 and calling Khomeini a saint, expecting things to be better, I would suggest to you not to make them-- the same mistake, not to put your faith in Islamists. Expect the worst of the Islamist regimes. These are people who are not going to let go of power. One man, one vote, one time or maybe two times is what you can expect. And therefore I say, better the greedy dictators that we can push around that we can change than the Islamist dictators who are our deepest enemies who we cannot change, who will be there for decades to come, who will inflict enormous damage on their own populations, be aggressors toward their neighbors and deeply mired in anti- Americanism. Thank you.

### Moderator
Claim: Thank you, Daniel Pipes. Our motion is "Better Elected Islamists Than Dictators." And here to speak in his position, closing statement on the motion, Reuel Marc Gerecht, a senior fellow at the Foundation for Defense of Democracies.

### Conspiracy Advocate (CA)
Claim: You know, I think Daniel started off by talking about tactics. And I have to say this is the part I simply don't understand. I mean, he says we have dictators to push around and make evolve. But we've-- they didn't evolve, and we did push them around. I don't understand how you actually make a dictator become-- allow liberals to win in a democracy and deprive everybody else. I mean, would that were possible. But it's not possible. Doesn't actually make any sense. If liberals are going to triumph, they're going to have to triumph in a free election sometime.

You're not going to be able to hold off an election and know-- you only get to have that election when you know that they are going to win. And until that moment, you can't have the election. Now, I think that's a recipe that any dictator can look at and say, I think I'm a dictator for life. And I think I have to be honest here. I think that's what Daniel is saying too. I think what he is really saying is it's just too big a risk, so we're just going to have to keep the dictators more or less forever because unless you actually are tested at the urns, you're never going to know how popular you are. And I would suggest to you it's only by being tested at the urns that you're actually going to begin to develop a liberal framework, a liberal process that makes sense. It's only by defining yourself against those who are not liberal that you're going to be able to gain votes.

I don't see how in the Middle East, where the region has been defined by faith, increasingly so under dictatorship, that you get to imagine a scenario whereby suddenly, through American pressure, intelligently applied, of course, because Americans always apply pressure intelligently, that you are going to create a liberal order without coming to the ballot box and testing yourself.

### Moderator
Claim: Thank you, Reuel Marc Gerecht. Our motion is "Better Elected Islamists Than Dictators." And here to summarize his position against this motion, Zuhdi Jasser who is president of the American Islamic Forum for Democracy.

### Scientific Advocate (SA)
Claim: Even before we said a word, our opposition was trying to paste us with the dictators. And at the end, I think if you look at the poster children for Islamists, which is really the question in this motion, the poster children for the Islamism movement are the Muslim Brotherhood. And look no further than their emblem.

Not their emblem in English that says, "Freedom and justice" and all those good words that we want to hear, but the words in Arabic and under it in Arabic, it says, and that's the beginning of a passage in our Koran that refers I think to something else, but it refers to, if you look at the translation, "Hence make ready against them whatever force and whatever mounts you are able to muster so that you might deter thereby the enemies of God who are your enemies as well." That is on the emblem of the brotherhood in Arabic. Their motto, "Allah is our objective, the prophet is our leader. The Koran is our constitution, jihad is our way, dying in the way of Allah is our highest hope." They got elected, and they haven't seemed to have abandoned that motto. Yet our opposition wants you to vote for a whim that somehow these demagogues, these Islamist supremacists will abandon these ideas. And I haven't seen one piece of evidence that they have. In fact, when they. In fact, when they get in power, they smother the liberals. And I think if you believe that hope springs eternal, then you should vote for the side for the motion.

If you believe that pessimism, that believing that Islamists are not better, but that that pessimism will signal to the liberals on the ground that we are with them, that we will not support their new dictators, then ultimately you must vote against the resolution and against the motion.

So many of our families have had it with dictators. Don't push upon our communities new dictators using religious language and suits. True moderation demands the abandonment of Islamism. You can't band-aid Islamism. It's a supremacist ideology. And it's bigoted to assume that Muslims and Islam can't have a third path, that Islamism is Islam. And it's not. So you must vote against the motion if you believe in real hope, real hope for those on the ground, and that those dying in the revolutions did not die in order to give opportunity to new Islamist dictators; they died for real liberty.

### Moderator
Claim: Thank you, Zuhdi Jasser. Our motion is, "Better Elected Islamists Than Dictators." And here to summarize his position in support of the motion, Brian Katulis, who is a senior fellow at the Center for American Progress.

### Conspiracy Advocate (CA)
Claim: This debate tonight has made me think a lot about the previous century and our century, the 21st century. And I think we see a worldview on contrast here. And when I hear our opponents tonight speak, I think about the 1950s in this country when we talk about -isms and Communism and lump large categories of people under one big banner and say that this is an ideological crusade; we can't deal with them; we can't talk with them; they're all lumped together, and no matter what, you can't do anything about that. And I started out by saying that you-- we really have a choice here tonight. It's either to accept the reality, a reality that the dictatorships in the Middle East and in parts of South Asia have fostered the sorts of ideologies that led to the deaths of people in those societies and right here in Manhattan on 9/11.

And we've got a choice here today. We can stick with that old system that is crumbling, a system in countries that have a population where more than half of the population is under the age of 25. And change is coming, whether we like it or not. And we can pretend like the system of dictatorships that we see in Saudi Arabia or in Iran or in other places, that we can work with them somehow and they'll open up, and that we'll actually whisper in the ear of liberals, and they'll bring about change in those societies. We can continue to pretend that that's the pathway forward. I believe that the rough- and-tumble jousting of politics in these societies are the only thing that's going to produce the sort of legitimate change that comes from within. It's going to take a long time. It won't be simple or easy. But I actually think we stick with the process of democratization as it's unfolding, or we continue on the current path that produces the sorts of extremists that we've seen. Thank you.

### Moderator
Claim: Thank you, Brian Katulis. And that concludes our closing statements, and now it's time to learn which side you feel has presented the more powerful and highest quality argument. We are asking you again to go to the keypad at your seat that will register your vote, and we'll have the readout almost immediately. The motion is, "Better Elected Islamists Than Dictators." We're asking you to vote a second time, and this time to vote on the quality of the arguments you heard. If you feel that the team arguing for the motion presented the better argument, push number one. If you feel the team arguing against presented the stronger argument, push number two. And if you remained or became undecided, push number three. And you can ignore the other keys, and just correct your last vote, and we will have the results in about 90 seconds.

I just want to say, about the quality of this debate we presented tonight, we've done-- I've done 46 of these now, and the question I'm most often asked is, "Which was the best debate that you've ever seen put on?"I think this one is a contender. I really want to congratulate these guys for doing this. Really, you kept it intelligent, and you kept it honest, and you actually heard and engaged with each other on the points that were asked, and you answered the questions. And speaking of questions, there was not a clunker from the audience tonight. It was terrific. I just want to give a round of applause to everybody who got up and asked a question. I have, as ever, a few announcements. Those of you who have been at the debate. We would be delighted if you would tweet about us. You would use the Twitter handle @IQ2US, and the hash tag is #IQ2US. Our next debate, if you happen to be in Chicago next week on October 10, we will be taking part for the second time in the annual Chicago Ideas Week.

And our motion that we will be debating there is "Ration End Of Life Care." Back here in New York, we have another debate coming up in October on the 24th. The motion is-- and we set up some of these topics to-- we feel-- we hope to crisscross with the political campaign and with the debates that the candidates were having. Our motion is "The Rich Are Taxed Enough." Arguing for that motion, we'll have Glenn Hubbard. He is dean of the Columbia Business School and chairman of the Council of Economic Advisors under George W. Bush and an economic advisor now to presidential candidate Mitt Romney. Art Laffer will be his partner. He is known as the father of supply side economics. He was a member of President Reagan's Economic Policy Advisory Board, and he is a former chief economist in the Office of Management and Budget. Arguing against that side, Robert Reich, who is former secretary of labor in the Clinton administration and professor of public policy at the University of California, Berkeley.

And his partner, arguing against the motion that "The Rich Are Taxed Enough," is Mark Zandi, who is one of the most widely followed economic forecasters, and the chief economist of Moody's Analytics. Tickets for this debate, that debate, the New York debate, and all of our remaining four debates-- fall debates can be purchased through our website, which is www.IQ2US.org. Also if you can't be physically in the audience, right now it's great. We have a lot of ways for you to catch these debates. As I mentioned at the beginning, we're being live streamed even as we speak now, on the Wall Street Journal's video initiative, WSJ Live. And you can hear these debates and this one also at the NPR, WNYC, that would be here in New York, and you can watch it on WNET and on the World Digital Channel. Okay, it's all in. Our motion has been "Better Elected Islamists Than Dictators." We have heard the arguments for and against this motion. You voted twice, once before the debate and once again afterwards.

And the team whose numbers have changed the most by your vote will be declared our winner, and here's how it goes. Before the debate, 38 percent were for the motion, 31 percent were against, 31 percent were undecided. After the debate, 44 percent are for the motion, that's up six percent, 47 percent are against, that is up 16 percent. That means the team arguing against the motion has carried the day. Our congratulations to them, thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
