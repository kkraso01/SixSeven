# Debate Transcript

Topic: Genetically Modify Food
Motion: Genetically Modify Food

Debate ID: 120314%20GM%20Food


## Round 1

### Moderator
Claim: So, please, your first test in spontaneous applause, please welcome to the stage, Mr. Robert Rosenkranz.

Hi, Bob.

### Moderator
Claim: Hi, John. Hi, Bob.

### Moderator
Claim: So-- so this one has a lot of emotion to it. I don't know if you've seen it, but already on our website where we let people sort of vote in an opinion poll sort of way, we have thousands-- thousands of votes coming in today. Why does this one get people so worked up?

### Moderator
Claim: Well, the debates we've had about food always seem to have that effect. We did one on-- on "Don't Eat Anything With A Face." We did one on “Organic Food Is Marketing Hype.” And they've all engendered high emotion, because I think people, many people, look at the food they eat not just as a lifestyle choice or a health choice, but almost as an expression of who they are as people. So the emotions run really, really high when people identify that much with-- with their food choices.

### Moderator
Claim: Okay. So, we have the emotion. Let's just look very briefly at the intellectual side of it. Where can this argument-- these arguments take us?

### Moderator
Claim: Well, I think, to me, the intellectual arguments are sort of first order effects and second order effects. The first order effect of genetically modified food is that farmers can produce a lot more food a lot more efficiently, and that's particularly important for feeding people in the less developed world where hunger is a real issue. So that's a first order effect. But the second order effects, now that we've had 30 years of experience with this, could include things like-- like super weeds or-- or plant species that-- that get immune to pesticides and therefore require more and more of them. So, I think it's going to be-- the intellectual side of this is going to be a debate between first and second order effects.

### Moderator
Claim: And a little bit just on the fact that as a debate, we're going through this tight exercise of arguing on this motion, but it means we want to be specific about what we and what the debaters think this motion means, "Genetically modify food."

### Moderator
Claim: So, I think what we're talking about is genetic modifications that will never occur in nature, that require human intervention to-- to bring about. And we're talking about plants and not animals. I think that's the definition of tonight's debate.

### Moderator
Claim: Well, I know that all four of these debaters care very passionately about this topic, as does, obviously, a lot of the audience. So let's welcome them to the stage. Ladies and gentlemen, our debaters. Thank you, Bob.

### Moderator
Claim: Thank you.

### Moderator
Claim: Okay, we're letting everybody get settled in. I just wanted to mention, when I talked about asking questions of the audience, that I can't ask questions of people who are upstairs. So when that time comes, you may want to come downstairs, and I'll make an effort if I know that you've made the effort, to try and call on you if I can.

And I just want to launch this now, please, with one more round of applause for Bob Rosenkranz for doing all of this.

I'm John Donvan. This is Intelligence Squared U.S. And nature has many unknowns, but one certainty is that tomatoes and fish do not have sex with each other. They never have. And yet, one of the most famous, or some might say, infamous feats of genetic engineering was the development of a tomato whose DNA was mingled with DNA from a fish, which gave it a longer life on the vine, and it worked. Then there's corn, where today some 90 percent of the corn grown in the United States has its DNA mixed with DNA that comes from a bacterium so that it will stand up better to pests, and that works. And is this a good thing, this genetic engineering, that nature could never accomplish on its own? Is it a safe thing? Is it necessary?

Well, those questions sound like the makings of a debate, so let's have it: "Yes" or "No" to this statement, "Genetically Modify Food," a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufman Music Center in New York City. We have four superbly qualified debaters, two against two, who will argue for and against this motion, "Genetically Modify Food." As always, our debate will go in three rounds, and then the live audience here in New York votes to choose the winner, and only one side wins. Our motion is "Genetically Modify Food." Let's meet the team first arguing for the motion. Please let's welcome Robert Fraley.

And, Robb, you are executive vice president and chief technology officer at Monsanto. You've worked there 30 years. You are the winner of the World Food Prize Laureate. That's an award often described as the "Nobel for food and agriculture." And it's related to this debate because of your work on what exactly?

### Conspiracy Advocate (CA)
Claim: Well, thanks, John. Yeah, that was a reward given along with two of my academic colleagues for basically developing the tools that have allowed us to create the GMO crops.

### Moderator
Claim: There at the beginning.

### Conspiracy Advocate (CA)
Claim: Yep.

### Moderator
Claim: Robert Fraley, ladies and gentlemen.

### Conspiracy Advocate (CA)
Claim: And I'm joined tonight by my partner, Alison Van Eenennaam, who is going to talk about the technology as well and the benefits.

### Moderator
Claim: Ladies and gentlemen, Alison Van Eenennaam.

Alison, you are also arguing for the motion, "Genetically Modify Food." You are a specialist in animal science at UC Davis. You said that you chose to study agricultural science when you were still in high school but that it wasn't an obvious choice for you. How come?

### Conspiracy Advocate (CA)
Claim: Well, I'm an urban girl, I was born in the city in Australia, and I'm kind of a science nerd, still am actually, and I was interested in how we might use science to improve the productivity of agriculture.

And it's what I've spent my career pursuing.

### Moderator
Claim: Thank you, Alison Van Eenennaam. That's the team arguing for the motion.

We have two debaters arguing against the motion, "Genetically Modify Food." Let's please first welcome Chuck Benbrook.

Chuck, you are at Washington State. You are known for your research on pesticide use in particular. You've debated with us before actually. You were a proponent of organic food, and you won overwhelmingly, very decisively. So, are you feeling lucky again tonight?

### Scientific Advocate (SA)
Claim: I am, John. We've-- we're well prepared, Mardi and I, and since we have the facts and science on our side I think we'll be fine.

### Moderator
Claim: And tell us, please, who is this Mardi of which you speak?

### Scientific Advocate (SA)
Claim: My partner--

### Scientific Advocate (SA)
Claim: Hello.

### Scientific Advocate (SA)
Claim: --Margaret or Mardi Mellon, is going to help me make the case.

### Moderator
Claim: Ladies and gentlemen, Mardi, Margaret Mellon.

Mardi Mellon, 18 years you are with the Union of Concerned Scientists. Interestingly, while a scientist you are also a lawyer. You are also the only debater onstage tonight with a last name, Mellon, that sounds like an actual edible product.

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: Coincidence?

### Scientific Advocate (SA)
Claim: Well, I don't think so. But my last name also sounds like a bank and--

--money is probably as important as food in this debate.

### Moderator
Claim: Very clever. Ladies and gentlemen, Margaret Mellon. And that's our team arguing against the motion, which is "Genetically Modify Food." I want to say this, I'm hearing hissing. I don't want to hear it, please. And if we hear it, I would appreciate the audience silence the hisser with a round of civil applause because it's just not the way we want to go with it. Okay. So, this is-- now I'm going to get all light again-- this is a debate.

And in that sense it's a contest. It's a contest of ideas and logic and argumentation and wit. And you, our live audience here, acts as the judges in that debate. We have you vote twice, once before the debate and once again after the debate, on your views on the motion. And the team whose numbers have changed the most from the beginning to the end will be declared our winner. So, let's go to the preliminary vote. If you go to those keypads at your seat, again, look at the motion, "Genetically Modify Food," if you agree with this motion as you come in off the street push number one. If you disagree push number two. And if you're undecided push number three. If you push the wrong button just correct yourself. The system will lock in your last vote, and you can ignore the other keys. They're not live. Okay. We're going to lock it out.

So, just remember again how you voted this time, and listen to the arguments, and we'll see how you vote the next time. And then, again, the team with the difference in percentage point terms-- the greatest difference-- will be declared our winner. Our motion is this: Genetically Modify Food. We go in three rounds. And let's go on to Round 1, opening statements by each debater in turn. They will be uninterrupted. They will be seven minutes each. Here to argue for the motion, please welcome Robert Fraley. He is executive vice president and chief technology officer at Monsanto. Ladies and gentlemen, Robert Fraley.

### Conspiracy Advocate (CA)
Claim: John, thanks. And I really appreciate the opportunity to be here. This subject is very important to me. It's really been my life. It started-- I grew up on a-- on a family farm in the central part of the United States. I was one of those-- I wouldn't have thought of myself as a nerd, but I was one of those kids who always knew he wanted to be a scientist. And I had the-- I had the unique privilege, after getting my doctorate degree, to attend the University of California at San Francisco, which was kind of the epicenter where GMO research started.

And even back then, it was pretty clear that GMO technology would have a profound implication in health care. And just as a quick test of the audience-- how many of you know anybody who's a diabetic and takes insulin? So, a lot of hands. So, actually, insulin was the first GMO product. And now, you know, that's the typical treatment. And it's a safer, better product. Today, in health care, just to give you a sense of the transformation, six of the top-selling drugs in the United States are based on GMO technology. So, tremendous progress. Let me-- let me make it a little more food related. How many of you eat cheese? All right. The first actual GMO product ever approved for food use was a product called rennet. Rennet is the enzyme that's actually used to make cheese. And today, 90 percent of our cheeses are based on GMOs, using a safer approach and a more effective way of making the technology.

So, as I said in the introduction, you know, I helped develop the first GMO plants back in the-- in the early 1980s. And then we took about another 15 years of additional studies and development before the first commercial products were launched in the-- in the mid 1990s. And those were products that helped farmers protect against insects and protect against weeds. So, for insect protection, we actually use the very same BT protein that is used by organic farmers for years, and built that into the plants to protect them from insects. And as a result of that, we saw dramatic reduction in insecticide use and an increase in-- in crop yields. And the herbicide tolerant crops, and herbicide tolerant crops have been a great enabler. They've enabled farmers to use safer and more environmentally friendly chemicals and replace the products that were previously used, but they've also had a profound benefit to the environment, of enabling farmers to not plow their soils.

And as a result, use less energy, release less carbon, and-- and reduce erosion, which have been key. Today, if you look around the world, GMO crops are grown in about 27 countries. They're being used by 18 million – farmers. And to put it in perspective, this has been the most rapidly-adopted technology in the history of agriculture. And that's because the benefits have been so real and so clear. As I said, it's reduced pesticide use. It's helped farmers to produce more food and bring it, you know, from their harvest into-- into the-- into the-- into consumption. It's preserved our soils. It's reduced greenhouse gas emissions and a lot of benefits. Now, you're going to hear different perspectives tonight on the technology. But here's a simple logic test. As I said, I grew up on a farm. I've watched my dad make those decisions on which seeds to buy, which equipment to use, et cetera, et cetera. I can tell you that there's no farmer who would plant GMO crops if they didn't have a real benefit.

And they certainly wouldn't have planted them for the last 20 years if they didn't have real value. So, the impact of GMOs has been amazing, and lots of applications across companies and universities. And my partner, Dr. Alison Van Eenennaam, is going to describe a lot of those applications that are still being developed. I'd like to step back and say, as a scientist and a father, the safety of these products is-- is absolutely on the-- on the top of my mind. And what I'm most proud about is the fact that these technologies have been in the marketplace for over 20 years, and there's not been a single, not one issue of food or feed safety ever associated with the technology. And I'd make this point, that there's a strong scientific consensus on the safety of GMOs, as I-- as there is on the role of greenhouse gases and climate change, so that's-- that's very important. The last area I'd like to highlight is that the safety actually starts with the fact that mankind has been genetically modifying and selecting crops from the beginning of time.

And whether you're looking at modern-day corn or tomatoes, or you're looking at peaches or soybeans, we've been moving genes around from the-- from the beginning of time. But through biotechnology, we're able to do it even more precisely, literally one gene at a time, and that's key. Also, this technology is highly regulated. It's regulated by the government agencies in the U.S. But it's important to realize that we export grains to 40 countries around the world who have all researched and approved these products. Alison's going to talk about some of the safety studies. Bottom line from those studies is these are the most thoroughly studied foods in our food supply, and they are absolutely safe. Now, let me make a couple of quick points as a scientist who's been involved in this his-- his whole career. First of all, GMOs are not the Holy Grail. What they are is an important tool, if used properly, can have a huge impact in bringing remarkable new products to farmers and benefit consumers for a long time.

Second, GMOs aren't the only tool we need. We need to continue to invest in plant breeding, we need to continue to invest in new areas like precision agriculture. We need to invest in organic farming techniques and other tools. And finally, let me just say, GMOs, are they perfect? Absolutely not. You know, they need to be regulated, they need to be managed wisely, like-- like any technology. And, for example, we know that insects can become resistant to GMO crops just like they can to other insecticides. We know that-- that weeds can evolve resistance, whether, you know, to herbicides, whether those are herbicides used in GMO crops or other systems. But I also know that-- and I acknowledge that these are legitimate concerns, but I also know that the science can make a huge impact to manage these technologies. So-- and this is so key as we-- as we think about the future, because we are on the brink of facing one of mankind's greatest challenges. Global population continues to grow.

It's going to reach 9.5 billion by 2050. Another 2 or 3 billion people will join the middle class. The demand for food will double by 2050. And so the decisions we make and the votes that you make tonight are really important. We will need to produce more food in the next 36 years than we have in the entire history of the world. So, it's a daunting challenge, and we're going to have to do that in the face of climate change and water shortage as we go forward. But I want to be clear, and I want to leave you with this optimistic note as I summarize. We can do this, but it means working together, and it means--

--finding a common ground.

--and using all of our tools so--

Thank you.

### Moderator
Claim: Robert Fraley, I'm sorry--

### Conspiracy Advocate (CA)
Claim: --finding a common ground.

### Moderator
Claim: I'm sorry, your time is up.

### Conspiracy Advocate (CA)
Claim: --and using all of our tools so--

### Moderator
Claim: I'm sorry. Your time is up. Thank you very much.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Robert Fraley.

Our motion, "Genetically Modify Food." And here to speak against this motion, Margaret Mellon. She is a science policy consultant and former founding director of the Union of Concerned Scientists Food and Environment Program. Ladies and gentlemen, Margaret Mellon.

### Scientific Advocate (SA)
Claim: Thank you very much, and thanks to Robb. He made a number of points that I think we're going to come back to over the-- over the course of the debate. But I want to focus my remarks, really, on just one point, and that is whether or not genetically modified or genetically engineered-- I'm going to use those two words interchangeably-- whether those technologies are essential or even an important technologies for meeting the challenge of feeding 9 billion people without destroying the earth. And that means raising our productivity but without dead zones in the Gulf of Mexico, without a Lake Erie or that has-- you know, in some parts of the year is now just a toxic algal soup. It's a huge challenge. Now, I'm going to argue against that. But I understand why a lot of people believe that genetic engineering is the answer.

And I think a lot of that has to do with the way the technology debuted. I mean, I was there in the early days when Monsanto came up with its products. I was working in Washington, D.C. for the environmental community. The place was abuzz with the idea that a new molecular technology was on the way that would convert agriculture into an environmentally benign activity. I was at the wildlife-- at the National Wildlife Federation when Monsanto folks came and said, “You people in the environmental community ought to be the first to embrace this technology because it's going to reduce pesticide use." I wanted to learn more, and I did when I went to Monsanto and got the tour out in St. Louis. And I was told, it's not only going to reduce toxic use of chemist-- of chemicals, it's going to produce crops that can fertilize themselves.

It's going to produce crops that are high yielding, that'll make famine a thing of the past, that are re-- resistant to stress, to cold, to drought, to heat. It was a-- it was a really compelling and-- and a vision I was really taken by. My big question was that it was a brand-new technology using very new techniques, and would it work? Well, we have had now 30 years to find out whether it's going to work, billions of dollars in investment in it. And I think there's just no doubt that compared to the vision, the early vision, it's a big disappointment. Now, after 30 years, there are no crops out there that fertilize themselves. There's one drought-tolerant crop that's drought tolerant because of genetic engineering.

There are no crops whose yields are the result of genetic engineering apart from making them better able to deal with pests. You know, there are no genetically engineered crops that resist water logging. I mean, you name it. It really hasn't happened, with one exception, which we've heard about, which is in the area of pest management, genetic engineering has been wildly successful. I mean, people have adopted it all over the world. And-- and that's because in the early days, the technology did deliver. It made it possible-- people that use Roundup-ready crops and Bt crops in the early days, their pesticide use went down. That's why their costs down, that's why their farms were easier to manage, even as they got bigger. And farmers-- you know, farmers were really happy about that.

But, you know, as one farmer has said, not too recently, the days of-- I mean, we've run through the best herbicide that the-- that the world had to offer. Glyphosate is no longer as useful as it once was, and it's getting less useful every day because resistant weeds are coming, and those resistant weeds are leading to more-- those resistant weeds are leading to greater and greater use of herbicides. And we are now at a point where, I mean, if you look forward, I'm going to let my colleague, Dr. Benbrook talk about this more, but there is, you know, nothing ahead of us except skyrocketing use, not only of Glyphosate, which is the major herbicide in Roundup, but of other herbicides-- 2,4-D, Dicamba-- herbicides we thought we'd never have to use much of-- much of again.

So, I guess to answer-- what I want-- I do want to say that we-- we now know why. I mean, genetically engineered-- it turns out to be a lot harder to do genetic engineering than I think anybody thought in the early days. And it's especially hard when you're dealing with complex traits that involve a number of genes. That's why yield and stress resistance have proven to be so difficult. But these pesticide technologies have involved really only the transfer of a single gene, and they-- you know, they have worked in the case of the two products we've talked about. But, you know, to answer my first question, a technology that, after 30 years, has not delivered, you know, on the full-- on the full range of products that it kind of promised to the public early on, and in the one application where it has delivered, the benefits of the technology are now being reversed, and we are going in the direction of increased herbicide use.

I mean, that is not a technology that is either essential or I would argue even important to addressing the major agricultural challenges ahead of us. Fortunately, we've got other technologies out there. They're far more powerful than genetic engineering. They’re traditional breeding and agro economy-- ecology we're going to talk about them later. But before we can talk about them, we need to be clear about what genetic engineering can't do. And we don't want to ban it, we don't want to abandon research on it, but we do kind of want to move it off to the side of the-- of the stage. And in order to do that, you have to rebalance the debate. You have to kind of take the rose colored glasses off and you can start that process right here, right tonight, by voting "No" on "Genetically Modify Food."

### Moderator
Claim: Thank you, Margaret Mellon.

And a reminder of what's going on, we are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, arguing it out over this motion, "Genetically Modify Food." You have heard two of the opening statements, and now on to the third. Here to debate for the motion, Alison Van Eenennaam. She is a genomics and biotechnology researcher and cooperative extension specialist in the Department of Animal Science at UC Davis. Ladies and gentlemen, Alison Van Eenennaam.

### Conspiracy Advocate (CA)
Claim: Wow, it's a great turnout here tonight, it’s not my usual audience. I spend a lot of my time talking to farmers and ranchers. And it's my pleasure to be here speaking to you tonight. I'd like to start with a premise that I hope we can all agree on, and that is in the future more people are going to need to be fed better with less environmental impact. And as a public sector scientist, my interest is finding real-world solutions to that problem.

And to me GM food offers one of those solutions. It's derived from crops produced using a breeding method based on the movement of useful genes from one species into another. Tonight I'll spend some time discussing the impressive safety record of GM crops, how they've provided well-documented benefits, and how GM is sometimes uniquely able to deliver a useful trait like crops that are more resilient to climate change. And I will contend that the benefits of GM are too great to vote anything but "Yes" for GM tonight. GMO technology often gets conflated with Monsanto and Big Ag, but it's actually a breeding tool, one that can be used for many purposes. In my own research, in selection for disease resistant cattle, I use many breeding methods, including classical selection for healthy animals and, more recently, the use of DNA markers to assist in selecting for disease resistant genes.

As a geneticist I can envision how combining GM with these other breeding methods, because they are not mutually exclusive, could accelerate the progress of my publicly funded research program by enabling me to use GM to directly protect cattle from infection. This would be associated with reduced illness and the decreased use of antibiotics, something I think is perhaps a common shared value amongst this group. As Robb mentioned, most commercialized GMO crops today have been made to resist insects and herbicides and have been adopted by 18 million farmers globally, but importantly 16.5 million of those farmers are in the developing world, both men and women, some of whom farm areas smaller than the size of the auditorium tonight. What have been the impacts of this widespread adoption? As a scientist I go to the independent, peer-reviewed literature to answer such questions, especially reviews and meta-analyses that present a summary of many independent studies. It's like a well- informed referee presenting an objective assessment of the state of play.

Recently, German university professors published a comprehensive analysis of 147 separate studies that assess the impact of GM crops. They found that the benefits were significant not only in the U.S. but more importantly in the developing world. On average, GM technology adoption has reduced chemical pesticide use by 37 percent, increased yields by 22 percent, and increased farmer profits by 68 percent. The yield gains are due to more effective pest control and thus lower crop damage. And the benefits have been largest for smallholder farmers in developing countries who have dramatically reduced their insecticide applications as a result of GM crops. This has benefitted both farmer health and also the environment and beneficial insects. Now researchers throughout the public and private sector are using this breeding tool to deliver other benefits to society. Researchers at Hawaii and Cornell University have used it to produce a virus resistant papaya, a product which has literally saved the Hawaiian papaya industry.

Other introductions include drought resistant corn, virus resistant squash, consumer traits like a non-browning apple, a low-acrylamide potato, and crops that produce oils improved for nutrition. None of these applications require the use of any chemical pesticides, an issue that often gets conflated with this technology. University researchers are working to develop GM oranges that are resistant to citrus greening disease, something that is devastating the Florida orange industry. And here in New York, researchers are using a wheat gene to develop GM American chestnut trees resistant to the imported chestnut blight. If approved, these trees will be distributed to the public in a not for profit program to restore the American chestnut tree to the eastern forests. Plant diseases annually destroy some 15 percent of our world's agricultural harvest, a number that is likely to grow as our climate changes.

There are many publicly funded groups around the world, working to develop GM- disease resistant varieties of crops, including apples, bananas, cassava, cowpea, eggplant, grapes, potatoes, rice, sweet potatoes, and wheat. Some of these staple crops are an essential source of nutrient in the diets of the poor. And it doesn't stop at plants. Researchers at CUNY are working with an international consortium to develop genetically-engineered cattle that are resistant to African Sleeping Sickness, a disease that kills several thousand people and three million cattle annually. This project is being publicly funded by the Bill and Melinda Gates Foundation, and the U.S. National Science Foundation. All of these GM applications focus on controlling disease with genetics rather than chemicals, an objective that I would argue is compatible with agroecology, sustainability, and feeding more people better with less environmental impact. There are literally dozens of other applications and field trials globally.

Nitrogen-efficient and flood-tolerant rice. Drought-tolerant wheat. And BioCassava Plus, a private-public partnership that will use GM to increase the nutrient levels, shelf life, and disease resistance of cassava, a major source of carbohydrates in parts of the world. Improved cassava harvests could increase the incomes of African households, helping lift poor farmers-- many of them women-- out of poverty. I could go on, but none of this would be possible without the broad scientific consensus about the safety of GM and solidated and support that consensus. A 2013 review article, written by independent Italian public sector scientists, reviewed over 1,700 scientific records on GE crop safety published this past decade, and concluded that the scientific research conducted so far has not detected any significant hazards directly connected with the use of GE crops. My own 2014 review paper examined both well- designed animal feeding studies and the field performance and health trends of the over 100 billion food producing animals that have been consuming GM feed over the last decade, and found no credible evidence of harm.

The American Association for the Advancement of Science, the world's largest and most prestigious scientific society, stated in 2012 that science is quite clear: crop improvement by modern molecular techniques of biotechnology is safe. They're joined by the World Health Organization, the American Medical Association, the U.S. National Academy of Sciences, the British Royal Society, and every major regulatory agency in the world. Given the realized benefits, the potential of this science, and the documented safety record, I urge you to allow breeders to use this valuable method to improve crops and vote yes for tonight's motion.

### Moderator
Claim: Thank you Alison Van Eenennaam. And the motion is, Genetically Modify Food.

And here is our final debater to speak against the motion, Chuck Benbrook. He is a research professor at the Center for Sustaining Agriculture and Natural Resources at Washington State University. Ladies and gentlemen, Chuck Benbrook.

### Scientific Advocate (SA)
Claim: Thanks, folks, and thanks to Intelligence Squared for having me back. I figured I used up my welcome last time, but glad to be back again. Well, I guess the reason we're having a debate is perhaps there isn't complete agreement on some of the things that we've been discussing already. In fact, you know, Robb and Alison, if all of what you said was true, I would be over there at your side of the table, going at it with-- with poor Mardi all by herself.

I do think it's time for sort of a national fireside chat about the applications of agricultural biotechnology in food production. And I'm actually glad it's happening. We've had a number of highly contested state level ballot initiatives on labeling of GE food. And as a result, the awareness and consciousness of people around the country is going up. And that's a good thing.

The-- there's tough choices for our society about whether we want to go down this road of more intensive, specialized input intensive agriculture, kind of with genetic engineering leading the train, or whether we want to steer agriculture in some other directions. So, a couple of things I ask of the audience, as you listen to the back and forth tonight. And there'll be-- there'll be a lot of it. I ask you to vote on the reality of what genetically engineered crops, the ones that are on the market today, have actually brought about, and not just how well they work for the first three or four years. And I think, you know, the record is very clear, they were rapidly adopted. They worked very well. They were spectacularly effective in particularly the Roundup Ready crops. And these are the so-called herbicide tolerant crops, which made it easy for farmers to control weeds in corn, soybeans, and cotton. Those were the three big crops. We'll mostly talk about those tonight.

So, don't-- you know, don't base this on the promise and the aspirations of the biotechnology industry and the things that the biotech industry thinks that at some point the science will deliver, things like corn plants that fix their own nitrogen or drought tolerant crops or nutritionally enhanced crops. Some of these things may eventually be achieved, but they haven't yet. And I ask you to think about the-- what's the reality of genetic engineering agriculture today as opposed to the promise or the aspiration. I also suggest and ask you to think about the impacts of genetically engineered crops as a package. It's not just the genes that Robb Fraley and his colleagues at Monsanto were able to work into the corn plant, but you have to think about how that corn plant behaves in the field, the yields, what the impacts of the BT proteins that are all throughout that plant are on the environment, on aquatic ecosystems, on the cost to farmers.

And, of course, in the case of the herbicide tolerant crops, the great concern is this huge increase in herbicide use that's started about a decade ago and has gotten worse and worse and worse each year. And now the-- the industry and the government has just approved the next generation of herbicide-tolerant crops that are now engineered to tolerate two of the riskiest old herbicides that have been in use for a long time. You'll hear the word "2,4-D" and "Dicamba." This is definitely not a step in the right direction. So, we have to think about the totality of the impacts, including we have put so much energy as a country, and the industry has put most of its plant-breeding effort or eggs in the GE basket for these herbicide tolerant crops and BT crops. And there's a lot of other priorities that plant breeders have not focused on as seriously as they should have.

And that is a cost of the technology. We're going to talk a lot about safety today. Rest assured there is no consensus about the safety of GE foods, and there are a number of reasons to be more concerned in 2014 than we were in 1996, the year that they were introduced, or in 2000, which was about the time the adoption of herbicide tolerant soybeans was very high. And, really, with each passing year, as more and more GE plants are grown, as more herbicides are required to bring them to harvest, the list of both health concerns and environmental concerns is growing. And I'm sure we'll get back to them. There was a National Geographic, wonderful National Geographic series about the future of food the last year. And perhaps many of you read at least some of them.

In the May 2014 issue of National Geographic, there was kind of a capstone piece that sort of presented a plan forward-- to meet the needs of 9 billion people on an earth with shrinking resources. And this guy, Jonathan Foley, an academic from the University of Minnesota, he wrote a piece, "A Five-Step Plan to Feed the World." It's really a great piece. It's short. So, here's where his five steps, and I quote exactly how he states them. "Freeze agriculture's footprint." And by this, in his discussion, he's talking about, let's not clear any more tropical rainforests. Let's leave most of the wild lands wild. Second, "Grow more on the farms that we have." And this is absolutely right on. I mean, you know, in-- in the developed world, farmers, you know, harvest 150 to 250 bushels of corn, in Africa, you know, 40 to 60.

So, there's great potential around the world to raise the yields on the-- on farms that really have worn out soils, don't have access to a lot of input. So growing more on the farms we have is clearly a critical part of the solution. His-- Foley's third way to help feed the world, it was, "Use resources more efficiently." This is kind of a no-brainer. It's-- it's something that obviously most of the agricultural inputs that today's corn, soybean and cotton farmers use are petroleum based. As the price of energy goes up, their prices is going to go up. And perhaps their availability will come into question. So, obviously we have to use petroleum-based inputs more efficiently and water more efficiently. The fourth, a very important one: "Shift diets." Us Americans, people in Europe, we-- we eat very high on the hog.

We eat a lot of meat, and it takes a lot of food calories to produce a single calorie of beef, about 100 to 1.

Thank you.

Well, good.

### Moderator
Claim: Chuck Benbrook, I'm sorry. Your time is up.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Thank you very much.

### Scientific Advocate (SA)
Claim: Well, good.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is "Genetically Modify Food." So, keep in mind how you voted at the beginning of the evening. I'll remind you one more time that you'll be asked to vote a second time after you've heard all of the arguments. And the teams whose numbers have changed the most in percentage point terms will be declared our winner. Now on to round two. Round two is where the debaters address one another directly and take questions from me and from you at our live audience here in New York. Our motion is this: "Genetically Modify Food". The team arguing for the motion, Robert Fraley and Alison Van Eenennaam, have argued that genetic engineering of food is no Holy Grail, but that it is a tool that can be used to help an enormous number of people.

They say the proof of this is the fact that farmers have been using it because, in fact, it works for them. She says their safety has been established over 20 years without a single known injury related to the consumption of genetically engineered food, that the studies are a waterfall of support for this argument and also for the benefits themselves of genetically engineered food. And they talk about the possibilities in the future of plants that can crush, absolutely crush plant disease and survive, which would be better for all. It's a lot of promise about the future. The team arguing against the motion, Margaret Mellon and Chuck Benbrook, they're saying, don't look at the future. Look at the present. And their argument is that so far, genetically engineered food has not lived up to its promise. It's pulled off a couple of very neat and important tricks, but not all that was promised in the beginning. They say that they're not necessary, that they are not proven safe and that in fact contrary to the other side's assertions that there is no consensus on their safety.

I want to go first to the safety question and take the argument back to Chuck Benbrook who just completed your opening statements. Chuck, you said that there is no consensus on this. Your opponents have actually framed the statement that there's no scientific consensus on the safety of genetically modified food as being akin to people challenging the science behind global warming, that-- that you have-- they didn't literally say this, but you have to be a little bit of a crank not to-- not to buy the science. What's your response to that?

### Scientific Advocate (SA)
Claim: I've read essentially all the statements by various bodies. And here's what they essentially all say. They use slightly different words. They say the genetic engineering of food as a technology does not create any new or different potential risks in the modified foods that other forms of plant breeding don't.

Several of the reports, including both of the two National Academy of Sciences reports that specifically address this say that there is a possibility that genetically engineered foods may pose higher risk of that nature, but we really don't know. They also all say that there's no convincing evidence now or at this point that there's been acute health problems in the U.S. population from the consumption of genetically engineered foods. And then they all go on to call for further investment in the development of more sensitive, scientific techniques to assess the possibile risks, and they also call for post approval surveillance. Most of the recommendations for better science, more careful risk assessment and post market surveillance that have been made for over 15 years, in these reports have not been acted upon--

### Moderator
Claim: All right, let's--

### Scientific Advocate (SA)
Claim: --in the U.S.

### Moderator
Claim: Let's let your opponent, Robert Fraley respond.

### Conspiracy Advocate (CA)
Claim: So, first of all, you know, don't want to repeat what I said earlier, but, you know, this science is-- has been around literally since the 1970s and had broad applicability to health and agriculture with an impressive safety record.

I mean, not a single issue of animal or human safety with the technology. That's because it's inherent that we've been moving genes from the beginning of time, but also, I just want to illustrate how important the regulatory oversight has been. Chuck and I first met when we put in place the USDA EPA and FDA oversight, which is still the gold standard around the world. But every country that we ship corn or soybeans to around the world has already done their independent health and safety assessments as well as literally thousands of academic studies that all point to the same conclusion that's been codified by every major science organization around the world.

### Moderator
Claim: All right, let me stop you for a second.

### Conspiracy Advocate (CA)
Claim: These products are safe.

### Moderator
Claim: I just want to ask Margaret Mellon, do you concede that point, or do you refute it?

### Scientific Advocate (SA)
Claim: No, I do not concede it.

### Moderator
Claim: So what-- what's wrong about his facts then?

### Scientific Advocate (SA)
Claim: Well, I think that there is agreement that there is no evidence that the current applications of genetic engineering have dramatic acute short term--

### Moderator
Claim: No, no, but the thrust of the argument-- and then you can go on for your point--

### Scientific Advocate (SA)
Claim: Yeah, sure.

### Moderator
Claim: --the thrust of his argument is that there has been an enormous amount of vetting going on at government levels around the world and that this in itself would act as a safety net, do you refute that, that sort of vetting is going on?

### Scientific Advocate (SA)
Claim: I think that there's a lot of review that's going on, and I think that it is focused on the point that I've just made, that there are no acute dramatic effects of the consumption of genetically modified organisms. All of those assessments have left open this notion-- two things, one, that there could be subtle long term effects that we have not identified and that each application of genetic engineering needs to be looked at separately. So, whatever you say about Roundup Ready crops, that says nothing about these new gene silencing technologies that are right up the way.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: So, a blanket assertion of safety isn't scientifically justified.

### Moderator
Claim: Alison, Van Eenennaam, would you like to respond?

### Conspiracy Advocate (CA)
Claim: Sure, I mean, as a scientist like I would never make a blanket assertion about safety and I think it's very much dependent on each particular review. But I think that as a scientist I let the data tell me whether there are safety concerns. And after 20 years and thousands of studies and I feel the weight of the thousands of academic colleagues throughout the world that have done these safety studies--

### Scientific Advocate (SA)
Claim: But let's look--

### Conspiracy Advocate (CA)
Claim: --that haven't found unique concerns that I have to accept the evidence for what it is and let the data tell me whether it's safe.

### Moderator
Claim: Margaret Mellon.

### Scientific Advocate (SA)
Claim: --but let's look at data like the kind that you've accumulated in your meta-analysis. You're looking at cows, cows that are killed when they are very young, maybe 14 or 15 months old, and you're drawing from the fact that there haven't been kind of increased condemnation rates at slaughter for cows over a long period of time.

### Moderator
Claim: Wait. Can you just back up on the term of art? So looking at cows because they're actually consuming the feed that's--

### Scientific Advocate (SA)
Claim: They're consuming the feed that's-- that is--

### Moderator
Claim: --and they're opening them up and they're not finding what?

### Scientific Advocate (SA)
Claim: Well, they're all-- I believe that Alison can tell us what she found in her study, but she just looked at the rates of condemnation when--

### Moderator
Claim: What's that word?

### Scientific Advocate (SA)
Claim: I mean, when you get--

### Moderator
Claim: Wait, condemnation.

### Scientific Advocate (SA)
Claim: --what-- you-- if a-- if someone brings an obviously ill carcass to a slaughterhouse--

### Moderator
Claim: It can't be sold as meat.

### Scientific Advocate (SA)
Claim: --right--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --they are not going to be allowed to sell it. And if you look at those rates and correlate them with-- you look at them over the time that we've been growing and that animals have been consuming this food, I think that's a valuable study and it tells you something. But it doesn't tell you very much. It certainly doesn't tell you about the effects of these crops even on animals who live a full lifetime.

### Moderator
Claim: What would tell us? And I want to go to the other side. Just so--- I can give you 10 seconds-- what kind of study would tell us the answer?

### Scientific Advocate (SA)
Claim: You need to do long term studies in animals, you need to do them progressively--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --and we, in fact, need protocols for how to do the kinds of studies that need to be done.

### Moderator
Claim: Okay, that's 10 seconds. Robert Fraley.

### Conspiracy Advocate (CA)
Claim: If you look at Alison's review, there's over two dozen long term animal studies that point to exactly the same answer, that these products are safe, and that's absolutely a fact. And the same agencies that have reviewed all of this data are the same agencies that have reached the same conclusion on the gravity of science around global warming. You know, you go to the National Academy, you go to all of the major organizations, at some point, you know, if-- consensus doesn't mean everybody agrees, it doesn't mean that there's a complete 100 percent alignment just like there isn't on global warming, but the science speaks for itself there, and the science has reached a consensus on this.

### Moderator
Claim: But, Chuck, you said that if you thought that you would go to the other side, that you're not married to your position, that you're married to data, because they're saying they have much more data for their position than you do.

### Scientific Advocate (SA)
Claim: A couple of really important points need to be made. The genetically engineered crops on the market today that are being planted by farmers and have been in the last few years are different from the genetically engineered crops that were planted in the early days.

Rob Fraley and his colleagues have brought out a continuing series of improved more effective products. And one of the things that they've done is they've stacked multiple traits into a single corn. One of the big concerns in the scientific community is that the Cadillac GE corn that Monsanto has developed, it's called, "SmartStax," and it actually expresses eight different traits. There's six different Bt proteins that are expressed to control different insects and two genes that confer tolerance to Glyphosate Roundup herbicide and another herbicide called, "Glufosinate." Well, this mixing of eight different traits in this single genetically engineered corn plant raises some, you know, important scientific concerns, just like when you go to the doctor the doctor's going to ask you what drugs you've been-- what other medications you might be on before prescribing you something else for some other problem you may have.

### Moderator
Claim: So--

### Scientific Advocate (SA)
Claim: The regulatory agencies, the industry-- no one has done any serious research on the potential problems from these stacked traits that are in today's GE food.

### Moderator
Claim: Alison--

### Scientific Advocate (SA)
Claim: question.

### Moderator
Claim: --Alison Van Eenennaam, is that sort of study called for? In other words, your opponents are saying, "We're getting into so many areas where we've never been before that we should go in a very, very cautious way and try to stay ahead of disaster by figuring out what's dangerous.

### Conspiracy Advocate (CA)
Claim: Well, I mean, I guess, as a breeder, we routinely stack traits. We're always selecting for multiple traits going into the--

### Moderator
Claim: So, this to you all familiar--

### Moderator
Claim: --and old hat. It doesn't feel--

### Conspiracy Advocate (CA)
Claim: That's-- well--

### Moderator
Claim: --new to you.

### Conspiracy Advocate (CA)
Claim: --it's breeding. You're always trying to improve multiple traits. And I think I need to understand the scientific kind of hypothesis, why stacked traits would be more dangerous when the individuals are not separate. I guess it's like looking at a broccolini, and you know broccoli is safe and the other plant that was crossed-- why would a broccolini be more dangerous than its two parents?

So, what's your biological basis?

### Scientific Advocate (SA)
Claim: The debate isn't about broccolini, it's about GM foods. And I'd like to get back to what Robert Fraley said about they're accepted around the world. I mean, Robert, you know about the problems your sister company, Syngenta, has now getting corn shipments into China. In fact, the corn industry is very concerned about the growing rejection of shipments in China and some other countries, because of unapproved traits. And in fact, we've been reading about ADM and Cargill, two of the largest grain companies in the United States-- have sued Syngenta. And there's, like, 50 lawsuits from farmers because of the lost income. So, it's really, I think, disingenuous to suggest that all over the world, all countries have opened their arms to GE crops, when, in fact, the trend--

### Moderator
Claim: All right. Let's let-- let's let him respond to that.

### Scientific Advocate (SA)
Claim: --is

### Moderator
Claim: Robert Fraley.

### Conspiracy Advocate (CA)
Claim: So--

### Moderator
Claim: So, the pictures

### Conspiracy Advocate (CA)
Claim: --I'd be happy to respond to that, although it's, you know, someone else's product.

But I just want to come back to--

### Moderator
Claim: No. No. I want you to stay on point. I want you-- you can come back later.

### Conspiracy Advocate (CA)
Claim: I'll return to it. So, the question-- we got into this-- was--

### Moderator
Claim: But Robert--

### Moderator
Claim: --but let me run the debate, okay? I did--

### Conspiracy Advocate (CA)
Claim: I know you do a great job of it, John.

### Moderator
Claim: And I will-- but I will come back to you. I will give you a chance to do that.

### Conspiracy Advocate (CA)
Claim: Perfect. That'd be-- that'd be great.

### Moderator
Claim: I just want-- I want t come to the point, because it's right in front of us now, that--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: --the picture you-- part of the argument you made was that the ready acceptance around the world. And your opponents just stated--

### Conspiracy Advocate (CA)
Claim: Right. So--

### Moderator
Claim: Okay. Not your company, but the product--

### Conspiracy Advocate (CA)
Claim: Sure. So let's talk about it. So, the issue is, to get the products sold in the United States, you get FDA, USDA, and EPA approval. But then you get the import approval from all the countries around the world. Syngenta got the approval for every country but China. And China is notoriously slow in their regulatory process. And you know, there may be a little politics involved in this particular case. But they got 38 out of 39 import approvals, and there's one more to go. And I know they've been working really hard to get that approvalAnd you know, it's unfortunate, when there's a market disruption. But it probably wouldn't surprise folks here to know that there's sometimes a little bit of politics and a little bit of mischief behind the scenes. And that's what's going on here.

### Moderator
Claim: Margaret Mellon to respond.

### Scientific Advocate (SA)
Claim: Well, I-- I mean, I think it's very important to note how much hassle-- trade hassle-- is associated with the fact that the U.S. continues to embrace and push genetically- modified food on the rest of the world-- some of whom like it and many of whom don't. In fact, there's, I think, a billion dollars of lost sales as a result of this-- of this trade disruption that we're talking about. But that's just one of many. I mean, there have been contamination incidents of all kinds that have resulted in American crops being turned back. I mean, this is an expensive technology for us to push in today's world.

It's amazing to me that the big grain traders, Cargill and--

### Scientific Advocate (SA)
Claim: ADM.

### Scientific Advocate (SA)
Claim: ADM, are suing the biotech companies. And they're suing them for huge amounts of money. I mean, this is-- this is serious business to them. They're losing them on a lot of money, and they're frankly not getting much in the way of--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --of benefits from the technology. So, I mean, I think it does signal that there is discomfort with technology around the world. Some of it may be--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --political, but it's sure

### Moderator
Claim: Margaret, I'm going to stop you there, because point made. Robert, I did say I'd let you come back to your point. So, it's your time.

### Conspiracy Advocate (CA)
Claim: Sure. So, just, you know, you said a lot about trade. Let me just make the point. 60 percent of the U.S. corn gets exported around the world and a third of our soybeans to markets that accept these products. We are the breadbasket to the world. It's unfortunate when there's a disruption, but it's been really minor against the context of the benefits that these products have provided for food security.

The point I was trying to make on the safety studies is each of these genes is regulated, individually looked at, and they are also looked at collectively, and there is no reason to believe that they have any concern in terms of stacking them together. In fact, Chuck, I remember one of the first times we met. You actually reminded me that the best way to bring this technology into the marketplace was to bring multiple products together so we had more durability and better insect protection. In so many cases, the industry's done exactly what you've said.

### Scientific Advocate (SA)
Claim: Yes, that-- that's true. I mean, we--

So, to have six different BT proteins in corn, the idea kind of goes back to the Frank Sinatra song, you know, if the right one don't get you, then the left one will. But the problem is we know that insects, they-- they have the ability-- once they develop resistance to one BT protein, it becomes much easier and quicker to develop resistance to others.

And we now know, both in cotton insects and in corn insects, we've got corn root worms out there resistant to three of the six BT proteins in his corn already, and it's only been on the market for four years. So while having multiple BT proteins in there sort of sounds like a good idea, it's already not playing out as planned. And think about it. On an acre of corn, the six different BT proteins add up to 3.7 pounds of the Bioinsecticide that's inside that corn. And that is allowing farmers to not use a tenth or perhaps 2/10 of a pound of a soil insecticide. So, how do you reduce pesticide use if you're replacing 2/10 of a pound--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --with 3.7 pounds.

### Moderator
Claim: So you moved to where I wanted to go next, which is into the effect on the environment. So we've discussed safety. Everybody said what I think they're going to say on it, and there's a bit of an impasse. But the impact on the environment.

And Alison Van Eenennaam, your opponents have said that in fact after getting off to a good start, in a sense, the big success story of Roundup ready wheat and BT corn have somewhat backfired and that their impact on the environment has become to be a negative because they led to the use of-- as you-- weeds resistant to-- to herbicide and to pesticides and more spring as a result. What's your response to that?

### Conspiracy Advocate (CA)
Claim: Well, I mean, again, I think you've got to look at the application and what the actual product is. And I think it's that the effective of BT crops has been a dramatic reduction in insecticide use, especially in the developing world. And, I mean, I stated the summary of that paper which said the adoption has reduced chemical pesticide use by 37 percent. So I think that, particularly BT crops have led to reduced use of insecticides. There have been a number of studies that have looked at herbicides. And depending upon which country you're talking about and which study and which crop.

In some cases they've substituted Roundup for a different herbicide that they were using that was more environmentally degrading and that stayed longer in the environment and so they've--

### Moderator
Claim: Okay, you--

### Conspiracy Advocate (CA)
Claim: --moved to a safer herbicide.

### Moderator
Claim: You nailed that point. I just want to take it to your opponent to respond.

### Scientific Advocate (SA)
Claim: I just want to, you know, point out--

### Moderator
Claim: Margaret Mellon.

### Scientific Advocate (SA)
Claim: --that, for example, the-- the metastudy of the 147 other studies, none of those studies were done after the evolution of resistant organisms, of resistant insects.

### Moderator
Claim: So, you're saying we don't know? You're saying that what your opponent--

### Scientific Advocate (SA)
Claim: No. I'm saying that the good news stories about biotechnology crops-- and there are some-- are all from the early days. But we know that it is inevitable that resistance is going to develop. I also want to say-- and will undercut all of the benefits that we're talking about. I also want to say that the 147 studies really didn't-- they did prove that there were benefits to GM crops, but not to GM traits.

They often compared one group of farmers, say, in India, who had adopted the technology, say a GM cotton technology with other farmers who hadn't. But the GM crops that were grown by the adopters were often much higher-- they'd been conventionally bred to have much improved genetics. And so what you were really comparing was better conventional genetics and a BT crop to-- to kind of poorer genetics without a BT trait. And you know, that really says more about the importance of traditional breeding than it does about GE.

### Moderator
Claim: Does she actually have a point in that analysis? Robert Fraley?

### Conspiracy Advocate (CA)
Claim: I don't think so.

### Scientific Advocate (SA)
Claim: The way to do those studies, if you want to identify the role of the GE trait, is to take isolines that don't have the GE trait, have farmers grow them under the exact same conditions as other farmers who are growing those crops with the GE trait and then see whether there is--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --any difference in-- and those-- and the 147 studies

### Moderator
Claim: Let's let Alison van Eenennaam come in.

### Conspiracy Advocate (CA)
Claim: That's actually-- I mean, that's what's done as part of the agronomic assessment of the performance of GM crops. But these were actual field studies done throughout the world by independent researchers looking at what the actual effects have been. And the effects have been--

### Scientific Advocate (SA)
Claim: I said, you've got to-- you've got to--

### Moderator
Claim: Yeah, let me bring in--

### Scientific Advocate (SA)
Claim: --isolate the GE trait if you're going to give the GE trait credit.

### Moderator
Claim: So let's-- Chuck Benbrook.

### Scientific Advocate (SA)
Claim: John asked about-- to open up a discussion of the environmental impacts. Roundup ready crops are grown now on--

### Moderator
Claim: Take, 10, 15 seconds and tell people the dynamic of Roundup ready crops.

### Scientific Advocate (SA)
Claim: Okay, so a farmer has a field of corn, soybeans, cotton, and weeds come up. In the past, they had to spray certain herbicides early in the season or cultivate the soil.

But--

### Moderator
Claim: And it was called Roundup. Or one of them was called Roundup.

### Scientific Advocate (SA)
Claim: Well, the-- roundup is Glyphosate herbicides. And in 1996, the first genetically engineered so-called herbicide tolerant crop came on the market. And scientists at Monsanto put a new gene into corn, soybeans, cotton and now other crops that makes it possible to spray to Glyphosate, which kills everything green that's growing. It would kill the corn without the gene. And so farmers can spray this broad spectrum herbicide, a very effective herbicide--

### Moderator
Claim: And not kill their corn.

### Scientific Advocate (SA)
Claim: Not kill the corn, but kill the weeds. But what's happened is in the early years, it worked great. But in 2000, in Delaware, in a soybean field, the first Glyphosate resistant weed-- it was a Marestail, was created by Roundup ready soybeans. And scientists that warned about this happening before they were developed-- and even predicted it would take about five years-- there it was.

Okay, so the industry-- okay, we better watch it. By 2004, we had six or eight different serious Glyphosate resistant weeds, mostly in the southeast, including this Palmer Amaranth that the roots of it-- the stock of it can get as big as a person's wrist. And it was breaking the cutter bars on cotton harvesting machines. And now there's like a hundred-- a hundred million acres--

### Moderator
Claim: I'm going to give you 15 more seconds. How did those weeds get to be resistant to Roundup? What did they-- what was their interaction with the corn?

### Scientific Advocate (SA)
Claim: When you spray one herbicide over and over again on weeds, they're going to develop resistance.

### Moderator
Claim: Okay. I just wanted people to understand. So, a random mutation. So, I want to take that to Rob Fraley. This is your area.

### Conspiracy Advocate (CA)
Claim: Yeah, let me reel all the way back in terms of the herbicide tolerant crops and the benefits they provided. So, in the old days, when I was a kid growing up, I'd come home from school, I'd get on my dad's tractor, and we'd plow all the fields this time of year, and we'd turn all the dirt over, and that was the method that people used to kill weeds.

The big benefit of Roundup ready crops is it gave farmers the ability to use Roundup. How many of you in the audience have ever used Roundup to control weeds? I mean, it's very effective. It's a very safe product. It's generally regarded as the gold standard. So it gave farmers a more environmentally friendly and a safer tool for controlling weeds. But the huge benefit, and absolutely the huge benefit of herbicide tolerant crops has been the fact that it has basically eliminated tillage. We don't plow fields any more. We don't expose that dirt to evaporation of the moisture. We don't have the erosion. We don't have the instantaneous release of greenhouse gasses when the flip the soil over. And since the adoption of herbicide tolerant crops in this country in the mid '90s, the rate of not plowing, of using conservation tillage has more than doubled.

### Moderator
Claim: But, Robert, are you--

### Conspiracy Advocate (CA)
Claim: That's a huge benefit.

### Moderator
Claim: --going to get to the point about-- are you going to get to the part about the weeds becoming resistant?

### Conspiracy Advocate (CA)
Claim: Sure, absolutely. It's real simple. Evolution is alive and continues. And, frankly, you know, we're going to see, as I think we get into issues of climate change and changes in microenvironments, we'll probably see more evolution and more resistance. Here's a simple question: You've all heard of antibiotic resistance. It's a problem, right? You're aware of it. So what should drug companies do? Should they not develop new antibiotics just because there's become a resistance to an antibiotic? Absolutely not. Roundup controls hundreds of weeds. In this country, 12 of them have become resistant. It still controls hundreds of weeds. It needs to be used effectively. And, Chuck, you were one of the first ones to point out that we should actually use combinations of herbicides. And that's what growers are doing today, and that's one of the benefits of being smarter and stewarding these products better.

### Scientific Advocate (SA)
Claim: Rob, back when we had that conversation, I might have also suggested it's not a great idea to put antibiotics in plants. Do you remember that?

### Moderator
Claim: We're going to go to audience questions now, and so raise your hand. The mic will be brought to you. We'd appreciate it if you would identify yourself. And if you're a member of the press, we really would like you to identify yourself. I can't resist calling on Bill Nye, the science guy.

But I have to say, Bill Nye, the science guy, that your question also has to be as good as everybody else's so…

### Moderator
Claim: My question is about time. Everybody can agree I think that you can know exactly what happens to any organism, any plant, any crop, but you cannot know-- I believe you cannot know what happens to an ecosystem, so can the four of you agree on a number of seasons, a number of years, a number of plantings and harvestings where we would be-- I think what people are concerned about is the effects on an ecosystem where you accidentally create a--

### Moderator
Claim: You were almost at a question mark there.

### Moderator
Claim: --resistant weed… say again?

### Moderator
Claim: You were almost at a question mark. You were--

### Moderator
Claim: Well, I am-- well, what is the timescale for each side? Is it-- for geologic time it's at least centuries, not five seasons. So, that's what everybody-- I think what many people are concerned about with regard to genetically modified foods.

### Moderator
Claim: Thank you. Let's take it to Margaret Mellon.

### Scientific Advocate (SA)
Claim: Well, I mean, from my perspective the timescale, you know, is something like decades. I mean, in the decades that we have seen herbicide tolerant crops we have seen a dramatic downward effect on the monarchs as a result of Roundup killing the monarchs' only food--

### Moderator
Claim: You're talking about butterflies?

### Scientific Advocate (SA)
Claim: --yes, I'm talking about Monarch butterflies. It turns out that it's called milkweed.

### Moderator
Claim: Oh, not, not--

### Scientific Advocate (SA)
Claim: Come on, you got to--

### Moderator
Claim: I'm thinking of people on the podcast, "How did the royal family get into this?"

### Scientific Advocate (SA)
Claim: I don't-- I wish I knew.

### Moderator
Claim: Just looking for clarity.

### Scientific Advocate (SA)
Claim: But, you know, in that period of time the monarch population has decreased by almost 80 percent, and it is certainly because they've been deprived of their food, which is a milkweed. They're – we’re seeing effects on honeybees, on-- and they're all subtle effects, you know. It's not like killing the honeybees, it's making it impossible for the honeybee to find its way back to the nest.

### Moderator
Claim: And that's why decades, you're saying.

### Scientific Advocate (SA)
Claim: Crayfish and earthworms, I mean, we are seeing effects right now that have ecological implications, so the timescale is not that great.

### Moderator
Claim: Alison Van Eenennaam.

### Conspiracy Advocate (CA)
Claim: Yeah, I mean, I think you're conflating the technology with other issues. I don't-- the Monarch butterfly is due to more effective controls of the milkweed. And so if we want more weed then we should grow more weed, but the fact that we're controlling the weed more effectively-- I guess from California I probably shouldn't say that, should I?

### Moderator
Claim: Another debate--

### Conspiracy Advocate (CA)
Claim: Sorry.

### Moderator
Claim: "Yes," or, "No," to this statement.

### Conspiracy Advocate (CA)
Claim: You know, there's been no association with GMs and honeybees. I think that's just that, that's a red herring out there--

### Scientific Advocate (SA)
Claim: Well, there's-- there are--

### Conspiracy Advocate (CA)
Claim: --and--

### Scientific Advocate (SA)
Claim: What concerns me is that we're talking about problems that are associated with the technology without considering the benefits. And there're tradeoffs with every production system. And what we need to do is remove the problems but retain the benefits, not just throw the technology out.

### Moderator
Claim: Chuck Benbrook.

### Scientific Advocate (SA)
Claim: What I'm concerned about, and many scientists--

--is that GE crops came on the market in 1996. Monsanto and Rob Fraley's very talented molecular biologists. They're on their fifth generation now of genetically engineered corn. None of the GE corns that have been on the market have had a dominant position for more than five or six years.

So, we are moving from one generation of GE crops to the next to the next before we've even begun to understand what the impacts of the first ones are. So, I would like to have the ability to at least do two crop rotation cycles, which might be six or eight years, to see how the farming system has responded, but in that time period, just that time period, the technology has changed. So, you never really get a handle on what has happened.

### Moderator
Claim: Okay, I'm going to go to another question.

Far up in the corner against the wall right-- and if you could stand up and tell us your name please.

### Moderator
Claim: Hi, my name is Amy Bentley I teach at New York University. And my question has to do with copyright-- the copyright implications of the GM seeds. If both sides could speak to that, I'd appreciate it.

### Moderator
Claim: You know what? I'm going to pass on it because it's a-- I'm not saying that it's not relevant to the larger discussion but it's not really getting us to the issues that we've delineated of safety and the impact on the environment.

Right down here, ma'am. Thank you, though, for the question. Yes. And if you could stand up and tell us your name, please.

### Moderator
Claim: My name is Nina Federoff, and I've been one of the inventors of this molecular technology.

### Moderator
Claim: You're a ringer!

### Moderator
Claim: 30 years. No. I'm just here.

### Moderator
Claim: Okay.

### Moderator
Claim: By chance. I would like to ask –

--I would ask-- I'd like to ask Rob Fraley to tell us historically how rapidly corn lines, and wheat lines, and so forth evolved long before GM had--

### Moderator
Claim: Yeah. That's-- wait-- wait. Yeah. I'm going to pass on that too--

### Moderator
Claim: What, no-- because it's--

### Moderator
Claim: Well--

### Moderator
Claim: --very relevant to what Benbrook said. In other words, he's saying--

### Moderator
Claim: I know. But you're kind of--

### Moderator
Claim: --here to help out your partner to fix his question-- not your partner, your colleague-- former colleague to fix his questions. So, it's a little messy for me.

### Moderator
Claim: Can I actually answer Bill Nye's-- Dr. Nye's question, because--

### Moderator
Claim: We can pretend that you're answering Bill Nye's question. Okay.

### Conspiracy Advocate (CA)
Claim: Because you asked the question, what kind of testing is required and what do we need to do? And that's so relevant here, because the testing requirements are developed by the USDA, specifically to look at the evolution of pests and the impact on the environments. We do studies for several years to do the analysis that's being reviewed by the agencies for their environmental impacts. And that's one of the key questions. The impact on the ecosystems, the-- on other species. That's all built into that regulatory system. And it's built on the fact that in this country, we have been developing new crops from the beginning of time. New corn hybrids, new soybean varieties, new cotton varieties. And that experience from plant breeding has given us the insights and base the regulations in terms of how the GMO crops are regulated.

### Moderator
Claim: Oh-- and-- uh--

### Conspiracy Advocate (CA)
Claim: Based on real, practical, real-world experience.

### Moderator
Claim: Do you have eyeglasses? Right there. And if you could stand up and tell us your name, please.

### Moderator
Claim: Hi. I'm Michelle. I'm wondering what are some of the scientific studies that have been done linking genetically-engineered foods and crops to human health. What are-- are there--

### Moderator
Claim: I feel-- again, I feel that we've covered that pretty extensively.

### Moderator
Claim: I don't--

### Moderator
Claim: Well--

### Moderator
Claim: I don't think we have.

### Moderator
Claim: Well, we've had-- we've had a number of conversations already about the question of whether the-- what the-- that there's a cascade of studies that look at safety. And I assume that safety refers to health. Am I-- does anybody on the panel feel that we haven't addressed that?

### Scientific Advocate (SA)
Claim: We're not going to make any progress on that.

### Moderator
Claim: Yeah. That's the only reason-- as I feel, yeah.

### Moderator
Claim: I do--

### Moderator
Claim: Very vociferous waving there.

### Moderator
Claim: Well, thank you. Hi, my name is Alice. And this question may be answered by either Margaret or Charles. My question is about the evidence. There's thousands of peer- reviewed studies showing that biotechnology doesn't pose a threat to human health.

### Moderator
Claim: Again--

### Moderator
Claim: On top of that-- wait, no. No. This gets to a very valid question.

### Moderator
Claim: It better.

### Moderator
Claim: Aside from the observational studies, going over multiple generations of over a hundred trillion animal meals--

You're reading.

Well, I'm sorry that I'm not the most eloquent of speakers, that I can use notes, okay? I'm sorry about that.

### Moderator
Claim: Oh, my God.

### Moderator
Claim: However, that being asked--

### Moderator
Claim: I've lost control.

### Moderator
Claim: My –

### Moderator
Claim: May I-- just-- just--

### Moderator
Claim: --go with your gut and get to your question.

### Moderator
Claim: No. My question is-- with all the studies and all the evidence, and all the peer review-- my question is, what-- what evidence would you accept as sufficient to change your minds since peer review obviously isn't enough?

### Moderator
Claim: That's a question.

Chuck Benbrook.

### Scientific Advocate (SA)
Claim: I would accept the battery of tests set out of by the Codex Alimentarius Commission, which is the internationally recognized body that sort of sets the testing rules for animal drugs, for pesticides, and other things.

There was a six-year negotiation involving countries from around the world that defined the set of studies that should be done on each new genetically engineered food. I think it was sound then. It's still sound. And not a single GE food on the market today has been subjected to the battery of studies called for by Codex.

### Moderator
Claim: All right. Chuck, you've brought out something-- you brought out--

### Scientific Advocate (SA)
Claim: And certainly not on the new GE

### Moderator
Claim: You brought out something we didn't know. And I want to hear your opponent's response to the fact that there is-- these are-- there's a set of standards that have been proposed for studying these that have not been used or addressed. You'll take it-- either--

### Conspiracy Advocate (CA)
Claim: Go ahead.

### Conspiracy Advocate (CA)
Claim: No, you take it.

### Moderator
Claim: Yeah. Rob--

### Conspiracy Advocate (CA)
Claim: So, generally, there's not alignment on those studies. Either their validity or their appropriateness for these types of products and there's not even recognition of that by the government agencies in this country. We comply to the laws of the United States and all the countries that we-- that, you know, import our crops. We are the breadbasket of the world. Two-thirds of the corn ships around the world to Europe, to Asia, and to other countries.

### Moderator
Claim: You're-- you know what? I--

### Conspiracy Advocate (CA)
Claim: And the standard for safety is

### Moderator
Claim: --have to stop you-- I have to stop you when you start going into talking points that you've repeated--

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: --endlessly.

### Conspiracy Advocate (CA)
Claim: Thanks, John.

### Moderator
Claim: Okay? Because I want to-- I really want to understand the point that was made that there is-- that there is a set of standards which you said you don't consider valid. But is that-- is that because of the camp that you're in? Is that because of the camp you're in? Or is there actually a dispute about whether there are studies that could be done and for some reason are not being done? I'll take it to Alison van Eenennaam first.

### Conspiracy Advocate (CA)
Claim: It's certainly not my area of expertise, but there are--

### Moderator
Claim: Then I won't-- then I'll go to the other side.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: Unless you want to take it.

### Conspiracy Advocate (CA)
Claim: Well--

Okay.

### Moderator
Claim: Unless you want to take it. I'm not trying to--

### Conspiracy Advocate (CA)
Claim: Well, I guess, to me, it's, what are the unique risks that all these safety studies are for? We're talking about a breeding method. And the data shows that there's no unique risks. And so we've-- we already do extensive studies that cost millions of dollars to bring these products to market. If we're going to do more studies, it'll be even more expensive. And I want to know what the unique risks are that we're looking for--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --that are triggering these studies.

### Moderator
Claim: A question that I would find interesting to come from the audience, and it does go to what Rob was just talking about--

No, no, no, I'm serious, because I'd like-- rather have it come from you in this portion.

But it does go to what Rob's talking about, because one of his strongest points-- and it is the talking point that he's come back to-- is the impact of this technology on feeding the world and on solving problems. And I would like to explore that. And I was the one still asking the questions, that's where I would be going. So, would somebody please say what I want to say?

I hope you do it now.

### Moderator
Claim: My name's Heather. And, yes, that's really what my question was about. It seems like we're always comparing the success rates of GMO farming to very chemically driven agriculture and not to an organic agriculture. And that's where I get very confused with the argument because the against side seems to be against the chemically driven agriculture, whether it's in GMOs--

### Moderator
Claim: Okay.

### Moderator
Claim: --or not. And is it viable to feed a world with organic farming?

### Moderator
Claim: Do we need-- do we need the technology to survive, basically is what you're asking. That's what part of the argument from the other side.

I will-- let's let it go to this side first and then come back to you to-- as a rebuttal since you've made the point several times. You're good with that? Who would like to take it?

### Moderator
Claim: Mardi.

### Moderator
Claim: Mardi Mellon.

### Scientific Advocate (SA)
Claim: First of all, the challenge of feeding the world's hungry people is not one that is met by production of any kind. I mean, if you want to feed hungry people around the world, I can give you a list of 10 things to do. You can build roads, you can raise their incomes, you can change the role of women, you can help people make their own decisions about what they want to grow, and help them grow it. So production itself is not an answer to the problems of hunger.

But beyond that-- but beyond that, I want to say that, you know, that genetic engineering, as I tried to say in my original-- in my introductory remarks, is not really producing the kinds of traits that we need.

Now, there-- I will just refer to one study in Nature magazine that was trying to help with a project. It started in 2010, trying to help African farmers develop corn crops that would grow on nitrogen poor soils. Now, in that period of time, that project has been able to produce 21 conventionally bred varieties of corn, adapted around Africa, that grow better in their nitrogen poor soils. Genetic engineering, which was also used, has produced one. And they don't think it'll be ready for 10 years.

### Moderator
Claim: Okay. Point made. Let's let Robert Fraley respond.

### Conspiracy Advocate (CA)
Claim: First of all, thanks for that. I was going to say that we might actually have reached-- reached some alignment. We've talked a lot about our differences. And one of the points I wanted to make-- you cited the National Geographic. I give that same speech all the time. I absolutely believe that, you know, this is a complicated challenge, of feeding the world.

It's going to take increased productivity and efficiencies, and that's clear, and that's where these tools come into play. It's also important that we reduce food waste. And, you know, there's things that we can do by protecting crops or providing refrigeration and diets. I absolutely agree. It's a complicated question that will take all the tools we have.

### Scientific Advocate (SA)
Claim: And would you agree that we can't--

### Conspiracy Advocate (CA)
Claim: Excuse me. Let me--

### Scientific Advocate (SA)
Claim: --use 40 percent of our corn for ethanol?

### Conspiracy Advocate (CA)
Claim: Can we-- we can address that if you want to. But let me just-- let me complete my thoughts. Food security challenge is the biggest challenge we face. We have to double the available food in 36 years. It's important that we make the right decisions today. The other important point on farming-- and we've talked a lot about small farmers. My mentor was a guy named Dr. Norman Borlaug. And Norman always made the point that if you help a farmer, you help poverty. 70 percent of the world's poor are farmers.

If you give them better tools to farm even incrementally better, you address not only poverty, but you address food security. And so these are all complex interrelated issues. There are no simple solutions. But I think we should play the game with all of our tools.

### Moderator
Claim: All right. I want to let--

I want to let Charles, if you want to respond to that. But first, I need to say this: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator, and we have four debaters, two teams of two, debating this motion: "Genetically Modify Food." Chuck Benbrook.

### Scientific Advocate (SA)
Claim: If you're persuaded that the argument from the biotech industry, that this technology is essential to feed the world, if this is what really grabs your interest in this, ask yourself this question: You have a 50-pound bag that you can get to a poor African farmer, trying to grow maize on worn-out soils.

You can give that farmer a 50-pound bag of nitrogen fertilizer, or you can give him a 50- pound bag with smart stack corn. Now, I think Robb Fraley would agree to me that African farmer's going to get a bigger boost out of the 50 pounds of nitrogen than out of his magic seeds.

### Conspiracy Advocate (CA)
Claim: Can-- can I--

### Moderator
Claim: Alison, yes. Alison van Eenennaam.

### Conspiracy Advocate (CA)
Claim: Can I address that? I mean, I think that's a false balance. You know, I don't think we have to choose one or the other. And I think if you provide that farmer with an insect resistant crop like a BT, maybe then it's protected from insects and then also add some fertilizer, then maybe you can improve the yield sufficiently to feed his family and also sell some product and help lift himself out of poverty. So, I don't think we have to choose one or the other. I think that's a false balance.

### Moderator
Claim: Margaret Mellon, do you want to respond?

### Scientific Advocate (SA)
Claim: I don't think you have to choose one-- either one or the other, either. But I do think it's very important to kind of get the power of the technologies in perspective in order to make the right decisions about where to put our money going forward.

And right now I think we have too much faith in genetic engineering, which as I said, has not-- it really hasn't proven itself except in one instance. So, I do think it's important that we face that. I also want to say how, you no he, we need to use all our tools. I want to give a shout-out to traditional breeding. I mean, since, or well before genetic engineering came on the scene, traditional breeders and agronomists were able to produce 1 to 2 percent a year increases in corn and soybean yields in this country for decades. It happened before biotech. All the way through the biotech era, we have continued to get 1 to 2 percent yields decade after decade.

And we would continue to get them if we weren't using genetic engineering sometime in the future. So, we need to acknowledge how important that technology is. And it is not getting the attention that it deserves. I mean--

### Moderator
Claim: Let's let Alison van Eenennaam respond to that.

### Conspiracy Advocate (CA)
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: Let me take a quick response.

### Moderator
Claim: All right, Rob Fraley.

### Conspiracy Advocate (CA)
Claim: I had-- you know, we're dangerously close to common ground here. I absolutely believe everything you said. In fact, let me just tell you a little bit of a secret. You know, I run the research program for Monsanto. We spend exactly twice as much of our research dollars on plant breeding as we do on biotech. Absolutely plant breeding particularly assisted by these molecular tools has a great opportunity and has a huge impact internationally. We work with the Gates Foundation to use these tools to breed-- to breed drought resistant maize for Africa, and we're working with them on other projects so I couldn't agree more.

### Moderator
Claim: Well, Rob, one-- one part of-- I think of Margaret's argument is that the focus on genetically engineered crops sort of sucks the oxygen out of the room and sort of integrates interest in more conventional methods, which she says would substitute perfectly well for genetic engineering. And I'd like either you or Alison Van Eenennaam to respond.

### Conspiracy Advocate (CA)
Claim: You know, I think the debate around GMO crops sucks all the air out of the room.

I think we're to the point where it's become a side show. It's become a distraction.

### Moderator
Claim: I know. But that doesn't answer the question.

### Conspiracy Advocate (CA)
Claim: Well, for example, we--

### Moderator
Claim: Alison van Eenennaam.

### Conspiracy Advocate (CA)
Claim: --wheat tends to be done by public breeders. And I know that the public breeders are using conventional selection and are basically locked out of using GM as a-- it's a synergistic tool. It can be used for very specific things like disease resistance much more effectively, potentially. And combining the two together would be a really beneficial thing. And so I just don't see it as being mutually exclusive. You have to do conventional breeding or genetic engineering.

### Scientific Advocate (SA)
Claim: I agree with that, but I also-- I mean, every time I hear about what genetic engineering is going to do, I always remember the promises that I've been hearing for decades, many of which have never come to fruition.

### Moderator
Claim: Does anybody want to respond to that before I take one more question? Because it's a point that was made earlier that was sort of left lying out there, that there was a lot of promise and a couple of tricks have been pulled off but not broadly in-- throughout agricultural.

### Conspiracy Advocate (CA)
Claim: Well, there are certainly products in the pipeline that have been delivered and things like the disease resistant papaya. And I guess as a public sector scientist I get a little bit frustrated by the same groups that are out there kind of scaremongering about the technology or at the same time saying, "Why hasn't anything come to market?" because it's really that, that's stopping the public sector from developing these products.

### Moderator
Claim: Right down in front here. Down one row, thanks. If you could stand, please.

### Moderator
Claim: Hi, I'm Mike. So, we've seen that often when you use new genes they have some great uses and then after a couple of years they fade off.

And maybe you come up with a new cocktail and try the same thing again. I'm wondering in the real scheme of time, as Bill was getting at, are we going to run out of tricks and basically play into bugs' wildest dreams, create super strong bugs and run out of genes to fight them?

### Scientific Advocate (SA)
Claim: A lot of cotton farmers in the Southeast have devoted with their operations that aren't growing cotton anymore. They can't deal with the resistant weeds. There's three or four different Glyphosate resistant weeds in a lot of the cotton acreage in the Southeast. And there's grave concern in the Midwest that the same fate will occur in the Midwest where we-- you know, we grow all-- most of the corn and soybeans. Corn and soybeans are the backbone of the U.S. food system, and if we have a weed-- resistant weed meltdown in the Midwest it'll be a serious national problem.

### Moderator
Claim: Is it plausible? I'll go to Rob Fraley.

### Moderator
Claim: We're on track we're on track.

### Moderator
Claim: Yes, we are.

### Moderator
Claim: I mean, is there a bug apocalypse?

### Conspiracy Advocate (CA)
Claim: Could you restate the question?

### Moderator
Claim: I really should. But his question was "Are we going to come ultimately to a total meltdown where we would run out of tricks and where the bugs would win?"

### Conspiracy Advocate (CA)
Claim: I think only if we stop investing in the science in the future. You know, absolutely, you know, I've mentioned in my opening remarks, you know, concern over resistance development is a concern that's been a concern from the beginning of time. But we have incredible tools. I'm actually proud of the fact that we are developing our third and fourth generation technologies and staying ahead of the curve. And if we can move forward with the science and all of the tools-- I mean, we need to make the advances in breeding, we need to make the advances in biotechnology, tremendous opportunity for precision agricultural tools to farm more smartly, we're going to need all of these tools. We have to double the food supply in 36 years. What wakes me up in the morning is I know we can do it if we can reach alignment on moving forward and using the common ground.

We all care about food security. We all care about the environment. Let's get smart and move forward.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. Debate--

## Round 3

### Moderator
Claim: --where our motion is "Genetically Modify Food." And right after our closing round, which will be two-minute statements by each debater in turn, we will have a vote again. So, on to round three, round three, closing statements by each debater in turn. They will be two minutes each. And here to speak for the motion, Alison Van Eenennaam, a genomics and biotechnology researcher in the Department of Animal Science at UC Davis.

### Conspiracy Advocate (CA)
Claim: This past week the U.S. celebrated Thanksgiving, a wonderful holiday, and we had 14 people over to our house. And as the hostess my task was to serve a safe delicious meal. You know the drill, keeping the raw turkey out of contact with food surfaces, making sure you cook it enough to get rid of food borne illness but not so much as to be dry, all while drinking a glass of wine which probably added to the risks.

But actually food poisoning is a real risk, and 3,000 people a year die of food poisoning. As we gave thanks for this abundant cornucopia, the one risk I was not concerned about was whether any of the food was genetically modified. And I was serving this meal to the people I love most in the world, my dearest friends, my husband, my two teenage sons. Their wellbeing is of paramount importance to me. And as a parent it's my responsibility to use the best possible information to protect their health and to determine what the scientific consensus is on technology. That is why my kids drink pasteurized milk and have had all of their childhood vaccinations. Sometimes the risks that concern people and the risks that kill people are entirely different. For too long the debate over the merits of genetically modified food has focused on unrealized hypothetical risks and has been conflated with the use of pesticides.

It has not addressed how GM could help with the very real risks faced by the hungry and malnourished. There are costs associated to excessive precaution. Doing nothing is doing something. During the 90 minutes we've had this debate, approximately 1,500 people died of hunger, more than all of you here in this room. Hunger and malnutrition are real risks, risks that kill over 20,000 people daily. And most of those who die are children. These are not talking points; they're people. As a mother and a scientist, what concerns me is the fear-mongering campaign against genetically-modified food has forced scientists from using this breeding method to help produce more nutritious and sustainable food sources for millions of people. Vote yes for GM food.

### Moderator
Claim: Thank you, Alison Van Eenennaam.

And our motion is, Genetically Modify Food. And here to give his closing statement against this motion, Chuck Benbrook. He is program leader of Measure to Manage Farm and Food Diagnostics for Sustainability and Health.

### Scientific Advocate (SA)
Claim: Unfortunately, the way that the GE technology and crop revolution has unfolded, it's really turned into kind of an arms race with weeds, using herbicides as the sole hammer. And as a result, we've had this spread of resistant weeds. And also, the rapid-- especially in the last 10 years, escalation in the use of herbicides. There may have been 100 million pounds or so of insecticides not applied since 1996 because of BT corn and cotton, but there's been 6 or 700 million more pounds of herbicides. Now, the word "pesticide" encompasses both herbicides and insecticides. So, if you've reduced insecticide use by 100 million pounds-- and that's a good thing-- but herbicide use has gone up by 600 million plus pounds, how do you come up with pesticide use going down? It's just not true.

And a lot of farmers would take considerable exception to the claims from the other side of the die here about pesticide use going down, and their job being easier. In 1995, the year before the GE revolution, there was about 27 million pounds of Glyphosate applied by farmers in American agriculture. 10 years later, it had gone up to 157 million pounds. And in 2014, USDA data shows pretty clear, it's about 230 million pounds of Glyphosate was applied. We have about 300 million acres of cultivated croplands, so we're talking about two-thirds of a pound of Glyphosate herbicide-- if it was spread evenly across the United States-- could be applied on every acre of cropland. That's why we've got Glyphosate in our blood, in our hair. That's why we have-- the scientists are concerned, even though it's generally regarded as a relatively safe pesticide, there is reason for serious worry here.

### Moderator
Claim: Thank you. Chuck Benbrook.

The motion, Genetically Modify Food. And here to summarize his position supporting this motion, Robert Fraley, executive vice president and chief technology officer at Monsanto.

### Conspiracy Advocate (CA)
Claim: Thanks for a great debate and for listening to the commentary. I hope it's helped provide you more insight into the important science and the important tools that GMOs represent. What I'd like to do is actually highlight what a vote against the motion really means, what it would be like to live in a world without GMO crops, what that would look like. First thing, there'd be a significant impact to the land. Without GMOs, farmers would need to dramatically increase their use of herbicides and insecticides. I estimate it to be about 100 million pounds added to the environment each year. Second, since GMOs improved yields and helped farmers deliver more food in their absence means we're going to have to farm more land.

And you know, it's going to take about 120 million acres more land to just keep where we are today. That's about one California or four New York states. And the pressure that will put on will mean-- it will drain more wetlands, will cut down more forests. We'll look at more prairielands, because people will fundamentally eat. Third, voting against the GMO technology really means exacerbating climate change, because it means we go backwards. We have to manufacture more chemicals. We have to take tractors and run up and down the fields and plow, and we release more greenhouse gas emissions. Banning GMO crops is equivalent to taking and putting 26 million new cars on the road from a greenhouse perspective. It also means higher food prices. North Carolina State just published a study showing that the average family going in-- not using GMO crops adds about $3,000 a year to their food bill. And that impacts everybody, and we all bear the cost of that. And finally, voting against GMOs means forgoing all those opportunities that Dr. Van Eenennaam had talked about. You know, it's a relatively new technology. The future is ahead of us.

We're at the tip of the iceberg stage in what's possible. So, I hope, for the sake of all of our families-- and I hope for the sake of all the people on the planet-- that you vote to keep all of our options open and vote yes to support GM food. Thank you.

### Moderator
Claim: Thank you, Robert Fraley.

And the motion is: "Genetically Modify Food" and here to summarize her position against the motion, Margaret Mellon, a science policy consultant and former senior scientist at the Union of Concerned Scientists.

### Scientific Advocate (SA)
Claim: You know, we really haven't heard a single piece of evidence tonight that supports the notion that somehow genetically engineered crops are important for helping hungry people eat. And I think that's really-- there is no evidence for that. If there is a consensus study out there, it's the World Bank consensus study that GE crops are not important to solve food security problems.

If you want to know what the world would look like without GE, you might want to look at Europe. Europe has an incredibly productive agriculture, so much so that they're all paying, you know, subsidies just like we're paying. They have a-- I would say they're still using too much in the way of herbicides and pesticides, but it's a very productive, safe and capable agriculture system that we would all be, I think, very comfortable to live in. We have to look at the fact that there are still safety concerns about this technology, particularly about the long term effects. And that's when the American cancer society says. Yes, the current products are safe, but the long-term concerns are still out there.

So, we can't pretend that those issues have been thrown away. I think we can say that since genetic engineering has been introduced, it has simply failed to address the big problems that are out there, the problems that are leading to dead zones in the Gulf of Mexico, but that there are technologies that can do that, and they are traditional breeding and Agroecology, which have not gotten enough discussion, so--

### Moderator
Claim: Margaret Mellon, I'm sorry, your time is up. Thank you very much.

### Scientific Advocate (SA)
Claim: I urge you to vote against it.

### Moderator
Claim: And that concludes round three of this Intelligence Squared U.S. debate. And now it's time to learn which side has argued the best. We want you to go again to the key pads at your seat and vote a second time on this motion: "Genetically Modified Food."If you side with this motion and with this team, push number one; with this-- the-- against the motion, and this team, push number two; and if you became or remain undecided, push number three. And it'll take us normally about 90 seconds to get the final result. But while we're doing that, the first thing I want to say is this is obviously a very, very-- this is obviously a very, very passionate debate, and there are strong feelings on all sides. But even with that, I felt that the integrity and the civility the debaters brought to the stage, they lived up to the spirit of Intelligence Squared, so I congratulate you all for that.

And everyone who raised his or her hand to ask a question and even the questions that I threw out, I respect you for getting up and asking them because it takes a lot of guts even if you have to read them. And congratulations to them for doing that.

Now, there's-- there's something new that I'm doing tonight. It's a one-time only thing, but as I mentioned, we have a podcast that goes out. And it turns out that there's a fan of Intelligence Squared named Ryan Everts who wrote to us and said that he and his girlfriend sort of court one another in part by listening to Intelligence Squared podcasts. And he wrote a very important note. He said, it was through-- "it helped my girlfriend and me to better engage with each other on fairly sensitive topics. It was through these episodes that we were able to discuss and learn more about each other's perspectives and opinions. Though we disagree on some political issues, we understand one another and respect each other's views on a much deeper level." And he got that from listening to us.

This is going to get-- this is going to go a little bit further. He contacted us because he's planning to propose marriage in about two weeks. And he asked me if I would record a mock debate motion about whether his girlfriend should marry him or not.

So, with the acoustics of the room and with all of your presence and voices, I'm about to do that. He's out there listening right now on the live stream, making sure-- he's making sure that his girlfriend, Nicole Morris, is not listening, otherwise the whole thing is blown. And if anybody out there knows Nicole Morris, don't tell her about this. But here it goes: That sounds like the makings of a debate, so let's have it. Yes or no to this statement: Nicole Morris, will you give Ryan the honor of caring and loving you for the rest of your lives? And arguing for the motion, we have Ryan Everts.

He was your neighbor back in Oakland and now lives with you here in Denver.

Ryan is deeply in love and would-- Ryan is deeply in love and would love nothing more than to grow old together with you. So, I say to this audience, yes or no to this statement: Should Nicole Morris say, "I do"?

### Moderator
Claim: Yes!

### Moderator
Claim: All right, I'm going to-- thank you for that. That was lovely.

So, one thing I want to do is I want to thank our generous supporters and donors who make these debates possible. The ticket sales don't come close to covering the cost of mounting these debates, so their-- their help is really appreciated by us. And as the holidays come up, I would encourage you to go to our website and make a donation at IQ2US.org. Our spring season is starting on Thursday, January 15th.

The motion will be "Amazon is the reader's friend." We have--

We have some best-selling authors, including Scott Turow, Joe Konrath, Franklin Foer of the New Republic and Vox's Matthew Yglesias. They're debating whether Amazon is good for readers and books. Other topics we'll be covering this spring include "America's decline," "the right to be forgotten," "presidential war powers," "abolishing the death penalty" and whether "smart tech is making us dumb." For the full list of debates, you can go to our website. It's at IQ2US.org. And as I mentioned before, you can download our app on Apple and Android mobile devices. IQ2US, just look for that app. And on that app, you can get all of our debates and research et cetera. This was debate number 98. In February, we're going to hit 100. And we're delighted about that. So--

All right, I now have the final results.

You have voted twice, once before the debate and once again after the debate. And again, the numbers-- and again, the team whose numbers have changed the most in percentage point terms will be declared our winner. Let's look at the first vote. In the first vote on the motion, genetically modified food, 32 percent agreed, 30 percent were against, 38 percent were undecided. Those are the first results. Remember again, the team whose numbers change the most between first and second will be declared our winner. Let's look at the second vote. The team arguing for the motion, their second vote was 60 percent. They went from 32 percent to 60 percent. They picked up 28 percentage points. That is the number to beat. But let's look at the team against the motion. Their first vote was 30 percent. Second vote, only 31 percent, only a 1 percent move. That means the team arguing for the motion, "Genetically Modified Food," has carried this debate. Our congratulations to them. And thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
