# Debate Transcript

Topic: A Democratically-Elected Hamas is Still a Terrorist Organization
Motion: A Democratically-Elected Hamas is Still a Terrorist Organization

Debate ID: Hamas-Transcript-112906


## Round 1

### Moderator
Claim: Well thank you very, very much Judy and good evening to all of you. I'm here with Dana Wolfe, the executive producer of this debate series and we'd like to welcome each of you to this third debate of our fall season. We want to encourage each of, each side of tonight's argument to listen to the proposing views and respond to inconvenient facts. I hope you the audience come away with the recognition that there's an intellectually respectable argument on both sides. And I want to thank once again WNYC and NPR for producing and airing these debates on public radio and to The Times of London for their sponsorship. I want to especially thank our moderator this evening, veteran broadcast journalist Judy Woodruff. And the extraordinary group of panelists who are the true stars of tonight's evening. This evening's debate is extraordinarily timely. Just this week, Prime Minister Ohmert took a conciliatory stance, offering Palestinians a series of incentives to build on a shaky cease fire in Gaza. It was also reported that Hamas lost control at a key Palestinian university, perhaps reflecting the shift in thinking of educated youth, cognizant of the economic costs of its continued violent Rosenkranz Foundation, A democratically-elected Hamas... rhetoric. In presenting tonight's debate, we're hopeful that the rapidly shifting events of the day can be seen in a broader context and a more historical and strategic one. In particular the debate promises to highlight the interplay of two ideas that both have deep appeal. The first is that the more democracy we have in the world, the better and safer the world will be. Our commitment to this idea cuts across a partisan divide. Ever since Woodrow Wilson, there's been a strong current in American foreign policy to promote a world order based on moral principles that we believe in. A current which liberal human rights activists and conservative democracy advocates both embody. The second idea is that the more terrorism succeeds as a weapon to achieve geopolitical objectives, the more dangerous our world becomes. Success emboldens terrorist groups, enhances their status as they jockey for power. Well the tension between these ideas comes into sharp focus if a terrorist group prevails in a democratic election. In principle, how should we interact with such a government? And what about Hamas in particular? Once in power, are Hamas leaders forced by global and local realities into a pragmatic stance? Should we listen to their rhetoric differently – as the familiar efforts of politicians to shore up their base, by speaking to the most extreme of their supporters. Which way does the evidence point? These kinds of questions, more than the semantics of the proposition itself, should determine Rosenkranz Foundation, A democratically-elected Hamas... how we vote on tonight's motion. I'm now gonna hand the evening over to our moderator, Judy Woodruff, who has covered politics and other news for more than three decades, at CNN, NBC and PBS. This year she has been conducting a series of reports for PBS on the views of young Americans. Thank you Judy. Enjoy the debate.

### Moderator
Claim: Thank you Bob very much for that introduction. And I am delighted to be here. I want to welcome all of you in the audience here in New York City, to the third Intelligence Squared US debate. I agree with what Bob Rosenkranz just said. We need more civilized discussions of important, even critical topics like the one we're gonna be hearing about tonight. I'm gonna give you just a brief rundown of this evening. First, we are gonna have the proposer of the motion begin by presenting his side of the argument. The opposition will follow. Each person will get a maximum of eight minutes and we will go back and forth from one side to the other. Second, when all six speakers have finished with their opening remarks I'm gonna be opening up the floor for brief questions from you in the audience. Third, when the question period from the audience is complete, each of the debaters will make a final statement that will last not more than two minutes each. And fourth, during those closing statements, ballot boxes are gonna be passed around the auditorium for Rosenkranz Foundation, A democratically-elected Hamas... voting. These are the tickets that you have, you should have in your hands. You will put in either the for piece, it's green or the against piece, it's red. You'll tear it off. Tear it off, rip it off and put it in, whichever side you are for. Or the whole ticket if you still don't know which side you favor. If anyone does not have a ticket ballot an usher will get you one at an appropriate moment. Fifth and last, after the final closing statements have been made, I will announce the results of the audience vote and we will know then which side has carried the day. We are fortunate tonight to have a very distinguished panel to be our debaters and I'm going to introduce them now. For the motion, former foreign policy advisor to Prime Minister Ariel Sharon and until earlier this month, Israel's ambassador to the United States, Daniel Ayalon. An expert on Arab politics and US Middle East policy from the Council on Foreign Relations, Steven A. Cook. Author, senior fellow at the Hudson Institute and editor-at-large of National Review, John O'Sullivan. And now against the motion. Lawyer and advocate for Muslim and Palestinian advocates, Stanley L. Cohen. Associate Director of the Harvard program on humanitarian policy and conflict research, Mahmoud Ould Mohamedou. And journalist, author and co-director of the UK/DC based conflicts forum, Mark Perry. And now we will begin the debate and to present the question once again, a Rosenkranz Foundation, A democratically-elected Hamas... democratically elected Hamas is still a terrorist organization. We are gonna call on each person to step up to the podium. I'm gonna call on them. And we are gonna begin with Steven A. Cook. For.

### Conspiracy Advocate (CA)
Claim: Thank you very much for being here this evening. I'd like to thank first of all IQ2 and the Rosenkranz Foundation. And looking out at the audience today it's truly extraordinary what a diverse group we have. Uh people in the audience who wouldn't normally sit together to discuss such difficult and emotion – and often emotional issues. Um I'd also like to thank Judy Woodruff for uh being here to uh to moderate this debate. And I'd also like to thank my fellow debaters. Uh I am very much looking forward to this evening's intellectual combat. The subject of this evening's debate is in one sense rather puzzling. Despite electoral success, Hamas is still a terrorist organization. What is there really to debate here? What does participation in an election have to do with Hamas' profile as a terrorist organization? I am quite sure that my colleagues on the other side of the debate will tell you that the Palestinian elections were the truest, freest and fairest in the Arab world. That's an absolutely true statement. They're also going to tell you that the outcome reflected the will of the Palestinian people. That's an absolutely false statement. And three, they're gonna tell you that Hamas provides critical social Rosenkranz Foundation, A democratically-elected Hamas... services to Palestinians in need. That is, my friends, totally irrelevant to tonight's subject. These arguments amount to little more than an analytical slight of hand. An organization can participate in a free and fair election. It can provide social services and be a terrorist organization. There is no seriously scholarly work out there that indicates that any of these activities are mutually exclusive. Despite what Bob Rosenkranz said in his eloquent remarks to open this evening's events, it is not an intellectual position to suggest that Hamas is no longer a terrorist organization. It's an ideological position. It's ideological. Rather than an analytical conclusion based on the available evidence, let's consider a few things. I'll leave it to my colleagues to describe for you the number of innocents who have been killed at the hands of Hamas. But it's important to provide some historical context here. To the evolution of Hamas. Hamas' very founding in the late 1980's was based on an imperative of violence. In the late 1980's, members of the Palestine branch of the Muslim Brotherhood grew concerned that another organization called Islamic Jihad was taking prestige and influence away from them because Islamic Jihad was engaged in violence. Their solution to this political problem was the establishment of Hamas. They would continue the Islamization of Palestinian society from below through the provision of social services, in keeping with the historic mission of the Muslim Rosenkranz Foundation, A democratically-elected Hamas... Brotherhood. But they also established a military wing. A military wing that was dedicated to terrorist acts against Israelis in an effort to burnish their nationalist image and out-maneuver Islamic Jihad. The founding covenant of Hamas which has not changed is explicit in its mission to elaborate all of historical Palestine through a variety of tactics including violence. The result has been the bloody carnage of the streets of Tel Aviv, Jerusalem, Ashkelon and numerous other Israeli cities. My critics will say this is old news. Hamas has evolved. It's become a political organization. This as Mahmoud Mohamedou said is a historic opportunity. But my question is has Hamas really evolved? It still denies Israel's right to exist. None of its leaders have renounced the right to armed struggle. The only thing has changed is a tactical change. It has sought to harness the elections that the United States has pushed on the Palestinians to advance its agenda. And what is that agenda? The establishment of a Palestinian state in all of historic Palestine with sharia Islamic law at its core. Well what about a cease fire? My critics will tell you there's been a cease fire since 2003. Be careful about the words that people use when talking about a cease fire. Hamas calls it a hudna. My colleague Mahmoud Mohamedou calls it tahdiya. Well in fact both of those, both of those have a temporary quality to them. Anyone who speaks Arabic should know that a hudna has a finite period of time. It's Rosenkranz Foundation, A democratically-elected Hamas... not much of a cease fire anyway. Since the Israelis withdrew from the Gaza Strip they've been victim of rocket assaults on their towns, the kidnapping of their soldiers and threats to their major cities. Under the weight of available evidence and I have a little bit of uh a little bit of this just before. Stanley and I were standing around before, talking about what we did agree on. The Giants, the Yankees, the Knicks and the desultory state of our teams. And then we got into talking about Hamas and I said sure, they wouldn't be a terrorist organization, they just have to lay down their arms. And he said you're right the Israelis have to lay down their arms. That's not the point. It's cute, it's funny but it's not the point. Under the weight of available evidence, supporters of Hamas tend to shift their argument to focus on Israeli behavior. And I should point out a case in point was Judy Woodruff's extraordinary interview with former President Carter last night on the “NewsHour.” It is true, Israel has expropriated land and continues to illegally settle the West Bank. Israel has killed Palestinian civilians. Though unlike Hamas not intentionally. It has worked assiduously to undermine Mahmoud Abbas and before him Yasser Arafat. All this is very, very true. But it neither alters the fact that Hamas is a terrorist organization. Nor absolves Hamas of the bloody responsibility for its own behavior. If the issue was Israel's contributed to an environment where extremist ideologies, alienation and terrorism Rosenkranz Foundation, A democratically-elected Hamas... can thrive, there would be little to debate. But this is not the subject we're examining here this evening. Participation in elections – Hamas' participation in the Palestinian elections is analytically irrelevant of whether it is a terrorist organization or not. It is a group that remains dedicated to Israel's destruction and in the process of that destruction, the inevitable killing of innocents. For Hamas to no longer be considered a terrorist organization it must change its charter. It must renounce its violence and it must lay down its arms. At that point and only at that point can it be seen as a legitimate participant in the political arena. With that I urge you, I urge you to vote with the proposition that a democratically elected Hamas is and remains a terrorist organization. Thank you very much.

### Moderator
Claim: Against the proposition, Stanley L. Cohen.

### Scientific Advocate (SA)
Claim: I would like to thank everyone for the invitation for tonight. To repeat this is a wonderful event. It's much needed in this city. I find myself sort of changing what I wanted to say as I was sitting here and listening to my adversary. I come from a different perspective. Interestingly enough, I’ve just returned from Damascus where I happened to be meeting with the leadership of Hamas. And I and I bring that to your attention because when I said I was coming to a debate in New York City over whether you're a terrorist organization or not, the leadership said you Westerners you spend all your time debating how many angels are on the head of a pin and history marches on. And that's not to denigrate or the significance of this debate, this discussion tonight. But to keep in its perspective that while we debate, while we argue, while we disagree, there is death and destruction on the ground. And while my adversary trivializes the injury to Palestinians, I'd like to sort of begin by really honing in on what we're talking about tonight. Since the year 2000, 4,800 Palestinians, mostly civilians killed. 839 children under ten. 755 women. 31,750 injured. 800 permanently disabled. 241 extra- judicial assassinations. 11,000 Palestinians including 380 under the age of sixteen and 240 women sitting in jails, most of whom who have never had a trial, have never seen a judge and do not have counsel. 4,800 homes demolished. 4,200 businesses destroyed. Thousands of hectares of oil groves razed. In the last five months, while unfortunately Israel has lost ten civilians, 557 Palestinians of whom 420 were civilians including 116 women and thirty three children were killed by the Israeli defense forces. Now collective punishment it's not the exception. Attacks on the infrastructure, the disruption of water plants, the destruction of electricity. Unemployment. Infant mortality rates. Disease. Malnutrition. These are not issues for abstract debate. These are harsh realities for Palestinians. Who did this? Hamas didn't do this, Israel did this. And it's not new. Think back to the British. The Stern gang, Menachem Begin, a Prime Minister of Israel, a terrorist. The King David and hotels blown up. The UN mediator assassinated by the Stern gang. Ethnic cleansings with 800,000 Palestinians driven from their homers. 400 villages erased from the map. So this is not some sort of esoteric debate with the West. This is reality. This is truth and this is sixty years. An unbroken trail of terrorism, not at the hands of Hamas. But at the hands of Israel. Dar Yassin, Sabra and Shatila, I love the notion about how Israel always unlike Hamas, accidentally kills. Bethanune last week, nineteen women and children sitting in a house, an errant tank shell. Of course the apologies, of course Israel says oops well sorry. We'll have an investigation and on it goes. And what of international law? The Geneva conventions that prohibit systematic torture. The Israeli Supreme Court eventually put an end to it. The occupied lands in violation of Israeli law and Geneva conventions. It goes on and on. 321 condemnations by the United – United Nations Generally – General Assembly ignored. Ninety one condemnations by the Security Council ignored. There is a double standard. And that's what's interesting and I mean no disrespect to the debate tonight. As a trial attorney sometimes I say to a witness so when did you stop beating your wife? And the witness looks at you like what are you talking about? And that's the problem with the debate.

It starts out with a pre-conceived notion that Hamas is a terrorist organization. To much of the world, Hamas is not viewed as a terrorist organization but rather a national liberation movement involved in low intensity, asymmetric warfare. To much of the world or many in the world community, Israel is viewed as a terrorist state. The problem is civilians are always caught in between. I don't apologize for any civilian getting killed anywhere but I don't make light of it as if they're just fodder for the Israeli machine. We know in this country we're used to civilian causalities. Sherman's march on Atlanta. The fire bombings in Dresden. It goes on. If you're a North American Indian you're a little bit familiar with terrorism in this particular context. And Israel in the war this summer, a million cluster bombs and anti- personnel mines. There is a fine line between terrorism and freedom fighter unfortunately. And it is who wins. Every person in the world dies to have a picture taken with Nelson Mandela. Who stayed in jail an extra eight years because he refused to renounce armed struggle. Malcolm X, an American by any means necessary. Now he's on postage stamps. So we have to be careful about evolving notions of terrorism. We have to be careful about language and what we suggest to the community. Who is Hamas? Hamas is not just a military wing. It's just kids strapping explosives on themselves. They're doctors and lawyers and professors and scientists and academics who have given their life to try to get, to try to reclaim what has been stolen from them. Now you can trivialize the election but most important remember Hamas is millions of people who voted and many of them with a bigger plurality than George Bush ever appreciated in his two terms, voted for Hamas. Now there's a double standard. The West, including Israel loves Abu Masen. And why do they love him? Well because he speaks Western. He talks Western. He walks the walk. He looks good. He's a good Palestinian leader. What's interesting is he's not considered a terrorist even though he's a figure head of Fatah which has an armed movement called al-Aqsa. They do bombings but he's OK. Hamas is not. Now what do we know that's happened since the election? Collective punishment. Leaders kidnapped. Cabinet members kidnapped. An attempt to destabilize and topple a legitimate elected government. Economic embargoes and strangulation. One –

Providing arms to the other side. The bottom line here is Hamas is the only group that can deliver. Let us find a way to break out of this cycle. To break out of this abyss. To forget about labels. Labels mean nothing. The only group that can deliver is Hamas, and you know what – if they can't, they'll be voted out. And at the end of the day it's time to end the embargo, it's time to empty the jails, it's time to stop the attempt to topple a government. But most of all forget the labels and forget the rhetoric. For sixty years it has not worked. Give the alternative a chance. Thank you.

### Moderator
Claim: Thank you and now for the proposition, John O'Sullivan.

### Conspiracy Advocate (CA)
Claim: Madam Chairperson, ladies and gentlemen. Uh well thank you for that kind introduction before Ms. Woodruff. And um and I want to share in the general uh agreement of the panel here that we're grateful for the organizers of this event of which there ought to be many more. Uh in order to stimulate genuinely interesting debate. I um I will begin by going straight to the topic. Because anyone who deals with terrorism has to be begin, and I was asked to do this by the last speaker, with its definition. I think you must also scotch the old canard that one man's terrorist is another man's freedom fighter. My own definition has the distinction of having been adopted by the Court of Appeals in Canada. If I may quote, Mister Justice Neland, quoting me in the case of Canada versus Najoub in October, 2001, the court spoke as follows – a terrorist is a man who murders indiscriminately, distinguishing neither between civilian and innocent and guilty nor soldier and civilian. He may employ terrorism – planting bombs in restaurants, hijacking planes, in a bad cause or a good one. He may be a Nazi terrorist or an anti-Nazi terrorist. A Communist or an anti-Communist. Pro Palestinian or pro-Israel. We may want to defeat his political cause or to see it triumph. For his methods however a terrorist is always to be condemned. Indeed to describe him objectively is to condemn him. Even if his cause is genuinely a fight for freedom with which we sympathize. Unquote, unquote. Now we are asked today to consider whether organizations that use terrorist methods as describe above should also be admitted into the arena of conventional politics and in particular to the arena of conventional democratic politics. The motion cites Hamas. But Hamas is not the only organization that combines seeking power through elections with terrorism. Hezbollah does the same. So does the Eta linked Batasuna party in the Basque region of Spain. So does the two headed Sinn Fein IRA in Northern Ireland. Nor are these organizations shy about their deeds. They openly boast of employing terrorism even if they sometimes quibble at the word. Sinn Fein for example has said clearly that it sought power through the Armalite rifle and the ballot box. These four parties I’ve mentioned have enjoyed varying degrees of success. They all raise the same question. If a democratically elected group employs terrorist methods, should it be regarded as having run itself out democratic politics and should we refuse, refuse to deal with it. Ideally I maintain that they should be run out of politics and that we should refuse to deal with them. Indeed I would go further. When we deal with such bodies, as if they are conventional parties, we are making murder respectable. We are in fact inciting people to murder. First because we are saying that murder is no bar to participation in high politics. And when we treat with terrorist parties supported by small numbers of voters as is true of the Basque party and it used to be true of Sinn Fein, we are inciting murder a second time. Because we have admitted, we are negotiating with them because they murder people and not for any other reason. When you incite murder you get more murders. Inciting terrorism has similarly produced a spreading stain of terrorism since the hijackings of Dawson Field in 1970. Let me make a first qualification for this bold statement of principle. If the price of halting a murderous insurgency is to admit the former terrorists into democratic politics that may sometimes be a price worth paying to save lives and establish a decent political order. But it is a price. The terrorists moreover must be former. They must have abandoned terrorism finally, completely and publicly. They cannot be mysteriously linked to terrorists still or leaving terrorism in a gradual way. They must be exclusively committed to democratic politics and willing to accept its verdicts even when those verdicts are unfavorable to them. I don't like making that concession. It means that crimes go unpunished, injustice is entrenched and the moral of democracy is tainted. Note though that is a very limited concession. While we may have to deal with former terrorists in official transactions of normal business, we should show them no signs of approval or respect. Even if they hold high government positions, they must be given no state visits, no honorary knighthood, no White House dinners. Until they have purged their guilt in some way, they must always feel the mark of Cane is on their brow. But the distinguished advocates tonight, opposite, are proposing something far more dramatic than easing former thugs out of terrorism and into official limousines. They suggest that we should treat as good faith democrats those who are still engaged in organizing suicide bombings and still planning rocket attacks. Their election it seems somehow validates their terror methods or at least their terror methods do not invalidate their election. Now here's my second qualification. We are going to reach somewhat different conclusions, depending on whether we are citizens of a country in which there is a terrorist group engaged in democratic politics. For example, if we're a Lebanese democrat in a state which has Hezbollah as a political party. Or depending on whether we are citizens of a state that is the um that is the neighbor of a country which has a terrorist government. For example the citizen of Israel next door to a government that includes um Hamas. Uh take the first case. The citizen of the state in which there is a terrorist party. Uh engaged in normal politics. That means that one party in politics has got its own private army and the others do not. It can intimidate the other parties. It can overturn election results, it can ignore political defeats. Uh it is not in a sense a normal political party at all. And its very existence is a contradiction of the concept of democracy that most of us would recognize. What happens in such cases? Well let us take the most favorable case for the other side, that of the Northern Ireland peace process which most people think has been a good thing. For the first eight years of this process One –

OK. I'm afraid I'm gonna skip to the, to the other point. Different principles apply when we're talking about relations between states. If a state is at war with another, whether or not the enemy government is democratic is a very secondary consideration. What matters is the disposition of that state's foreign policy. Does the other state have a serious interest in making peace? If it makes peace will it keep its word? Does it have long term aims compatible with a stable peace? Are its internal dynamics such that the government offering to negotiate peace is likely to survive. On strictly practical grounds, it is hard to imagine a prudent citizen answering those questions positively if the other government is composed of terrorists or routed in a terrorist party. The terrorists have a serious interest in making peace – will they keep their word, are they trustworthy? Do they generally have political aims compatible with a stable peace? We should probably answer all those questions no. And if the terrorist government is democratically elected Time's up.

The prognosis might be worse rather than better. After all if an electorate has voluntarily elected a terrorist party, it's internal dynamics are unlikely to be favorable to peace making and political stability. So for that reason it doesn’t really matter whether or not Hamas is democratically elected. What matters is whether or not it carries on its terrorist methods.

### Moderator
Claim: And now against the proposition, Mahmoud Ould Mohamedou.

### Scientific Advocate (SA)
Claim: Thank you very much Ms. Woodruff. You can add my voice to that of my colleagues to thank you and the organizers as well as the audience for this. Um it's a wonderful opportunity to have indeed intelligent debate. Um let me also preface my remarks by saying that my comments tonight are mine alone and don't necessarily reflect the views of my uh program. Let me pick up the argument where my friend Stan left it and it is that the inability to transcend the dominant misrepresentation of the Israeli occupation of Palestinian lands, is increasingly becoming problematic for both intelligent debate and informed policy making. It is a narrative that most people know to be problematic if not faulty. Yet is persists. Tonight's motion fits that pattern. And I invite you to reject it on grounds of inaccuracy and lack of intelligence for that matter. Hamas is not a terrorist organization. Hamas was the radicalized military expression of a national liberation movement, which grew into a social movement. Hamas is no longer a terrorist organization. Hamas has moved to a political contest which it has joined legitimately and has won fairly. More importantly, Hamas holds high levels of legitimacy among the majority of the people that it has been elected to represent and lead. Now before developing these arguments um it is important to establish a set of facts, yet there is a familiar discourse, an emotional discourse about the plight of the Palestinians which I will not rehearse here tonight. It is a classical discourse which unfortunately has been, in recent years, rendered part of the background noise of world politics. Triggering almost a sort of Palestine fatigue. However, and in addition to the facts that Stanley has listed, it is the following facts that are crucial to the assessment of the situation and the proposed motion before us tonight. Thirty-nine years of occupation, 1.4 million people in Gaza alone, in three hundred and sixty square kilometers. Five hundred and forty checkpoints in the West Bank alone, with a forty percent increase in that number in the past year. Settlements and buildings and land confiscation, the building of a separation wall, not a fence, a wall deemed illegal by the International Court of Justice. Daily, near daily military incursions and sporadic killing, essentially almost half a century of Palestinian disposition, loss of life and freedom. Now in that most urgent of context, a group that emerges as a resistance movement, grows into a social network upgrading welfare centers and educational services, and agrees to abide by the rules of Democratic contest, can certainly no longer be called terrorist.

Now Canadian definitions not withstanding, it is important, this is no mere matter of semantics to remember that the word “terrorist” is actually quite problematic when it comes to occupied people. Yes, indeed the saying “Your terrorist is my freedom fighter” captures that inherent subjectivity quite well. And some names were mentioned. To those we can add just this past century, Michael Collins and the IRA, and I will not even mention the Haganah, the Irgun, Yitzhak Shamir and others. Nelson Mandela and the ANC and so on, all of these people have been called by their opponents terrorists. The French resistance fighting the Germans, the FLN fighting the French. Yet time and again, both these individuals and their movements led their groups to national leadership and oftentimes through elections.

But the operative word of the motion is “still,” so is Hamas still a terrorist organization? Well let us look at what Hamas has done in the past ten months since their election. Even before that election, Hamas had decided on and implemented the unilateral cease fire. Which it observed for fifteen months straight until the Israeli killing this past June of the seven members of Ghalia family. Hamas had made former statements at the highest level of its multi-faceted representation regarding a disposition to enter this long-term truce. Much is made of this concept of hudna. It is important to understand that in fact, the phraseology used and the legal term is actually quite important in relation to an Islamic movement, which per force, obligates them too, and indeed is a form of protorecognition to begin with. Hamas has been part of discussions throughout the summer and the fall on a draft document for a program that we quote, “respect previous agreements in a manner that protects and safeguards the high interest and the rights of the Palestinian people.” Hamas had also proposed a coalition government back in March which included Palestinian Christians and women and has folded its executive force into the former national police. What have Israel, the EU, and the United States done in the same time frame? Insisting on this Three-Fold demand that Hamas recognizes Israel, forswears violence, and accepts previous Israeli-Palestinian agreements. They have decreed and implemented a crippling international embargo with a new humanitarian crisis by UN reckoning, a security crisis by security specialists’ reckoning, and indeed some sort of Iraq-ization of Palestine with the birth in mid- October of Al Qaeda and Palestine, which sent its first, a novelty by Palestinian standards.

But at this point one is really prompted to think, what kind of international community is this that is so blind to the injustice that it rationalizes? And the one that perpetuates out of ill- conceived and inefficient policies, but the argument that I'm putting before you is not an emotional one. It is not an ideological one, it is actually a rational one. The obvious problem with the Three-Fold demand is the disappearance of reciprocity. For the very same three demands could be put, but are not, to Israel. Israel has yet to recognize the existence of a Palestinian state on the 1967 borders. Israel has yet to stop its use of violence against occupied people, including women and children, and Israel has yet to implement the very agreements that it’s made with Palestinian representers. It is therefore contradictory to depict Hamas as still a terrorist organization while punishing Palestinians for their democratic choice.

It should also be said that we’re in effect, asking Hamas to be held to agreements which we no longer trust. While everyone is saying that Oslo is dead and that we need new thinking and moving on, we’re asking this newcomer to be held to these agreements which have faded or are certainly fading. And in effect, holding them to our own liabilities and failures. Contradictions are also displayed through a reading of the fact. There is no internationally agreed definition of terrorism, which is already an evidence of that problem. However, by law what qualifies a group as a group, an entity as terrorists is the indiscriminate targeting of civilians. So for the law to have any consistence, currency, it has to be applied across the board with certain selectivity.

Which leads me to my last element, Hamas is an adolescent Hezbollah, and look at what Hezbollah has become next door. The strongest power in Lebanon and the first one to ever defeat Israel. So there’s a sort of the assumption that Hamas can be extricated from that political reality is unrealistic. Ladies and gentlemen, given half a chance, Prime Minister Ismail Haniya and his Hamas colleagues are Gerry Adamses in the making. Voting for this motion essentially means endorsing and supporting a unilateral, sterile understanding of this conflict. I invite you to exercise intelligence, display fairness, and vote against the motion. Thank you for your attention.

### Moderator
Claim: And against the proposition, I'm sorry for the proposition, I misspoke. For the proposition, Daniel Ayalon.

### Conspiracy Advocate (CA)
Claim: Thank you very much. Can you hear me? Now start the clock now. Good evening, thank you very much for being here. With all due respect to my colleagues and my team, Steven Cook and John O’Sullivan who did a fantastic job, I must even thank more our adversaries, Stanley Cohen and Mahmoud, which did a great job actually convincing you I'm sure, to actually vote for the motion that Hamas is a terror organization. Actually I will depart. Naively I thought that uh, they will relate to the nature of Hamas. What do they do? What do they believe in? What is their conduct? But no, they actually opened the debate to a more geopolitical and historic um, issues which actually leave me on a much firmer ground. So I will depart from the notes I prepared here and I will answer the, my esteemed colleagues here on the other side who talked about occupation, who talked about Israeli aggression, who talked about UN resolutions, and I will say something which is very, very simple. Israel was attacked in 1967 by three countries around us, Jordan, Egypt, and Syria. The “Occupation,” quote-unquote as they call it, is this territory which was obtained by Israel as an act of self-defense. These three countries and others were trying to push us into the sea and actually destroy Israel, destroy the Jewish people who came back to their historic land, to their Biblical land, to the place where they belong. Now, the war happened in 1967. Israel was created in 19-, or was recreated in 1948. From 1948 to 1967, nineteen years, there was no occupation. West Bank belonged to Jordan, Gaza belonged to uh, Egypt, nobody talked about occupation then. Nobody talked about creating a Palestinian state. ] You know why? Because they wanted to create this Palestinian state right where Israel is now today, killing all the Jews. So from 1967 on, against her will, we had to defend ourselves and obtain possession of these territories. But still, we always wanted peace. The proof, 1977. When we had a leader like Anwar Sadat of Egypt, and he signed a peace treaty with us and he renounced terror and violence and he recognized Israel, Israel withdrew entirely from the Sinai, having peace with Jordan now for more than thirty years, uh, with Egypt for more than thirty years. 1995, Jordan, King Hussein, a great leader, wanted to make peace. We made peace. We withdrew from some, all the land that we occupied from Jordan and there is a peace between Israel and Jordan, recognizing each other, respecting each other, and not shooting at each other. In 1993, Israel, believing that the Palestinians really had a change of heart and they would like to make peace with us, we signed as the Oslo Accord. And the Oslo Accord was a very simple view, land for peace. Israel withdrawing from West Bank in Gaza, the Palestinians got a hold of themselves, stopped the terror, and becoming a responsible party. 2000, Camp David, former Prime Minister Barak meeting with uh, with Arafat to try and make peace. Barak is offering to withdraw from the entire territories, but this was not accepted by Arafat. Not only was it not accepted, but after it was rejected, this intifada started. Intifada is a misnomer, it was a very planned, pre-planned campaign of terror which cost more than a thousand Israeli lives, many children, devastation in our cities, and uh, continued rejection of the very notion of the right of Israel to exist in its home land. Now people compare between Camp David ’78 that succeeded with Saddam Hussein, with, with us with Sadat. I'm very tired, I came back from Israel not a few hours ago, between Sadat and Arafat, Camp David 2000. What was the difference? The difference was leadership. Sadat wanted to make peace. He prevailed over the advice of his advisors and signed a peace treaty. Arafat also unfortunately prevailed over the advice of his advisors who said sign the peace treaty because you will not get a better deal. And he was against it. Now Hamas was against Arafat. They did not even believe in any negotiations. They are against, and they were against Oslo, why? Because they do not believe in Israel’s right to exist. They do not believe in coexistence, they do not believe in peace. They do not believe even, in a democracy. Because they would like to have one Islamist Palestinian country a la Iran, Iran style and under the Sharia, the, the, the law of, of Islam. So lets go back to the debate tonight. What is the definition of terror? Killing intentionally of innocent people. What does Hamas do? Killing only, only children and innocent people. They stand terrorists strapped in explosives into markets, into pizzerias, into coffee shops, and into school buses and kindergartens. This is what they do. Are they a terrorist organization? If this is the definition of terror, they definitely are a terrorist organization.

Secondly, do they believe in coexistence? No, they deny Israel’s right to exist. Now people here are talking about whether elected democratically or not, this is besides the point. Just look into the Hamas, www.hamas.com in their website on the internet and look into the Hamas charter. They believe in killing, they don’t believe in Israel, they don’t believe in any peace. So are they a terror organization? According to this definition, they are as well. Now there is another issue here. Who is Hamas operated by? Are they really doing the will of the people? I don't think so. My esteemed colleague here on the other side, Stanley Cohen said he just returned from Damascus and he met Khaled Meshaal? Where did he meet Khaled Meshaal? In Damascus. Who is really operating Khaled Meshaal? The Syrians, and the Iranians. So they’re not really playing. They’re not really representing Palestinian authentic interest. They are representing the interest of this crazy Islamist in Iran, and in Damascus. Are they a terror organization? I think yes, I think all of you should vote for this motion.

Now there is this question whether they were democratically elected. Well I would say a broad definition of democracy is you know, doing the will of the people but also observing the rule of law. And the rule of law does not permit gangs to be brandishing their guns and going with bullets into the ballots. Uh, don’t take just the case of Hamas. Look at what happens. I mean we should apply this global world, global community, the same yardstick for everywhere. There were elections held in Iraq, in Afghanistan, in the former Yugoslavia. In all these elections, armed gangs were denied the right of voting and also of being elected. The same case should have been with Hamas but for some reason, this thing was ignored and Hamas was allowed to run. And I think this was a mistake. Unfortunately, Hamas won but it’s not because the people voted for their ideology – Time’s up.

It’s because it was a protest vote against Fatah which was corrupt and ineffective. So this is the reason why Hamas was elected. Did it change their character? Not at all. Does a formal process change intrinsically what Hamas stand for? Now after the elections, they still are killing. There are more than a thousand rockets fired from Gaza into our towns, killing babies and children, and there’s no reason for that since we left Gaza entirely. We left Gaza entirely in order to give Palestinians a chance to show everybody that they can govern themselves responsibly. That they can do away with terror and incitement and start negotiation with us. Time is up.

Just vote for the motion.

### Moderator
Claim: And the final opening argument is an argument against from Mark Perry.

### Scientific Advocate (SA)
Claim: The problem, the problem isn’t that Hamas is a terrorist organization. The problem is that Hamas is a Muslim organization, that’s what scares the hell out of us. And we ought to put it all out on the table and just say it. And how do we know that? Because the United States has dealt with terrorist organizations throughout its history and so has Israel. There were no preconditions for any talks with the PLO in 1993. And Yasser Arafat made sure of that. He said, we’ll recognize you after you talk to us. That was no preconditions. Why do we have conditions on Hamas? Because they’re Muslims, they don’t look like us, we say they don’t have our values. How do I know that we deal with terrorist organizations? Because tomorrow the president of the United States is meeting with a man by the name of Nouri al-Maliki. Who is he? Nouri al-Maliki is the head of the Dawa Party. Who is the Dawa Party? The Dawa Party opposed Saddam Hussein when we supported Saddam Hussein. We put them on the terrorism list. When we changed sides, we took them off the terrorism list. That doesn’t matter. They bombed the US Embassy in Kuwait and killed three Americans. We’re talking to him because it’s in our interest to talk to him, terrorist or not.

So what is the problem with Hamas? Well if you listen to the media and if you listen to our political leaders, here’s what they have to say. They don’t have our values. Our Judeo-Christian values. What values would those be? I'm a nice white boy from Wisconsin, grew up as a Lutheran. And I can tell you in my religion and I had to memorize through an ordeal the catechism of Martin Luther, one of the real anti-Semites of our era. They do not have a legitimacy. How do political parties and movements gain legitimacy? It’s not conferred by Israel or the United States as conferred by the people. They won an election. Oh no, their critics say. They didn’t win the election, Fatah lost it. Okay. Fatah lost it because Fatah couldn't organize itself credibly and competently to stand for election and because Fatah accepted twenty million dollars in American election aid. And as soon as that came out in The Washington Post and was reprinted in the West Bank in Gaza, they lost votes. They want to destroy Israel, so did the PLO. They have a charter that says they want to destroy Israel. So do the PLO. And yet we’ve had Hamas leaders that say the following. We have a charter that says, yes we admit it, we want to destroy Israel. But the charter’s not the Quran, and it can be changed. And under the right circumstances, if we can talk to our adversaries, we can and we will change it.

The other argument that we say, we’ve heard it tonight. They provide social services. Oh cynical people, how could they do that? You mean they’re actually trying to serve their people, clear up corruption? I too was talking to Hamas leaders when I was in the Middle East. Just one week ago, Osama Hamdan, the foreign minister of Hamas, here’s what they’ve done. They’ve penetrated the Education Health Ministries, cleaned them up, that’s forty percent of the total employment of the government of Palestine. They’ve thrown out the corrupt people. They’ve taken over the Ministry, they’ve started to provide services to people. They’ve kicked out Fatah members who are in exile around the world for stealing money from the Palestinian people. Don’t we want good governance? Shouldn't we talk to people who want good governance, who stand for elections? They kill innocent people. They have killed innocent people, rudely, terribly, like others have. It’s not an excuse to say, well the Israelis have done it. Well Lehi did it. That’s not an excuse. They’ve killed innocent people and they come out to be absolved. But after long discussions with Hamas, conducted by my organization, painful discussions, arguments about the killing of innocents, not moral arguments, practical, effective, political arguments. They stopped. I’d like to take credit. They stopped these suicide bombers through talk because they realized how ineffective they were, how they were losing support for what they feel is a legitimate cause. There hasn’t been a Hamas-led suicide bombing in Israel since August of 2004. That’s a fact. People can change.

There are three conditions for Hamas being recognized as a legitimate political party. To renounce violence, to give up their arms, and to recognize Israel. We’ve been through this and through this with Hamas, and we’ve said why don’t you do this? And the best answer that I’ve had from a Hamas leader is as followed. If we do that, if we renounce violence, if we give up our arms, and if we recognize Israel, what’s there to talk about? What do we talk to our enemies about? Do you think we’re going to say, oh welcome to the world of nations? Finally we’ll withdraw to the sixty-seven borders? Here’s what we would like. We will recognize Israel, Khaled Meshaal has said this very straight forward in Damascus again and again and again and again. We understand and we recognize that the Israeli people, the Jewish people have a narrative, it’s an important narrative. We’ve listened to it for many, many years.

We have a narrative. Here’s our narrative. In 1948, we lived on a land that was called Palestine. Many of us were kicked off our land and now live in refugee camps. We have legitimate grievances. If you will recognize our legitimate grievances, and recognize our narrative as a people, we can begin to share a narrative, to have talks. But until that point comes, when you stand up and say we understand that you have grievances that have to be addressed, we’re not going to recognize anybody. We’re going to represent our people. Now here’s what’s happening, I think, in the Middle East. Now, and I just returned from Beirut. There are, on the internet, calls for the assassination of the leaders of Hezbollah and Hamas by the leaders of Al Qaeda. Why? Because Hamas and Hezbollah have accepted the western, colloidal mandate, to stand for elections and represent their people. Al Qaeda thinks that’s a trick. Hamas and Hezbollah don’t. They answer to their people. We are lumping together the Girondists with the Jacobins. We are lumping together the true reformers in the Middle East, the ones who want to answer to their people with the people who drove their airplanes into our buildings.

We are forcing the Gironde – for those of you who remember French history – into the mountain, into the Jacobins. It is, it is so counterproductive. We are radicalizing the region. There are moderates in Islam. They’re called Hamas whether we like it or not. And it’s time to open up to them. I thank you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: We are forcing the Gironde – for those of you who remember French history – into the mountain, into the Jacobins. It is, it is so counterproductive. We are radicalizing the region. There are moderates in Islam. They’re called Hamas whether we like it or not. And it’s time to open up to them. I thank you.

## Round 2

### Moderator
Claim: Thank you very much to our six debaters, three for and three against. And I'm now ready to announce to tell you the results of the vote that was taken before tonight’s debate began. Before the debate, we’ve counted the ballots. One hundred and sixty-one of you voted for the motion. Fifty-one of you voted against the motion. And fifty-six of you said you didn’t know. And to remind, the motion is “A democratically-elected Hamas is still a terrorist organization.” Again, a hundred and sixty-one in favor, fifty-one against and fifty-six of you said you had not made up your mind. Now we are ready to begin the audience question portion of the program. I'm going to call on the questioners. Uh, we have someone on each side of the auditorium here who is going to come to you with a microphone and we ask that you stand uh, when you ask your question. And we also ask that you please make your question short and to the point. We ask that members of the press, identify yourselves, uh, tell us who you are. And we ask that members of the audience who are not in the press uh, we want to tell you, you have the option to either identify yourself or not. So we will get underway and lets see, we have a question here in the front, yes.

### Moderator
Claim: Um, this is for the people who are for the motion. It seems that the US wants democratically elected uh, governments in the Middle East only if it’s one that they like. Not just Hamas, but for example the reticence to have free and fair elections in Egypt out of concern that the Muslim Brotherhood would prevail. Isn’t that a little bit hypocritical, and as a corollary to that, when these groups are actually voted in, doesn’t the necessity of governance and the compromises they have to make in order to govern moderate them anyway?

### Moderator
Claim: Is that directed at one individual or any one of those?

### Moderator
Claim: Mr. O’Sullivan. Alright.

### Conspiracy Advocate (CA)
Claim: I, I may take a different view from some of my colleagues on this side of the aisle on this question. Um as a matter of fact, my sticking point is violence. Do you, do groups who are standing for election continue to advocate and practice violence? That’s, to me is the sine qua non, if they do, if they maintain a private army, if they are uh, if they are acting as for example, um, the IRA continued to act for some years after the Good Friday agreement, I'm against that. Now I think in the case of uh, Islamist standing for election, I'm absolutely in favor of it. I think the American government is taking a risk in, in urging free elections when it will, they’ll sometimes bring to power people who are hostile to American foreign policy. But that’s a risk which we have to take. After all, it’s a risk which we take with every other part of the world and, and we have to live with that. I think in the case of Hamas, we put ourselves in a somewhat false position and my pos-, and this is a rather complicated point here, but once we had accepted the legitimacy of Hamas standing, it seems to me we had crossed that Rubicon. And once they, having, their having been elected, we simply had to accept that they were, they were there. I would not have said that they were a legitimate contender in the election myself until, as I say, they’d abandoned violence which is my, in a sense, not my sole criterion, perhaps, but my overriding criterion.

### Conspiracy Advocate (CA)
Claim: Can I just add something to that Judy?

### Moderator
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: On this question of the United States only liking the people that gets elected, and you mentioned the issue of Egypt and since I'm writing a book about Egypt, I, I, I feel compelled to respond. There’s not a single Egyptian official, nor is there a single American government official who believes who has, that the United States is no longer pressing the Egyptians on democratic reform. It’s just not true. In fact I was in Cairo in September, and at the same time that the United States government presented papers to the Egyptian government that included benchmarks for democratic change. And that is even with eighty- eight members of the Muslim Brotherhood in the Egyptian Parliament. The difference between the Muslim Brotherhood in Hamas is that the Muslim Brotherhood in Egypt has not engaged in an act of violence since at least the 1970s. You can’t say the same thing about Hamas. Well that’s terrific, they haven’t –

### Scientific Advocate (SA)
Claim: Well that’s because there’s, there’s been a million, there’s been a million people that belong to the Muslim Brotherhood and probably two hundred thousand in Egypt that are in jail because they’re –

### Conspiracy Advocate (CA)
Claim: Hold it, Stanley.

### Scientific Advocate (SA)
Claim: As, as soon as the Muslim Brotherhood tries to run for election, they get jailed. They get tortured. They get, eighty-eight, eighty- eight members.

### Conspiracy Advocate (CA)
Claim: No, no, no, no, come on Stanley.

### Scientific Advocate (SA)
Claim: Who’s controlling Egypt? The Brotherhood?

### Conspiracy Advocate (CA)
Claim: We clearly know -

### Scientific Advocate (SA)
Claim: No, no.

### Conspiracy Advocate (CA)
Claim: We clearly know who’s controlling Egypt.

### Scientific Advocate (SA)
Claim: The question asked is –

### Conspiracy Advocate (CA)
Claim: It’s certainly not the Muslim Brotherhood.

### Scientific Advocate (SA)
Claim: Do we support democracies –

### Conspiracy Advocate (CA)
Claim: But they did –

### Scientific Advocate (SA)
Claim: And do we oppose democracies that we don’t and the reality of it is – You know -

When Musharraf –

### Conspiracy Advocate (CA)
Claim: Actually you know this.

### Scientific Advocate (SA)
Claim: Musharraf became –

### Conspiracy Advocate (CA)
Claim: You have absolutely no understanding of what the US government is doing right now to promote democracy in the Middle East.

### Scientific Advocate (SA)
Claim: Ask the audience.

### Conspiracy Advocate (CA)
Claim: This is all very entertaining -

### Scientific Advocate (SA)
Claim: They see it every night on television what the United States is doing to promote democracy. If you're with us, you're okay. If you're not, you're a good Muslim or a bad Muslim, Mr. Bush, it doesn’t change no matter what you want to call it.

### Scientific Advocate (SA)
Claim: Who’s going to be the next president of Egypt? You think it’s going to be democratically elected?

### Scientific Advocate (SA)
Claim: Right.

### Scientific Advocate (SA)
Claim: Or is it going to be -

### Scientific Advocate (SA)
Claim: Or Jordan, or Jordan. That other bastion of support, progressive ideology that the Israeli ambassadors supports. You're good if you're with us and if you're not, you're not. And it really doesn’t matter. If you follow our politics, you're a good guy, and if you don’t, you're trafe How is that, expert in Egypt?

### Conspiracy Advocate (CA)
Claim: Well I think this is, I think that this is really nonsense. I think we are here talking, you know, in just slogans, democracy and first of all we have to remember, you know elections, democracy doesn’t start with elections, it doesn’t end with elections. There is a culture, there is, there should be a rule of law, there should be a participation of all walks of life in a society. Unfortunately we have a backwards situation in all the Muslim and Arab countries where there is no, basically there is no middle class. There is only elite who really control all the resources, all the political power, all the economics, and everything else and all the others are poor, uneducated. And they, and really they are subject to the incitement of the ideological zealots from Iran -

### Scientific Advocate (SA)
Claim: What an arrogant statement to talk about five thousand year old culture –

### Conspiracy Advocate (CA)
Claim: Stanley, chill out, you’ll get an opportunity.

### Conspiracy Advocate (CA)
Claim: I'm talking about facts, I'm just talking about facts. So what I, what I would answer to you is no, we should not promote democracy in the Middle East. What we should promote is equal opportunities. What we should promote is empowerment of women. What we should p-, uh, promote is good education for the people so there’s not these inequalities. And when the people themselves will have a stake in their own lives, in their societies, they will decide what type of regime they do want.

### Scientific Advocate (SA)
Claim: What the ambassador means to say is, there won't be a vote until the people are ready which is just exactly what J. Edgar Hoover said about African Americans in America – Please.

Thirty years ago.

### Conspiracy Advocate (CA)
Claim: This has nothing to do with that and uh, irrelevant.

### Scientific Advocate (SA)
Claim: Just a quick comment on this, with all due respect to the ambassador –

### Moderator
Claim: And then we’ll get to the next question.

### Scientific Advocate (SA)
Claim: Yeah, I, I, this is precisely what I meant by unilateral understanding. We, I mean we, here again, we have to decide this, we have to support, we have, it’s, it’s, it’s very, very materialistic. It’s as if all of these populations have no sense of what is important to them, what is legitimate for them, who stands for them. I mean Fatah has lost all credibility in that, in that area not simply because of external support, essentially for what they’ve done with the b-building of apartments in Dubai and so on and so forth. The people know who stands for them, people know who will defend them. And if Hamas has left that scene which was, as I said, a military scene as, and has chosen to represent the democratic, uh, in a democratic way this, these groups, then it’s something that speaks for the values of these people. And keep in mind as well, who was fielded in these elections. Pharmacists, doctors, professors, I mean business, women, this is not simply a group of, as you called them earlier, “thugs in limousines.” Khaled Meshaal, last weekend at his, last week in his press conference, was citing Foreign Affairs articles by Richard Haass. I mean we really have to be a little bit more sophisticated – We’ve had –

### Conspiracy Advocate (CA)
Claim: Let me just mention to you, you're mentioning –

### Moderator
Claim: Good discussion now on this question and I think we do need to move to the next –

### Conspiracy Advocate (CA)
Claim: No but this is very important Judy.

### Moderator
Claim: We can get each of you –

### Conspiracy Advocate (CA)
Claim: I think it’s important because they keep raising this issue of –

### Moderator
Claim: Well –

### Conspiracy Advocate (CA)
Claim: Being pharmacists and doctors.

### Scientific Advocate (SA)
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: And all that, let me tell you –

### Conspiracy Advocate (CA)
Claim: Just because you're a pharmacist –

### Conspiracy Advocate (CA)
Claim: There are millions –

### Conspiracy Advocate (CA)
Claim: Doesn’t mean you're not a terrorist.

### Conspiracy Advocate (CA)
Claim: There are millions of engineers and doctors.

### Conspiracy Advocate (CA)
Claim: Osama Bin Laden is a civil engineer, come on.

And professors and musicians in the thirties who voted for the

### Conspiracy Advocate (CA)
Claim: Nazi party which brought on the Holocaust.

### Scientific Advocate (SA)
Claim: I think that’s an unfair – With doctors –

### Conspiracy Advocate (CA)
Claim: Lawyers, pharmacists.

### Conspiracy Advocate (CA)
Claim: Professors –

### Scientific Advocate (SA)
Claim: And the guy who – President of the United States, it begs the question.

### Conspiracy Advocate (CA)
Claim: And what they believe in, this is what should be the yardstick. Alright.

Not their diplomas.

### Scientific Advocate (SA)
Claim: As long as the Iranians and Syrians tell them what to do, is that correct?

### Moderator
Claim: We are going -

### Scientific Advocate (SA)
Claim: As long as the Iranians the Syrians tell them…

### Moderator
Claim: We are not going to resolve this now, we need to let the next person have a question. Yes, I believe, yes sir, you’ve been patiently waiting.

### Moderator
Claim: Hi, my question is for the against side, specifically for the gentleman who have had direct conversations with Hamas. If Hamas refuses to recognize Israel, how can the organization support a two-state solution?

### Scientific Advocate (SA)
Claim: Well long before there was Hamas, you know you got to, governments say things all the time. People say things all the time. If Hamas tomorrow said, we recognize the state of Israel or the right of Israel to exist, the ambassador would say prove it. Come back to us in twenty years, when you’ve shown we’ll accept it for twenty years. The reality of it is, I'm not concerned about what people say they will do, I'm more concerned about what in fact they do, do, and on the ground. The reality of it is that you’ve got statements that have come as close as they’re going to come. That talk about if we go back to the sixty-seven borders, that is the starting point and that’s where we’re going to move. Everyday the United States government makes statements.

There’s weapons of mass destruction, we go in through Iraq. You know what, no weapons of mass destruction. Don’t get hung up on the rhetoric of labels, don’t get hung up on we recognize your right to exist. What about recognizing the right of return? Stanley Cohen can go home, but if my name is Mahmoud, I can’t go home. So you have to be reciprocal. I haven’t heard a word from Israel about the right of return, I haven’t heard a word from Israel about the right to a government, I haven’t heard a word from Israel about the right to recognize what the Palestinian people want.

### Conspiracy Advocate (CA)
Claim: You’ll hear it pretty soon from me -

### Scientific Advocate (SA)
Claim: We want unilateral concessions.

### Conspiracy Advocate (CA)
Claim: Can I, can I answer to that? Well don’t judge us and don’t tell me what Israel will say for twenty more years. Just judge us by our deeds. When Egypt was ready to recognize Israel, we signed a peace treaty, the same with Jordan, the same with the PLO, and I take issue, I think it’s incorrect what you mentioned here. Israel was ready to recognize the PLO and talk to them only and only after Yitzhak Rabin received a letter signed by Yasser Arafat, ninth of September, ’93, which renounced terror, which recognized Israel’s right to exist, and which also promised to change this charter that you were talking about. This is exactly what we’re expecting from Hamas. And this is not just an Israeli expectation, this is a demand by the entire international community as was expressed by the quartet, the four parties that are responsible for the peace process in the Middle East. Which called for the Hamas after they were elected, they said okay, you were elected, it doesn’t matter if it was democratically or not, it doesn’t matter if you're a terror organization, lets look and move forward. And Israel is in that camp, lets look and move forward, not about what you did, the fact that you already fired Qassam rockets this morning, killing a baby in Sderot. Lets look to the future and we still say, if you renounce terror, if you recognize Israel’s right to exist and you abolish your charter.

And now also if you accept our previous agreements which were signed by the PLO, then you are a le-, legitimate parter, partner. But they’re not doing that because they’re still a terror organization, because they do not believe in coexistence and they do believe not in building a nation but destroying one, which is ours. And we are not going to let them do that. You're talking about, Stanley Cohen, about the right of return. What kind of right of return? There’s no right of return. There are, there were Arabs there which we wanted to coexist with them, but they refused -

### Scientific Advocate (SA)
Claim: It’s all, it’s all, it’s all a conspiracy between Iran and Syria. Eight hundred thousand people just woke up and moved.

### Conspiracy Advocate (CA)
Claim: Just read, just read the history, just read the history and then you will know, there is not such a thing as right of return. There is a problem of the refugees, this is true. There is a refugee problem, but the responsibility for the refugee problems lie on the heads of the leaders of the Palestinians and of the Arabs. Alright.

### Moderator
Claim: We have a question, I see a hand right there.

### Moderator
Claim: My name is Michael Brown, I'm a freelance writer. There’s something that seems very myopic about this conversation with the war raging in Iran and, and Lebanon. This, this sort of insoluble binary seems to have spread to the whole world in terms of who’s a terrorist, who’s a democrat, who’s right and who’s wrong. You hear repeatedly that the key to peace of a region and the world is in the Israel-Palestine conflict. This is for anyone in the panel, if you still think that that’s true.

### Moderator
Claim: For anyone on the panel.

Yeah.

Alright we’ll, we’ll begin with this side because we heard last.

### Scientific Advocate (SA)
Claim: Well I think you, and let me if I may, remind us of the motion that this debate is not about the Palestinian-Israeli conflict, the motion is about the last ten months and it, whether Hamas is still a terrorist organization. And the facts are that everything that Hamas did over the past month, ten months cannot be qualified as terrorist. I mean you can come up with –

### Conspiracy Advocate (CA)
Claim: Indiscriminate firing at children –

### Scientific Advocate (SA)
Claim: Well –

### Conspiracy Advocate (CA)
Claim: Schools, they’re all –

### Scientific Advocate (SA)
Claim: It’s interesting you should say that, you know I, because when you look at it, you will find out that, sir, I think you should know that, this was actually the violations that came, came from the Fatah side. And the Fatah was associated with that as well as –

### Conspiracy Advocate (CA)
Claim: Not at all.

### Scientific Advocate (SA)
Claim: Ghazi Hamad is the name of the person that actually speaks about these matters and you can go and check and, and see every one of the actions that was in violation was denounced by Hamas officially. So again, facts or statements?

### Moderator
Claim: Who holds Corporal Shalit which was kidnapped in our territory?

### Scientific Advocate (SA)
Claim: Well I wouldn't know.

### Conspiracy Advocate (CA)
Claim: It’s the Hamas. What you wouldn't know –

### Scientific Advocate (SA)
Claim: Who holds the ten thousand Palestinians sitting in jails that haven’t seen –

### Moderator
Claim: But who holds –

### Conspiracy Advocate (CA)
Claim: They are all terrorists and this is the difference.

### Scientific Advocate (SA)
Claim: They’re all terrorists?

### Moderator
Claim: Thirty-seven legislators –

### Scientific Advocate (SA)
Claim: All ten thousand of them.

Oh absolutely.

All ten thousand Palestinians including the fourteen-year-old –

### Conspiracy Advocate (CA)
Claim: Let me tell you that –

### Scientific Advocate (SA)
Claim: Then what are you afraid of? Put them on trial.

### Conspiracy Advocate (CA)
Claim: Let me tell you that they are not –

### Scientific Advocate (SA)
Claim: Put them on trial.

### Conspiracy Advocate (CA)
Claim: It’s not just the ten thousand there.

### Scientific Advocate (SA)
Claim: You have a democracy.

### Conspiracy Advocate (CA)
Claim: There are fifty thousand more.

### Scientific Advocate (SA)
Claim: You have a democracy.

### Conspiracy Advocate (CA)
Claim: Mm-hmm.

### Scientific Advocate (SA)
Claim: Let them go, let them have trials.

They are all –

Prove your case.

### Conspiracy Advocate (CA)
Claim: They are all being trialed, they are all being processed.

### Moderator
Claim: Let me, let me –

### Conspiracy Advocate (CA)
Claim: And I wish the same chance was given to the Israeli kids that are being targeted by these guys.

### Scientific Advocate (SA)
Claim: Oops. I know there we go again, every time those darn Palestinians get in the way of our missiles and our tanks and end up dead. Whoops, there it goes again. But yet when we do it, we’re sorry. But you, you target and that’s the moral superiority. So the mor-, the moral position that you’ve always taken. Look, it’s terrible when civilians on both sides get killed. It’s terrible, it’s got to stop and the way you stop it is you dare to struggle. You break the labels, you sit down with no preconditions and you try to move ahead. And if it doesn’t work, you're right back to where you were but at least there’s a chance.

### Conspiracy Advocate (CA)
Claim: Absolutely, this is exactly what we want. We, we say stop the killing, stop the terror and we will sit and talk.

### Scientific Advocate (SA)
Claim: And what about your side?

### Moderator
Claim: Question.

### Conspiracy Advocate (CA)
Claim: What we will talk about, what we will talk about? The road map to peace.

### Moderator
Claim: We only have about four minutes left for questions so I do want to recognize someone there in the very back, please, stand up.

### Moderator
Claim: I have a question. My name is Goldin and I'm a teacher. I have a question to Mr. Cohen. If your argument Hamas, with that said, with everything going on according to your plan and you would be, would you go for even a short visit to Israel just to recognize, just to receive congratulation? Would you take such a risk?

### Scientific Advocate (SA)
Claim: I go to Israel all the time. In fact, in fact sir, sir… Sir, I lost family in a bombing in Jerusalem, I lost family in World War II, I cannot tell you how difficult it is for me as a Jew to sit back and for sixty years, watch what has occurred – And not just in the name of people in Israel, but in the names of Jews all over the world. The answer is yes, I would go, and yes I would gladly do what has to be done to break bread and to try to bring some sanity to this war of labeling. That’s the problem. We are so locked into labels, we are so locked into an inability. You must do this or I’ll do that, I must do this or you’ll do that. There’s absolutely no down side to sitting down without preconditions and talking.

### Moderator
Claim: Absolutely.

### Moderator
Claim: John O’Sullivan. John O’Sullivan has been asking –

### Conspiracy Advocate (CA)
Claim: I think that there is, just on the general point here, there are consequences to launching unsuccessful wars against Israel. The first is that Israel ends up with territories which didn’t originally belong to it, the second is that there are going to be large numbers of refugees, and the third is that the Israelis, given their strategic, long-term vulnerability are going to be very suspicious of proposals for peace that don’t come accompanied by guarantees. But do come accompanied by demands for a right of return that would negate the Jewish state altogether.

### Moderator
Claim: Okay. We, we have time for one more audience question, preferably a short one, and please tell us who it’s directed to and lets see. Where do we, do we have someone with a microphone up there? Okay, go ahead.

### Moderator
Claim: I’d like to ask two brief questions, and I’d like to thank Mr. O’Sullivan –

### Moderator
Claim: Let’s make it one.

### Moderator
Claim: Okay.

### Moderator
Claim: We have two minutes.

### Moderator
Claim: I’d like to thank Mr. O’Sullivan and Mr. Perry for I think making the most uh, intelligent arguments tonight. Um, I just want to ask the For side how they, if they feel that political power is a uh, moderating force on uh, extremists. And how their view of terrorism uh, is consistent with the actions of David Ben-Gurion and the bombing of the King David Hotel.

### Moderator
Claim: Who would like to pick, Steven?

### Moderator
Claim: I’ll – Steven Cook.

### Conspiracy Advocate (CA)
Claim: I’ll go for it, thank you very much. Um, I think that there’s really no condition. The pothole theory of politics, that somehow Hamas, which is dedicated to a broader, ideological agenda, is someone going to have to pick up the garbage, that that is going to moderate their view of the world. That certainly didn’t happen with the PLO once it returned to Gaza, I don't expect it will happen with Hamas. Now of course the question of bomb, of the King David Hotel, everybody trucks that out as, as evidence of terrorism, the fact that the, the Israeli, Israelis before, in the pre- state era engaged in terrorism. My understanding of the bombing of the King David Hotel was that it was not directed specifically against innocent civilians, but it was against British occupation, authorities. That is not consistent with the definition of terrorism.

### Moderator
Claim: Alright. Uh, thank –

### Conspiracy Advocate (CA)
Claim: There, there were terrorist acts against British troops, during the war, by the way, just to make that point.

### Scientific Advocate (SA)
Claim: Oh.

## Round 3

### Moderator
Claim: Alright, it is now, it is now time for all of you in the audience, this is the moment, this is time to vote. This is the ticket, pull it out of your pocket or your lap, wherever it is, your handbag. If you want to vote for the motion, tear off the “For,” the green For from the ticket, the top of the ticket, and slip it into the ballet box that will be passed among you. If you want to vote against, tear off “Against,” the red. Tear off the red Against and put that into the ballot box. And if you do not know which side you're on, if you are undecided, put your entire ticket into the ballot box. The ballot boxes are going to be passed around the ushers, the front and the back of the auditorium. Pass it to the next person, we want to make sure everybody’s vote is counted. If you need a ticket, just wave your arm in the air, the ushers have extra tickets. Everyone gets one vote, And now we’re going to turn, while you're finishing this up, we’re going to turn to the panelists, beginning with the side opposing the motion. And we are going to ask them to make their final argument. So opposing the motion, against, Stanley Cohen. Two minutes.

### Scientific Advocate (SA)
Claim: Sure a lot more difficult debating here than it was in Qatar or in Doha. I have a friend, dear friend of mine, believe it or not, an Israeli. Named Leah Tsemel, famous Israeli lawyer, she used to be called Arafat’s whore by Israeli politicians. Leah said to me one day when we were driving to the Erez crossing where we had to wait twelve hours to go in to see people, Leah said in response to a comment about how they want to drive us to the sea and drown us, Leah said the only one who’s going to drive us to the sea and drown us is ourselves. The notions that Palestinians have nothing to do but to die or to kill after all of this time is the difficulty. We see resistance as this desire and this need to be terrorists, to die and kill which is defied by what’s happening on the ground. The real shame here, the real sin here is for the first time in history, Palestinian and Israeli kids aren’t going to schools together. They’re not spending time together, they’re not falling in love together, they’re not doing businesses together. And the problem is the walls of labels are keeping sides apart. People say Hamas is a terrorist organization, I say Israel is a terrorist state. Who cares? The two sides need to sit down without preconditions, see if you can find common ground as people to grow so those kids can fall in love again, thank you very much.

### Moderator
Claim: And now for the motion, Steven A. Cook.

### Conspiracy Advocate (CA)
Claim: It’s amazing, isn’t it? Everything I told you would happen, happened. Our interlocutors on the other side did not address the issue at hand, they shifted to Israeli behavior. But I want to respond to some specific things that each of them said to demonstrate how weak their arguments are. And since Stanley impugned my credibility and my expertise, I’ll return the favor. Stanley spoke passionately ponytail waving, arms in the air, doing the whole hippie thing, talking about many or most in the world believe. Come on Stanley, I got my Ph.D. because, I didn’t need to go to law school because I'm the son of a lawyer. You should know every first year law student knows that when you argue “many in the world,” “most in the world,” “most people believe,” it’s a logical fallacy. Just because most people believe it doesn’t make it true. What is Mahmoud talking about when he talks about protorecognition? Is that like being half pregnant? You can’t be half pregnant, you either recognize or you don’t. I had, throughout the 1990s, I spent my time parsing the words of Palestinian leaders, do they or do they not recognize, what is protorecognition? Hudna means somehow recognition, but hudna’s in. I don't understand it. The majority of the Palestinians did not vote for Hamas. Forty-four percent of the people voted for Hamas. Now I'm sure the people on the other side of the room would say that George Bush was not democratically elected because the majority of Americans didn’t vote for him in 2000. Well I would apply the same principle to Hamas. I'm shocked, I'm actually shocked that Mark Perry’s interlocutor is Osama –

### Moderator
Claim: Fifteen seconds.

### Conspiracy Advocate (CA)
Claim: Oh I’ll skip that part. I’ll just say, I’ll just say that it is extraordinary that Mark Perry gave all the evidence you needed to vote for the proposition. He said his Hamas interlocutor said that they would not give up violence because it’s a bargaining chip. Time’s up.

So thus the lives of innocents is a bargaining chip, it’s a political power player on the part of Hamas. They will continue their terrorism, thank you. I urge you to vote For. Oh you’ve already voted, so thanks for your vote.

### Moderator
Claim: Against the motion, Mahmoud Ould Mohamedou.

### Scientific Advocate (SA)
Claim: Thank you very much. Well I had a bit of an uplifting argument to finish with but I guess that unfortunately we’ve moved from intelligent debate to acuteness, apparently winning it. And it’s a pity because the whole debate was not necessarily about this pro- Israeli or pro-Arab or pro-Palestinian. It’s really something different. It was about justice, people fighting for justice are not terrorists, it’s about international legality, wars of national liberation are not terrorism. And it’s about the cogency of our moral principles. But it seems that all of this uh, sort of um, again acuteness that was adopted to address these life and death matters seems to have won the room and you know, fine. But again back to Stanley’s point, history marches on. Um and although one might think that there’s something inevitable about the Arab, Israeli conflict, I for one would like to believe that it’s not. Imagine if the EU were to call a Hamas delegation or have an adult conversation with them. Imagine if the Secretary of State were to address elected officials and, and invite them and discuss with them. Imagine if the Israeli population elected a government from which they asked and then to implement policies and negotiations with whomever is in charge. This I think would quell the violent, violence on both sides, resuscitate the peace talks, and get us into a new dynamic. You don’t have to imagine the opposite situation. We’re in it and we’ll continue to be in it as long as motions such as tonight, such as tonight’s will continue to let it. Thank you.

### Moderator
Claim: Okay. For the motion, John O’Sullivan.

### Conspiracy Advocate (CA)
Claim: Well I'm delighted that there are distinguished psychiatrists, doctors, lawyers and so on in Hamas, and at the moment Radovan Karadzic is on the run from NATO as a war criminal. He himself was a child psychiatrist before the war started. I wonder what became of his charges. It’s unusual for me to find myself as the idealist on the platform, but I point out that the argument that we should be having as well as the particular argument about the Middle East is an argument about violence in politics. When violence enters politics, it’s very hard to drive it out again. And when indiscriminate violence against innocent people enters, it damages the society very strongly indeed. Now that’s not the only way to have a revolution. Polish solidarity won independence from Russia. And that has been repeated in Georgia and in the Ukraine and elsewhere by a campaign of moral resistance and cultural resistance that wore down the opposition and persuaded people to come over to it. That’s the, that’s the kind of revolution if the, if one is needed. That’s the kind of revolution, recourse that we should encourage people to pursue. We should not turn a blind eye to their crimes because they have managed to be elected. It’s a fine thing to be elected, but it doesn’t absolve you from the laws of human conduct that the rest of us are supposed to obey.

### Moderator
Claim: And our final argument against, Mark Perry.

### Scientific Advocate (SA)
Claim: We won't be here two years from now, two years from now debating this question because by two years from now this, this debate will be resolved. Why? Because Israel will be talking to Hamas, that’s why. Because they’re talking to them right now. How do we know that? Because there is a proposed cease-fire in Gaza in which Khaled Meshaal traveled to Cairo and Ehud Olmert said, if you can stop those rockets, we’ll withdraw from Gaza. Now that might not be eyeball to eyeball talk but that’s a political understanding. And how did that happen? It happened because George Bush was going to Amman, Jordan and Dick Cheney is going to Riyadh, Saudi Arabia, to talk to those guys about helping us out in Iraq and they’re looking at him and saying how are we going to do that when our own people are making a clamor about the Israeli-Palestinian conflict? And so George Bush and Dick Cheney are picking up the phone and calling Prime Minister Olmert and he’s saying, what? I can’t, they’re a terrorist organization. George Bush is going to go, oh come on. Where do you think this is? Grow up, be adults. We’ve got a world to run. You want to run it? Talk to people, talk to them. They might be a terrorist organization, yes they’ve killed civilians, yes it’s a terrible thing. After World War II, we went into Germany and put three hundred and thirty-four people on trial and called it a day. Why? Because we have to go forward, and it’s time to go forward. It’s time to go forward, thank you.

### Moderator
Claim: And our final debater for the motion, Ambassador Daniel Ayalon.

### Conspiracy Advocate (CA)
Claim: Yes. Thank you, well what was the issue today? The issue was of little moral and practical nature. Legally, are they law offenders? They have illegal arms, they breached the law, yes, Hamas does. Moral issue. Are they killers of children and other innocent people, yes they are. And of practical issue, just a matter of common sense, is there any sense talking to them? Will talking to them bring peace and quiet? Well I don't think so. Now we have to make sure the equation is right, and it’s not that they will say well we will stop killing you if you give us land, if you give us political concession. This is not the equation. If they stop killing us, we will stop hunting them. When they are ready for political concessions, we will give them political concessions. It’s apple to apple, oranges to oranges. This is the issue and so long as the Palestinians and Hamas especially, deny recognition of Israel’s right to be there in their homeland, there’s not going to peace, to be peace. And the fact that they continued with this uh, terror, and some would call it resistance is also a fallacy because it’s not resistance. Israel is ready to uh, to build a Palestinian state. Israel was withdrawing from territories, the entire area of Gaza, areas of the West Bank. And we are willing to talk. What, what are we going to talk about? The road map to peace, how to make peace, how to create a Palestinian state which will live side by side with a Jewish Israel. This is at stake now, and so long as the Palestinians do not want to do that, as long as they keep the killing, there’s nothing to talk about. They stop the killing, then we talk.

### Moderator
Claim: Alright, I want to thank all of our debaters, I want to thank all of you in the audience for your excellent questions and your good behavior. It’s time now to announce the results of the voting after our debaters did the very best job they could to sway you. Here’s the number that we have. A hundred and fifty-nine voted for the motion, one hundred voted against which is a, almost a doubling of what it was before. And fifty-two said I don't know. So again, a hundred and fifty-nine for, a hundred, that means that a number of you didn’t vote when you first came in. That’s, it, it looks as if we’ve got forty-nine, fifty, fifty or so more people who voted uh, at the end. Uh, but again we appreciate the participation of all of our debaters, we thank you in the audience, I want to invite you to return next month for the fourth Intelligence Squared US debate on Wednesday, December 13th here at the Asia Society and Museum. The motion to be debated is Hollywood has promoted anti-Americanism abroad. We have an edited version of tonight’s Intelligence Squared US Debate, it can be heard locally on WNYC AM820 on Friday December 8 at 2 P.M. Please check your local NPR member station listings for the date and the time of broadcast outside New York City. Copies of Mahmoud Ould Mohamedou’s book, Understanding Al Qaeda, and John O’Sullivan’s new book, The President, the Pope, and the Prime Minister. Those are for sale upstairs in the lobby. Please also be sure to pick up a complimentary copy of The Times of London, that’s on the table outside the auditorium doors. Thank you all for your support of Intelligence Squared US.
