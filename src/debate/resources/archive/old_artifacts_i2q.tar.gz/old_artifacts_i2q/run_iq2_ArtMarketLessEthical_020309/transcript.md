# Debate Transcript

Topic: The Art Market is Less Ethical than the Stock Market
Motion: The Art Market is Less Ethical than the Stock Market

Debate ID: ArtMarketLessEthical-020309


## Round 1

### Moderator
Claim: Okay, Ladies and gentlemen, we’re going to begin in about one minute. If you could take your seats quickly... Thanks. All right, let’s begin. I’d like to begin the evening first by introducing the Chairman of Intelligence Squared U.S., Mr. Robert Rosenkranz.

### Moderator
Claim: Well thank you all very much. I see a lot of new faces. And I think the buzz at the cocktail hour was about as buzzy as we’ve ever seen. So thank you all for being here and braving the weather. The language of tonight’s resolution, I think I might have done it a little differently had I known about the Bernie Madoff scandal. But the art world does have its share of forgeries and its share of dealers who fake provenances and its instances where things are stolen from consignors. So there are bad apples in every basket. But that’s not really the thing that interests us and why we picked the language of this debate.

It’s really the ethical issues revolving around two ideas. And one idea is secrecy and the other idea is manipulation. When you buy a work of art at auction it seems like a very open process. But there are a lot of secrets. You don’t know what the reserve is. You don’t necessarily know the source or the meaning of the estimates that are attached. There’s no real disclosure about guarantees. If the auction house has made a deal with favored third parties, you don’t know about that. What’s described as a buyer’s premium is sometimes rebated to the seller or used for other purposes. Again, pretty obscure, a lot of secrets in that process. And the second element, I’d say, is market manipulation. As an example, the graphic symbol we used for tonight’s debate was Damien Hirst’s skull encrusted in diamonds.

That was widely publicized to have sold for a hundred million dollars, which I believe is the highest price ever paid for a work by a living artist. Well, it turned out subsequently that the purchaser was none other than Damien Hirst and his dealer to the tune of at least fifty per cent of the syndicate that was buying it – and who knows how much in reality. In the recent auction of Damien Hirst’s work he or his dealer was a buyer of a lot of key lots. And another example is the Warhol market, which is dominated by a family called Mugrabi – textile merchants from Columbia, who own eight hundred Warhols and are prominent buyers of all of the prime examples that they bid up at auction. So it’s also very common practice for dealers to bid up the auction prices of works of art by artists in their stables. But dealers get very angry at clients who sell at auctions – often blacklisting those clients.

So I’d like now to turn back to the stock market. In the 1920s there were syndicates of sophisticated investors who would quietly accumulate stock and would then sell the stock back and forth to each other at ever increasing prices in order to give the unsuspecting public the sense that there was an ebullient and lively market. When the public came in the insiders would quietly sell. Well, that conduct became illegal and it’s been illegal for the last sixty or seventy years. And in a way, when the art market is advertising prices at auction that are not real, that are intended really to deceive people about the true state of the market, that’s a very similar kind of manipulation. The questions for tonight are, How endemic is that? How common is it? Should those kind of practices be illegal? And finally, does the art market operate in a generalized sense with high ethical standards or not? And we have a very, very distinguished panel. And it’s now my pleasure to turn the evening back to John Donvan.

### Moderator
Claim: Thank you. And may I invite one more round of applause for Robert Rosenkranz, who makes these evenings possible? Ladies and gentlemen, welcome to another Intelligence Squared U.S. debate from the Caspary Auditorium at the Rockefeller University. I’m John Donvan, your host and moderator. And the motion before us tonight is this: The Art Market is Less Ethical Than the Stock Market. We have six panelists, all from the New York and London art world. We know that we have many members of the New York and London art world in the audience tonight as well, which makes for an even more interesting evening because this debate actually is a contest.

It is a contest of wit and logic and ideas and facts and argument, and most of all, persuasion. The six panelists are here to persuade to their point of view on our motion, which I will state once again: The Art Market is Less Ethical Than the Stock Market. In the course of the evening you will hear from the panelists in three rounds. In the opening round each side will speak alternately for seven minutes apiece. There will be no interruptions. They have clocks that tell them when their time is up. If they exceed that time I will step in and pull reins on them. After that we will have about a forty minute section where the debaters actually will debate head to head. And that will be mixed up somewhat with questions from me and also questions from you, the audience. And as I asked you earlier, when you ask questions please really think in terms of crafting a question. It is a challenge, it is an artistic challenge.

And the signature to a question is a question mark at the end of the statement. And finally, each of the panelists at the end of the evening will be able to sum up for two minutes and at that point we will find out who the winner is. Now, what we’re gonna ask you to do, we’re going to poll you twice during this evening – once now as you come in off the street to see where you stand on the motion, and once again at the end of the evening so that we can see how many minds were changed. So if you turn now to the keypads that are at your seats – and I explained this earlier, but for the new arrivals, there are a series of buttons. Please pay attention only to buttons number one, two and three. Those are the ones you need to register your opinion on this motion. The motion again: The Art Market is Less Ethical Than the Stock Market. Push number one if you agree, number two if you disagree and number three if you remain undecided.

If you think that you’ve pushed the wrong button just correct yourself and our system will record only your last entry. And I’ll give you about another fifteen seconds to record that. Does anyone need more time? Okay, we’re locking that down. And in a little while I’ll be reporting those early results and then that’ll tell us what the stakes are this evening. So let’s let the debate again. Our topic is: The Art Market is Less Ethical Than the Stock Market. Arguing first for the motion is Richard Feigen, President and Founder of Richard L. Feigen and Company, art dealers. He opened his first gallery in New York City in 1963, which in a sense gives him more experience in the art world than perhaps anyone else in this room – time enough to know what he likes and also to decide what he does not like, particularly before us tonight in the category of ethical behavior in the art market. Ladies and gentlemen, Richard Feigen.

### Conspiracy Advocate (CA)
Claim: Thank you very much and thanks to everybody for having this forum. It’s very interesting. And thanks to all of you for coming. The first premise that I want to propose is that the art market is a financial market now. It has become this and it is a totally unregulated financial market. I will also try to define ethical. I define ethical as a protection for the investor or art collector and unethical as efforts to deceive. I will narrowly define the stock market as publicly traded equities. Otherwise I risk sailing off into Bernie Madoff-land and uncharted waters. The art market really is divided into two parts – the private art market, meaning the galleries, and the public market, the auction houses.

In the private market there are protections of the purchaser in the form of the uniform commercial code in New York and the self-policing bodies like the Art Dealers Association of America. So I’m gonna foc...-- These are not totally protective but they serve a purpose. I’m gonna focus then on the auction market. The press usually defines the art market as the auction market for contemporary art, which gets all the press – where prices have ballooned in recent years. And therefore it has become press- worthy, because big prices make for press. In the past few years there has been rampant speculation. Until the middle-Nineties a work that appeared at auction, if it reappeared within five years it would be virtually unsellable. And now works appear almost immediately after being purchased or at least they did until the recent unpleasantness in the contemporary market, starting in November.

And because there’s a new wave of speculators at each auction. This all really began in the middle-Eighties, when art became monetized by the press and the financial institutions into a financial market, Sotheby’s launched a financial services arm, Citibank an art advisory department and so on. Banks lent money on art and auction houses lent money to buy art. Sotheby’s Chairman went to jail for colluding with Christie’s on auction commissions. Now art had become a serious financial asset. Whereas before the Eighties the market was tiny, it now became global. Thousands of people became involved. Billions of dollars changed hands. But except for foreign governments claiming repatriation of antiquities and Holocaust restitutions and despite the sums of money involved and vast numbers of participants, government seems to treat art as frivolous, as a luxury market with no regulation or oversight.

As just one example: in the Bush Administration tax code, when the capital gains tax was reduced from twenty-eight per cent to fifteen per cent art remained at twenty-eight per cent – apparently because it was treated by the government as a luxury, not an asset class. The stock markets are highly regulated by law. There are also protections for individuals who trade in the market through fiduciary, mutual funds and so on. Regulation came about as a protection for individual investors. The art market, on the other hand, is totally unregulated. Things occur, particularly in the auction market, that are deliberately contrived to deceive the unsophisticated individual and that would be subject to criminal penalties in the stock market. The most universally encountered is chandelier bidding, which means fake bids to entice bidders into competition.

Whereas regulations exist in the stock market to provide transparency, chandelier bidding is specifically designed to deceive, to imply that there is competition when there isn’t any. Novice buyers usually enter the market through auctions because they have no other way to establish values. And unlike securities, there are no two works of art that are identical or are in the same condition or have the same credentials. The only source of price comparison is auction data bases. But, again, comparisons are flawed. The novice auction bidder believes his only exposure is his incremental bid. He assumes that the under-bid represents a willing and able competitor. But if there wasn’t any under-bidder? What if the bid was a phantom, a chandelier bid?

When some years ago the issue of chandelier bidding was raised in New York’s Consumer Affairs Department, the auctioneers cried that to eliminate it would take the drama out of auctions and they threatened to quit New York City. When I was quoted as saying that when I want drama I go to Broadway I was called a horse’s butt. The only – I changed that word because my wife wouldn’t let me, or somebody in my office wouldn’t let me use it. The only result of this city inquiry was that the auctioneers were forced to identify items in which they have a financial interest or that are guaranteed or most recently in which there are irrevocable bids identified by miniscule symbols virtually invisible or incomprehensible to all but professionals. Otherwise, the auctioneers prevailed with their deceptive practices. In addition, the auction catalog disclaimers make it basically caveat emptor, as far as authenticity and condition are concerned.

In the private gallery market the invoice establishes the guarantee, by law. The real reason for the auctioneer’s ethical ambivalence is the dramatic shift in role over the last forty years from agent for the buyer. Then as demand started exceeding supply, first as agent for both buyers and sellers and then primarily for the sellers, the buyer paying almost all of the commission guarantees and irrevocable bids followed swiftly as further enticements to sellers. But the auctioneer’s role remained ambiguous. The auctioneer was now wearing at least two invisible hats and when he had an equity in the object, three.

### Moderator
Claim: Richard, I have to interrupt you. Your time is up. Ladies and gentlemen, Richard Feigen. Our next debater has arguably already earned his place in art history. Chuck Close’s paintings are in the collections of the National Gallery of Art in Washington, the Tate in London, the Museum of Modern Art here in New York. And while he has been known to spend months, even more than a year, on a single painting tonight we are giving him minutes to argue against the motion, that: The Art Market is Less Ethical Than the Stock Market.

### Scientific Advocate (SA)
Claim: Well, it doesn’t seem like we have to do much, given what’s happened recently. But, my argument is a little different. I don’t think that the value of art is determined by money at all. And I – I don’t think that the value of art is measured in that way. If you look at the turn of the century, Bugaro sold for far more than any other artist, in what would be in today’s terms, millions of dollars. And the artists that we now know and love, the Impressionists, Post- Impressionists, couldn’t sell their work at all.

So I question whether sales really is a barometer of value and whether ethics has anything to do with how that work is marketed. We have examples of the work being marketed extremely well, with great ethics. And we have examples of it being done in a somewhat sleazier fashion. I would say that art is not a business. Certainly the making of art is not a business. My good friend Joe Zucker, who is a great painter, his father was a junk dealer, a scrap metal dealer in Chicago. When he looked at Joe’s studio and saw the racks full of unsold paintings, he said, You can’t afford to make any more paintings until you get rid of some of your inventory. If any of us made work for that kind of reason, you know, you wonder where we would be. I remember Lee Marvin in The Ship of Fools was a washed-up baseball player.

And he’s standing at a bar, talking to an artist. And, because he isn’t being paid, he doesn’t play baseball anymore. And the artist is trying to explain to him why he has to have an occupation to support his profession. And that’s really where the art world is at. Most people, most artists make this work whether anybody wants it all, makes it year in and year out with little visibility, no critical attention and little financial support. Most artists, by nature, are mediocre. There are no undiscovered geniuses. Take my word. There are no undiscovered geniuses. There are many undiscovered competent artists, just as competent as the artists who are famous and we all know. There are no charlatans. If somebody wanted to be a charlatan the last thing they would do is go into art. There are many other ways. And I think the financial market is obviously a much better place to be a charlatan than being an artist.

If you’re lucky enough to find a dealer, the artist and the dealer relationship is the heart and soul of the art world. It is a marriage. Like many marriages, some don’t last forever and there may even be some cheating from time to time. But it is a marriage because this is where the rubber meets the road when it comes to art and how it is offered to the public. There are ups and downs. Things are in fashion or out, hot or not. And if you don’t understand the cyclical nature of the art world you’re in for a lot of pain. Dave Hickey said in a really wonderful article in, in Art in America this month: At one time a consensus of professional respect would carry an artist through times of no money better than money would carry an artist through times of no professional respect.

A few museum shows and a nice catalog essay during a lull meant that your prices would still be there when fashion changed and the money came back. He went on to say that works of art have no intrinsic value. All their value is extrinsic. It is invested from without and over a period of time. Damien Hirst’s jewel encrusted skull has hundreds of thousands of dollars – or it might be millions, I don’t know – of diamonds in it. It did not make that piece any more valuable than any other work of his, just because it had inherent value. I’ve got two minutes. Jesus Christ. So who are the deciders? Some are forces for good. I’m borrowing a phrase from Bush on purpose. Who are the deciders? Some of those deciders are forces for good and some are forces for evil. I'm not even gonna get into it. Oy. I’ll do this in my closing remarks. I--

Well, I’ve got two minutes. No, one more minute. No, I--

I would just repeat that the most important thing is the value that art-- art is a meritocracy. It is a meritocracy because the final arbiters of what is important are other artists. All the hype, all the spin, all the effort to construct a career out of thin air, all the efforts to manipulate the market notwithstanding, over the long haul if you don’t have the respect of other artists it will disappear and it will not stand the test of time. So if we’re looking at short term investment, perhaps it can be manipulated and perhaps it’s not always the most perfectly run organiza-- opportunity. But over the long haul it’s left up to other artists. And I think that’s what finally determines the value in art.

### Moderator
Claim: Do you want to yield the rest of your time to the evening?

### Scientific Advocate (SA)
Claim: Well, I’ve got two minutes. No, one more minute. No, I--

### Moderator
Claim: No, take it.

### Scientific Advocate (SA)
Claim: I would just repeat that the most important thing is the value that art-- art is a meritocracy. It is a meritocracy because the final arbiters of what is important are other artists. All the hype, all the spin, all the effort to construct a career out of thin air, all the efforts to manipulate the market notwithstanding, over the long haul if you don’t have the respect of other artists it will disappear and it will not stand the test of time. So if we’re looking at short term investment, perhaps it can be manipulated and perhaps it’s not always the most perfectly run organiza-- opportunity. But over the long haul it’s left up to other artists. And I think that’s what finally determines the value in art.

### Moderator
Claim: Thank you, Chuck Close. Our next debater, Michael Hue- Williams, is founder of the Albion Gallery, located in London and New York. And as we are debating here, London is snowed in. Both runways at Heathrow are shut down and somehow Michael managed to get what might have been the last plane out. He stepped off of it about three hours ago. So he obviously wanted to argue tonight. Ladies and gentlemen, Michael Hue-Williams.

### Conspiracy Advocate (CA)
Claim: Thank you. I’m going to make some points to support what Richard’s already begun on our behalf. And these will be made more in the way that a drunk might use a lamppost-- in support rather than illumination. however, an early statement from 1932, pre-regulation of the stock market, which FDR managed, importantly, to begin over here, began with the remarks that it was needed because of shocking disclosures of low standards in high places. This possibly is something that could be applied to the art market, I fear. The stock market in London has a dictum. The dictum is: Meum dictum pactum. This means, My word is my bond. And it is one of the important maxims in the art world, but unfortunately, it is not one that necessarily is worth banking upon. I’m gonna illustrate three reasons why the motion: The Art Market is Less Ethical Than the Stock Market, for me, holds water. The first is that there is no real regulation. The second, that there is no transparency in the market, and the third, that there are absolutely no barriers to entry. The first, no real regulation – let me explain by telling you a story against myself. In 1989 and 1990 – it’s a long time ago – I was in short trousers. I had a gallery in London already.

I came to New York on the day of one of the big auctions. And I made a deal with an art dealer here in New York – somebody who is extremely prominent to this day – to buy eight paintings by the German painter, George Baselitz – an artist who I still greatly admire. And I agreed to buy these for 2.4 million dollars, which at the time seemed an extraordinary amount of money to me. I think I was twenty-four years old at the time. And I left the gallery of this man I’d made the deal with. And I waited because there was one similar painting that night in auction in New York. And the painting made eight hundred thousand dollars. I went to bed that night feeling very clever. The next morning I got a telephone call from the dealer, who told me that the deal did not stand and that he was gonna walk away from it.

And of course I was outraged. But under the UCC regulations, anything that is not written on paper and is a transaction above five hundred dollars is not enforceable. Clearly here, ethics and the law were not working hand in hand. Ethically, I felt he was doing something that was appalling. Legally, he was absolutely right, he could do it. That illustrates my first point, that there is no real regulation. The second point that there is no transparency in the market has been touched upon by Richard, in his remarks about the auction houses and the creation of rings. Rings are… relatively simple to create, it needs a group of people who stand outside the framework of the auction houses, and they decide to promote an artist, it’s very easily done with a young artist, and I can think of one at the moment in the Middle East who is an interesting young painter whose work has rocketed in price, from tens of thousands of dollars to hundreds of thousands of dollars, in the space of less than two years. A group of people bought a lot of pictures, they each owned individually, group of pictures, and they started to put these pictures into auction, they then go to the auctions, they get groups of people bid them up, and thereby they feather their own nests.

And…this draws attention of the press, the press attention to the artist, and it’s a self-fulfilling prophecy that this artist starts to go up in value, and by a process of osmosis, the ring benefit from the auction house activity that they’ve begun. This is not transparent to the outside viewer, but to art world professionals, it is quite obvious when this is happening. The last point, and possibly the most important point, is that, unlike the stock market…there are no barriers to entry. To become an art dealer, you need to have a pulse. You need to be able to count… and probably you need two eyes in your head. But beyond that anybody can be and call themselves an art dealer. There was an extraordinary scenario that took place here, predominantly here in New York, with an art dealer, so-called, called Michael Cohen, some of you may know about this but I’m going to use him as an example of an extraordinary situation, where he began to trade in commodities, and in the stock market, and ran into a lot of financial trouble.

This was not his business, this was what he was making money doing on the side. But he realized that he could solve his problems, where there was an absolute call on his money at 30 days, and he had to deliver, by using other people’s paintings as collateral. Some of them, he parked even in the auction houses, his level of chutzpah has to be seen to be believed, he actually managed to sell a Titian that was on the wall of the Met. In any case, this gentleman eventually did become unseated. And he has disappeared, last sighted in Brazil. And if anybody can help us out with his whereabouts, Jerry Saltz, our resident investigative journalist would love to write a story all about it. I use him as an example, there are very clear demands placed upon people, who go into the stock market, the stock market is regulated, these individuals are fingerprinted, they are members of a licensed body of people who are allowed to trade. Their backgrounds are heavily investigated before they begin. This is not the case with the art world. And for these three reasons, there is no regulation, no transparency, and no barriers to entry. These are the reasons that I believe absolutely, that the motion, the art market is less ethical than the stock market, cannot be disputed.

### Moderator
Claim: Thank you, Michael Hue-Williams. Amy Cappellazzo is deputy chairman and international co-head of post-war and contemporary art at Christie’s, and she became famous for a quote, something she said a year or two back when describing a rather frothy art market. She said, “After you have a fourth home and a Gulfstream jet, what is there.” It has been picked up and repeated, and repeated and repeated and our next debater is Amy Cappellazzo.

### Scientific Advocate (SA)
Claim: Thank you, John. Well, this is such a juicy topic, I really don’t even know where to begin, my notes feel, you know, my head is flooding with all sorts of other ideas besides these, that I’ve put before myself on these pieces of paper today. Certainly I’d like to just say that when you’re on a panel it’s much more interesting to sit on one than sit through one, so I will, you know, work very hard to play to type and make it lively and interesting and there’ve been many swipes against auction house people tonight and as I am the auction house person on this panel, I will get to sort of support and defend the position and place of the auction house as sort an ethical player, but… In reading the proposition over and over again, “The art market is less ethical than the stock market,” of course I had to read this multiple times and I had to analyze every word.

Certainly colonizing the word “ethical” will help make you the winner tonight. And, something ethical is described as “proper conduct and good living.” An essential aspect of ethics is the concept of the life worth living, that each of us aspires to this quality of life and aspires to have the kind of life that allows us to sleep at night and lead an ethical, good life that makes it all worth living. A few things basically need to be established here. Art is not a pure commodity, it’s not an ordinary commodity. While it certainly is bought and sold and traded, the motivations for the place of art in our society, the motivations for its existence and everyone who plays within the game of the art world, are incredibly conflicting in fact.

So…my premise depends on the concept that the art market does not exist without the art world. That in fact the art world adds hugely to the conscience of the art market. What do I mean by the art world, I mean the entire museum profession, critics, curators, conservators, other sorts of people in the cultural production business, writers, graphic designers who work with artists, etcetera. Art is valuable emotionally, intellectually, historically, in a way that other commodities are not inherently. The motivations for becoming part of the art world are too multiple and varied, the rewards are too varied among the various groups, an artist becomes part of the art world for a completely different set of reasons, than a dealer does, than a critic does. So while there is—in the art world there are too many different rewards, the reward structure is fractured and varied. Whereas in the stock market, presumably there is a singular reward which is financial compensation.

Within that, there is not really an ability for ethical behavior to— it’s hard to get into ethical run-ins because everybody has a completely different system of reward and a completely different reason for existing within that. Part of what I put forth here is that art is a bit like physics, it can exist both as wave and as particle, so it is at once something that is bought, sold, traded as a commodity, or as something like a commodity, and it exists in this sort of higher place, of emotional, intellectual, historical, and cultural meaning and cultural relevance. I believe that there’s something that exists in the art world, that exists in the art market, that makes it completely different from the stock market, and that is something that I would call, pressure of a common pool, which is a sort of basic, Economics 101 theory, an idea that things that are precious in the public domain that no one exactly owns, let’s say like aquifers, groundwater, forests, fisheries, things of this kind, are in fact, there’s a kind of rule of conduct about how people engage within them which is essentially… more or less ethical. People who do not behave well within these common public treasures are in fact outliers or criminals and are really quickly rooted out, and that those of us who participate in this pressure of a common pool participate ethically and carefully. I believe works of art are something that give us tremendous pleasure. They really, you know, all the beautiful platitudes about feeding our soul and carrying us through difficult times, all of this is entirely true, particularly now, and that we all treat works of art in the same coveted fashion with care, respect, and preciousness that works of art deserve.

If you break these rules of engagement you are a criminal or an outlier. People who know art, people who collect it, artists who make it, collectors who very much covet it, really know that they are only temporary custodians of works of art, it’s kind of like being a foster parent, you don’t really own these works of art, you just take care of them for a while because they’re supposed to outlive you. And you’re supposed to pass them on to someone else. So as long as that is the ethos that surrounds a work of art, how this object is understood in the world and in the marketplace will always be different than something that trades as pure commodity. So, with the position that the art market is less ethical than the stock market, the art world is by far more ethical than the stock market. It has a conflicting set of—has a very varied and various, numerous reward system among its various participants, as opposed to the singularity of money that comes from the stock market. And the actual object traded is very different than a share of stock in all of its principles, properties, ideas, and values. And that is why I am arguing against this proposition tonight. Thank you.

### Moderator
Claim: Thank you, Amy Cappellazzo. So I just want to remind you where we are in the evening, we are now at this point halfway through our opening round. I’m John Donvan, your host and moderator, and this is Intelligence Squared US, Oxford-style debating on America’s shores. We have six panelists, three who are arguing for and three against this proposition, “The art market is less ethical than the stock market.” And now we are going to move on, our next panelist will be arguing for the motion, “The art market is less ethical than the stock market.” Adam Lindemann is one of the world’s leading collectors of contemporary art, he likes to share what he knows, he’s written essentially a buyer’s guide for collectors, and he also likes to buy what he likes. He calls himself a consumptaholic. Ladies and gentlemen, Adam Lindemann.

### Conspiracy Advocate (CA)
Claim: Thanks so much. I just wanted to remind you all that March 17th is “Blame Washington more than Wall Street.” I do blame Washington. April 21, “It’s wrong to pay for sex,” I do think it’s wrong to pay for sex. Unless you get a good deal. And May 12th, “Diplomacy with Iran is going nowhere” and it is, so, that gives you a hint of where I stand here, I’m here to basically argue the point that the art market is less ethical than the stock market, which it is.

I want to start off by reminding you all what “ethical” actually means, ‘cause I wasn’t even sure what it meant when I thought about it. “Ethical” means “being in accordance with the rules or standards for right conduct,” ethics means this is correct and right conduct and practice. The standards of a profession, and this is the standards of the profession of the art dealer we’re talking about. An example here is, it was not considered ethical for physicians to advertise. It is not ethical for physicians to advertise, I thought well why can’t physicians advertise if they’re good. And the reason is physicians are there to help people. Physicians are supposed to help you with your health. And therefore it’s not really a business. Just like the art market is not really a business but then how can it be a market and not be a business? We get into this whole…ethical question, about art and the market, these two things are really at loggerheads in a way. And I thought, do art dealers advertise. Because it would not be appropriate for physicians to advertise. Do art dealers advertise, and I thought, every art dealer I know, advertised heavily.

As a matter of fact, auction houses advertise, everyone advertises, and therefore, it immediately made me feel well perhaps, advertising is a sign that this is a business and not simply about…ethics and proper conduct. Now, in terms of the stock market, the SEC regulates public companies. And the reason for that, is really to protect the public. If it weren’t for protecting the public, in fact the government would let everyone do whatever they wanted to do with public companies, private companies and whatnot. We have many, many rules and regulations for the financial markets and of course more rules to break, is what many people will think, or more rules to skirt. But the reality is that those rules are there. Now on the other hand, we have works of art, which are inherently unique.

Each work of art is quite different. Even if there is a Degas which sold today for $19 million, that Degas is one of I believe 20 that he made and that particular Degas was cast after his death, that’s what we call a posthumous cast, so, in my view that Degas is quite different from a cast that Degas made during his lifetime. How could we regulate Degas’s Danseuse, even if two were exactly the same. The skirt is going to be slightly different, the patina was slightly different. One of them got dropped on the floor and restored, the other one didn’t. So therefore, since art is inherently, each work of art is inherently unique, it’s extremely difficult to regulate. So I was trying to imagine how we would regulate the art world in order to make it truly ethical. And I was thinking we would have to create something called the AEC, as opposed to the SEC we would have the AEC which is the Art Exchange Commission.

This would be a counterpart to the SEC, perhaps a subdivision, in which case we could go after Madoff and we could also go after art dealers who have sold things that are not correct. I think that that whole idea of regulating the art world is in and of itself impossible. And so then I thought, well, what are these standards for proper conduct. How can we be proper, how can we be ethical, in the art market. And I quickly thought of six fast reasons which make it difficult to ensure that every trade in the art market will be ethical. The…of course, many of the dealers and many of the people at the auction houses and many of the artists are my dear friends, and I don’t mean to say that any of them are unethical. My point is rather that the art market itself is ripe for unethical behavior.

That doesn’t mean that the participants in it are unethical. My personal feeling is that the people in the art world that I know are the most wonderful and ethical people I know in any environment, in any business. But that being said, the entire market is ripe for anything to happen. For example. Stocks, when stocks trade, you pay a commission. You can pay between one and 15 cents, you like the guy, you pay 15 cents, he’s given you good information, you can pay 50 cents, you can give him a dollar. You can trade with Charles Schwab. You—it’s a penny a share. When you’re buying a work of art, you have no idea what that real commission is. The art market is all fair game, it’s caveat emptor. Unless you’re going in with a dealer that you know, or a work of art that you know or you have a consultant who you trust, you have no idea what the commission is.

You don’t know if it’s 10 percent, 15 percent, yes, common practice is 10 percent. Common practice in the art world, 10 percent commission. My question to you is, 10 percent of what. The next point which I think is pretty much going to blow this up, is the insider trading. Now, you know that insider trading is wrong when you’re trading public securities. Matter of fact insider training is wrong when you’re trading bonds, when you’re trading stocks. Now, you know, it’s illegal on Wall Street and the reality is in the art market, we live on inside information. I mean the whole art market is based on inside information, I mean that’s the whole idea of art. You know, there are the insiders and then there are the outsiders. Yes, there’s the concept that art is for everyone and art will transcend, and we all want that feeling, I mean, certainly we want the art that’s going to speak to everyone.

However, the reality is, when you’re actually buying art, when you’re a collector, when you’re reaching into your pocket and you need to spend money, you want to know everything, at least I do. It’s not only about love, of course I love, but, I can’t buy everything in the world. So I need to choose what I’m gonna do with my resources and I wanna have all that information, especially the inside information that I know that dealer has. Another type of inside information would be if a young artist is going to a big gallery. This is a critical thing to know. The other thing is opportunities for currency exchanges. Geographic. A painting in one country is worth less than a painting in another country. Does that make dealers unethical? Absolutely not. But the whole system is ripe for anything to happen, and that’s the beauty of art, and the art market.

### Moderator
Claim: Thank you, Adam Lindemann. Well, we felt we needed an art critic in the debate tonight, and we are fortunate to have Jerry Saltz who in ArtReview’s 2008 “Power 100” list was ranked number 79… And his wife, Roberta Smith of the New York Times, the art critic, was ranked number 71. Jerry has said “New York City is not the center of the art world anymore, but it is the trading floor.” Do you recall that?

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: I hope you stand by it as you argue against the motion, ladies and gentlemen, Jerry Saltz.

### Scientific Advocate (SA)
Claim: Thank you. Thank you. First I wanna say, art is not optional. It’s always been here, since the beginning, it has never gone away, it’s not going away. Okay? It isn’t just a decorative hedge that grows in front of a market, or in front of industry or philosophy. Art is a necessity, okay? It changes the world, it won’t reduce the incidence of AIDS in sub-Saharan Africa but it does change the world incrementally, and/or by osmosis, okay? So when you keep talking about the market I want to say to my friends on the other side…that almost there’s a self-hating thing to your argument to me. Because, you are representatives of the market. And I have to remind you first of all, 1 percent of 1 percent of 1 percent of 1 percent of artists actually make money. And even they barely do and usually only for a very short time. So while—and look at, their clothes are pretty good. Uh… And I’m not against--Mr. Feigen just sold a painting for $12 million, that’s great, yesterday, and I think you deserve that. There’s nothing wrong with that. But when we’re standing here talking about secrecy and manipulation instead of sorcery or prestidigitation or you’re talking about, you’re upset because we’re not regulated. I don’t want us ever to be regulated. This is the art world…people. Am I yelling? This— If this were the industry, that side would be right. But this is the art world, and a world is a place that has a vision, that has problems. The market is a place obviously that people exhibit junkie-like behavior. Millionaires try to enter art history by spending a lot of money. Sometimes the market’s like a friendly Labrador that kind of slobbers all over you and it’s very annoying, but you can’t somehow ignore it. I’m not denying, that the market is a combination of hundreds of things, be it greed, luck, research, a great eye, and I do know one great art dealer in Germany, Johann Koenig, with only one eye, and he can only see about 10 percent with that eye, and he is one of the best dealers in the world. Did I just argue against our side? This is the art world. It isn’t the art industry. They are appealing—and I like them, you know, I see them everywhere—to the cynical side of your nature. I’m being honest with you. The part that goes yeah, it’s all a dirty deal. And everybody’s bad, but let me tell you something. Everybody isn’t bad, most people, and certainly…they’re not, but that’s a different— Art dealers, a lot of them are missing the same chromosome. You know? And it’s very annoying, but I—they create worlds…and they pay the bills, they deal with artists, they deal with critics, they deal with collectors. They deal with plumbers, they do a lot. And if they don’t sell 10 shows in a row, they will close. There shouldn’t be regulation, there shouldn’t— And you complain because anyone can enter? I’m gonna be honest, I have no degrees at all.

I am so lucky to be here, and I think about it all day every day. That I’m—you know how I got in the art world, I went like this. I’m in the art world. And they said, what are you, and I went, uh…I’ll be a critic. And that’s how I did what I’m doing. We all are making this up out of ourselves, just like you. To be perfectly honest, we’re all learning on the job. Everybody’s learning on the job, all the time, rules, you want to start the AEC, no, no, no. I mean no offense, I love these people but I hate these ideas. Sorry. We’re not talking about ethics, the art world is ethical, it’s not ethical, it’s this, it’s that, it doesn’t compare, it’s not a $15 billion bubble anywhere, for God’s sake, it’s not nuclear, secrets that are being leaked.

Yes, these guys do know how the secrets are done, and I love that they do, and I don’t even hate them for it, I think, fine, that’s part of it, that’s part of their game. But we’re not talking about ethics, we’re talking about—aesthetics. Aesthetics is the type of thinking and judgment that we use in the art world, and yes. Damien Hirst’s skull cost $100 million, it was very publicly, that he was one of the owners of it. Fine. Whatever. But there’s also the lifestyles of the poor and famous. Vito Acconci right now is standing around going, uh, I still have no money. You know. Adrian Piper, I’m naming names you might not know. The point I guess I’m trying to make, is the art world will work the way it works, it’s time to rethink it. This is true. Because, a lot of the ideas they’re talking about, and I don’t say this about them, but seem very, very yesterday. And a time long, long ago, and we were very lucky to have this very temporary bubble, where 1 percent of blah-blah-blah made money and that’s great.

I want more artists to make more money, so they don’t have to have dark nights of the soul at their jobs for 40 hours. Now they are. And so are you, and so are they, we’re gonna have to worry a little bit more. But…I think you just have to let the art world be what it is. The rethinking of it has to be look at the huge white cubes that we now have. Look, that they may not be enhancing the journeys to art, but may have become content in themselves. The same way that the talk about the market, hollows out art. It takes your eyes off the prize, the way Amy and Chuck were talking about, and you’re stuck talking about a red herring, something that to be perfectly honest, not one person this room, not them… got into the art world to do. Each one of them is here because they love art. So, peace and love.

## Round 2

### Moderator
Claim: Thank you, thank you, Jerry Saltz. That concludes the opening statements for our debate, can we have a round of applause for all of our panelists. When you all arrived for the debate we asked you to vote your opinion on our motion, and I’m gonna share the results with you now, to restate our motion, it is, “The art market is less ethical than the stock market.” You all voted before the debate and the results are very evenly split. 32 percent agree with the motion, 30 percent disagree, and 38 percent are undecided.

### Scientific Advocate (SA)
Claim: “4” means what?

### Moderator
Claim: “4” means I came in late—

### Scientific Advocate (SA)
Claim: those guys doing, we’re against the proposition—

### Moderator
Claim: Okay.

### Moderator
Claim: This is the “for” side—

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: —and that’s the “against” side—

### Moderator
Claim: Okay.

### Moderator
Claim: And how—

### Scientific Advocate (SA)
Claim: swing voters—

### Moderator
Claim: The way that we will judge the winner at the end of the evening is we look at, whose numbers move by a larger percentage so the fact that it’s quite evenly split makes this a pretty good horserace at this point but— At the end of the evening we wanna see who actually has a larger number or who has dropped numbers. Now we’re gonna move into the second section of the evening. And that’s where the debaters can talk directly to one another. You’ll be involved as audience members, I wanna remind all of you that the tone of this part of the debate can be quite informal, you don’t need me to be a traffic cop, I will only get involved and pull you back if there’s a terrible pile-on…and everyone talking at once, but feel free to interrupt each other, to support each other, it’s your debate, this part of the evening. But I wanna start it off by asking Michael Hue-Williams who heard the other side essentially argue that art is not like other stuff that can be regulated, it’s closer to love and you can’t regulate love or romance. What if you take the basic rule…buyer beware, whatever happened to that rule and why does that simply not apply. Why doesn’t that take care of all problems.

### Conspiracy Advocate (CA)
Claim: That’s a good question. I’m not sure I know the answer to that. So I’m gonna…say something completely different, I’m gonna say—

### Moderator
Claim: You could be in politics with that.

### Conspiracy Advocate (CA)
Claim: I’m— Yeah, I’m not gonna answer the question at all, I’m gonna say that actually…I wanted to agree with Jerry. And I wanted to say that, he’s absolutely right, we’re all in this for the same reason. But actually tonight, we’re here to debate a very specific motion which has nothing to do with the fact … the fact that—

### Scientific Advocate (SA)
Claim: Oh.

### Conspiracy Advocate (CA)
Claim: —that we are all involved with art because we love it and because it’s our lives and because we are not able to do anything else speaking from my own point of view. I had to invent a job for myself ‘cause nobody else would have me. But actually we’re here because we love art, because it drives us, because it thrills us and because, the exciting thing about the art world and the people that make it is that it is a… I always think of it as a running race, where the great artists pass the baton from one to the other, and the really great artists get to carry it forward. And for me seeing those artists and—

### Scientific Advocate (SA)
Claim: That’s very

### Conspiracy Advocate (CA)
Claim: —trying to help them—

### Scientific Advocate (SA)
Claim: fire. I’d like to—

### Conspiracy Advocate (CA)
Claim: Trying to help them go forward is a byproduct of what we do, and as a gallery, yes, we sell the work but also we sometimes have to help them create the work.

### Scientific Advocate (SA)
Claim: But—

### Conspiracy Advocate (CA)
Claim: And by the way, Jerry, in case you didn’t realize, I look after Vito Acconci.

### Scientific Advocate (SA)
Claim: And he’s a wonderful artist—

### Scientific Advocate (SA)
Claim: But I’d just like to say—

### Conspiracy Advocate (CA)
Claim: He’s doing wonderful things.

### Scientific Advocate (SA)
Claim: Michael, you sort of made a case in favor of regulation being something that, you know, normatively affects, that inspires ethical behavior, I mean I would like to know… I do not think regulation ensures ethical behavior at all, certainly we’ve seen in the stock market that lots of regulation certainly doesn’t ensure ethical behavior, we can—violations are tremendous, in fact, this idea of the pressure of a common pool or the idea that everybody who’s part of the art world… even part of the art market signs up for the full ethos here that you love, covet and take care of the art and in fact, if people in the art—you know, even the most highly compensated people in the art world, could make more if they chose a different profession, we all know that, so the reward system is obviously other as we’ve well-established here—

### Conspiracy Advocate (CA)
Claim: I think that’s two really important points, first of all we’re not actually talking about money here. We’re talking about ethics. And, we’re talking about whether a market is ethical. Not about whether people make lots of money or don’t make lots of money, we’re just talking about ethics.

### Scientific Advocate (SA)
Claim: But does—

### Scientific Advocate (SA)
Claim: Does regulation—

### Conspiracy Advocate (CA)
Claim: Whether one market or another market is ethic—

### Scientific Advocate (SA)
Claim: —ensure ethical behavior.

### Conspiracy Advocate (CA)
Claim: And the other thing I think is really important to understand is that, I’m not asking for regulation in the market, I know that that won’t happen, and I, yes, okay, mea culpa, I am a cannibal, I am eating my own as it were, I’m Jonathan Swift’s modest proposal, I am suggesting that we eat our own children, through the market. But actually, I am a great devotee of the market, I think that its inconsistencies, like Adam, are one of the great attractions of the market. And the fact that nothing is ever the same yesterday as it will be tomorrow is one of the extraordinary things about the art world.

### Scientific Advocate (SA)
Claim: But to—

### Moderator
Claim: Jerry Saltz—

### Scientific Advocate (SA)
Claim: —say that the art market is inconsistent, I think every—that’s built into it. But inconsistent doesn’t ipso facto mean it’s unethical, from here down to there. Of course there are going to be instances of people trying to manipulate any market to try to make money. You’re saying that it is an unethical thing, that is—

### Conspiracy Advocate (CA)
Claim: No we’re not—

### Scientific Advocate (SA)
Claim: —your argument—

### Conspiracy Advocate (CA)
Claim: —we’re not—Jerry, sorry, what we’re saying here, is that—and if you look at the debate motion again, we are saying that it is more unethical than the stock market, that’s what we’re debating—

### Scientific Advocate (SA)
Claim: And it’s done more damage, is what you’re saying than the stock market—

### Conspiracy Advocate (CA)
Claim: I’m not debating whether it’s done damage or not, I am simply debating the point, that—

### Scientific Advocate (SA)
Claim: But then why be in it.

### Conspiracy Advocate (CA)
Claim: I—

### Conspiracy Advocate (CA)
Claim: Because, because—

### Moderator
Claim: Richard Feigen. Richard Feigen, please—

### Conspiracy Advocate (CA)
Claim: Why be in it— In all deference to Jerry, the subject here is not the art world. Which I happen not to particularly like because people make a—

### Scientific Advocate (SA)
Claim: Why.

### Conspiracy Advocate (CA)
Claim: Why not—

### Scientific Advocate (SA)
Claim: Why don’t you like the art world—

### Conspiracy Advocate (CA)
Claim: —because people run around using it like they use fancy Bentleys and things like that, I don’t—

### Scientific Advocate (SA)
Claim: Well, you drive that, they don’t drive it out there, I’m telling you—

### Conspiracy Advocate (CA)
Claim: Look, we’re talking about a market. A market is a financial vehicle. In all deference to Chuck, I couldn’t agree more. But the subject here is not art. There is no—

### Scientific Advocate (SA)
Claim: Yes it is—

### Conspiracy Advocate (CA)
Claim: —more passion—

### Scientific Advocate (SA)
Claim: But the art market contains—

### Conspiracy Advocate (CA)
Claim: No. There is—

### Scientific Advocate (SA)
Claim: —many externalities—

### Conspiracy Advocate (CA)
Claim: There is more passionate—

### Scientific Advocate (SA)
Claim: Many externalities—

### Conspiracy Advocate (CA)
Claim: —there’s no one more passionate about art, thank you very much, than myself. And I’d much rather buy it—

### Scientific Advocate (SA)
Claim: Prove it.

### Conspiracy Advocate (CA)
Claim: —than sell it. Prove it?

### Scientific Advocate (SA)
Claim: Richard—

### Conspiracy Advocate (CA)
Claim: Ah, come on.

### Scientific Advocate (SA)
Claim: You’re—

### Moderator
Claim: Chuck Close—

### Conspiracy Advocate (CA)
Claim: Listen, everybody knows I’d rather be a collector than a dealer anyway, but the point is, that we’re talking about the art market. And the market, and I’m saying, that art has become a financial market. I don’t like it. It makes my life more difficult—

### Scientific Advocate (SA)
Claim: But it’s been a financial market since the Renaissance.

### Moderator
Claim: Let’s bring in Chuck Close—

### Scientific Advocate (SA)
Claim: Richard…

### Moderator
Claim: Chuck Close—

### Scientific Advocate (SA)
Claim: Yeah, you’re a second, primarily a second-market dealer, which means that you try to buy low and sell high, or like a real estate agent, you take things on commission and you hope to sell ‘em and collect a commission on that sale. That’s really not some— that’s to me not a very important relationship to the art world. Certainly not to— Not to artists, I mean you’re— you might be--it’s for dead artists or estates, but I’d like to talk about what I think is a real ethical bond between the primary art dealer, who represents artists, who believe in that artist, who take a risk on that artist, and put that work out there, and make that work available. I was a kid from a mill town in the state of Washington, I couldn’t believe when I got to New York and there was this incredible smorgasbord of art for me to look at, that was given to me free of charge by galleries. I could go in, I could look at this work, I was never gonna buy this stuff. This is a real service that the dealer provides. And they make that artist’s work available to collectors, and there are--at first I didn’t wanna meet a collector of mine ‘cause what if he or she was a jerk, and then I’d say oh my God, that jerk owns my work. So I tried not to meet them. And then I found out that really truly wonderful people out there buy art. And they give it to museums. And they make it available to other people, if it weren’t for really philanthropic people who are a real asset to the art world, and this commerce that goes back and forth, it—there are people who are speculators. I mean I was first an advisor to Charles Saatchi when he was first buying art, I told him which pieces by which artists he oughta buy. And he bought one of my pieces. I knew right away never to sell another work of art to this guy. I knew he was a speculator, he was gonna make—he liked to make and destroy careers. And—

### Moderator
Claim: Chuck, are you switching to the other side of the argument—

### Scientific Advocate (SA)
Claim: No, I’m—no. I’m not, I’m talking about the primary role that a gallery plays in an artist’s career, putting that work forward, and the responsibility, I hate to see them slammed. I hate to see them talked about as if they were selling hog futures. It’s another kind of business. And we, those of us who make art, we appreciate the truly wonderful collectors who are out there. Where would museums be without collectors giving their work to these museums. This is a wonderful part of how the art world works.

### Conspiracy Advocate (CA)
Claim: Chuck, your art—

### Scientific Advocate (SA)
Claim: It’s not

### Scientific Advocate (SA)
Claim: Even the trading’s—

### Moderator
Claim: Let me just, pause—

### Conspiracy Advocate (CA)
Claim: —you’re on a waiting list—

### Moderator
Claim: Let me pause the debate for a minute, I just wanna start the process of taking audience questions and then you can resume that moment. I just wanna see if any hands are up, because we bring up the lights. And also I wanna remind you that we’re delighted to hear from you—I feel you’re sitting on your hands a little bit tonight, feel free to speak out. So, we have a question down here on the front row, and if we move the mic down we’ll come to you in just a second, sir, as we continue the conversation. Richard Feigen. You were about to speak.

### Conspiracy Advocate (CA)
Claim: Well, Chuck, you are one of those important contemporary artists whose work sells in the seven figures and there’s a waiting list for it. Imagine, some kid who can’t get a gallery, where the rents are so high that the gallery can’t even show the work. I tried, I represented artists in the primary market—

### Scientific Advocate (SA)
Claim: Believe me, I know more of them than—

### Conspiracy Advocate (CA)
Claim: Let—

### Scientific Advocate (SA)
Claim: —you know.

### Conspiracy Advocate (CA)
Claim: Chuck, let me tell you, I tried it, and I’m no good at promotion. The touting, and all that publicity, and the politics, that go into making an artist successful. So I ran around feeling responsible, and guilty. All right, because I couldn’t do it, I don’t know how to do it. There—

### Scientific Advocate (SA)
Claim: That’s not why you didn’t do it.

### Moderator
Claim: Jerry Saltz—

### Scientific Advocate (SA)
Claim: The reason you didn’t do it is because you had a gift for what you are doing, you’re not involved with the contemporary art world because it wasn’t the first language that you really were made to speak—

### Conspiracy Advocate (CA)
Claim: Jerry, I showed contemporary artists in Chicago when—

### Scientific Advocate (SA)
Claim: I worked for you, when I was, 21.

### Conspiracy Advocate (CA)
Claim: I’m telling you—

### Scientific Advocate (SA)
Claim: On Michigan Avenue, I was there.

### Conspiracy Advocate (CA)
Claim: Well, right, look—

### Scientific Advocate (SA)
Claim: 620 Michigan—

### Conspiracy Advocate (CA)
Claim: Right now it’s all about— It’s the Charles Saatchis feeding into—

### Scientific Advocate (SA)
Claim: No, it isn’t—

### Scientific Advocate (SA)
Claim: —only about that—

### Conspiracy Advocate (CA)
Claim: —into the auction houses—

### Scientific Advocate (SA)
Claim: You’re only—

### Conspiracy Advocate (CA)
Claim: The whole thing is about touting—

### Scientific Advocate (SA)
Claim: —looking at one tiny, tiny, tiny sliver of it, and saying that’s the whole thing, from top to bottom, that it’s the core, so it’s become that for you guys.

### Conspiracy Advocate (CA)
Claim: I didn’t say top to bottom—

### Scientific Advocate (SA)
Claim: Even in the auction house it’s not that way, I mean even sitting in it it’s not that way. We—

### Conspiracy Advocate (CA)
Claim: Auction houses won’t take anything for sale unless it costs a certain huge sum of money, they won’t even accept in an auction.

### Moderator
Claim: Adam, Adam Lindemann, you said, Adam, that—

### Conspiracy Advocate (CA)
Claim: I don’t think that’s true—

### Scientific Advocate (SA)
Claim: We sell things all day for—

### Moderator
Claim: Adam—

### Scientific Advocate (SA)
Claim: —a thousand dollars—

### Moderator
Claim: Adam Lindemann argued that the market is ripe for unethical behavior, but you didn’t really gauge whether you think there is a lot of unethical behavior going on, you didn’t say one way or the other. And it seems to me relevant to this topic whether we’re talking about a few bad apples or are we talking about large-scale unethical behavior, and I wanna ask your side if it’s a few bad apples then we’re not talking about a huge problem. But is it bigger than that.

### Conspiracy Advocate (CA)
Claim: It seems to me that, the question becomes, you know, is the proposition correct, in a systemic definition, or is it correct in practice. Meaning, is the system that is the art market, the unregulated art market inherently more open to unethical behavior—

### Moderator
Claim: And you argued that it was—

### Conspiracy Advocate (CA)
Claim: —than a regulated market. Now your question is, in practice—

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: —is the art market actually unethical. And I have tremendous respect for the other side here. Speaking of ethics I think that had I chosen the other side, I wouldn’t have made the panel because they had more people on that side than this one. So I sensed that there was a spot for me over here. And I’m arguing this side… Which has a lot to do about art and the art market, you know—

### Conspiracy Advocate (CA)
Claim: —you have to feel your way through. That being said, I—the people that I deal with are the people that I think are ethical, I choose people that I have a relationship with…that are either my friends or I have a good feeling about them, and do things happen, of course, everything happens—

### Moderator
Claim: Right—

### Conspiracy Advocate (CA)
Claim: —in this world anything can happen. That being said, our side has definitely--you know, we’re going downhill here in the sense that we don’t have any rules in the art market… whereas the public is protected by the SEC as we were saying, perhaps imperfectly so but that’s the effort, the public can enjoy the art world that Jerry Saltz has laid out for us and certainly should support the art world that Chuck Close has laid out for us and, and I do feel very strongly that way. Nonetheless, there are no rules, there’s no inherent value, I mean, the other side literally said, let me see here. Artists… where is it, “There is no intrinsic value, only extrinsic value,” that’s Chuck Close’s words so, if there is no intrinsic value, then…it’s ripe for unethical behavior.

### Moderator
Claim: Let me turn to your teammate, Michael Hue-Williams, and Michael, if you can approach your microphone a little bit, I got a signal that the radio’s having a little bit of difficulty because of the distance. Are there a lot of unethical players in the art market or only a few.

### Conspiracy Advocate (CA)
Claim: I’m—

### Moderator
Claim: Or do you not know because nobody knows.

### Conspiracy Advocate (CA)
Claim: I’m sure there may be but I’m sure I don’t know them. I think your question is an interesting one but it actually has no bearing on the motion that we’re discussing here. Because this motion is a purely hypothetical motion, so, I’m gonna bring this back, and I’m going to agree with—

### Moderator
Claim: You really don’t like to answer direct questions, do you.

### Conspiracy Advocate (CA)
Claim: Now I’m completely lost. I think that the art market is open for manipulation because it’s unregulated, I think it is unregulated because, historically, it’s found its own way of operating because it’s just simply not possible to regulate this market, and it would be a ghastly thing, if it ever could be regulated. A lot of the excitement and fun would go out of it. So to answer your question, do I know a lot of bad apples in the art market, no. But the art market, when we have instances of things going wrong and manipulations and unethical behavior, attracts a huge amount of attention, a disproportionate amount of attention because the art market is very exciting, it is very well-reported, it always has been, because, it is also the cradle of— It’s an expression of humanity, it’s an expression of something that is above the humdrum essence of daily life, it’s something that when it is truly great, it takes us into another realm, into a realm that hopefully, will have cultural credibility for years and decades and centuries to come.

### Moderator
Claim: Let’s take a question from the front row, sir.

### Moderator
Claim: Well, we’ve heard tonight that the artist and the primary dealer are the foundation of the art market along with the collector. But we haven’t…and we’ve heard how, secondary dealers and groups of collectors can manipulate the market. But I’m wondering how does the art critic fit into this. Do the Clement Greenburgs of the world manipulate the art market, the Jerry Saltzes of the world? Where does the critic, critic fit.

### Scientific Advocate (SA)
Claim: That’s a really good question, I think we’re really, once upon a time the Clement Greenburgs of the art world, did, and they were able to manipulate taste. And therefore the market. That time luckily is long, long gone. And that now, I can like this, another critic can like that, Michael Wilson can like this, I’m looking at art critics in the room— And it really, we don’t have that kind of sway. I can say that Damien Hirst’s recent paintings were absolutely generic, fortieth-generation photorealist paintings… which I did write. And you know how many he sold? All of them. I’ve done that a lot, and just to show you the other side, oh, well, he’s just saying, he’s being… I’ve written that certain young artists are very, very good. And it doesn’t do, it won’t do anything. It has to be there. I don’t know what it is. You know, if you know, let me know.

### Moderator
Claim: Okay, we’re taking questions from the audience. I’m John Donvan.

### Conspiracy Advocate (CA)
Claim: But can I go another direction with that?

### Moderator
Claim: All right, let me, I just need to do this little piece of radio and then I’ll come right to you, Michael. I’m John Donvan, your host and moderator, and this is Intelligence Squared U.S., Oxford-style debating. We have six panelists, three for and three against this proposition: The Art Market is Less Ethical Than the Stock Market. We’re returning to our debate with Michael Hue- Williams.

### Conspiracy Advocate (CA)
Claim: I just wanted to take you in a slightly different direction. If you go back nearly a hundred years and you think of, not an art critic but a very influential art historian-- Bernard Berenson, who was in cahoots with Duveen – here you have an incredibly powerful manipulation which subsequently many other art historians have found to be entirely unethical and which museologists and museum directors have had to unravel as a result of the collusion between Joseph Duveen and Bernard Berenson. So, I'm just pointing that out as a, a fascinating manipulation of the market from an art historical point of view.

### Moderator
Claim: Take a question in the back. And I just want to bring a microphone down to the front to be ready. Good.

### Moderator
Claim: I’d like to address the question to the three people on the right side – that is, against the motion. Mr. Feigen and Mr. Hue- Williams made a number of quite specific assertions about the way auctions are manipulated and conducted and the way auction houses behave. And none of the three of you responded directly to those assertions. Could I ask you to do so?

### Scientific Advocate (SA)
Claim: I suppose I should take that one first, as the auction house person on this panel.

### Moderator
Claim: Amy Cappellazzo.

### Scientific Advocate (SA)
Claim: First I would like to say, the only area of the art world that is regulated is the auction business, funny enough. So the assertion on this side that the auction business that those – even Mr. Rosenkranz in his comments in the beginning brought up the auction houses as somehow being involved in something not entirely transparent or understandable. The truth is, it’s the only area that’s regulated and in fact, the entire market is Byzantine. And the only little glimmer of transparency comes when you watch a live auction and watch something trade in real time. So you can sort of understand the depth of market, how many people might be bidding. You might not know who is bidding or what exactly is going on but you might count those one, two, three, four telephones on that or what’s going on.

I mean, certainly I don’t think everything you’re hearing on this panel, while they’re saying part of what makes the art market susceptible to corrupt, to unethical behavior is the fact that it’s unregulated, nobody on this panel would cry for regulation. That would just be a-- it’s too small a market to care, in most ca-- I think that’s really why we’re not regulated. But also just from a sort of a New York would they, Christie’s would simply transfer me to London or Paris – cities that would make sure there was no regulation and I would be relocated over there and New York would have no real trading floor by which to operate that way.

### Conspiracy Advocate (CA)
Claim: Wasn’t that the claim when the question – probably before Amy, before you were born. But I remember back in the –

### Moderator
Claim: Richard Feigen.

### Conspiracy Advocate (CA)
Claim: ...was it the Sixties or Seventies?-- when the issue was brought up about chandelier bidding.

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: Okay? And they threatened, the auction houses threatened to leave New York City if they passed any regulation against this phantom bidding, which is designed to make people think there’s a competitor when there isn’t one.

### Scientific Advocate (SA)
Claim: Just so you know, for the purpose of the audience, I will explain what chandelier bidding is, which is the auctioneer is allowed to bid on behalf of the seller up to the reserve price. So the point of an auction is that sort of canter and lively chatter that goes on where he goes, One hundred, one hundred fifty, two hundred, two hundred and fifty. And you have to get a little momentum going. You can’t say, We’re opening the bidding at six hundred. Anyone? No, no bid? Boom, it’s over. So the auctioneer is allowed to bid on behalf of the seller and take bids, whether they exist or not, until they get close to the reserved price. That’s part of the dance of the auction, part of the momentum, part of the theatre that goes into it.

### Conspiracy Advocate (CA)
Claim: That’s what I talking about, that it was theatre.

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: And what I said, If I want theatre I’ll go down either to off- Broadway or Broadway.

### Scientific Advocate (SA)
Claim: Right, you’ll go to Broadway and you’ll have a little theatre. I get it, right. Exactly. Beautiful. You’ll have a little theatre that way. You know, the—

### Conspiracy Advocate (CA)
Claim: But what--

### Scientific Advocate (SA)
Claim: The auction is an ancient form. It’s not something we invented in this format. It’s been around for thousands of years and--

### Conspiracy Advocate (CA)
Claim: ...I don’t think that the chandelier bidding existed in the early years, when I started out. All I know is what--

### Scientific Advocate (SA)
Claim: They also didn’t print estimates and it was entirely dealers in the room. So--

### Conspiracy Advocate (CA)
Claim: But, Amy, when a new buyer comes along and he doesn’t have the knowledge of the market or of values, he goes to auction and why? Because it gives him a measure of value. Now, he goes in there and he bids. If he thought that his bid could not get the object because the reserve is higher and the bidding was fake, he wouldn’t bid. But they--

### Scientific Advocate (SA)
Claim: But what’s a--

### Conspiracy Advocate (CA)
Claim: But they make him think, because they say, Oh, there’s a bid over there, there’s a bid over there, there’s a bid on the telephone.

### Scientific Advocate (SA)
Claim: Look--

### Conspiracy Advocate (CA)
Claim: All this is your drama. All this is your theatre. But the fact is, it is meant to deceive that buyer into thinking he has a competitor when he really doesn’t. And so--

### Scientific Advocate (SA)
Claim: Look--

### Conspiracy Advocate (CA)
Claim: ...if all –

### Scientific Advocate (SA)
Claim: The rules –

### Conspiracy Advocate (CA)
Claim: What?

### Scientific Advocate (SA)
Claim: Listen, I’m not sure I can take on auction as a format. It’s an ancient method of selling and it’s really – You know, I’m not sure someone walks into Feigen Gallery and has a fabulous experience of transparency when they’re told what the price is on something. Or, in the case of auction there’s a printed estimate. There’s sort of a lively public discussion about why that might be the estimate. There’s a lot of people that novice collector can go ask and find out why the estimate is this. There’s all sorts of databases they can search. There’s a lot of self-education someone can do on their own behalf.

### Conspiracy Advocate (CA)
Claim: Are you telling me that he shouldn’t bid until he gets up to the low end of the estimate?

### Scientific Advocate (SA)
Claim: I’m telling, I would tell him all the time what the strategy is. The auctioneer can take bids to get the sort of rhythm going until he hits the reserve price.

### Moderator
Claim: Chuck Close.

### Scientific Advocate (SA)
Claim: The reserve price can be at the low estimate or lower.

### Moderator
Claim: Chuck Close.

### Scientific Advocate (SA)
Claim: If you want it, be ready.

### Scientific Advocate (SA)
Claim: My prob...anyone that knows me knows I’m not a big fan of auction houses. I’m sorry, Amy. But not for these reasons and not for the reasons that are part of that kind of arcane business, practice that I don’t think very many of us know or care about. What bothers me is that all an auction price means is that there were two people there that night who thought that that’s what it was worth. And that’s what’s destructive in the art world, because a dealer will look at the artist’s career and know that he or she cannot ask the most they can possibly ask for that painting that day because it’s gonna screw up that artist’s career for years to come. You don’t--

### Scientific Advocate (SA)
Claim: Look, a work of art is only worth what someone can ask for it until it resells. Then you know what it’s really worth.

### Scientific Advocate (SA)
Claim: No, you don’t know what it’s really worth. You know that two--

### Scientific Advocate (SA)
Claim: From a financial standpoint, from a modern kind of standpoint –

### Scientific Advocate (SA)
Claim: You know that two people that night thought that that was what it was worth.

### Scientific Advocate (SA)
Claim: Look, these are thinly traded markets. But so are the markets for commercial real estate, nuclear reactors, rocket ships.

### Scientific Advocate (SA)
Claim: A dealer will not, a dealer will not put a work out--

### Scientific Advocate (SA)
Claim: These are also thinly traded artists.

### Moderator
Claim: We’re going to go to another question from the audience. Sir.

### Moderator
Claim: Thank you.

### Moderator
Claim: And remember to hold that mic pretty close. That’s good.

### Moderator
Claim: Thank you very much. To return to the question itself, it seems self-evident that because of the absence or the limited amount of regulation that the potential as opposed to the practice in the art market is far greater for unethical behavior, as Adam Lindemann was pointing out. So I think that the answer hinges more on what sorts of people are drawn into the art market as opposed to the stock market. And Jerry Saltz said something very interesting earlier about how he thought that the people in the market might be missing a chromosome, the same chromosome. Uh--

### Scientific Advocate (SA)
Claim: Art dealer.

### Moderator
Claim: Art dealers.

### Scientific Advocate (SA)
Claim: Art dealers, I thought, were all missing the same chromosome.

### Moderator
Claim: Okay, now, I don’t know. Is that the same chromosome that is missing in the stock market, of people involved in the stock-

### Moderator
Claim: No. Can I take that as your question? It’s a good one.

### Moderator
Claim: Yeah.

### Moderator
Claim: Well, we see your point. So do you want to take that, Jerry?

### Scientific Advocate (SA)
Claim: Very quickly. That’s Jason Kaufman, a very good writer. I’m going to say that I don’t...Look, of course, there’s unethical behavior in the art market. I want to go back to this question. I would never say there isn’t. I mean, I’m sure people want to make money. But if, just because there is unethical behavior, I ask you, is it behavior less ethical than the stock market? I’m, again, asking for your better angels, to understand that of course this exists. So the second you feel like, Oh God, yeah, there’re people manipulating the prices-- well, that’s true. I don’t think our side is arguing against that idea. But we’re saying that’s not what it is. That does not become the definition of it and make it worse than the worst thing that’s happened in the United States in forty-five years, for God’s sake. If you really want to make that comparison, whoa, you really hate the art world.

### Scientific Advocate (SA)
Claim: Right.

### Scientific Advocate (SA)
Claim: You think, we are really Khomeini or something. Which is fine—

### Moderator
Claim: Question from the rear.

### Scientific Advocate (SA)
Claim: He’s sadistic to be here.

### Moderator
Claim: Does the panel feel that, in fact it’s debating a issue that’s not a debate? That basically, are you voicing that we’re really talking about people, and whether the people are in the stock market, whether in the art market, whether in the garbage market, it really doesn’t matter. The question of what is ethical behavior, as an individual, in whatever market you’re in, would seem to be the, can I say the basic premise that, going here is all manufacturing. And I just, I don’t hear enough people talking about the fact that they’re really on one side or the other. And that you’re really struggling with the same issue, of, it’s a personal matter. And you can have good ethics, bad ethics, anyplace, it’s really a personal question, it’s not a question of regulation—I’m sorry, I’m going on. It’s not a question—

### Moderator
Claim: No, actually I think that’s a really excellent question—

### Moderator
Claim: —I’ll cut you off ‘cause we get your point but…Adam, that sounds like it’s meant for you—

### Conspiracy Advocate (CA)
Claim: We don’t agree with you, we are for this proposition. We wanna win the debate. They are against. So, we’re not all together here, we’re for the proposition, they’re against. So if you agree with us, you wanna vote over here. That being said, it was very interesting that, Richard was saying something against the auctions…but Chuck was chiming in, and so I feel obliged to say something for the auction houses, just to balance it out here. Remember, if something sells at auction, somebody bought it. That is a fact. Doesn’t matter if they chandeliered it, doesn’t matter if they advertised it, I don’t care if they shined it with shoe polish. Somebody bought it, and we can actually see that. That is not possible in the private market, so…for better or for worse, this market wouldn’t exist without the auction houses, and we need them as collectors, I think as dealers, and I think, artists often don’t understand that, the auction market, the auction house actually makes this a market and is ultimately to everyone’s benefit.

### Moderator
Claim: Question from the far back.

### Moderator
Claim: As a lawyer who defends other lawyers who get into ethical trouble, and actually, yes, but it’s not an oxymoron, I—attorney ethics. The question is we have rules, you can’t lie, you can’t steal. There are actually defined rules. Why can’t everybody on this panel just agree, that in fact you do need a set of rules, that define what you can and can’t do within your own industry?

### Scientific Advocate (SA)
Claim: Can I ask you then, I will answer your question in the form of a question.

### Scientific Advocate (SA)
Claim: I don’t know if that’s bad. I have a painting here I say is worth a thousand dollars. What’s—how are we gonna put a rule on that.

### Moderator
Claim: Professor Charles Wolfram said it’s puffery. There is a subjective view, however—

### Scientific Advocate (SA)
Claim: Yes—

### Moderator
Claim: —the moment I ask you the question, do you have a valuation in your bag for less than that amount, if you do and you say you don’t, that is a false statement and therefore it is sanctionable.

### Scientific Advocate (SA)
Claim: I could never go to trial. ‘Cause I kinda lost you, all I know… All I know, is that, I just sold one of these for a thousand dollars this morning, and this is by the same woman, and it’s a thousand dollars. And there’s no rule on that. There is no rule, you could sell it for 1200, which is fine with me, or you could sell it for 800, if you decided to discount it now that the economy’s a little, ehh-ehh-ehh. It’s fine, there should not be rules in this. Not the rules you’re looking for.

### Moderator
Claim: But shouldn’t there be black-and-white rules regarding what you can and can’t do—

### Conspiracy Advocate (CA)
Claim: This is not an age of certainty, my friends—

### Scientific Advocate (SA)
Claim: Yeah, the black-and-white rules are take care of the art—

### Scientific Advocate (SA)
Claim: We’re in—

### Scientific Advocate (SA)
Claim: —be a good custodian—

### Scientific Advocate (SA)
Claim: —an age of uncertainty—

### Scientific Advocate (SA)
Claim: That’s all—

### Scientific Advocate (SA)
Claim: —again. Like the Renaissance.

### Moderator
Claim: Amy Cappellazzo—

### Conspiracy Advocate (CA)
Claim: We do have rules, we have—

### Scientific Advocate (SA)
Claim: No, I’m just say—

### Conspiracy Advocate (CA)
Claim: —we have very strict rules.

### Moderator
Claim: Richard Feigen—

### Conspiracy Advocate (CA)
Claim: On authenticity, when I make an invoice out and it says this is by Pablo Picasso, it is and if it’s proven otherwise—

### Scientific Advocate (SA)
Claim: Yes.

### Conspiracy Advocate (CA)
Claim: —then I am subject to penalties.

### Scientific Advocate (SA)
Claim: Of course.

### Conspiracy Advocate (CA)
Claim: If I say this is oil on canvas and it’s something else, if I say it’s this size and it’s that size, we have rules.

### Scientific Advocate (SA)
Claim: Yes—

### Scientific Advocate (SA)
Claim: Has to be—

### Conspiracy Advocate (CA)
Claim: And if anybody has a problem they go to the Art Dealers Association of America and complain, and Feigen gets blasted, I mean I, I have very strict rules and we have very strict codes of ethics. What I’m saying is, that—

### Scientific Advocate (SA)
Claim: So you’re ethical.

### Conspiracy Advocate (CA)
Claim: Well, yes.

### Scientific Advocate (SA)
Claim: Okay—

### Conspiracy Advocate (CA)
Claim: We’re ethical.

### Scientific Advocate (SA)
Claim: That’s what—

### Conspiracy Advocate (CA)
Claim: But I don’t believe in lying…

### Scientific Advocate (SA)
Claim: Me neither.

### Conspiracy Advocate (CA)
Claim: And so I don’t believe in saying—

### Scientific Advocate (SA)
Claim: Uh, me neither—

### Conspiracy Advocate (CA)
Claim: —that this guy over here bid when he didn’t, or it was the chandelier bidding against some poor innocent guy that comes along and thinks he has a competitor. A man who pays a million dollars for a painting because the under-bidder said 950 and he figures his exposure is $50,000, that’s his risk. He thinks there’s a willing and able buyer at 950. What happens if the willing and able buyer was the chandelier?

### Scientific Advocate (SA)
Claim: That would be unethical.

### Conspiracy Advocate (CA)
Claim: Well, it—

## Round 3

### Moderator
Claim: Ladies and gentlemen, that concludes the head-to-head section of our debate. We only have a few minutes left, I wanna remind you where we are, we are going to hear closing statements shortly, from each of the panelists. You were polled when you came in this evening…with the motion, “The art market is less ethical than the stock market,” 32 percent of you were for this motion, 30 percent were against, and 38 percent were undecided. We will poll you again shortly, but we now want to have closing statements of two minutes each from each of our panelists beginning with artist Chuck Close arguing against the motion.

### Scientific Advocate (SA)
Claim: It was not me but Dave Hickey who said works of art have no intrinsic value. All their value is extrinsic, it is invested from without and over a period of time. And that is truth. It’s not what any—the reason it can’t be regulated is it’s a kind of consensus. A consensus that’s formed, between art critics and art dealers, and art historians, and artists themselves. You can hype something for a while, you can spin it, you can try and produce, you can try and put it up for auction and manipulate it that way. But finally, it is—the art world is not hog futures. When you lose money in the stock market as I just did, I’m not gonna hang my stock certificates on the wall. If I bought something I like, and no one else in the world thinks it’s worth anything anymore, I at least having something I like.

And that is what makes it different from other kinds of investments. You can’t just look at it as hog futures or pork bellies or anything else. It is ruled by passion, and it is a consensus that’s formed amongst art-world professionals of all kinds, and most important by artists themselves. And you can manipulate it up to a point, what good is trying to regulate it when it is a self-correcting process. When the hype and everything else falls away, you’ll be looking at the work, and if there is not support for that work, if the professionals in the field, those people who know it and care about it whether in the auction houses, whether they’re dealers, whether they’re critics, or collectors or artists, that consensus is what forms value and nothing else matters.

### Moderator
Claim: Thank you, Chuck Close. Making his summary statement for the motion, “The art market is less ethical than the stock market,” Richard Feigen, an art dealer and collector, founder of Richard L. Feigen and Company.

### Conspiracy Advocate (CA)
Claim: I don’t quarrel with anything that Chuck says except, I do not believe that it addresses the point of this debate. I believe that nothing else has much val— intrinsic value than art. I don’t believe in anything else, I don’t believe in green pieces of paper that they print in Washington, ad infinitum to the trillions of dollars. I believe in art. However…there is an art market. This was created by the press, publicizing these huge prices, and by the financial institutions, who are lending money on it, who have set up departments to advise their clients on buying art. It has become, it has been transformed, metastasized, into a financial market. And because it is a financial market, for better or for worse, although I would prefer that it were not, because I am passionate about buying art, I’d rather buy it and this makes it more difficult for me, and more expensive for me, the fact is, that it is a financial market.

And as such, it is totally unregulated. And in my view things go on in this market that could not happen in the securities markets. People would go to jail. Okay, you can’t pretend that there’s a buyer when there isn’t, there’s no transparency at all. And what I’m saying is, I’m not saying to regulate the prices of art because, that is between the artist and his dealer as Chuck says. But the fact is nobody is saying—nobody is saying, something that’s not true. I’m saying that, in the auction market, and I agree that auctions are indispensable to establish values and for people that wanna go in and acquire art— In that market, there is no transparency, and there is deception, deliberate deception. And I do believe, that it ought to be regulated. That this kind of activity… Now, I wish all of you to vote for our position here.

### Moderator
Claim: Thank you, Richard Feigen. Summarizing against the motion, Amy Cappellazzo, deputy chairman and international co-head of post-war and contemporary art at Christie’s.

### Scientific Advocate (SA)
Claim: Feel it’s very important to address Richard directly here in his, clear dislike of the auction houses. Richard, if it weren’t for the auction houses bringing liquidity and transparency, what you would do all day would be a mere curiosity. So, the market depends on the liquidity and transparency that the auction houses bring, and remember that the area of the market you’re calling the most unethical or potentially corrupt is the only area that’s regulated, in fact. So…positively, I make the proposition, that this is way too specific an argument, that auction is an ancient art form and a completely legitimate way to sell something in the world and there’s a sort of ancient rhythm and dance to auction that, people seem to accept and understand. And there’s many ways for consumers to become informed.

To go back to the proposition, I think my hypothesis is anybody who signs up for the art world, signs up to participate by a certain set of values and ideas about how we look after and take care of the art, I mean…some of us are compensated well but no one’s in it for the dough. There is definitely another motive to be involved. And art exists with this larger art world that is the kind of moral and ethical conscience of what the market does. If you don’t have street cred, and soul, you ain’t gonna go very far in the art market. So I argue the proposition that, in fact the art world is at least as ethical as the stock market if not vastly more so, that individual people are unethical in their behavior and we all know them in every single industry, and the system of the art world, in fact, stands to be potentially more ethical because, there are all sorts of various motives to be involved but primarily it’s for the—for the love of the art itself.

### Moderator
Claim: Thank you, Amy Cappellazzo. Summarizing for the motion, Michael Hue-Williams, founder of the Albion Gallery.

### Conspiracy Advocate (CA)
Claim: I wanted to remind you, the idea that regulations are what force ethics, and in an unregulated market like the art market, it is hard to force people to adhere to ethical principles. Without ethical principles however, and with the manipulations of market, we can look, for instance, to the tulip market in 1636. We create bubbles, and these bubbles are intrinsically unhealthy. You may all know Charles Mackay’s extraordinary book, Extraordinary Popular Delusions and the Madness of Crowds.

People follow each other, because they feel that there are financial opportunities. Especially when these markets are unregulated. The tulip market crashed, but it was regulated by the Dutch government, rather too late. But, the point here is, that the art market is unregulated, it is open to unethical behavior because it’s unregulated. Not how often is it unregulated, but the fact that it, it is intrinsically unethical because it is, as I said before, it is not regulated, it is not transparent, and there are, most importantly, absolutely no barriers to entry. So that anybody may come in and manipulate the market. Whether we like them or dislike them, whether we admire them or not, is absolutely irrelevant. The important point here, is to remember that, the market is intrinsically open to manipulation, and intrinsically unethical. Whether it’s actually happening or not, is not important to the debate tonight. What is important is to understand, that the market is intrinsically unethical.

### Moderator
Claim: Thank you, Michael Hue-Williams. Summarizing against the motion, Jerry Saltz, columnist and art critic for New York magazine.

### Scientific Advocate (SA)
Claim: Art first, everything else follows. There has been an art market since the Renaissance. Right now, we’ve just finished a time of the biggest art market on the face of the earth. And now that art market is contracting. And in the coming years, a lot is going to change. Things will herniate out, other dealers, critics, collectors…et cetera, that we can’t yet see. I would say that, art is a way of knowing the world, and a way of knowing yourself. Art will have— the art market, became content for the art world.

It’s content for a lot of you right now—I want you to vote for our side, for us…but also for you, if I can say something that’s egotistical, because… If you’re only seeing art for its value, and saying that it’s…of course it’s going to be unethical. The people that buy and sell it. That almost goes without saying. But is it really more unethical, than what’s going on out there? Real pain? Real serious stuff, world-changing economic stuff? If you think that, then you really—I just wanna say when you go to an art gallery or museum…that could be in your way. That you think that all of this is unethical. That unethical. Yeah, it’s unethical, but… No more than you are.

### Moderator
Claim: Thank you, Jerry Saltz. Finally summarizing for the motion that the art market is less ethical than the stock market, Adam Lindemann, an entrepreneur and a major collector of contemporary art.

### Conspiracy Advocate (CA)
Claim: Thank you, John. The, Jerry, I just wanna say— to all of you over there, I do feel for you, and I’m with you… But, of course, I’m with my teammates here and— I appreciate the difficult time you’ve had tonight… And I love—

### Scientific Advocate (SA)
Claim: The feeling is mutual—

### Conspiracy Advocate (CA)
Claim: —everything that you said, you know, but the real—a minute 30, okay. Art is based on two things as far as I can tell, and, Jerry said we’re all learning on the job, and I—you know what, I couldn’t agree more. I’m learning right now. But the two C’s are consensus and confidence, and these are there, things that the art market is built on, so what makes a great artist. It’s sort of this Platonic concept, is there such a thing as great art?

Perhaps, but, in whose mind, the thing that makes art valuable is consensus, what makes Picasso Picasso, because everyone thinks he’s great. Someone thinks he’s crap and that doesn’t really matter because people are still paying a lotta money for it. So, consensus is what makes the art market, and then we need that extra thing that often the auction house brings, a dealer can bring, which is confidence, and, those are the two things that, that make us feel comfortable with art being valuable. The reality is though that the ethical side is up to the individual that you’re dealing with. There is no way to guarantee that anything is worth anything. And so, when we’re speaking in terms of Dave Hickey’s intrinsic and extrinsic value, the intrinsic value of art, is perhaps infinite. But the extrinsic value is really something that is almost impossible to measure on any given day.

Thank you, John. The, Jerry, I just wanna say— to all of you over there, I do feel for you, and I’m with you… But, of course, I’m with my teammates here and— I appreciate the difficult time you’ve had tonight… And I love—

### Moderator
Claim: Thank you, Adam Lindemann. And thank you to our panelists who have now concluded their portion of the evening. So, here’s what’s gonna happen next over the next three or four minutes, we’re going to have you vote again. I’m going to take a minute or two to talk to you about our upcoming debates and then we’ll have the results. So, to remind you, our topic is “The art market is less ethical than the stock market”… Coming in off the street, 32 percent of you supported this motion, 30 percent were against, 38 percent were undecided. We decide the winner by the side that moved…most people, that changed most minds and changed their numbers, most significantly. If you are for the motion now press number 1, if you are against the motion, press number 2, if you remain undecided press number 3.

So… Does anyone need more time or can we lock it out. We’ll give you 15 more seconds.

Okay, here’s what I’d like to tell you. Our next debate is Tuesday, the 17th of March, the motion will be, “Blame Washington more than Wall Street for the financial crisis.” Panelists for the motion are Niall Ferguson, professor of history at Harvard University and Senior Research Fellow of Jesus College, Oxford University, John Steele Gordon, an author and commentator specializing in business and financial history, and Nouriel Roubini, a professor of economics and international business at the NYU Stern School of Business. Panelists against the motion are Alex Berenson of the New York Times, Jim Chanos, the founder and managing partner of the short-selling investment firm, Kynikos Associates, and Nell Minow, editor and co-founder of the Corporate Library, an independent corporate governance research firm.

This debate I wanna remind you as well as all of our spring season will take place here, at the Rockefeller University’s Casprey Auditorium, and all of our debates including this one, can be heard now on more than 170 NPR stations across the country. You can check your local NPR member station listings for the dates, and the times of the broadcasts. And finally copies of books by Richard Feigen and Adam Lindemann, as well as past debates on DVD are on sale in the lobby.

We’ve had a very significant movement, in the results. Reminding you, before the debate 32 percent were for, 30 percent against, and 38 percent undecided— as you can see, 55 percent are for, 33 percent against, 12 percent undecided. The side for the motion carries the debate. Thank you very much everyone for joining us.
