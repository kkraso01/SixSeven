# Debate Transcript

Topic: Freedom of Expression Must Include the License to Offend
Motion: Freedom of Expression Must Include the License to Offend

Debate ID: FreedomOfExpression-101806


## Round 1

### Moderator
Claim: Can I ask everyone to come sit down, please? Hello. My name’s Jeffrey Toobin, I’m the moderator and warm-up act here today, and I just wanted to explain a few things before we got started. The first thing I wanted to say, which I’m sure is a great shock to you, is please turn off your cell phones. Ah, see, everybody’s… Also, please unwrap any delicious candies you plan on eating during the program. Now, I say this not because it is incredibly annoying to listen to both cell phones and candy unwrapping, but if you look above you, you will see that there are microphones. This event is being recorded and is going to be broadcast on WNYC and other NPR stations next Friday at 2 p.m. in an edited form. Now, that is significant just because it’s interesting, but it also means that you are an integral part of the broadcast. Your questions, when it comes to that, but also your reactions. If you want to clap, if you want to laugh, by all means feel free. This is not a solemn occasion, you’re expected to participate in it. Extended booing is discouraged but please, have “Freedom of expression must include the license to offend” fun. Now, this is very good, because I’m also supposed to, as a radio check, ask you to give a rousing round of applause. So since our panelists are coming out, why don’t you do that. Let me let Robert Rosenkranz take over from here.

### Moderator
Claim: Thank you, Jeffrey. Well, good evening, everyone, and thank you for being here. I’m Robert Rosenkranz, I’m the chairman of the Intelligence Squared U.S. Debate Forum, which is an initiative of the Rosenkranz Foundation. I’m here with Dana Wolf, our executive producer of this debate series. We’d like to welcome you. This is the second debate of our fall season, and with this season of live debates, and with our national radio audience, we’re pursuing a lofty, ambitious goal. We’re trying to raise the level of public discourse in American life. We see Congress mired in partisan rancor, we see a media that’s increasingly ideological, we see policy intellectuals in the think-tank world speaking to their respective choirs.

Discussion of contentious policy issues everywhere seems to be dominated by intense emotions, rather than by facts and reasoned analysis. But IQ Squared is not about the search for bland middle ground. Rather, we want to encourage each side of an argument to sharpen its own thinking by listening to opposing views, and responding to inconvenient facts. We want our “Freedom of expression must include the license to offend” audience, who voted on tonight’s resolution, to vote again after hearing the debate. I hope you’ll come away with the recognition that there is an intellectually respectable position on the other side. We’re thrilled that WNYC is recording our series of debates, and that through National Public Radio, you’ll be able to hear this debate in many of the major cities across the country, on local National Public Radio-member stations.

We also value the sponsorship of the Times of London, and I especially want to thank our moderator, Jeffrey Toobin of The New Yorker magazine, and CNN, whom I will formally introduce momentarily, and the extraordinary group of panelists who are the true stars of tonight’s event. At first blush, tonight’s motion seems like a slam-dunk for the proposers. 95 percent of the pertinent quotations I looked at were ringing supports of free speech. But there were a couple of more sardonic observations that are perhaps truer to our real attitudes. Here’s Heywood Broun: “Everyone favors free speech in the slack moments, when no axes are being ground.” Louis B. Mayer: “I respect my executives who disagree with me…especially when it means losing their jobs.” Well, it’s amusing, but we do indeed live in a world where jobs are lost because of speech. Larry Summers, for example, lost the presidency of Harvard because of remarks offensive to women. Senator George Allen may well lose “Freedom of expression must include the license to offend” his because of a highly arcane ethnic epithet. So given the heightened sensitivity of so many groups in American society to demeaning speech, we should hardly be surprised that speech offensive to Muslims elicits so strong a reaction, as appalled as we may be by the associated violence. I’m now going to hand the evening over to our moderator, Jeffrey Toobin. Jeffrey is senior legal analyst for CNN Worldwide, and is staff writer at The New Yorker, where he’s been covering legal affairs since 1993. He and I are both alumni of the Harvard Law School. He joined CNN from ABC News where he provided legal analysis on such high-profile cases as the Elian Gonzales custody saga, for which he received the Emmy Award. Jeffrey’s fifth book, on the Supreme Court, is due out next year, and it’s called The Nine: Inside the Secret World of the Supreme Court. You’re the first to know that title because it was only decided upon today. I’m now very pleased to turn the evening over to Jeffrey. Thank you, enjoy the debate.

### Moderator
Claim: Thank you, Bob Rosenkranz, and welcome to the second Intelligence Squared US debate. Let me give you a brief rundown of the evening. First, the proposer of the motion will start by presenting their side of the argument. The opposition will follow. “Freedom of expression must include the license to offend” Each person will get a maximum of eight minutes and we’ll go back and forth from one side to the other. Then, when all six speakers are finished with their opening remarks, I will open the floor to brief questions from the audience. Third, when the Q- and-A is complete, each debater will make a final statement lasting not more than two minutes each.

Fourth, during the closing arguments, ballot boxes will be passed around for voting. You all have your tickets, I assume, and if you don’t have your tickets with the “For” and “Against” on it, just raise your hand, some of the folks in the aisle have extra tickets. Ballot stuffing is discouraged. Also, there are pencils and paper for people who want to jot down questions while the debate is going on. Last, after the final closing statement is made, I will announce the results of the audience vote and tell you which side carried the day. For the motion, let me introduce our panelists. Author and editor of The Paris Review and a long-time staff writer for The New Yorker, Philip Gourevitch. Prolific British author, journalist, literary critic, contrarian intellectual and subject of a New Yorker profile just last week, Christopher Hitchens. Pulitzer Prize-winning editorial cartoonist for the Philadelphia Daily News, Signe Wilkinson. Against the motion, British scholar of Jewish history and research professor in “Freedom of expression must include the license to offend” history at Royal Holloway, University of London, David Cesarani. Executive director of the American Society for Muslim Advancement, Daisy Khan. Author, professor of law at Georgetown University Law Center and activist scholar, Mari Matsuda. So let’s begin. Signe Wilkinson, you’re first.

### Conspiracy Advocate (CA)
Claim: Thank you, and thank you, Jeffrey. Since World War III almost started over a bunch of cartoons, I want to thank this evening’s organizers for including a cartoonist—two, if you include Christopher Hitchens. 150 years ago, the Tammany Hall politician Boss Tweed responded to an offensive cartoon against him with the famous line, “Stop them damn pictures.” The reason we’re here tonight, is that these days, everyone wants to stop them damn pictures, if the damn pictures in question hurt their feelings or the feelings of their tribe. When I say everyone, I mean everyone. Early in my career, I penned this badly-drawn cartoon, “Fundamental Sex Ed—does the stork bring AIDS and herpes too?” I expected calls from the fundamentalist ministers in the area, but no, I got calls from schoolteachers saying, “Not all teachers are fat, old and carry rollers!” Schoolteachers aren’t alone. In the course “Freedom of expression must include the license to offend” of my 25 years as a paid professional offender, I have been attacked for criticizing people of color, people without much color, people of guns, people of excessive weight, people with trial lawyers, and Armenian people. This is a partial list, and certainly doesn’t begin to cover people of religion, who are the touchiest people of all. Unfortunately for the pious, Americans like their damn cartoons and they always have. In nine—in 1872, Joseph Keppler drew this tribute to religion, which as you can see on the lower left, offensive caricatures Jews, and on the right, offensively caricatures Catholics.

But wait—in the middle, he offensively caricatures Episcopalians, Mormons, Baptists, Presbyterians, and even Henry Ward Beecher, the New Age minister and adulterer of his age. If we had more time, I’d show more cartoons. So, when newcomers arrive on our shores, with their deeply held religious beliefs, they should be prepared to get in line to have those beliefs scrutinized, as they did in the mid-1800s when New York City, like Denmark today, was awash with poor foreign immigrants who came with their robed clerics and demands for separate schools. These were of course Catholics, not Muslims, but some American cartoonists reacted just the way the Danes did. In 1871, the father of American cartoonists, Thomas Nast, drew this. “The American River Ganges.” The hats of the reptilian bishops crawling ashore “Freedom of expression must include the license to offend” have menacing crocodile teeth—certainly the precursors of a turban as a bomb.

Usually, my colleagues don’t go out of their way to kick a clergyman. However, when the clergy ask for special privileges, demand special tax cuts, or are just especially misbehaving, we take notice. This Pat Oliphant, “The Running of the Altar Boys”… You’re cutting into my time, stop laughing. It was embraced by many lay Catholics, but bitterly denounced by official Catholicism. Note to church leaders—if you don’t want your clerics ridiculed as child abusers, make sure they don’t abuse children. Had Americans been able to see the Danish cartoons, they would’ve noted that they too were not just gratuitous attacks on the faithful. One was making fun of the idea that after blowing up innocent people, suicide bombers would be rewarded with virgins in Heaven. If you can’t make fun of that, what can you make fun of. What really enraged believers wasn’t that Mohammed was pictured but that he was pictured negatively. To test the point, at the height of the controversy I put Mohammed in this cartoon, “The Big Fat Book of Offensive Religious Cartoons.” He’s third from the right, flanked by Jesus and God, and a few other laughing deities. No one protested this because no one “Freedom of expression must include the license to offend” cared about Mohammed being drawn as jolly and benign. However, I have been picketed without putting Mohammed in a cartoon. “Radical Islam Sponsors the Miss Muslim World Contest—Miss Illiteracy, Miss Can’t Vote, Miss Waiting to Be Stoned.” When I say picketed, I mean picketed, including… including by one of my daughter’s high school history teachers.

But Muslims aren’t alone in their selective outrage. My Jewish readers were okay with the drawing with the Star of David that was pro-Israel, but roasted me for one that criticized a local Jewish senator who was attacking his opponent for being anti- Semitic. Critics said that the Star of David was off-limits— unless, apparently, it was used to make a point that they agreed with. What critics of offensive cartoons forget is that every time I exercise my free speech, my readers exercise theirs, swiftly and loudly. For that last little sketch with the Star of David, our paper received and printed weeks of vilifying letters. The Anti- Defamation League denounced me, I was called a Nazi, and the senator’s son helpfully suggested to my editors how they could better use my talents.

One reader wrote that I was worthy of Hustler magazine, which at my age I take as something of a compliment. “Freedom of expression must include the license to offend” Speaking of Hustler, its publisher, Larry Flynt, is the patron saint of cartoonists. When Hustler ran a spoof claiming that Jerry Falwell’s first sexual encounter was with his mother in an outhouse the right reverend Falwell did the Christian thing, and sued, in a case that went to the Supreme Court in 1987. The unanimous decision was written by that famed pinko degenerate, William Rehnquist, who wrote that “Even though the spoof was outrageous, outrageousness in the area of political and social discourse is inherently subjective,” and that “the court has long protected free speech, even speech that offends the audience.” So the offended are left with the same option I use—free speech. They can and do write, call, picket, boycott, and draw their own cartoons, but in America, thank God and the Constitution, they can’t claim special privileges and stop them damn pictures. Thank you.

### Moderator
Claim: Next, against the proposition, Mari Matsuda.

### Scientific Advocate (SA)
Claim: Thank you, Jeffrey, and thank you, Signe, for making us laugh and making my job so hard. It’s really not fair to put me after the cartoonist, but I volunteered to go first. I’m sorry, I didn’t bring cartoons, and I’m not going to make you laugh. I stand before you a censored person. Under American law, there are several “Freedom of expression must include the license to offend” things that I could not say. I could not attempt to sell you snake oil as a cure for cancer. I couldn’t tell you secrets that I know that could make you millions of dollars when the stock market opens tomorrow. I couldn’t tell a lie that would harm the reputation of any of the people on this stage. And I could not yell “Fire!” in a believable way that would cause a stampede for the exits. This point is the lawyer’s point. In a complex society, law necessarily mediates between competing interests. Speech is one of those interests, and it is profoundly valuable.

But when speech comes up against other interests that are also valuable, we have no choice. We mediate, we draw lines, we balance. This is what we do. My second point is a humanitarian point—that words are weapons. They can assault, wound degrade, exclude, and incite harm of stunning proportions. I am a citizen born of the last century, one that had genocide right in its center. That century will forever color my view of the harm that human beings are capable of. Propaganda is not a parlor game and rhetoric is not recreation. Words have consequences. I take words seriously enough to make them my vocation, and I believe that some words should remain unspoken. My third claim is that I am a Constitutionalist and a civil libertarian. I believe that individuals exist prior to the state and that the state must remain accountable to its citizens. Thus I am allied with “Freedom of expression must include the license to offend” my opponents in this debate in their healthy distrust of limits on speech.

Indeed, if we had time to discuss the entire history of suppression of dissent in this country, my guess is that all six of us here on this stage would agree that the record contains many deplorable episodes. So why do I diverge on the particular question of assaultive speech and urge you to vote no tonight? It is precisely because I value speech. As I see it, there are two main reasons for the First Amendment or for our protection of speech. One is simply that we respect individual choices. Each of us is sovereign over ourselves and entitled to express the cry of our own heart. The second reason is functional. We need democracy in order for our individual selves to thrive, and we need speech in order for democracy to thrive. Democracy requires that each and every individual speak, think, study, know, and participate in self- governance.

When hate speech and propaganda instill beliefs of inherent inferiority, the very things that the First Amendment is intended to protect are at risk. When racist invective keeps you away from a public hearing, as has happened, when sexual taunting keeps you away from a job, as has happened, democracy’s prerequisites of mutual exchange and participation are gone. My students tell “Freedom of expression must include the license to offend” me, you’ve got to give examples, people don’t understand without examples. So I’ll give you one from the Asian-American community. Right after the last major San Francisco earthquake, the big one, there was a public debate about whether to rebuild certain sections of the freeway. One off-ramp in particular that led into Chinatown was of concern to the residents of that community, and they turned out for a public hearing. Well, the white Aryan Resistance also decided to do a show of force at that hearing, in their full Nazi stormtrooper regalia.

This is pre-Internet so instead of a Web site they had a hotline you could call to hear racist invective and find out who had testified at that hearing. Many of the elders and merchants in that community would come out to testify, and it was their first experience with participation in the democratic process. They were frightened away, and were very unlikely to come out again as the debate continued around this issue of political discourse. If you think about why we disallow defamation, or impose legal penalties for it, it’s because reputation is part of the self, and it’s part of the self that’s needed to participate equally in the democratic conversation. If you lose standing in the community you lose liberty. The freedom to move about as a respected person, to speak credibly, to join your fellow citizens in this grand social contract that we call democracy. Your reputation is “Freedom of expression must include the license to offend” valuable, and thus we will restrain speech when it takes your reputation from you.

I submit that there are forms of assaultive speech that have very much the same effect. I’ve asked for 30 years why we penalize someone who calls a doctor a quack, but we won’t penalize someone who says that by race, the doctor is inherently worthless and properly subject to extermination. I haven’t received an answer. If you believe, as I do, that unbridled freedom to wound with words and to incite through propaganda can harm the very freedom that we intend to protect by protecting speech, then I suggest that you vote against the proposition. The other side will tell you we can’t start down that path of deciding which speech is acceptable, or we become trapped in the censorship business. This is a rhetorical move that lawyers call the slippery slope.

What the other side will not tell you is that we are already on the slippery slope of tolerating censorship of certain forms of speech, including libel, fraud, copyright infringement, conversations in restraint of trade. There is no easy and absolute way out. We do have to decide when, where, and how we will limit speech. The call of the question here uses the word “offensive.” But let me make clear that none of us would be engaged in this debate if we were just talking about table manners, or humorous insults with “Freedom of expression must include the license to offend” political purpose, the right to offend that Signe Wilkinson is talking about. If we say that we are closing the door, taking an absolutist position, giving a free license to those who would use words to assault, we’re doing much more than just allowing political cartoons, which I think should be protected absolutely, we can discern how to do that under our legal system.

But what I’m really getting at is words that are intended to wound, and to stop people from equal participation in society. If I spit on your shoe, you can sue me for that, it’s called a battery. There are words I could use that would have the same effect on your psyche, your personhood, or your ability to move freely. Yet if you vote for this proposition you’re saying that that form of assault is allowed. It happens in this city and elsewhere in our country. Thank you, vote no.

### Moderator
Claim: Philip Gourevitch. “Freedom of expression must include the license to offend”

### Conspiracy Advocate (CA)
Claim: Extraordinary how people who want to silence public speech won’t shut up. We’re faced tonight with people who want to stop cartooning but who make a caricature of the concept of free speech. They are not here to discuss free speech, they are here to discuss their deep conviction that speech is not free and therefore should not be free. That is essentially what the previous speaker said, she said there is no free speech, let’s be real, and therefore there should be no free speech and we should simply start restricting it endlessly. Since we are being cartooned as the monstrous side, let me begin with a monstrous image. In Northern Uganda for the last 15 to 20 years, there has been a movement known as the Lord’s Resistance Army. It practices its warfare in the name of God, and what it does when it dislikes the speech that is being made is that it cuts off the lips of the citizens who are speaking and it puts padlocks through punctured holes in their lips and shuts them. I’m afraid that I’m very much unable to picture these people doing that, but it’s very clear to me that that is what they wish to do. I will return to this image at the end, but that is the image that clearly you must bear in mind as you, the jury tonight, vote on the question of whether we shall be permitted to speak or whether we shall be inclined to silence anybody in whom we find offense. “Freedom of expression must include the license to offend” That is what they are saying, and who are they to judge what is offensive? Surely you have different ideas, surely we all have different ideas, and yet somehow, the concept of offense is being proposed by the other side as some sort of universal measure of civilization rather than the opposite. But one point of agreement that we have is that speech is fiercely powerful, and can be intensely dangerous. I spent some time reporting from Rwanda in the aftermath of the genocide there. The previous speaker referred to genocide, and one of the most striking things in Rwanda is that in a great deal of the genocide was incited by public speech, radio speech, incitement through words. The words were used as hate speech, which we will find the other side thinks should be censored because it is dangerous. The hate speech said, invariably, kill the minority, the Tutsis. They didn’t always say it directly, they would use euphemisms and the euphemisms would be phrases like “Do your work. Clear the bush. Do not let a weed escape the blade.” These were phrases that were well understood in the historical context and they were clearly hate speech, there’s no ambiguity about it. Those people have been tried and convicted for inciting mass murder in their country. The problem there was not free speech for haters. It was that this was the officially sanctioned “Freedom of expression must include the license to offend” speech by people who prohibited sanity from being free speech. Anybody who protested against the genocide was silenced as offensive. Offensive speech, my goodness. That Hutus and Tutsis should live side by side in comity, that they should allow each other to exist—how offensive. Let’s silence them. Let’s murder them. Let us have official speech. That was the position.

That is the position which—yes, ma’am. “Slippery slope.” It’s not a slippery slope, it’s a greased precipice over which they wish to push you. Once you start to say that racist or blasphemous speech is somehow or other offensive, you’re immediately on the quick descent towards book-burning. The books that you wish to burn are the books that include, let’s say, Huck Finn, where racists are used in possibly the 19th century’s noblest portrait of a black man in America. Blasphemous speech is used by Ahab. Most people who are burning books are of course too illiterate to notice. But let’s focus on the facts. They consistently elevate idiotic speech, like Holocaust denial, to a greatly important role by saying, lets us illegalize it, challenge it in courts, give these people a tremendous platform, and prove that they’re wrong…when no sane person can possibly suspect that this is serious history.

So we’re going to have to elevate them in order to silence them, “Freedom of expression must include the license to offend” rather than to ignore them, to discuss it with them. I would like to quote to you a short passage from David Cesarani in which he wrote, “Celebrating Austria’s Law Criminalizing Holocaust Denial.” This was in The Guardian. “Thanks to the Internet,” he claims, “it is virtually impossible to stop the dissemination of laws and propaganda these days. The classical arguments of freedom of speech drawn from Voltaire and Mill are redundant.” So we have an anti-enlightenment argument very strongly stated. “They addressed small, literate elites at a time when the means of reproduction were relatively few and easily controlled, when it was easy to contend that in a contest between truth and falsehood held among reasonable men, lies would be exposed and driven from the public sphere.

But the Internet is awash with falsehood and bigotry. Good ideas and beautiful truths coexist with trash and outright evil. Heaven forfend that bad ideas should be out there. Amid this anarchy,” he says, “all that decent people can do is agree to reasonable limits on what can be said and set down legal markers in an attempt to preserve a democratic, civilized and tolerant society.” That’s what he says. I say, who gives him the right to set up a chair in the antechambers of my mind and judge what I’m allowed to say and what I’m allowed to think. Is that what you want? Is that who you want? How does it avail the “Freedom of expression must include the license to offend” cause of civilization, sir, to fight brownshirts with brownshirt tactics? I would like to know that. What I share with this pious trinity of the opposing team is a deeply pessimistic view of human history. I do not believe that if you let people run around loose they’re going to have nice ideas about each other and behave nicely towards each other, because that’s not what they do.

Their response is to cut off their lips and to clamp on a padlock. To decide who should be in the Sanhedrin of the mind and who should be in the Sanhedrin of the soul, sit around and tell you what you’re allowed to say and what you’re allowed to think. They do not understand that there is not agreement about this. They seem to assume that somehow or other it will always prevail. Yes, they say times change, sometimes it’s allowed to be racist, sometimes it’s allowed to be anti-racist. Sometimes we silence the people who are pro-Jewish, sometimes we silence the people who are anti-Muslim, but that’s okay because we’re just rolling with the times, and we’re always going to let the people who we sort of think are civilized speak in the name of civility.

I think that this is extremely dangerous. I return, that while they conclude that we must accept that because speech is limited we must put ourselves in charge of limiting it, that we are dealing here really with a case of lesser evils. The question before us “Freedom of expression must include the license to offend” tonight, simply put and simply stated in the proposition that we were given, is that freedom of speech must include a license to offend. I would expand that license to blaspheme, and I would not call it a license. They speak of it as a license, they think all speech is a license and that all speech should be licensed because most speech should be restricted before it is licensed. Then we decide, okay, we’ll let this out, we’ll let that out, we’ll let this out, we’ll let that out. I think that that’s a very, very, very dangerous precipice on which they want to perch us. I do not trust them, even though I think that they’re probably more trustable than most.

But what is to say that they will stay in charge of that speech? What is to say that we will not fall into the hands of somebody we don’t trust? What is to say that the message that one day seems somewhat sane, the next day becomes to kill, and that the people who say let us not kill are silenced in the name of reasonable speech and in the name of civilization to moderate that. I remind you one last time as you go to vote, if you believe in chopping off lips and clamping on padlocks on open mouths, there’s your troika.

### Moderator
Claim: That was Philip Gourevitch. Next, against the proposition, David Cesarani. “Freedom of expression must include the license to offend”

### Scientific Advocate (SA)
Claim: Right. Well— First of all I want to thank Philip for repeating verbatim something I wrote in The Guardian. I stand by every word, and it’s saved me a bit of time. I do think it is possible for reasonable people, like the people in this room, to decide what is offensive and what is dangerous. Mari, in a very modest and less flamboyant way, tried to set out what it is that is offensive, and what is dangerous. I don’t think it’s really necessary to bother to respond to a very foolish idea of what this side of the house is advocating. We are not advocating cutting off people’s lips, we are not even advocating repealing the First Amendment. We’re not even advocating special laws that will have people banged up in prison for saying things that we don’t like. We’re just asking you, and I’m asking this as someone who’s British, to just reflect with a little humility on American society and culture. To reflect while holding in mind the fact that, in most other liberal democracies, there are modest constraints on what can be said and written. For good reason, too. Most international conventions that set out freedoms also include constraints on the freedom of expression, most notably the European Convention on Human Rights.

The reason is that the European Convention on Human Rights “Freedom of expression must include the license to offend” that was passed in 1950 was framed against the background of genocide, mass murder, persecution, and totalitarianism in Europe. Men and women had seen the drip-drip effect there of hate speech, words that demeaned and degraded, and resolved that freedom of speech could no longer be considered an absolute right. It was a right, a fundamental element of liberty. But it was not absolutely overriding because it was open to abuse. It was abused in Europe, it’s abused now, and I’d say it’s actually abused here. Philip Gourevitch said rather mockingly that we came to you to ask you to get real. I’m going to repeat that. Get real. There was a little article in The Guardian which amused me. Apparently, a few days ago, a meeting to be addressed by a colleague of mine, Tony Judd, a historian who I rate enormously highly, was canceled because of a phone call from Abe Foxman.

I don’t know if Abe Foxman is in this audience now, but he’s obviously a very powerful man. Just with the one of his voice he can have meetings canceled and freedom of expression curtailed. I think that is an abuse of power. I think that it is very dangerous that people can phone up organizations and have meetings canceled because they don’t like, not what the speaker is actually going to address, but other things that he has spoken about. Tony Judd has written some things about Israel that Abe didn’t like, so Abe phoned up the Polish consulate and said, do “Freedom of expression must include the license to offend” you really want to have that guy speak on your premises? Now, get real. You have constraints on freedom of expression in this great country. What we are asking you to do is to reflect with a little bit of humility on how you want those constraints to be exercised by the most powerful, the most ruthless, the ones with the biggest bank balances, the ones with the most votes.

Or do you want to have a public debate about how you protect those who are weak, who are vulnerable, who are defenseless, who are marginal, and who are often abused in the mass media or in work settings, as Mari mentioned. I think the real choice is not whether you’re in favor of absolute freedom of speech or constraints on freedom of speech tonight. It’s whether you’re going to be realistic, or whether you’re going to be smug and hypocritical and walk out of this hall thinking this is the land of the free, land of the brave, no such things as restrictions on freedom of speech here, and we don’t want to be lectured about that by some limey. Whether you’re going to recite to yourselves happily, Milton, Locke, Mill!— without actually knowing very much about what Milton, Locke and Mill had to say about freedom of expression. For none of these men was freedom of expression a good in itself. It was always a means to an end.

For Milton, who didn’t like Catholics, it was to expose the fallacies “Freedom of expression must include the license to offend” of Catholicism prior to crushing and eradicating them. For Locke, it was simply a means to good governments. For Mill, it was to advance education and truth. As soon as Mill considered the possibility of uneducated mass audiences, he panicked and resiled. He went back on everything that he’d said about unlimited freedom of speech. I’m going to read out what John Stuart Mill had to say. “Acts of whatever kind, which without justifiable cause do harm to others, may be—and, in the more important cases, absolutely require to be—controlled by the unfavorable sentiments and when needful by the active interference of mankind.” He included speech acts, and the notorious, wonderful example he gave is the folly of allowing a man in a time of famine to inveigh against grain dealers outside the home of a grain dealer before a public that is hungry, ill-educated, and not terribly reasonable. That unfortunately is the state of our society today. There are a lot of people who are unreasonable, who are ill- educated, who are angry about this and that, and there are plenty of people who want to stir the pot and who want to incite them. John Stuart Mill, who understood the perils of mass society, also understood that we are no longer conducting this discussion amongst a nice, homogeneous elite, but we are having to deal with huge numbers of people in divided, conflicted “Freedom of expression must include the license to offend” societies. I think—and I’m an optimist, unlike Philip Gourevitch—that we have it within our power, thinking and working together, to agree on what can and cannot be said, should and should not be said, to avoid conflict, to avoid people standing outside the homes of grain merchants, and inveighing against their business.

This is what Timothy Garton Ashe wrote recently in The Guardian. “We need to wake up to the seriousness of the danger”—the danger to freedom of speech, freedom of expression. “I repeat, this is one of the greatest challenges to freedom in our time. We need a debate about what the law should and should not allow to be said or written. Even Mill did not suggest that everyone should be allowed to say anything anytime anywhere. We also need a debate about what it’s prudent and wise to say in a globalized world where people of different cultures live so close together, like roommates separated only by a thin curtain. There is a frontier of prudence and wisdom which lies beyond the one that should be enforced by law.” We are, on this side of the house, advocating that you think about where that boundary of prudence and wisdom should lie. We’re not repealing the laws, we’re not passing them, we want you to reflect. Thank you. “Freedom of expression must include the license to offend”

### Moderator
Claim: That was David Cesarani against the proposition. Now for the proposition, Christopher Hitchens.

### Conspiracy Advocate (CA)
Claim: Well now, Mr. Chairman, ladies and gentlemen, brothers and sisters…if I may say, comrades and friends. Okay, then, “Fire!” It’s not that crowded a theater, but “Fire!” again. You see? If you remember the appalling judgment actually rendered by Mr. Justice Oliver Wendell Holmes in that case, he was comparing the action that I’ve just imitated and parodied to the action of a group of Yiddish-speaking socialists who gave out a leaflet, in Yiddish only, opposing Mr. Wilson’s war and actually calling attention as they were to a major conflagration raging in Europe in which they did not think the United States should become involved.

Be very, very, very careful when people give you arguments from authority or tradition that suggest that free speech can be limited by higher authorities like the sainted Holmes, because that’s what you’ll get. The end of it is a group of Yiddish-speaking radicals told they can’t hand out a leaflet in Yiddish on a major question of the day. That’s always how it will end, no matter how high-mindedly or creepily or sinisterly it’s presented to you. My “Freedom of expression must include the license to offend” favorite crowded-theater story is actually about the terrible Broadway production of The Diary of Anne Frank. Some people may remember this, it’s a production famous for its longueurs. In the third act as the German soldiers came pounding on the door and stamping into the parlor, someone in the front row shouted, “She’s in the attic!” Call me old-fashioned if you will, ladies and gentlemen, but as you will see I don’t think a joke is really a joke unless it’s at somebody’s expense.

Now if you’re thick-skinned and broad-backed enough to take that, I might have a bit more for you. The real question, utterly, utterly dodged by David in his shady remarks, is this. Who’s going to decide. We’ve already found that Oliver Wendell Holmes isn’t competent on the point. Who will you appoint. Who will be the one who says, I know exactly where the limits should be, I know how far you can go and I know when you’ve gone too far, and I’ll decide that. Who do you think—who do you know—who have you heard of, who have you read about in history to whom you’d give that job? I always say, just for this evening, I wouldn’t give it to anyone who’s spoken so far on the other side. Now, I sure do know a bit about Milton and quite a lot about Thomas Paine as well. Mr. Paine actually updated and I think improved John Milton’s Areopagitica which is the classic “Freedom of expression must include the license to offend” case for free expression.

Those of you who know Areopagitica and Paine’s commentary on it will know that it recommends free speech in this way—not for you, but for the people you are listening to and the people whose comments you hope to hear in return, for your own education, for your own enlightenment and for your own elucidation. As Mr. Paine says, commenting on Milton, one of the vices of those who would repress the opinions of others is they make themselves prisoners of their own opinions, because they deny themselves the rights and the means of changing them. Should this not be as plain as could be? The free interplay of ideas is not something that those of us who wish to speak or unload our opinions insist upon for that sake, it’s because we want to hear what is said in response, however unwelcome it may be to us.

Thus the defense of any one opinion or form of expression is a defense of all of them. The classic statement in modern times of this, in my view, would be Aryeh Neier’s book Defending My Enemy where he describes the decision of the American Civil Liberties Union, of which I am a supporter, to take the case of the American Nazi Party and its right to parade swastikas through the town of Skokie, Illinois, a favorite retirement community for those who’d survived the final solution. The ACLU lost a lot of “Freedom of expression must include the license to offend” members on that proposition but we did the right thing by the First Amendment. In the book he has a wonderful extract from Robert Bolt’s play A Man for All Seasons which some of you will have seen at least in celluloid form, where if you recall, Sir Thomas More is talking to one of the witch-hunters and prosecutors.

He says, “So you’d cut a road through the laws, would you, to get after the Devil?” The witch-hunter and prosecutor says, “I’d cut down every law in England to do that.” Thomas More says, “That’s worth knowing. And when the Devil turned round to meet you and had you at bay, where would you look for shelter, Mr. Prosecutor, the laws all being flat and cut down? Where would you turn then?” It’s impossible ever to think of infringing the right of anyone else to free speech without arranging, in a sense calling in advance for this to happen to you too. It’s quite different, obviously different, from any question of information. Information may be classified and information may be copyrighted. Every word said on that score by the first speaker on the other side was a complete waste of her breath, because it’s not what we’re meant to talk about. We’re meant to talk about the expression of opinion and conviction, not breach of copyright or leaking of classified information. If we’d wanted to talk about that, we would’ve phrased the motion differently. “Freedom of expression must include the license to offend” There’ve been some bad signs lately, a lot of slippage in what I would have thought was the pedantic obviousness of the points I’ve just made. The imprisonment of David Irving in Austria for a thought crime, for the possibility that he might while in Austria have given a speech saying that he doubts some of the verdicts of history on what I call the final solution. There’s no victim to this crime. The Austrian consul called me up weeping with self-pity when I pointed this out in The Wall Street Journal and said, “But we thought finally Austria would be popular. We had something that you would all like! So gut muttlich.” That the land that survives on the myth that Hitler was German and Beethoven was Viennese, that had Waldheim as its chancellor and has Jorg Heider as a member of its government, can revenge itself on a defenseless British academic and jail him is a standing disgrace.

There are attempts to extend similar thought-crime laws to other topics of historical importance, the most depressing of which recently is the provisional decision of the French parliament to criminalize discussion of the Armenian massacre, considered by me and most others to have been a planned genocide in the early part of the 20th century. Now you couldn’t take the contrary view. You couldn’t for example argue, as you can, that actually in the “Freedom of expression must include the license to offend” provinces of Turkey where Russian forces were not engaged, Armenians were not massacred. In other words, it could be that it was partly an act of war as well as an act of ethnocide. Speculations of this kind would now be actually in peril. The law on which it’s modeled, the Loi Gayssot, which criminalizes in France discussion of the Holocaust as well, is named for the French Stalinist, Monsieur Gayssot, who sponsored it and whose spirit, and the spirit of whose hero is present in all of these and other such discussions.

I stipulate that all of these things, when they happen, offend me very much. I’m offended by them, I want you to understand. It goes to the core of what I do and what I am. The First Amendment doesn’t just provide me with a living, the First Amendment is my life. When it’s infringed, I am offended, I have claimed the right to be offended. I do not claim the right to go burn down someone else’s place of worship, to threaten their religion with violent reprisal, to picket their home, to publish their name in threatening terms on the Internet—I won’t do any of that. It doesn’t mean I can’t be offended but it does mean that I’m even more offended by those who claim the right, not just to be offended, but to seek violent reprisal, as is so vividly and currently being done by the votaries of the prophet Mohammed, in recent instances which I have no time at all to inform you but “Freedom of expression must include the license to offend” about which you already know and to which I hope I will be asked to return. Thanks very much.

### Moderator
Claim: That was Christopher Hitchens for the proposition. Against the proposition now, Daisy Khan.

### Scientific Advocate (SA)
Claim: Distinguished guests, Philip, Signe, and Christopher. First of all, I think it was divine intervention that Christopher was not allowed to continue. I think Christopher should nominate me to decide who will decide, because really, Christopher, I’m quite fair. I definitely do not believe in cutting off lips, and I hate padlocks. So I want to begin by saying that the motion of today, where the freedom of expression must include the license to offend, is in a sense really a moot point and a moot question. I hope that all of you here today will consider rejecting and throwing it out.

The freedom we have to express ourselves does in fact enable us to offend. Christopher is doing it all the time, in his own sweet way. In fact, one can even say that sometimes it is necessary to offend, and for good cause. The appropriate question to ask today is whether freedom of expression is absolute and limitless, “Freedom of expression must include the license to offend” or should it come with some social responsibility. In the US we do have a value system that undergirds our free speech. Salient within the system is the value of fighting the suppression of truth. Let’s face it. The reason why we’re having this debate today, is because a number of recent events, such as the Danish cartoon and Pope Benedict’s remarks on Islam, have brought this issue to the forefront.

I’m mentioning these examples to frame the current affairs context for our discussion here today. There is no doubt in my mind that there are many issues, many suppressed truths, particularly within the Muslim world, that very badly need to be brought to light. I do not need to go through the litany of problems faced, for instance, by women in various parts of the Muslim world and the rest of the global South, all of which need to be discussed. There’s also no doubt in my mind that when it comes to religion, Muslims need to engage in a very honest and open discussion about many of the values that they espouse. Whether they are in accordance with the teachings of Islam is another matter entirely. There are, however, certain kinds of speech that undermine the very values that liberty of expression is meant to advance. Take for example the infamous Danish cartoon protest. “Freedom of expression must include the license to offend” To put it into context, we live in an environment—and this is especially true of Europe—where Muslims constantly face xenophobia. While the overwhelming majority of the world’s 1.2 billion Muslims do not partake in any violent actions in response to these political cartoons, a tiny, minuscule minority has grabbed the world’s attention and apparently now has absolute command of how Muslims are to be perceived. This is coupled with a time when a new generation of European-born Muslims have emerged that routinely face discrimination, alienation, and are often perceived as threats in their own countries. And all this while the violence in Iraq continues to surpass its already shocking levels. Clearly, we’re living in a very tense time. In such a situation, for a right-of-center Danish newspaper to come out with cartoons that show the prophet of Islam with a bomb in his turban, with a sword in his hand, and with a menacing look on his face does nothing, absolutely nothing, to advance desperately needed dialogue, or enlighten people in any positive way.

If it does anything at all, it serves to suppress constructive dialogue by fueling extremist sentiments. It is important to note that this example has little to do with religion, though I think Philip and Christopher would probably tell you that’s the case. This isn’t about drawing the prophet, for which there are many “Freedom of expression must include the license to offend” historical precedents in traditional Muslim art. To see the situation clearly, we must all understand nuance. That’s what intellectuals are here for—for nuance, for teaching us the nuance. My Jewish rabbi friend called me right after the cartoon crisis and said, “What are you doing about the cartoons?” I said, “What are we going to do? It’s just a cartoon.” He said, “No. Don’t ever accept it. This is what they did to us in Germany. They started with the cartoons”—

So when you publish cartoons which of course are a form of entertainment and hence immensely popular—and Signe, I loved that cartoon of the radical Islam contest—as a medium for conveying a particular message, or a speech is given by a person of immense power like the Pope, which further drives people apart and cements stereotypes, you’re using public discourse to malign the way an already marginalized community is perceived. This, my friends, is not in accordance with our foundational values of free speech. This is un-American. The point is not whether such things can or cannot be published. But of course, they are published. Who’s preventing them? The issue is whether there’s any wisdom in showing the prophet of Islam with a bomb in his turban no less. This is the sort of thing that furthers that familiar, yet dangerous and unsound argument, some Muslim men are terrorists, therefore, all or even most Muslim men are terrorists. Now this last statement is certainly something we can say, something that is enshrined in free speech. But is it true? Is it responsible? Does it elevate the public discourse? Or is it simply racist, xenophobic drivel, that isn’t half as clever as it purports to be?

There are a few additional things to say. While modern “Freedom of expression must include the license to offend” technology has allowed us to improve our communication, it also means that ideas, news and statements can be disseminated at a global level very rapidly. The upshot is that the global distance is of little relevance in assessing how close we are to each other. So the notion of space, of sharing space with our neighbors, needs to be negotiated and reexamined. What is needed now is a heightened sense of awareness that enables us to distinguish between useful and useless affronts. Truly, few things are more useless than statements that exasperate bigotry and racism. Finally, in keeping with my previous point, I want to make a point about individual psychology in various societies. We’re always shocked at how people in the global South react vociferously, especially my people, Muslims, and at times violently, to what we see as simple free speech which may or may not undermine their value system.

What we do not realize in our dismay is that in societies where the basics are not guaranteed, where one life, liberty, property, and family are not protected, individuals deal with disparities by developing a greater collective consciousness, where one identifies strongly with a larger community, in our case the Uma, and the collective values it represents. Something that is perceived to threaten or undermine those values are resolved not an individual level, but are resolved in a group dynamic which can sometimes “Freedom of expression must include the license to offend” result in chaotic mob reaction, which you’re all familiar with. In an environment defined by major uncertainties, heightened inequities, depictions like the Danish cartoons are perceived as yet another attack on what for some people sadly remain the final salvation—their dignity and their faith. And Signe’s right, religious people are the touchiest. It should come as no surprise, then, to see that—

I want to just finish one last—

The rabbi is my secret weapon and I told him I would never do this. Ultimately, the question to ask is do we use our free speech to insult an already marginalized people? Or do we use it to advance and enhance a desperately needed discourse between people living in an increasingly interconnected world. I hope you’ll throw out the other motion. Thank you.

### Conspiracy Advocate (CA)
Claim: Excuse me—

### Moderator
Claim: Wait, wait. Come on, come on.

### Conspiracy Advocate (CA)
Claim: No, that’s offensive.

### Moderator
Claim: Well— That—

### Conspiracy Advocate (CA)
Claim: That’s stupid.

### Moderator
Claim: Well—no, come on, Christopher, no, no, Christopher, come on.

### Conspiracy Advocate (CA)
Claim: Stupid, nasty—

### Moderator
Claim: Christopher, come on. Daisy, this will not be deducted from your time. “Freedom of expression must include the license to offend”

### Scientific Advocate (SA)
Claim: So when you publish cartoons which of course are a form of entertainment and hence immensely popular—and Signe, I loved that cartoon of the radical Islam contest—as a medium for conveying a particular message, or a speech is given by a person of immense power like the Pope, which further drives people apart and cements stereotypes, you’re using public discourse to malign the way an already marginalized community is perceived. This, my friends, is not in accordance with our foundational values of free speech. This is un-American. The point is not whether such things can or cannot be published. But of course, they are published. Who’s preventing them? The issue is whether there’s any wisdom in showing the prophet of Islam with a bomb in his turban no less. This is the sort of thing that furthers that familiar, yet dangerous and unsound argument, some Muslim men are terrorists, therefore, all or even most Muslim men are terrorists. Now this last statement is certainly something we can say, something that is enshrined in free speech. But is it true? Is it responsible? Does it elevate the public discourse? Or is it simply racist, xenophobic drivel, that isn’t half as clever as it purports to be?

There are a few additional things to say. While modern “Freedom of expression must include the license to offend” technology has allowed us to improve our communication, it also means that ideas, news and statements can be disseminated at a global level very rapidly. The upshot is that the global distance is of little relevance in assessing how close we are to each other. So the notion of space, of sharing space with our neighbors, needs to be negotiated and reexamined. What is needed now is a heightened sense of awareness that enables us to distinguish between useful and useless affronts. Truly, few things are more useless than statements that exasperate bigotry and racism. Finally, in keeping with my previous point, I want to make a point about individual psychology in various societies. We’re always shocked at how people in the global South react vociferously, especially my people, Muslims, and at times violently, to what we see as simple free speech which may or may not undermine their value system.

What we do not realize in our dismay is that in societies where the basics are not guaranteed, where one life, liberty, property, and family are not protected, individuals deal with disparities by developing a greater collective consciousness, where one identifies strongly with a larger community, in our case the Uma, and the collective values it represents. Something that is perceived to threaten or undermine those values are resolved not an individual level, but are resolved in a group dynamic which can sometimes “Freedom of expression must include the license to offend” result in chaotic mob reaction, which you’re all familiar with. In an environment defined by major uncertainties, heightened inequities, depictions like the Danish cartoons are perceived as yet another attack on what for some people sadly remain the final salvation—their dignity and their faith. And Signe’s right, religious people are the touchiest. It should come as no surprise, then, to see that—

### Moderator
Claim: Daisy, that’s time.

### Scientific Advocate (SA)
Claim: I want to just finish one last—

### Moderator
Claim: Well, finish the sentence, finish the sentence.

### Conspiracy Advocate (CA)
Claim: Finish by naming the rabbi.

### Moderator
Claim: Stop—

### Conspiracy Advocate (CA)
Claim: I want to know who that rabbi was—

### Moderator
Claim: Sorry, we’ll get to that. We’ll get to that—

### Conspiracy Advocate (CA)
Claim: Name that rabbi— “Freedom of expression must include the license to offend”

### Moderator
Claim: Christopher—

### Conspiracy Advocate (CA)
Claim: Name that rabbi—

### Scientific Advocate (SA)
Claim: The rabbi is my secret weapon and I told him I would never do this. Ultimately, the question to ask is do we use our free speech to insult an already marginalized people? Or do we use it to advance and enhance a desperately needed discourse between people living in an increasingly interconnected world. I hope you’ll throw out the other motion. Thank you.

## Round 2

### Moderator
Claim: Okay. Thank you, Daisy Khan. All right, before we get to the questions, I’m now ready to present the results of the pre-debate vote. Before the debate, 177 of you voted for the proposition, 25 against, and 24 don’t know. So we’ll see if that changes. We’re now ready to begin the Q-and-A portion of the program. I will call on the questioners, and someone on each side of the auditorium will come to you with a microphone. Please stand when you ask your question, and I ask that you please make your questions short and to the point. Members of the press should identify themselves as such. Members of the audience who are not of the press can identify themselves or not as they see fit. Why don’t “Freedom of expression must include the license to offend” you, sir, ask the first question.

### Moderator
Claim: My name is Barry Fredericks. I have a question. Have you all forgotten about Gallileo? I mean this conversation about religious problems and insulting people, I mean, we’ve tried that case in the third century. Do we want to go back? I notice there are groups in the Islamic world that’d like to go back to the 13th century. But do we really want to make that argument.

### Moderator
Claim: Okay, that’s a good question. Who would like to respond.

### Conspiracy Advocate (CA)
Claim: I’m for going back to the 13th century, personally. Yeah.

Is that the question?

### Conspiracy Advocate (CA)
Claim: He was much on my mind as I came here tonight. But I thought, here I am, facing the anti-Gallilean forces once again… And I expected them to be very, very old, so this…very strange. Very strange arrangement.

### Scientific Advocate (SA)
Claim: If I can— “Freedom of expression must include the license to offend” David?

Yes, the gentleman has repeated a hoary old myth about Gallileo. He actually was not persecuted—

### Conspiracy Advocate (CA)
Claim: I find the word “hoary” offensive.

### Scientific Advocate (SA)
Claim: —for his astrological discoveries. He was persecuted for various other things. He was patronized by the Pope, and he didn’t get into trouble with the Pope until he crossed swords with the papacy on completely different issues.

### Moderator
Claim: That’s not true. He was

### Moderator
Claim: The next debate is about Gallileo, so—

### Scientific Advocate (SA)
Claim: Read some history books that have been written within the last 30 years. I have.

### Moderator
Claim: All right, why don’t we have another question? Yes, ma’am. “Freedom of expression must include the license to offend”

### Moderator
Claim: I just want to make the point, and I think this is directed at Daisy, who talked about racism and bigotry, and then just talked about her Jewish friend. You are against the motion to offend, and yet I think you offended most of the people in this room. If anybody has a comment on that, I’d like to hear it—

### Scientific Advocate (SA)
Claim: Yes, I have a comment, I wasn’t offended. I wasn’t offended and I’m Jewish—

### Scientific Advocate (SA)
Claim: My Jewish friend came to my aid and came to the aid of my community—

### Conspiracy Advocate (CA)
Claim: Nor was I, actually, I was only pretending to be.

### Conspiracy Advocate (CA)
Claim: I was just fascinated that she only had one.

### Conspiracy Advocate (CA)
Claim: I don’t believe she has one. I want to know that rabbi’s name.

### Conspiracy Advocate (CA)
Claim: It ought to be traceable. Could I suggest that she speak to some others, because really, it’s not a majority view amongst Jews, and to try and invoke her one Jewish friend to paint this majority view is quite preposterous. “Freedom of expression must include the license to offend”

### Scientific Advocate (SA)
Claim: Now what you’re saying, Philip, is preposterous. Throughout Europe, the Jewish communities were very divided over the Danish cartoon issue.

### Conspiracy Advocate (CA)
Claim: The European Jewish communities have—

### Moderator
Claim: Well, let him finish—

### Scientific Advocate (SA)
Claim: Hello—

### Conspiracy Advocate (CA)
Claim: —been virtually eradicated—

### Moderator
Claim: Let him finish, let him finish.

### Scientific Advocate (SA)
Claim: Just a minute.

### Moderator
Claim: David, go ahead.

### Conspiracy Advocate (CA)
Claim: They live here, buddy. They live here now. No. David.

### Scientific Advocate (SA)
Claim: A lot of the Jewish communities in Europe, including the Jewish “Freedom of expression must include the license to offend” community in Britain, and these views are articulated by the chief rabbi, Jonathan Sachs, who felt that the cartoons were not only offensive but were dangerous for the reasons that Daisy gave. Yes, because to many Jewish people that kind of demonization of a religion and a religious-ethnic group brought back some very sick and bad memories. That is why in Europe—

### Conspiracy Advocate (CA)
Claim: Yes, of people burning books in the street—

### Scientific Advocate (SA)
Claim: —there is a much greater tolerance of what this side of the house is advocating than on that side, which is displaying an extraordinary degree not only of disrespect but also of arrogance and an astonishing unwillingness to face a real past.

### Conspiracy Advocate (CA)
Claim: I’m highly interested in facing a real past and that’s particularly why I feel that if your belief is that by muzzling Nazis you’re making us safe, I hope you’re not watching my back when they come back at us. I’m telling you the truth. If you think that there’s a mute button, and that by saying, oh, Nazis can’t speak in public, Nazis must be put in jail. We’re going to eradicate Nazism, rather than by having Nazis in a country where you can actually speak to them and argue with them, and not dignify them by putting them on trial every time they say something completely idiotic. You’re elevating Nazis and putting “Freedom of expression must include the license to offend” them down and then inciting a couple of politicians in Europe.

### Scientific Advocate (SA)
Claim: It doesn’t dignify them. David Irving’s battle against Deborah Lipstadt exposed him for what he was, it was very effective. He had faced—

### Conspiracy Advocate (CA)
Claim: He exposed himself for what was, he said the Holocaust didn’t exist and it did. If you were to eradicate all false history you’d have to stop all newspapers, it’s ridiculous.

### Conspiracy Advocate (CA)
Claim: I beg your pardon.

### Scientific Advocate (SA)
Claim: Faced by a prison sentence, David Irving courageously renounced all that he’s previously said about denying the Holocaust. The trial was very effective, and I don’t actually agree with putting people in prison for advocating Nazi propaganda and a version of The Protocols of the Elders of Zion because that’s what David Irving does. It’s not a kind of genteel rewriting of history which Christopher seems to think. It is the most poisonous kind of conspiracy theory—

### Conspiracy Advocate (CA)
Claim: Why do I seem to think that?

### Scientific Advocate (SA)
Claim: Well, it’s what you said in your article— “Freedom of expression must include the license to offend”

To the contrary. Very much to the contrary——and what you said just earlier, that he is engaged in the revision of history. He’s not, he’s a neo-Nazi propagandist, and this is what Justice Gray said in the verdict in his battle with Deborah Lipstadt. He is a neo-Nazi political activist, and he is using distorted history to propagandize for his cause.

### Conspiracy Advocate (CA)
Claim: And nobody had much heard of him until you put him on trial.

### Scientific Advocate (SA)
Claim: Well, you can fill it, you’re a journalist, you’re supposed to know these facts. He’s a best-selling author. He’s very important guy, he gets into people’s living room. Not for a while though, because he’s in a prison cell.

### Conspiracy Advocate (CA)
Claim: Nazis always get in the living room, but—

### Conspiracy Advocate (CA)
Claim: His book, his edition of The Goebbels Diary is a very useful and interesting book that everyone who wants to know more about the period should read.

### Moderator
Claim: Let’s get some more— “Freedom of expression must include the license to offend”

### Conspiracy Advocate (CA)
Claim: For example, it’s only in that book that it’s proved that the British Union of Fascists took money from the Nazi party, a claim they’d always denied. The question is, do you think you’re big enough to read a book by David Irving and make up your own mind about it, or do you think that someone else should do that for me. Right?

### Moderator
Claim: Yes, next question.

### Conspiracy Advocate (CA)
Claim: A very simple question.

### Moderator
Claim: Alan Miller, New York Salon. I do take issue particularly with David Cesarani’s view, when he talks about how vulnerable everyone is. It’s almost like an egalitarian-speak, this notion that humans are not robust and cannot discuss ideas and make decisions and be autonomous. So my question to the panel tonight is, when it comes to the really tricky, sticky issues, like we see around children and pedophilia, or as we see on the campuses, where we see speech etiquette, or when we see in the workplaces speeches of code, would they agree with the prospect that you should have the right to be offensive, and free speech at all times. That’s my question to them. “Freedom of expression must include the license to offend”

### Moderator
Claim: Mari, can you address that?

### Scientific Advocate (SA)
Claim: The line that I draw is between the right to dissent, to express your opinion, if you’re Gallileo, to oppose the powers that be and say that the sun is the center of the universe, that’s free speech. That’s what we need for democracy to thrive. The speech that I think is of lower value and that I’m asking us to consider restricting is speech that assaults, wounds, degrades and excludes. Let me give you a specific example since you raised the workplace. It’s a frequent pattern that the first woman to show up in a traditionally male job, in the coalmine, on the oil rig, is relentlessly harassed—with words.

Men describing her body, and saying they would like to rape her, and describing what that would be like. She goes to work every day and tries to do her job, up on a construction site. I think that goes beyond offense. I think that is an effort to exclude. People use these words because they’re tied to a history of violence, because they do terrorize people, and that is their intent. Now the other side is trying to say that we’re for opening the door of censorship. I certainly don’t stand for that. I think that this audience voted in the vast majority for the proposition precisely because they distrust censorship, and that’s good, that’s “Freedom of expression must include the license to offend” important. Any effort to limit speech has to be done carefully, through the rule of law, with discernment. But we can do it. We’ve done that with defamation.

We allow people to insult each other, but we don’t allow them to destroy character and reputation in ways that the law calls actual malice. It’s very close to requiring intent. That’s a limit, that means that a lot of very nasty speech is still allowed. But we’re trying to create that breaching space so that women can go to work, so that that family that’s the wrong race can move into that neighborhood, where we can have conversations like this one that are very hard. If it degenerates into name-calling the conversation shuts down, and what I’m trying to do is prevent the conversation-ending move in a world in which we need to talk.

### Moderator
Claim: That’s Mari Matsuda, Signe Wilkinson?

### Conspiracy Advocate (CA)
Claim: One little example of how this works in the real world was in the mid-‘90s at the University of Pennsylvania. There were some kids making noise outside of a dorm room. Some guy leaned out the window and told the water buffaloes to shut up. The water buffaloes took it to the speech code people at the university. Had they not, the guy who had said “water buffaloes” would’ve been the jerk that he was, but as it turned out, then the girls who got “Freedom of expression must include the license to offend” all upset about it made a federal case out of it. They ended up looking stupid, as did the administration of the University of Pennsylvania. Water buffaloes, I mean where are you going to draw the line? It’s an animal, it’s not like saying—

### Conspiracy Advocate (CA)
Claim: A very nice animal—

### Conspiracy Advocate (CA)
Claim: —I’m going to kill you. So to me it’s like…if you let someone say something stupid, they’re the ones who look idiotic. If then you start—like David Irving, I might add—but when you start taking him on and like Christopher said giving him the platform, then it’s you who are starting to look like you can’t quite join the debate.

### Moderator
Claim: Let’s take another question. Can you hand that woman the microphone? I’m sorry. We’ll get to you next.

### Moderator
Claim: Okay, my question is the following. There was a cartoon in the New York Times a couple of weeks ago which was never talked about, and it was from Ohio. They always do a synopsis of cartoons that they think are particularly relevant—

### Moderator
Claim: Yes, we know. “Freedom of expression must include the license to offend”

### Moderator
Claim: So it was the Pope saying, “I’m sorry that my remarks about Islamic violence provoked Islamic violence.” Now, nobody made a big scene about that, but who made the big scene about the Danish cartoon, who fired up the world about the Danish cartoon. Who got it started was an Islamic cleric, who got everybody in an uproar—

### Moderator
Claim: So what’s your question?

### Moderator
Claim: So my question is, why does this happen only in this situation when it was outside of the United States, and why did it not happen here.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: Daisy, do you have a response? I think that was mostly addressed to you.

### Scientific Advocate (SA)
Claim: Yes. Well, I think what happened with the Danish cartoon was that when the cartoon was published there was a small demonstration by certain Muslim groups. The newspaper decided they were not going to pay any attention to that because they had a license to free speech and expression which was fine. Then “Freedom of expression must include the license to offend” they took it up to some of the ambassadors of Muslim countries and they were hoping that their intervention might have helped with the situation. The ambassadors called for a meeting with the prime minister, and that meeting was refused. As you know, the ambassadors were ambassadors from various Muslim countries, and they wanted to have a meeting with him. He basically said I have nothing to do with this because this is not within my realm. They called for a lawsuit, and that lawsuit was not pursued. Basically the community felt their hurts and their concerns were not being addressed. They went overseas and sought support from overseas and then the whole situation went out of control—

### Conspiracy Advocate (CA)
Claim: They started a pogrom.

### Moderator
Claim: So wait, wait, no— Christopher’s turn to—let Christopher respond—

### Scientific Advocate (SA)
Claim: No, I just want to finish the point. What I’m saying is that had it been addressed at the local level it would have never become the international phenomenon that it became. It should be addressed at the local level, like Signe did. When the Philadelphia Inquirer decided to publish that same carton, they called the Muslim community and said we want to do something “Freedom of expression must include the license to offend” about this and we want to create dialogue. Now that was responsible, that was socially responsible.

### Moderator
Claim: Christopher, go ahead.

### Conspiracy Advocate (CA)
Claim: When Dr. Samuel Johnson had finished his great lexicography, the first real English dictionary, he was visited by various delegations of people to congratulate him, including a delegation of London’s respectable womanhood who came to his parlor in Fleet Street and said Doctor, we congratulate you on your decision to exclude all indecent words from your dictionary. He said, “Ladies, I congratulate you on your persistence in looking them up.” I think anyone who understands that story, which I’m pleased to see everybody obviously does, will see through the sinister piffle we were treated to just now. If people are determined to be offended, if they will climb up on the ladder, balancing it precariously on their own toilet system, to be upset by what they see through the neighbor’s bathroom window, there’s nothing you can do about that. The Imams in Denmark did the following. First, they invited the intervention of 22 foreign ambassadors in Denmark’s internal affairs, itself a disgrace, and the Danish prime minister quite rightly repudiated it. Then they added two cartoons of their own, drawn by them, one of them “Freedom of expression must include the license to offend” showing the prophet Mohammed in the shape of a pig, then they shopped those round the Muslim world until they could get kindling going under the embassies of a small democracy in the capitol cities of countries where demonstrations are normally not allowed.

They violated Danish diplomatic immunity, they tried to sabotage the Danish economy, there were random pogroms and attacks on individual Scandinavians. And, David Cesarani says he doesn’t like the reminiscence of the 1930s that is inscribed in the cartoon. I don’t like the reminiscence of the 1930s that is involved in a Kristallnacht against Denmark, put up by religious demagogues and thugs, and that’s what needs to be put down.

### Moderator
Claim: David Cesarani.

### Scientific Advocate (SA)
Claim: I actually agree with much of what Christopher has just said. I think the response in the Muslim communities and in Muslim countries, and in countries of large Muslim populations was abysmal. But I will absolutely defend the right of Muslims to protest in peaceful ways against those cartoons and to lobby.

### Conspiracy Advocate (CA)
Claim: So would I. “Freedom of expression must include the license to offend”

### Conspiracy Advocate (CA)
Claim: So would all of us.

### Scientific Advocate (SA)
Claim: Gooooood, okay, there’s a measure of agreement.

### Conspiracy Advocate (CA)
Claim: We all agree—

### Scientific Advocate (SA)
Claim: Now, let’s see if we can push it a bit further— Wow, you—

### Moderator
Claim: Wait, wait, wait, let him finish—

### Scientific Advocate (SA)
Claim: Just stop interrupting—

### Moderator
Claim: —we had a beautiful moment of agreement. So let’s, let’s, let’s let David go ahead.

### Scientific Advocate (SA)
Claim: You’re an angry man. Let’s think about this town. New York, New York. The gentleman there asked the question about who are these marginal, vulnerable groups. It’s kind of interesting that a lot of people, certainly on that side, have decided, well, Muslim, they’re not vulnerable or marginal, they don’t need protection. If you exclude them, who’s left. Gay men…women, “Freedom of expression must include the license to offend” probably not, Jews, definitely not. But how do we get to that position where gays or Jews in this town, are so strong, so powerful, so invulnerable. So much so that when Jesse Jackson had the temerity and the misfortune to refer to this great city as Hymietown, it was the end of his political career. I don’t know how Christopher Hitchens or Philip or Signe want to talk about gay men and women, but I guess there are quite a few epithets and words they would not use—

### Conspiracy Advocate (CA)
Claim: I have no idea—

### Scientific Advocate (SA)
Claim: —to describe their lifestyle or sexual preferences. Then there’s the N word. The N word. Do you want it back? Christopher? Do you want it on prime-time TV, front page of newspapers?

### Conspiracy Advocate (CA)
Claim: I don’t want you jailing people for using it—

### Scientific Advocate (SA)
Claim: Do you want it back, do you want cartoons of lynchings?

### Conspiracy Advocate (CA)
Claim: Well, allow me to answer—

### Scientific Advocate (SA)
Claim: Is that what you want?

### Conspiracy Advocate (CA)
Claim: What kind of foolishness is this— “Freedom of expression must include the license to offend”

### Scientific Advocate (SA)
Claim: Is it all right to inflict that on Muslims but not on gay men, not on Jews—

### Conspiracy Advocate (CA)
Claim: Don’t be silly—

### Conspiracy Advocate (CA)
Claim: You’re being completely preposterous. All right, no, wait—you’re getting yourself all— you’re getting your knickers all in a twist here—

### Moderator
Claim: Okay, Philip, go ahead, answer—he asked a question, answer his question—

### Conspiracy Advocate (CA)
Claim: Allow me to say that you’re just creating a lot of fantasies for yourself that are quite ridiculous.

### Scientific Advocate (SA)
Claim: It’s not a—

### Moderator
Claim: No, wait, let, let Philip—Christopher, let Philip—

### Conspiracy Advocate (CA)
Claim: I take it as— First of all—

### Conspiracy Advocate (CA)
Claim: “Freedom of expression must include the license to offend”

### Conspiracy Advocate (CA)
Claim: I take it—

### Conspiracy Advocate (CA)
Claim: Go ahead. It’s my turn—

### Conspiracy Advocate (CA)
Claim: I am going to take it as a tribute to the superior cogency of our side that there’s this repeated change of subject from the other side. For example.

### Scientific Advocate (SA)
Claim: No, it’s not the—

### Conspiracy Advocate (CA)
Claim: Nobody says it would be a good thing if the word “nigger” appeared all the time in the press. What we say is that those who want to be offended don’t have the right to close down the newspapers that offend them.

### Conspiracy Advocate (CA)
Claim: Nor by the way is the reason that word “nigger” doesn’t appear in the press because you would jail people who put it there.

### Conspiracy Advocate (CA)
Claim: I appeal to anyone in this audience—

### Conspiracy Advocate (CA)
Claim: The advertisers wouldn’t show or— “Freedom of expression must include the license to offend”

### Moderator
Claim: One at a time—

### Conspiracy Advocate (CA)
Claim: I appeal to any—

### Scientific Advocate (SA)
Claim: Ah, the power of capital! That’s a good defense.

### Conspiracy Advocate (CA)
Claim: I appeal to any male—

### Conspiracy Advocate (CA)
Claim: It is.

### Conspiracy Advocate (CA)
Claim: I appeal to any male in this audience—

### Conspiracy Advocate (CA)
Claim: Quite proud of it.

### Conspiracy Advocate (CA)
Claim: —who might see a woman being insulted at work or perhaps on the subway or on a bus or on the street or in a bar or in a restaurant, by an obscene, loudmouthed man. There isn’t a man in this room I’m sure whose sword wouldn’t flash in his scabbard, to defend the rights of womanhood in such a case. If that wasn’t the case, there’s going to be no law that will protect women from men with Tourette’s syndrome, I’m awfully sorry to say. “Freedom of expression must include the license to offend”

### Conspiracy Advocate (CA)
Claim: May I have my turn?

### Conspiracy Advocate (CA)
Claim: It’s just an attempt to change—

### Moderator
Claim: Let’s get another question here—

I actually want to respond though to what was said— No, you can’t respond to him, he’s on your side!

No, you asked me— You asked me to respond to David Cesarani.

No, hold it, let’s let the audience—

### Conspiracy Advocate (CA)
Claim: You wanted me to respond to David Cesarani—

### Moderator
Claim: —get involved here—

### Conspiracy Advocate (CA)
Claim: —who specifically was saying that he agreed with us on a point which he previously disagreed with us on which is the idea that he thought it was appropriate that there should be peaceful protests. However, he objected— “Freedom of expression must include the license to offend”

### Moderator
Claim: Philip, really—

### Conspiracy Advocate (CA)
Claim: —to the idea that any Jewish leaders in America should peacefully protest what was being said by Tony Judd by saying that they should not be allowed to put pressure on an organization— Next—

—where he spoke. Stop.

That’s absurd.

### Moderator
Claim: Philip— Paul, go ahead, wait, Paul has a question, hold on, hold on—

### Moderator
Claim: I’d love to ask a question quickly, my name is Paul Holdengraber, I’m the Director of Public Programs at the New York Public Library. I feel for this side which is opposed because they’ve been so terribly weak and I would be surprised that after this debate there are more than two or three people on your side. “Freedom of expression must include the license to offend” But be that as it may, I would like—

### Scientific Advocate (SA)
Claim: What makes you think that?

### Moderator
Claim: Well, I would like to—

### Moderator
Claim: No campaign speeches, ask a question, Paul.

### Moderator
Claim: —simply ask this question of David Cesarani. I don’t understand why on earth you brought up the example of Tony Judd. You mentioned it, you didn’t explain it, you said nothing about it. Could you say something cogent about that at least.

### Scientific Advocate (SA)
Claim: Okay. David Cesarani.

I’ll try and be cogent. It comes back to the question that Christopher Hitchens quite correctly raised. Who decides on these speech issues, on hate speech. Now, I think that American campuses are actually exemplary in this respect, and I think the American government has found a way of demarcating what it is permissible to say and what is offensive and dangerous, without going to law. I think that sets a precedent of how you can decide. I don’t think it is terribly good when powerful individuals phone up institutions, and by the tone of their voice have meetings “Freedom of expression must include the license to offend” canceled. I think there may be very good grounds for objecting and protesting, I think it is permissible to lobby. But I think that kind of intervention is not a good idea. I certainly don’t think that we should leave the defense of the weak and the marginal up to the advertisers, which seems to be what Philip believes is the way to defend our interests.

### Moderator
Claim: Philip Gourevitch?

### Conspiracy Advocate (CA)
Claim: All I said, that he’s trying to refer to in that bizarre quip, is that the reason that you don’t have the word “nigger” or that you don’t have a lot of the derogatory images that he was sort of proposing in a heated moment that—would you like to see these things returned to the public airwaves, ohhhh, was that they’re not on the public airwaves not because we’ve actually outlawed them and thrown everybody in jail in Austria as you advocate, but actually because— No, I said—

—they’re not on the public airwaves. Because one would not get an audience for them because people would protest those stations because people would make firm phone calls exercising their freedom of speech to say, you know what? We don’t want “Freedom of expression must include the license to offend” anything to do with you. You have no basis, I bet, you’ve never made a phone call, you’ve never asked a question, and you’ve done no reporting to find out whether Abe Foxman made that call, which has never been proven. I sit on the board of Penn and we raised the Tony Judd question. Absolutely nobody could ascertain whether or not Abe Foxman made that call. He may have made it, or he may not. Somebody made the call. But you’re—

### Conspiracy Advocate (CA)
Claim: But he does have Tourette’s syndrome—

### Conspiracy Advocate (CA)
Claim: —very, very, very confident— You’re very, very confident in accusing of somebody in public of something that you know nothing about—

### Moderator
Claim: Let’s have another question—

### Conspiracy Advocate (CA)
Claim: —which is gross ignorance, but no, I would like to finish something for a minute, Jeffrey. I’m not done. A gentleman with a British accent asked a question earlier of David Cesarani which he ducked very carefully. He raised the question, why is it that you’re so nervous about the broad public in his criticism of Enlightenment thinking and of Mill and of this one and that one. He sort of yearns for a clubby time, when you could count on a “Freedom of expression must include the license to offend” few select elites having a kind of common agreement. And that now what’s dangerous to him is the proliferation of voices, the idea that there are many ideas out there on the Internet, oh my goodness, and we can’t regulate them, and they might get in the hands of the wrong people and we can’t even agree who they are. For goodness sakes, those clubby people, as they put it, you know, even the Jews can have an opinion. I mean, why are you so concerned that there might actually be some unregulated voices out there?

### Moderator
Claim: You know what, let’s just go to a question.

### Moderator
Claim: I think that it’s sometimes a lot harder to defend very hateful, personal speech, like when hate groups leaflet the lawn of a neighborhood where a black family has just moved into a white neighborhood.

### Moderator
Claim: We’re running low on time, so get to a question, please.

### Moderator
Claim: But Daisy, do you really think that it’s a problem that we had cartoons that were… unfortunately distasteful to Muslim people, but cartoons in a newspaper that were quite humorous really, and I think they were talking about quite a legitimate political issue. Do you really want to ban that kind of free speech? You “Freedom of expression must include the license to offend”

### Moderator
Claim: don’t want to allow editorial cartoons?

That’s a fair question, but we’ve sort of done this question, we’ve done the Danish cartoons— We’ve done this question, yes, yes, it’s a waste of a question—

I think that’s a good point. Up there at the top.

### Moderator
Claim: I would just like to know, and I’ll be the first to admit that I was not aware of this whole discussion about the cancellation of this meeting. But when Mr. Foxman, or if anyone who called and got it canceled did so, were death threats part of the reason— Of course not—

### Moderator
Claim: No, they were not, you know, let’s—

### Moderator
Claim: Okay, thank you—

### Moderator
Claim: I mean, let’s put Abe Foxman and Gallileo aside and—

### Conspiracy Advocate (CA)
Claim: I do have a jot point that I would like to make. “Freedom of expression must include the license to offend” Oh—

I’ll make it quickly.

### Moderator
Claim: Okay, quickly, Christopher.

### Conspiracy Advocate (CA)
Claim: After my punch-up with George Galloway recently I was asked by the Republican Jewish Committee in Washington to come and speak to their ‘do down at the Old Temple and talk about the oil- for-food program and other things like that. They put my name on the bill, and then a gentleman named Mort Klein who some of you will know… He’s a madman who runs the Zionist Organization of America. He kicked up a terrific fuss because of some remarks I’d once made about Theodore Herzl, among other things, and got the meeting canceled.

Now, I don’t particularly complain about that as a matter of fact, and I don’t share in the tremendous steambath of self-pity that Mr. Judd has managed to generate. You have a right to your opinion. You don’t have necessarily have a right to the audience of the Republican Jewish Committee. They can decide not to have you. That’s okay. I’m just trying to say, just for once if we could stop people intruding things that “Freedom of expression must include the license to offend” don’t belong in this discussion, it’d save such a lot of time.

### Moderator
Claim: Two more questions, this gentleman right here.

### Moderator
Claim: Where do you draw the line between free speech and political correctness.

### Conspiracy Advocate (CA)
Claim: Another—

### Moderator
Claim: You know, that’s sort of—

### Conspiracy Advocate (CA)
Claim: Waste of a question—

### Moderator
Claim: We’ve been dealing with that issue generally, why don’t we get to this gentleman over here.

### Moderator
Claim: Back here?

### Moderator
Claim: No, this gentleman in the white shirt, get a microphone.

### Conspiracy Advocate (CA)
Claim: Stupid, boring questions should be disallowed.

### Moderator
Claim: No, but we need the microphone for radio purposes though. You can’t speak loud enough so that all of WNYC can hear you. “Freedom of expression must include the license to offend”

### Moderator
Claim: Thank you, just a quick question. One of the things I noticed on the panel is that no one talked about the civil rights movement and how that’s affected the topic here. Also, just quite frankly, how come there’s no African-American people on the panel? I’d just like to get your thoughts on that.

### Conspiracy Advocate (CA)
Claim: Next.

### Moderator
Claim: Well, I mean I think that’s a point that everyone can take for what it’s worth. At the end?

### Conspiracy Advocate (CA)
Claim: That was useful for the radio audience—

### Moderator
Claim: At the top, at the very top, underneath the light. That’s you, go ahead.

### Moderator
Claim: Okay, this is a question for Mari. You talked about women in the workforce. I don’t work on an oil rig, but I do work on a trading floor. I’m just wondering if you think that by limiting what people can say to me, if that’s actually protecting me from what people are thinking about me, and whether when I come into the office, I need to take care of myself. “Freedom of expression must include the license to offend”

### Conspiracy Advocate (CA)
Claim: Good.

### Moderator
Claim: Mari?

### Scientific Advocate (SA)
Claim: I trust that you can. But there are circumstances in which women have left jobs because they could not handle the relentless and brutal assaults on their personhood. This is why in civil rights law, to—

### Conspiracy Advocate (CA)
Claim: Not free expression.

### Scientific Advocate (SA)
Claim: —respond to the earlier question—

### Conspiracy Advocate (CA)
Claim: Not a free expression— Wait, wait.

### Scientific Advocate (SA)
Claim: The reason in civil rights and anti-discrimination law we do limit speech in the workplace, is that ideas about your inferiority, about your inherent lack of worth as a human being and your lack of entitlement to equality in the workplace, if they’re expressed regularly to you, create an environment in which it’s impossible for you to do your job on an equal basis with everyone else. “Freedom of expression must include the license to offend”

### Moderator
Claim: Does someone on this side want to address the point Mari’s made, which is that there is kind of speech, harassment. Is that speech you seek to protect?

### Conspiracy Advocate (CA)
Claim: I get that kind of speech all the time. One of my favorites was being called a liberal cocksucker. Now, I don’t know whether that means I like to cock-suck liberally or I only suck liberal cock or I just am not quite sure. But I didn’t call the police on it. Furthermore, half the people who write me horrible, horrible things, no one has seen my mail, they all start it, “Dear Mr. Wilkinson.” So it’s not me as a woman, it’s the ideas I put in the paper, and if we can’t discuss those ideas, even when they talk to me in loathsome, funny ways, we can’t talk.

The one thing I would like to say about the whole Danish cartoonist thing is this. Having had that confrontation has changed minds on both sides. The BBC reported that about two weeks ago there was another minor dust-up about it. But the reason you didn’t hear about it is because the Muslim side realized that it really wasn’t great PR to kill people in Pakistan to protest cartoons in Denmark. So it’s a much different protest, it’s “Freedom of expression must include the license to offend” been handled differently on both sides, including the Danish side. This is how we learn. We learn by conflict, we learn by calling each other things that, ehh, well, maybe weren’t a great idea at the time, but we can do it differently next time.

### Moderator
Claim: Forgive me for interrupting, but it’s now time to vote. If you want to vote for the motion— everybody’s got their cards—you want to tear off the greenish-blue, kind of aqua side. If you want to vote against, you tear off the red side. If you don’t know where you stand, you just put the entire ticket in the box. Now, can I ask everyone to please vote quietly. The boxes will be passed around.

### Conspiracy Advocate (CA)
Claim: How long does this take.

### Moderator
Claim: No, it’s going to go on while you—you’re going to talk while they’re doing it. You can start right away.

### Conspiracy Advocate (CA)
Claim: All right.

### Conspiracy Advocate (CA)
Claim: Wait. Who stars?

## Round 3

### Moderator
Claim: While you’re voting we’re going to go to final statements. The order is, please begin against the proposition, Mari Matsuda. You can stay where you are. “Freedom of expression must include the license to offend”

### Conspiracy Advocate (CA)
Claim: We docked some of her time, remember. We docked some of her time.

### Moderator
Claim: Yes, we did dock some of her time.

### Scientific Advocate (SA)
Claim: The “N” word is hollered out from a passing car to let a black man know that he is not walking in a neighborhood where he is welcome or safe. The speaker knows the effect of that word, and uses it precisely because it terrorizes. I asked earlier: why is it that we recognize in American law that if someone spits on your shoe, that’s an attack on your person, but we won’t recognize words that we know, socially, historically, from the reality of the human lives that we live, have exactly the same effect on your personhood and your ability to move freely? I am talking about liberty and it’s fascinating that we are all coming from the Enlightenment tradition. As much as we disagree, I feel affinity with people on the opposing side because we are all concerned with losing our democracy and losing our freedom.

I think there are forms of speech that make us less free because we stop talking to each other and we don’t have the conversations we need to survive. Allowing this kind of invective perpetuated… Daisy has been out on a limb by herself defending the Muslim “Freedom of expression must include the license to offend” community and I have to speak up. There is hatred of Islam in this country and it’s not a healthy thing. There’s also ignorance. We need to open a space where we can talk to each other, disagree, criticize, and learn, and that space closes when people are allowed to assault. I’m not asking for censorship, I’m asking that if you support the proposition, you’re making a choice for a license to assault. Daisy, that—

If you oppose it— That’s it—

—you open the door for a conversation about limits.

### Moderator
Claim: Okay, next. Thank you. that was Mari Matsuda. Now for the proposition, Signe Wilkinson.

### Conspiracy Advocate (CA)
Claim: Well, I basically said earlier pretty much what I think here. I’ll just go back to what Christopher said. This is a conversation. If you forbid someone to say what’s truly on their mind, you won’t know what is on their mind. It’s better almost every time, it seems to me, to find out what it is, and then be able to deal with “Freedom of expression must include the license to offend” it. I think that some of the questions get back to what is truly hateful speech and our history is filled with, for example, horrible images of black Americans who were made fun of simply because they were black, and these images occurred everywhere, in Courier and Ives and all of the major publications in the United States.

But the way that changed was not by someone saying, you may not ever, ever do a bad caricature of a black person. It was changed because the civil rights movement and black Americans showed through their own incredible endurance and persistence in going for equal rights in this country, that that movement made those images look awful. You can’t look at them today without wincing. It says more about the people who drew the cartoons than about who they were drawn by I feel sorry for you in New York because you don’t have very many really bitter cartoons published here, the New York Times protects you from that. But I really urge you to go on the Web, find out what people are thinking, and you’ll find out through cartoons among other pieces of free speech.

### Moderator
Claim: Thank you. Thank you, Signe Wilkinson. Against, David Cesarani. “Freedom of expression must include the license to offend”

### Scientific Advocate (SA)
Claim: I think what Signe said then about the struggle of black Americans to eradicate racist images from public media was very interesting and very important. It was about equal rights. There was a loss. There were some cartoonists who made a living from, you know, making fun of black people and depicting them in ghastly ways who probably went out of business, or just migrated to certain parts of America where that sort of thing is still tolerated. Elsewhere, however, the dignity and equality of black Americans—as is true of women, gays, and other groups who used to suffer demeaning and degrading images and speech acts—and the need to create and preserve a civilized, civil society, in which civility and respect of one for another is absolutely vital, triumphed. Dignity, equality and civility are values. They are goods. Our freedom of expression is a value, and it is a good. On this side we’ve simply been asking you to weigh up those values, those goods. We think that human dignity, equal treatment, and having a truly civil society is worth a modest, preferable voluntary degree of constraint, restraint, a kind of humility. Knowing where to draw the line. Thank you.

### Moderator
Claim: Thank you. David Cesarani. Now, for the proposition, Philip Gourevitch. “Freedom of expression must include the license to offend”

### Conspiracy Advocate (CA)
Claim: The proposition is, freedom of expression must include the license to offend. I would return to the idea that this is fundamentally the lesser of various not-ideal prospects. The other prospect is that one licenses someone to determine what offends, and that one is always at the prey of that question. Who is to judge, who is to decide, how are we to restrict their ability to license our ability to offend. In other words how are we to restrict their ability to restrict us. At what point does this admittedly slippery slope immediately become this greased precipice, and we fall off into a very dangerous situation.

The other side says, speech is dangerous, speech can be hateful, there’s hatred and ignorance out there, and therefore they want, in some way, to muzzle the people they fear are dangerous. I agree with them that speech can be dangerous and that there is a great deal of hatred and ignorance out there. We’ve heard a good deal of ignorance even tonight. I feel that that is why I urge you strongly to listen to the dangerous speech you’re hearing from the other side, and recognize exactly how it can impinge upon your ability not only to speak but to think. The fact that they keep using this strangely castrated phrase, “the ‘N’ word.” Which is supposed to be inoffensive, but is actually doubly offensive because it restricts you from the ability to hear the full offense of “Freedom of expression must include the license to offend” the word “nigger.” They’re at every time trying to double back and triple around and make you use words and trip over your own mind and not think and not speak what actually might occur to you in your effort to observe reality and contend with it. I think that’s a very dangerous predicament, I think that they’re presumptuous and wild in their notion that we can do that reasonably, and I think that we are at less risk taking the great risk of freedom.

### Moderator
Claim: Thank you, Philip Gourevitch. Against the proposition, Daisy Khan.

### Scientific Advocate (SA)
Claim: If all of us here wanted to offend each other, I’m sure we can. But would it be beneficial to building trust, and building long-term relationships? I was stunned at the response I got about my rabbi friend. It is because I had been dialoguing with the Jewish community—

### Conspiracy Advocate (CA)
Claim: What Jewish friend.

### Moderator
Claim: Stop. Enough.

### Conspiracy Advocate (CA)
Claim: What rabbi friend. “Freedom of expression must include the license to offend”

### Scientific Advocate (SA)
Claim: Yes, your question has been registered. Daisy, please continue.

It is the deep dialogue that has been going on between me and the Jewish community that has resulted in that concern for our community. It is out of that concern that the rabbi friend reached out to me and said, do not let this happen to you. So I was a little shell-shocked at the reaction we got from people here. As I mentioned, we’re living in a tense global environment, where misunderstanding is increased by peddlers of fear, and overpowered by intolerance. Today what is needed is civility, tolerance, patience, and sincerity. We need to get rid of negative words like “offend”—it’s a neighbor word—and replace them with positive words like “befriend.” Only once you make the effort to understand the perspective of the other person can you begin to understand the rationale behind their actions and thoughts. Furthermore, you’ll be in a better position to influence them, and only then can you even begin to be critical. We humans have a nasty habit of judging the book by its cover. If you’re offensive, it is difficult to make a difference because you’re seen as hostile, and your views are unwelcomed and outright rejected. This is human nature. “Freedom of expression must include the license to offend” No doubt it is essential to be critical. But do so at the right time, in the right environment, and with the right choice of words. Sticks and stones are not the only things that break bones, ladies and gentlemen, words do too. On a personal note, the reason I’m here today and I’ve dedicated the rest of my life to furthering understanding between peoples has to do with my powerful memories of my childhood in Kashmir. I went to Catholic school, was taught by Irish nuns, learned math from Hindu professors, played with Sikhs and Buddhists and was told the tale of how Kashmiris were from the lost 10th tribe of Israel. I was exposed to this broad perspective of unity and diversity, where celebrating and honoring each other’s traditions and beliefs was a way of life, but alas, this heaven turned into hell too.

If all of us here wanted to offend each other, I’m sure we can. But would it be beneficial to building trust, and building long-term relationships? I was stunned at the response I got about my rabbi friend. It is because I had been dialoguing with the Jewish community—

### Moderator
Claim: Thank you, Daisy Khan, against the proposition. Finally, for the proposition, Christopher Hitchens.

### Conspiracy Advocate (CA)
Claim: The real question, or if you like, subtext question before us is this—is nothing sacred. What we’ve really been discussing is the old question of whether or not there is such an offense as blasphemy or profanity. Now if I don’t tell you exactly what I think about the simpering speeches that we heard from the other side, I’m not censoring myself, I’m just being polite and civil and saving some of your time. What I will not prevent myself from “Freedom of expression must include the license to offend” saying, and will not let anyone else prevent me from saying, is the following. It is wrong and always has been for churches, powerful, secular, human institutions, to claim exemption from criticism, which is what’s really being asked here. If there’s going to be respect, it has to be mutual. Does Islam respect my right to un-belief? Of course it does not. Does it respect the right of a Muslim to apostasize and change belief? Of course it does not. I can name now four or five friends—six or eight, maybe, if I had time—five or six you would certainly have heard of—who have to live their lives under police protection for commenting on Islam. For having an opinion on it. This is getting steadily worse all the time, and it’s grotesque. Here is an enormous religion with gigantic power that claims that an archangel spoke to an illiterate peasant, and brought him a final revelation that supercedes all others.

It’s a plagiarism by an epileptic of the worst bits of Judaism and Christianity. That’s obvious, it seems to me. How long do you think I’m going to be able to say that anywhere I like? It would already be quite a risky thing to say in quite a lot of places. I did not come to the United States of America 25 years to learn how to keep my mouth shut. I’m going to reject all offers that I change that policy, however simperingly they are put, okay? “Freedom of expression must include the license to offend”

### Moderator
Claim: Please join me in thanking the debaters for a terrific work. Now it’s time for me to announce the results. As you recall, just to refresh your memory, before the debate was 177 for the proposition, 25 against, and 24 don’t know. Now, the result is 201 for the proposition, 39 against, 1 doesn’t know. So please congratulate the “for” team for winning the debate. I’d like to invite everyone to return next month for the third Intelligence Squared debate, Wednesday, November 29th here at the Asia Society. The motion to be debated there has nothing to do with Abe Foxman or Gallileo. The subject is “A democratically elected Hamas is still a terrorist organization,” and it will be moderated by Judy Woodruff. An edited version of tonight’s Intelligence Squared debate can be heard locally on WNYC-AM 820, on Friday, October 27th, at 2 p.m. Check your other NPR listings for other broadcasts outside of New York City. Please be sure to pick up a copy of media sponsor Thursday edition the Times of London and a Times Literary Supplement on your way out. Thank you all for coming.
