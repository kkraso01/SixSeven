# Debate Transcript

Topic: Too Many Kids Go To College
Motion: Too Many Kids Go To College

Debate ID: college


## Round 1

### Moderator
Claim: Intelligence Squared exists because of the efforts of Robert Rosenkranz, who brought it to the United States and has made this thing grow and spread. And it's been a terrific effort. And tonight it's a feather in his cap and our cap. So ladies and gentlemen, Mr. Robert Rosenkranz.

### Moderator
Claim: Thank you, and welcome. We're so pleased to be here in Chicago and proud to be a partner with the first Chicago Ideas Week. My role in these proceedings is to frame the debate, to outline the reasons we felt it was worth having. Tonight's motion is so counterintuitive one might wonder why we chose it as a topic. After all, there seems to be ample statistical support for the value of a college education. College graduates earn about $20,000 a year more than high school graduates, nearly half a million dollars over their lifetimes. Some 9.7 percent of high school graduates are currently unemployed compared with 4.2 percent of college graduates.

So going to high school and not college doubles your chance of being unemployed. In a rapidly changing global economy, many of the traditionally high-paid jobs in manufacturing that high school graduates could get are gone forever. And employers are looking for the kind of cognitive skills that we normally associate with college graduates. And turning from material considerations, a liberal arts education is likely to produce a superior electorate, a more vital civil society, a citizenry with better understanding of American ideals and better ability to adapt to changing circumstances. And on a more personal level, a Chicago reporter asked me how I, transcending an obscure family background through scholarships to Yale and Harvard Law School, could possibly entertain tonight's motion.

So what is the counter argument? It is that only a small percentage of high school graduates actually have the aptitudes to do well with colleges of reasonable quality. The majority of those enrolling in college lack the basic skills and aptitudes to take pleasure in the experience or otherwise to succeed. For such students, college becomes an extended adolescence and at best a remediation for inadequate high schools. But not a grounding of the essentials of cultural intelligence and such basic skills as expository writing or quantitative reasoning or scientific method or primary research. Might not such students get more from vocationally oriented education of the sort they would likely receive in such successful economies as Germany and Switzerland?

In those countries, by the way, only about 20 percent or so complete four-year degree programs compared with double that figure in the U.S. And for the students at the very top of the scale, at the most elite colleges, might college prove an impediment to creative thinking or a distraction from their entrepreneurial drive? What lessons might we take from the extraordinary contributions of such college dropouts as Bill Gates, Mark Zuckerberg, Larry Ellison and Steve Jobs? Well, your role tonight is to listen to the arguments, to question the panelists and ultimately to decide which side was more persuasive. Whatever you decide, I hope you will come away with the sense that on this issue, like so many others that seem at first blush to be one-sided, that there is an intellectually respectable position on both sides of the debate. And with that hope, I turn the evening over to our moderator John Donvan and this extraordinary panel of experts gathered for our first live debate in Chicago.

Thank you, John.

### Moderator
Claim: Thank you, Robert. And may I just invite one more round of applause for Robert Rosenkranz for making this possible. True or false: Too many kids go to college? That's what we're here to debate, another verbal joust from Intelligence Squared U.S. I'm John Donvan from ABC News. We are at Venue Six10 at the Spertus Center in Chicago. Too many kids go to college. Two teams will argue that proposition from opposite sides, for it and against it. All of our debaters come to this from different perspectives, all of them are trying to win you over because you, our live audience, will act as the judges. And only one side will win. So let's meet our panelist of debaters. The motion being, "Too many kids go to college." The team arguing for the motion include tech entrepreneur, investor and philanthropist, Paypal cofounder, Peter Thiel. teammate is a political scientist who sees the Bachelor of Arts degree as a source of class division. American Enterprise Institute scholar, Charles Murray. Opposing them at the facing table and arguing that it's not true that too many kids go to college, one of Northwestern University's most transformative leaders, president emeritus, Henry Bienen. And joining him, an entrepreneur turned academic, he is also a columnist for the Washington Post, Vivek Wadhwa. So this is a contest. It's a debate. One side will win, and one side will lose. And you, our live audience, will hear them debate for three rounds, and then you will choose the winner by voting once before the debate and once again after the debate.

So let's go to the first debate now. If you go to the key pads on your seats, only pay attention because on the right hand side is the one that's relevant to you. Pay attention only to keys number one, two and three. The others are irrelevant. If you agree with the motion that too many kids go to college, if, at this point, you agree with the side-- this side that's arguing that point of view, push number one. And if you disagree with this side, push number two. And if you're undecided, push number three. And if you think you made a mistake, just correct it, and the system will lock in your last vote. So remember, we have three rounds of debate. After the third round of debate, we ask you to vote again, to tell us who you think presented the best argument. And the team that has moved its numbers the most will be declared our winner. So on to round one, opening statements by each debater in turn.

They are seven minutes each. These statements are uninterrupted. Our motion is "Too many kids go to college." And speaking first for the motion, I'd like to introduce Peter Thiel who is making his way to the lectern. Peter Thiel changed our world and the way we do business by cofounding PayPal. He is the creator of that online payment system as well as an early investor in Facebook. You have now, Peter, stunned the world with your-- with your decision to offer grants of a $100,000 to people under 20 who forego college at least for a time to take on some sort of entrepreneurial task, which is going how?

### Conspiracy Advocate (CA)
Claim: Just got started, but we selected 24 students for the first two-year cohort. And they've been starting over the last month or two, and it's off to a really great start.

### Moderator
Claim: All right, sir. A bit awkward fact, Peter Thiel himself, Stanford 1989.

### Conspiracy Advocate (CA)
Claim: 1989.

### Moderator
Claim: BA in philosophy. 1992, law degree, Stanford University.

### Conspiracy Advocate (CA)
Claim: That is correct. I'm going to start with that fact, actually, but yes, that is very true.

### Moderator
Claim: We're going to be looking for an explanation. Ladies and gentlemen, Peter Thiel.

### Conspiracy Advocate (CA)
Claim: Thank you. Let me actually just start with that question. You know, I went to Stanford undergrad, Stanford law school. Throughout the '90s, I had a belief that education was absolutely paramount. We should only hire people that went to the best schools. And - - and we discriminated on this basis very aggressively in hiring at PayPal. And I use this - - and I used to-- I thought this was the most important thing in our society. And over the last four or five years, I've gradually come to shift my views on it for a number of different reasons. The narrow technology context in Silicon Valley, that I saw so many very talented people who had not gone through college tracks and who had still done extraordinary well. In some ways, they were also more creative.

They were not laden down with enormous college debt that was somehow forcing people to take better paying jobs that were more munitive but more boring, and track them into things that were not as interesting or important, that were discouraging people from doing things in nonprofit work or on the more entrepreneurial side. And this has become a more and more acute issue over the years because unlike the time when I went to college, the cost has gone up tremendously. The amount of debt that people leave college with have gone up tremendously. And so the choices are very different from the ones people had 25 years ago. College costs in nominal dollars have gone up by more than a factor of 10 since 1980. Even after inflation, it's gone up by 300 percent. Costs about four times as much. Inflation adjusted to go to college now as it did 30 years ago, it's gone up more than anything else in our society, more than health care, more than housing, more than any of a number of other things we think of as having been subject to runaway cost inflation and escalation.

And as I looked outside of just the narrow Silicon Valley entrepreneurial context I've come to believe that the problem is much broader, it's not just the most talented people who are perhaps being misdirected and encouraged to go on a very narrow tracked career, but that this is a broader problem and that we are in fact experiencing something of a bubble in education, a bubble that is as pernicious as the bubbles we had in technology in the '90s and housing in the 2000s, and like those two other bubbles is characterized by two things, number one, runaway costs where people are paying more and more for something where the quality hasn't gone up-- in the '90s it was tech stocks, in the 2000s it was housing-- education, I'm not saying it's worse than it was 30 years ago but I don't think it's gotten much better, and secondly by an incredible psychosocial dynamic where you cannot question it.

And in '99 in Silicon Valley you couldn't question the NASDAQ valuations, and in 2005 you could not question people buying houses, it was strictly taboo and forbidden, and in the same way this is the one thing people still really believe in our society. And to question the value of education is like questioning existence of Santa Claus with three- year-old kids or something like that. And while we're not trying to scare the children here or anything like that, we do think that we cannot afford to have a third bubble in this country. We had two already. They were catastrophically bad. They led to enormous misallocation of resources. And when we look at education more carefully there are a lot of worrisome signs. Student debts at this point total over a trillion dollars, and when you look at how well people are doing who come out of college, they are still doing pretty well, they're still doing better than they used to, but the outperformance has been going down, and going down since about 2000.

And, you know, the law school context I'm quite familiar with, there are about 50,000 people a year who graduate from law school in the U.S., there only are 30,000 legal jobs available in the U.S. and I would argue we have maybe too many lawyers as is, but we're producing way more for a society that probably already has too many. The median wage for lawyers is 62,000 which isn't that great considering that you've taken on another quarter million in law school debt typically. Pre-med, only about nine percent of the people who study pre-med have slots available to them in medical school. The other 91 percent are wasting their time, and somebody should have told them that their freshman or sophomore year and not waited till their senior year or several years of post college to figure that sort of stuff out. If you broaden the ambit more generally, there's something like 17 million people in the labor force who have college degrees and are basically doing unskilled work or find the narrow and extreme statistics, there's something like 6,100 people in the U.S. who have Ph.D.s and are doing janitorial work.

And so when we say that education is important and paramount, that is true but it can also be a distortion and it can be a distraction from some of the very real problems we have as a society. We need to figure out how do we create more jobs, how do we create more good paying jobs. We don't have enough of either in our society. And while education is linked to them, it's not this absolute thing. And we want to question this notion that education is an absolute good or an absolute necessity. And in fact when people say as our opponents do that it is an absolute good or an absolute necessity, you start ignoring all these problematic facts, you start making a lot of catastrophic approximations that abound. And that's what we want to sort of push back a little bit. Let me say one thing that we're not arguing for. We're not saying that nobody should go to college. We're not saying that college is categorically a bad thing.

We're not saying everybody should drop out. We're simply saying that too many people are going to college, just like too many people are buying houses and too many tech companies were going public in the late '90s, doesn't mean there should be no tech companies or no houses, it doesn't mean we should shut down all the colleges, but we shouldn't-- we need to make this a much more careful deliberate choice. And what we are hoping to start with this discussion and debate today is a discussion that would encourage all of you to think more about your future. Do not think of education as something that's an automatic ticket to the future, you need to think about it yourself. If I had to do something over again, having gone to Stanford, I probably would still go to college even with the higher costs, if I didn't have any great ideas of what to do instead I'd probably still do the exact same thing as I did in the late '80s even with all the problems. But one thing I would try to do very differently is not accept the answer that this was the automatic thing, that this was the thing you should do without thinking, I would have tried to think about what I want to do with my life as a senior in high school and a senior in college and not simply have more education be the automatic default answer for everything.

The question we want to push the other side back on a little bit is if education is an absolute good or absolute necessity, who is accountable if it is a mistake? And if these people are taking on these enormous debts are getting it wrong, where can they go to get a refund?

### Moderator
Claim: Peter Thiel, your time is up. Thank you very much. Our motion is "Too many kids go to college.” And here to speak against the motion, Henry Bienen. He is president emeritus of Northwestern University. And Henry, in the nearly 15 years that you were there, the university’s success really was and is recognized as your success during those 15 years. The school increased its endowment 15 times. The sports team won more titles. Applications skyrocketed. You launched a Center for Nanofabrication and Molecular Self-Assembly. Let Harvard eat that, right. you know these guys at the other side are saying that you’re a denizen of the system that they say is in a bubble. So you’re going to need to impress them.

### Scientific Advocate (SA)
Claim: It’s a joint effort to make a great university. Thank you for that, John. It took a lot of people working hard.

### Moderator
Claim: Henry Bienen.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: Ladies and gentlemen.

### Scientific Advocate (SA)
Claim: Well, thank you all for being here, especially Mayor Emanuel. Thank you for coming. You gave a great speech this morning on the budget. This is an important debate. It’s about the American dream. It’s about social mobility and American democracy. Because the answer to the question as to whether too many kids go to college is fundamentally about what kind of a society we hope to create. I care deeply about this issue. I’m an educator, 28 years at Princeton, 14.5 years as Northwestern’s president, now chair of a proprietary for-profit college, Rasmussen College, and a member of the Board of Education, appointed by the mayor for the Chicago Public School System. Sure, some dropouts make it big.

But social and economic policy should be informed by data and analysis, not anecdotal individual life histories, no matter how compelling. Most people are not Bill Gates or Steve Jobs. We should not misread particular circumstances at particular moments in time as an indication of likely long outcomes. As Damon Runyon once said, “The race is not always to the swift nor the battle to the strong, but that’s how the smart money bets.” The argument that too many people are going to college is not new. In his youth, Richard Freeman, a Harvard economist, argued this in “The Overeducated American” in 1976. He was wrong then, and our opponents are wrong now. And by the way, he’s changed his mind. We now have studies and lots of information. Mr. Rosenkranz alluded to some of them, which should persuade anyone with an open mind that more years of school, post-secondary, are positively correlated with earning over one’s lifetime, and also correlated with lower rates of unemployment and shorter duration being unemployed when a higher degree is not obtained. 4.3 percent of college graduates are unemployed. More than triple that number of high school students or high school dropouts are unemployed. This is very compelling. There’s a clear wage premium to education. There’s also a social premium to society, not just individual. Society benefits through greater productivity, lower crime, better health, better citizenship for more educated people. And the wage premium to education has been growing since the 1980s, not shrinking. The question to be decided is whether it’s true that too many kids go to college. Fact: In 2010, about 66 percent of the United States population between 25 and 30 had some college experience. The rest were high school grads or high school dropouts. It’s hardly the case that everyone or too many are pouring into college.

We need more, not fewer, college graduates. Going to college in the United States, by the way, means very different things. From two-year community colleges, flagship public research universities, small denominational colleges, elite privates, and for- profits. By the way, at the for-profits, the average age of the students is 28, and these are not kids. Many of them are single mothers. Many are minorities. They don’t choose to attend such a place for a liberal arts education or because we have great athletic teams or a climbing wall. They come to improve their careers, their income, their life chances, and they do. In his articles, Mr. Murray argues that too many people are going to college, and I feel he believes in innate qualities. He uses a language like, “He does not have it in him.” But how does he know this? What measures does he have for a great understanding of cognitive abilities or their impact? He believes, I think, that abilities are fixed.

It’s a highly stratified view of the world and people’s places in it, and I don’t share it. True, plenty of people who graduate high school are not college ready. We know this in Chicago. But low college graduation rates and dropout cannot be attributed everywhere and completely to individual's intelligence or competence. Even some qualified students in high school may not attain to a four-year degree within six to eight years because of their lack of resources which compels them to leave and drop out. No doubt, some people don't have the smarts or the personality skills to succeed. But for many, their environment at pre-college school systems have played a big role in not preparing them. We should not be so ready to consign them to what Mr. Murray may feel is their fate. Neither they nor our society will benefit from pushing them into what, for many will be low-level jobs. Because for every college degree holder who is a janitor or a waitress, there are thousands of times janitors and waitresses who are high school dropouts.

Mr. Thiel has acknowledged a correlation in his own writings between college attendance and higher income. But he doubts the direction of causation. That is, college may pay off for some people because smarter people go to it. In my view, whatever the direction of causation, you can learn skills at college and improve your life chances. And by the way, we have lots of studies, including studies of twins that Allen Kruger and others have done which shows you can isolate the college experience itself among all the other variables which count. And college does make a difference. Now, high school vocational alternatives are there, but they're not widely regarded as-- they're widely regarded as second best by the general public. Polls show that most Americans agree that everyone does not need to go to college. They support alternatives for other people's children. I wonder if those in favor of the proposition want their own children or relatives to not go to college.

Mr. Thiel, Mr. Murray, I know Mr. Thiel has started this fund, and I applaud his generosity. It is very generous. Will he fund tens of thousands, millions? All the trend lines show a shift in the U.S. economy and its labor force towards more people requiring post secondary education because growth industries require post secondary education. We've hollowed out industrial jobs. The clear way to premium for college graduates is growing. It skyrocketed in the 1980s and 1990s. Advanced degree holders did vastly better, and their advantage continues to hold up. And by the way, for women, that wage premium is even higher than for men. I need to conclude, but I want to conclude by saying there are not many alternatives in the U.S. We don't have a vocational system like Switzerland or Germany. I'm not against building such a vocational system. I'd like to see more tracks that people can go to. But what we really need to do is do better in pre-K through 12.

We cannot accept that too many kids go to college. In summary, those who go beyond secondary school are-- not all kids. There are not too many of them. I'm not willing to consign them to low-level jobs. We need to do better, and we can't give up on the American dream. Thank you.

### Moderator
Claim: Thank you, Henry Bienen. So a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have two teams of two members each arguing out over this motion: "Too many kids go to college." You have heard the first two speakers, and now onto the third. Charles Murray is the W.H. Brady scholar at the American Enterprise Institute. And Charles, you rather famously said that it was thanks to an SAT exam in 1961 and your fabulous score that you were able to get out of a small town in Iowa.

### Conspiracy Advocate (CA)
Claim: That's what I thought at the time.

### Moderator
Claim: And into Harvard. Well, I want to come back to that because-- so you went Harvard.

You did well in the liberal arts environment. Then you kind of moved onto the conservative arts, and you-- A trend setter in terms of thought on issues such as welfare where your writings had impact on policy. Your book, "The Bell Curve" despised by the left, and you like that. And I want to know where you are now on the SATs that got you out of Iowa.

### Conspiracy Advocate (CA)
Claim: Oh, I now recommend that we abolish the SAT, because it turns out that if they give an achievement test, I probably would have gotten into Harvard that way too. And the SAT, as it now exists, has taken on a really bad number.

### Moderator
Claim: Ladies and gentlemen, Charles Murray.

### Conspiracy Advocate (CA)
Claim: I think we better get the topic straight. When I agreed to debate on too many kids are going to college, I thought of college as being four-year colleges leading to the BA. I didn't think of it as a whole range of community colleges and the rest.

Anyway, that's the way I'm going to argue tonight because if the proposition were that too many kids are trying to get more education and training after high school, I wouldn't have accepted the position on the affirmative. Almost everybody needs more education after high school. What they don't need is to chase after this fraudulent, destructive, antediluvian thing called a BA. The thesis of my argument really is that the BA is the work of the devil. Let's go through each of those accusations. First, fraudulent. The BA is supposed to signify, in a very old-fashioned term, that you are an educated man, now-- an educated person. You know and I know that it doesn't represent that any more. The number of colleges that require the core courses that's go into a liberal education is virtually not-- don't exist. But it's much worse than that.

If the only thing you know about a person is that that person has a BA, you don't know anything. If that seems too extreme, I can document all kinds of stories about courses in introductory economics which use magazine articles as the text about students who get a BA after four years without having to write a single solitary term paper, about exam scores which, by any traditional grading system means a D or an F. But guess what? They're transmuted into Bs. And why are they transmuted into Bs? Because the story they want-- have now is retention, whereby the point of a college is to bring in as much tuition money as you can. And you've got to retain kids. And in fact, if they want to drop out of courses and stay for five or six years instead of four, that's just fine with the college. You can talk to employers all over the country who will tell you about applicants who have BAs, who can't write grammatical sentences in their applications and sometimes can't read very well.

All of these things do not refer to the products of a few diploma mills. I am talking about large chunks of the second tier and third tier state college and university systems. And I'm also talking about large numbers of courses and students in the first tier system and a whole lot of very expensive elite colleges. Knowing what major a person had doesn't tell you very much. Yeah, if it's math, if it's hard sciences, if it's engineering, okay. But what does it mean if you have a political science degree, spoken by a person who has a political science degree, if you're going to an employer and saying you ought to hire me. It doesn't really mean anything. Now, here is what you do know about a person with a BA if you know what school they came from. So if the applicant came from Harvard, you know a whole lot about what person was like at age 18 before he went to college.

You know he had terrific SAT scores, and you know he had a terrific high school record or he wouldn't have gotten in. You don't know anything about what Harvard has added.

And as a graduate of that institution, trust me, I am living proof of that statement in a whole bunch of ways. None of this should be news to any of you. The retreat of the academy from rigorous education is known to everybody who's in higher education. Except for majors in engineering and math and the hard sciences which account for just 12 percent of undergraduates, the bachelor's degree, all by itself, is meaningless. Okay, destructive. Even though we know that the BA is substantively meaningless, it remains true that for millions of jobs you can't get a job interview unless you have one. And the problem is that employers are behaving rationally when they do that because you've got about 32 percent of adults that have a BA. The employers know how clueless many of them are. Why should they go outside that pool and take even lower levels of population in terms of their ability.

So they're being rational. But the problem is this: We have created a kind of self- fulfilling prophecy. We have created a culture in which not having a BA labels you, in the minds of way too many people, as being either dumb or lazy. And so a lot of ambitious kids who have no interest in sitting in classrooms for four years and accumulating these large student loan debts, nonetheless want the piece of paper. It is not surprising that we have all the horror stories which are documented in journal articles and large surveys, not anecdotally, of kids who take the easiest possible classes and don't study. They aren't there to get an education. They're there to get a piece of paper. It is hugely destructive to have created this kind of false credential. It is destructive to the majority of young people who don't try to go to college because they know college is not for them.

It is destructive for about 40 percent of those who start college who never finish. But most of all it is destructive to America's civic culture. We have always prided ourselves upon the idea that everybody is equal in all the ways that count with regard to human dignity. We have given a meaningless educational credential a role in our culture that says otherwise. Antediluvian. I have time just to state the proposition and hope to have a chance to elaborate later, the four-year brick and mortar college is obsolete. Four years is almost always too long. There's hardly any profession that requires four years of class work. A lot of them require an apprenticeship much longer than that. The rationale for a big physical plant at a residential college is just vanishing. What's the rationale for having a library these days? It used to be central.

Why should it be that the brilliant professor giving a lecture where he doesn't take any individual relationships with students but just giving a superb lecture, why is he giving that lecture to 150 kids who happen to be sitting in the hall, why isn't it being given to millions? Distance education has all sorts of possibilities it didn't have before. The information revolution is giving us a cornucopia of new ways to help kids get an education. Well, that just begins to say what I want to say but what I'm really coming down to is nobody should go to college as the system is now defined. What we need is a transformation that gives young people a chance to tell employers or for that matter to tell graduate admissions officers what they know and what they can do, not where they learned it and how long it took them. Thank you.

### Moderator
Claim: Thank you, Charles Murray. Our motion is Too many kids go to college." And now to speak against the motion, Vivek Wadhwa.

He is director of research at Duke's Center for Entrepreneurship. In fact, you have a long list of academic credentials. You have research and teaching positions at Duke and at Emory and at Harvard Law. And what am I missing?

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: And Berkeley.

### Moderator
Claim: And yet you started as an entrepreneur, you've cofounded and sold successfully two software companies.

### Scientific Advocate (SA)
Claim: John, I call myself a tech guy lost in academia.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: That's the shortest way of describing--

### Moderator
Claim: All right. Ladies and gentlemen, Vivek Wadhwa.

### Scientific Advocate (SA)
Claim: You know-- it must be because I'm an immigrant, I'm a tech entrepreneur, I'm a foreign that I have a totally different perspective on this whole debate. In fact, when I first stepped into it, it was ripping Peter Thiel's head off in an article I wrote for telling kids to drop out of college because it didn't make sense to me. You know, as an academic for the last six or seven years I've been researching what's happening globally. I've been researching the impact of globalization on U.S. competitiveness.

I've been researching American schools versus other schools, and so on, and what makes America what it is, you know our competitiveness, immigration, and so on, those topics I've been researching. And when I step back from that, my conclusion is that these people in America are totally completely out of touch. If you read my writings, you'll see that I've been writing very controversial articles, each of them rip into a different aspect of American competitiveness because we don't get it. We're sitting here in our own little bubble disconnected from the rest of the world. Now, let-- I'm going to give you three perspectives on this. First of all, about U.S. education itself, believe it or not, U.S. education is by far the best in the world. Everyone is trying to be like us. This is-- you know, I mean, people from abroad stake their life savings, you know, all the money they can possibly raise and invest it in sending their kids to America because we've got the best schools. What do gain from our schools? It's not the courses. It's really the knowledge. It's how to learn. You gain social skills. You learn how to interact with other people.

You learn how to deal with failure, make compromises. You learn how to solve problems. These are sort of things you learn because our schools have a way of making you socialize, making you think, making you compete, and American kids come out the best and the brightest in the world. This is why America is what it is. Now, another argument we're discussing is well, some kids shouldn't go to college. You know, Charles has written a lot about IQ, IQ tests being determinants of who will and won't succeed in life. To me that's complete baloney. I mean, my whole life I've faced stereotypes because I happen to be like a-- you know, one-- a race that may not be very smart. In my youth it just be that my people were beggars and snake charmers, then we became low level engineers, now we're hotshot CEOs. In my lifetime I've seen the transformation of how people perceive me. So if I was going by these classifications of who should be and who shouldn't be educated, my people shouldn't get education because we don't really deserve it, we're not going to be successful, therefore, leave us out.

You'll find the same thing with many other minorities in America. We don't know. I tell you if-- I know from my own children that they've gone through gyrations, so trying to decide what they want to be when they grow up. When they were young, they had some ideas. They don’t-- other ideas. Now, if I had to decide when my sons were 16 years old, whether they would go to school or not based on their aptitude, it would be the worst decision I could possibly ever make because I’d be wrong. Both of them decided to do completely different things than what they were talking about when they were young. Children don’t know. So who are we? Who are parents to try to figure out whether they should get education or not? America is what it is because of our education system. America started educating the masses, and its productivity rose. We became the most fiercely competitive land in the world because we educated everyone. Now there are a lot of people left out as Henry talked about, but the solution to fixing America’s competitiveness is to bring everyone up to educate everyone. Now we can debate what a college is. To me, a community college is a college.

A college-- you know, Peter Thiel basically has lived in this bubble called Silicon Valley where everyone thinks-- when they think college, they think Stanford. They think Berkeley maybe, so, you know, one level below Stanford, but that’s it. And when he talks and when he gives all these great talks about education, he talks about $200,000 of debt, $250,000 of debt. I know some great people who have gone to community colleges who have almost no debt, who worked part time, been able to pay their fees off. Our community colleges in this country are also colleges, and they too are better than the best-- they too are better than the best institutions in most other countries of the world. I don’t know why we keep forgetting that. Now, I also taught, you know, I teach at several universities. I was at University, and my students brought up Peter Thiel. He’s quite a legend worldwide now. They were talking-- they said, “Professor, is there really an American investor who’s paying children to drop out of college?” I mean, they were so, so confused. At the end of it, we talked about it, and they said, “You know, this is great because we’re going to eat their lunch.”This is what they were thinking. They didn’t say it. But this is what’s happening in the world right now. Just as we had these stupid debates about educating our children, the rest of the world has learned our trick. India and China are now graduating 1.5 million engineers a year. They’re educating all their people because they know that it’s going to make them like America, and they’re going to eat our lunch. So if we keep having these silly debates about four-year degrees and this and that, we’re going to lose out. You talk about entrepreneurship, again-- again, I have a lot of respect for Peter Thiel while chatting with him, but, you know, he talks about entrepreneurs who can be pulled out of school and do very successful. Fine. They’re 25, maybe 200, 2,000 people in America who don’t need to go to college. I have researched this systematically. What we found was that the difference between entrepreneurs in the tech industry, in the same world that Peter comes from, the difference between entrepreneurs who have a Bachelor’s degree and who have a high school degree is huge, almost two-to-one in terms of revenue and number of employees.

In terms of success, that’s how much difference education makes. Now, the interesting thing is what we also learned was that it doesn’t matter what school you graduate from. The tech founders in America, the most successful people in America graduated from a wide assortment of universities. There are almost as many universities as there were entrepreneurs in the research we did. It didn’t matter whether you graduated from a community college or whether you graduated from Harvard. You could still make it big as an entrepreneur. Why? Because school gave you that basic foundation to be able to learn. Now, moving forward, the Indian and Chinese are going to be eating our children’s lunch, guaranteed. I mean, I’ve researched it enough to know that we have a lot to worry about. If we disarm right now and stop teaching them, we’re going to become like they used to be. They are absolutely going to demolish this country. And what’s going to happen is that globalization is going to wreck havoc on industries. Already we’re talking about manufacturing. We’re talking about several industries now going offshore. It’s going to happen more and more. We’re going to have to keep constantly reeducating our workforce.

Ten years from now, we’re going to have to have massive retraining programs for our workforce. If you don’t even have a Bachelor’s degree, if you don’t even have basic education, you’re beyond hope. These people may be end up, you know, waiting tables at restaurants, but we’re going to have too many of those. We need to provide our workforce with a basic education. I say we’d have to have every American getting at least a Bachelor’s degree and encouraging them to do Master’s and Ph.D.s.

## Round 2

### Moderator
Claim: Thank you, Vivek Wadhwa. And that concludes round one of this Intelligence Squared U.S. debate. Remember, we asked you to vote at the beginning of the debate, and we’ll ask you to vote once again at the end. And the team that has moved its numbers the most will be declared our winner. So now onto round two, and that’s where the debaters address each other directly and also take questions from you and questions from me. We have heard the arguments. We’re at Venue 610 at the Spertus Center in Chicago. We have two teams of two arguing this motion, "Too many kids go to college.”The team arguing in support of that motion, Peter Thiel and Charles Murray, are arguing that college can be a drag, a waste of time for the very talented and for much of the rest of the students who are pursuing BAs, they are pursuing what has been described as a worthless document, the Bachelor of Arts degree, meaningless document, the Bachelor of Arts degree. The team on the other side that include Henry Bienen and Vivek Wadhwa are arguing that, number one, going to college is part of the American dream, that those who go to college do better financially and otherwise than those who do not. And from a competitive point of view, we will be falling behind the rest of the world if we accept the notion that we need to limit, in some way, the numbers of people going to college. I want to put a question to the side that's arguing for the motion and take on that American dream question. And Peter Thiel, I think Henry Bienen used the term, we do grow up with the notion-- I think you've acknowledged it that in fact you felt straight-jacketed by it, that you do go to college because you're supposed to go to college.

And yet the other side is arguing that that's part of the dream, part of the American dream. So take that on, because it's-- I think that they're onto something with that.

### Conspiracy Advocate (CA)
Claim: Well, it certainly was not historically part of the American dream. So if you looked at how many people went to college in the U.S. in the 19th or early 20th century, it was a very, very small percentage. And it was-- this is a very recent phenomenon that this is seen as an absolute necessity. And I think-- I think in many ways I would actually flip it around, and I would say, what's gone wrong with the American dream that we have to have people go to college when that was never a necessity in the past. People don't need college degrees for many of the jobs that we have. There are many good jobs where you don't need them, many bad jobs. People get stuck with college degrees. But I'd actually flip it around. This whole question of what sort of a good is college. Is it an investment in your future? I don't think it's a good investment because it's costing too much, and there's no-- seemingly no accountability whatsoever from the other side on the costs.

It was absolute good, any price. Pay no attention what the price is. Is it a consumption decision? And I sort of have joked that it's like a four-year party. And I think that's kind of true, but I think people are too stressed out to really have a four-year party when they're taking on a quarter million in debt and know they're going to be debt slaves for the rest of their lives or for the next 10, 20 years. And so I think the way to think of it is that it's basically become an insurance policy because the cracks in our society have become so big. And we need to be asking why are so many people having to pay more and more for insurance and what's gone wrong that we're paying so much for insurance.

### Moderator
Claim: So Henry Bienen, you're opponent is describing more what sounds like an American nightmare in terms of the debt, in terms of having to do this, in terms of being the wrong thing for lots of people. And yet they go into it unthinkingly and get hurt by it. Can you take that on?

### Scientific Advocate (SA)
Claim: Well, I didn't think this was a debate about cost. I'd be quite happy to talk about cost. A lot of the sticker price is discounted, as you know, through very substantial financial aid.

Plus I also took literally the topic of college which means lots of low-cost colleges Vivek and others and myself pointed out. I don't think it's a nightmare for people. I think most people come out of a college experience feeling better. In fact, there's even surveys about how do you feel. You feel better as a person. And it's quite positive. I think of it as a consumption good but not as a full-time party for four years. No doubt there are some people who do that. Woe to them. But it's a consumption good in that there's something good in and of itself of learning about beautiful things and learning more analytical ways of thinking. It was Steve Jobs himself, the late Steve Jobs, who said when he came back after dropping out of Reed and sat in on courses, he took a calligraphy course. And that calligraphy course gave him a whole new world of thinking about design. Who knows what, in the college experience will trigger for people thinking about the world in a different way.

### Moderator
Claim: Let me go to Charles Murray and-- maybe we want to discuss what the metric is, how do we describe whether college is worth it. And your opponent is saying, you know, you can learn beautiful ideas. And I was an English major, and I speak English now superbly. It's been very practical and useful for me. But-- but seriously, is there-- are we putting dollar and cents measurement on something that needs to be measured more broadly than that?

### Conspiracy Advocate (CA)
Claim: Well, I'm not doing that when I say that too many kid are going to college. I'm coming at it-- again, let's go back to the American dream thing. In 1960, which wasn't that long ago for somebody as old as I am, only eight percent of American adults had college degrees. So college was a big deal then. But 92 percent didn't, including most of the successful people in this country. Not having a college degree had no relationship to the American dream at all at that time.

College did have prestige. But you didn't look down on somebody who hadn't gone to college. And one of the things we don't like to say any more, but it is absolutely true, is we do now. If you are just a high school graduate, you are a second class citizen in this country. That is a kind of destruction of the American dream that I think it's becoming like a caste system where if you go not just to college but to an elite college, the doors will open and you are going to be a success, and you don't give into that--

### Moderator
Claim: But they're arguing for more people to go to college to--

### Conspiracy Advocate (CA)
Claim: No, I'm not.

### Moderator
Claim: No, no. No, no. I'm saying they're arguing for more people to go to college, thus to presumably reduce the caste system.

### Conspiracy Advocate (CA)
Claim: The caste system is real. I mean, how many people out in the audience can tell to a fare-thee-well when someone says what college they graduated from, you know very well, you go clicking through your mind, and you can place that college as to where it is in the stratification.

### Moderator
Claim: The argument that your opponents have made that a Bachelor's degree is meaningless, now you-- you meant that in the extreme. I'm sure you're-- you also said that it--

### Conspiracy Advocate (CA)
Claim: If that's the only bit of information you have about a person, you don't know a thing.

### Moderator
Claim: Okay. What about--

### Scientific Advocate (SA)
Claim: I want to tell you, and mostly again because I am an immigrant, and I understand the American dream more-- better than most Americans do. Look at the rise of America relative to its education. We rose-- you know, in the '50s and the '60s, we were coming out of the war. It was a different era. Over the last 50 or 60 years, we've become "the" only world super power. Yes, the economy is in the tank right now. Yes, things are bad. We'll come out of it. This country keeps reinventing itself because it has smart people who can think outside the box that-- who can reinvent themselves over and over again. Yes, there's some outliers who can't. But the average American can reinvent him or herself, and that's what makes this country what it is.

Bachelor's degrees, if we want to declare-- bachelor's degree is irrelevant, then let's invent something new. But we're not going to be able to change the system like that. Like you said, if we outlaw bachelor's degrees, we're going to declare defeat to the rest of the world because the rest of the world has caught the American dream. Those Chinese students I talk about, they are just like my students here at Duke and at Berkeley are. They're just like the students we meet over here. They read the books. They follow us. They understand what we're doing. They want to get those bachelor's because they want to get master's, and they want to get PhDs. That's how it is. So forget about our vision of the American dream. We're now a small part of the world. Our economy is becoming a decreasing part of the world. We're going to be competing like you won't believe over the next 10, 20, 30 years.

### Moderator
Claim: side respond to that. Peter Thiel.

### Conspiracy Advocate (CA)
Claim: Let me just tackle this whole globalization international thing. So I think there obviously are a lot of things that are very admirable about India, China. People have a great work ethic. They're thinking very much about the future. And I do not want to at all underestimate how serious the competition is or to encourage people to be complacent.

But the proposition we're debating today, do too many kids go-- are too many kids going to college, and if you look at those countries, the percentage is much smaller, and it is-- you know, I looked these numbers up because I figured-- I thought you might make this argument. And the U.S.-- there are about 40 percent of college-aged students are in college. And of course there are a lot of them that end up dropping out. It starts at more than 40. But on average, 40 percent fromr in college. In China, the number is 20 percent. In India, the number is 10 percent. And if you want to look at China and India, it is a brutally selective system. Very few people can get in. People are worked incredibly hard once they're in college. And if we want to be more like them, the first thing-- simple approximation is you have far fewer people go to college. And this is true of any other country in the world you'd look at. And so if the U.S. should take its bearings from other countries, that is a very powerful argument for our side.

### Moderator
Claim: Let's bring in Henry Bienen.

### Scientific Advocate (SA)
Claim: Well, at one time, it wasn't so long ago, the United States was first in the world in post- secondary enrollment.

And whatever post-secondary enrollments meant. And now we're-- we were 12th a few years ago. I think we've actually fallen to 15 to 16. If anybody thinks that's a good idea, they would think again.

### Scientific Advocate (SA)
Claim: I want to add one more perspective getting back to the Indians and Chinese. Yes, it's a smaller percent of the population. But look at the industry in which everyone is moving, technology, engineering. 1.5 million versus about 100, 150,000 of ours. They're eating our lunch. You should-- you know, they have become-- India has become a $80 billion IT industry which came out of nothing at all the last 15 years. How? By educating its people. Zero to $80 billion in 15 years.

### Moderator
Claim: But they're saying that the number of people being educated relative to the rest of the population is a tiny fraction.

### Scientific Advocate (SA)
Claim: But there-- that's because they don't have the resources to do it. They're putting everything they can into education

### Moderator
Claim: So if you were king of the world, would you educate everybody in India? Would everybody go to college?

### Scientific Advocate (SA)
Claim: Absolutely. I would educate everyone in the world because it uplifts society. What it does is it improves-- because the low-level jobs are going to go away. Robotics are going to take over manufacturing in the next ten years or so. So those jobs which could be menial jobs that you could have non-educated people doing, they're going to disappear. It's become a knowledge economy where everyone has to now do intelligent things or they're unemployed.

### Moderator
Claim: Charles Murray.

### Conspiracy Advocate (CA)
Claim: But look at the way the caste system persists because you have good jobs which is being a lawyer or a doctor or a scientist, and then you have menial jobs. Now, tell me where it is written that we ought to--

### Scientific Advocate (SA)
Claim: Charles, you're creating a new caste system

### Conspiracy Advocate (CA)
Claim: But let me finish my sentence.

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: That we ought to think about what is more intrinsically rewarding about being a lawyer than being a cabinetmaker? Why does that have-- should that have any privilege over being a cabinetmaker? There are a whole lot of jobs in this world which are wonderfully fulfilling that don't require a college degree and we talk about them as being vocational training.

That is a kind of invidious caste system in education that I want to destroy by getting rid of college degrees.

### Moderator
Claim: Charles, which jobs are you talking about because what the other side is arguing is that those jobs are disappearing due to automation and robots, et cetera.

### Conspiracy Advocate (CA)
Claim: Wait a minute, skill jobs, listen, you want to hire a lawyer or a doctor you can do that in a nanosecond. You want to find good skilled labor? That's hard. Finding a good plumber, a good electrician to come and fix things, that's hard. We have a demand for a wide variety of skills-- a wide variety of skills that we aren't meeting because guess what that's demeaning those occupations.

### Moderator
Claim: Henry Bienen.

### Scientific Advocate (SA)
Claim: But now, Charles wants to overturn the wage structure of the world, not just the U.S., he wants to overturn the return to knowledge. I don't have any bias against craft skills and I agree that sometimes they're in very short supply and they get a good return, but we-- you know, if you believe at all in markets, I assume, Charles, coming from where he comes from and with his ideas believes in markets, people pay a return to something that they think is relatively scarce or that they value in some way.

And sometimes it's a great scientist and sometimes it's a great artist and sometimes it's a great craft person. But that's the way it works, so you can have a lot of complaints about college and cost but now he wants to complain about the world wage structure.

### Moderator
Claim: But you can't--

### Moderator
Claim: Peter Thiel.

### Moderator
Claim: No, no, no.

### Moderator
Claim: Let's let Peter Thiel--

### Conspiracy Advocate (CA)
Claim: But you can't have it both ways either. You want to say on the one hand that college is an end in itself, it's an absolute good, we don't ask any questions about it, it's not instrumental, and on the other hand it is completely instrumental and it's what leads you to getting a better job, more high paying job. You cannot have it both ways.

### Scientific Advocate (SA)
Claim: But the jobs--

### Moderator
Claim: One second, Vivek asked you a question about your point, but--

### Scientific Advocate (SA)
Claim: I said the jobs they're talking about, the plumbers and electricians, they're less than one percent of the U.S. population. What about the other 99 percent? What do they do?

### Moderator
Claim: Charles Murray.

### Conspiracy Advocate (CA)
Claim: You know, one of the great television shows on TV is "Dirty Jobs." Any of you ever seen it? Every week they go to a dirty job but the thing is you find out a couple of things, there are a huge number of ways to make your living.

They are interesting, they are fulfilling, the people who are doing the, you'd like to know--

### Scientific Advocate (SA)
Claim: One percent of the population--

### Conspiracy Advocate (CA)
Claim: --it is a great curative for the kind of way we are talking about the job structure, which has nothing to do with wages, it has to do with making a living in a way that is fulfilling and satisfying.

### Scientific Advocate (SA)
Claim: There's nothing wrong with doing those jobs for people who want to do them. The issue is how do you pick a child who gets educated or who not gets educated, you basically want to do it based on IQ.

### Conspiracy Advocate (CA)
Claim: Of course I don't.

### Scientific Advocate (SA)
Claim: How would you pick someone who goes to school?

### Conspiracy Advocate (CA)
Claim: I want absolutely open competition for every position in any kind of educational institution no matter what it's teaching. Where you got the idea I want to put IQ scores on kids' foreheads--

### Scientific Advocate (SA)
Claim: Look on the bell curve.

### Conspiracy Advocate (CA)
Claim: --say, "You can go to college, and you cannot," I'd like you to read a passage of anywhere that I've said that.

### Moderator
Claim: Charles, Charles, one point that the other side did make is that education can be transformative and somebody who may not necessarily start out as a freshman seeming like a superstar signed up for a BA even of the nature that you may not find terribly useful, that the experience of going to college can cause a blossoming and that just by being there, being in the situation, somebody who wasn't very promising might turn out to have a lot of promise, what-- can you take that on?

### Moderator
Claim: Well--

### Moderator
Claim: Okay, Peter Thiel, you were ready with it. Go ahead.

### Conspiracy Advocate (CA)
Claim: Well, you know, we can find all sorts of anecdotal things. We were told by the other side that we shouldn't look at anecdotes like Zuckerberg or Gates or Jobs and I agree those are exceptional cases, and there obviously are all sorts of people who have idiosyncratic things that can happen in college. They can also happen outside of college. Socialization does not have to happen in college. People should learn how-- you know, this is again a really bizarre recent phenomenon, you know, 92 percent of the people did not go to college in 1960, they were able to be citizens, they were able to vote, they were able to be-- you know, we wouldn't say nobody should have voted in 1960 because they didn't have college degrees.

That would have been an invidious thing to say.

### Moderator
Claim: And when you say that college is a bubble, are you also arguing that colleges have a self interest in growing, that in other words, they’re signing up students to keep the tuition up?

### Conspiracy Advocate (CA)
Claim: Oh, I think there are extraordinary conflicts of interest. It’s like subprime mortgage brokers saying people should buy houses. I mean, the self dealing that is going on is incredibly severe in all of this. And I do think--

### Moderator
Claim: All right, I want to take that point directly-- all right go ahead.

### Conspiracy Advocate (CA)
Claim: One other-- one last point. I don’t think you can separate the question entirely from the cost question. And so it’s like saying, you know, “Mrs. Lincoln, besides that, how’d you like the play?” So besides the fact that college costs you an arm and a leg, how much do you like it? And these two things are linked together.

### Moderator
Claim: Henry Bienen, having quintupled Northwestern’s endowment, the point made from the other side is that you had a conflict of interest, not you personally but people in your profession have conflict of interest in inducing students to continue coming to school because of the revenue that flows in as a result.

### Scientific Advocate (SA)
Claim: Well, we-- well, first of all, Northwestern, I can tell you, the full-- if you are a full tuition payer and you had no financial aid at all, you are paying about 60, 65 percent of the total cost of the university, and it leaves out a lot of other things that universities do, which lead to higher costs, some of which I approve of and some of which I don’t. But we’re the research generators of the world in American universities today. Bell Labs is gone. The big pharmas have offshored their research. We’ve adopted those costs. Now, not every university is a research university. It’s not a Northwestern or a Duke or a Stanford, but I want to speak to the question of cost directly since our opponents, though I don’t think it’s the subject of the debate. But you know, we don’t have to induce anybody to come to Northwestern.

We get 33,000, 34,000 applicants for something like an entering class of 2,000 students. So-- and that is true of the elite universities. Not all universities look like that. That’s true. And there is this range of places, which we’ve tried to talk about. If you believe in demand at all, people are still voting with their feet. And by the way, it’s foreigners who are voting with their feet because they want to come to American universities for the Ph.D. level. We’ve talked about undergraduate education a lot. But there’s something else that universities do out there, or at least certain kinds of universities which are very, very important. It’s a very important function for the place that I--

### Moderator
Claim: And response for this side? If not, I’ll move onto something else. Okay, I was curious to know, for you to paint a picture of, again, if you were kind of the world and these BA programs were shut down or, at the very least, people were discouraged from going to them, heard your message and stopped going, how many people would be left in college? What percentage? And where would they be going to school?

### Moderator
Claim: In my ideal world, the college campuses would be more full of students than ever, but they wouldn’t be there for four years. Somebody once want to go into business, so they have some marketing courses they want to take and some business administration and accounting courses. Takes them a year and a half. And they finish all the courses they want to take, and then there is a good certification exam, like the CPA exam for accountants. They take that exam, which doesn’t have to consist of just filling in dots and circles. It can be work samples. It can be a variety of things, but you can take that to the employer and say, “Here’s what I know academically about business.”

### Moderator
Claim: Do you two sides on this issue, that-- because it sounds to me that when you’re defining this motion as being about a variety of forms of school and education--

### Scientific Advocate (SA)
Claim: College-- community college is college.

### Moderator
Claim: And Charles is also talking about a variety of forms of education, it sounds to me as though there’s common grounds on this or you’re just coming at it from different--

### Scientific Advocate (SA)
Claim: Some common ground. I’m not so willing to consign the B.A. four-year to the dustbin of history, as Charles is. But I don’t think everything will or should stay the same.

I don’t disagree with that. I don’t believe-- for example, take distance learning. I suspect we’re probably on the same page. I think you’re going to see more distance learning, even at the major four-year universities. It’s going to happen. People can take a statistics course online. I’m chairman of the board of a company called Ithaca Harbors where we’re doing research on how people learn online. Maybe they learn statistics online as well as being in a classroom. Maybe they can even do Econ 101 like that. I don’t know. We’ll see. I’m for experimenting. Our law school went from everybody in a three-year law school program to some people in a two-year program. I think the great universities will change. They should change. Not everybody has to be in a bricks-and- mortar place. Online, for-profits, can be solely online or 70 percent online courses. So we ought to think about this in a flexible way. I don’t disagree with Charles and Peter on that.

### Conspiracy Advocate (CA)
Claim: I think we can close down the discussion.

### Moderator
Claim: Charles Murray.

### Conspiracy Advocate (CA)
Claim: All I’m asking is we don’t put kids in the straightjacket of the BA and we enable them to get certifications that show what they know even if it's-- even if they'd done it all online and that the B.A. loses its mystique.

### Moderator
Claim: But your-- your partner.

Your partner, Peter, spices the argument with-- by coming at it from a completely different direction which is talking about the experience of college actually being a waste of great talent as opposed to a resting place for the mediocre.

### Conspiracy Advocate (CA)
Claim: I think-- I think what Charles and I-- what Charles and I agree on very much is that there is no one size fits all approach. There are certain skilled people, very talented people. Not every talented person should go to Harvard. You know, there are a lot of different kinds of things different people should do. And I think that's-- that's sort of a basic starting point. We don't believe there is a single straight jacket. And the crazy thing in our society is that the more talented you are, the narrower the straight jacket has become. This is a very, very bizarre feature of it.

We also agree that learning is generally a very good thing. And we agree that we should be-- I think we all four of us agree on that. But there's a bit of a disagreement that I don't want to understate, is that a great deal of what masquerades as learning is nothing more than credentialing. And the basic numbers I've seen is that it's something like 90 percent credentialing, 10 percent learning if you try to sort of break the numbers out. If you got into Harvard versus finishing high school, let's say you make 30,000 a year in-- out of high school, 60,000 a year out of Harvard. Let's say it's two to one, something in that ballpark. You get to 45,000, if you were good enough to get into Harvard, that's the selection. And you get to 57,000 people knew you got into Harvard, that's the signaling. So 90 percent is credentialing. And the learning gets you from 57 to 60. We're in favor of that 10 percent. But it is outrageous how it's been conflated with this credential which is being parasitically charged to people in this-- way costs have escalated and escalated and escalated.

### Moderator
Claim: All right. Peter Thiel, thank you very much. We're going to take a break. And when we come back, we're going to go to questions from you in the audience.

So I'm going to do my little bit of radio here. This is one of those moments when I need you to very spontaneously applaud when I-- exactly when I tell you to. And I'm going to-- I'm going to say a line or so, and then I'm going to-- then I'm going to say the line again without the applause to give the radio editors a chance to make an editing decision on how to do that. So when I raise my right hand, you can just do a round of applause like before, please. Our motion is too many kids go to college. This is a debate from Intelligence Squared U.S. We are in Chicago. We have two teams of two arguing out this motion, and now we're going to go to questions from the audience. And I'm going to do that one more time without the applause.

Our motion is too many kids go to college. This is a debate from Intelligence Squared U.S. We are in Chicago.

And now we're going to go to questions from the audience. So if you can raise your hand, a mic will come to you, and I want to encourage you to-- to-- right down in the front will be first-- to really think in terms of a question that moves us along on this motion and that is terse. No two-parters. And have some phrases so it really is a question. Thanks. Ma'am, can you tell us your name, please? Oh, and if you hold-- it's already turned on.

### Moderator
Claim: Hello? Can you hear me?

### Moderator
Claim: And if you hold the mic about a fist's distance from your mouth, the radio broadcast will hear it fine.

### Moderator
Claim: Hi. Katherine Nvadaren professor of international political economy and expert on Asian entrepreneurship from DePaul university. I enjoyed this talk quite a lot. I'm an alum of Northwestern, so it's a great pleasure to see Dr. Bienen who was the president while I was a doctoral candidate there. It's a great pleasure to be with all of you tonight. My question is something that has not come up in the debate, and that is social networks.

I do analysis of high-tech gazelles all over the world, and I find that the social networks that individual entrepreneurs obtain while they are in the K through 16 pipeline, particularly while they're at universities and/or graduate schools are absolutely critical for them getting, one, trusting business partners, their first business partners, and two, angel investments. So I'd like for both sides to comment on the quality of the social networks that you get while you're in university.

### Moderator
Claim: Peter Thiel.

### Conspiracy Advocate (CA)
Claim: Well, I think-- I think the social networks are quite valuable. It's-- it's not clear people should be-- it's still not clear that it justifies the college's paying-- charging a quarter million. I think the social networks tend to be the most valuable only at the elite colleges. Once you go below that level, they actually function in a way where people, again, do not have access. So I think you have a very ambiguous aspect-- aspect about how it works. In practice, in Silicon Valley, most of the companies do get started by people who are a few years out of college. And I tend to think that when I started PayPal, there were some people I brought in from Stanford, but you know, I started with a colleague who, we met in a different social context in Silicon Valley.

And we'd gone to different schools, so it ended up being somewhat-- my own experience was different. But I think-- you know, I do-- I do think elite colleges have a social networking value. It's very-- that's a very oddly different thing from what we've heard here. That's very different from that's about learning, that it's about turning people into citizens or anything like that. And it seems to me that even if that's true, it should cost way, way less.

### Moderator
Claim: Vivek?

### Scientific Advocate (SA)
Claim: You know, not just elite colleges. Peter keeps talking about a quarter million dollars. That's Stanford. The rest of America is not Stanford. Most colleges are much, much cheaper. And the direction the students have are the same. It's not that the elite, you know, students at Stanford have a big advantage over the others. It's just that they happen to have gone to a nicer campus. So the social network is equally important no matter where you go. Now, the other thing is that if you don't go to college, if you drop-- forget about dropping out. If you went directly from high school to work, you're going to have a very junior position in some big company or some startup where you have very limited interaction with anyone else.

You're not going to build a social skills. You're not going to have a network greater than the handful of people that you happen to work with in your department. I don't know how many of you worked in big companies or any companies. But it's always to people you're exposed to. When you're in college, you're interacting with lots and lots of people all across the board. It's those interactions that define you. They can't be quantified. But that's what carries you through your whole life. You get to meet diverse people. It's not just people who happen to work in the same field and the same company that you do. So the kids that are dropping out and starting their own startups, they're going to be disadvantaged for the rest of their lives. I don't know what they're going to be 30 years from now because they haven't had that social interaction which defines human beings. We need that. We need that extra three or four years where you get to stabilize and learn and become who you are and decide what you want to be when you grow up.

### Moderator
Claim: Peter--

### Scientific Advocate (SA)
Claim: You don't know that going into college.

### Moderator
Claim: Peter, did you say earlier that-- that if you were to do it all over again, you would still go to Stanford. And can you take 20 seconds to explain why, and why you don't feel that the time you spent getting your-- on a graduate degree was a drag on your-- on your other-- other energies.

### Conspiracy Advocate (CA)
Claim: Well, I didn't know what else to do. And I think I probably would not have known what else to do. In some ways, I was probably a candidate for a good general liberal arts humanities education in many ways. I was really interested in learning. I was very interested in these things on their terms. I don't think most people are like me. I think a lot of people are at a different-- at a different place.

### Scientific Advocate (SA)
Claim: Peter, they are like you. They are like you. They don't know what they want to be.

### Conspiracy Advocate (CA)
Claim: It's-- I don't think people are identical. I think this is like-- this is--

### Scientific Advocate (SA)
Claim: They're not as smart as you, but they are like you. I tell you.

### Conspiracy Advocate (CA)
Claim: I know that this is a big philosophical disagreement we have. We should not understate. I don't think everybody is cut from the same cloth. People are actually different. And we need to acknowledge the diversity that exists in our world and we shouldn't pretend that everybody is the same and everybody should do the same thing.

### Scientific Advocate (SA)
Claim: Peter, you didn't know what you wanted to be when you were young. Most children don't know. They're muddling through it.

They-- they learn by interacting with other people and getting ideas from other students who have diverse backgrounds. That's how they decide what they're going to be.

### Conspiracy Advocate (CA)
Claim: But-- but, I think-- I think the-- I think that-- I think that most-- I think that there are a lot of people already in high school who were not academically motivated. And I can say that even if they do not know what they wanted to do professionally or work wise, you could say they weren't particularly interested in reading books and learning. And this was not their talent. That's not what they were psyched to do. And there is something crazy about saying everyone has to be locked into a room and read books and-- and that's what we have to do.

### Moderator
Claim: You made that point very forcefully, I just want to go to another question. Sir. You've got a black book in your left hand. If you raise it, a microphone will find you. There you go.

### Moderator
Claim: Hi. My name is Jeff Nelson, and I actually run a college readiness and first assistance program here in Chicago that takes low-income kids to and through colleges.

And amazingly, though, I've actually been appreciating some of the comments that are coming out of this table. I do--

### Moderator
Claim: By this table, you mean the side that's arguing that too many kids go to college.

### Moderator
Claim: Correct.

### Moderator
Claim: Okay.

### Moderator
Claim: What I did agree with is that I share a frustration with higher ed, and I think there is a distortion. But I think the solution is unfounded. I don't think the solution is actually that you should deter kids from actually going to college. I think your frustration comes from the fact that there are fundamental reforms that need to be made to higher education. In my opinion, it should in some way mirror the reforms that are happening in charter schools.

### Moderator
Claim: Could you bring this around to a question?

### Moderator
Claim: I will get to a question.

### Moderator
Claim: Thanks.

### Moderator
Claim: So--

### Moderator
Claim: But I mean now. Thanks.

### Moderator
Claim: So-- so the question is, do you think there are fundamental reforms that could be made to higher education that would sway you to want to have more kids actually stay in college?

### Moderator
Claim: Do you mean the four-year classic--

### Moderator
Claim: Yes.

### Moderator
Claim: Yes.

### Moderator
Claim: Yeah, I think that certifications as a replacement for the B.A. is the way to go.

And I think there are a lot of market forces working in that direction because the B.A. really is meaningless. And employers do know that it tells them extremely little. Whereas if they could get some strong indication that the kid sitting in front of them has actually learned something about things that are relevant to the job they're going to have, that would be good for them. And it would level the playing field. Let me repeat, I do not see our college campuses having fewer people on them, I see it having as many or more but not locked into the B.A. straightjacket.

### Moderator
Claim: We're being streamed live on Slate.com. Slate.com is our media partner and we had people submit questions actually beforehand once they knew what the topic was, and I just want to read one of those questions here. From Minneapolis, Minnesota, a Rob Arbow asks if fewer people go to college, actually he said if less people go to college, but I'm an English major so-- sorry, sorry, Rob Arbow, but he said if fewer people go to college, shouldn't the value of a college degree go up? Charles Murray.

### Conspiracy Advocate (CA)
Claim: I'm sorry.

### Moderator
Claim: If fewer people go to college, shouldn't the value of a college degree go up?

### Conspiracy Advocate (CA)
Claim: No. It's because of the college degree, you may have heard me say this, doesn't mean anything. If you say, "Oh, well, if you have a classical education and that becomes the standard of what goes into a B.A. and you can be confident that's what a kid has gotten when they have a B.A., then you'd have a very different kind of value associated with a B.A., but it doesn't happen right now.

### Moderator
Claim: Okay. Oh, Henry Bienen.

### Scientific Advocate (SA)
Claim: If we have fewer people who go to college, the premium of wages will go up in China and India and Brazil and Turkey where the jobs will go, and those folks will benefit.

### Moderator
Claim: You know, I'm reminded of the onion which had a suggested solution for the recession in the U.S. was just to give everybody another degree. And I think we have to think we can't just mechanically say, "You go to college, you get a B.A."It is, "What are you learning? What are the specifics?" You have to be focused much more on the detail--

### Moderator
Claim: No, I wanted to take to you, Henry Bienen, the question that-- Peter's opening point is that, that is kind of the default position in society, increasing more so, certainly more than 45 years ago, that it is-- if you're anywhere close to middleclass or aspiring to the middleclass it is an automatic, "I have to go to college," without a whole much great deal of the sort of weighing of other options that this team is talking about. Can you take that on? Is it too much of the default's position?

### Scientific Advocate (SA)
Claim: Well, I think one of the problems in the U.S., and I said this earlier, is that we haven't had a lot of other good options. So I'm not against having vocational streams in high schools, for example Westinghouse High School here, a relatively new high school, is an interesting place. It has both a high performance stream and a vocational stream.

See, Mr. Mayor, you send me to these places, I try to learn something about them. So that's okay with me. I'm not against that. I'm not against for more on the job training. Only 10 percent of our labor force has what the Swiss and the Germans would call on the job training. I'm not against that. Americans have decided they didn't want to go in that direction, they didn't want to stream the kids in high school really early. But I think if-- it's not a terrible option at least to open it up.

### Moderator
Claim: There's a question down in the front room. You have a mic?

### Moderator
Claim: Yes.

### Moderator
Claim: Okay.

### Moderator
Claim: Hi, I'm Jessica Posener My question is that it seems to me that in the-- with the invention of the Internet, technology, globalization, there seems to be less and less a concrete set of skills that people need to be successful in the world. There's much more like what a liberal arts education I think maybe focuses on developing critical thinking skills. And so how would a shift from a liberal arts or sort of a more a broader education to more concrete courses, focus on a very specific skill set, change the ability of our society to innovate and to continue to respond to changing demands?

### Conspiracy Advocate (CA)
Claim: So--

### Moderator
Claim: Peter Thiel.

### Conspiracy Advocate (CA)
Claim: --I actually very much disagree with almost every premise posted in that question but just let me-- let me just--

### Moderator
Claim: Wow.

### Conspiracy Advocate (CA)
Claim: --I'll just flag one. The most concrete skill oriented education people get is engineering degrees, and that is actually probably the one area and we may even agree on this where I think the U.S. does not have an excess of engineers. And but that is something that's specific and tracked and engineering is specific and that's what people get paid for the most. And as we were heading into a more technologically oriented world, that's actually-- there's going to probably be an increasing premium on engineering and on specific types of skills. And if I had to give people advice and they were set on going to college, you should study engineering or some form of engineering unless you are in a really unusual situation and really passionate about something else.

So I would sort of quibble with the question on that level.

### Scientific Advocate (SA)
Claim: Yeah, because I've been wanting to make this point because I think it was Charles who-- if I were to reinterpret what he said, he wasn’t against too many kids going to college. He was really against too many kids going to four-year B.A. at expensive colleges. I don’t think that’s really a mis-description, but so much of this conversation from Peter and Charles has been a focus where they’re negative about the general B.A. or presumably the humanities and social sciences. So let me speak up for the humanities and social sciences. So the, you know, there are lots of smart people who think analytically and rigorously who take the humanities and social sciences, who are art history majors, God love them, and who are historians and who learn Arabic and who learn Chinese, or who learn Hindi or who learn whatever.

And we’re going to send lots of those people. They need to have those languages. They need to learn cultures that are different from the U.S. They’re going to be business people who go abroad. They’re going to be diplomats, whoever they may be, so why should we only think that the only place to get an education which is rigorous, analytical, and will serve you well is going to be in the engineering, mathematics--

### Moderator
Claim: So what’s really going on in the Center for Nanofabrication and Molecular Self Assembly? Those are not English majors hanging out there.

### Scientific Advocate (SA)
Claim: No, nothing I said is against the sciences. I sunk a fortune into the sciences, and we hired the best chemists and computer scientists we could hire, and that’s great. I don’t think it’s one hand here or the other hand that. You can do lots of things in a great university.

### Moderator
Claim: Charles Murray.

### Conspiracy Advocate (CA)
Claim: I just want to comment that when we talk about the humanities and social sciences and rigorous critical thinking, I’m not only in favor that, I think we have a darth of it in the university system. The problem is we are talking as if universities consisted of Stanford, of Northwestern and Harvard and places like that.

Very few kids go to those colleges. Most of them are at West Podunk State or its equivalent. And you are talking about course that they’re no relation--

### Moderator
Claim: Could you name some names, seriously, of the types of colleges that you’re referring to?

### Conspiracy Advocate (CA)
Claim: Yeah, you take the state university systems which usually have about three tiers. There’s the, like Ohio State and Iowa University and so forth. Then there’s a second tier of colleges which are acknowledged to be not nearly as good even though they’re four- year and sometimes there’s a third tier. And those are the places where you are getting the courses that teach economics with magazine articles, that teach Shakespeare by having kids watch movies of Shakespeare’s plays but you don’t ask them to read them, places where kids do not-- I’m not talking anecdotes. I’m talking surveys about the percentages of kids who graduate from college unable to write grammatical sentences.

Critical thinking doesn’t enter the realm of college life in those places.

### Moderator
Claim: Question right in the center with the beret. Thanks.

### Moderator
Claim: Hi. My name is Irene and I’m a final-year physics college student. And my question is, as a society, we’ve grown up with the notion of the importance of a well-rounded individual which is why a number of four-year Bachelor programs in the U.S. have a substantial amount of unrelated course work that has nothing to do with a person’s major. On the other hand, Europe, which recently adopted the three-year Bachelor system a couple of years ago, has much less of that unrelated, more well- rounded amount of coursework and more focus on the concrete, actual coursework that pertains to one’s major. And my question to you is which system do you think has an advantage in the future?

### Conspiracy Advocate (CA)
Claim: Well, may I respond first by saying that if the required course in the humanities was to take The Epic Poem from Homer to Milton, I’d say that’s great. If it’s to take The Epic Film from Ben Hur to Lord of the Rings, it’s not so great.

So well-- so what we have as course requirements in this country, it just doesn’t fit this image you want to see of people sitting Aristotle and the classics and the rest of it. It’s not the curriculum.

### Moderator
Claim: Sir, there-- you’re behind-- yeah, thank you. And the mic’s coming from your right side.

### Moderator
Claim: My name’s Randall Spencer.

### Moderator
Claim: Could you-- we didn’t turn the mic on. Could you just repeat now? I think it’s ready for you.

### Moderator
Claim: My name’s Randall Spencer. I myself graduated from a four-year college with an engineering degree. We’ve heard about students that-- how much more people make by getting college degrees. But what do we know about those who think that they have this idea that college is something that they’re supposed to do, and they end up going to college and building up debt and they don’t finish. What do we know about them as far as the money they make, the debt they accrue, the percentage of people that are going to college and are not directly--

### Moderator
Claim: Can I rephrase your question to put a twist on it to relate it to our topic, is are so many kids-- are there people going to college who are hurt by going to college?

### Moderator
Claim: Right, exactly. And are there more or less--

### Moderator
Claim: Henry-- okay, great question. Henry Bienen.

### Scientific Advocate (SA)
Claim: It's interesting. The data shows, and the data is conclusive on this, that it's not just getting a degree which increases your life chances and your income. In fact, even in community colleges, which are basically two-year places, if you're in there for a period of time like one semester, you have a better chance, and you'll earn more money than if you never went. And this is true of two-year, four-year colleges, whatever. So it's-- if you look at this, it's almost linear that the more time you spend in college, irrespective of whether you get a degree, pays off for you. Now, there is a sheepskin effect at around 16 years. But it's a little bump. It's not a huge bump so--

### Moderator
Claim: How do you know that going to college is what causes that benefit as opposed to people who are able to achieve those sorts of things in life rather than people who select to go to college?

### Scientific Advocate (SA)
Claim: Well, there's always a causation issue, as I said from the beginning. It's not so clear often what's correlation and what's cause. On this one, I think we have lots of study which show that when you try to normalize or hold account for all the other variables, and there are lots of them; family background, environment, even intelligence. I mean, some people are smarter than other people. That's a fact of life. Whatever you do, you still find a college effect. But the point I was making to this question, John, because I think it's a very important question, that-- and even if you look at debt, if you look at the number of years in college or the number of even months in college, it's extraordinary. It pays off.

### Moderator
Claim: Peter Thiel.

### Conspiracy Advocate (CA)
Claim: Well, you know, I think there is-- I think it pays off but not nearly as much as you think because I still think it's mostly correlation and just a tiny bit causation. But I want to quibble a little bit more with the idea of the data shows and what this means.

And we're always looking backwards. And so 2005, you could have said the data shows that housing prices always go up. And they are less likely to go up if they've gone up a lot. And so what I will tell you as an analytic truth, not an empirical truth, when people are paying way more than they ever have, there are going to be more people who have been hurt than who were hurt in the '50s or '60s, when it was effectively free. And so-- and this will not be seen in advance. You will see this in 10, 15, 20 years time. You're starting to see it with college students, have to move back in with their parents because they cannot afford to get their own place and pay off their debts.

### Moderator
Claim: So is that the popping of the bubble that you referred to, this college being When you described it as a bubble in housing, and housing crashed obviously when credit dried up. What is the-- what is the popping of the college bubble?

### Conspiracy Advocate (CA)
Claim: It's-- what I think we are seeing a gradually unravel with the-- with this incredible recession in the U.S. because the basic lie that you take on all this debt, and then you get a good job is being seen as not quite true.

And there are many cases where it's not true. And I basically think it's sort of-- we see it unravel over four or five years as you have one class after another graduate, and there are no good jobs, even for the people with college degrees. I would say it's different from housing because there's no specific market. You can't precisely evaluate a college degree. And that's actually one of the things that makes it a much more pernicious bubble than housing because it will not pop instantly, and therefore it's likely to be actually even more pronounced and more extreme before it unravels.

### Moderator
Claim: Another question from the rear there.

### Moderator
Claim: Hi. I'm exploration and a graduation of the University of Chicago. We've heard lots of reasons to go to college. Most of it has been about work and economics, a little bit about the need to meet diverse people, be exposed to things we might not see before.

In the spirit of the debate, could you clarify what it is you think college is actually for? What's the end or purpose of college?

### Moderator
Claim: What a great question. Thank you. Henry Bienen or Vivek, if you want to take that.

### Scientific Advocate (SA)
Claim: Different strokes for different folks. I think it's what you make of it. I think it can be sometimes very focused. It can be, as Vivek has said, people don't know what they want to do until they get there. You learn, how do I know what I want to be until I grow up. I don't have a handy dandy formula. I think it's a good question, but I don't think there's an answer to it that it should be this or that because people are so diverse. They come with different interests, different experiences, different backgrounds. And they grow presumably in those-- in those years in college. And many of them find themselves. They get sparked by different things. I don't know what's going to spark somebody's interest. I mentioned for Steve Jobs it was a calligraphy course he stepped into. For somebody, it may be reading Shakespeare. It may be looking at beautiful paintings. It may be listening to beautiful music.

It may be all of a sudden math grabs them, and they didn't know what they could do.

### Moderator
Claim: But would it ever be watching Lord of the Rings. Could be. One more question on the far right, ma'am. Yep, if you could just stand up.

### Moderator
Claim: Hello. My name is Layla Dolsin and I'm currently an MBA student at the University of Chicago. We've heard that-- or some of you have compared college education to a bubble. And I'm sitting here wondering whether it might not be a bubble but rather inflation. The same kind of healthy inflation that you would experience with inflation of GDP as the economy grows. So what I'm wondering is, do you feel like high school education, in the same way that it might have been sufficient for society in the '60s, is also sufficient for society today. Thank you.

### Moderator
Claim: Charles Murray.

### Conspiracy Advocate (CA)
Claim: Well, since I said that virtually everybody needs more education and training after high school, obviously, I think that high school is not sufficient.

I do think that a great deal of what we talk about as a liberal education can be done at the K-12 level. There are things like the core knowledge curriculum that's created by Edie Hirsch, which is just wonderful. And it doesn't teach everybody a full-fledged classical education, but it-- it gets a lot of the common cultural knowledge for everyone in K-12. We aren't doing it in college. I think we could do it there.

### Moderator
Claim: Let me take one more question. Green, wearing all green.

### Moderator
Claim: Hello. My name-- hello, my name is Katherine Darts and I'm an architect and academic here, that is educated in Chicago, Paris and Copenhagen also. My question to everyone on the panel, what do academic institutions need to do to eliminate the influence-based system of family's previous alumni relations and money that keep us from having this open competition of education that Mr. Murray wants and get us to the opportunity of--

### Moderator
Claim: I'm going to respectfully pass on the question, although I think it's a very valid point, because I don't think it's going to get us to the issue of whether too many kids go to college or not. Sir, in the black tie. But thank you for the question.

### Moderator
Claim: Hi. My name is Phil Pappus When I was young, I-- I read that majority of the CEOs in Fortune 500 companies only had a high school education. Due to the deterioration of secondary education in the United States, isn't college, a college degree, a necessity to show that you have something that was once called a high school degree?

### Moderator
Claim: Peter Thiel.

### Conspiracy Advocate (CA)
Claim: It's possible that that's-- well, I think high school is very-- lots of them are still very good. A lot of them are not. But I-- it seems to me that that's a perverse cure for the disease. And so if that is the disease, we should be fixing K through 12 education.

And I think probably all of us on the panel would agree that K through 12 education has a lot of room for improvement.

## Round 3

### Moderator
Claim: All right. And I have to say that concludes round two of this Intelligence Squared U.S. debate. And here is where we are. We are about to hear brief closing statements from each debater. The statements will be two minutes each. They will be uninterrupted. And remember, you voted before the debate, and this is their last chance for them to try to convince you that they have argued most persuasively. And you'll be asked to vote once again and choose a winner just a few minutes from now. So onto round three, closing statements from each debater in turn. Our motion is this: "Too many kids go to college." And here to speak against the motion, Henry Bienen, president emeritus of Northwestern University.

### Scientific Advocate (SA)
Claim: Well, no one seems to doubt, including our opponents, that there is a wage premium and a benefit to college. They may have some confusion about what kind of college, whether they're expensive or not, though the debate was not about cost, as I understood it.

Mr. Thiel raises, I think, interesting points about causation, the direction of causation. But I think it's clear also that going to college isn't of itself an effect. It's a variable which moves people along in their lives, gives them more chance and gives them more income, independent of all the other things that get them to college in the first place. Now, yes, there are too many people who are unprepared that go to college. And I agree with what Peter said at the very last minute, that it would be a perverse effect to say, okay, college is going to be remedial for the lousy high school education that they got. The answer to that, which we're trying very hard to do in Chicago, is to improve the K through 12 elementary and high school education. And that's key. That is key to society as it is to make sure that higher education is good and affordable for all.

So the answer is not that too many kids go to college any more than it would be too many kid go to high school or elementary school because they don't get a good education in too many of those places, and I'm sure there are plenty of colleges where they don't get a good education, sure, I'm sure that's the case. I've just never been in any of them but I know that they exist. So I think the answer is very clear and that you have to decide in the negative on the proposition that too many kids go to college. That is after all the proposition, it's not about costs, it's not about whether everything is perfect, at every college in the country, it's not about whether we should do everything exactly how we've done it, it is the proposition that too many kids go to college, and the answer is clearly and unequivocally that's a wrong answer.

### Moderator
Claim: Thank you, Henry Bienen. There's a little bit of a lag on that one, but our motion is "Too many kids go to college," and here to summarize his position in support of the motion, Peter Thiel.

He is PayPal cofounder who's 20 Under 20 Fellowship Awards grant cash to young tech entrepreneurs.

### Conspiracy Advocate (CA)
Claim: The one thing that was clearly not done by the other side was to answer my question about where would the accountability be for all the people who get hurt by the system that costs too much and is not delivering. And it is clear to me that there is no accountability on the part of our education establishment. They're not willing to give people refunds. They're not-- you know, if you get a Ford and it blows up, a Ford Pinto blows up, you can go to the Ford company, you can get money back for your car, you might even be able to sue them for torts, such a mentality is unthinkable in the college case. And given that there is this lack of accountability, buyer beware. You are on your own. You take on the loans. It's worse than housing debt. You can never get out of it, not even through bankruptcy.

Bush amended the bankruptcy laws in 2005 so you cannot get out of college debts for the rest of your life. And you need to think about this on your own. The way bubbles end is when people start thinking for themselves. And that is the first thing we want to encourage people to do is not to simply go with the social pressure, not to go with the bill of goods, "This has always been done. This is automatic. This is necessary. This is globalization." But think for yourself, "Is the cost worth the benefit?" And when more people think for themselves about this, we will get to a very different equilibrium where there's less of a caste system, less of a social need to do these things for status reasons, people will still go to college, they will still get advance degrees, but there will be fewer of them who do it because there are a lot of people who are doing it for the wrong reasons, and I think that will be a much healthier and more balanced country.

### Moderator
Claim: Thank you, Peter Thiel. Our motion is "Too many kids go to college."And here now to summarize his position against the motion, Vivek Wadhwa. He is director of research at Duke Center for Entrepreneurship and Research Commercialization.

### Scientific Advocate (SA)
Claim: Yeah. What I heard from the other side was that if we define college the way Middle America does, then we actually are agreeing that we want more kids to go to college, so I'm not going to spend my two minutes on that. I want to actually challenge my new friend, Peter Thiel, on something which is very dear to his heart, about the fact that it's so expensive to go to college. That I agree with him on. And it's also antiquated. The system's antiquated. Peter and I are both associated with a great university called Singular University, which is on campus, where we teach about exponential technologies, how all these advances are happening which can change the world, impact the lives of billions. Well, you know, think about it, five or 10 years ago did you ever use an iPhone or an Android? None of us did. I'll bet you everyone in the audience has one today. The fact is that it's now possible to communicate in ways we could never do before.

We have these tabular devices which can deliver 3D simulations, take us into 3D worlds. We can teach people by taking them into games. We can change the entire concept of education. He has the ability to do that. He has done it before with social network, with Facebook, he's done it with PayPal. He has the ability to do this. Instead of investing in silly little social media technologies, why don't we put our joint efforts into improving education if it's changing the way we deliver, to change the way we educate-- and changing the world. I tell you, Peter, you can make it happen. So I challenge you here publicly to put your energy into improving education, into automating, into rethinking the way we educate so that the masses can get educated because all of us agree that we do want more people to go to whatever we call college. Again, I'm not going to define it as a four-year degree, again to get more education so we can be more competitive, we can take on the world, we can change the world together. We're going to need it more than ever over the next few decades.

### Moderator
Claim: Thank you, Vivek Wadhwa. Our motion is "Too many kids go to college." And now to speak in support of the motion, Charles Murray.

He is author of "Real Education: Four Simple Truths for Bringing America's Schools Back to Reality."

### Conspiracy Advocate (CA)
Claim: I think that even though we're supposed to be diametrically opposed, in fact there’s a lot of common ground. It’s not a very good thing to say in a debate. But suppose we got rid of the B.A. because it doesn’t mean anything. Suppose we had as the goal of education not this piece of paper, but we had as a goal of education that all children shall reach adulthood having discovered things they love to do and having learned how to do them well. If we take that as the goal of education, we will have a system utterly different from the one we have now, and it will not be college as we know it. It will not be four years, and a lot of times, it won’t be residential. And most of all, it will not separate people into those who are college graduates and those who are not. And the fact is that every career-- excuse me-- goes through a couple of phases. We all start out as apprentices.

And after we learn our trade, we become journeyman. And some of us who get really good at it become master craftsmen. That is just as true of a history professor or a lawyer or a physician as it of a carpenter or a plumber or an electrician. The kinds of changes we need to make to our educational system, sweeping, fundamental reforms, getting rid of the B.A., moving to certifications, has as its ultimate goal, in my view, something that is very important for America as it is increasingly stratified by class. And that is that it promotes a recognition among us that we are all engaged in the same process. We are not divided into professionals and service workers or blue collar workers. We all start out as apprentices. We become journeyman, and we all strive to become master craftsmen. Thank you.

### Moderator
Claim: Thank you, Charles Murray. And that concludes our closing statements. We have been though all three rounds of this debate now, and it is time to learn which side you feel has argued best.

We’re asking you again to go to the keypad at your seat that will register your vote. We’re asking you to judge on this motion, "Too many kids go to college.” Which side presented the stronger arguments? Press number one if you feel this side, arguing too many kids go to college, presented a better argument. Press number two is it was this side. Press number three if you are or became undecided in the course of the debate. And we’ll have the results in about 90 seconds from now. So before I announce the results of that debate, I just want to first of all thank our panelists for coming here with the attitude and the kind of argument that we encourage. They were terrific. And I want to say something about the questions that were asked here tonight. I really wish that I can import you folks back to New York. Because we had a lot of trouble with the question situation there, and you all really got the message.

And there wasn’t a bad one among them. And so thank you very much, and thanks to the audience for all of that. So this is our first debate in the city of Chicago, and it was our second outside of New York. And we want to thank very, very much the organizers of Chicago Ideas Week for inviting us to be part of this program with them. And we also want to spend a very, very huge thanks to Grovenor Capital Management who underwrote tonight’s debate for us and made the whole thing possible. Thank you. So we are-- we head back to New York. We have two more debates in the fall season. You can actually watch those online, as this one, it’s been streamed by our media partner, Slate. It will be 5:45 p.m. on our debate days. And this is what we’re doing. On October 25, we’re debating the motion, “Congress should approve Obama’s jobs plan.” The panelists at this point include the chief economist at Moody’s Analytics and also a former economic advisor to President Obama.

On November 15, our motion is "The world would be better off without religion.” And our panelists then include a rabbi and Charles Darwin’s great-great grandson. Streaming at 5:45 on Slate.com. You can find a full listing of the panelists for these debates in tonight’s program, which you should have all been handed on the way in. And if you happen to be in New York for any of these, tickets are still available for some of them, for both of them. And for updates on future debates, you can go to our website. It just-- it says-- this is new to me. You drop a business card on one of the boxes on your way out, and we will follow up with emails on how you can get in touch with our website. We’re on Twitter, Intelligence Squared U.S. and you can become a fan on Facebook and get a discount to future debates by doing that. All of our debates can be heard on NPR stations across the country, including WBEZ here in Chicago. So if you tune in, you’ll hear your own applause, which makes it all worthwhile.

All right now, these debaters have been arguing the motion "Too many kids go to college.” We’ve asked you to listen to these debates as they went through three rounds. You voted before the debate and once again afterwards to tell us where you stood when you came in and which side you feel argued best. So here are the results. The motion, "Too many kids go to college." Before the debate, 39 percent supported the motion, 40 percent were against, and 21 percent undecided. After the debate, 47 percent are for the motion for the side for the motion. That's up eight percent. Against is 46 percent. That's up six percent. Undecided seven percent. The side arguing for the motion, just barely wins this debate. Our congratulations to them. And thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
