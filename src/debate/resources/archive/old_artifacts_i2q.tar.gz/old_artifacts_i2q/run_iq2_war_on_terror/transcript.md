# Debate Transcript

Topic: It's Time To End The War On Terror
Motion: It's Time To End The War On Terror

Debate ID: war-on-terror


## Round 1

### Moderator
Claim: I'd like to thank all of you for coming and to introduce the founder and chairman of Intelligence Squared U.S., Mr. Robert Rosenkranz.

### Moderator
Claim: Thank you very much, and welcome to the first debate of our fall season. We're excited to be back and pleased to see such a nice turnout. This crowd was not terrorized by the weather. This is our 51st debate, but it's our first with Slate as our media partner and our first for our new relationship with PBS and WNET as our television outlet.

We're delighted to have such first class partners, joining our effort to improve the quality of our public discourse. So to our resolution tonight, "It's time to end the War on Terror." Ideologically, the appeal of terrorism as a way to redress grievances has been undermined. The Arab Spring has accomplished far more through largely peaceful means than Al-Qaeda ever accomplished through violence.

Tactically, the balance has shifted. Osama bin Laden was uniquely charismatic and inspirational, with large financial resources. Now he's dead as are most of his lieutenants.

Al-Qaeda's leadership is fractured; its communications primitive; its financing highly constrained; and its operational capabilities severely limited. We achieved this result by expending enormous resources for intelligence surveillance, drone attacks and brilliantly coordinated raids, but the Al-Qaeda war was never going to be ended by a peace treaty.

History, however, has moved on; and it's time for us to move on as well. The War on Terror no longer makes sense as an organizing principle for U.S. policy.

But what's the counter argument to all of this? It is that we cannot simply declare victory and shift our concerns elsewhere.

Terrorist attacks are still occurring with depressing frequency in Iraq and Afghanistan. Pakistan's duplicity has been exposed, but it remains a nuclear power with destabilizing, radical Islamic elements. Suicide bombers are still an asymmetric threat and a tactic to be reckoned with. America's hated as much as ever by Islamic jihadists who certainly have the desire to inflict mass casualties on us through whatever means they can obtain.

This is not the time to bask in the glow of victory but rather the time to maintain the vigilance that has kept us safe during the decade we're about to mark this week. But which is the better argument? It's up to you to decide; and to help you make that decision, we've assembled an extraordinary panel of experts.

Before I turn the evening over to them and to our moderator John Donvan, I'd like to invite Jacob Weisberg, editor and chief of the Slate Group to say a word.

### Moderator
Claim: Bob, thank you. We at Slate couldn't be more excited about becoming Intelligence Squared's media partner. You know, from our start which is 15 years ago, Slate's been all about the value of debate and conversation, the dialogue that the web allows you to have instead of what you might think of as the monologue in print.

And I've seen that same approach embodied in the Intelligence Squared debates, both as a participant-- which, to my relief, I'm not tonight-- and as a member of the audience.

Like Slate, Intelligence Squared is committed to the view that serious argument can be entertaining and that ideas and policy can be fun.

On our site, we're hoping to extend these conversations in both directions. We're going to run pieces, articles to help frame the subjects in advance; and we want to continue the conversation after the event is over. This isn't the only debate we'll be covering, but we have a reporter here tonight in case you want to read tomorrow and read a journalist's take on what took place.

I should say we've had a terrific time already working with Bob, with Dana Wolfe and their amazing team to help craft the propositions for the fall season; and we hope we've got a roster of ones that will prove both urgent and engaging.

So the subject we're starting out with tonight, which Bob framed extremely well, couldn't be more vital in its importance to the city of New York, to the country and to the world. So I don't want to delay it any further. I will turn it over to get things under way. It's my privilege to give you John Donvan.

### Moderator
Claim: Thank you. Thank you, Jacob.

And Jacob, you were a very good debater, by the way. So I'd just like to invite one more round of applause for Robert Rosenkranz and Jacob Weisberg.

True or false: "It is time to end the War on Terror." That's what we are here to debate. This is another verbal match-up from Intelligence Squared U.S. I'm John Donvan of ABC News. We're at the Skirball Center for the Performing Arts at New York University and on hundreds of NPR stations across the nation. "It's time to end the War on Terror." Two teams will be arguing that proposition from opposite sides for it and against it. And all of our debaters come at this topic from firsthand experience. They include security expert Peter Bergen, who as a journalist, interviewed Osama bin Laden in 1997 and sent out some of the earliest warning signals. Ladies and gentlemen, Peter Bergen.

Peter, we're doing a preliminary introduction and then--

You know what?

You know what? Peter did exactly what we asked him to do. But we forgot to tell him it was going to happen twice.

And that's our fault. My apologies. His debating partner, Juliette Kayyem, who in the Obama administration was an assistant secretary for Homeland Security.

Opposing them at the facing table, Mike Hayden, who ran the CIA and before that, the National Security Agency--

--and Richard Falkenrath, who advised President Bush on Homeland Security, then moved to New York City to become deputy commissioner of Counterterrorism.

So all four of these people know what they are talking about, and yet they disagree on calling an end to the War on Terror. All of them are dedicated to winning you over to their point of view here in our live audience because you, our live audience, are the judges in this debate, and that's what this is.

It is a contest. There will be winners and losers. And in this contest, you will decide who wins.

We're going to ask you, by the time the debate has been concluded, to vote twice-- once before and once again afterwards; and the team that has changed its numbers the most, changed most of your minds, will be named our winner.

So let's go first to the preliminary vote. You each have keypads at your seats. Our motion is this. "It's time to end the War on Terror." If you agree with this proposition, push number one. If you disagree, push number two; and if you're undecided, push number three. And if you feel that you made an error in the process, just correct it, and the system will lock in your most recent vote.

It looks like everybody's done. So to remind you again, that vote will be tabulated immediately, but we'll hold the result till the end of the debate to tell what you that base number is; and then we'll have you vote once again at the end of the evening, and the team that has changed the most minds will be declared out winner.

So on to the debate, round one, opening statements from each debater in turn. Our motion is this: "It's time to end the War on Terror." And speaking first for the motion, I'd like to introduce Peter Bergen, a CNN national security analyst.

He's director of National Security Studies at the New America Foundation and a best-selling author. In 1997, he traveled to Afghanistan and conducted Osama bin Laden's first television interview.

And Peter, I just want to share with you the fact that even your opponents can see that your knowledge of the operational details of terrorist groups is encyclopedic. I don't know if that's a psych-out--

--or not, but I hope you can take it as a compliment.

### Conspiracy Advocate (CA)
Claim: I do.

### Moderator
Claim: Okay. Ladies and gentlemen, Peter Bergen.

### Conspiracy Advocate (CA)
Claim: Thank you.

First of all, Juliette and I wanted to acknowledge the three and a half decades of public service that General Hayden has done and also Richard Falkenrath's more than a decade of public service.

I also wanted to acknowledge Juliette Kayyem's decade and a half of public service where she became the highest ranking Arab-American in the Obama administration, the assistant secretary to the Department of Homeland Security. She also had three kids that she raised at the same time, putting home into Homeland Security in a meaningful sense--

--and is one of the world's leading experts on the question of homeland security. My own connection to the story came when the Trade Center was bombed for the first time in '93. I traveled to Afghanistan, produced a documentary about the threat we face from Afghanistan and then, of course, interviewed bin Laden.

I've written three books on the subject of Al-Qaeda. I've embedded with our troops on multiple occasions in Iraq and Afghanistan.

From a self-interested point of view, I have every incentive to say the threat that Al-Qaeda and terrorism poses to us remains very serious. And it merits on open-ended conflict against them; but in good conscience, I simply can't make that argument.

War is no longer the most appropriate way to look at the problems we face today. Our singular focus on terrorism also masks many more pressing problems. Our crumbling infrastructure, our decaying schools, deeply serious economic problems.

Another national security problem is managing the future of the Arab Spring, for instance; preventing nuclear war between Pakistan and India; preventing a nuclear war between North Korea and South Korea; managing the rise of China which, while we’ve been distracted by the War on Terror, has quietly expanded its influence in Africa and in Southeast Asia.

Our opponents want to prolong the War on Terror, an open-ended conflict against a tactic that is already America's longest war. We're saying it's time for war to end.

President Obama correctly redefined this conflict downwards from a global open-ended conflict against the tactic to the more precise formulation of a war against Al-Qaeda and its allies, which both names the enemy and narrows the focus of the conflict.

When we say it's time for the War on Terror to end, we don't mean we should precipitously pull out of Afghanistan, but we do mean that it's time to stop conceiving our principle national security goal as the defeat of terrorists when putting, for instance, our own economic house in order will do far more to prepare us for the next real war we'll inevitably face at some point in the future.

The War on Terror, as everybody in the audience knows, has caused the American public at least a trillion dollars in expenditure and wars around the world and, of course, got us into the catastrophic Iraq War; further trillions on our-- both our Intelligence and Homeland National Security apparatus resulted in policies such as coercive interrogations and extraordinary renditions.

And you'll hear from my partner that the government has for years anyway moved away from the War on Terror and what it entails, not because there was no threat. We're not claiming that at all but because the threat has changed and has adapted and so we must-- we as well.

Key American National Security officials now say that Al-Qaeda's on its last leg. John Brennan, who, of course, is President Obama's chief counterterrorism adviser, said that just last week.

Leon Panetta said that the strategic defeat of Al-Qaeda is within sight.

General David Petraeus has made the same sort of comments recently. None of these gentlemen can be considered to be defeatist or soft on terrorism. So is this premature triumphalism the claim that Al-Qaeda is on its last legs? Well, I think the claim is well-justified. I mean, the leadership of Al-Qaeda's been completely decimated in the campaign of drone attacks.

The most dangerous job in the world right now has been Al-Qaeda's number two. There have been about 20 of them since 2008, including most recently, the group's number two out here, Atiyah Abd al-Rahman, who was killed just a few weeks-- just about a week ago.

Al-Qaeda hasn't carried out a successful attack in the West since the 7/7 attacks in London six years ago. Al-Qaeda hasn't killed a single American in the United States since 9/11.

And think about the real wars we've really confronted. The Civil War threatened to tear this country apart. World War II, we defeated an enemy that instigated a global conflict to kill tens of millions, and if the Cold War had ended with a bang instead of whimper, we'd all be not in this debate because we'd all be dead.

Those are serious threats.

The War on Terror-- the threat we faced from Al-Qaeda doesn't come close; and in fact, only 17 Americans have died as a result of Al-Qaeda's ideological ideas in this country, 13 of them, of course, at Fort Hood and others in other places.

More Americans accidentally die in their own bathtubs every year by considerable numbers around 300, and we don't have an unreasonable fear of bathtubs; so we shouldn't have an unreasonable fear of Al-Qaeda.

And by terrorism we're terrified, by the way, of course, and we're doing the job of the terrorist for them if we live in this state of constant fear that our opponents wish us to live in. And everybody in the audience knows very well that the threat from terrorism is actually dramatically receded in the years since the 9/11 attacks; and that's in part because Al-Qaeda and bin Laden have been losing the war of ideas in the Muslim world for years.

Their founder and leader was killed, as you know, in Abbottabad on the evening of May 1st. In the Arab Spring, there's not a single revolutionary who's carrying a single picture of Osama bin laden.

Bin Laden's ideas have been completely absent from the Arab Spring. There hasn't been a single flag burning in the Arab Spring of an American flag or even an Israeli flag; so bin Laden's foot soldiers, ideas and leadership are simply absent from this enormously important phenomenon in the Arab world.

Our opponents may claim that we're still threatened by terrorists armed with weapons of mass destruction. This claim, of course, follows simply the disastrous war in Iraq; and in fact, the 188 jihadi terrorist cases in this country since 9/11, not a single one of them involved chemical, biological, radiological and nuclear weapons.

We will no doubt hear from our opponents that to argue the War on Terrorism is overly soft or unrealistic or weak-- and they make claim that, at some point, we will decide we no longer need to define it as a War on Terror, but we aren't there yet.

I would submit to you in the audience, if the death of the founder and leader of Al-Qaeda isn't the point where we can say the War on Terror is over and then add to that the destruction of almost its entire top leadership, its absence in the revolutions across the Middle East, its inability to mount any kind of attack on the United States for a decade isn't the point to end the War on Terror, when will that point be?

We say it's now.

### Moderator
Claim: Thank you, Peter Bergen. Our proposition is "It's time to end the War on Terror," and here to speak against this motion, Michael Hayden, an Air Force four-star general. He's former director of the National Security Agency and the Central Intelligence Agency. He has overseen virtually every branch of the Intelligence community. He is now a principal at the Chertoff Group as is his debating partner, Richard Falkenrath. And I understand, Mike, you have a great deal of Pittsburgh in you--

### Scientific Advocate (SA)
Claim: I do?

### Moderator
Claim: --and that Pittsburgh returned the affection by naming a highway, a stretch of highway after you.

### Scientific Advocate (SA)
Claim: Actually, it's a street right next to Heinz Field; and the first question I asked was "Can I park there during football games?"

### Moderator
Claim: How do you work that out? Do you just drive up and down your street all the time--

--looking at the signs?

### Scientific Advocate (SA)
Claim: Take the grandkids--

### Moderator
Claim: Ladies and gentlemen, Michael Hayden.

### Scientific Advocate (SA)
Claim: Thank you.

Well, good evening. Thanks for the opportunity to talk about such an important topic, and it really is an important topic. It's not something that we should just decide idly. It's not something we should decide because we're really in a celebratory mood.

When I-- when I talk to audiences about the War on Terror, I generally refer to a speech I gave at the German Embassy in the spring of 2007. The Germans were in the chair of the European Union, and the German ambassador would have the ambassadors to the United States from the European Union over for lunch about every two weeks and would have an American come in to kind of be the lunchtime entertainment, and it was my turn.

I decided that the German ambassador was a good friend, and he deserved a good speech; and I decided I would talk to the European Union delegates about renditions, detentions and interrogations that were being conducted by the CIA at that time.

About page two or three of that speech, I wanted to make very clear to my audience what I thought, what my agency thought and what I think my nation thought. And I gave them four sentences. "We believe we are a nation at war." "We are at war with Al-Qaeda and its affiliates"-- the description that Peter just gave and that President Obama emphasized that reflected what we were thinking several years earlier. "A nation at war"; "At war with Al-Qaeda and its affiliates"; "This war is global in scope"; and "We can only fulfill our moral and ethical responsibilities to you, the citizens of this republic, by taking this fight to this enemy wherever he may be." George Tenet was the DCI, the Director of Central Intelligence. In 1999, sent a note out to all of us in the Intelligence community, saying "We're at war with Al-Qaeda." And George was but America wasn't.

America went to war with Al-Qaeda shortly after the attacks on September 11, 2001.

Two successive American presidents have defined us as being at war with Al-Qaeda. The American Congress has defined us as being at war with Al-Qaeda; and the American court system, only a few blocks from here, has defined us as being at war with Al-Qaeda when a defendant, attempting to claim he had been denied his right to a speedy trial because he had been in detention for several years, his claim was rejected by the court, saying we, as a nation at war, had a right to detain him as a combatant.

Now, we could discuss troop levels in Iraq, the rate of withdrawal from Afghanistan, a whole bunch of other details about this war, but that's not the point I think Rich and I want to make. The point we want to make is the legal construct-- the legal belief that we are a nation at war; that we are a nation in conflict; and we have a right, because we are in that status, to use the legal tools and the legal authorities that a nation at war is allowed to use.

What it is we're supporting is to keep all available tools on the table-- to keep a menu of options from law enforcement, diplomacy, or to arm conflict in order to keep you safe.

I would also add-- and I really want to emphasis this-- that conceiving yourself at war in addition to whatever it is you might do in a law enforcement channel is not somehow lawless. It is perfectly lawful. It is a different lawful approach than a law enforcement approach, but it is consistent with the laws of armed conflict that we have a right to resort to in order to defend ourselves.

I assume everyone here is happy that Osama bin Laden was killed on the morning of the second of May in Pakistan.

Let me give you-- thank you. Let me give you a slightly different description of that event. A heavily armed agent of the United States government was in a room with an unarmed man who was under indictment in the United States judicial system and was offering no significant resistance to the heavily armed agent of the United States government, and that heavily armed agent of the United States government killed him.

If you do not think we are at war, there are some very troubling definitions that you might want to attach to that act. That's the kind of authority we have perfectly lawful-- and no way am I suggesting anyone acted inappropriately. We acted perfectly lawfully because we are a nation at war and generally recognized as such.

You don't want to take those tools off the table while there are terrorists out there.

If you let this tool go, you will be less safe. Okay. If you look at the scope of our constitutional system, the law enforcement approach is designed, if you look at the constitution, the Bill of Rights and the American statutory law, the law enforcement approach is designed to make the government weak because we don't want the government arbitrarily taking away your liberties.

On the other hand, if you look at those sections of the Constitution that deal with armed conflict, they're designed to make the government strong so that it can protect you. You don't want to take that tool off the table. And quite perversely, if you take that tool off the table, you may actually threaten your own civil liberties.

Bear with me. There's a tight connection here. If the options of a nation at war are taken away from your tool kit, you must then rely on the options offered by law enforcement.

If you recall the events in-- on Christmas day a year or two ago, Detroit, Umar Farouk Abdulmutallab, the "Underwear Bomber"-- and he was Mirandized after about 50 minutes of interrogation, and I think everyone recognized that was probably a mistake. We should have interrogated him further.

We had the attorney general talking to the American Congress about legislation that would make Miranda more malleable so that we could interrogate these kinds of people longer in our law enforcement approach.

I don't want to make Miranda more malleable. Miranda defends me. Defends you. Defends your rights. And we're forced to contort the law enforcement approach when we attempt to make it answer and deal with questions it was never designed to deal with. This is one of those questions. Don't take that other tool, "We are a nation of war" off the table. Thank you.

### Moderator
Claim: Thank you, Michael Hayden.

Our motion is "It's time to end the War on Terror." We are now halfway through opening remarks of this Intelligence Squared U.S. debate. I'm John Donvan of ABC News. We have four debaters, two teams of two, fighting it out over our motion, our proposition, "It's time to end the War on Terror." You have heard two of the opening statements, and now on to the third. I want to introduce Juliette Kayyem, who, as I said at the beginning of the debate, these people on the stage really have had their hands in the business that they're talking about.

So her resume includes stints at the Justice Department, former assistant secretary to the Department of Homeland Security, the national security and foreign policy columnist for The Boston Globe. You've also served as chief of Homeland Security in the state of Massachusetts. You're a faculty member at Harvard's Kennedy School a Government; a mother of three, we've heard earlier, and often described as the Obama administration's highest ranking senior Arab-American female official.

### Conspiracy Advocate (CA)
Claim: Wow. Wow.

### Moderator
Claim: So which of those--

### Conspiracy Advocate (CA)
Claim: Tells you how many.

### Moderator
Claim: Which of those items is the most relevant?

### Conspiracy Advocate (CA)
Claim: American. American.

### Moderator
Claim: Ladies and gentlemen, Juliette Kayyam.

### Conspiracy Advocate (CA)
Claim: So I want to thank Bob and Dana, Peter, Mike and Rich and the organizers of Intelligence Squared; and I also want to take a moment to acknowledge, obviously, tonight, 10 years later and the tragedy and burdens this city has suffered.

We will debate with passion here but with the full acknowledgement that many of you suffered tremendously. The proposition I'm arguing for tonight is the War on Terror is over. That can mean a lot of things, obviously.

For me, it means one thing. A certain mind-set came to be known as the "War on Terror," and that mind-set, thankfully, is over. To explain what I mean, I want to tell you a story.

I did reenter government in 2006 when Governor Deval Patrick became governor of Massachusetts; and one of my duties was to oversee the Massachusetts National Guard.

I inherited a program that had been established on September 12 which was to put National Guard members on the roadways, leading up to our only nuclear facility, Pilgrim facility, and it was understandable in those days, you wanted to show greater force protection.

More than five years later, they were still there, the National Guard members. Despite the tremendous work being done to counter the terrorist threat and despite no evidence that terrorists would seek to enter by road a heavily fortified facility, nobody involved with intricacies of that security thought that they were still necessary, but no one really knew how to pivot. It's very hard to pivot.

And the political military and public input had to be aligned. It took us awhile, but eventually we did move on, and I tell that story not as evidence that the terrorist threat is over, not at all. I tell it to say that there were other procedures that we then put in place, more aggressive surveillance, sharing better surveillance of the streets, better communications between the nuclear facility owners and the local first responders that we instituted instead of the 19 National Guard members rotating 24/7.

I tell this story to remind you that 10 years is a long time. It is a long time to fight any war but one particularly where the enemy has changed so dramatically. And over that time, there had been a whole range of shifts in every jurisdiction in the federal government that had been similar to the one I just described.

So to just call the ongoing efforts to dismantle, kill and disrupt Al-Qaeda and its affiliates a continuity or continuation of The War on Terror-- capital T, capital W, capital T-- is to treat the United States and the government apparatus established since 9/11 as frozen in time.

It assumes that there has been no learning, no growth, no perspectives achieved, no recognition of mistakes made, no priority shifts, no advancements in our abilities and capabilities. It assumes that time had stood still for us.

In many respects this debate actually is a few years too late. The War on Terror, as it became known, was an entire government ideology, based on the notion that Islamic terrorism represented a unified and operationally centralized threat to manning a predominantly military response with the President as commander in chief who could use any means necessary.

Nobody, especially people who have served in National Security, denied that there is still a terrorist threat, and the U.S. Government, under any administration, to pick up on General Hayden's point, is going to have a variety of tools to use to combat that threat, including military force.

Nobody needs to make apologies for that, neither the left nor the right. The authorization for the use of military force passed immediately after 9/11, gave the President and the future ones the legal authorization to fight Al-Qaeda with force.

It is still the law today, and it is still good law; but the fact that the government continues to use many of these same counterterrorism strategies, including killing bin Laden, of course, does not mean that the War on Terror and all that it entailed remain because we should go through the list-- the enhanced interrogation, the dark side, the with us or against us, the indiscriminate interviewing a particular Arab and Muslim communities, the registration of Arab immigrants, military tribunals that adhere to standards unrecognized in military law, the color code alerts, the breathless press conferences, the rejection of the law of wars, the treating of the Geneva Conventions as quaint, secret wiretapping and violation of established law, the disdain for the judiciary-- those were also part of that war.

And thankfully, they are over, and they began to be over during the Bush administration and the continuation in this administration. It has not been more of the same, and that is good because we got better. Over these 10 years during both Bush and Obama administrations, the U.S. Security apparatus became more focused and sophisticated.

It was because the threat had changed. It was more decentralized and disparate, and we have adapted to that, certainly, by using military tactics to kill Al-Qaeda affiliates worldwide, but we have also become more focused, measuring success by effectiveness over shear activity.

And nowhere is this more true than in Homeland Security. Unlike war, Homeland Security is very bottom up. It begins with locals who run police departments or emergency management divisions or public health facilities.

It is overseen by mayors and governors, and if you want to talk about a change in America, there's only one governor who was governor on 9/11 still in the State House, and he's debating in California right now because he doesn't want to be governor anymore. That's Rick Perry.

So, I mean, there's just been tremendous change over these 10 years; and so calling it a War on Terror for them does not help them manage budget or defend certain programs or know actually how to prioritize.

As Rich Falkenrath-- who helped institutionalize the phrase "dual-use" policies that help the cop on the street in fighting crime as well as in counterterrorism; that provide training for emergency managers for a tower falling as well as Hurricane Irene-- these are the most sustainable and effective.

The color-code system seemed appropriate in an era that created a warlike climate but provided no clarity to the first responders on how to-- how to react, and the public rightfully rejected it.

More localized efforts to engage immigrant communities or in nationally adopting to "See Something, Say Something" campaign that came out of New York City are good and effective government action, and they are necessary as we have reason to be concerned with radicalization in our own nation.

None of these require military engagement or mind-set although, of course, as I've said, there might be a need for military engagement, and it's authorized by law. These are smart strategies adopted by people across the ideological spectrum.

I am here not because I have some invested intellectual interest in saying the war is over. Military efforts will need to be utilized. That goes without saying. But do not forget what the War on Terror was, and do not forget how much progress we have made in moving past it.

What has replaced it is a different way of thinking about the threat and our response. Surely, not everything is perfect, but criticism is accepted. There is nothing soft or weak or liberal about believing the War on Terror is over. It is actually the way the world is; and ask yourself "Are we less safe now from having moved on?"

### Moderator
Claim: Thank you, Juliette Kayyam. Our motion is "It's time to end the War on Terror." And here to speak fourth and against the motion, Richard Falkenrath, who has served as deputy commissioner for Counterterrorism of the New York City Police Department and as deputy, Homeland Security advisor to President Bush during the Bush Administration, obviously.

And Richard, I don't know if you know this, but coincidentally, we lived on the same street in Washington during that period, and all of the neighbors had a habit of watching your face as you would come home from work every day to try to figure out if we were in trouble or not.

And I just wanted to congratulate you on your poker face.

### Scientific Advocate (SA)
Claim: Oh, thank you.

### Moderator
Claim: And we never knew. Ladies and gentlemen, Richard Falkenrath.

### Scientific Advocate (SA)
Claim: That was a scary time, and happily it's over. Now, forgive my voice. I've got a little bit of a cold. It's a great pleasure to be here. Thank you to the organizers, the sponsors, to the other panelists, all of whom are long and close friends. We've known each other for a long time.

Debates like this often turn on trying to convince the audience, the voters, of a definition; and if you get them thinking about a proposition defined your way, it's clear which side should prevail, and if you get them thinking about a proposition defined the other way, it's clear which side should prevail. And this is no exception to that rule.

The War on Terror is a very open-ended concept, and it can be construed in many different ways. And Peter and Juliette are-- construe it in a way that really isn't that surprising, but they were very candid about it, frankly, which is they'd like it to be defined as a certain mind-set that we experienced some point in the past that we no longer should have today.

And I find, if I were probably-- if I was on their side of the proposition, I'd argue it the same way because this is a tough one to argue if you argue it the way Mike and I think it should be argued which, in fact, Juliette agrees with, which is you need to make this an operational proposition. You need to define it in some very precise way so there's something really to weigh in on. It's not just some squishy mind-set and set of feelings. It's actually something practical. And here, in fact, it is something practical.

War on Terror-- war is a legal state, as Mike said. It exists in law. It is decreed by Congress and, in fact, they did decree it in this case with the authorization for the use of military force, passed by Congress on Sept. 14, signed by President Bush on Sept. 18, and still in force today.

And the way I understand this proposition that we're voting on here, is essentially-- "Should we repeal or modify this in some way or another?" And Mike and I say, "No, we shouldn't. This should still stand." Juliette also agrees with us. She thinks it should stand too. I'm not sure where Peter is.

But it's worth noting exactly what is says because this is what it means to be in a War on Terror. It means to have this as your law of the land. It says that the President is authorized to use all necessary and appropriate force against those nations, organizations or persons he determines planned, authorized, committed or aided the terrorist attacks that occurred on September 11th or harbored such organizations or persons in order to prevent any further acts of international terrorism against the United States by such nations, organizations or persons. Now, our position is quite simple: it's that this should stay the law of the land. This should be the law in the United States, because, if it's not, then something Peter said is no longer the case: having the number two job in al-Qaeda is no longer the most dangerous job in the world.

It is today. And he's still there. The number two in al-Qaeda-- it's much, much diminished, decimated probably isn't too strong a word for al-Qaeda. But the number two officer in al- Qaeda on 9/11, Ayman al-Zawahiri, a shadow of the man bin Laden was, he's still alive. He's in Pakistan. But for this provision of law, we can't use military force unilaterally against him. This is what makes such action lawful, and without this, the alternative is to go arrest him, mirandize him, bring him back to the court, which is an option, which frankly I don't believe should be taken off the table, either. Probably not what we will end up pursuing in his case. But it simply makes no sense. It makes no sense to say you should repeal this. So that's my sort of first big point to you, is this is the law of the land. The war on Terror is a legal state that gives us opportunities to do things under the code of law, not extra-legally, so, if that commando team does go in and kill someone, it's not murder.

It is, in fact, an act of war. Blessed by both branches of government-- the judiciary-- the executive and the legislative-- and without this, illegal. So, we don't want that. And this strikes me as, clearly, sensible to continue.

Now, should it continue indefinitely? Who knows? I'm not prepared to say exactly when it should stop. But right now, today, when we know, some of the perpetrators of 9/11 are still at liberty, presumably in Pakistan. It really makes no sense whatsoever to repeal this. Now, Juliette and Peter would have us think instead about the proposition in a different way, and say, “It's about a mindset.” It's about that terrible state when John referred to when neighbors would look at a Senior White House Official's face to see how it was when he came home from work. Those days are happily over, and hopefully they'll never come back. That's really not the proposition here. Yes, there were lots of that we're-- if we want to have another proposition which was, did President Bush overdo it in the first four years after 9/11, that's a whole different debate. And maybe, they will prevail on that one. We're debating a different proposition here. This is not about whether we think President Bush got it just right in the first couple of years after 9/11 or not. This is also not really a partisan issue. And yeah, I worked for Bush. But I also worked for Mike Bloomberg. He--who knows what he is. I mean, he was a-- now he's independent. Then he was a Republican. At one point, he was a Democrat. This is not really a partisan thing. But Peter made an interesting point. He said President Obama has more correctly and more precisely characterized the continued offensive action against Al- Qaeda and its affiliates. And he's absolutely right, that the president-- President Obama's rhetoric is very different from President Bush's. They talked about it very differently. But the practice-- the nitty-gritty of what happens in counter-terrorism internationally, operationally, from the last four years of the Bush administration to today, in 9/11-- not only is it fundamentally unchanged. Obama is tougher. He is harsher. He is sharper. I'll give you just one example. I understand-- Mike probably knows this-- I just hear it from the news. There is a list of individuals who may be targeted, by name, individually, for lethal air strikes. Under-- that list started under Bush.

I think it notified to Congress. Under Bush, that list consisted of only non-U.S. persons. So, foreigners. If we are to believe what we read in the paper, President Obama has added a U.S. citizen to that list, who may be targeted by name. This is an extremely liberal, former constitutional law professor who has added a U.S. citizen to a list of people who may be targeted by name. Now, he does it because of this aspect of law, which consists today. That individual, Anwar Al-Awlaki, is in Yemen. He's a U.S. citizen. He is vulnerable to lethal strike today that are lawful under U.S. law. I submit today it makes no sense to repeal that law at this time, and thus, under the terms of this debate and the War on Terror. Thank you.

## Round 2

### Moderator
Claim: Thank you, Mr. Falkenrath. And that concludes Round 1 of this Intelligence Squared U.S. Debate, where the motion being argued is, it is time to end the War on Terror. Keep in mind how you voted at the top of the evening. We're going to ask you to vote again at the end of the debate, and reminding you that the team that has changed the most minds will be declared our winner. Now, before we go on to Round 2, I want to correct a mistake I made in the pronunciation of Juliette’s surname. And I just want to-- not just to be nice-- I want to actually say it again as I said it at the beginning of the program, so that it can be edited correctly into the radio broadcast. And so, I'm going to say and then I'd love it if you clapped with as much-- fervor as you did the first time. And Peter's partner, Juliette Kayyem, who-- in the Obama Administration-- was an Assistant Security for Homeland Security. Yeah. Yeah. I apologize. I really think name pronunciation is entirely unforgivable, so you don't even have to forgive me, okay?

So, now onto Round 2, where the debaters address each other directly and answer questions from the audience and from me. We're here at the Skirball Center for the Performing Arts at New York University. We have two teams of two arguing this motion-- “It is Time to End the War on Terror.” The side arguing for that proposition-- Juliette Kayyem and Peter Bergen-- are arguing that it never made sense to call our response to September 11th “The War,” and that in any case, the enemy that provoked that war-- Al-Qaeda-- is now on its last legs. Arguing against the motion-- that it's too soon end the War on Terror-- Michael Hayden and Richard Falkenrath. Their view, that there are still enemies out there, dedicated to hurting us. And as-- that as long they are there, calling it a war gives the government the tools and the powers that it needs to protect the people. So, I want to ask a question to the side that's arguing that it's time to end the War on Terror. And it's this: Do our enemies have any say in telling us whether this is a war or not? If they are there, and they want to hurt us, and even if Al-Qaeda had been-- had been put on the run, it was clear in the documents that were recovered from Osama Bin Laden's hideout, that they were still trying.

And as long as they're still trying-- as long as it's a war to them, can we say that it's not a war to us?

### Conspiracy Advocate (CA)
Claim: Well, there's a very substantial difference between it--

### Moderator
Claim: Peter Bergen.

### Conspiracy Advocate (CA)
Claim: I mean, sure, there was often-- when, in Bin Laden's house, in Abbottabad, or after all these blue sky plans to attack us on the 10th anniversary of 9/11. I think I can tell you right now, that's not going to happen. These were blue sky plans. These were kind of doodlings of a guy was basically spending five years with his three wives, with not much to do-- and thinking about, you know, like, some sort of grotesque parody of a Dr. No James Bond, sort of sitting there, coming up with-- plotting mayhem. But these were not, you know, the government itself-- DHS-- has said you know, that you know, these were-- there was nothing there then. There was no operation. He was essentially somebody who history had sidelined.

You know, President Obama has said something I think is quite accurate. “He's a small man on the wrong side of history.” And history just sped up for them, with the Arab Spring and the death of Bin Laden. And for us to sort of live in a state of constant fear that they're going to do something to us is to basically hand them a victory that they didn't even have--

### Moderator
Claim: Let's hear from Richard Falkenrath.

### Conspiracy Advocate (CA)
Claim: --when he was alive.

### Scientific Advocate (SA)
Claim: The direct answer to your question, John, is no, they don't. Whether we are at war or not is up to the United States and its constitutional authority to decide. But Peter did something once again that he did in his opening remarks, which is try to get you to think that we somehow stand for the proposition that you should live in constant fear forever, and it should never go away. That's absolutely not what we're saying. Nothing could be further from the truth. I worked for the NYPD. Our job is not to make the people feel unsafe in their communities. We want people to feel safe. That's why you show up to work in the morning and do your job. So, just, let's be clear. We're at War on Terror. We have this continued legal status of a War on Terror so that everyone doesn't live in constant fear.

### Conspiracy Advocate (CA)
Claim: Okay, okay--

### Moderator
Claim: Juliette Kayyem.

### Conspiracy Advocate (CA)
Claim: --I'm a lawyer, and let me tell you what the AUMF says. Because I agree with it. And I agree with them. I thought the question was, should the War on Terror continue? So, I didn't bring my legal books. But if you want to view the War on Terror as solely a legal issue-- the authorization for the use of military force is because of a debate between-- hard to imagine that they actually debated this after September 11th-- is limited to Al-Qaeda and its affiliates. And it gives the President authorization to use a whole bunch of tools-- including military action-- but a whole bunch of them, to fight Al-Qaeda-- those responsible for 9/11-- and its affiliates. That's what it does. And that is great. And we should continue to support it.

### Scientific Advocate (SA)
Claim: But why is that

### Conspiracy Advocate (CA)
Claim: But under that not everything was done under the AUMF. First of all, this notion of a War on Terror justified-- and we can get into a legal argument. And I did this for a while, so I'm happy to get into a legal argument.

The Authorization for the Use of Military Force was limited both in terms of its target, and did not initiate a War on Terror. But let's also not forget their legal analysis. Their legal analysis-- if you want to talk law-- was actually that because it was a War on Terror, Congress in many ways could not limit the President's authority in a number of items that we can remember-- that we can all go through. So, if we're going to debate law, let's debate the law as they interpreted it. But we're not here to debate law, because that's not why-- that's--

### Moderator
Claim: Michael Hayden.

### Conspiracy Advocate (CA)
Claim: --too easy.

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: It's too easy to debate the law, because then, actually, I'm on their side. Then I shouldn't have shown up.

### Moderator
Claim: Michael Hayden.

### Scientific Advocate (SA)
Claim: I just want to add, whatever label we put on it-- “War on Terror” or “War Against Al-Qaeda,” it still is the legal authority under which we operate, but against Al-Qaeda and its affiliates. That all we have been doing-- all that we have done, has been designed against that opposing armed enemy force-- Al-Qaeda and its affiliates.

So, don't be confused by the labels. All along, despite whatever the rhetoric may have been, we used-- again-- the tools of our own conflict against a specific set of enemies, authorized by the Congress of the United States.

### Moderator
Claim: But do you hear your opponent saying that's as a practical matter-- as almost a cultural matter - - the term “war” suggests much more than the issue of a legal authorization-- that it does reflect a mindset, and taking a side is keeping a population in fear.

And that charge-- it does reflect a mindset, a commitment to discussion over resources, a discussion over sacrifice, that talking about a war is a great deal more than the narrow legal sense that you're talking about.

### Scientific Advocate (SA)
Claim: Well, it can be, but you need an actionable proposition. I mean, you need something you actually can decide on. And when it's so subjective that you're talking about a mindset, it's like - - General Hayden and I showed up in the same government for three years or so. We didn't come to work with an identical mindset. We came with slightly different mindsets, and he-- at the time-- was an active military officer. I think it had a different meaning to me then as a civilian in the White House. So, it's a very subjective thing.

One of the things about this war-- which is different from, certainly, World War II or Vietnam-- is that the national security apparatus-- and actually a subset of it, feels like it's at war. Still to this day. But the people don't. And that's ahistoric. So, it hasn't usually been that way for us. And I actually think that's okay in this particular case for-- not everyone to feel like they're walking around, feeling like they're mobilized for war-- but for a subset of the national security apparatus to actually act that way.

### Moderator
Claim: So he's saying your definition of war is too subjective.

### Conspiracy Advocate (CA)
Claim: He is saying that. Yeah.

### Conspiracy Advocate (CA)
Claim: I think that's a weird way to put the War on Terror, only because what followed from calling it a War on Terror-- which was not my language. I mean, that was the language of an administration that determined that after 9/11, we would conceive of it at as war. And it would have all sorts of implications-- not just legal implications, but implications for a whole range of activities, because we were going to call it a war.

And all the-- so, it wasn't just a feeling. It was a series of procedures and policies that flowed from that. So let me just give you an example, because that may help-- what this legal debate means. So by deciding that it's a War on Terror. So, that's what it is. This is the debate about military commissions. What do we mean by military commissions?

Well, if it's a War on Terror, that is this thing that we can define and determine where we want to go with detainees or how we want to try or not try them. Then, we create a whole new military commission system that, under the previous administration, got essentially overturned by the Supreme Court. And then you have to come back, right? And then you have to say, “What are we going to do with these detainees?” Because it's a problem. We all agree it's a problem. And then you come back, and you work with Congress, and you create a military commission-- which this president did-- which provides very strong protections for the people within the military commission system, has independent appellate review-- and let's just be clear, has been supported by every Article III court, every federal court in the United States. We're not at a constitutional crisis every day. We're just not there.

So, it wasn't our language. It was the language of the AUMF-- authorization for the use of military force against Al-Qaeda and its affiliates. Wasn't our language. So to say now, that we're calling it a feeling seems like it's just a little bit of amnesia there, I think.

### Moderator
Claim: Mike Hayden.

### Scientific Advocate (SA)
Claim: Yeah. I'm confused. Are we a nation at war or not, is the question I would ask. And do our armed forces have the right-- does the president have the right to use the tools of a nation in conflict, to protect you against Al-Qaeda? We've got some commentary here about some things that were done over the last 10 years. And there's some criticisms-- or implied criticisms-- that some of these were overreactions, or not in the best traditions, or novel developments in American constitutional military law. I'm not here to debate that. I am here to suggest that we are not at our best when we are fearful. And that the degree that we are not fearful, we adhere to the best of our traditions. Lincoln's quote about the better angels of our nature.

We are able to do that more freely now. We are able to consult those better angels, because the threat is incredibly much reduced. And it's much reduced because those people who did those things are largely dead. And they're dead because we were a nation at war, and we're allowed to use the tools of a nation at war, to make them dead. I don't think it's time to give up that capacity-- to give up that authority--

### Moderator
Claim: Why, Michael, if they're mostly dead?

### Scientific Advocate (SA)
Claim: Because, Peter mentioned-- Peter mentioned-- because they aren't all dead. And Peter mentioned John Brennan, and Leon Panetta, and David Petraeus giving rather rosy descriptions of Al-Qaeda. I mean, rosy from our point of view. They were talking about Al-Qaeda maimed. They were talking about Al-Qaeda in Pakistan, and in the tribal region. They were not talking about the franchises in Yemen, or in Somalia, or in Islamic Maghreb. And none of them have suggested this is over. All of them, in fact, have called for at least the current tempo of operations.

I have met no one who is actually responsible for creating the circumstances that make this debate possible-- should we end this thing? No one who is responsible for creating that, who actually thinks we ought to stop doing what we're doing.

### Moderator
Claim: Peter Bergen.

### Conspiracy Advocate (CA)
Claim: Well, I'm glad that General Hayden has conceded that, certainly, our principal enemies are dead. I mean, that's usually how you end a war, when your enemies are mostly dead. We didn't kill every Nazi at the end of World War II. I mean, there's a certain point. What we're claiming here is it's time to end the War on Terror as the organizing principle of our national security policy, which by the way, cost us trillions of dollars over the past decade-- which has allowed us to ignore a lot of serious problems we have at home and other threats abroad. You know, there are a million Americans now with top secret clearances. I don't think they all needed them. That is one of the legacies of defining it as a War on Terror.

And Richard said that we're not debating the War on Terror as it was produced by President George Bush in the first four years. Well, I mean, let's try and take that back to our side a little bit. The War on Terror was not the war on Al-Qaeda and its allies. It was an open-ended conflict against a tactic that produced a lot of enormous problems for this country, including the Iraq War and all that, the legacy we have from that. And so, there is sort of historical part to this. It's important. We're not just debating about what happened today. It's about a mindset which causes countries some serious economic problems-- which we are still trying to recover from.

### Scientific Advocate (SA)
Claim: As I said--

### Moderator
Claim: Richard Falkenrath.

### Scientific Advocate (SA)
Claim: --maybe these debates often turn on trying to get the voters to think about the proposition in a particular way. And the--

### Moderator
Claim: But so are you doing it.

### Scientific Advocate (SA)
Claim: Yeah, that's why it's called a debate.

### Scientific Advocate (SA)
Claim: But I think I read the proposition a little more closely, because you could have written it like this. It could have said, “Should the War on Terror be the central organizing principle of U.S. foreign policy?” You could have said that.

I think we would have been uncomfortable on this side of the table.

### Moderator
Claim: But what do you think the audience is-- let me ask. Do you assume the audience sees it your way or do you think the audience--

### Scientific Advocate (SA)
Claim: Well, I suggested a way to think about it. And as a--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: --to make it sort of actionable. Because as we've said, we are currently at war, in a legal sense, and we'd like to frame this proposition, saying, “Should we no longer be?”

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: That's really what it means, “It's time to end the War on Terror.” Now, we could make this a referendum on how this was handled between September 11, 2001 and then the elections of 2006. Or, you know, you could do that too. That's a different argument. And, you know, we're prepared to have that, but it's really not the war that we face right now today. And many of these issues were considered-- this is ironic-- by the Obama Administration. Many of the sort of tactical issues. And as I said, he didn't divert anything from what Bush was doing. In fact he intensified it-- the unilateral use of military force against a neutral country-- Pakistan-- into their territory. It--

### Moderator
Claim: So.

### Scientific Advocate (SA)
Claim: --increased.

### Moderator
Claim: So-- make your point, but then I want to come back to the questions.

### Conspiracy Advocate (CA)
Claim: A couple things on what Rich says. This argument is actually-- if you read it-- is about the War on Terror. And it's not a referendum on the first four years of the Bush Administration, or the first six years, or even the first two of Obama. It is about, what did we mean by the War on Terror? What was that definition that was used for so many years? And are we ready to be over? And they are doing-- they are trying to convince you, sort of a simplistic notion here, which is-- for those of us who have also served in government and national security is way too simplistic, simply because you want to say that the War on Terror is over does not mean that you're saying, “No military action ever.” Right? It doesn't mean, “Oh, gosh, I wish Bin Laden had been brought to a courtroom in New York City.” No one is saying that.

There is authority for the President to use force, including killing Bin Laden, under the Authorization for the Use of Military Force. I support that.

### Moderator
Claim: So what stops, if you declare the War on Terror over, what stops happening?

### Conspiracy Advocate (CA)
Claim: Well, I think it's already over. So let me then-- that's a great question. Because what also happened over the course of this 10 year period is that a narrative is being rewritten. And the narrative is that Obama is exactly the same as Bush. But Bush wasn't exactly the same as Bush. We have grown. And there are examples everywhere-- coercive interrogation, the black site-- all of that, we have learned. They learned, we learned. And that ability to change doesn't mean that, you know, “Oh,” you know, “We're going to continue to call it the same thing.” That war ended. That notion that military or this War on Terror was how we were going to approach it. It became much better. And can we talk about Homeland Security for a minute?

### Moderator
Claim: But if it's ended, then why are you saying it's now time to end the war?

### Conspiracy Advocate (CA)
Claim: Because they're never going to end it.

### Moderator
Claim: Well--

### Conspiracy Advocate (CA)
Claim: Right? The 10th anniversary is a good sign to begin to say, “Let's give,”-- have the American public say, “We're ready to not think of our world this way.” That the War on--

### Scientific Advocate (SA)
Claim: So, maybe we should let Juliette and Peter argue this one out-- because they were not arguing the same proposition here. I mean, this is entirely different. Juliette says the War on Terror as we-- as she's defining it-- is already over. And Peter says, “Time to end it now, because we decimated most of the Al-Qaeda leadership and the ideology was defeated”--

### Conspiracy Advocate (CA)
Claim: Completely--

### Scientific Advocate (SA)
Claim: --“In the Arab Spring.” These are totally different propositions. So we're not clear--

### Conspiracy Advocate (CA)
Claim: They are two factual arguments to make the case.

### Moderator
Claim: Peter Bergen.

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: Which is fair-- which is a fair way to do it. But I think we hear your point. Michael Hayden.

### Scientific Advocate (SA)
Claim: I return to my point, that I'm the one on stage that got the phone call in the middle of the night. I knew what the war was about, right? It's about what he said.

It was about the authorization for the use of military force, and the ability to use combat power against Al-Qaeda and affiliated organizations. There was no confusion on my part. And so, I don't quite understand. If that's still okay, what is it we're departing from?

### Conspiracy Advocate (CA)
Claim: Well--

--as sort of another way to look at this is that President Clinton tried to kill Bin Laden in 1998, with cruise missile strikes. This is not new, the idea that we reserve to ourselves the ability to kill enemies of the state. Well, we're just calling for an end of this all-encompassing, global conflict that has cost us so much money. We're not calling for a global police action against terrorists, certainly. We reserve the right for a certain kind of war-like activities, but it's time to stop this sort of grandiose approach, where we're at war with any person who's ever said the word “Jihad” around the world, which is going to cost us a lot of money.

### Scientific Advocate (SA)
Claim: Peter, that's a cartoon.

### Scientific Advocate (SA)
Claim: That's-- no one said that anymore. This is not the case. I mean, you can lambast the other side of this debate by constructing the straw man, but that's just not it. I mean, we're not--

### Moderator
Claim: Well, is it?

### Moderator
Claim: Is it, Peter? Do you feel that that's still the rhetoric coming from the U.S.?

### Conspiracy Advocate (CA)
Claim: Well, I think when we say, “The War on Terror,” when FDR went to war against the Nazis, he didn't declare war against the sort of tactic of U-Boats or kamikaze pilots, in the case of Japan. I mean, the War on Terror was a very expansive notion that pulled us into the conflicts in the Iraq-- that we now orphaned-- and others. And that's what we're saying – it is the end of that. I mean, Juliette is making a point that it's, in a sense, already ended. But also, our enemies are essentially defeated. And defeat doesn't mean total obliteration. It means that we can now move on and say, essentially, that the longest war in American history, which it is now, the longest war in American history.

You know, there's a time-- a time to move on.

### Moderator
Claim: All right. I'd like to go to some questions from the audience. And the way we'll do this. I can see you, and we'll-- I think I explained beforehand. I believe everybody was here. If you raise your hand, a microphone will be brought to you. We'd ask you to rise, to be terse, to make it a question, to keep it on point, and to keep the microphone about four inches away from your mouth. And this gentleman in the very center, if you-- I'm looking right at you-- and if you'd stand up, they'll bring a mic over to you.

### Moderator
Claim: My question is--

### Moderator
Claim: I just want to get the mic over to you, so we can hear you on the radio broadcast.

### Moderator
Claim: My question is to Peter and Juliette. I think the other side has defined very well what they think would be lost if the war on terror, as they define it, would be ended. Can you explain very clearly what would be gained if the war on terror, as you define it, would be ended. Thank you.

### Conspiracy Advocate (CA)
Claim: Could you just say that last part again? If the war –

### Moderator
Claim: What would be gained by ending the war on terror, as you define it?

### Conspiracy Advocate (CA)
Claim: Honesty, descriptiveness, actually reflecting what's happening out there. I mean, whether the war on terror ended as we started to change, it's just a learning process over 10 years, to effective counterterrorism-- effective counterterrorism tools. That happened over the course of a 10 year period. So the reason why not to call it a war on terror is because we know what the war on terror meant. Now, they can now claim it was just a legal device.

But I lived that time. We all lived that time. We all served in government. Three of us served in government during that time. So I've just asked people to remember, as we have been discussing, what that meant. It's not an indictment on everything that happened or the changes or whatever else. It is just simply today we have effective counterterrorism measures.

Some of them might be military, might be the use of military force as authorized by law. Many of them will not be. And it's as simple as that. And so we can say that we didn't mean by the "War on Terror" anything but there's this law. And that's just for you all to decide if that's what you thought it meant at that time.

### Moderator
Claim: Can I ask you, sir, to, first of all, if you don't mind identifying yourself. And then in terms of the answer, do you feel that your question was answered, that it was addressed?

### Moderator
Claim: My name's Philip Gourevitch. I'm a writer. I was asking whether you think-- the issues that you're describing are a kind of broad conception of the war on terror.

And they're defining it as a legal set of tool-- a toolbox. And you're essentially saying that you agree with them that that legal toolbox should not be abandoned. So I'm saying, what would you--

### Moderator
Claim: Could you-- I'm sorry. One more time. Could you stand? You don't have to repeat the question because you were about to repeat it anyway.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: But go at it.

### Moderator
Claim: You're saying that that tool-- are you saying-- you're saying that toolbox shouldn't be abandoned either.

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: But the concept of the war on terror should be because of a bunch of things that you say have essentially--

### Conspiracy Advocate (CA)
Claim: Been changed.

### Moderator
Claim: --not been practiced for a while so--

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: --it seems like you think it should be redefined.

### Conspiracy Advocate (CA)
Claim: And, but-- and there's a reason for--

### Moderator
Claim: And I'm asking what would be gained by saying "The war on terror is over," and wouldn't-- if you're still preserving all those legal tools--

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: --that you think that they-- that they said that we should.

### Conspiracy Advocate (CA)
Claim: Not all of them, yeah. No. I think in answering in terms, I think more descriptive of actually what we're doing, more limited description of what counterterrorism efforts and procedures actually are. There's a difference between counterterrorism efforts and actions and war. And it's –

### Moderator
Claim: I think the question might also--

### Conspiracy Advocate (CA)
Claim: --be descriptive in that sense.

### Moderator
Claim: --might also be reframed as what's the harm to-- in continuing to call it a war on terror?

### Conspiracy Advocate (CA)
Claim: Well, then that's my-- I viewed the war on terror as so expansive and defining so many authorities, including a commander in chief by all-- any means necessary to protect us.

That explains a 10-year or eight-year trajectory. I'm not going back to say, oh, look how horrible they are. I'm going back to say, that's what the war on terror was. Aren't we glad that we have moved away from that? They moved away from it. We moved away from it.

### Moderator
Claim: I just want to see if your opponents would like to respond. Michael Hayden.

### Scientific Advocate (SA)
Claim: I talked about one dimension of expansiveness. You know, war on terror, whatever the rhetoric was, it was war on al-Qaeda and its affiliates. I'm sorry to repeat myself. I did not have the authority to do against Hezbollah and other terrorist organizations who are unaffiliated with al- Qaeda and not responsible for the attack of 9/11, the authorities I had to deal with this well, clearly defined enemy.

So the expansiveness in that dimension wasn't expansive. In addition, the expansiveness in this direction, what is it you could do against this enemy force, was controlled by U.S. law, by the Constitution.

### Moderator
Claim: But was not the invasion of Iraq, which had its own authorization, also part of the war on terror as they're describing it?

### Scientific Advocate (SA)
Claim: I-- you know, we can talk a lot about different and specific things.

### Moderator
Claim: But-- no, no. But no, no. But Mike, it-- I'm not debating the merits of the war on Iraq at all or asking you to.

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: Or I'm not debating with you because I'm the moderator. I'm just trying to deliver what I heard as her point to you, which is that there is an expansiveness to the term that leads to an expansiveness of actions.

### Scientific Advocate (SA)
Claim: The-- okay. So the attack on 9/11 created an environment in which the-- it was more likely that our government would make a decision to go to war with Iraq, I think that's clear. Okay? The war in Iraq was not tied to the authorization for the use of military force. And people like me in the American intelligence community, made it very clear that there were not operational connections between the Iraqi intelligence service and al-Qaeda, the named enemy in the AUMF.

### Scientific Advocate (SA)
Claim: John, I mean, is it-- to your direct question, the answer is President Bush and his principal officers in explaining the rationale for going to war against Iraq did reference the war on terror extensively and repeatedly. .

And they were by no means unique in doing so. That occurred on both sides of the political aisle and may still go on today. Now, whether that was an appropriate characterizations or not, who knows? But, I mean, they did.

### Conspiracy Advocate (CA)
Claim: Well, I think we do know.

### Scientific Advocate (SA)
Claim: Is this a debate about ending the war on Iraq or ending the war on terror?

### Conspiracy Advocate (CA)
Claim: Well, they were related to each other, I mean, that's-- the way-- the way the war was sold is that it was part of the war on terror. That was the intellectual architecture of the war.

### Scientific Advocate (SA)
Claim: Again, Peter, those are events of a half a decade ago or longer.

### Conspiracy Advocate (CA)
Claim: Well, we're still in Iraq.

### Scientific Advocate (SA)
Claim: Well, yeah, we are. And frankly, I mean, we all have to deal with life as it is, not as we wish it would have been. And so we're not--

### Conspiracy Advocate (CA)
Claim: Oh.

### Scientific Advocate (SA)
Claim: And so we're not-- oh, "awe." Come on.

There are-- people who are actually responsible for things have to deal with the world as it is, not as they wish it to be.

And that may be the actual core of the debate.

### Moderator
Claim: All right. I'd like to go to another question. You know, I'm-- I'm--

### Conspiracy Advocate (CA)
Claim: Can I just--

### Moderator
Claim: People often ask me, "Why don't you call on more women?" Because women aren't raising their hands. So I'd like to get-- oh, there you are. Do you mind giving us your name too? Thanks.

### Moderator
Claim: Thank you, yes. My name is Eileen Karovoch and I think I relate to the first gentleman's question. I don't understand the economic benefits of ending the war on terrorism. You talked about the trillions of dollars that we're spending. And I am tired of this recession. How will ending the war on terrorism give money back?

### Conspiracy Advocate (CA)
Claim: Well, I mean, it's a factual matter that we spent--

### Moderator
Claim: Peter Bergen.

### Conspiracy Advocate (CA)
Claim: --a trillion dollars at least in Iraq, right?

I mean, we're-- by winding down there and no longer part of the war on terror there, we're going to save ourselves a lot of money. As a factual matter, we spent half a trillion dollars on our intelligence. I think Juliette would have a better answer on how much we spend on our Homeland Security. We spend a huge amount of money on this, and we can't afford it right now. And clearly there is some belt tightening that is needed, and if we stopped having this construct on the war on terror it would help making the hard decisions that we need to make about reducing the size of our bloated – I mentioned the fact that there are a million Americans with top-secret clearances. That’s not secret. Top secret. I don’t think that all these people really need these top secret clearances. We are facing a group of people that on a good day may now number 300 or 400.

### Moderator
Claim: But it was a recession question on that. I’m not sure how the clearance issue relates to that.

### Conspiracy Advocate (CA)
Claim: Well, are going to have to reduce the number of people in our Intelligence apparatus. We are going to have to reduce the number of people, if we are going to draw down in Afghanistan and Iraq, and by saying that the War on Terror is over, that’s going to help those decisions.

### Moderator
Claim: We asked—Slate asked its readers to submit questions to us. Slate selected a few for us and I’d like to bring one of them up because I think it goes to this side and to some degree, Richard, you had touched on this but it’s more specific. His name is Peter McKay and he’s actually from New York City. “Since you believe that it is not yet time to end the War on Terror, could you please explain what specific conditions you would have to see met to know that that time has come.

### Scientific Advocate (SA)
Claim: No

### Moderator
Claim: Okay, fair question. Michael Hayden?

### Scientific Advocate (SA)
Claim: I’m kind of with Rich. This will be something that we’ll recognize when we see it, like Supreme Court justice described something else. All I can do is repeat what I said earlier. Everybody I know who’s actually responsible for getting us to the state we are in now, which is far better than we were one five or ten years ago – no one thinks it’s time to stop. No one thinks that we’ve gotten to the point for al-Qaeda is sufficiently non-resilient that it cannot regenerate.

Until we've reached that point and make that judgment, no, I don't think we should end what Rich and I are arguing we should continue, which is a legal authority to use all the tools at the disposal of the American government.

### Moderator
Claim: Richard, why is it difficult to foresee what those conditions would be?

### Scientific Advocate (SA)
Claim: Well, it's just something that I wouldn't want to write down on paper or articulate until you have to. And so I'm quite comfortable with the proposition tonight that now is not the time to do it. Do I want to rule out that some future time, if we have a new government in Pakistan, fundamentally change the environment in the horn of Africa and the Arabian Peninsula, might there be the conditions then? Maybe. But there's nothing pushing it. There's no-- as a-- one of the first questions that came from the audience was, what's the harm? I'm not seeing any harm. Any benefits that were gained by ending the war on terror as particularly Juliette defines it, were already gained when President Obama got elected and won the Nobel Prize principally for not being Bush and-- and, you know, this is-- the benefits have already accrued. Only harm comes from changing the legal apparatus that allows us to continue offensive military operations.

### Conspiracy Advocate (CA)
Claim: I just don't know--

### Moderator
Claim: Juliette Kayyem.

### Conspiracy Advocate (CA)
Claim: I just don't know how-- I mean, first of all, with all due respect, General Hayden, I think no one is arguing that al-Qaeda-- no one in authority or who has to deal with dealing with the security apparatus or figuring out how to distribute funds that are drying up, because that's what you know in particular Homeland Security, that's what state and locals are dealing with, that's what police departments are dealing with, how do I prioritize the threat out there when everyone wants to be safe not just from terrorism but from crime and whatever else may go on.

So no one is arguing that we're closing the door to acknowledgement of a threat of terror, and it's just not the debate. And so they're sort of throwing up a bunch of straw men against this typical notion of people who want the American public to acknowledge, and maybe it happened two years ago with the election of Obama-- growing recognition that war and what war meant was not the way to describe what we were doing.

And General Hayden talks about this consensus that we want all the tools in the toolbox, but to remind you-- the consensus was not a consensus because the President decided it was a consensus. It took Congress, the courts, the public, leaders within the Bush administration, and, yes, a new president, to realize that this construct that we had created over the course of six, eight, or 10 years needed to be thought about in a different way. And that's what we're asking of you, not saying, throw in the towel, let bin Laden, hang out with his wives, that is not what we're saying and it's a disservice to people who want to challenge this notion of the war on terror to caricature us that way.

### Moderator
Claim: Okay, I want to go back to another question. Sir, I'm looking at you, and you stand up because you seem to be-- just wait for the mike and if you could tell us who you are.

### Moderator
Claim: I’m Matt Foley I'm just wondering in 1993 the Trade Center was bombed first time, and they went a different route, they didn't start a war on terror, they prosecuted the people responsible.

Could you guys just give me an idea of what the cost of this war on terror has been-- dollars, we know that there's been thousands of lives, but in comparison to what was done in '93, why is this approach better than that one because it seems to me that they were able to apprehend the people responsible much more quickly and with far less human cost--

### Moderator
Claim: So your question is to the side against the motion.

### Moderator
Claim: Yes.

### Moderator
Claim: Mike Hayden.

### Scientific Advocate (SA)
Claim: In its starkest form, the law enforcement approach after the first attack on the World Trade Center in '93 did not prevent the destruction of the World Trade Centers in 2001. The "We are a nation at war approach" following 2001 has prevented any similar attack on the United States in the ensuing 10 years.

I think that's the biggest distinction.

### Scientific Advocate (SA)
Claim: Let me just say that--

### Moderator
Claim: Two years or three years, from '93 to 2000 there was no attacks.

### Scientific Advocate (SA)
Claim: Right.

### Moderator
Claim: So what you're saying is that this war-- because we don't know when the next-- hopefully there won't be any more attacks but right now the evidence is--

### Scientific Advocate (SA)
Claim: There actually were. They weren't against the continental United States but they were against U.S. interests abroad, and if I could just say, I'll tell you, one of the rhetorical excesses of the first Bush administration and so you know 2001 to 2004 in which I served which troubled me was a-- they did tend to dismiss the law enforcement approach as they were talking about the various military options. There's no question that there was a somewhat disdainful view of the law enforcement. As someone who then left the White House and went and worked in law enforcement, I no longer do, that troubled me because it strikes me as it's a completely legitimate set of options available to the executive branch and deserves no-- it should not be treated disdainfully at all.

There were successful prosecutions in that time period. Ramzi Yousef is currently serving a life sentence in super max. He was one of the architects of it, the nephew of Khalid Shaikh Mohammed, one of the architects of 9/11.

But there were many other aspects of that investigation that were enormously problematic, principally concerning the compartmentalization of information and the inability to allow the information generated in the law enforcement investigation to sort of transmute across the inner agency and inform a wider intelligence perspective of a growing threat. Now, a few people saw it, but the system as a whole struggled to grasp it.

### Moderator
Claim: Juliette Kayyem.

### Conspiracy Advocate (CA)
Claim: I would actually totally agree with Rich on this point. I think that the changes that were made over the course of the 10 years, not because we had to call it a war but these are actually statutory changes made to the Foreign Intelligence Surveillance Act have brought about tremendous changes within both the law enforcement intelligence community, local law enforcement and whatever else.

So I actually would agree with-- I think we’re all sort of-- there are a variety of tools that can be used by any present executive branch member or whatever else to counter al-Qaeda and to defeat al-Qaeda.

### Moderator
Claim: Sorry I’m going move on just because I think that actually both have answered your question. You might not like the answer, but they’ve addressed it. Right-- yeah. If you can stand, sir?

### Moderator
Claim: Warren Ilchman. I’ve heard al-Qaeda and its affiliates, and I’ve heard Hezbollah mentioned, but no one has mentioned in the whole evening the Taliban. Must the Taliban be defeated before the War on Terror is completed?

### Moderator
Claim: Which side would you like to put that question to first? Okay, let’s put it to Peter Bergen.

### Conspiracy Advocate (CA)
Claim: I think the Taliban has to be made irrelevant, and the Taliban to a large degree is becoming less relevant in Afghanistan over time.

I think what we’re looking at, if we pull out for a little bit-- there are still Marxist-Leninists somewhere in the United States on some college campus somewhere. Just no one pays any attention to them. And you know, we’re at the point where al-Qaeda and its ideas and we’ve included that in the Taliban, which, by the way, enjoys only a seven percent favorable rating in Afghanistan right now. There’s nothing like living under the Taliban as a prophylactic to their ideas about creating a utopia here on earth, don’t make sense. So these ideas are becoming irrelevant, and that’s why the War on Terror should be ended. We’ve just heard from Rich that he won’t even tell us when the war will end. Well, if it doesn’t end with the founder and leader of al-Qaeda, the intellectual author of 9/11, which is the reason we went to war in Afghanistan in the first place, the fact the Taliban wouldn’t hand him over-- if it doesn’t end when it’s totally irrelevant in the Middle East, if it doesn’t end when it’s the war of ideas in the Muslim World, if it doesn’t end when its entire top leadership is decimated, I mean, when does it end?

### Moderator
Claim: Richard Falkenrath, is the Taliban irrelevant?

### Scientific Advocate (SA)
Claim: No, it’s not. I mean, it’s not irrelevant. It certainly matters a lot in the reconstruction of Afghanistan and the geopolitics of that region. There’s no question that they supported 9/11, the Taliban organization. They supported al-Qaeda prior to 9/11. Now, it looks like that was a very expensive thing for them to do, and there are other groups in this area-- Peter is actually far more expert on this than I am-- that are still supporting the remnants of al-Qaeda central such as it were. So that’s a long-winded way of saying they are not essential to some sort of winning the War on Terror, prevailing them, but there’s no question that because of their historical legacy, they are legitimate targets for the U.S. military in what we are calling here the War on Terror as it operates in Afghanistan and Pakistan.

### Scientific Advocate (SA)
Claim: I’d like to blend both Peter and Richard’s point. The destruction of them may not be required in the same way that you want to destroy al-Qaeda core. Peter’s comment about destroying their relevance, I think, is the actual objective there.

### Moderator
Claim: Ma’am? Yeah. If you can rise and the mic will come to you.

### Moderator
Claim: Hi. Often a war is constituted with troop levels. So I would like to know each side’s perspective on troop levels in ending the war or continuing the war.

### Moderator
Claim: Troop levels where? I’m not sure-- well, can you try another crack at that?

### Moderator
Claim: Do you believe that troops should be brought out of Afghanistan to-- where the war is being conducted? Or should we continue to have troops and for how long?

### Conspiracy Advocate (CA)
Claim: My last appearance at this debate forum was arguing that the war in Afghanistan was something to continue, with Max Boot. He is also here in the audience. I think it would be difficult for me to now change my mind and in such a public fashion.

And I think that we, you know, we-- there are things that we, you know, making sure that Afghanistan doesn’t revert into a haven for the Taliban and a lot of groups is, you know, that is a very good thing. You know, it was the War on Terror kind of construct that got into a war which cost us a lot more in blood and treasure where we were not attacked from, which, of course, was Iraq.

### Moderator
Claim: Michael Hayden.

### Scientific Advocate (SA)
Claim: I agree very strongly with what Peter said. And I would suggest to you that the size of the American footprint there over time matters. I mean, it does have an effect. But far more important is the persistence of the American footprint. We left that region before, and we suffered for it greatly on 9/11.

And so I think Peter and I are in strong agreement that some substantial American presence there, as difficult as that is for us for a variety of reasons, keeps us so much safer that it's probably worth those sacrifices.

### Moderator
Claim: But is that presence of-- is that-- does that constitute war, Peter?

### Conspiracy Advocate (CA)
Claim: Well, as Juliette said and I've said, I mean, we're not opposed to conducting continuing our presence in Afghanistan and making sure that it doesn't revert into a safe haven - -

### Moderator
Claim: But we're talking about what we call it. So would you call it-- war--

### Conspiracy Advocate (CA)
Claim: Well, it's a war against al-Qaeda and its allies. The president, President Obama, correctly redefined downwards this open-ended global conflict against the tactic and named the enemy. And that's the enemy that we continue to fight.

### Moderator
Claim: Okay. Right in the center.

### Moderator
Claim: The people on this side define ending the war on terror as repealing the legal instrument that authorized military force.

I don't understand, on this side, exactly what it is that you do, what you define the ending of the end of the war on terror. Is it declaring victory and going home? Because President Bush did that on the aircraft carrier.

### Conspiracy Advocate (CA)
Claim: How'd that go?

### Moderator
Claim: Didn't go so well. I just don't understand exactly what it is that you think-- should President Obama give a speech and--

### Conspiracy Advocate (CA)
Claim: We're not-- we're not--

### Moderator
Claim: --declare victory?

### Conspiracy Advocate (CA)
Claim: Well, so here's--

### Moderator
Claim: Juliette Kayyem.

### Conspiracy Advocate (CA)
Claim: --what's so interesting about this. We're not asking for a-- this war is over. I mean, if anything, I hope that the description of the last year showed this may be a bit too late, not to criticize Intelligence Squared, that I actually think without you knowing it, we did end the war on terror and that in trying to expose how we ended it, it's-- and what the reason for discussing it in such an open manner is because how we talk about counterterrorism measures, whether it's killing Bin Laden or it's bringing someone to an article 3 court, or it's working with Arab and Muslim communities so that they will feel comfortable with the NYPD and tell them when there might be extremists amongst their midst, certainly the NYPD has been great at.

But we're-- so that is an acknowledgment of the reality of where we are, because it affects how we perceive ourselves. It clearly affects how everyone else perceives us in the outside world. And the war on terror is not a benign statement. We've been sitting here hearing, oh, yes, we may have gone too far, and maybe this war-- it wasn't benign. And so maybe part of our obligation 10 years later is to admit it's not a benign term.

### Moderator
Claim: Richard Falkenrath.

### Scientific Advocate (SA)
Claim: I think the question underscores one of the difficulties in Juliette and Peter's position on here. And if I can just sharpen it and pose it also as a question.

Since we've agreed-- or at least I think that Juliette concedes we shouldn't change the legal framework that currently governs counterterrorism operations by U.S. forces abroad. You could talk about it rhetorically differently. And in fact, President Obama could have his aircraft carrier moment right now wherever he wanted, to go out and announce that he is announcing the end of the war on terror. Okay, now, question, you used to work for him in the cabinet department, could go back and work for him. Would you recommend he do that?

### Conspiracy Advocate (CA)
Claim: Why would I not recommend that?

### Scientific Advocate (SA)
Claim: I'm asking, you would? He would never do it, first of all, no--

### Conspiracy Advocate (CA)
Claim: And because the politics--

### Scientific Advocate (SA)
Claim: You'd be fired.

### Conspiracy Advocate (CA)
Claim: Let me tell you why he wouldn't, because it took me nine months to move 19 Massachusetts National Guard members from the Pilgrim facility, because the war on terror is not benign, because this notion of the war on terror, it has completely limited our politicians' capacity to move. And I think the amazing thing about this president is how much he has moved us.

### Scientific Advocate (SA)
Claim: But this gets to the question that came up earlier.

### Conspiracy Advocate (CA)
Claim: Right? So if I think it would be bad political advice, and he should fire me if I told-- in the same way, you know, if I told him to say the war on terror is over, not because I think it's inaccurate but because I actually think that politically we-- that the public and the way we talk about it gives no opportunity for the kinds of changes, the little changes I had to make or the big changes that have been made.

### Moderator
Claim: All right, Richard come in on this--

### Scientific Advocate (SA)
Claim: I think this circles back to an earlier question, which is what gain would come from accepting your side of this argument. And what would happen is President Obama and his advisors would say, look I’ve already realized all the gains. We’ve talked about it differently, I’ve won the Nobel Peace Prize, I don’t need to do this. It’s already done.

### Conspiracy Advocate (CA)
Claim: So you agree that it’s over.

### Scientific Advocate (SA)
Claim: No

### Conspiracy Advocate (CA)
Claim: Isn’t that what you’re saying? You are admitting-- you are also admitting that it would be political suicide for anyone to say it. And all I’m saying is, maybe we can create a space where that’s not true. Where we can move 19 Massachusetts National Guard Members, or we can create more stringent military commissions, or we can close the black sites or whatever it is that we need to do, and that’s actually a good thing because it means we’ve changed over 10 years.

### Moderator
Claim: Sir.

### Moderator
Claim: My name is Josh Steps I’m from Sydney, Australia. In an attempt to bridge this definition or gap about the War on Terror. My question for Richard. Don’t you feel that over the long arch of history that maybe that the greatest inhibition of people’s freedom is governments and not so much terrorism and outside threats, and do you fear that maybe an open-ended war that goes forever that you’re not even able to say when it could possibly end, is more of a liability, even if it gives us more of a tool, more tools in the arsenal in the short term, that maybe the long-term liability outweighs that, and how do you feel about –

### Moderator
Claim: Interesting question.

### Scientific Advocate (SA)
Claim: It’s a great question, in fact it’s several questions marbled together. And one is that there’s no question that over the arch of history that governments have done more harm to human beings than any terrorist organization. Governments are capable of enormous destruction, there’s no question about that. And I don’t think that al-Qaeda or any terrorist group is 10 feet tall. I don't go to sleep afraid. I never did. And they are what I think is ultimately a manageable problem. In this-- there's always the potential for government excess. Government in our country domestically has a monopoly on the use of force and is authorized in certain circumstances to invade your liberty and your privacy in all sorts of ways. And one of the great debates in this country and in any country is how do you set those rules and what are they? And it's not set in stone. It evolves, changes over time. In fact, the last 10 years since 9/11 have illustrated that, and it has evolved greatly.

And I think Juliette pointed this out that there have been, in every single functional area, it has evolved. But here I want to come back to what my colleague, Mike, said, there really is, today, a consensus on this. There really is. It's remarkable. On electronic surveillance, there is a consensus. There was not in 2005 when James Risen published the details of a certain classified program. Today, there is. FISA modernization act was passed, broad bipartisan support. Obama is all for it. Bush was for it, no problem.

On detention, right, there is actually consensus on what happens now from where it was with Bush to today. On tribunals, also consensus. President Obama has expressly endorsed the military tribunal process signed into law by President Bush, enacted by the previous Congress. So a long-winded way of saying, to your question, yes, there are risks that we must constantly be vigilant for them. But there is broad consensus right now on where those lines should be drawn across the political elite in Washington.

### Conspiracy Advocate (CA)
Claim: This narrative of consensus was not a consensus--

### Moderator
Claim: Juliette Kayyem.

### Conspiracy Advocate (CA)
Claim: --necessarily of choice, right? I mean, let's not forget-- it's not like all these like really smart people sat in a room and go, okay, well maybe we're excessive then, but now we're going to be all Kumbaya and figure out how to do this right. It was a consensus because the Bush administration lost a lot in court, because Congress required them to make changes and that lasted into the Obama administration. Because their own national security experts, including interrogators, people in the military justice system, lawyers in the Department of Justice who didn't like the secret surveillance were rebelling. This was not-- so I'm glad that there's a consensus, but it's just-- I challenge this notion that-- ask you to remember that this sort of came about because, in all actuality, every smart person thinks the same.

### Moderator
Claim: Michael Hayden.

### Conspiracy Advocate (CA)
Claim: So it's very, very difficult decisions.

### Moderator
Claim: Michael Hayden.

### Scientific Advocate (SA)
Claim: It's a very great question that you raised, maybe let me give you a different perspective on what they do to states and what they do to their citizens. We have certain authorities, all right, that the states exercise that for reasons of discomfort or political risk or what else? A government decides not to exercise the full extent of their authorities. And because of doing that, very bad things happen to their citizens because they did not do all that they could do. If they did not do all that the law allowed, then for political reasons, they played back from the line. I used to describe this to our work force as to why we had to be as aggressive as we possibly could be within the law, because my view is this sort of box I'm creating for you is the field in which we're allowed to play. If we play back from those lines, and we fail, and bad things happen to you-- of a catastrophic nature that-- like happened ten years ago, that box I drew here, you're going to draw a different box. You are. And the box is going to be this way. So in another way, the way we security professionals, the intelligence community view this is we have to be very aggressive within the law doing our job because if we fail the natural tendency of a country like ours or a country like Australia would be to do things probably destructive to the long term liberties out of fear.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. Debate. So here's where we are. We are about to hear brief closing statements from each debater in turn.

They will be two minutes each, and remember, you members of the audience, you voted before the debate, we're going to ask you to vote once again afterwards, this is their last chance to change your mind. I'd also, with your indulgence, like to just record one more item for the radio broadcast, to allow them to take a break in the middle of the section that just happened, and it would be wonderful if I could ask you to applaud. I'll say my line and then we can move forward, okay? So if you could just applaud, that would be terrific, thank you. Welcome back to this Intelligence Squared U.S. Debate. We're in the question and answer section. I'm John Donvan, your moderator. We have four debaters, two teams of two, debating this motion, "It Is Time to End the War on Terror." That's it. Thank you. All right. So now on to round three. These are closing statements. They will be two minutes each. Each debater is speaking in turn. And our motion is, "It Is Time to End the War on Terror," and speaking first against the motion, Michael Hayden, former Director of the National Security Agency and the CIA.

### Scientific Advocate (SA)
Claim: Thanks, John. Our, Rich’s purpose and mind here tonight was not to defend all aspects of what our government has done over the last 10 years. There have been a lot of thoughts put out about some things that some people find offensive or uncomfortable about what we've done. I actually think a lot of those points are debatable, but that's not tonight's debate. What we're looking at is, broadly speaking, how should we conceive ourselves in order to insure our own national security. And I mean no disrespect but I'm trying to follow in detail what it is we're arguing against from the other side. And I think it's not an unfair characterization continue what we're doing, that we have a desperate plea to repackage the atmospherics around which that which we are doing. And I'm trying to parse out the arguments for just repackaging.

And from Peter I think I'm getting the argument that you've been successful, back off, you've won the thing. And from Juliette I'm getting the argument, you shouldn't have been doing all those things that you were doing that Peter said were successful because it enabled you to win those things. This is an important matter. That one percent of the republic that's defending the other 99 percent needs to know you're with them and that you're behind them. And I mentioned in my earlier comments about not being too celebratory, and Peter's right, massive events in the last six months, the Arab Spring and the killing of bin Laden. If one were to write a history of the American Civil War, one could determine I think looking backward that the decisive events took place in the first three days of July in 1863 with the fall of Vicksburg and the defeat of Pickett's Charge going up Cemetery Hill. I think historians would agree, it was decisive, but there was 21 months of war left after that.

And spiking the football and calling it a win and walking away from the battlefield in July of 1863 would have put at risk all that we now know have been achieved by that point.

### Moderator
Claim: Thank you, Michael Hayden. Our motion is, "It Is Time to End the War on Terror," and to speak for the motion, Peter Bergen, a CNN National Security Analyst and Director of National Security Studies at the New America Foundation.

### Conspiracy Advocate (CA)
Claim: We’ve heard from Rich tonight that al-Qaeda isn't 10 feet tall and also it's a manageable problem but also that we should be at war against this terrorism tactic until the 22nd century, and that there's no circumstances that he can define tonight when we should declare the end of this war. And as we were thinking about this question, we turned to two of the leading experts on terrorism in the world for some counsel, one of them said, we here in the United States certainly are much safer.

Al-Qaeda still exists but it's been massively damaged. Through nine years of an onslaught against them, our defensive abilities here in the country, our intelligence, our law enforcement, our Homeland Security is much better, so there's no question the United States is safer. The second leading expert said just a few weeks ago, future attacks are going to be more numerous but less complex, less well organized, less well likely to succeed, and less lethal if they do succeed. I think the killing of bin Laden will accelerate that change. The first expert was Richard Falkenrath speaking to CNN almost exactly a year ago.

And the second expert was General Hayden speaking to the Associated Press this summer after the death of bin Laden. We agree with both these gentlemen that al-Qaeda has been massively damaged and that there’s no question that we’re safer and that this much weakened al-Qaeda is far less likely to succeed with even small-bore attacks it will try and pull off in the future and that this process of al-Qaeda decline has been accelerated with the death of their leader. And for these reasons, and because we agree with these gentlemen, and others we’ve outlined this evening, we urge you to vote for the motion that "It's time to end the War on Terror.”

### Moderator
Claim: Thank you, Peter Bergen. Our motion is "It's time to end the War on Terror.” And here to speak against the motion, Richard Falkenrath, who is former deputy commissioner for counterterrorism at the NYPD and deputy Homeland Security advisor.

### Scientific Advocate (SA)
Claim: Thank you very much. It’s a real pleasure tonight to argue this out. It is a very important issue. Juliette and I have many things in common. We both were at Harvard for awhile. We have children who are about the same age.

We also had the privilege of serving at both the federal level of government, in my case the local, her the state level. And that perspective for me was immensely valuable, to come to New York-- I was not a New Yorker, but I came here to work at the NYPD for four years. It gave me a different perspective on these issues and one that I think is illustrative. The easiest thing to do for us, in this debate, tactically, is just to sort of to decry the rhetorical excesses that frankly Juliette decried of the first few years after the Bush administration. It was a very divisive time in our political life, very troubling time, frankly. But I was struck today actually walking to this debate. I saw something that made me say I shouldn’t just dismiss it all completely, which was there was a fire truck going by, and it was making a big loud siren. And it was barreling to some emergency. And on the front, they had stenciled “Support our Troops,” which said to me that the local responders, these local officials who were not in the military and have no extra authority gained from any of these laws that had been passed, in fact see a certain common purpose with the military officers and the intelligence officers who are still at war in a technical although somewhat invisible sense.

And that’s, I think, a useful way to remember this. It isn’t the sense of unity that this country achieved post-9/11 about dealing with this problem also was a little bit a-historic, which is my way of saying, yes, there were many bad things that happened at that time, things that I criticized and, as Peter notes, I’ve written about it and talked about in papers and stuff like that. But there were also some good elements of it. And if there was no better way rhetorically to unify the various actions of many different parts of America, the military and the intelligence, the lawyers, the first responders, the rest, than War on Terror. That’s what they came up with, and it worked all right. So, on that basis, in addition to the legal arguments we’ve urged you to accept, I urge you to vote against this motion.

### Moderator
Claim: Thank you, Richard Falkenrath. Our motion is “It is time to end the War on Terror,” and here to speak for the motion, Juliette Kayyem, the national security and foreign policy columnist for the Boston Globe and former assistant secretary at the Department of Homeland Security.

### Conspiracy Advocate (CA)
Claim: So General Hayden and Rich Falkenrath, I want to thank you both and thank you both for your service and this audience as well. They would have you believe that we simply want to repackage something, and they would have you believe that we would want to throw away laws that would have given Obama the authority to kill bin Laden. And they want you to believe that there’s this continuity of behavior over the course of the 10 years. And none of that is true. And I actually think none of it is true because, one, we’re not saying throw away the laws, throw away the authorization for the use of military force, nor is the War on Terror a benign statement. It is neither descriptive anymore nor is it benign.

And the continuity has actually been one of the-- I think what’s happened over the last 10 years has been sort of remarkable because it was not continuous, that what you saw over time was the American public, Congress, the courts, the Supreme Court several times, the Bush administration itself with its own internal conflicts, and a change in leadership between the presidents, show that it wasn’t continuous. It’s not just the excesses that I said. It was actually what made us better, what made our counterterrorism measures better. And they got better over time, so that all sorts of things are not happening because of this learning curve. So now we’re supposed to wake up 10 years later and say, “Okay, well, that was-- it was good we called it that and let’s just continue calling it that because that was-- it’s benign,” or, it’s just a legal matter. And all we’re asking you to do is actually think about that a little bit differently.

Remember the 10 years, be grateful for the work of both administrations, but also realize the war on terror as a unifying force is no longer accurate or benign. Thank you.

### Moderator
Claim: Thank you, Juliette Kayyem. And that concludes our closing statements. And now it's time to learn which side you feel has argued best. We're going to ask you again to go to the key pads at your seats. Our motion is, it is time to end the war on terror. If you agree with the motion, push number one. If you disagree, push number two. And if you remain or became undecided, push number three. And we're about two minutes away from having that number tabulated and compared to the opening votes, and we'll be able to declare a winner. So before we get to that, I have a few things I want to take care of, beginning with wanting to thank this panel for the quality of the discussion that they brought here shall the respect--

--they've shown each other.

Their expertise was on display as well as their respect for the power of a good argument.

Also, is your daughter shy about taking bows in audiences? She's not? So your children are, I'm assuming, up in Boston. But one of Richard's-- two of your kids are here. So why don't you-- because they're pretty young for a policy debate, so why don't you stand up and--

Thank you. They looked at you with admiring eyes throughout the debate. I also want to take note of the fact that our audience includes a contingent from West Point. So I want to thank you guys and women for coming down here.

And we had a number of people watching life stream on Slate. We want to thank them for-- for participating and watching and sending in the questions. And also for you as an audience, you were a terrific audience, and we did hear you, and I appreciated all of your applause, both spontaneous and rehearsed and requested by me.

Thanks a lot for that. So we're all going to be back here on Tuesday, September 20th. Our motion on the 20th of September is "Men Are Finished." Arguing for this motion, we have Dan Abrams, my colleague at ABC News. He's our chief legal analyst and author of the book, "Man Down: Proof Beyond a Reasonable Doubt that Women are Better Cops, Drivers, Gamblers, Spies, World Leaders, Beer Tasters, Hedge Fund Managers and Just About Everything Else." Joining him is Hannah Rosen, a writer for the Atlantic and Slate, and it was her controversial article, "The End of Men" that inspired this debate. Arguing against the motion, Christina Hoff Sommers who is best known for her extensive writings, among them, "The War Against Boys," and "Who Stole Feminism?" which chronicles feminism's divisive turn. And finally, David Zinczenko who is editor in chief of Men's Health magazine and author of the best-selling, "Eat This, Not That" series, and a long-time friend of his opponent in that debate, Dan Abrams. And according to the New York Observer, this debate has, "Already divided two halves of a media bromance."

So you'll find a full listing of this fall's debates in tonight's program that you can pick up on your way in or out and on our website where tickets are available for purchase. And all of our debates can be heard on NPR stations across the country, including WNYC here in New York and also viewable on WNET's 13, WLIW, and NJTV.

Don't forget to follow Intelligence Squared on Twitter and make sure to become a fan of us on Facebook. And if you do so, you'll get a discount to future debates. Okay. So we've had you vote twice, and the results have been tabulated, and here it is. Our motion is, it is time to end the war on terror. And recall the side that has changed the most minds, moved its numbers the most in the course of this debate is declared our winner.

Here are the results. Before the debate, 41 percent of you were for the motion, 28 percent against, and 31 percent undecided. After the debate, 46 percent are for the motion. That is up 5 percent. 43 percent are against. That is up 15 percent. And undecided went down by 20 percent to 11 percent. That means the side against the motion has carried this debate. Our congratulations to them. And thank you from me, John Donvan from Intelligence Squared U.S. We'll see you next time.
