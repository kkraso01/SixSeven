# Debate Transcript

Topic: Russia Is A Marginal Power
Motion: Russia Is A Marginal Power

Debate ID: 031214%20Russia


## Round 1

### Moderator
Claim: It’s at this point wwe like to bring to the stage the chairman of Intelligence Squared U.S., who actually brought this program to the United States back in 2006. We’re now, I think, on our 88th debate. And so, in tribute to that, and to hear what he has to say because he’s thought about this for us, let’s welcome to the stage, please, Mr. Robert Rosenkranz. Hey, Bob. The quick answer is some shoulder surgery.

### Moderator
Claim: No, I met this Russian guy in a bar, and I described his country as a marginal power.

### Moderator
Claim: Yeah. You don’t want to do that. Let’s talk about this word, “marginal power.” You know, we go at these motions. And sometimes, we get into a situation where people are actually debating what the motion is about. We have a specific thing in mind with that.

### Moderator
Claim: Well, in our minds, marginal power is the dichotomy of great power. Those are the two opposites.

Is Russia a marginal power? Or is it a great power? And I think that that’s what this debate is meant to be about, at least in our heads.

### Moderator
Claim: And the side that’s arguing for this motion that it’s a marginal power, therefore, not great, what kind of arguments do they have going for them?

### Moderator
Claim: Well, I think their argument would be that Russia has marginalized itself in a lot of ways by conducting its foreign policy in a way where it is pretty much isolated from the great powers of the world. So, yes, it may have Yanukovych as a friend in Ukraine. Or it may have Assad as a friend in Syria. But who wants friend like that? It may be pushing its weight around with its gas exports in Europe, but Europe is now trying to find alternatives to that kind of reliance. It may be sticking its nose-- sticking its thumb in America’s eye with the way it behaves with Snowden, et cetera, but it’s on the verge of losing its status as a G8 member.

And it’s really moving itself into the periphery of global-- the global centers of power.

### Moderator
Claim: Which are lots of ways not to count on the global stage. But what about on the other side? What’s the argument that they do count?

### Moderator
Claim: Well, the argument that they do count is that they take the game of geo-politics extremely seriously. And, in contrast to the United States, which seems not really to be playing that game. So, they are very, very interested in expanding their influence in their immediate neighborhood. And they’ve been a success at that. I mean, they’ve certainly succeeded in Syria-- in getting their guy entrenched in power. They’ve succeeded in the sense in the Ukraine in forestalling the greater unification of Ukraine with European institutions.

And that they’ve enjoyed a substantial measure of geo-political success. It looks like they’re going to be able to, at minimum, absolutely secure their naval base in Sevastopol, but very likely reenacts Crimea without any material consequences across. So, they think strategically like a great power. They act like a great power. And they’ve been successful in their initiatives.

### Moderator
Claim: All right. So, the two sides to the coin-- and one other question. Once your shoulder heals, are you going to have a face off again with that guy?

### Moderator
Claim: You should see how he looks.

### Moderator
Claim: Thank you, Bob Rosenkranz. And now, let’s bring our debaters to the stage. just want to check. I heard some radio transmission while we were talking. That’s all cleared up? Kind of? Audio is good? We can launch? Well, in that case, let’s do that. And I’d like to start with one more round of applause for Bob Rosenkranz for bringing these guests. Boy, did they matter to us once, back when we thought that they could wipe us out, and that they actually had a plan in place to do that. The Russians, I mean. Or the Soviets, as they were known then. Some part of each day, back when they were a superpower, each one of us had to give some thought to what might happen if the men in Moscow really got mad. And then, suddenly, it was over-- the Cold War. Both sides cut up a lot of missiles. We were the one superpower left. The Russians-- well, they seemed to matter less, kind of pushed to the side of our consciousness.

But now, they are certainly back in it, and in all sorts of ways in different parts of the world, which says what about how much the men in Moscow matter now, and how much do we actually need to worry about it? Well, that sounds like the makings for a debate. So, let’s have it. Yes or no to this statement: Russia is a marginal power. A debate from Intelligence Squared U.S. I’m John Donvan. We have four superbly qualified debaters-- two against two-- here at the Kaufman Music Center in New York. They will argue for and against the motion: Russia is a marginal power. Our debate goes in three rounds. And then, as always, the audience votes to choose the winner. And only one side wins. Our motion is this: Russia is a marginal power. Let’s meet the team arguing for the motion. First, please, let’s welcome Ian Bremmer. Ian, you started early. You traveled to the Soviet Union when you were 16 years old. You then edited a book on Soviet nationalities when you were 22 years old. When you were 28 years old, you founded the Eurasia Group, a political risk consultancy. So, a lot of precociousness going on there. And, in 2013, you wrote up a list of the world’s most powerful people. You gave the number one spot to nobody. But you gave the number two spot to Vladimir Putin, which the Russian state-controlled media got very, very excited about and took as a compliment. Did they get the message right?

### Conspiracy Advocate (CA)
Claim: Not entirely.

### Moderator
Claim: The point being?

### Conspiracy Advocate (CA)
Claim: The point being that Putin has become extraordinarily powerful at the expense at the Russian people and at the expense of the Russian nation.

### Moderator
Claim: So, not such a compliment.

### Conspiracy Advocate (CA)
Claim: Take it as you wish.

### Moderator
Claim: Ladies and gentlemen, Ian Bremmer. And Ian, who is your partner tonight?

### Conspiracy Advocate (CA)
Claim: My partner is the inexplicably charismatic Edward Lucas.

### Moderator
Claim: Ladies and gentlemen, Edward Lucas. Ed Lucas, you are the author of several books. You’re also arguing that Russia is a marginal power. Your books include “Deception,” a book about Russian espionage, and “The New Cold War,” in which you argue that Russia, under Vladimir Putin, is a danger to itself and to others. You’re also senior editor at The Economist, where you served as Moscow Bureau Chief from 1998 to 2002, which puts you in Russia really at about the time that Putin, essentially, for the rest of us, came out of nowhere to rise to power. We didn’t know much about him back then. But you had a bad feeling early on?

### Conspiracy Advocate (CA)
Claim: Yes, there was a clue in the three letters in his resume, which went KGB. And I plenty of experience of them. And I didn’t-- I didn’t like that.

### Moderator
Claim: It’s a dead giveaway. Ladies and gentlemen, Ed Lucas. Our motion is “Russia is a marginal power.” Two debaters are arguing against it. First, let’s please welcome Robert Blackwill. Bob Blackwill, you are a former Deputy National Security Adviser for President George W. Bush. You also served President George H.W. Bush as a special assistant for European and Soviet affairs from 1989 to 1990. So, you were in that Bush White House just at the time that Soviet power collapsed. And it’s been said that, basically, it all happened so fast at the time that nobody in the White House saw it coming until pretty much just before it went down. Is that an accurate picture of it?

### Scientific Advocate (SA)
Claim: Yes, more or less. We weren’t able to project the crisis and what would happen day by day, not least because the leaders in Moscow weren’t able to project the crisis and what would happen day by day. Vaclav Havel, the Czech leader at the time, said, “Things are happening so fast, we do not have time to be astonished.”

### Moderator
Claim: Which sounds like it could describe today, quite possibly. Ladies and gentlemen, Robert Blackwill. And Bob, your partner is?

### Scientific Advocate (SA)
Claim: Peter Hitchens-- well-known columnist, author, spent a lot of time thinking about and living in Russia. And I commend to you his columns in the Sunday Mail.

### Moderator
Claim: Ladies and gentlemen, Peter Hitchens. Peter, I was going to do that commercial for you, but your partner just did it so well. I just want to point out you spent two and a half years living in the Soviet Union-- at the end of the Soviet Union. And, rather controversially, you have written that you actually like Vladimir Putin. And, at the same time, you call him a “sinister tyrant.” So, how does that work?

### Scientific Advocate (SA)
Claim: Well, I think sometimes countries need sinister tyrants. And Russia is a country that needs a sinister tyrant now, having been through the dreadful debauchery and rape of the Yeltsin era, which we imposed upon it. It needs a sinister tyrant to--many, many Russians who love their country feel that way, and they've always preferred to be feared than pitied. And I think that's not an unreasonable position, and I quite understand it.

I'm lucky enough to live in a country which doesn't need to be feared or pitied, but I would hate to be in a country that was pitied.

### Moderator
Claim: Where are you from?

### Scientific Advocate (SA)
Claim: Well, actually, I was born in Malta, a small island in the middle of the Mediterranean, but it's part of the British empire.

### Moderator
Claim: Oh.

### Scientific Advocate (SA)
Claim: But the British Empire has subsequently disappeared. So I-- what I live in is airstrip one, a small province of the European Union.

### Moderator
Claim: Ladies and gentlemen, Peter Hitchens.

### Scientific Advocate (SA)
Claim: Formerly known as Great Britain.

### Moderator
Claim: So this is a debate. There will be a winner and a loser, and you, our live audience here in New York will choose by voting twice, once before the debate and once again after the debate. And the team whose numbers have moved the most in percentage point terms will be declared our winner. Let's go now to the preliminary vote. The motion is this: Russia is a marginal power. On to round one. Round one, opening statements from each debater in turn. They are seven minutes each. Our motion is Russia is a marginal power. And here to speak from the lectern first in support of this motion, Edward Lucas.

He is a senior editor at the Economist where he has covered the central and east European region for over 25 years, including time spent as the Economist Moscow bureau chief. He is the author of "The Snowden Operation.” Ladies and gentlemen, Edward Lucas.

### Conspiracy Advocate (CA)
Claim: Thanks very much, Mr. Chairman. Of course, Russia matters. It can't not matter. It's the largest country in the world by land mass. It's a $2 trillion economy, and it's a super power, not only a nuclear superpower but a cultural, scientific and linguistic one. The question is how to use that great potential. Does it maximize it in the mainstream of world affairs, or does it squander it on the sidelines? And it's my contention that Russia squanders its potential under the rule of Vladimir Putin.

Now, we had great hopes 25 years ago in those glorious days when Peter and I were covering the collapse of the evil empire, that freed from the burden of communism, of the burden of imperial history, that Russia would take its rightful place as a great power in the mainstream world affairs. And it didn't happen. Now, I disagree with Peter. I don't think that we imposed something on Russia in the '90s. I think the Russian leadership squandered those chances with a mixture of corruption, spectacular corruption, nostalgia and paranoia, and it's got worse and worse as it's gone on. What has Russia got now to contribute to the great problems that are facing us? What does Russia have in the way of a constructive original solution on the law of the sea, space, climate change, internet freedom, development, world trade system, reforming world finance, ethics of medical research, or on security? What's it have to say about the Middle East? About wars in Africa, about how East Asia should cope with a rising China?

I just ask my opponents if they can think of one constructive original contribution that Russia has made to these questions. It'd be great if they'd like to declare it because it's very easy to know what Russia's against. Russia's against the EU. It's against NATO. It's against modern organizations in general. It's against the West. So we know what Russia's against, but we don't know what Russia's for. Now, you may say, well, what Russia is for is sovereignty. It believes in the principle of nonintervention, and that's why it stands by and blocks sanctions against-- any sanctions against Syria that might have some effect on the terrible conflict there. But it's not consistent in this. It doesn't practice what it preaches. It's strongly against intervention when it comes to the West. But it's in favor of intervention, in fact, it loves intervention when it comes to the captive nations of the empire, perhaps the one countries that from all they suffered under Soviet rule, it should treat with the greatest sensitivity and respect.

Now, I believe in principle that intervention is sometimes right. I think we should have intervened in Rwanda, for example, to stop the genocide. But I think it was a high buy. You have to produce some evidence if you're going to intervene, evidence of real human rights abuses. There's no other way of an intervention to try and solve them. But Russia hasn't done that in Ukraine. Russia hasn't produced any evidence at all. It asserts things, but it hasn't invoked international human rights organizations, it hasn't tried to negotiate with the Ukrainian government. Its intervention in Ukraine is decried by the very people it aims to help. We have the Russian Philological Society in eastern Ukraine appealing to Putin to hold back. We have all the Jewish organizations and all the chief rabbis writing an open letter to Putin saying, please don't do this. So he doesn't produce evidence. He doesn't produce arguments. He doesn't like engaging with the mainstream of the way the world works because he knows those arguments are phony, and the evidence is empty, and his chances are slim.

I'd just like to-- as my opponents over there have been rather silent, to give them another question. Can you name one European country, one democracy that thinks what Russia is doing is right. In fact, okay, further, can you name one real friend that Russia has, a country that is friends with Russia because it wants to be, not because it has to be. So don't count Tajikistan, which has Russian troops on its territory. Don't count Armenia, which was arm-twisted into abandoning its deal with the European Union. Don't count Belarus which was strangled with the gas pipeline. Name a normal country, a country-- name a country, a country which actually says, yes, Russia, we share your views. We like you. Please don't mention Bashir Assad in Syria or Venezuela. Name a respectable country that is actually-- that actually likes Russia and says, "Good job, Vladimir, we really like it.” Russia is a marginal power, and it's marginalized itself.

It's not the West. We showered Yeltsin's Russia with money. Misfit, stolen and wasted, but we tried. We brought Russia into the G8. We set up the NATO Russia council. We brought Russia into the European security architect, the council of Europe, the OSC, all these organizations. And it hasn't worked because Russia doesn't want to be in the mainstream. Russia doesn't like having responsibilities. It doesn't like having rules. It doesn't like respecting other countries' rights. It likes doing things its own way, and that's a terrible misfortune for Russia's neighbors, and it's a terrible misfortune for the-- for the people of Russia. Now, I don't want to intrude too much on private grief, but I'd just like to ask you to share-- spare a thought for a moment for our opponents here, because they would love to believe that Putin had done something right, that maybe he'd sort of modernized Russia, he'd sort of stabilized Russia. He'd maybe repaired Russia's infrastructure, that he'd made Russia a power that could be respected, and it hasn't happened.

The Putin years have been 14 years of terrible missed opportunity. More than a trillion dollars of excess oil and gas revenues came flooding into the coffers of the Russian federation. At the end of it, you still can't drive from one end of Russia to the other. But who's to blame for that? Not the West, not the outside world. You have to blame the crooks, the thugs, the spooks and the cronies who have been misruling Russia, losing of tens of billions dollars a year, sometimes I admit with our complicity, laundered in the city of London, in Austria, maybe even New York, who knows? It's been a catastrophe. We should not approach this debate in some kind of tale of sneering triumphalism. It's not that we're pleased that Russia's on the sidelines. It's a tragedy. We need Russia to be playing a role in the mainstream of world policies, in the mainstream of world affairs, and it's not happening. One day maybe it will. But for the time being, ladies and gentlemen, Russia is a marginal power.

### Moderator
Claim: Thank you, Edward Lucas. And that is our motion: Russia is a marginal power. And now here to argue against this motion, I'd like to bring to the lectern Peter Hitchens. He is a columnist and reporter for the man on Sunday and a former resident correspondent for the Daily Express in Moscow and in Washington, D.C. Ladies and gentlemen, Peter Hitchens.

### Scientific Advocate (SA)
Claim: Well, good evening, or dobryy vecher as they say in the Kremlin. I feel a bit underdressed for this occasion. I haven't brought my order of the Red banner, but I'm sure Edward will have ordered me one by the end of the evening. All right. Edward and I hugely enjoyed the Cold War. I enjoyed particularly as an ex- Trotskyist, I loathed the Soviet regime from that point of view, and then later on as a fervent Cold Warrior and a genuine believer in the truth that the Soviet Union was an evil empire. It was an evil empire. There's no question about it. And anybody who doubts it should have seen what I saw.

But the problem of enjoying the Cold War and if we’d like to get a party together to go and put the Berlin wall up again tonight, I'll be at the head of it because it was, in many ways, extremely enjoyable for journalists and a wonderful moment in which we all knew which side we were on. Enjoying the Cold War as much as we did as a pleasure is that we forget that we ought to look upon it in one or two other rather important ways. There was a very, very important moment in the early years of Mikhail Gorbachev when he was dismantling the Soviet Union, when he came under attack from a group of American conservative journalists who kept on saying, "We don't believe this. We don't believe that you're doing to the Soviet Union what we say that you are.” And he just sat there smiling silkily as he did. And eventually he said, "Gentlemen, I'm terribly sorry. We have done to you the worst thing, the most unkind thing we could possibly have done to anybody. We have deprived you of an enemy." And this was what happened in 1991.

We were deprived of an enemy. I was in Moscow on that lovely sunny Monday morning in August 1991. I came out of my block of flats, my neighbors were the Brezhnev family and the Andropov family. I came out of my block of flats, onto my street, Prospect, and down the street were coming tanks, in the slanting sunshine, with their barrels pointing towards the center of Moscow, rolling down, kicking up dust, a very strangely moving sight. And I saw Moscow through all the following days as collapsed utterly. And one particular scene is burned upon my memory, and that is this, that in every trashcan in the city, every single trashcan was full to the brim of communist party membership cards burning. It was over. There was no question in my mind that it was over. This was not the Soviet Union, it was Russia. A year later, I was allowed to go into the closed city, as it then was, of Sevastopol, to see what was left of the Soviet navy, Admiral Gorshkov's great global blue water navy, the principal instrument of power projection of the Soviet Union, in its struggle for mastery of the planet with the United States.

And in every creek and inlet around Sevastopol were sunken ships, ships downed by the bow, ships downed by the stern, ships canting over at degree-- at 45 degrees, abandoned, wrecked, finished, over, dead, gone. So we have the communist party gone, and we have the world power gone. And then we have this extraordinary era in which I'm afraid Edward has been a little bit, how shall I say, "kind," to the West, in which we said to the Russians that, "We must now have in Russia democracy, and we must now have capitalism.” And we indeed showered them with money and stupid advice, paying very little attention to what that country really needed, which was the rule of law and liberty.

And that whole era is now known to most Russians who lived through it when it was a time of debauched currency, hopeless, terrible corruption, misery and theft, the loss of their homes, the loss of their jobs, the wiping out of their savings overnight. They refer to it-- you'll know the Russians, their democracy is-- demokratiya They refer to it as "dermokratiya," which I will translate politely as the "rule of excrement." That is the view of most Russians of what they went through. I will end with another reminiscence because this is very important in understanding why it is that Russia now so very much desires to be left alone. The other reminiscence is in my first week in Moscow, I went to a film being shown in the Cosmos Cinema. And it was a film called, which means approximately, "We can't go on living like this.” It was made by a man called Stanislav Govorukhin, who was a great friend of Alexander Solzhenitsyn. And it went through in great detail-- and it's a disgrace that no Western cinema and no Western TV stations ever shown this film because it's so graphic-- it went through in great detail the horrible misery, corruption, oppression, and lies of the Soviet Union.

And I became aware as I sat watching this that everybody in the cinema was weeping. For the first time, they had been allowed to see in detail the truth about the disastrous country in which they'd been living. Now what they want is actually to be left alone, to be Russia, a country which will exist whatever you do to it. You might as well try and remove the Himalayas with a teaspoon as to remove Russia from the international, diplomatic, or military, or economic landscape. It simply is not going to go away. And to pretend that it will and to impose on it Carthaginian treaties, when its territory is taken away and it's pushed up to the same borders, imposed on it by Keiser Wilhelm in 1918 is not going to work. But the thing to remember about that film is that during the last election in which Vladimir Putin won, one of his key supporters was Stanislav Govorukhin, friend of Solzhenitsyn.

And he said, "I'm supporting Putin because under Yeltsin we had disgusting hopeless misery and debauchery. Under Vladimir Putin we have normal corruption." And that was not a feeling which was unshared by millions and millions of Russians. He spoke for them. When Putin was elected, it wasn't entirely undemocratic. I a very simple point here. Here we are in a country which has the Pacific Ocean on one side, the Atlantic Ocean on the other, Mexico at the bottom, and Canada at the top. Now, just imagine for a moment that you didn't have that, you had Germany on side and China on the other and Japan breathing down your neck, and that you didn't have a gigantic global navy or an enormous amount of physical wealth, but you actually had to cope with the fact that you had dangerous neighbors, you might be less concerned with fanciful global ideas of wonderful global international cooperation, and you might be more concerned with the simple straightforward issue of whether you could survive defensibly as a country, a society, an economy, and a culture.

You would be closer to the truth than you are here in this extraordinary, wonderfully protected paradise. Ladies and gentlemen, Russia is not a marginal power. Please do vote against this motion. It is a very foolish motion indeed.

### Moderator
Claim: Thank you, thank you, Peter Hitchens. And here's a reminder of where we are. We are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two against two, arguing it out over this motion, "Russia is a marginal power.” You've heard the first two opening statements, and now on to a third. Debating in support of this motion, that "Russia is a marginal power," Ian Bremmer will now go to the lectern. He is founder and president of the Global Political Risk Research and Consulting Firm, the Eurasia Group, an author of "Every Nation for Itself, Winners and Losers in a G-Zero World.” Ladies and gentlemen, Ian Bremmer.

### Conspiracy Advocate (CA)
Claim: So let me start by saying I'm sympathetic to much of what Peter said. I certainly agree that the United States was not trying to rebuild Russia after the Cold War was over the way we did Japan and Europe with MacArthur and the Marshall plan. Shock therapy, NATO enlargement, energy diversification, those things that we actually did didn't help Russia, they weakened Russia. Okay, let's remember what this debate is about. The debate is about-- not about "Are we sympathetic with Russia's position?" I'm very sympathetic with Russia's position. They're just losing, right? They're-- if we had helped them a lot, they might still be a great power. Maybe, it's possible, they lost a lot. They had little legitimacy, but they might have-- they'd be in better shape. Peter and I clearly agree on this.

The problem is he's debating the other side, right? What we're debating is that Russia's not a great power, it's a marginal power. I decided to look something up in the dictionary before I got here. Marginal, what's the definition of marginal? It was "Not of central importance, limited in extent, significance or stature.” I look at global politics today. I look at the economy. Russia isnot a great power. It is a marginal power, and it's becoming more marginal by the day. I had a discussion with David Miliband, the ex- British foreign secretary just a few weeks ago, and there was a question from the audience as to why it was that British relations with Russia had gotten to be so poor. And he said, "Well, you see, the Brits believe that Russia is in decline, and Russia believes that Britain is in decline," and we are both correct. That's where we are. Oh, look, I agree with Peter as well that Putin is a sinister tyrant. Do I think that Russia really wants that? No, no, I don't. Certainly they like a little less sinister. They understand that leadership needs to be strong, but less sinister. Anticorruption? The Russians themselves did a poll on this in the last couple months, 5 percent of Russians believe that the anticorruption policies of Putin were in any way effective. They'd like them to be a little bit more effective. They would. You know, 110 Russians presently control 35 percent of Russia's household wealth. We have-- we talk about inequality in the United States. The Russians actually get it right, right? 0.0000007 percent of Russians control 35 percent of the country's household wealth. Look, it is a big country. They don't have many people on it , it's a big country, right? I mean, Palin can see them from her house-- you know, Putin can see Alaska from his house. Alaska doesn't have much sway in the bottom 48, right? It's big. They've got a lot of resources. They don't have many people, right? We're not excited about Alaska. I apologize if you're from Alaska, but we don't care. The problem is what’s Russia doing with all of that land? What’s-- what are you doing with all of that potential? I’ll tell you what they’re not doing is fixing their economy. There have been a lot of companies out there that have thought about investing big in Russia. IKEA used to make more money per square meter in Russia than anywhere else in the world in the early 90s. They’ve pulled back.

Why? Because folks came in. They said, “Oh, you’ve got environmental problems. Under your parking lot, there’s a gas line. You’re going to have to pay us an awful lot. We won’t do that. Oh, I guess we’ll shut down IKEA for a bit.” Wal-Mart thought about it for four years, decided not to invest. Wal-Mart wants to be everywhere. They’re your big-box, low-cost leader. They’re all over China. That’s not an easy place to invest. They’re not in Russia. Toyota, $28 million in St. Petersburg because the Russians desperately wanted them-- the Japanese to work with them. Koizumi brought over the chairman and CEO. Said, “Let’s do this.” They said, “We’ll test it out, and if it goes well a few years later, we’ll make Russia the base of manufacturing for the entire Eurasia region.” Have they expanded? Absolutely not. Everything walked out the door, right?

Economics-- we have to say economics matter, right? We can’t just pretend that it-- that it’s not important. Geopolitics-- here, let me go back to my friend Edward here.

You’re right. Tajikistan, Armenia, Belarus-- that is not a portfolio you want. Snowden-- the Chinese handled Snowden well. They said, “Let’s get him. Let’s bring him over.

We’ll grab all of his stuff. We’ll learn some stuff about how the American’s are spying on us. And then, we’ll send him somewhere.” And Russia said, “Me, me, me. Let’s have him.” And the Russians grab him. They said, “We’ll take all the stuff. And then, we’ll send him to Cuba. Oh, we didn’t think that through very well.” They don’t want to keep him. It became a problem. They didn’t think it through very well. Again, feather in Putin’s cap. It’s great. He can swan around. Feather in Putin’s cap. $51 billion on Sochi. What did that do for the average Russian? How’s that done for Russia in the world? It’s been a problem.

Ukraine is the most important national security interest that Russia has outside of their country. The average Russian believes that Ukraine has been a part of it for 300 years. The Americans and the Europeans didn’t care. Yanukovych wanted aid from the Americans and Europeans so that he could balance the Russians off against the Europeans. And we said, “Sorry, not it. We’ve got other things to take care of.”And so, then, Putin said, “I’ll write you a check for 15 billion out of our pension fund.” And, you know what? The Ukrainian people said, “We don’t care. We don’t want the money. We’ll demonstrate. We’ll die in the streets, rather than have to live under that.” That’s Ukraine. We’re not talking about Germany. We’re not talking about Indonesia. These are the people that speak Russian and Ukrainian together. So, they’ll have Crimea. They will take Crimea. We told them, “Red line.” We told lots of-- we told the Syrians, “Red line.” They stepped over it. Does that mean that they are a great power? Syria? It does not. Are the Russians a great power? They are not.

Let me just end a couple other economic bits. How big are the Russians today, economically, compared to China? Chinese economy is more than four times larger. That’s pretty-- talk about the BRICs, as if they’re all places that you would think about with equal importance.

The Russians are losing out in their backyard because of the Chinese imposing their will increasingly economically dominating central Asia, because that’s where all the investments are going to come from. East Siberia, because the Chinese are demographically swamping Russia there. The Russians are concerned about that. There’s no question in my mind that if we look at the future for Russia geo-politically, geo-economically, demographically, this is not a great power. We all wish it were. It’d be better for them. It’d be better for the world. But, it’s not. And I think you should vote, as a consequence, with us, and for the motion. Thank you.

### Moderator
Claim: Thank you Ian Bremmer. And the motion is “Russia is a Marginal Power.” And now, our final debater against the motion in opening statements, Robert Blackwill. He is the Henry A. Kissinger Senior Fellow for U.S. Foreign Policy at the Council on Foreign Relations, and former Deputy National Security Adviser under President George W. Bush. Ladies and gentlemen, Robert Blackwill.

### Scientific Advocate (SA)
Claim: Good evening. Skillful debaters, when they have a weak case to make, change the subject. So, let’s remember what the subject is. It is not, “Is Russia a responsible member of the international community?” No, it’s not. It isn’t, “Does Russia have friends?” No, it’s not. It isn’t, “Would you vote Vladimir Putin to be your church deacon?” The answer is no. And finally, it is not, “Is Russia a great power?” That is not the subject of this debate. The subject of this debate is, “Is Russia a marginal power?” And, as our colleague mentioned, this means a country with very little impact on the international system, and very little consequence for the United States.

So, I’m going to quickly go through why I believe that’s deeply mistake. So, first, Russia, today, is the only country on mother earth that can destroy the United States as we know it in 30 minutes. It has 1,500 nuclear weapons on hair trigger aimed at America’s cities. No other country could have the effect on the United States of Russia. It has 10,000 nuclear weapons. Think Hiroshima. Think Nagasaki-- 100,000 people died. And think 10,000 nuclear weapons.

Second, the United States and Russia possess 95 percent of all nuclear weapons on the planet. And let me just quote one of my favorite senators, if not my favorite senator, Diane Feinstein: “We have a chance to wind down and expedite the removal of 96 percent of the world’s nuclear weapons.”What an achievement it would be we could say that the nuclear arsenals of both Russia and the United States have been reduced to the barest minimums. That cannot be done without Moscow. And it’s hardly the example of a marginal county. Third, nuclear terrorist-- something that, of course, this great city is preoccupied with, because it would be one of the principle targets if a nuclear weapon got into the hands of terrorists. Since the end of the Cold War that we’ve been discussing, the two countries that possess most of the weapons, including Russia, have lost not one single loose nuke. And that has a major impact, potentially, on your lives.

Fourth, Russia works with the United States to prevent the proliferation of weapons of mass destruction, especially nuclear weapons and missile-delivery systems. Is their record perfect? No, it’s not.

But they are deeply involved in the negotiations we are having-- we, Americans, are having with Iran on the future of the Iranian nuclear weapons program, and on our efforts to cap the North Korean nuclear program. Sixth, Russia today is a vital lifeline for the 40,000 American troops that remain in Afghanistan. We could not supply our courageous men and women in Afghanistan fighting that war without the so-called “northern route” through Russia. And this is largely because of our problems with Pakistan, but it’s absolutely indispensable to the safety and security of American troops in Afghanistan. The U.N. Security Council-- Russia is a permanent member.

And, if you care about international law, and if you care about the United States acting abroad in the context of international law-- that is to say through security council resolutions-- that cannot happen unless Russia supports that. And we can all remember of actions the U.S. has taken the last 15 years which couldn’t command the unanimous vote of the U.N. permanent members, and which, you’ll remember, didn’t go all that well. Of course, as it’s been mentioned, Russia’s the largest country in the world. An eighth of the earth’s surface in this extraordinary country. It is the ninth- most populous country in the world. It’s not a small country-- 150 million people or so. If Russia is a marginal power, what’s a non-marginal power? Do our debating colleagues think only the United States is not a marginal power?

And, finally, the environment-- the environment. Russia emits one-quarter of all the carbon emissions on the globe. How can we say it’s marginal when it has that effect on the environment? I conclude with Ukraine. Our colleagues argue that Russia is a marginal country. Do you think the Ukrainians who just lost a part of their country the size of Massachusetts through the intervention of Russian military forces believe it’s marginal? Is that why the President of the United States has spent a total of five hours speaking with the Russian president in the last 10 days to try persuade the Russian president to withdraw those forces. Is that why the American president this afternoon saw the Ukrainian prime minister? Could that have happened? Would that be happening if Russia were a marginal power? Woody Allen once bragged-- resident of this city-- once bragged that he'd taken a 20-minute speed reading course, and read one piece in 20 minutes. And somebody asked him, what was it about? And he says, "It was about Russia." I think that our colleagues debating for this motion have taken a strategic speed-reading course to come to the conclusion that Russia is a marginal power. Thank you.

## Round 2

### Moderator
Claim: Thank you, Robert Blackwill. And that concludes opening statements in this Intelligence Squared U.S. debate, where our motion is: Russia is a marginal power. Now we move on to round two. Round two is where the debaters address one another directly, and they take questions from me and from you in our audience here in New York City. We have two teams of two arguing for and against the motion, Russia is a marginal power. The team arguing that Russia is a marginal power, Ian Bremmer and Edward Lucas. We've heard them argue that Russia could be a great nation, but it fails to meet that bar, that it has squandered the opportunities that it has innately and that have been given to it since the end of the Cold War. The nation is paranoid. It contributes very little to the solving of great problems in the world; that Russia doesn't really want responsibility in the first place.

It doesn't want to play as a responsible member of the international community. The team arguing against the motion, Peter Hitchens and Robert Blackwill, they argue two ways on this one. One of those partners argues that the anti-Russian narrative being heard from their opponents is in itself a sort of nostalgia for the Cold War and a yearning for an enemy. More specifically, though, they argue that trying to define what-- what Russia is in terms of greatness or marginality, issues like friendship are irrelevant, that a nation that has nuclear weapons, a nation that can destroy New York City in half an hour, almost by definition is already not a nation that you can call marginal, even if you can't call it a great nation, necessarily. What I find interesting in what we've heard in the opening statements so far-- and this is rarely happens in our debates-- is that the two sides actually, I think, agree a hundred percent on the basic facts about what is happening in Russia, that it was a powerful nation, less powerful now, that it is led by a sinister tyrant, that its economy is a bit of a mess.

Nobody's disagreeing about that. What they're disagreeing about is what these things imply. So I think what we need to do is go through some of the issues that came up and talk about what they imply in terms of greatness or marginality or somewhere in between. Let's start with the most obvious: Nuclear weapons. Robert Blackwill, the side arguing against the motion, has said the ability of the Soviet Union to blow us up and perhaps ultimately their intentions to do so, make them highly, highly relevant to the United States and to the rest of the world. He also points out that that may underwrite the fact that Soviet diplomats get attention, they get time in-- sorry, Russian. Thank you. Did I say Soviet.

### Scientific Advocate (SA)
Claim: Twice.

### Moderator
Claim: Let's go back and do that whole thing over again. for the record, and for our radio listeners, I lived there during the Soviets, and I can't get it out of my head. So I mean Russian. Every time I've said, "Soviets" so far, almost all of those times. Let's go to the side, though, that's arguing for it, the motion, Russia is a marginal power, and take on this issue of nuclear capability that Russia still possesses, which your opponents say all by itself makes-- makes it impossible to call Russia a marginal power. Let's take that to Ed Lucas.

### Conspiracy Advocate (CA)
Claim: Well, as I said, almost my opening words, Russia is a nuclear superpower. It's worth bearing in mind, of course, that having the nuclear war heads is one thing, and delivering them is another. And the record of the Russian Navy, of building new strategic submarines is pretty-- pretty patchy, even by the lamentable standards of defense procurement contracts worldwide. And there's something slightly comic about seeing the old bear bombers which look like something out of Dr. Strangelove lumbering up to Guam and other places in NATO air space to try and provoke us and scare us.

And you kind of wonder if the rubber bands and gaffer tape or duct tape is still holding it together all right. I worry about the security of the Soviet-- Russian-- ex-Soviet and now Russian…it’s catching--

### Moderator
Claim: Yeah, yeah, very.

### Conspiracy Advocate (CA)
Claim: --of a nuclear arsenal. But I just want to-- also, if I may, just pick up on one-- I don't really--

### Moderator
Claim: But just to the point then, you're saying that that capability is rather irrelevant to--

### Conspiracy Advocate (CA)
Claim: Well, it's there in the sense that if Putin goes mad or even madder, yes, he can do a Dr. Strangelove, and he can blow the world up, and that is indeed something to worry about. But I think you have to ask, how does he use that power? What is he using that power for? How does he take that power and put Russia at the center of world affairs. Is he helping, for example, to deal with nonproliferation. That would be a really good thing for a nuclear superpower to do, to try to make sure we deal with nuclear proliferation in the Middle East, maybe put pressure on North Korea so that they don't develop their nuclear.

That's what a responsible, what a mainstream nuclear power would do. Russia's not involved in that. On the contrary, it's actually constantly threatening to sell advanced systems to Iran which will give the Iranians more time and more protection for their nuclear program. They certainly played no role in helping to--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --deal with North Korea.

### Moderator
Claim: Let's take some of what you just said back to Robert Blackwill, where we hear Edward Luke was again arguing on this issue of what's marginality? What pushes Russia from the center of the game? And he's saying the weapons are irrelevant. It's how they use them.

### Scientific Advocate (SA)
Claim: Well, first of all, Russia is modernizing all three legs of its strategic deterrent, its delivery systems. So those are facts. Unlike the United States, Russia has active programs, missile programs, submarine programs and aircraft programs to deliver its nuclear weapons. They take it seriously. Second, Russia is involved in the North Korean diplomacy. And third, Russia has not delivered advanced air defense systems to Iran. They haven't done so. So all three of those facts are wrong.

With respect to nuclear weapons and our colleagues admit that it is a superpower. The question again, just to remind ourselves, is not, is Russia a responsible power? We all agree it's not a responsible power. And we can list all the different ways. But that's not what the subject tonight is about. It's rather how important a power is it, and the nuclear weapons make it of consequence to the United States.

### Moderator
Claim: Ian Bremmer, so take that point that your side made, that in a sense, the responsibility of a nation defines its greatness, its centrality or its marginality in its absence. Take that point about why you're, to some degree, hinging your argument on whether Russia is a grownup, mature player in the game.

### Conspiracy Advocate (CA)
Claim: I think our argument has a lot to do with whether or not its power is relevant and useable in the world today. I mean, Russia is a nuclear superpower. It's also a sugar beet superpower.

That's nice. Borscht would be unmakable in this country, were it not for Russia. The fact is, we're not very concerned about their nukes. For the last ten plus years, we've been most concerned about the war on terror. And just last year, finally, we said, well, you know, we've dealt with al-Qaeda at least in terms of the United States, just not for other countries, but now we're much more concerned about cyber as the principal concern for the United States. And, of course, in terms of cyber attacks, the Russians have a lot of criminals. But in terms of the potential of a government to engage in cyber attacks against the U.S., that is head and shoulders, neck, body-- it's China above anybody else, above the Russians.

So, yes, we're not going to deny the fact that Russia has 10,000 nuclear warheads. What we are going to say is that alone doesn't actually cut it on the world stage today.

We're certainly not acting as if it cuts it. We don't-- our strategic planning as a country and our prioritization and policy is not as if that is the principal thing that we are losing sleep over on a daily basis.

### Moderator
Claim: Peter Hitchens.

### Scientific Advocate (SA)
Claim: Well, I don't actually share this concern about nuclear weapons very much because I've come to the conclusion that they are more or less unusable, and I don't think anybody would-- since Harry Truman used them, I don't think anybody else will ever do so. It is noticeable what the Russians did develop in the first part of the 21st century. But--

### Moderator
Claim: But does that mean you're agreeing with your opponent?

### Scientific Advocate (SA)
Claim: Well, I do. I can't sit here and honestly say that I-- well, I don't believe. But I think it is simply the absurdity in this is not about nuclear weapons as the absurdity is in the wishful thinking of those who would like there not to be a major power on the planet which differs from the United States on a number of very important objectives.

And the motion is really about, we wish Russia were a marginal power because we would like it to be the case that we could bomb Syria as we failed to do. We'd like it to be the case that we could globalize the world and sweep away borders to the extent they have. The argument which is not being had here about Ukraine, for instance, is probably not largely known in this country, is the nature of the European Union. –It has a sort of supreme Soviet with no opposition. It is intensely bureaucratic. It is entirely lawless. It is monstrously corrupt. And this is--

This is the body which we were supposedly--

### Moderator
Claim: What does that have to do with our motion?

### Scientific Advocate (SA)
Claim: It has to do with the fact that there was-- what has provoked the immense international crisis in which we now find ourselves is not a struggle between freedom and tyranny. It's a struggle between two power blocks. And one power block is in favor of globalism and the sweeping away of borders. And one power block is in favor of national Soviet--

### Moderator
Claim: Okay, you're-- you're--

### Moderator
Claim: In a broad way, your opponents are sort of arguing that Russia is not very good at being very good at anything.

### Scientific Advocate (SA)
Claim: Yeah. I'm saying it's very good at standing up for national sovereignty. The issue of Ukraine’s international sovereignty is easily resolved. Ukraine is an artificial nation created at the nadir of Russia's fortunes. Had it been that the United States had gone through a tremendous crisis in 1991 in which Mexico had been able to seduce the four states, which the United States took from it in 1848, back into some kind of independent republic, allowing the United States Navy use of San Diego, you'd have roughly the same circumstances, and you'd view it very much the same as the Russians.

### Moderator
Claim: Okay. I want to go Edward Lucas. I want to point out that this audience is going to vote on whether-- on this motion whether Russia is a marginal power or not. And--

### Scientific Advocate (SA)
Claim: I just think this stuff is interesting, that's all.

### Moderator
Claim: Yeah, but you've got a partner there you want to back up. Edward Lucas.

### Conspiracy Advocate (CA)
Claim: When I was reading up for this debate, I came across a particularly good quote which I think exemplifies a very important point. It goes like this: “The idea that you can intervene in another country because you don't like its regime is wrong, dangerous, and should be opposed. That is why I like Vladimir Putin.” That's what Peter Hitchens said in his talk at Bristol. It's very interesting. Everyone's in favor of this until you come to a case you don't like. And I think the idea that you can just dismiss Ukraine as an artificial country is extraordinary. And I wonder how-- is anyone in the audience here from Ukraine, by the way? Yeah, do you think that it's a marginal country? Do you think Ukraine is a real country? Yes, you do. You're nodding. You think so too.

### Conspiracy Advocate (CA)
Claim: This guy's not sure.

### Moderator
Claim: For the sake of the radio audience, about three of the 500 hands went up. Are you done?

### Conspiracy Advocate (CA)
Claim: I'm not. But I will give way to you. I want to get--

### Moderator
Claim: All right. Robert Blackwill.

### Conspiracy Advocate (CA)
Claim: --to discussing more important--

### Scientific Advocate (SA)
Claim: Well, perhaps I am eccentric, but I can tell the difference between a nuclear weapon and a sugar beet.

And as for cyber, the morning New York Times reports that there are major cyber attacks emanating from Russia against Ukraine today. So to dismiss Russia's impact on the future of Ukraine as if it were not perhaps even the most important actor outside Ukraine on the future of Ukraine, seems to me quite myopic.

### Moderator
Claim: Ian Bremmer.

### Conspiracy Advocate (CA)
Claim: I cede to the ambassador that a nuclear weapon is not a sugar beet. Look, the question is not, do nukes matter? The question is, how important do we actually estimate Russia's capabilities broadly for-- since the Cold War is over, Gallup has taken a poll of all Americans asking, open-ended question, who do we think of as our principal enemy?

Right? They probably even asked Romney at one point, right? They got the Russia answer. But not from anybody else. China-- China most recently was number one. Before that, it was Iran. And the only other countries that ever make it into the top four are Iraq and North Korea. We're just not that worried. Look, when Obama came in, we sent over, as ambassador to Russia, Mike McFaul, guy I know very well, very capable guy, former Stanford prof. Did his PhD with me in Stanford, and is absolutely prodemocracy, pro-opposition. First day he goes over to Moscow, what does he do? He meets with the opposition, clearly a red rag to a ball, right? I mean, we never would have done that with China. We never would have sent over someone who would offend them that much. Why not? Because we care about China. Because China matters. It's big. I mean, there is a major power out there that doesn't agree with us on things. It's called China, right? We don't-- Hillary Clinton said, you don't preach human rights to your banker. That's what Hillary said. Right? Hillary just compared Putin to the Fuhrer, right? Why? Because she can, because Russia doesn't matter as much to us. That's the way we perceive it, right? And perception is a part of reality.

### Moderator
Claim: Okay. Let me step in here because that's a really interesting point I want to bring back to Robert Blackwill or Peter Hitchens if you want to jump in on it as well, that in fact we are-- Russia is a marginal power with the evidence being the way that we all treat it. And there's a logic to that. It's--

### Scientific Advocate (SA)
Claim: Well, there may be a logic. It's mistaken if there is such a logic. Empirically, as I said, the American president, the British prime minister, the German chancellor, the Italian prime minister spent hours on the phone we all know with Putin, trying to persuade him to change Russian policy toward Ukraine and the Crimea. You don't do that. These busy, busy leaders don't do that with a marginal power.

They do it with a country they know is going to be crucial in the future of an important country that has 40 million people, is geopolitically in a crucial place on the hinge between western, eastern Europe and out to Eurasia and so forth. So it-- they're not being treated by the international system as if they're marginal. And they're finally-- perhaps partly because we're in New York, we return to the Security Council. We cannot get our way in the Security Council without Russia--

### Moderator
Claim: Okay, Robert--

### Scientific Advocate (SA)
Claim: And without Russia, we act often outside international law.

### Moderator
Claim: Robert, what you've done, you've just come up with a term that I think helps steer this debate because you-- the two of you-- neither of you want to argue that Russia is a great power, but you just used the word "crucial," which fights the word "marginal" very, very well. So I want to take that back to Edward Lucas. In the definition that was just given by your opponent about Russia being a crucial power, geographically and in time and place. Edward Lucas.

### Conspiracy Advocate (CA)
Claim: Well, Russia's clearly a crucial part if you are living in Crimea right now, and if you're worried about the security of Ukraine. But Russia's not a crucial part on all the stuff that we would be doing if Russia wasn't being such a nuisance. And I think this exemplifies what Putin does. He craves attention. He longs to be able to say, to the Russian people, I'm standing toe to toe with the United States. All these foreign leaders are calling me. I'm really important. And it's almost a behavior of a sort of disturbed adolescent. He's just sort of, you know, locking himself in the bedroom because he loves hearing the grownups pounding on the door and saying, "Don't play with those matches, "and "what have you done with the kitchen knife?" It's deranged delusional behavior from somebody who doesn't understand that the world has changed.

### Moderator
Claim: Peter Hitchens, is that--

### Conspiracy Advocate (CA)
Claim: He's-- perhaps-- just a moment. These are tactical triumphs. They're strategic blunders. He's marginalizing Russia and leaving out of the mainstream on the margins of everything that actually matters in the world.

### Moderator
Claim: Peter Hitchens.

### Scientific Advocate (SA)
Claim: I just would like to comment on this Hillary Clinton referring to Vladimir Putin as a Fuhrer. There's this curious template in discussing foreign policy of the second World War. And usually, what it means is the person who's making the argument says, "He is Hitler. You're Neville Chamberlain, and I am Winston Churchill. Hear me roar." This is dribble. There are many, many other characters in foreign policy. And one of them is Woodrow Wilson who nobody ever mentions, who created, pretty much, the second World War by drawing foolish, unsustainable borders all over Europe, which have now been entirely abolished by the European Union, by the way, under the agreement, which were, of course, the principal cause of the second World War. And what we did to Russia was a mistake. This idea that Russia is a marginal power, which is why it is a stupid idea and why you should reject it, was put forward in the chancelleries of the West when Russia was lying flat on its back at the collapse of the Soviet Union in 1991, when NATO was pushed right up to the borders of Russia, something which all Russians believe they were promised would never happen.

And this-- this foolish treatment of Russia, this belief that it's a marginal power is a mistake, and it will rebound on us. It has rebounded on us in the Ukraine. It is rebounding on us in Crimea. It will rebound on us in many, many other ways. If we started treating it more sensibly as the sort of power that it is, we wouldn't have these problems.

### Moderator
Claim: And Peter--

### Scientific Advocate (SA)
Claim: --this is Fuhrerization.

### Moderator
Claim: And Peter, your-- in a response also to your opponent Edward Lucas' description at what's motivating Putin. If you don't remember--

### Scientific Advocate (SA)
Claim: Oh, I think it’s childish. You can look around the world. This is amazing the bad press that Putin gets. It's entirely deserved, but it's-- all defenders of Israel will know this too. The selective criticism, and there's genuine criticism. If people are criticized for things which other people are doing by people who then don't criticize the other people, that's not the reason for the criticism. There is a man called Recep Tayyip Erdogan, who is in charge of Turkey, who locks up journalists in large numbers, who stages show trials of his political opponents, whose country and government is fantastically, spectacularly corrupt.

He is our ally and friend, praised weekly in the Economist magazine in which I believe Edward-- Edward is a prominent figure. And never a word, never a word. One of his big-- he kills his own people. One of his victims of the attacks in the square demonstrations died yesterday as a result of having a tear gas canister fired on the side of his head. But there were many more than that. This is a disgraceful person. But-- from the economists and the globalizers with him because he is in favor of globalization. He is in favor of away borders so--

### Moderator
Claim: All right, Ian Bremmer. Ian Bremmer. I'm on a magical mystery tangent here, and I think it's relevant, I just need you to be a little bit terse on the divergence. Ian Bremmer, Ian Bremmer, now, your partner has said that the Ukrainians at this moment would find the Russians crucial. The Syrians at times have found the Russians crucial. The Iranians at times have found the Russians crucial.

And my question is how many crucial situations does it take before a nation overall becomes crucial?

### Conspiracy Advocate (CA)
Claim: No, that's right. That's a very good point. And, again, I'd focus on the fact that unfortunately for Russia there's been a lot fewer, and they matter more in the global stage. Look. I mean, there's no question that the Central African Republic finds Mali crucial right now. That doesn't make me say that Mali is a great power, a major power, or something we spend a lot of time on. I think the point that Edward made, that Putin absolutely desperately demands attention, and he had to, he won-- you know, he had a diplomatic victory, a tactical one on Syria. We really-- we got over our skis. We set a red line. We didn't want to do anything, right, because the enemies were as bad as Assad from our perspective, right? And so we then tried to back off. We were going to have a vote in Congress, and then we weren't really going to have a vote, and then Putin says, "Ah, let's have a deal." And he couldn't leave it there. He had to write an op-ed in the New York Times. You know, it was the most read op-ed in the New York Times all year. Putin, I do think-- I think as an individual, looking around the whole world, there is no single one person who is more powerful today than Putin.

I really believe that. He's got an enormous amount of money. He has no checks and balances on his decision making domestically at all. That is at the expense of Russian power. His institutions, which had been more consolidated, have weakened. His governors are now directly appointed. His judiciary is a shell of what it was-- hope-- what--

### Moderator
Claim: Are you not describing in many characteristics the Soviet Union?

### Conspiracy Advocate (CA)
Claim: No, no.

### Moderator
Claim: It wasn't-- I mean, it had a nasty leader who was abusive to his people, who didn't run things democratically.

### Conspiracy Advocate (CA)
Claim: Yeah, it wasn't personal power. I mean, again, the Soviet Union in many ways, much similar to what you think about China, it may be authoritarian, the fact is that you have a relative consensus, you can't just move willy-nilly with policy. You could say the Stalin period briefly had some of that, but Putin is governing over a much smaller place with much-- not just the United States facing him, again, China-- China's so much bigger and a direct security threat--

### Moderator
Claim: All right, I'm only interrupting because you've had the floor for a bit. I want to bring-- give Robert Blackwill a chance, and after that I'd like to start going to questions. So remember, again, raise your hand, let the microphone come to you, state your name, and ask a very terse question that keeps us on this motion about whether Russia is a marginal power or if it's more crucial as the word has no emerged in this debate. Robert Blackwill.

### Scientific Advocate (SA)
Claim: Well, I just reinforce what Ian has just said is that Russia under Putin is powerful. It's powerful with respect to the future of Syria, with the future of Iran, and I close by saying, again, this is not a debate about the European Union. It's not a debate about China. It's a debate about whether Russia is marginal, and I hope when you vote you'll be voting on that. We could also vote on the early movies of Steven Spielberg-- but I'd like to stick to the subject at hand if we possibly could.

### Moderator
Claim: Let's go to some questions. Sir. Right there. Let the mic come to you, and stand up, and tell us your name, and then go for it. Thanks.

### Moderator
Claim: Thank you very much. My name is Dr. Joshua Warrick And my question relates to the significance of American power, especially American military power, announcements that will degrade or decrease our manpower, on the marginality or the significance of Russia. That is, as America is uplifted or degraded, what significancedoes that have on our--

### Moderator
Claim: Do you mean is it a zero-- are you asking whether it's a zero sum kind of thing?

### Moderator
Claim: No, no, not at all, but what effect will it have?

### Moderator
Claim: Okay, let's go to Peter Hitchens.

### Scientific Advocate (SA)
Claim: I don't know. I just-- I think the problem that has been since the end of the Cold War that nobody really knows what the American military is for anymore.

And they don't know what to design them for, what sort of wars it's supposed to fight, how to equip it, what should be spent on it. We have a similar much smaller program in my own country where we have a gigantic nuclear arsenal which defends us against enemies we don't have who probably couldn't find us on a map anymore because we're now so insignificant it wouldn't be worth their while bothering. So I think that one of the problems that persists in all foreign policy is trying to work out what sort of world it is, and I think this-- the continued belief that we have of-- we have a major enemy in Russia is one of the things which a lot of people in what I think has been called the military industrial complex here rather like to cling to, and it doesn't-- it doesn't actually tally with what's really going on, the real struggles of power which are coming. They're coming as far as I can see in the Pacific, where the United States is not particularly strong or particularly well prepared either diplomatically or military for what's coming. And it prefers to divert itself in panics about Iran, panics about North Korea, and panics about Russia.

I think it's a mistake on your part that, of course, in 1776 you told us to keep our noses out of your business and I probably shouldn't say any more about it.

### Moderator
Claim: Sir, does that address the dynamic that you were trying to get at?

### Moderator
Claim: it does, but more specifically--

### Moderator
Claim: We need the mic to come back to you.

### Moderator
Claim: More specifically, for example, the president announced recently we would diminish our troop strength by 100,000 people. He's also said that there's a red line in Syria that something would happen if it was crossed. Nothing happened. So I don't think that these things really help American power, and I-- in fact, I think they enhance Russian significance rather than marginality. In other words, Russia can do things now.

### Moderator
Claim: Unless you want to address it, I want to move on to another-- okay, another question? Right down front here.

### Moderator
Claim: Hi, my name's Tiffany Cobb I heard it said to Putin, "Invading countries is like Pringles, he can't just have one." Can we talk about what we could expect in the future after Ukraine and Crimea, if anything?

### Moderator
Claim: I don't want to do predictions because it really doesn't help us with our voting on the motion of the status-- of the things as they stand out, but thank you for the question. Sir, right down front.

### Moderator
Claim: Hi, John--

### Moderator
Claim: I need-- everybody, please wait till the mike comes to you because the radio world will not hear you otherwise.

### Moderator
Claim: Hi, John D'agostino to the gentlemen against the motion, it seems like a lot of time was spent defining "What is power?" as with the "ability to disrupt," so be it through nuclear proliferation or nuclear weaponry or-- you didn't mention this but the stranglehold on European natural gas pipelines, if we define a power as the "ability to disrupt," if we expand for that definition, then aren't we opening the door for any rogue state, be it-- I won't get to names, but any rogue state, however small, large, economically important or not, to make themselves a power-- a not marginal power just by being disruptive?

### Moderator
Claim: Great question. Robert Blackwill.

### Scientific Advocate (SA)
Claim: I like the definition. It also, if you'd had more time, would have included the positive things a nation can do in the international system, but I think you put your finger on exactly the kernel here, which is the impact Russian external policies and behavior have on the international system and on the United States. And I agree with you and with I think all of us up here that, that's largely negative now, not entirely negative, but largely negative, sadly.

### Moderator
Claim: So in other words, you're saying that in terms of the plus column that things can do to establish themselves as real powers, the Russians aren't doing that well, which is very much what your opponent's argument is.

### Scientific Advocate (SA)
Claim: No, it isn't what-- no, I don't think it is what my opponents argue. My opponents argue rather I believe that it has very little impact on the international system, and that it's marginal.

And I'm saying quite the opposite, which is countries have choices, and Russia has choices, and sadly they've made one choice regarding the Crimea, one choice regarding Syria. We'll see what they do with Iran, but they could make another choice, and it is exactly their capacity to impact the international system in the United States, which supports our opposition to this motion.

### Moderator
Claim: Edward Lucas.

### Conspiracy Advocate (CA)
Claim: Just two very quick points. First of all, I think I-- it's easy to have a negative impact in the world. You can do negative things very quick. Kill all your own people, pollute the environment, do horrible things. What we're arguing is that Russia doesn't make a positive impact, and that's the sign of a country of that matters. It's not the ability to be a nuisance, it's the ability to have a positive impact. I just want to pick up on the speaker said about European natural gas. It's absolutely true. Russia used to be an energy superpower. And because of the appalling way in which they've treated their customers, they're now seen as an expensive and unreliable supplier of gas, and people are making alternative arrangements.

We may even begin to buy from the United States one day. We can get gasses, liquefied natural gas, from all over the place. We're going to develop our own shale. We've got gas coming from Algeria, from Norway, and everywhere else. And Russia's share of the European natural gas market is falling and falling and falling. It's their fault.

### Moderator
Claim: Ian Bremmer, very briefly.

### Conspiracy Advocate (CA)
Claim: I just want to say the ability of Russia also to do negative things, it's significant compared to the positive, but it's also going down, not just because of the way they've acted on energy but because of the energy revolution. Russia is an energy superpower, right-- not anymore. Its decreasing prices in Europe means the strangle-hold has been reduced. All the European countries are now aggressively renegotiating their contracts with the Russians because they have options on the downstream. In the next five years, that’s going to grow dramatically. The single thing that Russia really is known for, economically, is energy. And it’s falling apart. Meanwhile, what, seven years ago, the Russian budget would balance at $34 a barrel. Today, it’s $117, okay? That’s huge reduction in capacity to have impact.

### Moderator
Claim: That’s Peter Hitchens.

### Scientific Advocate (SA)
Claim: Can I just take issue with this word positive. It just means what Edward likes. And it doesn’t-- it isn’t actually some kind of objective measure of what is good and what is bad. Quite a lot of us, for instance, think that the Arab Spring was not a wild success. Many of us thing that turning Libya into a filed state with no government was not a particularly clever thing to do. And the destabilization of the Syrian Regime has reduced millions of people to abject misery, which was completely unnecessary. By standing against these things-- or, indeed, by standing against the idea of carpeting the world with useless windmills or forcing advanced countries to tax their energy industries out of existence in the environmental cause-- some of us think these things are not very clever either. So, to be negative about these things is not necessarily to be bad. It’s rather a good thing that there is an alternative source of-- how shall we say?-- wisdom in the world from the one which produces those brilliant ideas.

### Moderator
Claim: Let me put to the-- to the-- to the side-arguing against the motion. Your opponents have just pointed out that if being an energy superpower is a sign of crucialness of being a player, that the trend for Russia is for that slowly to be fading away now that we’re already in that trend and they see it continuing to go. And I’d like you to respond to it, whether that’s a marker of Russia’s standing in the world.

### Scientific Advocate (SA)
Claim: Over the long-term, yes. I agree with you in that, over the long-term, the combination of the mismanagement of its energy sector by the Russians and the U.S. energy revolution that’s underway-- the shale revolution-- will reduce the Russian capacity to use energy as an instrument of its national purposes, especially against Western Europe. But that’s 10 years down the way. That’s 10 years-- that’s how long it takes to develop it. I’d just say one other thing, which is this peculiar definition that-- and I take notes-- “countries that matter are ones that pursue positive policies.” What? That’s Mary Poppins.

That’s the strategic rationale of Mary Poppins.

### Scientific Advocate (SA)
Claim: I think that’s rather unfair to Mary Poppins, actually.

### Moderator
Claim: Another question? Is there anyone upstairs that I can’t see, unfortunately. Right over in the corner, there. You have a blue shirt.

### Moderator
Claim: My name is John Coleman With the exception of the discussion on the nuclear weapons, I’d like your opinion about what a power really is, whether it’s a local power-- because we’ve talked about things-- well, while Russia is a very large country, we’ve talked about things on their border-- versus being a global power and dealing with the rest of the world.

### Moderator
Claim: You don’t-- you don’t feel that this side has addressed its part in negotiations and-- I mean, it hasn’t only talked about weapons. And we just now talked about the oil and gas industry. And we--

### Moderator
Claim: And, again, you know, we’re talking about things that are on their borders. You know, we’ve talked about Syria. We’ve talked about the Middle East. You know, let’s look at Africa--

### Moderator
Claim: Okay. All right.

### Moderator
Claim: South America.

### Moderator
Claim: I take it, especially compared to the past. Robert Blackwill, I think that’s a question for your side.

### Scientific Advocate (SA)
Claim: Well, I agree that Russian policy, contrasted with the Soviet period, really has very little interest in either Latin America or Africa. So, I wouldn’t make the argument that the expression of its power, as you were defining it, is directed at those places. Rather, as you said, it is directed into northeast Asia, into the Middle East, into its own neighborhood, into Western Europe. All of those places matter a great deal to the United States.

### Moderator
Claim: Ed Lucas.

### Conspiracy Advocate (CA)
Claim: I just want to defend Mary Poppins for a moment. One of the wisest things she said is “a spoonful of sugar makes the medicine go down.” And that’s very, very useful in diplomacy. If you want to get things done in the world, it helps to be nice to other countries and get them to do the things that you want and make them feel good about it. And Russia is amazingly bad at doing it. Russia keeps on setting out very grandiose international organizations-- organization of gas-exporting countries. It’s meant to be kind of gas OPEC-- didn’t work. Shanghai Corporation Organization-- didn’t work. Eurasian Economic Union-- not working very well. All the countries that Russia tries to bring on its side, the closer they get to Russia, the less they like what they see and the further away they move from Russia, with the result that Russia’s big diplomatic initiatives just don’t get anywhere. Anyone remember the common European architecture? Common European security architecture? That was a great idea of Let’s all get around the table and try and sort out European security problems. Then people took a closer look and realized that Russia doesn’t believe that half the countries in Europe are proper countries.

They agree with Peter Hitchens. These are pretend countries that Russia has some kind of They can go in there and do whatever they want. And that’s-- nobody’s given them the right to do it-- with the result that all Russia’s neighbors are rather scared of Russia. Whatever Russia wants to do, they don’t like it, because they know what Russia is like. Instead, they’re flocking to try and join NATO. And some of them are even being allowed in.

### Moderator
Claim: I want to remind you that we are on the question and answer section of this Intelligence Squared U.S. debate. I’m John Donvan, your moderator. We have four debaters-- two teams of two-- debating this motion: Russia is a marginal power. Peter Hitchens, would you like to respond to the point just made?

### Scientific Advocate (SA)
Claim: Well, yes. This news about Russia overhauling and overpowering other countries. Again, this is-- it’s really crucial to understand that, in 1918, after Ludendorff had financed Lenin and the Bolsheviks to mount a coup d’etat against the then-Russian imperial government, which collapsed and surrendered in war. Germany imposed on Russia frontiers which were regarded by Russia as utterly humiliating. So humiliating that even Trotsky, one of the Bolsheviks, walked out of the talks rather than accept them and was forced to go back in. This was the Carthaginian peace.

It’s interesting that exactly the same borders imposed on Russia in 1918 by the German kaiser have now been imposed on Russia again by NATO and the European Union. They didn’t last then. They won’t last now. There are existential facts about countries. If, as they say-- if somebody took back from the United States the countries which it captured in the War of 1848, which is a good deal more recent than the absorption of Ukraine into Russia, there would not be very long before there was a move to take them back, and a strong feeling that they did not belong in whatever organization they found themselves in.

This is very, very important when you don’t have the Pacific Ocean, when you don’t have the Atlantic Ocean, when you don’t have Canada, and when you don’t have Mexico. Just remember that Russia is a country. It’s not an idea. And it exists in a hard, cruel world that’s been repeatedly invaded by Tatars, Swedes, Lithuanians, Germans, the Japanese, the Chinese, anybody who happens to be--

### Moderator
Claim: Peter, let me stop you. Let me--

### Scientific Advocate (SA)
Claim: Can we please acting--

### Moderator
Claim: Peter--

### Scientific Advocate (SA)
Claim: --as if-- as if--

### Moderator
Claim: Peter.

### Scientific Advocate (SA)
Claim: --as if security--

### Moderator
Claim: This is the moderator speaking.

### Scientific Advocate (SA)
Claim: --is as readily available to Russia as it is to the United States.

### Moderator
Claim: Peter. Land that thought to our motion. Why does that, therefore, fight the argument that Russia is a marginal power?

### Scientific Advocate (SA)
Claim: Because the whole-- the whole thrust of these people is that Russia should be treated as a marginal power, be pushed to one side, have its national concerns for reasonable security overridden in the belief that it no longer counts and no longer matters. That was in the head of George Bush Senior. And it was in the head of his Secretary of State, Jim Baker. And that’s what they designed. And that’s what we now have. And it won’t last. And the longer we believe it, the more it will hurt us.

### Moderator
Claim: All right. Ian Bremmer.

### Conspiracy Advocate (CA)
Claim: I’ll just say very quickly, which is that I actually think it’s a mistake for the United States to address as if it’s a marginal power because you’re actually just sticking Putin’s face in it. I mean, the best thing the United States could do is allow Russia to continue to decline and not really pay much attention-- call it less aware of that decline.

The fact that the Americans have pushed the Russians as hard as they have on Ukraine, which was critical to them, had been theirs, and which the West is going to win most of, right? The outcome is going to be worse-- after all of this, the outcome is going to be worse for Russia. But that’s not good enough for us. We, instead, have to also stick their noses in it. And, as a consequence, the Russians are going to get more antsy and uppity. And I don’t blame them. And we’re going to have a few more weeks of headlines around this. But that doesn’t mean that they’re not a marginal power. That just means that we can’t help ourselves, because we’re always right about this stuff, right? I’m sympathetic to what Peter is saying. I just don’t think it sways the way you should vote on this thing.

### Moderator
Claim: And I’m right behind you, sir. I’m sorry. The lady, please. And if you could stand up, so we can find you with the camera.

### Moderator
Claim: Sure.

### Moderator
Claim: Thanks.

### Moderator
Claim: I’m Vickie Schnletzer at Market News International. Last week, we saw the ruble fall to lifetime lows against--

### Moderator
Claim: Can I ask you to do one thing? Because this is a radio broadcast-- lives on for months and months and months. It would help the editor of the radio broadcast if you didn’t say “last week.”

### Moderator
Claim: Okay.

### Moderator
Claim: Because somebody will be listening in May, and will call his broker.

### Moderator
Claim: Okay. Recently, we saw the ruble fall against the euro and against the dollar to lifetime ruble lows. The financial market had a very negative reaction to this. Today, we saw Safe Haven treasury demand after the G7's rather strong--

### Moderator
Claim: When you say, "today," do you mean these days that we're in now?

Why don't you just-- just zoom into your question.

### Moderator
Claim: Sure.

### Moderator
Claim: Okay.

### Moderator
Claim: So we saw safe haven demand after the G7 statement. Does the financial market reaction suggest that Russia is not a marginal power?

### Moderator
Claim: That's a really, really great question. I'd like to put that to this side, to the side that's arguing Russia is a marginal power.

### Conspiracy Advocate (CA)
Claim: I think that the starting point has got to be, where does Russia matter in the global economy? And sadly, as Ian's pointed out, it doesn't. It's not a huge-- it does not-- it doesn't have huge attraction to outside investors. People don't like uncertainty. Russia is able to cause uncertainty. There's no doubt about it. But it's my contention that it's not enough to be a spoiler. It's not enough to be able to spook the markets. You've got to be able to send-- what would be nice would be to see Russia doing something to send the markets up rather than down. I actually have a suspicion-- this is just a kind of mischievous suggestion that possibly Putin is financing his adventure in Ukraine by shorting the ruble, then doing something stupid, then doing something sensible, letting it go up again.

But that's just hypothesis, that's sort of the way that Russian decision makers do sometimes approach the financial markets.

### Moderator
Claim: All right. Let's go to Robert Blackwill on that question.

### Scientific Advocate (SA)
Claim: I think that's a terrific question. The Russian economy mismanaged, though it is, is the sixth largest economy in the world. If our opponents believe that's marginal, it must mean that they think that only the top five economies-- or maybe they think only the American economy matters.

I want to say one other thing, as we-- as we proceed toward the finish line. I think that Americans in particular have a penchant to satirize and demonstrate contempt for foreign leaders. And we've seen that. We've taken them into the bathroom during our discussion here. It matters because these are homo sapiens too.

And how we talk about them and the degree of arrogance we often-- we Americans demonstrate about them is quite separate than what we think of their policies. And so my own judgment is, for what it's worth, is that we should be talking about Russian policies and not be ad homonym critics of Vladimir Putin's personal bathroom habits.

### Moderator
Claim: But in the case of Russia, are those two things-- is not Putin central to what the policy is?

### Scientific Advocate (SA)
Claim: Sure, he is. He's central. And we should do everything we can to affect the decisions that he makes, but we shouldn't make him a cartoon figure. He is not a cartoon figure. He has very great impact on the lives of millions and millions of people outside Russia.

### Moderator
Claim: And, Bob, in the context of this debate, why are you making that point now?

### Scientific Advocate (SA)
Claim: Well, I'm making the point because it's not that power that Putin's Russia demonstrates is felt around the world and is the best possible example that if millions of people are affected by a nation's policies, external policies, it cannot possibly be a marginal nation.

### Moderator
Claim: Ian Bremmer, do you want to respond?

### Conspiracy Advocate (CA)
Claim: Well, just the fact that Putin has made a satire of himself in his own country. This is not the Americans that started this. We don't may attention to international leaders. And we have the last couple weeks on this. But the reality is you want to see the cartoons that are being written about Putin, you want to see the local opposition, I mean, that is satire, and it's stinging, and it's painful, and it's unfortunate.

But, I mean, the fact is that the amount of the rapacious corruption that has been shown by Putin personally, spending a couple billion dollars on his dacha in you know, the-- we don't even talk about all the ways that he likes to show the amphora that he found that were placed a foot and a half under water that were thousands and thousands of years old that ended up coming, you know, from a museum. The Russians ended up finding out about that, even in the heavily state- controlled media in Russia, and they were embarrassed, and they laughed about it. This isn't the Americans doing this.

### Scientific Advocate (SA)
Claim: No, and I agree with that. But I think-- the point I was trying to make is that it's one thing for a nation's population to laugh at itself. It's another thing for American arrogance to laugh at others, to caricature others, to make others cartoons. We all will accept much more self-criticisms within our own country than pontificating from abroad.

### Moderator
Claim: Right down front here, please. If you can stand up, a mic is coming from the lefthand side. And we're a little short for time, so I need you to get right to it.

### Moderator
Claim: Do I have to stand up?

### Moderator
Claim: If I can.

### Moderator
Claim: --in front of everybody?

### Moderator
Claim: Stay there. In front of everybody, well--

### Moderator
Claim: Anyway, I just--

### Moderator
Claim: Nobody look.

### Moderator
Claim: I just quickly-- I just wanted to quickly address a couple things. You know, cartoons are done all the time about presidents, and I don't think that that's important. He still has-- Putin still has power. And addressing what the gentleman in the back said about the military, I really feel that--

### Moderator
Claim: But, wait, do you have a question?

### Moderator
Claim: Yes. The question is, I believe that-- I'd like-- no, I--

### Moderator
Claim: No question ever begins with "I believe."

### Moderator
Claim: Okay.

### Moderator
Claim: I believe that? Maybe. Go ahead.

### Moderator
Claim: I-- do you really believe that if we cut our military, which I think is wrong, that it's going to make a difference in-- it's going to make Russia stronger if we cut our military, honestly. And having nuclear power, having nuclear-- the question is, do you really feel that if we cut our military right now, which is on the table with--

### Moderator
Claim: I'm going to pass because neither side has raised that point and I want to--

### Moderator
Claim: Well, it's going to make Russia stronger.

### Moderator
Claim: Okay. But thank you.

### Moderator
Claim: It is going to make Russia stronger.

### Moderator
Claim: Can I just--

### Moderator
Claim: No.

### Moderator
Claim: Thank you, Dan Speara. For the group arguing in favor of the motion, could you describe which countries other than the United States and China you would consider a nonmarginal power and why in comparison to Russia.

### Moderator
Claim: Very quick list. Ed Lucas.

### Conspiracy Advocate (CA)
Claim: I'd say most of the countries in the G20. But I would also say that even small countries can play a really important role. I'd say Estonia, which is like 1 million people, is a cyber power. It does really interesting stuff on E government and on cyber warfare. And it sends people all over the world. They have people down at the NSA. They have people in Maryland.

### Moderator
Claim: Ed, are you-- wait, are you saying that Russia is more marginal than Estonia?

### Conspiracy Advocate (CA)
Claim: No, I'm just-- No, I was just-- I was just asked for acountry that is clearly not a marginal power.

### Moderator
Claim: All right, so you say-- you--

### Conspiracy Advocate (CA)
Claim: These countries earn their prestige. And it's not a binary thing, there's this one dimension. There's all sorts of dimensions in which countries matter. And I think you can find plenty of examples of small countries and also supranational institutions. I'd say the EU mattered.

### Moderator
Claim: Does this side want to respond? If not, that concludes round two.

## Round 3

### Moderator
Claim: With a shake of the head, that concludes round two of this Intelligence Squared U.S. debate where our motion is "Russia is a marginal power." And remember how you voted before the debate. Immediately after closing statements, we're going to have you vote a second time. And that is how we will choose our winner. The team whose numbers have moved the most will be declared our winner.

But first, round three, closing statements. Two minutes each. The motion is "Russia is a marginal power." And here to summarize his position in support of this motion, Edward Lucas, senior editor at the Economist.

### Conspiracy Advocate (CA)
Claim: We've talked a lot so far this evening about hard power, about diplomacy, about military and about economics.

We haven't really talked about soft power. And that's the way in which a country projects an idea, a way of doing things that other people want to copy. There's a very interesting test here. Go stand outside the American consulate in Moscow and count the number of people wanting to immigrate to the United States. It's a long, long line. Now go down to the Russian consulate in New York and try and find the people wanting to immigrate to Russia because it's so great there. That's a very good index of soft power. Look at the media. Look at Russia today. Russia today is a wonderful window into the mindset of the people who run Russia. They put tens, hundreds of –millions of dollars into-- into Russia today as a way of trying to undermine the West and promote the Russian-- the Russian view of the world.

And look at the people who appear on Russia Today. It's a bunch of cranks and cooks and nut jobs, people who are 9/11 truthers, one of their top presenters in 9/11 truther, people who don't believe that they have-- they interview people who don't believe the moon landings happened, people don't think the holocaust happened, a whole range of eccentric and sometimes very interesting, sometimes unintentionally quite entertaining views. But what they have in common, they're all marginal.

### Moderator
Claim: Thank you, Edward Lucas. And that is our motion: Russia is a marginal power. And here to summarize his position against the motion, Peter Hitchens, columnist and reporter for the London's Mail on Sunday.

### Scientific Advocate (SA)
Claim: Why do the other side so want you to believe the laughable proposition which they're struggling so hard to defend? It's quite simple because of the way Russia understands something that we have wholly forgotten. In 1648, the nations of Europe looked at their-- looked at their continent. And they saw that it looked pretty much like a Hieronymus Bosch painting-- nothing but desolation, ruins, and corpses stretching for hundreds of miles in every direction.

The population had actually fallen. The reason? Because they decided that it would be a really, really clever idea to intervene in other people’s countries, because they didn’t like the way they were governed. And they resolved that they would not do that anymore. And until a few years ago, when the disgraceful person who became prime minister of my country, Tony Blair, became prominent, this was a generally accepted view in all countries that we wouldn’t do this anymore. We wouldn’t shove our noses into other people’s countries just because we didn’t like the way they were run, because that led to misery, murder, and death. And Russia stands actually, for principles of 1648, it still continues to insist that countries should be left to mind their own business.

Stay out of ours; we’ll stay out of yours. That-- no wait a minute. I didn’t heckle you. Don’t you heckle me. This is a straightforward, simple question. The reason they want to marginalize Russia is because they have forgotten one of the most important lessons ever learned by civilization. They want you to forget it, too. We’ve seen in Syria the results of this folly. We’ve seen them in Libya.

And we see them in Iraq. It really is time it stop. The attack on Russia is actually attack on something else entirely. That’s why you should oppose this very foolish, very wrong- headed, and frankly rather hopeless motion.

### Moderator
Claim: Thank you, Peter Hitchens. And to restate this motion, it is “Russia is a marginal power.” And here to summarize his position in support of the motion, Ian Bremmer, founder and president of Eurasia Group.

### Conspiracy Advocate (CA)
Claim: If the motion were, “Is Russia--” or “Russia is a marginal power in the 17th century,”-- I would vote with Peter’s side because no one else has addressed that issue but him. That is not what we are talking about tonight. We’re talking about whether or not Russia is today. Now, look. No one really has defined power well, either. So, let me try to do it. Power is the ability to get other actors to do things they otherwise would not. And there’s two ways to do it. You can do it coercively, or you do it-- you can do it cooperatively. There are also many, many ways that you can get it done-- many axes, right? You can get it done militarily, economically, right?

Socially, demographically, culturally. If we were only talking about military, and particularly nuclear weapons, Russia would probably have major power status and superpower status. But on every other indicator, they wouldn’t. And if I add them all up, what other countries deserve that when you put all the indicators together? Japan, Germany, the United States, China. I mean, frankly-- I know Peter is going to hate this-- even the U.K. does better than the Russians do. That’s appalling how much the Russians have fallen-- over the last 20 years. And even on the military side, the United States still spends more than the next 10 countries, pretty much, combined, which is probably too much. And it probably needs to be cut back a bit. And sure, at the margins will be some things that the United States can’t do that other countries, as a consequence, can make some hay, yes.

But who’s going to make that hay? Overwhelmingly, it’s going to be the Chinese-- primarily in Asia and other places. And yet, still, we’re the only one with a blue-water global navy. And so, if you want to get energy out of the Middle East, even though we won’t need it anymore, everyone else will have to turn to the United States. So no, I’m not really concerned about that. If the only thing you want to vote on is, “Can they blow us up from a nuclear perspective?”, please vote with them. If anything else matters to you, please vote with us. Thank you very much.

### Moderator
Claim: Thank you, Ian Bremmer. The motion, “Russia is a marginal power.” And here to summarize his position against the motion, Robert Blackwill, former Deputy National Security Adviser for Strategic Planning under President George W. Bush.

### Scientific Advocate (SA)
Claim: I agree with Ian that it would be wrong to define Russia and its influence on the world solely through military means or nuclear weapons. I couldn’t agree more. So, let’s talk about diplomacy. And, in two regards. First, Iran. I think we all know what a danger Iran and its nuclear weapons program poses for Israel, for the United States, indeed, for the international system.

The five members of the Security Council are negotiating with Iran, including Russia, to seek to have a peaceful solution to that. That is only possible with Russian agreement. And if we don’t have a peaceful solution, the American president will be confronted with a terrible binary choice: either attack Iran with devastating consequences, or allow Iran to acquire a nuclear weapon with devastating consequences. And it is Russia that will decide whether we can have a peaceful solution to the Iranian nuclear program. And then, Syria. We’ve had some fun tonight, and we should in this kind of debate. But I want to end with deep seriousness.

Russia is preventing sanctions against Syria, which would have some hope of reducing the Syrian regime’s brutal attack on its own people. In that context, the Save The Children Fund this week argues that at least 1.2 million Syrian children have fled to neighboring countries. 4.3 million Syrian children need humanitarian assistance. And more than 10,000 Syrian children have died in that civil war in a-- in a situation in which Russia supports the Assad regime.

### Moderator
Claim: Robert Blackwill, I’m sorry. Your time is up.

### Scientific Advocate (SA)
Claim: those children believe Russia is a marginal country?

### Moderator
Claim: Thank you, Robert Blackwill. And that concludes our closing statements. And now, it’s time to learn which side you feel has argued the best.

We’re going to ask you again to go to the keypads at your seat and vote a second time on this motion, “Russia is a marginal power.” If you agree with this argue-- with this motion after hearing the arguments, push number one. If you disagree, push number two. And if you became, or remain, undecided, push number three. And we’ll lock it out in a couple of seconds. And we’ll have the results in about a minute and a half.

Okay, while we’re doing that, I just want to take a couple of-- I want to make a couple of very short announcements. First of all-- first of all, I want to point out that a number of the debaters on the stage, including Ian Bremmer, were about 30 to 48 hours ago on the other side of the world. And they got off planes and flew over here. And they must have been exhausted, but they brought great strength and energy-- and also, I think, decency and equality of respect to these debates that we aspire to.

You did a great job, all of you. And I want to thank you for all of that. I’ll remind you that we would love to have you tweet about this debate. The Twitter handle is @iq2us, and the hashtag is #RussiaDebate. Our next debate is at Columbia University’s Miller Theater in partnership with the Richmond Center. The motion is, “More clicks, fewer bricks: The lecture hall is obsolete.” That’s the question that we’re asking. And it’s basically do massive open online course and inexpensive online degree programs spell the end of the traditional campus-based college experience?

So, and then, following that, April 9th, we’re going to be back here at the Kaufman Center. And the debate will be on millennials. The media has painted them as kind of coddled and narcissistic. And the question that we’re exploring is, are their critics right?

Tickets for all of-- we haven’t exactly framed the question, but we will have it figure out. Tickets for all of our remaining spring debates are on sale through our website: www.iq2us.org. And for those who can’t join the live audience, as always, you can catch the debates on far.tv on our website. And you can listen to these debates, as I said before, and NPR stations across the nation. So, you can just go to our website for up-to- date information, and stay in touch in Twitter and Facebook. And we welcome your feedback. And we are always very, very open to ideas for our debates to take on in the future. All right. So, it’s all in now. I’ve been given the results. Remember, the team that has moved your numbers the most after a preliminary vote, and then a vote after hearing the debates, will be declared our winner. Here is how it went. The motion, “Russia is a marginal power.” Before the debate, 25 percent of you agreed with motion; 43 percent were against; 32 percent were undecided. So, those are the first results. Remember, you voted a second time. The winner is the team whose numbers have changed the most in percentage-point terms.

Here is the second vote on “Russia is a marginal power.” The team arguing for the motion-- their second vote is 35 percent-- from 25 to 35 percent. That’s a 10 percent gain; 10 percent is the number to beat. The team, now, arguing against the motion, their first vote was 43 percent. Their second vote was 58 percent. They pulled over 15 percentage points. The team arguing against the motion that Russia is a marginal power has won. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We’ll see you next time.
