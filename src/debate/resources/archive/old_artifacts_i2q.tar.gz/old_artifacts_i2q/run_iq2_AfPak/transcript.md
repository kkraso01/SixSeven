# Debate Transcript

Topic: America Cannot And Will Not Succeed In Afghanistan/Pakistan
Motion: America Cannot And Will Not Succeed In Afghanistan/Pakistan

Debate ID: AfPak


## Round 1

### Moderator
Claim: Ladies and gentlemen, we are about one minute away from beginning. For people who have just arrived, I want to say once again your voting pad is on the left arm of your chair, and I would like to remind everyone to turn off their cell phones now so that it doesn’t interfere with the broadcast on Bloomberg and on NPR, and at this point I’d like to welcome our debaters to the stage. At this point I would like to introduce the CEO of Intelligence Squared US, Mr. Robert Rosenkranz.

### Moderator
Claim: Well, thank you all very much for being here, this is certainly a very Will Not Succeed in Afghanistan and Pakistan” (10/6/09) timely event as the nation considers what to do about sending additional troops to Afghanistan and defining our strategy there. When we framed this debate and it’s my job tonight to explain why we chose it as a topic, we felt that the semantics of the debate might be of particular interest, we’re calling this, “America Cannot and Will Not Succeed in Afghanistan-Pakistan.” Our definition would’ve been, of success, would have been, first of all, to prevent Pakistani nuclear weapons from falling into the hands of extremists like the Taliban. And second to impede as much as possible, the ability of al-Qaeda to operate and project its terrorist objectives outside of the region. We really didn’t intend this debate to be about nation-building Afghanistan, but, the policy debate raging in Washington these days as we speak, does seem to conflate the Taliban and al-Qaeda. And it pretty much defines success as creating a reasonably stable, reasonably democratic and reasonably strong government in Afghanistan. So, given that, I think we’re going to learn a great deal this evening about, first of all about Afghanistan’s primitive economy, dominated by heroin production, about the ungoverned tribal areas that stretch from Pakistan to Afghanistan. About the divided loyalties of the Pakistani militaries and intelligence services. About the role of the Saudis in promoting Wahhabism, and about alternative counterinsurgency strategies. In short, this is a dauntingly complex mosaic. And at the end of the evening, where you vote may well turn on which side’s Will Not Succeed in Afghanistan and Pakistan” (10/6/09) definition of success you choose to embrace. And with that I’d like to turn the evening over to John Donvan and the extraordinarily able group of panelists that we’ve assembled this evening. Thank you.

### Moderator
Claim: Thank you, what I always like to do at this point is ask everyone for one more round of applause for Robert Rosenkranz who makes this all possible. Hello, everyone, and welcome to another debate from Intelligence Squared US, I’m John Donvan and once again, it is my honor to be acting as moderator as the six debaters you see here on the stage with me at the Skirball Center for the Performing Arts at New York University, will be debating this motion, “America Cannot and Will Not Succeed in Afghanistan and Pakistan.” And what debate topic could be more timely at this point for a contest like this, and that’s what this is, this is a contest, a competition of ideas, there will be winners and losers and while I am the referee, you, our live audience here at the Skirball Center are our judges. By the time this debate has finished, you will have been asked to vote twice, once before, and once again at the end, registering whether you agree or disagree with the motion. At the end of the debate, the team that has changed the most minds will be declared our winner. So let’s take 30 seconds and reach for those keypads by your seats, and it is time to vote, at this Will Not Succeed in Afghanistan and Pakistan” (10/6/09) point, on our motion, “America Cannot and Will Not Succeed in Afghanistan and Pakistan.” If you agree push number “1,” if you disagree, it’s number “2”…and if you are undecided, push number “3.” If you feel you’ve made a mistake…just push the correct button and it will automatically correct and eliminate the earlier one. All right. And so to the debate. Round 1, opening statements by each debater in turn, seven minutes each, and these are without interruption, and our first debater for the motion, Patrick Lang who is a retired US military officer, and a former Green Beret. He’ll be taking the microphone first to argue for our motion, “America Cannot and Will Not Succeed in Afghanistan and Pakistan,” ladies and gentlemen, Patrick Lang.

### Conspiracy Advocate (CA)
Claim: Well ladies and gentlemen, it’s a great pleasure to be here with you, this is a fascinating topic at this particular moment in American history. And I would’ve thought maybe that people were tired of it by now but I can see that that is obviously not the case. Now as the chairman said, in fact I don’t think this— you can decide that question other than in the context of what it—whether or not you’re going to succeed, other than in the context of what American policy is and what the stated foreign policy of the President of the United States is with regard to this question. That’s— I had the fortune or misfortune to go to any number of Army service schools, one of Will Not Succeed in Afghanistan and Pakistan” (10/6/09) them was the Army War College, where they taught me a lot about the strategy of planning… itself, you started with the mission, national purpose, you have a policy, and then you devise a strategy from that. then you implement that strategy. That’s how it works. Now, last March I listened carefully when President Obama announced that our policy in Afghanistan was to disrupt, destroy, and disorganize our enemies, our specific enemies who were a danger to the United States. That’s a nice… clear policy, you know, it’s not too hard to understand that. And to that end, General Stanley McChrystal was put in command out there, and sent out to make what is called a commander’s estimate of the situation. Which he did, with a lot of help from various people for several months and it is now as you know, the object of great contention in the Washington world. And the problem with his estimate, I think, that is causing so much trouble, is that it is normal in an estimate of that kind for a commander to propose several options to his superior, among which the boss can choose. To present only one option, in this case the option of a large-scale counterinsurgency campaign, across all of the really hostile parts of Afghanistan in the context of their ruined, if ever alive economy, and their obviously rather feeble political system, is a daunting task. But somehow it has become-- what we would call an implied task for General McChrystal, that the pacification of large parts of Afghanistan and the most hostile places are in fact a necessary thing. And for that Will Not Succeed in Afghanistan and Pakistan” (10/6/09) reason, he has opted for counterinsurgency. Now, I am happy to see so many members of my generation out here in the audience. There are usually too many young people for my taste. But— I started in the counterinsurgency business—in the church of the counterinsurgents, really. In 1964, if you can believe that, when the Army sent me down to Fort Bragg to study this subject with intensity and at the feet of the most learned French and British exponents of this theory of warfare which had been created as a result of the experience of the former colonial powers in World War II in fighting against the wars of national liberation as they were called then. And the Communists had gotten involved in all these wars so we were against all this as well, so we studied up on this in a big way, and one of the most interesting of the guys who taught from the stage there was a great, a great scholar named Bernard Fall. Bernard Fall. Some of you undoubtedly know who that is. And I remember watching him, I— of course I had no real idea who he was at the time but I remember him, watching him write—write on a blackboard on the stage, “Counterinsurgency equals political reform plus economic development plus counter-guerilla operations.” “Counterinsurgency equals political reform plus economic development plus counter-guerilla operations.” And that’s really all of it right there, that’s all of it in a nutshell. And it is in that context that when you look at Afghanistan, this huge place that’s Will Not Succeed in Afghanistan and Pakistan” (10/6/09) the size of Texas with 35 million people of very disparate origins, many of them speaking languages that are not mutually intelligible, and who don’t like each other, a lot of them, very much, in fact you can see, that this is a very difficult thing to do. We tried applying this theory of warfare, counterinsurgency, across the world in the 1960s and ‘70s and ‘80s and I did it myself in South America, in East Africa and Southwest Asia and all kinds of places, and of course Vietnam, how could I forget that. And we found that in places where the task wasn’t too big, you know, the country wasn’t too big, the problems weren’t manageable one way or another, or people weren’t thoroughly converted to some ideology that demanded revolution, that you could do this, by enough good works and suppression of guerillas you could turn this around, and I could name places if we had time. In places that were eerily big and where none of those conditions applied, we—you could struggle like the devil but you wouldn’t get very far, you know. And I—this is the problem I have with the idea of the application of counterinsurgency, those three things, to Afghanistan, I know that was four things. In fact, I think that is too big a task for us. We have been fighting for eight years, Afghanistan is a huge place, it has terrible problems, economic ones, political ones. And the combat problem, from the point of view of a guy who fought in several wars like this including Vietnam, is really very difficult. And I would submit to you that if what we’re going to do as General Will Not Succeed in Afghanistan and Pakistan” (10/6/09) McChrystal says, we’re going to try to protect the people, which means essentially, control the population because that’s what counterinsurgency is about, just like insurgency is about controlling the population either with positive means, or means not so positive, sometimes, you’re going to have to have a lotta troops to do this. I mean General McChrystal evidently wants 40,000 more people. Well I would say to you that that’s just the beginning. That’s how we started in Vietnam too. This is a big problem we’re facing in Afghanistan. And in fact, this slice of the pie will be followed by further slices of the pie. And my objection to all this is, and the reason why I don’t think we can win with a counterinsurgency strategy, is in fact because I think that, three or four years down the pike, if we apply that strategy, all you good people, and your fellow citizens across the country are going to look at this, going to say, are the Taliban, or whatever it is we’re calling the Taliban, are they really our enemies, in the sense that al-Qaeda was? Is this really what we want to do? And when that happens, I suspect that what’s going to happen is you’re going to tell your members of Congress that you’ve had enough of this, and then they will vote the end of the war as they did in Vietnam. So I don’t think we can do this, I don’t think we can do counterinsurgency in Afghanistan, there are other methods that could be applied, that would control the situation there over a long period of time, I don’t think we can withdraw altogether. But counterinsurgency in Will Not Succeed in Afghanistan and Pakistan” (10/6/09) Afghanistan I find to be a very difficult idea. Thank you very much.

### Moderator
Claim: And now the counterpunch, Steve Coll is CEO of the New America Foundation and his book which I’ll bet a lot of people in this hall have read, Ghost Wars, is a winner of a Pulitzer Prize, arguing against the motion that “America Cannot and Will Not Succeed in Afghanistan and Pakistan,” Steve Coll.

### Scientific Advocate (SA)
Claim: Thank you. Thank you all very much, thanks for coming out, I’m very pleased to share the stage with my friend and colleague Steve Clemons. To give you a little taste of hallway life at New America Foundation, I notice a few of my friends and many of his friends but I’m trying to suppress my concern that this is going to turn out like an Afghan election. Um… So the question before us is whether the United States can or will succeed in Afghanistan and Pakistan and I thought the chairman said it well, this is obviously an elastic question that depends on your definition of success. So let me offer my own. That US policy contributes to the persistence of an Afghan government that is not forcibly ruled by the Taliban, and a Pakistan that does not completely fail as a state, or fall into the hands of Islamic extremists. Well by that definition, which captures the bare Will Not Succeed in Afghanistan and Pakistan” (10/6/09) minimum of US interests at issue in the war, I think the answer is obvious, you can construct such a policy. Whether or not we will is another question I’m sure we’ll talk about, but we certainly can. There are two basic reasons, one is that there is still time to define our goals more modestly and allocate our resources more realistically. And the second is that the situation in Afghanistan and the surrounding region is not as dire as many of you may fear. So I want to concentrate my time now on the second argument because it’s the less familiar one. I hope there are some Afghans in the audience. They can tell you better than I that we as Americans diminish ourselves and—when we talk about Afghanistan as we too often do as a primitive land of savage tribes that has been at war for centuries. Afghanistan between the late 18th century and 1979 was a coherent and mainly peaceful independent state. Although very poor, after the 1920s it enjoyed a long period of continuous peace with its neighbors, secured by a multi-ethnic Afghan national army and unified by a national culture. That state and that culture were badly damaged, almost destroyed, by the wars ignited by the Soviet invasion of 1979, wars to which we in the United States contributed disruptively. Yet after 2001 Afghans returned to their country from refugee camps, and far-flung exile to reclaim their state. Not to invent a brand new western-designed democracy, but to reclaim their own peaceful decentralized, but nonetheless unified and even modernizing state. Despite the manifold errors of US Will Not Succeed in Afghanistan and Pakistan” (10/6/09) policy during the Bush administration, a strong plurality of Afghans still want to finish that work. And they want the international community to stay, to correct its errors, and to help them reclaim their country. After three decades of continuous violence most Afghans are sick of war, and afraid of the Taliban’s return. We have an obligation and a national interest and we certainly have the capacity to stand by them. About three times as many Afghans today still have a more favorable view of international forces in their country than they do of the Taliban. Millions of Afghans risked their lives to vote in the recent Presidential election. American, international and Afghan government failures have certainly handed the Taliban momentum. But the Taliban are hardly unstoppable, or even as successful as many Americans today apparently believe. Today we regard Iraq for example as passively stable. Yet the per capita rate of violent death in Iraq today is four times greater than the similar rate in Afghanistan. At the peak of Iraq’s war it was 20 times greater. We’ve heard much anxiety about the allegations of fraud in the recent Presidential election and for good reason. Fractured politics, corruption and weak leadership present some of the most important challenges to US policy in Afghanistan and Pakistan alike. These challenges do argue for a new strategy that places much greater emphasis on political approaches, than on violent military action. But consider what has not happened since the Afghan Presidential vote. No opposition Will Not Succeed in Afghanistan and Pakistan” (10/6/09) protesters have taken to the streets, not a single rock has been thrown through a single window. The opposition leader has spoken freely and offered pointed criticism of the sitting—sitting President, but he’s done so within the constitutional system. In Kenya a couple of years ago the incumbent President stole his reelection and the entire country burned down. The Afghan response to similar evidence of fraud has been entirely pragmatic. The great majority of Afghans continue to show they want security and normalcy, they’re willing to talk their way through this crisis, we should get ourselves organized and help them. Finally we can succeed at this course correction because we do not have to do it all ourselves. Our presence in Afghanistan is entirely legitimate, under international law the United States is—the United Nations is present, every government in the region other than Iran’s wants us to stay. Russia is supporting our supply lines, China wants a stable Afghanistan, India’s Prime Minister has announced his intention to seek a transformational peace with Pakistan. Some of our allies it’s true, including Russia and Pakistan, are sullen and ambivalent. But unlike in Vietnam or Iraq, this neighborhood is united in its desire for stability and security. And it’s united also in the conviction that American persistence in Afghanistan, corrected and recalibrate, is required. The ultimate exit strategy for the United States from South Asia is Pakistan’s success. This is not assured but the prospects are improving. Pakistani public opinion Will Not Succeed in Afghanistan and Pakistan” (10/6/09) has now turned sharply against the Taliban and al-Qaeda. The best way for the United States to support this momentum is to stay in Afghanistan, stabilize that country, marginalize the Taliban through population security and negotiations, and broaden and deepen its engagements in Pakistan. The best way to assure the failure of Pakistan on the other hand, a state with scores of nuclear weapons, would be to allow the Taliban to return to power in Afghanistan, or to conduct a narrow war of terrorism that takes no account of the aspirations or long-term security of the Afghan or Pakistani people. I’m astonished when I hear American leaders advocate a counterterrorism war that amounts to an indefinite campaign of remote-controlled assassinations by flying robots. This is hardly the face of America that we should be emphasizing. Our record in Afghanistan and Pakistan should humble all of us. It should bring humility to the way we define our goals and realism about the means that we—that are required to actually achieve them. It should lead us to choose political approaches over kinetic military ones, urban population security over provocative rural patrolling, and Afghan and Pakistani solutions over American blueprints. But it should not lead us to defeatism or to acquiescence in a violent Taliban takeover of either Afghanistan or Pakistan. We have the means to prevent that, and it is in our interest to do so. Thank you. Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: Thank you, Steve Coll, and our next debater, Steve Clemons, also works at the New America Foundation so this is the first time we’ve had a debater, debating with his boss. And we’ll see how that goes. Steve Clemons is also the publisher of the political blog The Washington Note, and he is arguing for the motion, “America Cannot and Will Not Succeed in Afghanistan and Pakistan,” ladies and gentlemen, Steve Clemons.

### Conspiracy Advocate (CA)
Claim: Thanks— Thank you, while I have a chance to pay tribute to my boss and colleague, Steve Coll, on the blogging front, Steve writes the blog “Think Tank” for The New Yorker, you should go check it out, I hope Steve writes about this. Steve was commended the other day by Senator John McCain at a forum in Washington. John McCain said to everyone go read Ghost Wars, and as it turns out Barack Obama’s been carrying a text of Ghost Wars around for about 11 months. I think it’s the most carried-around book that Obama has had, if he would just finish it we might get somewhere. I also want to take a moment to pay tribute to Kati Marton who’s a member of our board of directors and happens to be married to one Richard Holbrooke. Richard Holbrooke is in my view one of the most tenacious and effective results-deliverers in the global justice community. I put myself somewhat in the realist Will Not Succeed in Afghanistan and Pakistan” (10/6/09) community, but I don’t—I generally criticize some of the goals of the global justice community, for not being able to set priorities, not being able to set plans, not being able to pursue things to their end. And Richard Holbrooke does do this. My problem, and why I’m on this side of the aisle from my friend and colleague Steve Coll, is that very few people in the Obama administration are like Richard Holbrooke, or can frame the debate in Pakistan and Afghanistan like Steve Coll just did. And this concerns me. If you speak to people of responsibility within an administration, clarity of objectives and how you’re going to get there, the game plan, being not only able to explain to the American public why we’re doing something, but to be able to create internal plans that help you execute consistent direction is vital. And that clarity of direction has not been in place and it wasn’t until the leak of General McChrystal’s report, in my view, that you began to see higher prioritization of the Afghanistan question. That is a lousy way to tell the world that we’re under good management in the United States. A few years ago I was in China. I went to see the equivalent of the policy planning staff in China, said what are you folks working on. And they said how to keep you guys distracted in small Middle Eastern countries. And as we’ve moved from the problems in Iraq, we now have moved to a problem in South Asia, and very often we talk about as Steve Coll did, the drama that envelops the South Asian region, the very important Will Not Succeed in Afghanistan and Pakistan” (10/6/09) promise the United States has in possibly trying to achieve a new equilibrium there. But let me ask you all a question, how many of you look at China, whether you’re concerned about its security forces or indebtedness, as a major issue for the United States, just raise your quick hand. Okay, how— hands down. How many of you look at in the Middle East, what is unfolding with Iran, Iran’s nuclear intentions, as a significant, really giant hurdle for the United States. How many of you look at Russia, some of you look at Russia and what’s been unfolding in NATO as a major issue. Probably a fewer number, but they’re out there.

Yes—

I am seeing lots and lots of hands go up, lots of concern. And let me tell you— The issue, the issue here today, is one, whether the United States after eight years of failing to move the needle, in fact seeing the needle come back on itself very dramatically, is convincing the world today that it can achieve the Will Not Succeed in Afghanistan and Pakistan” (10/6/09) objectives it sets out for itself. I think Barack Obama has inherited one of the worst economic and national security portfolios of any President in American history. We are not starting out at the same starting point that George Bush was starting out. You’re starting out in major—in a major hole, in a major deficit. And how we conduct our primary goals and objectives, has huge consequence on the way our allies see us, and whether they depend on us or not, and it also has consequences on our foes and their behaviors, and I would argue today, that the equilibrium, the general equilibrium that the United States had around the world, has been broken, and the tectonics of global affairs have shifted around so dramatically, that as we find ourselves bogged down, into very large goals, which I think are commendable goals, but we’re not achieving them, we’re convincing Iran not to negotiate in a fair and honest way, we are convincing Russia to continue to move its objectives. We are convincing China, that we’re increasingly a basket case. We— China would have to finance this war. We’re paying $65 billion a year at current levels. And that’s before the add-ons, just in military terms in Afghanistan today. That does not include what our allies are spending militarily, nor does it include the non- military expenditures. Ladies and gentlemen, that number is bigger than the entire GDP of Afghanistan. We could buy the whole place, we could put everyone to work. We could do a Marshall Plan in the region for something very different. My worry about a lot of Will Not Succeed in Afghanistan and Pakistan” (10/6/09) the steps that we’ve taken in Afghanistan is that we’re finding ourselves increasingly in a civil war, in which the Pasthun opposition which is the home base for the Taliban, actually sees us increasingly as occupiers and controllers, and I worry about our inability to disentangle that. Now there are others who have written, and Les Gelb did so recently in a Daily Beast article, Les Gelb the former, well-respected head of the Council on Foreign Relations, said it’s time for the United States to find a way to turn this not just into a NATO war, and an American war, but an Afghan war with other stakeholders. Particularly countries like Russia and China and other stakeholders in the region where they can come in, and actually feel as if this matters to them too. That the instability there is happening, we are right now back into, while we have allies, back into a sense that this is our game. And we have some slightly reluctant fellow travelers from NATO helping us, and we’re achieving none of the big, progressive goals that I think that we should be able to. And so as we look at this, we look at the cost and we look at how we’re operating in Afghanistan, I think it’s very important to look at the consequences on US society and what it’s achieved elsewhere in the world. Jim Jones, President Obama’s national security advisor, just said, that we have succeeded in diminishing al-Qaeda’s resonance and its robustness, both in Pakistan and Afghanistan, and he said, that there is no imminent threat of a Taliban takeover. Now, this is quite different than Will Not Succeed in Afghanistan and Pakistan” (10/6/09) General McChrystal’s report and I have to say, that General McChrystal has probably written in my personal view, one of the most stark and realistic and probably accurate assessments of the mess in Afghanistan today. I disagree with the prescription because I don’t have confidence and faith in the ability of the Presidential leadership to get this right. My colleagues on the other aisle, are going to argue that it can. But, at some point you have to pull the plug, and say that it is time that we begin to move in a different direction. We need a consistent voice, consistent leadership, that is not happening. Thank you very much.

### Moderator
Claim: Steve?

### Conspiracy Advocate (CA)
Claim: Yes—

### Moderator
Claim: This makes very bad radio so can you tell our radio audience what you’re seeing, when the hands go up—

### Conspiracy Advocate (CA)
Claim: I am seeing lots and lots of hands go up, lots of concern. And let me tell you— The issue, the issue here today, is one, whether the United States after eight years of failing to move the needle, in fact seeing the needle come back on itself very dramatically, is convincing the world today that it can achieve the Will Not Succeed in Afghanistan and Pakistan” (10/6/09) objectives it sets out for itself. I think Barack Obama has inherited one of the worst economic and national security portfolios of any President in American history. We are not starting out at the same starting point that George Bush was starting out. You’re starting out in major—in a major hole, in a major deficit. And how we conduct our primary goals and objectives, has huge consequence on the way our allies see us, and whether they depend on us or not, and it also has consequences on our foes and their behaviors, and I would argue today, that the equilibrium, the general equilibrium that the United States had around the world, has been broken, and the tectonics of global affairs have shifted around so dramatically, that as we find ourselves bogged down, into very large goals, which I think are commendable goals, but we’re not achieving them, we’re convincing Iran not to negotiate in a fair and honest way, we are convincing Russia to continue to move its objectives. We are convincing China, that we’re increasingly a basket case. We— China would have to finance this war. We’re paying $65 billion a year at current levels. And that’s before the add-ons, just in military terms in Afghanistan today. That does not include what our allies are spending militarily, nor does it include the non- military expenditures. Ladies and gentlemen, that number is bigger than the entire GDP of Afghanistan. We could buy the whole place, we could put everyone to work. We could do a Marshall Plan in the region for something very different. My worry about a lot of Will Not Succeed in Afghanistan and Pakistan” (10/6/09) the steps that we’ve taken in Afghanistan is that we’re finding ourselves increasingly in a civil war, in which the Pasthun opposition which is the home base for the Taliban, actually sees us increasingly as occupiers and controllers, and I worry about our inability to disentangle that. Now there are others who have written, and Les Gelb did so recently in a Daily Beast article, Les Gelb the former, well-respected head of the Council on Foreign Relations, said it’s time for the United States to find a way to turn this not just into a NATO war, and an American war, but an Afghan war with other stakeholders. Particularly countries like Russia and China and other stakeholders in the region where they can come in, and actually feel as if this matters to them too. That the instability there is happening, we are right now back into, while we have allies, back into a sense that this is our game. And we have some slightly reluctant fellow travelers from NATO helping us, and we’re achieving none of the big, progressive goals that I think that we should be able to. And so as we look at this, we look at the cost and we look at how we’re operating in Afghanistan, I think it’s very important to look at the consequences on US society and what it’s achieved elsewhere in the world. Jim Jones, President Obama’s national security advisor, just said, that we have succeeded in diminishing al-Qaeda’s resonance and its robustness, both in Pakistan and Afghanistan, and he said, that there is no imminent threat of a Taliban takeover. Now, this is quite different than Will Not Succeed in Afghanistan and Pakistan” (10/6/09) General McChrystal’s report and I have to say, that General McChrystal has probably written in my personal view, one of the most stark and realistic and probably accurate assessments of the mess in Afghanistan today. I disagree with the prescription because I don’t have confidence and faith in the ability of the Presidential leadership to get this right. My colleagues on the other aisle, are going to argue that it can. But, at some point you have to pull the plug, and say that it is time that we begin to move in a different direction. We need a consistent voice, consistent leadership, that is not happening. Thank you very much.

### Moderator
Claim: So a reminder of where we are, we’re halfway through the opening round of this Intelligence Squared US debate, I’m John Donvan, we have six debaters, two teams of three who are debating this motion, “America Cannot and Will Not Succeed in Afghanistan and Pakistan.” Our fourth speaker now, against the motion, John Nagl who is president of the Center for New American Security, he is a West Point graduate, he is a Rhodes scholar, he served in Iraq, ladies and gentlemen, John Nagl.

### Scientific Advocate (SA)
Claim: Thank you, it’s a great pleasure to be here tonight to argue about a Will Not Succeed in Afghanistan and Pakistan” (10/6/09) subject that I think should concern us all and I’m very pleased that the American people are so closely engaged in this discussion that concerns the safety of the country, the safety of all of us, as well as the fates of many of my friends and I’m sure many of your sons and daughters and friends as well, so, it is well worth the time to invest in thinking hard about these questions and what it is we’re trying to accomplish in Afghanistan and Pakistan. Steve focused on why it is that we should succeed in Afghanistan and Pakistan, and talked to a certain extent about why it is possible for us to do so, that the situation is not as dire as perhaps has been presented. It is my task then to talk about part of the way we can succeed, part of the how. And I’d like to start off if I can by pointing out that, there has been an acceptance so far in this debate of what it is we’re trying to accomplish, of what success means. And success has been defined as a pretty minimal standard. An Afghanistan and a Pakistan that are not ruled by terrorists, a Pakistan that still has security over its nuclear arsenal. I would contend, that if we cannot as a nation achieve that success, if it is impossible for the United States to ensure that Pakistan retains control of its nuclear weapons from terrorists…that that is a very, very dire situation. And that’s why we have invested so much as a nation to date, and why I believe we need to invest even more, because the stakes are so very high, the consequences of failure are potentially so catastrophic. That’s the bad news. The good news is that we can Will Not Succeed in Afghanistan and Pakistan” (10/6/09) in fact succeed in this endeavor. And this book tells us how. This is the Counterinsurgency Field Manual written under the direction of General Petraeus and General Jim Mattis. For those of you who didn’t bring it along, I’m not going to read the whole thing. But to quote from Chapter 5… the way to conduct a counterinsurgency campaign is to do a number of different things, to do them all well, to coordinate them together. Our opponents say that it is impossible for the United States to help our friends and our allies do this, I would disagree, I would say that it is enormously difficult, but that we have a learning army, a learning State Department, we have adapted and we have developed the capability to do this reasonably well. We have a number of extraordinarily talented people, continuing to try to help our Afghan partners. And they do it by conducting combat operations against our enemies. This is a component of counterinsurgency, this is the counterterrorism part, killing or capturing identified enemies of the government of Pakistan, the government of Afghanistan, and that happens and that will continue to happen, and we are in fact, getting far better at that. Training and equipping host nation security forces is an essential part of a lasting counterinsurgency strategy, and it is essential for us not to have to conduct counterterrorism forever. So, if you want at some point the United States to be able to depart from Afghanistan, then you have to support raising and training Afghan security forces who in time, Will Not Succeed in Afghanistan and Pakistan” (10/6/09) will be able to secure their country on their own, something we have not done very well to date. We have to provide essential services to the population, water, electricity, most of all security. We have to provide them with good governance, something that, we have not helped with as much as we should. We have to provide them with good economic development and opportunity to have their sons and their daughters earn a decent living, so that they cannot be attracted away by the insurgents, many of the insurgents I fought against in Iraq in 2003 and 2004, many of the Taliban insurgents today, are economic insurgents. That is, there is no other way for them to feed their families, than to take money from the Taliban, in order to conduct attacks against us, against the governments of Pakistan and Afghanistan. So, for a very few dollars, well-invested, we can peel away the less committed parts of the insurgency, and we can provide them with an economic opportunity. We were able to do this in al-Anbar late in Iraq. The process started early but really came to fruition in late 2006, early 2007, and large numbers of the insurgents turned away from fighting against us, and started fighting on our side against al- Qaeda. We’ve done this before, the same people who made that process happen, who inspired that process in Iraq, are working now to do it in Afghanistan. So you can peel away insurgents and reduce the number of people you’re fighting, gain additional support for your effort. So we have done this successfully in the Will Not Succeed in Afghanistan and Pakistan” (10/6/09) past, it is not easy by any means, but we have a track record. It is also important to note that Pakistan is now succeeding in its efforts. In March the Pakistani government decided because of extraordinary American pressure, to fight against the insurgents who had taken the Swat River Valley, just 60 miles from the capitol of Pakistan. And in a not very sophisticated but very effective counterinsurgency strategy, they cleared the Taliban out of the Swat River Valley, and the people of the Swat River are now returning home. Pakistan is about to do the same thing in south Waziristan. They are conducting an effective counterinsurgency campaign to relieve the danger to their government, and to make their weapons, and, and, and their country more safe. The most important thing we can do to help them in this effort, is to continue to conduct counterinsurgency on our side of the Durand line in Afghanistan. It will be enormously difficult for us to encourage Pakistan to continue conducting its counterinsurgency campaign, if we decide not to do so in Afghanistan. And the implications of that decision are enormously important. The single most important step we have to take, to build a secure Afghanistan and a secure region, is to raise and train an Afghan army that is sufficiently sized, and sufficiently well-equipped, to secure Afghanistan on its own. In my last job on active duty in the Army, I worked with Afghan soldiers, I trained Afghan soldiers. These are people who are willing to fight for their country. They are disappointed that we Will Not Succeed in Afghanistan and Pakistan” (10/6/09) have not provided the resources to get enough of them to fight for their country, in order to enable us to begin to depart. Putting more effort into that, is the single most important step I believe, to helping America succeed in Afghanistan and Pakistan. Thank you.

### Moderator
Claim: The next counterpunch from Ralph Peters, he is a former US Army lieutenant-colonel, he is a writer, he’s also a novelist, his most recent novel just came out, it is called The War After Armageddon. It is an act of imagination, but he also writes about the current situation, writing in USA Today last February his assessment of Afghanistan: We should smash our enemies and then leave. It’s the fact that we did not leave, that explains why you are here to argue for the motion that “America Cannot and Will Not Succeed in Afghanistan and Pakistan,” Ralph Peters.

### Conspiracy Advocate (CA)
Claim: Thank you. Looking out at this crowded house I’m really happy that I’m almost over my swine flu. Ladies and gentlemen. So far this evening, you’ve heard quite a range of opinions. Let’s look at the facts. We have been in Afghanistan for eight years. We have committed enormous amounts of treasure and quite a bit of blood. And eight years on, the Taliban have no trouble attracting volunteers…in fact Will Not Succeed in Afghanistan and Pakistan” (10/6/09) their numbers are swelling. They are willing to take up primitive arms, and fight against the most powerful military in history, to stand with a Kalashnikov, or to attack a US outpost and stand and fight, despite the helicopters and the aircraft coming in on them, and killing them. And we can’t get the Afghan army to show up. Eight years. How much training does it take. Sophisticated weapons? What sophisticated weapons do the Taliban have. Bombs, rusty Kalashnikovs and grenade launchers. The Taliban are willing to give their lives for their cause. The Afghan army and police are not willing to die for the woefully corrupt and incompetent government of Hamid Karzai. That is simply a fact. Now my Army colleague John Nagl said, well, the Taliban are hiring, they’re economic soldiers. Ladies and gentlemen, you do not sign up to stand against the greatest army in history, and give your life, for the Afghan equivalent of a minimum wage. And we pay better than the Taliban. Why aren’t they lining up, to join the Afghan army and fight? Why do our soldiers and Marines have to go into battle alone? Or, worse, watching over their shoulder to see if the Afghans with them, are going to betray them or shoot them in the back, as has happened repeatedly. This matters. How many Americans should die for the government of Hamid Karzai? And we can—and Steve Coll said, well, you know, we’re going to fix that. When, how? Eight years. Ladies and gentlemen, we have the power to stay—and the wealth—to stay in Afghanistan forever.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09) Certainly beyond our lifetimes, if we wish. But strategy is about asking what we get out of it. And is it doable, strategy isn’t about what’s nice to do, it would be nice to turn Afghanistan into Vermont. But it is not going to happen. Because, one thing we cannot do— we can fly in in our helicopters, dismount, arrive in an Afghan village and get the elders to nod their heads, until we leave. We can bribe them for a while, they won’t stay bribed. But we cannot make Afghans want what we want. A brief history. We’ve been in Afghanistan before. We had major development projects, in Helmand Province, down where they’re fighting now, in the 1950s and ‘60s. Nothing came of it. The Soviets, had at their peak 140,000 troops, tens of thousands civilian advisors. Their interagency process worked because they could order people from other departments to go. They have thousands of Dari and Pashtun speakers. They built hundreds of clinics and schools and factories, it’s not like just the bad Soviets killing people in the movies. Their Afghan army was over 300,000 trained with helicopters and tanks. And they lost. Because the people of Afghanistan didn’t want what the Soviets wanted them to want. Now think of this as an investment. We’re investing our blood and treasure. What is the possibility of a positive return, for that investment. For the past 200 years, every foreign investor has lost. Are we truly exceptions to history? Is it worth the gamble? Afghanistan is not a country, it is an accident of where other Will Not Succeed in Afghanistan and Pakistan” (10/6/09) people’s borders to ended. You cannot nation-build where there is no nation to build. In a tribal society, you work with tribes. Now we may know that it would be wiser for all the tribes to get along. But we do not want what Afghans want. General McChrystal’s report is fascinating. In many respects it’s an objective view. But you know what it leaves out. Religion is barely mentioned. In the Counterinsurgency Manual, religion is barely mentioned. This is even more foolish than trying to deal with the war in Europe in World War II—and ignoring Nazis. Religion may be politically incorrect to talk about. It’s difficult, it makes us uneasy. But to write a 66-page report about the Taliban, and not mention the power of religion and fundamentalist Islam, seems to me that we are living in a dream world. Now. This debate-- Thank you. This debate, the terms of it make me uncomfortable. Because I’m in the middle. In a world of very strange bedfellows, I find myself aligning with Vice President Joe Biden, or, I’d like to think he’s aligning with me. But the choices aren’t all in or all out. There are rational choices. Ladies and gentlemen, why did we go to Afghanistan in 2001? Because of al-Qaeda. To punish them, to smash them, and to punish those who harbored them. Afghanistan was a low-budget terrorist motel. So the feds raid the motel, kill some of the bad guys, capture some, and others escape. And instead of going after the ones who escaped, we decided to renovate the motel. It… Will Not Succeed in Afghanistan and Pakistan” (10/6/09) Now, I would just close by saying, I believe there is still a purpose in maintaining a compact, lethal force, focused on destroying our enemies, helping Pakistan to the extent Pakistan deserves the help, but not allowing ourselves to be blackmailed by the Pakistanis, as we have allowed ourselves to do. But at the end of the day, this is about flesh and blood, Afghans of course, and our young men and women in uniform. Now, I am not a pacifist. Wars have to be fought. But let us ensure that they are true wars of necessity, and not wars of inertia, and bad habits. Let’s—when we ask our young men and women in uniform to die…if they must die, let it be for sensible strategy, and attainable goals.

Not because, we’re out of ideas.

### Moderator
Claim: Ralph Peters, your time is up—

### Conspiracy Advocate (CA)
Claim: Not because, we’re out of ideas.

### Moderator
Claim: Our final opening statement, from James Shinn, he is a former Assistant Secretary of Defense for Asia, and, immediately after this debate he is actually boarding a plane for Afghanistan so we’re delighted, James, that you were able to, to stop off here first. I give you James Shinn. Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Scientific Advocate (SA)
Claim: To convince you on your second vote, to support this motion, I think the other team has to convince you of either one of two propositions. The first is, that we don’t have any serious interests in Afghanistan and Pakistan, and therefore we should walk away. Or, they have to convince that we do have interests in Afghanistan and Pakistan, but they’re too costly to achieve. And therefore, we should walk away. Although I just heard a new one from Steve Clemons who says, well, we may have interests, they may be costly but we can achieve them, but we should walk away perhaps because the President can’t make up his mind. I think that Steve and John together have made a very persuasive case, for the interests that we have—we have, in Afghanistan and in Pakistan. That these interests are not just America’s interests but these are shared by our allies. And that we have the capacity, through the intelligent application of counterinsurgency doctrine, to achieve those. And listen very closely to Ralph Peters’ argument, the smash them and leave argument, I believe, and to still vote for this proposition requires you to go through a kind of a contortion known as remote-control counterterrorism. Remote-control counterterrorism, that’s where, presumably, you track and you deter al-Qaeda from offshore, maybe with precision munitions, maybe from satellites, maybe like that. I think that’s a fundamentally flawed proposition, I would Will Not Succeed in Afghanistan and Pakistan” (10/6/09) submit to you. And it’s flawed for a couple of reasons and let me share those with you. With some realistic talk about how you actually have to deal with al-Qaeda. Counterterrorism operations require two things, it requires intelligence, and it requires the ability to offensively strike against them. You need to know where they are, what they’re up to, and you need to be able to strike at them. There are only two sources of intelligence, if you’re tracking al-Qaeda folks up in the borderlands between Afghanistan and Pakistan. And I’ve spent a good deal of the last two years, in those two countries. One is by signals intelligence, where you try and track where they are by their cell phone. Even as texting New Yorkers have found out that cell phones can be dangerous to your health, the al-Qaeda guys have gradually stopped revealing themselves by the same notion, which leaves you, really, relying upon human intelligence. Spies, in other words. We don’t have a lot of spies on the border areas between Pakistan and Afghanistan, the intelligence that we get about al-Qaeda and their fellow travelers compassed from the intelligence networks run by the Afghans, and the networks run by the Pakistanis. If we walked away, why on earth would they share that intelligence with us. Let’s assume for the moment that you did have the intelligence about where a cell was who were planning another attack in New York or in a London subway. How do you strike at them. Right now the way we do it is with UAV Predators. They have a flight Will Not Succeed in Afghanistan and Pakistan” (10/6/09) range of about 400 miles. It’s 600 miles from Waziristan to the Indian Ocean. Which leaves you the option maybe like the Clinton administration did in 1998, with launching a Cruise missile at them, but in the hours that it takes to target and launch a Cruise missile, the target’s probably gone, and worse, since it’s not accurate, you have a lot of collateral damage, a lot of dead civilians, and the cycle continues. Fundamentally, to protect this national interest, that I believe even the other team agrees, to protect ourselves from terrorism, we need access, and cooperation, in Pakistan and in Afghanistan. We don’t need Vermont. We don’t need to stabilize the whole country, you don’t even need to engage in counterinsurgency activities across the whole landscape. But you do need cooperation, you do need access, and this is about as stark a statement of national interest that I can think of. Thank you.

## Round 2

### Moderator
Claim: And that concludes Round 1 of this Intelligence Squared US debate where the motion being argued is “America Cannot and Will Not Succeed in Afghanistan and Pakistan.” And as the debate began we asked all of the members of our live audience who are our judges in this debate to vote, to tell us where they stood on this motion before hearing the arguments, and we now have the results of that preliminary vote. And they are…before the debate, 48

Will Not Succeed in Afghanistan and Pakistan” (10/6/09) percent are for the motion, 25 percent against, and 27 percent undecided, and again we will ask you to vote at the end of the debate and the team that has moved the most votes, that has changed the most minds, will be declared our winner. Now on to Round 2, this is our middle round where we mix things up a little bit now, our two teams get to debate head to head, and they will also be responding to questions from me, and questions from you. It’ll go on for about 40, 45 minutes. And I want to start, by bringing something I heard from John Nagl over to Patrick Lang, Patrick Lang, you are a generation ahead of John Nagl, you’re both military men, you did counterinsurgency work, and you don’t seem to believe that the methods work very well and yet John Nagl comes in here, he actually brings along the manual…with the techniques and the rules and tells us that we have seen it work, in Iraq. Now, without turning this into a discussion about Iraq…tell me why John Nagl is wrong about success with counterintelligence, counterinsurgency measures.

### Conspiracy Advocate (CA)
Claim: Well, to begin with, it was, I did appreciate the fact that sacred scripture was brought to the meeting here so it could be read to us. In fact these words inscribed in that manual are in fact the same doctrine that we used in the 1960s and ‘70s across the world. And as I said, we had a varying pattern of success depending on how tough the opposition was and how long we were Will Not Succeed in Afghanistan and Pakistan” (10/6/09) willing to stick with it. With regard to Iraq, with the greatest of respect to Colonel Nagl, I would submit in fact that whatever it is that people call the surge, people are creating these fanciful concepts with single words as a public relations gimmick. The surge, what was the surge, an increase of 30,000 troops or so, in Iraq for some period of time? That was certainly useful in the Baghdad area in the context of Iraqi neighborhoods that had been largely cleansed ethnically or at least in a sectarian way, and then a lotta walls were built to separate these people, that worked very well indeed. But I would submit to you that what really worked out in Anbar, in the places where he said-- in other places in Iraq-- was the fact that we adopted a very simple, old-fashioned tool that has been used in the Middle East from time immemorial and often by the colonial powers. And that is in fact that we looked at our enemies and instead of believing that they were all one thing as had been advocated for three or four of the first years of the war, we actually looked at them and decided they were many different things. And that some of these people were only, as it was said economic insurgents, and that they could be split off and used against the other ones. And that had a devastating effect once it was put into effect against al-Qaeda—

### Scientific Advocate (SA)
Claim: And why would that not work again in Afghanistan, Patrick.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: No, it would work. That would work very well—

### Scientific Advocate (SA)
Claim: It would work.

### Conspiracy Advocate (CA)
Claim: Yeah, I actually think it would—I’m not in favor of withdrawing from Afghanistan.

### Scientific Advocate (SA)
Claim: Oh, heavens—

### Conspiracy Advocate (CA)
Claim: But what I—what I’m not in favor of doing is trying to Vermontize large parts of Afghanistan. I think that doesn’t suit—

### Moderator
Claim: Did—did you say “Vermontize”—

### Conspiracy Advocate (CA)
Claim: I just created that word, yes. Yeah—

### Scientific Advocate (SA)
Claim: It’s a cheese thing.

### Conspiracy Advocate (CA)
Claim: Yeah, it’s a cheese thing. Or a maple syrup thing, one or the other. And, but in fact— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: But to John’s point—

### Conspiracy Advocate (CA)
Claim: So—

### Moderator
Claim: —why would that not work in Afghanistan—

### Conspiracy Advocate (CA)
Claim: I did say it would work—

### Moderator
Claim: Yeah—

### Conspiracy Advocate (CA)
Claim: —it would work—

### Scientific Advocate (SA)
Claim: So Patrick, you would agree that America can succeed in Afghanistan and Pakistan—

### Conspiracy Advocate (CA)
Claim: No, no, no, no, no, no, no— No, it depends—depends on what you mean by succeed. If you look at, in fact, what President Obama said was his purpose in Afghanistan in March, that was to disrupt and disorganize our enemies, our enemies, not the enemies of the Karzai government, or some other group of Will Not Succeed in Afghanistan and Pakistan” (10/6/09) political luminaries there, but our enemies in fact. You can do that in exactly the same way it was done in Iraq because there are lots and lots of available, rentable Afghans out there. And they’re—a lot of them do not belong to the Taliban confederation, some of the ones who do belong to the Taliban Confederation, can be split off, and their—

### Scientific Advocate (SA)
Claim: So we can use these techniques to achieve success in Afghanistan and Pakistan, prevent the Taliban and al-Qaeda from controlling those countries—

### Conspiracy Advocate (CA)
Claim: I don’t really care who controls most of Afghanistan. What I’m interested in doing is disrupting the people who might use Afghanistan as a base for planning offensive operations against the United States. You have to stop thinking about improving the lot of the average Afghan, and start thinking about protecting these people here, and nothing else in fact—

### Scientific Advocate (SA)
Claim: And you believe it’s possible to do that.

### Conspiracy Advocate (CA)
Claim: I—well, you may believe that it’s possible for us over a sustained period of time to spend vast amounts of money, have a couple hundred thousand troops in Afghanistan, and maintain in power a Will Not Succeed in Afghanistan and Pakistan” (10/6/09) government like Karzai’s power. But I’m telling you, that what’ll happen here is that these folks will make a rational decision in several years if you do that, and they’ll tell their members of Congress let’s knock this stuff off.

### Moderator
Claim: Steve Coll.

### Scientific Advocate (SA)
Claim: That’s not what—that’s not actually what I think we’re all talking about, I mean when I listen to Ralph and you talk about sort of minimal goals and different means and a middle way and, there’s, this is not—neither of you is arguing for withdrawal.

### Conspiracy Advocate (CA)
Claim: No. We’re—I’m not.

### Scientific Advocate (SA)
Claim: So, you’re talking about nuances of transition strategy. What you’re really talking about is a plan, whether or not it is worth attempting to hold on to the Afghan state long enough to allow the Afghan national army to take the lead in the security of that state. Correct, I mean—

### Conspiracy Advocate (CA)
Claim: Yeah.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Scientific Advocate (SA)
Claim: —whether or not it’s, whether that investment—

### Conspiracy Advocate (CA)
Claim: Steve, Steve, for God’s sakes, eight years, when is the Afghan army going to show up?

### Scientific Advocate (SA)
Claim: Well, the Afghan army—

### Conspiracy Advocate (CA)
Claim: 80—how many more years, how many more years to—before the new Afghan army works—

### Moderator
Claim: Well let’s let him answer the question.

### Scientific Advocate (SA)
Claim: Let—let me take that if I can. So—

### Moderator
Claim: This is John Nagl.

### Scientific Advocate (SA)
Claim: Yeah, this is sort of what I do. So, and Ralph, I took great exception to your statement that the Afghans are not fighting and dying because the Afghans currently lose, just the Afghan police, more than 100 are being killed every month by the Taliban.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09) So these guys are showing up for the fight. And it is enormously disrespectful to say that they are not, it is enormously disrespectful to say that our European allies, who are also fighting and dying, Canadians, more Canadians proportionately have fallen in Afghanistan than Americans. So there are a lot of people working to make this go. First—

### Conspiracy Advocate (CA)
Claim: John. John. John…the Afghan police are dying because they’re hiding in their police posts and the Taliban are surrounding them and killing them. Our soldiers and Marines go out on patrol, and I talk to these guys, they are afraid of the Afghans betraying them, of shooting them in the back. It’s happened again and again, they can’t get the Afghan army to fight except for a few commando units.

### Conspiracy Advocate (CA)
Claim: May I—

### Conspiracy Advocate (CA)
Claim: You know, and there’s, there’s—

### Moderator
Claim: Steve Clem—let’s bring in your—

### Conspiracy Advocate (CA)
Claim: —there’s a point at which— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: —your fellow teammate—

### Conspiracy Advocate (CA)
Claim: —you’ve gotta give—

### Moderator
Claim: —Steve Clemons.

### Conspiracy Advocate (CA)
Claim: A colleague of mine and Steve Coll’s, Peter Bergen, who would no doubt be arguing on the other side of the panel, made an interesting point the other day in that the tragic death of these I believe 10 troops that were killed in an external outpost— The similar thing had been done in the past and there were hundreds of pages of review documents by the US military done to sort of prevent exactly what happened, that there was supposed to be pre- positioning of men—of equipment and a concern that this not replay. This gets at the issue I’ve been getting at, it is regardless of the merit of what you would like to try and achieve, the costs of the collective failure of the counterinsurgency approach of the months that have been under the Obama— I mean the Obama administration came in in a period where, the concern for upgrading of the forces at that time was linked to the spring offensive. Then there was the increase of 21,000 troops to make Afghans safe, Afghanistan safe for voters, and we needed to get Will Not Succeed in Afghanistan and Pakistan” (10/6/09) through the August 30th elections. And then we see dire predictions of the meltdown of Afghanistan, again you— We see a constant tick up, but no real serious competence in either generating a consistency of what objectives we’re at, whoever you talk to in the administration, if it’s DOD one day, State another USID on another, they’re not on the same page. And then we have the tragic death of these soldiers, in something where the military had studied and not deployed the reforms it said it needed to do—

### Moderator
Claim: All right, let’s bring in—

### Conspiracy Advocate (CA)
Claim: It’s a mess.

### Moderator
Claim: Let’s bring in James Shinn who’s already said he doesn’t really like your argument that the administration isn’t managing this thing well—

### Scientific Advocate (SA)
Claim: Well, as a former member of the Bush administration I will allow you to take on the Obama guys as much as you like.

### Conspiracy Advocate (CA)
Claim: I would take on the Bush administration as well, they had seven years of this. Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: James Shinn responding—

### Scientific Advocate (SA)
Claim: But the issue is not whether it’s 20,000 troops or 10,000 more troops, it really is, and on this point I have to agree with the colonel, it’s a matter of time. You’re interested in counterinsurgency, how long did it take to succeed in Malaysia?

### Conspiracy Advocate (CA)
Claim: The British you mean?

### Scientific Advocate (SA)
Claim: The British.

### Conspiracy Advocate (CA)
Claim: Yeah, it was a long time.

### Scientific Advocate (SA)
Claim: Long time—

### Conspiracy Advocate (CA)
Claim: And this is an interesting place too because you—

### Scientific Advocate (SA)
Claim: 12 years, and he did prevail, right?

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: They, they did prevail but you have to, you know perfectly well that this was an occasion in which the number of Communist terrorists as they called them, was quite small, they were confined to a particular despised ethnic minority, and the conditions were all there to—all you had to do was hold on long enough and keep after them and you were going to get them. But as I said before, this was a small-scale problem. Afghanistan is not a small-scale problem in terms of applying a general counterinsurgency strategy to this place because it involves economic development, political reform, and counterguerrilla operations. And those are all very complex things, and it’s going to be very expensive over a long period of time.

### Scientific Advocate (SA)
Claim: Well it is, it is big and it is complex and it will take time. But the risk here I think, is that the counterinsurgency clock moves at a slower pace than the political clock. The real question is, do we have the foresight or the strategy if you want to use Steve Clemons’s phrase, the strategic vision, to actually stay the course long enough so you achieve the objectives. Or rather, you simply sacrifice your interests and walk away.

### Conspiracy Advocate (CA)
Claim: Yeah but this is a democracy, right? I mean, at least we think it is Will Not Succeed in Afghanistan and Pakistan” (10/6/09) anyway. And in fact, what’s going to happen here is, if you remember the history of the late, great war in Indochina, 40 years ago, after the application of a great deal of counterinsurgency effort in the last two or three years of the war, and in fact, and the Christmas bombing up at North Vietnam, there was an armistice that lasted for two years, you were there during that period, in fact. And in fact, there was—did not a thing happen until, the people of the United States over some hiccup in world events then, told their members of Congress that they wanted a law passed to prevent this happening again, and the Congress passed a law that said not under any circumstances would the United States ever assist South Vietnam again. The other side, understandably understood that as a signal. Right? So, a year or so later or six months or whatever it was, they took their eight splendid divisions and they took a provincial capitol, and that was the end, everything fell apart.

### Scientific Advocate (SA)
Claim: So the question—

### Conspiracy Advocate (CA)
Claim: Now why wouldn’t something like that happen again—

### Moderator
Claim: John, John Nagl.

### Scientific Advocate (SA)
Claim: So the question is not, whether the United States can succeed in Will Not Succeed in Afghanistan and Pakistan” (10/6/09) counterinsurgency, the question is whether we have sufficient national interests to necessitate that we bear the burden over the number of—

### Conspiracy Advocate (CA)
Claim: No.

### Scientific Advocate (SA)
Claim: —years that will be required—

### Conspiracy Advocate (CA)
Claim: No—

### Scientific Advocate (SA)
Claim: —to do so—

### Conspiracy Advocate (CA)
Claim: —the question is—

### Moderator
Claim: Ralph Peters—

### Conspiracy Advocate (CA)
Claim: —can the US succeed in counterinsurgency. John…in that manual, you love to wave around, you did what bad academics do, you took a couple examples that supported your thesis, and ignored 3,000 years of history. There is nothing in that manual about religious motivation and religious war. And I will just tell Will Not Succeed in Afghanistan and Pakistan” (10/6/09) you. We’re having a—we’re pretty comfortable in this auditorium tonight. It’s easy to have this intellectual debate. But it’s really to an extent a moot point because the Army and Marines are out of troops. They are tired. They are worn. This isn’t an abstract issue. In order to send 40,000 more troops to Afghanistan on what I believe is a fool’s errand…based upon history, we would have to send some troops directly from Iraq to Afghanistan. Now we’ve been at this for eight years. We’ve had some great successes in targeting al-Qaeda and smashing them. We’ve—that makes sense in terms of our security. But teaching better dental hygiene to Afghan villagers does not persuade the Arab terrorists in al-Qaeda to stop attacking America, and America’s interests, so John, no, I do not agree that we can succeed in counterinsurgency. We are not necessarily better than the Brits, who had tried it for over 100 years, or even the Soviets. I need to see the proof that we can succeed, before send more—

### Scientific Advocate (SA)
Claim: Ralph, I—

### Conspiracy Advocate (CA)
Claim: —of our troops, to die for your theory.

### Scientific Advocate (SA)
Claim: Ralph…with great respect, none of the troops are dying for my theory, they are dying to keep America safe. Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: They are dying to keep the Karzai government in power.

### Scientific Advocate (SA)
Claim: They are fighting for the legitimate government of Afghanistan, we don’t know—yet know what government—

### Conspiracy Advocate (CA)
Claim: The ques—hey, guys—

### Conspiracy Advocate (CA)
Claim: The legitimate government of Afghanistan—?

### Conspiracy Advocate (CA)
Claim: —we don’t yet know which government that is—

### Conspiracy Advocate (CA)
Claim: Legitimate to who—

### Moderator
Claim: All right, all right, I need to separate this, because I want to bring in Steve Clemons.

### Conspiracy Advocate (CA)
Claim: I mean I—I hope that—

### Conspiracy Advocate (CA)
Claim: Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: —we—

### Moderator
Claim: Steve Clemons—

### Conspiracy Advocate (CA)
Claim: —I mean, binary debates, are always complicated but I hope we can stay away from sloganeering, I’m not there—the other day General David Patraeus said that one of his concerns, was that people would think that what happened in Iraq would be easily moved— that he thinks all the time about the tyranny of the mind, that one would get stuck in one framework that might not approach the others, so General Petraeus actually raised many of the same questions that we are about the applicability of the counterintelligence—but let’s take your manual for a minute, your manual as you know, and I’ve learned a lot about it from you, argues for a forced deployment which is staggering, but more important, of that staggering force deployment it argues that of the resources deployed, 80 percent of those should be civilian, 20 percent should be military. And I have to tell you that everything we see percolating out of the military analysis is calling for a 99.999 percent military approach to this. That only animates Pashtun tribalism, Pashtun concern over occupation. It animates and it has built a blob, which we’re increasingly calling the Taliban.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09) We’re not able to defuse that, and we’re not able to get the convertibility. I’ve talked to various people that—

### Scientific Advocate (SA)
Claim: Steve, you obviously haven’t read…General McChrystal’s assessment. Because he says right in there, that it’s as much politics and economics, that it is military.

### Conspiracy Advocate (CA)
Claim: I have read a significant portion of it—

### Scientific Advocate (SA)
Claim: He acknowledges that—

### Conspiracy Advocate (CA)
Claim: —but I—

### Scientific Advocate (SA)
Claim: —it’s not a kinetic exercise—

### Conspiracy Advocate (CA)
Claim: Well, I’ve read the whole thing. The—

### Moderator
Claim: This is Patrick Lang.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: The-- he talks so much about the need for good governance in Afghanistan and about the woeful deficiencies of the present setup which is based really on traditional norms of government in Afghanistan and throughout the region in fact. You know, then after a while you begin to wonder if he thinks in fact that Karzai is in fact reformable, or will have to be removed and replaced with somebody else.

### Moderator
Claim: All right, I want to at this point go to the audience for some questions. And we have people around the hall with microphones. And if you’re called on, I just want to urge you to hold the microphone about a fist away from your mouth so that we can hear you and the radio can hear you. And while the microphones are getting out I just want to take one last question to Steve Coll, in that I heard from your opponents’ side early in the opening statements, the remark that in the case of Afghanistan there is no nation to build, and I want to ask you is that true and is that relevant.

### Scientific Advocate (SA)
Claim: It’s false and it is relevant, it’s the heart of what I was trying to argue about Afghan partnership in this and the evidence, the clear evidence of Afghan resilience expressed continually despite our Will Not Succeed in Afghanistan and Pakistan” (10/6/09) errors and our underinvestment. You know, to talk about the Afghan army not showing up is to suggest that we made adequate investments, adequate commitments, to that project. In fact 80,000 Afghan soldiers go out and fight, put their lives on the line every day. You know, you’ve got incidents that you haven’t documented or described about fragging and for that you describe the entire institution as a failure, that’s just, I don’t understand how you can argue that, that the… President Obama ran for office signaling that this is what he intended to do, he argued that the Bush administration had taken American resources, attention and potential, and invested it mistakenly in Iraq, and that he was going to right that balance by turning back to finish what the Bush administration failed to complete in Afghanistan. He’s been in office for less than a year. And how do—how you reach a comprehensive judgment about his potential in performance, at the same time that you believe that the preservation of the constitutional Afghan state is of American national interest, you’re arguing we should stay, you’re not arguing we should go. So, I think this is achievable—

### Conspiracy Advocate (CA)
Claim: Well—

### Scientific Advocate (SA)
Claim: —in that— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: You know, I—

### Scientific Advocate (SA)
Claim: —you’re basically—

### Conspiracy Advocate (CA)
Claim: I’d like—

### Scientific Advocate (SA)
Claim: —we’re basically arguing for the same state, and we’ve gotten off onto a sidebar about counterinsurgent, rural—

### Conspiracy Advocate (CA)
Claim: No—

### Scientific Advocate (SA)
Claim: —counterinsurgency—

### Moderator
Claim: All right, I’m going to—

### Scientific Advocate (SA)
Claim: —topics and so forth.

### Moderator
Claim: I’m going to go—Patrick, I’m going to go to some audience questions, now remember my rules about questions. I need them to have question marks at the end. We really want Will Not Succeed in Afghanistan and Pakistan” (10/6/09) them to be questions. And we would like them to be as close as possible to relevant to our topic tonight, ma’am?

### Moderator
Claim: My name is Michele Steinberg, I’m from Washington, D.C., with EIR News Service. First to Mr. Nagl and Cole, I have a two-part question, one…at a recent counterinsurgency conference at the National Press Club and also at the Kerry Committee, I think it was Mr. Biddle, they were talking about figures of 400,000 or 600,000 troops to carry out this counterinsurgency. On closer examination it was, a large part of those would be Afghanistan soldiers. But that is enormous, and we need a comment for this audience about that, secondly, Mr. Coll, what you defined as success, I’m rather stunned about. To prevent a government of the Taliban in Afghanistan…and to prevent nuclear weapons from falling into the hands of Taliban or al-Qaeda or Mumbai terrorists in Pakistan being the definition of success, is so minimal… that there must be many paths to that other than four to six—400 to 600,000 troops.

### Moderator
Claim: Okay, thank you—

### Moderator
Claim: Please comment.

### Moderator
Claim: Thank you, Steve Coll, take that question.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Scientific Advocate (SA)
Claim: Well, I think you’re right, I deliberately laid out what I thought the minimal US interests were, and I don’t think that anyone believes that 400 or 600,000 troops are necessary to achieve those, in fact, I’m quite sure that they’re not. Ultimately, it may be that the combination of Afghan soldiers and Afghan police required to provide Afghan-directed security to Afghans, will be in that range. But there’s certainly no need to fight a war, today, or any time soon with American or combined troops of that size. In fact that’s not the plan, the plan is to hold the footprint of the cities with a much smaller force, and to challenge the Taliban, preserve the Afghan state long enough to build Afghan security forces and police, that can in time under the direction of their own national leadership, complete this project, and, ultimately it will be Afghans themselves who’ll decide how many, what size army and police deployed in what way is necessary to provide the security they require. This figure, to answer it, I’m sure John’ll want to say it is a mathematical calculation that actually has no bearing on US planning or policy. It’s basically a ratio figure that some academics use to describe what is the ratio of troops to population that is ideally required, and I’m not even sure that it’s universally accepted as the correct ratio.

### Moderator
Claim: Sir, your question.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: Yes, my name is Dennis Cole, I’m neither from a news service or have any expertise in the subject so I find this very interesting.—

### Moderator
Claim: As long as it’s a question that’s okay.

### Moderator
Claim: It’s a question. I understand the arguments that you’re— that some of the sides have been making or one side have been making about the Karzai government that we’re supporting, or maybe we’re defending. Either we’re engaging in nation-building or we’re defending a government that might be corrupt, et cetera. But, from a, from just a layman’s perspective, I put myself in the shoes of the President of the United States. It seems to me that the question that the President has to answer, and the question that each of you have to answer, is, we are in the middle of a war, we do have threats. And, we, on one hand if we exit Afghanistan or if we pull back from Afghanistan and Pakistan, we in my mind would suffer— that we would increase the probability of attacks here in…in the United States, on the other hand, if we stay there clearly we’re going to continue to lose young Americans so you have, a loss of life—

### Moderator
Claim: I don’t mean to be rude, I just want you— That’s—I think where Will Not Succeed in Afghanistan and Pakistan” (10/6/09) you’re going—

### Moderator
Claim: So the question is if you had to make a decision between continuing to lose young Americans in Afghanistan and Pakistan to try to win, to try to succeed, or if you had to suffer the higher probability of losses here in America, what would you choose.

### Moderator
Claim: It’s a terrific question—

### Conspiracy Advocate (CA)
Claim: Yeah, can I get this—

### Moderator
Claim: um—

### Conspiracy Advocate (CA)
Claim: The Taliban did not attack us on 9/11. Look… You— again, we’re obsessing on real estate. This is a Leona Helmsley strategy. al-Qaeda’s not interested in real estate except as a place to duck and cover. We need to remember why we went to Afghanistan in the first place. Afghanistan, I disagree with Steve Coll, it’s not a nation, it’s an accident of where other people’s borders ended, and here’s the key thing to take away from this part of it. First of all, we’re very successful against al-Qaeda, and no one up here is arguing we have to pull out, it’s not either/or.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09) We’re—I’m arguing and others are arguing, do you want to get back to focusing on America’s enemies, which is much cheaper, more effective, and…just briefly. We are repeating the last war in Afghanistan. The surge, the surge. What happened in Afghanistan although the surge helped, was that al-Qaeda was a foreign invader. We were too. But al-Qaeda was so monstrous, that they alienated millions of Muslims. And when the Sunni Muslims decided that they were—al-Qaeda was a much more horrible and threatening foreign invader than we were, the game was won. In Afghanistan, the Taliban are the home team. Again, say what you want—

### Moderator
Claim: But Ralph—I think the—

### Conspiracy Advocate (CA)
Claim: People are dying—

### Moderator
Claim: —I think the question was, if the Taliban returns to hosting in their hotel, al-Qaeda, would we rather have—have the deaths there or here and I think it’s a good question—

### Conspiracy Advocate (CA)
Claim: Well, that doesn’t connect. That just doesn’t connect— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: Well, let me just—

### Scientific Advocate (SA)
Claim: Al-Qaeda was trying to—

### Conspiracy Advocate (CA)
Claim: Ralph, can we get another voice—

### Moderator
Claim: Let’s, let’s let Steve Clemons in—

### Conspiracy Advocate (CA)
Claim: Mullah—Mullah—wait one second, Mullah Omar was trying to get rid of bin-Laden for over a year before 9/11, Osama bin-Laden wouldn’t go, there’s a lotta bad blood. Don’t assume that the Taliban equals al-Qaeda.

### Moderator
Claim: Steve Clemons.

### Conspiracy Advocate (CA)
Claim: I think that it’s dangerous, and sometimes counterproductive to look at questions and just in binary terms, that either you stay and you produce outcomes, you leave and you produce great consequences. Sometimes those scenarios, there are probably, Steve Coll and I talk about this, six or seven different scenarios that, I think for the sake of the health of American society we ought Will Not Succeed in Afghanistan and Pakistan” (10/6/09) to talk about more systematically, in what you can achieve, but some things that I would put on the table because I respect all the gentleman on the other side is that sometimes, we look very blindly and with an interesting kind of confidence about the ability of the US military to sort of earnestly and proactively go and create and shape outcomes. But it reminds me of trade deficits in economics, where frequently we look at GDP growth, we tend to not look at the current account deficit. We tend to look at what we generate and we tend not to look at some of the negatives and draw down. And what I fear is that there’s a blind spot in a lot of this discussion, about the down-side consequences of the size of the military footprint, in places that are very, very hostile to the narrative of colonialism, control, and that we don’t think about other ways to achieve some of the goals we might want to do, and so the question is efficacy, and actually getting efficacious outcomes, what I said about Richard Holbrooke. I was in a briefing with Richard Holbrooke and I can’t talk about the substance of it, other than I can talk about, he is doing some absolutely fascinating things, in a whole broad variety of areas but one of the area’s in agriculture. Moving a lot of the poppy-growers into other areas. You can sort of look at transparent, tangible results, changing the sort of lives and direction but, let me tell you—

### Scientific Advocate (SA)
Claim: But Steve, what do you want to do though— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: —just quickly, let me—Jim, let me just finish. The Taliban today, are delivering to their people, and this is a problem for us, accountability in political management. Courts, property rights, security, trade, ombudsmen. They are miserable on human rights, you would never want to be a woman living in those areas, and I think that it’s a night— it would be a nightmarish life on other fronts but in terms of the priorities people have, they’re there. I talked to a Dubai businessman the other day who was telling me—

### Moderator
Claim: Steve, I want to—I want to bring Jim in—

### Conspiracy Advocate (CA)
Claim: Yeah. Well—

### Scientific Advocate (SA)
Claim: So what do you want to do, Steve. I mean I appreciate your encomiums for Richard Holbrooke—

### Conspiracy Advocate (CA)
Claim: I want to seriously pull back—

### Scientific Advocate (SA)
Claim: —I used to work for Richard Holbrooke—

### Conspiracy Advocate (CA)
Claim: Yeah— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Scientific Advocate (SA)
Claim: —at the State Department, and I have observed him in action. But what do you want to do. Do you want to split the difference? Do you want to muddle through?

### Conspiracy Advocate (CA)
Claim: So glad you asked—

### Scientific Advocate (SA)
Claim: What national interest do you want to achieve in Afghanistan and how are you going to do it—

### Moderator
Claim: Let him—let him answer, answer the question—

### Conspiracy Advocate (CA)
Claim: So glad I was asked, what I would like to see first of all is for the administration, the Obama administration to get itself all on one page, and decide what it is about and what it’s achieved—trying to achieve. That clarity has been absent. I think with all due respect to Barack Obama, whom I supported as well, Barack—the concern that many of our allies have had in this is that Barack Obama’s eye has not been on the Afghanistan ball since March. It is now. And I look for informed leadership, particularly since he’s reading Steve Coll’s book. But let me tell you what I said, I intimated some of the other things that need to be done. We need to make this not an Will Not Succeed in Afghanistan and Pakistan” (10/6/09) American war in Afghanistan, it needs other major stakeholders, and not just NATO.

### Scientific Advocate (SA)
Claim: There are—

### Conspiracy Advocate (CA)
Claim: If they don’t come in—

### Scientific Advocate (SA)
Claim: —there are 41 countries engaged in this fight with us—

### Conspiracy Advocate (CA)
Claim: I know, this is a George W. Bush line, but China’s not there, Russia’s not there, there is not the broad stakeholders that I think matter—

### Scientific Advocate (SA)
Claim: This is the broadest coalition in history—

### Conspiracy Advocate (CA)
Claim: It’s an important symbolic partnership, but when it comes to the substantive, pushing the needle on what’s going on—I don’t want to denigrate anyone else’s role--it is not enough. Again this is not about, sloganeering, it’s not about--that I’m trying to make an assessment that the kind of weight that you need, consequential weight, to basically try and create an equilibrium there, remains absent.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Scientific Advocate (SA)
Claim: There are 41—

### Conspiracy Advocate (CA)
Claim: And let me add—

### Scientific Advocate (SA)
Claim: —countries involved in the effort, to prevent al-Qaeda from returning to Afghanistan and to help the Afghan people…build a better life. 7 percent…

### Conspiracy Advocate (CA)
Claim: John, 41 countries—

### Scientific Advocate (SA)
Claim: Only 7 percent of the Afghan people support the Taliban, well over 50 percent of the Afghan people want the Americans to— and the international community to be providing them with security. The Afghans I’ve talked to don’t want Americans to leave, they want more of us there and they want us to do this better, and they in particular want us to build a big enough Afghan army, so that someday they can leave. They want us to leave, but not yet, because they know what would happen to them if we did.

### Conspiracy Advocate (CA)
Claim: John, there are 193 nations in the world— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: Steve, I have to stop—

### Conspiracy Advocate (CA)
Claim: —you can play numbers games—

### Moderator
Claim: — I just need to stop you because I need to do a little bit of a break for radio which will take about 20 seconds. I want to remind you that we’re in the question-and-answer section of this Intelligence Squared US debate. I’m John Donvan, your moderator, and we have six debaters, two teams of three who are debating this motion, “America Cannot and Will Not Succeed in Afghanistan and Pakistan.” And I want to go to the—there’s a woman who has already been…got the nod a little while ago— There you are. And…it’s a question, again, please.

### Moderator
Claim: Sorry. Are they ready? Yes, it’s a question, um, my name’s Tricia DeGennaro, I’m an adjunct professor here in the Global Affairs Department. And also this question is for both sides. I’ve been to Afghanistan quite a bit and thank you very much because you both hit very much on the complex issues that are going on there and the decision to stay or go, or transition out. So within that context, how do each of you look at the mission which has not been defined yet, look at how to Will Not Succeed in Afghanistan and Pakistan” (10/6/09) better the command and control and collaboration or coordination on the ground, and, either if we transition out or stay there, we are going to need a better civilian service team there, and that we’re lacking, so I’d like you all to talk about that—

### Moderator
Claim: Steve Coll, can you take that first?

### Scientific Advocate (SA)
Claim: Well, I’m—we’ve all read the McChrystal report, but we don’t really know the answer to that very important question. I have my own idea, I think actually the other panelists have some ideas that are probably not as wildly far away as some of our tones suggest since none of them wants to turn around and leave either. Certainly, the notion of supporting the constitutional Afghan state by allowing it to build its own security forces more successfully than we’ve done so far, and by supporting the efforts that are already underway through the United Nations, NATO and others to bring, to keep the educational system that’s been build in Afghanistan, I don’t know what the numbers are but, tens of thousands of girls and women are in school today in universities. You don’t have to go very far in Afghanistan to run into them and to be inspired. And the idea that this is irrelevant to our presence in Afghanistan or to our security, just strikes me as self-deceiving.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: Patrick Lang—

### Scientific Advocate (SA)
Claim: But you—can I just answer—

### Moderator
Claim: Yes—

### Scientific Advocate (SA)
Claim: —her question because she asked a very specific question—

### Moderator
Claim: Right—

### Scientific Advocate (SA)
Claim: —about American civilian capacity, it’s a problem. The—Hillary Clinton has come into the State Department and beaten every drum that I think she knows how to find to get the American civilian partnership that is called for in common sense as well as in counterinsurgency doctrine, better present in Afghanistan. And I think…she’s going slower than she wants, but, everyone who’s involved says within a year there really is an opportunity to improve performance, I hope so because it is a critical question, I’m glad you asked it.

### Scientific Advocate (SA)
Claim: If I could just say— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: I want to bring Patrick Lang in here, we haven’t heard from him in a while.

### Conspiracy Advocate (CA)
Claim: Yeah. The, I think there’s room, considerable room for agreement here, I mean I agree with Steve Coll’s idea that the—be a good idea to withdraw to the major footprint of the major towns. And because—but to try to improve the countryside across Afghanistan is I think a visionary idea, as I’ve expressed before. But within those enclaves which contain a large part of the population, you know, you can do all these things that people want to do that are, are good and worthy projects such as the education of women and the improvement of daily life, all that kinda stuff. But in fact, you know, someone said earlier that you can’t go after the bad people unless you’ve got good and sufficient human intelligence. Well, and that—you won’t be able to do that if they think you’re not going to pacify the country. Well I don’t—I’m sorry, I don’t believe that’s true, you know, I was in the business of running human intelligence for the Defense Department for a long time. And in fact the way that you recruit spies, is—a variety of inducements often based on their peculiar psychology, each and every person, you know. And it’s a question of applied psychology in the field. So, the fact that you couldn’t acquire people, if you had a number of bases around in Afghanistan you couldn’t acquire people that Will Not Succeed in Afghanistan and Pakistan” (10/6/09) you could use to penetrate enemy formations and then have enough troops on the ground, not the huge force of the troops, but some troops, augmented by the Afghan national army, and using a lot of these tribal guys, who don’t like the radicalism of the Taliban or Wahhabi-inspired, absolute kind of Islam that they don’t like, you know, you can go after enough of our enemies to disrupt them and keep them at bay, without having to try to take this whole country over, and to transform it into something that’ll be altogether different. I don’t—as I’ll say again—I just think that’s too big a task for us.

### Moderator
Claim: Have a—

### Conspiracy Advocate (CA)
Claim: At this time.

### Moderator
Claim: Question down in the second row, sir.

### Moderator
Claim: Hello, my name is Zack Clements and I’m a student at NYU. And we were actually discussing this issue in class today a little bit. And I wanted to ask a little bit more about your endgame strategy for— We’ve defined success in the most minimalist terms possible. In a survey of 127 different countries during the Cold War period it shows that, democracy and stability tends to decrease 20 to 25

Will Not Succeed in Afghanistan and Pakistan” (10/6/09) percent post-intervention by a superpower. After we leave eventually, what institutions are we actually leaving behind, to prevent similar instability that we saw for the past 50 years. And then in that same vein, to what extent is the war on terror in general, a relic of the Cold War, and is it necessary today for American security—

### Moderator
Claim: Okay, I—Zack, I’m going to not use your second question because it’s really not to our point although it’s a interesting one we’ll put into a future debate perhaps. But your, but your first question, what institutions may be left behind, I’d like to go—I assume you’re putting that to the side that’s arguing that we can succeed. And any member of that panel can step forward. John Nagl.

### Scientific Advocate (SA)
Claim: The McChrystal report advocates the creation of a very large and strong Afghan army in order to enable an American departure, leaving behind a stable Afghanistan that does not support terror, and that does not drag down the region, putting further burdens on Pakistan and the other neighbors. That Afghan army of some 250,000 which is roughly three times the Afghan army today is something we know how to build. This is not something we’ve worked to build to date. The Afghan army is undersized, only 80,000, about twice the size of the New York City police force. New Will Not Succeed in Afghanistan and Pakistan” (10/6/09) York City is a tough town, but Afghanistan is tougher, and a whole heck of a lot bigger. So, until we start—and by the way right now today as we speak, we are only providing 50 percent of the advisors to the Afghan national army that we say are required. We’re fixing that now, this is another one of the 4,000 additional troops President Obama sent back in March are just arriving in country now, the Fourth Brigade of the 82nd Airborne. So we need to build an Afghanistan that can survive without us, and we are starting that effort now. We are eight years into this thing, we frankly

### Moderator
Claim: But John, does that mean that you don’t actually know the answer to his question, what institutions

### Scientific Advocate (SA)
Claim: No, the—

### Moderator
Claim: —will be left behind.

### Scientific Advocate (SA)
Claim: The Afghan— the Afghan institutions will be the Afghan national army. That will be the single most important institution. It is today the most respected institution in Afghanistan— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: And—

### Scientific Advocate (SA)
Claim: --already.

### Moderator
Claim: And, and your teammate would like to come in as well. James Shinn.

### Scientific Advocate (SA)
Claim: Well, you know, we’re not really good at building institutions anywhere, as I think you pointed out in your question, and I concur with Dr. Lang on that point. But in the end the Afghans are going to do this. I mean, eight years is a long time, but it’s pretty fast to come from basically devastation… three decades of destruction, at the hands of various invaders, to actually hold an election themselves. I mean it’s pretty amazing, and when you travel through the provinces and towns of Afghanistan, and you see what was there before, and you see what’s there now…it’s— So that’s the answer, the Afghans are going to work it out.

### Moderator
Claim: Ma’am, down in front—

### Scientific Advocate (SA)
Claim: And they’re in the process of working it out and it’s very impressive—

### Conspiracy Advocate (CA)
Claim: —whoa, whoa, whoa—

### Conspiracy Advocate (CA)
Claim: This is not, I mean, honestly, the—

### Moderator
Claim: I—the problem is we’re about out of time—

### Conspiracy Advocate (CA)
Claim: our greatest legacy—

### Moderator
Claim: Steve—

### Conspiracy Advocate (CA)
Claim: —of our vision there—

### Moderator
Claim: Steve—

### Conspiracy Advocate (CA)
Claim: —is leaving the military—?

### Moderator
Claim: Can you save that for your summary remarks— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Conspiracy Advocate (CA)
Claim: Yeah, well—

### Moderator
Claim: Thank you. Ma’am.

### Conspiracy Advocate (CA)
Claim: Let me just say that would just be very bleak.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Well he asked the best question of the night, this is the question the President’s supposed to be asking himself—

### Moderator
Claim: But Ralph, you’ve—

### Conspiracy Advocate (CA)
Claim: And nobody else—

### Moderator
Claim: —you’ve answered it in advance a few times—

### Conspiracy Advocate (CA)
Claim: Yeah, but— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: Let me go—let me go to this—

### Conspiracy Advocate (CA)
Claim: No, nobody’s articulating the answer—

### Moderator
Claim: —let me go to this woman and—

### Conspiracy Advocate (CA)
Claim: Nobody is articulating the answer—

### Moderator
Claim: —and our last question, please. That’s a good question—

### Moderator
Claim: My name is Elsa Ross-Greifinger. And the only qualification I have is that I’m a United States citizen. And, I’m troubled by several things. Question. There has been so much emphasis on Afghanistan. I would like to know, your approach to Pakistan, which after all is a different country, and this lecture was supposed to be, this debate, about the two countries, and I have not heard very much about your approach to Pakistan. Secondly, there was an article in the International Herald Tribune today, talking about the fact that in Pakistan, they absolutely detest us, they want no part of us, and I would like to know how that problem also affects our approach.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: Thank you. That can go to both sides.

### Scientific Advocate (SA)
Claim: So… it’s a great—

### Moderator
Claim: Steve Coll, first, and you’re on the side arguing that America can succeed.

### Scientific Advocate (SA)
Claim: That’s a great question, American policy in Pakistan over the last 30 years has been a failure. And only now are we proving the value—the truth of Churchill’s quip that after trying everything else we eventually get it right. The Congress passed Kerry-Luger legislation last year making a long, deep commitment, not to the Pakistan army, but to the Pakistani people, to the Pakistani constitutional system, to pluralism and development in Pakistan, and for the first time we are send— our government is sending a clear and reliable signal that we intend to invest in the broader health of the Pakistani state and its future success. The standing of the United States and public opinion in Pakistan is low. It is unfortunately three times higher now than it was just a few years ago. I don’t think that’s the metric of our success. Our interests do not lie in being popular in Pakistan, our interests lie in Pakistan succeeding. And the biggest change in public opinion that’s Will Not Succeed in Afghanistan and Pakistan” (10/6/09) occurred in Pakistan during the last two years and it’s very recent has been the decision by broadly based, diverse Pakistanis to reject the violence, the nihilist violence, of the Taliban and al-Qaeda. They have been the victims, of this—of their own Frankenstein monster, and they’ve come to recognize that they will not live in a country, they cannot live in a country, that is influenced by these groups. The United States has an obligation and interest in supporting that momentum. In the end, that’s what allows us to protect our own security and ultimately exit from South Asia, so I don’t think it’s a popularity contest. It’s about the success of Pakistanis themselves and they’re well on their way, in a region where, by the way, India’s own success is already lifting Pakistan into new directions, creating new incentives for economic integration and regional stability.

### Moderator
Claim: And let’s hear from the side that argues America cannot succeed.

### Conspiracy Advocate (CA)
Claim: I think—

### Moderator
Claim: Steve Clemons—

### Conspiracy Advocate (CA)
Claim: I think what Steve Coll just shared is true, but there’s also another truth in Pakistan, where, you get equations like the ally of our ally Will Not Succeed in Afghanistan and Pakistan” (10/6/09) turns out to be our enemy. And to some degree, there was a time when I had lunch with the former head of ISI and I was late to the lunch like I often am and didn’t know it was the former head of

### Moderator
Claim: Can you tell the audience who ISI is.

### Conspiracy Advocate (CA)
Claim: ISI is the—what’s it stand for, the—

### Conspiracy Advocate (CA)
Claim: Interservice—

### Conspiracy Advocate (CA)
Claim: Interservice Intelligence, they’re the bad guys’ CIA in, they’re the intelligence services.

### Moderator
Claim: And you were having lunch—

### Conspiracy Advocate (CA)
Claim: And they’re off, they are rumored to have helped seed the terrorist groups in Mumbai and they are active with some elements of the Taliban. And I asked this general, I said does President Musharraf, then-President Musharraf control the ISI and this General Jurani told me that President Musharraf has a lot to gain by acting like he doesn’t. And, in that kind of world, it’s, as Will Not Succeed in Afghanistan and Pakistan” (10/6/09) Steve Coll knows better than anyone else, you have a problem where we’re not always quite sure where the security apparatus of that state is. And that regardless, and I agree completely that something interesting has been achieved in Pakistan, so let them have it. Let them become their own barriers to Islamic jihadism and the most extreme elements of their societies. And I think if you’re fair with Pakistan society they’ve done a fairly good job of keeping the minority extreme parties… Islamist parties have been kept a minority in their political system. Let that continue to percolate, I don’t think it’s quite as vulnerable at even the point where we were worried before the Swat offensive. So, to a certain degree that’s there but I also worry about the fact that, the ISI may be taking us for a ride again, where we don’t quite know when they’re going to push buttons that actually destabilize the situation. I think Steve is right to say we have an opportunity to maybe get a deal, a grand bargain. But I have some concerns about that, just given the behaviors we’ve seen, and our own lack of contact with a whole range of managers, colonels and majors, within the ISI today that maybe Pat Lang needs to go over and spend some time with but—

### Conspiracy Advocate (CA)
Claim: Again—?

### Conspiracy Advocate (CA)
Claim: —I have a lot of doubts about that equation and the stability of it.

Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: I the man in my ear has not spoken to me for a long time, it’s apparently dead, but I’m getting a hand signal, that we do have time for one more question. And And I’m getting hand signals to go…there. Okay. I’m not sure. Well, I’m going to choose so—

### Moderator
Claim: —right over there.

### Moderator
Claim: Oh, I’m—I apologize, there was a mic already there. I need to turn that—

### Conspiracy Advocate (CA)
Claim: We all know who he is.

### Moderator
Claim: I have a question for the cannot and will not side because what you’re essentially advocating, is a counterterrorism strategy using long-range strikes to kill terrorist leaders in Afghanistan and Pakistan. Now as you know, Stan McChrystal—

### Conspiracy Advocate (CA)
Claim: No.

### Conspiracy Advocate (CA)
Claim: No, no, that’s not what we’re advocating— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: —was in charge of the Joint Special Op— Isn’t that what you’re advocating, Ralph, when you say—

### Conspiracy Advocate (CA)
Claim: No.

### Moderator
Claim: —kill them and get out?

### Conspiracy Advocate (CA)
Claim: I—where did I ever say kill them and get out. You show me one place. One of my books, one article, one TV show, when did I say that. That’s just nonsense. What I said was what—Joe Biden’s saying. That we need a small, lethal force focused on our enemies. Of course we need boots on the ground—

### Moderator
Claim: Well that’s, Ralph, if I could ask my question, that’s basically what’s known as a counterterrorism strategy—

### Conspiracy Advocate (CA)
Claim: Yeah—

### Moderator
Claim: —that’s the alternative to the counterinsurgency strategy that the other side is advocating. My question is, as you know, Stan McChrystal was our top counterterrorist, he was the head of the Will Not Succeed in Afghanistan and Pakistan” (10/6/09) Joint Special Operations Command, from 2003 to 2008. He was the guy who was out there in charge of the forces that were capturing Saddam Hussein, killing Abu Musab al-Zarqawi. He knows more about our Special Operations capability than anybody else live. But he has conclude that all our counterterrorist capabilities are not capable of keeping us safe in Afghanistan and Pakistan and that we need to do—

### Conspiracy Advocate (CA)
Claim: That, that is not—

### Moderator
Claim: —a counterterrorism strategy. So my question for you, Ralph—

### Conspiracy Advocate (CA)
Claim: That—

### Moderator
Claim: —and the others—

### Moderator
Claim: want to hear what the question is—

### Moderator
Claim: My question is—

### Conspiracy Advocate (CA)
Claim: Yeah, what is the question— Will Not Succeed in Afghanistan and Pakistan” (10/6/09)

### Moderator
Claim: My question is, why do you have more confidence in our counterterrorist capabilities than our top counterterrorist general.

### Conspiracy Advocate (CA)
Claim: Well, for two reasons. First of all because, you’re mixing apples and oranges—

### Moderator
Claim: Do I get to answer this—?

### Conspiracy Advocate (CA)
Claim: General McChrystal was given a mission, by the President. And the mission was pacify Afghanistan. He succeeded wonderfully, in the counterterrorism. But he has failed miserably and we will continue to fail, in the pacification effort. Now, nobody—I hate this stuff where people twist what you say. I said that we need a compact, lethal force, you need boots on the ground for intelligence, you need Special Forces, you need enough conventional forces for raising security. You probably need 15 or 25,000 guys. You don’t need 120,000 guys, and so, again, let’s—please, let’s be fair to each other and listen to what the other persons say, and not try to score points. The other answer is this. I get calls from the military around the world. There’s a myth out there that the military supports General McChrystal’s strategy. The calls I get are running about 50 to 1 against sending more troops. Only call or message Will Not Succeed in Afghanistan and Pakistan” (10/6/09) I’ve gotten supporting General McChrystal’s strategy, came from Kabul, and one of General McChrystal’s subordinates.

## Round 3

### Moderator
Claim: And that concludes Round 2 of our debate. And, here’s where we are…we are about to hear brief closing statements from each of the debaters, they will be two minutes each, they will be uninterrupted and, this is their last chance to try to change your minds before we vote, and, to recall, before the debate began we asked you to vote, your stance on this motion which is “America Cannot and Will Not Succeed in Afghanistan and Pakistan,” here are the results of that preliminary debate…that preliminary vote. 48 percent of you were for the motion, 25 percent of you were against, and 27 percent were undecided. You will be asked to vote one more time, and pick the winner just a few minutes from now, but, now, Round 3, closing statements, and to close first, Steve Coll, president and CEO of the New America Foundation and a staff writer at The New Yorker. He is arguing against the motion, America cannot and will not succeed in Afghanistan and Pakistan.

### Scientific Advocate (SA)
Claim: Well thanks, I’ve enjoyed the evening and, I came here not very much interested in the debate and the competition but interested in the discourse and the moment in the country’s life and the opportunity to speak freely about how I see a very complicated Will Not Succeed in Afghanistan and Pakistan” (10/6/09) problem. And I think we’ve done that in a lot of good ways, so I hate to get sort of all technical and debatey on you but I would point out, that we actually more or less all six of us agree on the question before you which is, that we can succeed. What we disagree with—and we actually all agree on the definition of success, which is an America that’s safe from its enemies, a stable, region, where we have access to our enemies, and we tend to think that we need some kind of Afghan state, I think, nobody wants to leave so I take from their willingness to stay that they’re willing to stay in an Afghan state. Well that’s more or less the minimum interests and definition of success that I outlined at the beginning. What we’ve disagreed about are a lot of really important subjects that are now before the President, they’re just not before you. They’re basically whether or not we should send more troops, whether we should pursue a counterinsurgency strategy that emphasizes rural population security versus urban, whether we should invest in Afghan security forces or whether we believe in the plausibility of that project to different degrees. But the basic notion is that America does have vital interests in both countries, and that the failure of our efforts to stabilize this region and prevent Pakistan, for example, from falling apart, are important enough to take these risks, there are risks in every direction. And I think we’ve had a good conversation about where some of those risks lie, but the fundamental question, do we have a reason to be Will Not Succeed in Afghanistan and Pakistan” (10/6/09) there, can we through this kind of discourse find the right strategy to succeed, I think we’ve answered that question, all of us, thank you.

### Moderator
Claim: Thank you, Steve Coll. Making his closing statement, Patrick Lang, retired US military intelligence officer, a former Green Beret who is arguing that America Cannot and Will Not Succeed in Afghanistan and Pakistan, Patrick Lang—

### Conspiracy Advocate (CA)
Claim: Well I think we’ve moved on beyond that, the question of the day here. I don’t have any quarrel at all really with what Steve said there. This is really a question of strategy and methodology, rather than ultimate goals with regard to this place I think. And I would point out to you that I would maintain completely that if in fact we decided to do a countryside wide in the hot parts of Afghanistan, all the Pashtun, across the Pashtun Belt and some other places as well, I think that the costs are going to go up so high in all the various ways that I’ve said before, you know, that in a couple years’ time you’re going to decide that there is going to be an endgame, right, because it’s got to—because we’re going to leave. That’s going to be the problem, and that’ll be bad, in a way because, this place will continue to be a breeding ground for Islamic zealots who are in league with other Islamic zealots in other parts of the world and who are dangerous to us. So that shouldn’t happened, I would Will Not Succeed in Afghanistan and Pakistan” (10/6/09) propose in fact, instead that what we ought to do, is hold the major cities, make sure that, that the Taliban don’t have a seat in the UN again, and use these places as bases from which we can affect a strategy of in-depth human penetration of the groups we really don’t like, and the use of various dissident parts of the tribal population that can be used for our purposes and they can be used for our purposes, I—this is not an impossible thing to do. And have a certain number of troops on the ground that you can use for those kinds of purposes. Now, that would be a far smaller number of troops probably than we have. Now, in that kind of strategy it may well be that there’s not going to be an endgame, in fact. Because this place is going to be dangerous for a long, long time, people there are not going to change very quickly, although we’ll do everything we can to improve their lives if they— And it may be necessary to maintain a presence in that country for a very long time, in order to ensure that we can carry out the goals of protecting the American people, that we need to focus on.

### Moderator
Claim: Thank you. Thank you, Patrick Lang. Summarizing his position against the motion, John Nagl who is president of the Center for New American Security. John Nagl.

### Scientific Advocate (SA)
Claim: Pat has just described what to my eyes is the critical weakness of a counterterrorism strategy, which is that there is no end state, that Will Not Succeed in Afghanistan and Pakistan” (10/6/09) we’ll have to be there forever. And I believe that the American people deserve security, and that the Afghan people deserve security and that there’s a way to achieve that in a reasonable period of time with a reasonable commitment of resources. I have tried the counterterrorism strategy, I have tried to practice counterinsurgency without enough boots on the ground, in al- Anbar Province in 2004. I worked to train Iraqi police and Iraqi army, the insurgents killed them. I worked to build better economic opportunities for the Iraqi people, and they were destroyed by the insurgents. And so, much as we would like there to be an easy way out of this, if we ever want to depart Afghanistan and have that flank secure, with al-Qaeda never again able to use Afghanistan as a safe haven for terror, then there is an investment we are going to have to make. We have made an extraordinary investment already, and it is, frankly it is many of my friends, your sons and daughters, your friends who are out making that investment. The best chance for a positive return on that investment, a secure and stable Afghanistan, a secure and stable Pakistan. Objectives that all of us here agree are of vital national interest to the United States, but should be accomplished, and it is within the power of the United States to accomplish. It is my personal belief that the best way to accomplish them, is through a properly resourced counterinsurgency strategy that is the approach advocated by General McChrystal, it is hard, but hard is not Will Not Succeed in Afghanistan and Pakistan” (10/6/09) impossible.

### Moderator
Claim: Thank you, John Nagl. Our motion is “America Cannot and Will Not Succeed in Afghanistan and Pakistan” and summarizing for the motion, Steve Clemons, publisher of the political blog, The Washington Note, Steve Clemons.

### Conspiracy Advocate (CA)
Claim: America will not succeed in Afghanistan and Pakistan unless it gets its act back together both on the questions of management and strategy, both of which it has failed miserably in over the last eight years with regard to this challenge. The issue is not just Afghanistan and Pakistan, it’s the bigger picture, of what is going on in the United States, rewriting to some degree America’s place in the world in what I think is a historic moment of opportunity but discontinuity with the past. Barack Obama has a huge challenge. The mystique of America’s superpower status was somewhat shattered by Iraq, where other nations saw our limits, our military limits, our economic limits, and our moral limits. All of that has to be reinvented. And while I’ve heard great arguments from our colleagues on the other side, I have not seen a general understanding that we need to begin thinking about the sort of place and mission we have 20 or 30 or 40 years out. We haven’t Will Not Succeed in Afghanistan and Pakistan” (10/6/09) discussed nearly enough what alternative strategies might actually generate a better human-rights regime, better opportunities for women democratic rights that we’ve seen fail miserably I think in the recent elections, under our management. We were the stewards of that election that just unfolded, in great degree and to some—and I think no matter where you look, turned out to be quite a bad deal. And trying to restore America’s place and the sense that America has leverage over important global affairs, is really vital in dealing with nuclear nonproliferation. Iran, recreating some sense that we have consequence and weight. So it’s not just about Afghanistan and Pakistan, being stuck in the mud there, and not coming up, and just having a strategy that throws more troops at the challenge, without saying how can you get to some consistent level of benchmarks that are shared within a team both military and on the smart power side of the equation. Until that’s done, I can’t see in any way that sending more resources into that fixes those management mistakes.

### Moderator
Claim: Thank you, Steve Clemons. Summarizing against the motion, James Shinn, former Assistant Secretary of Defense for Asia, and National Intelligence Officer for East Asia.

### Scientific Advocate (SA)
Claim: I think Steve Coll said that, that we seem to be converging on agreement, across the room, that we have vital interests, and that Will Not Succeed in Afghanistan and Pakistan” (10/6/09) we can and will succeed in Afghanistan and Pakistan. We do disagree I think on the tactics, but that’s, again is not the real issue here. I think, looking out ahead that we are going to be having this debate, this national debate about the ends and means in Afghanistan and Pakistan repetitively, for some period of time. But I also think we have, the President has on his desk a fairly clear strategy, by about the best people we can think to do it. And execution matters…properly resourcing it matters, and signaling matters, to the Taliban, to the Afghans, and to the Pakistanis. I think the worst thing we could do, is simply split the difference, put in place some artificial metrics, that we can use to hold, for example the Pakistanis accountable, and simply allows things to drift. That would be the worst of all possible worlds. I think we can and we will succeed, in Afghanistan and Pakistan.

### Moderator
Claim: Thank you, James Shinn. And, finally to summarize for the motion, Ralph Peters, a former US, uh, Army lieutenant-colonel and author of The War After Armageddon. Ralph Peters.

### Conspiracy Advocate (CA)
Claim: When generals are out of ideas, they ask for more troops. It is stunning to me how little we’ve talked about our troops tonight. This isn’t abstract, they have to do it. Our troops are worn down, Will Not Succeed in Afghanistan and Pakistan” (10/6/09) the equipment’s worn down. But yet they will do anything we ask them to do. If the President asks them to stay in Afghanistan in increased numbers by God they’ll do it. But we should ask them to do sensible things. Sensible things. Missions that could be achieved. So let me leave you, the audience, with a few questions. If the Karzai government is worthy, why don’t Afghans support it. Why did they have to steal an election. If Afghans want us to stay, why are our casualties climbing dramatically. If as you heard Afghans are fighting, why must we send more troops. If international support is so dramatic, why must we send 40,000 more troops. If we cannot articulate the mission, and the end state, how dare we send more young men and women in uniform, because we won’t force ourselves to answer the fundamental question, of what— why are we there, and what, concretely, do we expect to achieve. So I will leave you, with a question General Petraeus asked several years ago about Iraq. Tell me how this ends.

### Moderator
Claim: Thank you, Ralph Peters. And that concludes our closing remarks and now it is time to learn which side you feel argued best, it is time for you to pick the winner. We’re asking you right now once again to go those keypads on the left side of your seat that will register your vote. And we are going to get the read-out almost Will Not Succeed in Afghanistan and Pakistan” (10/6/09) instantaneously, once again our motion is, “America Cannot and Will Not Succeed in Afghanistan and Pakistan”… To remind you before the vote…48 percent of you were for the motion, 25 percent of you were against the motion, and 27 percent were undecided, and as we said before the side that changes the most minds will be declared the winner. Okay, we’re going to lock out the keypads. And the results will be with us in just a second. In the meantime I first of all wanted to thank all of the questioners who actually…gave us things with question marks and they really moved the debate along. Thank you to all of you and to those of you who we did not get to, I apologize. But we’ll see you next time. And also thank you to all of our panelists for a terrific evening, well argued, honestly argued. Our next debate will be Tuesday, it’s October 27th, the motion will be, “Good Riddance to the Mainstream Media.” Panelists for the motion will be the host of Public Radio’s “The Takeaway,” John Hockenberry, executive editor of The Politico Jim VandeHei and Michael Wolff, Vanity Fair columnist and founder of Newser.com. Against the motion, executive vice-president and editor-at-large of the San Francisco Chronicle Phil Bronstein, columnist and reporter for the New York Times David Carr, and editor and publisher of The Nation, Katrina vanden Heuvel. All of our debates will continue to be heard on more than 190 NPR stations across the country, and, to that point, Will Not Succeed in Afghanistan and Pakistan” (10/6/09) when I announce the results, just to give the radio broadcast a very nice flourish, at one point my arm will come up and I would love it if you would applaud at that point, and the incentive is knowing that your applause will be heard on 200 NPR stations around the world. You can also watch the fall debates on Bloomberg’s television network and read about them in the next edition of Newsweek. Books by tonight’s panelists and DVD’s of past debates are also on sale in the lobby. All right, it is now in. I have been given the results and, remember that the team that changes the most minds is declared the victor, and here it is, before the debate, 48 percent were for the motion, 25 percent were against, 27 percent were undecided. After the debate, 43 percent are for the motion, 45 percent against, 12 percent undecided, the side against…is our winner. Congratulations to them, thank you for all of you from me, John Donvan, and from Intelligence Squared US.
