# Debate Transcript

Topic: Tough Interrogation of Terror Suspects is Necessary
Motion: Tough Interrogation of Terror Suspects is Necessary

Debate ID: ToughInterrogationOfTerrorSuspects-031108


## Round 1

### Moderator
Claim: Thank you and welcome, with me is Dana Wolfe, our executive producer. Well, tonight our resolution is, “Eliot Spitzer Should Resign.” Well—well, okay, we’re not quite that timely. But the issue of tough interrogation of terror suspects is also very much in the news. President Bush has just vetoed an act of Congress which would have limited the CIA to the same interrogation techniques as those approved in the Army Field Manual. But what do these limits amount to, what effect might they have on the information that we can glean about terrorist activity? Tough interrogation is not our euphemism for torture. But it does invite discussion about where to draw the line. And terror suspects are not routine criminals. The threats they pose are of a different nature entirely. The discourse on the subject has tended to conflate Abu Ghraib and Guantanamo and waterboarding, and the infamous Justice Department torture memo. We picture an administration running roughshod over Geneva Conventions, and our own historic traditions of civil liberties and human rights. More pragmatically, how much useful intelligence has actually been gained, and have the costs in terms of public support for our policies at home and our image as a nation abroad been worth it? On the other hand, it’s easy to forget that the Geneva Conventions are reciprocal agreements, giving rights to armed soldiers on both sides of a conflict. These rights are conditioned on soldiers wearing uniforms, in order to protect civilian populations from collateral damage, as much as possible. Well, how is this relevant to terror groups who don’t abide by Geneva principles, who don’t wear uniforms, and whose very purpose is to kill and maim civilians? CIA terror interrogation practices are hardly transparent. But military interrogations are governed by very elaborate legal and procedural safeguards. For the military, it’s highly problematic to impose on terror suspects the same physical hardships we use in training our own troops, or the same psychological stress involved in civilian police interrogations, or even the same degree of sleep deprivation experienced by young investment bankers at Goldman Sachs. We have a superb panel to help us sort out these issues. It’s my pleasure to introduce our moderator, Brooke Gladstone. Brooke is the award-winning host and managing editor of WNYC’s On the Media. Brooke, the evening is yours, and thank you very much—

### Moderator
Claim: Thank you. Thank you very much, Bob. So I’d like to welcome you all to the eighth debate of the second Intelligence Squared series. The resolution being debated tonight, “Tough Interrogation of Terror Suspects is Necessary.” Let me give you a brief rundown of the evening. It’s a really interesting format, members of each team will alternate in presenting their side of the argument, those presentations will be limited to seven minutes. When opening arguments are complete I’ll open up the floor to brief questions from the audience, and after the Q-and-A each debater will make a final two-minute summation. Finally, you’ll get to vote on tonight’s motion with the keypad attached to your armrest, and I will announce your decision on which side carried the day. But, let’s start with a pre-debate vote. Pick up the keypad attached to the armrest on your left… Looks like this. Close the buckle and secure it firmly around your waist when— no. For audience members sitting alongside the aisle on my right, your keypad is attached to the armrest on your right side next to your neighbors. Again, tonight’s resolution is, “Tough Interrogation of Terror Suspects is Necessary.” After my prompt, please press “1” to vote for the motion, “2” to vote against the motion, or “3” if you’re undecided. Vote now.

Everybody done? I will reveal the results of your vote later this evening, and now I’ll introduce the panel. Please hold your applause until all six are introduced. For the motion…retired Air Force lieutenant-colonel and military analyst for NBC News, Rick Francona. The John M. Olin Fellow at the Manhattan Institute and a contributing editor to City Journal, Heather Mac Donald. And a partner at Baker & Hostetler LLP and Visting Fellow at the Nixon Center who’s served in the Reagan and George H.W. Bush administrations, David Rivkin. Against the motion. 25-year veteran of the FBI and president of the global risk and crisis management firm Clayton Consultants, Jack Cloonan. Former Judge Advocate General of the Navy, President and Dean of the Franklin Pierce Law Center, retired rear admiral John Hutson. And professor of political science and Chair of the Political Science Department at Reed College, Darius Rejali. Okay. And now we’ll start the debate—for the motion, Heather Mac Donald.

### Conspiracy Advocate (CA)
Claim: Thank you very much. I will argue that stress interrogation techniques are both necessary for getting information from suspected terrorists after 9-11, and effective in doing so. I will base my arguments on the actual experience of interrogators in Afghanistan and elsewhere. This is not a debate about torture. The stress methods that interrogators developed, such as short periods of sleep deprivation and isolation, were light years from torture. And to call them such, degrades the moral opprobrium that rightly attaches to the term. As my colleagues will demonstrate, the use of stress techniques on terrorists is lawful. The burden therefore falls on our opponents, to explain why legal and essential methods to gain critical information about future terrorist attacks should be off-limits. It didn’t take long for interrogators working in Afghanistan, to realize that the traditional army interrogation techniques were nearly useless against the Al Qaeda operatives and Taliban fighters whom the military was picking up in the fall of 2001. Those traditional techniques, a set of 16 psychological gambits assembled during the Cold War, were designed to help young Americans, soldiers, debrief Soviet prisoners of war on the battlefield. The 16 gambits have been crafted for use against conventional soldiers, lowly grunts, conscripted into a state army, who are often only too glad to be taken off the battlefield and out of the war. Army lore held that 95 percent of lawful prisoners of war would divulge information upon direct questioning. In Afghanistan, this ratio was reversed. Virtually none of the terror detainees was giving up information. Tried-and-true approaches, like appealing to a prisoner’s love of family, often had little purchase. If an interrogator offered a jihadist prisoner contact with his wife or children, in exchange for information, the jihadist might respond, quote, “I’ve divorced this life. I don’t care about my family,” end quote. Unlike lawful prisoners of war, the terror detainees were never off the battlefield. They continued their vicious attacks against their captors at every opportunity while in detention. Some of the detainees had been trained in resistance techniques, and knew the limits of American interrogation rules. Others quickly learned what those limits were. So the interrogators began cautiously experimenting with stress techniques, such as marathon questioning sessions or aggressive behavior, to put a detainee on edge. The purpose of such methods was to recreate the shock of capture, that vulnerable mental state immediately following capture, when a prisoner is most frightened, uncertain, and likely to give up information. Uncertainty is an interrogator’s most powerful ally. It can lead the detainee to believe that the interrogator is in total control, and holds the key to his future. An interrogator facing a resistant Taliban explosives-maker, for example, might angrily hoist the prisoner up by his collar, and storm out of the interrogation booth. The detainee had previously understood that American interrogators couldn’t so much as lay a finger on them. Suddenly, he doesn’t know what the interrogator’s limits are. That frightening uncertainty can change his calculations about whether to cooperate. According to interrogators in—in Afghanistan and Guantanamo, stress worked. The harsher the methods that the questioners used, the sooner they got good information. Eventually, the military codified a set of stress techniques for use in Guantanamo and Iraq. These included keeping a detainee awake at night, putting him on cold Army rations instead of hot meals, isolation, environmental manipulation, and impersonating a foreign agent. All were hedged round with numerous bureaucratic and medical safeguards. None of the stress techniques that the military approved for use on terror detainees had anything to do otherwise with Abu Ghraib. Abu Ghraib was the result of the unconscionable and culpable breakdown of military discipline, throughout the detention camp. Soldiers sprayed graffiti on the walls, engaged in public sexual misbehaver, and operated bootlegging and prostitution rings. Elliot Spitzer is not known to have used any of them. The guards’ sadistic and sexualized treatment of prisoners was an extension of the chaos they were already wallowing in. It had nothing to do with interrogation. Had the rules for prisoner treatment and questioning been followed at Abu Ghraib, the abuse couldn’t have happened. In conclusion, the stress interrogation techniques that interrogators developed to break detainees’ resistance, were necessary, effective, and lawful. They were far from torture. In certain instances as—as Bob said, they resembled what army recruits and professionals go through as part of their training. As a reality check, here’s the Senate’s definition of torture. It is that barbaric cruelty which lies at the top of the pyramid of human rights misconduct—such as sustained systematic beating, application of electric currents to sensitive parts of the body, and tying up or hanging in positions that cause extreme pain.

It would be reckless to ignore the experience of interrogators on the ground, who came up against detainee resistance that was potentially catastrophic in consequence. Intelligence about terror planning is our only sure defense against attack. Nothing else matters. Interrogators facing the urgent need to get life-saving information from terrorists with likely knowledge of future plots, should be allowed to use stress when the questioning techniques designed for lawful prisoners of war are not working. Thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: It would be reckless to ignore the experience of interrogators on the ground, who came up against detainee resistance that was potentially catastrophic in consequence. Intelligence about terror planning is our only sure defense against attack. Nothing else matters. Interrogators facing the urgent need to get life-saving information from terrorists with likely knowledge of future plots, should be allowed to use stress when the questioning techniques designed for lawful prisoners of war are not working. Thank you.

### Moderator
Claim: Against the motion, John Hutson.

### Scientific Advocate (SA)
Claim: Thank you. Gee, it all sounds so…sweet and benign. Uh…ask ‘em a few questions, have ‘em stand up for a while, you know…make them take their shirt off, get ‘em a little cold maybe. 300-pound Iraqi general… stuffed in—head-first—into a sleeping bag, bound up with electrical wires, sat on by a Army warrant officer… Hand put over his face every time he screamed out for Allah… Released, put back in, died. Dead. That was a stress position. Guy was prosecuted, got six months for some orders violations, but, basically, was released because it was an authorized stress position. Taxi driver Dilawar, hung from the ceiling, by his wrists. Five days after he’s—not captured, but turned over, turned over, to American forces in exchange for a ransom, beaten to a point where, according to the autopsy, by an Army doctor, his legs are pulpified. Dead. By the DOD’s own count, approximately 40 people have been killed in the hands of the United States, in detention, as homicides. So let’s not kid ourselves that this is some sort of benign search for the truth. Torture was never intended to be that. Torture was intended originally, to be an effort to get false confessions. You’re a heretic, you’re a traitor to the king, you’re a witch. We’ve given a bad name to torture. We’ve misapplied torture, we’re trying to use it to find the truth, for Pete’s sake. My experience has been, in doing these kinds of things and these—with these kinds of groups, that there are a number of people who have a number of different points of view about it. Some of you are moved by history, tradition…some of you are moved by the morality of it, the moral imperative. Some of you are moved by diplomacy. Some of you are simply moved by the practicality of it. Are there better methods, or is this the best method. What I want to do is address six aspects of torture, or, benign interrogation, whatever you want to call it, stuffing people in sleeping bags head first and binding them up, and then give each of you the opportunity to pick the one that you kind of think works, and then my colleagues will hone in on some of them. First one is that it inflames, enrages the enemy, and causes them not to surrender. There’s a reason the Nazis surrendered to the Americans on the Eastern front and not to the Russians. In the first Iraq war, tens of thousands of Iraqis surrendered to us because they knew that they would be treated decently. My friends, they’re not surrendering to us anymore. It endangers our own troops. We’re the ones on the front lines. It’s the—it’s US troops at the pointy end of the spear, forward-deployed in more locations on more occasions in greater numbers than all the other forces of this world combined. There is a reason that the United States wanted there to be a Geneva Convention, it wasn’t to protect them from us, it was to protect us from them. And we’ve lost that. John McCain said, that he believes he was treated incrementally better because the Vietnamese knew—North Vietnam knew—that we were abiding by the Geneva Conventions in spite of the fact we didn’t have to. According to the arguments, based on the same rationale that the administration uses now. It interferes with our ability to build coalitions, in the future wars are gonna be fought by coalition forces. The United States should not and cannot go alone. We were just put on the list of human-rights violators by Canada. We got them to take us off, but the point is…Canada, the Aussies, the Brits, aren’t going to want to fight with us if they can’t expect us to comply with the Geneva Conventions, and we’re going to be out there at the pointy end of the spear, all by our lone. It causes Americans to become torturers. It’s one thing for us to send our good men and women into battle and ask them to give that last full measure of devotion. It’s another thing to send them into battle and ask them to become torturers and come home that way. Fifthly, it’s simply not the most effective method. People say, “Does torture work?” Torture-, does torture work isn't the right question. The question is, is there another more effective way to do it. Let me quote to you from, say, General Petraeus, who one would think would know something about it. Some may argue that we would be more effective if we sanctioned torture or other expedient methods to obtain information from the enemy. They would be wrong. Beyond the basic fact that such actions are illegal, tort history shows that they are frequently neither useful nor necessary.

The fight depends on securing the pop-, boy, that went fast. I just…

…got into this. The fight depends on securing the populations, which must understand that we, not our enemies, occupy the high moral ground. And then finally, and I’d like to return to this, because I think it’s, if I get another chance, I think it’s the most important issue. This is an asymmetric war. In an asymmetric war you want to, you want to pit your greatest strength against the enemy’s greatest weakness. Fortunately, in this war, that works for us, if we will do it. Because our greatest strength is our ideas and our ideals. The enemy is completely bereft of ideas and our-, and ideals. Thomas Paine said in 1776, “The cause of America is the cause of all mankind.” Several hundred years later, that great geopolitical commentator Bono said America isn't just a country, it’s an idea.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: The fight depends on securing the pop-, boy, that went fast. I just…

### Scientific Advocate (SA)
Claim: …got into this. The fight depends on securing the populations, which must understand that we, not our enemies, occupy the high moral ground. And then finally, and I’d like to return to this, because I think it’s, if I get another chance, I think it’s the most important issue. This is an asymmetric war. In an asymmetric war you want to, you want to pit your greatest strength against the enemy’s greatest weakness. Fortunately, in this war, that works for us, if we will do it. Because our greatest strength is our ideas and our ideals. The enemy is completely bereft of ideas and our-, and ideals. Thomas Paine said in 1776, “The cause of America is the cause of all mankind.” Several hundred years later, that great geopolitical commentator Bono said America isn't just a country, it’s an idea.

### Moderator
Claim: Ok, thank you. For the motion, David Rivkin.

### Conspiracy Advocate (CA)
Claim: The critics invariably portray, as you just heard now, waterboarding and other stress techniques as torture. I would stipulate easily and readily that waterboarding and other stress techniques is a fairly unpleasant practice. It offends our 21st century sensibilities. It’s something that’s difficult to talk about. But I also believe we’re at war with an implacable and ruthless foe that thinks nothing about killing civilians by the thousands and is seeking to kill millions more. I don't think anybody would disagree about obtaining intelligence is vital in this war. And we can debate, theoretically, the proposition that other techniques work, but it’s a matter of fact. There are instances where hardened anti-operatives did not prove susceptible to these kinder, gentler techniques, and yet provided intelligence when they were subjected to stressful interrogation techniques. But my overarching message to you is that this is a policy debate. It should be a policy debate, which is why asking the question that has been posed today is useful. The obsession of legalities is not helpful. The legal definition of torture is necessarily vague. The torture defined in the ’94 statute which was passed to implement obligations under an anti-torture convention, as quote, “Intentional infliction of severe pain or suffering, both physical and mental.” Much of the legal debate about torture boils down to the question of how severe is severe. As far as the physical pain and suffering is concerned, it’s almost certainly the case that some forms of waterboarding have been practiced by the CIA on only three occasions that we know of, with three different high-value detainees, rise to the level of torture. And some probably, particularly those that did not involve full inundation of the subject do not. The reason for this is because the physical discomfort suffered by the subject of-, being subjected to this technique while was not severe enough. As far as the mental severe pain and suffering is concerned, it bears emphasizing that Congress deliberately adopted a narrow definition of the term “severe” to encompass only, and I quote, “prolonged mental harm caused by or resulting from the threat of imminent death or mind altering substances.” In my view waterboarding and other techniques practiced by the CIA do not fit this definition for at least two reasons. First of all, the practice of waterboarding used by the CIA was extremely short, sixty to ninety seconds, which certainly suggests even to our lawyer that it’s not protracted. Significant to the question of what is, what constitutes protracted was further debated by Congress in 2005 and 2006 in the context of two key pieces of legislation when Congress handled-, and once again, the answer was that there has to be some duration, some timeline for something to be considered protracted. Second, the high-value terrorist being interrogated are perfectly aware that they’re not in any danger of death, that the CIA was after information, their lives were not in danger. When Congress passed in the Detainee Treatment Act something called “shocks the conscience standard”, which makes it even harder to argue that these techniques are always, inherently, and absolutely torture, because the shock, shocks the conscience standard, by definition-- and it’s something that borrows from American case law-- it is inherently a context- specific standard. It is not something that you would be able to answer in the abstract. It’s also worthy to point out that while the original Justice Department so-called “torture memo” was perhaps overly broad in its definition of what level of pain and suffering constitutes torture, lots of legal council came up with some more nuanced analysis. Significantly, ladies and gentlemen, this analysis was developed by lawyers, at least some of whom where critical of the administration’s policy. Indeed, as reported in the media, including by Stuart Taylor of the National Journal, the lead author of the subsequent memo by OLC on this issue was none other than senior DOJ official Daniel Levin, who himself had been subjected to waterboarding as a part of his research. I know that trusting the gallowman is not an argument most of you like these days, but I would certainly be inclined to trust Dan Levin, who by the way was reportedly forced out by Alberto Gonzales for not being sufficiently solicitous of the White House positions on various other issues. Now, presented with this argument, the critics claim, “Well maybe it’s not torture, but maybe it’s cruel inhuman degrading treatment”, which is another set of legal buzzwords. Yet cruel, inhuman and degrading are even more capacious terms than torture. For some detainees, the mere fact that they’re being questioned by a Jew or a woman is an intolerable humiliation. Are we supposed to countenance and approve this kind of racist sentiment? Meanwhile, it’s also the case that there has to be some reasonable definition of what is cruel, inhuman and degrading, because I would submit to you that there is a degree of humiliation, cruelty, and degradation in any kind of custodial interrogation. There’s yelling, there’s screaming. Threats are being made against a person or his loved ones. Andy Fastow of Enron fame was told by his interrogators that his wife would be imprisoned for a long time, and I would submit to you that it was probably a cruel treatment. So there has to be some parameters of behavior that’s clearly-, is cruel and degrading and humiliating, but yet does not violate the law. My bottom line is this: while the waterboarding debate implicates legal issue, we cannot simply abandon the field to the lawyers. The lawyers have no special right or expertise to deal with those issues. So our duty as a society is to approach these debates seriously, in a mature fashion. To ask what is really consistent with our values. Incidentally, we’ve talked about mistakes. My good friend John mentioned mistakes. And yes, shoving somebody’s head in a sleeping bag is not a good thing. But as you may recall, these problems occur in other contexts. When I was at the Justice Department, one of my responsibilities was investigating various bad things that happened in the Bureau of Prisons. And let me assure you ladies and gentlemen, in a situation when there is no blessing for stress techniques, instead in fact-- prisoners in federal and civil and state penitentiaries not being interrogated at all have…

…fellow prisoners who commit horrible things. You have sadistic guards who do horrible things. Recently I had a case in Florida…

…involving mistreatment by the guards of a child in a boot camp, where he was basically smothered and suffocated in the course of trying to set him straight. This is not an easy debate. We should not focus exclusively on the question of how to deal with enemy combatants. We should ask a broader set of questions of what level of coercion are we prepared to tolerate in our public policy, something that our government is doing. We should not come up with one set of regimen for captured unlawful enemy combatants when we waterboard our own personnel. Then there are things going on other spheres of public life, including as I mentioned, in boot camps that are harsh. And--, but the last point is whatever we do, we should be honest and transparent about this debate. We should not use misdirection. We should not talk in terms of, “Well let’s adopt the same standards as an Army field manual.” Because ladies and gentlemen, the Army field manual, by the way, allows the level of “Mutt and Jeff” technique that does not allow the interrogator playing the bad cop to be disrespectful, to be tough on an individual. So here we have politicians advocating the level of kindness towards the unlawful enemy combatants that exceeds that that’s been adopted with regard to interrogation of criminal suspects. That is not…

…the good way to deal with this issue. Thank you.

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …fellow prisoners who commit horrible things. You have sadistic guards who do horrible things. Recently I had a case in Florida…

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: …involving mistreatment by the guards of a child in a boot camp, where he was basically smothered and suffocated in the course of trying to set him straight. This is not an easy debate. We should not focus exclusively on the question of how to deal with enemy combatants. We should ask a broader set of questions of what level of coercion are we prepared to tolerate in our public policy, something that our government is doing. We should not come up with one set of regimen for captured unlawful enemy combatants when we waterboard our own personnel. Then there are things going on other spheres of public life, including as I mentioned, in boot camps that are harsh. And--, but the last point is whatever we do, we should be honest and transparent about this debate. We should not use misdirection. We should not talk in terms of, “Well let’s adopt the same standards as an Army field manual.” Because ladies and gentlemen, the Army field manual, by the way, allows the level of “Mutt and Jeff” technique that does not allow the interrogator playing the bad cop to be disrespectful, to be tough on an individual. So here we have politicians advocating the level of kindness towards the unlawful enemy combatants that exceeds that that’s been adopted with regard to interrogation of criminal suspects. That is not…

### Moderator
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: …the good way to deal with this issue. Thank you.

### Moderator
Claim: Thank you. Against the motion, Darius Rejali.

### Scientific Advocate (SA)
Claim: All of us on both sides want good counterterrorism policy. Heather, David, John, all of us want to be safe. They just represent different fears. I’m here to represent the facts, not their fears. I have been working for 30 years on torture, on not- torture, and everything I’m about to say is in that 900-page book in the lobby. Bottom line, good torture is not good counter-terrorism policy. As the fascist military police said, torture for interrogation is, and I quote, the “clumsiest method,” and only a, quote, “fool” would use it. And this is from their interrogation manual from Burma in 1943. Now I don’t care whether you call it torture, tough stuff, muffin stuff, not torture. The only question really is, as you say, whether it gets the bad guys, and here is where everybody gets into storytelling--you’ve heard a few. I have one too. A World War II vet came up to me after a lecture and he said, in France, we caught this German soldier and we pulled a knife to his throat and said, where are the other soldiers. And I said, did you get good info? And he said yeah, sorta. I said I’m happy for you, I really am. I really am. Because if you had bad info, you’d be dead. You would be dead. The problem is that everyone who knows that torture or not-torture doesn’t work, is dead. For those for whom it works, they are walking around saying it worked for me, it worked for them, if… This is what we call in social science a biased sample. If you take real data from the best studies, armies using torture who carefully and selectively selected suspects, eighty—8,000 to 20,000 minimum is what you need to get the best-case scenario, and the best-case scenario that they manage to generate out of these cases is 20 to 78 innocent people had to be tortured for each bad guy they got. 20 to 78 innocent people for each bad guy. Now, for every accurate piece of info then you have to torture in the thousands if you’re professional about it— this is not retail business. This is wholesale. So you tell me, does torture work? I’ll give you the opinion of the professional Gestapo. In 1942 the Czech resistance assassinated Reinhard Heydrich, Reichsprotector of Czechoslovakia, Hitler wanted results, he didn’t care how, he said these guys don’t listen to anything, and the Gestapo got the three bad guys but to do that they tortured and killed 7,545 individuals, annihilating two villages. They also got 100 resistance members on the side they weren’t looking for but that’s pretty typical results, Battle of Algiers, Vietnam, we can go through them. At this point, enter Heinz von Panwitz, a career policeman and head of the Gestapo’s anti-sabotage unit from Prague, he said don’t be stupid. Depend on public cooperation, build up rapport, put out a reward. They got over a thousand tips and in fact what broke the case, what broke the case, was when Korda, a member of the Czech resistance betrayed the entire operation. Korda wasn’t tortured, he lived well, he collected a huge reward, in fact he lived long enough to be executed for treason after the war. The professional Gestapo repeatedly decimated the resistance through public cooperation and informers, in France, Denmark, Poland, Norway, Russia, Austria, Czechoslovakia, even in the concentration camps. The Gestapo turned to torture when they lost seasoned pros like Panwitz during the war. And then they had young men with whips running around and why learn good policing when you’ve got a whip. Huge government funded studies, our government-funded studies, have proven Panwitz was right. If you don’t have public cooperation the chances that a crime will be solved falls to 10 percent. Pathetic results. The Gestapo knew public cooperation was the best anti-terrorist method. Public cooperation works even when time is short. July 21st, London, seven guys get on buses with ticking bombs. The British police got all of these guys in 10 days, and the ticking bombs. The big break came in 24 hours when the parents of Mukhtar Said-Ibrahim turned their son over after seeing the security video. These were loyal British Muslims. Would they have turned their son over if they knew he was gonna be—not- tortured? The answer is no. Good torture isn’t just a source of bad intel, it destroys the only thing that really works, public cooperation. Good rapport weakens even the strongest bond we know, good rapport…restores the bond between parent and child. Even when time is short. Using these techniques during World War II, the British managed to catch 290 German spies hiding among 42,000 refugees crossing over from Europe without torturing any of them. I don’t split hairs over what torture is and what is not torture. If what makes torture moral or not-torture moral, if it saves innocent lives then the truth has to be that torture is immoral. Because it takes far more innocent lives than it has ever saved, and that’s true for not-torture. Actually, some not-torture we use is even worse than torture. Take sleep deprivation. We use it all the time. Professional Spanish Inquisitors, professional Spanish Inquisitors, wouldn’t go near it. They knew sleep deprivation has hypnotic effects under repeated questioning, people will generate visions. Perfect for seeing packs of the devil and Al Qaeda everywhere. That’s why crazy Scottish witch-hunters used it. It was very effective. But that’s them Protestants, not—a Catholic inquisitor would not go near this, quote, not-torture. They knew it was unreliable, and yet we use it all the time as if it gets magical results, well it is, it’s magical thinking. That’s all it is. Good torture creates bad intelligence, involves torturing thousands of innocents, while the terrorists run free. It destroys our soldiers who are forced to put in these positions we have the studies, and the organizations. And limited time makes all these effects worse, not better. That’s the data. The professional Gestapo knew this. The Japanese Kempei Tai knew this. Even occasionally a Spanish Inquisitor figured this one out.

With great respect, why shouldn’t we not learn from them. Good counter-terrorism policy depends on winning public support and building up human intelligence. Look. I used to be on the other side. I grew up in Iran under the Shah. The Shah’s SAVAK tortured terrorists, and the Shah said I don’t torture, we just have different ways of doing that, we have to be tough on these medieval radical throwbacks. They’re different. And Khomeini said, medieval throwback, now look who’s talking, the guys who torture. Nothing was a better recruitment tool for Islamic radicalism than not-torture. And so the question is, how many countries in the Middle East do you want to lose? How many witch-hunters do you want to follow. There is intelligence out there. It is time, it is really long past time for us to get our act together. Thank you.

Oh, thank you.

You know…ticking time-bomb scenarios are wonderful stories, it was actually in a wonderful novel from World—from the French Algerian story, it’s a wonderful fantasy novel, never happened. But I will tell you this. My book shows this. Ticking time scenarios--if you want to torture under those circumstances, do you know what the best result—when it’s gonna get you the best result? During peacetime non-emergency situations, when you need it least. It’s—

In other words, torture doesn’t work in wartime situations when you have a ticking time bomb, you have to do—it’s a volume business at that point. It is not a retail business.

Look, there was a ticking time bomb in World War II in England, right? Those guys who got off the buses, had a ticking time bomb. It was sitting in the bushes in Brighton, outside a jail. The British got it, because they had public cooperation. And if you want to torture, fine, but you’ll not find that bomb.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: With great respect, why shouldn’t we not learn from them. Good counter-terrorism policy depends on winning public support and building up human intelligence. Look. I used to be on the other side. I grew up in Iran under the Shah. The Shah’s SAVAK tortured terrorists, and the Shah said I don’t torture, we just have different ways of doing that, we have to be tough on these medieval radical throwbacks. They’re different. And Khomeini said, medieval throwback, now look who’s talking, the guys who torture. Nothing was a better recruitment tool for Islamic radicalism than not-torture. And so the question is, how many countries in the Middle East do you want to lose? How many witch-hunters do you want to follow. There is intelligence out there. It is time, it is really long past time for us to get our act together. Thank you.

### Moderator
Claim: Before we begin the discussion part of this debate, I have a question for each side. And Darius, I’ll direct this to you.

### Scientific Advocate (SA)
Claim: Oh, thank you.

### Moderator
Claim: No exceptions. We’ve all heard about the ticking-bomb scenario, a moment is precious; we need that information right away. If you agree that there can be exceptions, then where do you draw the line?

### Scientific Advocate (SA)
Claim: You know…ticking time-bomb scenarios are wonderful stories, it was actually in a wonderful novel from World—from the French Algerian story, it’s a wonderful fantasy novel, never happened. But I will tell you this. My book shows this. Ticking time scenarios--if you want to torture under those circumstances, do you know what the best result—when it’s gonna get you the best result? During peacetime non-emergency situations, when you need it least. It’s—

### Moderator
Claim: I don’t understand.

### Scientific Advocate (SA)
Claim: In other words, torture doesn’t work in wartime situations when you have a ticking time bomb, you have to do—it’s a volume business at that point. It is not a retail business.

### Moderator
Claim: I still don’t understand, if you have the ticking bomb, whether it’s wartime or not, and you know—somebody knows that there is—

### Scientific Advocate (SA)
Claim: Look, there was a ticking time bomb in World War II in England, right? Those guys who got off the buses, had a ticking time bomb. It was sitting in the bushes in Brighton, outside a jail. The British got it, because they had public cooperation. And if you want to torture, fine, but you’ll not find that bomb.

### Moderator
Claim: And now, to this side. David?

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: American leadership and our security, I think we can all agree are based at least in part on our alliances. And if America is seen as a—is seen in its interrogation methods as a renegade, as it has on such issues as say the ABM treaty and the Kyoto accords, won’t that endanger our leadership role, and thus our security, if we lose that moral high ground and that leadership?

### Conspiracy Advocate (CA)
Claim: Brooke, we certainly pay a high price for it but a couple of things need to be mentioned, first of all unfortunately the critics that promiscuously lump together, the kind of ordinary yelling, spittle-flying, psychological pressure, modest, sleep deprivation, and label it with the T word, are contributing to this problem. The notion that we as a society cannot draw nuances, cannot draw distinctions between a tough treatment, which my colleague Darius here referred to as non-torture and true torture, is frankly silly because that’s not what we do in ordinary life. In any other difficult issues. But more important than that, I am not convinced, I’ve heard this argument many times, I’m not convinced, Brooke, that the alleged… price we’re paying for this aspect of our policy, is sort of a but-for problem. There’re so many other things, that unfortunately our friends and allies do not like because they don’t take the threat of radical Islam seriously, they don’t believe in, in serious use of military power, they’re beyond that. But if we took that off the table it would make a difference. But the thing that makes me really angry is the notion that we are helping the recruitment of jihadis because we’re talking about a culture that countenances, without any problem, blowing up children, torturing American prisoners to death. See if you tell me…you know, that, we’re people who are not troubled by that, they think it’s okay. But if they ever read about some level of sexual degradation, humiliation being inflicted on somebody by us, that really ticks them off. I will tell you these are the people who are not gonna win their hearts and minds no matter what we try, I find this argument absolutely absurd, and the final point about how our soldiers are treated. Ladies and gentlemen, our soldiers have been tortured in every single war, since the end of World War II. So the notion that somehow there’s this nirvana, tell this to John McCain. Tell people in Korea when over 50 percent of American POW’s were tortured and starved to death. Look, we have to do the right thing because it’s the right thing. But let’s not pretend that it’s going to impact how our people are going to be…dealt with. By this enemy.

### Moderator
Claim: Go ahead, Rick—

### Conspiracy Advocate (CA)
Claim: I think one of the points you were trying to make is that it will staunch the willingness of our allies to join with us in these coalitions. I think John, you said coalition is the way we’re gonna go in the future. I agree with that, but I don’t think that this aspect is going to pay that big of a role because when you look at the interrogation techniques that our allies use, they’re much tougher than we are. Look at the way the French interrogate, look at the way the British interrogate, I— that they go far beyond our Army Field Manual.

### Conspiracy Advocate (CA)
Claim: I would also say, in one sense, I take John Hutson’s argument as really a confirmation of what we’re arguing because he’s—you didn’t address stress, you talked about clear abuses of the interrogation rules. There was no license for stuffing somebody in a sleeping bag and suffocating him to death, that was a violation of the rules, not an interrogation pursuant to them—

### Scientific Advocate (SA)
Claim: Nobody stopped it.

### Conspiracy Advocate (CA)
Claim: And people that have killed detainees have rightly been prosecuted. Most of the deaths occurred at point of capture, not in interrogation at that point when you are sort of still at war, and it’s a very ambiguous state, but in any case, out of the tens of thousands of prisoners that have been taken, 40 criminal homicides is…compared to wars in the past is a pretty low rate, but in any case, we are not arguing for torture. My side here is talking about stress interrogation and I would say as David does, it is perfectly valid to distinguish between keeping somebody up late that it—according to the interrogators who’ve written about this and spoken about this, reversing somebody’s sleep schedules does get information, and burning somebody or destroying them and inflicting deliberate severe pain and stress on—and suffering on them. We have to be able to make these distinctions. And, again, to conflate the murder of detainees which is clearly a violation of the laws of war, with the calibrated use of stress I think, does no service to what we need to be debating in the future in the war on terror.

### Moderator
Claim: Did you want to say something—

### Scientific Advocate (SA)
Claim: Yes, the—

### Moderator
Claim: —beforehand?

### Scientific Advocate (SA)
Claim: The—the point is that, in— This is not an existential war. World War II was an existential, Civil War was an existential war, this just happens to be the present war. And, for us to be here in 2008, and turn these people into supermen, that the Nazis and Imperial Japan were not, is just kidding ourselves. The problem that we face now is that nobody, nobody in the administration has had said stop. Nobody said, they may be terrorists, they may be evildoers, but they’re human beings, and we will treat them with the dignity and respect that Americans have always treated human beings, instead, we just let it run rampant. In 1950 the armed forces officer said “Wanton killing, torture, cruelty or the working of unusual, unnecessary hardships on enemy prisoners or populations is not justified under any circumstance.” We have backed away from that standard, and we have permitted good American men and women to engage in a kind of interrogation policy, not because we said, go out and torture, because we didn’t. I mean how—I’d like to have a nickel for every time the President’s said, the United States doesn’t torture. We don’t engage in extraordinary rendition. But the reality of it is, what was going on there, continued on. You know, you look at the pictures at Abu Ghraib, you look at—you listen to the stories of, of what happened at Guantanamo, gloves off, fear down, and it was pretty clear that if it wasn’t the express policy it was the benign policy of the United States to engage in techniques that we had absolutely forbidden. In 1903 we sent an American major to prison for 10 years for waterboarding a Filipino. We prosecuted Japanese for waterboarding, and sent them to prison.

### Conspiracy Advocate (CA)
Claim: John, to say it’s—we’ve let it run rampant is just not true, people that have abused prisoners have been prosecuted criminally. When Abu Ghraib came out—

### Scientific Advocate (SA)
Claim: Some, some have been—

### Conspiracy Advocate (CA)
Claim: —there has been—

### Scientific Advocate (SA)
Claim: —some have been prosecuted—

### Conspiracy Advocate (CA)
Claim: There has been investigation after investigation of that. I would agree, I think Abu Ghraib, there has not been sufficient, responsibility laid on the commanders that let that situation get out of control, I think it needs to go way far up the Pentagon chain of command but it hasn’t, but again, that happened in contravention of the interrogation rules, the interrogation rules, if they had been followed to the letter, they said that every interrogation technique had to be cleared, had to be monitored. What was going on was not interrogation, this was a bunch of deranged, sadistic guards, working in the middle of the night, that were getting their jollies on these prisoners, it had nothing to do with the interrogation rules—

### Conspiracy Advocate (CA)
Claim: Let, let me—

### Moderator
Claim: Rick?

### Conspiracy Advocate (CA)
Claim: You—

### Moderator
Claim: Rick?

### Conspiracy Advocate (CA)
Claim: Well—and I think we need to but this Abu Ghraib thing to rest, and you’re absolutely right, this was not the interrogations we’re talking about. This was a bunch of military policemen running amok, it was a breakdown of—where were their officers, where were the NCO’s, it was a complete breakdown of the chain of command—

### Moderator
Claim: That is—

### Conspiracy Advocate (CA)
Claim: It was set up by the, by the command in Baghdad and there have been careers ruined for this, General Sanchez is out of the army now. And he’s—he set up an unworkable chain of command, he put the intelligence people in charge of the prison. You don’t do that—

### Moderator
Claim: But some of the jollies that have been described here were techniques that were actually used in Vietnam. Somebody told them what to do, it wasn’t a simple improvisation—

### Scientific Advocate (SA)
Claim: —we’re having this debate and the public should, I think, understand this. We’re having this debate as if, and I think Heather articulated this point, tried to make this point, that everybody that came in on the battlefield in Afghanistan, whether they be Taliban or a so-called Arab insurgent, really had a lot of information. Her position is that people were not cooperating. They were not cooperating, and because they had been trained. When the fact of the matter is they weren’t trained. The fact of the matter was the reason why they weren’t cooperating, was because they didn’t know anything. By and large, you have to separate the Taliban from the Arab Al Qaeda fighter. They’re two distinct groups. In point of fact, they don’t get along quite well.

So if somebody is not cooperating, it doesn’t mean that they have been trained. The fact of the matter is that a lot of our people on the ground in Bagram, and I’m quite familiar with it, on the military side, had no idea what they were doing.

### Moderator
Claim: I need—

### Scientific Advocate (SA)
Claim: Had not received any training whatsoever.

### Conspiracy Advocate (CA)
Claim: You, you—

### Scientific Advocate (SA)
Claim: They were in the dark.

### Moderator
Claim: I’d like to return to this discussion about Abu Ghraib and those prisoners after, but first, we have two more speakers to hear from, for the motion, Rick Francona.

### Conspiracy Advocate (CA)
Claim: Well, we’ll just follow up on some of this, I had several pages of notes here, but Heather and David went through them quite quickly, so— I’ll speak to some of the subjects that we’ve brought up here—all this is great theory. I appreciate what all of the other speakers have brought to this, and most of the time we’re talking theory. I’d like to inject some reality into this. I’m going to submit that I’m probably the only one on the stage that’s been waterboarded. I don’t consider it torture, but by no means do I consider it pleasant and it’s not something you sign up to do, you know, for your summer camp. The Air Force did it during our training to show us what it was like, the purpose of it was to show us the treatment that we could expect as potential prisoners of war. And the point was made and I want to underscore this, never in our history have we gone into a conflict and our prisoners been treated right, the Geneva Convention was an attempt to make that happen. I submit that it has failed miserably. It restricts what we can do, we make sure we treat people right, and we get no reciprocal treatment at all. So it does not work—now. John McCain will tell you that torture doesn’t work, and that he’s against it because of his experiences in North Vietnam. No one can take away the fact that he was brutally treated, brutally tortured, and he has the gravitas to address this issue. But you have to understand that John McCain was the victim of torture for the infliction of pain. The Vietnamese were great at that. They could hurt you, they could make you say things that maybe you didn’t want to say. For the most part, our prisoners did very well. They gave up what they thought their interrogators wanted to hear which is the biggest threat you have when you resort to torture. Whoever you’re torturing, the subject, is going to tell you what he thinks you want to hear. Just like a defector, we’ve seen how bad information leads to bad actions, remember Curveball. The bad information about the Iraqi mobile labs. This is another instance where people tell you things they want to hear. Someone being tortured will tell you anything, anything, to stop the pain, to stop the treatment. Waterboarding, someone mentioned a figure 60 to 90 seconds. I can tell you that after about 35 seconds I was ready to tell them anything they wanted to hear. And I knew this was an exercise. You know, and in the back of your mind, your instructors are telling you, project yourself into a situation. Imagine this to be real. I survived by telling myself, I know this is a game. That they’re going to let me up before I drown. So, there is that reflex, and waterboarding is so powerful, that it will make you say something. So, in the hands of skilled interrogators, can waterboarding work? Absolutely, but you have to know what you’re doing. The North Vietnamese did not know what they were doing. They were great at inflicting pain, lousy at extracting effective, useful intelligence. Now does it work? Well, you hate to say trust the government. But we have two government officials that say it worked. That would be the former director of Central Intelligence, George Tenet, and the director of the bin Laden Unit, Alex Station. Dr. Mark Shore, you’ve seen him on television, he’s making the rounds, I think he has a book out. It can be effective if it’s done properly. The question is, not, can we do it, the question is, should we do it? And that’s where we have to decide, or is the tough interrogation of these suspects necessary…do we want to go beyond whatever line that is. I can tell you the line that the government is trying to draw, is the Army Field Manual, I worked under the Army Field Manual, it’s pretty restrictive, the new one is even more restrictive, they rewrote it in November of 2006. It’s online, type in to Google, “Army Field Manual Interrogation,” it’s a voluminous document, it’s written in typical Army bureaucratese, there’s probably four pages in it worth reading. So, and those are the ones that tell you the 16 psychological approaches you can use, none of which will be effective against a terrorism suspect because those techniques were written, just as someone said, to break a captured enemy soldier. One probably with no resistance training whatsoever. When we started taking large amounts of prisoners, in Desert Storm, we had thousands, tens of thousands of Iraqi prisoners that we had to interrogate, we had to assess, and determine if they were worth questioning. And once we determined that they were worth questioning, most of the time if you asked them a question, they gave you the answer. It was very surprising to us, to learn that all these techniques really weren’t necessary because the Iraqis had no training, most of them were happy just to be away from Saddam Hussein. Very powerful tool. The ones that did not want to cooperate with us, usually you found some major or lieutenant-colonel in the Republican Guard that didn’t want to talk to you, and that’s when those techniques became somewhat effective, but there were always ones that would spit at you, because they knew you couldn’t hurt them. They knew the Americans followed the Geneva Conventions. They knew, that you weren’t gonna hurt them. You couldn’t touch them. Until some—and I won’t use any personal references here, some lieutenant-colonels I know, would throw them down to the ground, pull out a pistol, put it to their forehead and say, tell me what I need to know, whatever the question was, or I’m gonna blow your brains out. That now will get you thrown out of the Army, without your retirement. Back then it was not common use but it was pretty effective because, it’s real easy in theory to know that the Americans can’t hurt you. But, when the gun is on your forehead, you’re not sure if this is the one American that didn’t get the memo. So this can be effective. Now, I think we—

—we have to be somewhat reticent in applying these forms of interrogation. But I think we would be foolish, absolutely foolish to outlaw them. I think the President was right to veto any bill that limits what the CIA can do. And this is only limiting the CIA, the neutered Department of Defense is already constrained by the Army Field Manual. The idea is to extend that to the entire government. I think that’s a mistake, we still have to have this tool in our arsenal because some people in the government who’ve done this for a living, say that it works. George Tenet said it saved lives, I don’t know that to be true, I don’t know it to be not true. But I think we would be very foolish to take an arrow out of the quiver. And I do think this is an existential war. And I think it is a war that we’re gonna be fighting for a long time. I think we need to apply every weapon we have.

### Moderator
Claim: One. Sorry—

### Conspiracy Advocate (CA)
Claim: —we have to be somewhat reticent in applying these forms of interrogation. But I think we would be foolish, absolutely foolish to outlaw them. I think the President was right to veto any bill that limits what the CIA can do. And this is only limiting the CIA, the neutered Department of Defense is already constrained by the Army Field Manual. The idea is to extend that to the entire government. I think that’s a mistake, we still have to have this tool in our arsenal because some people in the government who’ve done this for a living, say that it works. George Tenet said it saved lives, I don’t know that to be true, I don’t know it to be not true. But I think we would be very foolish to take an arrow out of the quiver. And I do think this is an existential war. And I think it is a war that we’re gonna be fighting for a long time. I think we need to apply every weapon we have.

### Moderator
Claim: Against the motion, Jack Cloonan.

### Scientific Advocate (SA)
Claim: Good evening. I don’t believe that harsh interrogation techniques actually work. I’m going to explain to you why, and I’m going to explain a little of my background as to why I’ve come to that conclusion. The question before us tonight is actually very, very important and it’s very, very important to you personally. I’m going to take us down from this sort of nuanced, 30,000-foot view that we’ve had discussed thus far, and I’m gonna take it down to what I like to call the practical level, the operator’s viewpoint, because that’s where I come from. That’s what my job was. That’s what I was charged to do. I was charged in 1996, to eliminate bin Laden, Ayman al-Zawahiri and others as a threat to US national security. And I found myself in the enviable position of having to travel around the world, and find members of Al Qaeda, and gain their cooperation. And I can assure you as I sit here tonight, being very proud of what the end result of that was, that I did not engage in any harsh interrogation techniques. It didn’t involve sleep deprivation, it didn’t involve threats from dogs. It didn’t involve hijinks, and all the other stuff that we’ve heard about. We have a deficit, ladies and gentlemen, that we are facing. And that deficit has to be, that we do not have as we sit here tonight, really good human intelligence. Yes, we spend an awful lot of money. We can intercept and suck up emails from all around the world. But we don’t really know what we have. We have a very hard time processing what we have. And when you have the opportunity to sit across the table from a real member of Al Qaeda, a person who has raised their right hand and swore bayat, or allegiance to Sheikh bin Laden, it’s your obligation to get information from them, and to ensure that that information is reliable. I would think even Rick would freely admit, in some of his writings he has stated that harsh interrogation techniques typically don’t work. In fact, rapport building is what works. We’re always having this discussion about the ticking bomb. The scenario that if we don’t get this information right away when we’re confronted with somebody who we believe has this sort of information, that lives will be at stake, and that we have to engage in these harsh interrogation techniques or, as we’ve just described, waterboarding. When Abu Zubaydah was waterboarded, and we now know that to be the case, he was waterboarded after he was in custody for thirty days. He was waterboarded because the agency, the CIA would argue, because what we were trying to get out of him we weren't getting out of him. Yet I have been able to speak to people who told me rhyme and verse about Abu Zubaydah. Abu Zubaydah is not what you think he was. Abu Zubaydah was a great travel agent. He was a logistics person. He was not what has been described, as a key Al Qaeda operative, quite the opposite. So when we engage in these techniques, there is a pushback from the opposition. And what does that pushback mean to you? What does that mean to you and your families? Because when we push back and when we engage in these type of techniques, the opposition is duty-bound, the enemy, as we’ve heard described here tonight, is duty-bound to get revenge. There is a constituency that you have not heard from tonight. And that is Al Qaeda. I am going to tell you what Al Qaeda has to say about torture. I am going to tell you what Sheikh bin Laden had to say about torture. And I'm going to tell you that from the prospective of having to deal with Ali Abdul Saud Mohammed who created the Encyclopedia of Jihad. Who taught people what to do and not to do if in fact arrested by the unbelievers, we, the blood people. Bin Laden’s view was that any brother who was picked up and withstood torture for 72 hours, he and the other members of Al Qaeda would not seek revenge against him. Even bin Laden understood and did not take revenge against those who cooperated with the United States. Think about that for a moment. I can talk to you about Ibn al-Sheikh al-Libi, which you’ve probably all heard about. I happened to be on the receiving end of a lot of information that Ibn al-Sheikh al-Libi was giving up to the FBI in Bagram, Afghanistan. Ibn al-Sheikh al- Libi is the man who’s alleged to have given information that was used in Colin Powell’s speech before the United Nations. Ibn al- Sheikh al-Libi agreed to cooperate with the United States…

…through rapport building. And he agreed to cooperate with the United States, but he was duct taped, put into a cardboard-, or a, or plywood box, and shipped and rendered off to Egypt to be interrogated. He had agreed to cooperate with us. This was a policy decision that was made. Good counterterrorism policy has to include the end result of what we do, whether it’s on the battlefield or whether it’s on the streets of New York. Rapport building, treating people humanely, getting information, solid intelligence is what we’re after. There’s too much at stake, your safety is at stake, to engage in harsh interrogation techniques, which is going to cause the enemy to seek revenge against each of you.

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …through rapport building. And he agreed to cooperate with the United States, but he was duct taped, put into a cardboard-, or a, or plywood box, and shipped and rendered off to Egypt to be interrogated. He had agreed to cooperate with us. This was a policy decision that was made. Good counterterrorism policy has to include the end result of what we do, whether it’s on the battlefield or whether it’s on the streets of New York. Rapport building, treating people humanely, getting information, solid intelligence is what we’re after. There’s too much at stake, your safety is at stake, to engage in harsh interrogation techniques, which is going to cause the enemy to seek revenge against each of you.

## Round 2

### Moderator
Claim: Thank you. I have one last question and only a few minutes to get an answer, and I'm going to address the same question to both sides. And that is, is this foe different from the other foes that we’ve faced? This foe has stated, especially the high-value prisoners, those on the inside of Al Qaeda have stated that it is-, they are ready for death. Can you break this foe by building a rapport? Jack? Rick?

### Conspiracy Advocate (CA)
Claim: Yeah, I’ll take that. Ideally, you want to break any foe. And Jack goes-- I mean, I agree that rapport building, if you have time, is the best way to go. The question is sometimes you don’t. The other point is sometimes you don’t have the time. But I believe this foe is a different one that we’ve ever-- than we’ve ever faced before. We’re not dealing with a state. We’re not dealing with someone with defined borders. The people--these are not soldiers in an army. This is an ideal. This is a-- these are committed warriors in a religious battle. And I think that brings something that we’ve never dealt with before, and I don't think we’re very well-prepared to do that.

### Conspiracy Advocate (CA)
Claim: If just…

### Conspiracy Advocate (CA)
Claim: And, and can I also add something that…

### Moderator
Claim: Just briefly, here.

### Conspiracy Advocate (CA)
Claim: …was already mentioned. The destructive power—this is an asymmetrical war as John said. The destructive power that now lies available to individuals that are not a member of the state, that cannot be deterred as states can is unlike anything that we’ve faced before. With the…

### Conspiracy Advocate (CA)
Claim: Let me just--one sentence.

### Conspiracy Advocate (CA)
Claim: …availability of nuclear weapons.

### Conspiracy Advocate (CA)
Claim: Our distinguished colleagues don’t have their act together.

Jack seems to be arguing that it is silly to counterproductively use stress techniques and accomplish reliable rapport. Nobody disagrees. Nobody would-- be a fool to suggest to promiscuously use stress techniques. But it’s equally foolish to say we should never use them. Because there may be circumstances where they’re necessary. And the true wisdom lies in ascertaining which one is which, and mistakes can be made. But wouldn’t it be a mistake, Jack, to just take something entirely off the table?

### Scientific Advocate (SA)
Claim: How…

### Conspiracy Advocate (CA)
Claim: Do you think that everybody is subject to…

### Moderator
Claim: So…

### Conspiracy Advocate (CA)
Claim: …to the…

### Scientific Advocate (SA)
Claim: That’s a sentence?

### Moderator
Claim: Let me address…

### Scientific Advocate (SA)
Claim: Where was the period?

### Moderator
Claim: …let me address this to Jack first. Because you raise the issue of rapport building as an effective way to get actionable intelligence…

### Scientific Advocate (SA)
Claim: It’s the only effective way.

### Moderator
Claim: …can…

### Scientific Advocate (SA)
Claim: …well no, I--that’s not what I'm saying. I used the word rapport- building, certainly. Did I engage in harsh interrogation techniques? Of course I did. But harsh doesn’t mean that I was engaging in sleep depravation. It doesn’t mean that I was engaging in some of these other techniques that we’ve now all identified. The harshest thing I ever had to do was to let somebody listen to Barry Manilow for twenty-four hours. That would be considered…

### Conspiracy Advocate (CA)
Claim: Sounds awful.

### Scientific Advocate (SA)
Claim: …you know… Doesn’t it? Honestly. No. What, what I'm saying is that we--there is this supposition out there that Al Qaeda is everywhere. There’s a supposition that the Taliban, you know, is, is, is Al Qaeda and we fail to make distinctions between that. If I ask the audience tonight, and I’ll ask my distinguished colleagues up here, and David, you can be the first one. How many members of Al Qaeda do you think there are?

### Moderator
Claim: Oh boy. Is this, uh, multiple choice?

### Scientific Advocate (SA)
Claim: I mean, the other side is arguing that this enemy is so vast, so depraved, so craven, they want to kill thousands of us. There’s no question about that. There’s no question that, that what they want to do-- we saw that. But my point to you is, when I took the original membership lift off of Ali Mohammed, who are Al Qaeda, there were seventy-two members.

### Moderator
Claim: There’s probably a lot more now.

### Scientific Advocate (SA)
Claim: Well-, the sales stru-, the sales structure within Al Qaeda…

### Conspiracy Advocate (CA)
Claim: Uh-huh.

### Scientific Advocate (SA)
Claim: …consists of four to six operatives. You are trying to find, on a beach, a small dime. That’s what we’re up against.

### Conspiracy Advocate (CA)
Claim: But Jack, that’s a different argument. I mean, it doesn’t matter whether they have a million or ten thousand, again, given the availability of weapons of mass destruction, that’s what we’re up against. And that’s the fear, that a small…

### Scientific Advocate (SA)
Claim: What are the weapons of mass destruction that they have…

### Conspiracy Advocate (CA)
Claim: …number of people…

### Scientific Advocate (SA)
Claim: …airplanes?

### Conspiracy Advocate (CA)
Claim: You can-, there is the possibility of…

### Scientific Advocate (SA)
Claim: They don’t have nuclear weapons.

### Conspiracy Advocate (CA)
Claim: …nuclear weapons.

### Scientific Advocate (SA)
Claim: Come on, Heather. Where, where....

### Conspiracy Advocate (CA)
Claim: You don’t-, you think it’s not going to happen?

### Scientific Advocate (SA)
Claim: …you think Al Qaeda’s got nuclear weapons?

### Moderator
Claim: I'm going to break in here.

### Conspiracy Advocate (CA)
Claim: They’re seeking…

### Scientific Advocate (SA)
Claim: Oh…come on…

### Conspiracy Advocate (CA)
Claim: There’s-, it’s never-, it’s not a…

### Conspiracy Advocate (CA)
Claim: They’re relentlessly seeking…

### Conspiracy Advocate (CA)
Claim: a puzzle. I'm glad, I'm glad to

### Scientific Advocate (SA)
Claim: Relentlessly seeking?

### Scientific Advocate (SA)
Claim: Rick may-, Rick may know this. Al Qaeda first tried to get fissionable material in 1993. What they got was red mercury, they got scammed. And we got that from, what? We got that from one of the guys that we cooperated with. So not only did we learn about what they were trying to do, we knew how they went about it.

### Moderator
Claim: I hope that will prompt…

### Scientific Advocate (SA)
Claim: There, the…

### Moderator
Claim: …the audience to raise questions about the actual nature and the extent of the threat. I'm going to be turning to you in just a moment. But first, I want to announce the results of the pre- debate vote. And before the debate, for the motion, which is--, I want to have the exact wording here, “tough interrogation of terror suspects is necessary.” 46% of you voted for the motion. 35% voted against the motion. 19% were undecided. So, so much for some on the panel that thought this was going to be an excessively liberal audience. So, now I’d like to open up the floor for Q&A. Please stand up when you have your question. I ask that you don’t start to ask your question until you have the microphone, this is radio. Please make the questions short and to the point. And it would be great if members of the press would identify themselves as such. Have we got a question ready? All right.

### Moderator
Claim: The arguments on both sides so far have been mostly utilitarian. Torture works, torture doesn’t work. Torture has side effects. But there hasn’t been much said about the moral high ground, and America showing leadership in an ethical and moral universe. The “do unto others as you would have them do unto you.” What about the moral issue in here, which I think is a problem that many of us have?

### Conspiracy Advocate (CA)
Claim: Can I just say very briefly, let the record show, that nobody’s arguing on our side in favor of torture. The shame, frankly, the fault lies with the critics that damn everything with the T word and paint with a broad brush. We’re not talking about torture. We’re talking about the level of coerciveness and unpleasantness that permeates our spheres of public life without drawing any opposition from anybody. You tell me why in order for us to occupy the moral high ground we should eschew, give up, whatever verb you want to use, a level of coercion that is routinely used in other areas, including training of our own troops, specialized and advanced training, federal and state penitentiaries, boot camps for juvenile offenders. That makes no sense for us as a society to-- instead of having a common baseline that is not torture--to have privileged, uniquely privileged-, only one set of people, captured Al Qaeda and Taliban terrorists. If that is morality, it’s silly. The…

### Moderator
Claim: That’s David Rivkin. Darius Rejali? Do you want to try this one on?

### Scientific Advocate (SA)
Claim: Sure. I’ll take that on. Look, you keep on saying that we do these things domestically and we should do them internationally and what’s the problem. Well, a couple of problems. First of all, let me just say a couple of things. A young professor comes to me and he says, “Could you tell me exactly what sexual harassment is? I mean, if I do a little bit of it, is it ok?” You’d think that’s creepy, right? These people are talking about, “Let’s do a little bit of it.” And it’s creepy. And it should creep you out, okay? Because there are certain things you shouldn’t get anywhere near. The line between domestic and international, whatever you want to call these things, not torture, is a thin one. And every war that we have used torture, the Philippines, when we used that in the insurgency, those guys, they come home, what kind of jobs do they get? They get jobs as policemen, prison guards, and your private security officials. And behind them follows torture. Or not torture, call it what you will. Chicago is paying twenty million dollars thanks to Mr. Burge and his fifty detectives who brought all their lovely techniques back from Vietnam. Look, at the end of this war, whether these guys get their way or not, people are coming back. And they’re going to be your cops, your neighborhood officials. They’re going to be your private people. And yes, there is a difference between domestic- international. But this stuff travels.

### Conspiracy Advocate (CA)
Claim: Darius, do

### Scientific Advocate (SA)
Claim: Let me make another point, too. That if this…

### Conspiracy Advocate (CA)
Claim: Why does…

### Scientific Advocate (SA)
Claim: …is, if this is important for us to do, to save American lives because we’ve got this superhuman enemy that we have never faced before, because this foe is different and they are so dedicated, if this is important for us to do at some level, then to the moral imperative question, why should we stop at all? Why not the rack? Why not perfidy? Why not treachery? Why not all kinds of things? Because if that’s the moral thing to do in order to save lives, then by George, we ought to be doing it across the board and not stopping ourselves anywhere short. I think that the world has relied, we’ve, the United States has been far from perfect. Our history is replete with examples of where we have failed in big things and in little things. But the world has relied on us to stand for the rule of law and for human rights. And it’s not a rule of law, if you only apply it when it’s convenient. And it’s not a human right if it only applies to some people. We need to stand tall in this, and not draw lines because this enemy is the worst enemy we have ever faced.

### Conspiracy Advocate (CA)
Claim: I—I—

### Conspiracy Advocate (CA)
Claim: I can—let me just argue that, first of all what we are doing is within the rule of law because a terrorist detainee is not covered by the Geneva Convention—

### Scientific Advocate (SA)
Claim: It’s how you define the law—

### Conspiracy Advocate (CA)
Claim: And—we are— he is covered by the Convention Against Torture, there is no question. We are obligated to follow the Convention Against Torture, that’s why it matters to make the distinctions that Darius refuses to. We are not arguing torture on this side. And Darius, you seem to think that the only possible set of questioning techniques are these random— it was rather arbitrary what got put into the Army Field Manual. You yourself know, there has been, contrary to the claims on the other side, there has been no serious empirical work on the—even on the Army Field Manual. Are you suggesting that those are the only possible… questioning techniques that can ever be used, and that somehow they are handed down from on high as the absolute way of questioning. There may have been 12, if Mutt and Jeff had not originally been included in them, my guess is that if we were now pro—…

### Moderator
Claim: Mutt and Jeff—

### Conspiracy Advocate (CA)
Claim: —proposing—

### Moderator
Claim: —are good cop-bad cop—

### Conspiracy Advocate (CA)
Claim: Good cop-bad cop—

### Moderator
Claim: —for people who don’t know the—

### Conspiracy Advocate (CA)
Claim: —you would call that torture as well because that wouldn’t be in the Army Field Manual—

### Scientific Advocate (SA)
Claim: No, actually, Heather, I think you’re getting—

### Conspiracy Advocate (CA)
Claim: So that’s why I think again—

### Scientific Advocate (SA)
Claim: —your distinctions quite all confused here—

### Conspiracy Advocate (CA)
Claim: —we need to—we need to discuss—

### Conspiracy Advocate (CA)
Claim: —whether stress is torture.

### Moderator
Claim: All right—

### Scientific Advocate (SA)
Claim: Heather, listen. I’m the one who argued for public cooperation, because Al Qaeda is living—is like a fish in a sea. You need to push it out of the water. It’s a small group of people, and you need to have Iraqi civilians come in and turn people and I have not been the one who argued for the interrogation manual. I have said, that all the studies show that unless you have public cooperation on your side, the chances that you will be able to clear and solve a crime will fall to 10 percent regardless of how you interrogate them, right. So it doesn’t matter what you throw at this problem, right. And the more you do your not-torture stuff, the more problematic it is, let me get to another thing. Barbaric, different kind of enemy, sure. They’re vengeful. And in the Middle East, they never forget. You know this. You know that in the Middle East they never forget. You can get away with this. Do they have weapons of mass destruction? Well as I understand, Mr. al-Libi after he was beaten up by the Iraqis, by the Egyptians actually, said that, Saddam Hussein trained Al Qaeda in weapons of biological and chemical destruction. The Pentagon yesterday produced this huge report that proved that this was entirely false. But it went into the President’s speech in October in 2002 and it was part of the case that took us to war. And let me tell you, I don’t know how many lives these not- torture techniques have saved. But I can tell you how many lives it’s taken. It’s taken everybody who’s died.

### Moderator
Claim: All right—

### Scientific Advocate (SA)
Claim: Think—think about it—

### Moderator
Claim: Now, wait a minute, I have to apologize, I have taken this debate out of sequence. And you guys are supposed to ask each other questions now, so— Let me hurry up and get some of those in. And if you don’t mind, I’ll begin with Heather. Heather, do you have a question for the other side.

### Conspiracy Advocate (CA)
Claim: Well, I’m just puzzled by the idea that, with—if you have Khalid Shaikh Mohammed in detention, I’m not sure what the public cooperation is that you’re going to expect to get information from him. The 9-11 Commission report, you’re claiming that interrogation stress did not work. They said that half of the information in that report came from the interrogation of high- value—

### Moderator
Claim: Is that the question?

### Conspiracy Advocate (CA)
Claim: Yeah, how do you—why are you disagreeing with the fact that, the interrogation of high-value detainees did produce valuable intelligence that allowed us to—

### Scientific Advocate (SA)
Claim: Well, in—in the case of, in the case of Abu Zubaydah, the information that was of high value, was not stuff that he gave up after he was waterboarded. The real critical stuff was in the apartment where he was seized. He jumped out the back window and in the apartment was a treasure trove of computers, documents, cell phones and the like. And so when they end— started to do their routine grunt work, and do the document exploitation and all the other stuff, that’s what led ultimately to the arrest if you will or the capture of Khalid Shaikh, and Ramzi ben Al-Shif

### Moderator
Claim: That was Jack Cloonan. John Hutson, have you got a question for the other side?

### Scientific Advocate (SA)
Claim: Yes, I do.

### Moderator
Claim: The side in favor of the proposition?

### Scientific Advocate (SA)
Claim: Yes. There’s been a lot of talk about the Army Field Manual and the difference now between DOD and the CIA. The President just recently vetoed the Intelligence Bill, which contained— would’ve made the CIA subject to the Army Field Manual. The Army Field Manual says, “Use of torture by US personnel would bring discredit upon the United States and its armed forces while undermining domestic and international support for the war effort.” Not making a distinction between the CIA and the army, just talking about domestic and intellectual support. “It could also place US and allied personnel in enemy hands at greater risk of abuse.”

### Moderator
Claim: There’s a question there, right—

### Scientific Advocate (SA)
Claim: Well, it—there’s going to be. Which of—now these— the Army Field Manual, or the Intelligence Bill that the Army Field—that would’ve incorporated the Army Field Manual, has the following prohibitions. Which of these prohibitions would you say is okay for the CIA, and therefore for the United States. Forcing a prisoner to be naked, perform sexual acts—and this is what the President vetoed. Forcing a prisoner to be naked, perform sexual acts or pose in a sexual manner. Placing hoods or sacks over the head of a prisoner, using duct tape over their eyes. Applying beatings, electric shocks, burns and other forms of physical pain, waterboarding, military working dogs, hypothermia or heat injure, mock-executions and depriving a prisoner if necessary of food, water and medical care. Now, which of those do you think it’s okay for the CIA on behalf of the United States to engage in, in order to get information.

### Moderator
Claim: Rick, do you wanna take that one?

### Conspiracy Advocate (CA)
Claim: Well, since I think he’s reading from my article—

### Scientific Advocate (SA)
Claim: No, actually I’m not.

### Conspiracy Advocate (CA)
Claim: That’s the Field Manual, right. It’s— well, this is what the Army is prohibited from doing, I’m not saying the CIA should be allowed to do any or all of these, I’m just saying you shouldn’t extend this manual to the CIA, the CIA operates under different rules.

### Moderator
Claim: But you were—

### Conspiracy Advocate (CA)
Claim: But do you—do you want to go through and then the CIA—

### Moderator
Claim: He—he’s asking—he gave you a multiple-choice question here because these were, this bill was vetoed—

### Conspiracy Advocate (CA)
Claim: But that’s—with all due respect, John, that’s not all that the Army Field Manual does, my favorite example is, and I wish I had it in front of me. If you look at the definition of a good cop versus bad cop, there’s a restriction on how bad a bad cop can be. The bad cop cannot act in a manner that’s disrespectful to the person being interrogated. I would submit to you it’s not a question of violating the law on the domestic side. In virtually every police station, the bad cop is pretty damn disrespectful to the drug dealers and rapists and muggers. We’re talking about using the rules we’re not using in our criminal justice system. That John is absurd, it’s insanity. It’s not morality—

### Moderator
Claim: But he’s citing the—

### Conspiracy Advocate (CA)
Claim: But he’s citing selectively. The Army Field Manual—

### Moderator
Claim: And he’s asking you to respond selectively—

### Scientific Advocate (SA)
Claim: My response is I have to defend all the good police officers and law enforcement officers out there. Because I can assure you that doesn’t go on as—as much as David suggested it does, it just doesn’t—

### Conspiracy Advocate (CA)
Claim: What— Bad cop does not yell?

### Scientific Advocate (SA)
Claim: No—

### Conspiracy Advocate (CA)
Claim: Spittle is not flying—

### Scientific Advocate (SA)
Claim: I’m saying that—

### Conspiracy Advocate (CA)
Claim: Threats are not made—

### Scientific Advocate (SA)
Claim: But you keep—

### Conspiracy Advocate (CA)
Claim: We’re not allowed to—

### Scientific Advocate (SA)
Claim: —you keep talking—you keep talking—

### Conspiracy Advocate (CA)
Claim: —grab somebody’s collar—

### Scientific Advocate (SA)
Claim: —about these extreme views. You keep talking in the extreme. What I’m trying to argue here is and I think we’ve done it rather successfully, frankly, is to tell you—

### Scientific Advocate (SA)
Claim: Little bias there Jack.

### Scientific Advocate (SA)
Claim: —is to tell you…is to, is to tell you, that, that when you speak in the extremes and you speak in the absolutes, that there is going to be problems. I don’t think you have sat across the—maybe you have, maybe you have sat across the table from one of these guys, and tried to get information. Heather, maybe you have, I suspect that Rick has, I don’t know. But I will tell you if you had, you’d walk away from that experience being very humble…and understanding what you’re up against. To the gentleman’s question, about the moral imperative. If you think, ladies and gentlemen and my distinguished colleagues over here, that we can defeat this enemy, with guns and bullets, and throwing money at this, you’re wrong. This is an epic struggle, this is a struggle for the next generation, and it’s the biggest challenge that we’re gonna have to face. And I don’t want to make it any more difficult than what it is. And when you engage in some of the things that have been, I’m not saying some of the things that we’ve discussed here tonight, you make that challenge a lot harder for us.

### Moderator
Claim: David, do you have a question—

### Conspiracy Advocate (CA)
Claim: Two very good questions—

### Moderator
Claim: —David Rivkin—do you— One question for the other side—

### Conspiracy Advocate (CA)
Claim: Why—all right—

### Moderator
Claim: —against the motion—

### Conspiracy Advocate (CA)
Claim: Why do you claim, that false, misleading information and lying only emanates from people who are being interrogated stressfully, the last time I checked, every criminal, every terrorist routinely lies and your job as an interrogator is to sift the truth from fiction. Isn’t it the case that the biggest problem is, when a person says nothing, zero, nada. Not the fact that somebody’s lying because you have enough time to cross-reference things, you can learn as much from lying, as from a person doing truth- telling, but everybody lies.

### Moderator
Claim: Okay. Does anybody want—

### Scientific Advocate (SA)
Claim: There’s— No kidding.

### Scientific Advocate (SA)
Claim: Well, look, there’s lots of collection—

### Conspiracy Advocate (CA)
Claim: Bad guys—bad guys lie—

### Scientific Advocate (SA)
Claim: —the question is analysis. Look. The guilty will lie no more nor—nor less, the problem is a selection problem. You have a fuzzy context in which you can’t tell who is a big fish, who’s a small fish. Who is Al Qaeda, who isn’t. These are people who hide as ordinary civilians, you’ve all admitted this, right? So you have a selection problem. You have to pull in large numbers of people, and there, you have to decide who is guilty and who is innocent. The guilty, you’re right, absolutely will lie no more or less if you do whatever you want to do to them, right? But the innocent, oh my God. If you start torturing—torturing the innocent to 20 to 78 at that rate, you’re going produce a mound of false information. You’re weighing down the exact war effort you want to win. And not only that, I ask you, what American value does it promote to torture 20 to 78 innocents to get your one hit?

### Moderator
Claim: Actually Darius—Darius, it’s your time to ask a question—

### Scientific Advocate (SA)
Claim: And I just asked that question—

### Moderator
Claim: Do you wanna ask that?

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: Did you guys get that—

### Conspiracy Advocate (CA)
Claim: But that’s a straw man, nobody is suggesting that this administration, much-maligned, has used— has used the stress interrogation techniques, against very few high- value detainees. And whether or not a given individual as Jack suggested, was more of a braggart, or, versus a real mastermind. He wasn’t innocent, the few people who were subjected to those things were anything but innocent.

### Scientific Advocate (SA)
Claim: Look—

### Scientific Advocate (SA)
Claim: Torture is like virginity—

### Conspiracy Advocate (CA)
Claim: I don’t think—

### Scientific Advocate (SA)
Claim: —once you’ve done it…

### Conspiracy Advocate (CA)
Claim: Go ahead—

### Scientific Advocate (SA)
Claim: —you’re torturer. You know, it’s a one-time deal, if we, it’s not necessary counting, or saying, well…these people above these lines are high-values, so we can torture them, below this line, they’re not, so, you know, once you’ve done it, once you’ve engaged in it, that’s who you are as a nation.

### Conspiracy Advocate (CA)
Claim: John, we’re not talking—

### Scientific Advocate (SA)
Claim: And you’ve got to—

### Conspiracy Advocate (CA)
Claim: —here is what you are suggesting—first of all, you guys don’t have your act together. The two people on both sides are making a utilitarian argument, it doesn’t work, we don’t need it. You’re making an absolute argument that there are certain things called torture that you should never do. Actually we agree. The question is this, are we gonna be a mature society, have a serious discourse about what is or isn’t torture, it’s distasteful, but it’s necessary, are we just going to clap our hands and say everything is torture.

### Scientific Advocate (SA)
Claim: Well, a mature society has to debate about what good counter- terrorism policy is, not what good torture is.

### Moderator
Claim: Rick, have you raised— I’m sorry, hold on a moment. Rick Francona, do you have a question for the side against the motion—

### Conspiracy Advocate (CA)
Claim: I suppose I can form this in a—

### Conspiracy Advocate (CA)
Claim: Can I—

### Conspiracy Advocate (CA)
Claim: —question.

### Moderator
Claim: No, you can’t, Rick has to go.

### Conspiracy Advocate (CA)
Claim: All right.

### Moderator
Claim: I’m sorry—

### Conspiracy Advocate (CA)
Claim: —I think it was Darius, you said that the motivation for cooperation the public…you used the public cooperation is how you would round these guys up. I don’t—I’m not sure that’s always the case, would you say that’s why Al Qaeda in Iraq is being taken apart by the Anbar cooperative group out there, they’re doing it because we’re gonna kill them, not because we’re not going to be nice to them.

### Scientific Advocate (SA)
Claim: You know, one of the nasty things about Al Qaeda, and this is true about all terrorist torture, let’s be clear, these people are barbarians, right, they chop off heads. They’re incompetent at it, they know they’re going to get a rise out of us. I have relatives, let me just be—I’ll be honest with you. I have relatives who used to collect eyeballs. Right? Beheading is ridiculous as, it’s clearly a bait, and it’s clearly designed to get us to make mistakes. Now, one of the things any Oriental ruler would have known, is not to fall for that bait, right? Terrorists don’t have fixed assets, they don’t have jails, they don’t have places, they have to be on the run, they have to depend on safe houses. What I’m finding right now in Al-Anbar, is we’re finding torture chambers. You know what that means? It means they’re feeling comfortable enough to build torture chambers. That is not good.

### Conspiracy Advocate (CA)
Claim: But wait a minute, it doesn’t work so it must hurt them more than it helps them—

### Scientific Advocate (SA)
Claim: Oh—it works— I’ll tell you what it works for. It works to intimidate, it works to make false confessions. I am happy to stipulate that, although I will say this too. We have all the records of French torture from the Ancien Regime. And we know that these guys boiled people’s feet in oil. They water- boarded. Do you know how many actually said anything? Do we have a single document left of a confession, three to 14 percent. That’s what false confessions are. And let’s not even worry about the true and false confe— The other part of this is, you think that, well, if the guy breaks, oh, we’ll know whether it’s true or not. Again, 40 years of psychological research will tell you this, we’re really, really bad at telling the difference between truth and lies, even interrogators, we’ve tested them, I’m sorry. There is no argument here.

### Moderator
Claim: Jack Cloonan—

### Conspiracy Advocate (CA)
Claim: It sounds to me like—

### Moderator
Claim: —Jack Cloonan, please direct the next question, to—

### Scientific Advocate (SA)
Claim: I’ll direct this to Rick. Rick…what is the best way, to get quality, actionable intelligence to protect this audience.

### Conspiracy Advocate (CA)
Claim: I don’t think there’s an argument, I agree with what you said. Establishing rapport—

### Scientific Advocate (SA)
Claim: Come sit over here.

### Conspiracy Advocate (CA)
Claim: Well—yeah—

### Scientific Advocate (SA)
Claim: Yeah, Rick, I don’t understand what you’re doing over there, I honestly don’t. I mean— we got Rick.

### Conspiracy Advocate (CA)
Claim: There’s a comma here. Given—you know, in a perfect world, and if you had time to establish that rapport. But many times, you don’t have the time to do that, you’re not sure you have the time to do that, the biggest problem is not what you know about a suspect, it’s about what you don’t know. And what you don’t know is what’s the timeline. And you have to get to that very quickly. And if you have any reason to believe that he’s got, you know, information of an imminent value, then you’ve got to ramp up the treatment. You know, ideally if you think this guy, okay, this is a low-level Taliban guy who probably doesn’t know much, let’s sit down and talk to him, and find out who he might know, where the training camps here, the routine order of battle kind of stuff you’d want to prosecute a war. But if you grab a guy, maybe bin Laden’s driver who was driving a set of orders somewhere, but you don’t know where, be nice to know where that is before the action happens.

### Moderator
Claim: I would now like to open up the floor to a couple of other questions, we’ve run long. Sure, right over there.

### Moderator
Claim: Hi,

### Moderator
Claim: Can you wait for the microphone, it’s coming your way.

### Moderator
Claim: …from Commentary magazine, my question is for Heather Mac Donald. Heather, help me out here with your teammates on this waterboarding question. I heard Rick Francona say, when he was subjected to it voluntarily, he broke after 30 seconds. David Rivkin says 60 to 90 seconds, isn’t torture. That seems like a long time for some— if Rick Francona has it—has it right, and… Second, Rick Francona cites Michael Scheuer and George Tenet as sources saying that waterboarding was effective. But…are those two credible? Is George Tenet credible, he of the slam-dunk assessments and Michael Scheuer, who is going around the country saying that Israel is running clandestine operations against the United States, through the Holocaust Museum?

### Moderator
Claim: Well, that’s—quite a question.

### Conspiracy Advocate (CA)
Claim: Well, I wasn’t aware of Michael Schauer’s testimony, I would rely on the 9-11 Commission report, I don’t know what the relevance of the seconds that people have held out, but…clearly we have gotten actionable intelligence from the high-value CIA detainees. What I—what I don’t understand is obviously we do need to think about this, not just as a utilitarian matter but a moral one. But why is it necessary, the moral position, to say that, we are not going to use stress on a single Al Qaeda detainee, and risk the possible destruction of hundreds if not thousands of innocent civilians, I—to me it—it’s not clear that the moral position, puts more value on the protecting of temporary extreme discomfort of one person who is pledged to destroy as many Americans as he can, that that’s moral to protect him, and to sacrifice thousands of American lives, the idea that stress does not work, never works, is an easy out. The fact is is that, regimes have used…torture, again, which is not what we are arguing for today. But even torture, has been shown to work, the French used it in the Algerian war, and they got information—

### Scientific Advocate (SA)
Claim: Oh—

### Scientific Advocate (SA)
Claim: Oh, God—

### Conspiracy Advocate (CA)
Claim: —they did—

### Moderator
Claim: And now they know—

### Conspiracy Advocate (CA)
Claim: They used—

### Scientific Advocate (SA)
Claim: Let’s hear that one—

### Moderator
Claim: That’s—

### Scientific Advocate (SA)
Claim: Let’s hear the evidence, let’s hear the evidence. 24,000 arrests. 24,000 police arrests…let’s call them torture warrants, right? To catch what, how many in the Casbah? Do you know how many there were? You guys don’t know how many Al Qaeda there were—

### Conspiracy Advocate (CA)
Claim: I actually do—

### Moderator
Claim: We—

### Scientific Advocate (SA)
Claim: Okay. Well—there were— There were—

### Moderator
Claim: All right, we are ready now for—

### Scientific Advocate (SA)
Claim: 1400.

### Moderator
Claim: 1400.

### Scientific Advocate (SA)
Claim: 24,000 torture for 1400, most of whom actually died and went over to the French as informers.

## Round 3

### Moderator
Claim: We’ve run nearly out of time, I want everybody to have their two- minute closing remarks. Can we begin with John Hutson, against the motion.

### Scientific Advocate (SA)
Claim: Thank you. Thank you all for your patience. I started out some time ago now talking about the various considerations in—that we’ve been talking about today, tonight. Legal, moral, diplomatic, practical. But let me go to the one very quickly that I think is, for me, most convincing. The enemy can’t beat us militarily. They’ve gotten a lift—they’ve gotten very little communication. They’ve got IED’s, they’ve got suicide bombers, they cannot defeat the United States of America militarily. But I’ll tell you how we can lose this war on terror…we can commit national suicide. And the way we’ll commit national suicide, is by disarming ourselves, giving up our greatest weapon, and our greatest weapon isn’t our military might, or our natural resources, or the essential island nature of our land-mass—

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: It sure as heck isn’t our economy right now. Our great strength is—Bono and Thomas Paine had it right—is who we are. And if we give up who we are, who we are as a nation, that’s a victory for the enemy. The enemy knows he can’t defeat us militarily. Killing us isn’t their goal. Our will to win, defeating our will to win isn’t the enemy’s goal. The enemy’s goal in the war on terror is to bring us down to them, to make us ever so slightly more like they are. To make us as miserable and pathetic as they are. And if we engage in the same tactics…they will have won that particular battle. Thank you—

Thank you. Thank you all for your patience. I started out some time ago now talking about the various considerations in—that we’ve been talking about today, tonight. Legal, moral, diplomatic, practical. But let me go to the one very quickly that I think is, for me, most convincing. The enemy can’t beat us militarily. They’ve gotten a lift—they’ve gotten very little communication. They’ve got IED’s, they’ve got suicide bombers, they cannot defeat the United States of America militarily. But I’ll tell you how we can lose this war on terror…we can commit national suicide. And the way we’ll commit national suicide, is by disarming ourselves, giving up our greatest weapon, and our greatest weapon isn’t our military might, or our natural resources, or the essential island nature of our land-mass—

### Moderator
Claim: Heather? Thank you very much, John Hutson, now Heather Mac Donald for the motion.

### Conspiracy Advocate (CA)
Claim: Well, I agree with the opponents that we need as many highly trained interrogators as we can get, they should be as fully versed in language and cultural skills and that has—clearly has been a weakness. But I would submit that the trained interrogators with the CIA were facing resistance that the existing tools that they had available to them were not able to overcome. And I don’t believe that the 16 army interrogation rules are the only possible interrogation techniques that should ever be available as we face an enemy that is not going to seek revenge because we are using stress, because they wanted to kill us 30 years ago, 40 years ago, and destroy as much as we can. I think that there are going to be times when—

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —stress is necessary. If we are facing an imminent threat, if we have somebody with, with knowledge of the next plot, we’re not going to have time to spend the months that it can take to build rapport. And if using stress on somebody with knowledge of the next terrorist attack is necessary to save thousands of American lives, I think that it is acceptable and lawful and moral to do so.

### Moderator
Claim: Again— Against the motion, Darius Rejali.

### Scientific Advocate (SA)
Claim: Is it better to be loved or feared. Loved or feared. The correct answer is that if you can fight with one hand tied behind your back and win, you will be loved and feared. If—and that’s the American way. If you want to be merely loved, you’ll be despised, if you really want to be feared, you’ll be despised. My great- grandfather wanted to be feared. He was a very powerful Persian prince. He didn’t hesitate to torture and kill anyone who got in his way. He cloaked his values in blood. And no one misses him today, and his world is gone. I accepted this invitation today, regardless of this debate, win or lose, just to tell you all one thing I know. Don’t make the same mistake my great-grandfather did. Don’t make the same mistake the Shah of Iran did. No one will miss you either. Do not close the values that I have come to this country for, do not close them in blood and make them a sham. I am really tired of having to move…

### Moderator
Claim: One.

### Scientific Advocate (SA)
Claim: …and your parents were really tired of having to move. Look, you can follow bagpipes into battle if you want, but the reality doesn’t change. In the end the Pied Piper keeps on playing all that hot air, the boys at the front die, and the pipers go back to the think tanks and have fine careers. You can’t have—you can’t win a football game with a bunch of Hail Marys, you can’t do it based on interrogation based on faith. We’ve told you the only thing that really works. Public cooperation, rapport-building. And if you’re still on the fence and you don’t know where to vote, I just have it on good authority by the way, that Rick Francona is a card-carrying member of Red Sox Nation.

Is it better to be loved or feared. Loved or feared. The correct answer is that if you can fight with one hand tied behind your back and win, you will be loved and feared. If—and that’s the American way. If you want to be merely loved, you’ll be despised, if you really want to be feared, you’ll be despised. My great- grandfather wanted to be feared. He was a very powerful Persian prince. He didn’t hesitate to torture and kill anyone who got in his way. He cloaked his values in blood. And no one misses him today, and his world is gone. I accepted this invitation today, regardless of this debate, win or lose, just to tell you all one thing I know. Don’t make the same mistake my great-grandfather did. Don’t make the same mistake the Shah of Iran did. No one will miss you either. Do not close the values that I have come to this country for, do not close them in blood and make them a sham. I am really tired of having to move…

### Moderator
Claim: For the motion, David Rivkin.

### Conspiracy Advocate (CA)
Claim: We are facing a very serious threat. One of the reasons that is the case, it’s not a question of numbers, it’s not a question of technology, it’s the question of dedication. It’s been decades since we fought people, who no matter how twisted and warped the ideology is, willing to commit the most inhuman acts, sacrificing not only themselves, mothers bringing their children up to die. Expressing pride at that. The force of that compulsion, of that conviction, is tremendously dangerous. I would suggest to you that we’ve heard a lot of emotional statements today. In my opinion not emanating from our side of, of this equation, but I ask you to use your rule of reason. We as human beings are all about making nuances, whether we’re dealing with our kids, our co-workers, dealing with our government. The human—what we’ve heard repeatedly from our opponents, is, extolling you not to try to draw distinctions, not to try to rule the rule of reason.

### Moderator
Claim: One—

### Conspiracy Advocate (CA)
Claim: But basically, adopt a rigid…unyielding framework, suggesting that anything that deviates from this framework, but degrees of coercion, which by the way are practiced in the criminal justice system, would absolutely allow most criminals to go free, because we’d not be able to suggest them to any psychological coercion, or frighten them, or their family members in any way. That is not the way America has gotten to where it is. This is not the way you’re gonna lead your own lives, this is not the way you’re gonna lead your professional lives, why should you lead that approach as citizens of this great body politic, use the rule of reason, and don’t worry about anecdotes about Spanish Inquisition, or the Iranian secret police.

We are facing a very serious threat. One of the reasons that is the case, it’s not a question of numbers, it’s not a question of technology, it’s the question of dedication. It’s been decades since we fought people, who no matter how twisted and warped the ideology is, willing to commit the most inhuman acts, sacrificing not only themselves, mothers bringing their children up to die. Expressing pride at that. The force of that compulsion, of that conviction, is tremendously dangerous. I would suggest to you that we’ve heard a lot of emotional statements today. In my opinion not emanating from our side of, of this equation, but I ask you to use your rule of reason. We as human beings are all about making nuances, whether we’re dealing with our kids, our co-workers, dealing with our government. The human—what we’ve heard repeatedly from our opponents, is, extolling you not to try to draw distinctions, not to try to rule the rule of reason.

### Moderator
Claim: Against the motion, Jack Cloonan.

### Scientific Advocate (SA)
Claim: I think honestly that we all on this stage tonight have learned something about each other and I think that we all want to get to the same position. I firmly believe that. I think that we have a different way of going about it. And we may differ in methodology. I believe on our side and our argument, and I’m not making this just based on moral grounds, I’m making this from the position of a utilitarian, practical application of what I know to work. And that because we have such a huge deficit in our ability to collect solid, good intelligence, I don’t want to waste the time trying to find that little dime I mentioned to you on the beach. We don’t have time to do that, the enemy as David suggested is very committed. Bin Laden has issued a fatwa and in that fatwa he has declared war on the United States and he has said it is the duty of every good Muslim to kill Americans.

### Moderator
Claim: One—

### Scientific Advocate (SA)
Claim: Where do they find them. The question is, how am I going to protect you. How is our government going to protect you. And the best way to do that it seems to me, is what we’ve been advocating on this side. Let’s be clear. Stress can be defined any number of ways. What we’re talking about are extreme measures. And those extreme measures don’t work…haven’t worked, and it sets us up for cataclysmic results, which means, as Darius pointed out, revenge of the worst sort. And we haven’t seen the worst yet. We haven’t seen the repercussions of what Abu Ghraib has represented and others. Trust me when I say that.

I think honestly that we all on this stage tonight have learned something about each other and I think that we all want to get to the same position. I firmly believe that. I think that we have a different way of going about it. And we may differ in methodology. I believe on our side and our argument, and I’m not making this just based on moral grounds, I’m making this from the position of a utilitarian, practical application of what I know to work. And that because we have such a huge deficit in our ability to collect solid, good intelligence, I don’t want to waste the time trying to find that little dime I mentioned to you on the beach. We don’t have time to do that, the enemy as David suggested is very committed. Bin Laden has issued a fatwa and in that fatwa he has declared war on the United States and he has said it is the duty of every good Muslim to kill Americans.

### Moderator
Claim: For the motion, Rick Francona.

### Conspiracy Advocate (CA)
Claim: I was struck by your question, sir, and I really appreciate you asking that, about the moral ground, you know, do we lose by not adhering to the moral high ground. Trust me, and I think all of us are on the same tier, no one wants to use these techniques as a matter of course. No one enjoys this, from those of us who have done this, it’s not a very pleasant experience. But we don’t live in a perfect world. We didn’t create that world, and it is inhabit by people who wanna kill us. And I’m not sure revenge is the factor it’s their stated goal in life, for whatever reason. Is this utilitarian? Yes. It’s the mission of, of the intelligence community and the armed forces to protect the country, through whatever means are—is legally possible. And when you’re lucky enough to get your hands on one of these suspects—and it’s very difficult to do, how do you find them. These are all very good points. Once you get your hands on one, you have to be able to get the information you need. If the rapport-building works, great. If it doesn’t, you’ve gotta be able—

### Moderator
Claim: One.

### Conspiracy Advocate (CA)
Claim: —to ratchet it up, and get what you have to have. They can’t defeat us militarily, but I am not willing to risk the death of thousands of Americans just on the moral high ground. I just, you can’t have it both ways.

### Moderator
Claim: Thank you all very much. Now it’s time, now it’s time for you to decide who carried the day, once again, please pick up the keypad attached to the left armrest of your seat, after my prompt, press “1” if you are for the motion…“Tough Interrogation of Terror Suspects is Necessary.” “2” if you are against the motion, “3” if you are undecided, please cast your vote now. I want to thank the debaters and the audience for their good work. Before I announce the results of the audience vote, I just want to take care of a couple of things. The next Intelligence Squared US debate will be on Tuesday, April 15th, here at Asia Society and Museum. The motion to be debated is, “Islam is Dominated by Radicals.” It will be moderated by NPR’s Robert Siegel, the panelists for the next debate are, for the motion, vice- president of research at the Foundation for the Defense of Democracies, Daveed Gartenstein Ross, senior fellow at the Hudson Institute, Paul Marshall, and former reporter for The Wall Street Journal and visiting scholar at Georgetown University, Asra Q. Nomani. Against the motion will be assistant professor at the University of California, Riverside, and Senior Fellow at the USC Center on Public Diplomacy, Reza Aslan, Professor of History at Columbia University Richard Bulliet, and Edina Lekovic, Director of Communications for the Muslim Public Affairs Council. An edited version of tonight’s Intelligence Squared US debate can be heard here locally here on WNYC-AM 820 on Sunday, March 23rd, at 8 pm. These debates are also heard at 140 NPR stations across the country and you can check your local NPR member station listings for the time and dates for broadcasts outside of New York City. Thank you very much.
