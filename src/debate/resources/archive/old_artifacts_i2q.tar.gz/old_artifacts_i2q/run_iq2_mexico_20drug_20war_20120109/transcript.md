# Debate Transcript

Topic: America Is To Blame For Mexico's Drug War
Motion: America Is To Blame For Mexico's Drug War

Debate ID: mexico%20drug%20war%20120109


## Round 1

### Moderator
Claim: Well— welcome everyone to another debate from Intelligence Squared US, I’m John Donvan of ABC News, and once again it is my honor and pleasure to be serving as moderator as the six debaters you see sharing the stage with me here at the Skirball Center for the Performing Arts at New York University, six debaters, three against three, will be debating this motion, “America is to Blame for Mexico’s Drug War.” Now, normally at this point in the evening the chairman of Intelligence Squared, Robert Rosenkranz, who is also chairman of the Rosenkranz Foundation, takes to the stage, and he briefly outlines what’s before us, what our debate really is about and what the issues are. Unfortunately he has taken ill this evening so we will not be hearing from him and we wish him well. I’ll just say very briefly, in terms of the drug war—that language has been around a long time, it’s 40 years this year that Richard Nixon first declared a war on drugs in the United States. Mexico launched its war on drugs three years ago, the difference is, that in Mexico it really is a war, as we think of war. It involves troops, and grenades and bombs and bullets, and it has come at a huge cost of 10,000 lives lost. The question before us is whether the United States has some responsibility to bear for this, given the fact that the United States serves as such a large market for narcotics, the question is also raised, whether there would be a war at all, whether the cartels could arm themselves but for the supply of illicit weapons from the United States. Are we in essence, responsibility for those 10,000 deaths. That is the question before us but we’re putting it in this form, “America is to Blame for Mexico’s Drug War.” I want to remind everyone this is not a panel discussion or a seminar, this is a debate, it’s a contest, there will be winners and losers. And you in our audience will be the judges, you will pick the winners, you will have voted twice by the time the debate begins, once before, and once again after the debate. And the team that moves the most voters, that changes the most minds, will be declared our winner. Now let’s go to the preliminary vote, before the debate begins. And turn to the keypad at your left side… There’s a range of numbers, but you only need to concern yourselves with numbers 1, 2, or 3. If you agree with the motion, “America is to Blame for Mexico’s Drug War,” push number 1, if you disagree, push number 2, and if you are undecided…push number 3. If you make a mistake, just correct it, and the system will lock in your last response. All right, I will have those results fairly shortly, but we’re going to move on now, so— On to our debate and on to Round 1, opening statements from each of the debaters, seven minutes each, uninterrupted. And, speaking first, for the motion, Fareed Zakaria, who— and if there are people out there still who doubt that an intellectual can also be popular in the United States, Fareed Zakaria is that example, he is the host— Fareed, you can make your way to the microphone—he is the host of “Fareed Zakaria, GPS” on CNN and Fareed, I’m certain that has nothing to do with getting directions off the highway. What does the “GPS” stand for?

### Conspiracy Advocate (CA)
Claim: “Global Public Square.”

### Moderator
Claim: “Global Public Square,” how appropriate for this, ladies and gentlemen, Fareed Zakaria.

### Conspiracy Advocate (CA)
Claim: Thank you very much, it’s such a pleasure to be here. You know, I feel very comfortable, I have to say, at the outset with the opposing team, sharing a podium with people with very different views about drugs, immigration, Mexico, because, my show at CNN is actually taped in the same studios as Lou Dobbs’s. So I shared— I shared studio space with Lou Dobbs, I can share a platform with you gentlemen, I’m delighted to do so. Look, what I thought I would do is try to convince you as best I can, that you should vote for this proposition. And, we are on the 40th anniversary of the drug war. The war on drugs was declared by Richard Nixon, and it began a vast effort by the United States government, to transform the issue of drugs into one about criminality and war. And it began a massive program in the United States that has spread throughout the region. The results are in, 40 years out, I would argue. We have spent about $1 trillion. That does not count by the way what local and state governments spend every year, to enforce the war on drugs, which is $41 billion. Every year. Now, if you look at any metric, I would argue, that would be reasonable to apply the availability of drug use, the potency of drugs, for the most part the price—the metrics suggest the drug war has failed, it has done nothing to dampen demand, it has perhaps in many ways increased potency, and certainly increased criminality. So, if you look at the simplest statistic in terms of what the effect of this vast war on drugs has had over the last 40 years. In the 1970s, the United States had the same incarceration rate, as every other country in the world. We were about at the world average in terms of how many people we imprisoned, as a percentage of our population. That rate today, is five times the world average. In 1980, those blissful, halcyon days of 1980, we had 41,000 people in prison on drug-related charges. Today we have 500,000 people. So, if you ask yourself, what the effect in the United States has been it seems to me plain, it is blindingly obvious. The question, I suppose, we have to then ask ourselves is what is the effect outside the United States, because there has been another effect of this war on drugs, which has been to internationalize the problem. Because we began this process, by interdicting in Miami, and then started moving to the sources, because the sources also started fleeing offshore. Then we went into Central America. You all remember that before we had the heroic wars of liberation in Afghanistan and Iraq we had the heroic war of liberation in Panama, where Manuel Noriega was indicted in a US court for drug dealing and we decided to send the US Army there, play very loud rock music, I am not kidding, and effectively arrested him. What has happened in almost all those cases is, the supply then shifts. And so it then shifted to Colombia, and we began Plan Colombia, which has been a vast, multi-year effort with many, many hundreds of American soldiers. When we talk about Mexico’s drug war which I will get to, one has to remember, that the wars on drugs that the United States has initiated over the last 40 years, have very much been ones involving troops and soldiers and bullets and deaths. Mexico is only the last in a long line of these drug wars. And so we got to Colombia, where the United States has now spent something in the range of eight to $10 billion. Colombia for many years was the second or third largest recipient of US aid, and much of that aid has gone toward intensely military activities. The GAO, the Government Accounting Office was asked to provide a summary report on what the effect of Plan Colombia has been. And this was only a few months ago, asked for by Vice President Biden, then- Senator Biden, had commissioned the report. And the results are plain. It has had virtually no effect. It seems as though heroin production is down, but cocaine production is up. And so you see the familiar Whack-a-Mole problem of the drug trade, which is that you push something down and something else pops up. And the two most common substitutions you see are the kind of drug, so you go from heroin to cocaine, and the place that these come from. You push it out of the Caribbean, you—it goes into Panama, you push it out of Panama it goes into Colombia, you push it out of Colombia, it goes to Mexico. And thus Mexico has to be seen as the last of a long line of these battles, in America’s war on drugs. And so in that sense you have to ask yourself, are we not in some way responsible for it? Well here’s the simple reality. We are the largest consumer of drugs in the world. We have the most demand in the world. And we also have the largest supply of weaponry in the world. 2,000 guns cross the American border every day to go into Mexico. Hillary Clinton has pointed out that we are arming the Mexican gangsters who operate the drug trade. President Obama has pointed out that 90 percent of the weapons that are found in Mexico can be traced back to the United States. There has been some contestation over the statistics… Fox News says it’s only 17 percent, Factcheck.org says it’s probably higher than 36 percent, but maybe not quite as high as 90 percent. Let me give you a simple statistic. The United States has 280 million guns. 50 percent of all gun production every year is bought in the United States. There are 80 million registered gun users in the United States. There are 2,500 in Mexico. I think we may have something to do with this problem. So if you accept my proposition that the supply of weapons is coming from one place and the demand for drugs is coming from one place, it seems self-evident that we are responsible. You will hear many convincing arguments by honorable people on that side. Honorable opponents of the Mexican government like Mr. Castañeda who ran against President Calderón. Asa Hutchinson who ran the Drug Enforcement Agency. But remember one thing. The only question we are asking you is are we in some way responsible. Let us not one more time shirk our responsibility, and accept that the United States, as the leading consumer of drugs, and the leading supplier of weapons, has got to be partly or substantially to blame for this. Mexico is the latest battle—

—in America’s drug war—

Thank you.

### Moderator
Claim: Fareed Zakaria—

### Conspiracy Advocate (CA)
Claim: —in America’s drug war—

### Moderator
Claim: —your time is up, thank you.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Our motion is “America is to Blame for Mexico’s Drug War,” and speaking first against the motion, Asa Hutchinson who was a Congressman from Arkansas, an elected position, but he’s also held significant appointed positions, he was a US Attorney, he was in the Department of Homeland Security for controlling border security, and was also Director of the Drug Enforcement Agency which, Asa, makes it sound like, in terms of this narcotics issue, for a long time, you were the law.

### Scientific Advocate (SA)
Claim: Indeed, and we enforced the law.

### Moderator
Claim: Ladies and gentlemen, Asa Hutchinson.

### Scientific Advocate (SA)
Claim: Thank you, and seriously, I did have occasion to head up the Drug Enforcement Administration, the DEA, and there’s one thing I learned, Fareed, very quickly as head of the DEA, that when you made a speech somewhere you had a way of drawing protesters. And particularly if you debated drug policy in San Francisco, so I am delighted that this audience is a little bit more friendly. And the other thing I learned that as a dad of a teenaged daughter, that being head of the DEA was a good way to drive away boyfriends that you didn’t want calling on your daughter. So, there are a few advantages to that. I am here today, on this debate topic because I believe it is critically important to the national security of the United States. I believe what happens in Mexico is critically important to that country, but I also believe that what happens in the overall fight against illegal drugs is important for this generation and the next of Americans. And I would agree with Fareed that we do have responsibilities, as United States citizens to reduce the demand for drugs in our country. There is a responsibility but ladies and gentlemen, I’ve noticed something thus far today, and they’re trying to change the proposition. The proposition is not that the United States shares some responsibility. The proposition is that America is to blame. And I believe there’s a distinction between blame and responsibility, or joint responsibility, or some responsibility. And “blame” is a heavy word, that implies that we as a government of the United States are doing something wrong. I agree that we have responsibility but it’s a shared responsibility. Drug consumption is not unique to the United States. I met with Vincente Fox in Mexico City. And I was there as Under-Secretary at Homeland Security but he didn’t want to talk about that subject with Secretary Ridge, he turned to me and said Asa, you were head of the DEA, we’ve got a problem in Mexico with drug consumption and addiction that we need to do something about. He was talking about Mexicans, and he’s talking about the challenges of drugs in his society. And that is across the globe that there is that problem. And…to respond to Fareed about where we are in our fight against drugs today, we should be reminded of some of our successes. Ladies and gentlemen, since the late ‘70s and early ‘80s, when we initiated strong effort against the fight against drugs, we have reduced overall drug consumption in the United States by 50 percent. Please remember that statistic, you can go on monitoring the future websites, a consistent poll and survey that’s done, as well as SAMHSA’s survey…overall drug use has declined 50 percent in our country, cocaine use has declined 75 percent, since the height of the drug problems in the ‘70s, and in the ‘80s. Ladies and gentlemen, that is progress that represents saved lives. Now let me move quickly to why the Mexican drug war, the United States is not to blame for Mexico’s drug war. And the first answer is that Mexico has allowed itself to be a major transit and source country. They are a transit country obviously for drugs but the source drugs that come from Mexico, heroin, marijuana that they grow in the hills, as well as methamphetamine that they produce, they’re sources of that, and they as a sovereign country have allowed themselves to be in that predicament. Secondly, Mexico has resisted US help. This is important to put this in the context of history. In the 1980s, as Fareed pointed out, two thirds of our illegal drugs in the United States came through the Caribbean basin into Miami. We had Miami Vice, we slowed it down in the Caribbean basin, but they moved toward other avenues to bring it in, and that being Mexico and today 90 percent of the cocaine comes through Mexico. How did this happen. It’s because Mexico did not shoulder the burden to say we want to resist in our country, it is a long historic problem that goes back to the ‘80s, decades, it’s not something that’s just happened in the last three years. A key event happened. In February of 1985, Kiki Camarena, a wonderful DEA agent, was captured in Guadalajara, brutally beaten, tortured, and murdered. It was a seminal event in our relations. As a result of that there was a massive manhunt for the perpetrators of that. Mexico believed that we were infringing upon their sovereignty. And therefore, they resisted any US assistance after that event in 1985, in fact in 1986 the Foreign Minister of Mexico said, that “the activities of the DEA trample our sovereignty.” And ladies and gentlemen, I am here today respecting fully the government of Mexico for their sovereignty, but they have made their own decisions, as we have made our decisions and they are a responsible nation and they would not want to blame the United States of America, they are the ones that resisted our assistance during that time. President Calderón has most recently reinvigorated this fight against the drug-trafficking organizations in Mexico. But whose decision was it to move from, you’re infringing upon our sovereignty, in the ‘80s, and DEA get out, we don’t want to have anything to do with you, to the partnership that President Calderón wants to have. It was a sovereign decision by the leader of Mexico that said we’re going to go to war against the drug cartels. That decision should not be blamed on the United States of America, it was a Mexican decision. And then fourthly, it is very important to understand, that the culture of corruption that has developed in Mexico, the failure of the rule of law in Mexico, is one of the largest contributing factors to the violence that we see today. And, I was on the Crime Subcommittee. I asked a question of a cartel member who was brought there to testify. I said what is the greatest weapon that you fear in the United States arsenal, or in the law enforcement arsenal. The answer came back very quickly, we fear extradition. And why is that. They did not fear law enforcement in Mexico or in Central America. It was extradition to the United States of America, you cannot have a failure of the rule of law, and be successful in the fight against drugs. The cartels have operated with impunity, and that is not the fault of the United States. The United States is not at fault for the historic problems in Mexico, we are not to blame for what has happened.

### Moderator
Claim: Thank you, Asa Hutchinson. Speaking now for our motion, “America is to Blame for Mexico’s Drug War,” Jeffrey Miron who is a Harvard economist and whose views on narcotics in this country I think among this panel are probably unique. On most drugs he believes in decriminalization, and with decriminalization, no war. Ladies and gentlemen, Jeffrey Miron.

### Conspiracy Advocate (CA)
Claim: Thank you very much, it’s very nice to be here, see so many people interested in this topic. Let me start by responding very briefly to a few of things that Mr. Hutchinson said. He said that in fact there’s evidence that the war on drugs has been effective in reducing drug use, as he mentioned that’s not really on point, that’s not really the question. But it’s also not correct. There’s tons of evidence, and I’m responsible for some of that evidence in my academic writing, on whether attempts to reduce consumption of drugs with prohibition are effective, and it universally finds little if any effect. Yes, you can cherry-pick certain statistics to find that in some periods drug use went down, okay, but in other periods it’s gone up, or some other kind of drug use went up, the overall result is clearly no evidence for the efficacy of prohibition. And note that over the last 40 years, we have dramatically ramped up our efforts to enforce prohibition, so we should have seen some effects if those effects were in any way going to be effective. Now turning to the proposition itself. Is America to blame for Mexico’s drug wars. The answer is indisputably yes. I want to argue it in three steps. First, there’s a fact already mentioned, that the US consumes a lot of drugs produced or trans-shipped through Mexico. No one disputes that and that’s clearly a part of the issue, but it’s not the whole issue, and it’s not the most important part of the issue, why, well…one, there’s not really anything we can do about the fact that the US consumers choose to consume drugs. Other countries consume some of the drugs from Mexico including Mexicans, including Canada or Europe, et cetera. But it is a piece of the story and it is one sense in which you might say that the proposition that America is to blame, is correct. But there’s a much, much more important sense. Why are there drug wars in Mexico. Why is there violence in the drug trade in the US, and many other countries. The reason there are drug wars is because the drug trade is prohibited. Whether you think drugs should be legal or not, it’s an indisputable fact, based on theory and evidence, that when you drive a market underground, it becomes violent. Why does it become violent? Because participants in an underground market cannot resolve their disputes with courts, with lawyers, by complaining to the Consumer Product Safety Commission or things like that. They can only resolve their disputes by shooting each other or by threatening to shoot each other. We see evidence of this from all over history and all over the world. The US alcohol industry was not violent before 1920, when we passed alcohol prohibition. It was then dramatically violent for 14 years, until we repealed alcohol prohibition, and then the trade became perfectly nonviolent just like any other legal good. If we look at the history of prohibition of drugs, that trade was not violent until we prohibited drugs, and ramped up and escalated the war on drugs. If you look at other commodities from gambling to prostitution to blue jeans supplied in controlled economies where they were in short supply, to commodities driven underground by high tax rates, whenever you drive a market underground, that market becomes violent because participants resolve their disputes with violence, okay, completely independent of the characteristics of the good, whether you’re in favor or not of prohibiting that good, it’s just a fact of nature that the prohibition creates the violence. Now the second thing to recognize is that the US, far and away above any other country, has historically and repeatedly and persistently been the country that has foisted prohibition on the entire world. Starting in 1919, in Paris, at the signing of the Treaty of Versailles which ended World War I, the US said it would not sign unless there was a clause in the treaty that required every other country to immediately go back and adopt drug prohibition. This is in 1919. Throughout the history of the United Nations the US has made fighting drugs and prohibiting drugs in particular a key part of the UN’s mission. And very recently, the US has actively tried to push Canada, England, other countries, and in particular Mexico, to enforce drug prohibition and to adopt drug laws that we approve of. Let me read you some quotes that suggest someone else thinks this is right as well. “While every Mexican administration since the ‘60s has piously declared that it intended to intensify its drug enforcement efforts for domestic motivations, the fact is that the real reason has always been American pressure.” Okay? Quote one. Quote two. “All this starts to show why current US drug policy would have to change in order for Mexico to change its stance. It also explains why it is virtually impossible for Mexico to follow a different policy unilaterally.” Okay? So who wrote those words, suggesting that the US policy, the US insistence, the US pressure on Mexico, is the crucial factor, in determining Mexico’s drug policy. Well, it turns out it’s one of my opponents, Jorge Castañeda, in an article that I found on the Web a few days ago. So I don’t think that point, that the US has tried very, very hard, not always successfully, but has tried consistently, to make sure every country adopts drug prohibition--that point is just not beyond rational dispute. So, part of the discussion here clearly is about what people think about legalization. I’ll comment on that in a second. But you actually don’t need to take a stand on whether it’s good to have drug legalization or drug prohibition, to take a view on the motion. You should be in favor of the motion because it’s just a matter of science and the evidence, that the US pressure to enforce prohibition in Mexico and the US prohibition in the US, are the reasons for the drug violence. Now some people may argue that violence is a cost of doing something that’s worthwhile. They may argue that prohibition reduces drug use, they may argue that drug prohibition has some other moral statement or something like that. Many other people including me would argue that prohibition mainly does bad things, not only the violence but the corruption, the restrictions on medicinal uses of drugs for people who are suffering, the infringements on civil liberties and on and on. Okay, and so you would think that for lots of reasons legalization is the right policy. But you don’t have to take a stand on that, regardless of your views on that, the correct position about the motion is that the US is indeed the single factor to blame for Mexico’s drug wars. Thank you very much.

### Moderator
Claim: Thank you, Jeffrey Miron. A reminder of where we are, we are halfway through the opening round of this Intelligence Squared US debate, I’m John Donvan of ABC News. We have six debaters, two teams of three, and they’re debating this motion, “America is to Blame for Mexico’s Drug War.” You have heard three opening statements, and now on to the fourth, I’d like to introduce Chris Cox, the argument has already been made, that one of the reasons for Mexico’s drug war is the availability of an illicit supply of weapons from the United States. Chris Cox is going to debate that point, as chief lobbyist for the National Rifle Association. Chris Cox.

### Scientific Advocate (SA)
Claim: Thank you. Look, we can all agree that Mexico’s violent drug war is destroying innocent lives on both sides of the border. But some have suggested tonight that lax US gun laws or the lack of enough anti-gun laws are somehow to blame for this crisis.

### Moderator
Claim: Yes!

### Scientific Advocate (SA)
Claim: I’m here to tell you—I’m here to tell you that it’s not just wrong, and it’s not just dishonest, it’s also a deliberate diversion away from the issues that really matter. So tonight let’s dispose of the lies and start telling the truth on this issue for a change. One that you just heard tonight was how 90 percent of the guns that are used by the drug cartels, come from the United States. Well, and not from CNN but after independent fact-checking organizations looked into it, it turned out the number wasn’t 90 percent. It wasn’t even close but Fareed, the question shouldn’t be how many guns, whether it’s 1 percent or 100 percent the question should be, well how can we reduce that number. That should be the question before us and the question is, well, maybe we can make smuggling guns into Mexico illegal, but the problem is we’ve already made it illegal. It’s illegal on both sides of the border, and you can’t really make something any more illegal than it already is. So let’s be absolutely clear. If you’re smuggling drugs, or running guns or doing anything illegal with a gun, whether it’s in Mexico City or New York City, you oughta be arrested, prosecuted, and thrown in jail. I think that’s something we can all agree with. No one more so than the National Rifle Association. Because these armed criminals don’t just endanger our families, they endanger our freedoms. And that’s why the NRA’s worked to pass meaningful laws, so if you misuse a gun in the commission of a crime, you’re going to go to jail. Let me mention just a few that we’ve worked on. If you give or even lend a gun to someone that you even think isn’t allowed to have one, you can go to jail for 10 years. If you’re arrested for dealing drugs and carrying a gun in this country, your sentence starts at five years, and that’s just for the gun. Pull the trigger, 10 years. If you shoot someone, you can go to jail for life or get the death penalty. And that’s not three strikes and you’re out, that’s one strike and you’re out. I challenge anyone to look at me with a straight face and say we could end the drug war in Mexico if we just pass one more gun law in the United States. It’s absurd, it won’t work, so let’s stop pretending that it will. Ask yourself. If American criminals don’t obey American gun laws, and Mexican criminals don’t obey Mexican gun laws, how is it that some new gun control law here in the United States is suddenly going to be obeyed by both. It’s not. Look, if you get caught trying to smuggle a gun into Mexico, you’re going to a US jail for a long time. And if you get caught on the Mexican side of the border, you could go to a Mexican jail for even longer. That is unless you can afford to make a donation to the Arresting Officer Scholarship Fund, which to these drug cartels, is nothing more than a small tax on doing business. So let’s not dance around the truth. The truth is they pump about $40 billion worth of product into our country. And it’s not just drugs. This is a sophisticated criminal enterprise, that seems to be involved in child prostitution, money- laundering, trafficking of pirated DVD’s, it’s a sophisticated enterprise. So it’s no wonder, they post profits of somewhere between 14 and $25 billion every year. That’s more profit than Microsoft makes. With that kind of money they’re buying whoever they want, whatever they want, wherever it is, no matter what it costs. Judging from the weapons that are seized, we know what they want. Fully automatic machine guns, RPG’s, hand grenades, armored personnel carriers, everything from airplanes to boats. Now intelligence sources say that this type of weaponry comes from the international black market. Places like China and Guatemala. But I gotta tell you the one place it doesn’t come from, are American gun shows or some mom-and-pop gun store in Texas or Arizona, ‘cause you can’t buy fully automatic weapons there, and you sure as hell can’t buy hand grenades, RPG’s and helicopter gunships. But there is another place that it’s available. The Mexican government. According to the New York Times, in the last seven years, more than 100,000 soldiers have deserted the Mexican army. Now how many people here think that all 100,000 turned their guns in before they betrayed their country. It’s ridiculous. Most of them were Special Forces, former Special Forces commandos or many of them went on to form their own drug cartel, the Zetas. Which our government says is the most sophisticated, technologically advanced, and dangerous cartel operating in Mexico. And the number-one organization responsible for most of the narcotic-related homicides, beheadings, kidnappings and extortions that take place in Mexico. But it’s not just the military. The cartels are working with the current administration as well. Last year more than a dozen ranking or former officials of the Calderón administration, were arrested for passing tips on to the drug traffickers. One of them, Mexico’s former drug czar. So if you want to talk seriously about this drug war, you’ve gotta talk seriously about the undeniable, institutionalized level of corruption, within the Mexican government. We need to stop talking around the issues, we’ve got enough laws. Everything the drug cartels are doing is already illegal, a hundred different ways on both sides of the border. We don’t need more laws, we’ve got all the tools we need. We’ve got the know-how, we’ve got the tools, the intelligence. What’s lacking is the guts, the political backbone to look each other in truth, and have an honest discussion about this issue. Instead of talking around the issues with some superficial discussion about how gun laws, which are going to continue to be ignored by criminals, could somehow make the difference. Nothing—and until we do that, nothing’s going to change and people on both sides of the border, will continue to pay the price with their lives. Thank you.

### Moderator
Claim: Thank you, Chris Cox. Our motion is “America is to Blame for Mexico’s Drug War,” and to debate next for the motion, Andrés Martinez of the New America Foundation, ANDRÉS was born in Mexico but came to this country and went to a bunch of Ivy League schools and then he discovered Pittsburgh and the Post-Gazette and became a writer, an editorial writer, and since has written and been on the editorial boards of papers such as the Wall Street Journal, the Washington Post, the New York Times, and I give you, ladies and gentlemen, Andrés Martinez.

### Conspiracy Advocate (CA)
Claim: Thank you. First off I want to make clear that I understand that some of Professor Castañeda’s students are in the auditorium. And I think it’s very important to reiterate and remind you that your vote is secret at the end of this, so— Your grades will not be affected by coming to the right side here. And I want to thank the Rosenkranz Foundation for holding this debate. As John mentioned, I grew up in Mexico in the 1970s, in the northern state of Chihuahua, and the capitol city of the same name. And back then it was a pretty easygoing mid-size city. My friends and I wouldn’t really think twice about hitchhiking home from school, or hopping on a city bus to go downtown to watch a movie, then grab a taco at our favorite hole-in-the-wall joint, Our parents didn’t really worry much about us then. I don’t mean to suggest that Chihuahua was Denmark. The state does sit on the border with the United States. And while the bulk of the hard drug trade in those days as Fareed mentioned, went through the Caribbean, there were plenty of trafficking organizations in the mountains of Chihuahua near the city. But we weren’t really aware of this, there was no violence, I didn’t even know anyone who did drugs. I got my first exposure to the consumer end of the pipeline when I came to school in the States. And it’s actually important to make clear that, contrary to something that was suggested earlier, consumption rates in Mexico still remain very low and that’s something we can explore later in the debate. The state of Chihuahua only became a bloody battleground, its border city of Ciudad Juarez synonymous practically with murder, after the US clamped down on the Caribbean routes via Miami once favored by the cartels. And that is what transformed Mexico into the global hub of the trade for drugs. I was talking to a childhood friend recently in Chihuahua and he told me that the city bears little resemblance to the place that we grew up in, and that he doesn’t dare now leave his kids out of sight. Lest they be kidnapped or caught in the crossfire between the cartels, or between the cartels and the security forces. I am proud I grew up in Mexico, and I’m even more proud to be an American. Which is why it’s doubly painful for me to acknowledge that America is responsible for what’s happened to Chihuahua, and that America is to blame for Mexico’s drug war. The United States cannot continue to have it both ways. We Americans need to make a choice. Either we get serious about clamping down on the consumption of illegal drugs, or we should legalize them. Wherever you come down on the moral health, economic merits of criminalizing versus legalizing drugs, please acknowledge that a continuation of the hypocritical status quo, which criminalizes socially accepted behavior, undermines the rule of law, both in our country, and in countries overrun by the goons who arbitrage between our supposed morality, and our actual behavior. That may all sound a bit abstract. What’s a little erosion of the rule of law between friends. Until you start counting the corpses piling up south of the border. They are closing in on 15,000 just since President Calderón took office in late 2006. And that’s nearly three times the number of US servicemen killed in Iraq and Afghanistan this decade. So let’s not be distracted by talk of corruption in Mexico or what percentage of guns in Mexico comes from where. Our debate isn’t about whether Mexico is like Denmark, or about America’s gun laws. It is about what happens to a nation that shares a 2,000-mile border with the richest nation on earth when that richest nation on earth insists on consuming some $65 billion worth of drugs a year, and insists on ceding control of that market, of that industry, to offshore criminal organizations. There’s an old saying in Mexico, perhaps you’ve heard it. “Poor Mexico, so far from God, so close to the United States.” But the real curse isn’t merely proximity to America. It’s being sandwiched between America’s insatiable demand for illicit drugs, and the sources of the most valuable of those drugs, the coca fields in Colombia and Bolivia. So let’s not be confused. Whatever Mexico’s shortcomings are, and there are plenty…and say Canada’s virtues, whatever those are— If our two neighboring countries…traded places, we’d be here talking about a Canadian war tonight. Geography sometimes is destiny. As Americans we believe in individual empowerment and the concept that our actions have consequences. As consumers we may shun products that harm the environment, maybe you buy fair-trade coffee. You know, we believe that our choices have consequences. On college campuses students have long thought globally but acted locally. You know, they mobilize against overseas sweatshops… Or they press institutions to to divest from investments that may harm people in Darfur or elsewhere. When I was in college in the States, the issue of the day was divestment from South Africa. Activists erected shantytowns on campus to pressure the college to stop investing in companies that were doing business there. Again, a laudable impulse. But even then I was struck by how some of these activists disregarded their socially responsible investment creed, when it came to recreational drugs. Their cash after all was underwriting the murder of elected officials, judges, and policemen in Colombia. As Fareed said back then that was the hub, and now it’s shifted to Mexico. And I do worry that we still haven’t made that connection. I actually shared this view with a girlfriend at the time in college, as an argument for our not indulging, and that may have hastened the demise of our relationship. She didn’t quite call me Buzzkill Martinez but maybe she did and I’ve omitted that memory. I must say though, President Obama to his credit has acknowledged this nexus. Saying that as the ultimate consumers of the drugs flowing north, we have a shared responsibility with Mexico in confronting its war. So we should count him as a member of our team here tonight. And even Ronald Reagan back in 1988 meeting with President de la Madrid said similar things, that the solution to the problem was for Americans to quit buying illegal drugs. And I would suggest another option, as has been suggested, is decriminalization. But we can’t continue to have it both ways. I recently read a best-selling book in Mexico by an author I respect a great deal, and from whom I’ve learned a lot. And on page 85 of that book, he wrote that the US wants Mexico… “to wage the war and provide the corpses, so it doesn’t have to.” And he refers to the US as exporting its internal conflict on drugs. The author of this book, and I’m sorry, Jorge, to pile on, but— You’re such prolific writer. The book is excellent. Is Jorge Castañeda of course, and, there’s still time, Jorge, for you to switch sides and come over to— to join us and Presidents Obama and Reagan. But I look forward to continuing this conversation, and thank you so much for your interest.

### Moderator
Claim: Thank you, Andrés Martinez. Well, our next debater is Jorge Castañeda and as you’ve heard his words keep coming back to bite him tonight, that’s because he writes an awful lot, Jorge served as Mexico’s Foreign Minister in the early 2000’s, also your dad as well held that position back in the ‘70s, am I correct—

### Scientific Advocate (SA)
Claim: That’s right.

### Moderator
Claim: He is also on the faculty here at New York University, ladies and gentlemen, Jorge Castañeda.

### Scientific Advocate (SA)
Claim: Very quickly first for my students, in Mexico we have ways of knowing how you vote. Be careful. Secondly, this is a tilted playing field. Because on that side, I have two of my current and former bosses and that’s not fair. Andrés Martinez is my boss at the New America Foundation, and Fareed had been my boss at Newsweek magazine for a long, long period of time. So obviously, you know, I feel somewhat constrained. My point is very simple here. The United States is not to blame for Mexico’s drug war, Mexico is not to blame for Mexico’s drug war, President Felipe Calderón is to blame for Mexico’s drug war, a war of choice that he should not have declared, that cannot be won, and is doing enormous damage to Mexico. It was started on false premises, that Mexican consumption had grown by 2006 which is false according to the government’s own health statistics. Not only has Mexican consumption not grown, it is lower than the consumption not only of the United States and Western Europe, but of practically all of Latin America. It was premised on an increase in violence in Mexico through 2006, which is also false. Willful homicides had been decreasing Mexico, for the previous 15 years, down to levels way below those of Central America, Brazil, Colombia, et cetera, though still higher than the United States. Thirdly, it was premised on a loss of state capacity to enforce the law in Mexico, from what you’ve heard here and quite rightly on both sides of the table, that state capacity in Mexico has never been immense, and it’s not necessarily worse today than it was before. Yes, there is corruption in Mexico, the point is there is more corruption today than there was 20, 25 years ago. I say no there isn’t. And finally, this was also a war that was predicated on the issue, that there was a current explosion of war, which had to be stopped, it cannot be stopped. Why did President Calderón declare this war of choice? Because he felt that he needed to legitimize himself in the view of the Mexican people, because his election was questioned. Fareed, I’m sorry on this point, I tried to run against President— Candidate Calderón, and wasn’t allowed to, and supported him actively, and wrote in many of the places I wrote and that you all quote, that I actively supported, called on readers to vote for him, supported him actively, during the campaign, during the election, and during the post-election discussion on whether the election was free and fair, which I thought it was. I thought he won, most Mexicans thought he won, but he decided that he had to legitimize himself in the eyes of the Mexican people for a questioned election. And he thought that this was the way to do it, by calling the Army out into the streets, donning a military uniform for the first time in 50 years of Mexican history, and trying to achieve, through the war on drugs, what he could have achieved in a much more useful way. This war cannot be won, simply because it is failing to comply with the fundamental tenets of a very good friend of mine, that some of you may know, Colin Powell’s view of the first Gulf War. To go into war like this, you need to have overwhelming force, we don’t have it. You need to have a definition of victory, we don’t have it. You need to have an exit strategy, we don’t have it. And you should have the support of the Mexican people in this case, which President Calderón does have, but he’s running out of it very quickly. Is the US to blame for this? I tend to think it’s not directly to blame, although there is a case to be made for the consumption and arms argument. The problem with the consumption argument, is that if the United States is going to reduce consumption significantly, well, it’s time to do so. And frankly that doesn’t seem to be what American society wants to do. I don’t see the United States wanting to reduce American consumption or demand. Frankly, if I was an American citizen and was asked to vote on this question, I would vote against reducing US consumption. Why bother? There’re much more intelligent things to do with US consumption, I believe, than trying to reduce it. For example, legalize or decriminalize the consumption of as many drugs as is reasonable right now. Start with what you can, see what happens, and then move forward. Is there an alternative issue—approach, of course there is. We don’t have to proceed the way President Calderón has, we don’t have to proceed the way both the Bush and Obama administration, who on this point, are exactly identical in their policy toward Mexico… We don’t have to proceed the way Calderón has proceeded and the way Bush and Obama have supported him. We don’t have to declare a war on all the cartels all the time as Carlos Fuentes has said. We can do either what the Colombians did, combat collateral damages. We can pursue a policy of harm reduction in Mexico. And we can pursue a policy in the United States, Mexicans, we Mexicans, of trying to lobby in the United States in favor of decriminalization where it can be done. But we certainly don’t have to go to war with more than 15,000 people already killed in drug-related killings, and the number rising every week, every month, every year. We have far more executions today in Mexico, than we had four years ago. But the last point I want to make is the most absurd one. We have tens of people dying every day in Tijuana. On the border, with the United States. Sometimes, 50, 60, 70. And, they are there basically dying to stop Mexican marijuana, among other drugs, from entering the United States. The small problem is that 120 miles north of Tijuana, in Los Angeles, there are more public, legal dispensaries of medical marijuana than public schools. There are more than a thousand medical dispensaries of marijuana in Los Angeles, perfectly legal. So we have our guys dying south of the border, to stop the marijuana from entering the United States, and being sold legally in Los Angeles. I think there’s something fundamentally wrong with that idea, it doesn’t work, it’s a war that cannot be won, it’s a war that should not have been waged, and it’s a war that we should call off promptly. The United States is not to blame for it, Mexico is not to blame for it, it’s a war of choice that President Calderón declared for strictly political reasons, thank you.

## Round 2

### Moderator
Claim: Thank you, Jorge Castañeda. And that concludes Round 1 of this Intelligence Squared debate. Our motion is, “America is to Blame for Mexico’s Drug War,” and we now have the results of where you our live audience stood before this debate began. You are the judges in this debate, you’re voting both before and again at the end, and the team that changes the most of your minds will be declared our winner. Here are the results where things started at the beginning. Our motion is “America is to Blame for Mexico’s Drug War,” at the start, 43 percent of you were for…22 percent against, and 35 percent undecided. So we’ll have you vote once again at the end of the debate, and the team that changes the most minds will be declared our winner. On now to Round 2 of this Intelligence Squared US debate, it’s our middle round, in which the debaters talk directly to one another, can challenge one another, and also we’ll take questions from myself and from you in the audience, and I’d like to start by asking you, Fareed, the point that Jorge Castañeda just made that, Mexico’s drug war basically is the fault of one man…do you buy it?

### Conspiracy Advocate (CA)
Claim: I’m a little confused listening to that whole team because, Asa Hutchinson says, consumption is down. Jorge Castañeda says consumption is up. I mean I’ve welcomed diversity but this is ridiculous. And more fundamentally it seems as though there is a contradiction here which is…Asa Hutchinson says, the problem, the reason Mexico has become this hellhole is because it did not declare war on drugs and did not prosecute efficiently and did not take the fight to the enemy. So then they do that, and Jorge Castañeda says, that’s the problem. I think it just proves that this is all kabuki. What we are talking about fundamentally is, these countries, among the poorer countries in the world, they are trying to fulfill insatiable demand for $65 billion of product. If it goes away from Mexico we will be back here next year, and we will be talking about, you know, the drug war in Peru, or somewhere else, because, the supply—Asa Hutchinson, as a Republican you surely believe, that, if there is a huge amount of demand from the richest country in the world, somebody is going to figure out a way to supply it.

### Moderator
Claim: All right, team—team—

### Conspiracy Advocate (CA)
Claim: That somebody is Mexico right now and we’re blaming them.

### Moderator
Claim: Team against, Fareed Zakaria has just said you’re contradicting each other. Asa Hutchinson, can you find unity.

### Scientific Advocate (SA)
Claim: Well, I think first of all, among the six of us up here there’s probably a different position on this issue for each one of us. But what this side is united upon is the proposition, and we have to come back to the proposition, that America is to blame for Mexico’s drug war. And there is unity on this side that that is not the case. Whether you take the argument that it is the decision of President Calderón, or whether it’s the fact of the historic problems in Mexico, their lack of cooperation or lack of the rule of law, America is not to blame. Now let me see if there’s unity on your side, Fareed. I just want to make it clear that if you’re saying America’s to blame to me that implies that there’s something wrong with our governmental policy. Now you can argue that as individual citizens, we should be making better decisions not to use drugs. But as you have libertarians on your side, that’s an individual citizen, not a governmental decision. So I assume that you’re saying our government is doing something wrong. We’ve had a balanced approach, strategy, of supply reduction, demand reduction, trying to teach young people to make good decisions, and rehabilitation. Do you want to move away from that to legalize marijuana, to legalize cocaine, to legalize heroin, to legalize methamphetamine, to legalize Ecstasy that comes from other countries. What is the position of your team, do you want to legalize all drugs, is that the shift in policy that you—

### Moderator
Claim: Jeffrey—

### Scientific Advocate (SA)
Claim: —wish to take.

### Moderator
Claim: Jeffrey Miron.

### Conspiracy Advocate (CA)
Claim: I don’t want to speak for others on that question—

### Scientific Advocate (SA)
Claim: I want an answer from Fareed first too, though.

### Moderator
Claim: No, let me, I want to go to the libertarian.

### Conspiracy Advocate (CA)
Claim: My— My position, separate from—independent of this debate is that we should legalize all drugs. I think the unity amongst the three of us although we probably differ in nuances of that view, is that, unquestionably the magnitude of resources we devote to prohibition is grotesquely excessive, that the set of things that we prohibit is substantially excessive, that there may be a role for government to try to address the negatives associated with drug use, through treatment, through harm reduction, through various policies, but that the current practice of spending tens of billions, by my estimates about $80 billion a year, locking people up, to try to get rid of the drug trade, is an incredibly counterproductive policy and we should stop.

### Moderator
Claim: Chris Cox, what’s wrong with that argument?

### Scientific Advocate (SA)
Claim: Well, I’d like to point out what may be another contradiction, Fareed seems to think that gun control is—

### Moderator
Claim: No, no, I want you to answer the question, what’s wrong with that argument.

### Scientific Advocate (SA)
Claim: I’ll defer to Asa Hutchinson on the—

### Moderator
Claim: Okay—

### Scientific Advocate (SA)
Claim: —the drug—

### Moderator
Claim: Fair enough—

### Scientific Advocate (SA)
Claim: —on the drug question.

### Conspiracy Advocate (CA)
Claim: Well, should I answer Asa’s… Because he’s charging me with—

### Moderator
Claim: Please—

### Conspiracy Advocate (CA)
Claim: Can I butt in on that too—

### Conspiracy Advocate (CA)
Claim: I mean, you—

### Moderator
Claim: Take it, Fareed—

### Conspiracy Advocate (CA)
Claim: —you might be surprised but Asa, I would join with the former presidents of Brazil and Mexico and Colombia, who recently put out a report in which they said, we just need a paradigm shift here because what we have done is criminalize and terrorize this entire process, by waging war on drugs, and what we need to start doing, is a comprehensive review of whether there are ways to decriminalize it. Look, many people have decriminalized drugs, I would be in favor of a controlled, slow, incremental approach, to see what happens. But I think there’s no question, that our current approach, massive criminalization, massive prohibitions, and most importantly the exporting of that war to other countries, is producing all the violence, it’s producing the criminality as Jeff pointed out. The reason this whole business is violent and criminal is because we have prosecuted it as a war. That is to me the fundamental responsibility we have, which we cannot shirk from. There are people dying in Mexico because of those choices that we have made.

### Moderator
Claim: Chris Cox, your expertise is the weapons issue, and the others—you made an argument that, laws restricting weapons won’t work, the other side is making more a simple argument, the very presence of American, of weapons sourced in the United States, are responsible for the war to some degree. Can you take on that question, the weapons are there—are those weapons part of the reason that—and they’re in the hands of the cartels—are those weapons part of the reason, that the war is going on and being prosecuted.

### Scientific Advocate (SA)
Claim: Well there’s no question when drug cartels are armed with hand grenades, when they’re armed with RPG’s, fully automatic weapons, that there’s a devastating effect on not only the drug cartels themselves fighting with one another but the innocent people in Mexico, who have no ability to defend themselves whatsoever. But the question becomes more of a common-sense type question. Is there something that the US can do, from a more gun control standpoint, that’s going to work any better than what works now, there’s a total ban—

### Moderator
Claim: Okay—

### Scientific Advocate (SA)
Claim: —on guns, basically—

### Moderator
Claim: Fair question—

### Scientific Advocate (SA)
Claim: —in Mexico now—

### Moderator
Claim: —let me take it to the other side—

### Scientific Advocate (SA)
Claim: It’s not working in Mexico.

### Conspiracy Advocate (CA)
Claim: All right—

### Moderator
Claim: Andrés Martinez.

### Conspiracy Advocate (CA)
Claim: Yeah, first off, I think Asa is twisting the proposition a bit by bringing it back constantly to the American government. “America is to Blame for Mexico’s Drug War,” the “America” there is, is a larger entity, it’s all of society. There are government policies but there’s also individual behavior and societal norms, and the disconnect between our laws and our behavior. And as a good Republican I would think that you wouldn’t necessarily always equate America with the American government. I think the dynamic— The dynamic here is there’s a pattern of behavior in terms of that this bilateral relationship. Where the United States historically has seen Mexico as a kind of back-yard Las Vegas where, the usual rules don’t apply, what happens in Mexico can stay in Mexico. So we can export our, our unresolved contradictions down there. People in Mexico are bearing the burdens of our conflict on drugs, and the fact that we have dysfunctional laws, it’s Mexicans doing the dying for our unresolved— We can’t bear as a society to go without these drugs, but we also can’t bring ourselves to legalize them. And—

### Moderator
Claim: Andrés, Andrés, I—

### Conspiracy Advocate (CA)
Claim: —what’s the cost of this—

### Moderator
Claim: —you’re not actually answering Chris’s question, Chris, restate your question—

### Conspiracy Advocate (CA)
Claim: I don’t—

### Moderator
Claim: —in one sentence— ANDRÉS MARTINEZ I didn’t have an opportunity to talk about the—

### Scientific Advocate (SA)
Claim: Okay, my question was, there’s basically a total gun ban in Mexico now. How effective is that working and do you think that we should bring that sort of gun ban to America, when if you look at cities like Juarez, Mexico, which are just devastated with cri—with drug cartel violence, and El Paso which is just a stone’s throw across the Rio Grande, that’s the third safest city in America, how do you rectify—

### Conspiracy Advocate (CA)
Claim: Well you’re also trying to twist the proposition into making it “America’s Gun Laws are to Blame for Mexico’s Drug War.” I think there’s a broader issue here, I mean I would follow the money, not necessarily the guns. There are an awful lot of American guns making their way to Mexico. However, it is true, that if you’re making $20-30 billion in the United States because American society has decided that this one industry that it doesn’t want to go away is going to be ceded to criminal organizations, you would be able to buy those guns elsewhere, I will grant you that. If the United States had the toughest gun control laws in the entire world…the Mexican drug cartels would still be armed to the teeth. What they’re really getting out of the United States, first and foremost, is guns, the fact that it’s very convenient for them to pick up guns while they’re here tallying up their profits, that just adds insult to injury.

### Moderator
Claim: Jorge Castañeda.

### Scientific Advocate (SA)
Claim: I would sort of go back to another question, my impression is that, at least on that side, you all seem to agree that this is a failed war. Which is certainly what I think, it’s the title of my book. I quote at length, Zedillo, Cardoso and Gaviria document at the end, who also said it’s a failed war. And I think that this is—failed wars should not be waged. If you continue, if you persevere in a failed war, you will continue to fail. So I think the key issue there is, what should Mexico and the United States, and basically the two governments because there, Andrés, it’s difficult to decide on the part of American society or Mexican society, that’s why you vote, that’s why we vote now. We didn’t always— We always voted but sometimes we voted for people or sometimes people voted for us but anyway. Or the government did. But, the fact is that now the question is what should the governments do. And the problem is that the Obama administration and the Calderón administration are in total synch in continuing this failed war. Pouring money into it, having more people die in Mexico because of it, while at the same time—and I agree with the Obama administration— at the same time, President Obama and Attorney General Holder say they are not going to apply federal anti-marijuana laws in those states that have legalized medical marijuana. Which I think is wonderful by the way. What I don’t understand is why President Obama and Attorney General Holder on the one hand do that, and on the other hand, give money to Calderón to wage a failed war on drugs. I think that’s the real question, not so much if I may be allowed to say so, who is to blame for Mexico’s drug war, which perhaps was not the right way to phrase the debate.

### Moderator
Claim: I’ll come back to you, Asa, Jeffrey Miron. I will come back to you.

### Scientific Advocate (SA)
Claim: Just want to say I agree with that—

### Moderator
Claim: Okay, let— Are— you wanted to say very briefly?

### Scientific Advocate (SA)
Claim: Oh no, I just for once I do agree with my debate partner— I think he sorta nailed it—

### Moderator
Claim: It’s so nice when it works out that way.

### Conspiracy Advocate (CA)
Claim: You just heard—

### Moderator
Claim: Jeffrey Miron—

### Conspiracy Advocate (CA)
Claim: Just heard Mr. Hutchinson say it that they’ve only agreed with each other once so far this evening. To go back to the gun point. What Christopher Cox is arguing is that if you take a substance, a commodity, that a large number of people want to own, and you prohibit it, a whole bunch of consequences happen. The market goes underground, it may shrink a bit, you may make it more costly, but it’s not going to disappear. It’s going to go underground. Then there will be corruption, as people try to evade those laws, there will be violence as people in the underground market resolve their disputes. There will be poor quality control and so on and so forth. Mr. Cox makes that argument, with respect to guns. Okay, he’s opposed to strenuous gun laws to prohibiting guns, but exactly the same arguments, apply to prohibiting drugs. The structure of the argument, the logic of the argument, is totally compelling, and it’s right for both commodities, not just one, and not just the others, so libertarians think that guns should be legal, and drugs should be legal. I hope that my opponent agrees with that proposition. CHRIS COX Actually, I agree— I agree with quite a bit of Jeff’s arguments, certainly—

### Moderator
Claim: Chris Cox—

### Scientific Advocate (SA)
Claim: —not with regards to guns but I certainly agree with your study—

### Conspiracy Advocate (CA)
Claim: Oh, they’re dropping like flies on that side—

### Scientific Advocate (SA)
Claim: Actually—there is a contradiction, believe it or not there is a contradiction on the other side. Fareed has pointed out some false statistics to suggest that more gun control laws would somehow have a major impact in this drug war. Ice agents have said we already have—

### Moderator
Claim: Fareed, did you make that—

### Conspiracy Advocate (CA)
Claim: I don’t think he said—

### Moderator
Claim: Did you make the point about gun control—

### Conspiracy Advocate (CA)
Claim: No, my point was the one you raised, the general prevalence of 280 million guns here, which is about a third of all guns worldwide, the fact that we share a border with one of the poorer countries in the world, and there is vast drug trade and vast cartels means…this is an easy way to criminalize and to accelerate the violence of this trade.

### Moderator
Claim: All right, I interrupted you because I didn’t hear Fareed make that argument, so

### Scientific Advocate (SA)
Claim: Okay, what I heard Fareed say was parrot many of the arguments that have been made by the gun control community but perhaps that’s not a fair reflection on Fareed’s own personal views but the contradiction is that, to suggest that we have a lot of guns, therefore, we’re part of the problem is to suggest that more gun control would make us less of a problem, and I think what Jeff has argued, certainly in his past writings is that, homicide rates amongst countries with the highest gun control, tend to be higher than homicide rates with those countries with the lowest gun control. So that’s certainly an area where I agree with Jeff but I would not agree with Jeff that, crystal meth, crystal meth addicts all over this country that are devastating communities all over this country are somehow a fair comparison to law-abiding gun owners in this country.

### Conspiracy Advocate (CA)
Claim: Can I—could I respond to that, I mean—

### Moderator
Claim: Yes, please do.

### Conspiracy Advocate (CA)
Claim: Throughout the last—

### Scientific Advocate (SA)
Claim: We talked about—

### Conspiracy Advocate (CA)
Claim: —90 years—

### Scientific Advocate (SA)
Claim: —legalizing drugs—

### Conspiracy Advocate (CA)
Claim: —the drug prohibitionists have identified one—

### Scientific Advocate (SA)
Claim: —we’re talking about legalizing crystal meth?

### Moderator
Claim: Sorry?

### Scientific Advocate (SA)
Claim: We’re talking about legalizing crystal meth now—

### Conspiracy Advocate (CA)
Claim: Yes. Yes, because if you go back and read what people were writing in the 1950s—

### Moderator
Claim: Jeffrey Miron—

### Conspiracy Advocate (CA)
Claim: —about marijuana. They were saying things absolutely as strong, absolutely worse than what people are claiming now about crystal meth, if you look at the data on the—

### Scientific Advocate (SA)
Claim: Whoa-hoahhh—

### Conspiracy Advocate (CA)
Claim: —number of people who use crystal meth, there’s zillions of people using it every day and a teeny fraction of them are doing the kinds of things that you’re describing. The drug prohibitionists for 90 years have constantly had a moving target, as soon as they identify one drug and say this is the killer drug, this is the one that’s the most evil, this is the one that’s going to destroy society.

### Moderator
Claim: But, relevant to—

### Conspiracy Advocate (CA)
Claim: And there’s some violence—

### Moderator
Claim: —relevant to our motion—

### Conspiracy Advocate (CA)
Claim: —associated with trying to prohibit that—

### Moderator
Claim: —relevant to our motion, Jeffrey’s point is that if you decriminalize, the need for war would go away because the bad guys wouldn’t have to defend and fight out on the streets, they could do it in courtrooms.

### Scientific Advocate (SA)
Claim: But, and—

### Moderator
Claim: Do— what do you think of that.

### Scientific Advocate (SA)
Claim: Again, I think the point’s almost irrelevant. The point is, whether or not the weapons that we’re suggesting, and Jeff has written as well that… violence— Weapons don’t create violence, violence creates a need for weapons and that these weapons are coming as even Andrés has pointed out from other areas, not only Central America but Russian, the former Soviet blocs that dumped guns in Mexico during the Cold War by the millions, if certainly by the tens of thousands. These weapons are there, and so, it’s really—I tend to agree with Jorge, we’re missing the point here—

### Moderator
Claim: Right.

### Scientific Advocate (SA)
Claim: Is America to blame, of course we’re not—

### Moderator
Claim: Well let me ask Asa, the whole decriminalization question seems to get your hackles up.

### Scientific Advocate (SA)
Claim: Well— I think—

### Moderator
Claim: His point is not whether it’s good or bad for the users, his point is whether it would make the war go away.

### Scientific Advocate (SA)
Claim: And I’m going to get to that, but I would think— I would think, I was hoping that we would have agreement that cocaine, methamphetamine, heroin are harmful drugs and our goal in society would be to reduce the usage of those drugs.

### Conspiracy Advocate (CA)
Claim: Well do you think—

### Scientific Advocate (SA)
Claim: After hearing Jeffrey say—

### Conspiracy Advocate (CA)
Claim: —alcohol and tobacco are harmful drugs—

### Scientific Advocate (SA)
Claim: After Jeffrey argues that methamphetamine is not as harmful as everybody says, and that would include the decriminalization, we can’t even reach an agreement on that point. But if you want to reduce usage, for example Alaska in the ‘70s voted to decriminalize marijuana. And once they did that guess what happened. The usage went up, parents did not like what they saw, and so the Alaskan voters voted to recriminalize that offense. Because usage went up, and that should not be the goal of parents, that’s the concern of parents. In terms of the drug trafficking and the war, I would make the argument it might have some peripheral impact, it depends on the extent that you legalize, if you just legalize marijuana, they’re not going to go away. Guess what, they’ve got cocaine, they’ve got heroin, et cetera, to market. If you legalize all of them, guess what. You still have prescription drugs there would be a black market on, that are totally regulated. They’re moving into other areas from alien trafficking, they’re business people. And the only solution to the war on drugs, is the rule of law. And Mexico does not have that right now. I want them to have that, Calderón seems to want them to have it. The fight is on the rule of law and unless you establish that, decriminalization is not going to rid Mexico of the drug war.

### Moderator
Claim: Andrés, just one second, I’m going to come right to you, I want to go after Andrés speaks to questions from the audience, I want to remind you once again, raise your hand, I’ll find you, a microphone will be handed over to you, stand up, if you’re a member of the news media please identify yourself, and please make it a question. Andrés.

### Conspiracy Advocate (CA)
Claim: I totally agree that the issue is the rule of law but it’s the rule of law in this country, it’s our failure to uphold the rule of law that is to blame for Mexico’s drug war. We are the ones with an addiction rate of illicit drugs that’s six times higher than in Mexico. We are the ones who are abusing this stuff, but can’t bring ourselves to legalize it, and it’s people in Mexico who are dying for that. We as a society, and I don’t think--you can be agnostic about whether or not drugs should be legalized, if that were the subject, the proposition tonight, I’m not sure which side I would be on. You can be agnostic on that, and still recognize the, the basic fact that the United States is to blame for the war on drugs. And I’m glad you mentioned immigration because you say, well, they’re diversifying into human trafficking. Well geez, I wonder why, again. Our failure to enact an immigration reform that matches supply and demand, again, we—again, back to my point about—

### Scientific Advocate (SA)
Claim: You’re blaming the United States for a lot of ills, in the world—

### Conspiracy Advocate (CA)
Claim: Well…let’s think about this, we are as addicted to Mexican low-cost labor as we are to imported drugs—

### Scientific Advocate (SA)
Claim: And Mexico has no—

### Conspiracy Advocate (CA)
Claim: —but we fail—but we—

### Scientific Advocate (SA)
Claim: —responsibility whatsoever—?

### Conspiracy Advocate (CA)
Claim: But we cannot— But we cannot bring ourselves to create legal channels for that. So either we have to decide, let’s close down the border, not import low-cost labor, and it’s the similar—it’s a parallel debate to what’s happening on the drug front.

### Moderator
Claim: Let’s

### Conspiracy Advocate (CA)
Claim: Your point about marijuana, 60 percent of the cartels’ profits come from marijuana—

### Moderator
Claim: Audience questions now. If you just bring your hand up… There’s a gentleman, with a blue shirt, necktie, no jacket. Thank you.

### Moderator
Claim: Hello, this is a question for Mr. Hutchinson. And I want to remind everybody how Mr. Hutchinson started talking. Mr. Hutchinson started talking that as a representative of the US government, he was in Mexico, and he was trying to pressure the government of Mr. Fox, to bring troops to go after, or people, to go after the people that had killed Mr. Camarena. And had tortured Mr. Camarena. I have these two—there are two questions that arise from. Both of them—

### Moderator
Claim: Just, just—I, I’ll just take one.

### Moderator
Claim: Okay. The, the question that arises from that, doesn’t he feel, as a representative of the American government, that he has a special duty to respect the sensitivity of the Mexican people about bringing American armed forces into Mexico. Because there is a special event in the Amer—Mexican

### Moderator
Claim: Okay, I—sir, I’ll stop you there because, you did ask a question—

### Moderator
Claim: No, but this is very important that he forgets—

### Moderator
Claim: Sir, I’m sorry, I need you to—

### Moderator
Claim: —the United States took away—

### Moderator
Claim: —get to your point and we do understand—

### Moderator
Claim: —50 percent of Mexican—

### Moderator
Claim: Asa, why don’t you take it and then Jorge wants to try—

### Scientific Advocate (SA)
Claim: Yeah, I think that it—

### Moderator
Claim: Thank you, sir.

### Scientific Advocate (SA)
Claim: Thank you, sir, it is actually a very good point that, if the United States did not regard Mexican sovereignty, and we wanted to solve the transit and source country problems we would send our troops there. But they’re a sovereign nation and we cannot go in there without an act of— declaration of war or some good cause which doesn’t exist, we’re not doing that, we’re regarding their sovereignty. But whenever we have a high regard for their sovereignty, that means America is not to blame. And yes, it wasn’t President Fox that I—I did go to see him but, Camarena was killed under a previous administration, I was not administrator then. But I know that history very well because it lives in the hearts of every DEA agent. And the fact is that he was murdered brutally, but more importantly, we wanted to assist Mexico and we were not allowed to do so because of the sovereignty of that country. Responsibility is something that’s shared, blame is something that is uniquely America’s fault, and that is not the case here.

### Moderator
Claim: Fareed Zakaria.

### Conspiracy Advocate (CA)
Claim: Can I just point out that we are respecting Mexico’s sovereignty, we are not respecting so much Afghanistan’s sovereignty, we have a hundred thousand troops in there, NATO and the US, we will have 130,000 troops in there. And yet, we have not been able to do anything about the opium trade. I doubt very much if we send American troops into Mexico it would change the fundamental fact, where there is demand there will be supply—

### Scientific Advocate (SA)
Claim: Guess what, we’re not doing that, that’s not the suggestion—

### Moderator
Claim: Jorge Castañeda—

### Scientific Advocate (SA)
Claim: —it’s not on the table—

### Scientific Advocate (SA)
Claim: Just as a point of factual issues here. To the best of my knowledge, and although I was not present at all of the meetings but between my father, my brother and myself we have been present at most of the summit meetings between American and Mexican presidents over the last 30 years, I do not recall ever the United States having asked for US troops to go to Mexico, firstly. And secondly, strangely enough, though obviously I stand by what you both quoted, in the case of President Calderón, in December of 2006, my impression, I don’t know this as a fact. My impression is actually, that the Bush people did not pressure him into declaring this war. This was a decision he made absolutely on his own. Unlike what had happened on other occasions under Echeverría, López Portillo, mainly de la Madrid, and then again on—under Salinas, my impression back then, the US did pressure these Mexican presidents to engage in more active drug enforcement, but the Bush people, not because they believed in not holding, pursuing this war, but perhaps because they had other wars to pursue, which were concentrating their attention at the time—

### Moderator
Claim: Okay, halfway up the aisle there—

### Scientific Advocate (SA)
Claim: —did not pressure Mexico.

### Moderator
Claim: Hi, I’m Robert Aleto, I’m a student. My question concerns the Mexican national economy and what role you think that plays in this issue. Because, there’s been a lot of demographic

### Moderator
Claim: And will you be able to relate this to our question about whether America is to blame.

### Moderator
Claim: Well—

### Moderator
Claim: I think you probably can but—

### Moderator
Claim: Transformation of the Mexican economy over the last several decades, I mean, America has a lot to do with that. And so I’m wondering if that transformation plays a role, in this drug violence, ‘cause a lotta these other factors, doing drugs, the transfer of guns, they seem fairly static, whereas, you know, the violence in Mexico has increased tremendously over the last few years, what is not static, what is changing—

### Moderator
Claim: Okay. Andrés Martinez.

### Conspiracy Advocate (CA)
Claim: Well, I think it’s true that Mexico has, really undergone a tremendous transformation, it’s a poor country compared to the US but it’s actually, if you look at it in global terms, it’s a fairly successful, relatively successful middle-income country plodding along, it’s just a stark contrast that it shares a border with the US. I think that the United States has opened up Mexico’s economy through NAFTA and through other ways so, it probably has given—the Mexican cartels have been able to take advantage of that—I don’t—I think it’s a little bit of a side issue to our main discussion here. But if you think about Mexico becoming a logistical hub for this global enterprise, a lot of what’s changed in Mexico has probably accelerated that and aided it. But—

### Moderator
Claim: Does this mean NAFTA is to blame for Mexico’s drug war—

### Conspiracy Advocate (CA)
Claim: But it’s— You know, I think just because it’s a lot easier for a lotta people in Mexico now to do business, likewise for the drug cartels, but I think this is a bit of a side issue.

### Moderator
Claim: Okay. There’s a gentleman, with the eyeglasses, and your hand is up, doing one of these. And the mic’s coming down to you. And again I urge you to be… question terse—

### Moderator
Claim: Hi, my name’s Tony Amato, I’m a Penn State student. My question is to the panel that is motioning against. What I want to know is… the amount of money that’s made in the drug trade, is astronomical. If you were to legalize or decriminalize or end prohibition on drugs, how would these drug cartels pay for this organization. I mean you did comment and say they, they could traffic people, they could traffic illegal goods, but the bulk of the money, comes from illegal drugs, so if you take the revenue stream out, how could they finance the, the organization, that’s what I’d like to know.

### Moderator
Claim: Okay, so Jorge Castañeda, why don’t you take that—

### Scientific Advocate (SA)
Claim: Well—

### Moderator
Claim: —and Asa, do you want to also—

### Scientific Advocate (SA)
Claim: I think it would be very difficult for them to finance which is why I also favor growing decriminalization or depenalization, I think that it would help, it’s easy or relatively easy I think with the marijuana and heroin issues, cocaine and methamphetamine issues are complicated, they’re more complicated. But you can start with something and see where it goes. The main point is I think you’re absolutely right, a lot of the profits would diminish. They’d go into the other businesses, yes, that’s absolutely true what Asa what saying. But the core business remains drugs. Let’s not get that part wrong, that’s the core business, and if you legalize that then, yes, you will probably have them making less money.

### Moderator
Claim: The other side care to respond, if not I’ll move on. Okay.

### Conspiracy Advocate (CA)
Claim: The experience of US alcohol prohibition, was that the vast majority—

### Moderator
Claim: Jeffrey Miron—

### Conspiracy Advocate (CA)
Claim: —of the illegal alcohol producers, became legal alcohol producers, and there was not a big surge in violence as they went into some other industry because initially there were not other industries that were highly prohibited for which they could make a lot of profit, they had to make an honest living in legal industries and the rates of returns were modest.

### Scientific Advocate (SA)
Claim: La Cosa Nostra, organized crime, came into existence and benefited tremendously after Prohibition, they had plenty of work to do, organized crime in the United States, even after Prohibition.

### Conspiracy Advocate (CA)
Claim: From trafficking in drugs, which were illegal.

### Scientific Advocate (SA)
Claim: Well, they, in a whole— They— and a whole host—

### Moderator
Claim: Gentleman in the red tie? And if you can stand the mic will be handed over to you.

### Moderator
Claim: The term “black market” invariably means, free markets that have been driven underground as Mr. Miron has eloquently demonstrated, particularly with the example of Prohibition. That happens because of bad laws or I would say, immoral laws. Mr. Miron, can you relate, the discussion has been more on practical matters, this works, that doesn’t work. But this is a moral issue and it’s an issue of individual rights, can you relate…the drug laws to individual rights and perhaps being a libertarian you might be able to relate it to the objectivist position.

### Conspiracy Advocate (CA)
Claim: Um… I’m actually more of a consequential libertarian than a rights-based libertarian, but we shouldn’t probably get into that—

### Moderator
Claim: Well, we’re getting some real inside libertarian baseball here.

### Conspiracy Advocate (CA)
Claim: Yeah. But I think that your question can be phrased in one of two ways, one way some people think about this issue of drug use is to say, individuals have rights to consume what they want, to do what they want as long as they’re not harming innocent third parties. A different way that people would say it is that, we should prohibit actions which negatively impact third parties without really using the word “rights.” We should let them consume what they want because it makes them happy, we don’t necessarily have to use those words, but they lead you to exactly the same positions. Both the moral perspective and the sort of mundane, practical perspective. We think about what the policies are, the policies have different consequences, and you can include morality as one of those sets of consequences. But the libertarian position is we should look at all the sets of consequences, not just the feel-good consequences—not just the alleged consequences, say eliminating drug use, which in fact doesn’t happen—when we decide whether to criminalize drugs.

### Moderator
Claim: I just, yes, right here. Thank you, sir.

### Moderator
Claim: I wonder if you look back on the history of drug abuse in this country, it feels not only an underground element, but it fuels other addictions—sexual addictions, it fuels the necessity, the necessity to try and buy drugs—regardless of what they cost. Because the ultimate problem with drugs is that they cost money. And if you know, if we legalize ‘em, they are going to be more expensive than they are now, because the government will get involved in trying to… Of course, we put a…

### Moderator
Claim: Sir, sir, how…? Could…?

### Moderator
Claim: Yeah.

### Moderator
Claim: With respect to your question…

### Moderator
Claim: Well, what I want to say is…

### Moderator
Claim: …how would you relate it to our, to our discussion?

### Moderator
Claim: Well, what… The question is… Legalization of drugs is not going to change anything, and it’s not the reason for America’s blame on the Mexican drug problem, or the Mexican drug war. Now what I want to understand from you people is….how do you feel that the legalization is going to make, all of a sudden, everything great? And no one is going to do drugs, and no one is going to create crimes, and nothing is going to happen that’s going to become more problems…

### Moderator
Claim: But you, I don’t think that’s what your point is here…

### Moderator
Claim: Well, you…

### Moderator
Claim: Well, let’s take a hack at it.

### Conspiracy Advocate (CA)
Claim: You have a controlled experiment. It is very rare in history to have a very simple, controlled experiment—which was the prohibition of alcohol. And all these arguments were made—and that’s alcohol consumption did decline somewhat during Prohibition, but it produced a vast criminal enterprise. It produced associated crimes in exactly the way you are describing. And then, once it was decriminalized, most of it—the vast majority of it—went away. So you know, nothing… No analogy is perfect, but it’s very rare in history that you have actually, a case that’s about as close as you can get… It’s very important also to point out, I think, for people thinking about this. There are many different ways you can decriminalize.

You can decriminalize with, you know, medical use. You can decriminalize with a very strong public health campaign, the way we have done with tobacco. It can be even stronger in terms of the regulatory issues involved. So it… That you can decriminalize some and not others. I do not agree that it is impossible to draw some lines. Well, we draw lines all the time. Alcohol is, at some level, a drug, and we have decriminalized it. So it is possible to do this in many different ways. We do have one historical example that’s pretty powerful.

### Moderator
Claim: OK. Just a little bit of radio business. We are in the question and answer section of this Intelligence Squared U.S. debate. I am John Donvan. As moderator, we have six debaters—two teams of three— debating this motion: “America is to Blame for Mexico’s Drug War.” I’d like to know, is there a question on the weapons issue, because we have Chris Cox here, and that is, that is his purview and that… Do I see a hand going up? Yeah, yes, down in the…the third row. I’ll bring a mike over to you.

### Moderator
Claim: My name is Alan Borstein, and I have a pistol license for three pistols and five shotguns in my apartment on Park Avenue. I have not used any of them…

### Moderator
Claim: Stand clear.

### Moderator
Claim: Yeah.

### Moderator
Claim: Go ahead.

### Moderator
Claim: Well, birds, which I eat. And, um… I think the gun issue is a totally separate issue and maybe something for debate at some point as to how they should be controlled. As far as the drug issue is concerned, I think that taxing it would be a great help. And, I wonder if you think there are other ways to reduce consumption in the United States, besides the drug war and what…

### Moderator
Claim: All right, fair question. Since… And why don’t you take that, uh, Jeffrey?

### Conspiracy Advocate (CA)
Claim: There are certainly possibilities for reducing use of any substance that we legalize, relative to what you would get otherwise. Minimum purchase ages might have some effect, although the evidence suggests they have relatively minor effects. A tax is almost certainly the most effective way, because that unambiguously raises the price. But there are clearly limits to what you can do with the tax, because if you make the tax high, try to make the price really high, you drive the market back underground. So the accurate view is—you can adjust how much people consume somewhat, but you can’t fundamentally change the fact that people are going to use these substances.

And whether you are getting the people you would like to discourage to stop using is much, much less clear. In particular, by making it illegal, people who have no respect for the law are likely the ones who go ahead and consume it anyway. The people who are likely the responsible users—the ones who might do it in moderation were it legal—are the ones who are deterred, so that’s exactly backwards under a policy of Prohibition.

### Moderator
Claim: There is a gentleman with a…waving a green card? The mike is coming to you.

### Moderator
Claim: Thank you, good evening. I have been an avid reader of Jorge Castañeda for years and years. And aside of his very well recommended agenda against President Calderón, he tried to change the terms of the debate tonight and put the blame on President Calderón. To me, it is crazy for President Calderón to wage a war the way he is doing. He is very courageous and I applaud him.

And today, Jorge failed to present a side—just throwing punches against the President of Mexico—for him to present an alternative. He failed tonight. He failed in his recent book. I would like to hear something, a real proposal like this—without the comprehensive, comprehensive strategy against President Calderón. Thank you.

### Moderator
Claim: Well, do you really want to take that, ‘cause I am…

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: …willing to give a pass on that…

### Scientific Advocate (SA)
Claim: No. No. I am very glad to hear my very good friend, Ruben Beltran, the Consul General of Mexico in New York, defend the government he works for. But…

### Scientific Advocate (SA)
Claim: …in the interest of full disclosure…

### Moderator
Claim: Oh…

### Scientific Advocate (SA)
Claim: …Ruben, it’s always better to be as open as possible on these matters…

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: …and I have great respect for Ruben’s professional wisdom as a Foreign Service Officer. He was an excellent officer when he served under me, and he continues to be an excellent officer.

### Moderator
Claim: OK, we understand. Go ahead.

### Scientific Advocate (SA)
Claim: Yeah. Just in case…

### Moderator
Claim: Yeah, yeah.

### Scientific Advocate (SA)
Claim: …if there was a little confusion there…

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: OK. I think there is an alternative, I think it is in the book. And of course, in the one or two minutes of the seven I had for this, I did try to lay it out. One of them has to do with not waging a war against all the cartels all the time, but concentrating on limiting collateral damage—that is, violence, kidnappings, corruption, etc.— without necessarily going after the drug trafficking itself, which is essentially what Uribe has done in Colombia. And I go back to the issue: There has been no reduction in coca leaf acreage in Colombia over the past 10 years.

Second, creating a national police force so that you don’t have to use the army. Every time we use the army, we get into human rights violations, we get into corruption of the army. This is a bad idea. We haven’t created a national police force. Zedillo didn’t do it; Fox, when I was in government, didn’t do it; and Calderón hasn’t done it. And until we do that, it won’t work. And that’s another part of the alternative.

### Moderator
Claim: OK.

### Scientific Advocate (SA)
Claim: And the third part of the alternative is, once again, moving in the direction of decriminalization, so that we try and reduce the profits for that.

And fourthly, yes, there is something to be done in truly sealing the border in Mexico—not at the southern border with Guatemala—but at the , which requires much more cooperation from the United States to do. What we’d be doing is just pushing the drugs out into the sea coming into the United States, but there is a good case to be made: Drugs want to come to the United States because Americans want to keep consuming them. What we in Mexico are interested, quite honestly, is that they don’t come through Mexico.

### Moderator
Claim: Hmmm. Andrés, do you want to be very brief?

### Conspiracy Advocate (CA)
Claim: I just want to very briefly take issue with Jorge’s repeated insistence that this “war” started in December of 2006. Yes, President Calderón ratcheted up the effort, but as we have been discussing here tonight, this problem in Mexico specifically—but in the broader regions, the region more generally—dates back many decades. And even the year before Calderón took office in 2005, if you had been living in you would feel there was a helluva war going on. So I just wanted to make that clear.

### Moderator
Claim: Is there… Is there not a single woman in the audience who wants to ask a question here?

### Moderator
Claim: OK.

### Conspiracy Advocate (CA)
Claim: A single woman or a married woman?

### Moderator
Claim: Well, why are you wording it that way? But thank you for doing that…

### Moderator
Claim: Hi, I am a student at NYU, my name is Alexandria Newton.

Thank you guys for being here, and it’s really great to have you on our campus. But I just wanted to ask. Would either side believe, does…? Does either side believe that the international drug wars could have been prevented if Richard Nixon and America didn’t declare that war on drugs?

### Moderator
Claim: Asa Hutchinson.

### Scientific Advocate (SA)
Claim: Well, I really have problems with the language that Richard—that President Nixon used: “War on Drugs.” I think that’s very unfortunate, because one, it implies an end; you like to have wars end; and secondly, it implies too much violence in that name. And so, I, as head of the DEA, resisted using that; I like to use “the fight against illegal drugs.” The fight for our families. You know, reducing, use agent addictions. So I think that is very unfortunate.

In terms of internationally, sure. The United States provides leadership whether it’s in the area of democracy and freedom, or whether it’s in trade. People do respond to the United States, so we have provided some leadership in terms of the fight against illegal drugs. But the bottom line is: Each of those decisions— well, they would never do anything, just because the United States wants them to do it. You look at the Netherlands, for example. The Netherlands started down the path of decriminalization. They are toughening it up a little bit. They see some serious problems there. And so every country is making decisions on their own. But I would say, by and large, the consensus historically has been: drugs are harmful. Let’s keep ‘em out of our families. The best way to do that is to keep them illegal.

## Round 3

### Moderator
Claim: And that concludes Round 2 of our debate. Here is where we are. We are about to hear closing statements from each debater. They will be two minutes each, and it’s their last chance to change your minds. After you hear them speak, you will vote for the final time on where you stand on the motion. But to remind you of where you stood before the debate: Before the debate, our motion being “America is to Blame for Mexico’s Drug War,” 43 percent of you were for the motion, 22 percent were against, and 35 percent were undecided. We’ll have you vote again in just a few minutes. And we are a short time away from learning who is the winner of this debate.

So Round 3: closing statements. And first to summarize his position against our motion “America is to Blame for Mexico’s Drug War,” Asa Hutchinson, former Congressman, DEA administrator, and Undersecretary for the Department of Homeland Security.

### Scientific Advocate (SA)
Claim: Thank you. And I am grateful for this chance to debate with my colleagues in respectful fashion. If I have been rude, please forgive me. It’s been a very healthy debate.

I am a little bit startled by the push toward legalization because I don’t think that is particularly relevant toward the topic. The topic being: Is America to blame? And quite frankly, if you would have asked the question, “Does America have some responsibility, in terms of their drug consumption, as to the challenges that Mexico faces,” I would have to agree with that. But I think that is totally different. And that’s not your decision today. It is: “Is America to Blame?” That implies that we are doing something wrong in our policy. And I don’t believe that we are.

And secondly, it implies that somehow we have made Mexico make these decisions. And I do not believe that the affirmative side has taken that burden of proof. They have not had any facts to support the proposition that somehow the United States has made Calderón—President Calderón—go after the drug cartels. I think the history is clear from everyone’s statements, that Mexico—and rightfully so—stands tall among the sovereign nations of the world. It was their congress that has said drugs are illegal in their country. It is their culture that has resulted in the society they have that—which there is according to President Calderón, a “culture of corruption” in that country—that they have to address.

Historically though, you have to go back 25 and 30 years and these problems are systematic. They are integral to the history of Mexico. And the United States is not to blame for that. America is not to blame for what is being phased in Mexico today. They say it’s because we have a consumption problem. That might be debate. I think the evidence is that marijuana use has declined from the ‘90s from 9.1 percent to 6.8 percent.

### Moderator
Claim: Asa Hutchinson…

### Scientific Advocate (SA)
Claim: It might go up, it might go down.

### Moderator
Claim: …your time is up. Thank you. Asa Hutchinson. Our motion is: “America is to Blame for Mexico’s Drug War.” And now summarizing his position for this motion, Fareed Zakaria, Editor of Newsweek International, and host of CNN’s Fareed Zakaria GPS.

### Conspiracy Advocate (CA)
Claim: Thank you all very much. And I want to tell you an anecdote. I was in Singapore about 15 years ago and the leader of Singapore, Lee Kuan Yew—a tough guy who runs a pretty tough shop—was coming under some pressure because he had very strict drug testing programs in Singapore. And he explained the problem to me this way. He said, “You see, you Americans look at things very differently than we do. When you have a drug problem, you look around and say, ‘Well, where are the drugs coming from? Panama. Let’s go in and invade Panama, arrest the president, put him in jail, and that’s how we’ll solve the drug problem.’ ” He said, “I don’t have that option in Singapore. I have got to actually deal with the problem I have in my society. And for that reason, I am going to have intrusive drug testing.” I raise this to make two points. One, you don’t have to believe in decriminalization to believe that we are exporting this problem and have been exporting the war and the criminalization from the Caribbean through Colombia, and now into Mexico. But the more important point I want to make—and I urge you… You know, it’s often you could look at these things as games. It is very important that America own up to its responsibilities. That we not push the blame on one more poor country, on one more neighbor. That we recognize that we do have something to do with what is going on. This is a disease in American foreign policy, it is a disease in American society. And it is very important that you and the vote you make—and we as a society— own up to it.

There is this wonderful quote from Fitzgerald’s Gatsby that I always remember about Tom and Daisy Buchanan. He says of them—as typical Americans—he says, “They were careless people, Tom and Daisy- they smashed up things and creatures and then retreated back into their money or their vast carelessness.” Let’s not be like that. Let’s take responsibility.

### Moderator
Claim: Thank you, Fareed Zakaria. “America is to Blame for Mexico’s Drug War” is our motion. And summarizing his position against that motion, Chris Cox, Chief Lobbyist for the National Rifle Association.

### Scientific Advocate (SA)
Claim: Thank you. What’s clearly not to blame is America’s Second Amendment or the lack of some law to outlaw what’s already illegal on both sides of the border. To even suggest that this criminal enterprise has anything to do with our rights is absurd. It’s preposterous.

So let me be clear where we come from. Do we support the current administration’s proclaimed conviction to hunt down and root out the drug cartels? Absolutely. Do we feel for the poor Mexican people who are being terrorized by narco terrorists?

They are abandoned by their own officials. They are left defenseless by their own, their own government? Of course we do, passionately. But we are going to give up our Second Amendment rights on some empty promise that’s going to—this is going to make the Mexican people safer? Not now, and not ever. Our rights don’t endanger anyone—and they make this country freer, safer, and a lot more stable than other countries around the world, including Mexico.

American law enforcement can work with the Mexican government, should work and does work with the Mexican law enforcement to bring people to justice who break the law. Collectively, we have the tools, we have the intelligence, we have the manpower, but what we apparently lack is the guts—that straight and high integrity to tell each other the truth on all these issues. Until we get to that point, until we can look each other in the eye and tell the truth and be honest, this whole question is irrelevant. Thank you.

### Moderator
Claim: Thank you, Chris Cox. Summarizing for our motion, “America is to Blame for Mexico’s Drug War,” Jeffrey Miron, a senior lecturer and Director of Undergraduate Studies in the Department of Economics at Harvard.

### Conspiracy Advocate (CA)
Claim: Again, thank you very much for being here and for listening. Let me start by conceding some elements of merit in my opponents’ points. First, I think Mr. Cox is absolutely right, U.S. gun policy has nothing to do with the issue. There would be just as much of a drug war, just as much violence, if we banished U.S. guns; the guns would come from somewhere else.

I think Mr. Hutchinson has a fair point. Countries are meant to be sovereign. Mexico could, in principle, say “We don’t care what U.S. policy is. We don’t care about NAFTA. We don’t care how much the U.S. is harassing us. We are going to legalize drugs,” or “We are going to de-escalate our own drug wars, because that’s a sensible thing to do.” In principle, could they do that on their own? Yes. Would they come under enormous international pressure and U.S. pressure? Absolutely. So I think he is painting much, much too optimistic a case.

I think that Jorge Castañeda has a very valid point. Certainly, the situation got much worse when Calderón escalated, OK? And the degree to which you try to enforce a “drug war” plays a huge role in how bad it is. Many European countries have laws which are not so different than the U.S. laws, but they basically do almost nothing to try to enforce them. They leave the cartels, they leave the suppliers basically alone, and they don’t get nearly the magnitude of the violence and other negative side effects. So there is certainly a valid point there as well.

I would also note, I think, that four of the six of us here could agree that we would have liked the question to have been, “Should the U.S. and Mexico de-escalate their war on drugs,” OK? And I think the three of us here—along with Jorge—would all agree with…in the affirmative for that. So perhaps we can have another discussion on that point.

But at the end of the day, the fact is that the U.S.—throughout the last 90 years—has done everything in its power to push its Puritanical, Prohibitionist message and policy on the rest of the world, Mexico being very much at the forefront, and going back well before Felipe Calderón. So yes, America is to blame for the for the drug wars in Mexico.

### Moderator
Claim: Thank you, Jeffrey Miron. Summarizing against our motion, Jorge Castañeda, former Foreign Minister of Mexico, and here at New York University, Professor of Political Silence—sorry, Political… Oh…

### Scientific Advocate (SA)
Claim: As my students can testify…

### Moderator
Claim: Yes, yeah. Well, let me finish, let me finish my windup for you, without the Freudian slip. Jorge Castañeda, former Foreign Minister of Mexico, and Professor of Political Science and Latin American Studies at New York University.

### Scientific Advocate (SA)
Claim: I am very glad to hear at this point that, yes, at least four of us— and I am not so sure, well, perhaps, well, the rest of my members of my team would disagree entirely that the way this war has been declared, waged and is being fought, perhaps was not the most intelligent idea and that perhaps a series of modifications should be made.

But in any case, on the fundamental issue. I think that if we accept the premise that the United States is to blame for the war—which I do not, because as I said, I think this is President Calderón’s war, and it did begin now. The previous six presidents of Mexico have contained with more or less corruption, more or less violence, more or less intelligence, the cartels, but did not declare this generalized war on them. The first time that has happened is now.

The question is: Is there any change in the United States’ situation…in the last two or three years…that has had a direct impact on Mexican production, violence, corruption, etc.? And there is no evidence of that. I would just respectfully disagree with my colleague Asa on the question of U.S. demand. Fareed brought it up, and he is right. I don’t know what “demand” has been, but I do know—from DEA figures—that the price of drugs in the United States over the last 40 years has tended to decrease for all drugs. Now, it may be that some “demand” has dropped and prices have also dropped, but that is hard to argue directly. My sense is that, overall, demand has been more or less stable for all drugs, except for changes within them.

And on the gun question, I also think that there is no significant change. It’s not that all of a sudden there are more guns going to Mexico. There are a lot though. Fareed, I would tend to disagree with “the 2,000 per day,” that’s 700,000 per year. That would be two million, just in the past three years. The numbers don’t add up. And by the way, there are three million registered guns in Mexico, including those of the government. There are more than two and a half billion registered, legal gun owners in Mexico today.

As my students can testify…

### Moderator
Claim: Thank you, Jorge Castañeda. And finally, with our motion, “America is to Blame for Mexico’s Drug War,” summarizing for the motion, Andrés Martinez, Director of the New America Foundation, Bernard L. Schwartz Fellows Program, and a former editor at the L.A. Times.

### Conspiracy Advocate (CA)
Claim: Thank you. And again, I want to reiterate my appreciation for your being here and for the Rosenkranz Foundation for hosting this important forum.

First off, I just quickly wanted to take issue again with Jorge on this question of whether the drug war started under President Calderón. And yes, there was a “surge,” if you will—or a “frontal declaration against all cartels, all the time,” as you put it. But I think the alternative… It’s very cynical to say, “Well, the government should have continued accommodating with these cartels.” And clearly, this day of reckoning was in the offing when— sooner or later.

But I think, again, America is to blame for the violence, for the war. Asa Hutchinson said, “We offered no facts, we offered no evidence.” I just point you again to a 65 billion dollar consumption demand for this, these illicit drugs in this country. I think the fact that we have spent so much time talking about whether or not to legalize is indicative—and again, I am agnostic on that question—but I think it’s indicative that we all understand that the root cause here is the fact that we have this massive market in this country for a product that we have also made illegal. 65 billion dollars is more than 5 percent of Mexico’s GDP. According to Jorge’s fantastic book, Mexico has a consumption—illicit drug consumption rates—that are below international averages. Only 5 percent of Mexicans have ever tried illegal drugs, compared to 42 percent of Americans. When I was a kid, they used to make stamps, “Mexico Exporta,” stamps of export products. They could have…might as well made illicit drugs. This is all about supply and demand. It’s all about supplying the American market. 90 percent of the cocaine that is consumed in this country now goes through Mexico, because of some of the shifts that Fareed mentioned earlier.

We have to accept that our actions have consequences. We can’t constantly outsource the repercussions of our hypocrisy. Please accept responsibility and vote with us that America is to blame for Mexico’s drug war.

### Moderator
Claim: And that concludes our closing statements. And now it is time to learn which side argued best. You are going to choose our winner. Once again, going to the keypads near your seat. You voted before the debate. Your position on our motion, “America is to Blame for Mexico’s Drug War.” We would like to ask you to vote once again on this position, having heard the arguments. Press number 1 if you support the motion, number 2 if you are against, and number 3 if you remain or became undecided. The motion, “America is to Blame for Mexico’s Drug War.” And it looks like everyone is done. We are going to have the results probably in about 90 seconds. In the meantime, I want to tell you what’s coming up in our next season. First of all, I want to thank all of you in the audience and our panel for a compelling discussion and for arguing honestly, fairly and good naturedly.

So this is our last debate of 2009. And looking forward to 2010, here is what we are going to be debating at this point in our spring series. On January 19th, our motion is “California is the first failed state.” It will feature former Governor Gray Davis and Van Jones, who recently left his post as White House environmental advisor.

On February 9th, the motion is “The U.S. should step back from its special relationship with Israel.” We are going to have New York Times columnist Roger Cohen and Columbia University pressure—or professor Rashid Khalidi, and Israel’s former Ambassador to the United States, Itamar Rabinovitz.

On March 16th, the motion is “Don’t blame teachers unions for our failing schools.” We’ll have former Education Secretary Rod Paige.

April 13th, “Organic food is marketing hype.” We’ll have Blue Hill chef Dan Barber, and Vogue food writer Jeffrey Steingarten.

Finally, on May 11th, the motion will be “Give every U.S. educated Ph.D. a Green Card.” We’ll have Intel’s Craig Barrett as part of that panel.

Individual tickets and packages are now available by visiting our Web site, and at the Skirball box office. And make sure to become a fan of Intelligence Squared U.S. on Facebook, and you will receive discount on next season’s debates.

And finally, a special thank you to NPR and to Bloomberg Television for distributing the IQ2 debates this season, and to our media partner Newsweek magazine. Don’t forget to pick up a copy on your way out.

And now it is in. You have voted twice. And I have just been given the results. Remember, the side that changes the most minds here will be declared our winner. Our motion has been, “America is to Blame for Mexico’s Drug War.” Before the debate, 43 percent of you were for the motion, 22 percent of you were against, and 35 percent were undecided. After the debate, 72 percent of you are for the motion, 22 percent remain against, and 6 percent undecided. The side for the motion wins. Congratulations to that side. And thank you from me, John Donvan, and Intelligence Squared U.S.
