# Debate Transcript

Topic: Israel Can Live With a Nuclear Iran
Motion: Israel Can Live With a Nuclear Iran

Debate ID: 011613%20israel%20iran


## Round 1

### Moderator
Claim: So I'm hoping my voice will hold out. If not, there are four great debaters who are going to do that for us. But before we get to that I want to bring to the stage person who brought Intelligence Squared U.S. to the United States, Robert Rosenkranz, who will help frame the debate for us tonight.

### Moderator
Claim: Pardon?

### Moderator
Claim: I'm going to make it.

### Moderator
Claim: Good.

### Moderator
Claim: Bob, this is a debate where we could have put in the motion, "The world can live with a nuclear Iran. The U.S. can live with a nuclear Iran." We made it Israel. Why Israel?

### Moderator
Claim: We made it Israel because for the United States a nuclear Iran is a strategic setback, but for Israel it's an actual existential threat. And because the stakes are so high for Israel, we felt the debate should focus on its decisions.

### Moderator
Claim: And the team that's arguing for the motion that Israel can live with a nuclear Iran, what's the best argument they have going for them?

### Moderator
Claim: Well, I'd say the best argument is that first of all Israel can certainly deter any kind of Iranian nuclear attack on its own soil. It's got vastly greater military capabilities than Iran does. It can defend itself better. And it can unleash absolute devastation on Iran.

Iran has had disturbing rhetoric, but they've never actually done anything that's irrational or self-destructive, so that they can be deterred just like any other country from using those kinds of weapons. The other argument against is that the ultimate way in which Israel would be able to prevent Iran from developing nuclear weapons is not just cyber attacks or these clandestine operations we've been reading about, but an actual attack, a bombing of their facilities, which would very likely result in a war in the Middle East, and that war could leave Israel isolated, it could entrench the Ayatollahs, it could actually over the long run result in a diminution of Israel's security.

### Moderator
Claim: So you actually made the argument for the other side as well.

### Moderator
Claim: Well, I mean, that's the argument in a sense why Israel can tolerate it because the costs of not tolerating it are too high. The counterargument would be that it doesn't matter whether Iran uses nuclear weapons or not, the mere possession of them changes the game. Iran is a revolutionary power, and if it has the protection of nuclear weapons there's no telling what kind of provocations we're going to get out of them. They certainly would be unconstrained in providing more advanced missiles to Hezbollah. They could be more unconstrained in supporting Assad in Syria. God knows what influence they might try to exercise in Iran. And it's not just about Iranian nukes. If Iran gets nuclear weapons, Egypt is not going to be far behind, and Turkey, and Saudi Arabia, and the last thing we need in terms of global security is a multi-nuclear Middle East. So the stakes in tonight's debate are very, very high.

### Moderator
Claim: Well, I know you've met our debaters backstage, and they're great, so let's bring them out. Ladies and gentlemen, our debaters this evening. Thank you. And I just want to invite one more round of applause for Robert Rosenkranz. It's the nuclear secret that never was, that Israel has the only nuclear arsenal in the Middle East; its leaders have never confirmed it nor never denied it, but one thing they cop to without hesitation is their total rejection of Iran ever getting the bomb. They talk about going to war to stop that from happening, because they say that Israel cannot without live a nuclear Iran. Or can it?

That's what we're here to debate, so let's do it. Yes or no to this statement: Israel can live with a nuclear Iran. A debate from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters to argue for and against this motion: Israel can live with a nuclear Iran. Our debate, as always, will go in three rounds and then, you, the live audience, votes to choose a winner and only one side wins. Israel can live with a nuclear Iran. On the side arguing for the motion, James Dobbins. He is the director of international security and defense policy center at RAND. His partner is Reuven Pedatzur, a senior military affairs analyst with Haaretz. the side arguing against the motion Israel can live with a nuclear Iran, Shmuel Bar. He is director of studies at the Institute of Policy and Strategy in Herzliya, Israel; and his partner, Jeffrey Goldberg, who is national correspondent for the Atlantic and columnist for Bloomberg View. Our motion is Israel can live with a nuclear Iran. And now let's meet the team arguing for the emotion. First, let's welcome, again, James Dobbins. And James, you are now at RAND, where you are director of the international security and defense policy center, but in a previous life, working with the State Department, you were at the talks for the conference for the setting up of the state of Afghanistan in the wake of 9/11. And, in that, you were involved in negotiations that involved the Iranians and you said that the Iranian delegation was helpful in the process and you know that that's not really the reputation that the Iranians normally bring to the table.

### Conspiracy Advocate (CA)
Claim: Well, they were helpful. I think it was just sort of a combination of gratitude and fear. They were grateful that we just knocked off one of their two principal regional rivals, which was the Taliban, and they were fearful that they might be next. And so it was a combination. It was also a different Iranian government than the one we have today; it was a reformist regime operating within an environment that limited their powers but not limited to the point they couldn't reach out. It was a genuine opportunity that we flubbed. I'm not going to argue tonight that we still have that opportunity.

### Moderator
Claim: James Dobbins. And your partner is? Your partner is Reuven Pedatzur.

### Conspiracy Advocate (CA)
Claim: Excuse me, I thought I was finished. Yes, Reuven Pedatzur.

### Moderator
Claim: Okay. Reuven Pedatzur, ladies and gentlemen. Reuven, you are also arguing for the motion that Israel can live with a nuclear Iran. You have obviously a serious personal stake in this, you are a resident of the state of Israel, you were a fighter pilot-- you were a pilot in the Israeli air force.

You now write for the Haaretz newspaper on issues of security and military affairs. Reuven, you told us back in 2006, seven years ago, where you stood on this issue, when you wrote a piece back then that said "Let them have nukes," them being Iran. What sort of reaction did you get back then?

### Conspiracy Advocate (CA)
Claim: There was no reaction whatsoever, because you should know that in Israel there are no public debates on nuclear issues; it's taboo, so there was no reaction.

### Moderator
Claim: And if that happened today?

### Conspiracy Advocate (CA)
Claim: The same.

### Moderator
Claim: Yeah, well, we're going to have a debate tonight. Ladies and gentlemen, Reuven Pedatzur.

Our motion is Israel can live with a nuclear Iran. And two debaters arguing against it: first, Shmuel Bar, ladies and gentlemen. Shmuel, like your opponent, you have that stake of being an Israeli citizen; you also served in war as an intelligence officer. You now direct studies at the Institute of Policy and Strategy in Herzliya, Israel. Just a short preview of your argument here. It's sometimes argued that the Iranians would be no more interested in nuclear war than the Soviets were during the Cold War, and they didn't use it. So give us one reason that that argument just doesn’t end this debate right now.

### Scientific Advocate (SA)
Claim: Well, since I'm a historian, I've noticed that if during history everybody had acted according to the rational actor model, then most of what we know as history wouldn't have happened. Pearl Harbor wouldn't have happened. Barbarossa wouldn't have happened. Certainly Stalingrad wouldn't have happened. So apparently things happen which are not necessarily because it's in the interest of somebody to let it happen but because of other dynamics.

### Moderator
Claim: Shmuel Bar, ladies and gentlemen. And your partner is?

### Scientific Advocate (SA)
Claim: Jeff Goldberg. I know how to pronounce it.

### Moderator
Claim: Ladies and gentlemen, Jeffrey Goldberg.

Jeffrey, you're also arguing against the motion that Israel can live with a nuclear Iran. You're a national correspondent for the Atlantic, a columnist for Bloomberg View. You're in a unique position in that you've had more exclusive interviews with Bibi Netanyahu, I think, than any other American journalist over the past several years. You've been inside the guy's head, or you've been near the head. Where do you think he is in terms of his thinking seriously about his willingness to go to war over this? Is it a posture, or is it a decision?

### Scientific Advocate (SA)
Claim: Well, I would say, first, that, you know, there are teams of neuroscientists in a bunker under the White House trying to figure out what's in Netanyahu's head. So it's a mystery to me too. I would say, to sum him up in a sentence, I would say that he has many manifestations of a typical, insincere politician. On the Iran question, I think he's actually sincere. What that means for policy, I don't know. But he is very sincerely gripped by this issue.

### Moderator
Claim: And he's not liking you very much these days.

### Scientific Advocate (SA)
Claim: We're having difficulties in our relationship, yes, at the moment. At the moment.

### Moderator
Claim: Thank you, Jeffrey Goldberg. Ladies and gentlemen, our four debaters.

### Conspiracy Advocate (CA)
Claim: You know Israel eye would like to know what's in Netanyahu's head.

### Moderator
Claim: Check with the guys in the basement of the White House.

So as we said before, in this debate, our live audience, act as our judges. By the time the debate is over, we will have asked you two times to vote, the first time telling us where you stand on this motion before hearing the debate, the motion being: Israel can live with a nuclear Iran. Then we'll have you vote a second time after the debate is over, where you stand on the point after hearing the arguments. And the team who has moved its numbers the most over the course of the evening will be declared our winner.

So let's register your preliminary vote. Our motion is: Israel, live with a nuclear Iran. If you side with this motion at this point, push number one on your keypad. If you're against it, push number two. And if you're undecided, push number three. And if you think that you made a mistake, just correct it. The system will lock in the last vote that you did. And all of the other numbers are inactive, so just deal with 1, 2 or 3. And it looks like everybody is done. So remember, again, we're going to reveal the result of that vote after you've heard all the arguments and after you have voted the second time. That will come at the end of the debate in its final minutes. And that is how you, our audience, will choose the winner.

So we go in three rounds. And first on to round one, opening statements from each debater in turn. They will be seven minutes each. And here to speak first for the motion, Reuven Pedatzur, arguing that Israel can live with a nuclear Iran.

He is a senior military affairs analyst with the Haaretz newspaper and a senior lecturer in political science at Tel Aviv University. He's a former pilot for the Israeli Air Force and services as director of the S. Daniel Abraham Center for Strategic Dialogue at Natania Academic Center. Ladies and gentlemen, Reuven Pedatzur.

### Conspiracy Advocate (CA)
Claim: Good evening. Where are the results? No results yet? Anyway, can Israel live with a nuclear Iran? The short answer is yes. Any questions? Okay. But the real question is not this one. The real question, do we have another choice? And unfortunately, the answer is no. Because it's possible, despite all pressures and sanctions and even if there will be an Israeli military attack that in this decade, Iran will have nuclear weapons.

So the question is for the Israeli policymakers, what then? What will be our policy in this case when Iran will have the weapons? Unfortunately there is-- as I said, there are no public debates on this, so we don't know what they think over there about future policy. What should Israel do when there will be a hostile Iran with nuclear weapons?

The most effective and maybe the only way to deter Iran is to abandon our ambiguity, nuclear ambiguity and to move towards unconcealed nuclear deterrence. And since, in Israel, we have censorship, as you know, I have to play the game. And when I refer to Israeli nuclear deterrence, Israeli nuclear weapons, Israeli nuclear submarines with nuclear missiles, it's all according to foreign sources. I don't know anything. And I have to use this phrase, "according to foreign sources."But Israel has to change its policy and to move, as I say, to nuclear deterrence-- with new rules of the game. And the other side should know what are the rules of the game. There will be red lines so the Iranians will understand it. For example, if Israel will detect a ballistic missile launched in Iran going westerly, for Israel, it will be the nuclear missiles. And in this case, Israel will not wait to see whether it is a nuclear missile or not. Automatically Israel will launch its nuclear missiles, according to foreign sources, and it, Tehran-- it's fine and so on and so on. And it should be clear for the other side what will happen.

And then the Ayatollahs in Tehran will have to decide whether to launch their missiles when they know exactly what will happen. What will happen, that Iran will be destroyed, and we'll go back to the Middle Ages. And I don't see any Iranian national interests that justifies this cost. So I believe that we can deter them.

I believe that the other team will use the argument of irrationality. We cannot deter these extremist Muslim Ayatollahs. And if this is the case, we cannot deter them, then Netanyahu is right, and we have to attack.

But I don't think this is the case, because if we have a very clear policy of nuclear deterrence, then the chances that the other side will use the weapons are very slim or not existent. For this, we'll have to change not just the policy. We have to show and declare our second-strike capability in order to show the Iranians what we have. And again, according to foreign sources, we have submarines, dolphin class with nuclear missiles. So we have second-strike capability, probably.

So when they use the argument of irrationality, everybody goes to the Cold War and say the Ayatollahs are not like the leaders of the two super powers. They are not rational. They are not going to act like the Soviet leaders or the American leaders, which is wrong, I believe, because if you can remember, during the Cold War, Stalin was perceived, even in the states, as a madman-- whenever he has the bomb he is going to drop the bomb. And the Ayatollahs are not like this. And it seems from professional and sober analysis that the Iranians will-- if we'll learn their way of thinking, their culture, their history, they are going to act like real rational leaders.

We should understand that the development of the Iranian nuclear weapons is not against Israel. It's based on their experience during the war, the Iran-Iraq war in the '80s, not against Israel. And it's very important to understand it, what is the base of their thinking about their nuclear program. And ironically, possession of nuclear weapons may moderate the Iranian leadership, exactly what happened with the Chinese leadership in '64 when they got their nuclear weapons, and they started acting like rational state. And another example is India and Pakistan. Only 23 seconds more.

Really?

So India and Pakistan, there were three wars, after they acquired their nuclear weapons in '98, about after a year there was the Kargil crisis, and they acted very rationally in order not to deteriorate the situation in using the nuclear war.

Thank you.

### Moderator
Claim: Well, now 19.

### Conspiracy Advocate (CA)
Claim: Really?

### Moderator
Claim: Well, now it's 15.

### Conspiracy Advocate (CA)
Claim: So India and Pakistan, there were three wars, after they acquired their nuclear weapons in '98, about after a year there was the Kargil crisis, and they acted very rationally in order not to deteriorate the situation in using the nuclear war.

### Moderator
Claim: Reuven Pedatzur, your time is up. Thank you very much.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Our motion is that "Israel can live with a nuclear Iran," and here to speak against this motion, Jeffrey Goldberg. He is a national correspondent for The Atlantic and a columnist for Bloomberg View. Before joining The Atlantic, Goldberg was a Middle Eastern-- a Middle East correspondent and the Washington correspondent for The New Yorker. Ladies and gentlemen, Jeffrey Goldberg.

### Scientific Advocate (SA)
Claim: Thank you. Thank you. Thank you, John. Thank you to Intelligence Squared. Thank you for coming. Thank you, Reuven. I-- as someone who's covered Pakistan extensively, I'm not going to sit here and make believe that I would hold up Pakistan as a model of stability-- and rational nuclear deterrence, but we can talk about that later. Since you brought up this subject of the nature of the Iranian regime and what they believe and what they think and what they seek, let's talk about that for a minute. What do we have in-- right now in the world? It's a genuinely unprecedented situation, certainly unprecedented in the post-World War II international order. We have a member state of the United Nations, the Islamic Republic of Iran, that actively calls for the destruction of another member state of the United Nations. That is Israel. And they're very, very clear and consistent on this subject right from the beginning of the Islamic Republic. I'll give you a couple of examples.

This is from the supreme leader of Iran, who, as his title suggests, is the supreme leader-- he's the guy who sets the policy. Quote, this is from last February, "The Zionist regime is a true cancer tumor on this region that should be cut off, and it definitely will be cut off." Its feelings are echoed regularly among the Iranian, and military, and intelligence elite. I'll give you another example. General Gholam Reza Jalali, the former commander of the Revolutionary Guard Corps, said last August, I quote, "The fact is, is that there is no other way but to stand firm and resist until Israel is destroyed." General Hassan Firouzbadi, the chief of staff of the Iranian armed forces, said last May, and I quote, "The Iranian nation is standing for its cause, which is the full annihilation of Israel." Finally, Mohammad Hassan Rahimian who is a top aide to Khamenei, said in the January 2010 television interview, quote, "We have manufactured missiles that allow us when necessary to replace Israel in its entirety with a big holocaust." Mr. Rahimian is the deputy minister for subtlety on the part-- of the Iranian regime.

Iranian opposition to Israel's existence is not only ideological and rhetorical, we have to remember that in addition to actually calling for the destruction of the Jewish state, the Iranian regime works to destroy individual Jews. Hezbollah, the Lebanese terror group, is a proxy of the Iranian Revolutionary Guard Corps. The rocket that it fires periodically into Israel are Iranian manufacture. The rockets that Hamas fires from Gaza very recently are Iranian rockets. Let's not forget in the last year you have multiple examples around the world of Iranians trying to kill Israelis, in Bulgaria, in Azerbaijan, in Georgia, in Thailand. And let's not forget a fact I find very amazing, which is that the current defense minister of Iran is actually sought by international law enforcement authorities for direct complicity in the bombing of a Jewish community center in Argentina.

So you're dealing with a regime that regularly calls for the annihilation of the Jewish state. You're dealing with a regime that seeks to destroy and kill individual Jews, which begs the question, "What would be the impact on Middle East stability and on the safety of Israel if this regime which seeks their annihilation, states very plainly it seeks the annihilation of the Jewish state, were to gain a weapon that would help it actually bring about that annihilation?" And that's the question that we're dealing with today.

Now, there are three ways to sort of deal with this dilemma, I think. The first is to-- is to, sort of, say, yeah, you know, on the one hand it's true, the Iranian regime is the foremost sponsor of terrorism in the world and it denies the holocaust while calling for a new holocaust. And it executes people for being gay and it threatens Christian pastors with execution unless they convert to Islam. And it's responsible for a quarter of the American combat deaths in Iraq, and it hides many leaders of al-Qaeda within its borders.

But, on the other hand, no one's perfect-- and I'm sure that these, you know, gay-hanging, Christian-persecuting, American- killing, Jew-hating mullahs, if they get hold of a bomb, will behave in a responsible, rational, and enlightened way. The second response is what I call the, for lack of a better term, the "Uncle Morty response," because a lot of us have an uncle Morty sitting in Boca who spends all day on the internet trying to prove that Barack Obama is Osama bin Laden's third cousin by marriage. And the Uncle Morty response-- the Uncle Morty response is to say "You know, it's 1938 and the second holocaust is beginning next Tuesday and we're all done, and we're finished." The third response-- and this is what I want to get into during the course of this debate. The third response acknowledges a couple things. Is that it isn't 1938. The Jewish people do not stand defenseless and naked before the world. Iran, the day after it gets a bomb will probably not fire that single bomb at Israel, but it's also clear that Israel in a post-nuclear Iran Middle East is going to have a very, very hard time surviving.

Three quick reasons why it's going to have a hard time surviving: my colleague, Shmuel, in a few minutes is going to talk about why the Cold War models of mutual deterrence don't really apply in this situation. I'm going to talk about reasons that it's going to be difficult for Israel to survive even if there is no nuclear propagation. The first is very clear to everyone, including President Obama. The day after there's going to be-- the day after Iran goes nuclear, there's going to be an arms race, a nuclear arms race, in the Middle East. President Obama has warned about this. He said very explicitly that a nuclear arms race in the world's most volatile region is inherently destabilizing. So you're dealing with, in a few years' time, the possibility that four or five different countries that all hate each other, are going to be pointing nuclear tipped missiles at each other. That's not a recipe for stability or happiness; it's certainly not a recipe for stability for the Jewish state.

Second reason: if you believe that Israel can only survive if it makes peace with its neighbors, then you will be opposed to the idea of Iran getting a nuclear bomb. Israel cannot survive in a Middle East in which America is a defeated and weakened ally. America is Israel's most important ally. If Iran trumps America, if Iran beats America by getting a nuclear weapon, it means that the Arab states that were predisposed to make peace with Israel-- and we know the peace process is Anyway, they will align with Iran, because Iran is the winner of that conflict.

The third and most obvious point is Hamas and Hezbollah, even now, periodically fire large numbers of rockets at Israeli civilians. Imagine the power that they will have when they can fire those rockets under the protection of the Iranian nuclear umbrella. Again, there is a real chance that an Iranian nuclear weapon would lead to conflagration in the Middle East. Even without that conflagration, it becomes very, very hard to envision how Israel survives in the long term. Thank you very much.

### Moderator
Claim: Thank you, Jeffrey Goldberg. And a reminder of what's going on, we are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two against two, who are arguing it out over this motion: Israel can live with a nuclear Iran. You're heard two of the opening statements. And now, on to the third. Debating in support of the argument, James Dobbins; he is a former U.S. assistant secretary of state and special envoy under the Clinton and George W. Bush administrations. He is now director of the international security and defense policy center at the RAND Corporation. Ladies and gentlemen, James Dobbins.

### Conspiracy Advocate (CA)
Claim: Well, just to remind us what we're debating about. The proposition is, can Israel live with a nuclear Iran, can Israel survive a nuclear Iran. The answer to that question is yes. You don't need to be absolutely certain it will survive. In fact, technically, you don't even think it has to be probable that it'll survive, just that it's possible that it will survive. And I think both of the opposition will acknowledge that it's possible it'll survive. And Jeff said that they'd have a hard time, which implicitly indicates that there's a good possibility they'd survive it, it'd just be harder. But-- so I mean, I think if you debate at that level, it's pretty clear. There's almost nobody who thinks that Israel's demise will be automatic and certain. It's a question of risk. And so I think in a sense, the real debate is, should Israel live with a nuclear Iran. And the answer is, not if they can help it, obviously. Nobody thinks a nuclear Iran is a good idea.

And we're already doing a lot to try to prevent it. We have a massive probably unprecedented international sanctions regime, an active, if so far unproductive diplomatic process, a very active and somewhat successful covert sabotage effort and cyber attacks. Now, these may work in some combination. But I'd have to acknowledge that they may not.

And so the remaining question is, should one of these fail, go to war to prevent Israel-- prevent Iran from gaining a nuclear weapon. And I think although that's not precisely what we're debating, the issue does tend to revolve around that. Now, the threshold for saying yes that we should go to war to prevent Iran from gaining a nuclear weapon really has to go-- there are two thresholds, one is efficacy, and one is unintended consequences. You need to look at both.

In terms of efficacy, I think most experts believe that an Israeli attack on Iran would set the program back by perhaps two years. That an American attack would be more effective and would set it back by maybe four or five years. It wouldn't prevent it, but it would slow it down. What about the unintended consequences? Well, most people are concerned about the possibility of counter attacks. Iran begins rocketing Israel-- Israeli nuclear facilities, terrorist attacks. But in many ways, the more dangerous response is, first of all, that an unprovoked attack on Iran validates their case for a nuclear weapon, for nuclear deterrence. North Korea doesn't suffer those kinds of attacks. Pakistan doesn't suffer those kinds of attacks. And many in the world and in Iran will come around to the view that maybe Iran actually needs a nuclear weapon.

A second consequence is that you begin to collapse the international coalition that so far has made Iran a pariah state that has cut off its access to international markets, international-- not just nuclear technology, but any kind of military technology, and increasingly even cut back dramatically its oil sales. And as a result, Iran gains access to the world economy. It breaks out of its isolation. And even perhaps certainly gains access to sophisticated military technology. In the aftermath of an attack, wouldn't Russia be prepared to sell Iran the kind of air defense systems which so far it's refused to sell Iran and perhaps even nuclear technology from states like Pakistan or others, North Korea.

I think in evaluating these consequences, one has to go back to the question of what is it that we, and for that matter, most Israelis, fear about Iran. And I think Jeff has pretty much answered that question. It's not Iranian invasion. It's Iranian subversion. It's Iran's capacity to appeal to militant elements within neighboring populations, dissident elements within neighboring populations in order to galvanize their efforts both against their own regimes in many cases and against Israel. So it's Iranian influence; it's Iranian capacity for subversion. It's not that Iran is going to march across two intervening states and invade Israel. That is a concern. And the fear is that they would be emboldened, and they'd do more of this.

But I think you have to ask yourself, which kind of Iran would have more influence with these dissident populations? Not with governments, but with dissident populations in places like Gaza and Lebanon and other Middle East states. An Iran that had nuclear weapons, or an Iran that was the victim of an unprovoked attack? Which of those two would give Iran greater influence and capacity to mobilize those kinds of populations? I think the answer to that is fairly clear. Now, the argument that Iran would be emboldened by possessing a nuclear weapon is certainly, I think, a real danger. But it's far from a certainty. It's not the historic pattern. You know, our major problems with the Soviet Union and particularly with China occurred before they had nuclear weapons. You know, Soviet Union gobbled up all of Eastern Europe before it had nuclear weapons. We had nuclear weapons, they didn't. China actually attacked the United States and Korea and made a two-year war with the United States and Korea. They didn't have nuclear weapons; we did. Once they got nuclear weapons, we didn't have anymore wars. Now, we had lots of confrontations, but they were eventually defused.

Both North Korea and Pakistan do behave irresponsibly on occasion, but there is a certain stability in their relations with India, Pakistan's relations with India, North Korea's relations with South Korea. There haven't been conflicts in either case. So the argument that they'd be emboldened to the point of actually threatening to use nuclear weapons or using nuclear weapons or even engaging in the kind of behavior that they're not engaging in now-- and I think if you listen to Jeff's list of all the things they're doing, you'd have to ask, what the hell else could they do that they're not already doing? And I think the answer is not much.

### Moderator
Claim: Thank you, James Dobbins. motion is that Israel can live with a nuclear Iran. And now our final debater who will be speaking against the motion, Shmuel Bar. He is the director of studies at the Institute of Policy and Strategy in Herzliya. He is also a senior research fellow for the international institute for nonproliferation studies. Shmuel, you can start making your way to the lectern. He served for 30 years in the Israeli government, in the Israel defense forces intelligence and in the office of the prime minister. Ladies and gentlemen, Shmuel Bar.

### Scientific Advocate (SA)
Claim: Thank you. First of all, I won't go into the post-fact scenarios that were brought, but suffice to say that I could offer more optimistic scenarios. When you shuffle a deck of cards, then you play a completely new game. I recall that when we took out the Iraqi reactor we thought it would delay it for three years. But it took about 10 years, and the Iraqis did not get back to the level that they were before we took out the Osirak.

Now, the arguments that have brought up the rational actor model, which I've already made some remarks as a historian about and the idea that deterrence works, and the other, the Cold War paradigm can be applied. I would argue that we have to look at both of these assumptions in a completely different manner. First of all, the rational actor model. Somebody, not me, McNamara, said that Castro was a rational man, Khrushchev was a rational man, Kennedy was a rational man. And three rational men almost brought their nations into utter destruction. And that was without any-- I mean, Che Guevara said that if Cuba had to be destroyed in order to destroy capitalism, then Cuba would be thankful for that. But in other words, rational people sometimes do things, or the dynamics between rational people, rational leaders, sometimes leads to things which are not rational.

The other thing is that strategic surprises have happened. I don't think there's anybody here who would debate the fact that strategic surprises have happened. And when they happen, they happen because things that hordes of analysts and pundits and journalists have said are completely impossible because it is irrational that people will act that way, but they happened. So the fact is that these surprises happen, and they reflect dynamics which were not pure game theory rational behavior. Now, the other thing is that if nuclear weapons make countries more responsible, then I would propose that the United States, which wants to reduce its nuclear arsenal, should now just divvy out all of the American nuclear weapons to the whole world, and then everybody will become very responsible, very rational, and peace on earth and goodwill towards men.

Now to the Cold War paradigm. The Cold War paradigm, let's define what it was. It was bilateral. It was a paradigm which, from a certain stage, had mutually assured destruction, with each party having a second-strike capability. It was with levels of intelligence that when these-- both the United States and Soviet Union acquired that capability, the second-strike capability, they also had satellites in the sky, so they had a reasonable picture of what was going on in the silos of their respective enemies. There were mutual communications after Cuba, and there was also a perception of a taboo after Hiroshima.

Now, when we're talking about a nuclear Iran, we have to understand we are talking about a poly-nuclear Middle East. The nuclear Shiite Iran is going to be perceived by the Sunni countries as something that cannot be countenanced, that they are going to have to acquire their own nuclear weapons.

In a poly-nuclear Middle East where every country has a very small arsenal, they do not have mutually assured destruction. They have sort of arsenal which is "Use it or lose it. If we are attacked then we won't have a second chance. We are going to have multiple nuclear states with these small arsenals with very low levels of intelligence. They won't have satellite intelligence, a very clear picture of what the real intentions of their enemy are. The size of the arsenals, it's better to have a lot of bombs than a few bombs because then, of course, you have the propensity to say, "Well, if I don't use it now, I won't have a second chance." But then I want to go into something which has to do with command and control. And this is a very esoteric area. But in order to prevent unintentional use of nuclear weapons or use of nuclear weapons without total control over the process of what's called "escalation dominance," you have to have very sophisticated capabilities.

When you look at the command and control structures in the various countries of the Middle East and the paradigms which existed in the Cold War countries, you actually discover that most of the key elements which were instrumental in preventing nuclear confrontation during the Cold War do not exist in the Middle East and cannot exist for various reasons, some of them because of the military culture, the political culture, et cetera, issues such as verification of authority, separation of authority over the delivery systems and the weapons, all of those things which made it more difficult suddenly to rush into nuclear confrontation, things like permissive action links which prevented unintentional use.

So all put together, we are talking about a very volatile region. We're talking about a possibility that not because Khamenei gets up in the morning and says, "Oh, what a lovely day, isn't it a great day to drop a bomb?" but that because the Iranians do a nuclear alert, the Saudis don't know whether it's directed against them. Israel sees Saudi Arabia, and Iran, and Turkey on clear alert. Everybody goes on DEFCON, and things get out of hand because none of these countries have the capability to control this spiral of escalation.

Now we're talking about something which is-- even if we say it's low probability, but low probability, high consequence, and this is where we stand on that. In other words, we can say, "Oh, there's a 10 percent possibility that this will result in nuclear confrontation." Well, 10 percent probability of total destruction is something that you have to think about.

So, putting all of that together, I think that I would agree with McNamara that rational actors or rational leaders do not guarantee complete rational processes. And as a final note, we also have to address the issue of the taboo of nuclear weapons.

Religious experts in Iran and in the Sunni world all ask themselves, "What is a nuclear bomb?" Since there can be nothing which the prophet Muhammad didn't speak about, they have decided that a nuclear bomb is like a catapult, it's just a big catapult, because a catapult used to be thrown over the walls of a city and you didn't see who it killed so it's indiscriminate killing. Well, that's like a nuclear weapon. I think that somebody who sees a nuclear weapon like a catapult is--

## Round 2

### Moderator
Claim: Shmuel Bar, I'm sorry, your time is up. Thank you very much. And that concludes round one of this Intelligence Squared U.S. Debate. And now we go on to round two, where the debaters address each other directly and answer questions from you in the audience and from me.

We have two teams of two: James Dobbins and Reuven Pedatzur, who are arguing for the motion that "Israel can live with a nuclear Iran." Their argument is that, much as the U.S. learned to live with a nuclear China, Israel can do the same, and it's not desirable, they're not saying that, but they're also saying it doesn't mean that the sky is necessarily falling. They portray Iran's leaders as not crazy as is sometimes claimed. They're saying that the Iranians will not want a nuclear war any more than the Israelis. And, by the way, they say that attacking Iran to destroy its nuclear program would only strengthen Iran's influence and make it harder to contain than ever.

Jeffrey Goldberg and Shmuel Bar are arguing against the motion, saying the risks to Israel are unacceptable. They have not, in their statement, promoted an attack in Iran, which they point out is not the premise of the debate, but they are depicting drastic consequences for Israel if a state that hates it as much as the Iranians say they hate Israel would get its hands on a nuclear weapon.

They say it would be a defeat for the good guys, it could set off an arms race in the region, nukes could reach terrorists' hands. And, bottom line, two or three bombs alone could destroy all of Israel. It's not the Cold War, folks, in that sense.

So those are essentially the arguments that the two sides are making. I just want to start off the questions by getting to this notion of the moderating influence of having a nuclear weapon that Reuven Pedatzur talked about. He talked about the fact that when China-- when Mao got the bomb in 1964, that he became a lot less, quote, unquote, "crazy" in that sense that he was depicted and thought of in the west; that he became a lot more sober-minded as a geopolitical thinker and strategist, because-- presumably because of the stakes. And I just want to put that to the other side and take it to Jeffrey Goldberg first. The notion that-- and you addressed it a little bit in your response, but I would just like a little bit more detail in recognizing what this argument actually is, that things did change in China at that time. So take on that question, Jeffrey Goldberg.

### Scientific Advocate (SA)
Claim: Well, I-- first, I would say that there's only a limited amount of knowledge we can gain by analogizing the Chinese Communist Party of 1965 with the mullahs who rule the theocratic authoritative state of Iran in 2013. I really-- I don't want to stretch this to the breaking point, and I feel like that does stretch it to the breaking point. Yes, it's possible. It's possible that Iran will become suddenly a responsible party, but it is revolutionary in nature. I think by the time China reached nuclear status, it had been-- it was growing into something. Iran's specific goal is to export the Islamic revolution throughout the Muslim world; its specific goal is to destroy Israel; its specific role is to liberate Bahrain. A country that has all of these goals which gains a nuclear weapon is not going to suddenly say, "All right, now that we have the weapon that will finally allow us to do all of the things that we've been telling you we want to do, we're not going to do it."

### Moderator
Claim: Okay. Reuven Pedatzur, Jeffrey Goldberg is saying that Iran is not China of 1964 in significant ways.

### Conspiracy Advocate (CA)
Claim: Iran is no China, I agree.

### Moderator
Claim: So we can go home now.

### Conspiracy Advocate (CA)
Claim: Absolutely, but China is not alone. Let's talk about India, Pakistan. Let's see that South Korea lives under the ship of a North Korean nuclear umbrella. So it happens to every leadership that the--

### Moderator
Claim: And what do you think happens to them? And I want to take your answer back to Jeffrey.

### Conspiracy Advocate (CA)
Claim: Because they know what is the price of using the weapons. There is no winning in nuclear war. So in this case, they know exactly what will happen and that makes them--

### Moderator
Claim: Okay, so, Jeffrey--

### Conspiracy Advocate (CA)
Claim: And let me give you an example. We're talking about the Iranians, that they're irrational. Let's talk about Khomeini; he was very extremist, right? In 1980, when the war with Iran began, Iraq did, he said that he'll never sign a cease-fire agreement with Iraq until they surrendered. In '88, they started launching missiles, conventional missiles, in Tehran, thousands people dead. And he signed an agreement, because the price was too high. And we are talking about conventional missiles, not nuclear missiles.

### Moderator
Claim: Okay. So, Jeffrey, Reuven gave you the logic behind his analogy of China, that the gravity of the damage, the destruction that the weapons can do will change any leaders' thinking.

### Scientific Advocate (SA)
Claim: Well, first of all, let me come back to Pakistan, because I've done a lot of reporting on Pakistan. Pakistan is moving away from minimal deterrence. We know that Pakistan now is mating its weapons and putting them on mobile launchers, so I would caution not use Pakistan as a great model.

### Conspiracy Advocate (CA)
Claim: Kargil crisis, for example.

### Scientific Advocate (SA)
Claim: But let me just also say this. I think we're actually also talking about the wrong thing. The thing that I worry about more than--

### Moderator
Claim: Are you doing-- are you doing a subject change to avoid the question?

### Scientific Advocate (SA)
Claim: I am not avoiding the question.

### Moderator
Claim: Okay, all right.

### Scientific Advocate (SA)
Claim: No, no, but I'm not avoiding the question. I am going directly at the question by changing the question. I don't--

### Moderator
Claim: I just think he gave you the logic.

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: And it's got some power to it, and I want to hear your responses.

### Scientific Advocate (SA)
Claim: Sure, sure. Let me answer the question by saying I don't necessarily think that Ayatollah Khamenei is going to, one day, wake up and decide to launch a preemptive nuclear strike on Israel because he wants to destroy Israel. What I'm much more concerned about is accidental escalation leading to all-out nuclear war. Think of it this way-- think of it this way: what happened two months ago? Hamas fires rockets into Israel, Israel fires back, Hamas escalates, Israel then escalates. Imagine if Iran was in the picture with a nuclear weapon, right? Now, just imagine this: Imagine that Iran, in response to Israel's escalation, decides to move war heads closer to their missile launching sights. And the American satellites see this. You'll be living in a Middle East of launch on warning. You'd be living in a situation in which the Israeli prime minister is going to say the Iranians are moving their missiles to strike us in defense of Hamas. What do I do?

### Moderator
Claim: We know the prime minister already wants to do this.

### Moderator
Claim: Let Jim Dobbins respond to that.

### Conspiracy Advocate (CA)
Claim: Well, I don't think the Israeli counterstrike is vulnerable. I mean, Israelis have nuclear weapons that can't be located, can't be destroyed.

### Moderator
Claim: Jim, could you come just a touch closer to your mic?

### Conspiracy Advocate (CA)
Claim: And so I think that launch on warning is not a necessary strategy for the Israelis. It might--

### Scientific Advocate (SA)
Claim: Can it wait till Tel Aviv is bombed and then launch against Iran?

### Conspiracy Advocate (CA)
Claim: I think they would-- I mean, it would obviously depend on the circumstances. If they thought--

### Scientific Advocate (SA)
Claim: There's only three cities in Israel the size of Staten Island.

### Moderator
Claim: Jeffrey, hang on. Let him answer.

### Conspiracy Advocate (CA)
Claim: You know, the United States was just as vulnerable as Israel. We had 24,000 nuclear weapons locked in on us. They would have damaged us just as badly as half a dozen on Israel. The result would have been the same. And it probably would have been worse for the rest of the world; indeed it would have been catastrophic for the world as a whole.

And we lived with that for 40 years. And all of these problems with launch on warning-- now, I quite take the fact that these regimes don't have the controlled mechanisms, the command and control or even the technologies that will make this a safer world. And so I fully acknowledge that there's an element of risk there. I fully acknowledge that Israel shouldn't live with a nuclear Iran if there's a better option. I'm just arguing that there may not be a better option.

### Moderator
Claim: Shmuel Bar.

### Scientific Advocate (SA)
Claim: Yeah, well, first of all regarding rationalism and Khomeini. Khomeini, two years after the Iraqi invasion of Iran, he could have signed an agreement. He could have stopped the war, but he continued with the war. And the reason that he finally agreed to a ceasefire was because the revolutionary guards actually imposed it on him. The other thing is that Iran isn't like China which was going through a process when it acquired nuclear weapons. China was already moderating its revolutionary zeal. Iran is going through what we would call the second generation of the revolution. I mean, we're already in this sort of Robespierre style second generation of the Iranian revolution going back to the pure concepts of the revolution.

Now, but that really isn't the real issue here. The real issue here, I think, is that analogies are absolutely irrelevant. You never walk into the same stream in the same place twice. And certainly when one stream is in China and the other is in the Middle East. Secondly, the dynamics of multilateral nuclear states is completely different to the dynamics of two main

### Conspiracy Advocate (CA)
Claim: Let me remind you, it was not bilateral. It was tri-lateral. China was for '64.

### Scientific Advocate (SA)
Claim: China never had the strategic capabilities of the Soviet Union, and the Chinese didn't have the missile capabilities at the time. And most of the Cold War was clearly a Warsaw Pact against NATO. It was clearly bilateral.

So the fact that nominally you also have Britain and France, et cetera, and you have China, that did not make it multilateral. So it doesn't matter, though, because we're not talking-- and as a historian, I find it difficult to discuss analogies because we think that stories tend to think that God is in the details. And the details on the Middle East is that we will have a poly-nuclear Middle East where we will have a Sunni world which is going to see a Shiite nuclear power as an existential threat to the Sunni world. Anybody who's read the best seller in Saudi Arabia, "The Protocols of the Elders of Qom," which tells how the elders of Qom wanted to destroy Mecca and Medina, realize that they see this as existential as well. And so we have to understand that this is the situation. This situation does not auger well for stability.

### Moderator
Claim: All right. Let me put a different-- bring in a different strain of the argument here. To the side that's arguing that Israel can live with a nuclear Iran, your opponents have pointed out that the specific rhetoric of the Iranian regime has discussed a deep aspiration to see Israel gone, wiping Israel off the map. Reuven Pedatzur, why not take that absolutely literally?

### Conspiracy Advocate (CA)
Claim: By the way, they’ve never threatened Israel with nuclear weapons, never. Never-- never. You never find one--

### Moderator
Claim: Very quickly, very quickly--

### Conspiracy Advocate (CA)
Claim: No, no, because--

### Moderator
Claim: Do you concede the point that they have never threatened to use nuclear weapons against Israel?

### Conspiracy Advocate (CA)
Claim: They don't admit that they are developing the weapons, so how can they threaten?

### Scientific Advocate (SA)
Claim: anybody who reads the materials coming out of media which is related to the Iranian Revolutionary Guard, I'm not even going back to Rafsanjani with his famous statement. But very senior Iranian people connected to Khamenei have made allusions which could clearly be understood that way.

### Moderator
Claim: All right. That's different from-- Reuven is saying they've never explicitly said, we will get a nuclear weapon and use it to destroy Israel.

### Scientific Advocate (SA)
Claim: Excuse me. If the Ayatollah Khamenei's aide, Rahimian is saying that he's going to replace Israel with a big holocaust, I don't think they're putting pumpkins on the catapults. You know, I mean, I don't think you have to stretch it--

### Conspiracy Advocate (CA)
Claim: So this is the rhetoric. This is the rhetoric for other reasons. They are not going--

### Moderator
Claim: So they're saying that they don't mean it.

### Conspiracy Advocate (CA)
Claim: If they could do it, they would have done it. But they don't mean they are going to use the nuclear weapons in order to achieve this goal, no. No way.

### Scientific Advocate (SA)
Claim: I beg to differ. I just----

### Moderator
Claim: Shmuel Bar.

### Scientific Advocate (SA)
Claim: I think that one of the problems-- and this, I must say-- we as Israelis tend to believe people who say that they want to exterminate us. We have some very, very good historic precedence-- that somebody said they want to exterminate us and they tried to do it.

### Conspiracy Advocate (CA)
Claim: So you--

### Scientific Advocate (SA)
Claim: So I don't-- I--

### Conspiracy Advocate (CA)
Claim: So Khamenei is Hitler?

### Scientific Advocate (SA)
Claim: I don't believe in rhetoric. I think that rhetoric becomes action when it can become action.

### Moderator
Claim: Reuven Pedatzur.

### Conspiracy Advocate (CA)
Claim: So you believe that the minute they'll have the weapons, they'll try to--

### Scientific Advocate (SA)
Claim: No, I didn't say that.

### Conspiracy Advocate (CA)
Claim: --destroy Israel.

### Scientific Advocate (SA)
Claim: No, I didn't say that. I said that given circumstances in which there will be escalation, that no party in this region will be able to prevent-- will have dominance--

### Conspiracy Advocate (CA)
Claim: I don't agree, because what will happen, it's what happened between the two super powers.

### Scientific Advocate (SA)
Claim: It won't.

### Conspiracy Advocate (CA)
Claim: Means of communication will develop.

### Moderator
Claim: Let me bring-- we haven't heard from Jim Dobbins for a couple of minutes. And Jim, for you also this question: If the Iranians are so explicit about their desire to see Israel gone, whether they use an active verb or passive verb, should the Israelis not take that literal-- with literal seriousness? And can you come close to your mic?

### Conspiracy Advocate (CA)
Claim: I mean, I think what-- a benign explanation, and I'm not arguing that one should necessarily accept the benign explanation, is that the Iranians are simply arguing for a multi-ethnic state, encompassing all of historic Israel, to include the West Bank, which is the Hamas position, for instance. It's not that the Israelis should go away. It's that Israel should go away and that a multi-ethnic state encompassing both Palestinians and Israelis should continue to exist. Interestingly enough, there are extremists, but viable parties in Israel who also think that the Israeli state should encompass all of the West Bank.

### Moderator
Claim: Okay so--

### Conspiracy Advocate (CA)
Claim: The difference is that they think it should be a Jewish state, whereas the Iranians would argue it should be a multi-ethnic state.

### Moderator
Claim: Well, Jeffrey Goldberg.

### Scientific Advocate (SA)
Claim: Just very briefly on that. What will happen was Israel's enemies realized that-- talking about pushing the Jews into the sea was not really a great PR strategy. So what they did was they changed the language, and they said, we don't want to push the Jews in the sea. We just want to get rid of Israel as a Jewish homeland and let everybody live there together. But then they also say, as the a toll laws say, all the Jews who aren't from there have to go back to where they're from, which leads to these incredible statements, and I heard this from many Iranian officials--

### Conspiracy Advocate (CA)
Claim: from.

### Scientific Advocate (SA)
Claim: The Jewish should go back. The Jews from Germany should go back to Germany. The Jews from Poland should go back to Poland.

### Moderator
Claim: But, Jeffrey, I think what Jim is saying that is the-- you could interpret the-- and I'm not saying this facetiously-- the Iranians are-- they're not saying, we will kill you. They're saying we want you dead, which is not exactly the same thing, which has to do with--

### Scientific Advocate (SA)
Claim: We want a lot of you dead, and we certainly want your country and your dream of a Jewish homeland dead. So, you know, to Israelis and to Jewish people--

### Moderator
Claim: But it means, would they be the agents of that killing?

### Scientific Advocate (SA)
Claim: Were they able to get away with it. But I--

### Scientific Advocate (SA)
Claim: They already tried, John. They already tried.

### Conspiracy Advocate (CA)
Claim: They can’t get away with it.

### Scientific Advocate (SA)
Claim: They already tried.

### Moderator
Claim: Wait, wait, wait. I love it when everybody is talking at once. Starting with. Well, you go first, Shmuel, then you, Reuven.

### Scientific Advocate (SA)
Claim: I know a thing or two about Hamas, and I read their websites avidly. Maybe that's an aberration. And their main website, they have constantly the Hadith from the prophet saying that the last day will not come until the Muslims kill all the Jews and the last Jew will hide behind a rock or a stone, and the rock will call out, "Muslim, there is a Jew hiding behind me, come and kill him." Now, I don't call this a multi-ethnic--

### Scientific Advocate (SA)
Claim: That’s very liberal.

### Scientific Advocate (SA)
Claim: --a multi-ethnic state. This is constantly--

### Scientific Advocate (SA)
Claim: Environmental.

### Scientific Advocate (SA)
Claim: --and they have these on their TV, you have children called up to quote it, and they get prizes for quoting things like that--

### Conspiracy Advocate (CA)
Claim: If you've seen this website yourself?--

### Moderator
Claim: Reuven Pedatzur.

### Conspiracy Advocate (CA)
Claim: talking about – rhetoric.

### Scientific Advocate (SA)
Claim: We're not arguing, by the way, that the Lubavitchers should get nuclear weapons. I mean, you know-- I have a general-- I have a general predisposition against letting nut job religious fundamentalists, that's the technical term-- all stripes, get hold of nuclear weapons. It's a pretty simple point.

### Conspiracy Advocate (CA)
Claim: It's very nice if they don't have the weapons, but if they have, then what? Then what?

Yes.

### Scientific Advocate (SA)
Claim: I think we already described what could happen.

### Conspiracy Advocate (CA)
Claim: Then Israel will our time.

### Moderator
Claim: I'm going to come to you in the audience for questions shortly. I just want you to get ready. Folks, if you're upstairs, I won't be able to call on you, but if you want to ask a question, come on down, and just stand in the back. And I'll see that you came downstairs, and I'll try to call on you for making the effort. I would really urge you to make these questions really, really brief and to form them as questions, not debating points, but as questions. And you'll know it's a question if a question mark goes at the end of what you say-- let it be on this point. We're not debating whether the Israeli government should launch an attack in Iran. We're trying to debate a-- a little bit of it has been put before - - as the day after, what would be the consequences for Israel of Iran getting a nuclear weapon. And so as you're getting ready to do that, I just want to go back to the side that's arguing that Israel cannot live with a nuclear weapon and point out that your opponent, Jim Dobbins, made the point that-- he asked "What actually would the Iranians be able to start doing that they're not already doing in terms of killing Jews around the world, and in terms of encouraging attacks from Hamas and Hezbollah, and being generally mischievous and deadly? What would be different if they had a nuclear weapon? Jeff Goldberg.

### Scientific Advocate (SA)
Claim: They have limitless escalation. Like I said, if Hamas has the protection of the nuclear umbrella-- the Iranian nuclear umbrella, it can be much bolder than it is today. Israel will then have to--

### Conspiracy Advocate (CA)
Claim: Doing what, more than a thousand missiles?

### Scientific Advocate (SA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: Twenty thousand?

### Scientific Advocate (SA)
Claim: Yeah, Hezbollah has 50,000 missiles sitting in Lebanon pointed at Israel right now.

### Moderator
Claim: Jim Dobbins, it was your point. Let's hear your response to it.

### Conspiracy Advocate (CA)
Claim: I mean, quoting from extremist websites is one thing, but as far as I know, the largest Jewish population in the Middle East that doesn't live in Israel lives in Iran.

### Moderator
Claim: The largest what

### Conspiracy Advocate (CA)
Claim: Jewish population in the Middle East that doesn't live in Israel lives in Iran.

### Moderator
Claim: No, I think they're in Israel.

### Moderator
Claim: Two hundred--

### Conspiracy Advocate (CA)
Claim: The largest Jewish population that doesn't live in Israel.

### Scientific Advocate (SA)
Claim: There's 25,000--

### Moderator
Claim: Okay. Got it.

### Conspiracy Advocate (CA)
Claim: So if they wanted to start killing Jews, they'd have an easy opportunity--

### Scientific Advocate (SA)
Claim: The Jews in Iran are under what-- it's called "dhimmi," they are under protection. That's something else. But--

### Moderator
Claim: But, Jim, I just--

### Scientific Advocate (SA)
Claim: Jews have fled Iran.

### Moderator
Claim: Jim, I want you to get back-- I want you to defend your opening point that Jeffrey just refuted, that Iran having a nuclear weapon wouldn't be doing much more than it's already doing. He says, "Yes, they would, because they could escalate under protection."

### Conspiracy Advocate (CA)
Claim: --nuclear weapons are extremely useful to deter people from using other nuclear weapons or from destroying their regime. There was one option that the United States would lose if Iran had a nuclear weapon, which it's lost with respect to North Korea, and that is to invade and overthrow the regime. That would be off the table. We might do other things to them. We've got 5,000 nuclear weapons. They've got two or three. There's almost nothing we could do to them, short of threatening to overthrow the regime, which would cause them to use their nuclear weapons. And I think Israel has never had the capacity of invading and overthrowing the regime, and Israel's not going to use its nuclear weapons to respond to rocket attacks from Hamas.

It's got other conventional responses to that which it can fall back on whether Iran has nuclear weapons or not. And Iran is not going to start a nuclear war to protect Hamas.

### Scientific Advocate (SA)
Claim: I totally disagree that nuclear weapons are only for deterrence. They actually have only been used for deterrence in a very limited case that we know of, the Cold War, but nuclear weapons can be used for compellence. And if you imagine Iran having a certain window of opportunity when the rest of the Middle East has not acquired nuclear weapons, and they do have an agenda. The Iranians are making it clear-- actually, they've escalated their rhetoric about Bahrain being part of Iran which was stolen by the Brits. They will probably take advantage of it to brandish nuclear weapons as a means of compellence in order to get the level of hegemony in the gulf and in the Middle East before the rest of the countries do acquire nuclear weapons. So I think that that is the most likely scenario, so it's not only what they could do against Israel, but what they do against Saudi Arabia, Bahrain.

### Conspiracy Advocate (CA)
Claim: We're not arguing that it's impossible.

### Moderator
Claim: Yeah, I'm not going to argue it's impossible--

### Conspiracy Advocate (CA)
Claim: There's no historic-- there's no historic example of successful compellence since 1945. There's no case in which a nuclear power used its nuclear power to compel some other country.

### Conspiracy Advocate (CA)
Claim: Britain and France got thrown out of every single colony they had in the world while they were nuclear powers. And their colonial powers weren't.

### Scientific Advocate (SA)
Claim: --analogies of such small effects have absolutely no scientific relevance.

### Moderator
Claim: I'm bothered-- I'm bothered by that. I'm bothered by that because that gives us nothing to talk about from history.

### Conspiracy Advocate (CA)
Claim: Right. I mean, history--

### Moderator
Claim: We've got to-- we've got to look back to some degree. I mean, it's your response every time-- every time they bring up something from history, you say it's irrelevant.

### Scientific Advocate (SA)
Claim: No, no. From history, you can bring up things from history but you have to bring up things from relevant history in a relevant region, in relevant circumstances and culture. What happened between--

### Conspiracy Advocate (CA)
Claim: So what is relevant, Shmuel?

### Scientific Advocate (SA)
Claim: --the United States and the Soviet Union, France and Britain--

### Conspiracy Advocate (CA)
Claim: Shmuel, what is relevant?

### Scientific Advocate (SA)
Claim: --has had nothing to with what happens in a region where people are--

### Moderator
Claim: I think we're having an Israeli moment here. Shmuel, what is relevant?

### Conspiracy Advocate (CA)
Claim: Jeffrey said-- Jeffrey said that Israel will have a hard time. We always have a hard time.

### Scientific Advocate (SA)
Claim: No, look--

### Conspiracy Advocate (CA)
Claim: Nothing will change.

### Scientific Advocate (SA)
Claim: Yeah, you always have a hard time. Some of it's self-inflicted, some of it is inflicted from outside; the proportion of the stuff that's going to be inflicted from outside is going to grow much great. You know, and Jim Dobbins is right. I mean, he's right. The day after Iran gets a nuke, you know, chances are Israel will still survive. I mean-- and it's a remote possibility that Israel could survive two or three or four years, but I really do believe--

### Conspiracy Advocate (CA)
Claim: A remote possibility?

### Scientific Advocate (SA)
Claim: I really do believe that Iran getting a nuclear weapon-- and, by the way, it's not the Israelis who believe it, it's the U.S. that believes this.

### Moderator
Claim: Whoa, Jeffrey, you said two or three years Israel would survive?

### Scientific Advocate (SA)
Claim: I think-- look, I believe that every three to four-- let's say every three to four years, there's another confrontation between Israel and one of Iran's proxies on its northern border or its southern border.

### Conspiracy Advocate (CA)
Claim: But there's nothing to do--

### Scientific Advocate (SA)
Claim: The next time there's one of these conflicts, I'm afraid that they're going to spin out of control. By that point, Saudi Arabia might have nukes, Turkey might have nukes, Egypt might have nukes. I don't see this as… As President Obama said repeatedly, that is, you know, to introduce so many nuclear weapons to such a small space that is already politically unstable, politically volatile, is a recipe for disaster.

### Moderator
Claim: So when Jim Dobbins said this debate isn't literally saying Israel can survive, you actually are taking it literally, that you think Israel cannot survive.

### Scientific Advocate (SA)
Claim: Oh, I read the instruction sheet wrong?

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: Oh really? No, I believe that-- I believe that it makes it-- that it makes it very, very--

### Scientific Advocate (SA)
Claim: Look, Israel-- why does Israel survive and thrive now? It survives because it's an immigration nation. Who's going to immigrate to a country that's on a hair-trigger nuclear alert, that lives under this Iranian nuclear umbrella?

### Conspiracy Advocate (CA)
Claim: Who immigrated to the United States?

### Scientific Advocate (SA)
Claim: investment. Who's going to build a $1 billion chip plant in Israel if they think that that chip is going to be blown up in a nuclear war?

### Conspiracy Advocate (CA)
Claim: Who immigrated to the United States, Jeffrey, with 25,000 missiles aimed at every target in the States.

### Scientific Advocate (SA)
Claim: But it was never the level of animosity--

### Conspiracy Advocate (CA)
Claim: And I hope that we'll survive more than three years.

### Scientific Advocate (SA)
Claim: --and the level of-- the level of conflict--

### Scientific Advocate (SA)
Claim: you know-- you know, you should survive forever, and that's what we're talking about. And I just don't see-- I don't see a Middle East that's poly-nuclear as a hospitable place for--

### Scientific Advocate (SA)
Claim: --that already has multiple dysfunctions.

### Conspiracy Advocate (CA)
Claim: I agree, it's not a nice neighborhood.

### Conspiracy Advocate (CA)
Claim: There's no automaticity to the--

### Moderator
Claim: Jim Dobbins--

### Moderator
Claim: --Jim we just need you near the mike, we can't hear you.

### Conspiracy Advocate (CA)
Claim: There's no automaticity to the idea that Iran's gaining nuclear weapons is going to proliferate. It's a risk, like these other things. And it's a risk that the U.S. takes seriously, which is one of the reasons why it's threatened to bomb Iran. It's not as if there's a gulf between the Israeli leadership and the leadership in Washington; they both agree that they should bomb Iran rather than allow it to have nuclear weapons, they just disagree about when.

### Moderator
Claim: Let's hear your questions. Front row, gentleman, right here. And just rise and we also need-- folks, because of the radio broadcast, also, hold the mike about that distance from your mouth. And tell us your name and ask your question.

### Moderator
Claim: Sure. My name is Randy And, Mr. Dobbins, the answer to your question is to mow the grass, that's what can be done. But I just want to follow up on Mr. Goldberg's line of thinking, which is the economic analysis, which is how many thousands of people will actually, human capital, leave Israel. How much actual capital, billions of dollars? Who is going to actually invest in Israel given the fact there is no margin for error and not only do you have explicitly nuclear weapons pointed at you, but you also have the danger of dirty bombs and technology transfer in the--

### Moderator
Claim: Okay. That's a great question, and it was really well done, let me just say. That's the model. Go ahead, Jim Dobbins.

### Conspiracy Advocate (CA)
Claim: The United States had a peer competitor that had in many cases, more nuclear weapons than we did. People invested. We had huge immigration. People went to New York and Washington, and they knew that they were going to be exterminated if there was a war. They were right in the hair trigger, wherever else the bombs fell they were going to fall there. Did it stop building? Did it stop immigration?

### Moderator
Claim: First of all, there's a difference in margin of safety.

### Moderator
Claim: Wait, wait. That’s for these guys.

### Conspiracy Advocate (CA)
Claim: Why? Why is there a difference?

### Moderator
Claim: Well, they're the debaters.

### Conspiracy Advocate (CA)
Claim: Why is there a difference?

### Moderator
Claim: Jeffrey, you have to say, first of all, there's a margin of safety issue.

No, seriously, I just want your question to provoke them. It was a great question, though, Jeffrey.

### Scientific Advocate (SA)
Claim: Am I supposed to deal with just the economic issue?

### Moderator
Claim: No, no. You're to respond to their response.

### Scientific Advocate (SA)
Claim: I'll let Shmuel do that.

### Moderator
Claim: All right, Shmuel.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: If you want to pass you can.

### Scientific Advocate (SA)
Claim: --Shmuel has the answer.

### Scientific Advocate (SA)
Claim: I don't know if everybody will leave Israel. I'll probably the one who turns off the lights at Ben-Gurion Airport. But I think it is absolutely ridiculous and absurd to compare a situation in which a country which has declared that it wants to exterminate the state of Israel, has nuclear weapons, as opposed to the balance which existed post Cuba between the United States and the Soviet Union, even though they both had nuclear weapons. It's-- you can make those analogies, but they have absolutely nothing to do with reality.

### Scientific Advocate (SA)
Claim: It's not-- it's not a real analogy. And I think that it would certainly have an effect-- by the way, an interesting poll in Israel was taken, and people were asked, will you leave the country if Iran gets a nuclear weapon? It turns out that somewhere around 30 percent of the Jews said they would think about it. 70 percent of the Israeli Arabs said they would think about it.

### Moderator
Claim: All right. But, you know, your-- part of your question that was really good that you were getting on your follow-up didn't get out, so go-- mic is back to you. Margin of error question.

### Moderator
Claim: Well, first of all--

### Moderator
Claim: Stand up, please.

### Moderator
Claim: Well, first of all, there's obviously an issue of a dirty bomb or the fact there's no geographic margin of error. But I really think that you ignore the key issue which I was trying to address in terms of my question, which are the actual capital which has been invested in Israel. Who is going to actually invest continuously in a country where you have the threat of existential destruction?

### Moderator
Claim: Okay. All right.

### Moderator
Claim: And in fact it was what-- a follow-up. The Israeli economy's been thriving and has been doing tremendously well. But given the fact that if there is this threat that's going on, the risk of an incremental investment there is just tremendous.

### Moderator
Claim: Okay. We-- we get it. Thanks. Do you want to take that, Reuven? I mean, it's a good question. Who's going to keep going to Israel, investing in Israel?

### Conspiracy Advocate (CA)
Claim: Jim gave an absolutely brilliant answer.

### Moderator
Claim: By comparing it to the U.S.

### Conspiracy Advocate (CA)
Claim: But who is investing in a country when each-- there are 60,000 missiles aimed at? Who invests in Israel these days?

### Scientific Advocate (SA)
Claim: I don't think you can compare conventional rockets to nuclear weapons.

### Conspiracy Advocate (CA)
Claim: Of course not.

### Moderator
Claim: You had a lot of subtext there. So can you draw out what your point was? You put into a rhetorical question that none of us can answer.

### Conspiracy Advocate (CA)
Claim: I believe this--

### Moderator
Claim: So make your point more explicitly.

### Conspiracy Advocate (CA)
Claim: I believe that most of the Israelis will stay in Israel even if there will be a nuclear Iran.

### Moderator
Claim: Is your point that Israel is already kind of a nasty neighborhood, and there are already Hamas rockets landing, and people are already investing in it?

### Conspiracy Advocate (CA)
Claim: I don't like our neighbors, but what can I do?

### Moderator
Claim: Let's go to the-- ma'am, right there. If you can tell us your name as well, please.

### Moderator
Claim: Hi. Quanta Ahmed. I'm a Muslim author. To my colleagues, Mr. Bar and Mr. Goldberg, I would say what's different and what you're arguing clearly is that the new ingredient is virulent political Islamism, which both of you have touched upon, which changes the equation, not just the poly-nuclear conflict. I think that's what makes this so much more dangerous than anything history's previously seen in terms of the Cold War. Would you agree? And could you expand?

### Moderator
Claim: Wait. Are you asking them-- you're saying you agree with them?

### Moderator
Claim: I agree with them.

### Moderator
Claim: But then you're asking them if they agree with you.

### Moderator
Claim: And also--

### Moderator
Claim: But do you want to put that question to this side?

### Moderator
Claim: As-- you're the moderator, but I think that's the part that's overlooked entirely.

### Moderator
Claim: So turn that into a question for this side, because that I think that's what your intention really is to do?

### Moderator
Claim: Why do you not feel that the ingredient of political Islamism, which is actually decimated so many Muslim states politically and ideologically and contributes to the destabilization in Pakistan, the country of my heritage, is not a destructive factor that is alien from the previous 60 years of nuclear armament.

### Conspiracy Advocate (CA)
Claim: Well--

### Moderator
Claim: Jim Dobbins.

### Conspiracy Advocate (CA)
Claim: First of all, I don't-- you know, Iran has been a very Islamist state for 30 years now, 40 years? '79.

### Conspiracy Advocate (CA)
Claim: '79.

### Conspiracy Advocate (CA)
Claim: It's probably a little less virulent now than it was, but it's still a virulent Islamist state. And yet it hasn't behaved irresponsibly in the sense of doing anything that endangers its existence. The regime has done lots of outrageous things. But none of them threatened its existence. None of them threatened the continuity of the regime. Iran in fact hasn't invaded anybody for 500 years. So it's not as if they have territorial claims. They're promoting subversion. They're promoting overthrow of hostile regimes. They're engaging in terrorism. And I would anticipate that they would continue to do so. At no point has either American or Israeli nuclear weapons deterred them from that. I don't think there's any level of that that they could engage in that would result in a nuclear strike on our part. And therefore, I don't think that their having nuclear weapons would particularly affect that kind of behavior, which would-- we would continue to have to respond to forcefully at times and certainly rigorously. But I don't think it would be notably harder.

### Moderator
Claim: Jeffrey Goldberg.

### Conspiracy Advocate (CA)
Claim: And as far as Islam and the Arab world, or for that matter in the South Asian world, I don't know that it's particularly, you know, relevant to this problem. It's certainly a challenge.

### Moderator
Claim: Jeffrey Goldberg.

### Scientific Advocate (SA)
Claim: Well, you know, to answer the question, the saving grace-- one of the saving graces of the Cold War was that the Soviets were atheists and that they didn't-- they didn't envision this world as simply the anteroom to a superior afterlife. And so I do think you have to take into account-- not just with Islam, but with-- as I said before, fundamentalist Jewish parties in Israel I wouldn't want to see controlling nuclear weapons. We're entering the age of political Islamism in the Middle East. The Muslim Brotherhood is in charge of Egypt today. In another year, it's going to be in charge of Syria. I'll answer this question with a question to the audience in a way, which is, would you be comfortable having the Muslim Brotherhood in Egypt be in control of nuclear weapons? Would you be comfortable having the Muslim Brotherhood in Syria be in charge of nuclear weapons? And for that matter, would you-- would you be happy if the chief rabbis of Israel had nuclear weapons?

### Conspiracy Advocate (CA)
Claim: They have. They have.

### Scientific Advocate (SA)
Claim: I don't know. The chief rabbis of Israel do not have nuclear weapons. They-- I don't want people who think that this world is simply a prelude to the next to help bring us there sooner.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this-- this is a little bit that I have to do. I wasn't trying to be funny. I want to remind you that we're in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters two, teams of two debating this motion: Israel can live with a nuclear Iran. Thank you for your patience. That's for the radio broadcast. Let's go on to some more questions. Ma'am, right here on the microphone, and please stand. Tell us your name.

### Moderator
Claim: My name is Susan Sandler.

### Moderator
Claim: The camera needs to find you. Thanks.

### Moderator
Claim: How does each side cope with the fact of unprecedented mass media, mass communications and to put it this way, everybody will have the same problems controlling their children that we have controlling our children as time progresses and people become more educated, more affluent in all parts of the world, and-- and although there is an Islamist revolution, there will be liberation from many dogma and many doctrines.

### Moderator
Claim: Ma'am, I'm not sure how your question focuses to our--

### Moderator
Claim: My question is how do they--

### Moderator
Claim: Just break it down, yeah.

### Moderator
Claim: --cope with this progression of-- of idea because nothing is-- since nothing is static, and so the apocalyptic, the inevitable view, how do they cope with it? And how do you cope on the other side with change that might evolve as it's coming up-- as is happening with all communications?

### Moderator
Claim: Ma'am, with respect, I'm going to decline your question because I think it's a little bit too broad and not focused. But thank you. Let's see. Right down in the front here, gray sweater. Yeah. Just wait for the mic to come for you. It's being passed down on your left side. And if you could stand so that the camera can find you. Thanks.

### Moderator
Claim: My question is for Mr. Goldberg. Mr. Goldberg--

### Moderator
Claim: Please, what's your name?

### Moderator
Claim: Oh, Farid Kress Many times the supreme leader has made a distinction between Zionism and Judaism. And many of the people in the regime have often said that they have nothing against Judaism. They have a Jewish MP; there's a very large synagogue that covers about four blocks in Tehran; you see many Jews-- not many, but I would say you see a few Jews going around, you know, with their distinct caps--

### Moderator
Claim: Ma'am, where are you going with this--

### Moderator
Claim: My question is this, is that-- do you really believe that the mullah-hating-- the mullah- hating Jews are who you claim they are? I mean, do they really hate the Jews when so many Iranian Jews of the older generation have returned to Iran? And they're--

### Moderator
Claim: So and your point being that this undermines the--

### Moderator
Claim: What I'm saying is that--

### Moderator
Claim: --Jeffrey's argument that--

### Moderator
Claim: --yeah, my question is that they don't really want to possibly annihilate the state of Israel more than maybe change the nature of the regime so it becomes more multi-ethnic, would you agree to that?

### Moderator
Claim: Okay, Jeffrey Goldberg.

### Scientific Advocate (SA)
Claim: Israel is the homeland and state of the Jewish people. They want to deny the Jewish people their right to a Jewish homeland and a Jewish state. They threaten to use violence and use violence to do that. I'm sure some of Ayatollah Khamenei's best friends are Jews. And I'm sure that people walk around the streets of Tehran with kippot on. I would point out that, yes, there's a synagogue open in Tehran, when Natan Sharansky and the refuseniks were in jail in the Soviet Union, there were five synagogues open in Moscow. It's not relevant.

The vast majority of Iranian Jews have fled the country. There was a population of 200,000. They're down to 25,000 now. It's not relevant. The Iranian regime is very happy to have their Jews living in protected second-class status, and that's the way that they like it. That's the Iranian regime. The Iranian people, by the way, are not anti- Semitic on the whole, but the regime most definitely is. I can cite you quote, after quote, after quote to show you that they have-- they take almost an epidemiological-- they use epidemiological metaphors to talk about the curse of international Jewry. You know, these are not people who want compromise on the West Bank. These are people who want the Jewish people denied their right to have a homeland in at least part of their historic homeland.

### Moderator
Claim: There's a-- right in front of you, two rows back, there's a mike being handed up to you. There you go.

### Moderator
Claim: All right, my name is William Gravsky I just want to preface this by saying that as a young man I had an opportunity to study for a year at the Hebrew University, very impressionable year. And recently I've had two opportunities to visit Iran for conferences there. And the question is really that Iran could be our natural ally-- is our natural ally in the region. You know, if there were 10 years of détente, the theocrats would be thrown out and there would be massive change. Also the--

### Moderator
Claim: Do you mean détente under a deterrent system?

### Moderator
Claim: I mean, relationships, that what we did with the Soviet Union--

### Moderator
Claim: Okay, I just want you to land this question in relation to our motion.

### Moderator
Claim: So what-- the very-- so-- that these are not fixed entities, that things can change, and that our policies could result in massive change in the Iranian regime, and that-- but in the-- a follow-up question is if there were a comprehensive settlement to the Israeli- Palestinian problem, wouldn't that also take the wind out of the sail of the Iranian animosity--

### Moderator
Claim: And would--

### Moderator
Claim: --and that anything that the Palestinians--

### Moderator
Claim: And, sir, let me-- I just--

### Moderator
Claim: Yeah.

### Moderator
Claim: --to-- I'm not disagreeing with you. You're asking this question, I'm asking you if you feel that you're-- would you amend it to say that even under a nuclear Iran things could change, that times could-- the settlement of the Israeli-Palestinian conflict would render irrelevant Iran's possession of the nuclear weapon as it relates to Israel's survival?

### Moderator
Claim: Well, it wouldn't change the problem of the partly nuclear Middle East. That would still be a problem. But it would change the dynamic.

### Moderator
Claim: Okay, you and I are debating now. I--

### Moderator
Claim: It would change the dynamic--

### Moderator
Claim: No, I don't mean to I just want you to put a focused question--

### Moderator
Claim: Would it change the dynamics of their animosity towards Israel?

### Moderator
Claim: Okay. Shimuel Bar.

### Scientific Advocate (SA)
Claim: Yes, I don't know, it seems-- I'm in this sort of cognitive dissonance here with some of those questions because I think sometimes I feel that I am living in a parallel world. I read what is written in Iran. I read the material coming out of the Iranian Revolutionary Guard.

I have no doubt that most-- you know, Iran is probably the most pro-American country in the Middle East after Israel, but it doesn't really matter, because, you know, you may have noticed that not everywhere in the world does the public opinion of the people rule the country. There are many, many countries in the world, not only North Korea and places like that, where people may think one thing and the regime is something else. And the more dictatorial the regime is, and the easier it is to make sure that what people want isn't what they get. The Iranian poet Saadi once wrote that the sultan is evil and you must get rid of him and you must destroy him, but if you cannot kill him-- you cannot cut off his hand, kiss it. And this is basically what has happened to the revolution in Iran. So-- to the green revolution.

Now, yes, it is possible that over a period of decades eventually Iran will get back to being, you know, a friend of America, a friend of everybody, and was a friend of Israel, was an ally of Israel. But what happens in between? And what does a regime do when it has a nuclear weapon and it does everything in order to enhance its position and to make sure that by enhancing its position abroad it can also put down its opposition at home, because who would dare intervene in Iran when Iran can do that sort of mischief abroad?

### Moderator
Claim: Okay. Do we have a question that will be directed towards this team? I only want to balance the talking time here. The far side. Oh, actually, I'm sorry, I meant higher up. But go ahead and do that. Go ahead, since--

### Moderator
Claim: You've talked a bit about the--

### Moderator
Claim: Can you tell us your name?

### Moderator
Claim: Sorry. I'm So you've talked a bit about the opposition. I mean, about the, sort of, fundamentalist groups in Lebanon and in Palestine, Hamas and Hezbollah. What do you think about how this would affect the fight against Mr. Assad, in Syria? And what do you think that the current situation in Syria, where you have 100 of fragmented groups fighting against Mr. Assad--

### Moderator
Claim: You mean--

### Moderator
Claim: How do you think that that could affect Israel?

### Moderator
Claim: Do you mean, Iran's getting a nuclear weapon. How would that affect the situation in Syria?

### Moderator
Claim: Yeah, how would that affect this situation and how could the combination of the two affect Israel?

### Moderator
Claim: Given that Syria is Iran's basic-- only ally in the region.

### Moderator
Claim: Yes, and that Syria shares a border with the U.-- with Israel.

### Moderator
Claim: Good question.

### Conspiracy Advocate (CA)
Claim: Good question. But, to use their phrase, it's not relevant.

### Moderator
Claim: Sorry?

### Conspiracy Advocate (CA)
Claim: It's not relevant to our debate what's going on in Syria.

### Scientific Advocate (SA)
Claim: I mean-- I mean, I--

### Moderator
Claim: Hey, give the kid a break.

### Conspiracy Advocate (CA)
Claim: Sorry, sorry.

### Moderator
Claim: Jim Dobbins. answer.

### Conspiracy Advocate (CA)
Claim: I mean, I don't-- Iran is already--

### Moderator
Claim: mic

### Conspiracy Advocate (CA)
Claim: Iran is already helping the Assad regime. It would probably do so under those circumstances. I don't see why it would-- its help would be more efficacious because it had nuclear weapons. It's not going to threaten to use nuclear weapons against the Iranian opposition, so I don't think it's likely to have a major impact. It might have some short-term psychological impact, but it-- you know, I mean, the United States successfully waged a war that got-- that three the Soviet Union out of Afghanistan employing Pakistani and Afghan surrogates. The Soviets had nuclear weapons, they were completely useless. They got defeated in Afghanistan despite the fact that they had 24,000 nuclear weapons.

### Moderator
Claim: I know it's an analogy.

### Conspiracy Advocate (CA)
Claim: It's not an analogy, it's history.

### Moderator
Claim: That's a pretty-- that's a pretty good analogy.

### Scientific Advocate (SA)
Claim: No, no, the timeline--

### Moderator
Claim: Shmuel Bar.

### Scientific Advocate (SA)
Claim: The timeline is-- you know, time is out of The Assad regime is going to fall within half a year or so anyway, and Iran is going to take over the northern part of--

### Moderator
Claim: No, but the part-- the part of what he said that I found interesting was how powerless the Soviets were when they had nuclear weapons--

### Scientific Advocate (SA)
Claim: Yes, but--

### Moderator
Claim: --to win in Afghanistan.

### Scientific Advocate (SA)
Claim: Because they-- you can't use a nuclear weapon in order to fight a war in Afghanistan, it wasn't relevant to that.

### Conspiracy Advocate (CA)
Claim: And in Gaza?

### Scientific Advocate (SA)
Claim: That's not the situation that we're talking about. We're talking about nation-states which have nuclear weapons and are posturing with nuclear weapons against each other and are going on nuclear alerts and are going into spirals of escalation. And this is what we're talking about; we're not talking about things like-- wars like the Soviets waged in Afghanistan. It's not relevant.

### Conspiracy Advocate (CA)
Claim: Why is-- why is what the United States did to the Soviet Union in Afghanistan different from what Iran is doing to Israel in Gaza? Why is it different? It's exactly the same. You're supporting an insurgent pool against them-- and nuclear weapons were irrelevant.

### Scientific Advocate (SA)
Claim: But why is it relevant to this?

### Conspiracy Advocate (CA)
Claim: It isn't relevant. That's the point. The nuclear--

### Scientific Advocate (SA)
Claim: No, I mean--

### Conspiracy Advocate (CA)
Claim: --weapons had no effect in either case.

### Moderator
Claim: The why is it relevant thing is really getting old for me.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: I find it relevant. And I'm neutral in this, but I find it an engaging thought.

### Scientific Advocate (SA)
Claim: Yeah. So the United States supported bin Laden in Afghanistan to help him kick out the Soviets, that was a very good idea, I think it was really a marvelous idea, I'm sure that you're happy with that, you know, in retrospect.

### Conspiracy Advocate (CA)
Claim: Seemed like a good idea at the time.

### Scientific Advocate (SA)
Claim: Yeah, especially in this city. But what we're talking about here is the risk of Iran acquiring a nuclear weapon against a series of countries, an array of countries which are going to have nuclear weapons as well, and not-- not the issue of how do you prevent a superpower with using limited conventional weaponry to invade a neighboring state, and then you use your own proxies against their proxies. It's a completely different game.

### Moderator
Claim: Right down in front here. Just let the mic come to you. It's coming from behind you. And if you could stand up, please.

### Moderator
Claim: Yamashi I would like to reverse a question. How much longer do you think Iran can live with a nuclear Israel?

### Moderator
Claim: That's not the debate tonight. I'm sorry. Thanks. No, it's not a bad question. It's just that it's not going to move us forward. Ma'am, on the far-- all the way towards the back there. Third from the far row.

### Moderator
Claim: Hi. Thank you so much.

### Moderator
Claim: Ma'am, could you stand? Thanks.

### Moderator
Claim: My name is Renee Tambor I'd like to ask the panel how they would like to live with somebody next door who said they're going to kill you, and they have all the weapons, just as we have guns and so ongoing on here, people threatening to kill other people--

### Moderator
Claim: Okay. Again-- again, ma'am, I think--

### Moderator
Claim: Excuse me.

### Moderator
Claim: I think we've covered-- I think we've covered it with respect that part of the question, and I respect your passion, and I hear it. But I want to move on to a different topic.

### Moderator
Claim: Can I just change my question at this point? I'll change my question.

### Moderator
Claim: You said how can you live with somebody next door to you who wants to kill you? And I-- and Jeffrey made that point very relevantly. And with respect, if you could yield the mic. Sir.

### Moderator
Claim: Thank you, Fred Baumgarten A question for Mr. Dobbins. You've talked about Israel dealing with uncertainties rather than certainties. My question is, can you give us some metrics by which Israel can calibrate an appropriate reaction And also, can you give us some historical examples of how other countries have dealt with existential threats and what levels of uncertainty has been acceptable versus a precursor to a swift response?

### Moderator
Claim: So what are the red lines to living with a nuclear Iran? Jim Dobbins?

### Conspiracy Advocate (CA)
Claim: Well, you know, I'm not sure that one can calculate exact levels of risk. I would certainly acknowledge that the risk of miscalculation and a nuclear exchange is higher if the countries have nuclear weapons than if they don't. It's high enough to be very concerned about. And so, going back to my proposition, Israel shouldn't have to live with a nuclear Iran if it has a better choice. I'm just arguing that there aren't better choices necessarily than those that we're already pursuing. I mean, I will get into whether it's relevant or not, but a whole literature on the concepts of deterrence, on means of deterrence, on mutual signaling, on avoiding escalatory instability by making sure that you weren't subject to a first strike, and thus tempting your adversary to make that first strike in rising tensions.

There are ways that one can minimize the risk of escalation by the way one constructs and hides and disposes of one's nuclear forces. There are technical ways that one can avoid unauthorized use of these kinds of weapons. And there's a long history of literature on that. The United States, for instance, has sought to help Pakistan establish physical mechanisms and procedures that would make an unauthorized or accidental launch of a nuclear weapon more difficult. I'm not suggesting we necessarily get into such a relationship with Iran, but we might hope someone did.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate. Where our motion is Israel can live with a nuclear Iran. And we are about to move on to round three which will be brief closing statements from each debater in turn. They will be two minutes each. And this is their last chance to try to influence your vote. Immediately after their closing statements, we'll have our second vote. And remember, it's the team that has moved your numbers the most in the course of the debate who will be declared our winner. Onto round three, closing statements. Our motion is, Israel can live with a nuclear Iran. And here to summarize his position against the motion, Jeffrey Goldberg, national correspondent for the Atlantic and columnist for Bloomberg View.

### Scientific Advocate (SA)
Claim: Thank you, John. I want to just tell a very brief story. In 1998, I was in Afghanistan, in Kandahar when Osama Bin Laden issued his first fatwa, the first big fatwa, the fatwa against crusaders and Jews. And I was with a bunch of people, westerners, and we heard about this. And frankly, we laughed about it because it seemed crazy, absolutely insane, the audacity of it. And, you know, I learned three years later that very often when someone who says something that seems crazy, says it over and over again, that it's worth paying attention to.

And so on my visits to Iran, and I've been there a few times, I've talked to people in the regime about these subjects. I'll tell you one very brief encounter I had with a guy named Mohammed Ali Samadi who was a leader of a group called the Seekers of Martyrdom, which actually sounds like a great name for a band, actually. But their job at the time was to try to figure out how to kill Salman Rushdie. And-- but I talked to him about Israel. And he said the following, which has always stayed with me. There are always infections and diseases in man. In the world, there is an infection called international Jewry.

And I listened to him, and I listened to various leaders of the regime. And I have decided to take them seriously. I think in the post 9/11 age, we have to take religious fundamentalists who say they want to kill you seriously. I think it is possible to overlearn the lessons of Jewish history, to overlearn the lessons of the holocaust. But I'm even more afraid of underlearning the lessons of Jewish history. I believe that the Iranian regime is serious about wanting to find a way to destroy the state of Israel. I believe that if they get a nuclear weapon, they will go a great distance to achieving that goal. And therefore, I ask you to vote against this resolution, vote against this motion. Thank you.

### Moderator
Claim: Thank you, Jeffrey Goldberg. Our motion is Israel can live with a nuclear Iran. And here to summarize his position in support of the motion, Reuven Pedatzur, a senior military affairs analyst with Haaretz.

### Conspiracy Advocate (CA)
Claim: Thank you, unfortunately, all the arguments that we have raised were irrelevant. So I tried. Anyway, I understand the arguments of the other side. It's very frightening to live under this shade of this hostile regime with nuclear weapons. I have no illusions. The Ayatollahs are not lovers of Zion. But they are very rational, and they want to survive, and they want to their country. And at the end, they are not going to use the weapons. We can live with nuclear Iran. I live in Tel Aviv. This is the center of the target. And I didn't ask my four daughters and my grandchildren to leave Israel, because I believe that we can live in Israel and survive more than three years.

In the '50s, at the end of the '50s when there was the threat of the Soviet Union, people in the States started building atomic shelters in their back yards. And Kennedy ran for president promising that he is going to build atomic shelters for the whole population. I hope that we are not going to start building atomic shelters in Tel Aviv. A nuclear Iran is not the end of Zionism. Thank you.

### Moderator
Claim: Thank you, Reuven Pedatzur.

Our motion is Israel can live with a nuclear Iran. And here, summarizing his position against the motion Shmuel Bar. He is director of studies at the Institute of Policy and Strategy in Herzliya, Israel.

### Scientific Advocate (SA)
Claim: Thank you. I want to just reiterate that rationality of every single individual involved in a conflict is not a guarantee that the conflict will end or will develop in a rational manner or in a way which everybody will be happy with. In the end, history shows us that a lot of things happened which everybody's sorry about, that it's bad for everybody.

Now, you know, we talk about the Cuban Missile Crisis, et cetera. Actually, during the Cuban Missile Crisis, all of these rational people were very, very close to Armageddon, which was, according to the capabilities of that period. During the Cold War, there were a number of instances where the United States and the Soviet Union, with all of their command and control capabilities, with all of their intelligence, actually came to some very, very dangerous points, which were avoided because the leaderships had a means of communication.

Now, the level of hostility in the Middle East does not augur well for direct communications between-- not even-- not only Israel-Iran, but Iran-Saudi Arabia, and we're talking about a Middle East in which countries are falling apart, and that some countries may acquire the nuclear weapons that they will inherit from the countries which are disintegrating. We're talking about a region which is-- I call this the "Humpty Dumpty stage," that they're falling apart and nobody would put them together again-- this is a very dangerous area to have nuclear weapons. Ultimately, the question is not, "Well, can you do anything about it? If you can't do anything about it, live with it," but "You have to do something about it. You've got to find a way." And, believe me, there are more than one ways to skin a cat, even a Persian cat.

### Moderator
Claim: Thank you, Shmuel Bar. The motion, "Israel can live with a nuclear Iran," and here to summarize his position in support of the motion, James Dobbins. He's director of the International Security and Defense Policy Center at RAND.

### Conspiracy Advocate (CA)
Claim: Well, I'm old enough to remember when in elementary school we were taught to hide under our desks under nuclear attack.

### Conspiracy Advocate (CA)
Claim: Duck and cover.

### Conspiracy Advocate (CA)
Claim: Duck and cover. And, you know, sirens would go off, and we would hide under our desks, so, you know, some level of fear and concern is natural enough in a society that faces that kind of threat. And if you can avoid the threat, by all means, do so if you have a better choice. We didn't have a better choice at the time. Reuven has suggested that a nuclear Iran will not be the end of the Jewish state. And I'd have to say most Israelis agree with him. The Times of Israel published a poll last week, a poll done in the context of their election campaign, in which they asked the Israeli populace what were the issues that most-- that created most anxiety, what were they most worried about. Was Iran the number one issue? No. Economic issues were their dominant concern. Was Iran the number two issue? No.

Actually, and perhaps rather healthily, the deterioration in relations with the Palestinians was the number two concern. Was Iran the number three concern? No. The third concern was the state of their education system. Iran was the fourth in this list of six, with 12 percent of the Israeli population thinking that the Iranian threat was their principal concern.

Well, I'm old enough to remember when in elementary school we were taught to hide under our desks under nuclear attack.

### Moderator
Claim: Thank you, James Dobbins. And that concludes our closing statements. And now it's time to learn which side you feel argued the best this evening. We're asking you again to go to the keypads at your seat as you did at the beginning of the debate. The motion, "Israel can live with a nuclear Iran," if after hearing the debate you've been moved to this side or stayed at this side, press number one.

If your position is or became against, push number two. And if you remained or became undecided, push number three. And if you think you pushed a key incorrectly, just correct yourself and the system will only record your last vote. And we'll have the results of that vote in just about a minute.

Okay. Before we do that, I want to do this. It's a contentious topic tonight. I think it was done in a very, very civil and constructive way. Certain things were declared irrelevant repeatedly. And maybe they were, but I want to congratulate our debaters for the quality of debate-- also want to thank people who asked questions this evening, and that includes the questions that I did not take. I want to make it clear that if I pass on a question it is not meant as a disrespect in any way or a sign that the question is invalid or unsound. I particularly liked your question. In fact, about-- what is their-- Iran going to do about nuclear Israel? Someday we're going to have that debate.

### Moderator
Claim: I know you feel it's relevant, that's why you asked it, but I have to make a judgment call on that, and the woman who expressed her passion about living next door to a neighbor who wants to kill you, I totally respect that, and there is no disrespect intended in passing on the question. I just felt that we had covered it. But I basically want to say let's give a round of applause to everybody with the nerve to get up and ask a question tonight. So thank you for tolerating my occasionally vanishing laryngitic voice tonight. It will be better at the next debate, which will be Wednesday, February 13th.

We will be looking at this motion: prohibit genetically engineered babies. It's based on the fact that we already screen for genetic diseases, and the ability to choose a child's color and intelligence is, actually, not so far off. We want to look, basically, at the policy and the ethics implied in that manifestation of a brave new world. Our debaters will include, for the motion, arguing to prohibit: Sheldon Krimsky. He is the chair of the Center for Responsible Genetics and professor of humanities and social sciences at Tufts University. He will be partnered with Lord Robert Winston. He is a pioneer in fertility and IVF treatment and professor of science and society at Imperial College. Arguing against: Nita Farahany. She is a professor of law and genome sciences at Duke, also a member of the presidential commission for the study of bioethical issues. And her partner will be Lee Silver. And Lee Silver is a professor of molecular biology and public policy at Princeton University.

Tickets for our spring season debates are available right now through our website, www.iq2us.org. And for those of you who cannot make it to the debate or be in a live audience, those of you are watching right now on live stream, know that there is the live stream at fora.tv. You can also listen to the debates, this one included, on NPR and watch them on PBS stations across the country. Just check your local listings for air dates and times. We'd also love it if you tweeted about tonight's debate. Even if you haven't, you can go home and do it now. Our Twitter handle is @IQ2US and our hashtag for this evening's debate in particular is @IsraelIran.

All right, the results are in. Okay, so remember, we've had you vote twice and the team whose numbers move by the largest percentage point is declared our winner. So let's find out who you decided won this debate. The motion: Israel can live with a nuclear Iran.

Before the debate, in polling you in the live audience, 25 percent of you agreed with the motion, 35 percent were against it, and 40 percent were undecided. So the final results-- remember, the winner is the team that has changed the numbers the most from the first vote to the second. The second vote now. The team arguing for the motion: they went from 25 percent to 37 percent. That is a 12 percent increase; that is the number to beat. Now, let's look at the team against the motion. They went from 35 percent to 55 percent. They went up 20 percent, that's the winning side. The team arguing against the motion "Israel can live with a nuclear Iran" has won our debate. That's it for this time. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
