# Debate Transcript

Topic: Diplomacy With Iran Is Going Nowhere
Motion: Diplomacy With Iran Is Going Nowhere

Debate ID: iran-diplomacy


## Round 1

### Moderator
Claim: Well thank you very much, and welcome. This is the final debate of the third season of the Intelligence Squared debates. The very first debate that launched the very first season was the resolution, “We must tolerate a nuclear Iran.” Well three and a half years, almost four years have gone by and Iran today has more influence in many neighboring countries than it had then. Influences in Iraq, it has much more influence in Syria, it has much more influence in Lebanon. It has supplied Hezbollah with more and better rockets aimed at Israel and it has made huge strides in uranium enrichment and the capability to build nuclear weapons. These developments all challenge vital U.S. interests – the nuclear program perhaps most of all. And atomic weapons don’t have to be used to deter threats of regime change or to deter vigorous response to Iranian provocations like proxy attacks on Israel or, in a possible scenario – interference with the flow of oil through the Strait of Hormuz. But we have to recognize that these developments are rational ways for Iran to enhance their own sense of security and to project their power and influence in their neighborhood. So tonight’s debate is not really about whether we should communicate with a hostile Iran, but what we should say. How can we plausibly induce Iran to change course? What costs can we threaten or impose? What inducements can we offer? And finally, what role should diplomacy have in this process? We have a really outstanding panel tonight to shed light on these questions and it’s my pleasure at this point to turn the evening back to John Donvan.

### Moderator
Claim: Thank you. And given that this is the conclusion of the third series of Intelligence Squared U.S. and that Robert Rosenkranz started this thing and it’s gone into its third year now, I just want to invite one more round of applause for Robert Rosenkranz. Welcome to another Intelligence Squared U.S. debate. I’m John Donvan of ABC News Nightline and I will be moderating the four debaters you see sharing the stage here with me at the Caspary Auditorium of the Rockefeller University in New York. Two teams, two against two for, two tables will be debating this motion: Diplomacy with Iran is Going Nowhere. Now, I want to make clear that this is not a panel discussion or a seminar. This really is a contest. It is a debate. It is a competition of ideas and logic and wit and possibly humor and charisma. We’ll see how it goes. But most of all it’s a contest of persuasion because these debaters are here to change your minds. By the time the debate ends you will have voted twice – once before the debate begins and once again at the end, telling us whether you side with the motion or against the motion. And we would like to register the preliminary debate right now, if you go to your key pads. Once again, our motion is: Diplomacy with Iran is Going Nowhere. Press number one if you agree with the motion, number two if you disagree and number three if you are undecided.

And again at the end of the evening we’ll have you vote again and the team that has changed most minds from this initial position will be declared our winner. All right, we’re locking in the vote and we’re moving forward. And I just want to point out to our radio audience, because they cannot see the hall there, that there’s a little bit of a buzz about the fact that one of our guests is the former Vice President of the United States, Dick Cheney, who is about four rows up. And it occurs to me, sir, by saying four rows up I may have ruined the undisclosed location rule. I apologize but I assume that we’re past that. So to round one, opening statements, our motion is: Diplomacy with Iran is Going Nowhere. Our first speaker, arguing for the motion, Liz Cheney, is a lawyer and under the George W. Bush Administration, she was Principal Deputy Assistant Secretary of State for Near Eastern Affairs. Earlier in her career she served at the U.S. Agency for International Development. She was in Poland, among other places, and curiously, Liz, in a debate that is about diplomacy, you have done quite a bit of diplomacy in your time.

### Conspiracy Advocate (CA)
Claim: Well, don’t hold it against me. Thank you. Thank you very much. It’s great to be here tonight. Dan and I are here with the task of convincing you why diplomacy with Iran is going nowhere. And I think it’s important as we begin thinking about this issue to stop for a moment and ask yourselves, What is our current diplomacy with Iran? What’s the current state of affairs? The current state of affairs is that the Obama Administration has privately and publicly offered direct, unconditional talks to the Iranian regime. The Iranian regime has failed to respond. So as of now, there is no diplomacy with Iran. There are no talks.

Even if there were talks tonight, Dan and I want to describe for you why it is that those talks, in fact, are going nowhere, and it’s for three reasons. There are really three elements that should be present in any set of diplomacy to have any chance for that diplomacy to succeed in preventing the Iranians from obtaining a nuclear weapon. First, the current set of diplomacy of diplomatic outrage by the Obama Administration includes no threat, no credible threat of military force should the diplomacy fail. Secondly, there is no time line in place that would prevent the talks from dragging on and on and prevent the Iranians from using the talks as an excuse to continue to develop their nuclear program. And third, none of the very crippling economic sanctions that might actually convince the Iranians that the cost of attaining a weapon is too high are in place.

Now, let me just be clear. Dan and I are not arguing that force is necessary. We’re not arguing that military force is unavoidable and we’re not arguing that diplomacy itself is doomed to fail. We’re simply arguing that the current course we’re on is, in fact, a course to nowhere. Now, as you think tonight about your vote with respect to this resolution, one of the really important things to consider, which the Obama Administration has not been considering, is the history of American efforts to reach out to the Iranians. And I wanted to just run through for you tonight a few of the high points of that history, because any realistic effort to use diplomacy effectively has gotta take that history into account. In 1979

National Security Advisor Zbigniew Brzezinski met in Algiers with the Iranian Foreign Minister, Prime Minister and Defense Minister.

And according to a note taker who was present in the meeting, Brzezinski told the Iranians, quote: We will accept your revolution, we will recognize your country, we’ll recognize your government, we’ll sell you all the weapons that we contracted to sell the Shah. Three days later the U.S. Embassy in Tehran was seized. Two weeks later the Iranian officials Brzezinski met with had lost their jobs. In 1980 Warren Christopher negotiated the Algiers Accord with the Iranian regime. The Iranians agreed to take no further hostile actions against the United States. Three months later they seized the American, seized new American hostages in Lebanon. One year later they attacked the U.S. Embassy in Beirut and three years later they killed two hundred and forty-one Marines in their barracks in Beirut. Throughout the 1990s the Europeans threatened to impose sanctions if the Iranians didn’t alter their behavior. The Iranians did not alter their behavior and the Europeans did not impose sanctions.

In 1996 Iran was responsible for bombing Khobar Towers in Saudi Arabia, killing nineteen American soldiers. Despite this attack in the late 1990s Washington decided it was time to try again, to extend yet another hand to the Iranians to build a new relationship.

We lifted parts of our sanctions program allowing food and humanitarian efforts, or humanitarian supplies, into Iran. And the President and the Secretary of State gave speeches essentially apologizing to the Iranians for past American behavior. In response, the Iranian Supreme Leader said these apologies were, quote: Too little too late and did no one any good since the Americans continue to commit such crimes. Now, you can read a much fuller account of this part of the diplomatic history in Ken Pollack’s terrific book, which I really do commend to you, called The Persian Puzzle. You’re welcome.

But to, to be fair, though, it’s not just Ken who has been involved in failed attempts to reach out to the Iranians. Nick and I have also have our fair share of that, as well, when we both worked in the Bush State Department. 2004, the European Union III completed the Paris Agreement with the Iranians in which they promised to suspend enrichment activities. In August of 2005 Ahmadinejad was elected. They announced they were continuing their enrichment activities and the Russians prevented us from attaining any real sanctions against the Iranians at the United Nations. In 2006 we took the step of offering for the first time in thirty years direct negotiations if the Iranians would give up their enrichment program and our European allies committed to imposing tough sanctions if they didn’t.

The Iranians didn’t give up the enrichment program and, of course, our allies wouldn’t allow us to impose tough sanctions. In 2007 the National Intelligence Estimate, parts of which were declassified, showed there is one thing, actually, that the Iranians did respond to. Although the Iranians did continue to enrich uranium they did halt other parts of their nuclear weapons program in the immediate aftermath of the U.S. invasion of Iraq. In 2008, despite the fact that the Iranians had failed to meet any condition we had set for direct talks and despite the fact that they were funneling weapons and terrorists into Iraq to kill Americans, we sent our Undersecretary of State, Bill Burns, to meet with the Europeans and Iranian representatives. Once again the Iranians learned that no red line is really a red line. To sum up this history let me quote from the man who was actually the note-taker at that first meeting in Algiers in 1979. He’s our current Secretary of Defense, Bob Gates. Describing this meeting recently, Secretary Gates said, quote: Every administration since then has reached out to the Iranians in one way or another and all have failed.

Some have gotten into deep trouble associated with their failures, but the reality is the Iranian leadership has been consistently unyielding over a very long period of time in response to repeated overtures from the United States. In closing let me just say that the history of our attempts to reach out to Iran offer us lessons about the three things that might actually work in terms of inducing Iranian effort, in terms of stopping Iranian efforts to attain a nuclear weapon. We’ve gotta have a credible threat of the use of force if diplomacy fails. There have to be crippling economic sanctions that impose a significant cost on Iranian attempts to attain a weapon and we’ve gotta have a timeline so that the diplomacy doesn’t drag on forever. None of those things characterize our current nuke diplomacy with the Iranians. And therefore, diplomacy with Iran is going nowhere. Thank you.

### Moderator
Claim: Perfectly timed. Because we give each of the speakers seven minutes and that was six minutes and forty-eight seconds. Huh, huh. Very, very well done. Arguing against the motion, our other diplomat in this debate, Nicholas Burns, who is now a professor in the practice of diplomacy at the Harvard Kennedy School. But for twenty-seven years he served five presidents, ultimately as our nation’s top ranking career diplomat. And Nick, I understand that under the second Bush Administration you were the State Department’s point man for Iran but you were not allowed to speak to any Iranian officials. How long did that persist? Three years. Well, here you’re free to talk as much as you want, as long as you’re within seven minutes. Ladies and gentlemen, Nick Burns.

### Scientific Advocate (SA)
Claim: Thank you very much. Thank you. Thank you very much. I’m delighted to be here. And thanks to Intelligence Squared for bringing all of you here for this important debate. I can think of no issue facing our country that’s more important to our future, more important to Israel, more important to our Arab partners than the issue of Iran. And I thank Liz for her remarks. It’s good to be on the same dais with Liz and Dan. They’re former colleagues of mine from the United States government, and Ken as well. We hope to convince you tonight, Ken and I, that actually, it’s very difficult to say that diplomacy is going nowhere with Iran when we haven’t started diplomacy with Iran.

I have something to say about this and some familiarity about this. I was for three years the point person on Iran on the negotiations perspective for Iran for the United States government for President Bush and I never met an Iranian government official during those three years. With the exception of a couple of meeting in Baghdad between – and these were public meetings – between our Ambassador and the Iranian Ambassador to Iraq there were no sustained negotiations between the United States of American and the Iranian government. So we attempt, we want to convince you that we’ve gotta give diplomacy a chance. We can’t give up on diplomacy before we’ve started diplomacy. I think that’s the first thing I’d like to say to you. Second, it is important to remember a little bit of the history that Liz reviewed. We’ve had three decades of a non-relationship with Iran. It’s the most unusual diplomatic or non-diplomatic relationship we have in the world. Since the Iranian Revolution there have been times when American officials have talked to Iranian officials but there have been no sustained negotiations on the nuclear issue and even on any other issue for many, many years.

That’s not a situation that we should feel proud of. It’s certainly not a situation that advances our national interests. We have no diplomatic relations with the government of Iran. We have no business community, American business community, in Iran and haven’t for thirty years. There is no major presence of American journalists. So we’re in the extraordinary position of looking at a government that arguably poses the greatest challenges to the United States in the Middle East and yet we know precious little about that government. So that’s what this evening’s debate is really all about: how to be tough minded-- and I certainly agree with Liz and Dan on that-- about the Iranian government, but also there’s a twin challenge, a second challenge: how to engage that government sufficiently so that we have a much better understanding of what its bottom line is, of whether or not a deal is possible, about whether or not diplomacy can be successful in this case.

President Obama intends to begin negotiations this summer, probably after the June 12th Iranian elections. My successor, Undersecretary of State Bill Burns, did meet with the Iranians once last year for a couple of hours. But the Obama Administration is about to test the proposition that perhaps we should have more extended discussions with the Iranians-- not because we’re acting of naivete, not because we’re weak, not because diplomacy is feckless, but because it’s our self-interest to gather information along with the Russians, Chinese and Europeans and see if there’s some way to maneuver the Iranians, pressure the Iranians away from a nuclear weapons future.

I certainly agree that there’s a lot to worry about with the Iranians. They are seeking a nuclear weapons capability that would change the balance of power in the Middle East against us. They’re funding and directing most of the major Middle East terrorist groups that are a problem for us, for Israel and for our Arab partners. And because of their proximity to Iraq and Afghanistan they are fundamentally involved in both countries and in a way sometimes that’s very detrimental to the United States. But the problem I have, and I think the problem all of us have in looking at this question is, have the policies of the Clinton Administration and even the administration in which I served, the Bush Administration-- have they succeeded? Policies of isolating the Iranians, policies of refusing to meet with Iranian government officials, calling for regime change against Iran-- I would submit that those policies have not worked.

And the test of any American policy is not whether we feel good about them or feel good about giving speeches. It’s are they effective? And therefore I think that President Obama is right to, to embark on a new path. What is that? It’s a combination of engagement with Iran and also pushing back against Iran to protect Israel, to protect United States’ interests. And what would that negotiation look like? The United States, Britain, France, Germany, Russia and China would be on one side of the table with Iran on the other. We would be arguing that Iran should cease and desist in its nuclear weapons ambitions, cease and desist in its support for terrorism. The only way to make that point effectively at this point is to stand opposite them and to engage them. Now, I agree with Liz. We’ve gotta be very tough minded. We’ve, I think President Obama would be well advised to put a time limit on these negotiations so that the Iranians don’t run out the clock.

He’d be well advised to keep the military option on the table because that is language that the Iranians would understand, and certainly well advised to say to the Iranians, If negotiations don’t work we are prepared to put Draconian economic sanctions on you. Because we’re not gonna give up on this fight to make the Middle East safe from an increase in Iranian power. Why try diplomacy? First, it’s the only way we will ever know if a peaceful outcome is possible. It’s the only way we’ll ever know if we can avoid a war in the Middle East. Second, we already have two wars underway in the greater Middle East – in Iraq and Afghanistan. Unless it is absolutely necessary do we Americans want to embark on a third war? Third, negotiations will actually isolate the Iranians. It’ll put the United States on the offensive for the first time in a long, long time and it will actually increase international leverage against the Iranian government.

And fourth, we are no worse off if we try diplomacy because if negotiations fail we will be in a much stronger position than I was as the person negotiating with Russia and China and the Europeans, to say to them, especially to Russia and China, We did what you asked, we tried diplomacy. Now you need to back us in very tough sanctions against the Iranian government. You need to put the weight of your governments behind the United States. We’ll be in a much better place to say that, to be convincing about that if we try diplomacy first. I don’t see how we can say that negotiations and diplomacy are going nowhere if we haven’t made a concerted attempt to try diplomacy first, backed up by a very tough minded American policy. Thank you.

### Moderator
Claim: Thank you, Nick Burns, arguing against the motion. Arguing now for the motion that diplomacy with Iran is going nowhere, Dan Senor-- a man who I know put his own security where his mouth was. I know this because in the early days of the U.S. invasion of Iraq I kept running into Dan Senor on my trips there. He located himself there full time to work as spokesman for the Coalition Provisional Government. He is now considerably better groomed than he was during those, that Baghdad summer. He is on the National Council, he’s on the Council of Foreign Relations and has co-founded the Foreign Policy Initiative and is here to argue that diplomacy with Iran is going nowhere. Dan Senor.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you, John. And it’s good to be on this panel with Liz and Ken and Nick, who probably all agree on more things than we disagree. But certainly on this issue there is disagreement. It’s also always good to be considering debating a potential conflict – heightened tensions in the Persian Gulf-- while in the heart of the Upper East Side. Liz and I are really advantaged in this and it’s live on BBC, no less. I just want to pick up on something Nick said, that it is hard to say that diplomacy with Iran is going nowhere if it hasn’t really begun. I would say he’s right, the second part of that – that it really hasn’t begun. But it’s not for lack of trying. I think it’s important to evaluate not only the history that Liz went through, in terms of the decades of efforts to negotiate and deal with Iran, but also actually look at just the last few months and the signals that this administration has sent to Iran, even before this administration took power. In 2007 and 2008, while this country was consumed with this fresh face on the scene – Senator Barack Obama – so was the world. There was deep, intense election night coverage in the United States but also on Al Jazeera and Al Arabiya and the Arab satellite channels and the different news broadcasts throughout the Middle East.

They actually covered primary, they have their own primary election night specials in the region – the best political team in Abu Dhabi coverage, or whatever you want to call it. And they were consumed with this. They were consumed with it for a number of reasons, not the least of which is so much of Barack Obama’s message was a clear rejection of U.S. foreign policy under George Bush. In fact, in the Democratic primary, one of his sharpest criticisms against Senator Hillary Clinton at the time was that she was basically a closet hawk, that she would represent somewhat of a continuation of Bush foreign policy. And the issue he specifically drew contrast with her on that was Iran, because she had supported some tough sanctions that related to the Iranian Revolutionary Guard Corps.

And, and Obama called this a continuation of Bush policy on Iran. There is going to be change. And the American people overwhelmingly voted for this new face, this change, this rejection, if you will, which was a centerpiece of now President Obama’s campaign – overwhelming voted and sent a message to the world that there would be a new policy. Barack Obama’s inaugural address with President Bush sitting a few steps away, he issued some pretty sharp, very public criticisms while the world was watching of the former administration’s foreign policy over the previous eight years.

He then in his first hundred days made good on his commitment on Iraq, which is basically to move along some sort of timeline for withdrawal, which was a big issue for the Iranian government. He has in recent weeks been very assertive about his plans for pursuing aggressively a two-state solution on the Israeli-Palestinian conflict – another important issue to the Iranian leadership. He traveled to Europe and gave a series of speeches in which, again, he almost apologized for U.S. foreign policy over the previous eight years and made clear that things were going to change. And then finally and most importantly, he was issued an unconditional invitation to sit down with the Iranian government, in defiance, I might add, of three Security Council resolutions that call on the Iranian government to halt its nuclear program.

President Obama is putting himself out there. He is really exposing himself by making such a clear and bold initiative for diplomacy. The only problem is, despite all this, against all this backdrop, the Iranian government still has not returned the call. So it is true that diplomacy has not begun. But it is not for a lack of trying. As Dennis Ross, who is currently advising President Obama on Iran policy today, has said in a report that was issued by the Bipartisan Policy Center late last year, If we have to chase the Iranians to the table then any hope of diplomacy is off the table. We can, there can only be a truly viable diplomatic track if we can get to the table quickly, both sides agree that there is a real diplomatic process. At the moment we are chasing the Iranians to the table. We are off to an unwinnable start. So I would just simply say that it is true that diplomacy has not begun but it is not for a lack of trying, which raises questions about where it is actually going. And finally, I would just pose the following question to Ken and to Nick: If you argue that it hasn’t gotten off the ground but it will get off the ground, the question is, What is your timeline?

I commend a report to all of you that came out today issued by the Senate Foreign Relations Committee on Iran. Chairman John Kerry of the Senate Committee hired an investigative journalist and hired a number of other journalists and former Intel officials who actually traveled around the region to really get their own independent assessment of how far Iran is from having a nuclear weapon. And the report was issued this afternoon. You can get it on the Foreign Relations Committee website. It’s very clear. The time for inaction is narrowing. So if we say diplomacy hasn’t begun and we gotta let the beginning, the path to the commencement take place, and then we’ll consider how long the actual diplomatic process will take, is a tough sell, given the timeline that many are projecting, including as of today the most recent, the Senate Foreign Relations Committee.

Finally I would say the question that needs to be considered is, What is the nature of the regime we are dealing with in Iran? If we believe that there is a possibility of diplomacy being successful, if that is our objective to prevent Iran from developing a nuclear weapon on this path, what is the nature of the regime? Is it a—one possibility is that it is a radical theocracy – in which case I’m not convinced they can be persuaded against a nuclear weapon. And if they are driven by some sense of martyrdom and some sense of inevitable outcome that is worth sacrificing their country I’m not convinced that they can be persuaded that they should not have a nuclear bomb. Perhaps they’re rational and a nuclear bomb would bring them national power, it would deter U.S. threats in the future, it would cement potentially their hegemony throughout the region. And if they’re rational and that’s what this is about, I believe there are no inducements we can offer them. There are none that, no carrots that would be better than all that they would gain from having a nuclear bomb. So if we are going to pursue some sort of diplomatic path it must have a real timeline that is narrow and it must be backed up by a very credible threat of military force and a very credible threat of crippling sanctions and a real clearly defined publicly available trigger point for those actions to take place. Thank you.

### Moderator
Claim: Thank you, Dan Senor. And finally, arguing against the motion that diplomacy with Iran is going nowhere, Ken Pollack, whose point of agreement with Dan Senor back in 2002 was his book, Threatening Storm, which argued for the toppling of the Saddam Hussein regime. Since then he has written about Iran, arguing for negotiations and his most recent book, A Path Out of the Desert: A Grand Strategy for America in the Middle East, makes the same point – and I must say, ‘cause I’ve read it, is a terrific read. Ladies and gentlemen, Ken Pollack.

### Scientific Advocate (SA)
Claim: Thank you all. It’s wonderful to be here. Thank you, John, and Liz also, for the plugs for my books. I can’t appreciate that enough. I promise to get you a check later on. And it is wonderful to be up here with my friends, with Dan, with Liz, with Nick, debating a very important topic. I thought I’d start where Nick left off. I thought I’d start by talking a little bit about the potential for a peaceful resolution. And we need to recognize that there is the prospect. We don’t know – and I say this as someone who has studied Iran for over two decades – at the CIA, at the Department of Defense, at the National Security Council and the think tank world.

We don’t really know what the Iranians want. We don’t really know what they’d be willing to give. And in direct answer to Dan’s question of what might it take...Why have they not taken the choice already? Well, we haven’t put the choice to them directly. The choice that we need to put to them is a very simple one. You get to have a good, thriving economy which is ultimately what the people of Iran want or you get a nuclear weapon. But you don’t get both. The critical thing that you need to keep in mind – and I don’t think that Liz and Dan necessarily disagree with that-- but the critical thing that you need to get, keep in mind is how we get to that choice, how we force the Iranians to recognize that they get to have one or the other, not both. They don’t get to have their cake and eat it, too. I agree that this regime in Iran is not yet ready to sit down and compromise with us. I think they’ve made a tactical decision to talk to us. They have not made the strategic decision to compromise with us. And so the question becomes, How do we get them to that point?

Well, as Liz very nicely described, we tried, when I was first in the Clinton White House, at the NSC, working on Iran. It was 1995-96, the period when the Clinton Administration, of which I was a part and working on Iran, imposed comprehensive unilateral sanctions against Iran. And these sanctions hurt. Do not believe for a second that those sanctions were meaningless. They hurt Iran and they hurt Iran to this day. But they haven’t hurt Iran enough to force them to make that choice, to make it the way that we want them to. Later on we tried in 1998-99, my second time in the White House, to bring the rest of the world on board because we recognized that the only way to put that kind of pressure on the Iranians was to get the support of the world, to get them on board with the same kind of sanctions which could inflict the kind of pain on the Iranians that would force them to make that choice, the choice that they’re trying to avoid.

And what we found was that the rest of the world wasn’t ready. And Nick and Liz tried the same thing during the Bush Administration and they found the same thing. And what we consistently heard over and over and over again was, You have not made a good faith effort with the Iranians. You’ve not put a deal on the table that they might accept, you have not given them a chance to say yes. Now we can debate about whether that’s true or not, but the simple fact is, that’s what the rest of the world believes. And until we convince them otherwise, they’re not gonna join us in imposing harsher sanctions on Iran, the kind of sanctions that might force the Iranians to come to that decision. Now the second thing that I wanna do, is to talk a little bit about what happens if we stop the diplomacy.

Because we do need to think about that, it’s the elephant in the living room. If we’re not talking to Iran we’ve gotta be doing something else. And as I said, unilateral sanctions, no matter how clever both the Clinton and Bush administrations were in imposing unilateral sanctions, those don’t seem to be enough. And so if those aren’t gonna be enough, and we’re not gonna try to diplomacy, that is the one way that we might be able to get international support for the kind of harsh sanctions on Iran that might change their mind, well, alternatives start to look a lot worse. And I say that as someone who is very realistic about the chances of diplomacy with Iran. I could add, Nick could as well, a half- dozen other problems to the ones that Liz and Dan have already mentioned. Okay, we’ve been through it, we know how hard it is to deal with the Iranians.

But the simple fact is, that diplomacy is much better than any of the other options, all the options stink. But some of ‘em stink a lot worse than others. Option one, we could do nothing. We could sit back and try to contain the Iranians, and deter them once they’ve got nuclear weapons. I don’t know about the rest of you, but that’s a social-science experiment I’d prefer not to run. Okay? We don’t know what the Iranians will do when they have a nuclear weapon, I tend to doubt they’d actually use it, but I’m not certain, and I wouldn’t want to find out that I was wrong. And even if I am right about it, we’re going to face an aggressive Iran, one that is going to be much more willing to support its terrorist allies, all across the Middle East. The last thing that the Middle East needs is more trouble, more instability, more Iranian-assisted troublemaking in the region, and that’s exactly what we get, if we allow them to have the nuclear weapon.

Another alternative is regime change. We go in there and we decided we’re gonna get rid of the governments. And the way that people typically think about regime change in Iran is, we’re gonna spark a popular revolution. And people say that because the truth is that as best we can tell most Iranians don’t really like their government, and they’d like to see it changed. The problem with this is, that revolutions are very unpredictable, and they’re very rare. And we don’t really know how to get one started in Iran. And beyond that, we have what’s called, what I call the Groucho Marx problem. That every—remember Groucho once famously said that, he wouldn’t wanna be a member of any club that would have him as a member? Well, every Iranian oppositionist who accepts money from the United States of America, is totally not someone we should be giving money to. ‘Cause they probably work for the Iranian intelligence services, and they probably don’t have any support among the Iranian people, because since 1953, when we overthrew Mossadegh, we have been the third rail of Iranian politics. And the last option that’s out there, and I don’t think anyone on the panel is arguing for this but let’s remember it, is war. Okay. We can try airstrikes against the Iranian nuclear program. But don’t think that this is gonna be a quick surgical strike. Okay, the Iranian program is big, it is dispersed, it is hardened. It is going to require hundreds if not thousands of sorties, to take down that program. And most of the intelligence people I’ve spoken to including the Israelis, believe that even a wildly successful strike would probably only set the program back by one or two, maybe if we got really lucky, three or four years. And the Iranians will retaliate. And they will rebuild. And we will have to strike again. Okay. This will not be a surgical operation, it will as Nick said, be an open-ended war. Another open-ended war in the Middle East.

These are all paths that we may have to confront at some point in time, but I’d suggest to you that we shouldn’t do so, until we have made sure that there is no diplomatic solution. We’re not there yet. And let’s just remember, the very wise words of Franklin Roosevelt, a man who was determined to wage World War II because he knew it was the right thing to do. But who famously once said, that jaw- jaw is better than war-war. Thank you.

## Round 2

### Moderator
Claim: Thank you, Ken Pollack. This is an Intelligence Squared debate, I’m John Donvan, your moderator, we have two teams of two members each, debating this motion, “Diplomacy with Iran is going nowhere.” And we’re gonna now reveal the…debate— the vote numbers, we ready with those? Do I have them in my hand—okay. As you recall when you came in you were asked to vote on the motion, “Diplomacy with Iran is going nowhere”…you pushed 1 if you were for, 2 if you were against and 3 otherwise. It’s a three- way split. 34 percent are for the motion— 33 percent against, and 33 percent undecided. And, reminding you that the way we predict—the way we call victory is the team that moves the most minds during the course of an evening and so it’s really a horserace at this point. On to round two, and in round two, the debaters address one another, they take questions from you the audience and also questions from me. I wanna begin with this, it seems as though we have a very basic disagreement on the facts when we hear Liz Cheney talk about repeated overtures, and Nick Burns arguing against the motion, saying that there has been no diplomacy, there is no diplomacy with Iran.

### Scientific Advocate (SA)
Claim: Well I think I said that, you know, since 1979-80, there’ve been lots of individual meetings, I think between Americans and Iranians, I think every administration has done that.

### Moderator
Claim: But why is that not diplomacy—

### Scientific Advocate (SA)
Claim: There have been no— That’s not diplomacy. That’s not what we mean by diplomacy. There have been no sustained discussions on the nuclear issue, which is the most important issue. Take…my example. I served in the Clinton administration, and I served in the Bush administration. In the Bush administration I had the responsibility for trying to put those negotiations together. And we were not able to do that, we didn’t meet with anybody, we didn’t have extended discussions with the Iranians, we never got in the room with them, in a meaningful way. That’s what diplomacy is.

It’s actually trying to figure out what the other side is up to, what their bottom line is, seeing if it’s right for us, and smart for us to make a deal. And I just pose the following question based on that. If you’re not for diplomacy now, and if you wanna give up on diplomacy which is the position of Liz and Dan, then what are you for. You can’t say you’re not for war. Because you’ll then leave President Obama with one option—to go to war, you’ll have no credibility to go to sanctions, as Ken said. If we leave the diplomatic field right now, the Europeans, the Russians and Chinese will not support us on sanctions. You’re leaving President Obama with one choice. Go to war, third war…

### Moderator
Claim: Liz Cheney—

### Scientific Advocate (SA)
Claim: —for the United States of America in the Middle East.

### Moderator
Claim: Liz Cheney.

### Conspiracy Advocate (CA)
Claim: Well I think first of all, Nick is mischaracterizing Dan’s and my view on this, Dan and I are not arguing that we should abandon diplomacy or that we should not undertake diplomacy. Dan and I are simply arguing that the current diplomacy is going nowhere, and it’s going nowhere because it’s flawed diplomacy. Now, discussing this issue with Nick, you know, I feel a little bit like Alice in Wonderland here, because Nick and I sat in many of the same meetings over the course of a number of years, and, saying that we didn’t have diplomacy because we didn’t have sustained discussions completely ignores the fact that it was the Iranians who made that choice in many, many instances.

And I went through in the beginning of the talk the extent to which the United States government has over 30 years attempted again and again and again, including our National Security Advisor sitting with the Iranian Prime Minister and saying, we will sell you weapons, we will recognize your country, we’ll recognize your revolution. And the Iranians walk away from the table time and time again. Now I think this gets to a very fundamental point that Dan made which is, what is Iran, what is the nature of that regime. And part of the problem with the current diplomacy, the reason why I believe—one of the reasons I believe it’s going nowhere is because there’s a fundamental misunderstanding, about the nature of the regime.

You know, President Obama makes—gives a Norouz message to the Iranian people but also to the regime and he talks about things like common hopes, and common dreams. I don’t believe that we have any common hopes or dreams with the supreme leader in Iran. I don’t, I think the supreme leader in Iran believes in exporting terrorism, he believes in exporting his Islamic revolution, and I think that, you know, at the end of the day, you’ve gotta ask yourself, you know, as Kissinger was asked, is Iran a country, or are they a cause, if Iran is a cause, if they are a hegemonic, revolutionary, terrorist, extremist power, and they’re attempting to gain a nuclear weapon, then we are being dangerously naïve and irresponsible to pretend that we have now history here of trying to talk to them—

### Moderator
Claim: Let me bring in the other side? Nick Burns.

### Scientific Advocate (SA)
Claim: It’s important to note that this famous meeting that Liz has now cited twice took place 30 years ago. Not exactly in modern times. I’d also say this in defense of President Obama. I’m impressed by him, I’m someone who’s not a Republican, I’m not a Democrat. I’m not a political person. I think he’s actually outpointing the Iranians. He’s put them on a defensive. That Norouz message was not to the supreme leader. It was to the Iranian people. And I think it’s— It makes a lot of sense. It makes a lot of sense to stretch out a hand, to the Iranian people, over this chasm of three decades—what has President Obama done? The Norouz message. He invited Iran to a UN conference on Afghanistan. He said that the United States for the first time would join these negotiations unconditionally which I happen to think is the right thing to do right now. Because our prior policy didn’t work. With the Iranians. And so therefore, it’s hard to argue that diplomacy’s going nowhere when President Obama’s taken baby steps to put us maybe into the first phase of diplomacy. I would submit that we’ve all gotta give him at least six months to try diplomacy—

### Moderator
Claim: Dan—

### Scientific Advocate (SA)
Claim: —before we denounce it—

### Moderator
Claim: Dan Senor.

### Conspiracy Advocate (CA)
Claim: Can I just ask a question—or go—go ahead.

### Conspiracy Advocate (CA)
Claim: I just wanna make one quick point which is that our opponents need to decide what their position is. Their position is either, diplomacy hasn’t started, which is what they both argued when they made their opening presentation, it hasn’t started, it’s gonna start this summer, give it some time. Or their position is, well, diplomacy has sort of started with some baby steps. Or their position has gotta be, you know, look, it’s started and the Iranians have responded well, you know, they gotta choose one of those. But I would say that, that at the end of the day what we’ve seen actually is the administration has attempted to reach out a hand, the Iranians have not responded and there’s a report this afternoon, uh, out of the Jerusalem Post that the Iranians are actually basing missiles now along the Straits of Hormuz.

### Moderator
Claim: Ken Pollack, your—your opponent’s calling for clarify on your position.

### Scientific Advocate (SA)
Claim: Yeah, look, I think that to say, have they started yet or are they just taking baby steps, it’s a difference without real substance there. I think the point that we’re trying to get at here though is that, we don’t really know what the Iranian position is. And more importantly still, the diplomacy is about more than just Iran. In fact the most important object of our diplomacy, are as Nick was suggesting, as I suggested, our European allies, our East Asian allies, the Russians, the Chinese, everyone else who is probably going to have to come onboard, before the Iranians realize that they’ve gotta make a serious decision—

### Moderator
Claim: But is—isn’t that diplomacy about Iran as opposed to diplomacy—

### Scientific Advocate (SA)
Claim: Correct, that is—

### Moderator
Claim: —with Iran which is—

### Scientific Advocate (SA)
Claim: That’s exactly—well, but both of them are interlocking. Because the rest of the world is not interested in us only having diplomacy with them, without also trying to engage the Iranians. That’s what they want. That’s the carrot for them. And in return, we’re trying to get them to sign up for the stick.

### Moderator
Claim: Liz, I—if you, can you come a little closer to the mic—

### Conspiracy Advocate (CA)
Claim: Yeah, I just wanna—you know…actually it’s not fair to say the rest of the world wants us to talk to Iran. I think that you’ve actually got a situation now, you saw it during the election, where you had the British for example act, you know, demonstrate extreme nervousness with the notion that suddenly the United States was offering direct, unconditional talks, which is basically leaving our European allies aside. Our European allies have been with us in the European Union III, we’ve been working on a multilateral course for diplomacy, direct talks cuts them out of the picture. We haven’t even talked about our Arab allies, and the notion that the Arab nations today want us to talk to Iran, you know, is a fallacy. What we’re hearing from government after government after government, is that they are very nervous, they believe the United States is about to make deals with Iran, and so they are now thinking do we need to make our own deals…? You know, their concern is so great that we’ve sent our Secretary of Defense out to calm ‘em down, so the idea that the rest of the world wants us to talk to Iran, fundamentally mischaracterizes the danger of this new openness and this unconditional—

### Scientific Advocate (SA)
Claim: Liz, I don’t—

### Moderator
Claim: Ken Pollack—

### Scientific Advocate (SA)
Claim: disagreement here, and the—

### Moderator
Claim: All right, I’m—

### Scientific Advocate (SA)
Claim: The fundamental disagreement I think—

### Moderator
Claim: —I’m, just to clarify, Nick Burns—

### Scientific Advocate (SA)
Claim: —that I certainly have with Liz is that I spent most of my time between 2005 and 2008 shuttling to Paris and London and Moscow, and Beijing on this question. Those partners of ours want us to have talks with Iran. They have accepted I think, I know they’ve accepted, that now we should do it unconditionally. We— when we conditioned in 2006, our entry into negotiations on Iran suspending its enrichment program, it gave the Iranians an excuse not to come to the table. Obama has taken away the excuse, which is one of the reasons why I’m impressed by his sophisticated diplomacy. And I can tell you for certain, that the European allies agree with this, and that they are ready to negotiate with us on that basis.

### Moderator
Claim: Dan Senor.

### Conspiracy Advocate (CA)
Claim: Nick, if the Americans have taken away the excuse, how long before the Iranians reciprocate, I mean, how long, you said six months, are you giving six months for them to agree to come to the table, or are you giving them six months, once they agree to come to the table, that then they have six months to figure out whether or not we can get a deal.

### Scientific Advocate (SA)
Claim: You know, Ken and I are not arguing that diplomacy is a panacea. We’re not naïve. We know that diplomacy might not work, but if you try diplomacy, and give it a shot, then it does strengthen us for what’s ahead, what’s ahead of us. Two major options to deal with Iran. One is to go back to very tough sanctions of the type that we haven’t tried before, because we haven’t had the credibility to convince the rest of the world to do it. And finally the use of force, and I’ve said, we should leave the use of force, the threat of it on the table, we should threaten sanctions, but you’ve gotta go through this diplomatic process first, to get to either of them. If you don’t do that you have no credibility—

### Moderator
Claim: What’s on the table is that the Iranians don’t want negotiations, Dan Senor said chasing Iranians to the negotiating table. Ken Pollack, do you think Iran, anybody in Iran wants negotiations—

### Scientific Advocate (SA)
Claim: I think the problem is that the Iranians do want negotiations, it’s not clear that they actually want a deal. That’s the problem, and that’s exactly what Dan is getting at, and he’s right to. But, you know, the point that— Look, we’re not the ones writing out the policy for the administration, if we were we’d be glad to engage this question of exactly when. For the purposes of this debate, for the abstract expression of it, I think that the key point is again, what will it take to get the allies signed up for the tough sanctions. If it’s six months of making a good-faith effort, fine. If they say nine, fine. Now, we can’t let it go forever, and for me the big question mark is can we get them signed up to harsh sanctions in advance, based on when the Iranians pass certain milestones. That oughta be the key question.

### Conspiracy Advocate (CA)
Claim: make a point there because that is an important point, and actually we did that. We had them as Nick well knows signed up in advance for tough negotiations in 2006 when we offered tough sanctions. When we offered direct negotiations, the deal was, that the allies would agree ahead of time that they would support tough sanctions on the Iranians if the Iranians did not agree to suspend enrichment. The Iranians did not agree to suspend enrichment, we got Security Council resolutions which the Russians in particular, as Nick knows because he spent hours and hours dealing with the Russians, managed to take every single tooth out of.

Now we’ve, since the Obama administration has been in office, had the Russian foreign minister in Washington, and he’s announced that in fact he doesn’t believe it’s time for tougher sanctions against the Iranians. But, I think it’s very important for people in the audience, first of all to look at the wording of the resolution, the question is not all of the questions that Nick and Ken are trying to get you to focus on, it’s not should we go to war, it’s not, should we do diplomacy or not diplomacy, the question is, is our current policy going anywhere. That’s the question, and I find it really fundamentally irresponsible, for Nick and Ken to act like, let’s just give diplomacy a chance ‘cause we haven’t done it before.

### Moderator
Claim: Nick Burns.

### Scientific Advocate (SA)
Claim: Right. Liz and I are, I’m not gonna engage in attacks, Liz and I are friends and we’ve been colleagues—

### Moderator
Claim: I—

### Scientific Advocate (SA)
Claim: It’s not true—

### Moderator
Claim: —honestly, I don’t think that was an—a personal attack—

### Scientific Advocate (SA)
Claim: Oh—

### Moderator
Claim: —that was—

### Scientific Advocate (SA)
Claim: I’m—

### Moderator
Claim: —that was right to the core of the argument—

### Scientific Advocate (SA)
Claim: —it’s not true that we also—it’s not true that we live in alternate universes. But it may seem that way. Now what happened in 2006 when the United States government made the most ambitious offer we’d ever made…and I really commend President Bush and Vice President Cheney and Secretary Rice for order—authorizing that. We made a very good offer and the Iranians turned it down, that’s the Iranians’ fault, they walked away at that time. But what hadn’t happened— What hadn’t happened is that we did not have explicit promises from the Russians and Chinese, much less the Germans, French and British, as to what type of sanctions would follow. And so what Ken and I are arguing is that, it would I think behoove itself to President Obama, to make a very explicit deal with Moscow and Beijing, before the United States sits down at the negotiating table, the Russians and Chinese will specify the type of sanctions that would ensue, should negotiation fail. That would be a stronger position that we had in the Bush administration.

### Conspiracy Advocate (CA)
Claim: this policy was actually sold internally, because people were told that we had commitments that there would be sanctions if the Iranians in fact did not suspend enrichment, now maybe you’re—now maybe you’re, it’s semantics about specific sanctions.

### Conspiracy Advocate (CA)
Claim: But the idea was, the—I’m telling you what I know. What I know is that we had a commitment from those allies that we would go to sanctions, that they would support tough sanctions, if in fact the Iranians refused to suspend. The Iranians refused to suspend, and we got no tough sanctions.

### Scientific Advocate (SA)
Claim: The tough—the word “tough” is not accurate. I negotiated that deal, ahead of time—

### Conspiracy Advocate (CA)
Claim: You negotiated—

### Scientific Advocate (SA)
Claim: —and I negotiated—

### Conspiracy Advocate (CA)
Claim: —for weak sanctions.

### Scientific Advocate (SA)
Claim: No I didn’t. I didn’t. I mean let’s be fair about this, Liz. Let’s be fair about it. I served in the Democratic administration and Republican administration. The policy of both President Clinton and President Bush has not worked…and we oughta have the courage to see it—

### Conspiracy Advocate (CA)
Claim: I totally agree with you—

### Scientific Advocate (SA)
Claim: —and the courage to admit it—

### Conspiracy Advocate (CA)
Claim: I agree with you.

### Scientific Advocate (SA)
Claim: And so what President Obama is trying to do, is to create a new type of diplomacy, it is very tough-minded. It allows us to fall back on military force if we have to, but it does give diplomacy a chance for the first time. We did not have commitments, for the type of specific sanctions that would go into play, and you haven’t seen that in 2006 and ‘7 and ‘8, these were very weak UN Security Council resolutions, admittedly. And now we’ve gotta have a different way of going forward, with diplomacy. So if Liz and Dan say, diplomacy’s failing, President Obama’s failing, then I think what they’re really doing is leaving him with one option and that is war and they can’t deny that—

### Moderator
Claim: Dan Senor, the—Nick Burns just made the point, why not give it a chance, it’s a new initiative, and he says in a new style, why not give it a chance.

### Conspiracy Advocate (CA)
Claim: ‘Cause it takes two parties to participate in a diplomatic process and right now there’s only one party participating in it. So we can call and call and call all we want, but they’re not participating, and I know we’re asking everyone here to vote on this motion, as Liz alluded to earlier, the Arab world which is closest to this, is already voting. How they think diplomacy is going, how they think the current strategy is going, I just wanna read you an editorial from the Jordan Times. It says “Arab capitols have all the right to be worried about a new adventurous US policy in this part of the world that may again not succeed as planned. Washington surely cannot dramatically shift its policy vis-à-vis the countries in the Gulf. The new administration lo—risks losing its barely- regained credibility in the region, if it does not consult its friends about its new standpoints in the area, new friends should not come at the expense of old ones.” This was not written at the height of the unilateralism of the Bush administration, this was published in the Jordan Times today. The Arab world is deeply concerned, that the message the administration is sending is it’s gonna cut some sort of grand bargain potentially with the admini—with Iran at best, and at worst, leave an open-ended process which is this, we’re calling and calling and begging them to come to the table and they’re never responding, and oh by the way the clock runs, and a nuclear bomb appears at the end of the day. So, debating, you know, giving diplomacy a chance, not giving it a chance, we’re perfectly prepared to give it a chance but just listen to those closest to it in the region. They don’t believe that there’s any reciprocity on the other side.

### Moderator
Claim: Ken Pollack.

### Scientific Advocate (SA)
Claim: I could—first, let’s, you know, you’ve accused us of mischaracterizing, let’s not mischaracterize what the Arabs are saying either. They are concerned about the negotiations, they are not saying don’t offer to talk to the Iranians, they are not saying don’t talk to the Iranians. What they’re saying is when you talk to the Iranians, do this and this and you better tell us everything you’re doing and you’d better not do the following things. Second, as Nick pointed out, the answer to the issue is not, that we only have two people at the table and one won’t come. There is a third party in the room, as we keep trying to point out, that’s the entire international community. And the question I would put back to you and to Liz, Dan, is basically this. You are saying you want tough sanctions. How do you plan to get those tough sanctions without going through diplomacy.

### Moderator
Claim: Okay, I’d like to… I’d like to bring you into the conversation now and I’d like to do it in the form…I would find a way to say what you wanna say and answer, it’s a politician’s trick and… I’ll call on you, please try to keep your question to 30 seconds or thereabouts, really a question, you can make an opening comment, certainly to state your premise but we don’t want you arguing as well because we have four very good debaters here. Hold the microphone this close to you, and where’s the center microphone— Gentleman right on the center aisle here, please.

### Moderator
Claim: Hi, I—I’ve heard Nick’s argument, and I think without getting in a more just round, in a circle, I’ve, from my perspective don’t see where the Iranians would give a lotta credibility to these threats of sanctions or war or anything else, so I would like to hear the panel kinda debate and address, what do you think the…make, make the arguments for what the Iranians have to gain, by giving up these nuclear weapons, and, what they have to lose. Ken started to touch on it. But it hasn’t really been explored.

### Moderator
Claim: Ken, can you—

### Moderator
Claim: And I would get into that to decide whether diplomacy can go anywhere.

### Moderator
Claim: Ken, put yourself in the position of the Iranian government in a negotiation with the US, what do they want.

### Scientific Advocate (SA)
Claim: Sure. Look, I think the truth is that the Iranians don’t want to be in these negotiations because they’re very happy with the status quo, that’s the regime. Okay, and that’s exactly a point that Dan and Liz have made, they’re absolutely right. We’re dealing with an Iran that is at least bifurcated, what the people want and what the regime want are often two different things. And that’s ultimately the goal of the diplomatic process. Is to put the regime on the horns of a dilemma.

To say to them you can have what you want or what your people want, but not both. And you’re going to have to choose. And what we’ve seen with this regime is, while they are autocratic, while they control absolute power in Iran, they are very sensitive to public opinion. They don’t like to be put in the position where it is clear that what they are doing is the exact opposite of what their people want. And what their people want is a thriving economy. Their economy is in desperate straits at the moment, it is going down the toilet. Comprehensive international sanctions could push it over the edge, and the regime is extremely fearful of that. On the other hand, what we can offer them if they do the right thing and that’s what we threaten them with if they do the right thing, if they do the right thing what we can offer them is the economic support that they so desperately need. The lifting of not just the international sanctions but of our own unilateral sanctions, the provision of trade credits, investment guarantees, and everything else. We say to the Iranians, you have two paths. You can choose the path of darkness, you keep your nuclear program and your support for terrorism and everything else, and we will cripple your economy.

And that is something that your people will not abide.

### Moderator
Claim: Dan Senor—

### Scientific Advocate (SA)
Claim: Or, you can do the other way, and we will make your economy thrive—

### Moderator
Claim: Dan Senor—

### Conspiracy Advocate (CA)
Claim: I would just argue that, it is true, the economy is in desperate shape, 25, 30 percent inflation right now, 25, 30 percent unemployment, oil trading today about 60 dollars a barrel. They are in a much weaker, you know, less than half than what it was a year ago, they are in a much weaker economic situation. But if it—what Ken is stating, that the Iranian government, which is complicated and opaque and difficult for all the reasons Nick said for us to truly understand, but if you believe that the Iranian government, is effectively going to make a rational decision and they can be won over with inducements which is what he’s saying, what package of inducements could we ever offer them, ever, that would be better than the situation they would get from having a nuclear bomb. I mean think about this, a nuclear bomb would be able to guarantee that the US would never threaten them again, we would— If Iran tomorrow decided that they wanted to go into Bahrain which they consider one of the original Iranian-Persian provinces, if they wanted to go, slowly take over Saudi oil fields, which would certainly help their economic situation, we would have virtually no leverage, we would pose no threat to them and as they’d try to further establish their own hegemony as I said earlier, in the region, having a nuclear bomb would allow them to cement that. What inducements do we have to offer them, that would be better than all that a nuclear bomb would give them.

### Moderator
Claim: I thought that was a rhetorical question, but Ken, you—

### Scientific Advocate (SA)
Claim: Come on…Dan, do you really believe that even after the Iranians have nuclear weapons we’re gonna let them take over the Saudi oil fields? We did a pretty good job of keeping the Russians out of Germany, I think we can keep the Iranians on the other side of the Persian Gulf.

### Conspiracy Advocate (CA)
Claim: I think trying to— This is a classic fallback position, trying to compare the Iranian regime to other governments, and other situations—

### Scientific Advocate (SA)
Claim: But, they’re much weaker, that’s my point.

### Conspiracy Advocate (CA)
Claim: Yeah, but potentially—and there’s also potentially an internal divide and fissures within the regime that’s divided between those who are motivated by national interests and those that are radical theocrats, as President Obama has described them, that aren’t terribly rational, and trying to figure out and game them out and hope that we can win over and resolve those fissures in the short period of time before they actually have a nuclear bomb, to me, is a pretty big gamble.

### Moderator
Claim: And your partner, Liz Cheney?

### Conspiracy Advocate (CA)
Claim: Yeah, I mean I think it’s, you know, terrific to sort of sit here and say here is the ideal set of circumstances, we gotta have these tough sanctions and, Liz and Dan, how are you gonna get those tough sanctions, you know, without doing diplomacy. And I would say the history of the relationship shows, we aren’t gonna get tough sanctions with diplomacy, the current diplomacy that we’ve got, at the end of the day, what Dan is—the argument Dan’s making is absolutely right that, the Ira— There are not inducements at this point, there are not inducements that make the Iranians better off than having the bomb. What does cause the Iranians to alter their behavior and what we have seen historically is if they believe that there is a credible threat of military force if they don’t alter their behavior. This is also true of our European allies. And as you’re talking about this diplomacy I think we need to think about the motives of all of the people, all the partners involved here. You know, the Europeans, as we’ve seen throughout, they like their commercial relationships with Iran, and they don’t like the notion that the United States is gonna use military force against Iran. If they believe the threat of military force is on the table, that’s frankly the only thing I’ve seen that convinces them they better get serious about sanctions. We have not seen them serious about sanctions, and I think the idea that we’re gonna call this current diplomacy strong or tough diplomacy, it simply doesn’t bear out if you look at the facts. This is diplomacy with no teeth, this is, you know, an open hand, direct and unconditional. And—

### Moderator
Claim: Question from the second row. You can stand up and, if you’re a member of the press please identify yourself.

### Moderator
Claim: pardon me, I’m nervous with this distinguished panel and this audience. I’ve one simple question for the Burns-Pollack team, with this basic background. Hope springs eternal, but history tends to repeat itself. And we’ve had 30 years of diplomacy with a capital or small “d.” We’ve had, Burns admits that in the, I think he said, ’96 or ’97, we gave a real good deal, and Iran flipped us whatever you wanna insert after that. My question is this. In the concept of we don’t know what Iran wants, I mean, we listen—

### Moderator
Claim: You know—go to your question—

### Moderator
Claim: My question is, can either Burns or Pollack point to any single thing, over the past 30 years, including Obama’s welcome mat of the last few months, that gives us any hope that history won’t repeat itself, and that diplomacy has ever gone anywhere.

### Scientific Advocate (SA)
Claim: Thank you very much. Thank you for your question. I just fundamentally disagree with Liz and Dan, that there’s been diplomacy, over the last 30 years, I am a professional diplomat, I now teach diplomacy, at a university. It hasn’t been diplomacy. We have not had sustained engagement with the Iranians. And the problem I have and what I find slightly irresponsible about the other side’s position, they wanna strangle this current diplomatic initiative of President Barack Obama, in its infancy. It’s about 30 days old. President Obama rolled out most of what he thinks should happen about 30 days ago. I think what you can expect, is that after the June 12th Presidential elections in Iran, you’re gonna see Iran accept negotiations, you’re gonna see Iran at the negotiating table. My best judgment would be that first round of talks will likely fail. I’m trying to strengthen us, in arguing for this policy, for the sanctions that come, and trying to strengthen us to find a way to deny Iran a nuclear weapons capability. If you start from the presumption that diplomacy is soft, and weak and un- American, and there are some people who believe that, then I can’t help you. Because that—that you’re just left with a military option. I think we’ve gotta stage this, we’ve gotta think 15 or 16 moves down the chess board. I think that’s what President Obama is trying to do, give him a chance, and let’s show a little patience for diplomacy to play out.

### Conspiracy Advocate (CA)
Claim: Neither Dan nor I are trying to strangle these efforts, in fact we are very hopeful that these efforts will succeed, I think everybody on this panel wants diplomacy to succeed in stopping Iranians’ nuclear weapons program. But I think that you have got to be realistic about what it will take to have that success. And when I hear Nick talk about 15 or 16 moves down the table and the first round is gonna fail, people need to look at how the Iranians in the past have described these discussions with us. In August of 2005, the chief Iranian nuclear negotiator gave an interview on Iranian television in which he explained in great detail and with great pride, that he was using the negotiations in order to gain the time that they needed to get the nuclear program up and running. He admitted it, he was open about it. The notion that, we’ve got 15 or 16 moves and we’ve got all kinds of time, I mean, I’d like to hear Nick explain how he can feel comfortable that we’ve got the time to undertake the kind of slow and cautious, toothless diplomacy, that we’re currently engaged in.

### Scientific Advocate (SA)
Claim: I just wanna correct the record in one—

### Moderator
Claim: Did—did he really say toothless at point—

### Conspiracy Advocate (CA)
Claim: No, I said—

### Scientific Advocate (SA)
Claim: I want to correct the record in one aspect, when Ahmadinejad was elected and sworn in in August of 2005 and when the Iranian negotiator made those remarks, he was not referring to negotiations with the United States, we were not in negotiations. The British and French and Germans were. The Russians and Chinese were in it. The diplomacy has evolved, so to suggest somehow, that because of the European negotiations failed in 2005, the United States should therefore not enter negotiations, is just not historically right. In the way that, in the way that Liz put it—

### Conspiracy Advocate (CA)
Claim: No. What I’m suggest—

### Scientific Advocate (SA)
Claim: And I think that anyone who—I’m just gonna finish my thought if I could. I think that anybody— I think that anybody who understands diplomacy and tries to learn from it understands that it doesn’t occur over a 30, or 40-day time period and here’s the weakness, in Liz and Dan’s argument. They’re arguing against something that has just begun. And we’ve gotta have the patience and determination to see this first phase concluded, or else, or else we leave ourselves with no appreciable option to resolve this peacefully if that’s possible.

### Moderator
Claim: Dan, very briefly—

### Conspiracy Advocate (CA)
Claim: We’re not—wait, I just need—

### Moderator
Claim: I wanna go to—back to the audience but Dan, very briefly respond to that.

### Conspiracy Advocate (CA)
Claim: I will give my time—

### Moderator
Claim: You will cede your time—

### Conspiracy Advocate (CA)
Claim: —to my partner here—

### Moderator
Claim: —to your partner. That was a very wise move—

### Conspiracy Advocate (CA)
Claim: I, you know…

### Conspiracy Advocate (CA)
Claim: To say diplomacy has not begun ignores the 30 years of history. And the point that I was making about the Iranian nuclear negotiator was, the Iranians used negotiations to stall, they used negotiations to buy time. So, Nick, are you saying you don’t believe that they’ll use negotiations to buy time if we’re at the table?

### Scientific Advocate (SA)
Claim: No, I assumed you listened respectfully when I was speaking as I did when you were. I said— I said, we should be tough-minded. We should impose a time limit on the discussions. We should work out the sanctions regime with the Russians and Chinese before we sit down with the Iranians, and we should leave force on the table. That’s tough-minded diplomacy, it’s certainly not toothless—

### Conspiracy Advocate (CA)
Claim: That’s not the current—

### Moderator
Claim: Question from the cen—

### Conspiracy Advocate (CA)
Claim: —that’s not the current diplomacy—

### Moderator
Claim: Question from the center, please.

### Moderator
Claim: Thank you very much for an incredibly interesting panel and very illuminating comments…I think you’re offering very compelling arguments for both sides and I’m actually undecided at this point. To help me decide, it would be really great to know what both sides of the panel think in terms of, who exactly are the key allies we wanna sign up for the tough sanctions against Iran. And what exactly are the tough sanctions, because, I have—I’m just wondering if both sides agree on what exactly both of those are. Thanks.

### Moderator
Claim: Nick.

### Scientific Advocate (SA)
Claim: That’s an excellent question and I think the tough allies that we need are not the Europeans. The Europeans have actually cut their trade with Iran by two thirds since 2005, they’re moving in the right direction. What has happened to us. The Chinese have fundamentally watered down and violated the UN sanctions, they’re the number-one trade partner with Iran. The Russians sell arms to Iran. The Arabs, who profess to be very concerned about the rise of Iran, trade with Iran every day. Specifically Saudi Arabia and the United Arab Emirates, the Japanese and the South Koreans trade. So what President Obama has to do, and what we tried very hard to do in our time in office, was to get all those countries to agree, that if the United States tries diplomacy it’s not gonna be feckless and toothless, that they will join us, they will commit to us. We did not have that agreement, in 2006, specifically, we should try to get it now.

### Moderator
Claim: Question from the far side?

### Moderator
Claim: I have two questions, my first question is, isn’t it a little bit—

### Moderator
Claim: I’d just like you to actually pick your favorite question.

### Moderator
Claim: Okay, my favorite question— They go hand in hand but it’s okay. It’s directed toward Miss Cheney. Isn’t it a little bit convenient to place a historical context—historically contextualize your argument just to 1979, being that the United States helped to overthrow Iran and Iran’s first democratically elected government in 1953? That’s not something that happened 200 years ago, it’s something that happened in my grandfather and my mother’s lifetime so it’s pretty, I would imagine for people living in Iran it’s still a pretty salient point.

### Conspiracy Advocate (CA)
Claim: Well, I think the reason that you start in 1979 is because it’s the same government, it’s the government that took over after the revolution in 1979, and the people that we’re dealing with today are the heirs of the people that we were dealing with in 1979. Now, there has been in many instances and we talked about it, you know, sort of this elusive attempt to find reformers, and I think a lot of what Ken did for example, during the Clinton administration was, attempt to reach out to those reformers. You know, people talk about who’s up and who’s down, but at the end of the day I think what you’ve got is clearly a situation where, the government we’re dealing with today, in terms of its ideology, its objectives, its desires and its approach to the rest of the world and its approach to us, are in fact, you know, they—they’re the Islamic government of Iran, they’re the inheritors of those that we were dealing with in ’79, which is why, I began in ’79, I mean you could go back thousands of years presumably as well.

### Conspiracy Advocate (CA)
Claim: Can I just—

### Moderator
Claim: Okay, your partner would like to add to that—

### Conspiracy Advocate (CA)
Claim: Yeah, I would just like to clarify one point ‘cause there’s clearly…and—

### Moderator
Claim: Is this in relation to the question or—

### Conspiracy Advocate (CA)
Claim: It’s connected—

### Moderator
Claim: —looking back, okay—

### Conspiracy Advocate (CA)
Claim: It’s connected—

### Moderator
Claim: No, I don’t mind, I just—

### Conspiracy Advocate (CA)
Claim: Yeah—

### Moderator
Claim: —wanna know, what the framework is—

### Conspiracy Advocate (CA)
Claim: Nick and Ken keep setting up this false choice. Either diplomacy, or military action. And what Liz and I are arguing, is we are all for diplomacy. We are for diplomacy that actually results in a diplomatic process beginning. The process has not begun. We are—and we believe that that diplomatic process will only get going, if it is backed up by credible threat of military action, we are not arguing for military action. But we are—we do believe that the Obama administration has to persuade our allies—

### Moderator
Claim: But I—I believe I’ve heard the other side say exactly the same thing—

### Conspiracy Advocate (CA)
Claim: But,—

### Conspiracy Advocate (CA)
Claim: Right—

### Conspiracy Advocate (CA)
Claim: —but hold on— But, can I—

### Conspiracy Advocate (CA)
Claim: That’s right, all four of us are arguing for the motion—

### Conspiracy Advocate (CA)
Claim: Exactly, President Obama— President Obama’s strategy does not involve that, so if Nick and Ken wanna come to our side and acknowledge that that is the problem. President Obama has not made clear that military action is serious and credible—

### Moderator
Claim: All right, let me bring in Ken—let me bring in Ken, Nick, ‘cause—

### Scientific Advocate (SA)
Claim: Okay—

### Moderator
Claim: —he hasn’t spoken in a bit—

### Scientific Advocate (SA)
Claim: I think— I was thrilled to hear Liz say that you guys are in favor, you want diplomacy to work. The question I would have for you is, what is it about what we’re doing now that you think is inadequate, what more do you want to do. ‘Cause my guess is not only would we sign up for it, my guess is the Obama administration would sign up for it too.

### Conspiracy Advocate (CA)
Claim: I don’t know if the Obama administration’s gonna be inviting the Cheney-Senor team into… to prescribe their policy on Iran, but hey, you know, stranger things have happened—

### Scientific Advocate (SA)
Claim: for you.

### Conspiracy Advocate (CA)
Claim: You know? Change is coming to America.

### Moderator
Claim: It’s the Middle East.

### Conspiracy Advocate (CA)
Claim: Sorry.

### Moderator
Claim: Nick. Nick, did you wanna follow up ‘cause I have another question or I can go to—

### Scientific Advocate (SA)
Claim: I think that Dan has not given President Obama sufficient credit. I heard him say during the campaign on multiple occasions, that he believed that we should leave the use of force on the table. We haven’t seen the full articulation of the policy. I have every reason to believe it’s gonna be very hard- headed and very tough-minded, it’ll include all the things that all of us are talking about. So to suggest that somehow this is feckless, toothless, soft, ineffective diplomacy, when it’s likely to include all the elements that Liz and Dan have suggested, I think is a little bit premature.

### Conspiracy Advocate (CA)
Claim: I don’t disagree, I hope President Obama comes forth with that, he hasn’t done so yet, my only point is if you are going to have a credible use—if you’re gonna have a credible threat of force, you have to articulate a timeline, a trigger point, and a credible threat of force. President Obama has done all the things that you have, have hoped he would do, except that last piece, so I don’t know why anybody in the Iranian regime, or among our allies, would take that threat that you’re positing as serious when the President himself has not taken it—

### Moderator
Claim: Nick, last year during the campaign you wrote in support of the President’s offer to talk to adversaries. You wrote a piece in Newsweek in which you said, “We should have enough self- confidence to talk to your adversaries,” why is it a matter of self- confidence.

### Scientific Advocate (SA)
Claim: There is this notion, in some parts of the political spectrum that we should not talk to governments with which we disagree. I don’t think that is in our self-interest. And I think we oughta have the self-confidence to understand that whoever represents the United States of America at the negotiating table is going to be tough- minded. Is going to try to achieve—

### Moderator
Claim: But you’re not hearing that argument from this other side of the table today, that’s not the—

### Scientific Advocate (SA)
Claim: Not today. But certainly I think one of the weaknesses of the Clinton approach and frankly, the approach in which I was involved, was that we didn’t have enough self-confidence to get to the table and trust ourselves, I think we weakened the diplomatic effort in 2006, by not attempting to talk to the Iranians, so I think the United States needs to engage those governments with, with which we disagree, Zimbabwe,—

### Moderator
Claim: Liz—

### Scientific Advocate (SA)
Claim: And Iran, and Burma, governments like that.

### Moderator
Claim: Liz Cheney.

### Conspiracy Advocate (CA)
Claim: How much time do you give the Iranians. How much time would you give the Iranians. So we’ve gotta have this tough-minded diplomacy that you promise is coming, although I have to say the resolution says it’s going nowhere now, just to remind people in the audience. But how much time. I mean I understand what you’re saying…

### Scientific Advocate (SA)
Claim: I don’t see the word “now.”

### Conspiracy Advocate (CA)
Claim: It says “is going nowhere,” it’s present tense. But at any rate, um… But it’s, it’s a serious question—

### Scientific Advocate (SA)
Claim: You could read the future tense into that—

### Conspiracy Advocate (CA)
Claim: It’s a—no you can’t actually—

### Scientific Advocate (SA)
Claim: Of course you can.

### Scientific Advocate (SA)
Claim: Liz, if you can—

### Conspiracy Advocate (CA)
Claim: It’s a serious question—

### Scientific Advocate (SA)
Claim: —if you’re in favor of diplomacy too let us throw it back to you, how much time would you give it.

### Conspiracy Advocate (CA)
Claim: I would give it very little time.

### Scientific Advocate (SA)
Claim: How much—

### Scientific Advocate (SA)
Claim: How much?

### Conspiracy Advocate (CA)
Claim: And I would say— I would give it basically enough time that we could actually sort of test out, the extent to which we’re serious about using force, I mean I, you know, my own view is the window is closing pretty fast here. I would say, you know, we’re very close to the point where, the Iranians themselves may in fact be near the point where any action that we take is insufficient to prevent them from actually gaining the value and the benefit of having at least the threat of a nuclear program—

### Scientific Advocate (SA)
Claim: So is that six months or 12 or 18?

### Conspiracy Advocate (CA)
Claim: You know, I’d say I’m—

### Moderator
Claim: But the—but the question—

### Conspiracy Advocate (CA)
Claim: I’m closer—

### Moderator
Claim: —was actually put to you—

### Scientific Advocate (SA)
Claim: I know, that’s why I’m putting it back to Liz ‘cause she’s saying—

### Moderator
Claim: But, but—

### Scientific Advocate (SA)
Claim: —she’s in favor too—

### Moderator
Claim: But do you—but do you—

### Scientific Advocate (SA)
Claim: Maybe—

### Moderator
Claim: —have an answer for her—

### Scientific Advocate (SA)
Claim: John, maybe the problem is just three months, maybe Liz believes six and we believe nine.

### Conspiracy Advocate (CA)
Claim: No, no, but it’s not just time, it—time as you heard me say at the beginning, time is key. Now I— my patience has, as you know, been tested and I think probably is closer to the breaking point than Nick’s is. And I think that’s a responsible position. Because I think to take the position that you guys are taking which is, yes, it’s definitely going somewhere, although it hasn’t really started yet, and once it starts, it’s gonna take us a long time because, you know, to do this professionally—

### Scientific Advocate (SA)
Claim: That’s not our position at all, Liz, our position is that—

### Conspiracy Advocate (CA)
Claim: You’ve said all of those things—

### Scientific Advocate (SA)
Claim: Our—no, no, no, that’s absolutely untrue, and you go back and look at the transcript—

### Conspiracy Advocate (CA)
Claim: All right, but Nick said—

### Scientific Advocate (SA)
Claim: What we said was—

### Moderator
Claim: Okay, we’re getting to transcript review—

### Scientific Advocate (SA)
Claim: —what, what, that—

### Moderator
Claim: —I wanna move on to another question—

### Scientific Advocate (SA)
Claim: —we need to pull this out to get the allies onboard—

### Moderator
Claim: Gentleman in the second row—

### Scientific Advocate (SA)
Claim: —for the tough sanctions—

### Moderator
Claim: Gent—gentleman—

### Conspiracy Advocate (CA)
Claim: What makes you think—

### Moderator
Claim: —in the second row has been very patient—

### Conspiracy Advocate (CA)
Claim: But what makes you think—

### Moderator
Claim: If a game-changer is required, and it seems to be, would Russia support effective sanctions if we rethought our position on missiles in eastern Europe, and are there similar quid pro quos we could offer the Chinese for them to support effective sanctions, and would that not change the whole situation.

### Moderator
Claim: Ken? That’s up your alley.

### Scientific Advocate (SA)
Claim: Okay, you’ve asked a critical question, and this is part of what has to happen with the diplomacy. We don’t know the answers to those questions. But frankly, if we can make some of those deals, if we can do some old-fashioned horse trading, and different people may have different views on what deals we should cut, but if we can do that to get them onboard, maybe we will. I think we probably ought to. But we’re never going to know until we suss them out. Until we go to them and ask them what’s it gonna take.

### Conspiracy Advocate (CA)
Claim: situation, we have to remember this, we’re in a situation where we have offered, not just to talk. You know, we offered to remove our objection to their WTO accession, we gave ‘em spare parts, we lifted pieces of our sanctions. You know, we’ve offered a whole range of things to them. And so for us to now be in a position where we’re going again to the Iranians and you know, to say to them, okay, well that didn’t work but how about if we do this for you, how about if we do this for you— Each time, the Iranians refuse to take the steps that the international community has said they should take. Nick and Ken seem to think we oughta go back to them again and say okay, well that wasn’t enough for you, what about this. And I just think that’s a dangerous situation to be in when they are getting closer every day to having a nuclear weapon.

### Scientific Advocate (SA)
Claim: the question. The question was what do we do with the Russians and Chinese. So we’re not talking about constantly going back to the Iranians. What we’re talking is going for the first time to the Russians and the Chinese.

### Conspiracy Advocate (CA)
Claim: But it is a key point, it—you know, if in response to the Iranian intransigence, we decide that we are no longer gonna support the missile defense system, that in fact has helped to protect and will help to protect some of our most important allies in the world against the eventuality, the potential of an Iranian nuclear weapon, that to me is a concession to the Iranians. Now maybe, you know, it’s a concession we’re making to the Russians, but it’s a concession to the Iranians.

### Scientific Advocate (SA)
Claim: I would not make those concessions right now either, I agree with Liz on this, I mean you’ve asked a great question. The Russians and Chinese should be interested in stopping an Iranian nuclear- weapons development program, because of their own interests. I think what’s happened is they haven’t quite believed that we’re ready to give diplomacy a chance, therefore, if we can show a little faith in diplomacy for a little bit of time, I think we’re more likely to get them onboard than otherwise, but I wouldn’t trade the missile defense systems in eastern Europe with the Russians.

### Moderator
Claim: Question, sir?

### Moderator
Claim: to have been on the hot seat all night—

### Moderator
Claim: Can you start your question again—

### Moderator
Claim: Yes—

### Moderator
Claim: —because your mic was off—

### Moderator
Claim: …so, I’ll keep you there. One of the reasons I’m voting for…that the Iran—or the diplomacy is going nowhere, is something that our ally, Israel, had mentioned a few weeks back, and incidentally, I was at the first debate, and no one mentioned Israel at all and they’re the country that had the most to lose, and they’re our friends. My question is when…Prime Minister Netanyahu said the other day in a very undiplomatic way, that if the United States doesn’t take care of this, we are. Now I thought that was shocking. That indicated, that they think, our diplomacy is sort of 1938 vintage with an umbrella, and a V sign, and it’s going nowhere. So, if Mr. Netanhayu were here tonight, how would you assure him that he can maintain his confidence in the United States.

### Moderator
Claim: Thank you, Nick Burns.

### Scientific Advocate (SA)
Claim: I’m glad you raised the issue, because we do have to talk about Israel here, I think one of the basic problems that the United States should have with Iran, is the threats that Ahmadinejad has made against the Israeli state and the existence of the Israeli people. And it should be a vital national priority, and it is, for the United States to safeguard Israel, and protect it. And that’s one of our key strategic interests here, how do we best do that. I fear that if we, if the Israelis launched airstrikes, or if we did, in the next couple of months, we wouldn’t have ever tested the proposition that maybe diplomacy and sanctions backed up by the use of force could work. And we get ourselves into a position where, we’d have the unintended consequences of war, we found out about that in Iraq. We’d have the ability of Iran to use Hezbollah and Hammas asymmetrically to attack Israel, to attack the moderate Palestinians and American interests. And, I’m not aware of a convincing scenario where the use of force actually works. And so, I would just say very respectfully to Prime Minister Netanyahu and he has a right to raise this issue--he should raise this issue--that the United States should make a commitment to Israel that we will safeguard its security. They should allow President Obama, in my judgment, working very closely with Israel, to take the lead, for as long as we think that this diplomatic path can be successful. There may come a time, when we wanna end diplomacy—

### Moderator
Claim: Dan—

### Scientific Advocate (SA)
Claim: —and go to a tougher option.

### Moderator
Claim: Dan Senor.

### Conspiracy Advocate (CA)
Claim: I would just, I’d put Prime Minister Netanyahu in the same category that I put all of the regional players, or at least many of them. Which they are deeply concerned about the mixed signals we’re getting from this administration. Prime Minister Netanyahu’s saying what he’s saying because he is concerned that the administration is not backing up their diplomatic plan with a credible military threat to solve this problem if it doesn’t go anywhere. That is the same thing that is going on throughout the Persian Gulf and the Arab world, and I take your point, your earlier point, Ken, that it’s very difficult to sort of read exactly what is going on in each one of these Arab societies, but, just the fact that Secretary Gates as Liz said earlier had to travel to Cairo and Riyadh to reassure them, don’t worry, we’re not gonna make this open- ended, and the fact that Dennis Ross has had to bounce around all these capitols to say, don’t misread what we’re try—you know, we’re trying to talk but it’s not gonna— I mean, it gets to a point here where these people are voting, whether it’s Netanyahu or the king of Jordan or the king of Saudi Arabia, or, or the president of Egypt, there is deep concern in the region, and this is a profoundly violent and volatile neighborhood we’re talking about, where wars often start because of misunderstandings and miscommunications and mixed signals, and violent revolutions. And we are dealing with a region right now, which I believe because of the current administration’s lack of clarity about how they intend to back up this diplomatic process, if the Iranians actually ever enter into it, is potential for a very dangerous situation.

### Moderator
Claim: Sir, your question?

### Moderator
Claim: For clarification on what you mean. The arguers against the motion, suggest that speaking with Russia and China would be part of diplomacy. Whereas the arguers for the motion, I don’t think they would—they’re thinking of that kind of diplomacy. As I understand the question, is whether we should negotiate or seek diplomacy, with Iran. Or should just tell Iran to get lost, but, that still reserves the opportunity to talk with Russia and China and try to agree on a sanction. So I’d like you each to define by what you mean by diplomacy, if you’re talking with China and Russia, who do you vote for in this debate.

### Conspiracy Advocate (CA)
Claim: I think we actually, probably all four agree that successful diplomacy cannot be bilateral. Now, I don’t…I probably shouldn’t speak for my opponents here but successful diplomacy has got to include countries like Russia and China who actually have relationships with Iran that they could use, they’ve got leverage with Iran that they could use were they to choose to use it. I think the difference between us, there are two differences between us, one is, I would say, you know, all right, let’s accept for the sake of argument that we can work with Russia and China to try to put tough sanctions in place against the Iranians. There’s no evidence right now that there’s any intent on the part of either Russia or China, to put tough sanctions in place against the Iranians, that piece of this diplomacy is going nowhere. And, I think the second difference is, you know, this question of how much hope do you hold out, after years and years and years, and, you know, Lavrov said to us, you know, within the last six weeks, I don’t wanna have tougher sanctions on the Iranians, I mean we ran into this problem consistently. At the end of the day, the only thing that will get the Russians and the Chinese and some of the other, some of the Europeans onboard with this is if they believe, if they don’t sign up for crippling sanctions the United States will use force. And right now they don’t believe that.

### Moderator
Claim: Ken Pollack.

### Scientific Advocate (SA)
Claim: You may have all noticed, we’re kind of competitive people, all of us, up here on this panel. And we’re actually all friends too. Please don’t let the competitiveness drown that out. And I wanna ask this question, not to score debating points, ‘cause I think that there is something really interesting going on here and I’ve just been kind of reflecting on it. And this question really kind of brought it to the fore for me and it goes back to the question I raised before but— I wanna put it in a neutral fashion, I don’t want it to be a debating point. But I do wanna ask this question, because you know, although I am the only Democrat on the panel, I am not speaking for the Obama administration. And as Dan and Liz and I know, I am very glad to disagree with my own party, very publicly, whenever I think it’s necessary. But the question I would like to ask is, what is it that you feel we’re not doing that we should be doing. That would make—‘cause again, I think I’d probably sign up for it, and I just—I wanna hear it.

### Moderator
Claim: Dan, I can give you 20 seconds—

### Conspiracy Advocate (CA)
Claim: 20 seconds—

### Moderator
Claim: —to answer that question—

### Conspiracy Advocate (CA)
Claim: —okay, I’ll be real quick, but I do wanna commend Ken for taking on his own party from time to time which he’s done on some pretty big issues so I—

### Moderator
Claim: That was a waste of four seconds—

### Conspiracy Advocate (CA)
Claim: Second—I know. With my— with the balance of my 16, I will say, if you believe there is a discussion going on right now within the Iranian government between confrontationalists, those who believe that we just need to plow—or the Iranians need to plow ahead and build their nuclear bomb and be quite confrontational, and those that are reformers that believe that, we can cut a deal, the Iranians can cut a deal with the west…we clearly wanna strengthen their hand. And what better way to strengthen their hand than when they’re going into those discussions with the hard- liners than to say, if we don’t act now, while employment is 25 to 30 percent, while our economy’s falling apart, 70 percent of the population is under 30 years old, we could have a revolt here… If the Americans move forward with truly crippling economic sanctions, or potentially military force, this regime will collapse and we will have a total mess on our hands. That is the kind of leverage we wanna give the reformers in their internal debates with the hard-liners. To say the Americans are lea—left this thing open- ended, they’re having a discussion, we haven’t even returned their phone calls, this is great, the hard-liners aren’t gonna be terribly persuaded that they should, they should be responsive.

## Round 3

### Moderator
Claim: That concludes round two of our debate. So we’re now in the final stretch and soon you in the audience will be choosing the winner, recall that, at the start of the debate we asked you whether you took sides with or against this motion, “Diplomacy with Iran is going nowhere.” Before the debate, it was an even split among the choices, 34 percent of you are for the motion, 33 percent are against, and 33 percent are undecided. And soon we will have you vote one last time, but we are going to go now to our third and final round, each debater is given a brief amount of time, two minutes each, to make a closing statement… And we will begin against the motion, Ambassador Nicholas Burns, former Under- Secretary of State for Political Affairs.

### Scientific Advocate (SA)
Claim: Thank you, this has been a terrific debate, and I’ve enjoyed it very much, I like where Dan left off. The way to get serious draconian sanctions, the only way in my experience and my judgment, is to continue this diplomatic process. Is not to give up on it. Is to bring the Russians and Chinese and Japanese and Arab countries in, the major trading partners, and to convince them to go along with us. I think we face a real threat in Iran. And we should be very tough-minded and very serious in facing it as Americans. And we should not leave military force out of this. We should leave that on the table. We should have a threat of sanctions hanging over the Iranians’ heads. But if we give up now, I’m afraid we’ll never know the answer to the question, was peace possible. Did we have the patience and ingenuity and the courage to believe in ourselves, to believe in our ability to be successful at the—at the diplomatic table.

I think we should lead with diplomacy, with the military in reverse. I’m afraid that if we agree with Liz and Dan’s position, we’re really leading with the military, and we’re forsaking diplomacy. President Obama has just begun his administration. He’s just begun this diplomatic process, which is gonna be quite complex, it’s not gonna go on forever. He needs to be given time, and we need to have the patience as citizens, to let diplomacy play itself out, not forever. But for—and I think everybody can agree on this. For several months’ time, to test the proposition, that we might find peace, and not find war, I think frankly, that if we just tried war now, and gave up on diplomacy, and either emboldened the Israelis to strike, or struck ourselves, which is the logical conclusion of this position of our opponents, I think it would be unconscionable of us, to go to war, to start a third war, without having given diplomacy a chance. That’s our position, I hope you’ll agree with it.

### Moderator
Claim: Thank you, Nick Burns, and summarizing for the motion, “Diplomacy with Iran is going nowhere,” Liz Cheney, former State Department official overseeing Mideast policy.

### Conspiracy Advocate (CA)
Claim: I would venture a guess that I’m somewhere to the right of many people in the audience tonight with one or two notable exceptions. But you don’t have to be as hawkish as I am on this issue to realize that our current diplomatic track with Iran is in fact going nowhere. You really only have to agree with the testimony that Nick gave before the Senate Foreign Relations Committee last week. In his testimony Nick very helpfully laid out steps that the Obama administration must take in order for diplomacy to go somewhere.

He said, force must be on the table, President Obama needs to prevail upon Iran to freeze its nuclear research as the talks proceed so Iran does not steam ahead unimpeded. President Obama should set a timetable, and finally Nick said, excuse me, that it’ll be crucial that the President agree on the automaticity of sanctions with the P-5 countries, especially Russia and China in advance of the talks. Now I think we probably disagree on whether these steps alone are tough enough to convince the Iranians to give up their weapons. But it is indisputable, that any of these steps are part of our current diplomacy. Therefore, as we debate the issue tonight and as you cast you vote, I would say don’t be swayed by Nick’s division of, you know, vote for them and you’re voting for war and vote for us and you’re voting for peace. What we’re arguing is that the current diplomacy is ineffective, is going nowhere, because, by Nick’s own definition, it does not include the steps that it needs to include to make diplomacy effective. Thank you.

### Moderator
Claim: Thank you, Liz Cheney. And, summarizing against the motion, that “Diplomacy with Iran is going nowhere,” Kenneth Pollack, Senior Fellow and Director of Research at the Saban Center for Middle East Policy at the Brookings Institution.

### Scientific Advocate (SA)
Claim: I think there are two interesting things that are going on right here, in some ways we’re having two separate debates. On the one hand, I’m really heartened by what we’ve all agreed to over the course of the last hour and a half. I’m really struck by the fact that we all do believe that tough-minded diplomacy really is what this is all about. And, Liz, while it may be useful in trying to win this debate, I would suggest to you that I—you and I both know Nick pretty well, he’s not contradicting what he said before the Senate. He still believes it, he hasn’t changed his mind over the weekend.

And what we’re saying is effectively the same thing. And so on the one hand, I think that the differences between us may be a matter of semantics, as I suggested it might be a matter of months. And I think that’s actually really remarkable. And it’s something worth taking away from this. Is that we all are pretty close on this, and what we’re defining as what the right policy is is actually pretty close. At another level though of course, the question as opposed I think raises a very different set of propositions in people’s minds.

And that’s what Nick was trying to get at just a minute ago and I think that it is important to think about. Because while I think that Liz and Dan have been very good about saying, look, we’re not talking about going to war, rushing to war or jumping right into these things, and we want to give diplomacy a chance, it’s just, doing some things differently and, we would come back and say, you know, look, the Obama people have just started, it’s not clear that these things aren’t part of what they’re doing, in fact there’s a lot of evidence to suggest it will be, I mean let’s remember, Hillary Clinton did talk about crippling sanctions against Iran, which was a very important point. But at the end of the day there are a lot of other people out there who aren’t on this panel, who will say, look at that sentence and say, you’re right, time to go to war. Or time to go to regime change, or something else. And I think that’s what we have to be concerned with. And those people don’t seem to be represented on this panel. And as far as I’m concerned on the wider debate, the one that isn’t gonna be scored tonight in the US public, that’s the debate that we really have to focus on. Because diplomacy is the right way to handle things, it is the right way to start. If we don’t start there, we’re never gonna end up anywhere that we wanna be.

### Moderator
Claim: Thank you, Ken Pollack. And, finally summarizing for the motion, “Diplomacy with Iran is going nowhere,” Dan Senor, Senior Fellow at the Council on Foreign Relations.

### Conspiracy Advocate (CA)
Claim: I would just close with a couple of quick points. One is a quote that I’ll read that characterized the Iranian leadership in March of 2007. “President Achmadinejad is reckless, he’s irresponsible, and he’s inattentive to the daily needs of the Iranian people.” That was not Liz Cheney, that was not Dan Senor, that was then-Senator Obama, in a speech in Chicago, on March 2nd of 2007. That characterization is probably accurate, and is probably consistent with the history that Liz laid out in her opening.

We don’t know exactly what will push the buttons of the Iranian people, none of us truly know what will push the buttons of the Iranian regime. It is such an opaque society, I went through this with Iraq when there were many experts on all sides of the ideological spectrum who had very strong views about how the Shiites would respond to this and the Sunnis would respond to this and the Kurds would— And, you know, some of them, all of them were— sometimes all of them were wrong and sometimes all of them were right, and as Nick said earlier, when you’re dealing with a society, for three decades we’ve had no communication, no interactions, it is very hard to know what’s going on inside. So all we have to base this debate on is the history that we’re aware of, which Liz went through in her opening statement. The actual public statements of the leadership of the country which should count for something, and the rhetoric they have used with regard to Israel and the United States and the west is apocalyptic.

And thirdly, their capabilities. The capability that they are trying to develop, right now, in defiance of UN Security Council resolutions, and in defiance of our effort to reach out to them. That is a dangerous, toxic combination. Their history of non-negotiation and stalling, combined with the public statements about what they would do, the genocidal rhetoric they, they articulate, that, they say they would use genocidal weapons for, and finally, the capability that they are trying to pursue. So—

### Moderator
Claim: Dan Senor, I’m sorry, your time is up.

### Conspiracy Advocate (CA)
Claim: A dip—

### Moderator
Claim: I’ll give you 10 more seconds—

### Conspiracy Advocate (CA)
Claim: A diplomatic process is fine, as long as we are clear and we can make clear to the Iranians, where it ends, and how strongly we back up the alternative course in our negotiations.

### Moderator
Claim: And that concludes round three of our debate, we will now have you pick our winner, recall that at the beginning of the debate, we were more evenly split than we have ever been at any of our debate series, 34 percent of you are for the motion coming in, 33 percent again, and 33 percent undecided, if you pick up your keypads, they are live now. Vote 1 if you are for the motion, 2 if at this point you are against, and 3 if you remain undecided. So…we’re locking that out, and we are now just a couple of minutes away from declaring the winner, a couple of things we wanna make announcements about, given that this is the end of our third season, everyone at Intelligence Squared is very grateful to those of you who have continued to show support and enthusiasm for these debates.

We also want to extend a warm thank you to the Rockefeller University for the use of this auditorium, Caspary Auditorium, throughout the season. We want you to know that ticket packages and individual tickets for next season, Fall 2009, and Spring 2010 series are on sale now, right now, through our website. The Fall debate dates and topics are these, on Monday September 21st, the topic is “Buy American/Hire American policies will backfire.” On Tuesday, October 6th, “Pakistan, not Afghanistan, is America’s real problem.” Tuesday, October 27th, “Good riddance to mainstream media.” Tried to slip that… Monday, November 16th, “Obama’s economic policies are working effectively”… Tuesday, December 1st, “America is to blame for Mexico’s drug war.” All of our debates will continue to be heard on more than 185 NPR stations across the country. And all five debates will now be covered by the Bloomberg Television network. To accommodate the television production and our growing audience we will be moving next season to a new venue downtown, we will be at the Skirball Center for the Performing Arts at NYU. And now more exciting news… More exciting news. Intelligence Squared US, is very, very pleased to announce, a new partnership, a media partnership with Newsweek magazine and here to help me with that is Newsweek CEO Tom Ascheim. Tom?

### Moderator
Claim: John. I’m here to kill the time while we count the votes. That was really thrilling, thank you all very much, it was great entertainment and I think really a great exemplar of what we are looking forward to in partnering with Intelligence Squared. I’m sorry, I have dastardly allergies so you’re hearing me sound like a frog, I apologize. We are incredibly excited about the opportunity to really embed the content from these debates in both our magazine and our website going forward. They are on issues of incredible importance, not least the future of mainstream media I’d like to point out. When we were first introduced to Intelligence Squared it was very clear that we had an enormous amount in common, perhaps most pertinently that we both love to see a great fight started, and it makes for really good content for all of us. There’s really no better time for us to be having this partnership, Intelligence Squared is expanding, it’s gonna be great to see it downtown. And we are already launching the very fabric that is Newsweek, on Monday the magazine is being reborn in a new form and a new way, I hope you will all check it out as well as the website as well as the brand in general, so, we look forward to a great partnership—

### Moderator
Claim: Tom—

### Moderator
Claim: Bob, thank you very much.

### Moderator
Claim: Tom, thank you.

### Moderator
Claim: Right.

### Moderator
Claim: Thank you, Tom.

### Moderator
Claim: And now to declare the winner, you voted before the debate on whether you agree or disagree with our motion that “Diplomacy with Iran is going nowhere,” you have now voted again and here we go, before the debate, 34 percent of you were for the motion, 33 percent against, 33 percent were undecided, remember when I raise my hand I will need applause. Here are the results, after the debate. 35 percent are for the motion, 59 percent are now against the motion— 6 percent are undecided, congratulations to the side arguing against the motion, and of course to the art of persuasion itself, for me, John Donvan, and Intelligence Squared, thank you.
