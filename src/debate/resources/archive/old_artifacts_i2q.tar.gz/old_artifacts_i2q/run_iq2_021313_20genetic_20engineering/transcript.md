# Debate Transcript

Topic: Prohibit Genetically Engineered Babies
Motion: Prohibit Genetically Engineered Babies

Debate ID: 021313%20genetic%20engineering


## Round 1

### Moderator
Claim: What Robert Rosenkranz really said in this debate, very often we do debates where things divide very clearly, policy issues where it's yes or no, where it's black or white. It was his feeling that this is one debate where the richness of the debate actually comes from the fact that there are an awful lot of shades of gray and shades of meaning in the issue, that black and white and yes or no, even though we're asking you to vote at that level, it's very complicated. And so he was looking forward to this being, in a sense, one of the more complex debates that we were going to have and have ever staged. So with that thought, let's please welcome our debaters to the stage. Thank you. Thank you. And because we're being broadcast for radio and television, there are various points throughout the evening where we like the radio audience in particular to know that you, our live audience, are here. So you can absolutely give voice. This is not like a presidential debate where you're not allowed to applaud. You can give voice to your passions in this. You can laugh, cheer, react however you want to. We just want it to not be mean spirited. We discourage you from hissing, for example. But-- but a chuckle like that is fine. And here and there, again, I'm just going to ask you to applaud entirely spontaneously, but it has to be when I ask you. work for the radio broadcast. And when I introduce, in a moment, each of our debaters, the first time I mention their name, I'll do a little of this, and that means, please welcome these-- these debaters with a round of applause. But let's just begin the whole thing, please. Welcome them to the stage one more time. So most of us would do almost anything for our kids to help them be their best, to help them get ahead. But what if even before they were born we could go in and alter their genes in such a way to give them an even greater advantage, to give them strength against illness and disease, to make them smarter or taller or prettier even if their parents themselves never had any of those traits. Well, that world is coming. Who's tempted? And who is horrified? Let's find out.

Yes or no to this statement: Prohibit genetically engineered babies. A debate from Intelligence Squared U.S. I'm John Donvan. I will be moderating as the four superbly qualified debaters you see on the stage argue for and against this motion, two against two: prohibit genetically engineered babies. As always, our debate goes in three rounds. And then the audience votes to choose a winner, and only one side wins. Let's meet our debaters. Arguing for the motion, prohibit genetically engineered babies, Sheldon Krimsky, a professor at Tufts University and chair of the Council for Responsible Genomics His partner is Robert Winston, a professor of science and society and emeritus professor of fertility studies at Imperial College, London. team arguing against the motion, they are arguing against the prohibition of genetically engineered babies, include Nita Farahany. She is a professor at Duke Law and research professor at Duke's Institute for Genome Sciences and Policy. Oh, okay. I just got a note in my ear, Sheldon, that I misnamed your institute, your council, so I'm going to--

### Moderator
Claim: Yeah, yeah, so I'm going to just say it out loud, and then we'll fix it in post. Actually it'll work, and then I'm going to come back to you later. I know you're all set to take your bow. Just hold that thought, and I'm going to introduce Sheldon again. And if you could applaud again, we'll fix it in the edit. So, Sheldon Krimsky, a professor at Tufts University and chair of the Council for Responsible Genetics. to anybody-- you know, we're fine with breaking the fourth wall. If I misspeak ever, just correct me right then and there. It's not a problem. And Nita Farahany's partner, her partner is Lee Silver, professor of molecular biology at Princeton University and author of the book "Challenging Nature." Our motion is, "Prohibit genetically engineered babies." Let's meet the team arguing for the motion. First, let's welcome Sheldon Krimsky. And, Sheldon, you are a professor at Tufts University and chair of the Council for Responsible Genetics. Your research has focused on the intersection of science, ethics, and public policy. Your very first book in this area was published in 1982. It was a social history of what was then considered a very, very controversial new technology, "gene splicing," 30 years ago, which could lead to the mistake that you are a geneticist, but actually you are a philosopher.

### Conspiracy Advocate (CA)
Claim: A philosopher of science, and I deal with the issues of ethics and also contested issues in science, and, of course, genetics provides great material.

### Moderator
Claim: And natural science came out of philosophy, so there remains a connection between these two?

### Conspiracy Advocate (CA)
Claim: Absolutely.

### Moderator
Claim: Okay, and your partner is?

### Conspiracy Advocate (CA)
Claim: My partner is Professor Robert Winston.

### Moderator
Claim: Ladies and gentlemen, Robert Winston. Robert, you are a professor of science and society at Imperial College, London-- who not only did groundbreaking work in fertility studies but also in the field of prenatal implantation, genetic diagnosis. However, renaissance man, you have also very often been a TV host. You are an award winning theater director, and very recently you were the star of a reality television show in which you learned to play the saxophone-- set out to play the saxophone. So if we brought a sax out right now, you could blow a few notes for us?

### Conspiracy Advocate (CA)
Claim: I would prefer the clarinet, I think.

### Moderator
Claim: Clarinet. Well, then we're just going to have to cancel that whole plan. Ladies and gentlemen, the team arguing for the motion. And, again, our motion is "Prohibit genetically engineered babies." The two debaters arguing against it, let's welcome, ladies and gentlemen, Nita Farahany. Nita, you are a professor at Duke Law and you are a research professor at Duke's Institute for Genome Sciences and policy, so you are trained both in science and as a lawyer, but in 2010 President Obama pointed you to the Commission on the Study of Bioethical Issues, and you're still a member. So now that you've done science and you've done law, how are you liking politics?

### Scientific Advocate (SA)
Claim: I think I'll be politic and not answer that.

### Moderator
Claim: So you have debated before.

### Scientific Advocate (SA)
Claim: Yeah, indeed.

### Moderator
Claim: Ladies and gentlemen, Nita Farahany. Nita, your partner is?

### Scientific Advocate (SA)
Claim: My partner is Lee Silver.

### Moderator
Claim: Lee Silver, ladies and gentlemen. Lee, you are also arguing against this motion to prohibit genetically engineered babies. You are a professor of molecular biology at Princeton. One of your landmark books was called "Mouse Genetics." It's a book about mouse genetics. And those are relevant because mice and humans share an astounding number of genes. It's a very high percentage, is it not?

### Scientific Advocate (SA)
Claim: I look at mice as little people.

### Moderator
Claim: Yeah? So you're not-- the thought doesn't turn you off and depress you that--

### Scientific Advocate (SA)
Claim: Oh, no, no, no. Mice have done a lot for human health.

### Moderator
Claim: All right, ladies and gentlemen, Lee Silver. those are our four debaters. So let's get to the first round of voting. Remember, you will be asked to vote twice by the time the debate has ended, once before you've heard the arguments and once again after you've heard the arguments. And the team whose numbers have moved the most will be declared our winner. The motion is "prohibit genetically engineered babies." If you agree with the motion, push number 1, if you disagree, push number 2, and if you are uncertain, push number 3. You can ignore all of the other keys, they're not live; and if you push the wrong key just correct yourself and the system will lock in your last vote. And we'll shut this out in about 10 seconds. And so remember how you voted; we'll have you vote again after the three rounds of debate. And in that case, the team that has changed the most minds will be declared our winner.

Onto Round 1: opening statements from each debater in turn. They will be seven minutes each. Our motion is "prohibit genetically engineered babies," and here to argue first for the motion, Sheldon Krimsky, professor of humanities and social sciences at Tufts University. He is chair of the board of directors for the Council for Responsible Genetics and coeditor of the book "Genetic Explanations: Sense and Nonsense." Ladies and gentlemen, Sheldon Krimsky.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you very much. The proposition before us today, to me means prenatal genetic modification of human reproductive cells, like sperm or eggs or fertilized eggs, called the zygote, in preparation for gestation in the womb and development to full term infants should be prohibited at the societal level, and to this I agree firmly.

The two basic reasons to carry out such an intervention: one, for curing or preventing genetic disease; or, two, for the enhancement of a person. For genetic diseases, in the great majority of cases there are simpler, less risky, less costly, less ethically controversial, and more dependable methods of preventing the birth of a child with a severe genetic abnormality by using prenatal embryo diagnosis; that is, for diagnosing the embryos. There are a couple of exceptions, which I think we will get to during this debate, such as mitochondrial disease. And we'll have more to say about that later. Other than the exception, the only sensible rationale for engaging in genetic modification of the fertilized egg is for the enhancement of a child. Enhancement might include intelligence, resistance to disease, greater height, muscle strength, appealing personality, longevity, any number of things you could imagine.

Now, engaging in genetic modification of human gametes, the human reproductive cells, for enhancement is where I find the greatest moral failure and the greatest scientific folly. I offer three reasons: first, whatever enhancement is sought, the only method for determining whether it would work would be to engage in a clinical trial where you would have dozens of fertilized eggs or embryos, genetically modify half of them, carry them all to term, follow the development of the children throughout their lives to determine whether the intervention worked and at what expense to their health. No set of animal studies can ensure the safety and efficacy of human prenatal genetic modification. It is unimaginable that any humane, democratic society would permit such a trial with public or private funds; the risk would so outweigh the societal benefits.

My distinguished colleague, professor Winston, will address some of the risks, complexities, and uncertainties with procedures using a genetic scalpel in the early embryo. Of course, the genetic modification of a single fertilized egg can be done outside of civil society, at some island community, where evidence of success, risks, and knowledge gained are of no concern. So that certainly can always happen. This takes us to the second reason that babies should not be genetically engineered for enhancement: from a biological and developmental standpoint, the so-called traits under consideration cannot remotely be enhanced by the modification of a gene or two.

Traits like intelligence, personality, muscle tone, musicianship and-- are complex and not only involve dozens if not hundreds of genes but are the result of nutrition, social and environmental factors, genetic switches that are outside of the DNA and the gene- gene interactions that occur in human cells. Scientists and the so-called trans- humanists who believe that it is possible think of the human genome as a Lego set, where pieces of DNA can be plugged in or out without interfering with the other parts of the system. Actually, the human genome is more like an ecosystem where all the parts interrelate and are in mutual balance.

Even for height, one of the most heritable traits known, scientists have found at least 50 genes that can account for only 2 to 3 percent of the variance of the samples. So there could be hundreds of genes associated with height. If you want a child, a tall child, marry tall. Finally, the idea of genetic enhancement grows out of a eugenic ideology that human perfection can be directed by genetics. The danger is not so much that it will work, but as a myth, it will have social power that can be used by those who have wealth and resources to make others believe that to be prenatally genetically modified makes you better.

It would be as much a myth as believing that the sperm of a Nobel laureate will give you a genius child. I am all for human enhancement, but it must start after an egg is fertilized, beginning in utero by protecting the fetus from toxic chemicals and continuing postnatally through environmental, nutritional and cognitive enhancement and moral education. Enhancement through genetic engineering of human germ plasm is a fool's paradise and will lead to no good. Thank you.

### Moderator
Claim: Thank you, Sheldon Krimsky. Our motion is, "Prohibit genetically engineered babies." And here to argue against this motion, Nita Farahany. She holds a joint appointment at-- as professor of law and philosophy at Duke Law and as a research professor at Duke's institute for genome sciences and policy. She is also a member of the presidential commission for the study of bioethical issues. Ladies and gentlemen, Nita Faranany.

### Scientific Advocate (SA)
Claim: Good evening. I'd like to thank the Rosenkranz Foundation for airing this important debate, our moderate for John Donvan and my esteemed colleagues in this debate. I am here tonight to represent my personal views, and not the President's Commission on Bioethics of which I am a member, about why we should not prohibit genetically engineered babies. In a little while, you'll hear from my debate partner, Lee Silver, who will debunk many of the scientific claims against genetic engineering. But first I want to convince of you two things: that we already can and have safely genetically engineered babies and that a middle ground of prudent vigilance, public oversight and debate about genetic engineering is better than prohibition.

I also want to call your attention to the resolution this evening. It calls for an outright and complete ban on genetic engineering of babies. If Lee and I can convince you of any instance in which genetic engineering of babies is legitimate, then you should vote against the resolution. Throughout the evening, I'll defend why genetic engineering is no different in kind from the many ways that we already engineer our children, from the partners we choose to prenatal screening to the supplements we take that impact our children and their fates. Recently new research shows the powerful effect of taking folate during pregnancy and how it reduces the incidence of autism in children. And yet no one thinks that we should ban folate. But I want to convince you that we already can and have taken the next step of genetic engineering of babies and that we would take a drastic step backwards to ban outright that technology.

I'm going to tell you about inherited mitochondrial disorders, which are progressive and cause tragic health consequences. A little biology 101 should help frame the debate. About 98 percent of your DNA is nuclear DNA. It codes for much of who you are. But about 2 percent of your DNA is mitochondrial which supplies the energy to your cells. To understand this, visualize a cell with its small nucleus and a little bundle inside of the cell and the mitochondrial DNA and the fluid that surrounds it. The nucleus of the cell is where 99.9 percent of the action is, but only in the mitochondria functions properly. About one in 5,000 babies born have problems with their mitochondrial DNA that cause rare but incredibly serious disease, including heart failure, dementia, blindness, severe suffering and death. There is no way to treat the condition once it is acquired, and it is extremely difficult to predict how severely a child will be affected. With genetic engineering of babies, we can altogether avoid this suffering.

Professors Winston and Krimsky will argue that we can just screen out and abort the defective fetuses or destroy the embryos in the lab. But mitochondrial DNA, which is solely inherited from the mother, is often passed on to every child of an afflicted mother. Only genetic engineering can safeguard a woman against these difficult choices and altogether eliminate the risk of a child being born with mitochondrial disease. Take, for example, Sharon, a woman who had a healthy pregnancy and who gave birth to a beautiful, healthy girl. Twenty-eight hours later, that baby died of an unknown disease. This tragic tale repeated itself five times as each of Sharon's babies lived for just a few hours. Only her son, Edward survived. And by age four, he started falling over repeatedly. He'll spend the rest of his life in a wheelchair with little control over his muscles.

You see, Sharon has Lee's syndrome, a rare mitochondrial disease, and she passed it on to all six of her children. The only way that Sharon or any woman with a high level of mitochondrial abnormality will have her own healthy genetic children is through genetic engineering of the babies. We'll talk about two techniques to do so: Pronuclear transfer and maternal spindle transfer that safely eliminate the risk of these diseases. At least 30 children have already been born in the United States using an earlier version of mitochondrial transfer. All of these children were born free of mitochondrial disease. And these newer techniques have even fewer risks than those earlier ones and promise even better outcomes for future generations.

The United Kingdom, notoriously conservative about reproductive technologies, has given the green light in the use of these technologies. A ban by the U.S. would make us an outlier, a country standing in the way of scientific progress, at odds with the scientific and ethical consensus that mitochondrial transfer, a form of genetic engineering of babies, is permissible. But mitochondrial genetic engineering proves my larger point that I want to convince you of this evening, that a middle ground approach is better than an outright ban. You'll hear my opponents talking about opening floodgates to a dystopia of designing perfect babies. But technology itself is not evil. Only misuse and misapplication of it is. The public can and should decide what limits if any there should be on the uses of genetic engineering. But a complete ban would just drive the practice into back alleys or overseas. Criminalizing genetic engineering will make the practice hidden from public view so that we will have no idea whether Sharon and women like her are using unsafe and unsavory practitioners to carry out genetic engineering.

Reproductive tourism is already rampant, where women and couples are traveling to foreign countries to gain access to reproductive technologies banned in their own countries. You can be sure that women like Sharon, afflicted with terrible Lee's syndrome, will travel great distances to safeguard their children. Now imagine just for a moment how we would enforce the outright ban that the resolution calls for. Would we forcibly genetically test all babies? Would they-- would the government appear in Sharon's hospital room or at airports with handcuffs to arrest her or her child? Would we forcibly sterilize Sharon and her baby? Is this the kind of society that you want to live in? Some of the worst examples of abuses of government power in the last century have involved the government trying to control our reproduction. This grim history of eugenics and of laws against interracial marriage, of programs of forced sterilization and abortion, provide a strong reason to reject the resolution.

We aren't here to defend every type of genetic engineering. We're here to urge you to vote in favor of a middle ground, to allow parents and private citizens to make private choices about one of the most intimate decisions they will ever make, to bring a healthy child into the world.

### Moderator
Claim: Thank you, Nita Farahany. And a reminder of what's going on, we are halfway through the opening round of this Intelligence Squared U.S. Debate where the motion is, "Prohibit genetically engineered babies." You have heard two of the opening statements. And now on to the third. In support of the motion to "Prohibit genetically engineered babies," I want to introduce again Robert Winston. He is a professor of science and society and emeritus professor of fertility studies at Imperial College, London. Ladies and gentlemen, Robert Winston.

### Conspiracy Advocate (CA)
Claim: Well, Ladies and gentlemen, it's great to hear my partner, Sheldon Krimsky, talking about the sperm of Nobel prizewinners. We've got Jim Watson in the audience, and it's-- lovely to see him there.

### Moderator
Claim: Well, I mean, we should tell the non-applauders who he is.

### Conspiracy Advocate (CA)
Claim: Well, I know--

### Moderator
Claim: And we'll stop the clock for a second to do that.

### Conspiracy Advocate (CA)
Claim: I'm not going to ask whether he's banked any of his sperm.

### Moderator
Claim: What?

### Conspiracy Advocate (CA)
Claim: I'm not going to ask him whether he's banked any of his sperm.

### Moderator
Claim: Jim Watson is one of the discoverers of the structure of the double helix DNA, if you read the book in high school in the '60s, he's the guy, and he's here. We're really pleased to have him. Ladies and gentlemen, let's welcome him for doing that work. Yeah. And the clock starts.

### Conspiracy Advocate (CA)
Claim: And it's the 60th anniversary of your paper coming up, isn't it, on the DNA structure, which is a remarkable landmark. Ladies and gentlemen, this is actually quite a simple proposition. And it's quite clear that what our opponents are recommending is something which Americans shiver at, which is experimentation without the consent of the individual being experimented upon.

It's worth looking very briefly at American history. The history of eugenics, which started probably in Britain, with Francis Galton back in the 1850s, is still a scar to some extent on genetics. And Davenport, of course, and other people who followed him, I think, had a great deal of responsibility for the sterilization of women without consent, with the prevention of people who might want to make love together because they were different races were prevented by law in many states in the United States. And this is something, of course, which directly influenced the Nazi holocaust.

And although it may seem farfetched, it's worth bearing in mind that the time when the planet is oppressed by the risk of global warming, and by the risk of conflict, by the risk of all sorts of serious issues on the economy, it may well be that people might want to see eugenics raising its ugly head again. And the United States, in my view, as the leading biotechnological country in the world, has a major responsibility to lead it in this ethical issue. Now, as my partner has said, there are two concerns here. One is genetic engineering to change horrific genes such as these are mentioned, and the other, of course, is to enhance individuals. The problem, of course, is that once you go from one, I think you go to the other as well. And mitochondrial disease, let's just knock that on the head straightaway. Mitochondrial disease, although it's a terrible thing to have, it is really trivial in terms of its incidence. It's a very, very uncommon disorder.

And it is worrying to me that our opponents have got the numbers wrong. It isn't 2 percent of the DNA, it's 16,000 base pairs out 3 billion base pairs. So it's a tiny amount of DNA, but we know already that even fiddling with the mitochondria may make a massive difference to what happens to the nuclear DNA. It's still not clear. And it's worth bearing in mind that abnormal children have been born as a result of mitochondrial transfer. This has been completely unpredictable. Now, with regard to one of the issues about genetic engineering for enhancement, it will be permanent, it will be irreversible, and it may impart values to a child that, that child might find is not valuable in the society in which they are growing up. And, of course, with regard to disease, it is quite clear that screening embryos is a much better bet.

If we take a cell away or the look at the biochemistry of an embryo, which you can now do, and detect the disease, we can simply substitute that embryo for another one in a clutch of eggs because, of course, a woman-- it's worth bearing in mind that the average childbearing woman watching this program will lose two eggs during the course of the program, each genetically unique. The males, meanwhile, have made some 70,000 new sperm. Each of those are equally genetically unique, an every embryo is different. And therefore, to screen embryos which have a clear disease, by the techniques which are now being developed, is certainly possible and much safer than meddling with the genome.

And, of course, what we have to understand is that we now know that the environmental influence on the embryo, the environmental influence on the fetus has a massive point, has a massive change, in how it grows up. And, in fact, really, what we should be trying to do-- rather than trying to risk making abnormal babies, what we should be trying to do is to improve the environment so that the DNA functions in the best possible way.

There is a lot of evidence to show that a woman can change the cognitive ability, the intelligence of her fetus, by what she eats in pregnancy, what happens to her stress hormones in pregnancy, and this research is burgeoning. And that is something which we should really recognize in a democratic society as something that science should really concentrate on.

Now, the big problem of course is that genetic engineering is unpredictable. And I'm going to give you two examples from the two biggest users of people who make genetically modified animals. The most common place for genetically modified animals, of course, is in the pharmaceutical industry. Pretty well every drug is now tested-- nearly every drug will be tested on animals, where their genes have been modified to make a model for human disease or to look at the action of that drug. And if you look at the figures which are being published by two of the largest companies in the world, with very large series of mass models, you can see the problem you'd have with genetic engineering.

AstraZeneca published 51 different models, a vast number of mice in those models, 70 percent, ladies and gentlemen, of those animals were abnormal and the abnormality was unpredictable. Some of the abnormalities were trivial, others were not. The animals were not followed up for long term, they were simply discarded, so we don't know what would have happened to-- in old age. We do know that changing genetics makes a difference to what happens to us in our old age, and certainly the fetal origins of adult disease are very important. We know, for example, that stroke, diabetes, some cancers, may be caused by what happens in the environment of an embryo early on.

And Pfizer has gone even further. It's looked at 74 different tests on mice that are bred after genetic modification, and 50 percent of the mice failed the phenotype test. And this is without, of course, testing the very things for which we would want to enhance people, i.e., intelligence and their ability to solve a problem.

So let's just say one other thing, if I may, and that is that one of the problems, of course, is that one may modify genes, but we don't even know whether they will continue to function in the way. And there is a lot of evidence from the work we do in my own laboratory, which shows that gene expression in a modified animal stops after a while during development. Ladies and gentlemen, as I say, you have a responsibility here. You have a duty to lead the world to make certain that your medicine is ethical. Thank you.

### Moderator
Claim: Thank you, Robert Winston. And our final debater against the motion "prohibit genetically engineered babies," he is against prohibition; I'd like to introduce Lee Silver. He is professor of molecular biology and public policy at Princeton. He is also founder and principal science advisor of GenePeeks, a personal genomics company. Ladies and gentlemen, Lee Silver.

### Scientific Advocate (SA)
Claim: Thank you. The proposition this evening is "prohibit genetically engineered babies." Prohibit even if the purpose is to promote health; prohibit even if the recipients understand precisely the actual risk; prohibit even if it's safe; prohibit even if the technology is safer than doing nothing. I just need to convince you of one example of acceptability and you should vote to oppose the proposition. And my colleague has already talked very eloquently about mitochondrial DNA deficiency, and I'm going to go beyond that, because I hope to convince my opponents here to vote for my side of this proposition. They've both written and talked quite eloquently about the use of genetics to prevent disease. So what are we talking about here tonight when we talk about genetic engineering? Conceptually, it's very simple: genetic engineering will allow perspective parents to give their child genetic information that they themselves do not carry. That's how genetic engineering will first be used, not soon, but that's the way it's first going to be applied.

And to understand what parents might want to give their children, we should examine the facts of genetics that have become available to us over the last five to ten years, have given us a very different perspective on the human genome than we had previously. And it revealed some unpleasant facts. I want you to look at the person sitting to the right of you. And if there's no one on the right, look at the person sitting to the left. That person and you differ at over a million locations in your DNA. Most of those differences don't do anything. But even if you're a healthy adult, at least 100 of those genetic variance can cause deadly childhood disease. Not in you, of course, because you're sitting in the audience. But in your grandchildren or their grandchildren.

You carry thousands of other genetic variants, every one of you in this room, that impact your health and risk to thousands of diseases in different ways, including cancer and heart disease and neurological disease. And some of the variants that you carry are better than those of your neighbor to the right. Some are worse than those of your neighbor. And all in all, some of us are born with better health genes, and some are not.

Now, if you have made a decision, you or a daughter, granddaughter, have made a decision to have a child, what do you hope for the most in that child? And Dr. Winston has spoken eloquently to this question many, many times.

You hope for a healthy child. You'll love any child, but you hope for a healthy child. And Dr. Winston has also said, and I agree, in pluralistic societies like yours and mine, genetic selection against diseased embryos is a matter for the individuals concerned. If you agree with Dr. Winston on this point, it follows that you should be willing to accept genetic engineering when needed to accomplish the same goal.

But, you might worry, doesn't this violate Mother Nature? Well, I'm here to tell you that Mother Nature doesn't care at all about you or your baby. Throughout the history of the human species, Mother Nature has engaged in all-out warfare against us with infectious diseases caused by viruses and bacteria. And it's only in the last century that we gained the knowledge and power to fight back with vaccines and antibiotics and other medicines.

Now, do some people abuse pharmaceutical drugs? Of course there is abuse out there. But that doesn't mean that we should prohibit medicine. With infectious diseases essentially vanquished in our society, although not everywhere in the world, the next target in our sights is Mother Nature's genetic wrath. Unfortunately, if you're in the audience, it's too late to do anything about the genome and the hundreds of trillions of cells in your body. But we can think about the future. You can think about your children's children and their children's children, because the expansive amount of knowledge we are gaining about the genome has flabbergasted even those of us who are most optimistic about this science.

So let's think about the next generation or the generation after that. Now, Mother Nature is a metaphor, and it's a really bad metaphor because in reality, inheritance is a game of craps.

You throw the dice, you hold your breath, you hope your child is healthy. It won't have to be that way in the future when we learn how to take the genetic dice, place them on the table in the way that is going to promote health most likely for the child to be.

What about the risks? We've heard about the risks from both of the proponents of this proposition, the precautionary principle is often mentioned. You shouldn't deploy a technology until all of the unknowable risks are known. And we can't possibly understand how genes work because the whole system of life is very complex. And if we put a new gene in, it might have unattended consequences. And I agree with the proponents of the proposition. We don't understand genetics. It's very complex, and it's more complex the more we understand it.

But what society and people can do in the future is consider genetic information that already exists in some people but not others. I want to focus your mind on the fact, as I said a moment ago, we all carry thousands of genetic variants, some of which are promoting health and some of which are not. And even if a variant is in just 1 percent of the population out there, we can study the effects of that genetic variant in the people who carry that variant. And we can see the benefits or not of that variant. So the precautionary principle is not in effect here.

I want to conclude that if you are thinking about voting for this proposition, you'll need to explain why you did so when your daughter or granddaughter comes to you with the following question: "Dad, grandpa, why can't I give my child health-promoting, disease- preventing genes that other children get naturally?" If you can't answer that question, you must vote no on this proposition.

## Round 2

### Moderator
Claim: Thank you, Lee Silver. And that concludes round one of this Intelligence Squared U.S. debate where our motion is, prohibit genetically engineered babies.

And now we move on to round two. Round two is where the debaters address each other and take questions from me and you in the audience. Our motion is "prohibit genetically engineered babies." We have two teams of two arguing it. The team arguing for the prohibition include Sheldon Krimsky and Robert Winston. They have made an argument, as I hear it, that goes both scientifically and morally. The scientific argument boiled down is that genetics is an enormously complex field. It is not yet well understood, that there is enormous potential for horrendous mistakes to be made.

The crux of their moral argument is that the pursuit of a myth of human perfection is immoral and ultimately corrosive. The Nazis fell for it with calamitous results. They're talking about a slippery slope that we're just at the beginning of now.

The team arguing against the prohibition says, No. 1, it would be-- the immoral thing is to ignore the opportunity to use genetics as a tool to correct and avoid enormous situations of pain and suffering, that the United States will be left behind in something that has already begun to happen. And in terms of the complexity, we just heard that in fact there is a way to find a road map through this forest by studying what is known already, what is observed in the population, that it's not-- that there's not a way into this-- into this forest and a way out of it again.

So I want to put questions to each of the sides in turn. And I want to begin with just this broad notion of the U.S. being left behind. Since we're talking about a prohibition, we're talking about, in that sense, something legal or regulatory. The side arguing against prohibition says the net result of that would be to leave the U.S. behind in something that is happening already, that this train has left the station. Sheldon Krimsky, can you respond to that?

### Conspiracy Advocate (CA)
Claim: Well, that's an all-purpose argument that you can apply for many things. We have all kind of moral provisions in the United States. We don't allow the sale of organs. We restrict certain types of uses of viruses in research. We prohibit certain experiments with animals that are considered immoral. We can always use that argument and say somebody will be left behind, but we have to establish moral principles and safety principles that make sense to our scientific community and our general society.

### Moderator
Claim: Thank you, Sheldon. And I just want to ask the panelists not to hold the mic, because of vibrations are picked up. Nita Farahany, your response.

### Scientific Advocate (SA)
Claim: It's true that this is an argument one could make in nearly any area, but it's different in this one because this isn't just that other countries are doing it. It's that other countries have studied it, they have found it to be scientifically and ethically valid. The U.K. has the human fertilization and embryology authority. Unlike the U.S., things happen there with oversight, public oversight. This organization held a long inquiry inviting scientific and ethical input. The Nuffield Council on Bioethics likewise in the U.K. looked into mitochondrial DNA transfer. What they urged the U.K. to do is to green light this technology and go ahead. We are not saying all genetic engineering. This particular type has the green light. We would be left behind if we decide to prohibit it.

### Moderator
Claim: Robert Winston, your opponent.

### Conspiracy Advocate (CA)
Claim: Well, it's nice to be able to answer Nita firsthand, because, of course, I happen to be a member of the British Parliament, the upper house, and we voted overwhelmingly to abolish the Human Fertilisation and Embryology Authority because it's useless. And actually it's inhibited research. It's not a very good way of regulating. So I don't think you should hold up the British model. What is needed actually-- what I think is needed is a consensus amongst all of us that we act as far as we can ethically and in the best interest of patients, whatever that might mean.

### Moderator
Claim: Nita, do you want to respond?

### Scientific Advocate (SA)
Claim: Sure, yeah, I also agree, we should act ethically. And the most ethical thing to do in circumstances where the only way to prevent a particular type of disease where we readily have a technology available that people will avail themselves of either in this country or another one is to give the green light to proceed.

The ethical way to proceed is to study a technology, to have an open public debate about a technology, to have scientific valid-- scientifically valid studies that are allowed to proceed. This technology is proceeding. This technology can save lives. It has saved lives. We would be taking a drastic step backward.

### Moderator
Claim: Sheldon Krimsky.

### Conspiracy Advocate (CA)
Claim: Sharon was mentioned. I don't know her personally. And I'm so happy that she had a successful pregnancy. But she had choices. One of her choices was to adopt someone else's egg and have a baby. She-- it wouldn't be her DNA but it would be somebody else's DNA. Another choice would be for her to adopt a child, which, you know, is certainly a desirable thing to do in a world where there are children who need adoption.

What is the urgency of people to have their DNA in their child? In fact, most of the things that our children get do not get from our DNA, they get from all the enhancement that we give them, so there's this obsession that "My child has to have my DNA." She did have some other choices. The risks that she took were real.

### Moderator
Claim: Lee Silver.

### Scientific Advocate (SA)
Claim: Well, Professor Krimsky and I both have children here in the audience, so we--

### Moderator
Claim: I want to point out also that you two live in the same apartment building.

### Scientific Advocate (SA)
Claim: We live in the same building--

### Moderator
Claim: And that sometimes you meet up for coffee downstairs in the shop, and you have this out quite a bit.

### Scientific Advocate (SA)
Claim: We have coffee at Jack's, the best coffee in the city. And I have no conflict there. And we both have children in the audience, so we've used our ability to reproduce to have our children who I'm sure that you love your children as much as I love mine.

I don't think we should discriminate against those people who, for whatever reason, are unable to reproduce and say, "Well, they don't have the ability, therefore, they should be adopting or solving other societal problems." I don't think that's fair because we don't ask ourselves to adopt, although a very, very few people do, so I question the alternative here.

### Moderator
Claim: Sheldon, I want to put a question to you, or Robert, whoever wants to take it, that your opponents in their opening statements focused primarily on enhancement that ameliorates negatives. They mostly talked about helping produce children who wouldn't have dreaded illnesses, conditions, and diseases. Before we get on to the other side of it about enhancing-- you know, to create pretty people and tall people, do you see the distinction between a genetic intervention to avoid pain and suffering as opposed to making a superman?

### Conspiracy Advocate (CA)
Claim: I--

### Moderator
Claim: Robert Winston.

### Conspiracy Advocate (CA)
Claim: I think it was a very clear distinction, and I think the other side are absolutely right to concentrate on genetic abnormalities because, of course, gene defects are appalling. They are amongst the worst kinds of diseases that people have. Children in the main die of genetic defects. A few of them like mitochondrial diseases don't always kill people but they often have major effects on the central nervous system. They're deeply unpleasant, and there's no question that if we could avoid these diseases, if we could prevent them or treat them more effectively, we should do so.

### Moderator
Claim: So do you concede that point to them?

### Conspiracy Advocate (CA)
Claim: But I think the problem really is that, first of all, there will be enhancement. And I think that's risky. And the difficulty really is that in preventing one genetic disease, you're likely, very likely, to cause another genetic disease.

The fact, of course, is that we now know that there are only 20,000 genes in the human genome, but there's a huge amount happening outside the genome which is of vital importance. The ENCODE data which has just been published show that there are not just 20,000 genes, but literally 3- or 4 million sequences already known in the messenger RNA, for example, which have an effect--

### Moderator
Claim: So you are not conceding the point that intervention--

### Conspiracy Advocate (CA)
Claim: No, I'm not-- I'm not conceding the point, but I can--- what I'm saying is it's a seductive point and I can understand why they're concentrating on it, because the rest of the argument is bound to be very weak.

### Moderator
Claim: Nita Farahany.

### Scientific Advocate (SA)
Claim: There is no rest to the argument. Our argument is that people all differ, we have genes that are different from each other in promoting or preventing disease and we think that, on that ground, parents should have the right to be able to promote health.

### Moderator
Claim: But I also think-- the reason I was looking for clarity, I thought that I heard Robert Winston say that it's just not practical, realistic, to do these interventions to prevent disease because you don't know enough. And you specifically said this sort of intervention can actually promote other genetic outcomes.

### Scientific Advocate (SA)
Claim: Let's talk about that, the idea that if there is uncertainty we shouldn't proceed. Well, I mean, I have news for you, which is every single time we choose to reproduce there's uncertainty. We have no idea how this unique combination of individuals is going to result. And we certainly aren't going to say that we're going to ban natural reproduction, which is no more sex and no more kids. That's not going to happen. Instead, what we're going to do is we're going to ensure the scientific safety and efficacy of technologies before we allow them to proceed, and with mitochondrial transfer, which is a major form of genetic engineering, we have already had major scientific studies and an emerging scientific consensus that shows it's safe, it works, it eliminates massive childhood suffering. One out of 5,000 babies who have mitochondrial--

### Conspiracy Advocate (CA)
Claim: Hey, Nita. Nita, just bear in mind that the children that were born after mitochondrial transfer are still children. And the real problem, of course, is what happens to them when they're adults. We don't know. We don't--

### Scientific Advocate (SA)
Claim: Well, happily they get to become adults. They won't become adults without this option.

### Conspiracy Advocate (CA)
Claim: Well, what we-- what we do know is that there is a huge amount of evidence that adult disease is caused by what happens to the genome very early on, either at the time of conception, or shortly afterwards, or during pregnancy. And so, for example, diseases like stroke, heart disease, cancer, and so on are things which we may be imprinting on those-- I'm using imprinting in a--

### Moderator
Claim: Right. But let me-- let me interrupt a second and to ask you a somewhat hypothetical question. But we're having a relatively hypothetical debate, so I would like you to entertain it.

### Conspiracy Advocate (CA)
Claim: Well, it's not hypothetical when abnormal babies are being born.

### Moderator
Claim: No, no. The question I'm asking is going to be hypothetical. If, in fact, the scientific problems could be solved, if, in fact, after years or decades of investigation these unwanted side effects of genetic intervention could happen, would that change your point of view?

### Conspiracy Advocate (CA)
Claim: In June 2000, President Clinton announced, in the White House, the sequencing of the human genome. We now know that, actually, it's hugely more complicated than was presented then; actually, it's getting more and more complicated. So, actually, the problem really is that it's becoming less and less--

### Moderator
Claim: But that's why my question is hypothetical. Unless you're saying you think it will never happen.

### Conspiracy Advocate (CA)
Claim: I don't think we can answer a moral question on a hypothetical point. We have to answer it on a practical point: are we prepared to cause damage to children which they don't deserve?

### Moderator
Claim: Lee Silver.

### Scientific Advocate (SA)
Claim: Well, I think the point that we're trying to make here is that there's huge diversity in the human genome among people, and if there are people in the world who have a particular form of a gene which gives them a health advantage, we know what that is, we can study that in those people. And that eliminates the experimentation part of this.

### Moderator
Claim: Sheldon Krimsky.

### Conspiracy Advocate (CA)
Claim: We have a very-- we have a very elaborate system in this country of allowing or not allowing people to be involved in clinical trials. The safety issues that have to be taking care of this, institutional review boards. Now, if you were a woman who wanted such procedures to be done, one of the first questions you would ask is has this been done within a clinical trial setting, with the government's imprimatur, or is this being done at a hospital that has, really, no accountability to any national bioethics system? In fact, these experiments were done in violation of a de facto rule by the federal government, because they used private funds.

So there is really not a good clinical trial that was used to suggest that these procedures were safe. There are a lot of risks that these women took.

### Conspiracy Advocate (CA)
Claim: There's one thing, of course, is the data also curiously changed halfway through. So we don't actually know how many embryos really were abnormal. That's a big problem.

### Moderator
Claim: All right. Let's go to the other side. Nita Farahany.

### Scientific Advocate (SA)
Claim: I'm so glad that you read the fact that there's no government funding for this, because the best way that we can actually have public oversight and insight into what's happening in science is by actually having transparency. It's true; most of the different techniques that have been-- that have been studied in the U.S. have happened via private companies. What that does is ensure that there's no opportunity for public oversight. All we have to do is simply fund that research in order to have public oversight. With public oversight, you ensure safety and efficacy. You ensure the ethical process of science, and you ensure the ethical use of this technology.

### Moderator
Claim: All right. I want to put-- move this into this somewhat fanciful area, but I think it's relevant, on just how good it can get in the world that you're talking about, Lee Silver, where, as you put it before, parents can introduce to their children DNA that is not their own.

### Scientific Advocate (SA)
Claim: Well, that's the definition of

### Moderator
Claim: Yeah. And it's an excellent one, actually. It really is useful for this debate. But you both have focused so far on, let's avoid bad situations. In your imagination, how far does this go in the creation of smarter, taller, prettier children?

### Scientific Advocate (SA)
Claim: Well, I don't know how far it goes.

### Moderator
Claim: How far do you want it to go? How far do you-- how far do you dream of it going?

### Scientific Advocate (SA)
Claim: It doesn't matter what I want.

### Moderator
Claim: Well, I want-- and what would you do?

### Scientific Advocate (SA)
Claim: What would I do for my children?

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: I love my children the way they are.

### Moderator
Claim: Are you avoiding what, to me, seems like a really relevant question. Just what are you talking about?

### Scientific Advocate (SA)
Claim: No, I don't think it's avoidance, because I don't think that's what parents care about the most. What parents care about the most is promoting the health during the lifetime of their child. And that's what they're going to focus on.

### Moderator
Claim: So you don't-- there were intimations from this side when you used the term "the pursuit of human perfection."

### Scientific Advocate (SA)
Claim: There is no such thing as human perfection. It's not a scientific concept.

### Moderator
Claim: Well, if there's a pursuit of human perfection.

### Scientific Advocate (SA)
Claim: No, I don't mean-- that's not what parents are trying to do. They're trying to just-- give their children whatever--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --health advantage they can. That's not perfection. There is no perfection.

### Moderator
Claim: So you're basically saying that that slippery slope is-- is a red herring.

### Scientific Advocate (SA)
Claim: I just don't believe in perfection.

### Moderator
Claim: Okay. I just want to put it to the other side then. Basically, I think your opponents are saying that that particular concern is a little bit chicken little.

### Conspiracy Advocate (CA)
Claim: Well, I don't think either of us have--

### Moderator
Claim: Robert Winston.

### Conspiracy Advocate (CA)
Claim: I don't think either of us said we were chasing perfection. Of course, we're not. I think all of us on this panel, all four of us are sensible people. And the areas of disagreement are perhaps quite narrow, but they are very, very important.

And I think the issue is not perfection but the fact is that really what you are proffering, what you're offering is something which at the moment and for the foreseeable future is entirely unpredictable. And it's dangerous to individuals where the unpredictability

### Moderator
Claim: But, Robert, your partner did introduce that broader moral notion. You're-- the moral concern that you raised, Sheldon Krimsky, was not simply the problem of the unpredictability of the science. You talked about the larger vision of what we want to be as a society when we have this technology more fully developed. Can you--

### Conspiracy Advocate (CA)
Claim: Exactly. I was going to leave that for my final comments because I truly was plagued by the mitochondria problem. I think it is a problem for people who oppose genetically engineering babies because on one hand you feel for people, and you want them to have the best for their lives. So there has to be a response to the mitochondrial problem or other problems where people have two copies of a diseased gene and cannot use pre-implantation embryo or diagnosis.

### Moderator
Claim: Nita Farahany.

### Scientific Advocate (SA)
Claim: I think what's important to realize is that with every slippery slope argument, the question is, is a ban-- a ban outright better, or is there some middle ground? Is there some way that we can trust society to have reasonable limitations on the advancement of technology? We've offered one. Mitochondrial DNA has 2 percent of your DNA, but it codes only for about .1 percent of what happens in an offspring. It's the essential energy source. What if we stopped it there? What if we decided that that one step is something we believe is safe and efficacious? It would still call for not an outright ban.

The next step would be nuclear DNA. And if we felt like nuclear DNA is off limits today until we have better safety studies, that would be a reasonable approach forward, and then we would say, what scientific evidence do we have? Given the scientific evidence that we have, what ethical constraints do we as a society wish to put into place? We do it all the time with every technology we have. We don't ban technologies. We have public transparent debates about the best place to draw the line.

### Moderator
Claim: In just a moment, I want to come to you in the audience to start taking your questions. And I want to remind you again how it works. If you just raise your hand, a microphone will be brought to you. If you can stand up, hold the microphone about as far away from your mouth as this one is from me so that the radio broadcast can pick you up. We'd appreciate it if you could state your name. And the hardest part of all is to be really concise and to really make it a question. And you'll know because a question mark goes right at the end of it. If that feels right, you've succeeded. I want to let Robert Winston respond.

### Conspiracy Advocate (CA)
Claim: Just a brief point about the mitochondrial thing, this extraordinarily rare situation where mitochondria are abnormal. The very few experiments done in animals on mitochondria, but one that stands out in my mind is a thing called the PEPCK mouse. PEPCK mouse whose mitochondria have been modified, runs 20 times further than a normal mouse and is much more athletic. It turned out completely unpredictable because it has really strange fertility disorders. It has a very weird metabolism. And above all, it's much more aggressive than other mice. It's not one that you'd want to have in your kitchen.

### Moderator
Claim: Lee Silver. Sounds like a bad mouse.

### Scientific Advocate (SA)
Claim: Sounds like a good mouse to me. But we're not arguing that the safety and efficacy exists right now for all of the possibilities of the future. I mean, we're talking about-- the mitochondria is one small case. In the larger sphere, we're talking about our children's children and their children. And the advancements in genetics are happening so fast that we can't prohibit forward advance if it's done safely and effectively.

### Conspiracy Advocate (CA)
Claim: John, can I just tell the audience--

### Moderator
Claim: Sheldon Krimsky.

### Conspiracy Advocate (CA)
Claim: --what we're dealing with here with the mitochondrial case? The woman's egg has abnormalities in the cytoplasm. And the mitochondria is in the cytoplasm. But her DNA is perfectly normal. So there's several ways that they deal with it. They either take her DNA out of her egg and put it into another egg where the DNA has been removed so she'd operating with her DNA in somebody else's mitochondria. So you have then a child born with the DNA of two women and then one man. And these interactions between the nucleus DNA and the cytoplasm DNA are totally unknown.

### Conspiracy Advocate (CA)
Claim: That's right.

### Conspiracy Advocate (CA)
Claim: There are other ways to do it. One way is if you have like rotten milk, you take the milk and divide it in half and then put good milk into it. You take the cytoplasm from a healthy egg, and you pump it into the abnormal cytoplasm of the abnormal cells so you're pumping in somebody else's DNA into the woman's egg. And then you have the child with that, hoping that--

### Moderator
Claim: Okay. Let me-- let me take back to Nita Farahany because you talked about the mitochondrial transfer in your opening statement quite extensively. And your opponent has basically just said the whole premise of what you're talking about is actually its own kind of crap shoot.

### Scientific Advocate (SA)
Claim: So let me add one technology that my opponent didn't talk about, which is-- which answers his issue. There's a technology for mitochondrial transfer that's going to clinical trials from a company in Boston this year. And in that technology, what they've discovered is that women have precursor cells before their egg cells. And those precursor cells can be used to develop their own mitochondria, healthy mitochondria. And they can take their own healthy mitochondria, fuse it with their own nuclear DNA, and they can end up with a healthy offspring, free from mitochondrial disease.

Already in clinical trials, already ready to enroll human subjects, already with the green light to go ahead. You would be banning that technology and preventing women who have abnormal mitochondrial DNA from being able to have the choice to have their own genetic children.

### Moderator
Claim: Response from the other side, or shall we go to questions from the audience?

### Conspiracy Advocate (CA)
Claim: Well, let's wait and see the results of the trial, shall we? I suspect that we might find some surprises as we have with every one of these other trials. You could argue too that you're not genetically modifying anybody because you're using the DNA that's already there in the person. It's rather like pre-implantation genetic diagnosis.

### Moderator
Claim: Actually, by-- by Lee's definition-- by Lee's definition, that does not--

### Conspiracy Advocate (CA)
Claim: I think it's a spurious argument.

### Scientific Advocate (SA)
Claim: And I think Lee's definition is too-- it's modifying genetic offspring. Surely you would also agree that that is genetic engineering, and you wouldn't –

### Conspiracy Advocate (CA)
Claim: You keep on--

### Scientific Advocate (SA)
Claim: --try to claim mitochondrial DNA now is your own.

### Conspiracy Advocate (CA)
Claim: Forgive me. You keep on talking about 2 percent of the DNA. It's not. It's a tiny, tiny proportion. It's a miniscule fraction of DNA.

### Scientific Advocate (SA)
Claim: Tiny proportion of the information, yes.

### Scientific Advocate (SA)
Claim: That's right. That's still two percent of DNA.

### Moderator
Claim: Let's go to some-- let's go to some questions right here on the aisle, sir. And if you could stand up, and tell us your name, and hold the mike pretty close to your mouth –

### Moderator
Claim: I'm Robert Klitzman from Columbia University. Great debate. Question for the opponents, I'm wondering if we should be allowed to enhance children genetically, not perfect them, but, for instance, many parents say they'd like to have kids who are blonde haired, blue eyed. Should that be allowed? Should there be a line drawn anywhere in terms of enhancement, and, if so, where?

### Scientific Advocate (SA)
Claim: Well--

### Moderator
Claim: Lee Silver.

### Scientific Advocate (SA)
Claim: --in fact, we've actually done a poll where parents, in fact, don't believe that. What most parents want are children that resemble themselves, just a little bit prettier and a little bit smarter. That's what parents want. The blonde haired blue eyed thing is fiction.

### Scientific Advocate (SA)
Claim: Let me just add to that--

### Moderator
Claim: Nita Farahany.

### Scientific Advocate (SA)
Claim: --is that the enhancement versus therapy distinction is really just a red herring. So if I improve somebody's health, have I enhanced them? And the truth is, every improvement that we've had in our health over the past century and more has been an enhancement. So do parents want to enhance their children? Of course, they do. They give them better education. They give them prenatal vitamins. They, you know, do prenatal yoga and every other type of thing to try to, you know, make things better. They take headphones and play music for their children during, you know, the gestational period. So do parents want to enhance their children? Yes. Do they already do it? Yes. Should genetic engineering that enhances their health be permitted to go forward? Yes.

### Scientific Advocate (SA)
Claim: And I would just add, it's not--

### Moderator
Claim: Lee Silver.

### Scientific Advocate (SA)
Claim: --an either/or. We all agree that environment is important, but the genes are also important.

### Moderator
Claim: The other side want to respond to that? What I found interesting in what Nita said is she said the difference between intervening so that your child will not be-- will not have a heart problem, say, in his 60s is a form of enhancement. It does make the child's life better, and maybe it's not so different from giving the child a little bit of a intelligence boost as well, that once you're making things better, you're making things better. You-- earlier-- you said there was a distinction between those two things, and I just want to see if you can respond to what I think her point was. Sheldon.

### Conspiracy Advocate (CA)
Claim: I mean--

### Moderator
Claim: Robert Winston.

### Conspiracy Advocate (CA)
Claim: You know--

### Moderator
Claim: Do you mind if Sheldon takes it-- because we just haven't heard from him in a while-- if you have an answer to that, Sheldon.

### Moderator
Claim: Just in the interest of fairness.

### Conspiracy Advocate (CA)
Claim: I think my argument was that any of the factors we think about enhancement are so complex, they involve so many genes, that it would just be unrealistic to think that you can enhance a person by manipulating a few genes here or there.

And, plus, we haven't even discussed the epigenome, which are all the switches that turn genes on and off, which are so complex--

### Moderator
Claim: But that doesn't get to the point that she was making. She was making the point that fixing something a little bit is not all so different from pushing something that's not fixed into a better place, not broken, into a better place.

### Conspiracy Advocate (CA)
Claim: If she's saying that there isn't a clear distinction between a medical improvement or medical-- or therapy and enhancement, I actually agree--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --that there is a fuzzy line between enhancement and therapy.

### Moderator
Claim: Right in the very center.

### Moderator
Claim: Thank you, this is great. My name is Gerry Ohrstrom, and my question is for Professor Krimsky. Professor, your debating opponent Lee Silver mentioned that "Mother Nature doesn't care." In contrast, if I infer correctly, when you briefly introduce the concept of balance in your remarks, you seem to be saying that the genome has evolved as some idealized natural balance and shouldn't be messed with. My question is whether this concept of balance is actually valid, given that evolution operates through randomness and through natural selection in ever-changing random contexts.

### Moderator
Claim: You're saying nature--

### Moderator
Claim: Is there really a place for this notion of balance or--

### Conspiracy Advocate (CA)
Claim: Well, yeah.

### Moderator
Claim: That nature could have done a much better job if this was-- if nature was so good at it, we would be a lot better than this?

### Moderator
Claim: Well, that might-- my question is whether the professor perceives our evolved genome as something that should be. Or is this--

### Moderator
Claim: Okay.

### Moderator
Claim: --Hume’s fallacy?

### Moderator
Claim: Right.

### Conspiracy Advocate (CA)
Claim: I think that--

### Moderator
Claim: Sheldon Krimsky.

### Conspiracy Advocate (CA)
Claim: --over millions of years, mistakes have been bred out to a great extent. And it's remarkable how many children are born normally with the billions and billions of biochemical actions that take place from the fertilized egg until the child is born.

So a lot of mistakes were bred out of the system, and it's taken millions of years before the human genome has evolved. Now we're saying, okay, we can get a few technologists to tinker with that and do a better job at the balancing the homeostasis of what I consider an ecosystem, a genetic ecosystem. And my colleague here has pointed out how many abnormalities occur when these genetic mice are manipulated.

### Moderator
Claim: Lee Silver.

### Scientific Advocate (SA)
Claim: Well, I think we've learned something very important about the genome in the last five to 10 years, which is that every member of this audience has hundreds of mutations that can kill a child if they're in the same embryo as a mutation from the other partner, so it's not so pleasant.

### Moderator
Claim: Okay, another question, right down in the front here. Or, actually, I like to do a little gender balance, so forgive me, but, ma'am? I'll come back to you-- If you would stand up, please. Thanks.

### Moderator
Claim: Yes, my name is Jane Gabret This question is really for both sides of the motion. There has been so much in vitro fertilization that's gone on, and I know that there are many studies now that are linking a possible link autism to in vitro fertilization. And is that an example of seeing something after the fact-- a good thing, in vitro has produced many, many babies but now they're thinking that the big, huge spike in autism could have some link to that.

### Moderator
Claim: Robert Winston.

### Conspiracy Advocate (CA)
Claim: Well, I think it's fair to say that we certainly will find some rather unusual occasions when there are abnormalities which are a result of the broad aspect of in vitro fertilization. There are particular issues which do change gene function; we know, for example, that embryo freezing on rare occasions changes gene function. We published that from my own laboratory, demonstrating that a cancer suppressing gene is suppressed in its action after routine freezing. We also know from animal studies in mice and rats, that there may be an increased risk of demyelination; that is, a form of ME in the brain in some animals that have had a cell removed. Now, I have to say that these things have to be much more carefully validated.

The problem really is, with in vitro fertilization, it's probably rather like meddling with a genome: most of the time, it might well be quite safe. And I would not want people to go away from here thinking that IVF is a horrible thing to do for a child, it clearly isn't. But the full consequences of in vitro fertilization cannot be known for a very long time ahead. It's well worth putting your--

### Moderator
Claim: So you're-- so you're not saying that-- you're not--

### Conspiracy Advocate (CA)
Claim: Just one point. It was 50 years before we fully understood the effect of ionizing radiation, and even now we can't quantify it exactly.

### Moderator
Claim: Okay. So you are not saying that you see an autism link; you are more broadly saying you don't know where things are going to go. And I want to take that part of the question back to the other side. Nita Farahany.

### Scientific Advocate (SA)
Claim: Well, quite nicely, he makes the point for us, which is there are still uncertainties with IVF and yet he's in favor of going ahead with IVF. And why is that? Because we have to act in the face of uncertainty in life. I agree, there has not been a strong showing of any link between autism, maybe it has something with age of mothers who are undergoing IVF, we don't know. But I think the much more important question to ask is, we've been using technologies that have some uncertain risks, are the lives worth living that have resulted from those technologies?

And the answer is yes, those are lives worth living. The children believe those are lives worth living, the parents believe that those were lives that were worth bringing into life. That's what these technologies have enabled people to do, is to bring into life a life worth living. There may be some risks, there may be some uncertainties, but that doesn't mean it's not worth proceeding.

### Moderator
Claim: Another question?

### Scientific Advocate (SA)
Claim: I just want to raise the point--

### Moderator
Claim: Okay, very quickly.

### Scientific Advocate (SA)
Claim: --we don't stop people who are both carriers for the same mutation at reproducing, even though they have 25 percent risk of having a child with a serious disease. We shouldn't discriminate against people just because they're infertile.

### Moderator
Claim: Four rows from the back, you're wearing a black and white striped shirt, thanks.

### Moderator
Claim: My name is Maria So science is science, and science will always have its uncertainties, but at the end of the day this is a very emotional issue, and prohibition, what we know from history, is that people do dire things when they really want to, coat hanger abortions or bootleggers. So to the team against-- or to the team arguing for prohibition, what do you tell the woman who's about to go get the equivalent of a coat hanger abortion? So if you can't do this, what do you tell her?

### Moderator
Claim: Well--

### Scientific Advocate (SA)
Claim: I think the point is a good one, which is, in the years before abortion, 1.2 million women per year had illegal abortions. Do we really think this technology won't exist?

### Moderator
Claim: I think the-- I think the-- I just want to say with respect that I think you kind confused the issue by the linkage to a coat hanger abortion, when in the case of seeking a therapy, it might be the situation that people will go offshore or that the wealthy will go offshore which was a point that was brought up earlier.

So would you be willing to rephrase your question to say, what are you going to say to women who can't get this while other women can? Because I-- I don't know that there's going to be a back alley, you know, geneticist working this.

### Moderator
Claim: Well, I--

### Moderator
Claim: So I'd like-- I'd like to rephrase the question. I'd like to rephrase the question to this side, that if in-- if the technology in particular, as Nita Farahany had said in the U.S. being left behind, if it's going to be available overseas in safe clinical settings, but you have to be rich to get there or connected, what are you going to say to the women who can't get there? And I'll put that to Sheldon Krimsky.

### Conspiracy Advocate (CA)
Claim: To the women who cannot get the genetic engineering for this problem?

### Moderator
Claim: In a world-- in a world where it's already-- where the train's left the station.

### Moderator
Claim: In a world where just the wealthy can get it.

### Conspiracy Advocate (CA)
Claim: Genetic-- genetically modifying human reproductive cells is a totally new frontier. It has lots of risks, and its risks are not only to the individuals who are involved in it. Its risks are to the society as a whole or to other societies, a new Hitlerian society that arises.

The last thing you want to do is to provide a technology that could be misused by authoritarian societies for their own functions. And this is a totally novel frontier that we should be extraordinarily cautious about in trying to break through. We have never done this before. Those examples that she gave us are very tentative. They're full of risks. And if we produce the child that was abnormal, then society would have to deal with it.

### Moderator
Claim: Okay. I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters arguing out this motion: prohibit genetically engineered babies. Nita Farahany, do you want to respond to the questioner's point?

### Scientific Advocate (SA)
Claim: I think that the answer was not particularly forthcoming in addressing what happens when people who are desperate, particularly women, for example, who have mitochondrial disease, who are going to pass it on to every one of their children and want to have a choice to have a genetic child. What are they going to do? Well, they will go abroad. The technology will go abroad. And what does the prohibition then look like in this country? Does it mean that we show up with handcuffs at the airport, and we arrest the person? Does it mean that we forcibly test everyone? Because what we're arguing for here is not adding in genomes outside of the human genome, into children. We're arguing that the babies would look identical to ones that are already in our population. So how are we going to detect those differences? And what is the society that prohibits it like going to look like? Is it forcible sterilizations? Is it forcible genetic testing? How are we going to detect it? How are we going to enforce it? And is that a kind of society that we want where we intrude that deeply into our private lives?

### Moderator
Claim: Do you want to--

### Scientific Advocate (SA)
Claim: I want to respond directly--

### Moderator
Claim: Lee Silver, go ahead.

### Scientific Advocate (SA)
Claim: --to the point that you made, Sheldon, which is that the children are going to be born and society is not going to take care of them. Every year 4 percent of children born from natural reproduction have birth defects. Some children are abandoned by their parents. And an ethical society takes care of those children. I don't see why it would be any different in the future, no matter how children come into conception.

### Moderator
Claim: Sir, down in the front here. And a mic will come to you.

### Moderator
Claim: Hi. My name is Harlon Millcove and my question is, is there a concern that through genetic engineering a defect in DNA could be introduced that isn't known until several generations later, by which point there is, you know, potential damage to the gene pool that might affect--

### Moderator
Claim: This side has actually said that it has that concern, so let me have you put your question to this side. And did everyone hear the question clearly? Okay. Sheldon-- Lee Silver.

### Scientific Advocate (SA)
Claim: the questions whether the defects can be introduced into the genome, let's compare what already exists. In your genome, there are defects right now. You have a hundred mutations that could have caused childhood disease. You have deletions of genetic information. So you have all sorts of defects in your genome right now. We're talking about technology which we all think should be done only when it's proven safe and effective.

### Moderator
Claim: Sir, down in front here.

### Moderator
Claim: Jamie Metzl. First, thanks to Intelligence Squared for this incredible debate. I believe, as many of us here, this is one of the most important issues that our species will face in our future, so it's great that we're having this important conversation. The arguments of both sides seem to rely on pre-implantation genetic diagnosis process. In the case of the affirmative for screening and in the negative for engineering. My question is, does this mean that by both of your arguments, in the future, sex will be a form of recreation, but IVF will be the preferred form of procreation for advantaged people?

### Conspiracy Advocate (CA)
Claim: Sex is already a form of recreation.

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: Good answer.

### Moderator
Claim: We're all looking at the British guy.

### Scientific Advocate (SA)
Claim: Well, you just heard it from our side already.

### Conspiracy Advocate (CA)
Claim: I got the impression it was a rhetorical question.

### Moderator
Claim: I think it was a rhetorical question, and it got a good laugh. Ma'am, on the aisle there. You've had your hand up a long time, and a mic's coming from-- yeah. Oh, no, no. I'm sorry. I meant the woman who's standing. I'm sorry to disappoint you. And I will come back to you.

### Moderator
Claim: Thank you. My name is Michelle Boardman. The debate is focused properly I think on ethical and practical questions. But I have a question about rights. So what right, if any, does a potential parent have to access these technologies, such that a ban would violate those rights?

### Moderator
Claim: Nita Farahany, do you believe in a rights issue?

### Scientific Advocate (SA)
Claim: I think the question about procreative rights and liberties is a very difficult question. If your question is, is there a constitutional right to access technologies, I'd say no. If the question is, is there a natural right that people should have over procreative liberties, over the choices that they make about having children and who they meet with and whether or not they bring a healthy child into the world, I think that that is the most fundamental of rights that a person has. And an outright ban threatens to intrude upon that in so many different ways, not the least of which is the method of enforcement that you would have to use.

### Moderator
Claim: We are being live streamed on fora.tv, and people who are watching us are sending in questions. And I want to read one that's just been handed to me. And it's for Lee Silver. And we've touched on this broadly, but this makes it more specific. "What about a scenario where employers would only hire enhanced people because they will be less prone to issues? Isn't there a potential to create a fragmented society where only privileged populations can afford it?" Lee Silver.

### Scientific Advocate (SA)
Claim: Well, that's the "Gattaca" scenario of people being evaluated solely on their genes. I don't think it's realistic because an employer is always going to look at the productivity and the past performance of a person when they hire because that's much more-- much stronger than whatever genetic predisposition they might have.

### Scientific Advocate (SA)
Claim: I just want to add a quick thought on that, which is--

### Moderator
Claim: Nita Farahany.

### Scientific Advocate (SA)
Claim: --we want to be careful to not convey the idea of genetic determinism, that there is a one-to-one relationship between genes and behavior and identity, because there simply isn't. We know far too much about the interaction of the environment and so many other things that give rise to our behaviors and our identities.

So the idea that genetic engineering will result in a particular type of behavior that employers can then screen for simply belies an earlier conception of genetic determinism that we have rejected, and we should continue to reject.

### Moderator
Claim: Robert Winston, your opponent.

### Conspiracy Advocate (CA)
Claim: 112 years ago, one of the most famous British scientists ever, Lord Calvin, said, "You can take it from me, heavier than air flight is impossible." Two years later, Orville Wright flew his biplane. I would strongly recommend that you don't ask scientists at all ever for predictions. We are no more cable of predicting where we will be in five years than anybody else. It's a massive mistake. That's why we have to act responsibly now.

### Moderator
Claim: Going to come to another question. I'm sorry. I don't see a hand up anywhere. Oh, right down in front, please. Thanks.

### Moderator
Claim: My name's Trudy Levine. What we do have now is genetically engineered food. And this started off with the idea that it was going to enhance food production, it was going to enhance food all over the world. There are many countries that have said, as you're saying, that they didn't know what would happen. And they decided to not do it. We've now seen that it is affecting production of non-genetically engineered food.

### Moderator
Claim: Can you end this question in relation to humans?

### Moderator
Claim: Yeah, and I'm wondering, you know, you seem to be willing to go ahead and say that the risks are worth taking, and if we look at where the risks have taken us so far--

### Moderator
Claim: Your question to decide arguing against prohibition.

### Moderator
Claim: --problems, so I'd like you to address that.

### Moderator
Claim: Thanks. Lee Silver.

### Scientific Advocate (SA)
Claim: We've been genetically engineering food for 10,000 years. That's the basis for civilization. When it comes to--

### Moderator
Claim: No, Lee, but genetic-- I mean, the genetic-- the modified food is the actual mixture of species, it's not the same thing as crossing species.

### Scientific Advocate (SA)
Claim: Well, we've been mixing species, too, actually. Cows come from different species, and the--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --the llama comes from different species. People understood this--

### Moderator
Claim: Absolutely right.

### Scientific Advocate (SA)
Claim: --thousands of years ago. But what I am talking about supporting is the case where there are already people in the world, some people, who have certain genetic variants that provide health advantages, promote health. So we understand how those genes work because we see the empirical evidence. That's what I am suggesting, that we should allow parents to choose for their own children. Why can't they give the genes that have already been present in other children and promote health, why can't they give those to their own children?

### Moderator
Claim: Response from the other side, or do you want to pass?

### Conspiracy Advocate (CA)
Claim: Genetically modified foods don't go to school or make love, whole range of things they don't do.

I've got no problem with genetically modified plants. I think actually it would be an important technology for the world, given the problems with water supply. I think we have to differentiate very substantially from what happens in genetically modified crops from what happens actually in human beings.

### Conspiracy Advocate (CA)
Claim: The actual-- the issue of genetically modified food's an interesting one because it shows you how you can develop a technology, patent it, and then control it through monopoly control like some of the companies do, so that farmers can't-- farmers cannot even own the seeds or replant the seeds. I mean, we've seen a system of capitalistic control over seeds that we've never seen before in history. I don't think this is very desirable for a diverse agricultural system, but we're waiting to see what happens in the future. No parent of any child will ever control that child. Take it from me.

### Moderator
Claim: And speaking of children, young man. I hope you won't think it condescending for me to ask you what grade you're in?

### Moderator
Claim: Seventh grade.

### Moderator
Claim: All right, good for you for being here.

### Moderator
Claim: Thank you. This question is directed towards Mr. Silver. And you just touched on the topic of safety when--

### Moderator
Claim: Oh, what's your name, by the way?

### Moderator
Claim: Philip Schneider

### Moderator
Claim: Okay.

### Moderator
Claim: And I was wondering to what extent does safety mean for this thing to go into effect?

### Scientific Advocate (SA)
Claim: Safety's very important.

### Moderator
Claim: But what does "safety" mean?

### Scientific Advocate (SA)
Claim: What does "safety" mean?

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: Safety is relative, and I think that's the most important point. And reproduction is dangerous. If a technology can come along that can make reproduction less dangerous, that's a technology we should embrace.

### Conspiracy Advocate (CA)
Claim: You know, we have--

### Moderator
Claim: Sheldon Krimsky.

### Conspiracy Advocate (CA)
Claim: --a system of safety on drug safety, for example, in the United States, and you wouldn't expect people to just be taking drugs that have not gone through clinical trials and a government regulatory agency. And you cannot just go to a company and say, "I'll be part of your clinical trial," unless there's been some approval for that. Otherwise, their drug would not be accepted by the government. But yet we've heard that there were these experiments that were done without any government imprimatur. We have no idea what the safety controls were in those experiments or how far along in the lifecycle of the child that was born that we have to investigate. So I think safety is very important, and any society has to set up the standards of safety before they do any kind of test.

### Moderator
Claim: We have time for one more question. I said I'd get back to you. Make it great.

### Moderator
Claim: My name is Kate McCloud If we permit this technology, it sounds very expensive to me, so who will it be available to, and who will be restricted from having access to the technology?

### Moderator
Claim: Sheldon Krimsky, do you want to take that on your side? I'm going to go to the other side, as well. Or Robert?

### Conspiracy Advocate (CA)
Claim: Well, let me speak for the other side, because-- because, actually, poor things, I think they need a bit of support. Actually-- There really-- there really is an issue. You're quite right, this technology is expensive, it would cost tens of thousands of dollars, perhaps even-- maybe even $100,000 to start with. But actually caring for a child that's got a serious genetic disorder is far more expensive. And, of course, the expense of that care is not only the expense, the money, but also the tragedy, the distress, the pain, and all the rest of it. So I think we have to be careful and cautious about the financial arguments, and I'm sure that Lee and Nita would agree with me.

### Scientific Advocate (SA)
Claim: You spoke for me.

### Scientific Advocate (SA)
Claim: We're so glad we've convinced you to join our side.

### Scientific Advocate (SA)
Claim: Technology start out being very expensive become more optimized over time and become cheap. Everybody thought computer technology was too expensive 20 or 30 years ago and now everybody has computers on their desk.

## Round 3

### Moderator
Claim: And that concludes Round 2 of this Intelligence Squared U.S. debate, where our motion is, "Prohibit genetically engineered babies." And now you are about to hear brief closing statements from each debater in turn. They will be two minutes each and these are their last chances to change your mind. Remember you were asked to vote once before the arguments and you'll be asked to vote immediately afterwards, and then we'll very quickly have the results.

On to Round 3, closing statements. Our motion is "prohibit genetically engineered babies," and here to summarize his position against the motion, Lee Silver, he is professor of molecular biology at Princeton and author of the book "Challenging Nature."

### Scientific Advocate (SA)
Claim: A friend of mine here was introduced to me by another friend of mine here, who had a baby with a sperm donor, I met her in 2009. And a few days after her child's birth she got a call from her doctor, who told her to go into the bedroom to check on her sleeping baby to see if he was still alive. The baby had been born with MCAD deficiency; he had inherited this mutation from both my friend and the sperm donor who contributed to the conception. And the mutation was in her genome, and it had been in the genome of her family for hundreds of years, at least, and it was silent; nobody knew about this mutation.

With a particular dietary plan, my friend's son is now a healthy five-year-old boy, happy ending to that story. And she and her wife decided to have another child with a sperm donor. So they went to the sperm bank and tested the new donor that they were going to use for mutations in the MCAD gene, and they found the donor was free of mutations in the MCAD gene, which the genetic counselor said should ease her mind. But, in fact, that shouldn't have eased her mind, because MCAD is just one of the hundreds of mutations that she actually has in her genome, so even if the sperm donor had not had MCAD mutation, it's just as possible that he had another mutation that was not compatible with her DNA.

So that's the important point that I want to make here that is very important for all of us to remember: there's no perfect baby, there's no perfect person, there's no perfect genome, there's no one human genome. We are all just a combination of many different genetic variants that makes us different from each other for better and for worse.

### Moderator
Claim: Thank you, Lee Silver. The motion is, "Prohibit genetically engineered babies," and here to summarize his position in support of prohibition, Sheldon Krimsky. He is a professor at Tufts University and chair of the Council for Responsible Genetics.

### Conspiracy Advocate (CA)
Claim: So it is perfectly understandable why parents would want to provide as much enrichment to their child as possible to ensure their success in life. But prenatal genetic engineering is not enrichment of a newborn, it is an effort to redesign the human genome. Science has succeeded in applying genetic modification for enhancement to animals and crops, some would say successfully, others would say the jury is still out.

But in the hundreds and thousands of trials that failed. We simply discard the results of the unwanted crop or animal. Is this the model that civilized humane society wishes to apply to humans? Make pinpoint genetic alterations in the human germ plasm and discard the results when they don't work out. It is sheer hubris to think that manipulating the human germ plasm for enhancement will not produce mistakes. Under our current laws and civil morality, society must bear the expense to care for my severely disabled individual produce the reproductive genetic engineering.

I'll leave you with one story. A little over ten years ago, scientists discovered that by modifying a mouse's gene, it greatly improved the mouse's memory. Subsequently, they also learned that modification produced a mouse that increased sensitivity to pain. I want to say a word about the mitochondrial disease problem. Some decisions appear ethical from a pinpoint perspective, but they're clearly unethical from a wider lens. For this, we have to look at the wider lens of genetic engineering and not at the pinpoint perspective in order to understand its ethics to society. Thank you.

### Moderator
Claim: Thank you, Sheldon Krimsky. Our motion is, prohibit genetically engineered babies. And here to summarize their position against this motion, against prohibition, Nita Farahany. She is a professor at Duke Law and a reach professor at Duke's Institute for Genome Sciences and Policy.

### Scientific Advocate (SA)
Claim: This debate is quite personal to me, and I'd like to share why with you. In 2001, I attended the wedding of a dear friend. Two years later, she developed thyroid cancer, and she underwent radioactive iodine treatment. The next year, when she and her husband started to try to have children, she learned that she had substantial mitochondrial abnormalities that she would pass on to each and every one of her children. She underwent mitochondrial transfer and now has a beautiful and healthy son, made possible by this technology. We don't know if the radioactive iodine caused those abnormalities. What we do know is that she now has a child-- healthy, active and bright-- from a technology that is available, and we have already used.

In 2010, I also received radioactive iodine therapy for thyroid cancer. When I'm ready to have children, I hope that I also have the option of having a healthy child with whatever the best technology is that we have available to us today. I'm not here to defend every type of genetic engineering. And I don't think we're ready as a society to embrace it all. But we already know that there are certain forms of genetic engineering that are safe and effective to use. And what I urge you to do is vote against the resolution, to vote in favor of scientific progress, to vote to enable each of us as private citizens to make private choices and the most intimate choice we will ever make in life, to bring healthy children into this world. Thank you.

### Moderator
Claim: Thanks Nita Farahany. Our motion is, prohibit genetically engineered babies. And here to summaries his position in support of the motion to prohibit, Robert Winston. He is a professor of science and society and emeritus professor of fertility studies at Imperial College London.

### Conspiracy Advocate (CA)
Claim: Ladies and gentlemen, don't be seduced by a single, very heartrending story. That is really not at issue here. There's a big issue for the whole of our society and for people in general. I regret to say that I'm saddened to see the simplistic argument about mitochondrial DNA from the other side. We don't understand the interactions with the mitochondria. And already we've seen a number of horrid mishaps. So, of course, maybe a particular individual was lucky, but they might have been unlucky. How different we would have been then. We heard that people have a right to have a healthy child. Of course, they don't have a right, sadly, to have a healthy child. What we do have a right to, though, in a democratic society, surely, is to have access to the best and the safest treatment. And at the moment, the safest treatment is certainly not meddling with the genome. It is not meddling with the mitochondrial DNA.

It is actually to look at every other way of dealing with these terrible diseases. We're not ready for it. Of course, at the moment, I have no doubt it shall be banned. Bans can always be lifted if there's more research done to show that it is worth doing. And it's worth bearing in mind too that we're not going to eradicate genetic defects by doing this, not remotely. New defects occur all the time as Lee Silver rightly points out. All of us have defective DNA. 30 percent of boys born with the male form of muscular dystrophy have this as a new mutation, as he well knows. No amount of pre- implantation diagnosis will have changed that. It is a particular problem. And that is always going to be the issue here. The question is how we deal with these diseases actually when we have them.

And finally, can I just say, on a very personal note, it really is-- and I don't mean this patronizingly. It's wonderful to see young people in the audience, and it's great to see you here. Thank you very much for sitting so patiently during these arguments. What I think is important to understand is that this technology is something that you will have to deal with in time. And I--

### Moderator
Claim: Thank you, Robert Winston. I'm sorry. Your time is up.

### Conspiracy Advocate (CA)
Claim: I hope-- I hope they show the same responsibility that we're trying to show this evening.

### Moderator
Claim: Thank you, Robert Winston. And that concludes our closing statements. And now it is time to learn which side you feel has argued the best. We're going to ask you again now to go to the key pads at your seat that will register your vote. And we will get this readout almost instantaneously. Remember, the motion is, prohibit genetically engineered babies. If you agree with the motion, if that means if you agree with the prohibition of it, push number one. And if you disagree, push number two. And if you remain or became undecided, push number three.

And, as I said before, you can ignore the other keys, and you can correct an incorrectly keyed vote just by pressing the right one, and it'll register your last vote. And we're going to have the results probably in about 120 seconds from now.

So I want to say that this has been a spectacularly-- spectacularly well-argued debate by both sides. I just want to invite a round of applause for them for what they did. And there are a lot of debates where I actually reject a lot of questions. There wasn't one bad one tonight at all. I just want to thank everybody in the audience for great questions that you brought up. We would love to have you Tweet about the debate. As I said before, use the Twitter handle @IQ2US. Our hashtag for this debate was #designerbabies.

Our next one comes up on Wednesday, March 13th. The motion will be "America doesn’t need a strong dollar policy." Our debaters arguing this motion, Steve Forbes. He is the chairman and editor in chief of Forbes Media. His partner will be James Grant, editor and founder of the Financial Markets Journal, Grant's Interest Rate Observer. Tickets for our-- that season are available through our website, www.IQ2U.S..org.

Their opponents, by the way, are-- one card out of my hand-- Frederick Mishkin. He is a former member of the board of governors of the Federal Reserve. And his partner arguing for the motion will be John Taylor who is the chairman and founder of FedEx-- FX Concepts, one of the largest currency hedge funds, not FedEx.

For those of you who can't join the live audience, of course there are a lot of other ways to watch this debate. Those of you watching live stream on fora.tv know about that, but you can also listen to these debates on NPR or watch them on PBS stations across the country. Check your local listings for air times and dates.

Just a very few-- very small biographical facts about our panelists tonight, though, I didn't get to share. I was able to tell you about the two guys on the end living in the same apartment building. I did not share Robert Winston is actually-- he's been made a peer for his work in the U.K. He actually is known as Lord Winston. And it was at his insistence that we dropped that tonight, because he was over here in the colonies. But actually we had a conference call with him last week. He was in the House of Lords. And he said, "I've got to run. I'll call you back in ten minutes. I've got to go vote." So that was-- that was a lot of fun. And Nita Farahany, she doesn't want me to say this, but when she graduated from high school, she was the National Forensic Society's single best national debater in the country. she more or less begged me not to tell you that, so we have the queen of debaters and the lord of-- All right. We now have the final results in. Remember, you voted twice: before the debate and again after hearing the arguments. The team that changes the most minds will be declared our winner. The motion is, "Prohibit genetically engineered babies." Let's look at the results. For the team that was arguing for this motion to prohibit, before the debate, 24 percent agreed, 30 percent were against, and 46 percent were divided. That was the preliminary vote for everybody. Those are the first results. Now let's look at the vote that the team arguing for the motion received in the second vote.

The team arguing for the motion, the second vote is 41 percent. That's an increase of 17 percent. That is the number that the other team needs to beat. It needs to beat 17 percent. Let's see how the other team did. Before, they were 30 percent. They went up to 49 percent. That's a 19 percent difference. They just pushed by. The team arguing against prohibition of genetically engineered babies carries this debate. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
