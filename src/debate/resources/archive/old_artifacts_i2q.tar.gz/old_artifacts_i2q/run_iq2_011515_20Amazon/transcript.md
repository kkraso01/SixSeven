# Debate Transcript

Topic: Amazon Is The Reader's Friend
Motion: Amazon Is The Reader's Friend

Debate ID: 011515%20Amazon


## Round 1

### Moderator
Claim: So, let's now please welcome to the stage the chairman of Intelligence Squared U.S., Mr. Robert Rosenkranz. Hi Bob.

### Moderator
Claim: Good evening, John.

### Moderator
Claim: So, Amazon's been around now 21 years or so, and we're getting to this debate now. What's-- give us a sense of what's at stake in this one.

### Moderator
Claim: Well, it's more current than you might think. I was reading an op-ed in the Wall Street Journal yesterday. And the headline was about an economics textbook, one of the most popular ones that kids are required to buy. You know what the publisher's price is, $360.

### Moderator
Claim: Wow.

### Moderator
Claim: And--

### Moderator
Claim: Must be a really good book.

### Moderator
Claim: I glanced through it. Most of it's wrong.

But that said, you can buy it on Amazon for a discount, pay $292, or you can rent it for a semester from Amazon for $24, so I'd say in that case I think Amazon is the reader's friend.

### Moderator
Claim: I mean, if it's put in pricing terms, it does seem that Amazon is the reader's friend, that it's obvious, that there is no debate in that sense. So, what it-- what is there to debate about on this?

### Moderator
Claim: Well, I think this debate is sort of about first and second order effects. Right now it feels fine to be a reader to have the choice and-- that Amazon offers. But we're in a process where ultimately Amazon has a lot of power, and it affects authors, it affects writers, it affects publishers, and ultimately maybe affects readers in a way that's not obvious right at the moment.

### Moderator
Claim: But Amazon has power also in appliances, and they're putting pressure on the appliance store business. Why focus on books and reading?

### Moderator
Claim: Well, because books are so important to our culture. I mean, they represent our intellectual life, our creative life, our cultural continuity. It's just-- it's very different from other kinds of commodities, and frankly the people who write books and are interested in books are a lot more articulate than the people who make appliances for a living.

### Moderator
Claim: So, books are not widgets.

### Moderator
Claim: They are not.

### Moderator
Claim: All right, well, we've got some-- I don't want to say, "widget makers"-- we've got some writers coming to the stage tonight. All of our debaters are writers. They're passionate about this but very, very divided. Let's thank Bob Rosenkranz and welcome our debaters to the stage.

Welcome. Throughout the evening, because we ultimately turn this debate into a podcast and a radio broadcast, I have to take various breaks. But I don't really take a break. I don't go anywhere. I say, "We'll be right back," and you'll notice that I'm still here.

So, I want to explain that I'll be doing that and that a number of times I'll say things over and over again like, "My name is John Donvan." It's not because I forgot.

It's because we're coming back from a radio break. And when those moments come, it would be wonderful if I could sort of subtly prompt you to a moment of spontaneous applause--

--such as this, if you could do that.

That'll help us begin. Welcome to Intelligence Squared U.S.

I'm John Donvan. And, wow, that Gutenberg guy, 1455, he churns out a Bible with moveable type. And how would that be described if it were today? Well, we would say that Gutenberg was really rocking the religious content space with a platform of innovation and disruption, putting the whole God brand in front of a whole lot more sticky eyeballs for scripture.

Pardon my buzzwords, please. But now comes Amazon and is that perhaps as historic, one-click shopping, eBooks. Disruptive? Amazon could very well drive traditional publishers and brick and mortar bookstores completely out of the book space. And is that a good thing or a bad thing? Well, that sounds like the makings of a debate. So, let's have it, "Yes," or, "No," to this statement, "Amazon is the Reader’s Friend," a debate from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters. They are all writers and book lovers, but they are deeply divided on this issue and are arguing two against two over Amazon being the reader's friend.

As always, our debate goes in three rounds, and then our live audience here in New York votes to choose the winner. And only one side wins. Let's meet our debaters. Please, ladies and gentlemen, welcome to the stage Joe Konrath.

Joe, you are an author known for your bestselling thrillers. You are also one of the leaders and biggest advocates in the field of self-publishing. You did the traditional book publishing route but your real success, and that means millions of books that you've sold, came after you decided to self-publish with Amazon. How did readers find you?

### Conspiracy Advocate (CA)
Claim: Well, I hope they find me entertaining.

### Moderator
Claim: I hope we'll find you entertaining as well tonight. Joe Konrath, who is your partner?

### Conspiracy Advocate (CA)
Claim: My partner is the wonderful, the drop-dead sexy editor at Vox, Matthew Yglesias.

### Moderator
Claim: Ladies and gentlemen, please welcome Matthew Yglesias.

Matthew is also arguing for the motion that Amazon is the reader's friend. You are, as just mentioned, executive director-- executive editor at Vox.com. You write a lot about economics and business and politics. You wrote a book called, "The Rent Is Too Damn High," and you come from a family of writers, novelists, in fact. Your father, your grandparents, your brother. Are they on your side in this debate?

### Conspiracy Advocate (CA)
Claim: Well, my father happens to be here live, so I'd like to think he's voting strategically and sort of rigging the grade in my favor.

### Moderator
Claim: All right. Well, we're going to have to check on his vote later on, but let's welcome this team to the stage arguing for the motion.

But we have two writers arguing against the motion Amazon is the Reader's Friend. First please let's welcome Franklin Foer.

Author of a book about globalization called "How Soccer Explains the World" and until recently editor of the New Republic.

That's a different debate we'll have another time.

In the October issue of the New Republic you actually wrote that cover story and the title you gave that cover story happens to sum up a lot of your feelings about this debate topic. Can you tell the audience what that title was?

### Scientific Advocate (SA)
Claim: It might be a touch obtuse for my opponents, but it was called "Amazon Must Be Stopped."

### Moderator
Claim: Subtle. And your partner is?

### Scientific Advocate (SA)
Claim: Well, he's the author of "Presumed Innocent," and tonight you should presume him correct, Scott Turow.

### Moderator
Claim: Ladies and gentlemen, Scott Turow.

Scott Turow, you are also arguing against the motion that Amazon is the Reader's Friend. You're past president of the Authors Guild and, as mentioned, written a lot of best sellers a lot of us have heard of, and not just because they turned into movies, but a lot of them have.

You have been criticizing Amazon in the past, particularly in its 2014 struggle with Hachette Publishing. Hachette, you worked for-- Hachette through Grand Central Publishing has published your books. We just want to get that out there. But all of this - - does this mean that you are not a member of Amazon Prime?

### Scientific Advocate (SA)
Claim: No. I am a member of Amazon Prime.

But I refuse to buy anything from Amazon during the course of the Hachette/Amazon brouhaha and for many years now and it continues. I refuse to buy books from Amazon.

### Moderator
Claim: Point of principle?

### Scientific Advocate (SA)
Claim: I would call it patriotism.

### Moderator
Claim: All right. Ladies and gentlemen, Scott Turow and the team arguing against the motion--

--that Amazon is the Reader's Friend. Now this is a debate. There will be one team winning and one team losing and that decision is made by our live audience here in New York. By the time the debate has ended you will have been asked to vote two times, once before the debate and once again after the debate.

And the winning team is that whose numbers have changed the most in percentage point terms between the first vote and the second vote. So, let's lodge in that first vote. Let's register that first vote. If you go to the keypads at your seat you'll see that there's numbers one through zero. That makes no sense. One through nine and zero and you only have to pay attention to one, two, and three. If you agree with the motion push number one. If you're with this side, push number one, the side that's arguing that Amazon is the Reader's Friend. If you're against push number two, and if you're undecided push number three. You can ignore those other keys. They're not live. And if you made the wrong choice, pushed the wrong button, just correct yourself and the system will lock in your last vote. And again, I'll say this one more time and a few more times, it's the team whose numbers have changed the most between now and the end of the debate when you vote the second time that will be declared our winner. Let's move on to round one. Round one, opening statements by each debater in turn.

Our motion is this: Amazon is the Reader's Friend. And here to argue first in support of this motion Matt Yglesias. He is executive editor of Vox.com. He is the author of the book "The Rent Is Too Damn High." Ladies and gentlemen, Matt Yglesias.

### Conspiracy Advocate (CA)
Claim: Amazon is the reader's friend. In the long-term obviously readers are only going to thrive in a world where author's also thrive and I suspect we're going to spend a lot of time eventually talking about the impact, the long-run impact of Amazon on authors and authorship. And my partner is going to be able to speak to a lot of that in a great deal of detail, more depth than I possibly can. But I write about economics. I'm a pretty literal person. So, I’m going to keep it a little bit on the surface level-- Amazon is the Reader's Friend. And I think you can see that Amazon is the reader's friend, by just asking, why are we debating this at all? Why is this a subject of controversy? It's a subject of controversy because Amazon is really big.

It's a big company. It's a powerful company. They have 41 percent of all books sold-- I saw a statistic from last March-- and 67 percent of all digital books. That's big. That's a big power player. It's worth talking about. And it naturally raises the question, you know, how did the company get so big. How did they have so much market share? Why are they so dominant? My argument is, they're so dominant in this space because they're the reader's friend. Who buys books? It's readers. Amazon sells books to the vast majority of readers because it's good for readers. Another argument-- you know, Frank has written that Amazon is some kind of a monopoly, some kind of an abusive force that's dominating the marketplace, maybe through nefarious means, something like that. Some strategy other than being a reader's friend. And I think that that's just not true, this idea that Amazon must be stopped by some kind of external force. It doesn't hold up, because the fact of the matter is even though Amazon has an extremely large share of the market, it faces a ton of competition. I don't know about you guys, but I'm the owner of an iPhone.

I bet a lot of people in the audience may be-- may be iPhone users. Yes? No? Yes. Yes?

Maybe-- maybe some of you have a Google, an Android phone, something like that, yeah? Yeah. So, some people have Smartphones. It turns out these phones, they're directed-- they're connected directly to digital stores. You can go on iBooks on your iPhone. You can go to the Google Play store on your Android. And you can find “How Soccer Explains the World.” You can find-- Frank edited a book called "Jewish Jocks" that I've been meaning to check out since I was in a debate in San Francisco with his co- editor. And I actually-- I picked it up on my phone on the train. You can find-- I'm not sure if it's every Scott Turow novel, but a great deal of them. They're there in the Google store. They're there in the Apple store. These are companies that are competing with Amazon.

And they're not, like-- these are not small, weak, pathetic, helpless companies, right? They're actually bigger than Amazon. Amazon is not going to drive Apple out of business. They're not going to drive Google out of business. What they are doing is beating them badly in the electronic book space. They're selling way more books than those companies. So, how is it that they're doing that? Did they do something sneaky? No. They have a better product, right? You can get Apple, Google on your phone. You get them on your tablet. But it's Amazon who invested in creating the Kindle, which is a digital device that's really meant for reading, you know? I like to read books sometimes on my iPad. It's fun. But my wife, she's got a Kindle Paperwhite, and she loves it. And I've been known to borrow it, because it-- it really is a better device for reading books on than what these other companies do. They've also got a superior piece of software. If you download a Kindle book, you can read it on your Kindle, but you can also use the Kindle app on an iPhone, on an Android tablet.

You can read it on the Web. Apple and Google, they both want to make more exclusive, more locked-down platforms that don't give you as much flexibility. And that's fine. Different companies have different strategies. But normally, in a market, if you were going to offer an inferior product, you would try to beat your competitors on price. But Apple and Google don't do that either. In fact, Apple tried to team up with book publishers to make prices higher. So, it becomes pretty natural, you know? Amazon has this market share because they have a better product, a better product than their digital competitors. And if you compare it to their brick and mortar competitors, you know, there's no-- there's no competition. It's cheaper to get digital books. It's much more convenient to get digital books. It's much more flexible. You can take them along when you're traveling. And Amazon also has a store where if you're looking for something-- you know, you put it in there. And if it doesn't exist in a digital form, you can order the paper book, right? That's really neat. It's a good convenience, because when there's something you want to read, you know, you really want to get the text that you want. You don't care as much about the format.

The other digital companies don't do that. All of which is you know, it's a long way of getting to the point, but it's to say that Amazon has won its market share the best possible way to win market share. It's by doing a better job, offering a better service at a better price. Long story short, they're the reader's friend, you know? So, we're debating this in New York City. New York is a great city. I know New York very well. I grew up here. I grew up on 12th Street and University Place, down in the Village. And I remember, when I was a kid, right in the neighborhood, you know, you could go to Broadway. There was a Shakespeare and Company down maybe on 4th Street. There was a Forbidden Planet, which had comic books and specialty sci-fi books. You have the Strand, which is this fantastic used bookstore. We had I think it was the original outlet of Barnes & Noble over a few blocks further north from there. And, of course, you also have here in New York probably the greatest public library system in the world. This is like part of what makes New York an amazing place.

But it's important when you're thinking about this issue to not think with these sort of narrow New York blinders on and to recall that you know lots of people live in places that are not as big, places that do not have as many-- did not traditionally have as much diversity in terms of book retailing, where you might be talking about a lengthy drive to one bookstore, a limited selection that's there, a library that, you know, maybe has some capacity to get loans from other places, but, again, it had its own kind of constraints. What you have in the digital space, it's this vast stockpile, you can get any kind of book you want. You can go get public domain books, download them for free off Amazon. And this is a-- really like an incredible bounty. I think there's a red herring out there that on one side of this debate is people who love Amazon and on the other side of the debate are people who think books are an important cultural artifact. Culture matters. Books are crucial to our society. And that's exactly why it is so important that Amazon has made it cheaper, easier, and more convenient for people all around the country and in a growing number of countries, to access these crucial cultural artifacts.

Books aren't widgets. Books matter. And that's why it's so important that you recognize that Amazon truly is the reader's friend and vote for this resolution. Thank you.

### Moderator
Claim: Thank you, Matt Yglesias.

And that's our motion, "Amazon is the Reader's Friend." And our next debater will be arguing against it, Scott Turow. Scott Turow is an attorney and author of 12 books, including his newest novel, "Identical." Ladies and gentlemen, Scott Turow.

### Scientific Advocate (SA)
Claim: Well, I listened to Matt carefully, and I want to begin with a major concession. He is not totally insane. The-- he is right, of course, about certain things. Amazon charges low prices. Amazon has built a better mousetrap. Their software is great. But that's really not here-- all that we're here to talk about.

The question isn't whether Jeff Bezos bears some faint resemblance to Lex Luthor. The question is whether Amazon is the reader's friend. And in defining that-- or I'd like to be a little lawyerly, I'd like to talk about two things and focus on two words. The first, of course, is "reader's," because readers are more than mere consumers. We agree that books are more than widgets. They bear our culture, thought, knowledge with them. And as Frank Foer is going to talk about when he comes to the podium, Amazon is doing great damage to our literary culture. The second word and perhaps one I want to focus on most is the word, "friend." "Friend," as we commonly understand the term, means somebody you can rely on to treat your interests as equal to their own.

And instead what the record demonstrates is that Amazon is nobody's friend but Amazon's. They are capitalists of a particularly ruthless breed who, in point of fact, have habitually turned on their business allies whenever it meets their business needs. And, in point of fact, Matt, they are beginning to do this now to readers. Matt concedes that Amazon has a huge market share. I don't-- even sort of waving your hands and saying that I don't think does full justice to the magnitude of the power Amazon currently exerts. They sell three-fourths of the physical books that get sold in this country online. They sell at least that many eBooks, especially when you count the market that's starting to grow where Joe is-- has been so successful, that is to say, "self-published" authors.

There are parts of the book market that Amazon literally just owns. They have bought up the two largest producers of audio books. They bought the biggest seller of used and rare books, of books sold to the international market, of print on demand books, of self- published-- physical self-published books, and, of course, they've swallowed up sites like GoodReads, or, BookFinder, that might have become competitors to them, another place where readers could have bought books. Now, to Matt I have to say that anybody who believes that Amazon will use this power only in friendship has not read Lord Acton or Machiavelli.

Amazon already pushes books forward on their site at the expense of others for business purposes, or worse, for political purposes, and their tactics vary between the ruthless to the underhanded. Is Amazon being the reader's friend, Matt, when they alter search results in exchange for promotional payments without acknowledging to their readers that they do that? Or consider the subject you talked about, the chokehold that Amazon got on eBooks with the introduction of the Kindle in 2007. First-- and the only innovation in the Kindle, by the way, was not the device. It wasn't e-ink. All-- it wasn't digital books. All of those had existed. The innovation was when Amazon convinced the publishers to allow digital books, eBooks, to be sold at the same time that hardcovers went on the sale-- went on sale.

The publishers agreed, and as soon as they did that, friendly Amazon backstabbed the publishers and began selling eBooks at a loss of $3 to $4 apiece on average. Now, people like to say that Amazon sold eBooks at a loss to promote the sale of the Kindle. That frankly is bologna. If you want to promote Kindles, sell them at a loss. Amazon sold eBooks at a loss for two reasons, to stifle competition-- they wanted to prevent anybody else, competing device makers, places like bookstores, which would've been a great place to buy eBooks-- they wanted to prevent them from going into the market in competition with them. They artificially-- the second thing they did by selling at a loss is they tilted the market away from physical books, the books published by the publishers who had gone into this business with them, and, of course, in the process, put businesses like Borders, not to mention thousands of bookstores, out of business.

And this loss selling was not honest free-market competition on a level playing field. It was frankly a mugging sponsored by Wall Street. For 20 years since the company was established, Wall Street has given Amazon unlimited capital, clearly with the expectation that even though the company didn't report a profit, sooner or later they would reap the immense profits that are bound to come from knocking all the competition aside. Then last year, Amazon-- Wall Street finally became concerned. When is this company ever going to make a profit? The Amazon share price slid by 25 percent, and Amazon reacted by squeezing its suppliers, which is to say publishers and authors, and, of course, readers. This is what led to the dispute between Hachette and Amazon where Amazon punished not only the company but also Hachette authors by subverting the sale of Hachette books.

They disserved authors like Joe, self-published authors, by starting a subscription series that undercut the income of authors like Joe, who's admitted that in print. And finally, of course, Amazon started raising book prices. The company that announced in 2001 it would sell any book over $20 at a 30 percent discount no longer adheres to that practice.

All right.

Thank you.

### Moderator
Claim: Scott Turow, I'm sorry, your time is up.

### Scientific Advocate (SA)
Claim: All right.

### Moderator
Claim: Thank you very much.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: And a reminder of what's going on, we are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan, the moderator, and we have four debaters, two against two, arguing it out over this motion, "Amazon is the reader's friend."We have heard from the first two debaters, and now on to the third. Let's please welcome to the lectern Joe Konrath. He is author of the bestselling "Jack Daniels" thriller series that has sold over a million eBooks through self-publishing.

Joe Konrath.

### Conspiracy Advocate (CA)
Claim: Wow, I am so happy to be here, and I'm glad you're all seated after listening to Scott's monologue because he just proved that Amazon is engaging in nefarious acts of capitalism.

I'm smiling right now-- seriously, what the heck am I doing on this panel? We've got two journalists on this panel. We've got a lawyer on this panel. We've got a lawyer on this panel who did what all the lawyers wish they could do. He actually saved an innocent man from death row. He did.

Okay. That's enough. His head is big enough. Innocent man from death row. These guys went to Harvard. They went to Stanford.

They went to Columbia University. I went to Columbia College.

It is not affiliated. I majored in Budweiser. And you think oh, that's a blow off major, but I still only got a 2.2 GPA.

You know what, that may have been a 2.2 blood alcohol level.

I couldn't remember the finals at all. I'm telling you. But I am very happy to be up here and I'm going to keep smiling because I really can't believe that I am here. Who's seen the movie "The Paper Chase"? It's about a Harvard law student working his butt off, taking classes, studying to actually become a big lawyer, and Scott actually did that. And when I went to school I was in my dorm making a sofa out of empty beer cans.

So why am I here? I don't know why I'm here.

Okay, I've sold some books. Okay, I like Amazon. By a show of hands, how many people here have bought something from Amazon? Okay.

### Moderator
Claim: Let's tell our listeners that that's everybody in the room.

### Conspiracy Advocate (CA)
Claim: That is everybody in the room. By a show of hands, how many people hate raising their hands?

That's meta. You're going to laugh about that later. Let's get on topic here. Scott brought up publishers. Amazon is the big bad guy, but what about these publishers? Well, you know what? Publishers are the bad guy and I'm going to tell you why. He said earlier we need publishers for culture, for rich literary culture. That's incorrect. Publishers don't write books. Authors write the books. Authors are the ones who impart this rich literary culture. The publishers are just high-priced middle men, okay? Let's talk about publishers and all of the books they have rejected.

Publishers reject hundreds of books for everyone that they publish. Now think about that. That's censorship. It really is. There are thousands of books out there that you have never seen because the guardians of culture, those publishers, have never published them. Nine of them were mine.

I got more than 500 rejections. Yeah, I know, every time the mailman came I had to pop a Prozac.

I eventually did get published after my 10th book and then I learned more about publishers. I learned that publishers charge too much. Scott's new book, which I'm sure is excellent, the publisher nicely printed the price right on the cover, $28.00 for a hardcover. Wow, 28 bucks. If you can't afford that and you're a huge Turow fan you can wait a year and get the cheaper priced paperback.

That's called windowing. That doesn't seem like publishers are really friends to readers. They would give them that paperback earlier because the paperback vastly outsells the hardcover. Publishers give out advances. They give an author an advance. Now, I got a nice advance according to Publisher's Weekly, $30,000 bucks and I was pleased to get it and I felt I was really lucky because the average advance is $5,000. You're not going to live off $5,000, especially since publishers pay you that over the course of three years. In small payments twice a year, because publishers only pay twice a year. It-- a word on advances before I get off that topic, an advance has to be paid back in copies sold, okay? And it's a very high interest loan.

If I self-publish on Amazon, which I have done successfully many times, in fact since I started self-publishing on Amazon, my income went up 20 percent. Oh no wait. That's wrong. It went up 20 times.

So it went up 2,000 percent. My best year traditionally published I made 50 grand. Last year I made a million dollars. That's still 50 grand after taxes.

What it comes down to is publishers are deciding what you read and what you won't read. They decide how you get it and how much you pay for it and they have that much power because they are a cartel. They are a form of monopoly called an oligopoly. The top five publishers control 80 percent of all the print books. As a writer, if I want to get into a bookstore, I have to go through those publishers. And they don't have to pay me anything, because there are 10 guys behind me who want my spot.

Amazon looked at this market and they decided publishers weren't reader's friends. So, they innovated. They opened the world's biggest bookstore with the best customer service. They invented the e-book reader that everybody wants, along with the app that everybody wants. They gave all authors a chance to reach readers. So, my nine books that sat on a shelf finally got out there and reached readers. And I guess readers like them, because I sold a million of them.

In other words, Amazon looked at all the things publishers were doing wrong and then they did them right. And rather than try to compete, the publishers colluded and price- fixed to raise prices. We'll talk more about that a little later. This debate is not about Amazon being the writer's friend, though. I can give you examples that they are, but that's not what this is about. It's not about Amazon being the publisher's friend. That's not this debate.

It's not about Amazon being a monopoly. That's not the debate. It is about Amazon being the reader's friend. Amazon isn't perfect. No person is. No company is. But let me tell you something. If Amazon right now were building a death machine that was fueled by the screams of puppies-- it still wouldn't matter because they're still a friend to readers. Thank you.

### Moderator
Claim: Joe Konrath, your time is up. Thank you very much.

And our motion is Amazon is the Reader's Friend. And here to debate against that motion, Franklin Foer. He is the former editor of the New Republic, author of the book "How Soccer Explains the World: An Unlikely Theory of Globalization"-- ladies and gentlemen, Frank Foer.

### Scientific Advocate (SA)
Claim: Well, I'm feeling real good about the literary future right now. Listening to these guys come out here and talk in such fawning, slavish terms about a corporation.

Amazon is a company. They are not-- they are not pursuing the greater good. They're not pursuing cultural greatness. They are a company out to make a bunch of money. They have done this extremely well. They produce things at very low prices. They have technologically innovated all over the place. I use Amazon. You use Amazon. And there isn't anything wrong about that. The problem is this-- it's that they have done it extremely well. And-- and a company can perform at a very high level, and in turn, obtain a monopoly. They can be the only player. Matt says they aren't a monopoly. But when you control 70 percent of a market, that, historically, counts as a monopoly. In the old days, it-- before-- before the Reagan Revolution, before the Chicago School of Economics trashed anti-trust law, our authorities used to get upset when companies controlled 10 percent of any given market.

Not 70 percent-- nearly 70 percent of any given market. But this is different. This is books. This is about our crown intellectual jewels. This is about the thing that we should care most about in the world, because it's about imagination. It's about understanding our past. It's about rooting out people in power. And when you have one company that sits there, and is the chokehold for books, that becomes a problem. It may not be a problem just now, but it will become a problem in the future. And it's something that we, as readers, as citizens, as guardians of the book, need to pay incredibly close attention to. Why do I care about this? Well, when I wrote an article about Amazon in the New Republic, what was their immediate response? They yanked ads from the New Republic.

When it-- they were having the dispute with Hachette, the publishing company-- what did they do? Well, they punished the guy who wrote the book about the Koch brothers, but they let Paul Ryan's book go unscathed. They didn't punish him. When a company has that chokehold, when they can decide who wins and who loses in the publishing game, we need to be very, very afraid as citizens. So-- what is Amazon? Amazon is the everything store. Their ambitions are boundless. They name themselves after the largest river in the world. They're making Woody Allen movies-- television shows now. They're selling you your underwear, your socks. They want everything. They want nothing else to be able to breathe on this planet except for their consumers and the people who make their goods. And so that's a very, very dangerous thing, and we've seen this with publishing.

We've seen the way that they've treated book publishers to date. It's not the worst offenses in the world. They're trying to-- whatever. But it's bad, and it portends bad things. They've thrown around their power in order to try to continually squeeze the publishers. Now, I want to just say something in defense of publishers because they've been trashed considerably tonight, and I have a feeling that a lot of this debate will come down to a referendum on book publishing. Yeah, book publishers suck. They're an oligopoly. They're five big publishers. They're not great, but there are going to be a lot less of them because when companies see one big powerful player who controls their market, their natural instinct is to huddle together in safety and to cower. And that's what's happening now. Penguin merges with Random House. Hachette tries to buy Perseus. And that's going to continue in the face of Amazon, and that's going to continue to just squeeze the diversity out of our intellectual space.

Now, what publishers don't do a great job always of picking books, although you have-- when you look at the shelves in your library, you have to say, Norman Mailer, Philip Roth, Zadie Smith, that they've done a pretty good job of picking winners in the past. But that process of picking winners is incredibly important. If you go to Amazon's self- publishing page and you look at the self-published authors, there are thousands of them. And I have no idea which one of them to read. I am too lazy as a reader. I don't have enough time to go read the first chapters of all these books in order to determine what's good. I look to publishers to see that somebody other than the author's mother thinks that the book is worth reading. So they play an important role-- in sifting through the market, which is one great thing that they do. The second thing that they do is that they help authors who are usually introverts and nerds and very bad at self-promotion-- break through in the world.

And, you know, they don't-- they didn't do that for Joe Konrath? Well, you know, shame on them. But they do a good job of that for many, many, many other authors. Now, the most important thing that they do-- and Joe is talking about fiction, which is fine. I think it's a different market than nonfiction. Nonfiction books often involve deep reporting, many trips to the archives. They're very, very expensive to produce. You can't just sit up one day and say, "I'm going to go write a biography of Virginia Woolf." That's expensive. You got to go travel to England. You've got to-- you've got to photocopy things. You know, and in the way that you are able to finance a project like that is by an advance. They are Kickstarter for authors. They pay authors a little bit of money at the beginning of a project which enables them to complete-- to complete that. And I could be wrong here, but I can't even-- I was trying to think if I could think of any self- published nonfiction books that have been successful, any great biographies or histories, and I couldn't do that.

And that stuff is going to suffer in this new world. And so I think in this debate, you are readers. You are the defenders of the book. The presumption here should be that anything that is distantly threatening to the book is something that you should be very, very concerned about. Anything that threatens this wonderful intellectual ecosystem that we have, which is already imperiled in so many different ways, shapes, and forms, needs defenders. It's your obligation here to step up, to send a message to Amazon, and to defend the book. Thank you.

## Round 2

### Moderator
Claim: Thank you, Franklin Foer. And that concludes round one of this Intelligence Squared U.S. Debate, where our motion is, "Amazon is the reader's friend." I'll be right back after this message.

Now on to round two. Round two is where-- I need you to not chuckle during this.

I know, I invited that. Let's start with a round of applause. That'll get it out.

Welcome back to this Intelligence Squared U.S. Debate. Our motion is, "Amazon is the reader's friend." We move now on to round two. Round two is where the debaters address one another directly and take questions from me and you-- from you, our live audience here in New York City. We have two teams debating this motion, "Amazon is the Reader's Friend." We've heard one team, Joe Konrath and Matt Yglesias, argue for the motion. They're saying that Amazon is the reader's friend and that this is blatantly obvious because readers are flocking to Amazon. It's a company that gets more books to more people in more places than any other company in history. They are publishing writers who could not get through the door at a lot of traditional publishers. They represent it as a kind of a freedom from publisher tyranny, and they basically say the bottom line is that Amazon makes a better progress and that the traditional publishers in this story are the bad guys.

The team arguing against the motion, Franklin Foer and Scott Turow, they're saying, "It's all a trap. Amazon is more than halfway on its way to controlling everything in publishing, that Amazon is only Amazon's friend, and that there will be a problem down the road when its chokehold is complete, that this is a company that cares as much about books as it does about socks and blenders, and, more than that, that the company plays dirty. It may be capitalism, but they're playing by rules that are going to harm writers and harm books, and, therefore, harming readers, and, therefore, it can't be the reader's friend." I want to go to the team that is arguing against the motion and put to you basically the frontline argument your opponents are saying as I just stated. Their frontline argument is that readers are flocking to Amazon, and all by itself that answers this question.

They're the reader's friend because readers love it and that they're feeling loved. Frank Foer.

### Scientific Advocate (SA)
Claim: So, one of the things that-- the world of the Internet is a deceptive one. It looks like it's wide open until it's not. But the people who arrive first and establish advantages in that world are the ones who win and win in a major way. It's what happened with Google, it's what happened with Facebook, then it happened with Amazon. They were able to get there first and then build distribution systems, technology. That's very, very hard for other companies to come in and compete with. And so the fact that they've actually produced this product that in some ways is genius for consumers, it's understandable that consumers would flock there, but it also helps explain why they've achieved so much market share. It's very, very hard for anybody to get into this market and compete with them. And the fact that they are the everything store, and the fact that when we do go there we're also buying movies and clothing and food and everything.

It just becomes a matter of convenience for people to buy books there.

### Moderator
Claim: Let's let Matt Yglesias respond to that.

### Conspiracy Advocate (CA)
Claim: So, I think it's just false that Amazon is impossible for new startups to compete with. I think-- I bought these glasses at Warby Parker, which is an online glasses store. I got this suit from Alton Lane, which sells men's clothing online. I actually did get my socks at Amazon.

But you see, I mean, venture capitalists in Silicon Valley are, in fact, willing to back online retail competitors to Amazon because they don't think it has the same kind of network effects as a Google or a Facebook. And you also see-- I mean, I said this in my original point, and I haven't heard it addressed, but eBooks are sold by companies that are not Amazon, by well-financed companies called Google and called Apple. Amazon has market share vis-à-vis those companies not because of a nefarious power but because Google and Apple have not brought forth a better product at a better price.

And that's unfortunate. I mean, I wish that they cared as much about the book market, but it restrains Amazon's ability to raise prices or squeeze consumers or do any of these other terrible things.

### Moderator
Claim: So, Matt, you're saying that it's not true that it's inevitable that Amazon will control everything.

### Conspiracy Advocate (CA)
Claim: Exactly.

### Moderator
Claim: I want to take that to Scott Turow.

### Scientific Advocate (SA)
Claim: Well, I-- the problem with Apple and Google as competitors is that they don't sell physical books. And there's nothing wrong with the Apple software and the iBooks Store. It works as well as Amazon's. I wouldn't say the same thing about Barnes and Noble. But the problem is it's not a book site. There aren't physical books there. They're not a full or a real competitor with Amazon in that sense. And they got into the eBook market because they were unwilling to fully concede the space to Amazon, which is what happens between these big four companies, you know, Microsoft, Amazon, Apple, they nibble at each other's markets.

But they're not there for real.

### Moderator
Claim: Joe Konrath.

### Conspiracy Advocate (CA)
Claim: Well, when did it become necessary for a company to buoy up its competition? I mean, aren't companies supposed to try to beat the competition? Isn't that the point? Can you imagine the CEO of Coca-Cola calling his board meeting, "Well, we're really kicking Pepsi's butt. And, you know, we want to foster competition, so what we're going to do is we are going to send out teams--"

### Moderator
Claim: But, Joe--

### Conspiracy Advocate (CA)
Claim: "-- to beat up everybody who is drinking a Coca-Cola."

### Moderator
Claim: --Joe, in fairness, your opponents are not saying that Amazon should buoy up the competition. They're saying Amazon is so successful that the competition will disappear and that would be a bad thing.

### Conspiracy Advocate (CA)
Claim: And what company does not try to compete and gain as much market share as possible?

### Moderator
Claim: But as they-- you've argue against oligopoly. They're saying that your alternative in oligopoly is a monopoly.

### Conspiracy Advocate (CA)
Claim: Well, look, Scott just said otherwise. He correctly pointed out that Apple was not originally in the book market.

They didn't care as much about books as Amazon did, but when they saw that Amazon was taking over they wanted to move in. This is, again, I mean, this is not like a small mom and pop operation Apple is running. They came in like in a big way. They haven't gained much market share because their product is not quite as good, but if Amazon did any of these horrible things or if book publishers had any confidence in their own ability to market authors around Amazon and say hey, we got this amazing Scott Turow book, why don't you find it on our hugely popular internet store, they could sell them to these people.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: Be the e-retailer.

### Moderator
Claim: Let's go to Frank Foer. Frank Foer.

### Scientific Advocate (SA)
Claim: That's wishful thinking. I mean, it's wishful to imagine that Penguin, Random House is going to re-create e-commerce. Amazon invented e-commerce and they did it very successfully. The problem isn't that they've done it successfully and own the market, the problem is that they use their size to treat the whole economy very badly and there're some good examples of this.

I don't just want to be the publisher, to do business with the publishers and get the most favorable rates from them, they want to destroy them. They call them antediluvian losers with rotary telephones.

They conceived a project called--

### Conspiracy Advocate (CA)
Claim: Yeah, but they kind of are.

### Scientific Advocate (SA)
Claim: There was a project called the Gazelle project--

--they're antediluvian losers and you know what? God bless them. The reason that their commitment to things other than profit-- yes, they are obsessed with profit, but they're also-- they also publish poetry and they publish histories and they publish other things that don't make conventional sense on a balance sheet, because they view their mission as to make money, but also to create and to sustain a book culture. Amazon referred to-- they tried to kill the small publishers in something called The Gazelle Project where they wanted to negotiate with them in a way where they said that the small publishers were a sickly gazelle and they would pounce on them like a cheetah.

### Moderator
Claim: All right. Let's let the defender of the gazelle killer respond.

Joe Konrath.

### Conspiracy Advocate (CA)
Claim: A gazelle to everybody who votes for us. Okay. Talking about your last question monopolies versus the oligopoly and why am I against the oligopoly. The oligopoly wants less choice and higher prices. The monopoly wants more choices and really low prices and what is the topic of this debate? Is Amazon the friend to readers? Well, what do you want? Higher prices? Less choices? Lower prices? More choices? It's pretty simple.

### Scientific Advocate (SA)
Claim: Well, Joe, first of all the monopoly sells the products, that is books, made by the oligopoly.

### Conspiracy Advocate (CA)
Claim: No, they're made by authors, Scott.

### Scientific Advocate (SA)
Claim: But the problem, the problem is that the monopoly wants to put the oligopoly out of business. Publishers are of no benefit to Amazon and they are doing their best to slowly squeeze them to death.

### Conspiracy Advocate (CA)
Claim: And that bothers you because you've made a lot of money with these publishers, and I understand that.

### Scientific Advocate (SA)
Claim: Because you haven't.

### Scientific Advocate (SA)
Claim: No, no.

### Moderator
Claim: I'm not sure you're going to want to go down that road.

### Scientific Advocate (SA)
Claim: I'm not speaking for me here.

### Moderator
Claim: Joe.

### Scientific Advocate (SA)
Claim: I'm not speaking for me. I'm--

### Moderator
Claim: Let Scott finish his point.

### Scientific Advocate (SA)
Claim: There are books that cannot be written in the Amazon self-publishing model, nonfiction that Frank talked about takes years to write and it does require the support and investment of a publisher. Donna Tartt's "The Goldfinch," a wonderful novel. You and I talked about that on the radio this morning. It took 10 years to write and it has to have the patronage of a company that believes in her talent.

She can't do that on her own and yes, genre fiction has been very successful and there are some wonderful writers who have come to light because of that, but you are truly throwing the baby out with the bath water if you let Amazon kill the publishing system that has nurtured our literary culture.

### Conspiracy Advocate (CA)
Claim: Okay, well, you know what? I've listened to you guys and I'm going to back off on my stance for a little bit. You made a point. Advances for works of nonfiction that take a long time, we should support these, and publishers have in the past supported these, but you're conflating two things here, Scott. It's a fallacy. Just because that's the way things were always done doesn't mean it's the way it should be done forever. Franklin said something great. Only one thing, but he said something great. He said, "You know what advances are like?" Advances are like Kickstarter for authors.

You know what's great about that? You know what's better than an advance that takes 52.5 percent of your money? How about Kickstarter.

### Scientific Advocate (SA)
Claim: Wait, Joe--

### Moderator
Claim: Frank Foer.

### Scientific Advocate (SA)
Claim: You know there was a study-- there was a study done out of Queen College about the median income of self-published authors. And it was found to be under $5,000. And nearly 20 percent of self-published authors reported deriving no income from their writing. And it says-- she found that only 1.8 percent of self-published authors last year made over $100,000 from their writing. That's not enough to sustain a living.

### Conspiracy Advocate (CA)
Claim: You-- you are not comparing equals. It's--

### Moderator
Claim: I-- I--

### Conspiracy Advocate (CA)
Claim: I have choice.

### Moderator
Claim: I want to bring Matt back into this conversation.

### Conspiracy Advocate (CA)
Claim: All right.

### Moderator
Claim: Please. Matt Yglesias.

### Conspiracy Advocate (CA)
Claim: So, you know, advances is like a super-important subject here. And here's the fact of the matter. You have to understand.

Book publishers, the big ones that we're talking about that are here-- these are commercial enterprises. They're subsidiaries of big multi-national for-profit companies. They don't offer these advances because they're careless and just throwing money around like drunk morons. And they don't do it as an act of charity. I mean, there is, in fact, philanthropic support for certain kinds of non-profit work. Lots of important non- fiction books are written by professors at universities, et cetera. Et cetera. But book publishers pay advances because it's part of their business model, because as you say, it's required to get the book written. And so, the question is that either makes financial sense or it doesn't, right? Giving people the advance in exchange for a cut of their sales is either a profitable business to be in-- in which case people will continue to do it in the future-- or else it's not a profitable business to be in, in which case it's going go away-- regardless of what happens with e-books, and whatever else like that. So, I think it's a total red herring. And I think, again, to focus this on the question of-- no one is denying that Amazon is not the book publisher's friend.

But is it the reader's friend, right? They're squeezing these publishers, but they're doing it-- they're trying to sell books. You sell books to readers. And you sell books to readers by making books affordable and by making them accessible. That's what Amazon is doing. That's what makes Amazon the reader's friend. And if you care about books, pound the table, culture, yes, culture is great. That's why it's great to make books more affordable and more accessible.

### Moderator
Claim: Okay. There's a presumption that's been made in this side arguing in favor of this motion, that traditional legacy publishing is a tyranny. And I want to-- I want to focus on that point with a technique we're introducing tonight, a 30-second rebuttal round. We just want to, like, focus in specifically on this point of whether or not it's a tyranny. And that's why I have with me this special bell.

It's going to go like this. You get 30 seconds, one of you. 30 seconds back. 30 seconds back. And 30 seconds back. Just to discuss this one topic, without changing the subject, or you lose your time-- about whether or not traditional publishing actually functions as a tyranny. Which of you would like to go first?

### Scientific Advocate (SA)
Claim: I'll be happy to talk about--

### Moderator
Claim: Scott Turow, okay. Your 30 seconds-- will end like this. And your 30 seconds start now.

### Scientific Advocate (SA)
Claim: Right now, and it's a great thing, there are alternatives for the publishers, for the authors whom those publishers reject. And that's the self-publication route. Works for some. And that is a great thing. Doesn't work for most, but it's still great that it works for some. The problem is that the company that Joe champions, Amazon, wants to put the publishers out of business. They have no interest whatsoever in letting the publishers survive. It's good for them--

--if they're gone.

### Moderator
Claim: Joe Konrath.

Your 30 seconds starts now.

### Conspiracy Advocate (CA)
Claim: Okay. We don't need publishers. They are middle men. They were once essential because they were the only way you could get your book into bookstores. They were the only way to connect an author and a reader.

Now we do not need them. We can reach readers-- and I can reach more readers through Amazon than I could with the 10-something publishers, all of which were big publishers, that I worked for. And it's not equal. It's not like you can choose to self- publish or legacy publish, because legacy publish--

--makes you jump through –

### Moderator
Claim: Frank Foer.

### Scientific Advocate (SA)
Claim: Here's why we’re going to win this debate--

--these are the Manichean guys. They say, "Self-published authors should win and the traditional publishing houses should lose.” We are the men of peace. We--

--believe that there's no reason that you can't have a world there are self-published authors working through Amazon and traditional publishing, as is. That provides pluralism, diversity, a very rich culture. Why can't we go there? Because you guys have, it seems like, a little bit of a chip on your shoulder about the publishing houses, as does Amazon--

### Moderator
Claim: Matt Yglesias.

### Scientific Advocate (SA)
Claim: --want to destroy them.

### Moderator
Claim: Matt Yglesias, and the-- the question which has still not been answered is why is publishing traditionally a tyranny.

### Conspiracy Advocate (CA)
Claim: Traditional book publishers are much too incompetent to be a tyranny.

I agree with Frank. In principle, there's no reason why there can't be coexistence. And if you look at the movie industry or the music industry you see competing digital retailers and you see publishers of these things. And that's because movie studios are good at marketing movies. So, they do not need to fear any one distribution platform because they will sell their movies through other ones. Book publishers are bad at their job of marketing books. That's why they're afraid of Amazon.

### Moderator
Claim: The side that's arguing for the motion-- in a moment I want to come to audience questions. And I will say this in advance, I won't be able to accept all questions if they're off point. I apologize in advance for saying, "No," to certain questions, which I will do respectfully, and there's no shame in being turned down, but try to keep your question on the point of this topic, this motion.

Move it forward, be terse, don't argue with the debaters, and really make it in the form of a question. What will happen is you'll raise your hands, and I'll have a-- I'll call on you, and a mike will come. And if you're a member of the-- particularly the news media or actually if you're even in the business, we'd love to know that if you're willing to share, and we'd also like to know your name. Before we get to that, I just want to put one more question to the side arguing for the motion and then hear the response. Your opponents are saying that-- your opponents are saying that Amazon cannot be trusted, that it's becoming more and more powerful, and that-- and that's probably likely to continue, although you're saying there are mitigating forces. But they're saying that with the power it already has, that it's already demonstrated that it cannot be trusted to do the right thing. Joe Konrath, do you trust Amazon?

### Conspiracy Advocate (CA)
Claim: Well, okay. I am less worried about the tiger that's going to eat me next month, and I'm more concerned about the lion that is chewing on my leg right now. The lion chewing on my leg is Legacy Publishing.

### Moderator
Claim: Scott Turow.

### Scientific Advocate (SA)
Claim: Joe has managed to succeed outside that system. I don't understand how Legacy Publishing is doing anything to hurt you, Joe.

The problem is you are in bed with the devil because--

### Conspiracy Advocate (CA)
Claim: And the devil is good, Scott. The devil is good in bed.

### Scientific Advocate (SA)
Claim: --because you don't-- you have no-- no matter how popular you are, you have no control over Amazon, and Amazon has no interest in letting Legacy publishers survive.

### Conspiracy Advocate (CA)
Claim: Scott, I don't have a contract with Amazon. I can leave Amazon whenever I want to. You have a contract with Hachette. You once called Amazon the "Darth Vader of the publishing industry." Why are your books still on Amazon? You're like profiting from selling the evil empire

### Scientific Advocate (SA)
Claim: Because they're a monopoly. You can't avoid them.

### Conspiracy Advocate (CA)
Claim: Oh, is that it? So, you can take a strong stance against something, but then profit off of it? What's that word?

What's the word for that?

### Scientific Advocate (SA)
Claim: I don't-- you can apply whatever word you want to, but where else am I supposed to go? Where else are you going to go, Joe?

Joe, you shook your head and denied something that I have seen you admit in print. For all your stout defense of Amazon, they introduced Kindle Unlimited, and that cut your earnings.

### Conspiracy Advocate (CA)
Claim: No.

### Scientific Advocate (SA)
Claim: And it did it to many, many self-published authors.

### Conspiracy Advocate (CA)
Claim: What-- I know what you're-- That's not what I said. You're misquoting me or you misread me or you misunderstood me. I don't make any decisions unless I have information. They introduced-- Amazon introduced something called Kindle Unlimited. For $10 a month, you can get unlimited books, read as many as you want to.

### Moderator
Claim: Sounds terrible for readers.

### Conspiracy Advocate (CA)
Claim: I know, that sounds terrible for-- it does sound terrible for readers, doesn't it? My books were in that program. I now have data of what it's like to be in that program. Now I am going to take them out of that program because I control my books, and I am going to check to see how the data aligns. And if I don't like it, I will leave.

### Moderator
Claim: Matt Yglesias.

### Scientific Advocate (SA)
Claim: But was that a fair thing to do to you and the other self-published authors?

### Conspiracy Advocate (CA)
Claim: As opposed to you who has no power over where your books are put?

### Moderator
Claim: Matt Yglesias just let me bring back to you the question of whether you trust Amazon to do the right thing, given its power.

Do you-- are you good with them?

### Conspiracy Advocate (CA)
Claim: I-- you know what, let me just quote my opponent, Frank Foer, on Amazon. He said, "They want nothing else to breathe on this planet except their consumers," which is to say, "their readers." You know, I wear some different hats, I'm an editor at a website, I've written books, but as a reader I absolutely trust Amazon, not because I have some crazy blind faith in them but because their business model is getting more people

### Moderator
Claim: So, your opponents are talking about a world in which they will just be able to raise prices because they control everything, and it just won't be that

### Conspiracy Advocate (CA)
Claim: Well, as I've been trying to say-- that is a made-up world--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --in which you're wishing away Apple and Google.

### Scientific Advocate (SA)
Claim: But let me just--

### Moderator
Claim: Frank Foer.

### Scientific Advocate (SA)
Claim: --read a quote from a respected author named Matthew Yglesias--

--which comes from an article you wrote in Slate where you described Amazon as "awesome." You said, "If you own a competing firm, you should be terrified. Competition is always scary, the competition against a juggernaut that seems to have permission from its shareholders to not turn any profit is really frightening."Yes, Matt Yglesias, yes.

### Conspiracy Advocate (CA)
Claim: Amazon is definitely not a friend to competing bookstores. I mean, that article is all about the benefits-- the many benefits that Amazon has brought to consumers through its relentless competitive spirit.

### Moderator
Claim: Let's go to some questions. And, again, I implore you that if you have an interest in this, let us know about it because we're probably going to be able to tell anyway.

Ma'am, right up there. And the mic is coming down to your-- behind you, and if you could stand up and again tell us your name. Hold the mic about as far away from your mouth as this mic is from mine as well so we can hear you clearly. Thanks.

### Moderator
Claim: Greetings. I will admit, I am a literary agent. So, I'm one of the first gatekeepers that our writers have to go through. And my question is what kind of readers are we talking about? Because the books that come in to me are really unedited. I do what I can.

Then I find the right publisher. They edit them. So I think readers benefit from books that are edited by publishers.

And we haven't talked about the editorial process and what the publishers bring to that.

### Moderator
Claim: Okay, I'm going to take that question to the side arguing for the motion because it sounds like more of a challenge to them. Do you want to take that,

### Conspiracy Advocate (CA)
Claim: Editing is fantastic. I mean, I'm an editor in my day job at a website.

### Moderator
Claim: You're a gatekeeper?

### Conspiracy Advocate (CA)
Claim: I am. I keep the gates of what articles go up on the site. And I'm also a writer, and I feel like my writing has always been improved by editing. But you can see when you look, I mean, the world of writing is much bigger than the world of book publishing. And there's lots of different ways in which editing gets done between the final publication of something and the initial conception of it. And so I think when editors are adding value to writers and to readers, which I think they often are, there are ways to make that happen. I think the particular way that editing of books happens, the sequence from the writer, to the agent, to the publisher, to the editor who works for the publisher, you know, that is being several challenged by the current dynamic.

But anyone who really cares about making their writing better, finds ways to work with editors. And that happens in newspapers, it happens in magazines, it happens in websites, and it'll continue to happen.

### Moderator
Claim: So, Matt is saying that it-- you don't need to have a-- you know, a big five editor editing your book in order to get edited.

### Scientific Advocate (SA)
Claim: I-- well, I don't know where else it's going to come from unless-- the model that Joe believes in is one where the self-published author goes out and hires his own marketing advice if he's not a marketer himself, his own editor if he's not his own editor-- which is not a good idea I think ever, it's like being your own lawyer-- so and I don't know where these authors who are just starting out are going to get that editorial advice, where they're going to get the bankroll to finance the marketing and the editorial.

### Moderator
Claim: Joe, you live it. I mean, who edits for you?

### Conspiracy Advocate (CA)
Claim: I love editors, and I have several editors, and they're easy to find.

There's a whole group in this country called, "freelancers," and they actually will do editing for a set fee, and that set fee is nice. It's some cost. It's not you paying forever. When you are edited by one of the big five, they own that book for your lifetime plus 70 years. That editor who spent two weeks on a book that it took you two years to write gets paid for that long. I'd rather pay a freelancer some costs and then keep the money from that point on.

### Moderator
Claim: Frank Foer, what's wrong with that argument?

### Scientific Advocate (SA)
Claim: So, freelance editors are-- their life with the project is-- you said two weeks or something-- they're not fully invested in the success of a project. When a publisher edits a book, they're invested in its success. They have very, very strong incentives for excellence.

A freelancer, some person you find on the Internet, to come punch up your book, isn't going to be fully invested in its excellence.

### Moderator
Claim: That's-- all right, that-- I get that point. I want to take it back to your side. It's very-- Matt Yglesias, very persuasive point.

### Conspiracy Advocate (CA)
Claim: You know, listen. Future business models, that's tough, I-- you know, I could be like a book visionary, but I'm not. I'm just an editor on a website. But the fact of the matter is you can imagine lots of different ways this works, right? You can imagine companies that just don't happen to be the existing big five publishing companies doing a similar sort of service, where they look at drafts and when they find drafts that they think are promising, they agree to edit them, work on them, and improve them in exchange for a percentage of the sales. That's not like a crazy business to be in. The book publishing business has worked along that kind of model for a long time. It often is the case when technologies change that the particular incumbent companies lose out, but something sort of similar takes its place. I think that you've seen in the journalism world that I'm in, right, that some old companies have struggled.

Some old companies have thrived. Some new companies have come out, but this stuff that's really valuable in terms of like writing, reporting, editing, that still happens at all different kinds of places and I think you'll see the same thing in publishing.

### Scientific Advocate (SA)
Claim: The quality of editing on the internet, though, has diminished significantly. I mean,-- and it's-- you know, editing is not just a business it's a craft. It's something that you have to practice with devotion just like writing is, and, in order to get that quality of editors that you'd want in order to really significantly improve things, you need people who are committed to craft. And the worst thing is if writers are going to perceive editing as just kind of an unnecessary expense, because no writer really truly believes that they need to be edited. And writers are the people in the world who are least able to see the flaws in their own work.

### Moderator
Claim: So, Joe Konrath, it sounds as though Matt Yglesias is, I don't want to say conceding, but is acknowledging that there are some services that legacy publishers do deliver, such as editing, that have a value.

But that the framework in which they exist is the killer for you.

### Conspiracy Advocate (CA)
Claim: Well, everything is of value, but value also has a cost and the cost for a legacy editor is, in my opinion, too high. In some instances it may not be too high. I had a great publisher at Hyperion for my first six books. Her name was Leslie Wells. She was great.

And now she was fired so I can hire Leslie Wells whenever I want to and she just appeared on my blog talking about her new book, which she self-published.

### Moderator
Claim: And is she editing it herself?

### Conspiracy Advocate (CA)
Claim: No, she's going to get an editor.

### Moderator
Claim: Okay. Another question, please. Right in the center here. You're wearing an orange shirt. Again, if you've got skin in the game let us know.

### Moderator
Claim: Thank you very much. Can you hear me?

### Moderator
Claim: Yes, very clearly.

### Moderator
Claim: Jim Corsey, avid reader and member of the unwashed masses. This is for the against group. Information by itself wants to be free and throughout--

That is-- I'm sorry. There is nothing else in this society that is supposed to be free. To say information is free-- to say information wants to be free--

### Moderator
Claim: Scott, I'm going to ask you to let the guy get the question out.

### Scientific Advocate (SA)
Claim: Okay.

John, I disagree with the premise.

### Moderator
Claim: You can come back to that, but I really want to see what happens when he gets to the question mark.

### Moderator
Claim: Throughout history disruptive technologies have brought information to us in a variety of different ways from the creation of written language to the Gutenberg Bible to the creation of competitive press to electronic publishing and e-books.

And my question to you is why are you so afraid of the latest revolution in allowing us to have access to information in the way that we want?

### Moderator
Claim: Why do you say they're afraid? Why do you portray their argument as one based on fear?

### Moderator
Claim: Because they're providing us with a view that there has to be a set of, I don't want to use the term oligarchy, but there have to be curators for the information that we're allowed to access and consume so we know which one is the good and which one is the not good.

### Moderator
Claim: It's about the judgment process that you're questioning. All right. Let's take it to Scott. You have--

### Scientific Advocate (SA)
Claim: First of all, my differing with the people who say information wants to be free are the people who want to devalue copyright and indeed even do away with it and I think if you do that you will not have authors, you will not have books, and you are doing no service to readers. I'm not sure, though, that you're listening carefully to what Frank and I have been saying. I am not against Joe self-publishing his books.

I am happy that that is happening. I believe the more voices the better. So I'm not against that. The problem is that the company that Joe works with wants to do away with the other model and that is I believe overall an immense threat to our culture.

### Moderator
Claim: Let's take another question.

### Moderator
Claim: Has the number of books read by the number of people-- has book readership in general increased since Amazon has become so powerful? In other words, not just their slice of the pie, but have they grown the pie? Have they contributed to that? And if so, what does that indicate about their friendliness?

### Moderator
Claim: Nicely done.

Joe Konrath.

### Conspiracy Advocate (CA)
Claim: I've got a friend named Hugh Howey whose sales just completely blow mine away and Hugh and an unnamed data guy who I happen to know who really knows his stuff, started a website called authorearnings.com.

And what they're showing is, yeah, the pie is growing. Traditional publishers don't see the pie growing. Their part of the pie is staying the same. But for the rest of us, the pie is getting bigger.

### Moderator
Claim: Would you like to respond, on this side?

### Scientific Advocate (SA)
Claim: Well, here's the one problem with that. Amazon doesn't release sales figures. So, we have no idea whether Hugh Howey, who of course is the champion for his own cause, is accurate. His data guy is totally unnamed. There's no backing up of his sources.

### Conspiracy Advocate (CA)
Claim: The data is there, Scott. You can check it. Anybody can check it. He-- they list everything and their math is solid.

### Moderator
Claim: Scott

### Scientific Advocate (SA)
Claim: Joe, it could be a work of fiction. Nobody knows where those numbers came from.

### Conspiracy Advocate (CA)
Claim: They take screenshots of Amazon. That's where they're coming from.

### Moderator
Claim: We're in the middle of this Intelligence Squared U.S. debate, second round--

I have to do this little bit. Hang on one second.

Our motion is this, Amazon is the Reader's Friend. This is a debate from Intelligence Squared U.S. I'm John Donvan. And we have two teams of two debating for and against-- Joe Konrath and Matt Yglesias arguing for, Frank Foer and Scott Turow arguing against. We're taking questions from the audience. Right down in the front here.

### Moderator
Claim: Hi. I'm Sadie.

### Moderator
Claim: Hi Sadie.

### Moderator
Claim: My question is directed mostly towards the opposition, particularly towards Scott, because he's a published novelist. Full disclosure, I work-- I volunteer at a writing outreach nonprofit based in my hometown, called Project Write Now. I'm wondering what you think about-- do you think that if Amazon really does become this-- this monopoly that you fear it will be, or fear it already is, do you think the quality of books that are getting out there and getting popular are going to decrease?

### Scientific Advocate (SA)
Claim: The short answer is yes. And it's-- but it's for complicated reasons.

What I worry about is that most authors can't afford to be self-published authors. They can't spend years and years working on their books. They can't-- a first-time author has no money to hire an editor or a marketing guru. And so, the temptation-- and what happens with most of the self-published authors is that they produce book after book-- sometimes several in one year. Now, I will tell you. Trollope and Dickens wrote at that pace. Steve King writes a lot of books. So, it's not-- I'm not saying it's all bad. But I'm telling you that the odds are that most people aren't Trollope and Dickens. And so, yes, that system, I think, will produce works of lower quality, and less thoughtful works.

### Conspiracy Advocate (CA)
Claim: I think that Scott is skipping a lot of logical steps when he gets-- so, what he is actually describing is not a world in which Amazon has ruined literary culture.

He's describing the fear-- a fear that I think a lot of people share, and not totally unreasonably, that readers-- maybe the world just doesn't want to pay for great literature. And I think that's an interesting question, right? I mean, maybe, Netflix will destroy literary culture. And-- but that's not what we're debating here, right? I think any world where there are people, talented authors with great books that they want to write, and if there are readers who want to get their hands on great books, there is just no way that Amazon, as a retail layer in the middle, is somehow preventing that from happening. There are plenty of ways that you could put books up for sale that don't involve Amazon. There's no sign that Amazon has some objection to great books being sold on its platform. Amazon is trying to sell as much stuff to as many people as they possibly can.

And these other sort of questions-- big questions about the future of books-- are very important. But we have to understand that, like, Amazon's commitment to serving readers and to serving the book market in a digital world is part of what helps books stay viable in a world where they face competition from all kinds of other entertainment.

### Moderator
Claim: Let me see if anybody wants to respond--

--Frank Foer.

### Scientific Advocate (SA)
Claim: You know what? Amazon-- Amazon isn't just a search engine. It's not just a place you can go in and look for whatever book that you're interested in. Amazon has a home page, a very powerful home page that drives traffic to books. They decide-- they pick winners and they pick losers. And they have tremendous power--

### Moderator
Claim: But doesn't--

### Moderator
Claim: --don't the publishing houses do exactly the same thing?

### Scientific Advocate (SA)
Claim: They do. But the problem is that we're imagining a world where you have one-- I mean, this is the nightmare scenario where-- which we're on the road towards, where you have one company that is the arbiter of all things literary, all things book.

And they--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --they set the standards, and they make the choices. And it's not a neutral playing field, where we all have a--

### Moderator
Claim: Let me--

### Scientific Advocate (SA)
Claim: --chance.

### Moderator
Claim: --take that point to this side. Because Matt Yglesias is arguing it's not going to happen, because there's Google and Apple. But as a theoretical thing, if you guys don't mind playing with the hypothetical, Joe Konrath, if-- if Amazon ultimately became fully a monopoly, had no competition, would that be a nightmare scenario, that Amazon was alone and able to pick the winners and losers?

### Conspiracy Advocate (CA)
Claim: They're not picking anything. They're just allowing anybody who has an idea to have the opportunity--

### Moderator
Claim: No. I'm talking about-- I'm talking about--

### Conspiracy Advocate (CA)
Claim: --to reach--

### Moderator
Claim: I'm talking about the ranking he was just talking about, on the home page. They pick which ones to put on the home page and which not to.

### Conspiracy Advocate (CA)
Claim: Well, it's their company. They can do what they want to with that company.

### Moderator
Claim: Is that-- I know they can. Is it

### Conspiracy Advocate (CA)
Claim: I would love to have my books available on Scott's site. It's not going to - -

### Moderator
Claim: I know they can. Their point isn't that they can--

### Conspiracy Advocate (CA)
Claim: --it's their choice.

### Moderator
Claim: --or-- their point isn't they can or can't. Their point is that it would be a bad thing. I just want to see if you think that would be a bad thing or not.

### Conspiracy Advocate (CA)
Claim: Well, hypothetically, I think a lot of bad things can happen. But I don't see that happening right now.

I talk with Amazon about changing algorithms. I haven't heard anybody admit that, "Yeah, we're futzing with this and we're futzing with that." Now, they're notoriously tight-lipped about anything. What are they going to tell me for? But how do we automatically jump to, "Wait a second. Amazon is doing something shifty here."

### Scientific Advocate (SA)
Claim: But it is shifty. And let me--

### Moderator
Claim: Frank Foer.

### Scientific Advocate (SA)
Claim: --tell you why. Right now, when you type in-- you type in "police"-- "police noir novels" into their search engine, you get a series of results. How do you think that series of results is ranked? A publisher has paid for one of the top ranks there. So, that's--

### Scientific Advocate (SA)
Claim: --that's their but they're not-- they're not letting consumers into that in a-- that, you know, with full awareness of the ranking that's actually happening there. They're posturing as if it's like Google.

### Conspiracy Advocate (CA)
Claim: You think Amazon invented that? That's called co-op.

That's why, when you go into a Barnes & Noble, you see 400 Scott Turow books--

### Scientific Advocate (SA)
Claim: But it's--

### Conspiracy Advocate (CA)
Claim: --stacked up in front--

### Scientific Advocate (SA)
Claim: No. No.

### Conspiracy Advocate (CA)
Claim: And you see my one book out in section.

### Scientific Advocate (SA)
Claim: But it's different if you have one big player picking the winners and losers. And that's-- that's the point you guys haven't really addressed here tonight, which is that we're-- they already have 57 percent of the--

### Moderator
Claim: Yeah.

### Scientific Advocate (SA)
Claim: --e-book market.

### Moderator
Claim: I mean, just as-- just as the referee of the debate, I agree that you haven't addressed it. Now, you-- you've refuted it as, "Why should I deal with it, because it's not going to happen," Matt. And Joe, you're refuting it as, "I can't talk about hypotheticals." Fair enough if that's your response to their hypothetical, but you just don't think it's worth dealing with. I want to-- I want to give you--

### Moderator
Claim: --one more –

### Conspiracy Advocate (CA)
Claim: No. No. No. Let me try to respond to it as clearly as possible.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: If their argument is that in a counterfactual world, in which no other websites existed, that then, in that world, Amazon would be a threat to literature and to readers, that's true.

But it also tells you that in the actual world, where there are lots of other websites, it isn't the kind of threat they pose-- but to generate this threat, they have to assume a crazy series of subsequent events that take us from here to this dystopia.

### Moderator
Claim: You think-- you think we're far, far away from that happening, is what you're saying?

### Conspiracy Advocate (CA)
Claim: Yes. There’s no possible way it could happen.

### Scientific Advocate (SA)
Claim: Can I ask just a brief question, Joe? What percentage of your sales take place on the Amazon platform?

### Conspiracy Advocate (CA)
Claim: When are we talking these sales? In the past? Maybe 70 percent. Recently, 95 percent. Now I'm scaling back on Amazon, because I'm going to test some things out with some other platforms, see what they're doing. It changes. It fluctuates. The industry is in flux right now.

### Scientific Advocate (SA)
Claim: Well, 95 percent, Matt, doesn't sound like the other websites are doing very well to me.

### Conspiracy Advocate (CA)
Claim: I'm not on the other websites.

### Moderator
Claim: Let's now go to a question, please.

### Moderator
Claim: I'm Jeremy Greenfield. I've written about this topic for a long time.

And I actually conceived of, and authored, and edited the original versions of the studies that Frank mentioned. My question is also about different kind of reader, the reader who lives in a rural area, who doesn't have access to a large literary culture, the reader who finished the latest Scott Turow book on the beach and wants to read one of the older ones immediately. Is Amazon not that reader's friend right now?

### Moderator
Claim: That's a great question. That's a great question. Let's take that up. Scott, you take it.

### Scientific Advocate (SA)
Claim: Just to go back to where I started-- I will not say that Amazon does nothing good or that Amazon hasn't contributed value to the reading world. Of course they have. The vast library-- they've cut down the barriers to book buying. They've made things instantly available. It's an enormous library of available material, and they're great for the person in the rural area.

And I believe all of that. The problem is it's a binary world. They will not agree to anything but their model. They want to crush the publishers. They see no benefit in their existence. And I know that when that happens, the literary culture will be poorer, and, as a result, they call it "creative destruction," I call it "cultural destruction."

### Moderator
Claim: In the far corner there.

### Moderator
Claim: Hi, so for the kind of--

### Moderator
Claim: Could you tell us your name, please?

### Moderator
Claim: Oh, hi, I'm Carrie So, for books that are currently out of print, you know, that are still available from Amazon just, you know, from other sellers who actually want to sell that book, isn't Amazon the reader's friend for that reason?

### Moderator
Claim: More reader's friends reasons, there are a lot of them coming up. Frank Foer, why don't you take that?

### Scientific Advocate (SA)
Claim: My sense is that the out-of-print book market is something that the Internet more broadly does a good job of. So, yes, they are the reader's friend in that sense, and so is eBay, and so are any number of sites. That happens to be one part of the market where there's more competition because the barriers to entry are lower.

### Scientific Advocate (SA)
Claim: And-- can I add to this? I know that they get more time as a result.

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: But in 2008 Amazon bought a company called, "BookSurge," which provided print on demand services for small publishers-- often for out-of-print books. And Amazon immediately turned around to those small publishers and told them they would not have access any longer to the Amazon site unless they used BookSurge, which at that time offered a more expensive product.

And the publishers had to choose between doing any business at all or standing up to Amazon.

### Moderator
Claim: Matt Yglesias.

### Conspiracy Advocate (CA)
Claim: You know, something that connects I think the last two points that I saw recently is that the world of public domain books, you know, books that are old and out of copyright, thanks to Amazon you can go online like right now and you can get the complete works of Jane Austen for free. That's pretty great for readers, it seems to me, and not something traditional publishers are interested in doing, they're not making money that way. And it's just an example of the way in which a relentless desire to kind of serve this digital market, to serve consumers, to gain as big a share as possible, has really made Amazon a reader's friend by getting that long tail, including the books that are completely free, out there and into the hands of as many people who want--

### Moderator
Claim: And, Joe Konrath, do you want to comment on that?

### Conspiracy Advocate (CA)
Claim: No.

### Moderator
Claim: Okay.

Go to another question. Let's see. I'm sorry. Sir, sweater and shirt, yeah.

### Moderator
Claim: Me?

### Moderator
Claim: Yeah. Well, I meant the fellow in front of you, but you win by aggression.

I hate to reward it but I'm going to. Do you need a mic? Oh, I didn't even know you were down there.

I'll let you go. In the interests of time, that was-- see that was aggressive, and that was sneaky, and I like that.

### Conspiracy Advocate (CA)
Claim: He's the Amazon of the audience.

### Moderator
Claim: So, my name is Stephen I'm a full disclosure business student, and textbooks are expensive. But getting to my real question-- so there's plenty of other destructive business models happening, whether it be in the music industry with Spotify and the like, but ultimately the adaptability I think ends up generating more value for the users. So, whether it be the Amazon be the reader's friend or the publishing houses be the reader's friend, I kind of wonder in this unrest in the book economy what you guys view as the projection of being value added for the reader.

### Moderator
Claim: I'm going to pass on that question because I don't think it's going to help us vote on the motion, but thank you for the question.

And my original-- you won through patience.

### Moderator
Claim: Hi, my name is Eric Two questions quickly for Matt Yglesias.

### Moderator
Claim: Just make it one question, okay? Pick one.

### Moderator
Claim: One question for Matt Yglesias.

The stock market values Amazon at a really high level despite the fact that it's never made any money, and, of course, that's because the stock market with the support of the management of the company believes that they're going to change what they do and ultimately take advantage of the control of the individual markets that they dominate to raise prices and to do things that are more profitable for the company. So, my question for you is, is it possible that you think that Amazon is a friend to readers today, but that five years from now or 10 years from now it won't any longer be friends to readers?

### Moderator
Claim: Matt Yglesias.

### Conspiracy Advocate (CA)
Claim: Well, you know, the--

--the stock is actually down 25 percent over the past year and--

### Moderator
Claim: Almost a dollars.

### Conspiracy Advocate (CA)
Claim: Yeah, yeah, yeah, but, I mean, 25 percent is a lot, and that's during the context of a rising stock market.

And I think that's happening because the investing community has begun to lose faith in this idea that this kind of cut prices to the bone, dominate everything then jack the prices up, it's dawning on them that that doesn't really work, that you can build a successful business of low margins and high volume and that there's some real value to that, but that this like monopoly doomsday scenario of theirs is not realistic and it's not financially realistic. That's why you've seen share prices starting to go down. That's why you've seen investors backing new e-retail startups, because they see there isn't this kind of opportunity for monopolization that people fear.

### Moderator
Claim: So, your answer to the question again is that you just don't think it's a realistic scenario?

### Conspiracy Advocate (CA)
Claim: Well, I mean, I don't think it's true that the stock market even thinks it's a realistic scenario.

### Moderator
Claim: But that wasn't the question. You don't think it's a real--

### Conspiracy Advocate (CA)
Claim: I don't, yes, and I think investors--

### Scientific Advocate (SA)
Claim: You don't think Amazon's become more interested in a profit in the last year?

### Conspiracy Advocate (CA)
Claim: Well, they've started to become interested, but this is--

### Scientific Advocate (SA)
Claim: They raised the price of Prime 25 percent.

### Conspiracy Advocate (CA)
Claim: Scott, I understand that, but I'm saying this is the question, right, is do they have the ability to first secure monopoly then jack up prices and receive these huge

### Scientific Advocate (SA)
Claim: I--

### Conspiracy Advocate (CA)
Claim: Wall Street feels that they don't have that opportunity, which is why their stock prices started to go down. Now if you want to talk specifically about books and price increases we should talk about the time the big five book publishers and Apple formed a cartel to fix prices and raise them. That's why e-book prices have gone up, which is separate from Prime and Amazon and all that other stuff.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. debate--

--where our motion is: Amazon is the Reader's Friend.

## Round 3

### Moderator
Claim: Okay. Remember. Thanks very much for all the questions. It was-- they were great. Remember how you voted? As soon as you hear the closing statements, which will be very brief, they're two minutes each, and eight minutes from now we will be voting. Two minutes from that we get the response. On to round three, closing statements.

They will be three minutes each. Our motion is: Amazon is the Reader's Friend and here to summarize his position supporting this motion, Joe Konrath. He's author of several dozen novels, including "The Jack Daniels Thriller Series."

### Conspiracy Advocate (CA)
Claim: I have one fan. Thank you.

I have three minutes or two minutes? Okay. Two minutes. You know, I'm thinking can I finish in two minutes and I know my wife is watching this and she's like you always finish in two minutes.

I'm not going to-- hey, hey, you're wasting my time. I'm not going to sum up everything. I'm not going to use any more-- I'm not going to introduce any new data. I'm not going to introduce any new facts. I'm not going to try to sway over on the logic here, I'm going to say this one thing. I will bribe you if you change your vote to Amazon is a friend to readers. This is how I'm going to bribe you. I'm going to give you all of my e-books for free and because I know Scott is such a fan of piracy I'm also going to give you all of his e-books.

For free. Actually, of course, I'm kidding, but underneath that, I'm kind of not kidding. I have the ability to with Amazon give away my books, put them on sale, lower the price, make them free. I've sold millions of books. I've given away millions of books. Amazon allows me to do that. Tell me that's not being a friend to a reader and remember please vote Amazon is the reader's friend. Thank you.

### Moderator
Claim: Thank you, Joe Konrath.

That's our motion: Amazon is the Reader's Friend and here to summarize his position against this motion, Scott Turow. He is former president of the Author's Guild and author of "Presumed Innocent."

### Scientific Advocate (SA)
Claim: I'm probably dating myself as I usually do, but long ago on Saturday Night Live Garrett Morris played a character called the Chico Escuela and Chico used to say regularly "Baseball been berry berry good to me."And the truth of the matter is Amazon has been very, very good to me. They have sold thousands and thousands of my books with their relentless discounting that has driven sales on which when you talk about hardcover books very nice for me because I get a full royalty on each of those sales. There was a time, as the matter of fact, that Jeff Bezos even invited me to his little thought colloquia the Campfires until I remarked that they were the Darth Vader of the literary world.

And the invitations ceased-- have ceased coming. I do not judge things on the basis of what's good for me. In point of fact, I spent 20 years trying to get my first novel published. I was Joe Konrath and that experience never leaves me. And I am concerned about what is good for authors in general, not what's good for best-selling authors.

Amazon wins. We all have to become entrepreneurs. The best-selling authors are the people who will prosper most in that situation, because it's an undifferentiated mass. People whose names are already known would be the winners. But I know-- I know that the system we have now-- yes, great, Joe, good. I really and truly am happy that you have found an audience. I want every author to find an audience who deserves one. But the system that has perpetuated that is that of traditional publishers. And remember that these gentlemen do not deny that Amazon's ultimate goal is to describe-- is to destroy traditional publishing, to force every author to become an entrepreneur, his own marketer, his own editor, and we will lose good writers in the process.

### Moderator
Claim: Thank you. Scott Turow.

The motion is Amazon is the Reader's Friend. And here summarizing his position supporting this motion, Matt Yglesias, executive editor of Vox.com.

### Conspiracy Advocate (CA)
Claim: I think it's really important when you consider voting on this motion to really think about and listen to the arguments that our opponents have made. They have raised a lot of interesting ideas. But they're all-- they're these very complicated, very hypothetical ideas with a lot of red herrings and a lot of distractions from the core question here, which is, has Amazon been and is it now a friend to readers? I mean, they haven't really disputed that it is, that Amazon has made books cheaper, that Amazon has made books more convenient, that Amazon is outcompeting the largest and richest technology companies in the world by offering a superior platform for shopping for books. Now, it is true that if many, many things that are not true became true at some hypothetical time, through impossible mechanisms, Amazon might be an enemy to readers in that world. I studied philosophy in college and this possible world stuff-- it's fascinating.

And you can-- thanks to Amazon-- go buy David Lewis's book about the causal analysis of counterfactuals. You can get edited volumes that were written by his students. And you can really mull through this kind of stuff about these complex things. But if there was no Amazon, it would be extremely difficult to find David Lewis's book or all those other books about the metaphysics of causality, hypotheticals, et cetera-- because you know, brick and mortar bookstores have limited spaces. They don't want to carry that crap. You know, maybe right by a college campus they would, but in general, no. Amazon is the reader's friend. You can get all these books there. And that's pretty great, you know? Do they want to take over the world? Sure. Of course they do. And their nefarious plan for taking over the book world is to create the cheapest, best, and most convenient way to buy books. They are the reader's friend. That's how they got so big. That's why we're debating this.

Other people with other interests have legitimate beefs with Amazon, but they got those beefs because Amazon is the reader's friend.

### Moderator
Claim: Thanks, Matt Yglesias.

And that's the motion, Amazon is the Reader's Friend. And here to summarize his position against this motion, Frank Foer, former editor of the New Republic.

### Scientific Advocate (SA)
Claim: We live in a fast-moving world. Disruption is our secular religion. And a lot of the things that get disrupted-- and are replaced with something good. A lot of things that get disrupted just disappear. And we, as Americans, are very optimistic. We can always assume that things are going to work out for the best. But here, we're dealing with something very, very special and very, very important. And the economics of the book business-- and therefore, the substance of it-- are about to change. It could be wonderful. It could be a dystopian hell. They have not answered two fundamental things.

The first is that Amazon already is a monopoly. By any traditional standard, they are a monopoly. They control 67 percent of the e-book market, 40 percent of the total book market. They are there. It's one corporation with lots of power over our most precious things. And so, you tonight have the opportunity to take a stand. I guarantee you Amazon is watching tonight.

But here's the thing. Your stand is cost-free in one regard. It's not going to bring in any government regulation. You're not going to put anybody out of business. But you have a chance to send the message to Amazon and say, "Look, be careful, guys. You're dealing with precious cargo. We're watching you. You have a lot of power right now. Your power is probably going to keep increasing. Don't abuse it."And so, you know, maybe you don't believe in the worst hypothetical scenarios that we've talked about here. But you care about the word. You care about the thought, you care about the underlying thing. And so be brave, take a stand, vote against this resolution, and be good stewards of word and thought.

### Moderator
Claim: Thank you, Frank Foer.

And that concludes closing statements and round three of this Intelligence Squared U.S. Debate. And now it's time to learn which side has argued most persuasively. We're going to ask you to go again to the keypads at your seats and to vote a second time. And, remember, it's the team whose numbers have changed the most in percentage point terms between the opening and the closing will be declared our winner. If you agree with the motion that "Amazon is the reader's friend," we're asking you to push button number one. If you disagree, push button number two. If you remain or became undecided, push number three.

Okay, while you're doing that, I would like to say this. It was very, very-- it was a really fascinating thing to see four men of letters and lovers of books disagree so bitterly on something that's so personal to them and actually do it in a very respectful and civil way. I just want to ask for a round of applause for the way they did this.

And I want to say to Frank Foer, since you knew Amazon was watching, what you had to say up there was very, very brave and courageous of you.

And I wanted to say to Joe Konrath, after hearing the writer type described as sort of "shy and introverted," I want to congratulate you on overcoming this obstacle tonight and getting up on this stage.

I also want to thank the people who have been supporting Intelligence Squared for the last several years, and particularly in the past year, as the ticket sales do not in any way come close to covering the cost of putting on one of these debates.

And we're counting on and have been counting on the support of a lot of people, but we need the support of many, many more. And I really mean it when I say the size of the contribution doesn't matter, but it would make a very, very big impact on our ability to continue doing these and to do more of them. If you go to our website, you have the opportunity to donate there, and it would be really, really something that we would really, really appreciate. Speaking of keeping this going, our next debate is right here at the Kaufman Center on Wednesday, it's February 11. It will be our 100th debate.

Yeah, we started back in 2006. And we're hitting number 100 this year. So, we hope you can all come and celebrate it with us. That debate is going to be focusing on sort of the-- a very sort of big picture look at the prospects for this nation. And the motion is going to be framed this way, "Declinists be damned: Bet on America."Our debaters include a German publisher, a geopolitical strategist, a member of the Canadian parliament, and a finance guru. We'll keep you in suspense on who's on whose side on that one. But you can check it out on our website. And we're going to be looking through the rest of the season at this whole role of power. Our debates through this rest of the spring will be the right to be forgotten. We're going to be looking at presidential war powers, we're going to be looking at abolishing the death penalty, and, finally, on whether smart tech is making us dumb.

For the full list of our debates and to purchase tickets, you can go to our website. And I mentioned in the beginning we have a terrific app that we launched this year. And when I say it's terrific, you can see all of the debates that we've done, including this one, the 99th and the next one coming up. You can hear them as well as podcasts. You can vote. You can do research. You can find out who's going to-- who our panelists are. It's a very, very rich and deep app, and it's mobile. So, we recommend that, and I think I've covered all of that.

The results are in now. We've had you vote twice on this motion, "Amazon is the reader's friend," once before the debate and once again afterwards. And, remember, the team whose numbers have changed the most in percentage point terms will be declared our winner. So, let's look at what the preliminary voting results were. The motion, "Amazon is the reader's friend," before the vote-- before the debate 41 percent agreed with this motion, 28 percent were against, and 31 percent were undecided. Those were the first results. Now let's look at the second vote on this motion, the-- "Amazon is the reader's friend." The team arguing for the motion, their second vote was 42 percent. They went from 41 percent to 42 percent. They picked up one percentage point. That's the number to beat. The team against the motion, first vote 28 percent, second vote 50 percent. They picked up 22 percentage points.

The team arguing against the motion, "Amazon is the reader's friend," has won this debate.

Our congratulations to them. And thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.

Thank you.
