# Debate Transcript

Topic: U.S. Airports Should Use Racial And Religious Profiling
Motion: U.S. Airports Should Use Racial And Religious Profiling

Debate ID: airport-profiling


## Round 1

### Moderator
Claim: And I'd like to introduce the gentleman who makes all of this responsible, Mr. Robert Rosenkranz.

### Moderator
Claim: Good evening and welcome. You know, several years ago an Intelligence Squared audience voted against the motion, quote, "Better more domestic surveillance than another 9/11." I was personally surprised by the vote. But after speaking with audience members, I understood that most people's only experience with counterterrorism is airport security. They take a dim view of it. Didn't want those responsible for it to have any additional powers. Today's headlines about the TSA's new scanner and pat down proceedings only seem to validate that point. So clearly getting airport security right is important, not just for its own sake, but for the sake of public attitudes toward counterterrorism efforts generally. .5

Profiling has the appeal of simple common sense. We know that the vast majority of terrorists are Muslim males ages 15 to 30 from a handful of countries and ethnicities. Homeland Security services have scarce resources. If they don't target the resources they've got efficiently, they're not doing their job, and they're undermining public support for their mission. Well, the counterargument is that this sort of profiling cuts deeply against bedrock American ideals. Alternatives such as full body scanners in the news today and behavioral profiling are both more effective and less discriminatory. Perhaps the vast majority of terrorists fit a distinct profile. But the vast majority of travelers who fit that profile are not terrorists. .2

Treating them as if they were encourages resentment and anti-American attitudes. To succeed in the long run, our efforts need to diffuse those attitudes, not create them.

So which is the more persuasive view? We have some extraordinary panelists with us this evening to help you decide. But before I turn the evening over to our moderator John Donvan, I did want to note that ticket sales cover only a small fraction of the cost of presenting this program. There are a substantial number of charitable foundations and friends who support our efforts as your program notes. And as your own thoughts turn to holiday giving, why not considering joining our friends group or perhaps giving a series subscription to some of those on your gift list. Well, that's my pitch. And now, John, over to you.

### Moderator
Claim: Thank you, Robert. .0

And just as in fact the main benefactor of this program is the Rosenkranz Foundation, I just invite one more round of applause for Robert Rosenkranz. True or false, U.S. airports should use racial and religious profiling. That is what we are here to debate. I'm John Donvan of ABC News. We are at the Skirball Center for the Performing Arts at New York University and on NPR stations across the nation for this Intelligence Squared U.S. debate on the proposition U.S. airports should use racial and religious profiling. We have two teams of three members each arguing for and against. And they're not necessarily who you would think. Arguing against the motion, for example, a woman whose brother died as a pilot on flight 77 that crashed into the Pentagon is here to argue against the motion. Also the gentleman who was the second secretary of the Department of Homeland Security. Arguing for the motion, our team includes an American Muslim woman who certainly would be one of those pulled off the line if we went into profiling, or at least the male members of her family. .2

So it's not necessarily who you would think. Also, we think that you will be surprised by the level of some of the debate. The point here is really that this is a contest, a contest of a well-argued idea, a verbal joust. And you, our audience, are here to listen and to act as the judges. I would like you now to go to the key pads at your seat and register your position on this motion. U.S. airports should use racial and religious profiling. Your position as you come in off the streets before you've heard any of the arguments. If you agree with the motion, U.S. airports should use racial and religious profiling, push number one. If you disagree, push number two. And if you are undecided, push number three. If you feel that you've made an error, just correct it, and the system will register your last vote. And we'll be able to present that vote towards the end of the debate. . .0

All right. Once again, as I'm saying, you the audience are the judges. By the time this debate has ended, you will have been asked to vote two times, once before the arguments and once again afterwards. And the team that has changed the most minds will be declared our winner.

So on to round one, opening statements by each team in turn. And I would like to introduce as he rises from his table and heads to his podium, Deroy Murdock. He is a syndicated columnist with the “Scripps Howard News Service,” media fellow at the Hoover Institution. Like me, he does a lot of traveling on airplanes. And Deroy, have you been in the system lately?

### Conspiracy Advocate (CA)
Claim: John, I was in the system last night when I flew back from Nashville.

### Moderator
Claim: Have you experienced your first pat down?

### Conspiracy Advocate (CA)
Claim: Well, I have not yet. And I guess that may come up at some point in the future. But let me be clear, John, if you touch my junk--

### Moderator
Claim: Ladies and gentlemen, Deroy Murdock. .3

### Conspiracy Advocate (CA)
Claim: Thank you very much. Let's begin with a thought experiment. Just imagine that you work at JFK International Airport here in New York City, and you're in a Federal Express facility inspecting incoming packages that have just been pulled off of a jet that's landed from Heathrow Airport in London. And you're clearing these parcels that can be taken on across America and delivered to their destinations. And you see a package from Somalia, and it's addressed to a synagogue in San Francisco. "Hmm," you think to yourself, "that's kind of unusual." So you call over your supervisor, you take a look at it, you discuss the package, and you decide that you're going to put it aside until a bomb- sniffing dog can come over and render its opinion on the matter. Congratulations, you just engaged in profiling. Now, obviously, packages are not people. Fed Ex boxes have neither civil rights nor emotions. People do and we always must be aware of and sensitive to that. However, in a world of limited time, personnel, and money, we have no choice but to focus on those people who threaten to destroy aircraft and the flying public who ride within them. .0

And that is why my team and I urge you to vote in favor of tonight's resolution, "U.S. airports should use racial and religious profiling." Let me emphasize that we do not advocate letting airport security personnel cater to their own personal ethnic or ecclesiastical biases. Instead, we want the TSA and others to recognize that the current threat to passengers and airliners comes almost exclusively from one source, and we all know what it is, young males between about 18 and 35 who practice a fundamentalist strain of the Islamic faith, and generally hail from the Middle East, as well as largely Muslim nations in Africa and South Asia. There are exceptions to this profile, but they're quite rare indeed. We learned about this profile on September 11 when all the hijackers who attacked us that day fit the parameters that I've identified. .2

Had the security personnel at Newark, Dulles, or Boston-Logan Airports profiled these hijackers, they might have been stopped and nearly 3,000 people who were killed on 9/11 would be with us here today. In a few minutes you will hear from my colleague, Asra Nomani. She will demonstrate that this profile did not begin on September 11 and it did not end then either. My colleague, Bob Baer, a former intelligence officer, will explain that what we advocate is a response to intelligence. He also will show that preventing terror at and through America's airports involves responding to the evolving threat profile that faces us at any given time. Now, mind you, we are not arguing that the TSA should send anyone named Mohammed to be water boarded somewhere between the first class lounge and the Pizza Hut. However, if you are a male between about 18 and 35 and are traveling on a Middle Eastern passport or one from a predominantly Muslim country, it might be smart to ask you a few extra questions, carefully peruse your papers, and if things seem unusual we perhaps should take a closer look at your luggage. .6

This really is not religious or racial profiling so much as it is terrorist profiling. We want to increase, not decrease, the probability that our security personnel will stop terrorists before they can board passenger jets, and once again turn them into bombs and missiles. This differs little from what police departments do today to deploy their limited resources in order to raise the odds of successfully reducing crime. If the NYPD were seeking a mafia hit man who just flew in from Naples to whack somebody, I doubt the NYPD would dispatch squad cars to 125th Street and Malcolm X Boulevard. If you set up a sobriety checkpoint, if you’re a police department, you most likely would put it somewhere near bars, not close to churches. Similarly, if a wave of bank robberies were committed by a black man between ages 45 and 50, and if he were just under six feet tall, and lived in Manhattan’s East Village, I would not be shocked if the police stopped me and asked me a few questions. .0

Why? I perfectly fit that profile. Now, would that leave me thrilled and delighted? Probably not, but I would know that these law enforcement officers were doing their jobs, and that, I would understand. Does my team advocate violating people’s rights? Absolutely not. Remember, among the rights that officials need to protect is the right to fly on a plane and assume that it will land at your destination with you and your fellow passengers alive and well at your destination. That right deserves maximum attention from those who we pay to keep us safe from those who want us dead. Our opponents might say that the profile we've identified would miss someone like Timothy McVeigh, the non-Muslim man who blew up the Federal Building in Oklahoma City. However, to look more carefully at someone does not mean that you ignore everyone else. This resolution is not an either/or proposition. .4

Terrorist profiling can exist with wisely applied traditional screening measures for other passengers. Finally, what if we avoid terrorist profiling? At best, we will keep wasting scarce resources by subjecting everyone to the same time consuming often humiliating searches that have generated such public outrage recently. The TSA can keep checking the prosthetic breasts of American women who have endured mastectomies as happened a few months ago to Cathy Bossi, a 32-year veteran airline employee. At worst, TSA officers might come face-to-face with a bomb-wielding passenger who fits the terrorist profile but then breezed him through security because they don’t want to make him uncomfortable. The result could be a deadly airborne attack that we all have feared since September 11. My team wants to prevent this from happening and we hope you do, too. Please join us in supporting tonight’s resolution, “U.S. Airports should use racial and religious profiling.” Thank you very much. .7

### Moderator
Claim: Thank you, Deroy Murdock. Well you’ve just heard the motion restated, “U.S. airports should use racial and religious profiling.” And now heading to her lectern to argue against this motion, Debra Burlingame who is actually a career flight attendant and you went to law school and you practiced law. On September 11, your brother took off at the controls of Flight 77 before the hijacking. He died in the crash into the Pentagon. I want to ask you now that you’re no longer practicing law and you’ve left the airline business, what would you say is-- how do you define yourself, your role?

### Scientific Advocate (SA)
Claim: Well I started off just trying to find out what happened to my brother that day and it evolved into essentially becoming a political activist. But I would just basically say I’m a troublemaker and I hope to cause some troubles for those guys over there tonight.

### Moderator
Claim: Ladies and gentlemen, let’s see how you do, Debra Burlingame.

### Scientific Advocate (SA)
Claim: Thank you very much. Thank you. .9

I stand in opposition to the resolution that U.S. airports should use racial and religious profiling and I do so not only as the sister of someone who died at the hands of terrorists in the cockpit of his commercial airliner but also as someone who worked in that industry for many years. I did so in the late 1970s into the 80s at a time when aviation became the obsessive focus of international terrorists and trans-national terrorist organizations. It is different now. It has evolved and it has gotten a lot more complicated. The environment up there is basically the same. The reason for my opposition is simple. It simply doesn’t work. It results in a waste of time and resources. It is counterproductive and by that I mean it causes more harm than any good, any putative good. .0

For those of you sitting in this audience who are neither Arab looking nor South Asian looking, I ask you to contemplate, think back the last time you were at the airport if you were ever pulled out of line when you didn’t expect it and you hadn’t said or done anything wrong and maybe even treated a little peremptory way because the airport recently maybe an unexpected engagement that was quite unwanted and maybe even by your definition quite humiliating. I ask you, for those of you who have been through that who are not Arab looking or South Asian looking or Muslim looking, I ask you to consider what it would be like to experience that every time you go to the airport on every time you fly. It would appear to you, it would feel not like a security measure but a grave injustice because you would be singled out, not for anything you said or did, as I said, you would be singled out simply for the level of melatonin in your skin. .1

And make no mistake, the TSOs who are doing this will not know what country you are from. In fact U.S. travel documents don’t indicate that. Maybe perhaps if you’re showing your ID where you were born. But basically when they’re picking you out of the line, all they’re going by is how you appear. Now I frankly don’t know how U.S. airports would profile on religion because religion is something that’s in your heart or on your head. And I believe that there would be a legal challenge if this question were asked at the airport or if it were somehow required to be in your travel documents or your ID. I think it would fail the Constitutional challenge. So what are they going by? They’re going to be going by, what, head scarves. .4

I will only bring you to the example of the airport security video that was published. You can see it on YouTube of the hijackers on my brother's plane going through Dulles. They look like your typical American people. They're wearing dress shirts and Chinos. And there is nothing in that video that would suggest to you that they are a terrorist or that they are Muslim or that they hate infidels and want to kill them. Not a thing. And I thank you, Deroy. They would thank you, future terrorists, for giving them a blueprint in your description of what not to look like the next time they come to the airport.

Thank you. I hope I pick up some votes there. I'm in favor of behavioral profiling. And I believe that does work. I think we should stop focusing on things. Yes, packages aren’t people. .6

We should focus on behavior because the moment we profile on status, the enemy will seize on it and go in a different direction. I'm going to give you-- try to give you three examples very quick on how behavioral profiling has been very successfully used. There are lots and lots of examples. But here are three that I think are pretty good. I'm going to try and make it under the limit. A guy by the name of Benni Norris, aka, Ahmed Ressam. He was the millennium bomber. He rented a car to get from Canada on the car ferry over into Port Angeles, Washington. At the state of Washington, a very astute customs agent saw him. He had filled out his customs forms incorrectly, so he was singled out, tapped for secondary screening. Her colleague says, “Oh, Diana, we want to go home. It's Christmas time. It's the last car, the last ferry, let it go.” She said, “No, there's something wrong about this guy.” And here is what was wrong. He was sweating profusely in cold, freezing weather in December. .2

She asked him some questions. That went badly. She asked him to open up his trunk. Bingo, explosives, det cords, a map of LAX. He was done.

Mohammad al-Qahtani, the so-called 20th hijacker who came in through Orlando airport, a Saudi national who was, again, brought-- tapped for secondary screening. The inspector asked him questions. His answers were all wrong. He had $2,800 in cash, one way ticket, no return ticket, no hotel, no credit cards, no visible means of managing in six days of vacation travel on 2800 bucks alone. It went downhill from there. But he got turned around. Basically he was given the choice of leaving or going through court proceedings. He left. The next time we saw him was at Tora Bora, the battle of Tora Bora. He ended up at Guantanamo.

And the final one I'll give you-- and again, there are many, many more-- that's Zacarias Moussaoui. .8

He presented himself as a businessman, Moroccan born, French accent, businessman from France who wanted to buy simulator time on a Boeing 747 400, the biggest passenger plane in the sky. But he didn't make sense. And two very astute flight instructors-- I like to say their names because they're heroes. Hugh Sims and Tim Nelson, they thought it was awfully weird that a businessman would be paying for his sim time in a plane that he didn't have any understanding of with 68 100-dollar bills. They pressed their employer to call the FBI, and the rest is history. I could go on and on about the morality or the immorality of doing this. But I'll leave that to my teammates. Please vote for us. Thank you.

### Moderator
Claim: Thank you, Debra Burlingame.

“U.S. airports should use racial and religious profiling.” That is our motion. And now here to speak for the motion, Asra Nomani who is a former Wall Street Journal reporter. .6

She now works on a project investigating, still investigating the murder of Daniel Pearl who was her friend and long-time colleague. She is the only American Muslim on the stage tonight. And I presume to say that you're in the position where you would or-- let me say male members of your family, very likely would be, in this time we live in, those who would be pulled off in line. Do you-- am I being too presumptuous on that, or do you think that's realistic.

### Conspiracy Advocate (CA)
Claim: No, I mean, I was happy to take the train from DC today.

### Moderator
Claim: All right. Looking forward to hearing the rest of the argument. Ladies and gentlemen, Asra Nomani.

### Conspiracy Advocate (CA)
Claim: I want to first thank all of you for coming to talk about this really important discussion. We all know it's in the news. We know that it is something that matters to us personally. And I want to thank the panel from the other side and my own teammates for daring to talk about something that is so sensitive that oftentimes it is a taboo topic. .5

And it especially is one inside of our Muslim community. It is one that hurts us. It is one that causes me great pain to actually come and speak to you about. When I first got the invitation, the assumption was that I would be speaking against the motion. But after several years of pondering on this really difficult topic, I firmly believe that U.S. airports should profile based on religion and racial issues. I came to this country at the age of four in the summer of 1969 on a TWA jet from Bombay to John F. Kennedy airport. Ever since then, I have loved travel. I have loved the airline industry. I came from a very conservative Muslim family. Islam has been a part of my life. It's been a part of my being. But something very sad has happened in the 40 years since, both inside of our Muslim community and inside of the airline industry. .5

Inside of our Muslim community, we have had the emergence of a very real interpretation of Islam that justifies the attack on airports and airliners and civilian targets. This is a reality that is really difficult to accept sometimes inside of our community. But it's a truth. And I want to chronicle how this unfolded over these recent years. And inside of the airline industry, we have seen Pan Am leave us. We have seen TWA die off. The airline industry is also under great pressure. Airplane crashes, airline security issues have serious consequences, not just on the traveling public but on this really important industry. . And this issue of profiling has been the taboo topic in the midst of all of this conversation. .4

I do come from a Muslim family. I am brown, for radio audience members who can't see me. My father has Mohammed in his name. He's 80-some years old, but he gets pulled at the security checkpoint. And still I stand before you and I say, profile me. Profile my family. Profile my father because inside of our Muslim community, I fundamentally believe that we have failed to police ourselves. We have failed our country here in America. We have failed our world. I express my deepest sorrow and sympathy to Debra, to all of you who have felt the trauma of September 11. And I recognize that we as a nation, both in the U.S. and inside of our Muslim communities, have largely not yet even healed. .3

We are struggling with how to deal with this very real incredible threat that exists out there. And religion, ethnicity and issues of race have a very direct relationship with issues of violence. A wonderful study by the State University of New York at Albany concluded, what makes terrorist organizations more lethal is religious ideology. When you combine religion and ethno-nationalism, you get a dangerous combination. We saw that dangerous combination on September 11. It was the manifestation of an interpretation inside of our Muslim world that justified an attack on an airport and on airliners. There was a fatwa issued by Osama Bin Laden in 1998 when he had created the international Islamic front for fighting the Jews and crusaders. .3

And he established very clearly in his marching orders, “Bring down their aircraft. Have the attack be one of violence that is pitiless.” He was very clear in what his objective was. And I have before me a Koran that comes from the kingdom of Saudi Arabia. And I want to establish really clearly that this ideology is one that permeates inside of our community, giving young men then the religious justification to do that which they want. And in it it says “Guide us to the straight way.” It's a very simple message. But what the government of Saudi Arabia has done is added into here, “unlike the way of the Jews and the Christians.” And so this ideology is the ideology that fuels the extremism that makes airports and airliners targets. .8

And it's not just the stuff of rhetoric. Bojinka, 1990s, plot by Ramzi Yousef and Khalid Shaikh Mohammed to bring down jetliners coming from Asia to the U.S. Scotland, Glasgow, airport attack attempt, the millennium bomber attempt in the Los Angeles Airport was also a successful event, not at just behavioral profiling, but a warning had gone out to look out for men of Middle Eastern origin, and so the customs officials actually had an eye out for the man who was trying to put bombs on baggage carts at Los Angeles Airport. .0

And 2007, JFK Airport, that airport where I arrived, there were young Muslim men who said, "Let us attack John F. Kennedy International Airport because any time you hit Kennedy it is the most hurtful thing to the United States, to hit John F. Kennedy, wow, they love John F. Kennedy, like, he's the man. If you hit that, this whole country will be mourning. You can kill the man twice." This is the stuff of the operations and the actual attacks that are inside of our community. I'm not happy that this is happening inside of our community, but I tell you that we must be honest about it, and I urge you to vote for the motion that U.S. airports should use religious and racial profiling. Thank you so much.

### Moderator
Claim: Thank you, Asra Nomni. So here's where we are. We are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan of ABC News. We have six debaters, two teams of three, arguing over this motion, "U.S. airports should use racial and religious profiling." .3

You have heard the first three opening statements, and now on to the fourth. I'd like to introduce and welcome to his lectern Hassan Abbas, who is from-- comes from Pakistan, has been living in the United States since the beginning of 2001. He was associated at that time with Harvard. He's now at Columbia. Beginning of 2001 he was working on his master's. He now holds a Ph.D. but in the interim, after the attacks on September 11, he wrote a book that made him very unpopular back in your home country because you said what?

### Scientific Advocate (SA)
Claim: Because I decided to declassify some of the stuff on my own, and had talked about the militant groups and their linkages with the State, and I criticized the darling of the West, Pervez Musharraf.

### Moderator
Claim: And you were for a long time a member of the administration of Pervez Musharraf.

### Scientific Advocate (SA)
Claim: I was part of the police service in Pakistan.

### Moderator
Claim: Before you came. Ladies and gentlemen, Hassan Abbas. .0

### Scientific Advocate (SA)
Claim: Thank you very much. First, it’s a great honor and privilege to be here today. I would like to right in the beginning just be very clear about the topic. And let’s exactly focus on what we are looking at. U.S. should profile based on racial and religious identity. This whole discussion and debate about liberty and security is not a new one. Even the cabdriver who brought me here, because I was coming from Colombia, it was about 40- minute drive so we started discussing the issue. He was from South Asia. And when I was trying to explain him-- I was looking at my notes and trying to explain to him what this debate is about where he was taking me, he said-- he stopped me because he was listening to the NPR the whole day, he said, "Well, you are talking about these Swedish grandma, Swedish grandmas who have to be patted down." And I said, "No, this is not-- be focused--." .2

The central issue I would argue is not about the different ways and mechanisms and the different strategies, that will be used in profiling, there are three fundamental issues, the first and the foremost is about whether it is legal and constitutional, secondly, what law enforcement tells you, what these different police organizations, there are so many people who are involved in the security sector, what is their general consensus, and the third, and I think a very important point, is what is the impact of this policy on the social fabric of society? First, very clearly, it is illegal and unlawful. Why? When we are saying that a person of a certain religious identity, certain religious belief will be checked, how will you do that? You'll ask them-- as Debra rightly pointed out, whether you'll ask them to bring their ID cards, or you will ask, Muslims within the United States about five million or so and all Muslims from around the world to bring an ID, whether they are Muslim. .0

So by that definition, and I’ll have to ask them to also to bring this ID whether they’re Christian, whether they’re Jewish, whether they’re Hindu. My argument is that is in principle a violation of the Constitution. Let’s leave even this argument on the side and let me move on to something which is more profound which is that this kind of religious profiling and racial profiling is not something which is an isolated thing at the airport. This is something which transcends, you start looking at that community in a way that is “Okay these are the guys who are always stopped at the airport because they pose a certain threat.” It has an impact on the job opportunities for that community. It has an impact on their status in society. It has an impact on the kids. .8

And I give you a few examples also about how perhaps later on, examples which tell you what the kids from these communities, Muslim community here we are talking about, go through because then there is a threatened environment where you blame the whole community and to Asra with all due respect. I am absolutely not ready to apologize for all the bigots and the narrow-minded people who conduct terrorism. I would argue, just look at the data bases. There’s a new study which is not mentioned, only in the academic circles, but was mentioned in 2010 on CNN. It tells you very clearly that the whole threat about extremism coming from the Muslims is an exaggerated thing. Look at the latest Rand study, it’s a major think tank, it’s not some small research institute in some corner. It’s a major think-tank getting funding from U.S. government also. Rand Corporation says the total number of terrorism incidences which involved radicals from the U.S. .6--were 46. In some cases there was only one person involved, in other cases, about three people. It’s another matter how many of them were convicted. But just compare this data set which is on the FBI’s website. Compare the total number of terrorist attacks within the United States from 1970 to 2009. It is so very clear. The number of terrorist attacks, for example, those that were happening in 1970’s where much more lethal, from much more diverse communities. So the larger argument I am making is we need smarter strategies. We need strategies which will be able to utilize with limited resources. Another issue, related to this is, this often is a cover-up, a cover-up for bureaucratic incompetence and their failures. It’s very easy for them to say because we our intelligence has failed because of all the different ways we could have profiled those terrorists have failed, if you cannot distinguish between a Pakistani Taliban or an Afghan Taliban and so many other groups. .1

The tendency is to just call all of them al Qaeda, on one side, just call--on the other side are people who are Taliban. It is very important to note how many of these groups are posing a terror threat to the United States. I’m not interested in the total number of terrorist attacks all over the world. The suicide bombers in Sri Lanka or what’s happening with the Islamic movement in Uzbekistan in Central Asia or the suicide attacks in Pakistan for that matter. I am as a Pakistani-American interested in those people who are attacking or who are posing a direct threat to the United States. Look at the data set in the last nine years and it will make it very obvious. One last personal anecdote and there are many other arguments about the legality of the whole issue that I’ll come to later, I would even argue that racial and religious profiling is already taking place. Just a brief anecdote. .6

I have hardly a minute or so to tell you. I am an academic. I teach at Columbia, previously at Harvard as was mentioned. About six, seven months ago I was invited to go and give a lecture to the NATO officers in Germany who were about to be deployed to Afghanistan. And on the way back and by the way the last 10 years despite all my academic work and my work about militants, I always am screened and that’s fine. As a former law enforcement officer, here I agree I’m absolutely fine with that. But if I am stopped every time. The last time the question I was asked “So what were you teaching.” I said “About terrorism.” They said “Really? So did the NATO officers pay you?” I said yes. “Whether that cash is in your bag?” I said “No, that cash is not in my bag.” But I was stunned. I would like to tell you and I am about to be done with my time, my question is I’m fine when I’m profiled. .4

But when I’m traveling with my family and every time my daughters ask me, after four hours of waiting that “Baba, Dad, are you a criminal? Have you committed some terrorist attack?” I would like to--

### Moderator
Claim: Hassan Abbas, I'm sorry, your time is up. Thank you very much. Our motion is “U.S. airports should use racial and religious profiling.” And here to argue for the motion, Robert Baer, a former CIA agent making his way to the lecturn. Bob there is the CIA guy journalists love to interview because he really did it in the late '70s, through the '80s into the '90s. He really was a spy in the Middle East and wore disguises and jumped out of airplanes. And then he wrote a terrific book about it, a little bit naughty because he told a lot of secrets. It was turned into the inspiration for a movie called “Syriana.” And Bob, apparently you inspired the George Clooney role. Did you see the resemblance all along?

### Conspiracy Advocate (CA)
Claim: I guess so. I was starting to get thick around the middle, yes. It's true. .8

### Moderator
Claim: Ladies and gentlemen, Robert Baer.

### Conspiracy Advocate (CA)
Claim: Thank you. You know, all these arguments are telling. But I'm going to approach profiling from-- first I'd like to say that I have a daughter from Pakistan. And I have a lot of Pakistani visas. And she's from Faisalabad, it's from a center of terror, a lot of terrorists have come there. And I would fit that profile as well. And I'll say it now. I don't mind being stopped. And I have been stopped. But we have-- you have to look at this-- what I think is a mistake is if we let this devolve, this argument, into Islam against the West or the United States against the West. Let me take an example. It may seem a bit facetious, but it's a very real one. The secret service has a source inside the Aryan brotherhood. .3

A source says there's going to be an attempt on a black American president. It's going to take place inside Washington, D.C. And that's all the details I have. Maybe it's going to be a rocket. Maybe it's going to be a service to air missile that can hit a helicopter. The D.C. police are informed, the FBI, Homeland Security. And all we know at this point is it's probably going to take place in a week. What does the secret service do the FBI. They do triage. They are going to be looking for white males with tattoos, short haircuts, frequenting certain places of a certain economic stature. Those people are going to be profiled. So I think it's important to get away from this is a crusade against Islam because that's not what it is. Let's take the Israelis. .9

Whatever side you come down on that, they have a certain experience in the Middle East. Call it profiling, call it what you will. I was in Lebanon in the '80s. And their assumption when they invaded in 1982 is they were going to have a problem with Palestinian Muslims. By 1987, the problem was not with Palestinian Muslims. It was with Christian women. First suicide bombers were Christian and women. Their profile went from religion to a fairly light Maronite and orthodox Christians.

The whole idea of profiling has to do with triage. If you're TSA or the FBI or the CIA, you have a limited amount of time, and you have to understand the background and the religion of people. Let's take Iran today. Everybody calls it a terrorist state. .8

But give me one example when an Iranian has committed suicide either on a plane or a car bomb or anywhere else. They just don't do it. Look at the history going back to 1980. Yes, they did on the front. But they were never involved in terrorism. If I am the TSA supervisor, and you have a plane and a threat, and you can only check a certain amount of people, I would write off the Iranians first of all. Within Islam, there is profiling in Saudi Arabia. They can pinpoint the cities, the villages and the school of Islam that is likely to commit suicide bombings. When's the last time there's been a bombing on a Saudi airline? Hasn't been one. They know who's getting on. And they can identify the religious school which happens to be Hanafi, that has a proclivity for this. .3

Yes, they profile. But at the end of the day, we-- the problem is we are a liberal society. Our intelligence, having served 21 years in the CIA and having tried and failed many times, is not good. We are not the Israelis. The Israelis know every single Palestinian, who gets on, who's safe, who needs to be searched, who doesn't.

Scanners don't do it. You can take PETN and you can insert it in a cavity, and the chances of a scanner picking this up are remote. Behavior, look at the 9/11 bombers. They went to bars the night before. They were drinking. If the FBI had been after them, they wouldn't have fit a profile for-- nothing in their behavior before-- they didn't go to the mosque. .6

They didn't do any preaching, anything like that. And once they got on the airplane, I have seen the film. They looked pretty normal to me. But had TSA been around, and had they looked at this, they could have figured out where those-- the muscle 15 came from in Saudi Arabia, and say, yes, that school of Islam had a proclivity for doing suicide bombings.

Another thing, we go back to triage and why this profiling is in a sense repulsive because it is based on a certain amount of racism. Let's face it. But there isn't a choice. And because the triage changes from day to day, you look at the Tamils, there's still a war going on. If you're at JFK, and you get a threat to Air India, it's going to be a suicide bomber, and Air India and TSA have to go through triage. They are going to be looking at people who are darker, because the Tamils are. .8

They're Hindus. They have certain names. And in no way is this-- you are selecting them out for a secondary search. This will happen in almost any good airport in the world. I just came back from Sydney. They stopped me. They wanted to know who I was. I'm white, middle class. Don't look like a suicide bomber. But they did a credit check at the airport, pulled me aside because I was an American. I realize it doesn’t have anything to do with religion, but they profiled me. They established who I was. I was let on that airplane. So this is why I urge that as difficult a decision it is, that we have to profile to help our intelligence services. And there isn't a choice.

### Moderator
Claim: Thank you, Bob Baer.

Our motion is “U.S. airports should use racial and religious profiling.” And speaking finally against the motion, I'd like to introduce Michael Chertoff. .9

When September 11 happened, and the U.S. responded by creating the Department of Homeland Security, he was its first secretary. And I want to ask Michael, at that time, was there an internal debate about making profiling policy?

### Scientific Advocate (SA)
Claim: Actually, John, I was the second secretary from the time of 9/11. I was the head of the criminal division of the Department of Justice. And it was my responsibility to track the hijackers and be part of the first efforts to prevent this from happening again. And, of course, I carried that on when I was secretary of Homeland Security, where my top priority, frankly, was making sure it didn't happen again. And I am pleased that it didn't, and it hasn't yet. But it's a constant struggle.

### Moderator
Claim: My correction, it was Tom Ridge. But I get back to the question. Was there--

### Scientific Advocate (SA)
Claim: The answer is--

### Moderator
Claim: Was there a debate?

### Scientific Advocate (SA)
Claim: There was a debate. And we sat at various times with the professionals, people with lots of experience at border protection and aviation protection and the FBI. .6

And there was a unanimous belief that racial and religious profiling would be not only ineffective, but counterproductive from a security standpoint.

### Moderator
Claim: All right. Let's hear your argument. Ladies and gentlemen, Michael Chertoff.

### Scientific Advocate (SA)
Claim: I want to-- I want to praise my adversaries because they've done on eloquent job of arguing for a different proposition than the one you were asked to vote on a few moments ago. The proposition here is, do we engage in racial or religious profiling? And the answer to that, I submit, is no. The proposition they argued for is do we engage in behavioral profiling. Do we look at characteristics of people's behavior, where they went to school, where they traveled, things that they might have done, people they might have known. And do we use that as part of the basis for determining whether we need to take a closer look at them. And I think the answer to that is yes. That's good law enforcement. It's good intelligence. But it's not based on race or religion. .2

It's based upon things that people do, places they go, schooling they've had, people they associate with, people they communicate with, people who buy their tickets. You know, Robert Baer talked about the 9/11 hijackers not being susceptible to behavioral profiling. I had the responsibility for investigating that and for authorizing the prosecution of Moussaoui, and I can tell you, had we in fact examined their behavior going back over a period of time, we would have seen the connections to radicals and extremists that would have tipped us off, that we should have taken a closer look. That's a great argument for behavioral profiling, it's a lousy argument for racial or religious profiling. You know, Deroy talked about the class of people that he thinks we ought to be looking at, what race and what religion, and the problem is that it's the wrong set of principles to apply here. What is the race we ought to look at? He said, "Well, we ought to look at people who are Arabs or people from Muslim countries." .7

Well, does that mean Indians, for example, most of whom were Hindu, some of whom were Buddhists? Does it mean people of Asian descent who live in South Africa? What about Africans and African-Americans? Abdulmutallab came from Nigeria. Does that mean Deroy ought to be pulled aside because he's an African-American? The sad reality is that there is no single group, ethnicity or a group signified by its appearance, that you can identify by looking at them in a way that will tell you that they are an extremist or not an extremist. Let's talk about some of the more notable terrorists that have been apprehended in the last nine years. There's Jose Padilla, not from South Asia, a converted Muslim, came from Chicago. There's Bryant Neal Vinas, came from Long Island, his parents were Catholic, he converted, he went to Pakistan, he trained, he came back to try to blow up subways. Daniel Maldonado went to Somalia. He was born in New Hampshire, again, Catholic parents, converted. .2

None of this would be evident to the naked eye if this person went through the airport. How about this, would you stop, for example, Debra Burlingame as opposed to Asra? Well, according to my adversaries, they'd stop Asra but not Debra because she's blonde and Caucasian. Here's the problem, Colleen LaRose, 46-year-old, blonde hair, blue eyes, Philadelphia, radical extremist, sought to recruit others to blow up a cartoonist in Denmark. On the internet she said, "I can evade detection because I do not look like everybody's conception of what an extremist is." And then there was Jamie Paulin- Ramirez, her co-conspirator, another blonde woman, this one with a six-year-old child, who was pregnant. She was another extremist radical. Deroy says, "Well, we ought to look at males because we know the males are the ones who are the terrorists." LTTE, the extremist group in Sri Lanka, has trained female suicide bombers, including one who in April, 2006, masqueraded as a pregnant woman in order to kill eight people and wound 27 others. .3

The problem with using racial and religious profiling is it takes you down a road to looking at people who you don’t need to look at and avoiding looking at people that you should look at. The fact is it would be an engraved invitation to al-Qaeda to recruit exactly the kind of people who don’t fit the profile. And this is not speculation. I said this publicly when I was in office, and it’s been said by everybody in the intelligence community, we know that the targeting that al-Qaeda has undertaken in the last four or five years in terms of recruitment has been deliberately aimed at Westerners who have Western passports who don’t fit the stereotype of what a Muslim looks like and who therefore can pass under the principle of racial and religious profiling while we’re spending our time looking at Asra, who we really shouldn’t be worried about. .6

Finally of course I guess there’s the argument that, "Well, maybe we don’t look at people’s race because if we do that, based on our past experience, it’s going to basically include everybody, including blonde-haired blue-eyed women like Colleen LaRose and Jamie Paulin-Ramirez, but we ought to look at religion.” But here’s the problem, how are we going to look at religion? Are we going to ask people at the airport what your religion is? Do you think the terrorists are going to say, "Oh, I’m a Muslim"? No, they’re going to say, "I’m a Presbyterian." They’re going to walk in with a big cross, if not a nun’s habit. I mean, the reality is these people are not stupid, and the more you target on obvious but misleading characteristics, the more you invite them to recruit in a pool that doesn’t meet that set of preexisting prejudices and biases. Look, if I believed that it was a foolproof way to tell from someone’s appearance who is dangerous when they get on an airplane, I would say political correctness be dammed, let’s pick people who meet that appearance. .7

Certainly when we have a description of somebody, a particular person, and we’ve had this experience, we will absolutely look to people who fit that description. But the problem is, the proposition that is argued here doesn’t meet those standards. I challenge the adversaries to tell you what is the race, what is the appearance that they would rely upon? I challenge them to tell you how are they going to know what religion people are? Are we going to have to start putting religion on our driver’s license? Should we wear little arm bands? Well, we don’t want to go down that road. We know where that wound up 50 or 60 years ago. I suggest to you, as hard as it is, and it’s tough because we all know that we personally are not terrorists and we don’t like to be searched. But more important when you get on an airplane is we want to be sure the person next to us isn’t a terrorist. And the way to do that is look at behavior, to use intelligence and frankly sometimes to use scanning and screening tools but not to rely upon racial or religious pre- conceptions which will only mislead us and ultimately, frankly, probably cause more damage than good. Thank you. .8

## Round 2

### Moderator
Claim: Thank you, Michael Chertoff. And that concludes round one of this Intelligence Squared U.S. debate. Now we move on to round two where the debaters address one another directly and answer questions from you in the audience and from me as well. We’re at the Skirball Center for the Performing Arts at New York University and on NPR stations across the nation. I’m John Donvan from ABC News and at this Intelligence Squared U.S. debate we are arguing out this proposition, “U.S. airports should use racial and religious profiling.” On one side we have Robert Baer, formerly of the CIA, Deroy Murdock, a columnist and Asra Nomani who is a former journalist for “The Wall Street Journal” and an American Muslim who recognizes, she says, the need for profiling. This side arguing that profiling is just a recognition of the fact that at this moment the threat comes from radical Islam and it’s an unfortunate necessity that, they also argue, that it works. Not to use it would be immoral. .1

Arguing against this motion, Hassan Abbas from Pakistan, Debra Burlingame whose brother died on September 11 in the plane that crashed into the Pentagon, and Michael Chertoff who was the second Secretary of the Department of Homeland Security. They are arguing that profiling is corrosive, basically that it is un-American, but most importantly, that it does not work. It gets you looking at the wrong people and missing the right people. I want to go first to you, Asra Nomani, you mentioned your dad, you said, is in his 80’s and he has been pulled off of lines at airports.

### Conspiracy Advocate (CA)
Claim: He has.

### Moderator
Claim: And that obviously being a case of a profile. I want to know in what way does your dad, other than the fact that he’s a Muslim, fit the profile of a terrorist. How does that make sense?

### Conspiracy Advocate (CA)
Claim: He’s got visa stamps from Pakistan, Saudi Arabia, Jordan so you’ve got travel through some of these nations that are problematic. .1

And I think basically there’s the idea that we have a religion that you know characterizes all of the attacks that we’ve talked about. I mean, I’m really glad that Michael, Debra and Hassan chronicled for us who the attackers have been. What is the one distinguishing characteristic of all of them? They’re Muslims. We cannot deny that fact. We don’t pretend to have the answers on how we’re going to profile well, I’ll be honest with you. This is something that we have to identify. But the truth is that if we exclude religion and religiosity and interpretation of religion in our assessment of risk as was done to my father then we are not being honest about the threat as it exists today.

### Moderator
Claim: But do you-- obviously we all know that your father wasn’t a threat but did it make any sense that day at the airport to pull him off the line given his age? .2

### Conspiracy Advocate (CA)
Claim: Well you know, does it make any sense what we’re doing with the pat-downs? You know, what was happening was that, I think, we’ve got this very impractical approach to security at airports right now and what I really believe we need to do is get a more common sense approach. We need to really look at who the adversary is and be very realistic about those type of individuals. So my dad may not fit because also there is as Deroy mentioned in the research a clear age in which the threat has been coming from, age from about 20 to 30. And so I would love, if I could, to ask a question of Hassan.

### Moderator
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: I was really glad that you mentioned the RAND report. I think you have it. What’s the name of it again?

### Scientific Advocate (SA)
Claim: The report, Would-be Warriors: Incidents of Jihadist Terror Radicalization in the United States Since September 11, 2001, by Brian Jenkins.

### Conspiracy Advocate (CA)
Claim: Okay, so would-be warriors, an important point. .3

Hassan, what did the report establish related to the ethnicities of the individuals? There were 125 individuals that they looked at. And so do you remember what some of the ethnicities were that they chronicled?

### Scientific Advocate (SA)
Claim: Yes. They have chronicled in some cases, people who were radicalized within the U.S., someone who is born and raised here. For instance, I am no more interested in the ethnic background of that person who is born and raised here, whose equal right to be American or not.

### Conspiracy Advocate (CA)
Claim: But it's really interesting because--

### Scientific Advocate (SA)
Claim: --and so how is that relevant?

### Conspiracy Advocate (CA)
Claim: It's really interesting because, I mean, I really recommend Hassan's book, which is “A Drift into Extremism,” which chronicles incredibly the militancy inside of Pakistan. And in fact in this RAND report, what they established was very clear ethnic groups from which unfortunately this radicalism has emerged. And what are those nations? Pakistani, Yemeni, Jordanian, Egyptian, Iraqi, Lebanese, Palestinian origin. And what connects them? Islam. .4

I mean, it is a sad reality, but unfortunately, these boys, our lost sons--

### Moderator
Claim: Let me let your opponent, Michael Chertoff respond to that.

### Scientific Advocate (SA)
Claim: I think the problem is this. Asra, I don't disagree that there is an ideology that ferments and motivates extremism. The difficulty is that ideology is only a small percentage of the total population of the religion, that people who are motivated to get violent. And it's not evident on the face of the person coming through the airport that they meet that ideology. Part of the problem is this. One of the-- again, you know, I mean I hate to disturb a good argument with the facts. But much of the recruiting that occurs in the United States occurs in prisons. And it occurs, frankly, with African-American prisoners who become Muslim extremists.

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: Now, they don't fit that profile. They come from Los Angeles and Compton. They don't come from Pakistan and Yemen. How are you going to deal with them when they go through the airport? The problem is what you're trying to argue is this: If we look at a certain class of people, we don't have to look at anybody else. .1

And in that argument, you are giving the enemy the tool that they have told us they want, which is the ability to use our own prejudices as leverage to slip by our defenses.

### Conspiracy Advocate (CA)
Claim: With all due respect, I mean, we are not talking specifically only about religion and race. At the end of the day, we have to be complete in our analysis. So we have to include religion, race, behavioral and all of the other factors. We don't look at just religion and race. I mean, this is exactly why driving while black becomes a problem because race is the only indicator. But what we're arguing is that include religion and race in the analysis because that's what--

### Moderator
Claim: Does the other side-- anybody on the other side object to that, an inclusion-- let it part-- on the menu?

### Scientific Advocate (SA)
Claim: I actually do, because--

### Moderator
Claim: Debra Burlingame.

### Scientific Advocate (SA)
Claim: I thought the resolution was resolved, that U.S. airports should use racial and religious profiling. .8

And I don't think there's anything in there about behavioral or all the other--

### Conspiracy Advocate (CA)
Claim: Well, I don't think it's--

### Scientific Advocate (SA)
Claim: --all the other components.

### Conspiracy Advocate (CA)
Claim: It's not exclusive. It's absolutely not exclusive. And when you-- When you-- when you--

### Moderator
Claim: Let's-- let's let Debra continue, and then we'll come back to you.

### Scientific Advocate (SA)
Claim: Because my understanding is that there are people who think that you can-- for instance, how would the screeners at the airport know that your 80-year-old father, what his religion was based on his passport stance because that means anyone who works with “Wall Street Journal” who's active in foreign reporting, they're going to be pulled off too. I mean, I just think that it-- you're going down a road that-- where you're mixing apples and oranges. And I think that, again, the resolution isn't inclusive. It says racial and religious profiling.

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: That's why I'm on this side of the panel because I do not believe that-- I don't know how you would administer that. .4

If you-- if you object to the pat downs or some of the treatment that's going on at the airport right now, how are TSOs, who are the airport screeners-- how are they going to be trained to-- to look people over and employ the kind of discretion that you're talking about in the-- in that sort of flash encounter they have with, I believe it's anywhere from 500 to 800 million passengers a-- a year in U.S.-- U.S. international-- U.S. carriers. So I guess what I'm saying is that I don't see how you can put-- if you're going for behavioral profiling, what does race and religion add? And how is that going to be administered by fallible people at the airport?

### Conspiracy Advocate (CA)
Claim: Well, the important point is that the motion is not exclusive. That's-- it is completely-- can include all of the other elements--

### Moderator
Claim: Let me bring in Deroy--

### Conspiracy Advocate (CA)
Claim: --that are part of our issue.

### Moderator
Claim: Because we haven't heard from him in a bit. Deroy Murdock--

### Conspiracy Advocate (CA)
Claim: I would agree with what Asra's saying. As I pointed out in my opening remarks--

### Moderator
Claim: --arguing for the motion.

### Conspiracy Advocate (CA)
Claim: --this is not an either/or proposition. .4

I believe that we ought to include, in our airport activities, racial and religious profiling. But nothing here in the resolution says that would be to the exclusion of behavioral profiling or anything else. I think we want to look at all of these things and this-- as we are doing now, we need to include this.

### Moderator
Claim: I do think that that’s the sense of this resolution.

### Conspiracy Advocate (CA)
Claim: This is clearly what-- clearly what is the threat we face today. And I think it's important to point out, as I think we've alluded, that the threat profile can change. We heard earlier about Puerto Rican terrorists. There is a wonderful bar here in town called Front’s Tavern That was blown up by people who wanted Puerto Rican independence back in the 1970s. Even earlier than that, back in the 1950s, they opened fire on the floor of the U.S. House of Representatives. Well, over time, people who were interested in independence for Puerto Rico have expressed that through peaceful means. There is no longer a violence profile regarding people who are interested in Puerto Rican independence. It's really not something which we check for. At the moment, however, those people who we do see as targeting our aircraft and people upon them happen, almost always, to be people who are Islamic and very often from the Middle East. .0

### Moderator
Claim: Michael Chertoff.

### Scientific Advocate (SA)
Claim: But Deroy. Sorry. The Hispanic names I mentioned were not Puerto Rican terrorists. They were Islamist extremists.

### Conspiracy Advocate (CA)
Claim: That's exactly the point I'm making.

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: Precisely the point I'm making.

### Moderator
Claim: There was a threat profile back in the-- in the '50s through the '70s, when there were people who were for Puerto Rican independence and expected that violently. That no longer is the case so, that profile is just--

### Moderator
Claim: Right.

### Moderator
Claim: We're talking about the profile that exists today.

### Scientific Advocate (SA)
Claim: Are you advocating that we--

### Moderator
Claim: Let me bring Hassan Abbas. Hassan Abbas.

### Moderator
Claim: religion?

### Scientific Advocate (SA)
Claim: And I--

### Moderator
Claim: Arguing against the motion.

### Scientific Advocate (SA)
Claim: --may I ask one question? You have started your argument, by saying-- your first sentences were we have limited resources. We are short of time. So now you are arguing that every possible, everything that can be conceived of should be added.

### Conspiracy Advocate (CA)
Claim: Well, let's--

### Scientific Advocate (SA)
Claim: And you're asking--

### Conspiracy Advocate (CA)
Claim: Let's try this. Well, how--

### Scientific Advocate (SA)
Claim: Let me complete the argument. Let me complete the argument.

### Conspiracy Advocate (CA)
Claim: I’m saying there are--

### Scientific Advocate (SA)
Claim: Now you are arguing add 10 more things.

### Conspiracy Advocate (CA)
Claim: Well, let's--

### Scientific Advocate (SA)
Claim: That will become much more complicated.

### Conspiracy Advocate (CA)
Claim: I'm-- we're talking about adding two. I'm sorry. Go ahead.

### Conspiracy Advocate (CA)
Claim: Let's think about--

### Moderator
Claim: Wait. Bob Baer, do you want to come in, and you can pass if you want.

### Conspiracy Advocate (CA)
Claim: I go for the inclusive. .3

I mean, you know, with Christmas day bomber, he was from Nigeria. He was black. He had been to Yemen. He was a Muslim. He was traveling with no luggage. Bought his ticket with cash. I mean, he should have been profiled. And part of it was because he was Muslim. I mean, but let me go back--

### Scientific Advocate (SA)
Claim: How would anyone know he was Muslim? How would that--

### Conspiracy Advocate (CA)
Claim: You look at the name. If you-- you can look at the names. His name is an Islamic name. It just does.

### Scientific Advocate (SA)
Claim: Like Daniel Maldonado, is that Islamic?

### Conspiracy Advocate (CA)
Claim: What?

### Scientific Advocate (SA)
Claim: Daniel Maldonado an Islamic name?

### Moderator
Claim: No, but--

### Conspiracy Advocate (CA)
Claim: I think the point –

### Scientific Advocate (SA)
Claim: Jose Padilla.

### Moderator
Claim: I think the president of the United States has a Muslim name, and he's a Christian.

### Moderator
Claim: I'm sorry.

### Conspiracy Advocate (CA)
Claim: Now. But the point is when we do-- the point is that when we do profiling, we don't have to be stupid about it, either. I mean, it's-- it's very true. And if I could, I mean, I would suggest to Hassan's question. .6

I mean, how about if we take a few dollars away from this new security system that we have called cop-a-feel security, and basically turn it to some intelligent analysis of what the threat is about.

### Moderator
Claim: I don't think the other side disagrees with that though.

### Conspiracy Advocate (CA)
Claim: I'd like to say one thing. You know in 1954, the first state hijacking was conducted by Mossad, by Israel. I would have hoped, if there had been a TSA at the time, that they would have started looking at Israeli Jews. And would I have been called anti-Semitic at the time? Absolutely. But the fact is that was the first hijacking. It has nothing to do with Islam.

### Scientific Advocate (SA)
Claim: I still want to challenge--

### Moderator
Claim: Michael Chertoff.

### Scientific Advocate (SA)
Claim: --the other panel to explain how you're going to tell who is a Muslim since presumably the enemy is going to lie about it. And since we don't, at this stage of the game, have travel documents that disclose your religion, it strikes me the premise of your argument is that you're going to be able to tell just by looking at somebody if they're a Muslim. And I defy you in the face of the actual experience we've had to say that that's possible. .3

### Moderator
Claim: Bob Baer.

### Conspiracy Advocate (CA)
Claim: Well, it's triage. It's never going to be completely accurate. But if you take a black American who just spent the last five years in Yemen, it wasn't for--

### Scientific Advocate (SA)
Claim: But you're changing the-- I agree with you. If a guy spent five years in Yemen, absolutely, look at him. That's behavior.

### Conspiracy Advocate (CA)
Claim: And then you ask him if he's converted.

### Scientific Advocate (SA)
Claim: But that's behavior. What you're not arguing, we all agree, I think, that if someone spent eight-- you know, five years in Pakistan or five years in Yemen, you might want to ask them more questions. This resolution says-- talks about racial and religious profiling. And we know what that is because we saw it on the New Jersey turnpike 10 years ago. That is you see somebody, you say that person's-- as in the case of the turnpike, black. They're driving while black. I'm going to pull them over. That's racial and religious profiling. And that's what I think we're

### Conspiracy Advocate (CA)
Claim: That's not what we're talking about at all. That is absolutely not what we're talking about. There is a phenomenon where they want to talk now about flying while Muslim to compare it to that same issue of driving while black. .5

But the truth is that we don't have to be discriminatory in order to be discriminating. We don't have to be prejudicial if we're going to be pragmatic. We can be very realistic about this. And just to point out this issue of threat, there have been 60 incidents since 1970 of attacks on airports and airliners. And in 1970, who were the attackers? It was the Jewish Defense League, the Black Panthers, Black September, so the threat was very different from the threat that we have today. But it would have been very realistic and important for our national security and our airport security personnel to target those kinds of individuals because they were the ones who were perpetuating that kind of crime. Our motion is not about figuring out how we're going to do it. We need to come to agreement I think and send a really important message that we are going to put away political correctness and look very practically at the issues of race and religion as they impact airport security. .7

What Michael is trying to do is take us down a path that I'm afraid we're not paid enough to do.

### Moderator
Claim: Debra Burlingame.

### Scientific Advocate (SA)
Claim: I think to punt on the subject, Asra, with all due respect, of how we're going to do it, really is-- it doesn't do justice to the resolution because frankly you know the proof is in the pudding,

### Moderator
Claim: Especially since their argument is that it doesn't work.

### Conspiracy Advocate (CA)
Claim: Well, of course it works.

### Scientific Advocate (SA)
Claim: The devil is in the details and I have to say it is quite true that there is assiduous recruiting going on in U.S. prisons. They call it “Prislam.” It's a kind of a bastardized version of Islam. And al-Qaeda, which I believe is a very racist organization, by the way, it courts blacks in the prison population, and they foment the sense of injustices or some people who've been through some difficult histories, criminals, convicted criminals, and they play on their sense of injustice, but they do that outside the prison as well. .5

You have these groups that are the civil rights-- these justice groups that are really-- I do not believe they're friendly to Muslims, I believe that they are really friendly to the enemy. And they cozy up to material support. People who are involved in material support, some of them are even Muslim Brotherhood front groups. And they would absolutely use this kind of profiling as Exhibit A of why you should be angry not only at the U.S. government but the people in your neighborhoods who live around you, come join us. And we know that they're doing that.

### Moderator
Claim: Debra, let me ask you a question, a little bit of personal experience, but it relates to something that the other side has said. I'm married to an Israeli. I'm not Jewish. Any time I apply to Israel without my wife I'm profiled as not Jewish.

### Moderator
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: And I go through-- I'm pulled off and I have a passport also full of Arab country stamps. .9

And I'm pulled off, I spend sometimes an hour, hour and a half, they actually in the middle of the night call my in-laws, "Is this guy for real?" It’s a big pain in the neck, but once I’m on the plane I’m glad they did it to the guy behind me. And what I’m hearing from Bob Baer, you said the same thing about your daughter.

### Conspiracy Advocate (CA)
Claim: I always getting profiled in Tel Aviv.

### Moderator
Claim: And I’m hearing you're saying the same thing, and so if--

### Conspiracy Advocate (CA)
Claim: Well, maybe for different reasons, but

### Moderator
Claim: Where is the offense? Because especially your colleague Hassan talked about that, about the stigmatization, et cetera. I want to hear more from you about that side of the argument because there is also that pragmatic side. It’s not nice, but if it keeps the planes flying, then I’m willing to go with it.

### Scientific Advocate (SA)
Claim: I think because for all the reasons that we have said that we can give-- Michael can go longer with all the examples of people who don’t fit that profile. And al-Qaeda, you know, they’ve made some mistakes, but they’re very smart. .7

They’re very adaptive, and they will find like mercury that you know they’ll find the crack and so--

### Moderator
Claim: Wait, are you answering the question that I asked or--

### Scientific Advocate (SA)
Claim: What I’m saying to you is-- what I’m saying to you is that I think it’s-- it is offensive when you’re pulling people aside who have a sense within them that they have done nothing wrong. Remember this is a community that’s already under assault. It pained me frankly to hear Asra apologizing for the beast who did that brutality on 9/11 to my brother. I do not hold Muslims responsible-- all of the Muslims of the world responsible for the acts of a few. I’m not-- I do not. And--

### Moderator
Claim: Okay. I want to go to the audience. As I mentioned at the beginning, I’d like to ask for four or five people just

### Moderator
Claim: Just one minute. I will take you.

### Moderator
Claim: I forgot.

### Moderator
Claim: I want to come to you to just raise your hand and give me one sentence answering this question, that as you hear the arguments so far-- .0-- the weakest thing that you’re hearing or the strongest thing that you’re hearing in one sentence, at most two, and we’re going to go very quickly, one, two, three, four. While you’re thinking about that, I want to go back to Hassan Abbas.

### Scientific Advocate (SA)
Claim: I would argue in response to your concern that you feel more comfortable about the person that’s sitting behind you. There is life that exists outside those airports also. We have to look at the larger picture. Those concerns can be responded to if you know that the law enforcement at the airport is effective, if you know that they have spent time researching that issue. Whereas the consequence of this whole issue of every Muslim or someone from one country background has to be looked at as I mentioned, it means that you’re isolating the whole community. It is fashionable today to be very critical of the Muslims. So maybe many of the people will feel very comfortable. .9

But look at it in an historical, larger, comprehensive context that you just are saying that all the Muslims respond, they tell you why everyone is innocent unless

### Moderator
Claim: Is that part of your--

### Conspiracy Advocate (CA)
Claim: You made that point. Without an educated TSA, this is going to lead to racist disaster.

### Moderator
Claim: So part of his argument I want to bring to this side that you made in your opening statement, Hassan, is that it does go bigger. If you see more Muslims being pulled off to the side at an airport and the kids see that, are they going to grow up thinking there’s something wrong with Muslims. Are people who are going to try to get jobs as Muslims going to be stigmatized in the larger sense because--

### Conspiracy Advocate (CA)
Claim: This is why the Israelis put young men and women, well-educated, college educated who are very sensitive and they do not sit and insult these people. But there’s a point we have not touched on, it is that we are in two wars in the Middle East, that we are killing Muslims, and one war is illegal, the Iraq war, and that’s just a fact. And a lot of this is where we’ve taken sides in the wars in the Middle East. .7

We need some sort of reaction in this country to defend ourselves.

### Moderator
Claim: Okay. I want to do a little bit for radio. We are in the question and answer section of this Intelligence Squared U.S. debate. I’m John Donvan of ABC News. We have six debaters, two teams of three, arguing out this motion, “U.S. airports should use racial and religious profiling.” And I’d like to just take a moment to take the temperature of the audience to gauge your opinion of what you’re hearing so far. Anybody who would be willing to-- sir, I’m pointing right at you, if you can stand up we’ll bring you a microphone, and gentleman right in the front row in the gray cap, gentleman in the orange shirt and gentleman in the white shirt.

### Conspiracy Advocate (CA)
Claim: And a woman?

### Moderator
Claim: I wanted to-- let’s see, alright. We’re going to profile for opinions. And we’re going to swap out the young lady down in the front row. Thank you. Did you see any?

### Conspiracy Advocate (CA)
Claim: Oh yeah, I saw their hands. .0

### Moderator
Claim: Down in the front row, could you rise and stand up, we’ll come to you. And again, just one sentence and we’re going to go left to right and we’ll start with you, sir.

### Moderator
Claim: So I understand the argument that racial profiling--

### Moderator
Claim: I really want you to do what I asked you to do which if you’re hearing--

### Moderator
Claim: Right. It’s very short. So I understand the argument that racial profiling creates a blueprint for potential terrorists to avoid but I don’t understand how behavioral profiling doesn’t do the same thing.

### Moderator
Claim: Thank you. We’re going to bring the camera over to the gentleman in the front row with the gray cap and pink sweater. Hang on a second. Okay.

### Moderator
Claim: I would like to hear more from the panel against the motion what they think about countries who do racially and religiously profile and are successful like in Israel.

### Moderator
Claim: Okay and to the front row, very first row, right behind the sign. Go ahead.

### Moderator
Claim: I think we are assuming that terrorists have limited intelligence because the Mumbai terrorist attacks were carried out by United States citizen called David. .1

### Moderator
Claim: Okay and orange shirt.

### Moderator
Claim: The one thing that I’d like to hear that I have not heard, legal issues aside, the motion aside, is what does the data and the evidence show? Does profiling make people on flights safer?

### Moderator
Claim: Do you mean racial and religious profiling? It’s a very vague term right now.

### Moderator
Claim: Racial and religious profiling at airports.

### Moderator
Claim: Can you rephrase that so that you don’t have me interrupting you?

### Moderator
Claim: Does the racial and religious profiling work.

### Moderator
Claim: Is there data on that? Let’s go to Bob Baer on that if you know the answer.

### Conspiracy Advocate (CA)
Claim: Well I’d go back to Israel. It’s a simple one. There’ve been no attacks on airplanes. They do profile, profile white, middle age Christian Americans and they tend to leave the Orthodox and they know who the Orthodox are. .9

Before they get on the airplane, they profile flight lists before they get on. And if you just take that one example, it works.

### Scientific Advocate (SA)
Claim: Let me--

### Moderator
Claim: Michael Chertoff.

### Scientific Advocate (SA)
Claim: I did-- I used to get asked about the Israeli situation all the time. The Israelis do a very good job. But they have 20 flights a day. We have--

We have-- we have 20,000 flights a day. I mean, and I've talked to the Israelis about this. The scale of what they have to do is really just trivial compared to what we have to do. It's a different system. By the way, when they take you into secondary, you don't get a virtual strip search. You get a real strip search. I've been shown what they do. They are-- they are much, much more thorough and aggressive. But they can do it. If we did that in our airports, and we looked at that some years back, you'd be waiting in line for nine hours. So I think it's not practical in the context of our airport architecture.

### Conspiracy Advocate (CA)
Claim: Can I mention something that we do have happening in our arguments today--

### Moderator
Claim: Deroy Murdock.

### Conspiracy Advocate (CA)
Claim: There's a very interesting article that I've seen on MSNBC.com about a man by the name of Tom Sawyer, no less, age 61. .8

He happens to have survived bladder cancer. And he flew from Detroit to Orlando. And as he was being patted down by the TSA, he said, “Look, I need to tell you that there is a-- I have a medical condition.” And the TSA agent didn't want to hear it. He proceeded to pat him down very hard. The-- basically a bag that collects urine burst, and this poor man was covered in his own urine and had to fly on a plane that way. And so my question to Michael Chertoff, who I guess you supervised the TSA when you were secretary of Homeland Security. What would you say to someone like him who's gone through this really humiliating experience? Why should we call it the status quo rather than using racial and religious profiling in our arguments?

### Scientific Advocate (SA)
Claim: That's completely unacceptable behavior for someone to do that. But the fact is you get a minority of people who are either belligerent or behave improperly. Doesn't mean that the right answer is to racially profile. Supposing the guy had been a Muslim from Pakistan? Same thing would have happened. Is it just that we couldn't care because he was a Muslim? .2

I mean, that's--

You know, part of the problem is people-- I really understand-- I travel a lot by air. I go through the same thing everybody else does. People are looking for a magic bullet. They like to know there's some way to distinguish the bad guy from me. The problem is, while we all know we are not terrorists ourselves, we don't know who the next guy in the seat is. And until we find a foolproof way to do it, or unless we have real knowledge about everybody who flies, real background checks on the hundred million people a year who fly, using racial profiling is a way of avoiding bad behavior by a TSO is not the right answer.

### Moderator
Claim: Let's go to some questions now from the audience. And--

### Conspiracy Advocate (CA)
Claim: We had one question that we didn't answer.

### Moderator
Claim: Which one?

### Conspiracy Advocate (CA)
Claim: Up here, which was that we're making assumptions, because, for example--

### Moderator
Claim: Wait, wait.

### Conspiracy Advocate (CA)
Claim: The person who did the Mumbai attack--

### Moderator
Claim: Can you re-ask the question with a little bit-- a little bit more context? .2

Thank you.

### Moderator
Claim: I just want to give an example of where, for example, profiling is used based on what has happened earlier. And in India, every terrorist attack has been, for example, been from Pakistan. And we were warned that terrorist acts were going to happen in Mumbai, apparently. But nothing came of it because we were profiling according to the kind of terrorists that we had earlier. And the person who carried it out was an American citizen called David Headley. And we just completely missed him because we weren't looking for him.

### Moderator
Claim: So what's your question? How would you phrase it?

### Moderator
Claim: My question is if we had focused on behavior instead of for example, religion, we might have found him.

### Conspiracy Advocate (CA)
Claim: But what I would actually argue is that, for example, in the case of the Mumbai attacks, and this-- this man, David Headley, he was Muslim. He was from Pakistan. He had changed his name so that he could hide his identity. I mean, Bob can speak more to this. But obviously, in terrorist circles, there is something that they call false flag operations, where people try to hide their own identity. And we have to outsmart that. .5

I mean, we have to be one step ahead of them in terms of how they're trying to hide their identity. And that's what I think David Headley was doing.

### Moderator
Claim: Hassan Abbas.

### Scientific Advocate (SA)
Claim: There is something--

There was a question about-- there was a question about what the studies tell us. Is there a data set? There are three or four things, very briefly, I’ll mention. One was an advisory by the Department of Justice in 2003, which very categorically said that racial and religious profiling is not only wrong. It is counterproductive. I can mention to you many studies as my own background as a law enforcement officer, as a Punjabi in a Pashtun land in northwest frontier province. Whenever-- even in South Asia, there are studies. Whenever you try to look at the whole community, then you lose all the people who are the agents of change and who, within those societies and communities can stand up and challenge. So you lose completely that community. All the academic studies, especially, for instance, there is an association of police chiefs in the United States. .6

They have mentioned time after time that these traffic stops, always stopping the blacks or the Latinos, that has not proved to be effective. So I'll draw a lesson from all those studies also which there's almost a consensus, or overwhelming evidence.

### Moderator
Claim: Another question?

### Conspiracy Advocate (CA)
Claim: Let's not-- let's just not-- let's just not make this parallel.

### Moderator
Claim: Asra, I'm going to move-- I'm going to move on, or we're going to stay forever on one question.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: Thanks. Anybody raising their hands in that direction? Many more over here. Gentleman in the-- yeah, white shirt. And if you could rise. And if any members of the news media, if you ask a question, could you please identify yourself as such.

### Moderator
Claim: It sounds to me as if the question has been framed so narrowly that it's very difficult to answer. Using racial and religious profiling, I mean--

### Moderator
Claim: Can you-- can you hold your mic right up? Thanks.

### Moderator
Claim: The people for it have said that-- to use racial and religious profiling is correct and effective. But they've also said that you should use all types of profiling, which I also think is correct. .1

I'd like to know, from those who think you shouldn't do it, what you should do, what we should do.

### Scientific Advocate (SA)
Claim: Well, I think what you should do is you look at behavior. Now, what do I mean by that?

### Moderator
Claim: Michael Chertoff.

### Scientific Advocate (SA)
Claim: And it depends on whether you have the information. But we collect a lot of this, for example, from people coming from overseas. Who paid for the ticket? What's your travel history? What's your telephone number, for example, that you used as your contact number. If we have information that someone has studied at a radical school, if we see literature that they have that suggests that they may be extremists. All that is fair game.

### Moderator
Claim: So you're saying-- but religious behavior.

### Scientific Advocate (SA)
Claim: It's behavior. It is things that you are doing.

### Moderator
Claim: But it's religious behavior you're talking about.

### Scientific Advocate (SA)
Claim: Yeah. And that's not profiling. I mean, there's no question-- I think we have to be clear about this. There's no question that if somebody affirmatively trains to be a terrorist, the fact that the terrorist camp says Islam training camp doesn't immunize them from having us look at that. .7

That would be crazy. What racial and religious profiling is about is looking at someone's race or religion, assuming you can figure out what it is, and saying based on that, I'm going to single them out. And that is the proposition that was offered. And that's what we're arguing against.

### Moderator
Claim: Another question? Sir in the blue-- you're wearing a blue shirt and a blazer. Yeah, if you're looking at your shirt, that was you.

### Moderator
Claim: Yeah. It seems to me the question is should U.S. airports use any racial or religious profiling. And I guess I feel like I hear the two teams sort of arguing different sides of that. So I guess the question I have is should U.S. airports use any racial or religious profiling at all.

### Scientific Advocate (SA)
Claim: Can I answer that one?

### Moderator
Claim: Yes, Debra Burlingame.

### Scientific Advocate (SA)
Claim: You all remember the infamous flying Imams from four years ago at Thanksgiving time. They boarded a plane to a U.S. airport in Minneapolis. .5

They called attention to themselves because they were standing in the heaviest traveled time of the year in a boarding area. They got down on the floor and started doing Muslim prayers very loudly. They were shouting out “Allahu Akbar! Allahu Akbar!” very, very loudly. Frightened the passengers all around them because, let's face it, “Allahu Akbar,” I wrote about this for the “Wall Street Journal,” is the last thing that was-- that you hear on the flight data-- or the cockpit voice recorder of 93 as it's screamed into the ground. We associate that for good or ill with something bad in this country. So passengers hear that. Did that prevent them from being allowed to board that plane? No. But they called attention to themselves. That was a way that people knew that they were Muslim. It wasn't just because of the Arab dress. Once they got on the plane, they weren't finished. They-- they were together in the boarding area. But now they're scattered in the front, center and back of the plane. .1

This is the exact configuration of the 9/11 execution teams. They asked for seat belt extensions for obese people. None of these men were obese. They rolled them up tightly and put them under their seats. Now, remember, everyone's watching them now. And this is all behavior. What I would say to you is, sir, is that the fact that they yelled “Allahu Akbar” and were praying in the Muslim custom, although it's not customary to pray in an airport. And in fact every Muslim that I've ever spoken to says, “No. You can't just drop and pray in the middle of Times Square. There are dispensations for time, place and location.” Once they've--

### Moderator
Claim: Debra, can--

### Scientific Advocate (SA)
Claim: Once they've identified themselves as Muslim, then you're not profiling any more. You're just being minimally observant.

### Moderator
Claim: Okay. Asra Nomani.

### Scientific Advocate (SA)
Claim: And you don't ignore it.

### Moderator
Claim: Asra Nomani to respond.

### Conspiracy Advocate (CA)
Claim: But what was the religion that was being profiled there? It was Islam. I mean, we can't deny that. .8

### Moderator
Claim: We're not yelling out the Lord’s prayer, now was it?

### Scientific Advocate (SA)
Claim: It was their behavior that got -them in trouble, not their religion.

### Conspiracy Advocate (CA)
Claim: It was religious profiling.

### Scientific Advocate (SA)
Claim: disagree.

### Conspiracy Advocate (CA)
Claim: That's the sensible thing to do. And just to this argument that Hassan made earlier that it's unconstitutional, we have had a Supreme Court decision that has established that if there is pressing public necessity--

### Moderator
Claim: I'm sorry. Can you be terse on this.

### Conspiracy Advocate (CA)
Claim: Sure.

### Moderator
Claim: I'll let you go but be terse.

### Conspiracy Advocate (CA)
Claim: But if there's pressing public necessity, then we do have to take considerations like racial and religious profiling into account and make that possible. We do it with our visa waiver program already. Those countries from which the terrorists have been identified as coming from, they don't-- they're not part of a visa waiver program, countries like Germany, Greece, England, they are part of it-- because we've identified as a nation that we--

### Scientific Advocate (SA)
Claim: Why do you think Osama bin Laden sent Richard Reid, the shoe bomber, and Moussaoui, he sent them in the second wave because they had Western passports and they anticipated that, that would now be scrutinized after 9/11. .6

### Conspiracy Advocate (CA)
Claim: and they're trying to outsmart our profiling. And so we again, as I said earlier, need to outsmart them.

### Moderator
Claim: Question from the second row. Ma'am, you're wearing a green scarf. Yeah, we'll bring a mike to you. Dana, how much time do you think we have to go on with questions? One more after this?

### Moderator
Claim: Yes.

### Moderator
Claim: Okay.

### Moderator
Claim: My question is for those arguing for this motion, do you agree that the word "U.S." can be replaced with any other country facing threats? And in that case, given the amount of state terrorism sponsored by the United States in the Middle East, thousands of Iraqis, Afghans killed, should U.S. citizens everywhere be profiled?

### Moderator
Claim: Bob Baer.

### Conspiracy Advocate (CA)
Claim: Well, they are profiled.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: I mean, if I go to the tribal areas of Pakistan, you can count on it that I would--

### Conspiracy Advocate (CA)
Claim: Right, would be--

### Conspiracy Advocate (CA)
Claim: Well, no, any place we're at war with, same with Iraq.

### Conspiracy Advocate (CA)
Claim: It happens.

### Conspiracy Advocate (CA)
Claim: Yes, I'm profiled. .5

### Conspiracy Advocate (CA)
Claim: I mean, that's why American citizens oftentimes will hide their passport when they travel to countries like this, because they are profiled.

### Conspiracy Advocate (CA)
Claim: I happen to think the United States is a force for good, so I would-- I certainly reject the premise of your question.

### Moderator
Claim: One more question. Right there.

### Moderator
Claim: I have a question for Judge Chertoff. So I agree if we have detailed information about someone's personal behavior that may be more probative than race or religion but a lot of times we don't have that information. A lot of times all we know is that someone bought a ticket with cash, or they're not traveling with luggage. We don't have the resources to stop everyone who bought a ticket with cash who doesn't have luggage. We do have the resources to stop every Muslim who paid in cash who doesn't have luggage. Do you agree that if all we know about someone is they paid in cash or they're carrying no luggage, that if we add in the fact that they're Muslim, that increases the probability they might be a sponsor of terrorism?

### Scientific Advocate (SA)
Claim: Yeah, here's my problem. My problem is I have a lot of difficulty understanding how we're going to know they're Muslims. .6

You know, at the-- we don't carry our religion around, and we don't state our religion when we buy tickets, and your ability to guess who's a Muslim would have probably have failed if you'd come to face to face with Jose Padilla, or Danny Maldonado. I understand that-- the desire to believe there's some way of separating groups out like this but the difficulty is you’re way over inclusive in some respects, but more important frankly, and more troubling is, you're under inclusive because the guy who you really have to worry about is the guy who is not going to let you know he‘s a Muslim, and that’s the flaw in using religious or racial profiling, is it’s not an accurate-- there’s not an accurate tool to measure who meets that particular profile.

## Round 3

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. Debate. And here’s where we are, we are about to hear closing statements from each debater. They will be two minutes each. Remember, you in the audience voted before this debate, you’re going to get to vote again. .8

This is their last chance to change your minds, just a few minutes from now when you pick the winner. So on to round three, closing statements, to speak first against the motion, Debra Burlingame, cofounder of Keep America Safe and 9/11 Families for a Safe and Strong America. Our motion is "U.S. airports should use racial and religious profiling." Debra Burlingame.

### Scientific Advocate (SA)
Claim: I’m going to close with a story, a real story. I actually spoke to this man just yesterday because I wanted to make sure I had my facts straight. He worked for 26 years at American Airlines. He got a nickname, a moniker, called "The Detective," because he was so, so good at picking out bad actors. He was a customer service agent at American Airlines on the morning of 9/11. And he boarded two of the Muslim hijackers that were probably the men who killed my brother. These men stood out to him. They were Nawaf and Salem al-Hazmi. .8

And here’s what he said about them, "They paid in $2,000, cash, paper tickets, they were in first-class dressed poorly, not just cheap shoes, the kind of shoes poor people would wear. I couldn’t understand what people dressed like that would be doing in a first class cabin.” And he didn’t know if they were Saudis. He thought they might be Pakistanis but all he knew was that this picture didn’t add up so he selected them for secondary screening. He said and by the way, Saudis sometimes have people who can’t speak English. These guys, neither one of them could speak English or understand his questions. Sometimes Saudis will have servants travel with them in first class but they’re usually nannies, they’re women, not beefy guys who looked like this. He selected them for secondary screening and he said “I normally walk them over surreptitiously and nod to the agents to let them know be sure you check these guys good.” He said “I didn’t do that that time” and it’s been rough for him. .9

I asked him one last question. I said to him is there-- “Was the fact that they were Arab looking have any effect on your actions that day” and he said “Yes. I didn’t walk them over that day because I didn’t want my colleague to think I was a racist and a bigot.” And that, to me, is what I believe will happen in U.S. airports and will happen in this country. It will have a reverse effect of people being afraid of being identified as racists and bigots because they call people out on the basis of--

### Moderator
Claim: Debra Burlingame, your time is up.

### Scientific Advocate (SA)
Claim: --their skin color or their religion.

### Moderator
Claim: Debra Burlingame, your time is up. Thank you very much.

Our motion is “U.S. airports should use racial and religious profiling.” And now to summarize his position for this motion, Deroy Murdock, a syndicated columnist with the “Scripps-Howard News Service” and a media fellow with the Hoover Institution.

### Conspiracy Advocate (CA)
Claim: Well thank you very much and thank you to my opponents and my colleagues for what I think has been an excellent and lively debate. I think the general position that we’ve heard from the other side is that since it’s impossible to catch everyone who might pose a threat to our country and our flying public and who want to kill us, therefore we shouldn’t even attempt to find those who might have those malicious intentions. .9

It is true that you might, in an effort to catch everyone who happens to be a Muslim, perhaps not catch someone like Jose Padilla who was of Hispanic background and converted to Islam or perhaps people who have gone through “Prislam” as I believe Debra put it who have gone to prison and been radicalized there and might be black and therefore they might slip through the profile. But because they might not go through the profile doesn’t mean that we ignore the fact that people from the Middle East who are Islamic, unfortunately they represent the profile of the people who threaten this country at this time. I think you certainly can check by looking at things like passports which definitely will give us a sense of where they come from maybe not on a domestic flight but certainly on international flights and people going through international airports. I also think that if al Qaeda gets smart and says “Well I guess they’re looking for people who like those who were 9/11 hijackers we probably should go to the trouble of finding women who are blonde haired, blue-eyed.” .7

Let al Qaeda go to the trouble of finding blonde-haired, blue-eyed women who agree with them and want to blow themselves up then it’s going to be a lot more difficult for them to fish around in that pool than to find more Muslim men who are 18 to 35. Let’s at least make things difficult for them. The last point I’d make is the consequences of this. I’m very sympathetic to the point Hassan has made about Muslim children asking their parents if they’re going through questioning at the airports, “Daddy, did you do something wrong? Daddy, are we criminals?” That is very tragic and very sad. But I think the other consequence we must remember is if somebody slips through and we have something like the plane flying over Detroit which was attacked; fortunately, the bomb did not go off. If we have something like that happen, we have much, much worse consequences than people feeling duly upset and saddened. We want to keep them alive no matter where they’re from.

### Moderator
Claim: Thank you, Deroy Murdock. Our motion is “U.S. airports should use racial and religious profiling” and now summarizing his position against the motion, Hassan Abbas, international and public affairs professor at Columbia University and former official in the Benazir Bhutto and Pervez Musharaff administrations.

### Scientific Advocate (SA)
Claim: Thank you very much. I would just make you one big request which is not to ignore and always to remember the very idea of America. .1

I would highly encourage you to go and read the Fourth Amendment and the Fourteenth. Reading the First Amendment will not be that harmful also. So don't forget about the essence. What terrorists want. They actually want to scare you into making wrong choices. Terrorism starts influencing your policy choices. And terrorism plays fear on you, fear of the unknown, fear of the unknown attack. When will the next attack happen? I have heard senior intelligence and security people say, “We are certain the next attack is going to happen. We just don't know when.” Well, these kinds of generalizations at times are counterproductive. I would argue we are not saying on this side that there should be no profiling of any sort. We are saying, yes, based on behavior, based on information, based on intelligence, how do you collect intelligence? Do you think it's all about these iPhones and listening to telephones and wire tapping? No. .0

It is about having access to those communities which are at risk. Communities which are also fighting extremists. Don't forget that within the Muslim world in the United States and all around the world, there are people among the Muslims, majority, mainstream, who are fighting extremists. Don't just lump all of them together by your one policy choice. Don't isolate them. Don't lose the hearts and minds. So yes, do profiling, but don't lump anyone together. That will be something exactly opposite to all what this great country stands for.

### Moderator
Claim: Thank you, Hassan Abbas. Our motion is “U.S. arguments should use racial and religious profiling.” And summarizing her position for the motion, Asra Nomani, author and former “Wall Street Journal” reporter who teaches journalism at Georgetown.

### Conspiracy Advocate (CA)
Claim: Debra told a very moving story about a man who was among the last to see the hijackers. .1

What is it that he said? He said that “They looked like Arab terrorists if I'd ever seen them,” according to the media reports when he was interviewed. If that man could have participated in some type of religious and racial profiling, perhaps the tragedy that we knew on 9/11 could have been mitigated somewhat. And that is the motion.

We're not talking about persecution. We're not talking about discrimination. I know every single one of you, no matter what your narrative has faced some sort of discrimination in your life. There is no need to add trauma to people who have already been traumatized. But to argue that we will create new extremists is, I think,-- is completely without basis because they have enough reason to hate us. .0

That same Saudi Koran that I read to you, that translation, it says “then when the sacred months have passed, then kill the nonbelievers wherever you find them and capture them and besiege them.” These are people who are not the majority inside of our Muslim community. It's not what speaks from my heart. It is not what speaks from my father's heart. It's not what speaks from Hassan's heart. But there is a minority inside of our global community today who believe this interpretation of Islam. And we have to figure out how to identify them so that we can keep our skies safe and so that we can actually live lives that-- in which we don't have to be in fear. I urge you to vote for the motion that airports should use religious and racial profiling. We need to be smarter than the enemy.

### Moderator
Claim: Thank you, Asra Nomani. .1 “U.S. airports should use racial and religious profiling,” that's our motion. And now to summarize his position against the motion, Michael Chertoff, former secretary of Homeland Security and cofounder of the Chertoff Group.

### Scientific Advocate (SA)
Claim: I agree with Asra, we do need to be smarter. And that's what concerns me about the motion that's been put. I think it's not smarter. I think it attempts to fight the struggle of 2010 by looking at what we faced in 2001. We all agree we have to look for extremists. The problem is that what I've heard today is a list of preconceptions about what the extremists look like. I have not heard anybody say how they're going to figure out what religion you are at the airport while you're waiting online. I haven't heard anybody say what are the races that are included in the profiling and what are the races that are not included in the profiling. And what really concerns me is this. If you can't pick out people except by looking at what you imagine an Arab looks like or a south Asian looks like or by looking at a name or a face and trying to say this is a Muslim. .5

If that's what you're focused on, you're not focused on the kind of subtle cues that actually tell you when somebody is dangerous. The fact is it's not something we're speculating about. We know because Colleen LaRose told us. The enemy is acutely aware of what we imagine a terrorist looks like. And unfortunately, they're having no difficulty recruiting people in prisons or in Western Europe or in the United States, including blond-haired blue-eyed women to carry out terrorist acts. So for me, it's a very simple choice, frankly. Every other consideration goes secondary to the issue of being effective. That's what I spent most of the last 10 years trying to do, is be effective in preventing this from happening again. And I don't think we're effective if we take what I consider to be the lazy man's way out of trying to figure out who fits a racial or religious profile as opposed to what is real intelligence analysis, which is to look at behavior. .0

If religion is part of that behavior and is an element of what you see that gives you a specific behavioral picture, that's not profiling. That's good intelligence work. But I--

### Moderator
Claim: Thank you, Michael Chertoff. Our motion is “U.S. airports should use racial and religious profiling.” And now here to summarize his position for the motion, Robert Baer, a former CIA field officer assigned to the Middle East and currently Time.com's intelligence columnist and a best-selling author.

### Conspiracy Advocate (CA)
Claim: I apologize for ending this on a bit of an academic note, but I would like to take a country that I'm not particularly fond of and I wrote a book about, and they're not fond of me either, and that's Saudi Arabia. Saudi Arabia had a very bad terrorism problem 2003, 2004. Princes were being killed. Car bombs were going off. And we got a new king in Saudi Arabia, King Abdullah. And he sat down with his intelligence chief, Hamid bin Naif And he said profile. .4

Who are the people. Where are they coming from, what tribe, what sect, what religion. The first thing they sat down, and they eliminated immediately Saudi Shia who were an oppressed minority. But they were not blowing themselves up. They were not turning to suicide bombings, radical Islam. Since then, all attacks on Saudi Arabia have come from outside the country. They have whipped the problem. Of course, it's a home-grown problem. They knew about it. But what they did was they profiled. I would prefer if we had the opportunity and we had the intelligence to base all of our profiling on behavior, tickets, flight lists, the history of people, digital databases, credit checks. But right now, this country does not have that capacity to run an algorithm through every single flight that comes into this country. .8

Nor can it even keep track of the people that are in this country. And this forces the police and TSOs to fall back on a very primitive unattractive weapon. But it's the only weapon we have at this point until our intelligence gets better. Thank you.

### Moderator
Claim: Thank you, Bob Baer. That was Bob Baer. Bob Baer speaking for the motion. And that concludes our closing statements. And now it is time to learn which side has argued best. Once again, the side that has changed the most minds is the one that we declare our winner. So we're asking you again to go to the keypad at your seat that will register your vote. And we will get this readout almost instantaneously. Our motion is “U.S. arguments should use racial and religious profiling.” Push number one if you are for the motion. Push number two if you are against and number three if you are undecided or became undecided. And we will have the results really in about a minute. .6

In the meantime, I wanted to thank all of our panelists for coming here and debating with great integrity and intelligence. Thank you. And also the caliber of questions and comments from you in the audience was also outstanding. Thank you for that. We wanted to let you know that this spring at Intelligence Squared U.S., we're going to be doing something new. We are doing an umbrella series. The umbrella title is “America's house divided.” And we will be focusing on some of the more important policy issues that represent this division and debate about whether we need to bridge the division. The topics will be the economy, the two-party system, America's global influence, energy policy and immigration reform. The dates and the tentative language of the motions are these, January 11, “Repeal Obama Care;” February 15, “The Two-Party System is Making America Ungovernable;” .8

March 8, “Renewable Energy Cannot Power America;” April 5, “It’s Time to Clip America's Global Wings;” and, May 3, “Don’t Give Us Your Poor, Your Tired, Your Huddled Masses.” They’re all on Tuesday evenings, and tickets are available though our website and at the Skirball box office. You can also follow Intelligence Squared now on Twitter and on Facebook. And if you friend us on Facebook you’ll get a discount. As we’ve mentioned before, this debate will be available, we’ll be airing on Bloomberg Television starting next Monday at 9 p.m., Eastern Time, and on more than 220 NPR stations across the nation. You can also find out the times from just looking at your local areas. That was our 44th debate tonight, and we look forward to seeing you in January when we have our 45th debate. All right. It’s all in. I’ve been given the results. Now, remember, the team that changes the most minds is declared the victor, and here it is. .7

Before the debate, 37 percent were for this motion, "U.S. airports should use racial and religious profiling," 37 percent were for, 33 percent against, and 30 percent undecided. After the debate, 49 percent are for the debate, that is up 12 percent, 40 percent were against, that's up only seven percent, 11 percent remain undecided. The side for the motion carries the debate. Our congratulations to them, and from me, John Donvan, and Intelligence Squared. We’ll see you next time.
