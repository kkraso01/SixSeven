# Debate Transcript

Topic: Bush 43 is the Worst President of the Last 50 Years
Motion: Bush 43 is the Worst President of the Last 50 Years

Debate ID: Bush43IsTheWorstPresident-120208


## Round 1

### Moderator
Claim: …Okay, all of our preliminaries are out of the way, at this point, we’re going to begin the evening and it’s pleasure to introduce, to set the stage and set the theme, the chairman of Intelligence Squared, Mr. Robert Rosenkranz.

### Moderator
Claim: Thank you very much and welcome. Well, it’s my role in these evenings to frame the debate, and I think for most New Yorkers, we’re all very familiar with the liberal critique of George W. Bush. But even from a conservative perspective, the Bush presidency could be seen as far worse than than Bill Clinton’s. Clinton was for free trade, he spent a lot of political capital getting NAFTA through, versus the Bush administration with steel tariffs and ethanol subsidies. Clinton had welfare reform. This administration has had the first new entitlement of great scale in the last 40 years in prescription drugs for the elderly. Clinton had a balanced budget. This administration has had absolutely out of control public spending. On the other hand, consider the following. This administration accomplished something that nobody would’ve thought possible—they kept America safe after 9-11. And then think about a President like Nixon who was so reviled in his time, but whose rapprochement with China really set the stage, geopolitically for everything that transpired, the collapse of the Soviet Union, the emergence of the Chinese economy.

Sometimes the historic perspective gives a very, very different view than what you see at the moment. And finally consider Jimmy Carter. He invented the term “stagflation,” we had 13 percent inflation, no economic growth, 19 percent interest rates. He abandoned the Shah of Iran who was a staunch American ally, enabled the ayatollahs to take over in Iran. His ineptitude during the hostage crisis emboldened Russia to invade Afghanistan. He was a truly awful President. So, there’s a lot to be said on both sides here. And it’s my pleasure now to turn the evening over to John Donvan, and the outstanding panel that we’ve assembled tonight.

### Moderator
Claim: Thank you, and may I just invite one more round of applause, sustained applause for Mr. Rosenkranz for making all of this possible. Welcome to the Symphony Space in New York City, we are here with a sold-out audience, for an Intelligence Squared US debate, in which the motion is, “George W. Bush is the worst American President of the last 50 years,” that is, “Bush 43 is the worst President of the last 50 years.” I’m John Donvan, your host and moderator, and tonight we have, arguing for the motion, an esteemed panel, to my left, to your right, beginning with Jacob Weisberg, who is editor-in-chief of Slate and author of The Bush Tragedy. Joining him on the same team, Simon Jenkins, a distinguished British newspaper editor and commentator. Arguing against the motion, to your far right, Karl Rove, former deputy chief of staff to President Bush. And his debating partner, Bill Kristol, editor of The Weekly Standard and chief of staff for former Vice President Dan Quayle. The Intelligence Squared and Intelligence Squared US debates are supported by the Rosenkranz Foundation.

Now, shortly you will be hearing from our four panelists, two for the motion, and two arguing against. But this evening is a contest, a contest of wit and skill and logic and ideas and in that contest, you are the judges, we are going to poll you twice during the program, once now and once later. We want to poll you to see where you stand on the motion. After that the debate will be open for our opening statements, and then we’ll come to questions from you, the audience. So, if you turn to those keypads that each of you had at your seat…as we explained before, it’ll only take a moment to vote, you press 1 if you agree with the motion that George W. Bush is the worst American President of the last 50 years, 2 if you do not agree, that Bush 43 is the worst President of the last 50 years. And number 3, if at this point you are undecided.

Does anyone need more time? Terrific. We’ll come to those results shortly after we hear the opening statements from the panelists. For this point let us say, let the debate begin, our motion is, George W. Bush is the worst President of the last 50 years, Bush 43 is the worst President of the last 50 years. Arguing first for the motion is Jacob Weisberg, a chairman and editor-in-chief of the Slate Group. He has just published a book, a history of the Bush family in politics, its title, gives you a sense of where he is coming from on this debate, it is called The Bush Tragedy. Ladies and gentlemen, Jacob Weisberg.

### Conspiracy Advocate (CA)
Claim: If you need more time I’m afraid I can’t help you. I’d like to thank Bob Rosenkranz and Intelligence Squared. I feel like I’ve spent most of the past year watching Presidential debates, it’s nice to finally be in one. Please don’t change your minds, Bush was obviously the worst President of the past 50 years. Yet the task Simon and I have tonight is extremely difficult. We have to convince a small fraction of you, at least if you’re anything like the people who have given Bush the lowest approval rating of any post-war President, who still resist that conclusion. And to be honest I’m not sure that people who still defend the Bush Presidency are entirely open to persuasion. But I wanna try, by talking a little about how much Bush has done wrong and how little he’s done right. Let me first just tell you a little bit about my own perspective on this, I am not a Bush hater. I’m not someone who can be described as a partisan Democrat, the way Mr. Kristol and Mr. Rove are partisan Republicans.

I’m a centrist liberal, I’m fairly hawkish on security issues, I’m in favor of limited government. And let me just state up front, I think George W. Bush was a fine governor of Texas. I think Ronald Reagan was a successful President, and I think George H. W. Bush, 41, understood foreign policy better than all but a few Presidents in the post-war era. About two years ago, I started writing a book about the Bush Presidency. And I was gonna spend a lot of time on Bush’s successes and accomplishments. And I’ll admit that I wanted to do that not just to be fair, but so I would look fair. And, I looked for the successes and accomplishments, and I looked, and I looked, and I came back totally empty-handed. There were a number of areas where I expected to stick up for Bush, but I really found it impossible. For example, I was sympathetic to his approach to education reform. But even from a conservative perspective, Bush didn’t allow— provide enough resources to allow for any real mobility or choice in public schools.

Instead of national standards which we needed he let the states write their own tests. That’s what the conservative base wanted. They don’t believe the federal government should be involved in education at all, and in caving in to them Bush ensured that he’d make little meaningful progress on education and in fact, he has made very little meaningful progress. I thought Bush was right about the need for immigration reform. And then I watched him surrender to the xenophobes and nativists in his own party. I thought Bush was right to spend a lot of money fighting AIDS in Africa. And then I watched him save far fewer lives than he might have, because of religious extremists, again in his own party, who believe abstinence propaganda’s more effective than condoms. I thought Bush was right about free trade, and then I watched his lack of leadership lead to the collapse of the most important item on the global trade agenda, the Doha development route.

So, those are the partial successes. I can’t hope to cover all Bush’s failures tonight. What would be a top failure for a President doesn’t even really make his top five. So, never mind his incompetent response to Hurricane Katrina, it doesn’t make the cut. Never mind his denial of climate change and eight lost years on global warming, that doesn’t make the cut either. I’m just going to give you my top five. Number one is the invasion of Iraq. This was the most important decision of the Bush Presidency and he made it on the basis, as I think we all know, of the false premise that Saddam Hussein was threatening America with weapons of mass destruction, and consorting with al-Qaeda. Now I’m not someone who believes that Bush deliberately falsified the evidence. But I believe he was totally uninterested in the evidence. This war would never have been fought, if Bush had been interested in the truth as opposed to finding a pretext for something he wanted to do.

I think his second biggest failure is the mismanaged occupation of Iraq. Bush refused for more than three years to change a failed military strategy. And almost the whole time people like my friend Mr. Kristol here were desperately insisting, rightly in my view, that Bush needed to move to a counterinsurgency strategy. Bush said, essentially, don’t bother me with the details. He delegated the strategy to Rumsfeld and he ignored the failure. I think the surge has helped tremendously in Iraq, the outrage is that Bush moved to it in 2007, not in 2003 or 2004. His third biggest failure is undermining Constitutional rights, and American ideals. Now I can’t go into detail here about all the ways he abused his authority, and disregarded the rights of both foreigners and American citizens.

But he and Vice President Cheney opened the door to torture, which led directly to the horrors of Abu Ghraib. He effectively suspended habeas corpus, holding suspects for years without charge or trail, and he took a perverse view of his office, claiming that virtually limitless executive authority was part of the inherent power of the Presidency. His fourth failure was sabotaging American unity after September 11th. The day after the attacks, the front page of La Monde in Paris said “We are all Americans.” The whole world was with us. But Mr. Bush and Mr. Rove saw September 11th as a political opportunity for what Spiro Agnew called, “positive polarization.” Now Simon is gonna speak to the harm, that this did to America’s image in the world. But I would just say, with a new administration coming into office, never in more than 200 years of our history has restoring America’s around the world been such an urgent project for a new President.

Number five, my last, is Bush’s catastrophic economic mismanagement, which is so current we hardly even need to spell it out. It remains to be seen whether we’re facing a depression, whether Bush will stand in for Herbert Hoover. But I think it’s clear that we’re living through the direct result of an ideological refusal to sensibly regulate financial markets. Bush says he’s sorry about all the lost jobs, if you saw his interview on ABC last night. But, as he loses his, the interesting question is whether he ever understood or understood now, his own contribution. Now our opponents this evening, may try to argue that Richard Nixon or Jimmy Carter was worse. But neither of those Presidents failed as badly as Bush. Carter had the Camp David agreement, and despite Watergate, Nixon left historic accomplishments including opening relations with China, and creating the Environmental Protection Agency.

Neither of them rivals Bush for sheer, all-pervading incompetence. But if our opponents tonight— Thank you. I’m closing here, if our opponents tonight wish to argue that Bush was only the second worst President of the last 50 years, that’s not much of a defense. This national nightmare, I would suggest, has been the deepest and longest of all.

### Moderator
Claim: Thank you, Jacob Weisberg. And actually perfect timing. Bill Kristol is the editor of the influential Washington-based political magazine The Weekly Standard. Just over a year ago he wrote a piece predicting that President Bush’s Presidency would be remembered ultimately by history as a successful one. We bumped into each other on the street last week, and he said, “I’m still prepared to argue that, but can I leave out the US economy.” Bill Kristol, ladies and gentlemen.

### Scientific Advocate (SA)
Claim: Well, thanks, John, I’m still happy to argue that and it’s the truth— It’s good to be back on the Upper West Side, let me say I grew up just a mile from here, Bella Abzug was my Congresswoman. And that made me a conservative. Right. A decision I’ve not regretted, since then. Bush was not my first choice, George W. Bush was not my first choice for the Republican nomination for the Presidency in 2000, I’ve had my quarrels with the Bush administration, but he’s been a pretty good President. He’s, it’s— Well… As we sit here safely, seven years after 9-11, having won a war in Iraq, we can snicker and laugh with the US economy having grown 18 percent over the last eight years, faster than any other Western advanced country, with the prescription drug benefits having been passed that has benefited many seniors which Bush gets no credit at all which he took on his own party for, on issues like immigration he valiantly took on his own party and did an awful lot to try to get that through. Bush has actually been a pretty impressive President, it’s unfortunate that the public has, for various reasons, some of them good, soured on Bush, and he’s done a horrible job, his administration, of explaining what they’ve done and what the choices were.

In the real world the choices are not, you know, perfection, and a pretty good Presidency, in the real world he’s made a lot of tough decisions, most of them correct. When he became President al- Qaeda was ascendant, Saddam Hussein was contained but unsustainably so, unless you think we could’ve had sanctions and inspectors for the last eight years. North Korea and Iran were secretly working on nuclear weapons programs, A. Q. Khan was dispensing nuclear material and know-how all over the world, Pakistan had exploded a nuclear weapon, in 1998. Then, 9-11, Bush reacted to that correctly, basically. We have been protected here since then, we have al-Qaeda on the run internationally. People can talk all they want about—there are a couple of things he did that he shouldn’t have done, these have been— they were fixed by people in his own administration. Jack Goldsmith, Attorney General Ashcroft, Attorney General Mukasey, have fixed some of the mistakes that were made under the pressure of trying to defend this country against a ruthless terrorist group that had taken 3,000 lives, history will look kindly on Bush’s performance as a national security and homeland security President. And one piece of the proof is that Obama is not going to change much. As the Obama people get briefed on the threats, they see that the surveillance program is necessary. I suppose Obama will close Guantanamo and move, in effect, Guantanamo here to the United States and put the people at Fort Leavenworth but he’s not going to release these people into the US. Enhanced interrogation techniques which McCain and Obama oppose, so I guess I’m a lonely person in defending those, saved an awful lot of lives when used on Khalid Sheik Mohammed and I’m not willing to second-guess the decision, to use those techniques.

Bush was a strong President on national security, the decision to go into Iraq was necessary I think. The Middle East today, with Saddam in power, or his sons in power, with terror connections, redeveloping the weapons of mass destruction programs presumably, since I don’t think we could’ve kept sanctions on, and inspectors in for eight years, would’ve been a much more dangerous place. The decision to go with the surge was a courageous decision, made in December 2006, January 2007 under great adverse pressure, with very little public support, very little support from the Republican establishment, no support, obviously from almost any Democrats except Joe Lieberman. It was the right decision, it’s been utterly vindicated. Have we ever seen really, this kind of real-time test. Bush said let’s do this, here’s what will happen, here’s how we’ll work, these critics said it can’t work, it wasn’t working, you’re crazy, more lives are gonna be thrown away, and we had a real-time test of who was right and who was wrong.

And now Barack Obama of course being an intelligent person, admits that the surge worked, and we are now beginning to draw down in a position of success in Iraq, not leaving a country that would’ve been a breeding ground for terror, I mean the degree to which Bush does not get enough credit, for refusing to cut and run in 2007 in Iraq, the degree to which people don’t appreciate the strategic, the geostrategic disaster that would’ve been, remains kind of amazing to me. We have a pretty good outcome in Iraq, a very important ally in the Middle East, that has sacrificed a lot in fighting terror groups, that is standing with us against Iran, that has signed just a Status of Forces agreement with us, that will be a strategic partner with us.

In a way this could be a strategic victory that could be the flip- side of the strategic defeat that the Iranian revolution in 1979, was. The rest of Bush’s foreign policy has been…I have my quarrels with some of it, but most of it’s been pretty successful, the relationship with India, the management of the China and Japan relationships. The Europeans have been annoyed at Bush at various times, on the other hand we’re working more closely with Europe on Iran than we ever have before, and for all the talk about the US image in the world, the truth is, Barack Obama’s not going to change those policies much at all. And I think it’s good as an America, if we get a lot of credit now with Obama and people decide they like us better but the actual policies, the NATO policies, the Afghanistan policies, the Iran policies, the Pakistan-India policies, the China policies, are not going to change much. Because they’re sensible pollicies.

On the economy, obviously that’s been terrible in the last few months, I do think Bush could’ve done some things differently but to be fair, it’s not as if the Democrats had one prescription and Bush had another, and we went down one road and that’s where we are. There were bipartisan mistakes, on some of the institutions like Fannie and Freddie. I’d say Bush was more correct than the Democrats, on others, he might’ve been somewhat less correct. We did have economic growth over these eight years, on the other hand, the big piece of deregulation that everyone loves to site as being the kind of key that unlocked the derivatives and the other instruments that have turned out to be, that spiraled out of control, the key that unlocked that was presumably the 1999 deregulation of financial institutions signed by Bill Clinton.

Bush didn’t sign any big deregulatory bill. So he gets a bit of a bum rap on the economy but, I won’t, I won’t make that my leading argument, for why Bush was a successful President, but the prescription drug benefit has worked very well. It has preserved competition while coming in under budget and helped a lot of seniors, aid for Africa has worked well, Bush has fought for free trade against a Democratic Party that has tried to turn its back on free trade and would…hopefully Obama will follow Bush and not some of his fellow Democrats in that way. The proof is in the pudding. Obama is not going to change many Bush policies. So it’s a little ridiculous to say, Bush is the worst President in 50 years, Barack Obama’s an intelligent, impressive man. He promises change, I hope he brings some change. But the fact of the matter is, Obama’s Presidency will be in most major respects, a continuation of the Bush Presidency, and that’s a good thing for the country.

### Moderator
Claim: Thank you, Bill Kristol. Simon Jenkins is a journalist and an author and writes a column for The Guardian, he is a British subject, he is a friend of America, but has never hesitated to tell America when he thinks it has made mistakes, ladies and gentlemen, Simon Jenkins, arguing for the motion.

### Conspiracy Advocate (CA)
Claim: Well ladies and gentlemen, I just heard a wonderful suggestion, Barack Obama is going to be the second-worst President since the war. The only thing I think that might make you, or many of you at least, not agree that George Bush is the worst American President of 50 years, is to hear somebody say it in a British accent. I’m acutely aware of the sensitivity of international comment. I am a deep skeptic about my own government, and I will not say much good of Gordon Brown, I won’t say a lot of good about hereditary monarchy. But if I hear someone with an American accent insult my Queen I’ll hit them. There is something about foreign accents on these subjects, that gets people’s backs up, so I beg your pardon. The point I want to make is this. That there are really two American Presidents. There’s a President of the United States of America, and that is entirely your business. But there’s a second American President. And he is the President of the Western Alliance, and in many senses since the end of the Cold War, is seen as a sort of President of the rest of the world. I’ve just been in Syria and Lebanon. A lady speaking at a meeting made a rather moving remark. She said every single one of us round the world, went to the polls on November the 4th, but only some of us were let in. The vast majority disenfranchised, sat outside, while America decided on their economy, on their diplomacy, on their politics, in many cases on their lives.

And it’s to that American President that I want to say a few words tonight. I’ve spent almost all my life cheerleading for America. I’m second to nobody in this noble cause. And I can tell you it’s not been easy this past eight years. But until the last eight years, I have always felt, that each American President, in some small sense, pushed uphill the great boulder of democratic freedom. Every single one, I felt at the end of it, yeah, America’s done it again. We’ve made a bit of progress. I felt that was one of the great strengths of America, that it could push that boulder a bit uphill. It may have been a military intervention, it may have been a trade agreement, may have been a single example.

Whatever it was, somehow or other, there was progress forward with what I call the great American crusade. When George Bush came to power I was rather in favor of him. I rather admired the program he put forth with this foreign policy. Condoleezza Rice’s famous article on a humble foreign policy, definitely appealed to me. I liked the remark about America setting the world an example by what it did at home, rather than by getting the 82nd Airborne to lead kids to school. This seemed to me to be a refreshing, unbombastic, unostentatious diplomacy. Then came 9-11. And I’ve always remembered those few weeks after 9-11, when the whole world was pro-American. Yasir Arafat gave blood for New Yorkers. Many people forget that. Almost nobody, almost nobody, was not on America’s side for those two or three weeks. And the disaster that followed, going to war in…true retaliation for it, is something from which I don’t think American policy has ever recovered.

I’ve recently been touring around that arc of instability, and the consequences of the consequences of 9-11 really have been catastrophic. To pretend that Iraq is a success is obscene. Iraq today is more or less back to what it was like in 2004 and if Karl or Bill want to walk hand in hand with me down Haifa Street in Baghdad, as you could still in 2004, well, I can tell you they won’t. Afghanistan is heading in exactly the same direction, I think Afghanistan’s going to be a far worse mistake than Iraq. But in every single theater that you look, with the possible exception of Japan which had been eccentrically mentioned, you will see what I can only describe as the wrong decisions taken.

Iran should not be a at the moment, it should much more like Egypt, and it could’ve been. There’s no reason for undermining the Pakistan government to the extent it has been undermined by American military intervention there. Russia, a putative friend eight years ago, is now a serious menace. Wherever you look, you see what I call the crashes down the road of neoconservatism, littering the highway of world affairs. This was unnecessary, it was not required by circumstance, it was choice, it was decisions made in Washington. Now those of us who feel very strongly about America, always regarded the basis on which America operated out of its area, America went abroad to do things, was that it had a sort of moral superiority. There was behind what it did, a backbone. And that backbone was the backbone on which those people who approved of American intervention abroad always relied on.

I’m afraid under the leadership of the last eight years, that backbone has snapped. It has been simply impossible to tell countries elsewhere in the world that the American example, that the American intention, that the American execution of its intervention has been for the best. People just don’t see it that way. If you go round many of these countries today, and I mean today, you see the most extraordinary faith put in the next American President—

If you go round the world today, you will find the most extraordinary faith in the person you’ve elected as your next President. I have never come across anything like it. A totally naïve belief, that this is the messiah, Barack Obama, has come to save not you, but everybody. He will solve the Middle East. He will get out of Iraq, he’ll get out of Afghanistan, he’ll pacify Pakistan, he’ll make friends with Iran. Ludicrous expectations are placed on the shoulders of this man. The reason why that’s happened is because people simply have despaired over the last eight years. The reason why, I think, unrealistic but possibly disastrous expectations are made of Barack Obama, is that, George Bush, for better or for worse, George Bush, has caused such a catastrophe in so many countries around the world. I congratulate you on voting for Obama, I hope you will vote for this motion, thank you.

### Moderator
Claim: Simon, could you repeat that line because we wanna not edit the bell and…

### Conspiracy Advocate (CA)
Claim: If you go round the world today, you will find the most extraordinary faith in the person you’ve elected as your next President. I have never come across anything like it. A totally naïve belief, that this is the messiah, Barack Obama, has come to save not you, but everybody. He will solve the Middle East. He will get out of Iraq, he’ll get out of Afghanistan, he’ll pacify Pakistan, he’ll make friends with Iran. Ludicrous expectations are placed on the shoulders of this man. The reason why that’s happened is because people simply have despaired over the last eight years. The reason why, I think, unrealistic but possibly disastrous expectations are made of Barack Obama, is that, George Bush, for better or for worse, George Bush, has caused such a catastrophe in so many countries around the world. I congratulate you on voting for Obama, I hope you will vote for this motion, thank you.

### Moderator
Claim: Thank you, Simon Jenkins. Karl Rove has been a member of President Bush’s political family since President Bush first decided to go into politics. It goes back more than two decades. He is known as the architect of the 2000 and 2004 victories. The President has referred to him as “The Boy Wonder.” Ladies and gentleman, Karl Rove.

### Scientific Advocate (SA)
Claim: Thank you, John. Thanks to Intelligence Squared for having me here tonight. Simon, I know what you mean about the problem with foreign accents. And I noticed it didn't take you all long to vote, did it. I'm going to make an appeal to the open minded people of the upper west side. And for those of you sensitive to sulfur and brimstone, I apologize, nothing I can do about it. I’d like to spend my time talking about the drive-by’s we just saw. Let’s start with education. We say a drive-by on No Child Left Behind. Sure, we said states should set standards. We didn't set one national standard, because we wanted the people in New York and the people in New Mexico to be engaged in setting standards for their states, and to be involved in setting up a system that they would buy into. And in the five years since No Child Left Behind has come into force around this country, which requires every state to set standards, and to test every child grades three through eight to find out if the children are meeting the standards for reading, writing, and other material, we have seen more improvement in reading and math and science scores in those five years than we’ve seen in the twenty-eight previous years combined. And the scores have gone up most… The scores have gone up most among minority communities, black and brown and poor and rural. We heard about immigration, with a, a line that said, somehow or other the President threw in with the immigration restrictions. You know what, I don’t think that bill we brought to the floor of the United States Senate was an immigration restrictions bill. It was a bill that resolved the problem in a comprehensive way, and the President showed courage by standing for it and making it possible. PEPFAR. I heard a dismissal of this incredible effort, by the generosity of the American people, that is today providing over two million people in Africa with life saving retroviral drugs. Now sure, we insist upon encouraging programs to have to educate people about abstinence and faithfulness within marriage, and how those can help break the cycle of the spread of AIDS. And it’s working. And free trade, I love this one, I love this one. I sat there and was part of the team that bled to win trade promotion authority, and you know how many votes we won it by? One. We got CAFTA, which was a no-brainer, should have been a no- brainer. You know how many votes we got it by? One. I sat there in that room, in the cabinet room with twenty-two Democrats who voted for NAFTA, and China, and TPA under Clinton, who could not bring themselves to vote for free trade under this President. Why? Politics. So, I appreciate the enthusiasm that some of our adversaries here at tonight’s debate have for free trade, and I'm looking forward to working with them in common cause on behalf of every free trade measure that comes before the United States Congress. And why don’t we make a pact that we’ll start with Columbia? Why don’t we do that. Now, about that invasion of Iraq, I appreciated hearing about how it was done on a false premise, and hearing those words come from the mouth of somebody who wrote eloquently about the need to remove Saddam Hussein from power, I appreciate your support at the time. Nice of you to flip flop now. Easy to flip flop now. Look, do we wish we had the, that the weapons were there? And it was justified under those terms? Yeah. You know what? You know what, though? Smart people, like Bill Clinton and Al Gore and John Kerry and our new Secretary of State designate sat on the floor of the Congress or at the White House in the nineties, or in the Congress in the 2000’s and said Saddam Hussein had weapons of mass destruction. And we now know that there was a reason why he didn't have them, but he wanted us to think he had them. He told his interrogators he felt it made him look big in the neighborhood, and he, and we know from two reports by, by Kay and Duefler, that Saddam Hussein was intent upon recreating these programs the moment the West lost its interest in him. So he literally siphoned tens of millions of dollars out of the Food for Peace Program to do two things, to keep together the engineers and the scientists and the technicians to reconstitute these programs, and to keep the dual use facilities to rapidly reconstitute particularly the chemical and biological programs. Now, I loved also being lectured about sabotaging unity after 9/11. I sat there in those meetings on Homeland Security, where we had a great consensus about the need to defend the homeland by reorganizing our government, and the Democrats insisted on one thing, that the Department of Homeland Security should not be subject to the same constrictors regarding union membership that John F. Kennedy put in place for the rest of the government in 1961, and that Jimmy Carter signed into law in 1979. They wanted the Department of Agriculture and the Department of Transportation to be governed by strictures that said, in a time of national security, certain elements of the agency could be declared off limits for union organizing, but they didn't want that same rule to apply to one department in the government, The Department of Homeland Security. Because they saw it as a sop for their union allies. That was not national unity in the aftermath of 9/11, and it was an absence of national unity, because there were Democrats in the Congress who never accepted the legitimacy of this President. Talk about the mismanagement of the economy. Let’s talk about it. The Dow down thirty-eight percent, the NASDAQ down seventy-eight percent. The S&P down fifty percent. Six trillion dollars lost in value in one year. I'm not talking about today, I'm talking about March 2000, when the markets started to go down and bottomed out in October of 2002. Thank God this President had the wherewithal and the political capital and the moxie to pass a large effective stimulus package of one point six trillion dollars over ten years that got the economy growing again by long lasting tax cuts that benefited everybody in America who pays taxes. Even the critic Ray Fair at Yale, who forecast that in 2000 his model said George Bush would get thirty-four percent of the vote, he was just a little bit off, said that without this one out of every twenty American workers who were employed in 2001 and 2002 would not have been employed were it not for the tax cuts. Now, we’ve heard some other things, Fannie, and we’ve heard about Yassir Arafat, giving blood in the aftermath of 9/11. Well, as long as America wasn’t going to throw over Israel as our ally and friend, that was going to be a temporary act of friendship, and an enduring life of hate. And Iran, it’s somehow our fault, Bush’s fault, that the Ayatollah’s, and the Mullah’s, and the lunatics are pursuing a nuclear weapon in Iran? I think that has to do with their decision to pursue a nuclear weapon, not us making them do it.

And Pakistan? I loved it, being lectured about undermining the government of Pakistan. After all, haven't we just elected a President who promised to invade Pakistan if it didn't comply with America’s wishes? Now look, I will defend the President, and I will defend the record of the last eight years. Not always successful, but enormously successful over the long term and the long sweep of history.

Thank you for having me here tonight.

### Moderator
Claim: Karl, you’ve got thirty seconds.

### Scientific Advocate (SA)
Claim: And Pakistan? I loved it, being lectured about undermining the government of Pakistan. After all, haven't we just elected a President who promised to invade Pakistan if it didn't comply with America’s wishes? Now look, I will defend the President, and I will defend the record of the last eight years. Not always successful, but enormously successful over the long term and the long sweep of history.

### Moderator
Claim: Karl Rove, thank you very much.

### Scientific Advocate (SA)
Claim: Thank you for having me here tonight.

## Round 2

### Moderator
Claim: Thank you, Karl Rove. And that concludes the opening statements. In a minute or two we’re going to come to you, the audience, again, reminding you to keep your questions focused and brief and have a question mark at the end of it. But we now have the numbers that tell us your opinions as you came off the street tonight. On our motion that George W. Bush is the worst president of the last fifty years, that Bush 43 is the worst president of the last fifty years, sixty-five percent of you are for the motion, seventeen percent against, and eighteen percent undecided. And again, as we said at the beginning, we tend to judge success in this debate by how much you can actually move those numbers. So, if that sixty-five percent goes up, the side for will have prevailed, if the seventeen percent that is against goes up, that side will be seen to have prevailed.

Anyone ready with questions just yet? Yes? Lady standing here. You can sit if you’d like to, it’s up to you.

### Moderator
Claim: This is a question for any member of the panel. What president in the last fifty years has faced the challenges that Bush 43 has faced?

### Moderator
Claim: Very good, and very sharp and focused question. Bill Kristol.

### Scientific Advocate (SA)
Claim: Every president faces challenges, and obviously each different. But I think if you're implying that Bush faced particularly stark challenges, with a plummeting economy as he took over, and then of course 9/11, for which the government wasn’t prepared, the country wasn’t prepared, the Bush administration frankly wasn’t prepared, but certainly the Clinton administration hadn't done much to help prepare for, I think the President reacted well to the challenges he faced. And that is what makes someone a reasonably successful president. He made mistakes, as he said recently in the interview. You know, he wasn’t, he hadn't realized he was going to have to fight two wars, no one thought we would do that, be doing that in October of 2000. He adjusted in the conduct of those wars, I think pretty well, and the same with Homeland Security, they made a couple of mistakes, but basically ended up, thank God, I think, hardening this country in a pretty effective way, and putting al Qaeda on the run by taking the offensive. I really don’t understand this, I mean, Pakistan, poor Bush, he gets criticized not promoting democracy in Pakistan enough. Then we promote democracy in Pakistan, we have elections, we actually have a rather good leader of Pakistan, now he has a corrupt past, but has said the right things about trying to curb… Well, you can laugh about it, but it’s a tough place to govern. He’s trying to curb the ISI and the terrorists. We’re now going in aggressively in the northwest frontier to take out al Qaeda. I don’t think that’s a mistake. I think Obama is right to support Bush on that. So, I think Bush adjusted well to very difficult circumstances.

### Moderator
Claim: Jacob Weisberg, the implication of that question is that no president could have done well with these circumstances. What do you think of that?

### Conspiracy Advocate (CA)
Claim: Well I disagree with that. Every president until, through Bush’s father, had to manage the Cold War which was infinitely more threatening to the existence of civilization than September 11th was. And in particular, if you want a particularly specific example, John F. Kennedy and the Cuban Missile Crisis, which probably brought us closer to Armageddon than we’ve ever been. And the way Kennedy personally managed that crisis, if you’ve ever seen the movie Thirteen Days, or listened to any of the tapes, is an amazing story, because he rejected the advice of very powerful people in his administration who claimed to know a lot more than he did. But his instincts were very good, and he made the decision that saved us all.

### Moderator
Claim: Audience questions. I'm going to collect a couple. To the right here, and then I want to get to the other side, I see a white sleeve halfway up, keep that hand waving and we’ll get a microphone to you.

### Moderator
Claim: Thank you. This is a question for Mr. Rove. I have great belief in the wisdom of the gross American population. If what you have said about the Bush successes is true, how is it that his general, approval record is so extraordinarily and historically low.

### Moderator
Claim: OK, I'm going to hold that question, Karl, and collect a couple of others. But we will come to it. The gentleman with the white sleeve we spoke of?

### Moderator
Claim: This is also a question for Mr. Rove. If the United States is known for its Constitution and for respect for the rule of law, how would you rate the Bush presidency? And as a follow-up question, why would you not testify in a criminal investigation related to abuse of government power? Thank you.

### Moderator
Claim: All right. We’re going to take these two questions. Now, these questions are to Karl, but I see an opening a truck could drive through for your opponents to also be part of this conversation. Karl, the first question, why are the President’s approval ratings so low?

### Scientific Advocate (SA)
Claim: Yeah, well look, we’re asking, it’s an unpopular war, and we’re asking the country to do tough things for a long time. And the economy’s bad. I would remind you, not to correct Mr. Weisberg, but there have been three presidents who have had lower approval ratings that I'm aware of, Carter, well actually four, Carter, Nixon, Johnson, and Truman. Truman left office with numbers lower than this President’s. History has judged each of these men differently after their departure. If I could respond to the second one, rule of law. First of all, I'm not aware that I’ve refused to testify in a criminal investigation. You may know something I don’t know. You want to elucidate? I think what you may be suggesting is why will I not testify in front of the United States Congress? And the reason is because I believe in the rule of law. The rule of law that says there’s a separation of powers between the executive and the legislative branches, and that the President of the United States has a right to receive confidential advice form his assistants, which has been upheld by the United States Supreme Court. Now, right now it’s being re- litigated again, because the United States Senate did not like the answer the White House gave them in the summer of July, in the summer of 2007. If I'm called upon, and a court of law says that the President has no such right, I’ll testify. In the House of Representatives and in the Senate, we have made numerous attempts to provide the Congress with the information that it’s requested, in a way that protects the right of a President and his prerogative to receive that kind of advice from his staff, from his confidential advisors. The Senate has refused to take any one of the options. The House refused to take five separate options that we gave them, until finally, some members of the House Judiciary Committee asked the questions that were being asked by the Committee, and sent them to me. And under penalty, I responded to those, and if you like, you can find my answers at Rove.com. So, I’ve answered them. But, there is a rule of law, and we ought to respect that rule of law that says there is a separation of powers between the branches, and that’s exactly why I’ve been directed by the President not to testify in front of Congress on these issues.

### Moderator
Claim: Simon Jenkins, I want to bring you into the conversation. We, the issue, that question was premised on the notion that America’s image has always rested on its adherence to the rule of law, and that the years of the Bush administration have, to some degree, to seem to have been a disintegration of the value of the Constitution. With Barack Obama now taking over, does the fact that he has this terrible image with which to compare himself, give him a boost, or does the fact that American leadership have been so diminished, respect for America has been so diminished, give him a terrible starting point?

### Conspiracy Advocate (CA)
Claim: Well, I think the origin of this whole part of the discussion is the response to 9/11. 9/11 is the starting point of almost everything that we’ve been talking about. And I think many people in Europe, and around the world, simply feel that America over- reacted, and so did Britain, I may say. So, this is not something peculiar to America. It was a feeling that some new force had been unleashed on the world to which we had to respond by restricting our normal customary defenses and liberty. I'm a libertarian, and I feel that was, I’ve always felt that was simply unnecessary, the reaction was an overreaction. The consequence of it, however, is that we have, in a sense, played the terrorist’s game. We’ve done what they wanted us to do, which was restrict our liberties, curb our liberties, behave in a certain way towards other States and other peoples that we would not normally have done before. And—

### Moderator
Claim: But I heard Bill Kristol saying, and Bill, let me bring you into this, I’ve heard you say that, when it comes to terrorism, rather than playing the terrorist’s game, that the President has succeeded in putting the terrorists on the run, which is why 9/11 was the only incident in this city.

### Conspiracy Advocate (CA)
Claim: Would that they were on the run.

### Moderator
Claim: Bill Kristol.

### Scientific Advocate (SA)
Claim: Well, they haven't been very successful here, and they haven't been very successful in Western Europe, and they’ve actually not been very successful elsewhere. Al Qaeda has been a losing proposition for the last several years. It remains a huge problem of, a jihadist impulse in the Islamic world, which is, unfortunately, abetted by certain states. But I think Bush has done a pretty good, well, a very good job of making terror a losing proposition, which is the most important thing he could have done, taken away their momentum, which again, if we had not gone into Iraq, and if we had lost in Iraq, that would have been the single most disastrous result. Bush turned that around. But I just don’t buy this premise that we’ve radically curved civil liberties. Bush has done less after the 9/11 attack than any other President has done, much, much less, he’s much more responsible than Franklin Roosevelt was after we were attacked in World War II. He’s been much more solicitous of civil liberties than, if I might say, John Kennedy and Lyndon Johnson were during, and Richard Nixon were, during Vietnam. We’ve had, you know, some controversial calls, and some tough calls. There were a couple of over-reactions which the Bush administration itself walked back, Jack Goldsmith and Attorney General Mukasey have, I think, corrected some controversial interpretations that probably went too far—

### Moderator
Claim: Bill, can I interrupt you—

### Scientific Advocate (SA)
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: One second—

### Moderator
Claim: Jacob Weisberg.

### Conspiracy Advocate (CA)
Claim: Jack Goldsmith was drummed out of the Bush administration for challenging those decisions—

### Scientific Advocate (SA)
Claim: That's not true.

### Conspiracy Advocate (CA)
Claim: He was not—

### Scientific Advocate (SA)
Claim: They, he changed the actual Office of Legal Counsel policy, and Attorney General Mukasey is leaving the Bush legal program intact, and I—

### Conspiracy Advocate (CA)
Claim: But if you—

### Scientific Advocate (SA)
Claim: It’s totally defensible, and it will not be changed much by Barack Obama.

### Conspiracy Advocate (CA)
Claim: If you read Goldsmith’s book he was driven out, more or less. But the point is you--I'm amazed by--I appreciate how open minded you are about some of these issues. But on the civil liberties issues, you're amazingly cavalier. Closing Guantanamo is no big deal, we have them here, we have them there. Torture, you won't second guess the decisions. I mean, these go to the heart of the questions about the rule of law and the Constitution, and the question of whether terror suspects…

### Scientific Advocate (SA)
Claim: OK, well what is the question?

### Conspiracy Advocate (CA)
Claim: The question—

### Scientific Advocate (SA)
Claim: Bush—

### Conspiracy Advocate (CA)
Claim: The question—

### Scientific Advocate (SA)
Claim: Bush has lost fewer court decisions than almost any president has. He lost two five to four decisions. You can, maybe the five were right, maybe Bush shouldn't have gone quite as far as he did in some of the claims he made about Guantanamo. But we are going to have to detain people. We are not going to be able to provide them all civil trials. I do not believe that is a way you can deal with terrorists captured on the battlefield.

### Conspiracy Advocate (CA)
Claim: Why can't you deal with them with military trials? We have an existing—

### Scientific Advocate (SA)
Claim: We are, he set up a system of military trials—

### Conspiracy Advocate (CA)
Claim: No, he set up his own alternate system. We already had a system of military justice—

### Scientific Advocate (SA)
Claim: He signed legislation—

### Conspiracy Advocate (CA)
Claim: He decided he needed his own—

### Scientific Advocate (SA)
Claim: …that Congress passed. He signed legislation that Congress passed in 2005 and 2006.

### Moderator
Claim: Karl Rove, let’s bring in Karl Rove. And I just want to say, it’s fine to register your reaction to this with applause. I heard it for Jacob, I haven't heard it for Bill Kristol. I mean, is there a sense of support for, for Bill Kristol’s argument?

### Scientific Advocate (SA)
Claim: No, no, no…

### Moderator
Claim: Karl Rove?

### Scientific Advocate (SA)
Claim: Don’t, don’t be doing that again, John, we’ve lost sixty- five/seventeen. Come on, man. I’m delighted that we did better than the Upper West Side—

### Moderator
Claim: I was trying to get the seventeen to applaud here.

### Scientific Advocate (SA)
Claim: You know, we got eight percent of the vote in one of the precincts up here, I mean, come on, man! Come on! All right, look, it’s clever to suggest that we ought to have the military, the style of courtroom justice we provide to our military, and provide that for enemy non-combatants, I mean enemy combatants. We shouldn't. That’s what we attempted to do in the military justice system, is to the greatest possible degree possible duplicate our civil justice system. And are you suggesting that we ought to Mirandize these people and keep a chain of evidence and all the other things that we normally do in both military and civilian courts for terrorists?

### Conspiracy Advocate (CA)
Claim: Not at all, and people have far fewer rights under the military system. But the point is, under your system, they have no rights. The prisoners at Guantanamo were originally denied access to a lawyer, we couldn't even find out who was there, and the original claim by the Bush administration was that this applied to citizens as well as non-citizens. So, if the Bush administration decided that you were suspected of terrorism, you could be held indefinitely without a lawyer, without a hearing, without a trial.

### Scientific Advocate (SA)
Claim: You know what—

### Conspiracy Advocate (CA)
Claim: I'm not saying that these—

### Scientific Advocate (SA)
Claim: With all due respect, you're making it sound like everybody on the Upper West Side needs to worry about being sent to the reeducation camps in Texas. And in reality what it was focused at is, if we picked up a US Citizen who was a terrorist on a battlefield abroad, would we subject him to US law, or would we treat them as a terrorist—

### Conspiracy Advocate (CA)
Claim: But here’s what you slipped in, if we picked up someone who’s a terrorist. What if they happen not to be a terrorist? Some of these people have been acquitted.

### Scientific Advocate (SA)
Claim: And the system has a process of review in which that determination can be made.

### Scientific Advocate (SA)
Claim: Anyway, the big picture, look, the fact is in the big picture—

### Scientific Advocate (SA)
Claim: Name one guy you're worried about—

### Moderator
Claim: Let’s take it to Bill Kristol.

### Scientific Advocate (SA)
Claim: Name one guy you're worried about.

### Conspiracy Advocate (CA)
Claim: No, that's exactly right.

### Scientific Advocate (SA)
Claim: You're worried about John, John Lindh? You're worried about him?

### Conspiracy Advocate (CA)
Claim: I'm, I'm—

### Scientific Advocate (SA)
Claim: I mean, what person are you worried about?

### Scientific Advocate (SA)
Claim: Was the Bush administration bad at explaining their policies, especially abroad? Yes. Did people abroad take a kind of cavalier and really, hypocritical sense of pleasure in decrying those ridiculous Americans with all this stuff? While they themselves, of course, as you know well, in Continental Europe, treat their own citizens with many less rights, are much, much nastier to their minorities, Bush went out of his way, and with great success, to say this is not a war on Islam, we need to protect everybody’s rights, he was incredibly solicitous, as he should have been of Muslim-Americans, Muslim-Americans here have a much fairer and more equal playing field than Muslims do in most of these wonderful European countries that sit around having heart attacks about two hundred people held at Guantanamo…

### Moderator
Claim: Simon, let’s—

### Scientific Advocate (SA)
Claim: And let’s just talk, Bush made two Supreme Court appointments, they were incredibly highly qualified. Alito, sixty-one appointments to Federal courts. Whatever, they were conservative, of course, as Obama’s will be liberal, extremely highly qualified judges. He made a couple of mistakes, I think, in his appointments, out of excessive loyalty, perhaps with Alberto Gonzales, but the fact is, Ashcroft was a serious Attorney General, and then he brought in Mukasey, and he’s leaving an intact and functioning legal system which we can be proud of given the threats we’re facing.

### Moderator
Claim: Simon Jenkins?

### Conspiracy Advocate (CA)
Claim: What I think is extraordinary to people abroad, is that those of us who are enthusiasts for America and American liberties cannot see why you needed to do these things. You will never persuade the outside world that you have not restricted liberty in America. You will never persuade them that you have not taken out Muslims as a particular group, and you will never, and you never persuade them that you really needed to do these things.

### Scientific Advocate (SA)
Claim: What things?

### Conspiracy Advocate (CA)
Claim: Because—

### Scientific Advocate (SA)
Claim: What have we done to Muslims in America? What has happened?

### Conspiracy Advocate (CA)
Claim: Arrested them.

### Scientific Advocate (SA)
Claim: We’ve arrested Muslims in America?

### Conspiracy Advocate (CA)
Claim: Incarcerated them without trial.

### Scientific Advocate (SA)
Claim: We’ve incarcerated—

### Scientific Advocate (SA)
Claim: Rounded them up?

### Scientific Advocate (SA)
Claim: …Muslims in America without trial?

### Scientific Advocate (SA)
Claim: Rounded, rounded them up? Name one?

### Scientific Advocate (SA)
Claim: Nonsense.

### Scientific Advocate (SA)
Claim: Name one instance.

### Conspiracy Advocate (CA)
Claim: The, belabor me all day with lists of people who have vanished. Vanished.

### Scientific Advocate (SA)
Claim: You know—

### Scientific Advocate (SA)
Claim: Well, that—

### Scientific Advocate (SA)
Claim: This is on the border of lunacy, with all due respect.

### Conspiracy Advocate (CA)
Claim: But you didn't need to do it, you didn't need to do it—

### Scientific Advocate (SA)
Claim: We didn't do it!

### Moderator
Claim: All right, let’s come back to some questions.

### Conspiracy Advocate (CA)
Claim: Hang on, hang on here.

### Conspiracy Advocate (CA)
Claim: You didn't need Guantanamo Bay.

### Moderator
Claim: I see down in, down in the front row, there—

### Conspiracy Advocate (CA)
Claim: You’ve got the world believing America is a less robust place, and it really is.

### Scientific Advocate (SA)
Claim: Now, what part of the world is that? Is that—

### Conspiracy Advocate (CA)
Claim: You—

### Scientific Advocate (SA)
Claim: …China and India? Do they have… I'm serious.

### Conspiracy Advocate (CA)
Claim: No.

### Scientific Advocate (SA)
Claim: Let’s talk about “the world.”

### Conspiracy Advocate (CA)
Claim: Yeah, yeah.

### Scientific Advocate (SA)
Claim: The world turns out to be a certain class of liberal elites in Western Europe. Not all of Western… It does, it does! Is Bush… Is America unpopular? Has anyone here been, is America unpopular in East Asia? Is America unpopular, has Bush’s policy towards China been terrible in terms of Chinese views? Have we had a, India is a great success story, a rather important, huge democracy, for Bush. Even in Western Europe, when Bush took over, there were rather anti-American prime ministers, democratically elected obviously, in France and in Germany—

### Conspiracy Advocate (CA)
Claim: It’s just not true.

### Scientific Advocate (SA)
Claim: Or at least skeptical of America. Then Merkel wins in Germany, and Sarkozy wins in France. If they're so, if America’s image is so ruined, if they just can't stand America, why did they elect the more pro-American candidate in both of those races?

### Moderator
Claim: I want to go to questions. First row? And you know I don’t want to be biased against folks in the back just because I can't see them, if you can be a little horizontal. Ah! All the way in the rear, blue shirt? I want to collect your question in the front row, and then you’ll be—

### Moderator
Claim: Well, I hate to disrupt that exchange, but question for Mr. Rove and Mr. Kristol, who is the worst President of the last fifty years and why?

### Moderator
Claim: One second. Let’s see what we have in the back.

### Moderator
Claim: The statement has been made that we have been made safer since, because of President Bush’s administration since September 11th. If he is to receive credit, is he to receive blame for not protecting us from September 11th?

### Moderator
Claim: OK, I want to take a third one from about eight rows up, and three rows, three seats over.

### Moderator
Claim: Question for misters Kristol and Rove. In the last fifty years this administration has been by far the biggest spending administration with the possible exception of Lyndon Johnson.

### Moderator
Claim: Can, sir, can we ask you to start the question again? Thank—

### Moderator
Claim: In the last fifty years, this administration has been by far the biggest spending administration with the possible exception of Lyndon Johnson, and that’s even before spending on Homeland Security and Iraq. What is your response to that.

### Moderator
Claim: OK, I want to go to the second question first. On the question of September 11th, does President Bush deserve any blame for September 11th?

### Scientific Advocate (SA)
Claim: We published in the Weekly Standard of, in July of 2001 an article by Reuel Marc Gerecht, who I think has participated in these debates, alarmed that we were not doing enough to fight al Qaeda, that they had bombed the USS Cole in October of 2000, and that neither the Bush administration, nor the Congress, the Democrats, Republicans, really understood how serious the threat of al Qaeda was. I think the Bush administration would say, I mean, I think Conde Rice and others have said this, that they now wish, of course, they had been more alarmed and more alert as they had taken office in those first few months. So yes, there is blame to go around on 9/11. But fundamentally, the growth of al Qaeda, the ability of al Qaeda, which was key to have the terror training camps unmolested in Afghanistan, is not something that primarily happened under Bush.

### Conspiracy Advocate (CA)
Claim: Can we just, one more word on this, because if you read Richard Clarke’s book, or some of the other inside accounts of this, it’s clear, it’s not that nobody had heard of al Qaeda, Richard Clarke, for example, was running around with his hair on fire about how dangerous this threat was. And it’s clear that Bush, in the early days, downplayed it, rejected it, didn't take it seriously, and did so because it had been a particular focus of the Clinton administration, and he was reversing policy.

### Scientific Advocate (SA)
Claim: The focus…? If it was such a focus of the Clinton Administration, it would be nice to know what they did about it, since—

### Conspiracy Advocate (CA)
Claim: Well they…

### Scientific Advocate (SA)
Claim: Richard Clarke himself—

### Conspiracy Advocate (CA)
Claim: They launched missile strikes—

### Scientific Advocate (SA)
Claim: Well, they launched one series—

### Conspiracy Advocate (CA)
Claim: …on Osama bin Laden—

### Scientific Advocate (SA)
Claim: One series of—

### Conspiracy Advocate (CA)
Claim: They missed. Bush hasn’t got him either. They started a little later. Anyway…

### Moderator
Claim: A question you were asked, who is the worst President of the last fifty years?

### Scientific Advocate (SA)
Claim: Look, I mean this is a, you know, this is why this question is a little artificial. I mean, Lyndon Johnson probably made the worst mistake, perhaps, of the last fifty years, with Vietnam, but he also deserves a huge amount of credit, I think, and I’ll say this as a conservative and a Republican, some of what he did in terms of, certainly, civil rights, and I would say something like Medicare. So, people are not, you know, univocally good or bad. I do think, at the same time, personal, corruption of the political system for political, of the judicial system, and of the governmental system for political ends, clearly Nixon. And I would say in terms of just incompetence and leaving the country in dangerous shape which had to be reversed, Carter. So, the seventies was a bad decade, in my opinion, for American presidents, and for America, and for the world. Which was reversed by Reagan.

### Moderator
Claim: Karl Rove, we had a questioner say that President Bush was a big spender.

### Scientific Advocate (SA)
Claim: Yeah, look, I like how first of all you did put, say put aside Homeland Security. Let’s take a look at discretionary domestic spending. The last budget left to us, the FY ’01 budget, left to us by that previous President whose name you can fill in, increased discretionary domestic spending in FY ’01 fifteen percent in one year. That means that would double the discretionary spending of the Federal government, if left at that rate, in five and a half years. We cut, in our first budget, FY ’02, discretionary domestic spending to seven percent, in FY ’03 to four percent, in FY ’04, excuse me, FY ’05, two percent, and six, seven, and eight, have flat lined discretionary domestic spending of the government. Been hard to do. We’re going to leave a big, we’re going to leave an enormous benefit in place for Barack Obama in that we have flat lined discretionary domestic spending.

### Scientific Advocate (SA)
Claim: And the biggest, and the biggest spending item is, are two things, the tax cuts, we can debate economic policy, but I think an awful lot of people think especially 2003 tax cuts were sensible and ended up producing, actually, a lot of revenue. And prescription drug benefit, which I would defend as a conservative. Medicare exists, it is a pretty good program, it had to be improved, it had to be updated by bringing prescription drugs into it. It’s come in under budget, and I think, what, ninety-two percent of seniors are covered, and it seems to be working pretty well. Now, if you're a strict, small government libertarian conservative, you would object to Bush starting a new entitlement program, and that’s a defensible, philosophical position, but in that case, the biggest domestic expenditure, the biggest piece of domestic legislation of the Bush administration, it did what Bush said it was going to do.

### Moderator
Claim: I'm collecting questions again, from the upper left where the camera is.

### Scientific Advocate (SA)
Claim: John, could I add a little bit of that to, to—

### Moderator
Claim: I want to move on, Karl, because your colleague covered it quite well.

### Scientific Advocate (SA)
Claim: He did.

### Moderator
Claim: Yes, sir?

### Moderator
Claim: Hello, my question is for mister…

### Moderator
Claim: Your, I think your mic might have cut out, at least it did to the hall here. Can you try again?

### Moderator
Claim: …Jenkins…Weisberg. Before 9/11 terrorism was viewed as a criminal act, let’s investigate, let’s get the bad guys. In my opinion—

### Moderator
Claim: Sir, I apologize because we’ve got the camera with you, and the mic is malfunctioning, and another one is on its way to you. While that’s happening, I'm going to go to a question down front row center.

### Moderator
Claim: Yes, for Mr. Rove. Had the—

### Moderator
Claim: Wait, I'm sorry, do you need the shot? You're good? OK.

### Moderator
Claim: Mister—

### Moderator
Claim: I'm sorry, we, we’re not quite ready. OK. We can't hear you also. OK. Try again.

### Moderator
Claim: Had

### Moderator
Claim: I just want to ask our broadcast side if they heard that, because I know I didn't. All right. Here it comes.

### Moderator
Claim: The question is for Mr. Rove. Had the intelligence been accurate prior to the invasion of Iraq, would the invasion have still taken place, in your view?

### Scientific Advocate (SA)
Claim: No. In the aftermath of 9/11 the concern was about a tyrant guilty of enormous human rights abuses, but possessed with weapons of mass destruction and an intention to use them as a state sponsor of terror. Absent that, I suspect the administration’s course would have been to work to find more creative ways to constrain him than he’d been constrained in the nineties. The President did have an enormous concern about the human rights abuses under Saddam Hussein. He also had a concern about the deterioration of the credibility of the United Nations, which had passed sixteen resolutions calling upon him to abide by the outcome and the agreements that he made in the aftermath of the ’91, of the first Gulf War, that he’d not lived up to. But absent weapons of mass destruction, no, I don’t think there would have been an invasion.

### Moderator
Claim: OK, are we set for the question up in the corner up here yet? And otherwise I’ll come up the aisle, if you can come up the aisle, red sweater. Let’s wait till the camera reaches you. Very good, very patient.

### Moderator
Claim: Thank you. My question is for Mr. Rove. What is the future of the party? Specifically in terms of diversifying the party? As we’ve seen, that was the biggest issue next to the economy. Can you please talk on that issue.

### Moderator
Claim: OK, let’s hold that question and collect a couple more, just because we’re having this microphone problem. The young lady of two rows down, eyeglasses.

### Moderator
Claim: This is for Mr. Jenkins and Mr. Weisberg. You’ve criticized President Bush for going to war with Iraq. If President Bush had not decided to go to war with Iraq and had only decided to go to war with Afghanistan to fight terrorism, do you think Saddam Hussein would have, A, remained a neutral and impartial observer in the war between Islamic terrorists and the West; B, allied with the United States in an effort to stamp out Islamic terrorists and bring democracy to Afghanistan; or C, grown a dangerous supporter and protector of Islamic terrorists, including al Qaeda and others.

### Moderator
Claim: Simon and Jacob, why don’t you take that.

### Conspiracy Advocate (CA)
Claim: We have a problem here. I just don’t see terrorism as a state projected force in the way that you do. I regard it in the sense that the question was trying to ask before, as a criminal act of gangsters roaming the world, and badly in need of curtailing by their own governments. I think the way we treated international terrorism is to glorify it, to give it the status of a state. We’ve given huge recruiting energy to those people who want to bring young people into this particular odious fold, and I think by declaring war on some governments, I may say not all governments that harbor them, we’ve accorded them a status wholly beyond what they deserve. I believe that my country and your country’s overstated this threat. I just think we’ve overdone it. And in overdoing it, we turned very large numbers of countries in the, particularly in the Islamic world, into state menaces. They themselves are undermined by the status we’ve given to these people. Pakistan being a classic case of that. This is quite a cosmic question. If you declare a very small group of people to be an international menace, you turn them into a sort of hero, and we’ve done that, and it’s been a terrible, terrible mistake.

### Moderator
Claim: Jacob?

### Conspiracy Advocate (CA)
Claim: Mr. Rove mentioned somewhere in that incredible litany of distortions that… that I was in favor of getting rid of Saddam Hussein. I was, as were a lot of sensible people. I didn't happen to favor doing it the way Bush did, largely unilaterally, rejecting allies, as opposed to building pressure on Saddam, and not waiting for the inspection process to play out. But I think the point is, and what we’ve subsequently learned, and the problem I had that Bush didn't have, was I did not have access to analysts from the Department of Energy trying to tell everybody that those aluminum tubes were not for nuclear weapons. But the point is that Saddam was being, had been successfully disarmed, and was being successfully contained, and he was not supporting international terrorism, because he was afraid to. He was a miscalculator, a serial miscalculator, but he was not a mad man, and I think he understood very clearly that supporting terrorism against the United States would have resulted in the same thing that happened anyway, his destruction. I think what would have happened if we didn't invade Iran, I’d actually like to turn the question around a little bit and ask Bill Kristol, for example, does he, knowing what we know now, still think invading Iraq would make sense? But I think that we might have ended up having to take military action against Saddam Hussein at some point in the future. But I think we could have done it with allies, I think we could have done it in a more thought out way, and I think we could have planned for an occupation, it could have been expected if we knew we were going to have to do it.

### Moderator
Claim: Bill, I think that question to you was more than rhetorical, but I want you to take twenty seconds to answer it.

### Scientific Advocate (SA)
Claim: I think Karl is right that we, that the President would not, in fact, have gone to war if he had known what seems to be the case, that Saddam had no real functioning weapons of mass destruction programs at the time. I, having said that, so I think as an analytical manner Karl’s certainly right, the American political system wouldn't have supported it. Now, I think it was right to go to war to remove Saddam. I think the Middle East would be incredibly much more dangerous if he were, or his sons were in power. I think every radical state and every radical group would be empowered, because weakness is what empowers them, and he would have stood, stood down, in effect, the US, and the UN, and the civilized world. It’s inconceivable we could have kept the sanctions up. They were already fraying. It’s inconceivable, the inspectors were only in because we moved a hundred and fifty thousand troops next door. They would have gone out, it would have been a horrible defeat for the West, and I think it would have, we would have had a much more resurgent radicalism in the Islamic world than we have today, where I think it’s a mixed bag, that actually in many respects the terrorist groups are on the defensive and on the run.

### Moderator
Claim: Karl Rove, you had a question… You had a question, Karl Rove, about the future of the party particularly in its ability to be more diverse.

### Scientific Advocate (SA)
Claim: Well, after a loss, every political party goes through a period of introspection and rebuilding, and Republicans have to do that this time. Let’s be clear, though, about what happened in this election, and that is that Barack Obama got three point one percent more than Al Gore got in 2000. This is not the blow out that you might expect given the conditions of the economy and the unpopularity of the war. This was not a sixty/forty victory. He got fifty-three percent of the vote. He got seven point one million more votes than John Kerry got, and four out of every five were black or brown. And therein lies the challenge for the Republican party. The party of Lincoln needs to make a concerted appeal for African-American votes, knowing that in the short term it is going to pay off not one twit, and in the long run, it has a moral obligation as a great political party to represent all Americans. And it can only do that by making the case to African-Americans and Latinos. And Republicans have a similar problem brewing among Latinos. George Bush got forty-four percent of the vote among Latinos, John McCain, who was a courageous, early advocate of immigration reform, got thirty-one. We cannot take the largest, fastest growing minority in America and write it off like we did with African-Americans. And then we also have a problem with the young, because let’s be candid, the war has turned young voters, eighteen to twenty-nine, against the war. They voted for Obama by two to one, and they not only were against the war, they're against the Republicans. And those three Republicans have got to work on. But, on the other hand, Republicans had a victory, had a defeat this year that was not the blowout, and it was also the victory for Obama that was not as big as anticipated. I, take, for example, Ronald Reagan in 1980, when he got elected, he brought in a hundred state senators with him, net, and three hundred members of state houses. This time around Barack Obama brought in a net of ten state senators, and ninety-four house members. This was an individual victory for a charismatic, articulate, inspiring individual, an historical figure, and the Democrats are going to make a mistake if they think this is some kind of gigantic swing toward their party.

### Moderator
Claim: We’re heading down the home stretch from questions from the audience. Where the mic is positioned now, and the camera, and halfway up to the left, the red sleeve. I'm sorry, because I'm rather blinded by the lights, I'm seeing the colors of sleeves. I’ll take you over there first.

### Moderator
Claim: OK, as I tried to say before, my question is for mister Jenkins or Weisberg. Some will say that George W. Bush’s most difficult decision, and maybe most courageous, is to treat …and not a criminal act. I ask you, we’ve had decades to judge these, please name me the difficult and courageous decisions made by Lyndon Baines Johnson and Jimmy Carter that have been proven to be the right ones, please.

### Moderator
Claim: All right, and up here?

### Moderator
Claim: Mr. Jenkins, I watched Prime Minister’s questions on Wednesday morning. And the UK outlawed anchor babies as a way to curb illegal immigration. Do you think that would work here in America, and what does the panelists think?

### Moderator
Claim: I'm going to, I'm going to pass on that question, I'm afraid, because it’s actually not on our topic tonight, with respect, but thank you very much. And I want to ask the cameraman to pivot to his right, and there’s a man in a blue shirt.

### Moderator
Claim: To Simon and Jacob, how would you describe Bush’s prosecution of the Iraq War and his rationale for the Iraq War, versus the rationale and prosecution of the Vietnam War by JFK, LBJ, and Nixon—

### Moderator
Claim: All right, it’s—

### Moderator
Claim: And what differences do you see in how those two conflicts have been resolved?

### Moderator
Claim: It seems as though those two questions actually come together, so I'm going to go for a third one, the gentleman whom I can see clearly in the bright light with his hand up. Hold on, one moment. OK.

### Moderator
Claim: Just one simple question, first of all, thank you all for coming here. I'm curious, if an aspect of the success of the Bush presidency is his foreign policy, and his defending us against the, terrorism, then how do you explain the fact that no one has caught Osama bin Laden at this point, the chief architect of the act that set all this off?

### Moderator
Claim: Karl Rove?

### Scientific Advocate (SA)
Claim: Because he is hiding in a deep, dark cave in a very dark corner of, in all likelihood, Pakistan. And, to suggest that not every effort has been made to get him is inaccurate. Every effort has been made to get him, to get at his communications, to get at his allies, to get at his subordinates, to get at his inner circle. A lot of them are dead…and we aren’t hearing much from him. And…but we gotta recognize we’re dealing with an odd part of the world, this is not as Simon alluded to, this is not a state. And it operates through states, the Taliban controlled a state, Afghanistan, that harbored and trained and gave succor to these terrorists. But they live in a odd and dark part of the world that is not a state, and it’s what makes destroying al-Qaeda’s leadership and our relationship with Pakistan both two very problematic things.

### Moderator
Claim: Simon and Jacob, you had two questions along the lines of comparisons of George Bush to both Presidents Kennedy and Johnson, with I think the implication that, the President’s Iraq was their Vietnam, can you take on that question?

### Conspiracy Advocate (CA)
Claim: When I was a very young journalist, was in Vietnam at the very end of that war, and attended the relevant briefings, and this is not a—a very well-informed comment but, my view was that the Vietnam war and occupation of South Vietnam, was far more competently executed than the occupation of Iraq. The occupation of Iraq, was, and I followed American and British occupation troops around the world for most of my career—the occupation of Iraq was simply the most incompetent thing I’ve ever seen. It was stupefyingly incompetent… And I’ve no doubt at all that many people possibly on the platform wouldn’t disagree with that, because it was conducted by a very small group of people, against the advice of a much larger group of people within the administration. It simply has been a catastrophe. Afghanistan is much better conducted, although I think it’s a much more difficult war to fight. And that’s why I think it’s gonna end in greater tears than Iraq will end, Iraq is fairly simple to end, you just leave. It’ll be very, very difficult to leave Afghanistan. But certainly in Vietnam, I think you had on the whole relatively competent military people there, they had experience in Korea many of them. They lost but they only just lost. I do think that America could’ve stabilized South Vietnam had it stayed longer. It was not the right place to be and the right thing to do, but it was not a hopeless case. I think when you go into a country without a good reason, or with the purpose of simply punishing the country as was the case in both Iraq and Afghanistan, you’re not likely to do well, because you haven’t really plotted what the purpose of the exercise is, it was simply to punish. And I think it’s that punitive element that’s been the problem, certainly in Iraq. And I am sorry I’ve been there only twice, but I cannot accept that it is in any sense of the word a success.

### Moderator
Claim: Jacob?

### Conspiracy Advocate (CA)
Claim: Just on a— Sorry to step on your well-deserved applause, Simon. The… just on LBJ, the questioner asked what courageous thing did he ever do, just for starters, how about saying goodbye to the South for the Democratic Party for generations, when he signed the Civil Rights Act in ’64 and the Voting Rights Act in ’65. Johnson knew that would be the political consequence of that decision and he did it anyway, to me that’s almost the definition of political courage. On judgement however I don’t think Johnson does so well in Vietnam and it’s quite comparable to Bush, I think— I think both of them were very poor—I think both of them were essentially unable to admit error, to recognize error, and to reverse error. And, whereas Johnson a slightly different story, and you know, you get into sort of psychological territory here but, Johnson clearly didn’t trust Kennedy’s advisors. He had this longstanding issue with the Kennedy brothers and I think he was getting some good advice from some of the Kennedy people, but I think he couldn’t hear it because of who was giving it. And likewise with Bush on Iraq, certainly the advice he got from Colin Powell at the very beginning not to invade Iraq was very good advice. But I think Bush was so blinded by his own motives, whatever you think they were, that I think he effectively couldn’t hear that. And then he couldn’t hear the very good advice that I said came from Bill Kristol, among other people that the strategy was failing and— You know, it finally took just a series, I mean it got to the point really where there was a total consensus that the strategy was failed, and that Rumsfeld was failing and I think Bush postponed change until there was absolutely no choice.

### Moderator
Claim: Okay, we’re coming down to our last few minutes of questions and I would like to make it a little bit forward-looking and I just wanna see if any of the hands up here are—have questions related to what President-Elect Obama inherits from Bush, is anybody thinking along those lines quite clearly, and don’t snooker me because I’ll squash your question if it’s… Gentleman with the— Gentleman with the stubble. That’s what it is.

### Moderator
Claim: I think we all know that this issue won’t really be decided here tonight but it very well may be in 12 years, in 16 years, in 20 years. For those against the motion, can you paint us a picture of the world that would make your case?

### Scientific Advocate (SA)
Claim: Yeah. Iraq as a functioning semi- democracy in the heart of the Middle East, as an example, that would be a powerful antidote to the terrorist image of what the future oughta be like. Afghanistan stabilized, a continued decline in the ability of terrorist elements like al-Qaeda to threaten the West. A continued diminution in their ability to recruit, which incidentally I think you may have seen or heard about the new report out which shows a dramatic decline in their operational capability and in their recruitment ability. And a world where the institutions that the President is seeking to leave in place, like PEPFAR and the Millennium Challenge have revolutionized and changed America’s pattern of foreign assistance to focus on results, and transparency and accountability. And new institutions whether it is the replacement for Kyoto with the G8 agreement this year to pursue a new international regime in which all the major emitters are at the table, and all the major emitters are focused on energy efficiency and technological advances that allow them to clean the air and reduce greenhouse gases, like we have done, we’re the only economy, the last year for which numbers are available are 2006, there’s only one industrialized economy in the world that grows that year, and reduces the absolute level of greenhouse gases, it’s the United States of America because of the approach we’re pursuing.

### Scientific Advocate (SA)
Claim: Great—

### Scientific Advocate (SA)
Claim: That’s how it would look abroad.

### Scientific Advocate (SA)
Claim: Let me just add to that and just, very briefly, make it a little sharper perhaps. Look, from 1979 on the Iranian revolution and the disastrous Saudi Wahhabi decision to compete with the Iranian revolution by exporting Wahhabi Islam much more aggressively abroad, enabled to do that by the, obviously oil revenues from the ‘70s, that they—once they were able to jack up oil prices in the ‘70s— jihadism, Islamic jihadism, Islamic extremism, terrorism has been unfortunately on the rise doing some damage to us and huge damage obviously, within the Islamic world and in the Middle East, and the greater Middle East and in South Asia. Successful Bush foreign policy, I mean, successful US foreign policy, which would have been begun by President Bush, 10 or 20 years from now, would’ve reversed that and I think we are on the cusp of reversing that. I think that is why the intervention in Iraq, the stabilizing of Iraq as a non- extremist, non-terror-friendly regime in the center of the Middle East, the crushing of al-Qaeda, and there’s some very difficult things to be done with Pakistan but at least so far maintaining some of the decent civilian government in Pakistan, while moving aggressively against the terror, parts of Pakistan that had been for quite a long time, terror-friendly, I mean that, reversing that would be incredibly important, that is really crucial to having a decent 21st century. And I think Bush has begun to reverse it, there’s much more that has to be done, I trust that President Obama will do it. And secondly nuclear weapons. It’s amazing that we have had as little proliferation of nuclear weapons as we’ve had. Many experts think over the last 50 years in retrospect the Pakistani explosion of nuclear weapons in ’98, and I was no more prescient about this than anyone else, was a huge moment, a very dangerous moment, and what A. Q. Khan was doing, unbeknownst to us and, you know, to others, was unbelievably dangerous and made possible the North Korea program, it’s made possible the Iranian program, it accelerated the Iranian program. If we can prevent the spread of nuclear weapons, and that means preventing Iran from going nuclear, because if Iran goes nuclear are other nations in the Middle East going nuclear and we’re off to the races, then with a combination of nuclear weapons and possible terrorist and jihadist connections, it’s unbelievably dangerous, so I would say… Bush I think has done a pretty good job of beginning with that, I might’ve done a few things more hawkish than Bush actually, in terms of confronting Iran but, you know, he’s got the Europeans together for the first time with serious sanctions through the UN Security Council, the united front he’s handing Obama, to put as much pressure as possible on Iran, if he can turn around the negative momentum on nuclear proliferation and on Islamic jihadism, we will have a much safer world, if we can turn it around over the next 20 years, if all of us can turn it around around the world— if not we’re in a lotta trouble.

### Moderator
Claim: I’m gonna turn one more time and, I wanna hear the question before we go to the panel, I’m really looking for something that talks about the legacy that President-Elect Obama inherits… We’ve had a question from you… Yes.

### Moderator
Claim: I for one am proud of the job President Bush has done to keep us safe, and, in turn the world. With that said, Mr. Jenkins and Mr. Weisberg, you speak in theories, what would you suggest that Barack Obama now do with Islamo-fascism, its threat to the world, and how is that different from the current policies that the Bush administration is employing.

### Moderator
Claim: Jacob.

### Conspiracy Advocate (CA)
Claim: I think Obama should focus as he’s appropriately doing on Afghanistan and how to turn around a deteriorating situation there. I think he should figure out, how to get us out of Iraq without Iraq falling back into the situation it was in before the surge. I think those are com—things that are compatible, I think they’re possible. And, you know, much of this is so invisible to us that it’s very hard when we say Bush has kept us safe. It’s true, we have not had another terrorist attack in the United States. How much of that is the result of policy, how much is the result of accident. We don’t know that much about it, it’s the dog that didn’t bark. Would another President have handled it differently, I don’t think so. I think that it’s—it’s impossible to say.

### Moderator
Claim: Simon Jenkins.

### Conspiracy Advocate (CA)
Claim: I imagine the reason why there’ve been no more attacks in America or in Britain or in most of Europe, is because of good policing on the ground, not because you’ve been at war in the Middle East. I believe in good policing, I think the Kyoto terrorism, whatever that precisely may mean, people blowing people up, is essentially front-line policing. Good intelligence, good espionage, good work on the ground. It’s not by going to war against other states. But the phrase Islamo-fascism, so easily bandied about from this side of the Atlantic, and I may say from Europe, when you travel in these countries the relentlessness of the assumption that every Arab, every Muslim is a crypto-Islamo-fascist. And the evidence you give of it, by going in and invading some of their countries, is the surest possible way to turn them into hostile— I cannot emphasize enough—

### Moderator
Claim: As a follow-up to that—

### Conspiracy Advocate (CA)
Claim: —these are normal people, by and large. They’re people quite like you. They don’t think, most of them, that they have a right to come and invade your country, close down Guantanamo Bay, do all the things they think you’re doing wrong. There is now an assumption on the part of both your country and my country under Tony Blair, that we have in some sense a right to go and sort out their countries, because they’re not like our countries. This must be one of the great fallacies of the modern age. I hope Obama overcomes it.

### Moderator
Claim: Sir, did—did you get your answer?

### Moderator
Claim: Yes, I did. I didn’t ascribe the term Islamo—

### Moderator
Claim: I’m sorry, I—

### Moderator
Claim: —fascism to every—

### Moderator
Claim: Can you start—can you begin again, please.

### Moderator
Claim: I didn’t ascribe the term Islamo-fascism to everyone who’s a Muslim, or in that part of the world. I’m speaking about a specific group of people, who have no intent but to do all Westerners harm. You’ve taken it beyond that which is a great…liberal-elitist move to include everybody, but… To the answer to my question, how does Barack Obama, tackle it, what does he do different from the current policies to be effective.

### Conspiracy Advocate (CA)
Claim: Well, I think that, good relations with a country, are more likely to get that country to suppress those elements within the country that are inclined to terrorism than bad relations with the country, that has to be true.

### Scientific Advocate (SA)
Claim: I myself, I myself tend—I’m sorry, do you—

### Moderator
Claim: Bill Kristol.

### Scientific Advocate (SA)
Claim: No, I mean I myself tend…not to use the word Islamo-fascism, I just think it’s a little, analytically confusing, I’m not sure fascism is the best way to describe them but, the Islamo-fascists if you wanna use that term, the Takfiris, the terror— Islamic terrorists have killed more Muslims than anyone—than they’ve killed Westerners. And if you talk to Muslims they want those people, to many Muslims including many in Iraq, the greatest single vic— what country has been the greatest victim of the terrorists of al- Qaeda? Iraqis, Iraqi Muslims. And they are grateful now that they are going to be able to vote in 2009 in regional elections and in national elections and have a shot at not having a horrible dictator who himself murdered hundreds of thousands of people, who are not being dominated by ghastly Islamo-fascists if you wanna use the word, but I do think, I sort of agree with the question in that sense— Precisely using the term Islamo-fascist separates, the reason you use the term is precisely to say that’s not all of Islam, that’s a little part of it which unfortunately has been ascendant, and if not resisted, will become more ascendant, and we need to help people resist it, we can’t stand back and say hey, none of our business, Afghanistan, Taliban takes over, so tough on you, you know, and Saddam, tough on you guys, and I guess in the Sudan, it’s tough, and other places it’s tough and the Iranian civil society gets suppressed, and I guess we just can’t say anything. And we just say hey, that’s the way they wanna live in that part of the world, I mean that is really what the counsel I think of these sort of realists who want us to think they are going to improve America’s standing in the world and in fact, will correctly call down condemnation on America as has happened in the past. Incidentally, one of the things that encouraged radicalism in the Middle East, was the sense that we were standing aside, and supporting dictators out of narrow self- interest. The single greatest harm we did to ourselves was stepping back in ’91, we went in to kick Saddam out of Kuwait which was correct, we needed to do so for strategic reasons, and then we abandoned the people of Iraq, when Saddam turned on them, I don’t think that’s something to be proud of and I very much hope actually that Barack Obama does not revert to that kind of foreign policy.

### Scientific Advocate (SA)
Claim: I’d like to quickly— I’d like to quickly return to a question about why was America kept safe for seven years. We’re given two answers, one was luck and the other was that any other President would’ve handled it the same way. Now luck does come into play. But luck works when you have the kinda attitude that this President has which is he’s gonna stay on the offense so we fight ‘em over there, and we’re gonna use every intelligence tool at our disposal, to find out what they’re up to. That is why we broke some of the plots that you know about publicly. You don’t know about all the plots but you know about the attempt to bring down Liberty Tower in Los Angeles, or to blow up airliners simultaneously over the Pacific Ocean. We’re able to break up those plots because this President adopted programs—now maybe, Jacob is right that any other President would’ve pursued the terrorist surveillance program, and the widespread use of our intelligence assets abroad, to listen in on the enemy. I hope he’s right.

### Conspiracy Advocate (CA)
Claim: What do you mean, Karl, by fight them over there, they weren’t in Iraq. Unless you meant somewhere else by over there.

### Scientific Advocate (SA)
Claim: Well first of all, again I repeat, I appreciate you support for the war in Iraq at the time.

### Conspiracy Advocate (CA)
Claim: Well, I wasn’t—

### Scientific Advocate (SA)
Claim: But Jacob, but let’s be honest, he was supporting terrorists, this is a man who, who gave payments to terror bombers. This is a guy who allowed terrorist camps to organize in his country. The ricin attack in London was launched from a camp in northeast Iraq, this is not a nation which you can organize a terrorist camp without the central authorities knowing about it—

### Conspiracy Advocate (CA)
Claim: Hang on—

### Scientific Advocate (SA)
Claim: —in the aftermath—pardon me, let me finish.

### Conspiracy Advocate (CA)
Claim: Okay.

### Scientific Advocate (SA)
Claim: In the aftermath of Afghanistan and taking down the Taliban, where did Zarqawi go for medical treatment. He checked himself into the Mayo Clinic of Baghdad. You don’t get that unless somebody in the government up top allows a known terrorist to seek, to seek succor and medical care in Baghdad, this was a bad actor. Now, did we think he had weapons of mass destruction, you bet, and I’ve got a sheaf-load of quotes from people that you love, like Ted Kennedy and others saying he did. He didn’t. We now know that. We went in on intelligence that was flawed, but I would remind you of this. Intelligence gets it wrong both ways. In the run-up to Iraq Muammar Qaddafi looked around and said you know the United States is serious about it, Britain is serious about this, I got problems. If they’re willing to take out 25 million people and take on Iraq with 25 million people they’re willing to take me on. And he coughed up his weapons programs. And Western intelligence found out they were wrong, they systematically underestimated how far along his chemical and biological programs were which were weaponized, and how far along his nuclear program which—which was way beyond what anybody in Western intelligence thought he had.

### Conspiracy Advocate (CA)
Claim: What was this ricin attack in Britain.

### Moderator
Claim: Jacob, Simon, the rest of the panel, I wanna— If you wanna respond to Karl’s point, save it for your summary two minutes—

### Conspiracy Advocate (CA)
Claim: Milk powder, milk powder.

## Round 3

### Moderator
Claim: Simon— Thanks. We’re out of time on the questions and answers but you have two minutes to sum up, and you can respond to the point there, I just wanna thank all of you, and encourage you to give yourselves a round of applause for terrific questions. So, I wanna remind you where we are in this Intelligence Squared US debate. We’ve already polled you when you came in before the debate began to see where you agree on the motion. The motion before us is, “George W. Bush is the worst President of the last 50 years.” “Bush 43 is the worst President of the last 50 years,” before the debate, 65 percent of you agreed with the motion, 17 percent were against, 18 percent, one in five of you roughly, were undecided, and we’re going to poll you again shortly but now we move on to the final session of the debate in which each of the panelists has two minutes to summarize. I will step in at the two-minute mark just to tell you that your time is up, and we are going to begin the summary against the motion, that George W. Bush is the worst President of the last 50 years, Bill Kristol, the editor of The Weekly Standard.

### Scientific Advocate (SA)
Claim: As someone who grew up not far from here it’s embarrassing frankly that 83 percent of the people who voted think either that Bush is the worst President in 50 years or are undecided about it. Look, people don’t have to like Bush, half the country voted against him in 2000 and—well, virtually almost half in 2004, if you’re a liberal you won’t approve of his domestic policies, if you think that we’d be better off not having gone into Iraq which obviously is a debatable proposition, you could be very condemnatory of going into Iraq and certainly many people have criticized the way in which we managed that war from 2004 to 2006. There’s no reason not to be critical of Bush, not to disagree with Bush, not to prefer Obama, not to have voted for Gore and Kerry, most people in New York obviously, have all those views. But to think that he’s the worst President in 50 years is just silly. It’s just silly and it came out very well in the Vietnam discussion, I mean are we being serious here? Vietnam was well-run and that was okay somehow and, you know, Westmoreland knew what he was doing. Of course we lost 55,000 people, we lost a war, 2 million people plus died in Vietnam and Cambodia, it was an unbelievable catastrophe, which the region took a long time to recover from, it was a terrible humiliation moral and political for the United States. That’s like Iraq? Where we’ve lost 4,000 soldiers, where Iraq is now back on its feet, where we’ve won the war, where we’ve won the war and established US credibility and a willingness to stick to it even though we’ve made terrible mistakes and where we’re actually in pretty good shape with most of the governments in the region, I myself being more of a democracy and human rights activist am a little unhappy that we’re so friendly—

### Moderator
Claim: Bill, conclude—

### Scientific Advocate (SA)
Claim: —with the governments—

### Moderator
Claim: —your time is up, 15 seconds grace.

### Scientific Advocate (SA)
Claim: With the governments in the region. But we are so if we’re in the real world, in the real world you can dislike George W. Bush but you should be against this motion.

### Moderator
Claim: Summing up for the motion that George W. Bush is the worst American President in the last 50 years, Jacob Weisberg, author of The Bush Tragedy and editor-in-chief of the Slate Group. Jacob Weisberg.

### Conspiracy Advocate (CA)
Claim: Thank you. “We’ve won the war in Iraq,” there’s something about this “mission accomplished” language that always makes me a little nervous. I think the damage in Iraq can be mitigated, but it can’t— the war can’t be vindicated as a decision. And this goes to the heart of our disagreement, Bill said at the beginning that Bush had bad choices, I don’t think he had bad choices, I think he made bad choices. And I think things could’ve been different for Bush. I think he could’ve taken a different approach, and in fact it was the approach he took when he was governor of Texas. He could’ve united the country and the world after September 11th, it would’ve given him an opportunity to be a great President, he could’ve reached out to the other party the way FDR did after Pearl Harbor. He could’ve kept his focus on America’s real enemies, as opposed to becoming distracted by Saddam Hussein. He could’ve compromised with Democrats on a whole range of issues including climate change, expanding health care coverage, entitlement reform. He could’ve focused on protecting the free market instead of the interests of big business. And I think if Bush had tried to govern from the center right, instead of from the far right, he would’ve been reelected by a bigger margin in 2004 and he would’ve been a successful President. But Bush was never up to the job of being President, and it’s not a matter of lacking in intelligence, it’s a matter of lacking character. Bush wasn’t interested enough in policy, he couldn’t tolerate challenge or dissent or disagreement, he couldn’t open his mind long enough to consider alternatives or admit the possibility that he might sometimes be wrong. He let his righteousness and his arrogance and his anger get the better of him. And in the end I think what’s so damning about Bush and what does make him the worst President of the last 50 years, is that these were things within his control. And to finish, I think we can say at this point that, American’s great nepotistic experiment is finally coming to an end. It’s— And as my colleague Simon Jenkins has said, it’s finishing not just with failure, not just with rejection, but in global disgrace.

### Moderator
Claim: Thank you, Jacob Weisberg. Making his summary statement against the motion that George W. Bush is the worst American President of the last 50 years, Karl Rove, former deputy chief of staff and senior advisor to George W. Bush.

### Scientific Advocate (SA)
Claim: John, you said that with a particular glee, I mean it’s,… Look…I wanna end with, by accentuating the point that Bill made, but first of all I need to say Jacob’s comments can be read in his book, which is a piece of fiction. To believe that George W. Bush didn’t tolerate strong people in his cabinet or dissent, or disagreements, is ridiculous. And to suggest that he’s not interested in ideas is that peculiar form of Bush hatred that causes people to lose their rational senses about the man. And this President has been— This President has been on the receiving end of this kinda attitude since the moment that he took office in an election, that many on the left thought made him an illegitimate President. Now, here’s a man who one of his—the first person that he met with from the United States Congress was the Democrat, ranking Democrat on the House Education and Labor Committee, George Miller. Didn’t compromise with Democrats, didn’t compromise with Democrats on No Child Left Behind which he worked with Ted Kennedy and George Miller and John Boehner and Judd Gregg to get passed. Didn’t cooperate and compromise with Democrats when we came out and endorsed wholesale large elements of the Joe Lieberman program for homeland security. Didn’t compromise with Democrats when we came out for immigration reform? You know, that’s just ridiculous. But I wanna end, ‘cause most of the circle’s around Iraq. Vietnam I agree, better prosecuted than Iraq? We ended Vietnam in defeat, for which the families of 55,000 fallen heroes, had reason to ask themselves, whether or not that sacrifice had been made in vain. And we’re coming out of Iraq with Iraq becoming a functioning democracy in the heart of the Middle East, still fragile, but because of the surge, and a place today where we can see the moment that US troops can come home with their honor and in victory. And for which the sacrifices of those who have died, will not have been in vain.

### Moderator
Claim: Karl Rove, time up, take fifteen seconds, if you need it. You're good? Karl Rove.

Summing up, finally, for the motion that “George W. Bush is the Worst President of the Last Fifty Years,” Simon Jenkins, journalist and columnist for The Guardian. Simon Jenkins.

### Conspiracy Advocate (CA)
Claim: Well, I repeat my view at the very beginning. I'm not here to be rude about an American President. I would just point out about Iraq, you cannot say something’s a success when I saw last week two million Iraqi’s are camped outside Damascus because they haven't got the nerve to go home to their homeland because the Americans are there. Two thirds of all the Christians in Iraq have been driven out of that country under America’s aegis. Fundamentalism is far more rife in southern Iraq than it ever was under Saddam Hussein. Let’s just get some facts here. However, let me come back to the original point, I had great respect for Bush when he came to power. I liked his courtesy, I liked his moderation, and I liked his concept of humility in America’s power projection. I think, tragically, after 9/11 he allowed the politics of fear to get the better of him, he persuaded my Prime Minister, Tony Blair, to let the politics of fear aid his re-election campaign as well. The politics of fear is the most corrosive of all forms of politics in a democracy. Power, and America remains… …remains a hugely powerful country, power has an obligation of restraint. If you're the most powerful country in the world, your obligation is not to go over the top, to charge around the world invading countries on the feeblest of pretexts, your obligation is to show restraint. My America was always a country of huge self confidence, belief in its ability to resist attack of any sort, and not needing to erode its own freedoms and those of other people in order to achieve that defense of democracy. I personally think that you’ve just elected a man who I have found, from when I first read his book, a truly remarkable figure, on whom I think it is right to place great expectations. And, but, he has got to recover from a terrible legacy in the world, outside America. I still believe he will. I think you have a terrific future ahead of you, but you have been through an awful eight years. Thank you very much.

### Moderator
Claim: Thank you, Simon Jenkins. And may I invite a round of applause for our entire panel.

I'm asking them to sit back down for the moment of truth. Gentleman, have your seats once more, because we have to decide the winner. Let’s remember where we are. We have heard the debates, we have heard the arguments, and we have heard from you when you came into this debate, that sixty-five percent of you were for the motion, that “George W. Bush is the Worst American President of the Last Fifty Years,” “Bush 43 is the Worst President of the Last Fifty Years.” It is now time for you, seventeen percent of you were against, and eighteen percent, one in five, were undecided. It is now time for you to reach for those keypads and register your decision at this point. While you're doing that, I will… Does anybody need more time? Is everybody locked in? OK. Sorry? Oh, I'm sorry, some of you weren't here in the beginning, which really is going to mess up the numbers, isn't it? You press one if you are for the motion, two if you are against the motion, and three if you remain undecided. The other keys don’t matter. If you make a mistake, just re-enter your number, and your last number will be recorded by the computer. Everyone is clear on that? And does anyone need more time? Just shout out. OK, so the numbers are being tabulated, it will take about ninety seconds. And while we’re waiting for the vote I would like to remind you that our next debate will be here again at the Symphony Space, and it will be recorded once again for broadcast on BBC World News Television. The motion to be debated on Tuesday, January 13th, 2009, is this: “Major Reductions in Carbon Emissions are not Worth the Money.” Panelists for the motion are Peter Huber, Bjorn Lomborg, and Philip Stott. Against the motion, Daniel Kammen, Oliver Tickell, and Adam Werbach. And we will see you all back here in January at Symphony Space. And just in time, thank you, the results come. Well, we tend to judge who is the winner by who moved most positions, and in that case, I’ll give you the numbers in a second, but the bottom line is that those against the motion changed more minds tonight than those for the motion. Before the debate sixty-five percent were for the motion, seventeen percent against, and eighteen percent undecided. After the debate, sixty-eight percent were for the motion, twenty-seven percent are against the motion, and five percent remain undecided. Congratulations to all of our panelists, congratulations to you, and thank you for joining us at this Intelligence Squared US Debate.
