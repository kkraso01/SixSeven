# Debate Transcript

Topic: Afghanistan Is A Lost Cause
Motion: Afghanistan Is A Lost Cause

Debate ID: afghanistan-lost-cause


## Round 1

### Moderator
Claim: Critics of the War argue that prevailing in Afghanistan cannot be done. And even if it could be done, it shouldn’t be done. It cannot be done, because the Karzai government is hopelessly corrupt, inept and unpopular. Because Afghanistan is a tribal culture that has never accepted strong centralized authority. Because after 9 years of combat there has been essentially zero progress in handing responsibility for security to the Afghanis.

And it shouldn’t be done because we have falsely conflated the Taliban with Al Qaeda. The Taliban is local: it wants to impose its extreme version of Islam on the territory it is fighting to control in Afghanistan. In contrast, Al Qaeda is global. It is largely based in Pakistan, with outposts in Yemen and Somalia and is specifically organized to project terror globally and is a clear threat to US national interests. Prevailing in Afghanistan will not diminish Al Qaeda.

The counter argument is that it should be done because the Taliban and Al Qaeda are ideological soul mates. The Taliban sponsored Al Qaeda before and will do it again. The success of their insurgency will be a humanitarian disaster, a stinging defeat for the US and our allies, and will provide no end of encouragement to our enemies. And it can be done because our efforts in Afghanistan to defeat that insurgency are now headed by General Petraeus. He accomplished a much harder mission in Iraq where he literally wrote the book on counter insurgency operations.

He is among the most creative and thoughtful military leaders we have, or have ever had. We are succeeding in making life miserable indeed for the Taliban, thus setting up the conditions for a negotiated settlement. We have been at this, with full troop deployment and under Petraeus’ leadership for a few months. We can hardly declare victory, but it is way too early to declare defeat.

Which is the better argument? Tonight’s expert panelists will be trying to persuade you to vote their way; and it is now my privilege to hand the evening over to our moderator, John Donvan.

### Moderator
Claim: Thank you. And may I invite one more round of applause for Robert Rosencranz, please. or false: Afghanistan is a lost cause. That's what we are here to debate. Welcome, everyone. I'm John Donvan of ABC News. And on behalf of Intelligence Squared U.S, welcome to the Skirball Center for the Performing Arts at New York University and on NPR stations across the nation. As we argue this motion, Afghanistan is a lost cause. We have two teams of debaters, two against two. They include a journalist who has spent time among the Taliban and come back to tell the tale, a State Department official who walked away from his job in Afghanistan in frustration, a journalist who sat down and talked with Osama Bin Laden in the '90s, a good indicator of what was coming, and a military historian.

Now, this is a debate. It's a contest of idea, a verbal joust. And in this debate, you, our audience, serve as the judges. We would like you now to go to the key pads on your seats and register your opinion on this motion as you come in before hearing these arguments.

The motion again, Afghanistan is a lost cause. If you agree with this motion, press number one. If you disagree, press number two. And if you are undecided, press number three. If you feel that you have pressed a key in error, just correct it, and the system will lock in your last answer. All right. I'm assuming everybody's locked in. So let's move forward. By the time this debate has ended, you will have been asked to vote twice, once before and once again at the end of the debate. And the team that has changed the most minds will be declared our winner. So onto round one, opening statements by each side in turn. They will be seven minutes each.

And I'd like to begin by introducing our first speaker for the motion, Matthew Hoh. Matthew Hoh, in addition to serving in Iraq as a marine captain, went on to serve in Afghanistan for the State Department. He resigned his position there in 2009, writing a letter to his superiors in which he said, "I have lost understanding of and confidence in the strategic purposes of the U.S. presence in Afghanistan." When he turned his back, great efforts were made by members of the Obama administration to get you to stay, Matthew. You didn't. And I want to know, have you ever had any second thoughts about that decision.

### Conspiracy Advocate (CA)
Claim: You know, John, I do. At times, I do. I just had lunch the other day with a friend of mine who is back on R & R from State doing a job like I used to do in Eastern Afghanistan. And you do have pangs of guilt, but they're pangs, and they go away when you realize that there's a larger issue here in terms of what's of benefit to U.S. national interest.

### Moderator
Claim: Which is what you’re about to argue. Ladies and gentlemen, Mr. Matthew Hoh.

### Conspiracy Advocate (CA)
Claim: Thank you. It's an honor to be here tonight, particularly on this stage with Peter and Max, who are all acknowledged experts in this field. Also a little daunting. I've done a lot of panels. I've never done a debate with clocks and buzzers and voting. So cut me some slack. I'm also local. I'm from Jersey, if that helps in the voting process as well. But I just want to say also, too, if there're any Marines in the room, happy birthday Marines. Today is the 235th birthday of the Marine Corps. And it's appropriate to be having this discussion tonight because, you know, so far this year in Afghanistan, or so far this month in Afghanistan, the first ten days in November, we've seen 16 service members killed, many of them marines.

So it's important for us to have a discussion on a day like this because it's those service members and their families who are bearing the direct costs of this conflict. You're going to hear tonight a lot of nuanced and complex arguments between us. And that's about right because the United States is entangled in a very complicated situation. To use the term civil war is not incorrect. You're going to hear us disagree on the relationship between the Taliban and al-Qaeda. I found, in my experience, in both eastern and southern Afghanistan, that the vast, vast majority of the Taliban that are fighting our troops every day are not wedded to an ideology that al-Qaeda embraces, that they are fighting occupation, and they are not fighting for some type of transnational jihad.

You will see us disagree over the similarities between the Iraq and Afghan surge. Again, I was in both. I was fully invested in the Iraq surge in 2006 in Anbar province, I was one of the first civilian surge members last year into Afghanistan. And there are similarities between the Iraq surge and the Afghan surge. But those similarities are more in terms of how the US is doing policy and how we didn't do things right to begin with in Iraq and now all those policies we're doing wrong in Afghanistan. And I look forward to a discussion. I know Nir's got a lot of comments on this, and I look forward to having this talk with Peter and Max. You're also going to hear a lot of facts, figures and statistics tonight. And I want you to keep in mind the big picture. I want you to ask, so what?

After every fact or figure or statistic you hear. Hopefully when Peter and Max say it and not when Nir and I say it, because it's just a case of don't lose sight or track of the forest because of the trees. And so keep in mind, bear in mind some basic aspects of the war in Afghanistan. The cost. Last year we spent-- the United States spent $104 billion in Afghanistan. This year, we are projected to spend $119 billion in Afghanistan. Afghanistan's GDP is $14 billion. We are spending seven times as much in that country as it's worth. As the Dutch, the Canadian, probably the French and Italians move out of Afghanistan, of course, our costs will go up. And so when you hear the administration say, we're looking at keeping this policy in place till 2014, that's a half trillion price tag plus about 2400 dead American and coalition soldiers as well as thousands more Afghans at this pace.

Keep in mind that since 2005, we have seen a fivefold increase in U.S. and NATO troops in Afghanistan. Literally every year since 2005, we have doubled the foreign troop presence in Afghanistan. And what's occurred from that is that only every year a commensurate rise in violence, a commensurate rise in support for the Taliban and a decrease in support for the Karzai government. You see this with a number of Taliban. In 2005, we estimated there are 2000 active duty fighters in Afghanistan. Now we're estimating there are 35 to 40,000 active duty Taliban fighters in Afghanistan. So not only is the policy expensive, failing, it's also counterproductive because it's causing people to join the insurgency.

It's exasperating the conflict, and it's making the region less stable. And that includes Pakistan. Additionally, keep in mind the nature of al-Qaeda. Keep in mind it is only 50 to a hundred members of al-Qaeda in Afghanistan, according to our CIA. And contrast that with the 1,000-- the 2,000 members of al-Qaeda that our State Department said are still in Iraq in their report last August on terrorism. Contrast that with the fact that the German police say there are 45 members of al-Qaeda in Hamburg, Germany. Hamburg being the place that probably had as much to do with the planning, if not more, for the 9/11 attacks than Afghanistan. And before I forget to put a plug in for a great article on the nature of al-Qaeda on Khalid Sheikh Mohammed and on 9/11, please read the “New Yorker” article from September by Terry McDermott. Really shows how al-Qaeda is this grouping of individuals.

It's a collection of individuals. It's not a formal military organization that we can defeat with conventional forces. And think about it. Look back at the last 10 years of their attacks. Their most recent attack, a lady who took two parcel bombs and FedExed them from Yemen. Look at the attacks of the last three years in this country in the sense that they're done by individuals, small cells, it's a decentralized organization that will not be affected by the presence of brigade combat teams occupying Southern Afghanistan. So nine years ago 19 men hijacked four airplanes. We're now in Afghanistan 109 months later with 100,000 troops spending over $100 billion a year. Nir and I are not advocating for us to cut and run or abandon Afghanistan but we are advocating for a policy that is not destabilizing, not counterproductive, and not effective against Afghanistan.

We're arguing for something that will-- or against al-Qaeda, we're actually arguing for something that will affect al-Qaeda and stabilize the region. Thank you.

### Moderator
Claim: Thank you, Matthew Hoh. Our motion is "Afghanistan is a lost cause." And now to speak first against the motion, Max Boot, who is a military historian. He's on the Council of Foreign Relations. Interesting to me since I actually covered Afghanistan when the Soviets were occupying, I found it interesting that you were born in Moscow before your parents flew out to L.A. But the Soviet invasion and occupation, was that always a lost cause?

### Scientific Advocate (SA)
Claim: It was really night and day, John. I mean, I've actually been reading about the Soviet War in the 1980s for a book that I'm now writing on the history of guerilla warfare, and it is so totally different from what we're doing, I mean, the Soviets really fought in the scorched earth manner, they killed over a million Afghans, they turned over five million into refugees, they destroyed the countryside, they threw landmines around indiscriminately--

### Moderator
Claim: Different story this time.

### Scientific Advocate (SA)
Claim: --completely different from what-- the kind of tactics that we're employing today.

### Moderator
Claim: Different story this time, and let's hear it. Ladies and gentlemen, Max Boot.

### Scientific Advocate (SA)
Claim: Thank you very much, John. It's a pleasure to be here. And I'd like to extend my sympathies to our distinguished opponents on the other side. I know they will make a valiant attempt as you've already heard Matt do, but I'm very sorry to say they have an impossible burden of proof today. They have to convince you that it's impossible for America and our allies to prevail in Afghanistan, that there is no way we can achieve our objective, which isn't to create paradise on earth, but merely an Afghanistan that is free of terrorist safe havens and that can secure and govern itself. For our part, we don't have to convince you that success is assured; only that it's possible. For anyone familiar with military history, that ought to be a no-brainer.

Numerous countries have won wars after overcoming obstacles far more severe than those we face today. Think of Britain standing alone against the Nazis in 1940. Think of U.S. forces almost being pushed off the Green Peninsula in the summer of 1950, or more recently, think of Iraq in 2006. Now, you will hear, as you've already heard from Matt, our opponents say that Afghanistan isn't Iraq. And they're right. Iraq was much worse. In 2006 Iraq was in the throes of a full-blown civil war. That year 34,000 civilians died, Shi’a and Sunni terrorists had high levels of support in their sectarian communities, Prime Minister Maliki’s government was implicated in death squad activity, and back home the Democrats won majorities in Congress on an antiwar platform. Even many supporters of the war effort thought we were on the brink of defeat. For example, on August 9th of 2006, I wrote in the L.A. Times, "Bush needs to do something radical to shake up a deteriorating status quo if we are to have any hope of averting the worst American military defeat since Vietnam.”Luckily President Bush did do something radical. He ordered a surge which turned around a war effort which many had written off as hopeless. Today another surge is just starting, and it actually has better prospects of success because the situation in Afghanistan is objectively much better than it was in Iraq. Yes, civilian casualties are up, but they're still 1/16th as high as they were in Iraq. Yes, violence has spread, but 63 percent of attacks still happen in just three provinces. Yes, there is the stress among ethnic groups. We are not facing a civil war. This is an intra-Pashtun conflict. Yes, Hamid Karzai is a problematic leader, but at least he is not running death squads and he has cooperated on important initiatives such as the village security program. And, yes, public opinion has turned against the war, but President Obama will receive a lot more support from Republicans than President Bush received from Democrats. I am also relatively optimistic about Afghanistan because the armed forces have gotten much better at counterinsurgency.

The COIN strategy that General Petraeus is implementing today draws not only on the war in Iraq, but also in conflicts as diverse as Columbia, El Salvador, Malaya, and the Philippines. He is not only focusing on kinetic operations, killing the enemy, but also on improving governance, intelligence collection, the handling of detainees, information operations and much more. It’s a huge difference from the sleepy days of 2008 when there were only 32,000 U.S. troops in the country and they were stuck in a holding pattern. Now we have a hundred thousands troops there. The last of the surge forces only arrived in September but already they’re making a difference. This summer I visited Nawa in Helmand province. Before the Marines got there in 2009, it was a virtual ghost town dominated by the Taliban. Today, it’s safe enough to walk around without body armor. Stores and schools have reopened, electrical lines are going up. Agricultural canals are being cleared. This is tangible progress.

Similar operations are now in full-swing around Kandahar, the heartland of the Taliban. The New York Times, hardly a pro-war organ, reported on October 20, “American and Afghan forces have been routing the Taliban in much of Kandahar Province in recent weeks forcing many hardened fighters to flee strongholds they have held for years.” We are also seeing stepped-up operations to capture or kill Taliban and Haqqani leaders. In the past 90 days, Special Operations forces have carried out more than 1,500 operations resulting in the death or capture of almost 3,800 insurgents. Air strikes have more than doubled over the past year and yet according to the U.N., civilian deaths from NATO bombings were down 64 percent in the first half of the year. That’s a tribute to the very careful rules of engagement promulgated by General McChrystal and General Petraeus something that distinguishes us greatly from the way the Red Army or others have fought in Afghanistan. To win over the population, coalition forces are also working to improve governance and cut corruption.

A lot of the corruption in Afghanistan has been fueled by our own money. In the years when we have few troops there, we contracted out security to warlords who abused the people and drove them into the arms of the Taliban. Now that is changing. We are less reliant on warlords and General Petraeus is striving to ensure that our spending doesn’t fuel corruption. A lot of the focus today is on avoiding bottlenecks in Kabul by working in the provinces where the troops are assisted by a civilian surge with the number of civilian U.S. government employees there having gone up three times in the past year, three fold. Perhaps the most important line of operations is the training of Afghan security forces, the ANSF. That’s our ticket out of Afghanistan. As they stand up, we can draw down responsibly as we’ve done in Iraq. We don’t need to stay until Afghanistan is as peaceful as Switzerland, only until it can be secured by its own troops. And how is the ANSF training going? Well let me quote you again from The New York Times on October 12.

Which said that “Long a lagging priority, the plan to produce many more trained Afghan troops is moving this fall at a rapid pace. ANSF numbers have jumped from 137,000 in 2008 to 258,000 today and their quality is higher because of smaller class sizes and more intensive mentoring. Salaries are up, desertion rates are down.” Now I don’t want to over-estimate the progress that has occurred or under-estimate the problems that remain. There is no doubt that we face a long, hard fight. But the biggest thing we have on our side is public opinion. My colleague Peter Bergen will tell you more about this. But the fact is the Afghans have experienced Taliban rule and they didn’t like it. Fewer than 10 percent say they want a return to the Taliban. More than 60 percent support the NATO troop presence. Again, John, this is not the Soviet invasion of Afghanistan. We have the people on our side. Is Afghanistan a lost cause?

President Obama doesn’t think so. Otherwise he wouldn’t have sent more than 50,000 additional troops there. General Petraeus doesn’t think so. Otherwise he wouldn’t have accepted a command that could tarnish his sterling legacy. We don’t think so either. I look forward to hearing from our opponents to see how they can possibly prove otherwise. Thank you.

### Moderator
Claim: Thank you. Next please. This is a debate from Intelligence Squared U.S. I’m Jon Donvan of ABC News. We have two teams of two each arguing it out over this motion: “Afghanistan is a lost cause.” We have heard opening statements from the first two debaters and now on to the third. Nir Rosen is a journalist who risked an awful lot by crossing over for several weeks or months to report on the Taliban side of things and he survived and came back to tell the tale in a new book he’s just come out with called “Aftermath.” Nir, I read in the book that before you went, you memorized some phrases in Pashto to get around.

What was the single most important phrase that you learned and took with you?

### Conspiracy Advocate (CA)
Claim: Manoo whizhna means don’t kill me.

### Moderator
Claim: Don’t kill me. And apparently they listened. Ladies and gentlemen, Nir Rosen.

### Conspiracy Advocate (CA)
Claim: Max said that our goal in Afghanistan is to make sure it’s a terrorist safe haven-free country. In a sense, we did that. In 2001 and 2002, we got rid of al-Qaeda in Afghanistan. So I'm not sure why we're still there. He also said that Iraq was worse than Afghanistan during the civil war. That's true. And Iraq is still worse than Afghanistan today. So where is our success in Iraq? You have more civilians being killed in Iraq today than you do in Afghanistan today. This is after the surge. Now, people like to forget about Iraq, and the media has certainly forgotten about it. But I think we can't understand what's happening in Afghanistan and what the Americans think they're doing in Afghanistan without understanding what really happened in Iraq. The surge is this narrative that things were going badly.

You have the 2006 Samarra shrine incident where the shrine was blown up, the civil war broke out. And then this genius general called David Petraeus came up with a new way of fighting a war, and that solved the problem. None of that is really true. Robert also mentioned that Petraeus wrote the counterinsurgency manual. That's not really true, either. He signed his name at the bottom of it, but he actually had hundreds of other people involved in the process and probably corrected a few spelling mistakes. But you have all kind of academics and officers involved in that process.

Now, the civil war in Iraq, the people that won the civil war weren't the American forces. It was Black and Decker. What do I mean by that, whenever you find a corpse in Iraq that was beheaded, you knew it was killed by a Sunni militiaman. If you find the corpse with Black and Decker power drill marks in it, Shia militiamen killed it. And what defeated the Sunni insurgency in Iraq was not the American surge. It was Shia militiamen in collaboration with the Iraqi police and the Iraqi army who brutally crushed the Sunni population,Not just with power drills, but also with executions and rape with full knowledge of the Americans.

There was a Shia colonel in west Baghdad called Sabah an army criminal who used to kidnap men, Sunni men, and then force their wives to have sex with them in order to release these men. Beginning in 2006, this was about six months before Petraeus came into Iraq, I began to meet Iraqi resistance leaders in Baghdad, in Syria, in Jordan. And suddenly, they were saying, “We lost, we lost.” And why did they lose? Because the Shia had depopulated Sunni areas brutally, a sort of brutality that the Americans could never use. So we were killing innocent civilians but not in these rates.

At the same time, you had a total separation of Sunni and Shia civilians thanks to the civil war. One side won the civil war, the Shias, one side lost, the Sunnis. And Sunni neighborhoods in Baghdad became, very often, virtual ghost towns. This is all six months before the surge started. And I was just in Iraq about a month ago.

I was at Diyala province, where in July 2007, seven months after the surge began, hundreds of villages were destroyed. Al-Qaeda guys would come in there and total the village, blow up all the houses, slaughter the men, likewise Shia militiamen were doing the same thing to Sunni villages.

Seven months after the surge, violence was still peaking. What changed, apart from the Sunni realization that they lost was the Shia cease fire. The Shia militiamen, the Mahdi army declared a ceasefire, and violence dropped significantly after that. At the same time, you had a government that actually had some legitimacy because they would, a year later, go after the Shia militiamen, totally destroying them as well.

Now, none of the factors that helped reduce violence in Iraq to the terrible levels where they are today, still worse than Afghanistan, none of these factors even exist in Afghanistan. First of all, the Sunnis in Iraq who dominated the insurgency, were 20 percent of the population. And they were destroyed and brutalized and turned into refugees in Syria and Jordan and elsewhere. The insurgency is Afghanistan is dominated by Pashtuns, 38 to 40 percent of the population, the largest group in Afghanistan.

And they are not being brutalized. The Taliban is not a Pashtun movement, but it's dominated by Pashtuns. And they feel like they're on the rise. They have the momentum. They are spreading not only in Pashtun areas, but even in the north, among non-Pastuns, among Tajiks and Turkmen and Uzbeks, they’re reactivating old networks from the Taliban era. They feel like they’re doing quite well. Likewise, Baghdad was the prize in the civil war in Iraq. It was the dense, urban areas. The Americans could take each neighborhood in Baghdad and build immense walls around them, and really control the population. In Afghanistan it’s a rural insurgency. We might be focusing on the cities Kandahar, Kabul, Lashkar Gah--the Russians did the same thing. Most of the population of Afghanistan is in the villages. The Taliban are in the villages, just like the Mujahideen in the '80s were in the villages. We're making the same mistakes that the Russians were making, trying to control the cities and thinking that somehow we'll defeat the Mujahideen and the Taliban who are in the rural areas.

Now, in Iraq, we had a government that somehow had some legitimacy. They represented the majority of the people. They crushed the Shia militias. In Afghanistan-- a key element in American counterinsurgency thinking is that you have to build the capacity of the government so it can spread its power and control the population. But in Afghanistan, the government is the problem. It's predatory, it's corrupt. It's lacking any credibility. It’s the best recruiter for the Taliban. So the last thing we want to do is ally ourselves and tie ourselves to this Afghan government which is hated by most of the population. The police, when they're not doing drugs, the Afghan police are stealing from stores, are demanding taxes at checkpoints. The Afghan army, I was with the Americans in the surge of 2009. The Afghan army didn't show up. They're Afghan police. This time in Kandahar, the Afghan army didn't show up again. We've spent billions on the Afghan army. We, as taxpayers should be upset about this. And who's fighting on our side in Kandahar today? It's not the Afghan army. It is Colonel Raziq from the border police, a brutal warlord who brutalized the population of Kandahar a few years ago and turned many people, such as the Noorzai clan, against the U.S. and joined the Taliban.

We've gone back to the same guy, Colonel Raziq, not the army, recruited a warlord. Where is the Afghan army? They just decided not to show up. We don't know what happened to our billions of dollars. So you don't have a government with any legitimacy or any prospect of legitimacy. You don't have any sign that you're defeating the insurgency or that you're punishing the population. In fact, there's only one counterinsurgency campaign that's ever worked in history. That was the British in Malaya. And why did that work? The British basically took half a million ethnic Chinese, put them in concentration camps and took them away from their homes. So, sure, we can do that in Afghanistan. We could defeat the Taliban. We could massively depopulate Pashtun areas and be genocidal about it. Short of that, there's just no evidence to date that we can do anything better. Nine years into this, every year, things have gotten worse and worse. This year is the worst year so far. Next year is guaranteed to be worse. The violence is spreading. Taliban control about 80 percent of the country right now.

We are hated. In my travels, I was shocked-- I was in Afghanistan last January and February. And I was shocked to see that school teachers, local government officials, bus drivers were all complaining to me about the Americans and their night raids and their operations killing civilians. I don't think the American people know the extent to which the Afghans resent their presence or feel humiliated by it.

All right. Thanks.

### Moderator
Claim: Nir Rosen, your time is up.

### Conspiracy Advocate (CA)
Claim: All right. Thanks.

### Moderator
Claim: Thank you.

Afghanistan is a lost cause is our motion. And now to speak against the motion, the last speaker in our opening statements, Peter Bergen is a journalist who is well-known for the fact that in the mid '90s, he went out to Afghanistan and sat down with a gentleman named Osama Bin Laden, one of the very few Americans ever to have met and talked with him. He wrote a book called “The Osama Bin Laden I Know.” Peter, what do you know what the rest of us don't?

### Scientific Advocate (SA)
Claim: No sense of humor. He's not a barrel of laughs. He's not a funny guy.

### Moderator
Claim: Peter Bergen.

### Scientific Advocate (SA)
Claim: First I want to salute the service of Matthew Hoh both in Afghanistan and Iraq. And I want to salute Nir Rosen's brave and enterprising reporting. It's very good to be on this stage with them and my colleague Max. And let's remind-- Max at the beginning said what this motion was about. This motion is not about Afghanistan is kind of not going well. This motion is not about we're kind of not doing so well. We're sort of losing. This is-- the motion is about Afghanistan is a lost cause. Now, that is a pretty high bar that they have to prove. And so far we've heard a lot about Iraq, not much about Afghanistan, and some pretty easy to disprove assertions that they've made when they talked about Afghanistan. And some things that they didn't even talk about, I'm surprised. You know, the graveyard of empires cliche, for instance. They didn't bring this up. Well, turns out that many empires have gone into Afghanistan and done pretty well.

The only empire that didn't do well there was the Soviets for the very good reason that they, as my colleague Max point out, they killed a million Afghans, made 5 million of them homeless. A successful counterinsurgency operation is exactly what we're doing and what the Soviets did not do. Rather, the small numbers of Afghan civilians are dying in this war, too many to be sure. But we're talking, instead of millions, as happened under the Soviets, hundreds. And as Max pointed out, the numbers are dropping, particularly because of our rules of engagement.

We heard from Nir that Afghanistan is a very violent place. Well, actually, you're more likely to be murdered in my hometown of Washington, D.C. than you are to be killed in the war in Afghanistan right now. Last year, about 3,000 Afghan civilians were killed in the war, population of 30 million. But you're more likely to be murdered in the United States in 1991 just generally than you are to be killed in the war in Afghanistan right now. It is simply not that violent. In fact, my wife is sitting here. We met in Afghanistan. You can actually have quite a good time in Kabul.

It's a relatively peaceful place. There are restaurants, there are bars. You can have a regular social life, which, by the way, you could never have in Baghdad. And if you look at the murder rates in countries like Mexico, Venezuela, Columbia, and Russia, they're much, much higher than the death rate from the war in Afghanistan. We're not saying that Washington, D.C. is a lost cause. Maybe some people might say that. But we're not saying that Russia is a lost cause, we're not saying that Columbia is a lost cause, we're not saying that Mexico is a lost cause, we're not saying Venezuela is a lost cause, yet our opponents are suggesting it's a lost cause. And this is ridiculous. Another thing we've heard, of course, if the Karzai government is corrupt, and inefficient, and incompetent, sure, no doubt, but let's look at the neighborhood. To his west he has Iran with Ahmadinejad, who's a Holocaust denier. We don't need to say much more about him. To his north he has Karimov, of Uzbekistan, who boils people alive as a sort of forensic technique. To his west we have the military dictatorship on and off of Pakistan, Asif Ali Zardari, the President, who's Mr. 10 percent because he takes at least 10 percent of everything.

And so if you look at the neighborhood he's in, this is-- Karzai is looking pretty good. And he actually won at the most recent election. Sure, it wasn't the fairest election in history. But he's winning elections. I mean, this is a democracy. Look at the neighborhood. And, in fact, Freedom House, which looks at political freedoms around the world, judges that Afghanistan is about as free as any of the immediate neighbors. And look at Afghan history, think about Karzai's predecessor for a second, the warlords, the Taliban, Najibullah, the Communist dictator, and, of course, the Soviets. By that standard, both regionally and historically, Karzai is looking pretty good. One of the weakest arguments that our opponents didn't even bring up is that foreign forces in Afghanistan are always antibodies. Well, Nir did say that we're hated. BBC, hardly pro-American, generally speaking, news organization, found that 68 percent of Afghans last year had a favorable view of the U.S. military.

Well, you probably can't find 68 percent of the inhabitants of the upper west side who have a favorable view of the U.S. military. And yet the Afghans do, and that number used to be 85 percent. Sure, we're losing some of our popularity, but we are still liked. They don't want us to go. They want us to perform on the promises that we seem to have given them early on that we would bring a more relatively prosperous and stable place. And since at the heart of a counterinsurgency is the views of the population, the population is very much on our side. Matthew mentioned that we can't afford this war. Well, we're spending $100 billion on the war. That's one percent of GDP. Between Vietnam we spent 10 percent of our GDP on the war. And I think this money's well-spent. First off, the numbers are going to go down as we spend less money and we have fewer troops. Secondly, just-- we were sitting in New York, and my wife and I just toured the Trade Center site this morning, and, you know, that cost 3,000 American lives, and it cost $500 billion, and it affects the American economy, five percent of our GDP, had a devastating effect on so many of us in this room.

And, you know, to make sure that al-Qaeda cannot come back to Afghanistan is money very, very well-spent, and the idea that the Taliban and al-Qaeda are not somehow allied is ridiculous. Anybody in this room who recalls the May, 2010, attempt in Times Square by a guy called Faisal Shahzad to blow up an SUV to kill dozens of people on a Saturday night at 6:00, luckily it didn't work out, well, he came from the Pakistani Taliban, which is a group that has been infected ideologically by al-Qaeda. And the fact that al-Qaeda is a relatively small group doesn’t mean very much at all because on 9/11 al-Qaeda only consisted of 200 people. And yet it did all this damage to us. What the problem with al- Qaeda is, is its ability to reinfect ideologically other groups, and the Taliban is one of them. And let's also accentuate the positive for a second. There are millions of Afghans back in school, of course, many of them girls, one in six Afghans have cell phones, perhaps as sort of a debatable form of progress, but one nonetheless in the sense where in a country that didn’t have a phone system at all.

Their GDP growth rate in Afghanistan in 2007 was 14 percent. It’s gone down just as every other economy has recently. Former Afghan refugees returned home. Refugees do not return to places they don’t think have a future. And so there are many positive indicators about what’s going on. And let me give you-- there’s a very common polling question is: Do you have a positive view of the future? And, now, when Americans were asked that in the closing days of the Bush administration, only 17 percent of Americans said, "I have a positive view of the future." Understandable, why? The country was in the worst depression since the Great Depression. Well, when Afghans were asked this just recently, 70 percent of them said, "I have a favorable view of the future." And that’s because they’ve lived through the Taliban. I was there under the Taliban. I was there during the Civil War. What is going on now is obviously better than what happened before. And Afghans don’t think their countries are a lost cause, so why should we think that?

## Round 2

### Moderator
Claim: Thank you.

And that concludes round one of this Intelligence Squared U.S. Debate. So I want you to keep in mind how you voted at the beginning of the evening and reminding you that we're going to ask you to vote once again after you've heard all of the arguments. And the team that has changed the most minds over the course of the debate shall be declared our winner. Now, onto round two where the debaters address each other directly and answer questions from the audience and from me.

I’m Jon Donvan of ABC News. This is a debate from Intelligence Squared U.S. We’re at the Skirball Center for the Performing Arts at New York University and on NPR stations across the nation. Our motion is: “Afghanistan is a lost cause.” We have two teams of two members each arguing over this debate. The side for the motion is arguing that the more effort that the U.S. puts in to Afghanistan, the more violent the situation becomes. The side arguing against the motion is telling us that we are hearing more and more of military victories piling up and that the Afghan people are with us.

That’s the question that I want to put to the side for the motion, the side that is arguing that Afghanistan is a lost cause. The Afghan people are with us your opponents say. Nir Rosen, you’ve been out there. Unlike most of the people in this auditorium and on this panel, you’ve been journeying among the Taliban. You have a different point of view, a different perspective from most of us. Are the Afghan people with us?

### Conspiracy Advocate (CA)
Claim: To cynics I think it doesn’t even matter because we never went there for the Afghan people. Afghanistan was never a cause for us. This was purely a security issue. But in my experience, polls in Afghanistan are notoriously unreliable because people focus on cities, on urban people who have more money and have a vested interest in the Americans staying there. But when you travel the countryside as I have, as many of the journalists have, you find an intense amount of resentment and hatred by people you wouldn’t expect to hear it from. That’s because of our night raids, many of our operations. Sure, we’re not as brutal as the Russians were. But we’re dropping bombs on weddings. Our Special Forces are going on raids and they’re killing innocent civilians.

Many innocent Afghans are dying as a result of our operations. Our operations are disrupting normal activity. Bus drivers were complaining to me, the guys who do the routes from Kabul to the south and Kabul to Herat, about how brutal the Americans are.

### Conspiracy Advocate (CA)
Claim: Tajiks our nominal allies, Americans are enemies of Islam.

### Moderator
Claim: Let me just put-- one of the points you just made I want to put to your opponent. It doesn’t really matter whether the Afghan people are with us. Max Boot, military historian, you’ve been over there as well. Does it matter whether we have their hearts and minds?

### Scientific Advocate (SA)
Claim: It absolutely does matter.

### Moderator
Claim: And do we?

### Scientific Advocate (SA)
Claim: And we do and it comes not only from the polling data, which I would cite as Peter did, to show that only about four percent of the Afghan people actually want to return to the Taliban. More than 60 percent support the NATO troop presence. But that’s what I also find just by talking to ordinary Afghans. The biggest cause of resentment of NATO and U.S. forces is the fact that we have not done a better job of creating law and order. That’s what they want. They don’t want to see a return to the Taliban. They want us to defeat the Taliban.

They support the nascent democracy in Afghanistan and it’s not just the polls, Nir. You also look at the number of insurgents that we’re facing and you’re right. The number has gone up in recent years but even at the worst case scenarios, worst case estimates we’re facing perhaps 30,000 insurgents. The Russians were facing over 200,000. The whole society was up in arms against them. The society is not in arms against us. It’s a very small percentage of the Pashtun population and if we can do a better job-- a lot of people who are fighting are just doing it because they want a paycheck or they’ve been terrorized by the Taliban. If we can do a better job of restoring security which we now have a chance to do with over 140,000 NATO troops there, the people will continue, will support us even more strongly than they already do.

### Moderator
Claim: Max, are the opinion polls, are they reliable? Your opponent, Nir, has made the point that you’re polling in the cities, you’re not polling in the countryside.

### Scientific Advocate (SA)
Claim: You know, there’s always questions about the reliability of opinion polls not only in Afghanistan but here.

### Moderator
Claim: that’s a very different--

### Scientific Advocate (SA)
Claim: There’s no question.

But the polls have been pretty consistent over a number of years and they comport with what I and many other people find out for ourselves by talking to ordinary Afghans which is that there is not an overwhelming resentment of foreigners. What there is is resentment of the fact that the foreigners have come and have not done a better job of defeating the Taliban whom they hate.

### Conspiracy Advocate (CA)
Claim: I don’t think you talked to ordinary Afghans. You go on these babysitting tours where the U.S. military protects you, white guys with guns who take you around the country and it’s all choreographed and staged. It’s not really like you’ve been in Afghanistan. It’s all organized and staged and the Afghans aren’t going to interact with you the same way when you’re the occupier, the Christian occupier with the M-16 next to you as opposed to going into villages and talking to common people.

### Scientific Advocate (SA)
Claim: Okay, well, criticizing Max--

### Moderator
Claim: Peter Bergen.

### Scientific Advocate (SA)
Claim: I mean, let’s get back to the real point. Anecdotes about what I talked about this Afghan or that Afghan. I’ve been visiting Afghanistan since ’93. I was there during the civil war. The Afghans destroyed Kabul. It wasn’t the Soviets. Hundreds of thousands of people died. Then the Taliban came.

They were the most brutal and incompetent regime. As Max has pointed out there’s nothing quite like living under the Taliban for not having a nostalgia about their wonderful rule. Only seven percent of Afghans have a favorable view. These opinion polls, they are scientific opinion polls. They’re conducted by major news organizations, the BBC, ABC News, German television, the Asia Foundation. These are not amateurs. These are as good as polls that come out in this country. There may be some-- there's always several percentage points. But in general, you know that the trend is pro American, pro-NATO, anti-Taliban.

### Moderator
Claim: Matthew Hoh. Matthew, let me put the question to you. I just want to remind people of your background in Afghanistan. You went out there as a foreign service officer. You had served in Iraq. You believed in missions. This one, you walked away from. What was it that-- what was the ultimate turning point for you that you would do something so dramatic that you saw such failure written there that you would turn away from it?

### Conspiracy Advocate (CA)
Claim: The main thing is our troops aren't fighting al-Qaeda. They're fighting Taliban. They're fighting people who are upset that we're occupying their villages and valleys. The U.S. intelligence community will cite-- you can look at the Boston globe from September 2009, that nine out of ten members of the Taliban are members of the Taliban because of foreign occupation and because of an ongoing civil war. I actually support Peter and Max's polls. 60 percent or 68 percent of Afghans are for our presence. 32 percent are violently opposed to the point they'll take up rifles. This-- Afghanistan is not a homogenous society. It's a regionalized, localized society with many, many different ethnic schisms, regional schisms. There are Hatfield and McCoy type situations that our troops are finding themselves in the middle every day. And remember, this war goes back to the '70s. The reason the Soviet Union intervened in Afghanistan was because the country was already at war.

So we-- in 2001, when we intervened, the country was at civil war. We took one side out of power and put the other side in power, but we didn't address those underlying root causes of the conflict.

Now, getting back to the polling data, again, I support that. You probably have about a 60/40 split in the country. I'll also say that some of the things-- you've got to look at the polling data real well because, yes, 7 percent of the population supports the Taliban. However, in the Asia Foundation poll that was just cited, 80 percent of the population supported talking to the Taliban and negotiating with them. Here is the deal, if you are given a choice, if you are a rural Pashtun villager, and you are given a choice between the Taliban who are ethnically and culturally similar to you or the Karzai government which is made of up non-rural Pashtuns, outsiders who are corrupt and who are backed up by an invading and occupying army, which are you going to choose?

### Moderator
Claim: All right, let's go--

### Conspiracy Advocate (CA)
Claim: It's a bad choice.

### Moderator
Claim: Let's go to Max Boot, and

### Scientific Advocate (SA)
Claim: Can I just-- can I take issue with a point that Matt has made several times now, which is to suggest that the Taliban are fighting essentially because we're there. That really flies in the face of history. And the fact is the Taliban movement began in the mid 1990s, when there was not a single American soldier in all of Afghanistan. They were a response to the chaos to the conditions that prevailed in Afghanistan when we had no presence at all there. And they managed to take over the country after a brutal and horrifying civil war and to impose one of the most totalitarian and anti-Diluvian roles the world has ever seen in Afghanistan. So the notion that somehow the Taliban would go away or would stop fighting or would suddenly be transformed into Mother Teresa if we weren't there is really ahistorical because if we weren't there, they would take over as they did last time in the 1990s.

### Moderator
Claim: Nir Rosen, is that what you're saying?

### Conspiracy Advocate (CA)
Claim: Well, they'll probably take over much of the country. That's true.

### Scientific Advocate (SA)
Claim: We rest our case.

### Conspiracy Advocate (CA)
Claim: This is not the Taliban of pre-2001. This is an insurgent movement which is very clear about its goals. They are local people, local farmers who are fighting for very local reasons.

Maybe it's anti-occupation, maybe it's for Islam or for their village or for revenge or because Americans are backing one tribe against another tribe. But they are locals fighting for Afghanistan. They've always been very clear about that.

### Scientific Advocate (SA)
Claim: I love the fact that this is not the Taliban of 2001. This is a much worse Taliban. This is a Taliban that is more ideologically with al-Qaeda. The reason that we're facing the big insurgency that we are is that they've adopted wholesale al-Qaeda's tactics from the Iraqi theater. Suicide attacks went up five times between 2005 and 2006, IED attacks. These groups are much more closely aligned. There was a public stoning by the Taliban just a few weeks ago. And so the idea that somehow the moderate Taliban are going to kind of take-- come into Afghanistan is nonsensical. The whole notion of a moderate Taliban is sort of an oxymoron. Is that the Taliban who let their girls go to school once a month or once a week? These are unreformed, and they got worse over time.

### Conspiracy Advocate (CA)
Claim: I resent the idea that the Taliban or the opponents of the Taliban in Afghanistan are wearing white hats, is not true.

### Scientific Advocate (SA)
Claim: We're not suggesting that.

### Conspiracy Advocate (CA)
Claim: Neither side are paradigms of women's rights or anything in this conflict.

### Moderator
Claim: Nir Rosen and Matthew Hoh. You're arguing that Afghanistan is a lost cause. If Afghanistan is lost, if the Taliban takes over significant parts of Afghanistan or simply the chaos continues in Afghanistan is that a threat to American national security?

### Conspiracy Advocate (CA)
Claim: The Taliban, with their pickup trucks and AK-47s are no threat to the US. Al-Qaeda is not in Afghanistan. They were defeated. They're in Pakistan. They're in Yemen. They're in internet cafes and slums around the world. The Taliban leadership is composed of Afghans. Al-Qaeda which is based now in Pakistan, to the extent that it exists as a real organization is led by Arabs and Pakistanis. In all the Taliban statements, the Afghan Taliban, not the Pakistani Taliban, two very different organizations, the Afghan Taliban speaks very much about their goals in Afghanistan. Peter conflated the two. It's true--

### Moderator
Claim: So we can leave Afghanistan, it would not cause-- it would be fine as far as our national security goes.

### Conspiracy Advocate (CA)
Claim: As far as ours, absolutely.

### Conspiracy Advocate (CA)
Claim: We’re not advocating us leaving.

### Moderator
Claim: I know you're not advocating, I just want to see-- Max Boot.

### Scientific Advocate (SA)
Claim: Can I cite a differing opinion here from an article that I consider fairly authoritative on this matter. It says the Taliban, once an isolated and impoverished group of religious students who knew little about the rest of the world and cared only about liberating their country from oppressive warlords are now among the best armed and most experienced insurgents in the world linked to a global movement of jihadists that stretches from Pakistan and Iraq to Chechnya and the Philippines. Now, the author of that article, which ran in “Rolling Stone,” in 2008, called “How We Lost the War We Won,” was a fellow named Nir Rosen. I don't know if you might be related to the gentleman sitting on the other side of the stage here.

### Conspiracy Advocate (CA)
Claim: There is a marriage of convenience, of course there's some cooperation, although we don't see it very much. When you visit villages, as most journalists who have met Taliban will say, they are local fighters. They raise money locally.

They're not fighting more money, by the way. They're fighting for very local reasons. And you don't really see many Arabs among them. When you speak to them, as I have, and other journalists have, they will often criticize the Arabs and non-Pashtuns among them, and they also condemn suicide bombing as well. But sure, they do use suicide bombers. It's not an al-Qaeda tactic. This is an insurgency tactic. It's not so much a question of ideology.

### Moderator
Claim: Matthew, I want to acknowledge that I know that you're not saying-- your position is not that we should cut and run. But a question to the other side now, if we were to leave Afghanistan-- because I want to understand what the stakes are in the situation there, being allowed to continue without an American presence were there in order to mitigate those circumstances. If we left, Peter Bergen and Max Boot, would that be harmful to American interests?

### Scientific Advocate (SA)
Claim: Of course, it would be. It would be a moral catastrophe to allow the Taliban to take over and impose a regime on Afghans. We overthrew their government. We have a moral responsibility to more or less--

### Moderator
Claim: So what's the security threat?

### Scientific Advocate (SA)
Claim: --more or less get it right. Well, we already know, when the Taliban was in charge of Afghanistan, al-Qaeda had free rein in the country.

The Taliban, by the way, have had ten years to say 9/11 was a bad idea, al-Qaeda is a bad idea. Osama Bin Laden really was kind of a problem for us. They've never said that. They never-- one of the central-- if there are negotiations with the Taliban, you know, one of the things they've got to do is reject al-Qaeda. They've never done that. And in fact as we've seen in Times Square that these groups are very closely aligned.

### Conspiracy Advocate (CA)
Claim: Pakistani Taliban, though. It's dishonest to compare the Afghan Taliban with the Pakistani Taliban.

### Scientific Advocate (SA)
Claim: It's the Taliban. They're all based in Pakistan right now because we thankfully got a lot of them out of Afghanistan. And if we got out of Afghanistan, they would all come back to Afghanistan. They're only in Pakistan because we are forcing them out. And what we're trying to prevent is a safe haven in Afghanistan coming back for al-Qaeda and the Taliban who just moved across the border. We can't invade Pakistan.

### Moderator
Claim: Let's hear Matthew Hoh's response.

### Conspiracy Advocate (CA)
Claim: You know, two things, one, I don't think al-Qaeda needs a safe haven and wants a safe haven. I'd like them to go back into safe haven. I'd love for them to open farms back in Kandahar because then we could bomb them.

They do not operate in any manner that we're going to-- they don't operate in a manner that we can attack with conventional forces. Again, look at the history of attacks in the last ten years. I urge you to go to the Heritage Foundation website, the Heritage Foundation, not a limp-wristed, left-leaning organization by any means. And you'll see that they documented the 30 attacks against the United States by transnational terror groups, primarily by al-Qaeda, for the last ten years. And you'll see it's all done by individuals in small cells who don't require large safe havens. Since 2001 al-Qaeda has evolved into an organization that is decentralized, it's near virtual, and it does not exist in a manner that we can attack. And actually the RAND corporation did a study two years ago. And it found that 84 percent of all terrorist groups since the '60s have met their end by either police action, by intelligence action or by political action. So the smart way to go about them is to attack al-Qaeda as they actually exist and not as we want them to be or not how they were 10 years ago.

They're an organization like any other organization. They evolve. Organizations tend not to devolve. It does not make any sense why al-Qaeda would want to go to a place or go back into a form where they could be readily attacked by our aircraft, our cruise missiles, our commandos. And like I said, if they did, that's great, because then we could go after them that way.

### Moderator
Claim: All right. I want to take a break. And when we come back, I want to talk about who our allies are. So as soon as I restart this, I'm going to after a minute or so I would like to go to you in the audience and just gauge from you your take on what you're hearing so far. I'm not asking you for questions. I'm asking you to do something different to fill in the blank on this sentence, "The argument that I am hearing tonight that I think is very weak is--" and one or two sentences, or, "The argument that I'm hearing tonight that's surprising me with how compelling it is, is--" and fill in the blank. So in a minute or two I'll come to you, and just raise your hands. We'll have microphones come to you and we'll pick, I think, four people and do it one after the other.

So let's come back to the debate.

This is a debate from Intelligence Squared U.S. I'm John Donvan of ABC News. Our motion is "Afghanistan is a lost cause." And something that has come up in the discussion is the fact that our allies, the government of Afghanistan, is not by any definition savory. And I want to go to Max Boot, because I believe you had in your visit there some contact with them, how much of a problem is that, that the guys that we're backing are so incredibly disliked, which is something that you concede?

### Scientific Advocate (SA)
Claim: Well, John, the fact is we don't have perfect allies in Afghanistan, but that's true in any counterinsurgency fight because think about it, the reason why you have an insurgency in the first place is because the government isn't doing a very good job. And if the government were doing a wonderful job, you would not have an insurgency. Despite that, however, most insurgencies fail.

The research I've done for this book on the history of guerilla warfare suggests that more than 65 percent of all counterinsurgency efforts have been successful over the last 200 years whereas insurgents have achieved their objectives only about 20 percent of the time. That means in more than 65 percent of cases, it has been possible to increase government capacity to not only militarily defeat the insurgency, but also to take away some of the reasons why they're able to recruit in the first place. And that is something that we are working very hard to do in the case of Afghanistan. And there is no question that the Afghan government has many imperfections, that it has corruption, it is ineffective, it has a lot of other problems, but, again, on the other side, you are not exactly facing-- you're not exactly facing the League of Women Voters. You are facing an intensely unpopular group which has far more problems, and which is far more brutal, far more implicated in the drug trade, the people of Afghanistan have experienced the rule of both the Taliban and the current government. They know the current government has problems.

But, again, to refer to those polls which marry up with everything I've learned in my trips to Afghanistan, over 90 percent of Afghans prefer the current government to the Taliban, and that's the underlying reality which will make it possible for us to prevail.

### Moderator
Claim: Your opponent, Nir's, point that you're not getting around Afghanistan the way he is, that you're not seeing the uglier side of it the way that he has, is painting for you a rosier picture, and it's not quite an ad hominem argument, there's actually an issue of data collection there. And I just want you to respond to it because it was a little bit brushed off before.

### Scientific Advocate (SA)
Claim: Well, there's no question that Nir has embedded with the Taliban and I haven’t, so hats off to him. But I’m not sure that necessarily embedding with the Taliban gives you a rounded view of what the people of Afghanistan think either. And, in fact, the reality is most of the Afghans are not part of the Taliban. Most of them abhor the Taliban. And, again, you don’t have to take my word for it, you don’t have to take the word of the pollsters for it, all you have to do is look at the number of Afghans who have-- as I mentioned before, who have actually taken up arms against the government.

It’s a miniscule portion of the number that took up arms against the Soviets in the 1980s who were genuinely detested by the entire population.

### Moderator
Claim: And to the side that’s arguing that Afghanistan is a lost cause, something that your opponents said that I found quite interesting is that you have a very high bar to prove. You are arguing that Afghanistan is a lost cause, but when, now or in the future? And if it’s in the future, is-- what if we pour in more troops, what if we increase our effort, what if we simply allow more time to go by, in making things try to work? What’s to say that ultimately with time this could not work out?

### Conspiracy Advocate (CA)
Claim: More is the problem, the more troops we put in there, the more money we’ve put in, we’ve actually created a conflict because of our money. Iraq's people are fighting over control of the oil. In Afghanistan the only resource is American money. You have warlords that we’re backing competing for American money, you have the Taliban who are making money from our presence there, you have Afghan police who are selling the bullets we are giving them to the Taliban, you have contractors where the Americans are paying who are paying bribes to the Taliban.

It’s all about American money, the more we put in there, the more of our presence, the more supplies it requires, the more warlords we’re paying to protect our convoys. In Iraq we were using American mercenary companies. In Afghanistan we're using Afghan warlords.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: The problem--

### Moderator
Claim: Peter, I want you to respond to his-- the main thrust, the more we do, the worse it gets.

### Scientific Advocate (SA)
Claim: I think quite the reverse, the less we did, the worse it got. If you look-- go back to 2003, there were 6,000 American soldiers in Afghanistan. That’s the size of the police department of Houston in a country the size of Texas with a population 10 times larger. It was precisely because of the Bush administration’s ideological opposition to nation building that we did everything on the cheap and we got what we paid for. Into the vacuum of governance and authority stepped the Taliban and al Qaeda and actually this raises a very good point which is it would be much more convincing to say that look, we should just sort of wash our hands of Afghanistan if we hadn’t already done it twice.

In 1989 we closed our embassy there after arming the mujahideen and defeating the Soviets. The Clinton administration then zeroed out aid to one of the poorest countries in the world and into that vacuum stepped the Taliban and al Qaeda. Then in 2001, the Bush administration did almost exactly the same thing. So it’s not because we’ve done too much. It’s because we’ve done too little. We’re finally beginning to-- we’re in year one of a serious effort. Up to this point, we’ve really done not enough and if you go back to some of our other peace keeping operations, in Bosnia we spent 20 times per capita what we’re spending in Afghanistan in the first years of occupation; in Kosovo, much, much larger. According to the Rand Corporation, this was the least resourced nation building effort the United States has engaged in since World War II.

### Moderator
Claim: All right. Let’s hear what your opponent has to say to that. Matthew Hoh?

### Conspiracy Advocate (CA)
Claim: We did. When we got there in 2001 we were welcomed. People didn’t like the Taliban. They didn’t receive their support. They fled to Pakistan. We stayed and supported a clique that was the government. The government was exclusionary.

And so what you had happen over time, that period from 2002 to 2005 was the American troops never left. We spent a lot of money there that went to enrich a few people and we supported and propped up a corrupt and illegitimate government that was exclusionary. When I say exclusionary, one thing I have to say again, going back to Afghanistan, it is a very ethnically regional and localized country. This is as if-- now we’re talking about the government-- I was embedded with the Afghan government. I ate a couple of meals with them a day. I had the parasite to prove it. It’s a wonderful weight loss thing, guys. But no, in a sense it would be like after 2005 our federal government put me, a guy from Jersey, in charge of a parish in Louisiana and sent the New York National Guard to keep me in power. That’s the dynamic that you see there. And this idea about-- just to get back-- another thing about the government, the idea that we’re on the side of good and the Soviet Union was on the side of bad, again, the Afghans don’t see it that way.

It’s such a confused conflict there. But I can tell you that the Afghan army brigade commander I worked with, the Afghan police commander I worked with, and the Afghan intelligence chief I worked with were all Moscow trained. They had all fought on the side of the Soviets. The Afghan army was well over 100,000 people at times. Kabul was so safe for the Soviets that Soviet administrators used to live in Kabul with their families. The Soviets had 20,000 civilian advisors there. So the idea that what we’re doing-- I agree with parts of what Max said about the difference between us and the Soviets but there are also similarities that really can’t be ignored.

### Moderator
Claim: All right. I’d like to hear from you in the audience to gauge how you think this debate is going and see what you think is persuasive and what is not. What I’d like is for you to do is answer this question. What I’m hearing that makes very good sense to me is-- or what I’m hearing that is just not holding water is-- and I’m not asking you for questions and I’m not asking you for information. I really want your judgment on the arguments that you’re hearing.

So any hands go up. Okay. The woman in the center. We’ll get a microphone over to you. Anybody on the-- yes, sir, I’m pointing right at you and you can stand up as well. Sir, yeah, yeah and the mic will come to you. Anybody else on the-- down front, gentlemen in the brown blazer and the front row in the green sweater. And again, I’ll just ask you to make the statement and you, members of the audience, if you like the critique or observation that we’re hearing, feel free to applaud. There’s one more down here. Do we have a fourth microphone? Okay. It’s on its way. And we’ll just pass it to the far end of this aisle. Sir, could you pass that one down and we’ll get you another one? Pass that one to the end of the aisle and there’s another one on your other side. Here we go. Okay and so you can go first.

So I just want to know, what do you think of the debate you’re hearing so far?

### Moderator
Claim: I found the argument about the poll results to be very, very weak indeed. If these people are not willing to fight to preserve themselves from the Taliban, I really wonder whether it matters very much if they say they’re opposed to it when you ask them that.

### Moderator
Claim: Thank you very much.

Ma'am, you can stand up, and let me just make sure the camera's found you. Yes.

### Moderator
Claim: So the argument I'm hearing tonight is that Afghani people don't think Afghanistan is a lost cause. I'm from Iran, and I go back there for home. And there are quite a few Afghanis who work in Iran, low-paying jobs, most of them are illegal. And I see-- and I saw them after the government was toppled, that they went back to Afghanistan. And a lot of them are back in Iran. The country that you just dismissed as being way worse than Afghanistan.

If Afghanis don't think this is a lost cause, why are they coming back to Iran to work a low-paying job?

### Moderator
Claim: Thank you.

### Moderator
Claim: I'm not hearing enough from either side about the role of Pakistan and the Pakistani government in all of this. Because it seems to me it's more than just the difference between the Pakistani Taliban and the Afghani Taliban. It's also the fact that there's evidence that elements within the Pakistani government are directly funding and/or assisting the insurgency in Afghanistan. If that is the case, how can we possibly succeed?

### Moderator
Claim: All right. Thank you very much.

And one more down front. If you may rise. Thank you.

### Moderator
Claim: I think that we should have our special forces going around the world defeating al-Qaeda. But I think we should pull our army out of Afghanistan.

There's no way we're going to defeat them with their special groups of fighter warlords that all have different interests. So it's a lost cause to stay there.

### Moderator
Claim: Okay. Thank you very much. I want to take the question-- turn into a question the comment about Pakistan because you have made the case that talking about there being a Pakistani Taliban. But we haven't really talked a great deal about Pakistan as an agent in Afghanistan. And this gentleman's comment is that he feels the role of Pakistan as a negative influence in what's going on there makes more or less-- is turning this into a lost cause. It's a little bit of an affront to your point of view. So I'd like you to take, that Peter Bergen.

### Scientific Advocate (SA)
Claim: Yeah. Pakistan has very belatedly begun to realize that the Jihadi Frankenstein that they helped create, the Taliban, has become a huge problem for them. Benazir Bhutto, the most popular politician in Pakistan was killed by the Taliban. The Taliban have attacked hundreds of police, killed hundreds of police officers and army soldiers.

And as a result, the Pakistani public, which used to view the Taliban as sort of religious Robin Hoods, now see them largely as thugs. Support for suicide bombing in Pakistan dropped from 33 percent to five percent in the last several years. And the Pakistani military have done significant military operations in Swat, which is the tourist destination in the north of Pakistan and also in southern Waziristan. And it's not perfect, but the enemy of the perfect is not the reason we okay. And the Pakistani government, military and public have already turned against the Taliban in a very sizeable way because they understand that the Taliban is now attacking the Pakistani state.

### Moderator
Claim: Nir Rosen.

### Conspiracy Advocate (CA)
Claim: There's a very dangerous conflation here, though, because there's the Pakistani Taliban and Afghan Taliban. It's true, the Pakistani state is fighting brutally the Pakistani Taliban. It's not fighting the Afghan Taliban. It's supporting the Afghan Taliban. In fact, the Afghan Taliban has criticized the Pakistani Taliban for fighting the Pakistani state and told them they should come to Afghanistan to fight the Americans in Afghanistan. But I think it's not only important to look at what the Pakistanis are doing to Afghanistan and to us---- it's important to look at what we're doing to the Pakistanis. We've driven-- Pakistan is a much more crucial country, with nuclear weapons, conflict with India. We have driven the Taliban into Pakistan. We've driven al-Qaeda into Pakistan. And our drone strikes now are not only pushing the Taliban and al-Qaeda into Pakistan, but further into Karachi into Sindh, Punjab. We are destabilizing Pakistan, a much more important and dangerous country. Just by being in Afghanistan, we're also pushing drug networks out of Afghanistan into Pakistan. It's our presence which is threatening this crucial country, which, of course, can go into conflict with India, et cetera.

### Moderator
Claim: Thank you, Nir. And I--

### Scientific Advocate (SA)
Claim: Can I ask a question here? I mean, what is-- what is more likely to produce a stable and pro Western Pakistan in the future? Is it an American defeat in Afghanistan? Is it a withdrawal that will be hailed by the jihadists as a glorious victory against another super power, one that will allow their allies and the Taliban to take power in Afghanistan? Is that going to be good for the future of Pakistan? Or conversely, what about the future---- of Pakistan if we are in fact able to stabilize Afghanistan to shore up the friendly pro- Western government there which works with the West to fight terrorism? What is the impact of that going to be on Pakistan. I think my point is-- should be pretty clear, which is that if we are concerned about the future of Pakistan-- and I certainly am-- then running out of Afghanistan is not the strategy to pursue. That will in fact weaken the government of Pakistan and destabilize it, whereas if we can stabilize Afghanistan, that will do much to strengthen the forces of moderation in Pakistan.

### Conspiracy Advocate (CA)
Claim: John. Just to answer that real quick?

### Moderator
Claim: Very quick, yeah, Matthew Hoh.

### Conspiracy Advocate (CA)
Claim: Two things: One, does al-Qaeda receive more recruits because we occupy two Muslim countries or because of a supposed loss in Afghanistan? And also, too, we're not talking about losing or running from Afghanistan. We're talking about getting a political process that resolves 30 years of conflict in Afghanistan. In 2000-- go into Pakistan. In 2001, Pakistan had two insurgencies.

They had insurgency in Sindh and an insurgency in Balochistan. They didn't have insurgency in the Pashtun areas. There were extremist groups there, but there was not an insurgency. The Pakistani Taliban did not come into existence until 2006 or 2007 and had popular support from the Pashtun people until we had the Islamabad government send the army into there, which hadn't occurred for 40, 50 years, and until our drones start showing up. So if anything, if you look at what's happened to Pakistan in the last 10 years, our presence and our continued escalation of Afghanistan, that has destabilized Pakistan. So, again, we’re not talking about cutting and running from Afghanistan. We're talking about having a political process that ends 30 years of war that stabilizes not just Afghanistan but Pakistan as well.

### Moderator
Claim: All right. I want to go to some questions from you and invite you back into it. And again, thank you for those comments that actually helped move this debate along.

Our motion is “Afghanistan is a lost cause.” I'm John Donvan of ABC News. This is a debate from Intelligence Squared U.S.

We have two teams of two arguing it out; Afghanistan is a lost cause from the Skirball Center for the Performing Arts at New York University. And I'd now like to go to questions from the audience. And, again, on questions, I'd like them to be on topic on the motion. I'd like them to be brief. I'd like them to be questions. I'm going to go-- yes, please.

### Moderator
Claim: Hi. I'm Dina Temple Raston with National Public Radio. And I wonder if you could discuss a little bit something that you touched on but really didn't dive into, and that is the nascent peace talks between the Taliban and the Karzai government. And for Matthew, for you, and for Peter Bergen, for you, could you please explain how these peace talks fit into your view of the motion, Afghanistan is a lost cause, and whether or not they are at all meaningful?

### Moderator
Claim: Thank you. And that was a question.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: Peter Bergen.

### Scientific Advocate (SA)
Claim: Three weeks ago, an expert on Afghanistan discussed this very topic. And he said that-- talking about the---- peace negotiations with the Taliban, he said reports of the U.S. being involved with efforts to reconcile elements of the insurgency with the Karzai government are reports that provide hope, albeit cautious hope that a more sensible and rational U.S. policy is taking hold. The same expert also said that he had cautious optimism for Afghanistan as a result of these talks. That expert was Matthew Hoh. Just three weeks ago, he said there was hope and cautious optimism because of these talks. Now he's saying it's a lost cause. Which one is it, Matthew?

### Conspiracy Advocate (CA)
Claim: You guys do your homework.

### Scientific Advocate (SA)
Claim: Sorry.

### Moderator
Claim: And you should too.

### Conspiracy Advocate (CA)
Claim: Well, you know, they're both true. They are. I mean--

### Scientific Advocate (SA)
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: If you look at-- again, if you look at this conflict that's been going on for 30 years, if you understand that the Taliban are not a monolithic organization, that they're composed of multiple local groups with legitimate political grievances, then there is a need to negotiate to end the conflict.

Go home tonight and look up a thing called the National Strategy for Victory in Iraq in 2005. This was our document. And I worked on it when I was in the State Department in 2005 after I came back from Iraq my first time. Go and look it up. We called it the NSVI. And it says the same things about the Iraqi insurgency. It's monolithic. They're all terrorists. We can't negotiate with them. We can't leave Iraq because it will become a safe haven for terrorism. So the same things we did in 2003 to 2006, in terms of lumping the Iraqi insurgency together, calling them all terrorists, the same things we're doing now in Afghanistan. What changed in Iraq? And I can tell you when I was there in Anbar province, where--

### Moderator
Claim: Matthew, can you relate this to the question, to the question on the peace talks?

### Conspiracy Advocate (CA)
Claim: Yeah, sure. The point--

### Scientific Advocate (SA)
Claim: Does it give you hope or not as you wrote three weeks ago?

### Conspiracy Advocate (CA)
Claim: Very cautious hope that there will be a breakthrough that we would start to peel off elements of the insurgency and shatter the insurgency and splinter the insurgency.

### Scientific Advocate (SA)
Claim: Cautious hope and lost cause are completely different things.

### Conspiracy Advocate (CA)
Claim: Well, it depends what the cause is.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: The cause-- I think I wasn't-- I probably didn't have this debate in mind when I was talking to-- I mean-- you know, but honestly--

### Scientific Advocate (SA)
Claim: Do you take back what you wrote three weeks ago?

### Conspiracy Advocate (CA)
Claim: No, of course not. No.

### Scientific Advocate (SA)
Claim: Okay. So then cautious hope and optimism.

### Conspiracy Advocate (CA)
Claim: Cautious hope and optimism for talks to end the conflict through-- I think I've been clear the entire night about the need for reconciliation.

### Moderator
Claim: Nir Rosen.

### Conspiracy Advocate (CA)
Claim: First of all, there are no talks. And Petraeus has done his best to nix those talks because he's adopting a very aggressive militaristic approach to Kandahar which isn’t even counterinsurgency, it's going back to the Russian operations of '83 and '84. But if Afghanistan is a cause in terms of a military strategy, with U.S. strategy as a very militaristic one and military focused, then, yes, there's no hope. But if you approach it as a political problem, then there is hope and that hope involves some kind of political settlement and abandoning this increased militaristic approach, but it just depends on how you define your terms.

### Moderator
Claim: Another question?

### Scientific Advocate (SA)
Claim: Can I just reply to

### Moderator
Claim: All right, Max Boot before the

### Scientific Advocate (SA)
Claim: because I think Nir must be talking about a different war than the one I'm familiar with, comparing what we're doing in Kandahar, for example, to what the Soviets did in the 1980s when they leveled the city and killed hundreds of thousands of people, hey, I was in Kandahar this summer, we're not leveling the city, buddy, okay? Now, in terms of negotiations and how wonderful they are, there is no question that ultimately at some point a lot of this insurgency will be dealt with through negotiations, but the question is--

--how do you set the conditions for those negotiations? What General Petraeus recognizes and which I don't think Nir Rosen seems to understand, is that first you have to convince your enemies they are not going to win at gunpoint. As one NATO officer put it to me in Kabul, he said, sure, you can give the-- first you have to knock the Taliban on their back, then you can give them a helping hand up. They have to be convinced they are not going to win. At that point they will start to negotiate seriously. We are only now starting the process of convincing them that they will not win because we are only now implementing a serious counterinsurgency strategy on the ground.

As we have more success in pacifying areas like Nawa, or Marjah, or Kandahar, then you will see the insurgents coming to the table and a lot of them giving up and stopping the fight. But they're not going to do it if they see Americans on the way out.

### Moderator
Claim: I want to move on, and you can bring this in your closing statements. Sir.

### Moderator
Claim: Hi, my name is Ali Grebe And I just wanted to challenge Peter Bergen on the specifics of something he said before. He said that the Afghani Taliban hadn't repudiated al-Qaeda at all, and that's true in the sense of the strict repudiation word for word. But Ahmed Rashid reported in February of this year in the New York Review books that Mullah Omar, who's the head of the Afghani Taliban and the had pledged that if the Taliban were allowed to return to Afghanistan that there would be no interference from foreigners, and then also there would be no threat from Afghanistan to any neighboring or outside countries.

And that's what I was just wondering, for comments on that

### Scientific Advocate (SA)
Claim: He would say that, wouldn't he? I mean, come on, this is a guy who was prepared to-- Mullah Omar was prepared to lose everything on the point of principle that he wasn't going to hand over bin Laden, and he did. This does not suggest that he's going to be Henry Kissinger in some future negotiation with us. This is a religious fanatic who very closely allied to another religious fanatic, Osama bin Laden. I was there under the Taliban. I can tell you that a doctor was earning six dollars a month, the World Bank stopped measuring the economic indicators of the country because there were none, all women were imprisoned in their homes, and all girls were not allowed to go to school. This is the-- Mullah Omar is not a rational actor with whom we can do business. And it would be a moral catastrophe for us to allow him to come back into power in some shape or form.

### Moderator
Claim: Another question? Ma’am, yes, and if you could stand up, please…

### Moderator
Claim: Hi. My name is Lauren I'm a student at NYU.

If you do pull out of Afghanistan, how do you know that al-Qaeda will not come back, because would it not be possible for them to use the fragmentation that is within Afghanistan and the weak government to come back into power and to use it as a means of recruiting people?

### Moderator
Claim: I’m not sure that you're saying to pull out of Afghanistan

### Conspiracy Advocate (CA)
Claim: No, but—

### Moderator
Claim: Nir, take the question.

### Conspiracy Advocate (CA)
Claim: If we were to pull out and al-Qaeda came back to Afghanistan, I think that would be the greatest thing because right now they’re in Pakistan where we can’t actually get to them, we can’t find them, there’s a much great infrastructure for al-Qaeda to hide in Pakistan, dense urban areas in Karachi and other places where they can blend with the population. In Afghanistan, if they have bases, whenever you want you can pound the hell out of them. Drop B-52 bombs on them be as brutal as you want. I think it’s also important to remember, al-Qaeda is not that big of a threat. They’ve had one success, September 11, and that's it. So we shouldn't exaggerate this threat of al-Qaeda in the first place.

### Moderator
Claim: I just want to go to Max Boot.

Nir’s thesis being al-Qaeda coming back into Afghanistan would not be such a bad thing because you can get them there.

### Scientific Advocate (SA)
Claim: Well, you know, that’s the strategy we tried prior to 9/11. We can see how well that worked with cruise missile strikes on al-Qaeda training camps in Afghanistan. And frankly, Nir's statement just now I think puts a lot of his comments into perspective because he’s saying the Taliban aren’t much of a threat, but he seems to think that al- Qaeda isn’t much of a threat either, so do we face any actual threats out there, Nir, I’d like to know?

### Conspiracy Advocate (CA)
Claim: The Taliban certainly are no threat. You’ve only had one Afghan ever try to attack America and that was Zazi here in New York and he spent most of his life here. You don’t have any Afghan Taliban trying to attack the U.S. outside of Afghanistan, of course where they’re occupied.

### Scientific Advocate (SA)
Claim: Except in Times Square just in May.

### Conspiracy Advocate (CA)
Claim: Pakistani Taliban, not Afghan.

### Scientific Advocate (SA)
Claim: distinction without a difference. They are essentially the same group of people.

### Moderator
Claim: There’s a lot of grumbling from the audience.

### Conspiracy Advocate (CA)
Claim: When I was bringing up Iraq before, this is what we did for three or four years in Iraq. We conflated all the groups together, did not address any of the local grievances that those groups had.

They had been usurped from power, they were excluded from the government. The outsiders were occupying them. This is-- if we want to keep this kind of mindset about the Taliban, then we can fight them for decades. Has everyone seen the film “Gladiator”? Okay, remember in the beginning they’re fighting the Germans and one general turns to Russell Crow and says “Don’t people ever know when they’re beaten?” And Russell Crow says, “Would you?” Same thing. This is human nature. It is, it’s human nature. Who here as a kid watched “Red Dawn”? Okay? Right? I mean, when I went into the Marine Corp, you know, I grew up in my 10 years in the Marine Corp, “Red Dawn” was probably my favorite movie, okay? If the Russians had invaded, I would have fought them. It’s the same type of principle, okay? We’re dealing with people who primarily see the reason for supporting the Taliban as occupation and a government that excludes them.

If we drive a wedge between them and the Taliban who I’m not saying there are no Taliban who are aligned with al Qaeda. There are. But split them. Why fight all of them when we can negotiate with 80 percent of them.

### Moderator
Claim: Right in the front row. And there’re three hands up. I mean the person in the middle. Yes, you chose correctly. Could you stand up, please. Just give a second for the camera--

### Moderator
Claim: I’m a high school senior on Long Island and my question is that this debate seems to come down to all about is Afghanistan is a lost cause in terms of military occupation and although I agree with that, I’d like to ask you, what about humanitarian efforts? I mean, since NATO presence there’s been an increase in health care availability to have assistance from nine percent to 85 percent, a 50 percent increase in crop yield due to I mean, how can you denounce the fact that there’s been a massive increase in terms of quality of life for the average Afghani civilian?

### Moderator
Claim: So you agree with the side arguing against the motion that there’s a lot of progress?

### Moderator
Claim: In terms of this debate, I don’t agree that the military presence-- I believe the military presence is a lost cause but I do think the humanitarian efforts being at present have--

### Moderator
Claim: All right. Since that actually was part of Max Boot’s opening argument. That there are a lot of other aspects of life that are succeeding, I’d like you to take that question.

### Conspiracy Advocate (CA)
Claim: Yeah, the U.S. has spent since 2001, 50 billion dollars on foreign assistance in Afghanistan. The average life expectancy of an Afghan is 44 years of age. One in five children die before their fifth birthday. Yeah, one in five. So what is the biggest tragedy for an American family is a rite of passage for an Afghan family. Access to electricity is less than 10 percent for the Afghan people and when I say access, that’s three to four hours. There have been some successes. But this is still a country that is ripped apart by war. So what you need to do is find a way to keep those successes and end the conflict in the other part of the country. So it is, it’s a mixed thing but to say that they’ve only benefited from our presence there, some have but many, many have not.

### Moderator
Claim: Sir? Could you stand please? Thanks.

### Moderator
Claim: Reid Schoenfeld a one-time newsman.

### Moderator
Claim: I used to work for you, actually, a long time ago. You didn’t pay very well at all. I’m not going to forget that.

### Moderator
Claim: I think you came after I left. You would have been more poorly paid if I was still there. But why, if 90 percent of the Afghans don’t like the Taliban and why did General Casey, excuse me, General Oates Michael Oates stand up in Washington 21 days ago and he’s the guy in charge of trying to eliminate IEDs and he uses ground sensor devices to do that among others say that there’s little utility in the use of ground sensor devices against IEDs because as soon as they were planted, the local population told the Taliban---- about it and the local Taliban appeared, either avoided them or appeared and unplanted them.

### Moderator
Claim: Max Boot.

### Scientific Advocate (SA)
Claim: Well the problem of IEDs was actually far worse in Iraq than it is in Afghanistan. And what we found there and the general is right, there’s not a quick technological fix for IEDs. What works in getting rid of IEDs, the roadside bombs the insurgents set, is to implement classic counter-insurgency strategy, to bring security to the villages, to bring development to the villages, to protect the people from the insurgents. And once you protect them from the insurgents, they will then be willing to rat out the insurgents who are in their midst and tell you where the IEDs are being planted. That is exactly the strategy that our forces are now implementing in Afghanistan. They are bringing security to the villages and to the towns. And as they do that, as they provide a more secure environment, it will be impossible for the Taliban to plant IEDs. There is not a quick technological fix to it. But what we found is that these classic tried and true counterinsurgency techniques are incredibly successful.

In Afghanistan-- in Iraq, they led within a couple of years to a more than 90 percent decline in violence.

taking effect in Afghanistan. I see similar success happening in areas like Nala where our troops have been a little bit longer than they are in--

### Moderator
Claim: Matthew I would like you to respond to that as well.

### Conspiracy Advocate (CA)
Claim: Actually, when I was in Iraq, I was a combat engineer in the Marine Corps where I had to actually go out and look for IEDs. Or my marines-- I was an officer, so my marines did, you know. But Max is correct, but it's not working. Gareth Porter, a journalist for Inter Press Service--

### Scientific Advocate (SA)
Claim: We don't know it's not working.

### Conspiracy Advocate (CA)
Claim: We know it's not working, Max, because--

### Scientific Advocate (SA)
Claim: We're just starting to do it now.

### Conspiracy Advocate (CA)
Claim: No, we're not starting to do it. Has there-- I mean, again, I'll refer to a movie because it's-- we've been doing counterinsurgency for years--

### Scientific Advocate (SA)
Claim: I can't argue with “Red Dawn.” You've got me there.

### Conspiracy Advocate (CA)
Claim: Yeah.it is a great film, right? But I would urge you all to see the film “Restrepo”--it's a documentary done by a journalist-- to see what it's like to be an American infantryman in Afghanistan. But that film was done three and a half years ago. And you see our soldiers doing counterinsurgency then.

The Lieutenant General Barno who was in command of our forces in 2004 said we are moving to a counterinsurgency strategy. What Max is talking about, and he's right, that is counterinsurgency strategy to try and get the population to support you and turn in the IEDs. In southern Afghanistan where we have insurgent troops for several years now, the first marines, the first U.S. Marines went back into southern Afghanistan two and a half years ago into those parts of Hellman where we're still losing guys every day. The success rate and the percentage of IEDs that were being turned in by the population, less than two percent. The population is not embracing our presence.

### Moderator
Claim: We have time for one more question. Ma'am. I'm favoring the bright lights tonight because of the television.

### Moderator
Claim: So you mentioned several times, Matthew, that you had-- for us not to pull out exactly, but you had some sort of other solution.

And I'm wondering if Afghanistan is a lost cause, could we accept that it's not just a question of methodology, but our actual presence there. What is the alternative? What will happen when we leave? And what can, I guess, we do? And what can Afghanis do? I guess that's it.

### Moderator
Claim: I want to pass to a different question because it doesn't really go to the issue we're trying to decide tonight. I think it's a very valid question, but it's more about if it's lost, then what? And if you-- respectfully, I'd like to try one other question. Yes, on the far right. Thank you, though, for that.

### Moderator
Claim: I had experience with counterinsurgency in South Vietnam as a marine. And I am a little concerned about the Karzai government and their move to disarm the contractors. I think that if one goes out of your base to try and help the village and counteract whatever Taliban influence there is, without good security,---- if they're disarmed, and you depend upon the Afghani police, is our effort outside going to collapse? In other words, is our village pacification in Afghanistan going to disappear if Karzai really disarms the professionals?

### Conspiracy Advocate (CA)
Claim: What's scary is that we've spent $27 billion building the Afghan police and the Afghan army after nine years, and we can't rely on them to protect humanitarian assistance projects. Losing the private security for development workers there is very troubling. And it will have a severe impact on humanitarian assistance.

### Scientific Advocate (SA)
Claim: Actually, I think this is a good move on President Karzai's part because these private security companies have been a big part of the problem in Afghanistan because they've run roughshod over a lot of the country. And we've relied upon them for years because we didn't make a serious effort to send our own troops or to build up the Afghan security forces. We have not tried to create an Afghan security force large enough to stabilize and secure the entire country.

We're only now making that attempt. And as we do that, we can be less reliant on the private contractors who are out of control in many cases and under poor supervision. And we can rely more on our own troops and more on the Afghan troops that they are mentoring alongside of them. And you will see an increase in security. So I think this is actually-- I'm critical of President Karzai for a lot of things, but I think is actually a positive initiative.

### Conspiracy Advocate (CA)
Claim: The Afghan troops are part of the problem. It's the Afghan police who are the best recruiters for the Taliban by oppressing people, by stealing from them, by demanding bribes.

### Scientific Advocate (SA)
Claim: That's because they haven't had salaries, and they haven't had training. And both of that is changing there.

### Moderator
Claim: And that concludes round two of this debate. .

## Round 3

### Moderator
Claim: And here's where we are. We are about to hear brief closing statements from each debater. They will be two minutes each. It's their last chance to change your minds because we're going to ask you right after that to vote one more time. Remember, we asked you to vote before the debate. We're going to ask you to vote again right after these closing statements. And the team that has changed the most minds will be declared our winner.

Onto round three, closing statements from each debater in turn. Our motion is “Afghanistan is a lost cause.” And here to argue his position against the motion, Max Boot, senior fellow at the Council on Foreign Relations and the author of “War Made New.”

### Scientific Advocate (SA)
Claim: Well, guess what, folks? My pre-debate intuition held up pretty well. The other side has not even come close to proving their case that Afghanistan is a lost cause. What they have essentially done is they've thrown up various problems that exist in Afghanistan. And I-- we agree with them. There are a lot of problems that exist. There are a lot of problems that existed in Iraq. There are a lot of problems that existed in Malay and Colombia and El Salvador, in Peru and many other places where insurgencies have been defeated. But the fact that the problems exist does not mean that we cannot overcome them. And for the very first time, we are making a serious effort to overcome them. Matt talked to you about how we've been trying to do counterinsurgency in Afghanistan for years. No, we haven't. We have not made a serious commitment to do counterinsurgency in Afghanistan until right now.

When you have 30,000 troops in a country of 30 million people, you are not doing serious counterinsurgency, no matter what your generals say. We are starting to do serious counterinsurgency right now with hardened-- battle hardened troops, experienced in both Afghanistan and Iraq, led by our finest general, implementing many of the lessons we have learned, not only in Iraq but many other conflicts. We are addressing local grievances, the very things that Matt says is driving the insurgency. We are working with provincial reconstruction teams and district support teams to improve lighting, to decrease corruption, to improve economic development, all these things that people want. There is-- I think it is crazy right now when the surge is just beginning to suggest that it already has no chance of success. It is ahistorical. It-- when you look at the fact that, as I mentioned in my opening statements, many wars have been won when countries faced far more dire circumstances than we face today.

And I go back to the fact that the people of Afghanistan are fundamentally on our side. Somebody asked, “Well, if they're on our side, why aren't they fighting for us?” Well, the fact is they are fighting for us. More than 250,000 Afghans are in the Afghan security forces. Only about 30,000 or even fewer are in the Taliban. Ten times more are fighting on the side of the government. And those numbers are increasing. So I urge you to stand with the brave people of Afghanistan to resist the tyranny they hate and that will threaten us if the Taliban should ever return to power.

### Moderator
Claim: Thank you, Max Boot. .

“Afghanistan is a lost cause” is our motion. We are hearing closing statements. And now to issue his closing statement for the motion, Matthew Hoh, who is the director of the Afghanistan Study Group and a former State Department official.

### Conspiracy Advocate (CA)
Claim: Thanks, John. I've been doing counterinsurgency all my adult life. Before the wars, I was stationed in Okinawa, Japan. We used to go and work with our counterparts in Thailand and Philippines and Indonesia who are all fighting active insurgencies. I've been doing this.

This is not the same as those insurgencies. It's not the same as Iraq. What we are involved in, what we're entangled in is a 30-year-old civil war that has roots that go well before the existence of al-Qaeda. We also have to-- and again, what I just said there was al-Qaeda. What effect are we having on al-Qaeda? How is this making America safer? And that's the question that you need to go home with tonight. And to be honest, you know, I'm probably the worst debater you've ever had because I really don't care who wins the debate because at the end of the night, we're all going home. But there's a hundred thousand Marines, soldiers, sailors and airmen who are in Afghanistan who, you know, it's not theoretical to them. You know, this kid named Lieutenant Robert Kelly who was killed just yesterday. His family is not having a hypothetical debate on these issues. This is very real for a lot of people.

And it's something that, when you go home tonight, keep in mind, and keep thinking about it, and keep talking about it. You know the percentage of people who voted on this issue in the midterms? Less than eight percent. So these guys all have great books, and I encourage you to go and read their books. And I encourage you to do your research on your own on this and to talk about it with your friends and neighbors, because, like I said, we go home tonight, there are a hundred 100,000 American soldiers, sailors, airmen, and Marines who are not going home tonight, and some of them will never go home. So just please keep that in mind.

### Moderator
Claim: Thank you, Matthew Hoh. Our motion is "Afghanistan is a lost cause." And now summarizing his position against the motion, Peter Bergen, a journalist and co-director of the New America Foundation's Counterterrorism Strategy Initiative.

### Scientific Advocate (SA)
Claim: I'd also like you to think about the 3,000 families who didn't have anybody come home on the night of September 11th. And that's just as important a sacrifice and it's something we cannot let happen again.

And I'd also like you to think about the history of Afghanistan. Think about the Soviet invasion that killed a million Afghans and made five million of them homeless. That was a lost cause. Think about the Civil War where hundreds of thousands or more Afghans then died. That was a lost cause. Think about the Taliban. I don't need to detain you with what they did to the country. That was a lost cause. It's not surprising that 68 percent of Afghans have a favorable view of the U.S. military and 42 percent of them blame the violence in the country on the Taliban and only three percent on NATO and the United States because they well understand what a catastrophe it would be for the Taliban to come back. 70 percent of Afghans have a favorable view of the future. They know what they're living through is better than anything in the last 30 years. They don't think it's a lost cause. Don't take our word for it. Think about what they think about as they go to work without having the Taliban ruling over them in a brutal and incompetent method every day.

### Moderator
Claim: Thank you, Peter Bergen. Our motion is "Afghanistan is a lost cause," and summarizing his position for the motion, arguing that Afghanistan is a lost cause, Nir Rosen, journalist and author of "Aftermath: Following the Bloodshed of America's Wars in the Muslim World."

### Conspiracy Advocate (CA)
Claim: Peter said that the refugees from Iran and Pakistan have gone home. They've gone home because Iran and Pakistan expelled them from there so they could go back to Afghanistan. He also said that Washington, D.C. is more dangerous. It's true in a certain sense. You may be killed by criminals there. But there's no insurgency there. It's not the police and the State that are being attacked in D.C. as they are in Afghanistan where there is just no-- you cannot have a State in most of the country these days because they're being undermined. And a white person like Peter cannot walk in most of Afghanistan without being kidnapped by criminals or killed by the Taliban or just held for ransom. We're destabilizing Pakistan, a key country with nuclear weapons and a rivalry with India, much more dangerous and much more problematic than Afghanistan.

We're even doing counterinsurgency in Pakistan these days. In Kandahar it's just going back to massive military sweeps using a warlord, not the Afghan army, a warlord who in the past has pushed people into the hands of the Taliban. Al-Qaeda-- you've never had an Afghan, except for one guy, ever try to attack Americans, and that's Zazi. So you don't have any kind of history of Afghan Taliban trying to attack the U.S., they're a very local nationalist group, obviously very retrograde. In fact, this is what’s so depressing with the situation. We’ve managed to make in the eyes of many Afghans the Taliban look good, this is how incompetent we’ve been until now. This is not the first surge, this is the fifth surge. We keep on trying more and more of the same thing. The generals are begging, "Just give us a little bit more time." So far there’s no sign that it’s working. Why would you trust them? I mean, they have a history of lying. Petraeus in 2004 wrote a letter to the "Washington Post" talking about how great the Iraqi security forces were. Just a few months later they were involved in brutal attacks against the Iraqi population. Finally, if you want to defeat al-Qaeda, you have to at some point address the grievances.

We’re supporting dictatorships throughout the Middle East, we’re backing Israel blindly, there are specific reasons why there are people in the Muslim world who resent the U.S. Or you could ignore it and say, "Okay, we want to have cheap oil. We want to be this empire that supports dictatorships in Pakistan, Egypt, Saudi Arabia." As a result of that, though, you’re always going to have a small group of people who are going to want to seek revenge unless we change who we are at some point.

### Moderator
Claim: Thank you Nir Rosen. And that concludes our closing statements. And now it’s time to find out which side in your judgment has argued best. We’re going to ask you once again to go to the keypad at your seat and register your vote. And we’re going to get the readout almost immediately. Press number one if you’re for the motion "Afghanistan is a lost cause." Press number two if you’re against. And press number three if you’re undecided-- you came undecided or remain undecided. And we’re going to have the results actually almost instantaneously. While the results are being tabulated I just want to thank you in our audience for your comments and for your questions and for your participation.

I also want to thank these four panelists, all of whom have been in Afghanistan and know of which they speak. They came here with sharp disagreements, but they honored the spirit of debate by honoring one another by hearing them-- each other's arguments out. Our congratulations to them for what they did. The last debate of our fall season is going to be on Monday, November 22. The motion is: U.S. airports should use racial and religious profiling. Panelists for this motion are Robert Baer, a former CIA agent who was based in the Middle East. His book “See No Evil” inspired the movie “Syriana.” Deroy Murdock is a syndicated columnist and a fellow at the Hoover Institution and Asra Nomani, a former Wall Street Journal reporter and co-director of the Daniel Perl Project.

Against the motion, Debora Burlingame, whose brother was the pilot of the American Airlines Flight 77 which crashed into the Pentagon on September 11th.

Michael Chertoff, the former Secretary of Homeland Security and Hassan Abbas a Columbia University professor and a former official in the Benazir Bhutto and Pervez Musharraf administrations. Tickets for this are still on sale, available through our website and at the box office upstairs at the Skirball Center. And don’t forget to follow Intelligence Squared U.S. on Twitter and to make sure you become a fan of us on Facebook. If you do, you’ll get a discount on our upcoming debates.

Starting on January 11, we’re going to be focusing all of the debates on a single theme through our Spring season. All five debates will be related under this umbrella topic of “America, a house divided.” We’ll be looking at the two-party political system, our declining global influence, energy policy, immigration reform and income inequality. We’re still working on the exact language of the motions and booking the debaters. All of our debates though, including this one and the sound of your own applause, can be heard starting next week---- on NPR stations across the nation and on the Bloomberg television network, starting next Monday, on Bloomberg at 9 p.m. and if you visit Bloomberg.com you can find out where to get that on your local channel.

All right. It’s all in now. I’ve been given the final numbers. Remember, the team that changes the most minds here is declared the victor and here it is. Our motion: America is a lost cause. Before the debate, 46 percent were for the motion. America’s a lost cause? I-- you know, I want to talk about Washington being a lost cause and it got me thinking. Thank you so much for your laughter and helping me to edit this. Our motion: Afghanistan is a lost cause. Before the debate, 46 percent were for the motion, 23 percent were against, 31 percent undecided. After the debate, 51 percent are for the motion, that’s up five percent, 36 percent against, that’s up 13 percent, with 13 percent undecided.

The side against the motion carries this debate. Our congratulations to them. Thank you from me, John Donvan and Intelligence Squared U.S. We’ll see you next time.
