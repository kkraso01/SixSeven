# Debate Transcript

Topic: Legalize Assisted Suicide
Motion: Legalize Assisted Suicide

Debate ID: 111314%20Assisted%20Suicide


## Round 1

### Moderator
Claim: So, spontaneous applause moment number one, please, let's welcome Robert Rosenkranz to the stage.

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hi, Bob.

So, Bob, one thing we wanted to clarify, the motion language is very tight. Three words, shorter than we normally have. It sounds very obvious, but we-- we mean something specific when we say, "Legalize assisted suicide," whose meaning could be more ambiguous than it sounds.

### Moderator
Claim: Well, I think what we mean is legalize physician-assisted suicide.

### Moderator
Claim: Okay. We want to be clear about that, because it's not broadly used--

### Moderator
Claim: So that’s what we’re talking about.

### Moderator
Claim: And the other thing we were chatting backstage beforehand, a sort of interesting perspective that you have on this topic.

You know, you've done a lot of things in your-- you've got-- had a number of careers behind you, and you were talking about that, number one, you've been an insurance executive, and number two, you've been a lawyer. And you, looking at this topic, those two perspectives gave you kind of interesting insight on this. So start with the insurance executive side of it first.

### Moderator
Claim: Well, our insurance company ensures about 8 percent of the U.S. labor force against catastrophic injuries at work. So, I see a lot of case of people who are really, really seriously injured. I saw one just last week, of somebody who is now a quadriplegic and going to be bedridden for the rest of their lives, to 30-year-old who has a life expectancy of 30 years.

And a person like that, who might decide that life is not worth living cannot end it except with assistance. And yet the statute doesn't really cover them. The statutes at least in Oregon and-- and Washington only refer to terminally ill. So, in some ways, you know, the-- the statutory issue is narrower than what I think might be the issues that-- that ought to be discussed tonight.

### Moderator
Claim: And that gets to the lawyer side of your experience. You went and sat down and read the statute, and you came back with some interesting responses.

### Moderator
Claim: Well, the other-- the other thing-- requirement of the statute besides terminal illness is that person has to be capable of making a decision. And that term "capable" is not defined. And indeed they talk about-- the statute talks about an ability to communicate their decision in ways that imply that the person is barely able to communicate at all.

So, you know, maybe just shaking their head or squeezing a hand or blinking an eye or something like that, which the implication is that it would be very, very hard to actually assess their mental acute or their ability to make these critical decisions. So, that just struck me, as a lawyer, as a pretty troublesome bit of legal draftsmanship in this question of who is capable legally of deciding whether to invoke the statute for legally assisted suicide.

### Moderator
Claim: So, what's interesting in this one is there is this clash of principles that runs right into practicalities and the practicalities, the details leave all sorts of room for interpretation.

### Moderator
Claim: I mean, the more you think about this, the more complicated it gets. And it is a very, very highly emotional issue for a lot of people, and it's going to touch their lives in very profound ways.

But we're talking about legalizing something, which means passing a statute, and therefore you've got to pay some attention to the language of that statute and what the limitations are and what the ambiguities are.

### Moderator
Claim: Well, we do have four debaters who are very, very well versed in this, and they are passionate about it, so let's welcome them to the stage. Ladies and gentlemen, our debaters.

Thank you. And I would just like to invite one more round of applause for Bob Rosenkranz for bringing this to us.

Sometime numbers can tell a simple story.

So, here are some numbers from Oregon which has had a Death with Dignity act since 1997, allowing individuals with terminal illnesses to get lethal prescriptions from their doctors to take their own lives. In the first 17 years of that program, the number of people who actually took their lives when they had the pills: 752. 94 percent were Caucasian. More than half had finished college. Median age: 71. Roughly divided between men and women. Some more interesting numbers: 400 people in Oregon got the pills but never took them. And a much larger number asked for the pills but were denied, five out of six were denied according to one early study. So the problem with all of these numbers I've just recited is that they actually don't tell a simple story and they don't answer the essential question of the rightness and wrongness, the morality, and the practicality of what is called "physician-assisted suicide" or sometimes "assisted dying," because it's not that obvious.

And getting at it is really something that will take a good solid debate, so let's have it, "Yes," or, "No," to this statement, "Legalize Assisted Suicide," a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufman Music Center in New York City. We have four superbly qualified debaters, two against two, who will be arguing for and against this motion, "Legalize Assisted Suicide." As always, our debate goes in three rounds, and then our live audience here in New York votes to choose the winner, and only one side wins. Our motion, "Legalize Assisted Suicide," and let's meet the team arguing for the motion. Please, ladies and gentlemen, let's welcome Peter Singer.

And, Peter, you are a professor of bioethics at Princeton. You have written some classic books, "Animal Liberation," "Practical Ethics." You are often described as-- and wait for this-- "the world's most influential living philosopher."You subscribe to a theory of ethics called, "utilitarianism." If you could explain that in one sentence, what would it be?

### Conspiracy Advocate (CA)
Claim: Sure, in one sentence, utilitarianism is the view that the right thing to do is the act that will have the best consequences, all things considered, of the options open to you.

### Moderator
Claim: You nailed it in one sentence.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Thank you, Peter Singer. Did I add-- did I-- did I add an extra syllable-- I said, "utilitarianism."

### Conspiracy Advocate (CA)
Claim: That's correct.

### Moderator
Claim: That's right?

extra syllable. And please tell us who your partner is.

### Conspiracy Advocate (CA)
Claim: My partner is Andrew Solomon. Andrew's a writer who's written very movingly about this issue. He's also a public speaker. And if you look at the talks he's given on TED, TED.com, you will find that eight million people have viewed them, whereas my talk has only been viewed by one million.

### Moderator
Claim: Ladies and gentlemen--

--ladies and gentlemen, Andrew Solomon.

Please welcome Andrew Solomon. Thank you. Andrew, a lot of your story was just told. You are a professor of clinical psychology at Columbia. You are an award winning author of several books, including "Far from the Tree: Parents, Children, and the Search for Identity," and "The Noonday Demon." You have also written about your family's own experience with assisted suicide, and, in an article from 1995, you note that back in the '90s no one wanted to hear about it or ask about it, that the subject was completely taboo. Now it's legal in five states and 20 years have gone by, have times changed? Is the subject still taboo?

### Conspiracy Advocate (CA)
Claim: Well, it's somewhat less taboo, but in a society in which people tend to be in denial about the reality of mortality altogether, getting them to talk about this is still frequently a struggle. But I think speaking about it openly, as we are doing tonight, is one way to help people be less afraid to tell their families or to tell their doctors what they actually think and feel.

### Moderator
Claim: We will be discussing it tonight, thank you, Andrew Solomon.

Our motion is "Legalize Assisted Suicide." And we have two debaters who will be arguing vociferously against this motion. Please let's welcome Baroness Ilora Finlay.

Baroness Finlay is a member of the House of Lords, and after this she is just "Ilora." She has agreed that while she's here in the former colonies she will drop the honorific.

She is, more importantly, a palliative care physician. She is president of the British Medical Association, and she comes to this debate with a personal story that she will share later on as well. But she's also, as I said, a member of Britain's House of Lords where an assisted suicide bill is being considered. And, Ilora, doctors everywhere are for the most part opposed to these laws, but the majority of the public most everywhere support it, how come?

### Scientific Advocate (SA)
Claim: Well, I think it's important to remember that doctors know the complexities of trying to do assessments as to whether somebody really wants this or not and all the other issues that would have already been touched on.

They also know about advances in medicine and that things today are very different. Most of the public sees stuff on the media that looks scary. They're scared about their own dying and we're all going to die. And they also often have memories of things that might have happened a quarter of a century ago.

### Moderator
Claim: I'm going to stop you right there because I think you're getting into your debate material.

### Scientific Advocate (SA)
Claim: Oh, I'm sorry. I'm just so enthusiastic.

### Moderator
Claim: Thank you. Ilora Finlay.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: And tell us, please, who your partner is?

### Scientific Advocate (SA)
Claim: I'd like to introduce the kind, caring Dr. Daniel Sulmasy, who has studied this in-depth--

### Moderator
Claim: Ladies and gentlemen--

### Scientific Advocate (SA)
Claim: and is a physician.

### Moderator
Claim: --ladies and gentlemen, Dr. Daniel Sulmasy.

And Daniel, you're-- you wear several hats. You're also arguing against the motion, "Legalize Assisted Suicide," but you wear several hats. You're a professor of medicine and ethics, and-- at the Department of Medicine and Divinity School at the University of Chicago.

You also have been a member of the presidential committee on the study of bioethical problems since 2010. You have an MD and a PHD. What we're wondering is, you know, with these hats you wear-- medicine, ethics, religion-- do they clash or do they work well together?

### Scientific Advocate (SA)
Claim: I think, in some ways, what it really means is I have too many bosses. But beyond that, they fit together seamlessly for me, really. I mean, doctor, when you think about it, means "Teacher." And I try to just be a good teacher for my ethics students, for my medical students, and for my patients.

### Moderator
Claim: Well, we'll be getting some teaching you-- from you tonight, I imagine. Ladies and gentlemen, the team arguing against the motion.

And those are our four debaters. And to remind you, this is a debate. It's a contest of persuasion with ideas, logic. And you, our live audience here in New York, will be serving as our judges in picking the winners of this contest. By the time the debate has ended, you will have voted twice-- once before the debate and once again after the debate.

And the team whose numbers have moved the most in percentage point terms will be declared our winner. So, let's have the preliminary-- the first vote now. If you go to the keypads at your seat-- you see a set of numbers on them? Just pay attention to 1, 2, and 3. If you agree with this motion at this point, Legalize Assisted Suicide, push number 1. If you disagree, push number 2. And if you're undecided, push number 3. You can ignore the other keys. They are not live. And if you push the wrong one by mistake, just correct yourself and the system will lock in your last vote. And we'll lock it out in about 10 seconds. Okay. It looks like we're good. We're going to move forward. We go in three rounds. Let's begin with Round 1. Round 1. Our motion is Legalize Assisted Suicide. Here we have opening statements from each debater in turn. They'll be-- they will be seven minutes each. And here to make his first opening statement, supporting the motion, Legalize Assisted Suicide, Andrew Solomon.

He is a professor of clinical psychology at Columbia University, author of the book "Far from the Tree: Parents, Children, and the Search for Identity." Ladies and gentlemen, Andrew Solomon.

### Conspiracy Advocate (CA)
Claim: Because much of modern medicine prolongs not living but dying, we need to rethink death itself. Making someone die in a way that others approve, but that he feels is anathema, is an odious form of tyranny. Aid-in-dying needs to be tightly regulated, as any life or death matter does, from driving to surgery. But while no one should be pressed into assisted dying, no one should be categorically denied that right. It's about dignity. In his dissent in Cruzan, Supreme Court Justice William Brennan said, "An ignoble end steeped in decay is abhorrent.

A quiet, proud death, bodily integrity intact, is a matter of extreme confidence.” And it's about reassurance. Brittany Maynard, who captured headlines for choosing to end her life at the age of 29 at the end of a battle with brain cancer, said, "It has given me peace. I do not want to die, but I am dying, and I want to die on my own terms." It's not about depression. When hope of recovery is gone, when one achieves relief from physical symptoms only at the cost of mental clarity, when – one’s dignity is lost to physical deterioration, the wish to end your life may be rational. Now, there are some people who find great meaning in those very final stages.

But there are other people who are not interested in finding that meaning. And from a non-theological point of view, it can be argued that the meaning people attach to that stage of life is an artifact of the human imagination. It's not about suicide. Suicide responds to personal disintegration while this precludes it. And it is about the limitations of medicine. It's nothing short of medical arrogance to say that palliative care and hospice can adequately deal with the end of every life. Hospice, in fact, can impose an authoritarian, hard, paternalistic view that the hospice way of dying is the only way, and it's rooted in precedent, as John said in the opening, in Oregon, where after 17 years, only 752 people have died from lethal prescriptions, which is to say .2 percent of the people in the state who have died.

As Hillary once hoped for abortion, this is safe, legal and rare, and it has popular support. According to a 2013 Gallup Poll, 70 percent of Americans support legalization of physician assistance in dying. When my mother's friend, Sandy, was dying of cancer, my mother visited and saw her in the hospital where she was screaming in pain and so heavily medicated that she was unable to recognize the other people in the room. And when she came home, my mother said, "If I ever get to that state of pain, promise that one of you will shoot me." My mother was diagnosed with ovarian cancer when she was 56. And when her first chemotherapy failed, she said that she would submit to another round of agonizing treatment only on the condition that someone got her those pills.

By the time of her third chemo, she was in dilapidated health. She was vomiting. She had a persistent malaise, she had hair loss, she was negotiating surgical adhesions, but she also had the pills. And the agony became unimportant because the symptoms were permanent only until she decided that she could take no more, and then she would be free, and so the disease was no longer in control of her. My grieving father, my mother, my brother and I talked through the logistics as though a dress rehearsal would exhaust some of the pain of the loss in advance. We planned it together, much as we had once planned parties or family vacations or Christmas. We were liberated by our newly clarified emotions, but we were entombed in the loneliness of our illegal collusion.

My mother went to see a gastroenterologist two years after she got sick, who told her that she had significant tumors in her intestines and would soon be unable to digest food. She called my brother and me, and she said that it was time. It was all very much as we had planned it. She said, "The only thing I still fear is this not going smoothly." And she took the antiemetics. A few nights earlier, my mother and my brother had pulled a wishbone, and my mother had won. And now my brother said to her, "What did you wish for?" And she said, "I wished for this to be over as quickly as possible. And I got my wish, I got my wishes so often." And then she said, "When you were children, I wanted my love to make the world a safe place for you.

And my greatest hope is that it will still wrap you up for your whole life." And she said to my father, "I would gladly have given decades of my life to be the one to go first. For 30 years, Howard, you have been my life." And then as her voice slowed with the medication, she said, "I'm sad to be going." But even with this early death, I wouldn't want to change my life for any other life in the world. I have loved completely, and I have been completely loved, and I've had such a good time. I've looked for so many things in this life, so many things. And all the time, paradise was in this room with the three of you." I've seen other deaths, and I remember feeling that they belonged to the hospital or the illness or the gun or the catastrophe.

This death was my mother's own. She was the same person in death that she had been in life, and it was her right to choose it over a death like Sandy's, and it should be everyone's right. The words "liberty" and "dignity" are nearly synonymous in death as they are in love.

### Moderator
Claim: Thank you, Andrew Solomon.

Our motion is "Legalize Assisted Suicide." And here to argue against the motion, Daniel Sulmasy. He is Kilbride-Clinton professor of medicine and ethics in the Department of Medicine and Divinity School at the University of Chicago. Ladies and gentlemen, Daniel Sulmasy.

### Scientific Advocate (SA)
Claim: As you heard, I am a physician. And part of my job is to help people die with dignity and in comfort. But I don't want to help you or your daughter or your uncle to commit suicide.

And you shouldn't want me to. I urge you to oppose physician-assisted suicide, because it's bad ethical reasoning, bad medicine and bad policy. I'm going to concentrate on the first of these, and Ilora will take up the other two. Now we strongly support the right of patients to refuse treatments and believe physicians have a duty to treat pain and other symptoms even to the point of hastening death. But empowering physicians to assist patients with suicide is quite another matter. Striking at the heart not just of medical ethics, but of ethics itself. That's because the very idea of interpersonal ethics depends upon our mutual recognition of each other's equal independent worth, the value that we have simply because we are fellow human beings.

Some would have you believe that mortality-- that morality depends upon equal interests, usually defined by preferences, and of advanced utilitarian arguments based on that assumption. But which is more important: people or their preferences? As Aristotle observed, small errors at the beginning of an argument lead to large errors at the end. If interests take preference over the people who have them, then assisting the suicide of a patient who has lost interest in living is certainly something that would be morally praise worthy. But it would also follow that active euthanasia ought to be permitted, that the severely demented could be euthanized without their explicit consent, even experimented upon. And it also follows that infanticide ought to be permitted for children with congenital illnesses. Now, many might see these as frightful conclusions, but this is not just the slippery slope.

These all follow logically from arguing for assisted suicide on the basis of maximizing our individual interests. So, if you don't believe in euthanizing severely disabled children or the demented, you might want to rethink your support for assisted suicide, at least if you want to be consistent. Now, is assisted suicide death with dignity? The word "dignity" has at least two senses. Proponents, like the one you heard, use the word in an attributed sense to denote the value others confer on them or the value they might even confer upon themselves. But there's a deeper, intrinsic sense of dignity. Human dignity ultimately rests not on a person's interests, but on the value of the person whose interests they are. I don't have to ask you what your preferences are to know that you have dignity.

And Martin Luther King says that he learned this from his grandmother who told him, "Martin, don't let anybody ever tell you that you're not a somebody." Somebodiness, this intrinsic sense of dignity, was at the heart of our civil rights movement. And the message is that it doesn't matter what a person looks like, how productive that person might be, how others view that person or even how that person may have come to have viewed herself. What matters is that everybody, black or white, sick or well, is a somebody. Now, assisted suicide and euthanasia require us to accept that it is morally permissible to act with the specific intention of making a somebody into a nobody, to make them dead. Intentions, not just outcomes, matter in ethics.

Intending that somebody be turned into a nobody violates the fundamental basis of our interpersonal ethics, our intrinsic dignity. We live in a society that worships independence, youth, and beauty. Yet we know that illness and aging often bring dependence and disfigurement. The terminally ill, especially, need to be reminded of their intrinsic dignity at a time of fierce doubt. They need to know that their ultimate value doesn't depend upon how they look, how productive they are, or their independence. You see, assisted suicide flips the default switch. The question the terminally ill hear, even if never spoken, is "You've become a burden for you and for us.

Why haven't you gotten rid of yourself yet?" Now, a good utilitarian might think that a proper question, even a moral duty, but as a physician who cares for dying patients, I am much more fearful of the burden this question imposes on the many who might otherwise choose to live, than the modest restriction imposed on a few when assisted suicide is illegal. Assisted suicide should not be necessary. If it's pain and other symptoms you fear, they can almost always be alleviated. As evidence, consider that pain or other symptoms rarely come up as the reasons for assisted suicide. The top reasons are: fear of being considered a burden and wanting to be in control. Now, you may ask, "Why shouldn't I have this option?" and yet we all realize that society puts many restrictions on liberty and for a variety of reasons, to protect others, to promote the common good, to safeguard the bases of morality and law.

For example, we don't permit persons to drive drunk or to freely sell themselves into slavery. Paradoxically, in physician assisted suicide and euthanasia, patients turn control over to physicians who assess their eligibility and must provide the means. And, further, since death obliterates all liberty, saying that respect for liberty justifies the obliteration of liberty actually undermines the value that we place on human freedom. Now, Ilora and I live our lives dedicated to supporting patients and families, to listening to patients at the end of life, to relieving suffering, and to valuing them to the end.

That's why you shouldn't vote for assisted suicide.

### Moderator
Claim: Daniel Sulmasy, I'm sorry your time is up. Thank you very much.

### Scientific Advocate (SA)
Claim: That's why you shouldn't vote for assisted suicide.

### Moderator
Claim: Thank you. Daniel Sulmasy.

And a reminder of what's going on, we are halfway through the opening round of this Intelligence Squared U.S. Debate. I'm John Donvan. We have four debaters, two teams of two, arguing it out over this motion, "Legalize Assisted Suicide." You have heard the first two opening statements, and now on to the third. I'd like to welcome to the lectern Peter Singer. He is--

--let me just say this, Peter Singer is the Ira W. DeCamp professor of bioethics in the University Center for Human Values at Princeton and laureate professor at the University of Melbourne. Ladies and gentlemen, Peter Singer.

### Conspiracy Advocate (CA)
Claim: Thank you. Let's be clear what we are debating this evening. It's "Legalize Assisted Suicide." It's not "Put Utilitarianism into Practice," and it's also not anything further to do with other areas in which one may or may not think that sometimes death is preferable and ought to be provided.

That is not the topic. You're asked to discuss-- to focus only on this quite narrow question. Now, if you think about that question, we are, of course, influenced by the idea that normally death is a bad thing. We often think of it as the very worst thing that can happen to us. But if we ask ourselves why that should be, "Why is death a bad thing?" then we can think that there are a variety of reasons in normal circumstances. For instance, people want to go on living, so death is contrary to that very strong wish that people have. It violates their autonomy. If somebody else in particular kills them, it normally violates their autonomy, which is something that we ought to respect. Secondly, death ends your life, and most of us think of life as a positive, as a good thing, fortunately.

So, it prevents you from continuing to live that life that you find worthwhile, that you find fulfilling and rich, that brings you happiness and other values. And, thirdly, death is a bad thing for those who love and care for the person who dies. It's a source of grief to them that someone they love dies. So that's why normally, of course, we should not promote death, let alone kill people. But there are very special circumstances in which none of these things apply, and that's what we're talking about tonight. There are circumstances in which the person who is considering death wants to die. That is their autonomous choice. So, death is not a violation of their autonomy, or contrary to their strongest wishes. But it's in accordance with them, as Andrew described in the case of his mother just now.

Secondly, there are cases in which a person has no more valuable life to look forward to, valuable by their judgment, not valuable by somebody else's judgment imposing on them the idea that their life is still worthwhile, even though they, having thought the matter through-- perhaps having thought it through for many years-- again, as in the case Andrew described, have decided that life would not be worth living for them under some circumstances. And in particular, if they have only a short time to live, as in the case of the statutes in Oregon and Washington, and now Vermont as well, then they know that they cannot look forward to more years of happiness. And as for the grief that those who love them will feel, of course they will feel that grief if they die now. But in the cases covered by these statutes, where people are terminally ill and likely to die-- two doctors certify that they will die, they have less than six months to live, then the family is going to grieve anyway.

And the caring family-- like Andrew and his brother-- will at least feel that the person they love got to die at a time of their own choosing. And that's important. Now, in fact, this idea that this is sometimes a good thing is recognized by our opponents. Daniel Sulmasy just said that sometimes it's justifiable to relieve patients' pain, if you're hastening death. It's not the hastening death that they object to, because they acknowledge that you can withdraw treatment that would keep patients alive-- sometimes would keep patients alive for a long time. It's the intention of ending a patient's life that they object to. But we don't have to accept that morality. That's a specific morality which Daniel Sulmasy is free to hold, of course. And if he-- as he said at the beginning-- would not like you-- to help you end your life, that's entirely up to him. Nobody is suggesting he should be compelled to end anyone's life against his conscience.

But if a different doctor-- and there are such doctors-- is willing to do that, indeed, thinks that that's the best final care that he can give to a patient who he can no longer restore to a situation that the patient considers worthwhile, then I don't-- I don't think we should be hung up by this idea that something is somehow always a wrongful intention, even if in normal circumstances, to aim at someone's death would be a wrongful intention. But not in these circumstances. In these circumstances, it may be the right intention. Now, I'm sure we're going to hear from probably Ilora Finlay, I guess, that there are risks – that this is a dangerous thing-- that it will lead to a slippery slope. That argument has been around in this debate for a long time. I think that when I first became interested in this question-- which now goes back about 40 years.

That that was an argument that you had to treat very seriously and had to give a lot of weight to. And I could not be completely sure that it was not justified. But now we have much more experience of the legalization of assisted suicide. We have, in the Netherlands-- in fact, more than 30 years' experience of the open practice of-- by the medical profession, with the support of the Royal Dutch Medical Society-- not against the doctors' views-- of that practice. And with its full legalization, about 14-- about 12 years ago. And fully supported by the Dutch population, so that although there's been a succession of governments-- some conservative, some more liberal, one of them under a Roman Catholic prime minister-- they have not ever sought to repeal the legislation. And similarly, in Oregon, we now have 17 years of experience, a relatively small number of people dying each year.

And as you heard, more of them requesting the prescriptions, but not using them, because they want the control. They want to know that they could end their life if they want to. So, with that experience, the experience of Belgium as well, which followed the Netherlands, its neighbor, and then Luxembourg, and then also Washington-- the state of Washington, the neighbor of Oregon, which was watching what was going on there, and decided that was a good system that they wanted, and therefore accepted it-- we have not seen a slippery slope here. We have, in fact, found that these-- this legalization is something endorsed by the populations concerned and supported by it, and they want it to continue. Thank you.

### Moderator
Claim: Thank you. Peter Singer.

Our motion is Legalize Assisted Suicide. And here is our final debater making an opening statement against the motion. Ilora Finlay, she is a leading palliative care physician. You can make your way to the lecturn. She is president of the British Medical Association. She is a member of the House of Lords. Ladies and gentlemen, Ilora Finlay.

### Scientific Advocate (SA)
Claim: Thank you. I'm a palliative care physician. For over a quarter of a century, I've looked after dying patients, thousands. I've had countless conversations about death and dying, and supported each in what they tell me they need, not some kind of formulaic death. But I've seen despair return to enjoy life in new found, unexpected and treasured ways. It is through compassion that I see how dangerous it is to license doctors to provide lethal drugs. How much assistance is needed? Well, euthanasia, as practiced in the Netherlands by and large, more than physician-assisted suicide, is the injection of lethal drugs. Here in the U.S., that seems to be reserved for a state execution. It's pretty much the same drugs used. But let me tell you about someone.

Let me tell you about David, aged 36. His spinal tumor was causing very difficult pain and incipient paraplegia. His surgeon, oncologist, and family doctor all thought his prognosis was three months. And I was asked to see him only because his doctors couldn't give him a lethal injection. He seemed a very clear-cut case for assisted suicide. When I saw him, the distress was palpable. Their third child was six weeks old. David fitted every criteria of every bit of legislation I have ever seen. He had a clear, settled wish, had mental capacity, was not being coerced and was very, very distressed. It was October. I thought he'd be dead by Christmas. So what happened? After some persuasion, careful, gentle persuasion, he accepted my input. And gradually, he lost the wish to die. 11 years later, he phoned me. His lovely wife had pancreatic cancer and was dying. That baby, now 11, sat with his sister, brother, and dad holding his dying mum's hand. Is David an exception? No. He illustrates all the problems with proposals for assisted suicide. Let's look briefly at what happens in states which have changed the law. Over 16 years of Oregon's law, assisted suicides have risen four and a half to fivefold. In Washington state, which legalized assisted suicide in 2008, the rate of rise is fast deeper; 43 percent in one year alone. When you normalize physician-assisted suicide, the underlying social dynamic changes. Laws aren't just regulatory instruments.

They send a message. And the message they send is that if you're terminally ill, ending your life is something that you probably ought to think about. Indeed, in Holland, when they changed their law, they thought their figures had plateaued, but they've actually doubled. And in Belgium, the Belgians are quite frank about the fact that they know that somewhere around about half are actually happening outside the law. Changing the law isn't simple and straightforward. So, what are some of the problems? Well, let's look at prognosis. Prognoses are notoriously inaccurate. Even the most expert have a 50/50 chance of being wrong over life expectancy of six months. Oregon's law requires a prognosis of six months or less, yet two years, nine months from request to death has been recorded. Pathologists tell us that at postmortem, about 1 in 20 are found to have died from something different to the condition they were being treated for.

And how real is a settled wish? 40 percent of seriously ill people have some mental disturbance often attributed to the illness or anxiety or treatment. And in 13 to 14 percent, this is a major, treatable depression. Yet Oregon's own research shows a quarter of those seeking assisted suicide have depression, which is sometimes missed or overlooked. And research into a sample showed one in six of those given lethally-- lethal drugs legally supplied actually had an undiagnosed, untreated depression. The researchers themselves said the current practice of Death with Dignity Act may not adequately protect all mentally ill patients. Capacity, it has to be situation-specific, decision-specific. How do you assess capacity commensurate with the biggest decision that you could take; that to end your life? Only 6 percent of Oregon's psychiatrists feel confident to do it.

Pressures are harder to pick up than depression. Coercion can be subtle, the costs of care, life insurance about to expire or just caregiver fatigue, the person who picks up that their family are stressed and doesn't want to be thought of badly. After all, most parents love their children, but not all children love their parents. And dignity, research has shown that the way that care is delivered enhances or undermines dignity. Cicely Saunders of the hospice movement said, "Dignity is having a sense of personal worth." Yet in Oregon, 40 percent, and in Washington, 61 percent cite concerns of being a burden, and 80 percent are concerned at losing their dignity. Are they being made to feel their lives are an inconvenience to be disposed for the sake of others? And what of doctors? Like it or not, you rely on your doctor.

For the doctor under pressure, it is all too easy to give into the pressure to prescribe. Doctors must recognize dying, not impose futile treatments and relieve distress. But I do not think they should be licensed to cut off life by weeks, months or years. Remember David? I saw him last weekend, 23 years on from that first referral. And he said I can tell his story. He brought up the children alone, fantastically well. But what would have happened if his doctor had been able to accede to his request? It is too dangerous to license doctors to prescribe lethal drugs for suicide. Please vote against this utilitarian motion. And it is utilitarian.

### Moderator
Claim: Thank you, Ilora Finlay.

## Round 2

### Moderator
Claim: And that concludes round one of this Intelligence Squared U.S. debate where our motion is "Legalize Assisted Suicide."Now we move on to round two. And round two is where the debaters can address one another directly, and they will take questions from you and from me. Our motion is this: "Legalize Assisted Suicide." And in our opening statements, we heard one team arguing for the motion, Andrew Solomon and Peter Singer, making the case that we need to rethink death in this country, that the principal here really is one of choice and that if the instruments are available to people who are in the last phases of their life to choose the time and the manner of their dying, then that should be their right. They say that in practice, in Oregon and other states, this practice has been demonstrated to be safe, legal and rare, and for the medical physician to oppose this is an act of arrogance. The side arguing against the motion, Ilora Finlay and David Sulmasy, they're both physicians, by the way, and both want to part of assisted suicide.

They make the argument that to assist in taking somebody's life is to make a somebody into a nobody and that that is plainly and morally wrong; that assisted suicide, aid in dying, is bad ethical reasoning, bad medicine and bad policy. They also say that there are alternatives to assisted suicide for people who are suffering in life, such as palliative care and that our knowledge of death is so full of holes that it should not be something that doctors are handing out in the form of a pill. I want to go to the side that's arguing for the motion. And I want to go to Andrew Solomon who told a very powerful story about your mother and about your argument for personal choice. And I want to ask you-- I want to say to you that I believe your opponents are acknowledging the power and force of personal choice. They're just saying that there are other interests that are-- are larger and greater than that, that the personal choice that your mother made and that today more legally other people are making has social implications that ripple through society and affect all of us.

Basically, they're saying that there is no such thing as just a personal choice that affects one person, that it's broader than that. I wonder do you concede that point?

### Conspiracy Advocate (CA)
Claim: Well, I think that actually we send a very dark message to the society at large when we say to people that they don't have the right to make these decisions, when we say to people that we look at their suffering and their anguish, and we refuse to help or support them. I think that sends a social message. I think people have a difficult time speaking openly and directly to doctors if they know that what they are discussing is illegal, and they don't know what their doctor's legal or ethical position on it is going to be.

### Moderator
Claim: Andrew, can I-- can I stop you there, because to a degree, you made that point in your opening statement, and I don't want to suppress that point of view. But what I'm really trying to get at is whether the negative consequences that your opponents are talking about, do they exist, are they real, and are they simply outweighed by the interest of personal choice, or do they not exist?

### Conspiracy Advocate (CA)
Claim: I think that a shift of this kind always has a range of social consequences, so I cannot say that they don't exist at all, but I would say that to me they are vastly outweighed by the benefits that are gained.

### Moderator
Claim: Okay. And I want to go to the other side and take this to Daniel Sulmasy, the issue of personal choice, which I think is very much what your opponents' essential argument is, and it's something that obviously we all enjoy and value. And you're making the argument that it's not the only thing that's at stake here. Can you go on with that?

### Scientific Advocate (SA)
Claim: Sure. Now, I certainly am a supporter of patients' rights. They have the opportunity to refuse all kinds of treatments that we give them. There's no need, for instance, for your mother, Andrew, to have gotten the chemotherapy that she got that was making her sick. All those sorts of choices need to be honored and respected. But it is not the case that suicide is simply a self-regarding act.

A psychiatrist at Massachusetts General Hospital, Ned Cassem, says that when a patient asks about suicide, he begins to ask them, "In whose closet do you intend to leave your skeleton?"

### Moderator
Claim: Well, not quite--

### Scientific Advocate (SA)
Claim: The sense that it is interpersonal, right, that this is going to be something that is an act of communication to other people, it says something in that sense, it is always something that impacts other people, and it can't be considered simply a self-regarding act to commit suicide.

### Moderator
Claim: So, you're saying it's not entirely private, that it also is public--

### Scientific Advocate (SA)
Claim: Correct.

### Moderator
Claim: --ways that--

### Scientific Advocate (SA)
Claim: Correct.

### Moderator
Claim: --maybe Peter Singer disagrees with. Peter Singer.

### Conspiracy Advocate (CA)
Claim: Look, I do disagree with it. I mean, there's a sense in which none of us is an island and every act could be seen as having some ramifications socially. But this one is one that I think has very few. And I don't think that the implication that if you end your life somehow you've left a skeleton in the closet, that seems nonsense to me.

And, after all, you're making a decision, why wouldn't you say the same to the patient who says, "I don't want any more treatment"? You know, you say patients have the right to refuse treatment, you say that Andrew's mother didn't need to have the chemotherapy, but, you know, why wouldn't you say-- why couldn't the doctor say, "Look, this could keep you alive, maybe even you'll live for another 23 years, who knows?" like David? You know, you can't exclude it, but you're quite happy to say to people, "You can refuse treatment, you can withdraw burdensome treatment of various kinds-- the doctor can do that, you don't have to accept it," so I don't see really there's such a big difference in terms of the ramifications here of, in both cases, a patient's decision not to do what will prolong their life.

### Moderator
Claim: Okay, well, I mean, this has to get philosophical to some degree. And I want to have you, Ilora Finlay, take that. So, what is the difference between a patient asking for pills to end his or her life in the last two weeks if it's presumed the last two weeks and asking to be taken off life support in presumed the last two weeks, and dies in both cases?

### Scientific Advocate (SA)
Claim: They are actually completely different decisions. The person on life support is in a way being held in that state some-- to someone with disease artificially, but that disease is progressing. What you're talking about here is somebody where their disease may stop progressing, they may actually get much better and improve, but you're making a decision to cut their life off deliberately. And so they're dying of that lethal overdose and they're dying long before they may have died of their disease because you just can't tell. And that's the problem. If you make a decision in life, you must have accurate information. And what I'm saying is, don't kid yourself that information about prognosis is accurate because it isn't.

### Conspiracy Advocate (CA)
Claim: But why doesn't that apply to a decision to withdraws a ventilator.

### Moderator
Claim: Peter Singer.

### Conspiracy Advocate (CA)
Claim: I mean, have you never seen a patient where a doctor said, "I think we should take the ventilator away," and the patient actually lived quite a lot longer?

### Scientific Advocate (SA)
Claim: That does happen occasionally, yes, but they are dying of their disease. And you shouldn't be giving people treatments that you think are not achieving a benefit because they're futile. So if the person doesn't want to be-- have a treatment, they can refuse it. Ventilation is a treatment, and if they decide to refuse it, then they can, and I as a doctor must support them. But that is quite different to me, deliberately assisting their suicide because what happens is then you stop actually actively trying to make the day in front of you better than it would have otherwise been--

### Moderator
Claim: Andrew--

### Scientific Advocate (SA)
Claim: And even if it's the role

### Moderator
Claim: Let me-- no, let me Andrew Solomon and then I'll come back to you, Daniel. Andrew Solomon.

### Conspiracy Advocate (CA)
Claim: Withdrawal of life support equipment requires a much more active role for the physician than the prescription of medication that someone can use to bring about the end of their own life.

It involves the physical removal of equipment. It usually involves the administration of morphine to ease the person through the dying process. There's a great deal that a physician has to do. And this idea that somehow, that it's something that is natural, and because it's natural, it's okay, and the other thing that is somehow unnatural seems very distorted to me. Because--

### Moderator
Claim: Daniel. Daniel Sulmasy.

### Scientific Advocate (SA)
Claim: No, this-- first of all, that's not what we're saying and that's not a reasonable way to defend the distinction between killing and allowing to die. I think one way of putting the difference, from a moral point of view-- at least from our perspective-- is that treatments can be considered and futile and terminated. But patients should not be considered futile and terminated. And that's the difference, intentionally, in the structure of what we're doing, right? So, if somebody's on a ventilator, right? And I stop it, my intention is not that they should be dead.

My intention is that they be discontinued from a treatment that I think is needlessly causing suffering, prolonging their dying--

### Moderator
Claim: But you don't decide.

### Scientific Advocate (SA)
Claim: And I am not--

### Moderator
Claim: They decide.

### Scientific Advocate (SA)
Claim: --I have not-- I have not-- no, they decide whether they go on-- or whether they want to be on it or not. I respect that. But--

### Moderator
Claim: But-- but--

### Scientific Advocate (SA)
Claim: --but if they haven't died-- but if they haven't died, I don't say, "I failed. Please let me go out and get a pillow to smother them, because my intention has been fulfilled when they-- when the treatment has stopped." The paradigm case in this country of terminating life-sustaining treatment is the case of Karen Ann Quinlan. What did people go to court for? They went to court to discontinue her ventilator. And when-- they were surprised--

### Moderator
Claim: Daniel--

### Scientific Advocate (SA)
Claim: yeah?

### Moderator
Claim: --let me stop you and take 15 seconds to remind people of-- of Quinlan’s case in the 1970s.

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: 15 seconds.

### Scientific Advocate (SA)
Claim: Yes. Karen Ann Quinlan was a young woman in a vegetative state on a ventilator after partying and overdosing on drugs. And the courts-- the hospital didn't want to discontinue her ventilator without court justification for that.

And what-- the family went to court to do was to say that "We want the right to be able to discontinue our ventilator." And I'm totally supportive of that. And that's what they--

### Scientific Advocate (SA)
Claim: --the judge-- the judges decided this is what would happen. And to their surprise, the woman began breathing when she was disconnected. But what they did was to discontinue a treatment that they thought was futile--

### Moderator
Claim: Okay. Let me bring it back to Peter Singer. So, what I'm hearing your opponent say, to some degree-- and was also made in the opening statement-- is that-- is that we-- death remains beyond-- beyond our understanding, fully. And then dying remains fully beyond our understanding. And your opponents have come up with several examples of cases where individuals would have lived longer. This is just purely the medical, not even the ethical question now-- that we don't really know what we're doing, and that the odds of killing somebody prematurely are out there.

### Conspiracy Advocate (CA)
Claim: Look, as Andrew said, you can't say that it will never happen. But is it right to condemn a vastly larger number of people to suffer when they don’t want to because there may, you know, in one in several thousand cases, perhaps, be somebody like the David and Ilora Finlay described? I don't think so. And I would, again, emphasize, I think the case that Daniel Sulmasy just brought up, with Karen Quinlan, precisely shows that they are making decisions when they withdraw treatment. She lived another nine years. She never recovered consciousness and she died without recovering consciousness. In my view, that was pretty pointless. But if you believe in intrinsic worth of human life, you shouldn't have seen the ventilator as futile, because the ventilator kept her alive-- was thought to be keeping her alive. And after it was removed, the feeding tubes were keeping her alive. So, was that a good thing? I mean, I don't think it was a good thing, I have to say.

But it certainly shows that the decision about withdrawing treatment is just as much a decision that you can get wrong, and you can be dramatically shortening someone's life, as the decision that we're talking about.

### Conspiracy Advocate (CA)
Claim: And let me just add that I have interviewed hundreds of people and heard stories of thousands more who wanted the option to be able to end their lives. And because they had to deal with the system in which what they were doing was illegal, they felt they had to do it while they still had enough vitality and enough self-control to take the lethal medications that they had been able to obtain. And they, over and over and over and over again, die months or sometimes years earlier than they would otherwise be going to die because they're afraid that they will lose that capacity. And my own mother said she could have lived longer if she hadn't been afraid that those intestinal tumors would make it impossible for her to ingest her--

### Moderator
Claim: All right. Let's let Ilora Finlay respond.

Ilora Finlay.

### Scientific Advocate (SA)
Claim: But, Andrew, we're talking about physician-assisted suicide in which the patient has to take the medication and-- or the lethal drugs, I would prefer to call them. And that's what they have to do. So that's not consistent. What you're arguing for is euthanasia. And that's not what we're debating tonight.

### Moderator
Claim: Make the distinction for us.

### Scientific Advocate (SA)
Claim: Well, in physician-assisted suicide, the doctor prescribes lethal drugs. The patient has to self-administer.

### Moderator
Claim: And that's the law in Oregon.

### Scientific Advocate (SA)
Claim: And that's the law in Oregon. And they will say, in Oregon, well, if you can't do that, then that's too bad. What you're arguing for is that the doctor injects you with lethal drugs because if you can't take them yourself--

### Conspiracy Advocate (CA)
Claim: I'm arguing no such thing. My question is whether--

### Scientific Advocate (SA)
Claim: But that's what sounded like.

### Conspiracy Advocate (CA)
Claim: --the doctor is injecting you. It's a question of whether you'll get into a hospital within which you will not be able to exercise your own volition anymore, because the hospice system can be so controlling and you are so tightly monitored that you lose the capacity to take those drugs.

### Scientific Advocate (SA)
Claim: Well, why would you have to kill yourself, because you've got a failure with your healthcare system? I would suggest you need to rectify your healthcare system so people can make choices and control.

### Conspiracy Advocate (CA)
Claim: Excuse me, but the only way to rectify that aspect of the healthcare system would be to give people the capacity to take those drugs under supervision of the healthcare system, which is precisely what you are opposing.

### Scientific Advocate (SA)
Claim: No, absolutely not.

### Moderator
Claim: Ilora, let me just ask you, when you say "your healthcare system," you're saying, "You Americans," with your--

### Scientific Advocate (SA)
Claim: I'm afraid I am because I do think that actually in the UK, however much you criticize us, we are not providing the degree of futile overtreatment that people here seem to be frightened of.

### Moderator
Claim: We don't criticize you.

### Scientific Advocate (SA)
Claim: And actually-- actually, we are very careful to have conversations with patients about what they want.

And advanced care planning is now becoming a standard part of all care for people who have life-limiting illnesses, in terms of what do they want, where do they want to be, what treatments do they not want and so on. So, those discussions are happening a long time before the situation

### Moderator
Claim: But you're not denying--

### Moderator
Claim: Let's let Daniel Sulmasy come in.

### Scientific Advocate (SA)
Claim: No, I'm just sort of concerned by the kind of angry tone that's sort of permeating the panel here. You know, I can certainly see--

### Moderator
Claim: Honestly--

### Scientific Advocate (SA)
Claim: I can certainly see--

### Moderator
Claim: Honestly, let me just say, because we--

### Scientific Advocate (SA)
Claim: No, no.

### Moderator
Claim: --don't support anger. I think it's impassioned not anger.

### Scientific Advocate (SA)
Claim: Yes, yes, yes. It's really-- it's real. It's But it's placed-- no, I'm-- I was going to get to that actually. I think that we sort of want to understand what that comes from, and it comes from, I think, the kinds of failures in healthcare systems and the kinds of problems we have in providing exactly the optimal kind of palliative care that's possible.

And, you know, I've had plenty of patients who begin their journey at the end of life with me by asking, you know, you've got-- you're going to give me those pills, aren't you doc? And I tell them, "No, I'm not going to do that. But let's see how things progress in terms of your care. I'm going to be with you. I'm going to care for your pain. I'm going to care for your depression when you're depressed." It is not natural to be depressed when you're dying. You can be sad, but to have a depression with a capital D is something treatable. And as I follow these patients through to the end of their life, the question never comes up again because they're getting the kind of care that people really want, which respects their dignity, which respects their choices and keeps them pain free. And that's what blunts the kind of, sort of righteous-- righteous anger that I think is justified in those cases where that kind of care isn't provided.

### Moderator
Claim: All right. Let's hear from Peter Singer.

### Conspiracy Advocate (CA)
Claim: Yeah, I take it that Ilora Finlay is not denying that in the UK there are requests for physician-assisted suicide and that indeed there is a movement because you know very well that there is a bill in your own House, the House of Lords, which seemed to make some progress just the other day. And it's also true that there are British subjects who have traveled from Britain to Switzerland in order to end their life because Switzerland allows nonresidents, unusually, to have assisted suicide, physician-assisted suicide. So it's clearly the case that it's not just the U.S. system although, you know, I wish we could just snap our fingers and then we would have a wonderful U.S. health system in which nobody needed to end their life. But it's not an easy task, as President Obama found out, to reform the U.S. healthcare system. So unfortunately, we're going to have to live and die with the system that we have. But I can't really imagine a system in which-- you know, in the foreseeable future in which there are no serious considered requests for physician-assisted suicide.

### Moderator
Claim: I'm sorry for interrupting. I want to go to audience questions in just a moment.

But before I do, I want to take one more question to Ilora Finlay, or-- or Daniel Sulmasy since you're both physicians. Part of what I'm hearing from you is that you don't like the fact that your profession is part of the mechanism of this whole thing. And if-- if there - - would you be on this stage at all if doctors weren't involved? If there were some government body or some civilian organization that made these assessments and handed out the pills, and it didn't have anything to do with medicine?

### Scientific Advocate (SA)
Claim: I think it's really important that you talk about the assessments and that everyone's quite clear that not everybody who asks is getting. That's already been said. So, it isn't about true choice, if you like, because you're not actually choosing. You're making a request to somebody. I think it would be much safer if doctors weren't the gatekeepers here.

### Moderator
Claim: Were or were not?

### Scientific Advocate (SA)
Claim: Were not.

### Scientific Advocate (SA)
Claim: Because I think it would be much safer-- and my argument is about public safety-- that you have to produce a report to an independent body who can look at all kinds of things going on.

Doctors don't ask you about your personal finances. They're not in the house. They don't have in-depth understanding of the coercive pressures that may be going on at home. But those pressures become important. I have seen families that I thought were loving families, and actually they were hoping somebody would die before the life insurance policy ran out. And the other point that I would like to make in all of that is the doctor needs to be looking after the whole family. And don't forget people have children, they have people who they leave behind. What is it like for a teenager, that his love was not enough to sustain his mother through an illness when he desperately wanted her to keep on living and be part of her suicide?

### Moderator
Claim: Powerful point, and I want to take it to Andrew Solomon, who is our-- who made our most powerful point this evening.

And what's your response to that?

### Conspiracy Advocate (CA)
Claim: Well, that's actually been studied in the context of Oregon. They've looked at the families of people who have had physician aid in dying and compared them on various psychological measures with families of people who died of natural causes. And what they found is that there is no difference at all except that the people who had relatives who went through physician aid in dying by and large have a greater acceptance of what has happened and have a grieving process in which they feel there is more coherence. That's what the statistics in Oregon have shown.

### Moderator
Claim: All right. I want to go to some audience questions. And here's one thing I want to say. I think that people who have lived through this may have a desire to tell their stories tonight because it's such a powerful thing. And I just want to discourage it, because we have people on stage who are doing that. So, please don't do that. But that doesn't mean if you have a story to tell you that still don't have a question to ask. So, I'm fine with the question part of it. So, I want to go right down here in front.

### Moderator
Claim: Kelly Posner from Columbia University. So, my question really goes to the to capacity and depression is often a secondary consequence to terminal or chronic illness. And the wish to end one's life is actually a symptom of depression. And there are studies that show that when you treat people who make those requests with antidepressants, they actually withdraw the request. And you, Andrew, are one of the greatest proponents of antidepressant treatments that exists, so I was just wondering how you reconcile that?

### Conspiracy Advocate (CA)
Claim: Well, I think it's terribly important that people have a psychological assessment. When we proposed this, what we proposed is a highly regulated system. And we have many highly regulated systems. In fact, we have a highly regulated system for making a decision to discontinue life support. We already have a system for people who don't want to go on living and who have a serious illness.

That system in which people have to be shown to be competent, in which they have to be assessed not to be suffering from a psychiatric illness, in which, if there is any evidence that they might be, they have to undergo treatment before it's determined whether their decision is a fully rational decision is an appropriate set of measures. But we set regulations like that everywhere. I mean, 92 people a day die in traffic accidents in the United States. We don't say, because people are dying in traffic accidents, we should make cars illegal. We say people shouldn't drive over a certain speed limit. They should pay attention to traffic lights. We set a regulatory system in place. And none of us are arguing in favor of an unregulated activity, and none of us are arguing in favor of helping people to die who have got a depression that could be calls to resolve.

### Moderator
Claim: Would the other side like to respond?

### Scientific Advocate (SA)
Claim: Yes, because actually the--

### Moderator
Claim: Ilora Finlay.

### Scientific Advocate (SA)
Claim: --the data from-- the data from Oregon itself shows that they are missing those serious depressions. And the Oregon system and the Washington system don't have a proper monitoring in place.

There is no investigation after the death. There is no independent commission. And actually it relies on the doctor being honest enough to report what they've done, but there's no way of picking up if they haven't been. So your regulatory system is actually failing. And in Vermont understand that they thought that after three years they wouldn't need to have the safeguards in place anymore because doctors could be trusted, and I was really horrified when I saw that.

### Conspiracy Advocate (CA)
Claim: But we are not wedded to the Oregon system or the Vermont system without saying that it could be improved. I know that your House of Lords just accepted an amendment that there should be judicial review of doctors' decisions. We are certainly welcome to consider those possibilities. We are simply saying that there is a legal system of regulating assisted suicide which is worth implementing.

### Scientific Advocate (SA)
Claim: And the problem is that even Charlie Falconer who’s bill this is said that nothing can be watertight, and that's the problem.

If you could come up with a system that was watertight that would be different, but that's not what you've proposed and that's not what we're debating tonight.

### Moderator
Claim: I'm going to go to another question. Sir, over by the wall.

### Moderator
Claim: I--

### Moderator
Claim: Just please wait for the microphone to come to you. It's coming down the left hand side. Thanks. And if-- please, can you tell us your name, please.

### Moderator
Claim: My-- I'm Peter Strauss This is a question for the opponents. Since you've injected the slippery slope argument, could you give me your justification for saying, "It will lead to euthanasia," which is not what any of the statutes in New York call for or would allow?

### Moderator
Claim: Daniel Sulmasy.

### Scientific Advocate (SA)
Claim: Sure, I think that it's simply the logic just-- if the justification, as we've heard, is that people have the right to choose, right, then the next step becomes, "What about that person who is paralyzed and can't actually take the pills?" So, the justification becomes, "Well, that's actually discrimination because they actually can't take the pills," so we have to move from assisted suicide to euthanasia.

Then the next step becomes because the person can't take the-- say that they have the autonomous choice, we can infer that they would and that we would have what's called "non-voluntary euthanasia," not "involuntary" but "non-voluntary" in which we, like we do for withholding/withdrawing life sustaining treatments, say that people who are demented can have the family say that the treatment can be discontinued. And all of this has actually happened in the Netherlands already. So, if you want to sort of say that this can't happen, we've moved from a period in the Netherlands in which first of all it was legal-- illegal but tolerated, then to being something that was legal for persons who were autonomous and could ask for it, then it's moved on actually to children-- there's a grown again protocol for infanticide of children under the euthanasia law there-- psychiatric indications of people who feel that their psychiatric illness is insufficiently treated can ask for it and get it under those--

### Moderator
Claim: All right, Daniel, we see where you're going with that, and I want to take it to Andrew Solomon. he-- well, you just have, you know, painted the staircase of the slippery slope here, and I want to ask Andrew Solomon-- it sounds-- you know, it sounds real, it sounds concrete, does it concern you?

### Conspiracy Advocate (CA)
Claim: Well, I would start by saying that the situation in the Netherlands and what's been dealt with in that law is different from what's been dealt with here. But, like Peter, I believe that there is room for improvement even in the laws that currently exist. But in Oregon we have had 17 years of this law. There has been no evidence of involuntary euthanasia. There has been no evidence of physicians giving people who are disabled injections to terminate their lives. The law is narrow and specific. And it's that narrow and specific law that is in discussion here. We live on a slippery slope. We all live on a slippery slope. There are many practices within our society that, taken to extreme, would be incredibly damaging and detrimental, and we contain them, and we can contain the damage in this and accomplish an enormous, enormous good.

### Moderator
Claim: Ilora Finlay, do you feel that Oregon is evidence that the slippery slope is not necessarily inevitable?

### Scientific Advocate (SA)
Claim: No, not at all, because you've got no way of detecting abuse, and actually if you talk to the campaign organizations in Oregon they actually are wanting to campaign eventually for it to just be a pill that you can have without having to see the doctor and go through all that. If you look at the Netherlands, they started off having physician assisted suicide and euthanasia. But actually it was more convenient for the doctors because it didn't take so long, so they would go down-- they pushed it down the euthanasia route. That was a-- in--

### Conspiracy Advocate (CA)
Claim: No, that was just not true, sorry. There was never a case when physician assisted suicide--

### Moderator
Claim: Peter Singer.

### Conspiracy Advocate (CA)
Claim: --was legal or accepted and euthanasia was not. But that's--

### Scientific Advocate (SA)
Claim: --no, no, they--

### Conspiracy Advocate (CA)
Claim: they just didn't see that distinction.

### Scientific Advocate (SA)
Claim: --they didn't see that distinction, but they're now using euthanasia more, and also the-- complications that arose with physician-assisted suicide, because of vomiting, and nausea, and so on.

They've gone over to injecting drugs in--

### Moderator
Claim: They both have done that.

### Conspiracy Advocate (CA)
Claim: That's really not right.

### Scientific Advocate (SA)
Claim: In Belgium, they've extended it, so now you have somebody who had euthanasia because he had a botched sex change operation. There's been approval for a prisoner who wants to have euthanasia because he doesn't want to carry on living in prison, and so on. So, it's not a slippery slope down, but it's an incremental extension that we're seeing, where the law can change.

### Moderator
Claim: Ma'am, up there. Right in the aisle. Folks, if you're upstairs trying to ask questions, I just want to let you know that we don't have mikes up there. But if you come downstairs, I-- for your effort, I'll try to call on you.

### Moderator
Claim: I'm Debra Albert First, I think there's a point that can be made for anybody on the panel. I'm sort of in Peter's camp when I think about death. I don't think anybody here has ever experienced death.

And so, you don't actually know whether or not it is a state that is better than being in excruciating pain all the time. And for those that are opposed, I don't think that you can say that death is not a better choice. But my question actually goes to Daniel. When you speak about the societal effect that this can affect other people-- it's not just a personal choice-- I can take a drug and go outside now-- like alcohol--

### Moderator
Claim: I-- I--

### Moderator
Claim: --get into a car--

### Moderator
Claim: I need you to-- you had a minute of our time.

I need you to-- I'll give you 15 more seconds to nail this.

### Moderator
Claim: Okay. I can take a drug that can affect death on someone's life who doesn't choose to die. And yet, they're not taking alcohol away from me or society.

### Scientific Advocate (SA)
Claim: Yeah. Again, let me first say, in response to the first part of your question, that the excruciating pain that you're talking about is nothing that Ilora or I would support that patients have to go through.

What we're-- we are totally in support of treating patients' pain, even to the point that it might hasten their death. And so, there's no need-- if people think they need assisted suicide in order to avoid pain, that's not the issue here. That's not even why people in Oregon say they're taking the pills, right? It's not because of pain, because we can take care of that, even to the point of rendering somebody to be unconscious. What we're talking about is the kind of world we want to live in, one in which we can say that-- to a person that the fact that you think that you are a burden is sufficient to be able to end your own life, and that we would have an atmosphere in which that kind of judgment could be made by people-- I think is a problematic world to live in.

### Moderator
Claim: I want to remind you that we are in the question and answer section of this Intelligence Squared U.S. Debate.

I'm John Donvan, your moderator, and we have four debaters-- two teams of two-- debating this motion, Legalize Assisted Suicide. Right in the center there. Yeah. You're standing and-- you are the right one. If you can tell us your name, please, when the mic comes to you.

### Moderator
Claim: Hi. I'm Misha Gupta earlier you argued that life support and taking someone off such ventilation is justified, due to the fact that their illness is progressing. However, many people applying for assisted suicide are in the same position. And I understand there's always exceptions to the rules, in your personal experience –David. What about the candidates whose illness does not turn around and does progress and worsen? What's your justification or reasoning that differentiates the two?

### Scientific Advocate (SA)
Claim: Okay. Thank you for that question. You-- all the patients I look after have got an incurable illness. They all have progressive illness.

And they all have illness that is-- working towards their death and they're likely to die from. What I'm saying is that you can't be certain. And I am supporting them while they go through that phase of their lives, helping them reframe their experience, and doing everything I can to improve quality of life. Let me tell you one story. A woman who was desperate to be taken off her ventilator, but wanted a lethal overdose-- her husband was very angry that we weren't giving her a lethal overdose. One morning, I persuaded him to go out to the pub for a drink, let me have half an hour in with her, which I did. In that time, I asked her, "What's the worst thing for you at the moment?" And she said it was the whiskers on her chin. And I said to her, "Would you like me to give you a quick facial?" Now, I've never been trained to do it, but we found some tweezers and one of the nurses came and helped me. And she did indeed have some quite long whiskers on her chin, and we plucked them out. And the nurse said, "Do you want to be made up again?"And she said, "Yes." We made her up. And her comment was, when we showed her in the mirror, she said, "I feel like a woman again." And from that point on, she never asked for lethal overdoses, but she asked to be made up every day. Why? Because she realized that she could be a woman again and have personal worth. But my argument is that this motion comes from despair, from seeing that there is no worth left in a human being once they're ill and once they appear to be dying. But you just can't tell. And I want doctors to have to strive to improve quality of life. And that is why I oppose this motion.

### Moderator
Claim: Peter Singer.

### Conspiracy Advocate (CA)
Claim: I find it a very sad story, actually, that that was so important to that woman, that sense of being a woman.

But--

### Scientific Advocate (SA)
Claim: You've got whiskers on your chin all the time. I'm afraid I would like mine plucked.

### Conspiracy Advocate (CA)
Claim: Okay. But-- and I think in a way it's trivializing the reasons why people ask for physician assistance in dying. It's things like being nauseous, feeling breathless, being-- just being able to lie there and not being able to do anything. I mean, it may be that pain can generally be controlled, or I've certainly read palliative care specialists who acknowledge that it can in every case, except as Daniel Sulmasy just said, by making the patient unconscious. But, you know, that then is getting, I think, very close to what we're talking about. I've seen surveys that say that the majority of American intensive care specialists have used terminal sedation, that is they sedate the patient to the point of unconsciousness.

The patient, of course, then does not eat, and they don't tube feed the person, so the patient then dies. I mean, what's the difference between giving the patient so many drugs that they're unconscious and then they're not fed and they die, or allowing them to take a drug which, at their choice and at their time, will end their life?

### Moderator
Claim: Well, your opponents say the answer is intent.

### Conspiracy Advocate (CA)
Claim: And I would just add that--

### Moderator
Claim: But I just want Peter-- that, before you do, Andrew.

### Conspiracy Advocate (CA)
Claim: But I think you have to accept, surely. I mean, it's a fictional notion of intent to say that you intentionally make somebody unconscious knowing that you're not going to feed them and you're unintentionally ending their life? Come on.

### Moderator
Claim: Andrew?

Andrew, you're going to follow quickly so that--

### Conspiracy Advocate (CA)
Claim: I will quickly. First to say that I think we're all agreed that compassionate medical care is to the good and that anyone who can find meaning in life or can be helped to find meaning in life should be encouraged to do so and receive every possible support.

But I--

But I think, in keeping with what Peter has just said, that there are a great many people exploring a great many means to bring these ends to their lives. There are people who are shooting themselves in houses by themselves because this is unavailable. There are people who take this medication, someone I interviewed recently was the wife of someone who had managed to get medication and took it and vomited and knew he couldn't get another prescription and had to eat his vomit in order to ensure that he came to an end. There is back alley euthanasia going on in various ways, and it is uncontrolled and unregulated. And if it were legalized, it could be brought more into control.

### Moderator
Claim: Daniel Sulmasy.

### Scientific Advocate (SA)
Claim: Actually, even under legalized assisted suicide, much of what you have described still happens. Patients often vomit. In fact, if you read "Final Exit" from Derek Humphrey, he suggests putting a plastic bag over your head to make sure that the vomitous doesn't get onto the bed and that you actually suffocate afterwards if the drugs haven't worked.

And there are suicides that don't work even under those--

### Scientific Advocate (SA)
Claim: --even under those sorts of laws, and there are some even with this that go on outside of that. But I want to go back to Peter's-- peter's point about, first of all, you know, again, painting the sort of medical burning lorry case, the person who's in excruciating pain, that's untreated, who's got uncontrollable nausea, et cetera. I mean, these things, in the right hands of palliative care are probably as rare as you would suggest assisted suicide is in Oregon right now. These-- we can control most of the symptoms of patients. We don't have to continue life-sustaining treatments on them. They can die, you know, rather quickly. But what I don't want to affirm, again, is that a patient's life is futile.

I can say that the treatment is futile, but not the patient themselves and that I would not act with the intention of making them dead. When I give a patient drugs because they have pain at the end of life, and I am sedating them, I'm not sedating them to death. I mean, there may be some people who do that, and that's part of the practice in the Netherlands that's also on a continuum with euthanasia. But what I'm doing is acting with the aim of treating their symptoms. And if in fact it takes making that person unconscious in order to treat their symptoms, I'm willing to accept that with the consent of the patient that we both are willing to take that risk, because lots of patients are also make the tradeoff, I'd rather have a little bit of pain and have some time to visit with my family. So you've got to make that kind of decision jointly with the patient. And I'm not euthanizing patients when I give them morphine at the end of life.

### Moderator
Claim: Down in front here, please. Third row. Thanks. And if you could stand and tell us your name, thanks.

### Moderator
Claim: Jesse Silburg This is to the team arguing for the motion. So, physicians are fallible. If we legalize assisted suicide, are we asking to risk their integrity? And are we asking too much?

### Conspiracy Advocate (CA)
Claim: No, I don't think we're asking them to risk their integrity--

### Moderator
Claim: Peter Singer.

### Conspiracy Advocate (CA)
Claim: --we're asking them to act with integrity, to consider carefully whether the circumstances are the ones that are prescribed in the law, as we said, could be-- have various kinds of safeguards and reviews, and will minimize those kinds of mistakes. It is true that physicians, like everyone else, are fallible, and it is true that occasionally there may be a mistake, and it may be that somebody could have lived longer and even found their life worthwhile. We're not saying that that can never happen, because we know that in all human things, things could askew occasionally.

But we don't think these rare possible cases are sufficient to say that nobody else can have these choice, nobody else can make this decision that "I've had enough," and that because of these very occasional mistakes, everybody else has to suffer through to the end whether they want to do that or not.

### Moderator
Claim: Up there against the wall.

### Moderator
Claim: Good evening. My name's Caroline Simpson. This question is for Dr. Sullivan.

### Moderator
Claim: Sulmasy.

### Moderator
Claim: Pardon me?

### Moderator
Claim: Dr. Sulmasy.

### Moderator
Claim: Sulmasy or Solomon.

### Moderator
Claim: --I apologize.

### Moderator
Claim: Solomon's not Sullivan, and he's not a doctor.

### Moderator
Claim: I'm conflating you.

### Moderator
Claim: Sulmasy is here.

### Moderator
Claim: Okay.

### Moderator
Claim: My question-- my question is, I'm a little confused whether you are relying on an intrinsic worth of life that just is prioritized over everything or whether it's the fact that you believe you can relieve all pain.

Hypothetically, if someone were in excruciating pain, that just-- unbearable, no matter what you did in terms of palliative care, would you still be against physician-assisted suicide?

### Moderator
Claim: Excellent question.

### Scientific Advocate (SA)
Claim: Yes. Again, first of all, I'm not a vitalist. I don't think that life itself is the value here. And secondly, that I've suggested several times here that the person who is in the kind of excruciating pain you're talking about, under my care or Dr. Finlay's care, would be able to get increasing doses of morphine until the point that their pain was relieved, whether that hastened their death or not. My aim there is not to eliminate the patient, but to eliminate the patient's pain. And I foresee the possibility that this could happen, but that's not my aim.

What I want to do is reverence people, right, and not act with the specific intention of making them dead, of turning a somebody into a nobody. I want to eliminate pain where I can. And if it takes making them unconscious in order to do that, I'm willing to do it.

### Moderator
Claim: Ma'am, did you-- all right. Well, let's get the mic back to you because I just want to make sure-- it was a really good question, I want to make sure it's

### Moderator
Claim: I'm sorry. I don't think you've answered my question. Hypothetical--

### Moderator
Claim: Take-- take 10 more seconds and get right at it.

### Moderator
Claim: Okay. Hypothetically, you cannot alleviate the pain. No, no, no, I just-- I'm trying to understand your underlying argument because this feels utilitarian.

### Moderator
Claim: Okay. Don't argue with him, please. Just make-- make your--

### Moderator
Claim: I'm sorry. But I'm-- I would ask you to accept the hypothetical, but I can only ask.

### Scientific Advocate (SA)
Claim: Yeah.

### Moderator
Claim: Let-- I think-- I think your partner wants to take a crack at it also.

### Scientific Advocate (SA)
Claim: Can I answer?

### Moderator
Claim: Ilora Finlay.

### Scientific Advocate (SA)
Claim: Because you've asked a practical question. I've seen patients whose pain score was 11 out of 10, not just 10 out of 10.

I have sat there with a syringe full of Diamorphine and injected slowly, milligram by milligram, minute by minute until their pain score is down and it is bearable, until we get it under control and redouble the efforts. And sometimes the person has seemed a bit sleepy for a time and we've had side effects and we've had to get over them. But my role as a doctor is to relieve that suffering. Those patients may say, "I can't bear this, I ought to be dead," but that does not continue, that request does not continue when you get on top of their symptoms. I've had conversations with hundreds of patients about how they feel, about what's happening to them, many people are devastated when they first realize that they have a life threatening illness. The world is not as they thought it was going to be. But actually when you work with them, and it is hard work, they come through and they often have a fulfillment that they never imagined they could have before.

I've had people who've wanted theoretically to have assisted suicide or euthanasia, but they've abandoned that when they themselves are ill.

### Moderator
Claim: Okay, I'm going to--

### Conspiracy Advocate (CA)
Claim: That's not the question. You both evaded the question. The question asked you to accept--

### Moderator
Claim: Peter Singer.

### Conspiracy Advocate (CA)
Claim: --the hypothesis that you can't relieve the excruciating pain. It's an attempt to understand your underlying philosophical or ethical position. And neither of you-- you've both just evaded that question.

### Scientific Advocate (SA)
Claim: No, because I don't accept--

--no, there's a fundamental premise here and a misunderstanding. Those of us that actually are the ones with the drugs and the techniques to relieve the pain keep on trying and going back and back and back again, so you're painting a hypothetical question, I'm saying I faced it practically and I still oppose physician assisted suicide.

### Moderator
Claim: And that concludes round two of this Intelligence Squared U.S. Debate--

--where our motion is "Legalize Assisted Suicide." And here we are. We are about to hear closing statements from each debater in turn. Those will be two minutes each. And remember how you voted just before the debate because right afterwards we'll have you vote a second time. And the team whose numbers have changed the most between the two votes will be declared our winner. First, on to round three, round three closing statements, and here to summarize his position in support of the motion, "Legalize Assisted Suicide," Peter Singer, professor of bioethics at Princeton University. Oh, Peter, for this one we'll remain seated on all these.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Sure.

### Conspiracy Advocate (CA)
Claim: It's easier.

### Moderator
Claim: Well, let me wind up to introduce you again just for the ultimate radio broadcast of perfection.

## Round 3

### Moderator
Claim: Here to summarize his position for the motion, "Legalize Assisted Suicide," Peter Singer, professor of bioethics at Princeton University and author of the book, "Practical Ethics."

### Conspiracy Advocate (CA)
Claim: We want you to support this motion because, firstly, we believe that people should be the ones to decide for themselves whether they think that continued life is worthwhile for them or not. We don't think that it should be up to anybody else to say, "We think your life is worthwhile." And, secondly, we think that there is a lot of unnecessary suffering, whether it's excruciating pain or not, there is suffering and distress of various sorts which continues and is going to continue for the foreseeable future in this system and it could be relieved by a relatively simple legislative reform that exists already and has been shown to work. Now, in fact, this region today took a little step closer to that. You may not know that the New Jersey State Assembly today voted to pass the Aid in Dying for the Terminally Ill Act which is similar to the other legislation that we've been discussing. It voted 41 to 31, so a fairly clear majority. It still, of course, has to go to the Senate, and then it would need the assent of a candidate-- a governor who wishes to be the Republican candidate for the presidency-- so it still has some way to go. But I just want to quote one of the supporters of that whose name is Janet Colbert. She's a retired oncology nurse, so she knows a lot about cancer and about people dying from cancer. She now herself has terminal liver cancer, but she supports this because she said, "As I battle my illness I would like the choice and comfort that comes with the option of aid in dying." That's all we're asking for. Thank you.

### Moderator
Claim: Thank you, Peter Singer. The motion, "Legalize Assisted Suicide," and here with his closing statement on the motion, Daniel Sulmasy, professor of medicine and ethics in the Department of Medicine and Divinity School at the University of Chicago, speaking against the motion.

### Scientific Advocate (SA)
Claim: You know, I get questions frequently from patients who ask how I can be opposed to assisted suicide when they're getting sick from their chemotherapy, suffering complications from the big IV they've got stuck in their neck, are depressed and in pain, and spending more time in the hospital than outside it. So, I ask them, "Why are you still getting chemotherapy? Why have you got that big IV stuck in your neck? Why not ask for hospice to help treat your pain and your depression? Why go to the hospital? Supporters of assisted suicide want-- our opponents want respect for their dignity and attention to their individual needs. But we're all human. We're fragile, interdependent, connected in bonds of mutual respect and support. Suicide is always interpersonal. It's an act of communication. Many persons who raise the question of assisted suicide are doing so because they're really testing the waters.

They are asking us if we care enough to try to stop them. And when we don't stop them, we confirm their deepest fears and make it difficult for them to see an alternative. And if the suicide happens, their physicians and families must wrestle with it the rest of their lives. We shouldn't be about constructing a society that makes assisted suicide routine. Rather, we should redirect our energies towards making sure that all patients get the kind of care that I think we all want, helping all of us to live to the fullness-- to the fullest, even as we're dying. So, I want you to vote for that kind of high-quality compassionate care at the end of life, and for the sort of ethical world that really makes that possible by voting no on assisted suicide.

### Moderator
Claim: Thank you, Daniel Sulmasy. And that is our motion: Legalize Assisted Suicide. And here to summarize his position-- his position supporting this motion, Andrew Solomon.

He is author of the award-winning book, "Far From the Tree" and the other book, "The Noonday Demon." Andrew Solomon.

### Conspiracy Advocate (CA)
Claim: I take exception to the idea that all pain is treatable. It's not true to clinical data and it's not true to personal experience. And I also take exception to the idea that we value life by insisting that somebody-- to borrow your phrase "not become a nobody." That can be care, but it can also be oppressive. Rilke wrote, "We need, in love, to practice only this: letting each other go, for holding on comes naturally. We do not need to learn it.” Death is not only the start of nothing, but also the end of everything. And it's important that it keeps faith with the way that someone has lived. Nothing so resembles a person in his biography, as the manner of his or her death.

The finale is what makes sense of the symphony. Simone de Beauvoir's mother begged her for help when she was sick, and Simone de Beauvoir instead took the word of her doctors. And afterwards, she wrote, "Beaten by the ethics of society, I had abjured my own.” One is caught up in the wheels and dragged along, powerless in the face of specialist diagnoses that forecast their decisions. A race had begun between death and torture. I asked myself how one manages to go on living when someone you love has called out to you in vain? Let us not treat those we love with that pusillanimous disregard. Let us not institutionalize and enshrine in law prohibitions that force us to suffer contrary to our beliefs and force us to watch those we love suffer contrary to their expressed wishes.

### Moderator
Claim: Thank you. Andrew Solomon.

Our motion is "Legalize Assisted Suicide." And here to summarize her position against this motion, Ilora Finlay, a palliative care physician and president of the British Medical Association.

### Scientific Advocate (SA)
Claim: It's all too easy to be swayed by emotion and fear. But human beings are uniquely interconnected. If I accede to the request to provide lethal drugs, I actually give the message, "Yeah, I think you're right. You'd be better off dead." I don't give the message that you are of worth. I've been there myself. My own mum was in hospice dying, angry, terribly angry that I was opposing the assisted suicide that she wanted. She thought it was the answer. This fiercely independent lady dreaded dependence. It broke my heart, and I was torn apart by it. An argument about philosophy with a member of staff let her see that her mind still worked, and she still had something to offer.

So, she battled with us, all of us, and then went home, to everyone's surprise. She didn't die. She lived four more years. And in those four years, she saw her two great grandsons born. And she said they were the richest years of her life. They were important to her. They were important to us all, everyone, in the family. I beg you, it's not like in the movie. Assisted suicide isn't straightforward and clean and quick. Some people awake. Six did in Oregon. Some people take a long time to die, up to 104 hours. That's not dignified. Don't vote for this dangerous, dangerous law that actually deprives people of the possibility of having their dignity and having doctors who have to work to improve their quality of life. This law allows them to throw the towel in.

### Moderator
Claim: Thank you, Ilora Finlay.

And that concludes our closing statements. And now it's time to learn which side has argued best. We're going to ask you again to go to the keypad at your seat to register your vote. We'll get the readout on this almost instantaneously. Remember, the motion is "Legalize Assisted Suicide." If, after hearing the arguments, you agree with this motion, push number one. If you disagree, push number two. If you became or remain undecided on it, push number three. We'll give it about 15 more seconds. And if you push the wrong button, just correct yourself, as I said before. It registers your last button push. And we'll lock out the vote. So, the first thing I would like to say is that this was an-- from the beginning, one of the most passionate debates we've ever had with a very, very high level of emotional intensity.

But I had enormous respect for how the panelists on this stage kept it civil all the way throughout. So--

That is our goal here, and they met it. Also, all of the questions were very, very good today, even the ones that went on a little bit long. They were-- they got to a good place. So everybody who had the courage to get up and ask a question, congratulations to them.

I want to take a moment and thank our generous supporters who make these debates possible. Our ticket sales do not cover, by any means, the cost of putting one of these on. So we encourage you to go to our website if you are interested in making a donation, because every gift counts for us and keeps it going. And thank you to those who have already done so and those of you who will. Our next debate is here at the Kaufman Center.

It will be on Wednesday, December 3rd. Our motion is, once again, a three-word motion: "genetically modify food." We will be looking at whether the world is better off or worse off with GM food crops, issues of safety, environment and food security. For the motion, we will have the chief technology officer at Monsanto and a genomics and biotechnology researcher from UC Davis. And against the motion, a research professor who studies agricultural technology, food quality and safety. And that debater is partnered with a former senior scientist from the Union of Concerned Scientists. Tickets are available at our website. And as we said at the beginning, if you can't get to our debates to be-- to watch them live, you can download our new app, the IQ2US app. It's on the Apple and Android stores. And just search for IQ2US at iTunes or Google Play.

And you can watch this debate and all of our debates at our live stream and listen to NPR stations across the country. Also, I want to make note that today we had a special section of our audience. We have the students and the debate coaches from the New York City Urban Debate League. They're with us tonight. And you guys can stand up.

And they're going to be continuing debating this topic themselves over the next few weeks, so good luck to them with that. Okay. So, it's all in now. I have the final results. You have voted twice before the debate and again after the debate. And the team whose numbers have changed the most will be declared our winner. Let's look at the preliminary vote on the motion "Legalize Assisted Suicide." Before the debate, 65 percent of you agreed with the motion. 10 percent were against. 25 percent were undecided. Those were the first results. Again, the team whose numbers have changed the most between the first and the second votes will be declared our winner. Let's look at the second vote. The team arguing for the motion, their second vote was 67 percent. They picked up 2 percentage points, 2 percentage points is the number to beat. The side arguing against the motion, their first vote was 10 percent. Their second vote was 22 percent. They pulled over 12 percentage points. The side arguing against the motion, "Legalize Assisted Suicide," declared our winner. Our congratulations to them. Thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
