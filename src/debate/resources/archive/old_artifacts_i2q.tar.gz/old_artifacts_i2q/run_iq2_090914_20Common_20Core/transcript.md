# Debate Transcript

Topic: Embrace The Common Core
Motion: Embrace The Common Core

Debate ID: 090914%20Common%20Core


## Round 1

### Moderator
Claim: So we’re going to begin again or anew, and we’d like to, love to start the radio broadcast with all of you clapping, so let’s have one more. Sometimes when we set out to fix what is broken, we can argue not only about what the fix should be, but actually about what the problem is. And when it comes to American public education, the diagnosis has been offered that our schools suffer from a lack of consistent standards coast to coast about what our kids should leave school knowing. And the fix that has been adopted in a number of states in the last few years is a set of standards called the Common Core, which have become the most contentious issue in American education in the last generation, with disputes about who drew up these standards, whether they result in kids being over tested and even whether standards make sense. Do they have to be common? Are we fixing the right problem?

Well, that sounds like the makings of a debate. So let’s have it. Yes or no to this statement, Embrace the Common Core. A debate from Intelligence Squared US. I’m John Donvan. We are at the Kaufman Music Center in New York City. We have four superbly qualified debaters who will be arguing two against two on this specific motion, Embrace the Common Core. As always, our debate will go in three rounds and then our live audience here in New York City votes to choose the winner, and only one side wins. Our motion is Embrace the Common Core. Let’s please meet our debaters. Please welcome first, Carmel Martin. And Carmel, you are arguing for the motion, Embrace the Common Core. You are right now at the Center for American Progress.

You’re an executive VP there for policy. You were in the Obama Administration four years as Assistant Secretary at the Department of Education. Carmel you have and will argued the standards were, the Common Core standards, were first gathered together by the states, but President Obama then endorsed them and in the eyes of many of his opponents, he them tainted them and made them unpopular. The question we have for you is back at the beginning of this, did anybody see that there would be a political backlash with the administration’s endorsement?

### Conspiracy Advocate (CA)
Claim: Well honestly John, we weren’t thinking about political backlash. We were thinking about what was best for kids, but I do agree that the issue has become a little bit of a political football, which I think is unfortunate and I hope people will focus on what’s best for children.

### Moderator
Claim: So no football tonight then. And your partner is, Carmel?

### Conspiracy Advocate (CA)
Claim: My partner is my sometimes opponent actually, always my friend and distinguished colleague, the brilliant Michael Petrilli.

### Moderator
Claim: Ladies and gentlemen, Michael Petrilli.

Michael, that was a very nice introduction.

### Conspiracy Advocate (CA)
Claim: I was hoping for "good-looking," but I'll take brilliant. That's good-- that's okay.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: You are not only good looking. You are also president of the education policy think tank, the Thomas Fordham Institute. You're an executive editor of Education Next. The Common Core, as everybody in-- who knows the issue knows is that it's not an easy left- right issue, that there are people on both sides, from both ends of the spectrum. And a case in point in that is that your debate partner, as pointed out, is a liberal--

### Conspiracy Advocate (CA)
Claim: Affirmative.

### Moderator
Claim: --while you represent a conservative think tank.

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: However, recently, a number of conservative governors have pulled out of the Common Core. So, is it-- is it starting to get a little lonely on the conservative side?

### Conspiracy Advocate (CA)
Claim: Perhaps a little lonelier, but it's important to know that still half of the nation's Republican governors are supportive of the Common Core. So, lonelier, but I am far from alone.

### Moderator
Claim: And you're going to try to pull some people over to your side tonight.

### Conspiracy Advocate (CA)
Claim: Absolutely. On the left and the right.

### Moderator
Claim: Thank you very much. Michael Petrilli, everybody. Our motion is Embrace the Common Core. We have two debaters who are arguing against this motion. First, please welcome Carol Burris. Carol, you are-- you are principal. You are the-- the educator on the stage tonight. You're principal of South Side High School in Rockville Center in New York. 2013, a New York High School Principal of the Year. Congratulations on that. You're also the author of three books. And one of these books was called "Opening the Common Core," at which time you were supportive of the standards. Now you are arguing on the other side. What do your students at-- at South Side make of this whole controversy over the Common Core?

### Scientific Advocate (SA)
Claim: Well, over half of my ninth graders last year refused to take the Common Core test when they were in eighth grade, with their parents' permission. So, I think it's safe to say they're not fans.

### Moderator
Claim: All right. I have a feeling maybe some of them are here. Thank you, Carol Burris. And your partner tonight is?

### Scientific Advocate (SA)
Claim: My partner is the good looking and charming Rick Hess.

### Moderator
Claim: Ladies and gentlemen, Rick Hess. Rick, you're at the American Enterprise Institute. You are an education policy studies resident scholar and director of that section. You have a blog called "Rick Hess Straight Up” at Education Week. Like your opponent, Mike, you are an executive editor for Education Next. And it's also interesting to note, you and your opponent Mike co-wrote a book in 2006. So, are there no more collaborations down-- down the road for the two of you?

### Scientific Advocate (SA)
Claim: You know, John, we wrote that book on No Child Left Behind after Mike-- who had been an enthusiast-- came to share my more measured take. I'm hopeful that history will eventually repeat itself.

### Moderator
Claim: All right. Thank you. Rick Hess. And the lineup showing just how complex this topic is and how the bedfellows are strangely made.

Our motion is Embrace the Common Core. This is a debate. There will be a winner and a loser by a vote of the live audience. By the time the debate has ended, you will have been asked to vote twice-- once before the debate and once again after the debate. And the team whose numbers have moved the most in percentage point terms will be declared our winner. Let's go to the preliminary vote. If you go to the keypads at your seat. We're going to start with that. I'll remind you-- you want to pay attention to keys 1, 2, and 3. You push 1 if you agree with the motion "Embrace the Common Core." If you're with this team. You push 2 if you're against it. If you do not agree that we should embrace the Common Core, you push #2. And that's this team. If you're undecided, which is a perfectly honorable position of which to start this, you push #3. If you push the wrong key, just correct yourself. The system will lock in your last vote. Looks like everybody's got it, so let's move on to Round 1.

Our motion is Embrace the Common Core. Round 1, opening statements by each debater in turn. They will be seven minutes each. Speaking first for the motion, Embrace the Common Core, Mike Petrilli. You can make your way to the lectern. Michael Petrilli, President of the Thomas B. Fordham Institute. He is research fellow at Stanford’s Hoover Institution and author of "The Diverse Schools Dilemma." Ladies and gentlemen, Michael Petrilli.

### Conspiracy Advocate (CA)
Claim: Thank you very much. It's a real honor to be here. I was just surprised-- I just saw Rick press the undecided button. So, that was interesting. We'll see how that goes. It is such an honor to be here today. Let me tell you a little bit about what our game plan is, that - - Carmel and I. We've been together all afternoon, we've been scheming about this. I will start by talking about what it means to embrace the Common Core. Then I will talk about some of the problems in our education system and frankly in previous waves of reform that the Common Core is trying to address.

Carmel then is going to talk about the process of developing the Common Core, the role that educators play, the role that evidence played, as well as talk about some of the equity issues that are at stake here, how the Common Core can help to narrow the achievement gap. Now, what you won't hear us argue is, first of all, that Common Core is going to solve all of our nation's educational problems because, of course, it won't. You're not going to hear us say that the Common Core are perfect. They were not handed down from Mount Sinai, they are not set in stone, right, or we're going to hear plenty of concerns about this individual standard or that individual standard, so you won't hear us say that they're perfect. And you're not going to hear us say that it's all going perfectly out there around the country, because, of course, it's not all going perfectly out there around the country. This is a big country, 50 million kids in public schools, 100,000 of those schools, and like any ambitious reform, it's a work in progress, okay? But what you are going to hear us argue is that despite all of that you should still embrace the Common Core.

Now, why is that? Why should you embrace the Common Core? And what does that mean? In our view, to embrace the Common Core is, first of all, to embrace the idea that our schools should have standards, all right, that doesn't sound so radical, and that the standards that we have should be set at a high enough level to indicate that our students are ready for what comes next. And that means kids graduating from high school, that they're either ready to go and succeed in college or to go and get a good paying job. Now, what you might have to understand is that this is a radical departure from how we used to do this. States did have standards before the Common Core, but, by and large, they were set at a very, very low level. And so what that meant is that students could meet those standards, they could pass the standardized tests connected to those standards, but it didn't mean that they were ready for success later on. In fact, in many states it didn't even mean that they were at grade level. And so we had a system that was giving a lot of false information out there to students, to teachers, to parents alike.

So, to embrace the Common Core is to say, "Let's embrace standards that are set at this college and career ready level." It's also to say that we should embrace the idea of moving to next generation assessments, right, tests that measure these standards, that are worlds better than the tests that we've been living with for the past two decades. Many of us in this room as parents or as teachers, we know that there has been this huge focus on standardized testing in this country. And unfortunately, by and large, those tests have been terrible, fill in the blank, multiple choice tests, tests that don't do a good job measuring what students know and that encourage very low level kind of teaching and learning in the classroom. But now, after four years, we're finally getting to the point where there are new assessments coming connected to the Common Core that are going to be much more like advanced placement exams or international baccalaureate exams like the ones that Carol uses in her school, and this is our chance to move to those assessments. So, if you embrace the Common Core, its high standards, its next generation assessments, that's what we are moving towards.

Now, what's the problem we're trying to address? Every study that's ever been done on American education comes to pretty much the same conclusion. It's not that our schools are failing, though some are failing, but on the large, it's not that schools are failing, it's that our schools, by and large, are mediocre when compared to schools overseas. They're in the middle of the pack. They're not the best schools in the world, they're not the worst schools in the world. They're in the middle of the pack. And it's not just our demographics. It's not just because we have a lot of childhood poverty, though we do. Our rich kids are in the middle of the pack compared to other rich kids around the world, poor kids, middle class kids, high achievers, low achievers. Throughout the education system, it's this concern around mediocrity. And we've known this for 30 years. And we have been working hard at trying to address that. And we've made some progress, right? Poor and minority and low achieving kids today are reading and doing math two to three grade levels ahead of where they were back in the 1990s. That's incredible progress.

And our public education system deserves credit for making that progress. And almost certainly it was because back in the '90s and 2000s, states decided to set standards, to have tests that measured those standards, and to have accountability systems to make those standards stick. And it-- again, we've made real progress. But because the standards were set so low and because the tests have been so easy, all of the focus has been getting the lowest performing kids over that very low standard, right? And that's led to great progress for the kids at the bottom but it hasn't done much for the kids at the middle or the kids at the top because they were so far ahead of those standards that it didn't get much traction with them. At the same time, it's come along with a lot of unintended consequences, and we know about those, too, teaching to the test, narrowing of the curriculum, driving out a lot of the joy that we want to have in our schools, okay? And again, Carol, Rick, many others have been very eloquent on this point.

This is our chance to embrace the Common Core, is to fix all of that, to move to a system with much higher standards but also better tests that give better information but that also encourage better teaching and learning in the classroom. Carmel and I had a chance today to meet with a group of teachers, many of them are here in the room tonight, to tell us how it's going with Common Core. And it's not perfect. There's issues, and there is bumps in the road, but they talked about these higher expectations for their students that some of these kids, they couldn't-- you know, four years ago they couldn't believe that the kids could perform at the level that they're performing now, but these higher standards have pushed them in that direction. Now, Rick and Carol are going to say that we should not embrace the Common Core, and I don't know if they're willing to hug the Common Core or kiss the Common Core or fist bump the Common Core, so I'm not-- we'll see what their position it, but what do they want? Do they want us to go back to the old standards, the ones that were set way too low, that gave everybody this false impression that everything was fine? Do they want us to stick with the-- still the standardized tests, these rinky-dink standardized tests that we've lived with for 20 years?

Do they want to follow the example of Oklahoma, the one state in the country that has repealed the Common Core and replaced it with something else right away, and in Oklahoma today, today in Oklahoma schools, teachers did not know what standards they were supposed to teach to. They don't know six months from now which tests they're going to be held accountable to, but I guarantee you it's not going to be one of these next generation assessments because there's no time and there's no money for that. It's going to be one of these rinky-dink assessments instead. Lots more to talk about throughout this debate, but for all of those reasons, this is why you should vote to "Embrace the Common Core." Thank you.

### Moderator
Claim: Thank you, Mike Petrilli. And that is our motion, "Embrace the Common Core." And now here to speak against the motion, Carol Burris. She is an award-winning principal at South Side High in Rockville Centre, New York. She also blogs on "Answer Sheet" in the Washington Post. Ladies and gentlemen, Carol Burris.

### Scientific Advocate (SA)
Claim: Good evening, and thank you for inviting us to this very important debate about the quality of the Common Core standards. I say "quality" because this isn't a debate about whether or not we need standards. Of course we do. And this isn't a debate about whether or not schools should improve. That's a given. Rather, this is a debate that asks whether or not the Common Core standards are so remarkable and so sound that we should embrace them as the standards by which every American child is both educated and judged. In a little while, Rick is going to explain the flaws in the design of the standards. As a lifelong educator, I'm going to explain the flaws in the standards themselves. Let's begin with kindergarten. Listen while I read this Common Core kindergarten standard. "Compose and decompose numbers from 11 to 19 into 10 ones and some further ones. Example, by using objects or drawings and record each composition or decomposition by a drawing or equation. Example, 18 equal 10 plus eight. Understand that these numbers are composed of 10 ones and one, two, three, four, five, six, seven, eight, or nine ones." Now, I ask you, should that be a standard for a five-year-old? Or to put it another way, do the standards know and match what we know now about childhood development? Well, in 2010, when the standards were first rolled out, experts said, "No." Five hundred early childhood experts, pediatricians, psychologists, researchers, and teachers found the Common Core standards to be so developmentally inappropriate that they called for their suspension in grades K through 3.

Back to Louisa Moats, one of the few early childhood experts that were on the team that created the literacy standard, is now one of their most outspoken critics. Why? Because the Common Core standards disregard decades of research on early reading development and instead yank up difficulty levels at every grade. So, how could the developers of the Common Core get it so wrong? The Common Core standards were built backwards from grade 12 down to pre-K. But kids don't grow backwards, they grow forward, and their development is unique and uneven. The Common Core requiring that kindergarteners count from one to 100 by ones and 10s, even though we know that most five years old can count to 20, is as silly as expecting all two-year-olds to be potty trained.

Research did not guide the development of the Common Core standards. And then there is the math. Most of the time, when we think of standards, we think about what topics should be taught at different grade levels. But the Common Core goes beyond and seeks to influence how math should be taught, often in confusing ways. Here’s a first grade example. “Use strategies such as counting on, making ten. Example, eight plus six equals eight plus two plus four equal ten plus four equal 14, decomposing the number leading to a 10. Example, 13 minus four equal 13 minus three minus one equal ten minus one equal nine, and creating equivalent but easier or known sums. Example, adding six plus seven, by creating the known equivalent, six plus six plus one equal twelve plus one equal thirteen.”Now, when you listen to that, are we surprised that we have created complicated homework problems that comedians joke about and that make children cry? This is why parents and teachers are rebelling. In one year, in the bluest of states, California and New York, the Common Core has moved from majority approval to majority disapproval. In one year, teacher support for the Common Core has dropped 30 points. This is not a Tea Party rebellion. This is a parent rebellion and it’s happening because the Common Core has moved from paper to practice, from the ideal to the real. And then yes, there are the tests. Even as the consortia developed national tests, New York State is giving Common Core tests twice. And guess what, they’re multiple choice tests and they don’t look anything like the IB.

Results have been devastating for our special education students, our English language learners, and our students of poverty. And they’re based on arbitrary measures of proficiency. Bad test scores have consequences for kids. Fourteen states require that third graders be left back based on poor reading scores. Kids are put in remedial classes. Test scores decide who gets into gifted programs and into competitive schools. High school graduation rates are expected to plummet. The Carnegie Corporation has predicted that the six year drop out rate will double, from 15 percent to 30 percent. And the four year graduation rate will drop from 75 percent to 53 percent. We already have a preview. The GED test was the line to the Common Core. It dropped 19 points to a passing rate of 53 percent. Here’s the bottom line:There is no evidence, none, that the Common Core standards and its tests will actually increase student learning. And as we engage in this experiment, we may very well hurt the kids who need our support the most. And so I urge you to vote no at the end of this debate, because if we embrace the Common Core, we are embracing a set of flawed standards that will mark as failures more than half of our kids. And your kids and your grandkids deserve better than that. Thank you.

### Moderator
Claim: Thank you Carol Burris. And a reminder of where we are, we are halfway through the opening round of the Intelligence Squared US debate. I’m John Donvan. We have four debaters, two teams of two, arguing it out over this motion, “Embrace the Common Core.”You have heard from the first two debaters, and now on to the third. Let’s please welcome Carmel Martin. She is executive vice president for policy at the Center for American Progress. She’s served as assistant secretary for planning evaluation and policy development at the Department of Education. Ladies and gentlemen, Carmel Martin.

### Conspiracy Advocate (CA)
Claim: Thank you John and thanks to Intelligence Squared for bringing this debate here tonight and including me in it. I want to start by telling you the story of Janelle, a young woman from Philadelphia who I spoke to recently. And whose story embodies why I feel so strongly that the Common Core is a crucial step forward for American education. Janelle is an African American woman from the north side of Philadelphia. Her parents believed in the power of education to transform lives. They had one overriding message for their daughter: Do well in school and you will be the first person in the family to go to college.

Janelle got the message. She worked hard. She took honors courses. She got all As. She was her vice president of her senior class. And she graduated in the top of her class. She was number three in her class. She diligently applied to college, and she and her parents ecstatically celebrated when she not only got into college, a public four-year institution in Pennsylvania, but got a full scholarship. But it wasn't very long after going to college before she realized that she had been duped. The As she'd earned in her honors courses in high school seemed to bear little relationship with what it took to succeed in her college-level courses. In subject after subject, she struggled, becoming more and more dejected. She explained to me how one of the problems that she encountered was that in high school, her teachers helped her translate her textbooks.

But when she got to college, her professors expected her to be able to do that for herself and then analyze the information, as opposed to just understanding it. And her-- she didn't have those skills. They hadn't taught them to her in her high school. As a result-- as a result, Janelle's GPA dropped and she lost eligibility for her scholarships. Now, the good news is, she did-- she has managed to return to college as a sophomore. She was able to fill the gap left by her scholarships with student loans. Many children in her-- in her situation would have given up and dropped out. The Common Core is for Janelle and for the thousands of students who are giving it their all but not getting their money's worth. Now, I agree with something Rick has said before, which is that standards are meaningless unless they're translated into effective instruction. As Mike noted, the Common Core is not a silver bullet for all that ails our education system. But it is an essential building block.

And for students like Janelle who, for generations, have been shortchanged by the old, failed system, new standards will help ensure they are never left behind again. We know what we were doing before wasn't working. We see remediation rates as high as one in four college students who are not ready for college-level material. And that translates, just here in New York, to $80 million in wasted resources that could be spent on other supports for our students to be successful. And that doesn't even address the students like Janelle who are not in remediation, but are struggling with college level content. Some schools, like the one that Carol runs, have adopted International Baccalaureate programs or advanced placement courses to supplement the old state standards, but we can't rely on visionary principles like Carol-- or a patchwork of programs to close our nation's gaping achievement gaps or prepare future generations to compete with China.

Now, I'd like to cut-- clear up a couple misconceptions about the Common Core that had been promoted by the Glenn Becks of the world. First the Common Core was not developed in secret and was not developed by the federal government. This was an initiative led by Democratic Governor Markell of Delaware and Republican Governor Sonny Perdue of Georgia. Back in 2008, virtually all of the governors, with the exception of Rick Perry and Sarah Palin, were strongly supportive of it. Unlike the previous patchwork of standards, the Common Core was developed with significant input from educators and content experts, like the National Council of Teachers of Mathematics. The authors consulted teacher unions, the civil rights community, college leaders, and business leaders. The standards were revised based on over 10,000 comments from the general public. And contrary to the assertion of the opposition, most teachers are not opposed to the standards, and indeed strongly support them.

Now, I appreciate that there has been a great deal of controversy about the way the standards have been implemented and concerns with how test scores are being used in our education system. I think those concerns are real. And we should-- we should address them. But-- and teachers, when asked about the standards in the context of accountability-- particularly accountability for themselves-- their own performance-- they're hesitant about the standards. But despite these concerns, a Winston poll in early August revealed that two out of three teachers approved of the adoption and believed they are what their students need to be successful. And when implementation is done well, which I strongly believe requires that you use teachers to help you develop an implementation plan-- teachers feel excited about the standards and believe they have more, not less, freedom in their classroom. John, a high school geometry teacher, said it better than I could: “The old standards gave teachers a set of specific and sometimes constricting direction on where to turn, when to turn, and how fast to go. The Common Core standards instead give us mileposts to aim for, tell us where we should end up but not how to get there.” And this was something that Mike and I heard loud and clear this afternoon when we were talking to teachers from right here in New York. Later in the debate, I'm sure we'll talk more about the challenges of implementation and the need for commonsense use of tests. Those are important issues. But because we have challenges doesn't mean that we should turn our backs on the incredible work that's been done over the last four years here in New York and around the country to lay the groundwork for the implementation of these standards. I think there are commonsense ways we can and should make implementation go more smoothly. As Mike said, I think that the Common-- new assessments aligned to the Common Core will address one of the chief complaints of teachers and students alike, fill in the bubble tests.

Because the Common Core requires children become problem solvers and good communicators, the new tests aligned to them will measure complex thinking, reading, writing, communications, and problem solving kids' skills. As a result, teachers will no longer be driven to narrow the curriculum or teach to a bad test. There have always been standards and always will be standards. There have always been tests and there always will be tests. It's time to get them right. For that reason, I ask you to "Embrace the Common Core."

### Moderator
Claim: Thank you, Carmel Martin, speaking for the motion. And now, to speak against the motion in the final statement of the opening round, please welcome Rick Hess. He is a resident scholar and director of educational policy studies at the American Enterprise Institute, author of several books on education including, "Cage Busting Leadership." Speaking against the motion, "Embrace the Common Core." Please welcome Rick Hess.

### Scientific Advocate (SA)
Claim: It's a pleasure to be here with you this evening to talk about this issue.

Notice that we-- I am not here to argue that the Common Core is malicious or atrocious. I am here to argue that we should not embrace it. Now, you might wonder why. I heard Mike try to recharacterize the Common Core as meaning that one is for standards, for high standards, and for great tests. Well, if that's the Common Core, then I'm for it, too. But that's actually not the Common Core. That is Mike trying to turn the Common Core into a vague principle that we like good stuff. Carmel talked about Janelle. I got to tell you, if you think there was any state in the Union, circa 2009, that said, "It's state standards," or, "It's okay to graduate high school as an illiterate," that's actually not the facts on the ground. The standards bear only a passing resemblance to what is asked of kids and what actually gets taught. But that's all kind of a distraction. There's a couple reasons that we should absolutely not embrace the Common Core. First, the Common Core does not solve the problem that it was designed to solve.

The motivation behind the launch of the Common Core was what we called the "race to the bottom," after No Child Left Behind, the concern that states were playing games with their test scores in order to make their schools look better than they were. Common Core was supposed to help address this. It doesn't. It doesn't because in order to get a lot of states to sign on, partly with the inducement of federal money, the advocates for the Common Core brutally compromised the design of the thing. Common Core allows every state to set its own cut score, so every state can decide what is or is not passing. The Smarter Balanced Consortium, one of the two federally funded testing consortia, gives states a 12-week testing window. They can decide where in a 12-week period during the spring they would like to test their kids. That means some states can have their kids get 50 percent more learning time than other states.

This is a time-tested way to inflate your test scores. And only about 35 to 40 percent of students are actually going to be tested in the spring with the federally funded Common Core assessments. Other states have been bailing in droves, and we've now got a slew of states whipping up half-baked assessments for next spring that certainly aren't comparable and very likely may be lousier tests than the one they abandoned for the Common Core. So the bottom line is that Common Core actually not only doesn't solve the race to the bottom problem, it may actually aggravate it. Second issue going on here is a number of strident claims were made for the Common Core. We are told that the Common Core is evidence based. We are told that it's internationally benchmarked, that it's rigorous. Well, that evidence is about as disciplined as Mike's reference to the - - his assertion that every study over 30 years-- just no, you can't make statements like this.

There are tens of thousands of studies conducted of United States education, and they don't all show anything. The idea that the Common Core is evidence based? Look, what they mean is the folks sitting on the committees that wrote the Common Core looked at some statistics on the kinds of high school courses that college kids take, and they looked at some surveys of employers and college professors. That's fine. That's good. I'm glad they did that. That's not evidence of what needs to be or not be in the Common Core. In fact, I'm not sure what kind of evidence one would point to, to prove that children need to learn to multiply fractions at this grade rather than that grade. Frankly, these are judgment calls which reasonable people can disagree on. Lynn Fuchs, professor at Vanderbilt, who's got no dog in the Common Core fight, has pointed out that there's no empirical basis for the Common Core, that we don't know yet whether it makes sense to have this particular set of standards or not.

Internationally benchmarked? What they mean is that people on the committees writing the Common Core looked at some international standards, and they copied some, and they didn't copy others. The idea that the Common Core's more rigorous? Well, frankly, the Common Core ends high school math after algebra 2. Most state standards went beyond that. They included trigonometry and pre-calculus before the Common Core. Now, Mike and Carmel might say that they don't think that stuff's necessary or useful, but it's hard for somebody to convince me that these are undeniably more rigorous standards when we're jettisoning the last two years of mathematics. Now, this would all be interesting enough and a reason to maybe go slow, but there's another piece to the puzzle, which is that Common Core is actually not just about words on paper. It's also about theories of hypotheses about how kids will learn better.

These hypotheses are baked into the Common Core, into the tests that have been designed to support the Common Core, and they have received shockingly little debate, given how radical they are. One is a fascination with what Common Core advocates called close reading. This is the idea that students ought to learn to read by deciphering the text-- preferably nonfiction, by deciphering the text without regard to other knowledge and without any personal reaction to the text. Now, I don't have a problem with close reading. It turns out when I taught high school two decades ago, I actually did a fair bit of this. But the idea that this is how every child at every grade level in every subject across an ocean ought to experience reading? I find that a radical proposition. Common Core embraces something called conceptual math. You may have seen some of the worksheets or the YouTube videos.

This is the stuff that Carol was talking about, the idea that elementary children in particular ought to master math by learning the concepts, not just the arithmetic, and the best way to master these concepts is by composing and decomposing lots of these numbers in various drawing exercises. I don't have a problem with this as a way to teach kids math. I find it shocking that this should be the way all children of all performance levels across the nation ought to learn it. Third, the Common Core embraces something called informational text, informational reading. At the high school level it wants kids to read 70 percent informational text. It doesn't want to do this in English class, which is why we are now looking at children in chemistry classes, for instance, reading EPA reports. The idea that you are going to learn science more effectively by reading EPA reports than by doing lab is a radical proposition. In some, given that the Common Core doesn't solve the problem, it has been sold based on exaggerated claim and calls for major changes of a certain value, it seems to me reasonable not to embrace the darn thing. Thank you.

## Round 2

### Moderator
Claim: Thank you, Rick Hess. And that concludes round one of this Intelligence Squared U.S. Debate, where our motion is, "Embrace the Common Core." Remember how you voted before the debate. I want to remind you again that after the debate you'll vote a second time and the team whose numbers have changed the most in your estimation in percentage point terms will be declared our winner. Now on to round two. Round two is where the debaters address one another in turn and they take questions from me and from you and the audience. But to remember where we are and where we've been, we have two teams against two, Carmel Martin and Mike Petrilli are arguing that you embrace the Common Core, thereby they're arguing for the motion. Their argument's saying, "No," they're saying, "The standards are not perfect." They're saying, "The implementation has had problems." But they say that basically the idea is sound and the need is real, that our schools are mediocre, that they're letting down students, not allowing them to graduate in ways where they're prepared for college or the or the job world.

They say that the testing issue is solvable. They say it makes no sense to go backwards at this point because of the chaos that would result. And finally they says “The Common Core standards are a crucial step forward for American education”. The team arguing against the motion, Carol Burris and Rick Hess arguing that you do not embrace the Common Core. They agree that the standards are not perfect and then some. Their argument is that the standards disregard decades of research on child development, on how children learn. That in the testing, children are being presented with questions of such obscurity that it makes them cry. They say that it’s, when the claim that their raising the standard is bogus, when they’re doing things like jettisoning the last two years of mathematics. And they finally come down with this, that there is no evidence that the standards actually will lead to improvements in student achievement.

So, I want to look at a lot of this and slice it up. But there’s one point that I want to get to early in this. Given that a lot of the controversy about this debate has been of a political nature, I heard the opposition make an argument based on substance, which I welcome. Nevertheless, it’s a very political hot potato with the accusation being made that the Common Core was designed in secret by a small cabal of people directed by Bill Gates and by the Obama Administration. Your opponent Carmel Martin, who to some degree was defending against this. You didn’t make that argument at all. I just want to know, do you concede her point? Do you take the point that it was a state thing and on the charges that this is a top down Obama Administration program is one that you concede to that side?

### Scientific Advocate (SA)
Claim: I would say yes and no. You know, certainly they weren’t conceived in secret, but they were conceived by a very, very small group of people who were predominantly non- educators.

And the input happened after the fact. Certainly as an educator, I had really no awareness of any of this going on and I stay very current. Until 2010, and then everything was presented in one fell swoop. Certainly the president has made it very clear that he is supportive of the Common Core standards but mostly what happened was Race to the Top. And that was a federal program. And if you look at some of the writings and went back to 2008, as the Governors Association were talking about this, they were actually saying these are the kinds of incentives that we need.

### Moderator
Claim: Carol, remind people what race to the top was.

### Scientific Advocate (SA)
Claim: Right, Race to the Top was a stimulus program that came into effect shortly after President Obama was elected president. The whole idea behind Race to the Top was that there were going to have to be radical changes in schools, adoption of Common Core standards or something similar., testing programs, evaluation of teachers by test scores, and other things.

And in order to get the money and we all desperately needed the money, states very, very quickly put together applications.

### Moderator
Claim: Okay, let me take that to your opponent. I guess we will touch somewhat on the politics of this. I’m going to take this back to Carmel Martin between you responded to this in your opening statement. We’re hearing Carol Burris saying that de facto, the fact that the administration offered prizes, financial prizes to schools, partly for adopting common standards, does suggest that that this was a federally steered, to some degree federally steered effort.

### Conspiracy Advocate (CA)
Claim: Well, I would say again, this was an effort that was underway before President Obama was President Obama. It was led by a democratic and republican governor from very diverse states. They had the support of virtually again, Sarah Palin and Rick Perry don’t support much, but the other 48 governors were strongly supportive of it.

And the Obama administration supported an initiative that was state led, that was driven from, I would argue, bottom up, not top down. And I think what we need to keep in mind though, is even if--we’ll never know how many states would have adopted the standards but for the incentives provided by the federal government. But then the question before us right now is, given that it was something that was developed, through I would argue, contrary to Carol, through a very rigorous process. It brought teachers into the process. It brought the public into the process. And then once each state adopted it, there was process at the state level around the standards. So, then the question before us is, are the standards good for our students? And Mike and I think it is.

### Moderator
Claim: Okay, and we will come to that question. I want to see if we want to do one more round on the political issue. Rick Hess, if you want to respond to what Carmel said.

### Scientific Advocate (SA)
Claim: Yes, I think first off, Carmel is playing, her characterization of the timeline is I think loose-- what the governors supported in 2008 was the exploration of the idea of making some standards more common. I think most folks, in 2009, 2010, imagine there were maybe a dozen or 15 states that were, themselves, ready, unprovoked, to move forward and explore the Common Core. In fact, Mike, I'd like to hear your take, because you, for instance, have said that the federal government has been heavy-handed with Common Core and deserves to be chastened. In fact, you have encouraged Oklahoma governor Mary Fallin to sue--

### Moderator
Claim: Rick Hess--

### Scientific Advocate (SA)
Claim: --the Secretary of Education.

### Moderator
Claim: I just want to remind you to pull your papers under the mic, because--

### Scientific Advocate (SA)
Claim: I'm sorry.

### Moderator
Claim: --we lose you a little bit when you turn away--

### Scientific Advocate (SA)
Claim: My apologies.

### Moderator
Claim: Why don't you-- why don't you rephrase the question again, just so the radio audience gets to hear it?

### Scientific Advocate (SA)
Claim: Sure. No. Absolutely. My apologies for that. Mike, I'm curious on your response to Carmel, given that you have previously testified to the Indiana State Senate that the federal government has been heavy-handed with this reform and deserves to be chastened.

And that you have, in fact, said that you hope the Oklahoma Governor, Mary Fallin, sues the U.S. Secretary of Education because not through race to the top, but through waivers from No Child Left Behind-- you said, "Nothing gives a secretary of education the authority to push states around when it comes to those standards."

### Moderator
Claim: Okay. Mike, you got to hear the question twice. Extra time to think about it.

### Conspiracy Advocate (CA)
Claim: I did. Yes. And it had a question mark at the end. That was good. Yes. Absolutely. And if we were here to debate the federal role in education, I would move over there. Maybe Carol would be over here. I'm not sure. But we are here to debate--

### Conspiracy Advocate (CA)
Claim: --to debate the Common Core, right? It is true. Look, the-- I think everybody is in agreement. I wrote an article recently with a strong opponent of the Common Core. We wrote together. Here are the facts. It started out as a state-led initiative. And then the Obama Administration came in and endorsed it. There's no doubt that it had a big impact in the number of states that got involved. And in my opinion, we would all be much better off if the federal government would now butt out. So, Carmel, maybe you can share that view with the Secretary of Education.

### Moderator
Claim: All right. Let's move on. Let's stipulate that this side feels that this was not top-down, that it was-- it started with the states. This side feels it's murkier than that. I want to move on now to the substance of the arguments that were made. And I want to take to this side the very strong charge made by your opponent, Carol Burris-- I want to take it to the side arguing to embrace the Common Core. Carol Burris's statement that there is no evidence that these standards actually will result in achievement. What's the evidence--

### Conspiracy Advocate (CA)
Claim: Well, I would say--

### Moderator
Claim: Carmel Martin.

### Conspiracy Advocate (CA)
Claim: --it's early to judge the implementation of the standards.

### Moderator
Claim: But that's not the question. The question is, where is the evidence--

### Conspiracy Advocate (CA)
Claim: I understand that.

### Moderator
Claim: --supporting them?

### Conspiracy Advocate (CA)
Claim: I would-- but I would say, although it's early, we do see some signs of success. And I would point to Kentucky, which was one of the first states to adopt the Common Core. And in--

### Moderator
Claim: Carmel, can I stop you? Only because of time limits, that I think the sense of the question is that when they were put together, prior to their implementation, that there was no evidence that they were-- they were based on no evidence that they would work, as opposed to how they've done--

### Conspiracy Advocate (CA)
Claim: Well--

### Moderator
Claim: --since then. I think--

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: --that was your point?

### Moderator
Claim: Yes.

### Moderator
Claim: Yep. Okay.

### Conspiracy Advocate (CA)
Claim: Well, I mean, I think that's just factually inaccurate.

I think that the folks who got together to draft the new standards relied very heavily on the existing research that they had about what children needed to be able to do and what set of knowledge they needed to have to be successful in college and in good jobs. They brought in the people from the post-secondary sector, something that hadn't been done in K-12 education historically, which really is pretty illogical that that hadn't been done before. They brought in people from the business community to talk about what skills they needed their employees to have. They brought in content experts. They showed the standards to the associations that represent teachers in mathematics and English language arts. And they took in their input. I think neither Mike nor I would say that each and every standard is perfect. But I think if you look at the process that was used in the development of these standards and compare--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --it to the process that was used under the old standards by most states, that it was very rigorous, and they did look at evidence. And you can--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --disagree, but they did look at evidence.

### Moderator
Claim: Carol Burris, have you been refuted on this point?

### Scientific Advocate (SA)
Claim: No. I-- the truth of the matter is, one of the things that's very different about the Common Core that I spoke about, is unlike the old Massachusetts standards, the standards in New York-- which really just identify what kids should know at grade levels-- the Common Core standards create-- or contain what's called instructional shifts in practice. Six in ELA and six in

### Moderator
Claim: ELA?

### Scientific Advocate (SA)
Claim: English language arts. Thank you. For example, the whole idea that it makes sense for young children to engage in close reading-- there is absolutely no evidence that that's the case. At the high school level, yes. But not at the elementary level. There was no real research that was based on yanking up lexile levels. We know from years of developmental reading research that kids do best when they read independently with leveled readers. But the Common Core says no. The Common Core says predominant reading should be on what is considered to be grade level, which has just been increased.

And if the kids don't get it, well, the teachers should read it aloud. Well, let me tell you something. You learned how to ride your bicycle by riding your bicycle. You didn't learn how to ride your bicycle by having your dad never taking his hands off the bar.

### Moderator
Claim: Mike-- let's let Mike Petrilli respond.

### Conspiracy Advocate (CA)
Claim: Yeah, and I'm so glad that you raised this, a couple times, this idea of close reading. And I spent the big part of the weekend talking to some reading experts getting ready for this question, and I think I have a better understanding. It's going to get a little weedy, but I'll get through it very fast. And it's this. We've had a system for years where we've said, "Okay, if a child can only read at the first-grade level and they're in fifth grade, we're going to give them first-grade level books, right, with the hope that over time they would get better. The problem is there's five or six rigorous studies showing by and large those kids were never getting better at reading.

And that they're-- what the studies showed is what you really need to do is find ways to get the kids to read more challenging texts at their grade level, which means at first-- and the teachers today helped explain this so, so much better than I could-- that the teachers start by reading it aloud, having the kids follow along. They do what they call, "scaffolding," over time. And over time, they start to teach the kids how to do this reading so that they can let go of the handlebar and they can ride the bike on their own. And kids who are way behind grade level, including kids who are special education students, are never going to make progress if we don't challenge them with those grade level texts. This is what the evidence says, and the Common Core looks at the evidence.

### Moderator
Claim: Rick Hess. Rick Hess to respond. He's wisely letting the applause die down before he speaks.

### Scientific Advocate (SA)
Claim: Yeah.

Mike, I hate to step on the applause line, but actually I think you conflated two things. You conflated close reading and Lexile. These are not the same thing.

### Moderator
Claim: What's a Lexile?

### Scientific Advocate (SA)
Claim: A lexile is gauging how complicated a piece of reading is-- a piece of literature. Look, close reading is a particular theory of how kids should read.

David Coleman, president of the college board, the lead writer on the English Language Arts Standard, liked to talk about close reading as teaching kids to read like a detective and write like a journalist. Frankly, I think that sounds perfectly fine as one piece of how we teach children to read. I don't think that I'm a particular fan of the idea that every child in America from grades K to 12 ought to learn to write like a journalist.

### Conspiracy Advocate (CA)
Claim: Right, but Rick, is that actually in the standards? Do the standards say that? No. What the standards say is that children need to read at grade level proficiently.

### Scientific Advocate (SA)
Claim: Well, Mike, wait a minute. This is, I think, the degree of ambiguity in the Common Core that drives a lot of people crazy, that at one level the Common Core is just a bunch of innocuous words on paper, you know, one of the eighth grade reading standards, "Compare and contrast the structure of two or more texts and analyze how the deferring structure of each text contributes to its meaning and style." This isn't very different from what most states previously had.

These are a bunch of pleasant words on paper. I have no particular objection to them. The significance of the Common Core is that the advocates for the Common Core and the people who are designing the test talk very explicitly about, as Carol said, these instructional shifts, which have not been publicly debated, which got little public airing as 40-odd states rushed to adopt the Common Core in 2009, 2010, and which portend a dramatic shift in how we teach 50 million children reading and math.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: I'm not sure these are bad things, but I sure as heck think we ought to find out more before we embrace them.

### Conspiracy Advocate (CA)
Claim: But when there is evidence--

### Moderator
Claim: Mike Petrilli.

### Conspiracy Advocate (CA)
Claim: --as we have now in early reading-- there was evidence 20 years ago on phonics-- on phonemic awareness, that was finally incorporated into our schools-- now we have good evidence that these level texts, just having kids who are fifth graders reading first grade texts over and over again, has not been working. Now we have that evidence. It's time to follow the evidence. And that's what Common Core does. Not every point has that, but where there is evidence-- we know that calculator use in the first grade, not a good idea.

The Common Cores says we should not be using calculators till the kids get older. These are dramatically more evidence based than the standards that came before.

### Moderator
Claim: Hang on one second. Carol Burris.

### Scientific Advocate (SA)
Claim: Yeah. I think it's really easy for you to say, Mike, "Well, this is what the evidence shows." I guess what I'm going to say to you is, "Show me the evidence," because what I-- Common Core is wrong about literacy in many ways, okay? in 2013 has pointed out test complexity is based on the erroneous notion that we must ramp up test difficulty beginning in third grade in order to achieve college and career readiness. Kylene Beers and Robert Probst-- these are university professors in reading, their excellent book, Notice and Note, worries that text dependent questions in close reading will lead to student disengagement in reading. Piano, 2013, has shown that the elimination of work-play stations may harm the development of oral language so vital for these learners.

These are all people in the research community and in schools saying, "This does not work." I have never--

### Moderator
Claim: All right, Carol, let--

### Scientific Advocate (SA)
Claim: --seen the evidence that level checks do not work.

### Moderator
Claim: That's exactly the question I wanted to take to Mike. Your response to this

### Conspiracy Advocate (CA)
Claim: Yeah, yeah, no. Well, I will be happy to go find it for you after this debate. I don't have it with me. But, look, here's the question--

### Moderator
Claim: But you're confident that it exists?

### Conspiracy Advocate (CA)
Claim: I-- no, I'm absolutely confident. Look, this has been the dominant way we have taught reading now for decades. And you look at our achievement in reading, and it is mostly flat. And you look at our achievement in reading for special education kids, for kids who are behind, and what you find is that they are not making progress fast enough. We've done better in math where we've made greater progress, particularly for poor kids, but in reading it's been slow. We've made some progress in teaching early reading because of phonics and phonemic awareness because there we finally followed the evidence.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: And what I'm saying is that we need to follow the evidence. The Common Core is saying that's what we need to do, follow the evidence. Kids deserve to be challenged.

The teachers I talk to today, you know-- I mean, Carol's argument earlier-- the four words, "These are too hard," right?

### Moderator
Claim: All right, let me-- Mike, let me-- I want to move on to-- in terms of evidence, earlier when the question of evidence came up, Carmel Martin, you started talking about the evidence so far in places where it has been implemented, how it's doing, and I cut you off because we weren't at that point.

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: I want to hear now, what's the evidence that it's working in places where it's in place?

### Conspiracy Advocate (CA)
Claim: Well, first, I just want to finish Mike's thought there. I mean, when we talked to teachers today, they acknowledge that when the standards were first brought to their schools, they were concerned that they would be too hard for their children, but we heard things like reports that teachers said, "Wow, I didn't think they'd be able to do it and they are," and talk about the joy that they've had in seeing their children meet that challenge. And I have to say, as a former civil rights attorney, it just makes me very nervous when people talk about how, you know, you need to--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --some kids can't reach the same expectations as other kids.

### Moderator
Claim: All right, all right.

### Scientific Advocate (SA)
Claim: Can I jump in?

### Moderator
Claim: Yeah, I want to let Carol Burris respond.

### Scientific Advocate (SA)
Claim: I am the last person on the planet that would ever say, "Some kids can't." I run an integrated high school, 16 percent of our kids are on free or reduced price lunch, and every one of them tomorrow who are 12th graders will walk into an international baccalaureate English class. So, that's-- this is not about it being hard, it's about it being wrong. That's what it's about. It's about it being appropriate.

### Moderator
Claim: Carmel, do you want to respond to that point before we move on?

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: Please do.

### Conspiracy Advocate (CA)
Claim: Yeah, like I said earlier the point-- the example that Carol made about being able to count to one-- to 100 in ones and tens, I know lots of five-year olds who can do that. And I think that if we ask children coming from all different backgrounds to be able to do that, they'll be able to do that.

And, you know, I think that we have lots of evidence that we're-- what we're asking them to do under the old standards wasn't working, that--

### Moderator
Claim: Let me-- let me bring a question to your opponents because it's something about your opening statements that I either didn't understand or confused me. It sounded-- I felt I was hearing a mixed message. I was hearing from you, Carol, "These standards are too high," for kids in kindergarten. And I was hearing from Rick, "These standards are too low," and I'm not sure which way you're going on this. Rick, do you want to take it, or Carol?

### Scientific Advocate (SA)
Claim: I'd be happy to take it. It's not a matter of too high or too low, it's a matter of silly and not right. For example, in the early grades, there are a lot of standards that are not developmentally appropriate, but then when you go up to the high school level, which Rick was talking about-- I mean, I was talking with my math teachers today.

We have to implement Common Core geometry. Well, what does it do? It's a whole different course in geometry based on constructions. Well, it worked out really well for the early Greeks, but it is not an effective strategy today. We actually tried it in our school a couple years ago in anticipation of the Common Core, and the kids were lost. Trigonometry has been stripped out of the algebra 2 class. Since I went to school back in, I hate to admit it, the 1960s, trigonometry was part of the course of studies in high school. Common Core has changed it. It's not algebra 2. So the problems that you hear is not, "It's too hard," or, "It's too soft," it's just not right at a variety of levels.

### Moderator
Claim: Okay, and I want to take-- I want to move to that-- and so your point being it's wonky in many ways?

### Scientific Advocate (SA)
Claim: Yes.

### Moderator
Claim: Fair enough. It can be wonky in many ways, and your point would hold up. I want to take to Mike Petrilli because you were talking in your opening statement about the nature of testing.

And you were saying that there's-- "I sense a technology of testing that's better than it used to be."

### Conspiracy Advocate (CA)
Claim: Right.

### Moderator
Claim: Testing is one of the things that parents are most upset about. Not only are they confused about the work that they’re doing, they’re very, very upset about the testing processes. What is your response to those parents?

### Conspiracy Advocate (CA)
Claim: Right, is that their concerns are very well founded, as are the concerns of many educators who have been complaining for years, decades now, that the tests we’ve been using to judge schools are not well designed. And they’re right. Those tests by and large have been very inexpensive tests. They’ve been set at a low level. They’ve been fill in the blank. And now we finally have this opportunity to move to much better tests with the Common Core, that are under development, that are coming this spring for the very first time in about half of the country. And this is our opportunity to now address many of those concerns. And for example, these tests will have a lot more writing on them than most of the other tests had. It’s very hard to test kids’ critical thinking skills if it’s just multiple choice. Right, certainly hard to test their writing skills.

Yet a state like Georgia has been trying to get by with a test that costs eight dollars per kid and therefore doesn’t have any writing on it. And what we’re trying to do here is to turn that page. And say look, there were major problems with the test under the No Child Left Behind era. We’ve heard those concerns and now we’re trying to get something better, something that I think that Carol and Rick have supported in the past.

### Moderator
Claim: I’d appreciate it if Rick, if you want to step in, because we haven’t heard from you in a bit. And you look like you’re steaming over there. If you want to defer to your partner, please do.

### Scientific Advocate (SA)
Claim: No, I always look that way. Two thoughts, one on testing and one just on the prior question. One, you know John, one way to think about this is it’s really we’re debating embrace the Common Core. Again I’m not declaring the Common Core to be atrocious or malicious. I am suggesting that the standard of proof for the Common Core is much higher than for old state standards. Massachusetts had had state standards in place for 18 years, give or take.

Those standards had produced substantial and sustained improvements in student learning. If what Mike and Carmel had been advocating for, was taking these standards whose tires we’ve kicked for 15 or more years, and taking those national, I would have been very open to that. The idea that we have a bunch of design hypotheses about what kids should know, we think, maybe, and how they should learn it, maybe. The idea that we want to roll this out for 50 million children with little opportunity to see how this plays out or what it means, leaves me remarkably nervous. So for me-- So, for me it’s less about too high or too low. I think frankly we just don’t know. On the testing point, I mean, like I said at the beginning, I’m with Mike. I’m for good tests. I’m anti-bad tests. Mike and I are on the same page here. But I think the notion that the Common Core tests are good is an open question.

### Moderator
Claim: Okay I want to remind you that we are in a question and answer section of this Intelligence squared US debate. I’m John Donvan your moderator and we have four debaters, two teams of two, debating this motion, embrace the Common Core. Let’s go to some audience questions. Again if you raise your hand and wait, a microphone will be brought down to you and we’d like you to stand up. And hold the mic about fist distance from your mouth for good broadcast quality right in the center there. And if you stand up, a mic will find you. Coming, it’s coming from your right hand side. So really nice, tight, do me proud, good question.

### Moderator
Claim: Hi, My name is Nareda and I’m not a teacher or an educator. I’m actually Janelle. I went to Smith College and then later to Oxford University and my first year at Smith was tough. So my question is about the next generation learning tests. How do or do not, how do they measure critical thinking skills, with the caveat that PISA, the countries that score the highest in PISA are using multiple choice straight answer tests?

### Moderator
Claim: Let me ask you if you could rephrase your question in a way that lets him convince you to embrace the Common Core. So, are you saying are these next generation tests the key, the secret, are they going to save it?

### Moderator
Claim: I want to know more about them. Exactly, we want next generation exams that are no longer simple to answer. But how do they actually, what role do they play in actually measuring critical thinking skills and developing them so that we have a standard?

### Moderator
Claim: Can I rephrase your question to be--

### Moderator
Claim: Yeah.

### Moderator
Claim: Tell us why these next generation tests are working and why therefore we should embrace the Common Core. That’s the gist of your question?

### Moderator
Claim: Exactly that.

### Moderator
Claim: Okay. Carmel Martin.

### Conspiracy Advocate (CA)
Claim: I would say the Common Core standards very much drive towards teaching and assessment that is focused on creating problem solvers and good communicators, those kinds of skills. And we heard just today from a group of teachers that we talked to, that under the new assessments, they can’t teach to the tests anymore, because the tests are no longer about rote memorization.

It’s about children being able to make inferences and digest the texts, so I think it goes exactly to the point that you mentioned. The crafters of the Common Core did look at at PISA. They also looked at Massachusetts and they did borrow from places where they thought it was working, as well as looking into the evidence, so I think it really tackles the issue that you're talking about very effectively. And I think assessments aligned to those kinds of standards should really help us move away from a mode of rote memorization towards teaching in an enriched way.

### Moderator
Claim: Carol Burris.

### Scientific Advocate (SA)
Claim: I think it's always helpful to have an example. Here's what's called the Research Simulation Task. The Research Simulation Task-- this is from PARCC-- is an assessment component worthy of student preparation because it asks students to exercise the career and college readiness skills of observation, deduction, and proper use and evaluation of evidence across text types.

In this test, students will analyze an informational topic presented through several articles, multimedia stimuli, the first text being an anchor text. Students will engage with the text by answering a series of questions and synthesizing information from multiple sources in order to write two analytic essays. I think that sounds great. Grade 3. That was Grade 3. You know what? If kids can do that at the end of Grade 3, I can retire. Just give them calculus in fourth grade and send all those Doogie Howsers off to college.

### Moderator
Claim: Another question?

### Moderator
Claim: Kelly Posner-Gerstenhaber, Columbia University. Now, we all know that every child deserves the right education, but many think tanks and thought leaders talk about one of the most critical issues in our nation is-- is talent development.

And the future of our country actually depends on not ignoring them anymore. And by the way, the low-income high achieving kid is probably the most underserved kid in our nation. It's been said that--

### Moderator
Claim: But I need-- I need you to--

### Moderator
Claim: --zero into your question.

### Moderator
Claim: --I'm getting there. In states where there's--

### Moderator
Claim: No. No. I need you to get there right now.

### Moderator
Claim: Right. I'm getting there right now. In states that are doing better, Common Core is actually going to bring them down. So I was wondering what you thought, how Common Core actually addresses the needs of this underserved group.

### Moderator
Claim: Carmel Martin.

### Conspiracy Advocate (CA)
Claim: Sure. I would say there have been analysis comparing the Common Core to the high- achieving states, like Massachusetts, and shown that they are comparable and higher in some respects. So, I-- and I think if you look at-- talk to the folks in Massachusetts-- just as an example-- they feel like the Common Core is helping them to serve all their students-- because they're focused on development as skills, again, and not just rote memorization and test preparation, that it's helping-- we heard this today as well, but it's helping children across the spectrum in terms of where they start.

I started saying earlier, Kentucky is one of the first states to implement the Common Core. In just one year, their high school graduates ready for college and career jumped from 34 percent to 47 percent. And that's still not good enough, but that shows clear progress. You-- also in New York, this year, again, slow progress, but since implementation of the Common Core, there has been increase in performance. And the best increase has been among minority populations. Three to four percentage points for African American and Hispanic students here in New York.

### Moderator
Claim: Rick has a response.

### Scientific Advocate (SA)
Claim: Sure. I mean, one, Carmel-- I mean, I think this point about Massachusetts, if I recall right, Mike, for instance, has argued that the Massachusetts standards were better-- or at least as good as the Common Core. So, yet-- I think let's be careful about imputing claims to the Common Core. Even folks who support them, I think, tend to be more measured about how good they think they are.

Second, the Kentucky point-- the fact that you've got more kids scoring proficient doesn't mean anything whatsoever. You can adjust a cut score in any direction you want. This has always been the concern with post-No Child Left Behind testing. So, the fact that Kentucky scores went up doesn't tell us a thing unless we know how Kentucky is setting the score and

### Moderator
Claim: By-- this and by cut score, you mean make-- the score at which you make the cut to pass or fail?

### Scientific Advocate (SA)
Claim: That's correct.

### Moderator
Claim: Or to graduate or not graduate.

### Scientific Advocate (SA)
Claim: That's correct.

### Moderator
Claim: Okay. Let's go on to another question. Right down in front here. If anybody is raising their hands in the back, I've got to-- or upstairs, I can't see you, so I just want to ask you to come down a few steps please.

### Moderator
Claim: Sure. So I understand this--

### Moderator
Claim: Can you tell us your name, please?

### Moderator
Claim: Oh. Effie Fisch I understand the side arguing against-- has posed a lot of criticisms on the Common Core tests. But I want to go back to something that you had said in your opening remarks, about if we accepted that position, what would we be accepting in its place? Is it a national test based on the Massachusetts standard? Is it going back to different state standards? Would we just be kind of waiting and hoping something came along better?

### Moderator
Claim: What would happen if we don't embrace the Common Core?

### Moderator
Claim: Sure. That's a great question.

### Moderator
Claim: All right. you want to take it?

### Scientific Advocate (SA)
Claim: So, you know, my response would be, "Look" I think not embracing the Common Core says that if there are states where parents and educators and policymakers are sufficiently enthused about the work-- I think there's eight or 12 or 15 of these-- I think they should proceed. And they can go down that road, and we can see how well it works and see what the results are. I think in other states we should absolutely, as Mike suggested, get the federal government the heck out of this question through No Child Left Behind waivers or anything else. We should feel comfortable with states either choosing to revert to the standards they had in place, highly regarded previous standards like Massachusetts', D.C.'s, Indiana's, or California's, because, remember, nobody hit the delete button on those old standards, on the curricula that matched, or on those assessments.

I think it makes sense, before one does a dramatic and bold remaking of 50-- of the schools serving 50 million kids, that we actually move deliberately and carefully for once and see how this works and what unanticipated changes lurk.

### Moderator
Claim: Mike Petrilli.

### Conspiracy Advocate (CA)
Claim: Well, you know, I know Rick spends a lot of his time writing books in a cave somewhere. I think he's been in a cave perhaps-- because Rick is 2014. Teachers have been implementing these standards for four years in these states, okay? So, you know, there are enormous--

### Moderator
Claim: Let him go on, and then I'll come back to you.

### Conspiracy Advocate (CA)
Claim: You know, there are enormous, enormous costs, financial, morale issues. You know, teachers have put their heart and soul into teaching these standards-- I mean, we heard from some of these teachers today-- for four years. So let's be clear that this is not now a hypothetical argument, "Should we move forward? Should we adopt the Common Core?" Schools have adopted it. They're moving forward. And so now the question is, "Should we go back and undo all the work of the last four years?"And you've held this very high bar, both you and Carol today, that basically the Common Core have to be remarkable in order to go ahead. So if you're going to go back to those old standards, those lower standards, in the vast majority of states, what is your evidence that we should move to those lower standards? Why aren't you having a high bar for that?

### Moderator
Claim: Carol Burris. You know, your argument basically is, "We're stuck now," I mean, but--

### Scientific Advocate (SA)
Claim: and that, I find to be a very frightening--

### Moderator
Claim: Carol Burris.

### Scientific Advocate (SA)
Claim: --I find to be a very frightening argument. I-- you know, I don't live in the world of talking points where I have to worry about changing my mind. I live in the world of kids, and I see what the Common Core standards are doing to kids. I hear my teachers come in. I don't know what group of teachers you're talking to, but they're very different than the ones that I work with every day who come in, showing me bizarre worksheets, who tell me their children don't want to go to school anymore, that they hate school, that they want to be able to read interesting books instead of technical manuals.

You know, we're really resilient smart people, teachers. Please don't think that we could not adjust. I've lived through four sets of standards since I've been in education. We can do it. We can do the work. We need the federal government to back off, and we need to have dialogues within our states where we take-- maybe we start with the Common Core. We clean up what's a mess, and we make them actually better. You know, there is something about competition that is not a bad thing. If we are all doing the same thing in every state and doing it the same way, where will the new ideas come from? I really see the changes in my high school.

### Scientific Advocate (SA)
Claim: And they're not positive.

### Moderator
Claim: This matter of-- this matter of going back at this point reminds me as I was reading on this, one Republican governor who was very enthusiastic about this.

And then I guess put his finger in the wind and became very unenthusiastic about it. I paraphrase him, but he said, "It's never too late to make the right decision." I want to remind you we're in the question and answer section of this Intelligence Squared U.S. Debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, debating this motion, "Embrace the Common Core." Let's go back to audience questions. Anybody farther up who I'm not seeing? Sir, right there. If you look to your left, he's coming that way. If you could tell us your name again, please.

### Moderator
Claim: Hi, my name's Trevor. I went into a private school where we didn't have a lot of testing. And I found out my motivations for learning were genuine and a little more self- motivated, so the nature of just testing itself, I want to know numbers, quantitatively how much testing is there in the Common Core to be expected, and also what do you think that those specifically for the morale and-- of the students and also the teachers?

### Moderator
Claim: Carmel Martin.

### Conspiracy Advocate (CA)
Claim: Well, I don't have the exact numbers in terms of how much time will be spent testing, but it is my hope that under these new better fairer fewer assessments under the Common Core that we can eliminate a lot of the testing that happens around the country under the old set of standards and assessments, what we see across the country is districts layering on additional assessments on top. And I think as we move towards these better assessments under the Common Core that we can eliminate unnecessary testing. I think testing is a tough issue. It's something-- my kids hate it, and I have to explain to them why they have to do it and how it provides really valuable information to their teachers about how they're doing so they can help them to do better, just like when I bring my child to the doctor and they say, "I really don't want to get that shot," sometimes you have to do things that aren't very pleasant. I think what's important is to make sure that in creating a culture around testing, we're not making children stressed out, we're not making them cry over the tests. And I think that part of that is professional development, the environment in the school around the tests. We heard that-- we heard that from some teachers we talked to today about how that's-- and that takes a lot of leadership in the school to make sure that it is being used as a tool to get better. I think Carol has made a lot of good points about the way assessments are being used, that we really should take a closer look at that--they do help create a negative culture around testing. But again, that's about how the tests are used, not what the standards should be and whether you should have the assessments so you can learn from them and improve practice.

### Moderator
Claim: Carol Burris.

### Scientific Advocate (SA)
Claim: Yeah, in New York State, testing was increasing anyway, but under the Common Core it's gotten worse. You're talking about increases of 200 percent, for example, at some of the grade levels. You're talking about three days of ELA testing, three days of math testing, and a lot of it is really because of not only the Common Core itself, but also the policies that were also part of the Department of Education that Carmel worked for.

So, that teachers now are evaluated by test scores which then added a lot of other additional tests. All of these things have come together at once, and kids are crying. I've had colleagues who-- they've had kids who've wet their pants. You know, kids want to do well on tests. They want to please their teachers. They want to please their parents. And when they find themselves reading and rereading paragraphs in order to do close readings and flipping back and forth, some of them really just start to give up. You know, in New York, we had 60,000 kids opt out of testing last year. We never had that. We never had that before.

### Moderator
Claim: Another question. I'm just trying to look farther up in the back. Right up against the wall there.

### Moderator
Claim: Hi, good evening. My name is Pamela.

I'm a New York City Department of Education teacher. I've been teaching since the late '70s. You know, through all of our professional development and graduate programs, we're always talking about differentiated instruction and how important this is for our special needs students, ELA students, ESL students, regular ed students. Everybody learns differently. We all know this. There's been a hierarchy of learning for all those years. My question is how does adhering to the Common Core advance the progress of teaching with differentiated instruction to support the way that students learn and the way that they test because, as you said, not all students test well.

### Moderator
Claim: Okay, you actually had a question mark, and I'm going to land it there.

### Moderator
Claim: Yes, I did.

### Moderator
Claim: So I'm going to-- I'm going to go--

### Moderator
Claim: Yes, thank you.

### Moderator
Claim: Thank you for the question. Go to Mike Petrilli.

### Conspiracy Advocate (CA)
Claim: Thank you. That's a great question. You know, this is key. And we've had these debates for a long time. Just to say that, you know, standards does not have to equal standardization, right? We want to make sure that our education system is linked to success for what comes next, and that means that if we're measuring student progress, this should be against the real world and what they're going to have. But that does not mean that we have a standard way of getting there. Different schools have different approaches, different teachers have different approaches, and different kids are going to learn different ways, and that's all absolutely appropriate. What we don't want to have is a system that has standards that are set so low that we're giving the false impression that kids are doing fine when they're not. And, you know, Carol, I know you keep saying, "Well, it's not too high, it's not too low, it's just wrong." Go back to those old systems, okay? Colorado, before they adopted the Common Core, for example, you could score at the 10th percentile in reading in Colorado and be considered proficient, okay? So you would get a report as a parent that your child is proficient. That's great.

Okay, what you didn't know was that, that meant that 90 percent of the kids at that same grade level nationwide were reading better than you were. That meant that you weren't ever even close to being on grade level. That is the system that we had, and that is the system that state states that are thinking about pulling out the Common Core, which is mostly in these red states, with big Tea Party influence. That is what they are going back, that’s what this is about, that’s why we need to keep moving forward.

### Moderator
Claim: Rick Hess.

### Scientific Advocate (SA)
Claim: So Mike, first that’s not an accurate characterization of what it means to be a Common Core state. As you well know, lots of Common Core states are making up their own tests. They are choosing their own cut score. Nothing of significance has changed from under NCLB. So imputing this great virtue. Secondly these statistical gains can be played both ways. James Milgram, Professor Emeritus at Stanford, one of the five members of the Common Core validation committee who refused to sign off on the quality of the Common Core, has pointed out that if you look at federal data for instance.

That students who only go through Algebra II, only 40 percent of them ever complete a four year college degree. Whereas 75 percent of students who take pre-calculus, which those old Colorado standards had, go on to complete a college degree. So, I guess if we’re going to argue about these implications, one question is, why truncate it if this data seems to suggest that the Common Core is going to have fewer children ready to complete their educations?

### Moderator
Claim: Mike Petrilli.

### Conspiracy Advocate (CA)
Claim: Right so, let’s go back to the question about testing. Rick is right, that there are a number of states out there, that because of political pressure, mostly from the political right, have decided to pull back from the Common Core testing. Right, it’s because that’s the position you are arguing. Your position is being heard in red states and they are saying, therefore we’re not going to do these better tests. We’re going to do our own tests. Because we don’t want anything involved with the federal government.

We’re afraid of all kinds of other issues. My argument is that those states have not embraced the Common Core. They have not fully embraced the Common Core. Because you cannot embrace higher standards if you don’t also embrace better assessments.

### Scientific Advocate (SA)
Claim: But Mike, embracing the Common Core.

### Conspiracy Advocate (CA)
Claim: They go together.

### Scientific Advocate (SA)
Claim: Embracing the Common Core, does embracing the Common Core mean embracing a national cut score?

### Conspiracy Advocate (CA)
Claim: It means embracing a rigorous standard .

### Scientific Advocate (SA)
Claim: No, no, no. Does it mean embracing a national, because otherwise, states can use a Common Core tests, which are still very much of unproven quality, as I think you’ve publicly conceded. We don’t know if they’re good tests or not. But you can use those tests and still make up your own cut score, and still three extra months of instruction. So the idea that you are now getting honest clear apples to apples comparisons because you have used, it is just simply.

### Conspiracy Advocate (CA)
Claim: Then I am excited.

What I think I’m hearing Rick, is that you agree with our position, that we should embrace the Common Core, embrace good assessment and make sure that the states are

### Moderator
Claim: No, no, no, no, no.

No, he actually asked a really good specific question. Which is, if the Common Core is embraced from California to Maine to Florida, to Alabama to Montana, does the kid in Montana have to get the same score, to get, on the same test, to get past through the high school, as the kid in Alabama?

### Conspiracy Advocate (CA)
Claim: Right. I would prefer that kind of policy. And it looks like the states that are doing the PARCC test, as far as we can tell, are going to agree to a common cut score. We’re not sure yet about Smarter Balance. I think even those other states, even those that don’t have great tests, all signs are, even those are going to have much more challenging cut scores than they had before. So we will have made some progress on these issues. But look, Rick, I would love-

### Moderator
Claim: That’s a yes.

### Conspiracy Advocate (CA)
Claim: That is a yes.

### Moderator
Claim: Okay, you got a yes on that. Are you surprised by that? Now where do you go?

### Scientific Advocate (SA)
Claim: I mean I think, frankly, I think this is part of it. I think not embracing the Common Core is to say look, a number of states should do the Common Core and they should do it uncompromisingly and aggressively. And we should see if their children actually benefit.

### Conspiracy Advocate (CA)
Claim: How long do you want to wait?

### Scientific Advocate (SA)
Claim: I’d like, I’d like, I’d like--

You know, I wrote a book, in my Harvard dissertation, close to 20 years ago, called Spinning Wheels. Pointed out that the average urban school system in the United States launched 13 major reform waves between ’92 and ’95. That is the history of education at stake, that we excitedly tout a new thing, an exciting thing, No Child Left Behind, or reading verse, or comprehensive school reform. We have to rush it out, into lots of venues and lots of sites. And then when it doesn’t work, we go oh gosh, but we got another one for you. For once, just for once, I would like us to actually try to keep the Common Core.

### Conspiracy Advocate (CA)
Claim: Follow through on what we started?

### Scientific Advocate (SA)
Claim: Excuse me?

### Conspiracy Advocate (CA)
Claim: You’d like us to follow through on what we started?

### Moderator
Claim: Oh, well.

### Moderator
Claim: I have a quick question.

I’m the mother of a special needs child. I am also a teacher of English language learners. But my question is, are these standards copyrighted? And as a result of that, can teachers veer off the script? That's my question.

### Moderator
Claim: Let's take it to Carmel Martin.

### Conspiracy Advocate (CA)
Claim: Yeah. They are not copyrighted. They're open. And teachers-- I think where we see Common Core being implemented effectively, teachers aren't following a script. What we see is that the-- as I said in my opening, the standards create guide posts, a destination. And teachers are able to then construct lessons so they can differentiate for the children in their class. We have heard very positive things from teachers of special ed students, that in some ways, they're better than the old way because it allows you to get the answer through different methodologies-- and math, for example, it's-- allows for different ways to get to the answer.

So, I would say that they should not feel scripted. I do think, in some places, with that-- with those bad instructional leadership, they're being given scripts and told to follow the script. But I don't think that's the right way to implement the standards. And I don't think the standards themselves dictate that. I think the standards really try to shift in the direction of giving teachers more freedom, like the teacher that I quoted in my opening had mentioned.

### Moderator
Claim: Carol Burris.

### Scientific Advocate (SA)
Claim: The Common Core standards most certainly are copyrighted. They are. And I really-- all of you. Go online tonight and look. You're going to see that they're copyrighted. They're not allowed to be changed. When they're adopted by states, states may add 15 percent, but they cannot change any of the standards. That's one of the problems. Second, in terms of scripts, if you look, in New York State, Engage New York, we spent over $28 million for curriculum.

And that curriculum is full of script. And those scripts-- at Engage New York, at least you publicly praised when you've talked to-- I think it was the Governor's Commission, you said how wonderful Engage New York is. They truly are scripts. And we find so many teachers who are so afraid to go off-script, to not teach exactly what--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --Engage New York says--

### Moderator
Claim: You've made the point--

### Moderator
Claim: --unfortunately, I want to let-- I want to let Carmel respond. Or Mike Petrilli.

### Conspiracy Advocate (CA)
Claim: Sure. Let's talk about--

### Moderator
Claim: Michael Petrilli.

### Conspiracy Advocate (CA)
Claim: New York is an interesting case, because it is the only state in the country that has developed a fully fleshed out curriculum. And I think you can certainly make the case that it's too fleshed out. And out-- and good administrators will tell their teachers, "Hey, use it as a resource. And it's there for you. But by no means should you be following it word-by-word," okay? You know, it-- most states have the opposite problem, which is that there's nothing. There's nothing been developed, and teachers are saying, "I'm desperate for something to help me teach to these standards." And what those teachers usually use is Engage New York.

## Round 3

### Moderator
Claim: We have a-- we have to wrap up this section of the debate, but before we do, I want to bring a question in from an NPR listener. It's a question for the against side. I'm not going to give you time to answer it, because I just want to let it linger, because I like the question. It's great-- it's great to think schools are incubators for new ideas, but what if you're in a school system with subpar teachers and administration? Surely not all principals are like Carol. Something to consider. And that concludes Round 2 of this Intelligence Squared U.S. Debate, where our motion is Embrace the Common Core. And here's where we are.

We are about to hear closing statements from each debater. They will be two minutes each. And remember how you voted before the debate. Immediately after the closing statements, they will-- we will have you vote again. And this is their last chance here now, for them to change your minds. Onto Round 3, closing statements. From each debater in turn. Our motion is this-- Embrace the Common Core. And here to give you his summarizing statement in support of this motion, Mike Petrilli, president of the Thomas P. Fordham Institute.

### Conspiracy Advocate (CA)
Claim: Great. Thank you, John. And thank you so much to Rick, and Carol, and Carmel for this great discussion. It's-- it is so nice for a change to have a discussion about the Common Core that is so substantive, because unfortunately, that's not been what's happening for much of the last couple of years. I just want to say to some of the points that Rick and Carol made. They're very smart to go and to look at some of the specific standards that they've got questions about.

And as we said at the beginning, there's no doubt, the Common Core are not perfect, nor are they set in stone. You look at states around the country, they have found ways to add to the standards. Florida, for example, adding calculus to their math standards because of some of the concerns that Rick made. Totally legitimate. Other states adding cursive, because parents have been concerned we're not teaching cursive. There are no Common Core cops. States are free to do that, and they should do that. And they should make them their own. But I want to talk again about what happens on the other side of this if you go backwards. Rick is right. Rick's book, "Spinning Wheels," you should read it. It's a classic, right? You want to see spinning wheels? Go check out Oklahoma right now, because that's where you have spinning wheels, because the legislature decided out of political pressure to pull back on these standards. You listen to Jeannetta Jante she's a English language arts teacher at Oklahoma City's Southeast High School, she called that decision a "travesty." She says, quote, "Now it's like we've wasted teacher training, teacher time, lesson planning, resources, all of those things we've just done. The senators have basically said, 'Oops, sorry, we didn't mean for you to do all of that.'The chaos in the classrooms will be great. The chaos in the classrooms will be great." Okay, we are four years into this. And many, many teachers, millions of teachers across the country are working hard at making Common Core work. We should follow through now on what we have started. We should make it better as we go. We should address problems and challenges. But we should embrace the Common Core. Thank you.

### Moderator
Claim: Thank you, Mike Petrilli. And that's our motion, "Embrace the Common Core." And here to summarize her position against this motion, Carol Burris. She is principal of South Side High School in Rockville Centre, New York.

### Scientific Advocate (SA)
Claim: Well, you know what, there probably is a mess down in Oklahoma. But in Ohio what they're doing is they're considering adopting the standards of Massachusetts. Doesn't need to be a mess. It doesn't. About 10 years ago my husband and I bought a new car. It was gorgeous. It was silver.

It had heated leather seats, a great steering wheel, lots of pep. I loved that car. And then one night when we were coming home about a month after we bought it, it broke down. The oil light went on. Took us 10 minutes to get the car going again. Brought it into the station. They tweaked it a little bit. And they sent us on our way. Well, six months later the car broke down again, and this time when we brought it in, they weren't quite so nice. They started asking us, "Well, what kind of oil were you using?" A year later, same thing happened, car stopped, oil light went on. We couldn't get it started. The car had to be hauled in. Now we said we wanted the oil pump repaired, and all of a sudden they started talking about how maybe we had not kept it up properly. We just had not implemented that car the right way. Well, the bottom line was when we looked online we found out that a lot of other people were having the same problem.

We bought a lemon. We bought a lemon. But luckily, luckily, there were other cars for us to buy. I have to tell you, from my perspective, 25 years as an educator of I think one of the finest schools in the country, the Common Core is a lemon-- and the problem is because it is on a national scale it's the only car that they want to have on the lot. Our kids deserve better than this. They deserve new ideas. They deserve new approaches. They deserve differentiation. And they certainly don't deserve what has happened in New York where only 30 percent of the kids are deemed to be proficient based on an insane standard.

### Moderator
Claim: Carol Burris, I'm sorry your time is up.

### Scientific Advocate (SA)
Claim: Okay, don't embrace the Common Core.

### Moderator
Claim: Thank you very much. "Embrace the Common Core," is our motion, and here to summarize her position in support of the motion, Carol Martin, she is executive vice president for Policy at the Center for American Progress.

### Conspiracy Advocate (CA)
Claim: Thanks, John.

### Moderator
Claim: I'm sorry, I want to redo that because I just mispronounced-- misspoke your name. I'm just going to do it again for the radio broadcast so that, that never happened.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: The miracle of editing. And here to summarize her position for the motion, Carmel Martin, executive vice president for Policy at the Center for American Progress.

### Conspiracy Advocate (CA)
Claim: Thank you, John. As a mom and a former civil rights attorney, I've seen firsthand the consequences of low expectations and their long term effects. Our children do deserve more. They deserve to be taught to the level that they need to be successful in college and career, and that's the overarching goal of these standards, and there's lots of evidence to support that it will get them to where they need to be. The Common Core gives teachers the space to create an exciting classroom experience for all rooted high expectations, project-based learning, problem solving, and exploring concepts deeply instead of focusing on worksheets and rote memorization.

If this were 2012, all four of us-- all four of the panelists here would be in agreement that we should not repeal the Common Core. Carol said as recently as 2012 that higher level thinking is more prominent in the Common Core than in all present state standards. And Rick said just last week that he was not necessarily saying to pull out of the Common Core. I think what he's saying tonight is the jury is out. What Mike and I are saying is to-- let's keep moving forward because our children can't afford to wait any longer for higher standards, and they can't rely on extraordinary principles or teachers to help them get there. The achievement gaps in our country are staggering, and it's time to tackle them aggressively. Your vote tonight will be closely watched and folks outside of this theater may not understand all of the nuance of Rick and Carol's position. A vote to not embrace the Common Core will be interpreted as a vote to repeal the Common Core altogether.

And as Mike said, we do not believe that there are good alternatives to that. There are real consequences to this decision, higher versus lower standards, new expenses in changing course, frustration for countless educators. Those consequences should be at the forefront of your decision. Students who come to high school, falling behind, only one in 10 of them get to catch up, according to a recent ACT study. We need to get to them earlier.

Okay.

Thanks, John.

### Moderator
Claim: Carmel Martin, I'm sorry, your time is up.

### Conspiracy Advocate (CA)
Claim: I urge you to "Embrace the Common Core."

### Moderator
Claim: Well done, thank you. Carmel Martin. And that's our motion, "Embrace the Common Core," and here to summarize his position against this motion, Rick Hess. He is director of educational policy studies at the American Enterprise Institute.

### Scientific Advocate (SA)
Claim: Thanks, John, it's a pleasure to be with all of you this evening. Mike, Carmel, thanks for a terrific conversation. Mike and Carmel tonight have repeatedly suggested that the Common Core is right on the big things, that all of the concerns, the tests, the curricula, the instruction are glitches, they're bumps in the road, they're things to be worked out.

For me, having done this for a while, this all brings to mind the advice offered by a thoughtful pundit a few years ago on another major reform effort, No Child Left Behind. On reflecting on NCLB, this pundit, who had enthusiastically championed it until he soured on it penned a terrific chapter for a book of mine, titled, "The Problem with Implementation," is the problem. The author was our own Mike Petrilli. In this chapter, Mike observed the central task of No Child Left Behind implementation is translating its aspirational statements in bold principles into action in the real world. To work well at the local level in real schools affecting real children, its contradictions must be resolved, its fuzzy notions must be made crystal clear. He wrote that when this fuzziness led to confusion, the fault must be placed on the law itself, not just on those charged with carrying it out.

Mike offered some terrific advice there on this whole question of whether to embrace these kinds of changes. He observed, "Where the implementation of the law has gone most smoothly is where at least a handful of states and districts have already paved the way." I think that was great advice. I think Common Core, like No Child Left Behind, certainly deserves its day in the sun. I'm not opposed to giving it a chance to show what it can do. Happily, states have only begun implementation in earnest in most cases. Until 2013, two thirds of American adults had never even heard of the Common Core. This is actually a propitious moment to hit pause, slow down, figure out what we're doing before we get too far downstream. For that reason, I'd like to ask you tonight to please vote against embracing the Common Core.

### Moderator
Claim: Thank you, Rick Hess. And that concludes our closing statements.

And now it is time to learn which side you feel has argued the best. We're going to ask you again to go to the keypads at your seat. You've been through this once. It's the same thing. Push number one if you agree with the motion, "Embrace the Common Core." Push number two if you disagree. Push number three if you remain or even became undecided. And it will take-- that can happen. Nothing wrong with that. And just-- if you make-- if you push the wrong key, correct yourself. The system will lock in your last vote, and we will lock the whole thing out in about 15 seconds. It looks like everybody's got it on top. Okay, so we are about 90 seconds away from having the results. And in the meantime I just want to say a couple things. First of all, I really want to congratulate the spirit that the debaters brought to the stage tonight. It's clear that they had sharp disagreements. It's also really clear that they deeply agree in very fundamental ways about the big picture and that, that informed the civility and the intelligence that they brought to this argument on the stage tonight.

I want to congratulate all of them for the way they did that. And to everyone who got up and asked a question, I think this is the first debate in a long, long time where I haven't thrown out a single question. They were, with a little bit of tweaking, they were all good and they were all informative. They led to a better debate for us, so thank you for those contributions, everybody in the audience. I’d love to have you, as I said in the beginning, please tweet about this debate. Our Twitter handle is @iq2us. Our hashtag is CommonCore. I want to let you know that we’ve just launched a new app that’s downloadable from the iTunes store and from the iphone-- from the Apple store and from the Android store. The app store at Google Play. And this lets you not only get to all of our debates, it lets you vote on our debates, see what’s upcoming, so you can get background information, all on your smart phone.

We just launched it about a week and a half ago, and I have to say it’s beautiful and elegant, and it’s intelligent. So, I hope you’ll take a look at it. Our next debate is right here at the Kauffman Center. It’s on Tuesday, September 30th. The motion that night will be this, flexing America’s muscles in the Middle East will make things worse. Our team arguing for that motion, Aaron David Miller. He is a former Middle East negotiator. He served two decades at the Department of State helping to formulate U.S. policy in the region. He is against flexing our muscle more in the region. His partner, Paul Pillar, a 28 year veteran of the U.S. intelligence community. He served as a national intelligence officer for the near east and South Asia. Arguing against them, Michael Doran. He has served on the National Security Council as senior director for Near East and North Africa. And Brett Stephens who is a Pulitzer Prize winning foreign affair columnist, deputy page editor for the Wall Street Journal.

Again that motion is, flexing America’s muscles in the Middle East will only make things worse. Tuesday, October 7th we’ll be returning to Philadelphia’s National Constitution Center. This is a new initiative in the last several months and the last year. Intelligence Squared is partnering with the National Constitutional Center, doing a specific kind of debate that has been really very successful. It’s where we take a constitutional cut at an issue today, by examining so far, we’ve examined twice, the application of specific amendments to things that are going on in policy and in the world. And they have been very, very interesting and successful. And I recommend using our app to go watch these debates. We’re doing one coming up on October 7th. The motion is this. The mass collection of U.S. phone records violates the fourth amendment. Philadelphia is a 90 minute train ride. Tickets for all debates are available from our website, iq2us.org. And of course, those who can’t join our live audience-- I’ll take that-- there are a lot of other ways to catch these debates. I’ve mentioned them. You can download the app.

You can watch the live stream on our website, iq2us.org or listen to the debate on NPR stations across the nation. And you can stay in touch with us on Twitter and Facebook. By the way we welcome your feedback and topic ideas. We’ve been getting a lot of them lately, and they’re very much in the mix, so we take it seriously. We’ve gotten some very good ideas that I think we’re going to launch into debates in the coming seasons, so please keep that up. All right so, so now it is all in. Let me find my page on this. Okay, it’s all in. I have been given the final results. You have been asked to vote twice on this motion, embrace the Common Core. Once before you heard the arguments and once again after you heard the arguments. And by our rules, the team that wins is the team that has changed most minds in this hall in New York City in percentage point terms. So let’s get to the results. In the preliminary vote, embrace the Common Core, before the debate, 50 percent agreed with the motion, 13 percent were against, 37 percent were undecided.

Those are the first results. Remember, you have to have changed the numbers more than your opponent in order to win, in percentage point terms. Let’s look at the second vote. Embrace the Common Core, the team arguing for the motion, their second vote was 67 percent. They went from 50 percent to 67 percent, a 17 percent increase. That is the number to beat in percentage points, 17 percent. Let’s look at the team against the motion. Their second vote was 27 percent, they pulled over 14 percentage points, but it was not enough. The debate goes to the team arguing for the motion, embrace the Common Core. Our congratulations to them. Thank you from John Donvan and Intelligence Squared. We’ll see you next time.
