# Debate Transcript

Topic: The U.N. Should Admit Palestine As A Full Member State
Motion: The U.N. Should Admit Palestine As A Full Member State

Debate ID: palestine


## Round 1

### Moderator
Claim: We have these debates because of the generosity of the Rosenkranz Foundation which started them and continue to sustain them. And I want to welcome to the stage, to launch things, the chairman of the Rosenkranz Foundation, Mr. Robert Rosenkranz.

### Moderator
Claim: Nearly 18 years ago, the Oslo Accords were reached, which provided for mutual recognition of Israel and the PLO. Ever since there have been outbreaks of violence and an intermittent “peace process” has been carried on with the hope of resolving the conflicts. Very little tangible progress has been made, while Israeli settlements have altered the facts on the ground is Israel’s favor. On the other hand, the facts on the ground, in terms of world public opinion have moved decisively against Israel, not only in the Middle East, but in Europe, and perhaps in the U.S., as well.

Against this back drop, the Palestinian authority is asking the UN for admission as a member state. A bit of background about the UN is helpful. The UN Security council includes five permanent members, the US, China, Russia, France, and the UK. Any one of these can veto the admission of Palestine. In contrast, the General Assembly, in which all members vote equally, can acknowledge Palestine’s status as a state, but only as a non member. Granting Palestine status as a member state would reinforce the UN’s long standing resolutions in favor of a two state solution, express its disapproval of Israel’s settlements policy and the difficulties it has imposed on the lives of Palestinians living in the west bank. It would lend moral authority to the Palestinian cause, and might induce Israel to take a more conciliatory posture in negotiations.

The US could exercise its veto power in the Security Council but at a cost in terms of our relations with the Arab world. And even a vote by the General Assembly to grant Palestine status as a non member state might give the Palestinians access to the International Criminal Court, where they could legally challenge the Israel occupation. On the other hand, nothing the UN can do will alter the facts on the ground. Nothing will resolve the dysfunctional, fragmented, conflict ridden, often corrupt, character of Palestinian attempts at self- government. Nothing will get the Palestinians to develop a coherent negotiating position, or to provide realistic assurances that agreements once reached would be enforced. Prior UN resolutions have endorsed the goal of Palestinian sovereignty.

A UN admission of Palestine would be a redundant expression of hope, rather than a meaningful step toward peace. Debates about Israel and the Middle East are always heated. Tonight’s debate should generate light as well. We have an outstanding group of experts to illuminate these vexing issues, and it’s my pleasure to turn the evening over to our moderator, John Donvan.

### Moderator
Claim: Thank you, Robert.

### Moderator
Claim: Thank you.

### Moderator
Claim: Thank you. And may I just invite one more round of applause for Robert Rosenkranz for making this possible. Yes or no to this statement: The UN should admit Palestine as a full member state. It is a statement that divides us, but it's one that is worthy of fair and open debate. And that's what this is, another debate from Intelligence Squared US. I'm John Donvan. Welcome.

We have two teams, four superbly qualified debaters, all of whom have lived at the heart of this argument. And it's an argument that, let's face it, in our lifetime, has seemed to be rather permanent, the way that the Berlin wall once seemed permanent, but turned out not to be, or apartheid in South Africa seemed permanent, but turned out not to be. But Israel and Palestine, this is the one that seems never to end. And why is that? Well, nothing helps expose the fault lines like a good debate. And debaters who are trying to make you understand their point of view and maybe get you to see something in a way that you have never seen it before. We go in three rounds of debate. Then the audience votes on the winning debate. Only one side wins.

Our motion is "the UN should admit Palestine as a full member state." And to meet our debaters, Mustafa Barghouthi, you are a Palestinian, a former presidential candidate in the Palestinian authority. You are a Nobel Peace Prize nominee because you lead a party that is adamantly devoted to peaceful resistance to the Israeli occupation. And just very briefly, before we get started, what do you think is the point in this debate that your opponents don't understand yet, that you want to make them understand?

### Conspiracy Advocate (CA)
Claim: I think the point is that admitting Palestine to the UN as a full member is in the best interest not only of the Palestinian people, but also of Israeli people.

### Moderator
Claim: Thank you.

### Conspiracy Advocate (CA)
Claim: And that it is in the best interest of peace with everybody.

### Moderator
Claim: Thank you, Mustafa. Your teammate, who is also arguing for admission, Daniel Levy. It's going to surprise some people that Daniel Levy arguing on this side is actually a citizen of the state of Israel. You were also a negotiator on the Israeli side in negotiations with Palestinians.

And Daniel, from your point of view again, knowing that many of your fellow Israelis would oppose admission, what do you want the doubters to hear tonight?

### Conspiracy Advocate (CA)
Claim: Well, doubt is okay. Skepticism is healthy. But we can't pretend the Palestinians away. And time isn't healing this. So not acting to facilitate the Palestinian state is just a dereliction of responsibility to ourselves and to future generations.

### Moderator
Claim: And because I just mispronounced your name, I'm going to repeat the first sentence I said. Your team, and also arguing for the motion, Daniel Levy. I will be consistent with that from this point on. Our motion is this: "The UN should admit Palestine as a full member state." And arguing against the motion, Dore Gold, you are at the United Nations as Israel's representative. You are an advisor to Prime Minister Netanyahu. You have been around the block on this one for years and years and years. And my question to you is what do you think the audience needs to hear tonight that they've never considered before?

### Scientific Advocate (SA)
Claim: I'm sorry. I have to correct you. I'm currently not an advisor. I'm a private citizen. But nonetheless, I'll answer your question.

### Moderator
Claim: Does he listen to what you say?

### Scientific Advocate (SA)
Claim: Have to ask him. Look, the position I am taking has nothing to do with recognition of the Palestinians. It has nothing to do with national dignity, which every people is entitled to. It has everything to do with undertaking an act which will create chaos, precisely at a time when the Middle East is more dangerous than ever.

### Moderator
Claim: Thank you very much. And your partner is Aaron David Miller. Aaron, you are a former U.S. Middle East negotiator, a public policy scholar at the Woodrow Wilson international center for scholars. And you also have been involved in this at the negotiating table as an American and as the American at the table for 20 years. And what do you want your audience to key in on tonight?

### Scientific Advocate (SA)
Claim: John, thanks-- thanks for having all of us. No more illusions is my trope. Americans and Israelis have had their fair share. And now the Palestinians have theirs.

UN admission in the absence of an agreement between Israelis and Palestinians will not take the Palestinians any closer to the full sovereign state that they deserve.

### Moderator
Claim: Thank you, Aaron David Miller. So we've heard from all of our debaters. We've met them all. And shortly, we're going to move on to round one. But first we want to ask you to go to the key pads at your seat and take a look again at our motion: "The UN should admit Palestine as a full member state." If you agree with this motion at this point, push number one, if you disagree, please push number two, and if you are undecided, push number three. And if you've made an error, just correct your vote, and the last vote will be registered. These will be tabulated. We're going to hold this result till the end of the debate. We'll have a second vote. We'll ask you in that second vote to judge which team presented the better arguments. And the team that has moved its numbers the most will be declared our winner.

So onto round one, opening statements from each debater in turn. They will be seven minutes each. Our motion is, "The UN should admit Palestine as a full member state." Up for the motion first, "The UN should admit Palestine as a full member state," former Israeli government negotiator, senior fellow at the New America Foundation where he is co-director of the Middle East task force, Daniel Levy.

### Conspiracy Advocate (CA)
Claim: Thank you. Ladies and gentlemen, on October 10, 1971, the United Nations admitted the People's Republic of China as a member and kicked out Taiwan. If that were the kind of motion we were debating tonight, I would not be standing here arguing in favor.

What we are proposing is to admit Palestine at the U.N. not instead of Israel but alongside Israel, unfinished U.N. business from the middle of the last century. Let me first clear up what I hope will not become debris in the way of constructive debate tonight. We have not convened here to discuss matters of legal principle, "Does Palestine meet the criteria of Montevideo for statehood?" Law matters, but this is primarily a political, not a legal question. And it's not about the United Nations and whether it is a force for good or a frustrating institution. It can be both, and Israel of course went to the U.N. to get its own birth certificate endorsed. But the assumption of this debate is the two-state paradigm. We do not have anyone here advocating a greater Jewish Israel or a binational democratic state, nevertheless, it would be hubris to take two states for granted, and we need to recognize certain realities.

The territorial viability of a second state in this area looks increasingly precarious. Approximately 600,000 Israelis, one in 10 Israeli Jews live beyond the green line. Settlements grow. Outposts are legalized. I invite you to go and see the reality. And it's not just a physical manifestation of blurring. It is also the conceptual universe in which a growing number of Israelis live. Prime Minister Netanyahu may have talked the talk on two states, but he has not walked the walk. His own Likud party platform opposes two states, and one must take seriously the Jewish-Israeli narrative that says 100 years ago we had nothing, then we got Balfour, then we got the '47 partition, then we got 78 percent of the land, then in 1967 we got 100 percent of the land, and we're not going anywhere.

That's a serious view, and it has an amen corner, by the way, certain people perhaps in New Hampshire tonight's part of that amen corner. Passivity cannot be the response. If we want two states, we have to act. And U.N. admission for Palestine is precisely the anchor for a two-state future, a clarifying moment. We need to be deeply respectful of the choices that Israelis are going to have to make, difficult choices, and the conversations in Israel, and, therefore, to understand just how unproductive the lack of clarity is for that Israeli conversation. Indulging bad behavior, treating that with impunity, is unhelpful in any human predicament.

And we encourage the most self destructive tendencies in Israeli behavior when we pretend that by doing nothing, allowing this slippage away from two states, somehow we're making it easier for Israeli society to change course. We are not. The cost benefit calculation of Israelis needs to look different. Do we really think that Israel is waiting to leave the territory, it's just waiting, and the Palestinians just need to ask politely enough and behave well enough, and that's the key to unlock this? Let's acknowledge that it's not going to be easy but the current policies aren't helping. What, then, can be done? The Palestinians do actually have options, violence. I'm against that. That's illegitimate. They can use nonviolence, coercive diplomacy of sanctioning. I can see its legitimacy, but I'm not an advocate of that. Or they can use declarative diplomacy, draw a line, lay down a marker to get the attention of Israelis.

That's what U.N. membership is, and I would argue it correlates with what is best, therefore, for Israel. We can't expect the Palestinians to wait forever, and we can't say to them that you can neither have self-determination and express it at the U.N. but nor can you accept the one-state reality and argue for equal rights in one state. Suggesting the Palestinians can do neither is unrealistic, but it's also immoral. So if we want to salvage a two-state solution but at the same time if we can't impose a solution and if we can't even prevent deterioration, if we can't even get a settlement freeze, then how do we give oxygen to this gasping for breath two-state idea? We vote to admit Palestine to the U.N. and we vote for this motion tonight. U.N. membership is not a silver bullet. It’s not a panacea. It’s not sprinkling pixie dust on the harsh realities of the Middle East.

But it is an important and legitimate part of a strategy to signal a different future. We will no doubt be told that this can’t happen, that it’s meaningless symbolism, and especially not now with the Arab spring. Wrong. Yes, the U.S. has committed to a veto. No doubt, we’ll discuss that. But does that make this debate pointless? Can the realpolitik argument really close down our entire conversation? If that’s the case, I strongly suggest you guys cancel the debate you have planned in March about banning college football, because it won’t be. And that can always be an argument. I urge the other side of this debate to give us more than naysaying, to give us more than negotiations. Those negotiations are asymmetrical. One side is so lacking in leverage and they are so steeped in years of failure. Negotiations cannot be the singular tool in our toolkit.

And finally, if we are concerned about Israel’s security, then let’s acknowledge that hope too is a security currently. Hopelessness encourages violence. There will always be the next mountain range that you need to occupy, but strategic security is about a basket of interests and balances and avoiding casus belli. And perhaps, perhaps, occupation itself contributes to insecurity and Israeli democracy. Eventually managing an occupation and justifying it and sustaining democracy cannot happily coexist. Not to dramatize, but if we don’t have a Palestine, we are saying Kaddish. We are saying the right of prayer, of last prayer for Israeli democracy. I urge you to support this motion, to support the principle of Palestine alongside Israel at the U.N. Thank you.

### Moderator
Claim: Thank you, Daniel Levy. Thank you, Daniel Levy. Our motion is “The U.N. should admit Palestine as a full member state.” And here to speak against the motions, Aaron David Miller. For over two decades, he advised six secretaries of State, shaping U.S. policy on the Middle East in the Arab-Israeli peace process. He is a public fellow at the Woodrow Wilson Center.

### Scientific Advocate (SA)
Claim: John, thank you very much. And thank all of you for coming. Daniel, I’ve known you for many years. I admire your passion and your intellect. You’re a powerful advocate of Israeli-Palestinian peace, of logic and common sense. All of this, however, does not address the fundamental problem, the conundrum now, Daniel. We’re dealing with a conundrum. We are stuck. Violence will never produce sovereignty for Palestinians, but neither will negotiations right now. So the question is what to do. What you are suggesting, in my judgment, is that we take an action that is not simply neutral, that will retard and undermine the very concept as dubious as you may believe it is.

And Mustafa will agree. Dore may even agree. It is simply no justification for proceeding in the face of common sense logic toward an alternative that ultimately will not bring Palestinians closer to meaningful sovereignty. I speak here not as an Israeli to you and not as a Palestinian. I speak with all its imperfections and contradictions as an American, absorbed in this process for many years, 25 years. And during the course of that period, I developed a faith in three primary assumptions: Number one, there was a solution, equitable and durable; number two, negotiations were the only way to achieve it. And negotiations is flawed and it’s imperfect because it’s based on human frailty and weakness and on the need and the capacity to compromise; and finally, that the United States had a critical role to play in this process by being fair, by being tough and by being reassuring-- all of these assumptions.

Any honest man or woman would acknowledge And the situation, you’re quite correct, Dan, it will be worse. It will get worse before it gets worse. But the question still has to be addressed. How will granting the putative state of Palestine admission as a full-member state into the U.N. address any of this? Now, I’m here to argue in six basic points. I don’t want to bore you. I’m not here to entertain you, but to leave you with perhaps a baker’s dozen in the next four-and-a-half minutes of why I believe this is a bad idea. And, by the way, I concede, particularly to you, Daniel, that I know bad ideas when I see them.

I know illusions when I see them. I was responsible, over the course of a 20-year period, for quite a few, as Mustafa will attest, perhaps even Dore. But not tonight. I have no illusions tonight. First, as an American whose country sits on the Security Council, I cannot, in all good conscience, recommend the admission of a putative state however morally or ethically compelling it may be as a full member state. Prime Minister Salam Fayyad, the man who has done more to build institutions of Palestinian statehood on the ground is against this proposition because he knows it'll undermine the work that he has done. It'll undermine the institutions. Palestine has no borders. It has no control over its population. It has no monopoly over the forces of violence within its own society. In short, it does not control the guns, all of the guns in its society. I would argue that's critically important for statehood.

Yes, much of this may be due to the Israeli occupation. But that doesn't change the reality. Admission of Palestine now will create a situation in which it cannot discharge its own obligations as a member state, in large part because half of its government, the rival Palestinian national movement doesn't ascribe to a peaceful solution of interstate conflicts. Mustafa may have much to say about this, but this is an obligation of UN membership. Second, as an American, I'd oppose this because I believe it's not symbolic. It's not symbolic at all. It's a prescription, and an RX, if you will, for instability and perhaps even escalation. Think about it. We are admitting the Palestinian authority that presumes to control Palestine into the UN when in fact two other entities, one, the state of Israel, an ally of the United States, and the second factor and force, Hamas, an entity which is an adversary of the United States, has more control over what transpires in Palestine, this putative state than the Palestinian authority.

That is a prescription for endless contradictions and perhaps even violence. Mustafa will tell you, and he may be right, that the basis for this negotiation, and the basis of-- for any Palestinian state will be June 4, '67 borders. But admitting Palestine into the UN will mean that a Palestinian president not only has the right and the obligation to defend those borders. I wouldn't want-- I mean, maybe you see this as a blessing. I see it as a huge contradiction, to put any head of a putative state in a position where he has to defend borders that he cannot defend. And what is he to say to his public when the Israelis continue to do what they will do?

Which brings me to my third point. There will be an Israeli reaction. And who is going to control that reaction? The United States? The international community? As Israel seeks perhaps to set its own boundaries, to basically say to the Palestinians, fine, you have now set your boundaries. June 4, '67, is the basis of a negotiation if we ever return to the table. But we're going to set ours now as well. We will set our boundaries. And we will be dragged sooner rather than later away from the prospect of any kind of solution. For, if the Palestinians want to pick a fight with the Americans, that's their business. But I would argue it's counterproductive. You're going to have an election in November. And I'm not talking as a Republican or as a Democrat. But anybody looking at this situation might argue that if you truly had a strategic interest in promoting Palestinian statehood, you probably would want to see the re-election of the current president.

You would probably want to see the re-election of the current president, which would mean essentially that you're not going to force him into a position to take action that will weaken the prospects of his own election. Finally, I'll come back to my initial point. Just because we're stuck does not mean the pursuit of a strategy that's going to take us farther away than ever from our goal. Admission of Palestine now without an agreement will take Palestinians farther away from sovereignty.

### Moderator
Claim: Thank you, Aaron David Miller. Your time is up. Thank you. A reminder of what's going on. We are halfway through the opening statements in this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two fighting it out over this motion: "The UN should admit Palestine as a full member state."You have heard the first two opening statements, and now onto the third. To debate in support of this motion that the UN should admit Palestine as a full member state, Palestinian democracy activist, secretary general of the Palestinian National Initiative and Nobel Peace Prize nominee, Mustafa Barghouthi.

### Conspiracy Advocate (CA)
Claim: Thank you so much. And thank you for coming tonight, and thank you for inviting me to this debate. I have four reasons that I would like to emphasize why Palestine should be admitted to the UN. The first is that time is not an infinite commodity. And time-- we're losing time. And with the continuation of Israeli settlements on the ground, which are illegal, and after 20 years of failed negotiations, we cannot have the risk of losing the two-state solution.

If Palestine is not accepted as a state very soon, there will be no two-state solution. And the outcome will be dangerous and bad for everybody. So we need the UN in this case to change the parameters, to change the course, the course of failure which Mr. Miller is defending. What Mr. Miller has suggested and what probably Mr. Gold will suggest is to continue the same path of failure, the same negotiation that's failed to produce anything because of the imbalance. What-- and that, in my opinion, is irresponsible towards Palestinians and irresponsible towards Israelis as well. What they are proposing is to continue what Einstein described as insanity, which is doing the same thing over and over again and expect different results. it also indicates, as I suspect Mr. Gold will show, such a position against UN admission indicates an underlying intention of rejecting the principle of having a Palestinian state, which means rejecting the right of the Palestinian people to be free. Continuing negotiations while settlements continue to grow is like having two sides negotiating over a piece of cheese. One side, the Palestinian side, is stuck behind bars. The Israeli side having access to the piece of cheese and eating it while negotiating. At the end of the day, we'll find nothing to negotiate about. And that is not a solution. So my second point is that in the light of the failure of the disability and inability of the United States for internal reasons that are well-known to you, and in the light of the weakness of the Europeans and their participation, and in the light of the stubbornness of the Israeli extreme right wing, we have to find a way for a new strategy.

We have one of three options. Either Palestinians would surrender to injustice, and that's what some people are calling for. In this case, what you will witness is the consolidation of a system of apartheid, where Palestinians are discriminated against. And Israel would become the worst apartheid system in the 21st century, something that nobody could be proud about. Or the second option is violence, which we reject, and we don't want. The third option is to have nonviolence, peaceful resistance, exactly like Gandhi did in India, and like Martin Luther King did here in the United States. And that's the course we are taking.

And that's why going to the UN is nothing but another act of diplomatic resistance within the context of popular nonviolent resistance to change parameters and to change the balance of power so that we can have productive negotiations really and have a result at the end of the road. My third point is that, supposing our right to be admitted to the United Nations will be sending the right message, the message of respect to human rights, the message of respect to people's right for self-determination, the message of respect of the right of people to be sovereign. If we speak about the right of people in South Sudan and in Kosovo and in Libya and in Syria to be free and to have self-determination, then why not Palestine? And why continue to use the double standard, especially that admitting Palestine in the UN would be about correcting a historical mistake that was made. Since 1947 resolution the United States spoke about two states, Israel was established.

Palestine was not. My last point is that we know that admitting Palestine to the United Nations would not immediately create a change on the ground. We understand, but it will achieve three goals. First, it will give us hope. It will give Palestinians hope. Hope is what we need today to sustain a nonviolent approach to our resistance and struggle. Desperation and lack of hope as is advocated on the other side will only bring violence and dangerous things. Second, accepting Palestine will actually invalidate all the de facto actions on the ground that are made by Israel and by creating settlements. And, third, it will send a message to the Israelis that they will not be really free unless Palestinians are also free.

We are now victims of oppression and discrimination. The Israelis are hostage to occupation and fear, especially security fear. And Mr. Gold will try to show you that there is more fear today because of the Arab Spring. Instead of Israel being happy about people becoming democratic, they are having more fear. This is not the right approach. We want to liberate ourselves through popular nonviolent resistance through admission to the United Nations, but we also want to liberate the Israelis as well. Martin Luther King liberated the United States, not only the African-Americans, from segregation as well as Mandela liberated the whole of South Africa, the whites and the blacks together by liberating South Africa from apartheid.

And that's why what we want, what we are working for, is to liberate ourselves from oppression, the longest occupation in modern history, and the worst apartheid system, and to liberate the Israelis from fear, from the security phobia. One time a Palestinian leader came to the United Nations with a gun and an olive branch. Today we are coming to the United Nations with two olive branches. Don't let us drop them. Thank you.

### Moderator
Claim: Thank you, Mustafa Barghouthi. Our motion is "The U.N. should admit Palestine as a full member state." Our final debater is going to speak against the motion. He's Dore Gold, world renowned expert on Middle Eastern affairs. He's former prime minister of Israel's foreign policy advisor and former ambassador to the United Nations. Dore Gold.

### Scientific Advocate (SA)
Claim: Those of you who are voting tonight should remember that we're speaking about Palestinian membership at the U.N., we're not in New Hampshire. When I served as Israel's ambassador to the United Nations back in the late 1990s, I had a colleague, a counterpart, who was the U.S. ambassador to the United Nations, became a very close friend, it's someone I intellectually admired. His name, unfortunately he's passed away, was Richard Holbrooke. And one of the things I was struck by, before I was sent to the U.N. I was the Israeli negotiator. I was sent to the sand dunes of Gaza where Muhammad picked me up in that extended Mercedes and take me to Arafat's house. We would discuss how to move forward in peace, and, by the way, those discussions were tough because he-- when you're in a meeting like that, you don't know where to park your head.

Should you remember the Israelis who died in repeated suicide terrorist attacks that came out of territory under Arafat's jurisdiction? I know that's tough to mention, but you've got to know that. Do you think of those people? Do you think about the moment? Do you think about building a future? Do you forget about the tragedies of the past so you'll have hope? How do you orient yourself? It's very, very tough. But I had that experience. We were involved in-- I spent hours with Mahmoud Abbas, Abu Mazen. I spent a tremendous time on the Hebron Agreement with Aaron and of course the Wye Agreement that followed afterwards. And what I had seen in the '90s is that we didn't succeed. We didn't succeed. We reached agreements. And, by the way, the man that some spokesmen like to try and put in the corner Prime Minister Benjamin Netanyahu signed two agreements with the Palestinians-- withdrew from territory, made sacrifices for peace, risked his whole political base because he wanted to move the process forward.

It may not be the conventional wisdom in certain circles, but I experienced that. But let me go back to Holbrooke. So I saw that we had a tough time moving forward. And after I left government in 1999 and when Mr. Ehud Barak came into office. And Barak went to Camp David with Yasser Arafat. The peace wasn’t concluded. But I asked myself through my contacts with Holbrooke, “How was it?” And Richard Holbrooke delivered the greatest political diplomatic achievement of the Clinton administration, the Dayton Accords over Bosnia. Well, we didn’t succeed in the Middle East. We failed at Camp David. I’m not sure I still understand why that occurred.

By the way, that is a tough conflict, the battle between Croats, Bosnian Muslims, the Serbs, was religious, ethnic, territorial. It had all the ingredients that we had. But they persisted. They persisted to negotiate. I discerned from my discussions with Holbrooke and from reading his memoirs on that conflict that there were three elements. He concluded that there must be a negotiated outcome. As much as you could be cynical about tough negotiations, that’s the only outcome that will work. The second thing that comes from my experience with talking to him and also in his memoirs is that peacemaking must come from the parties themselves. The great breakthroughs of Dayton came from those three warring parties. It’s true. They were brought to Ohio. It’s true. Secretary of State was in and out. President Clinton was ready to come in.

But they themselves were responsible for reaching peace and imperfect peace. And finally, you need diplomatic flexibility. Let me tell you something. Both sides, certainly in our case-- I can speak to Israelis-- we have a deep inner conviction in the justice of our cause. But tonight’s not the night to lay that out to you. The point is that even though you have that deep inner conviction, the point is that even though you can go on every American network from CNN to FOX Television and lay that out to the American audience, you have got to make a compromise. You’ve got to cut a deal. You can’t walk away. And because they knew there had to be a negotiated outcome, because they knew it had to come from the parties themselves and the needed diplomatic flexibility, in the Balkans, they cut a deal, an imperfect deal.

In fact, Holbrooke writes in his book the critical question: Will the Bosnians grasp an imperfect peace or let the war resumed remain unresolved right up until Dayton was convened? Now, let me move to the issue at hand between us. What is my problem with the proposal that a Palestinian state be recognized as a U.N. member state? As I said in my opening words, this isn’t about national dignity. You know, every people wants to recognized. And there are a lot of peoples out there beyond the discussion of who’s supposed to get independence-- Kurds, Tibetans, you name it-- every national movement wants to be recognized to the U.N. So my question isn’t about recognizing the rights of Palestinians.

That was recognized by Menachem Begin back at Camp David in 1978. My question is really twofold, and my concern is twofold. First of all, carefully listening to the speech of Mahmoud Abbas on September 23rd this year, or last year now, at the U.N. General Assembly, he wasn’t just saying, “Accept us in principle.” He was laying out borders. And I think Aaron made the reference to it, the June 4, 1967 line, as though there was some kind of pre-’67 boundary, border, that was an international line that we have to agree to. That’s it. When we signed the Oslo Agreements, borders were supposed to be negotiated. And that-- to that point, to that very point, Yasser Arafat agreed. He signed those agreements.

Or actually Abu Mazen signed the first agreement. The implement agreements, he later signed. So we're talking about predetermining the final boundaries by moving to the UN.

## Round 2

### Moderator
Claim: Dore Gold, I'm sorry. Your time is up. It went by quickly, but you can bring some of that in later on. And that concludes round one of this Intelligence Squared U.S. debate. And you can do one of those applause moments. Thank you. So our motion is: "The UN should admit Palestine as a full member state." Keep in mind how you voted at the beginning of the evening because we're going to ask you to vote again at the end of the evening. And the team that has changed the most of your views on this motion will be declared our winner. So now onto round two. And this is where the debaters address one another directly and answer questions from you in the audience and from me. We have two teams of two.

We have Mustafa Barghouthi and Daniel Levy who have been arguing that the UN should admit Palestine as a full member state for several reasons, including the fact that it introduces hope to the Palestinian people, and that hope militates against violence. Also, that in a peace process that is going nowhere, that is stuck, it lays down a marker that the Israelis cannot ignore. The team arguing against the motion, they include Dore Gold and Aaron David Miller, are arguing against this motion on the grounds, number one, that what exists now in the territory controlled by the Palestinian Authority doesn't really meet the qualifications of a state because it can't control its borders, it can't control its guns. And they're also arguing that it is too soon to give up on negotiation itself. So we're going to take questions from you. But first from me, I want to put a question to the side arguing against the motion. And I think, Dore, this may have been where you were heading. I want to understand why admission of the UN-- why admission of Palestine to the UN necessarily precludes the continuation of negotiations.

Why can't there be this admission to the UN, and yet negotiations continue and ultimately a solution reached?

### Scientific Advocate (SA)
Claim: I mentioned that point already, which is, of course, that these are issues that have to be negotiated. You know, for example, one of the hard choices that Mahmoud Abbas has to face, one of the critical issues that he has to deal with is announcing, it's the end of the conflict. By going to the UN, getting a Palestinian state, he doesn't have to do that. He doesn't have to come to terms with the question that we keep raising. We're being asked, recognize the rights of the Palestinians to an independent state. So we've done that. But we're asking the Palestinians to recognize the right of the Jewish people to a nation state of their own. That has to be in the package. But in fact, there-- there--

### Conspiracy Advocate (CA)
Claim: But how are you recognizing the Palestinian state when you refuse to go back to '67 borders?

### Scientific Advocate (SA)
Claim: Because the borders have nothing to do with the existence of a state.

### Conspiracy Advocate (CA)
Claim: The borders would be up in the air, or no borders?

### Scientific Advocate (SA)
Claim: No. We have to work out the borders. We have real problems. You know, everyone says, oh, just get out of the Gaza Strip unilaterally in 2005. You won't have a full peace agreement because we didn't negotiate it unilaterally. And the situation will stabilize.

### Conspiracy Advocate (CA)
Claim: Sorry. No one says that. That was the initiative of the Israeli prime minister.

### Moderator
Claim: Daniel Levy.

### Conspiracy Advocate (CA)
Claim: And he refused to--

### Conspiracy Advocate (CA)
Claim: No one was telling him unilaterally--

### Scientific Advocate (SA)
Claim: No one was telling us unilaterally. It does, but everyone said, if you end the occupation, the source of violence will end.

### Conspiracy Advocate (CA)
Claim: Gaza is 6 percent of the land mass of the remaining 22 percent of mandatory Palestine that we're talking about in a two-state solution. No one was saying, any occupation in six percent, maintain and entrench the occupation in 94 percent and see how that goes.

### Scientific Advocate (SA)
Claim: Wouldn't you expect--

### Moderator
Claim: Dore Gold.

### Scientific Advocate (SA)
Claim: Wouldn't you expect that if you get out of the given territory, that the level of violence from that territory would decline? Maybe it would go up elsewhere.

### Moderator
Claim: Dore, I-- let me-- wait. Wait a minute. Dore, let-- let-- wait a minute. Excuse me. Excuse me. Dore.

### Scientific Advocate (SA)
Claim: I have a right of response.

### Moderator
Claim: I don't feel that you answered my question.

### Scientific Advocate (SA)
Claim: Okay.

### Moderator
Claim: Although, although you said that you had addressed it. My question is, you just talked about what's left to be negotiated. Let's take borders for example. Why not do this political gesture at the UN for the Palestinians? Why would that preclude then having discussions on the borders afterwards? In other-- you were saying this stops everything. And I'm trying to understand why this would stop everything, and these negotiations could not continue on those points afterwards.

### Scientific Advocate (SA)
Claim: Well, what if the very resolution itself states that the borders will be the June 4 lines? Is the Palestinian side willing to relinquish that phraseology from a Security Council resolution?

### Moderator
Claim: Mustafa Barghouthi.

### Conspiracy Advocate (CA)
Claim: Well, let me reiterate one thing. Let's remember that in 1947 the--

### Moderator
Claim: Are you going to-- will you answer his question?

### Scientific Advocate (SA)
Claim: Simple question.

### Conspiracy Advocate (CA)
Claim: Yeah, I'm answering this question. In 19-- he has-- he has been talking a lot, so let me 1947, it was decided there would be two states. Israel would be on 54 percent of the land, Palestine on 44 percent of the land. Now we are accepting 22 percent. That's less than half of what we should have had according to the UN in '47. And Mr. Gold wants to take away parts of that land because for the settlements that keep growing, Israel is the only country in the world that has not told anybody what are its borders. Why?

### Moderator
Claim: But you're not answering his question.

### Conspiracy Advocate (CA)
Claim: Because--

### Moderator
Claim: His question was--

--the resolution--

### Scientific Advocate (SA)
Claim: What about India or Pakistan?

### Moderator
Claim: Excuse me, Dore.

### Scientific Advocate (SA)
Claim: Why do you--

### Moderator
Claim: Dore, excuse me. Excuse me.

### Scientific Advocate (SA)
Claim: And why do you keep--

### Moderator
Claim: Dore, Dore, excuse me.

### Scientific Advocate (SA)
Claim: --assertion for this totally based--

### Moderator
Claim: Dore, excuse me. The question that he put, could there be a resolution that would not stipulate borders, that would leave that to be negotiated?

### Conspiracy Advocate (CA)
Claim: I think there are four issues for negotiation. There is settlements, there is the borders, there is the issue of refugees, there is the issue of Jerusalem. Nobody said that admitting us to the UN will mean that we will not negotiate about all these issues.

### Moderator
Claim: Okay. That's what we're trying to come back to. And Dore, I'm to understand why you say that can't happen.

### Conspiracy Advocate (CA)
Claim: As one final point, please, it's very dangerous to say we admit, we accept Palestinian, that they should have a state, but we don't agree with '67 borders because what that means is that you want us to have a Bantustan like there was in South Africa. There were also Bantustans in South Africa with kings, not only presidents. But that did not mean that people were free. They were subjected to discrimination and apartheid system.

### Moderator
Claim: Let me bring in Aaron David Miller.

### Scientific Advocate (SA)
Claim: Look, we're getting away from some very basic issues here. Admission to the UN recognition would conflate with acknowledgment of sovereignty. Legally, that may not be the case, but that is the way it would be read. That is the way the Palestinian Authority would interpret it. And presumably, that is the way the international community might interpret it as well.

And that, the notion that recognition and admission would create the mindset, the June 4, '67 borders have been established, have been laid down, would make it more difficult, even though, Mustafa and Daniel, it may well be the only rational, logical outcome is a negotiation with June 4, '67 borders as a basis. Second, you have a divided Palestinian polity. And let's not forget this point because it's fundamental to the entire argument. You're not dealing here with a negotiation which consists of one gun, one authority and one negotiating position. The notion that you would admit, as a member state, a divided Palestinian polity, half of which has not even signed up to the conditions that are essentially, by definition, basic to a negotiation--

### Moderator
Claim: Okay. Let me bring in Daniel-- you've made two--

### Scientific Advocate (SA)
Claim: It's critically important--

### Moderator
Claim: --very strong, pragmatic arguments. Levy.

### Scientific Advocate (SA)
Claim: It's not-- it's not-- one more point, John. John, John, another-- one last point. It's not - - this notion of a division between what is morally acceptable, what is symbolic and what is pragmatic is a-- is a division without distinction. No one is doubting the fact that if the Palestinians were admitted into the UN, they would be more hopeful. No one is doubting that it would impress on the international community the notion of Palestine as a sovereign state. What I am doubting, and what you have yet to demonstrate, is that such an act would bring us any closer to--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --meaningful sovereignty--

### Moderator
Claim: Daniel-- Aaron, I want to bring it to Daniel because I want to come back to some of the points--

Daniel Levy.

### Conspiracy Advocate (CA)
Claim: Aaron, given that you've told us that it has to get worse before it gets worse and that the Palestinians should join the reelect President Obama campaign, I'm not sure-- and this isn't easy because it is probably obvious to everyone in this room. Me and Aaron aren't exactly hostile when it comes to one another.

There's deep mutual appreciation, and I greatly respect the service that Dore Gold has given to the state of Israel. I want to address the two points you put out there. First of all, what-- what we've tried to make the point of is that if you want a two-state solution, you have to do something about it, and you have to begin to anchor it, and you have to send signals. No one is expecting, the morning after admission of Palestine to the UN, Palestine actually realizes its sovereignty. This isn't a standalone gesture. No, Aaron, I'm going to-- I'm--

### Scientific Advocate (SA)
Claim: I'm not going to say a word. I'm not going to say a word.

### Moderator
Claim: Well, ultimately, you will.

### Conspiracy Advocate (CA)
Claim: Yeah, exactly. As for the expectation that, if it's admitted to the UN, well, that means it's got full sovereignty. Listen, for 40 plus years, the Soviet Socialist Republic of Belarus, and of Ukraine, were members of the U.N.

Did that mean that they were independent states in the USSR? Come on, this is a political act. What we're talking about here is sending a political signal from the U.N. Your second point, the divided Palestinian authority. First of all, Aaron, you didn't get it exactly right in your description of who takes-- who assumes that Palestinian seat at the U.N. It's not the Palestinian authority, it's the PLO, and that has been clarified and made clear. The PLO is still headed by Abbas. The PLO has certain commitments that it has made in signed treaties. And I would look at this as I try and look at most things, to be honest, as how do we use this opportunity? How does this become an entry point to problem solving rather than rejecting it as another nonstop--

### Moderator
Claim: All right, let me come back to--

### Conspiracy Advocate (CA)
Claim: I want to finish the point.

### Conspiracy Advocate (CA)
Claim: My entry point for this is a problem solver is I would turn around and say, "Palestine, you're in the U.N., you sign the U.N. charter, read the words of the U.N. Charter.

Hamas, you want reconciliation, you have to be signing up to the U.N. Charter as well." I would make this part of the encouragement of internal Palestinian unity, to see the opportunity, not a way to threat.

### Moderator
Claim: Dore Gold.

### Scientific Advocate (SA)
Claim: Daniel Levy mentions the U.N. Charter. And, you know, one of the most important points in this discussion to keep in mind is-- sorry to be legal-- but Article 4 of the Charter, which says, "Membership in the United Nations is open to all other peace loving states which accept the obligation to continue the present charter," peace loving states. Why is that important? Mustafa Barghouthi has invoked the names of Martin Luther King-- I don't know if he said "Gandhi," but--

### Conspiracy Advocate (CA)
Claim: I said "Gandhi" and "Mandela."

### Scientific Advocate (SA)
Claim: --and Mandela-- men who were against violence.

### Scientific Advocate (SA)
Claim: If only we had them.

### Scientific Advocate (SA)
Claim: Exactly, if only-- I mean, Palestinian political culture had adopted those positions, but-- frankly, frankly, just now, on December 22, in a meeting in Cairo, and I'm not sure whether you were there or not--

### Conspiracy Advocate (CA)
Claim: I was.

### Scientific Advocate (SA)
Claim: Yes, okay. I don't want to get it personal, but there was a meeting of the Palestinian leadership and it included Khaled Meshal, the head of Hamas, it included the heads of Islamic jihad, and these are organizations that call for the obliteration of the State of Israel, the destruction of the State of Israel. So how do you square the circle of invoking to an American audience names like Martin Luther King and then going to an event in Cairo with the leaders of the Islamic jihad which is a wing of the Pasdaran of Iran, of sitting with the Hamas leadership while they-- after your meeting with them are quoted in Al-Hayat, in the Arabic press, still calling for armed struggle against the State of Israel?

### Moderator
Claim: Mustafa Barghouthi.

### Scientific Advocate (SA)
Claim: I can't square the circle and you cannot have U.N. membership, you cannot have U.N. membership when you're coming to the U.N., when you're going to the secretary general--

### Moderator
Claim: All right, we take--

--I can't just let you have the floor forever. We got your point and we want to keep the point moving.

### Scientific Advocate (SA)
Claim: But you want to cut me off.

### Moderator
Claim: Thank you. Mustafa Barghouthi.

### Conspiracy Advocate (CA)
Claim: You know, Dore, I want to ask you about the policy of Israel.

### Scientific Advocate (SA)
Claim: I asked you about the policy of the Palestinians.

### Conspiracy Advocate (CA)
Claim: I think--

### Scientific Advocate (SA)
Claim: And tell me about Cairo. You were there--

### Conspiracy Advocate (CA)
Claim: I want to ask you about the fact that Israel is the third largest--

### Moderator
Claim: No, Mustafa, he--

### Conspiracy Advocate (CA)
Claim: No, no, give me the chance to speak here. Israel is the third largest military exporter in the world.

### Scientific Advocate (SA)
Claim: Exporter?

### Conspiracy Advocate (CA)
Claim: Yes, Israel is now-- has you know hundreds of nuclear heads.

We all know that, so when you speak about peace and you speak about nonviolence, you might as well think of how Israel itself should stop using violence. Now, you said one of the arguments that were told here by Mr. Miller is that--

### Moderator
Claim: Wait, wait, wait. The reason I'm intervening, there's a lot of scores being settled here. And we're traveling very far, and I'm not disregarding or disrespecting the passion about these issues, but we're trying to talk on the practicality or the morality either of this motion. And a very focused question was put to you--

--but you've already-- you took the moment to take a slam at Israel's record, fine.

### Conspiracy Advocate (CA)
Claim: No, no, no, no.

### Moderator
Claim: But there's a good point that he raised, and it's the same reason I'm interrupting you. There's a good point that I would like to hear the answer to, and I think the audience as well, if in fact-- it's very simple.

If Hamas is part of this state and the U.N. is an organization devoted to peace, can you please just bring those-- reconcile those two things. It’s a pretty obvious question.

### Conspiracy Advocate (CA)
Claim: There are two major important developments that have happened thanks to our work, thanks to our advocacy of non-violence, which is that I know there are several statements and you could pick up the bad ones, but the official position now of Hamas is to accept non-violence. This is a big achievement, and you should be happy about it. If people change positively, you should not get angry, as Mr. Gold does. Also, they are accepting ’67 borders. That’s an important change.

### Scientific Advocate (SA)
Claim: Excuse me, can I make a point?

### Conspiracy Advocate (CA)
Claim: And when we--

### Moderator
Claim: Let him finish, yeah.

### Conspiracy Advocate (CA)
Claim: When you speak about the Palestinian authority being incapable of controlling security, of course, because it’s under occupation. We are the first people in the human history who are asked to provide protection to their occupiers without being able to defend themselves from the occupiers. That makes no sense. We are saying we are ready to have international troops standing on the borders, even inside the Palestinian government state. We are ready to be totally demilitarized. We are, but we cannot provide security to anybody and even to ourselves if we are not independent.

### Moderator
Claim: Do you want to yield to Aaron?

### Conspiracy Advocate (CA)
Claim: Why going to the U.N., why admission of the U.N will change the parameters for once The balance of power today is so much skewed in the interest of Israel, and Israel does what it wants. What we need to do is to change the balance of power.

### Moderator
Claim: Okay, so let me bring--

### Scientific Advocate (SA)
Claim: We’re engaged-- with all due respect, I--

### Moderator
Claim: Aaron, can you come a little closer to the mic?

### Scientific Advocate (SA)
Claim: With all due respect to IQ2 U.S.-- I want to be invited back at some point-- we’re engaged in a kind of a thought experiment here. There’s a certain reality which we, once we leave this theater tonight, we’ll have to take account of there are only three ways that the Palestinian state will be born.

Either the Palestinians will take it from the Israelis by force, which they are unable and I take you at your word, Mustafa, unwilling to do. Second, an international organization or body where the will of the international community will somehow deliver it to them on their behalf, but that is incredibly fanciful. The notion that admission into the U.N. will give you access to the ICC, the International Criminal Court, the Israelis will have their own case to be made against you. And, by the way--

### Moderator
Claim: What did you think of Mustafa’s response to Dore’s point, that in fact Hamas has accepted 1967 borders and--

### Scientific Advocate (SA)
Claim: That in itself is a-- I have a tremendous respect for you, Mustafa, but that is-- that strains the bounds of credulity to the breaking point-- by the way, and by the way, this is a political organization which may, in fact, be undergoing a transformation. It is going to have to find a new home because the arc on the Assads is running south.

### Scientific Advocate (SA)
Claim: No, what I’m saying to you is that if in fact there is a change, it is a process that will have to be demonstrated not in words and not in quiet conversation and not in Cairo--

### Moderator
Claim: Let’s bring in Daniel Levy.

### Scientific Advocate (SA)
Claim: That is not-- that is not the main issue.

### Moderator
Claim: I will come back to you.

### Conspiracy Advocate (CA)
Claim: Why are you afraid of change?

### Moderator
Claim: Mustafa, Mustafa, I want to hear from your partner. And I’ll come back to Dore.

### Conspiracy Advocate (CA)
Claim: I know this is an issue in which people, you know, kind of skate in and out, don’t have very deeply held feelings. I think it’s a shame that we’ve descended into a blame game here, and I want to try and pick up on the thread that I think Aaron was trying to reintroduce to the conversation. The Palestinians can take this by force.

They can have it delivered to them by the international community. And I’m guessing where you’re going with the third one is they can convince the Israelis to actually withdraw. Or at least that’s where I would go with it. And if you’re about to tell me that they can wait for America to deliver it for them, then I suggest you see a production of “Waiting for Godot.” No, the point I want to make is that I think what the Israeli public needs to see right now, yes, there’s a continued-- there’s more of a Palestinian commitment and are continued by those who are already there, commitment to living alongside Israel, but I don’t think a charm offensive is the entirety of the ingredients that we have to bring into the mix. We have to bring in the ingredients which say to the Israelis, “Hey, I hope we’re moving away from violence, but we can’t sit on the sidelines while you swallow up all of Palestine. So we're going to make declarative attempts.

This does not mitigate against the fact that we want to live alongside you. We're not trying to replace you at the UN. But we do have to begin to accumulate some beginnings of a balance of leverage, some addressing of this asymmetry. I think that's productive for any future Israeli-Palestinian process.

### Moderator
Claim: All right. I'm going to-- I'm going to come to the audience for questions in a moment. Dore Gold has been very patient waiting through two rounds for a chance to respond.

### Scientific Advocate (SA)
Claim: Well, one of the purposes--

### Moderator
Claim: Dore Gold.

### Scientific Advocate (SA)
Claim: One of the purposes of this discussion-- we're in an academic setting. Academic setting means we have to distill what the truth is about certain situations. And we have to report the facts. And it is interesting to share those facts when you come from Cairo, or I come from Jerusalem. And unfortunately, there is the fact that five days after your meeting in Cairo, Hamas, on its official website, Palestine-info.info, Hamas made the following statement. "We underline our adherence to our right to the struggle in all its forms, particularly the armed struggle." That's not Martin Luther King. Sorry. And if I can just finish the sentence, it's not the UN charter which is our subject for tonight. And you can't embellish this. You can't somehow treat it as though it's not there, because you're asking these people to vote for admission of Palestine to the UN. If Palestine involves arms struggle, are you prepared to vote for arms struggle against my people, the people of Israel?

### Conspiracy Advocate (CA)
Claim: I can quote here--

### Moderator
Claim: Mustafa Barghouthi.

### Conspiracy Advocate (CA)
Claim: --many Israelis, including rabbis and Mr. Lieberman, your foreign minister, who described Palestinians as crushers But I'm not going to do that. I-- I--

### Scientific Advocate (SA)
Claim: --Hamas. There is some guy on the fringe of Hamas--

### Conspiracy Advocate (CA)
Claim: Sorry, sorry. So Avigdor Lieberman is some guy on the fringe of Israeli politics? On the same day that Israeli negotiators sat with Palestinian negotiators in Amman, this week, last week, Foreign Minister Lieberman said, this isn't going anywhere. There's not going to be a Palestinian state. The Likud platform says the government--

### Scientific Advocate (SA)
Claim: Excuse me, Daniel Levy. Daniel Levy.

### Moderator
Claim: Dore, let him finish.

### Conspiracy Advocate (CA)
Claim: I'm against the establishment of Palestinian-Arab state. I'm against Hamas' position. But this is not coming from one side--

### Scientific Advocate (SA)
Claim: Daniel Levy, that's called moral equivalents, Daniel Levy.

### Conspiracy Advocate (CA)
Claim: Oh, don't throw moral equivalents at me.

### Scientific Advocate (SA)
Claim: Yes, it is. Because--

### Conspiracy Advocate (CA)
Claim: What delegitimizes Israel, which we don't the border--

### Scientific Advocate (SA)
Claim: Daniel Levy, you can't--

### Conspiracy Advocate (CA)
Claim: What delegitimizes Israel is when--

### Scientific Advocate (SA)
Claim: Daniel Levy, you cannot--

### Conspiracy Advocate (CA)
Claim: --is when they maintain an occupation.

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: You cannot compare--

### Moderator
Claim: Passions are running high… debate is robust.

I'd like to go to audience questions please.

### Scientific Advocate (SA)
Claim: --Foreign Minister Lieberman did not call for murder, so don't put him in the same box as Hamas.

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: You're wrong. You cannot--

What undermines the state of Israel is your continued settlement project.

### Moderator
Claim: Daniel?

### Conspiracy Advocate (CA)
Claim: You think settlements are not a big deal. The settlements are the death knell, the death knell of Israeli democracy.

### Scientific Advocate (SA)
Claim: Nobody is killing anybody. I'm talking about our struggle.

### Conspiracy Advocate (CA)
Claim: But the settlements aren’t backed by the Israeli military. The settlements exist in some kind of bubble, esoteric world of-- come on. The real world. Who defends the settlements? The tooth fairy?

### Conspiracy Advocate (CA)
Claim: I'm really sorry for Mr. Gold because you are really advocating the creation of apartheid. And that means killing the two-state option.

### Moderator
Claim: You know, you know, what we aspire to here, and we just went to an episode of not doing it-- is actually to shed light by arguing relevant facts.

And all of these facts may be relevant to the larger argument. We're talking about the practicality or the morality of this motion. And we can talk about Cairo and who was at the meeting. And we got that point the very first time. And we can-- we know that Israel has a record that is offensive to the Palestinians. And we got that the first time. We would really ask you all to try to bring this level up to-- and I do think settlements are completely relevant, and you made that point well. But we would like to ask you to bring this up to a level of keeping this on the facts that are happening here. Now I'm going to the questions. And I'm-- I'm-- I'm counting on you folks to hear what I just said. So again, I urge to you really try to focus it as a question. Keep it on this point. We cannot argue every point of history back to 1948 and before.

And we're trying to understand-- we're trying to understand what will happen if this motion were to pass or if this motion were not to pass. Sir, and you're wearing a pink shirt on the far right.

### Moderator
Claim: Hi. I'd like to ask Mr. Barghouthi a question. Two brief questions, one is--

### Moderator
Claim: I'd like to just ask one. Pick one.

### Moderator
Claim: Well, they're so fast, it's going to be less than--

### Moderator
Claim: Just pick one. I want him to answer one.

### Moderator
Claim: Well, okay. One is there was a 10-month settlement freeze and the Palestinians, there's no movement on the part of the Palestinians. And two is, in '47-- I'm sorry.

### Moderator
Claim: All right. How is that-- sir, how does that relate to our motion directly?

### Moderator
Claim: to a motion. It's a question about what he was talking about.

### Moderator
Claim: Okay. Thank you, I'm going to go on to another question. We're trying to stay on the topic of this motion. With respect. Ma'am, right in the center.

### Moderator
Claim: So staying away from the question of whether it should be a two-state solution, but going back into the argument before.

What do you feel is the impact of passing a Palestine into the UN? How does it impact the actual negotiation process? So going back to what would actually--

### Moderator
Claim: I think Dore Gold said it would be--

### Moderator
Claim: --take two steps back--

### Moderator
Claim: --it would kill it. Didn't-- did Dore Gold not argue that it would be very detrimental to negotiations--

### Moderator
Claim: But I want to-- I want to understand from the side that's arguing for, how do you actually deal with-- I mean, are you undermining negotiations by prematurely entering into this position.

### Moderator
Claim: Okay. Let's let Mustafa Barghouthi take that question.

### Conspiracy Advocate (CA)
Claim: I have two questions. The first is about the 10-month settlements. The 10-month settlement to me, it's-- actually, there was no freeze, because it did not include Jerusalem. It did not include what they call “natural growth.” So there wasn't freeze. And Palestinians are trying their best, although I would agree with the tactics. But yesterday--

### Moderator
Claim: Mustafa, this audience is going to vote on what you said about the motion tonight. She asked a direct question about-- about the motion. If you could tell--

### Conspiracy Advocate (CA)
Claim: About the motion, yes. The second question is about the motion. And I want to say here that if we are admitted to the UN, the most important thing that will come out is that the illegal actions of settlements which are destroying the possibility of a two-state solution would be invalid. That means de facto creation of settlements on the ground does not undermine the right of the Palestinians to have a state. That will be good for peace and for two-state solution.

### Moderator
Claim: Aaron David Miller, do you have a response to that? It's a very interesting answer.

### Scientific Advocate (SA)
Claim: Well, I think it--

### Moderator
Claim: But could you come a little closer?

### Scientific Advocate (SA)
Claim: With all due respect, I think that exists in the level again of a thought experiment.

### Conspiracy Advocate (CA)
Claim: It doesn't.

### Scientific Advocate (SA)
Claim: It is-- admission to the UN will not stop Israeli settlement activity. I would argue actually it's going to accelerate it. And it will allow the Israelis to make it unmistakably clear to the Americans, who will, in fact, take their part in this, in large part because we - -

### Moderator
Claim: Mustafa's point is not-- not that the Palestinians would have more legal standing to resist.

### Scientific Advocate (SA)
Claim: The legal standing to do what? The day after you are admitted--

### Conspiracy Advocate (CA)
Claim: The fact--

### Scientific Advocate (SA)
Claim: Mustafa, let me finish.

### Conspiracy Advocate (CA)
Claim: --on the ground will not become fact--

### Scientific Advocate (SA)
Claim: Mustafa, let me finish. The day after you are admitted into the UN, nothing will change. And arguably-- and we've been arguing about it. Nothing is going to change because neither-- you need two powers to support and make sovereignty meaningful to you. You may have given up on them. You may have convinced yourselves that their administrations are bankrupt, and they may offer you no hope. But it is a reality that unless you can take what you want by force, unless the international community is going to give it to you, which they will not. They will not. They have the Iranians, they have the Syrians. People are standing in line to sanction well ahead of what the international community would do with respect to the Israelis.

Your ultimate objective is to create-- and I would agree with Daniel-- a different constellation of forces to support a negotiation, to end the conflict. But you cannot create that improved balance by seeking admission into the UN. It will not improve your standing. And I have heard nothing in the last hour--

### Moderator
Claim: All right. Daniel-- Daniel, do you have--

### Scientific Advocate (SA)
Claim: --to suggest that it will.

### Moderator
Claim: Do you have something new to say to him?

### Conspiracy Advocate (CA)
Claim: But before that, one second, please. I didn't say that admission to the UN is the only factor that will change the balance. I said this is part of a bigger thing which is popular, nonviolent resistance. It's diplomatic resistance within the context of something bigger. This will change parameters.

### Scientific Advocate (SA)
Claim: But you'll get the--

### Moderator
Claim: Daniel Levy.

### Scientific Advocate (SA)
Claim: You'll get the opposite reaction.

### Moderator
Claim: Aaron, let me let Daniel Levy, because I didn't hear from him.

### Conspiracy Advocate (CA)
Claim: Two responses, Aaron. First, I really beg to differ with you on what looks different the morning after Palestine's admitted to the UN.

In the following way, and this isn't just about Prime Minister Netanyahu and his coalition, but I do think that when Prime Minister Netanyahu can strut his stuff and say, "You see, the international community doesn't admit Palestine to the U.N.," I think that sends precisely the wrong signal to the Israeli public. I give credit to the Israeli public intelligence in knowing the cost benefit calculation of the signals they're receiving are not affirmative enough yet regarding two states, and I think it's that signal that matters, and I do think it's not going to change everything but it would change something in the discourse if Palestine is admitted to the U.N. And that's the kind of change that we need to begin to see happening.

### Moderator
Claim: All right. We are in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two, arguing out this motion, "The U.N. should admit Palestine as a full member state."And on to another question, yeah, you're very enthusiastic and you've got a red sweater.

### Moderator
Claim: You asked for questions that would eliminate a good discussion here. Could you please define to me who are the Palestinians? Whom are we negotiating with?

### Moderator
Claim: Wait, wait. I'm going to let you elaborate. I want to-- I want to know what you're--

### Moderator
Claim: I can't elaborate. I am sincerely asking.

### Moderator
Claim: So you're saying the PLO, the PA, the Hamas, are you confused or what?

### Moderator
Claim: Yes, I don't-- I do not have a sense of a nation of people that are properly represented to have negotiations to make--

### Moderator
Claim: All right. I'd like Mustafa Barghouthi to take this.

### Conspiracy Advocate (CA)
Claim: There was once an Israeli prime minister by the name of Golda Meir.

She said, "Who are the Palestinians? They don't exist." Well, since then, Israel has been fighting with a non-existing people. And I feel-- I'm so sorry that you think--

### Moderator
Claim: That you were nonviolent.

### Conspiracy Advocate (CA)
Claim: I'm so sorry that you think this way, ma'am, because denying the presence of people is nothing but a reflection of racism. We are there. We are there. We have our history. We're 11 million people. Six million of us are in the Diaspora. You know what would surprise you most is how much Palestinians are similar to the Jewish people. The suffering you had, we have and we will get there one day. And you and us would be happy--

### Moderator
Claim: I just have to ask you, what is the premise of your question, the Golda Meier, "Palestinians don't exist" thought, is that what you were--

### Moderator
Claim: No, I am--

### Moderator
Claim: Take the mic back. That's why I asked for clarification. Are you saying there's simply a splinter--

### Moderator
Claim: I would like to have a-- some kind of a description of whom are we talking about that we are negotiating with or not negotiating with, what is the entity that we can actually work with? What is the actual--

### Moderator
Claim: Daniel Levy, do you want to take a very quick run at this?

### Conspiracy Advocate (CA)
Claim: Well, Israel signs agreements with the PLO or the agreements that Prime Minister Netanyahu signed that were referred to earlier, those are signed with the PLO, the Palestinian Liberation Organization. There's negotiation right now as to whether on the conditions under which Hamas and other bodies will join the PLO. They're not in the PLO at the moment. The PNC is in the PLO. Every member of the Palestinian parliament, which means the gentleman sitting next to me is included in the PLO, that's who Israel--

### Moderator
Claim: Okay, let's move on to another question.

Sir, in the very center, dark sweater, you have-- wait for a microphone and please ask a question. And, by the way, ma'am, that was a question, and it was tightly focused, formally perfect.

### Moderator
Claim: Thank you very much.

### Moderator
Claim: Uh oh.

Male Speaker Solid answer, I am a third party here. I heard this side. I heard this side. special like me, he mentioned about peaceful nation under Article Number 4.

I need you to get to a question in the next two sentences.

### Moderator
Claim: So that is-- the question is whether Palestine is qualified to be a peaceful nation or not. The situation tells now that they don't.

And my comments on that are that they should be given another 100 years to go through the training and be a peaceful nation.

### Moderator
Claim: Okay, I don’t think you’re going to get any argument from-- maybe from this side. And we’ve heard the response already because this side has made that argument, so I want to move on, ma’am. Ma’am, right there. Yeah, yeah, you just pointed to yourself. Oh, I’m sorry. I’m not sure whether there is a mic is on this side. It’s going to come-- right on the edge there-- no. Yeah, that’s it, that’s it, that’s it. Thank you.

### Moderator
Claim: Hi.

### Moderator
Claim: Hi.

### Moderator
Claim: I think there are about 133 U.N. Security Council Resolutions against Israel or something like that. No?

### Conspiracy Advocate (CA)
Claim: I think you--

### Moderator
Claim: How many U.N.--

### Conspiracy Advocate (CA)
Claim: --General Council with other U.N. bodies.

### Moderator
Claim: Okay, well, how many U.N. resolutions have--

### Conspiracy Advocate (CA)
Claim: There are 41 U.N. vetoes against resolutions in the Security Council.

### Moderator
Claim: Well, I wanted to know how many U.N. resolutions Israel has formally rejected against it and why, if it rejected those, it suddenly sees the viability of U.N. decisions in this case?

### Moderator
Claim: But it won’t. So I’m going to move onto another question. Ma’am, in the far left-- you’re right at the last seat against the wall, yeah. No, with respect, sorry.

### Moderator
Claim: Hi. Thank you. I wanted to address this to Daniel Levy. The point that Mr. Miller made about that how can they control the guns, you’re saying that the PLO will be the one to take the seat at the U.N. Council. How will they then control the guns if there’s division within the Palestinian people?

### Moderator
Claim: You mean, how will they control the guns in Gaza?

### Moderator
Claim: Right.

### Moderator
Claim: Daniel Levy.

### Conspiracy Advocate (CA)
Claim: Yeah. I mean, as I’ve said, I think there are two ways of coming at this. First of all, call me curmudgeonly pessimist, but I don’t think the morning after Palestine’s admitted to the U.N., Israel is going to say, “Ah, game’s up. We’re withdrawing to the ’67 lines now.”So, in practical terms, you know, I believe that this is about what signals do we send, even as an academic exercise. So in practical terms, I think it’s a crucial question, but it’s not the morning after we all vote tonight or you all vote tonight or Palestine is admitted to the U.N. What I do think is-- and you know, let’s be creative diplomatically here-- what I do think is you should be encouraging realistic terms for Palestinian reconciliation, for one authority with one gun. And I think part of the blend of how you do that could be using the very admission of Palestine to the U.N., the very signing of that U.N. charter to hold Hamas to a certain standard on violence. Personally, I think, the--

### Moderator
Claim: Dore Gold, do you think that would happen?

### Conspiracy Advocate (CA)
Claim: --condition were not a good idea. The violence one was.

### Moderator
Claim: Dore Gold, do you think that’s what would happen?

### Scientific Advocate (SA)
Claim: Unfortunately, Hamas, and this is hard for us to understand this in the West, is a rigidly ideological organization. You know, in 2006, Hamas won the Palestinian election, not just in Gaza Strip but also in the West Bank. And Mahmoud al-Zahar, who would become the Hamas foreign minister, was asked by a Western correspondent, “Are you willing to change the Hamas Charter from 1988, which, by the way, does not call just for the destruction of Israel. It calls for the murder of Jews. It’s a genocidal document, and I have to use that language because that’s what it is. And do you know how al-Zahar responded in 2006? Not a single word. And many of us thought, you know, British Gas has found huge gas deposits offshore in the Mediterranean next to the Gaza Strip.

They want to have commerce with the EU, with the world. They’ll change. They’ll be flexible. They’ll meet the Quartet conditions. Hamas, in 2006 until our conflict with them in 2008, 2009, didn’t move and still haven’t moved.

### Moderator
Claim: Your answer is no.

No, no, I’m not-- your partner wants to bring in a point

### Scientific Advocate (SA)
Claim: Daniel’s response to this--

### Moderator
Claim: Aaron David Miller.

### Scientific Advocate (SA)
Claim: --question, to me, is an indication of the fundamental problem. It isn’t thought through, Daniel. Your response to this young woman is simply not rigorously thought through. You're assuming that we can create--

### Conspiracy Advocate (CA)
Claim: Go on. Help me with my lack of rigorous thinking Aaron--

### Scientific Advocate (SA)
Claim: No, no, that is not my-- I’m out of that business. I’m not here to help you think it through cleanly, but you are dispending a proposition that will in effect set into a motion a set of consequences over which you will have absolutely no control. This is the fundamental problem.

Just because negotiations are stuck, and I am the first person to acknowledge just how stuck they really are-- doesn't mean that in an effort to maintain hope, to diffuse desperation and to accommodate some measure of urgency, we need to pursue an idea that I would argue to you-- and you've, in my judgment, failed to demonstrate where the real upsides are. The downsides of this are very, very real. In July 2000, we decided to recommend to Bill Clinton to go to Camp David to try to create a conflict-ending solution between Israelis and Palestinians. Do you realize that a dozen years after that summit, we are still paying for the lack of wisdom and the recklessness of that decision? Israelis and Palestinians have not yet recovered from the trauma of those ten years, because we believed in an effort to do something in the face of a desperate situation, that we could make it better. This notion--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --is reckless, and it's not well thought through.

### Moderator
Claim: Daniel Levy to respond quickly.

### Conspiracy Advocate (CA)
Claim: With all due respect-- with all due respect, Aaron, to American omnipotence, I think we can allow Israelis and Palestinians just a little bit of agency for what happened--

### Scientific Advocate (SA)
Claim: They can have all the agency they want.

### Conspiracy Advocate (CA)
Claim: --in the last dozen years. And I'm sorry, Aaron. What you have failed to demonstrate is what is the negative impacts of having two states at the UN. What you've failed to-- what have you said?

### Scientific Advocate (SA)
Claim: Because you--

### Conspiracy Advocate (CA)
Claim: No, sorry. You've said this may harm Obama's re-election. Well, I don't think it's realistic--

### Scientific Advocate (SA)
Claim: No, that's not the major point.

### Conspiracy Advocate (CA)
Claim: Okay. Let's go on then. You have said-- you have said that it might lead to more settlements. You know what? If the Israeli goal is to make this territory indivisible-- and I hope it's not, but if that's the goal, let's start dealing with that reality. I don't want to go there. You've said it would undermine negotiations. Negotiations have gone nowhere. You're the one who wrote that it was America acting as Israel's lawyer that undermined that very Camp David effort that you just reminded us about. So come on.

Give us a constructive proposal to move forward because we've explained why this helps, and you haven't explained why it doesn't.

### Moderator
Claim: On the aisle here. Could you stand-- could you stand, please? Thank you.

### Moderator
Claim: Quick, yes, another question for Daniel Levy. Is it fair for the Israelis and the international community to expect that in return for what you support, the membership in the UN, that Hamas will say publicly and clearly and consistently, forevermore that they disavow violence in an arms struggle against Israel. Yes or no?

### Moderator
Claim: Daniel Levy. Do you want to concede to Mustafa on that, or do you want to take it, or share?

### Conspiracy Advocate (CA)
Claim: I do not think that the Palestinian right to self-determination, and therefore, by extension, Palestinian membership at the UN should be contingent on that. What I do think-- and I made clear here tonight-- I do not think that.

I don't think that Israel's right to self-determination should be contingent on certain things that I believe Israel should stop doing, okay? Not that I'm drawing the

### Moderator
Claim: Mustafa.

### Conspiracy Advocate (CA)
Claim: What I do think-- what I do think is we should use this, vis-a-vis Hamas. And I want to make another point here, because we've spoken an awful lot about Hamas. And anyway, as people have noticed, there's something going on in the Middle East. The Muslim Brotherhood, political Islam, of which Hamas is a part, is kind of popular when people get the chance to vote democratically. This is a reality we have to deal with. Now, we can bury our heads in the sand and say, there's a charter, and you have to stand up and publicly disavow X, Y or zed, or we can work, work day in, day out, to try and create a new reality that Hamas relates to, to try and create a new reality that the Muslim Brotherhood relates to, to work with this new reality in the Middle East. And the more Israel buries its head in the sand and says, you have to tick boxes X, Y and zed before we do anything, the worst we are going to make are predicament.

### Moderator
Claim: All right, Mustafa Barghouthi.

### Conspiracy Advocate (CA)
Claim: But on one side, we are told we would not be able to progress because Palestinians are divided. But then the same people, Israel and Mr. Gold, are against Palestinian unity. What we are working on, what we have achieved, actually, through the most recent negotiations is that Hamas officially declared, on the words of Khaled Meshal, that they are committing to nonviolence. I am trying to explain that to you, and you-- you don't want even to hear it, because if change is happening in the positive direction, what you see today is-- there is no violence in--

### Moderator
Claim: But Mustafa, let me make this point.

### Conspiracy Advocate (CA)
Claim: And-- no, no, but just one last point. If you-- what Mr. Miller is reporting is just specifically a continuation of the status quo. And we are saying this is dangerous, because today you have the whole Palestinian camp ready to accept nonviolence.

If nothing changes, if a solution is not found, if we don't move forward, then things will get worse. Is that what we want? We want to find a solution. And when we say we are admitting-- we are committing to nonviolence, we are doing diplomatic resistance, Israel should be happy about that, because that opens the road for a solution.

### Moderator
Claim: But-- but--

### Conspiracy Advocate (CA)
Claim: --just staying on the same course means--

### Moderator
Claim: Okay, Mustafa, I'm interrupting because you've made this point. But Dore Gold has left hanging out there several very alarming statements made by Hamas.

### Moderator
Claim: Exactly.

### Moderator
Claim: --very recently that do not suggest a commitment to nonviolence. So-- so I just need you-- I just need you to-- I just need you to tell us, what do we do with those statements? What is the

### Conspiracy Advocate (CA)
Claim: What did you do in Iraq? What did you do in Iraq? What was the Sunni awakening that you worked with? Were these people who were shooting Americans, did you ask them to make all kinds of pretty statements? You faced a tough situation.

What are you doing now with the Taliban? Sometimes you have to mix it with unpleasant, unsavory elements. This isn't a lesson in how to primly have nice tea parties. This is a hard reality--

### Moderator
Claim: Aaron David Miller.

### Scientific Advocate (SA)
Claim: Daniel, if you-- if you--

### Moderator
Claim: Aaron David Miller.

All right. Let him respond, and then I'll come to you.

### Conspiracy Advocate (CA)
Claim: The fact that Mr. Zahar and others came out against Meshal is proving my point, because that means that a division is happening there. But the official spokesperson, the leaders of this movement are admitting this. If this positive change is creating opposition within that organization, that is another proof that this is serious.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: And at the end of the day, the Palestinians are coming to the United Nations and saying, we are committed to nonviolence as the PLO and as Palestinians.

### Moderator
Claim: Aaron David Miller.

### Scientific Advocate (SA)
Claim: Look, in a negotiation, at least this negotiation, even if you were admitted as a member state, the logic of your analysis just isn't good enough.

You are going to need a monopoly over the organized forces of violence in your society, even to induce the Israelis or even by extension the Americans.

### Conspiracy Advocate (CA)
Claim: But isn't that what you praised in the West Bank today?

### Scientific Advocate (SA)
Claim: To help broker a solution on--

### Conspiracy Advocate (CA)
Claim: Aren’t you praising the government in the West Bank for having done that.

### Scientific Advocate (SA)
Claim: Can I finish? On the four core issues that drive the conflict, you will need one gun, one authority and one negotiating

### Conspiracy Advocate (CA)
Claim: Isn't that the case here?

### Scientific Advocate (SA)
Claim: But you don't have that. And the presumption is that you should be admitted into the United Nations as a full member state without it.

### Moderator
Claim: But he's saying that they do-- that you do have it.

### Conspiracy Advocate (CA)
Claim: In the West Bank, and he is praising it. He is praising Mr. Fayyad on--

### Moderator
Claim: On this point, he's saying that in fact that controls in the West Bank.

### Conspiracy Advocate (CA)
Claim: Isn't that the case today in the West Bank?

### Scientific Advocate (SA)
Claim: Sadly, as a consequence of the Oslo process, the area that you do control, you've actually done it as a consequence of intimate security cooperation with the Israelis and assisted by the United States and the Jordanians quite a lot, yes.

### Conspiracy Advocate (CA)
Claim: So why are you unhappy?

### Scientific Advocate (SA)
Claim: And you're building the institutions of statehood. But it's a far cry to assume that your national movement right now is unified and cohesive enough to warrant what it is you seek. Right now-- and I don't mean to trivialize this. The Palestinian national movement is literally like Noah's ark. There are two of everything. There are two Constitutions. There are two sets of security services. There are two polities. There are two independent entities--

### Conspiracy Advocate (CA)
Claim: At least we have a Constitution. Israel does not have a constitution.

### Scientific Advocate (SA)
Claim: Neither does Great Britain.

### Scientific Advocate (SA)
Claim: On this narrow point-- on this narrow point--

### Moderator
Claim: Daniel-- Daniel, the Noah's ark point.

### Conspiracy Advocate (CA)
Claim: What I'm hearing is that a case has been made. What I'm hearing is a lot of obfuscation from the other side. What I'm not hearing is, how do we advance this in a different way? What I've not heard--

### Moderator
Claim: That's not their--

### Conspiracy Advocate (CA)
Claim: I know. I know. I know. But we're making a case. We're making a case for how you can begin to lay down a marker on a rapidly evaporating two-state prospect. And all we've heard-- and I thought we'd hear it. And even-- I do think there's some onus on the other side to do a little more than give us an hour and a half of nay saying. I'm sorry, but I really--

### Scientific Advocate (SA)
Claim: If the proposition-- John, can I-- can I respond?

### Moderator
Claim: Yes. Yes, you can.

### Scientific Advocate (SA)
Claim: If the proposition that IQ2 US wanted to sponsor was, is Israeli-Palestinian peace possible, then we could have had a discussion. But the assertion that is made here-- the motion is-- you are asserting that Palestine should be admitted as a member state. And it is our-- it was our objective-- we may not have succeeded to your satisfaction--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: --perhaps even to the audience's, demonstrate why in fact that course of action--

### Conspiracy Advocate (CA)
Claim: What you are suggesting, Mr. Miller, is that we give Israel the time to finish the settlement project.

### Scientific Advocate (SA)
Claim: I'm not suggesting that at all.

### Moderator
Claim: You premised a lot of your argument on--

### Moderator
Claim: Who's the question for?

### Moderator
Claim: Mr. Barghouthi.

### Moderator
Claim: Okay.

### Moderator
Claim: You premised a lot of your argument on claims about the balance of power between Israel and the Palestinians. The last negotiation in my mind is one in which the Israelis traded one soldier for hundreds of Palestinian terrorists-- thousand-- excuse me. And I'm wondering, given the willingness on one side-- on behalf of one side of the debate, namely the Palestinians, to send in young boys and girls to kill themselves, how can you argue that the piece of cheese is entirely on the side of Israel and that the Palestinians are left with nothing to do? It seems like the willingness to commit suicide leaves them with a lot to do and transforms radically this balance of power which you're arguing has completely shifted to the side of the Israelis.

### Conspiracy Advocate (CA)
Claim: You are a young man. You are a young man. And I think as a young person-- I'm responding to your question-- no, I'm saying as a young person, and I admire young people, you should look into the reality today, not keep talking about the past. What you are describing-- what you are describing is something that is a long time disappeared. And if we keep going back to the past, we will not find a way to the future.

You're asking why Israel exchanged one prisoner for 1,000 Palestinian prisoners, because Palestinians had only one prisoner.

And, by the way, by the way, by the way, there are still 5,000 Palestinian prisoners in Israeli jails. Do you know how it feels-- do you know how it feels-- what is strange to me is why when the Oslo agreement was signed, not all of the Palestinian prisoners were released, why did it take Hamas to capture an Israeli soldier so that spent 33 years in jail had to be released? Why couldn't they be released? Because of the peace agreement. This is the mistake.

### Moderator
Claim: One last question.

### Moderator
Claim: Little far from the U.N. Can we keep it on the issue?

### Moderator
Claim: Can you come forward? Come forward into the-- so the camera can see you.

### Moderator
Claim: I'd like to address my question to Daniel Levy and Dr. Barghouthi.

This is a question of context, gentlemen, which I don't think we've heard in this debate. The last legitimate democratic election in Palestinian areas was won by the Hamas convincingly in 2006. The Palestinians, the PLO, Fatah as the lead faction of the PLO has failed to conduct negotiations in January 2010 and subsequent. So the only legitimate government in the eyes of the Palestinian people today is the Hamas. On the basis of Mr. Haniya in Gaza, he is the legitimate Palestinian leader in the eyes of the Palestinian people.

### Moderator
Claim: All right--

### Moderator
Claim: So how do you argue that the Israelis should be-- that the Israeli public should be comfortable with a legitimate sovereign called the "PLO" when in the eyes of the Palestinians, the majority of the Palestinians, it is only the Hamas that was the sideline and jailed and tortured by the Fatah, legitimate Palestinian leadership?

### Moderator
Claim: Mustafa Barghouthi.

### Conspiracy Advocate (CA)
Claim: Let me clarify one point here. When Hamas won election, they got 44 percent of the votes and Fata got 41 percent. It was the stupidity of Fatah, who did not accept full proportional system that led to Hamas getting a majority in the parliament. Today I assure you there is a growing number of Palestinians that want to see a third alternative, which I think we represent. And I do not think that either Hamas or Fatah will get an absolute majority in any future elections. What you should encourage is that Palestine becomes a full state democracy with pluralism. I always believed and I still believe that the only way to have a peaceful-- a lasting peace between both sides is if we have two democracies negotiating an agreement and not to have an agreement enforced from one side to another.

## Round 3

### Moderator
Claim: All right. Thank you. And that concludes round two of this Intelligence Squared U.S. debate. And here’s where we are. We are about to give brief closing statements from each debater in turn. Those closing statements will be two minutes each. And after those statements, we will ask you to vote on this debate and choose the winner. Our motion is “The U.N. should admit Palestine as a full member state.” And here to summarize his position against this motion, Aaron David Miller, a former U.S. Mideast peace negotiator, advisor to six secretaries of State, author of a book coming out in September of 2012 called, “Can America Have Another Great President?” Aaron David Miller.

### Scientific Advocate (SA)
Claim: Yeah, thank you very much. I realize that in the last 90 minutes that perhaps one of the most astute things that I’ve done, one of the best decisions I’ve made was to leave the Arab-Israeli negotiating process. And I say that with tremendous respect and affection for everybody on this panel. If the goal is achieving statehood, if that is really the goal, then it seems to me that U.N. admission simply doesn’t make much sense.

You alienate the two countries that Palestinians will need-- Israel and the United States-- to produce meaningful and legitimate Palestinian sovereignty. You will kill Salam Fayyad’s nation-state building effort. There’s no question about that. And you’re putting your hope in an international community that has never ever abandoned you, actually, but isn’t capable of delivering your sovereignty. And I would argue that even though, Dan, you persist in saying that we haven’t demonstrated what the downsides are, I think given, in my judgment, the risks of admission and the uncertainties that will certainly follow, other than hope, which is extremely important, and diffusing a measure of desperation, even more important, you haven’t demonstrated how in effect U.N. membership will bring Mustafa Barghouthi and his people any closer, any closer to negotiating Jerusalem borders, security, refugee into meaningful statehood.

Maybe the strategy has more to do with internal Palestinian politics with Mahmoud Abbas’s exit strategy, with the Arab spring and the Arab winter, with a full reconciliation with Hamas. In effect, if that is your objective, well then maybe you should seek U.N. admission but not if you want to facilitate the negotiations. My good friend, Daniel Levy, wrote the day before yesterday, the PLO strategy-- the PLO has a bad case of strategic combobulation. And the U.N-Palestinian effort was a weak-- a damp squib, a damp squib-- damp squib--

### Moderator
Claim: Aaron, I have to set you-- one more sentence, please.

### Scientific Advocate (SA)
Claim: If Daniel Levy doesn’t believe it, which I don’t think he does, then why should--

### Moderator
Claim: No subordinate clauses.

### Scientific Advocate (SA)
Claim: Then why should we believe it?

### Moderator
Claim: Thank you, Aaron David Miller. Our motion is “The U.N. should admit Palestine as a full member state,” and here to summarize his position in support of this motion, Daniel Levy, former Israeli peace negotiator and senior fellow at the New America Foundation.

### Conspiracy Advocate (CA)
Claim: What I said was right. I think the Palestinians should pursue this in a different way, and it’s going to take time, but there’s a strategy for getting there. We’ve spoken a lot here about Hamas. But I think the way you further empower Hamas and discourage change in Hamas is to close all nonviolent diplomatic options in the face of the Palestinians. I know people here. And I also don’t like to hear the word “apartheid.” Here’s what the Israeli minister of defense, Ehud Barak, said in February 2010, “The simple truth, there is one state including Israel, the West Bank and Gaza. It’s either bi-national or undemocratic.” That will be an apartheid state. That’s the tragedy that we want to prevent.

And you know what? Our toolbox is an impoverished one because we have tried so much already. But sticking exclusively with negotiations really must be the dumbest idea. So what do we have left that’s nonviolent. Let’s use the international tools of diplomacy that are at our disposal to make a statement. We haven’t heard negative consequences that can come from this. And mostly we haven’t heard what else to do except to blindly continue to place our faith in negotiations or that the Palestinians somehow should only be ingratiating themselves without creating any leverage with Israel and America. It’s been tried. It hasn’t worked. The risk is the status quo. The risk is the continued dissent of Israeli democracy to a place where it will be unrecognizable and an inability to reach a two-state solution. We need to send a signal here from this room that Palestine should be admitted to the UN.

And the UN needs to send a signal to Israelis and Palestinians that there's going to be a two-state solution, otherwise the next debate will be about equal rights in one indivisible territorial unit. I'm not against equal rights in democracy, but I want an Israel, an Israel that's different, that changes. But I want an Israel. And I'm sure Mustafa wants a Palestine. And we should have both of those as member states of the UN.

### Moderator
Claim: Daniel Levy, your time is up. Thank you. Our motion is, "The UN should admit Palestine as a full member state." And here to summarize his position against the motion, Dore Gold, former Israeli ambassador to the UN and former advisor to Prime Minister Netanyahu.

### Scientific Advocate (SA)
Claim: These are-- this is a very important issue. And I am sorry that at certain points in this discussion we got heated. But the stakes are not just winning a debate in this very nice auditorium in NYU. This is about issues that relate to our very existence.

I started, before I was cut off earlier on, telling you that when we withdrew from the Gaza strip in 2005, we had great hopes that we were removing a cause, an irritant, and therefore, Prime Minister Sharon, whom I knew very well, decided to take that risk and pulled out unilaterally. And instead of rocket fire dropping as a result, it increased between 2005 and 2006 by 500 percent. The state of Israel is obligated to make sure that whatever arrangement we make on the West Bank doesn't replicate the conditions in the Gaza Strip. Unfortunately, unfortunately, Mahmoud Abbas has decided on a course of action that he actually began at the end of the Olmert government. It's a course of unilateralism.

And with this unilateralism is an effort to get recognized as a Palestinian state with UN membership, without having to address our concerns, without having to address the security of Israel, without having to recognize my people's right to a nation state, even though I'm being asked to recognize his people's right to a nation state. And finally, to predetermine the outcome of negotiations by going to the UN and saying, the borders will be June 4, even though the UN back in '67 said we weren't going back to the exact '67 lines. And therefore, I suggest to you, particularly in light of the fact that we're seeing an effort to sell you an unreformed Hamas, and unreformed Islamic Jihadist part of the Palestinian political community, to reject the notion that the Palestinians should be accepted as a member state until they change.

### Moderator
Claim: Thank you, Dore Gold. Our motion is, "The UN should admit Palestine as a full member state." And here to summarize his position in support of this motion, Mustafa Barghouthi, member of the Palestinian parliament and leader of the Palestinian National Initiative.

### Conspiracy Advocate (CA)
Claim: Thank you. Mr. Gold has repeated practically what Weisglass, who was an advisor to Mr. Sharon when he said that we withdraw from Gaza so that we can put peace in formaldehyde. We can put peace to sleep. Unfortunately, creating fear is not a solution. And everything that Mr. Miller and Gold have suggested today is nothing but wasting time and using time. And I am telling them, you can maybe afford to lose time because you haven't lived for 44 years under occupation. You haven't lived in this position for a long time. And you haven't been humiliated every day by occupying forces. You can maybe even afford to be sarcastic, gloomy, and even depressed.

But that will not bring change. Yes, the peace process has become a substitute to peace, and that's why we need to change the situation. I cannot afford to lose time because this is about my life, about my daughter's life, and it's about the lives of the Palestinians and Israelis. And the Israelis themselves cannot afford it. When I ask people, what do you want? They say we want jobs, we want education, and we want health care. We could not have had that-- we couldn't have that because we have occupation. And this needs to end. What the Israelis want is also security. But that also cannot be available as long as Palestinians are insulted and humiliated. Where Azizi in Tunisia created a revolution because he brought the issue of dignity to people's minds. And every day, thousands of Palestinians dignity is harmed. What we are trying to say to bring light in the end of the tunnel.

When you vote today, don't take away hope. Don't take away light at the end of the tunnel. And let me remind you here with what Plato said. He said, “We can easily forgive children for being afraid of dark. The tragedy is when grown people are afraid of light."

### Moderator
Claim: Thank you, Mustafa Barghouthi, very much. And that concludes our closing statements. And now it's time to learn which side this audience feels has argued best. We're going to ask you again to go to the key pads at your seat and to push the keypad whose number corresponds to the side that you feel argued best. Our motion is "The UN should admit Palestine as a full member state." If you feel this side, the side in support, argued best, push number one. If you feel the side against, this side argued best, push number two. If you remain or became undecided, push number three. And as I said before, just correct it, and you'll get the last one come in correctly.

So I want to-- there is no need to apologize for bringing a little bit of heat to the conversation tonight. In fact, it was justified and passionate. But I also have a thing for light. And so I like to bring as much light as heat. And I think that ultimately this team-- both teams rose to that. And I want to thank you for hearing each other and for hearing me. And debating this honestly and fairly. And I also want to thank members of the audience who had the guts to get up and ask questions. And the vast majority were very good and very on point and really did move this along. So a round of applause to those of you who are able to get up and ask questions. So we'll have the vote-- the results of the vote in just a minute. What I'll do is I'll read off the preliminary numbers for, against and undecided, and then the final numbers, for, against and undecided.

And the team with the largest difference will be declared our winner. In the meantime, very briefly, I want to tell you about our next debate. It's coming up on February 7th. And in light of the fact that there is a health crisis in this country of many, many varieties, but we're going to be talking about the obesity epidemic, with 33 percent of adults in this country, and 17 percent of children obese, we thought it was time to find a way to look at this issue as a matter of debate. And the way that we're looking at it is whether-- where is the issue of personal responsibility and government responsibility in this in terms of, are people obese simply because they eat too much, or are they obese because they're being advertised to because of what's in food, and additives, the proliferation of fast food. And does government have a role in that or not. Basically, whose fault is it? And who should do something about it? Arguing in support of the following motion: "Obesity is the government's business” will be Pamela Peeke, also a medical doctor. She's a nationally renowned physician, a scientist and an expert in the fields of nutrition and fitness. And on web MD, she is the chief lifestyle expert. The team arguing against this, that's saying obesity is not the government's business, is Paul Campos. He is author of "The Obesity Myth." He's a Constitutional law professor who came to this issue in an unusual way. He was watching all of the coverage of the Monica Lewinsky story back in the late '90s, and he became obsessed with the obsession in the news media over Monica Lewinsky's weight. And he just started thinking. And he ended up writing some books and has strong points of view on this issue. And his debating partner, also arguing that it is not the government's business, but a matter of personal responsibility, John Stossel, an Emmy award-winning journalist.

He is host of FOX Business Network's Stossel, a weekly program that highlights consumer issues. He is a contrarian. If you know him, who would like government to stop meddling in people's business. And he is himself a very, very slender television correspondent. And I can-- I can only admire him. So we'll take just about 30 seconds more. And the results will come to us. But thank you very much for your patience. Okay. I've got them. I've just been given the results. Remember now, we had you vote twice. You've heard this debate, this argument, the arguments for and against this motion, "The UN should admit Palestine as a full member state." We asked you to vote before and again afterwards. The vote afterwards telling us which side you feel presented the better argument. Before the debate, 37 percent were in support of the motion that the U.N. should admit Palestine as a full member state, 30 percent were against, and 33 percent were undecided.

After the debate, 55 percent support this motion, that is up 18 percent, 37 percent are against, that is up only seven percent, the undecideds went down by 25 percent to eight percent. That means the motion has carried, the side arguing the U.N. should admit Palestine as a full member state has won this debate. Our congratulations to them. Thank you from me, John Donvan, and Intelligence Squared U.S. We'll see you next time.
