# Debate Transcript

Topic: Don't Give Us Your Tired, Your Poor, Your Huddled Masses
Motion: Don't Give Us Your Tired, Your Poor, Your Huddled Masses

Debate ID: tired-poor


## Round 1

### Moderator
Claim: And now I'd like to invite all of our debaters to the stage. I'm told there's one exception to the no phone rule, and that is if you are Tweeting. You can Tweet to your heart's content. And so that's it. I also want to-- this is the last of our regular season in our fifth season of Intelligence Squared U.S. And all of them are because of the generosity of our chairman, the Rosenkranz Foundation, who makes this all possible. I'd like to welcome to the stage Mr. Robert Rosenkranz.

### Moderator
Claim: Well, thank you very much. It's great to see you all. And my task in these proceedings is to frame the debate, to give a sense of the arguments on both sides.

And for more than a century, the statue of liberty has welcomed visitors with an Emma Lazarus poem engraved on its pedestal. Tonight's motion comes from one of the most famous lines in that poem, "Give me your tired, your poor, your huddled masses yearning to breathe free." Well, today, many would want to rewrite those lines to read “Give me your energetic, your affluent, your educated elites.” But how should we feel about poorly educated, unskilled immigrants, especially those here illegally? If we analyze the question in terms of costs and benefits, we can see that those who benefit from immigrant labor are a very different group than those who shoulder the costs. And that may be why the issue is so controversial.

Employers of low-wage immigrant labor reach the major benefits, large scale farming operations benefit. And as concerned as we all gain from lower food prices, owners and patrons of restaurants benefit. Affluent household benefit from child care, landscape maintenance, housecleaning and all manner of other services that only immigrants seem eager to provide. The costs are borne very differently. Low-wage immigrants receive more from government, especially state and local governments than they pay in taxes. The state provides education for their children. It provides emergency medical care and array of other benefits. In some communities, crime and drug issues disrupt the lives of law-abiding citizens and impose major costs for police, courts and prisons.

All these costs add up to a major fiscal drag. And it's no wonder that states like Arizona favor stricter enforcement of existing laws. And if we think about the question more philosophically, both sides of the debate can cite appealing principles. “Give us your tired, your poor, your huddled masses” does express American generosity of spirit, the vision of our nation as a beacon of opportunity and invokes a rich history of immigrant groups that have succeeded here. But equally appealing principles point in the opposite direction, respect for the rule of law and a basic sense of fairness are also bedrock American values. Policies that reward those here illegally at the expense of those patiently waiting for legal status fly in the face of those principles.

Considering the costs and the benefits, considering the conflicting principles, which side of the argument should prevail? Well, it's up to you to decide. And it's now my privilege to turn the evening to our panelists and to our moderator, John Donvan. Thank you, John.

### Moderator
Claim: Thank you. And I'd just like to invite one more round of applause for Robert Rosenkranz for making this possible. The famous verse inscribed on a plaque at the base of the Statue of Liberty says "Give me your tired, your poor, your huddled masses yearning to be free." But do we really all agree on what that means? Or if we flip it around and say, "Don't give us your tired, your poor, your huddled masses," what does that mean? Well, that's what we are here to debate. This is another debate from Intelligence Squared U.S. I'm John Donvan of ABC News. We're at the Skirball Center for the Performing Arts at New York University.

And here on the stage we have two teams of two members each to argue over this motion, "Don't give us your tired, your poor, your huddled masses." We have a Texas mayor. We have a man who has written laws on immigration. We have a former congressman and a journalist who has written about immigration who will be arguing this out and trying to change your minds because that's what this is. This is a debate in which you, our live audience, are the judges. By the time the debate has ended, you will have been asked to vote twice, once before the debate and once again afterwards. And the team that has changed the most minds will be declared our winners. So let's go to your preliminary vote, where you stand on this issue before you actually hear the arguments. There are key pads at your seat on the right hand side. And if you agree with our motion, “Don't give us your tired, your poor, your huddled masses,” press number one. And, yes, you're voting for a negative so, it's a little bit tricky. Be careful with that. If you agree-- if you disagree with this motion, press number two. And if you are undecided, push number three.

And if you think you made a mistake, just fix it, and the system will lock in your last vote. And we're going to share the results of that vote at the end-- the vote that you just made at the end of the debate as we present both the before and the after votes to tell us who you chose as our winner. So on to round one. Round one, we have opening statements by each debater in turn. They are seven minutes each. And with our motion, “Don't give us your tired, your poor, your huddled masses,” speaking first for this motion, Tom Tancredo. He's a former Colorado congressman who sought the 2008 Republican nomination for president to bring attention to the issue of illegal immigration. And while the language of this debate is a little bit spicy and to a degree metaphorical because we know that you're not against all-- not against all immigration. It's not that absolute. You did, nevertheless, sign up to argue for this side.

### Conspiracy Advocate (CA)
Claim: That's right.

### Moderator
Claim: Don't give us…And, Tom, so in a sentence, why have you identified yourself so powerfully with this battle on illegal immigration?

### Conspiracy Advocate (CA)
Claim: Well, I will be happy to answer that. Let me first tell you that I must say in response to your discussion about the title of this debate, about the proposition itself, I was a little bit uptight about it originally because, after all, we are debating this issue here in New York City a few miles from Ellis Island. And I have been-- I have participated in things in the past that have been a little bit skewed, and I can recall a spoof of me, a debate-- or actually it was supposed to be a little discussion between me and Vincente Fox, but it was a spoof on "Saturday Night Live," and so they had someone who looked like-- and I knew it was biased from the beginning, from the very beginning because the guy playing me looked like me and the guy playing Vincente Fox was Antonio Banderas-- No fair, come on, guys.

### Moderator
Claim: So to my question, in a sentence, why do you identify so powerfully with this?

### Conspiracy Advocate (CA)
Claim: Frankly, I-- you look at it and begin to think about the ramifications of immigration, both legal and illegal, and they are fascinating. It is really one of the most intellectually stimulating areas of public policy I think we can possibly talk about.

### Moderator
Claim: Okay, we'll let you go, ladies and gentlemen, Tom Tancredo.

### Conspiracy Advocate (CA)
Claim: A great deal of mythology has built up around the Statue of Liberty, around the Emma Lazarus poem, and a lot of that mythology, of course, is just that. It's mythology. But unfortunately we have a tendency in the United States, we look back sort of nostalgically at a period of time because most of us are either children of or grandchildren of immigrants, and so the whole idea of immigration has a sort of a nostalgic appeal to us, and that's our first thought usually. And I am the same way. I am the grandson of Italian immigrants, came right here into Ellis Island.

And my parents being first generation Americans were very, very strict about one thing and that was to become an American, to become-- and it meant a lot of things to them in different ways, and I'll get to it in a minute, except that I do want you to understand I have that same nostalgic opinion to a large extent of what our immigration policy was, but we can't confuse that and make-- and develop true policy today based on mythology and, you know, some of the myths that we have to dispel. I think tonight's a good place to do it, it’s-- first of all the Statue of Liberty was not a gift from France that was designed to explore the wonderful idea of open immigration. Indeed it had nothing to do with immigration policy. It had everything to do with extolling the virtues of a republic. In fact, the statue was called “Liberty Enlightening the World.” It was not called “Liberty Inviting the World.” As for the Emma Lazarus poem, it was added 30 years after the statue got here.

And it was about that time that the author of the poem, Ms. Lazarus, was talking about the need to limit immigration to various groups. Remember also that a lot of the tired, and poor, and huddled masses got stamped “return to sender" here at Ellis Island. There were people with dangerous elements and ailments like pinkeye or a cough or fever, and if anyone exhibited any degree of exhaustion by climbing the very steep stairway over at Ellis Island which was purposely built that way, that was one of the things that could get you sent home. It was not a take all comers time in American history. As for the poor, well, long before the Ellis Island experience, the colonies had enacted very, very stringent regulations about this particular aspect of immigration policy.

In New York in 1691, it required an immigrant to have, quote, "A visible estate or manual occupation or give a sufficient surety that he shall not be a burden or a charge to the respective place that he shall come to inhabit." In 1996 in the Congress of the United States, they tried to actually expand on this and say that you had to have an affidavit signed by someone if you’re coming here, you had to have an affidavit of support. They put it in, it was part of the Welfare Reform Bill, never, not one time, never has it been enforced. And so the fact is we are in a-- unfortunately, we are importing a large degree of poverty into the United States. The National Academy of Sciences along with the Center for Immigration studies shows that welfare use, the rates for welfare use, are significantly higher for immigrant households than they are for nonimmigrant households.

Federation for Immigration Reform could identify a net cost, net cost after taxes were paid by illegal immigrants, they were just focusing on that one part, a net cost to American taxpayers of over $150 billion annually. Now, my point here is to show that for a long period of time in American history, we had what I would think was, and believe, is a rational policy. It was rational for us to bring in a lot of people, especially during the hay-day of American immigration, the 1890s and 1900s, a lot of people who were low-skill, low-wage people. Why? Because, of course, we were building the Industrial Revolution here. They were fueling it. That was appropriate. It was right. It served purpose for the people coming and it served a purpose for the people here. I hope-- well, also, as I see we’re getting toward the end of that 7-minute period, there is another myth I want to try to dispel quickly.

And that is that immigration has always been sort of a straight-line increase from the time America started until today, that it’s always just been going up. Absolutely untrue. About 1830 is when immigration began to be statistically relevant in the United States. It started to climb. By 1850, it started to go down. Around 1880, it grew. Around 1890, it declined. It rose dramatically right before the First World War, but declined dramatically after the First World War with the Immigration Act of 1924. It stayed relatively low for a long period of time until, as a matter of fact, 1965, when everything changed with the Immigration Act that was pushed by Senator Kennedy at the time, Senator Teddy Kennedy. And we’ve had now really massive immigration, low-skill, low-wage workers ever since that period of time.

Now whether or not those-- that cyclical movement and that cyclical characterization I just gave you of immigration was purposeful or not. It had and served a good purpose, I think. We had periods of high immigration. We had periods of low immigration. And you know what happened during the periods of low immigration? People used that time to assimilate. And let me tell you, from my point of view, this is by far the most important aspect of the debate. Assimilation-- we can have massive amounts of immigration to this country, the right time and the right type of immigration, especially, as I say, depending upon our needs here as long as we have assimilation along with it. Or, if it doesn’t happen along with it, it has to happen at that period of time that we take a break, which is not a bad idea for us to think about even now, because assimilation is not occurring.

It’s not occurring to the extent-- I mean, I know you can’t categorically say that, but it is certainly not occurring to the extent that we need it to in this country. We desperately need, perhaps more than any country in the world, we need things to hold us together, to think about as being Americans, to connect together, not pull us apart. And I’m afraid our immigration policy is doing just that.

### Moderator
Claim: Thank you, Tom Tancredo. Our motion is "Don't give us your tired, your poor, your huddled masses." And here to argue against the motion, I’d like to introduce Julián Castro. He is mayor of San Antonio, Texas. He is a superstar in his party. He was the youngest, at the time, the youngest member ever elected to the San Antonio Council and is now the youngest mayor of a major U.S. city, although, Julián, you know that if you stay in that job a lot longer, people are going to stop saying that.

### Scientific Advocate (SA)
Claim: I’m already starting to get the grey hair.

### Moderator
Claim: Ladies and gentlemen, Julián Castro.

### Scientific Advocate (SA)
Claim: Thank you all very much. Thank you. Thank you very much, and let me say thank you, John, and to everyone here at “Intelligence Squared,” to Congressman Tancredo, Secretary Kobach, and to all the folks who showed up tonight. We appreciate being here. Tamar Jacoby and I have the distinct pleasure of arguing against the motion on the table tonight. You know, last week, I’m a little bit embarrassed to say that at 3:20 in the morning, Central Time, I woke up to flip on CNN to watch the Royal Wedding. I admit it. I couldn’t help myself. It was one of those moments that you’d just rather see live than see on tape. My wife didn’t even wake up. She stayed asleep and I woke up. And they had about two hours of coverage before the bride actually showed up on the doorstep of Westminster Abbey. And in the background of the coverage in one of the shots on ABC or CNN---- one of the networks that was covering it, there was laid out on a fence post, the United States flag, the flag of America. And I was surprised to see that, although it was a welcome sight. But there was something in my mind that told me that that American flag looked out of place at the Royal Wedding. And as I thought about it more, the reason that our American flag looked out of place is because our country has never been a country about royalty or caste or one's station in life. It has always been defined as a country for the strivers, for the aspirers, for the folks who can pull themselves up by their boot straps, who are willing to take the chance, the entrepreneurs, most of whom start off as folks of lesser means, folks who make themselves.

And this country, the United States, of all the countries in the world and all the countries throughout history, has defined itself as the nation that has taken in folks from around the world and allowed them to pursue their dreams, to reach their American dream and to become, from some who was poor and huddled among masses, to someone who is successful and able to enjoy the fruits of the capitalist system. And so it is that I believe we need to continue to welcome not only the wealthy but the poor from other countries. We need to do that for several reasons. The first is that immigrants are vital to our national economy. Immigrants actually found companies at almost twice the rate of native born U.S. citizens. Companies founded by immigrants in the years between 1995 and 2005 actually created 450,000 jobs in the United States of America.

In one single year, they generated $52 billion in sales in industries like high technology and engineering; that the number of folks who start those companies is at 25 percent nationally. And in Silicon Valley, it's at 52.4 percent. And remember, it is a false distinction to think that the folks who found these companies start off as wealthy. Oftentimes they don't. Think about your own experience, either in your own family, or how many times have you heard someone tell the story of their family member who came here with just a few dollars in their pocket and were able to contribute great things to this country? Congressman Tancredo also mentioned the idea of assimilation. And I believe that it is important for folks generally to assimilate to a common culture in the United States.

And that's exactly what has been happening in the United States of America throughout our history with immigrants. What we have seen consistently, and I think that Congressman Tancredo and I agree, what we have seen is that from time to time there has been this very intense concern about balkanization. Benjamin Franklin famously said that we should rid Pennsylvania of the Germans in 1751. We had the Alien and Sedition Act of 1798, the Chinese Exclusion Act. We had the fear in the early 1940s during World War II that Germans and Japanese would somehow try and overthrow the government of the United States. The reason that we have succeeded as a nation, that today we are the most powerful economy in the world is that we have been able to overcome those impulses. And I believe that we need to continue to overcome those impulses for the future. It's also incorrect to say that immigrants only take, and they don't give.

In 1993, the Urban Institute did a study that found that 94 percent of immigrants were not on welfare and that the distinction between immigrants and natives in terms of who was on welfare was less than three percent. They also contribute up to $240 billion in taxes overall into Social Security and Medicare that they're actually never going to get a chance to use. And the National Conference of State Legislatures, a few years ago, did an analysis of 16 different states. And they found that in five of those, including some of the biggest ones, New York and Texas, that there was a net positive from immigrants, including illegal immigrants, versus a negative. And so this idea that they don't pay taxes, that they only take, that they're on welfare, the evidence clearly demonstrates that that's not the case.

I also believe, and I anticipate that some may argue that having so many folks come to our country is not good in terms of crime. The numbers bear out that immigrant communities are actually safer than nonimmigrant communities. Terrorism, the idea that somehow there are many folks walking across our borders that are going to commit acts of terror against folks in the United States. I don't believe that's true, either. In fact, in 2010, of the 463,000 apprehensions that we had in the United States, two 10,000ths of one percent were apprehensions from folks that, excluding Cuba, were from countries that were listed as a state sponsor of terror. What we're catching really are a whole bunch of folks who are yearning to breathe free, who are chasing the same values. Congressman Tancredo asked what's going to keep us together. What's going to keep us together is what always has kept us together as a nation, the fact that people come here to work.

They're entrepreneurial. They believe in democracy. They're people of good faith. They have the same values that have always made America great. And I hope we'll continue to do so if we can get the policy right. Thank you.

### Moderator
Claim: Julián Castro, your time is up. Thank you very much. So a reminder of where we are. We are halfway through the opening statements of this “Intelligence Squared U.S.” debate. I'm John Donvan of ABC News. And we have four debaters, two teams of two, fighting it out over this motion, “Don't give us your tired, your poor, your huddled masses.” You have heard two of the opening statements, and now on to the third. I'd like to introduce Kris Kobach, who is secretary of State for the State of Kansas, and who also gets around the country quite a bit consulting as a lawyer for other states on immigration laws. He was the co-author of Arizona's controversial SB1070. You are also defending laws-- no hissing, please.

You're also defending laws in I believe Missouri, Texas. Where else?

### Conspiracy Advocate (CA)
Claim: Nebraska.

### Moderator
Claim: Nebraska.

### Conspiracy Advocate (CA)
Claim: Pennsylvania.

### Moderator
Claim: Pennsylvania. Now, your-- do people in Kansas think you're not taking this secretary of State thing not seriously if you're getting around so much?

### Conspiracy Advocate (CA)
Claim: Well, I'm making plenty of noise there too.

### Moderator
Claim: Okay. I just want to remind you to move a little closer to your mic. And ladies and gentlemen, Kris Kobach.

### Conspiracy Advocate (CA)
Claim: Thank you. My work in terms of immigration policy at the national level began in 2001 when I served as counsel to John Ashcroft at the Justice Department. And after I left the Justice Department in 2003, I left with a very important idea in my head and that was that the rule of law has broken down in immigration, and much had to be done to restore it. But it had to be done not only at the national level, but also at the state level. And that's why I got involved helping states like Arizona and many other states.

In 2007 for the first time, every state in the country saw legislation introduced into the state legislature to, in some way, restrict or slow down the pace of immigration into that state. Not all of them passed, but that's an important point. Every state is a border state now. The reason that nearly all of the states on the map are trying to take steps to discourage illegal immigration is several-fold. But the number one driver is a very important point in this debate, and I'd like to start there. The fiscal cost, fiscal cost, the cost to governments, to taxpayers to the illegal immigration in particular is unsustainable. My point can be summarized in one sentence by Nobel laureate, Milton Friedman. He said, it's just obvious. You can't have open immigration and a welfare state. You can't have open immigration and a welfare state. Now, my guess is that there are a few fans of the welfare state here in the audience. I am not a big fan myself, I accept the reality that it's here to stay. And given that reality, there is an important distinction that needs to be made between the current wave of immigration, which started in the '80s and has been going unabated for three decades, and all preceding waves of immigration.

They were not immigrating into a welfare state. They were immigrating into a situation where they rose or they fell based on their own merits. There was no safety net to catch them. That is a critical distinction that changes everything. When Emma Lazarus wrote that poem, she spoke of a lady holding the golden-- the lamp by the golden door. Now, the golden door she was referring to was a golden door of opportunity. You come here, you're free to do whatever you can. You make it or you lose it, but it's all up to you. Now that golden door represents goodies, public benefits, services that are available to people who come to the United States more than any other nation in the Western hemisphere. The golden door represents something completely different. Now, aliens are consuming those benefits far more than U.S. citizens are doing so. Now, the average per household consumption-- that consumption of public services and benefits, is estimated, from a 2007 figure, not 1993 numbers, 2007, to be $19,400 per year net.

They're consuming-- and this is all immigrants, the illegal and legal combined. 19,400 per year more in services than they're paying it in taxes. So that's a net drag on the fiscal status of the country. Now, Julián mentioned this 1993 study. I have not seen that study. That is so old I wouldn't even know where to begin because the numbers are so different back then. Now we're talking 11.3 million illegal aliens in the country. There was also a study that came out last month based on census figures from 2010, and the number was generated by the Center for Immigration Studies, crunching the numbers, 71 percent of illegal alien households are consuming some form of welfare, 52 percent of lawfully present alien-headed households are consuming some form of welfare, in contrast to only 39 percent of the U.S. citizen-headed households are consuming some form of welfare. Now, the explanation for this is obvious. It has nothing to do with ethnicity or nationality, it has everything to do with economics and demographics. Poor people are more likely to consume welfare.

And immigrants coming into the United States, especially illegal immigrants, are almost in all cases having less than a high school education. If you look at all immigrants combined, about two-thirds have a high school education or less, and so we are importing a very impoverished set of immigrants, both legal and illegal, into the country. Here's another fact to chew on. The Mexico-American border has the greatest disparity in income levels of any border on the planet. There is no other national border where the difference between the rich country and the poor country per capita is greater. That fuels a lot of this fiscal cost, too. So since 1996, Congress has passed laws trying to discourage this handing out of public benefits because it exacerbates the problem. Most states have ignored that law. New York is one of the states that continues to give public benefits to illegal aliens. New York also gives in-state tuition rates to certain illegal aliens. Think about that if you are a-- well, I don't think any of the out-of-state students who are at a public institution are clapping right now because they're paying out-of-state tuition rates.

Now, the-- nationwide, as Tom mentioned, it's over $100 billion a year net that is flowing out to illegal aliens, that is to say, they're consuming that much more in benefits than they're paying in taxes. And the burden falls overwhelmingly at the states. Indeed, I like to say illegal immigration is the ultimate unfunded federal mandate because the federal government, which is chiefly responsible for enforcing the laws, fails to do so, and then the states have to pay the burden. You can think of story after story about this. Hazelton, Pennsylvania, one of the cities that I'm representing, they saw their population explode from 20,000 in the year 2000 to about 30,000 five years later, 50 percent increase in population, but they get most of their revenue from an earned income tax and their revenue remained flat. Population goes up 50 percent, no additional tax revenue, that was because most of the additional people coming in were working at a meat packing plant nearby, were illegal aliens, and they were either earning too little income to pay any taxes or they were earning purely cash income.

And the city wasn't getting any revenues. Look what happened. All the costs to the city went up 50 percent, all the costs contingent on population. The school districts, the budget was breaking, English as a Second Language, the expenditures in 2002 were 136,000 that year. In 2006, they went up to 1.1 million. Talk about that kind of burden on a small town school district. The same thing is happening at the national level. And as a result, we have to recognize that there is a fiscal cost. Or take it on the individual level. Look at the jobs. There are 14 million Americans out of work. A vast majority of the 11.3 illegal-- million illegal aliens have those jobs, about seven million are in the workforce. Many states are realizing the simple truth, if you want to create a real job for a U.S. citizen tomorrow, deport an illegal alien today. It actually works. But of course many of you are probably thinking, and I'm sure we'll hear from the other side, that those are jobs Americans won't do, that those are jobs that are too low on the totem pole for Americans to do.

Well, the statistics don't bear that out because in every single one of the industry-- industrial sectors where illegal aliens are prominent, U.S. citizens still have the majority of jobs there, 74 percent of construction workers, U.S. citizens, 76 percent of food preparation workers, U.S. citizens, 56 percent of agriculture laborers, U.S. citizens. The U.S. citizens are there, and they're working right alongside the illegal aliens who are depressing the wages or taking their jobs outright. So if we care about our fiscal health, and if we care about the Americans who are struggling to put food on the table, we should look very seriously at our immigration problem in the United States.

### Moderator
Claim: This is our motion, "Don't give us your tired, your poor, your huddled masses." And now here to speak against the motion, Tamar Jacoby, actually had a long career as a journalist, was a writer, a justice reporter for Newsweek, then was deputy editor of the op-ed page in The New York Times.

And then you went on to write books about immigration, and now you're running an organization called "ImmigrationWorks USA," and you're not approaching this from the left but you're actually looking at it from the point of the small businessmen whom your organization assists and, Tamar, I just want to say I’m very glad to hear about the post- journalism career success personally. It’s very heartening.

### Scientific Advocate (SA)
Claim: You too can go into politics.

### Moderator
Claim: Ladies and gentleman ladies and gentleman, Tamar Jacoby.

### Scientific Advocate (SA)
Claim: Thank you so much, and thank you so much to the sponsors of this event. So, like all of us, I’m a descendant of immigrants. In my case, there were two kinds of immigrants. On one side were the Eastern European Jews, and on the other side were the people who came on The Mayflower. So, I grew up in a house where I had two lessons. One was that difference was really kind of what made us great. It’s certainly what made the two sides of my family great. And I learned to understand later it was what made the country great. But I also learned that, in many ways, what we have in common-- this was another lesson in my household-- what we have in common is more important than our differences.

And so I see the challenge for the country going forward, as it was in my family, is to make sure that balance is in the right-- is in balance, that we’re getting the benefits of the difference, but we’re also holding together as one country. And that’s where I start when I’m considering immigration. It’s not-- there have been words thrown around here: nostalgia, generosity, I’m not sure anybody mentioned rights, but that’s another way that a lot of people come at it. I don’t come at immigration from any of those perspectives. I come at it from what is in America’s interest. What’s really good for us, for our economy, for our security, and for our future? And that’s why I’m dead set against this motion. I don’t think it’s good for our economy or for our values. So let’s start by being honest. Immigration is about economics. It’s driven by economics, for the people who get up in their home villages and come here, and it’s driven by economics for the Americans who hire them. And the bottom line is it turns out to be an economic win- win. Immigrants create jobs.

And contrary to what you’ve just heard from Kris Kobach, it’s counterintuitive, I know, but you heard me right. Immigrants create jobs. It’s easy to see how that works on the high end. The 25 percent of the patents in the United States that are taken out by people who are foreign-born, the 25 percent of the doctors in America who are foreign-born, the 25 percent of the nurses, the half of all of our science and engineering Ph.D.s who are foreign-born. And you heard it from my partner, Julián, the quarter of the tech startups that were started by foreign-born. As in the past, countries competed-- powerful countries competed for coal and iron-ore in colonies. Today, countries around the world are competing for high-end engineers and smart immigrants. But it’s true at the low end, too, that immigrants create jobs. And again, I know this gets even more counterintuitive, but, you know, I’ll never forget here-- and this is really what partly brought me to do exactly what I’m doing now---- hearing the man who ran a seafood processing plant on the Eastern Shore of Maryland talk about his company. He came to the floor of the Senate and he did this. He talked about how he had a 100-year-old family company. The native born people on the Eastern Shore no longer wanted to do the hard seasonal work. Americans like full-- year-round jobs. No one wanted to do the hard seasonal work of picking the crab out of the shell. So he brought Mexican women every summer to pick those crabs out of the shell-- very low-paid, uneducated people, seasonal workers. You know, that’s the low end of the economic totem pole. But because he had those seasonal workers, he could actually keep his company open in a way that he wouldn’t have been able to if he didn’t have them. And because he kept his company open, there was a job for the manager in the company and the people who packaged the seafood and the accountant in the company. And because he could keep his company open, there was seafood for the restaurants in the town where the tourists came to eat seafood.

And because those restaurants and the seafood, hotels, gas stations, insurers, you can get the picture-- up and down the food chain, those lowly, lowest bottom-of-the-totem seafood pickers were keeping an economy going. And the point is that on both the top and the bottom end of our economy, the bottom of the skill ladder and the top of the skill ladder, we have holes that needs filling by a foreign workforce. The American workforce is changing. We’re getting older. People are-- we’re having smaller families. People are retiring sooner. We’ve created-- we have holes at the top and bottom of the workforce, and we’re lucky that they’re filled by immigrants who, because they’re different from Americans, either more or less skilled, they’re complementary, not competitive. They create jobs for Americans. Of course, there are costs, and we’ll talk more about the costs in this-- I don’t deny there are costs to immigration, but in the long run, ultimately, the good far outweighs the bad.

Our need for workers also changes. That’s not so-- in a bad economy, we need fewer foreign workers and in a good economy, we need more. But ultimately, the point is the patents, those PhDs, the startups and the jobs for U.S. workers up and down the food chain. And the 64 million question for me is how are we as a country going to handle what I think is a given of the interconnected world. We're lucky immigrants are coming to fill these niches at the top and bottom of our economy. And how are we going to handle it in a way that's consistent with our values, that maximizes the benefits, minimizes the cost and is consistent with our values? And this is really where I differ from my opponents in this debate. I too am for the rule of law. I too am for security and effective enforcement. But I also think we need to be honest about our needs.

It doesn't really work I don't think to have two signs at the border, one that says, "Help wanted,"-- one that says, "Keep Out" and one that says "Help Wanted." I don't think that's an honest standup way to go about our business. I don't think we want to treat the people who come to work for us-- I think we want to treat them in an honest, standup way. We don't want to say, "Wink, wink, nudge, nudge, come on in" when times are good and then harass them with policing laws when times are bad to so that they leave. Ultimately, that's what I think today's debate is about. It's about how to do we deal with the reality of our economic needs in a way that's consistent with our values? And if you listen tonight, what I think you should be asking yourself is whose way is more likely to lead to a successful immigration and successful integration or assimilation? Is the best way accepting reality, allowing people to be here legally, treating them with dignity, or is the best way pretending that we don't need these workers, pretending that we can drive them out when we can't and driving them further underground?

## Round 2

### Moderator
Claim: Thank you. Tamar Jacoby. And that concludes round one, opening statements of this “Intelligence Squared” debate. So here's where we are. We are past opening statements, and we're about to go into round two, and that's where the debaters address each other one on one. They take questions from me. And after a little bit, we'll take questions from you as well. And I want to, again, urge you, when you're formulating your question, to really think in terms of something that's terse and on the point and that really is a question. So if it has a question mark at the end of it that's there appropriately, that's the telltale sign that it's functioning as a question. What I'm trying to discourage is your debating with the debaters, but to throw something in here that would actually make them continue to hash out the issues. So I've got to do this part for radio.

And I'll do this from time to time. I just need to do a little make believe welcome backs kind of thing, and we're taking a break, even though we really won't. So it would be a great help to me if you could do a round of applause that-- that will play coming back from a break in the radio broadcast, and then I'll start talking. Thanks very much for doing this. Go ahead. So we are back, and now on to round two where the debaters address each other directly. I'm John Donvan of ABC News. We're at an “Intelligence Squared U.S.” debate at the Skirball Center for the Performing Arts at New York University. Our motion is “Don't give us your tired, your poor, your huddled masses.” We have two teams of two members each who have been arguing it out. The team arguing for the motion says that we're working under an out-of-control immigration system where the wrong people are getting in the wrong way and exploiting America's generosity, while also, in some cases, diluting America's American-ness. The other side is arguing that immigration may need some fixing but that it is vital for the U.S. economy.

And they're also arguing that immigration actually is the American story. So I'd like to go to the side that is arguing for the motion, arguing don't give us your tired, your poor, your huddled masses. And Tom Tancredo, you were talking about the notion that right now we're importing poverty. And I want to ask you, who is welcome? Who are the immigrants that are welcome?

### Conspiracy Advocate (CA)
Claim: Well, certainly, you could establish an immigration policy based upon the needs of the country in an economic sense. And that is a determination I think that we have made many times during our past. Are our needs primarily low-skill, low-wage workers, or are they with high skilled. The people that Tamar and the mayor referred to as being these startup companies, these affluent-- or at least people who became affluent, had all these skills, great, fine.

It's wonderful. But I'm telling you that that's not what our immigration policy is today. Today it is based almost entirely on something called family unification. And because we've had so many people coming into the country over such a long period of time from such low-skilled, low-wage backgrounds that that's who we get.

### Moderator
Claim: And take 30-- 15 seconds to describe the dynamic of family unification.

### Conspiracy Advocate (CA)
Claim: Well, sure. It's, if you get here, once you get here and get status here, status as someone here legally, you can begin the process of bringing in your family, bringing in the immediate family then bringing in extended family.

### Moderator
Claim: And the problem being?

### Conspiracy Advocate (CA)
Claim: Being it's coming exactly from the same group of people, the same economic group, especially, that is predominantly low-skilled, low-wage workers when we have, right now, at least-- by the way, this is also legal-- I'm talking legal immigration.

### Moderator
Claim: As well.

### Conspiracy Advocate (CA)
Claim: Let alone the people that are coming across the borders illegally. Not many of those people have these kinds of skills that you're talking about that are so desperately needed.

### Moderator
Claim: Okay. Let's do a response from the other side. Julián Castro is mayor of San Antonio.

### Scientific Advocate (SA)
Claim: Thank you very much. First, the argument is built on this idea again that immigrants, both legal and illegal, are somehow soaking up welfare payments and other state subsidies which is not borne out by the evidence. I would also say that last week, folks may have seen this news story. The Internal Revenue Service, the IRS, reported that 45 percent of households in this tax year will pay nothing in federal income taxes. So are we to say then that they have no value either because they're not paying any federal income tax.

### Conspiracy Advocate (CA)
Claim: It's interesting that you mention that because, of course, when we also start talking about the taxes that immigrants and even people who are here illegally pay, there is-- your side suggests that they're paying their fair share. But in reality, they pay nothing in terms of income taxes. Most of the people we're talking about end up getting income tax credit and therefore money back from the federal government because again, it's low-skilled, low-wage work.

And low-skilled, low-wage people don't pay income taxes. They usually pay-- they pay sales taxes and that sort of thing. But it never balances off with--

### Moderator
Claim: Julián Castro.

### Conspiracy Advocate (CA)
Claim: --the costs we incur for the infrastructure we provide.

### Moderator
Claim: Julián Castro.

### Scientific Advocate (SA)
Claim: Let's just be precise here. They do pay state income taxes and in some cases federal income taxes. They also pay sales taxes any time they go and buy something. They pay hotel occupancy taxes every time they go to a motel or a hotel. They pay car rental taxes when they rent a car. They pay all types of fees to the government that help the government run and also patronize businesses and spend their money. And they have a tremendous economic impact on every local community.

### Conspiracy Advocate (CA)
Claim: They do.

### Moderator
Claim: Let me ask Kris Kobach--

### Conspiracy Advocate (CA)
Claim: That is true. And economic impacts are not positive.

### Moderator
Claim: Tom, let me bring in your-- let me bring in your partner. Kris Kobach, I just want-- Kris, I just want you to respond to what we just heard because I think that's news to a lot of people, a long list of taxes in fact which the immigrants are paying. True or not?

### Conspiracy Advocate (CA)
Claim: It is true that aliens, legal and illegal, of course, pay sales taxes.

They indirectly pay property taxes. They may pay some income taxes if they're working under a false Social Security number. I'm talking about the illegal aliens here.

### Conspiracy Advocate (CA)
Claim: Which, by the way, they'll never be able to claim.

### Conspiracy Advocate (CA)
Claim: But the fiscal impact is undisputed. Now, there are some economic studies that look at the overall impact. Have we cheapened the price of some goods? Have we given some economic benefits? But if you narrow it to the fiscal impact, it is undisputed. Every single study in the last 10 years, whether you're talking about Robert Rector's study in 2007 or the Census Bureau numbers that I related just a moment ago where you have seven, eight percent of illegal aliens consuming welfare programs, 51 percent of legal aliens and 39 percent of U.S. citizens, which, by the way, matches up well with that 40 percent figure. It shows statistically that they are consuming the fiscal benefits. And if you just look at in terms of the benefit to us as taxpayers, we're losing on--

### Moderator
Claim: Okay. Let's go to Tamar Jacoby, your opponent.

### Scientific Advocate (SA)
Claim: I mean, again, it all just depends on how you measure it and how you look at it. If you look at it most immigrants pay their taxes to the federal level because they have their income tax withheld from their paycheck.

So if you look not just at the state level, but the federal level as well, and you look over their whole lifetimes, they actually pay in about as much as they take out because what costs is health and education--

Let me finish. Let me finish. The cost is health and education. But then they turn into earners and taxpayers. And so if you look over their whole lives, if you look at the federal story as well, it's about an even-even. Social Security, they pay in every year about $7 billion that they don't take out because they pay in on-- illegal immigrants pay in on Social Security numbers, and they don't recoup the costs. So they get to keep the--

### Moderator
Claim: But your opponents have made the case that in other ways that immigrants and illegal immigrants especially are drawing on the welfare system.

### Scientific Advocate (SA)
Claim: Well, they're exaggerating their welfare numbers. But let me just make my--

### Moderator
Claim: 2010 census.

### Scientific Advocate (SA)
Claim: Let me just make a closing point. The point is that what you're leaving out is growth, is the growth they make possible.

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: And let me just give you a couple numbers. So in the State of North Carolina, they measured over the '90s, what an immigrants-- what was the fiscal cost and what was the growth made possible in consumption and adding to businesses. Fiscal costs over 10 years, $61 million. Now, that's real money, that's those costs by Latinos coming to the States-- growth, growth, 11 billion--

### Moderator
Claim: All right. Tamar, I-- we see where you're going with the growth

### Scientific Advocate (SA)
Claim: Growth, 11 billion.

### Moderator
Claim: --take it, but I want your opponents to respond to your earlier point.

### Conspiracy Advocate (CA)
Claim: That rightwing organization, the National Academy of Sciences, I mean, will you accept that as a legitimate entity that assesses these issues? I mean, it doesn't have-- to the best of my knowledge, it doesn't have a dog in this fight, it doesn't have a political bone to pick with anybody. It's the National Academy of Sciences. You can argue with the-- with CIS and other studies, but the National Academy of Sciences shows that you're not correct, Tamar, when you suggest that this isn't a fiscal drain on this country. It most certainly is.

### Scientific Advocate (SA)
Claim: That's not what that study found.

### Conspiracy Advocate (CA)
Claim: It is also just common sense, it's not even something that you have to go through reams of statistical evidence to prove it is common sense.

If you come here without an ability to provide a service that is well paid for you are not going to be able to pay the income taxes you're talking about, but you are undeniably going to require the services, the services for your children, the children who are in the public school system, the services for the-- the social services--

### Scientific Advocate (SA)
Claim: And I consider educating the workforce of the future--

### Conspiracy Advocate (CA)
Claim: --the social service benefits.

### Scientific Advocate (SA)
Claim: I consider educating the workforce for the future not as a welfare benefit but an investment.

### Conspiracy Advocate (CA)
Claim: Yeah, or in the day today

### Moderator
Claim: Tamar cedes some time to her colleague, Julián Castro.

### Conspiracy Advocate (CA)
Claim: Sure, an investment. Well, okay, how about the investment in our prison system?

### Moderator
Claim: Tom, Tom, Tom, I want to bring in Julián Castro.

### Scientific Advocate (SA)
Claim: Well, what Congressman Tancredo may remember as well is that in 2006 the Republican State Comptroller of Texas did an analysis that said that-- that analyzed how much revenue-- state revenue had been generated by illegal immigrants and found it at $1.58 billion and said that $1.16 billion in state resources had been taken by illegal immigrants, and so this idea that it is just is so clear cut across the country, that's not true.

### Moderator
Claim: Kris Kobach.

### Conspiracy Advocate (CA)
Claim: I with that study, that Texas Comptroller study looked-- it didn't just look at fiscal income and outgo, then they went on and considered, "Well, have there been generations in second and third degree effects of extra businesses or extra--

### Scientific Advocate (SA)
Claim: Right.

### Conspiracy Advocate (CA)
Claim: --consumption that might have occurred?" Now, that's fine, and look, let's get this straight, the fiscal debate is clear, they are a fiscal drag. Now, I will agree that there are - - we get cheaper vegetables because of this, but you have to realize there are winners and there are losers. The winners are the employers who are able to exploit the illegal labor, the losers are the consumer-- the winners are the consumers of some goods who really want that extra two pennies off the price of a head of lettuce, but the losers are the U.S. citizens who lose their jobs, the U.S. citizens who are still working in those fields and are getting paid a lower wage, and the taxpayers. There's no doubt the taxpayers are the losers.

### Scientific Advocate (SA)
Claim: None of this is true, that no economists-- no economists looking for a wage effect, there’s been people studying it for 20 years, even the most--

### Conspiracy Advocate (CA)
Claim: George Borjas--

### Scientific Advocate (SA)
Claim: --yeah--

### Conspiracy Advocate (CA)
Claim: 2007.

### Scientific Advocate (SA)
Claim: --has found that over 20 years there's a less than five percent wage effect for the people at the very-- for a high school dropout.

### Conspiracy Advocate (CA)
Claim: So you can see there is a wage effect.

### Scientific Advocate (SA)
Claim: And other-- economists challenge him and say--

### Conspiracy Advocate (CA)
Claim: I agree.

### Scientific Advocate (SA)
Claim: --it’s less than one percent, and other economists who studied it say that so the division is between over 20 years for the-- only the 10 percent of Americans who drop out of high school, that for them it’s between one and four, and for everyone else it’s actually gains is wages--

### Conspiracy Advocate (CA)
Claim: Can I see if we agree on this point?

### Scientific Advocate (SA)
Claim: --for everyone else it’s gains in wages because having low skilled people there makes the productivity of the higher workers go up.

### Conspiracy Advocate (CA)
Claim: So do we agree on-- do we agree on the Borjas numbers? Says that if you have a 10 percent increase in the number of laborers in a given industrial sector you will have in the short term a decrease in wages of seven to eight percent, and in the long term a decrease in wages of three to four percent, in the long term. So we agree on that, they can decide whether that's significant or not.

### Scientific Advocate (SA)
Claim: Three to four, three to four.

### Conspiracy Advocate (CA)
Claim: I think that’s significant.

### Scientific Advocate (SA)
Claim: For other high school dropouts.

### Moderator
Claim: Julián Castro, you--

### Scientific Advocate (SA)
Claim: no, no--

### Moderator
Claim: Julián, you heard your opponent.

Moving on to a different part of this argument, and that’s the assimilation argument, your opponent's raising the concern that the wave of immigrants that we’re talking about for the most part, poor immigrants and illegal immigrants as well, that they’re not coming-- they’re not really becoming part of the culture. They come to dip their toes and to remain speaking Spanish and to remain with the dream of going back home ultimately and not really buying in. Can you take that on?

### Scientific Advocate (SA)
Claim: Sure, I’d say first that it’s been a common theme in American history, this impulse to believe that anyone who is other than the dominant majority is somehow going to poison the culture. And look at us all these years later as a nation, we are a very strong nation, we’re the number one economy in the world. We’re a nation where folks are learning English, where they are participating in democracy. You know, in my own family, for instance, just anecdotally, my grandmother that I grew up with, came to the United States when she was very young from Mexico, and tonight I’m speaking perfect English, not Spanish, so.

### Moderator
Claim: By the way, I hear your Spanish is pretty terrible.

### Scientific Advocate (SA)
Claim: My English is about 100 times better than my Spanish, and really the idea is not that, you know-- the idea is that you see a common trajectory, no matter whether it’s the Germans that Benjamin Franklin was talking about, the Chinese that we tried to exclude, you know, the French that we were, we passed the Alien Sedition Act for, or today, the Hispanic culture, folks embrace America--

### Moderator
Claim: Right, but I think your opponents are arguing it in several ways. This time it’s different. And I want to go back to Tom Tancredo And why is it different?

### Conspiracy Advocate (CA)
Claim: It would be exactly the same, quite frankly, if the numbers were close. What I mean by that is this-- all during the period of time that we talk about as being the heyday of immigration to this country, we of course witnessed exactly what you say in terms of people coming here and being, you know, sort of sequestered or put in-- or sequestering themselves.

I mean, it didn’t always happen because we forced it that way. You know, groups settled where they were comfortable, settled in what we call ghettos sometimes. But that’s natural. It’s a natural phenomenon. They’re going to look for the people that they know, the language they understand, the customs and habits that they’re familiar with, perfectly natural. What happened in the past is that the numbers allowed for, and also the timeouts that I mentioned earlier, allowed for an assimilation process. Even if people didn’t want to, they were almost forced into it in order to get ahead in the country. Of course, there was the issue of English. My grandparents, I can remember so distinctly my grandmother and grandfather in the back seat of the car, Sunday afternoon drive, after a couple of hours, they had been together for probably long enough in close proximity so they started to argue about things. And my grandfather would lapse into Italian and my grandmother would yell at him, “Speak American, dammit!”And it was her purpose, and it--

### Moderator
Claim: But why are you saying that’s not happening in the Mexican communities as well?

### Conspiracy Advocate (CA)
Claim: Because the numbers today are so high of people coming from a particular area into a geographic area that bring the culture--

### Moderator
Claim: You’re saying there’s a critical mass-- you’re saying there’s a critical mass in this case that makes it different--

### Conspiracy Advocate (CA)
Claim: That makes is much more difficult to assimilate.

### Moderator
Claim: I just want to see what the other side’s response to that.

### Scientific Advocate (SA)
Claim: People in the second generation, even among poor-- children of poor Mexicans, everyone learns English. And the third generation, three-quarters of the people can’t speak Spanish anymore, can’t speak to their grandmother. People are learning English as they did in the past.

### Moderator
Claim: No, it’s not, Tamar.

### Scientific Advocate (SA)
Claim: Where I want to shift the conversation is, I believe that the policies of our opposing team would actually make integration or assimilation harder, not easier. They want to keep people on the wrong side of the law, not let them make restitution and get right with the law and come into society. They want to end birthright citizenship so that the children of immigrants grow up not as citizens, which every study that’s looked at it has shown makes the parents less likely to learn the language and integrate.

### Moderator
Claim: All right, before you go through your list, I’d like to give them a chance to respond. Kris Kobach?

### Conspiracy Advocate (CA)
Claim: There are-- obviously, assimilation has occurred and obviously assimilation can occur in the future in America. But assimilation doesn’t happen automatically. As Tom mentioned, you have to have-- there’s a tipping point. If the percentage of the immigrant population is so high and is so disproportionately speaking one language or sharing one culture, then the pressure from the rest of us, the rest of the American society, on that group to assimilate is lower.

### Moderator
Claim: Kris, the point that was just made by your-- the point that was just made was, for example, a policy that you mentioned before of denying in-state tuition prices to immigrants actually acts to stifle assimilation because those are going to be kids who won’t be going to school.

### Conspiracy Advocate (CA)
Claim: Well, actually, it’s to encourage people to leave and comply with the law and go home. That’s the idea. Now, but let me-- let me give one more point on assimilation, and that is one of the greatest engines of assimilation-- I think we can all agree on this-- is the public schools.

In the past for the last 100 years or so, the public schools have been the primary engine of assimilation. That engine is not working anymore. According to a study done at a high school in San Diego, I think in 2002 or 2003, after three years of high school, the proportion of students self-identifying themselves as Americans went down 50 percent. The proportion saying they were hyphenated Americans, in other words, Mexican- American or something like that, went down 30 percent. And the number that they were saying they are a foreign nationality after three years of high school went up 52 percent.

### Scientific Advocate (SA)
Claim: And that study was done in the middle of the battle over Prop 187, which was denying benefits to immigrants--

### Conspiracy Advocate (CA)
Claim: That was in 1994.

### Scientific Advocate (SA)
Claim: --had commercials on TV saying stop them coming-- I know the study you’re talking about, Rumbaugh’s study, and what he was showing was that when there’s an anti-immigrant climate, people get alienated and identify with their group. And that’s exactly what I would argue your side is creating, is an anti-immigrant climate that drives people to identify with their group and not assimilate.

### Moderator
Claim: Do you see the logic? I just want to-- I’m not taking sides, but Tamar Jacoby has presented a logical explanation there.

I’d just like you to take it on. Tom Tancredo.

### Conspiracy Advocate (CA)
Claim: Sure, the logical argument is this: If people come into this country illegally, especially illegally, we should all go, huh, well, you're an immigrant, and therefore we should be happy about the fact you're here. We should not-- we should not raise our concerns about it. We should not say that people should come into the country the legal way. There is a door. 180-- 165,000 people a month come in today still legally. We are the most liberal country in the world regarding to legal immigration. But the minute we start talking about the fact that people are violating American laws to get here, that's all of a sudden making it an uncomfortable place for immigrants. Well, bologna. I will not accept the idea that you can't talk the rule of law and be critical of people coming into this country illegally.

### Scientific Advocate (SA)
Claim: I agree with you that illegal immigration-- I agree with you--

### Conspiracy Advocate (CA)
Claim: What's wrong with that?

### Scientific Advocate (SA)
Claim: --that illegal immigration is not what the country wants.

And I agree with you--

### Conspiracy Advocate (CA)
Claim: But you want to grant an amnesty.

### Scientific Advocate (SA)
Claim: that we need enforcement of the rule of law. But the problem is our system makes it hard to enter legally, and we don't have enough places for the workers we need. And then we make it easy to enter illegally.

### Conspiracy Advocate (CA)
Claim: A million-- a little over a million and a quarter people coming legally every year. And by the way, as you know, Tamar, the number of visas that are allowable for people to come here and work in the agricultural arena, H-2A, I believe, are unlimited. Right there you could have 10 million people come tomorrow and on their visas.

### Scientific Advocate (SA)
Claim: But they don't.

### Conspiracy Advocate (CA)
Claim: You don't because--

### Moderator
Claim: I want to bring in--

### Conspiracy Advocate (CA)
Claim: Just a moment.

### Moderator
Claim: --Julián Castro has not been heard from for more than four minutes, and I would like to - - which is rare for a politician.

### Conspiracy Advocate (CA)
Claim: You don't have that because--

### Moderator
Claim: Tom, let me--

More than four minutes, and you have.

### Conspiracy Advocate (CA)
Claim: All right. Okay.

### Scientific Advocate (SA)
Claim: Yeah, a few months ago, the census released its 2010 figures. And I believe that the population was somewhere around 308 million. And the number of illegal immigrants in our country has been pegged at 11 million.

Now, you know, almost half of those folks are not Mexicans. And so this idea that somehow one and a half percent of this population of folks who are illegal, or even if you take three percent, are going to Balkanize the United States of America is just absolutely ridiculous. In fact, I've seen in San Antonio the effective generations of what has happened with the waves of Hispanic immigrants. San Antonio is now the seventh largest city in the United States, the second largest city in Texas. It has a very robust local economy, so much so that during these last couple of years and Forbes and others have ranked it as one of the most successful US cities.

### Moderator
Claim: But Julián, can you address-- and to a degree, your partner did. But the numbers that your opponent Kris Kobach brought out about the number of kids in public schools who are identifying as not American, do you think that's solely down to an anti-immigrant climate from the debate, because they obviously don't. I'd like to see what you think about that.

### Scientific Advocate (SA)
Claim: Well, first, I haven't seen that study.

But Secretary Kobach said that that was from a San Diego high school. The first thing is I would question the sample and the breadth of that study. I don't think that you can draw many conclusions from one high school in the United States, one class. But think about your own lives and the folks that you've met here in New York or wherever you've gone. Folks are very proud to be Americans. They came here for a reason. They came here to get ahead. They come here because of what America stands for. My experience has been that people very much identify themselves and are proud to be Americans.

### Scientific Advocate (SA)
Claim: Just look at the names of the people who are fighting and dying in our wars. Hispanics are a representative proportion to their proportion of the population. These are newcomers, and they're fighting and dying for us.

### Conspiracy Advocate (CA)
Claim: Here legally.

### Moderator
Claim: Kris Kobach.

### Moderator
Claim: He says they're not.

### Conspiracy Advocate (CA)
Claim: Here legally and are U.S. citizens--

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: --primarily. But let me correct a number Julián mentioned.

### Moderator
Claim: Kris Kobach.

### Conspiracy Advocate (CA)
Claim: The census bureau, the actual number, you’re right, 308 million total people residing in America, approximately 36 million are aliens, and that includes legal and illegal.

So it's about 12 percent--

### Scientific Advocate (SA)
Claim: Well, here you go--

### Conspiracy Advocate (CA)
Claim: --of the population. And that is basically--

### Scientific Advocate (SA)
Claim: Kris, I mean, you're switching between legal and illegal and making some arguments only for legal.

### Conspiracy Advocate (CA)
Claim: Okay, here, look. It's 11.1--

11.--

### Scientific Advocate (SA)
Claim: You can't have it both ways. That's the point.

### Conspiracy Advocate (CA)
Claim: --million is illegal. You do the math.

### Scientific Advocate (SA)
Claim: That is a good question. Are you guys against just illegal immigration, or are you against immigration, period?

### Conspiracy Advocate (CA)
Claim: I'm telling you what we are in favor of is increasing the percentage of aliens who are exactly the ones you're talking about, the job creators, the entrepreneurs that are starting the companies. The way you increase that percentage is you reduce illegal immigration to zero, and you change our priorities about legal immigration, and you give higher preference to people who are skilled.

### Scientific Advocate (SA)
Claim: And who--

### Conspiracy Advocate (CA)
Claim: We can accept the cream of the crop, and we should.

### Scientific Advocate (SA)
Claim: And who's going to grow our food? And who's going to take care of our old people? And who's going to work in hospitals?

### Conspiracy Advocate (CA)
Claim: Well, the 14 million unemployed Americans would be a starter.

### Moderator
Claim: Okay. I'd like to go to questions from the audience. And the way that this works, the lights will come up, and if you raise your hand, I'll find you, and then a microphone will be brought to you.

We'd like you to stand up so that the camera can find you. Really, if you could keep your question to one sentence or two sentences, I mean, try to formulate it-- I'm okay with a brief statement of premise, but we would like to keep it terse. And hold the mic about a fist's distance from your mouth. And this gentleman in the front row in a blue shirt?

### Moderator
Claim: Hi. Yes. Actually, the mayor of New York City, Michael Bloomberg, he's been talking a lot about an immigration policy that will allow a lot more individuals to come in from all different classes, but that would be focused on having these immigrants come in a little bit more quickly, a little bit easier if they would agree to stay in cities that are necessarily in decline like Detroit for a period of two to three years, five years. I'm just curious. Does that change any positions on either side? And could that be a viable plan that could maybe bring--

### Moderator
Claim: So he’s saying there is a place. Kris Kobach, do you want to--

### Conspiracy Advocate (CA)
Claim: Mayor of Detroit has already responded to that, I think.

### Conspiracy Advocate (CA)
Claim: Yeah, Mayor Bloomberg, you notice he didn't suggest that the illegal aliens come to any particular borough of New York. And the citizens of Detroit weren't asked whether-- you know, they're facing unemployment-- whether they would like a large number of unskilled folks to come in and help revive their economy by taking a job they're already - -

### Moderator
Claim: Julián Castro. Okay, Tamar Jacoby then Julián.

### Scientific Advocate (SA)
Claim: You can make light of this, but I mean, it's true. Go to any immigrant neighborhood, they revitalize the neighborhoods. They open shops. They open restaurants. They've taken burnt out neighborhoods across the country and revitalized them on the same way they create small businesses, and they're-- and they're consumers. Yes, I don't know if we really want to send them all to Detroit. But the truth is immigrants bring economic vitality, and they create jobs.

### Moderator
Claim: Julián Castro.

### Scientific Advocate (SA)
Claim: He's on to something.

### Scientific Advocate (SA)
Claim: First, as I said earlier, the studies have shown that immigrants as a class have a higher rate of founding businesses than native born U.S. votes.

Mayor Bloomberg is correct, and that's why he has made the economic argument very powerfully for both more legal immigration and then doing something with the 11 million folks who are here illegally. It is not realistic that you're going to deport 11 million people because it would decimate the American economy and because-- and this isn't about dollars and cents, but because these people are human beings. They're human beings.

### Moderator
Claim: Tom Tancredo, do you want to weigh in on this?

### Conspiracy Advocate (CA)
Claim: Yeah. What our opponents have done here is very skillful, really great at it, and I give them credit for setting up all kinds of straw man arguments, you know, that if you are opposed to immigration, you don't understand that some people who are coming here are patriots and want to be-- well, of course, it's absolutely true. Nobody's suggesting that every single immigrant comes here under that premise. But the idea that you-- when you say you can't deport, I don't have any-- I have never once, in as many millions of words as I have expended on this topic, suggested everybody's got to be deported. All I've ever said is, look, all you have to do is obey the law.

All you have to do is restrict the ability of a employer to give a job to somebody who is here illegally. People self-deport when that happens. It happened in Arizona. You do not have to round people up. These are all cannards. These are all things that people on the other say to make it look as though we're all people who are just waiting and biding our time until we can get these people out of our country. That's--

### Scientific Advocate (SA)
Claim: Your policy is even worse than deportation.

### Conspiracy Advocate (CA)
Claim: Why is it hard to suggest that obeying the law would be a good way to deal with--

### Moderator
Claim: Tamar Jacoby.

### Conspiracy Advocate (CA)
Claim: --the immigration problem? How do you-- what's the deal?

### Scientific Advocate (SA)
Claim: The theory behind this policy-- the theory behind the policy that Tom Tancredo and Kris Kobach are advocates for is called attrition through enforcement. It's, let's make immigrants' lives so miserable that they go home of their own accord. First of all, it doesn't work. Many immigrants who are here, the unauthorized immigrants, are people who have been here for five years, 10 years, 20 years, who own homes, who own businesses, who are married to legal Americans. They have citizen children.

You might get a few to go home. But most are not going to go home. And honestly, I don't think that's how we want to deal with this population. These are people who we said, "nudge, nudge, wink, wink, come on in. Do some work for us.”

### Moderator
Claim: Don't say "we."

### Scientific Advocate (SA)
Claim: And now we're saying, let's make their lives so miserable that--

### Moderator
Claim: Does it work, Kris Kobach?

### Scientific Advocate (SA)
Claim: --it will drive them home. I don't think that's the way to deal with that.

### Conspiracy Advocate (CA)
Claim: Statistically-- statistically, attrition through enforcement works. And it's basically the idea. It's the same law enforcement approach you have. You have a section of highway 95 where there are no police officers patrolling. You don't say, well, the only options are to have an amnesty, i.e., have no speed limit, or to catch 100 percent of the speeders. No. Which would mean to--

### Moderator
Claim: But Kris, I don't want our eyes to glaze over with the answer.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: But when you say-- when you say statistically, can you give us a sense of what you mean?

### Conspiracy Advocate (CA)
Claim: Yeah. We have the numbers. Arizona, more than any other state, has tried to encourage people to leave. Give disincentives. Take away public benefits. From middle of 2008 to middle of 2009, the overall illegal alien population in the United States dropped seven percent.

### Scientific Advocate (SA)
Claim: Arizona--

### Conspiracy Advocate (CA)
Claim: In Arizona, in dropped 18 percent, more than double the national average.

### Scientific Advocate (SA)
Claim: But most of them didn't go home.

### Conspiracy Advocate (CA)
Claim: The only difference was the enforcement.

### Scientific Advocate (SA)
Claim: But most of them didn't go home.

They went to other neighboring states right next to--

### Conspiracy Advocate (CA)
Claim: Then why did the Mexican-- why did the Mexicans – why did the Mexican state of Sonora…

### Moderator
Claim: That proves their point, though. You want to get out of Arizona.

### Scientific Advocate (SA)
Claim: That's true, but it does make the point that they

### Conspiracy Advocate (CA)
Claim: Why did president--

### Scientific Advocate (SA)
Claim: --many of these people anymore. Mexico, they’ve been out of Mexico for 10 or 15 or more years, they're married to Americans, they have citizen children, Mexico's not home anymore. They leave and go to Oklahoma.

### Moderator
Claim: Okay. I'm getting in my ear to go to some more questions and there's a woman in the fourth row, and thank you.

### Moderator
Claim: Good evening, everyone. I just want to start out quoting another Nobel Laureate, it was Elie Wiesel who said in the ’80s, who in documented immigrants gave the slogan, “No human being is illegal.” And I think that's a really brilliant place from which to start because sometimes we see that our laws have inhumane consequences. But my question is for Kris Kobach, how do you explain working for a designated hate group, the Federation for American Immigration Reform, founded by white nationalist John Tanton, who was recently profiled in The New York Times?

How do you explain the hate speech?

### Moderator
Claim: Okay, I'm-- you two can talk afterwards. It's not on our-- and I'm not disrespecting the question or its validity or the conversation you two can have afterwards, it's not on our topic.

### Conspiracy Advocate (CA)
Claim: I'd like to answer one her points, though. The designation, by the way, is by the Southern Poverty Law Center which designates lots of people lots of things, but the bit about no human being being illegal, the reason I use the term "illegal alien" or "alien unlawfully present in the United States," is those are the terms used by federal law, and being a lawyer, I try to use the terms used by law. The word "undocumented immigrant" does not appear anywhere in the entire United States Code.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: the term "undocumented worker" does not appear.

### Moderator
Claim: We take the point. I thought I saw a hand. Sir, with the yellow tie, goldish, I'm not that good on the colors.

### Moderator
Claim: Thank you. I noticed that Mr. Kobach is a professor of constitutional law, and yet he's advocating that states have their own immigration policy. Do you not understand the Constitution you're trying to teach?

### Conspiracy Advocate (CA)
Claim: I understand that perfectly well. I understand it perfectly well and--

### Moderator
Claim: I'm again close to saying do you want to take this?

### Conspiracy Advocate (CA)
Claim: I'd love to take it, because, yeah.

### Moderator
Claim: I think he does.

### Conspiracy Advocate (CA)
Claim: Because these questions really are a lot of fun-- I’ve got-- but-- now, let me just--

### Moderator
Claim: We've got people here who have committed to really making arguments on the issue.

### Conspiracy Advocate (CA)
Claim: Let me try to make this interesting because that's what a constitutional law professor does.

### Moderator
Claim: Really fast.

### Conspiracy Advocate (CA)
Claim: Really, no, the question-- the doctrine you're talking about is preemption doctrine. That is the idea that some things that Congress can only do and some things that they-- and the states can do alongside Congress. The United States Supreme Court last opined on this in 1976 about a California immigration law and said, yes, the states can do things to discourage illegal immigration. There is a case before the United States Supreme Court right now, Whiting versus Chamber of Commerce, we should have a decision within the next month or so, this will be the first time the Supreme Court has spoken in 35 years. So the precedents are very clearly there, and that's why many of these cases, the states and cities are winning.

### Moderator
Claim: Okay, can I ask-- just in phrasing the questions to restrain the tendency to want to attack the, you know, ad hominem-- please? Because it--

### Moderator
Claim: I know you can take it but it’s not what we want to do.

### Moderator
Claim: If you stand up. Oh no, no, no, you've got to get to a microphone first.

### Moderator
Claim: Can you hear me?

### Moderator
Claim: No, no, you get a mic . Yeah, wow. Even the radio listeners could hear you on that one.

### Moderator
Claim: You have been tossing around this statistic about 11 million immigrants, illegal immigrants in this country and then you tossed something in about it dropped, you know, so many percentages, what illegal immigrant is telling you that he’s illegal? And where are these statistics coming from?

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: It's really interesting, the census has what’s called a current population survey and they do these every month and they do a really big one in March.

And they actually give them to everybody and illegal aliens answer these surveys. And so they’re based on very large surveys done by the Census Bureau. And those numbers, the 11.3 million, those are generally agreed upon numbers by both the Pew Center and by the Center for Immigration Studies so I think there’s broad agreement--

### Scientific Advocate (SA)
Claim: No, I'm just going to say the same thing.

### Moderator
Claim: Same thing, you agree on something? Okay.

### Scientific Advocate (SA)
Claim: Something technical, we agree on something technical.

### Moderator
Claim: It's very technical. You have a white collar and I believe gray shirt-- oh, it’s a white collared gray shirt.

### Moderator
Claim: Earlier the mayor made a point that if you look into the future and you treat not just the snapshot of the economy but actually the dynamic picture of the economy, you see immigrants not just as one person, but as a pyramid of people who can contribute to the economy over many generations. Why do you folks on the pro side of this question always look at the snapshot and never at the long term picture?

### Moderator
Claim: Interesting question.

### Moderator
Claim: Because I think, you know-- if many of the people in this room, if our immigrant descendants had come here now you would send them home. But in fact over the many generations we’ve contributed to this cause.

### Moderator
Claim: Tom Tancredo.

### Conspiracy Advocate (CA)
Claim: I think I at least attempted to address that when I spoke earlier when I talked about these periods of timeout. In fact, we have had immigrants-- immigration is an important part of America. There is nothing-- there is no argument about that. It’s just that it was rational over American history to create an immigration policy that fit the time, that fit the economic situation in the country. That’s exactly what happened in the 1890s and the 1900s, massive immigration, low-skilled people. Fine, worked, it’s okay. And so you can say over a long period of time, it worked. Well, it would work again today except that we have never had this timeout. And we continue to bring in the same category, low-skilled, low-wage worker, even though we don’t have enough jobs.

### Moderator
Claim: Okay, that’s an argument that has a logic to it, and, sir, I just want to know what your-- we need a mic back to you, and briefly, if you can rise again. Did you hear it?

### Moderator
Claim: Yeah, I don’t think that really answers the question. The question, again, is why are we looking only at a snapshot and not at the full intergenerational contribution that immigrants and their families make?

### Moderator
Claim: Okay, he’s really saying why is it-- why are you not saying that 30 years from now, those folks that are here now, and you’re saying in an inappropriate time could not actually end up contributing. I think that’s what you’re saying, it’s a dynamic thing.

### Conspiracy Advocate (CA)
Claim: What do we-- 30 years from now, could things be better? Yeah. I mean, who’s supposed to be able to make that determination? And why would we begin to think about creating-- exacerbating a problem we have today, a massive problem, with unemployment in this country-- 10, well, nobody knows the real percentage.

Well, let’s settle on what’s generally talked about as the real unemployment in America, at 10 percent-- why would we tell all those people who are unemployed today, that they’re going to have to figure out a way to think about their lives as being better in the long run because they can’t get a job today.

### Moderator
Claim: Okay, Tamar Jacoby.

### Conspiracy Advocate (CA)
Claim: I mean, it makes no sense.

### Moderator
Claim: Tamar Jacoby.

### Scientific Advocate (SA)
Claim: The problem with your arguments-- with our opponents’ arguments about integration and assimilation is they’re all based on hypotheticals. There’s no timeout. There was a timeout in the past. There’s too much welfare, that we didn’t have so much welfare in the past. But you’re not looking at the empirical evidence of whether today’s immigrants are integrating, and they are. 99.9 percent of the children are learning English. Even in the first generation, the home ownership rates and the wealth accumulation rise to Americans of similar background. They’re owning homes. They’re starting businesses. They fighting our wars, and they’re integrating.

### Moderator
Claim: Okay, I’m hearing from Tom Tancredo. He’s disagreeing with your points down the line.

### Conspiracy Advocate (CA)
Claim: Almost every single study on this-- this is one of the-- another area where there is some degree of agreement in the number of studies out there.

Hispanic immigrants in America-- although Hispanics make economic and educational gains from the first to the second generation, not disputed, the progress stops there. Third-generation Hispanics still earn significantly less than whites, graduate from college at less than 50 percent of whites, and, by the way, in terms of language, still do not accept English as the primary language, even at the third generation.

### Scientific Advocate (SA)
Claim: That’s just not true.

### Scientific Advocate (SA)
Claim: That’s just not accurate. Come on.

### Conspiracy Advocate (CA)
Claim: Well, that’s-- okay. So we have another argument about statistics.

John Donvan: We have an impasse on that. There’s a-- ma’am in the third row. Yeah, there’s a-- if you look to your left, that mic’s closer. And if you could stand, thanks.

### Moderator
Claim: Hi, I’m--

### Moderator
Claim: Could you-- would you mind standing up for the camera? Thanks so much.

### Moderator
Claim: Sorry. I’m wondering whether the premise should be concentrating on immigrants. Why are we not-- for job losses-- first of all, legal or illegal, why are we not concentrating on companies that export the jobs into the third world or the companies like GE that are allowed to take their disbursements and costing this country--

### Moderator
Claim: Okay, I--

### Moderator
Claim: No, but it has to do with immigrants because it is not about-- it’s pennywise and pound foolish.

### Moderator
Claim: I agree, I agree. I agree that there’s a serious tension there, but it’s not going to move our discussion along. But thank you. I say that respectfully.

### Scientific Advocate (SA)
Claim: Well, but there is actually something to say about this. Can I just-- can I say something to that? It’s not about-- I’m not going to talk about-- I’m going to talk about immigration, I promise you, I promise you.

### Moderator
Claim: Save it for your closing remarks.

### Scientific Advocate (SA)
Claim: And for many industries, the choice is actually do we send the jobs abroad or do we have the immigrants come here? For, in agriculture, if immigrants don’t come here, I guarantee you, Americans are not going to go out into the fields and pick lettuce and pick fruit. We will start outsourcing--

### Conspiracy Advocate (CA)
Claim: The majority of employees in those fields are Americans right now.

### Scientific Advocate (SA)
Claim: We will start outsourcing agriculture.

### Conspiracy Advocate (CA)
Claim: According to the census, the majority-- 56 percent are Americans in those fields right now.

### Moderator
Claim: Okay, so ma’am, you did have a good question. I acknowledge. Sir?

### Scientific Advocate (SA)
Claim: But they’re supervisors, not the workers.

### Moderator
Claim: I don’t see how our latest economic pitfalls of-- with the tours that we’re running and the enormous deficit are caused by-- how are the immigrants, illegal or legal are a drag to our economy or to causing a drag on our economy?

### Conspiracy Advocate (CA)
Claim: Well, see, you heard the numbers, although they're somewhat disputed about the fiscal drag. I think everybody's coming to an agreement, Democratic or Republican alike that we have to get a hold of this deficit, $1.4 trillion a year.

### Moderator
Claim: million unemployed caused by the illegal immigrants?

### Conspiracy Advocate (CA)
Claim: Well, if we don't create-- if we do not create, in this country, 200,000 jobs a month, that's 200,000 new jobs every month have to be created in this country by the private sector in order for us to climb out of this recession, okay? Most economists agree that that's the number. We haven't had a 200,000 monthly increase in quite some time.

But we do bring in 160 some thousand a month legally, let alone the numbers that come across the border and fly in this country and stay, which is a significant number. It's not just people coming across the border who are illegal aliens in the country. And so they're part of the problem. Where do those jobs go?

### Moderator
Claim: Okay. I'm sorry. I can't have you debating with him. But thank you for your question. And we're going to take a short break and come back with more of your questions.

Welcome back. Our motion is “Don't give us your tired, your poor, your huddled masses.” This is a debate from “Intelligence Squared U.S.” We are in the question-and- answer section of the debate. I'm John Donvan of ABC News. We have two teams of two sides each arguing this motion, “Don't give us your tired, your poor, your huddled masses.” And now to some more questions. There's a woman, if you did that--

### Moderator
Claim: talk about potential changes to our existing immigration policy, and I wonder if the against side would also talk about what changes you would make, because I think most people would agree that what we have now doesn't work tremendously well.

### Scientific Advocate (SA)
Claim: So the key and the most important change--

### Moderator
Claim: Tamar Jacoby.

### Scientific Advocate (SA)
Claim: --is that we give the workers who we're going to need in the future a way to come legally. Right now, we don't need that many foreign workers. We need some in agriculture. And at the high end, we don't need that many. But in the future when the economy picks up, and Americans go back to their better jobs and their year-round jobs, and they start to go to restaurants, and they start to go to hotels, and we start to build houses again, we're going to need immigrant workers. And on that day, I say we want to have them come legally as opposed to illegally. If our economy needs them, have them come legally. I also think we need enforcement. Our opponents aren't wrong about enforcement. We do need better enforcement on the border and better enforcement in the workplace to make sure-- we need to create legal channels and enforce against the people who are coming illegally.

And we need some answer for the 11 million people who are already here and are not going home no matter how miserable we make them with police stops and other things. You know, maybe some of them will go home--

### Moderator
Claim: But doesn't your argument for the enforcement that would keep the numbers down fight your argument that we need the workers and the--

### Scientific Advocate (SA)
Claim: No, no. You need-- the best answer for illegal immigration is a legal immigration system that works. If people are coming to work here, give them a legal way to come and then stop the illegals coming--

### Scientific Advocate (SA)
Claim: I would also just add really, very quickly, that this idea that everybody agrees that they broke the law. But there are a million different ways that people break the law every single day of the year. And for instance, if you break the law, and you're speeding, you mentioned speeding earlier, or you're breaking the law because you don't have insurance, and you're driving, or you're breaking the law because, for some other reason, one of the models that's out there is something called deferred adjudication. So as a lawyer you know, Kris, that basically under deferred adjudication, you still get punished either by paying a fine or doing community service.

And as long as you don't commit another crime within a certain amount of time, you're able, basically, to wipe that off your record and get on with your life. That happens millions and millions of times. I would imagine in just about every state in the United States.

### Moderator
Claim: Something like an amnesty.

### Scientific Advocate (SA)
Claim: It's not like the model is not there already.

### Moderator
Claim: Kris, it is. Kris Kobach.

### Conspiracy Advocate (CA)
Claim: Amnesty is a horrible idea for four quick-- for four reasons. Number one, you're going to see that the fiscal impact is going to triple. The 89.3-- $89.1 billion a year that we're losing fiscally is going to become 2.6 trillion over 10 years. That was according to the Robert Rector study in 2007. The reason is simple. Right now, illegal aliens get food stamps, Medicaid, free school lunches, K through 12 education. If they become legalized, then they get the big ones. Then they get Medicare and Social Security. And the price goes way, way up. Talk about the golden door. Number two, it won't just be 11.3 million. The last time we had a major amnesty in 1986, according to the INS's own records, 398,000 illegal aliens quickly came across the border to falsely claim that they were already here and grabbed the amnesty.

Number three, we've been hearing about the terrorists. We mentioned that earlier about the terrorists coming in. The notion that we are going to suddenly sift through this population and know who the terrorists are and who they aren't is demonstrably false. Mahmud Abouhalima who was one of the ring leaders in the ’93 attack on the World Trade Center here in this city was given amnesty in the 1986 amnesty. And number four, it's a slap in the face to the people--

### Moderator
Claim: Everybody who paid the price--

### Conspiracy Advocate (CA)
Claim: --who did it the right way.

### Moderator
Claim: And did it the right way.

### Scientific Advocate (SA)
Claim: No one's talking about amnesty. We're talking about asking people to make restitution and get right with the law. Nobody's talking about amnesty.

### Conspiracy Advocate (CA)
Claim: A slap on the wrist, and then you get to stay. That's called amnesty.

### Scientific Advocate (SA)
Claim: No. I would say, Kris, that that that's an open question. In other words, how much are you going to punish, just bluntly, how can you punish them for having broken the law? I think that there is room to maneuver among reasonable people there.

### Moderator
Claim: Third row, beige sweater. Wait for the mic, okay?

### Moderator
Claim: I'm really concerned about the argument, the fiscal argument that this group over here is making in regards to the fiscal impact. When you support the attrition through enforcement strategy, that strategy has detained thousands of-- hundreds of thousands of people over-- almost 400,000 people were deported last year. There is about 30,000 immigrants detained in facilities all across our country that is costing the American people, including immigrants, because they are contributing to the economy and to taxes, $1.7 billion. There's 30,000--

### Moderator
Claim: You're saying there's a cost to enforcement.

### Moderator
Claim: There's a cost. And that's just the detention cost.

### Moderator
Claim: Okay. Let's let--

### Moderator
Claim: So that has-- and that is also, you know, in terms of our values of being here in the United States, what does that speak to to the people who are here, that we-- you know, do we want to be viewed as a country that is detaining 30,000 people in detention and deporting almost 400,000 people?

I don't think that that's the values that the United States is really portraying across the country.

### Moderator
Claim: Kris Kobach.

### Conspiracy Advocate (CA)
Claim: As a lawyer who has worked in this area, you're right. It's about 30,000 who are detained. Those are people in deportation proceedings. We call them removal proceedings. But that's a small percentage of the total number of people who are being removed from the country at any given time. And the reason that 30,000 is actually too low is that if you do not detain an alien while he is in removal proceedings, and then the judge says, at the end of the immigration removal hearing, "You are deported," hands him a removal letter, 93 percent will abscond. They will leave. They will disobey the letter. And it's known among the immigration attorneys as a run letter. And so if you don't detain, they don't go. And if we believe that our courts have any meaning, and are nothing more than just a laughing stock, we have got to try to detain the ones that present the highest risk of leaving--

### Scientific Advocate (SA)
Claim: But the point is the whole system is broken.

### Moderator
Claim: Of people in detention, a lot of these people in detention don't even have an attorney, don't have any due process. And that needs to be addressed. And do we want--

### Conspiracy Advocate (CA)
Claim: Okay. Every immigration hearing has a right to an attorney.

### Moderator
Claim: --as the American public, to be viewed as--

### Moderator
Claim: Kris, Kris, I don't want you debating with the audience.

But your passion has been registered and respected. Sir, on the same aisle to your left. Let the mic go back down. Gentleman in the purple tie. Oh, it's coming the other way. And if you could stand up, sir. Thanks.

### Moderator
Claim: The con side has both been saying there’s not enough legal immigration. But it's been briefly mentioned we do accept 1 million permanent legal immigrants each year and about-- and nearly a million temporary workers, and that number has not gone down since the recession. Ms. Jacoby says that you support-- we don't need it now. So would you support a moratorium until the jobs go back up? And also how many people, 15 million people apply for the diversity lottery alone. So how many do you want in the country before you--

### Scientific Advocate (SA)
Claim: So the point is that the market--

### Moderator
Claim: Tamar Jacoby.

### Scientific Advocate (SA)
Claim: --works really well to attract people-- when times are good, the market attracts people.

And when times are bad, people get the signal all the way to their villages in Mexico, and they don't come. Since the downturn, half as many people have been coming every year from Mexico, half. People hear that there are no jobs, and so they don't come. They're not coming for welfare. They're not coming for unemployment. They don't get those things. They're coming to work. And that's-- we should be happy about that.

### Moderator
Claim: That's attrition by bad economy, though.

### Scientific Advocate (SA)
Claim: Exactly. We should be happy that the market sends the signals. And the system that--

### Moderator
Claim: Tom Tancredo.

### Scientific Advocate (SA)
Claim: --I think we should have is a way for when the market is good and attracting people, those people who are coming to work should be able to come legally. I don't think we need people working here and being--

### Moderator
Claim: Tom Tancredo.

### Conspiracy Advocate (CA)
Claim: Tamar apparently agrees that jobs are the attraction. Without the jobs, they don't come. Without the jobs, they go back. Therefore, it's an enforcement issue. Something that's called-- right now, it's a program that's voluntary. It should be mandatory. It's called E- Verify, just a requirement that every employer use a process that--

### Scientific Advocate (SA)
Claim: I'm for E-Verify.

### Conspiracy Advocate (CA)
Claim: --actually verifies whether the person is-- has got a good social security number.

Now, can it be-- can there be problems? Of course. You can steal the social security. But it's a great use of a tool that's out there that would not cost a great deal of money, it's an easy process, and it would have the effect if Tamara's right that people won't come if they hear there's no jobs, it would have the effect I think also of saying I believe if there are no jobs--

### Moderator
Claim: Julián Castro.

### Conspiracy Advocate (CA)
Claim: --so many people left, by the way--

### Moderator
Claim: Julián Castro.

### Conspiracy Advocate (CA)
Claim: --so many people left in Arizona--

### Scientific Advocate (SA)
Claim: Let me just say that I agree that jobs are what drive folks over here. I disagree with the idea that if those jobs aren't there at a given time that they're necessarily just going to go back. You know, the point was made very early that these folks-- let's say that you've had a job for 12 years, 13 years, and you've had-- and you're married now and you have children who are United States citizens, you know, for the children the United States is home.

Mexico or wherever they're from is not home. And in many ways, Mexico isn't even the place that feels like home anymore. So it's a much more complicated issue than just to say if you press this button then this is going to happen.

That's not reality. That's not

### Moderator
Claim: Okay, we have time for one more question that I want to get in, sir, at the far edge, if you could stand up.

### Moderator
Claim: Hi, this question’s for the pro side, what would you tell to the people like the teenagers, the low skilled American worker, people with the minority communities, who are trying to get jobs, but yet some of those jobs been taken by illegal immigrants and those are those jobs they could have probably had?

### Scientific Advocate (SA)
Claim: So I work with seasonal employers. I just did a survey of a couple hundred of-- actually probably up to 500 seasonal employers. These are like resorts in remote places and fruit picking and seasonal work. And I asked them, are more Americans showing up now in the downturn to apply for these jobs?

And what they tell me is in the past, no, Americans showed up to work in a seasonal job but, yes, this year a little uptick in the numbers of Americans showing up, but then when they learn that it's only a seasonal job and that it's physically-- that it's outside and that it's not going to lead to anything, that they're going to have to leave at the end, people are not taking those jobs, staying for maybe a few weeks and then leaving. The Americans are not competing with immigrants. They're mostly doing jobs that Americans do not-- are not wanting to do.

### Conspiracy Advocate (CA)
Claim: They--

### Moderator
Claim: Kris Kobach.

### Conspiracy Advocate (CA)
Claim: Let's not talk about one anecdote, let's talk about data in whole industries. There is no industry that expresses this more than the meatpacking industry. The meatpacking industry 30 years ago was almost entirely worked by U.S. citizens, the Green Bay Packers, a bunch of, you know, whole cities built on meatpacking. But today, the meatpacking industry is about half and half, about half illegal aliens, half U.S. citizens. We see exactly what happens when the INS, now ICE goes and shuts down a meatpacking company because-- or does a raid, and suddenly 300 employees have gone out. There was a raid in Georgia a few years ago, and they had two to 300 employees were arrested.

What happened? Wages went up. They had to go up. They went from $6.75 an hour, and then they went up to $7.75 an hour, and what happened was U.S. citizens and legal aliens started taking the jobs once the wages got high enough.

### Scientific Advocate (SA)
Claim: But you're leaving out the turnover also went up.

### Conspiracy Advocate (CA)
Claim: That’s exactly what has to happen.

### Scientific Advocate (SA)
Claim: The turnover went through the roof because people do the jobs for a little while and then they don’t want to do them anymore.

### Conspiracy Advocate (CA)
Claim: Twenty years ago, the average wage in meatpacking was about $12 an hour.

### Scientific Advocate (SA)
Claim: And that's--

### Conspiracy Advocate (CA)
Claim: Now it’s about eight dollars an hour, that’s not in real dollars that’s in absolute dollars. There’s no other industry--

### Moderator
Claim: I have to separate the you because that concludes round two of our debate.

### Scientific Advocate (SA)
Claim: Oh, no.

## Round 3

### Moderator
Claim: And here’s where we are, we're about to hear brief opening statements-- we're about to hear brief closing statements from each debater in turn. They will be two minutes each, and remember how you voted before the debate because immediately after their closing statements we’re going to ask you to vote again and the team that has changed the most minds according to your votes will be picked-- declared our winner.

So on to round three closing statements by each debater in turn. Our motion is "Don’t give us your tired, your poor, your huddled masses," and here to argue against the motion, against the don’t, Julián Castro, Mayor of San Antonio, Texas, the seventh largest city in the United States.

### Scientific Advocate (SA)
Claim: All right, well thank you very much for giving us this audience this evening. You've heard arguments on both sides tonight. But I want you to think about at the end of the day what the United States of America stands for, what it stood for from its founding and what it stands for in this year 2011. The United States has always stood for opening up the doors of opportunity to folks around the world. And that means that through the years there have been many folks who came here legally and there have also been many folks who came here illegally. It is undisputed that folks who are both legal and illegal are making an enormous economic contribution to the United States.

In fact, depending on the studies whether it’s a one percent difference or a three percent difference, they are contributing in taxes, in creating jobs for others, in economic impact in founding companies, and our folks on the other side are trying to have it both ways, to say that, yes, throughout history we’ve become the number one economy in the world because of all of these immigrants. And many of them were illegal during that time as well. But something has changed. We have to change the entire identify of the country. I don’t believe that that’s true. I believe that the evidence bears out that, yes, we can strengthen our enforcement, but we need to deal with the 11 million folks who are here illegally, punish them for the fact that they broke the law, and then give them a chance at the back, at the end of the line, to become citizens eventually, and to deal with the fact that the American economy needs these influx of workers.

In 2012, we’ll have the oldest average age for an American worker in our history, 41.6 years. We have a declining workforce that must be replenished by immigrants to the United States. And there’s no better place to deliver that message than New York City, the city of immigrants that has become the greatest city in the world.

### Moderator
Claim: Thank you, Julián Castro. Your time is up. Our motion is "Don't give us your tired, your poor, your huddled masses." And here to argue for the motion, for the “don’t,” Tom Tancredo, a former Congressman from Colorado.

### Conspiracy Advocate (CA)
Claim: I mentioned that I first got into this whole thing because of the intellectual stimulation I believe that it provides. And I think tonight’s a good example, that it certainly does that. It is a fascinating discussion, and I sincerely respect the opinions of the people on the other side of this. I would say that there is, for America, I think all of us at this table want exactly what has been expressed, Julián, by you, certainly an opportunity for people who come here, an opportunity to do great things.

I also want for people who live here, for people who are on the lowest rung of the economic ladder in this country to also have an opportunity, to have the ability to actually get a job, progress through the system, and especially the ones-- I’m talking about the ones that have done it the right way. Nothing hurts-- there’s no group of people in the United States that’s more negatively impacted by massive immigration, both legal and illegal, of low-skilled, low-wage people, than the people who are here legally, who are low-skilled, low-wage people. They are our citizens. Why is it so hard for us to think about them, to think about their needs? For the most part, you know, when we’re talking about the immigration process and these people, they came the right way. And, by the way, this has nothing to do with race, ethnicity, absolutely nothing.

I assure you that if Italy was on our southern border, had as much poverty, as much population, we would have just as many problems with Italians coming across that border illegally. It’s got nothing to do with ethnicity, nothing. Although it’s always tried to be - - people try to cast it in that light because they want to move the discussion away from the real problem and to this bogeyman of racism. Is it out there? Of course. But I’ll tell you what, it does not motivate me. All I want is for this country to achieve its goals. I want it to be the place, yeah, that, still, everybody wants to come because we have a vibrant economy in which most of the people here are doing well, in fact, all of the people are doing well, and this is--

### Moderator
Claim: Tom Tancredo, your time’s up. Thank you.

### Conspiracy Advocate (CA)
Claim: Okay.

### Moderator
Claim: Our motion is "Don't give us your tired, your poor, your huddled masses." And here to argue against the motion, Tamar Jacoby, who is president and CEO of Immigration Works USA.

### Scientific Advocate (SA)
Claim: Well, in conclusion, I would just like to sharpen the choice here a little bit.

I think what you’ve heard is we all agree that the immigration system we have isn’t working, but we differ in a very sharp way about what the solution is. Our opponents say that the solution has one dimension. It’s enforcement and enforcement only. We say that the solution has several dimensions. Yes, it’s enforcement. Yes, it’s security. But it’s also a legal immigration system that works. The best antidote to illegal immigration is a legal immigration system that works. And I urge-- and the other place we disagree is we disagree over whether immigration and, really, the economy in America and American life is a zero-sum game or not. Our opponents are saying they have the vision of America that leaves no room for people with energy and grit and entrepreneurialism who want to come here and make better lives for their families, but also make America a better place. They have no room for-- their vision leaves no room for hope and for an expansive America.

Their vision is that there’s never enough of anything and that’s it’s a zero-sum game. And our point is that that’s just not true in America. Yes, we’re in a hard time now, but that hard time is not going to last forever. Immigrants don't take jobs. They create them. Immigrants don't threaten us. They bring talent and vitality. American culture and society haven't lost their appeal. Immigrants are as drawn to them as ever, and immigrants are still integrating or assimilating every bit as fast as they did in the past. So I think the notion is exactly wrong. Shutting the gates now would be a disastrous policy. We need immigrants to create jobs and grow. And that need's only going to get stronger as the economy recovers. Just saying no isn't an answer. It's a fantasy, and it's an un- American fantasy at that.

### Moderator
Claim: Thank you, Tamar Jacoby. Our motion is “Don't give us your tired, your poor, your huddled masses.” And here to argue for the motion, Kris Kobach, Secretary of State of Kansas and co-author of Arizona's S.B. 1070, the legal immigration law.

### Conspiracy Advocate (CA)
Claim: I just want to address a couple of loose ends quickly. Julián just mentioned this notion that if we had an amnesty, it would be just fine. It'd be fair because the illegal aliens would go to the end of the line. Legally speaking, that's impossible. When you have an amnesty, you immediately give lawful status to the people who are here. They have been automatically given what four to five million people are waiting for who are trying to do it the right way. There is no such thing as the end of the line. As soon as you grant an amnesty, the person is automatically at the front of the line. And then we heard from them earlier that we shouldn't have a policy that fluctuates, encourages immigration some years, it discourages it depending on the needs of the U.S. economy. It should be pretty much wide open all the time. No. That's exactly what we want. We want immigration policy that is legal and that meets the interests of the United States because we owe our highest duty to our own citizens. And finally, we hear about this point again and again, and they're encouraging this myth of belief that there are jobs Americans won't do. And we have to bring them in for the lower end jobs because Americans won't do those jobs.

Now, remember, I told you the statistics. Americans are doing those jobs. But there's a cultural problem with that argument too. It's encouraging high school kids today, many of whom have never pulled on the starter cord of a Briggs and Stratton lawnmower engine, to believe that certain jobs are beneath them. I would say that is un-American. Our country is built on manual labor, everybody going through a period in their life when they worked a job like that, and then they moved on. Well, this attitude of, let the immigrants do those jobs is a pernicious attitude in our society. And so I'll conclude-- conclude with this. Don't give us your tired and your poor because our tired and our poor American citizens, who are disproportionately minority and who are out of work need those jobs. They need also the welfare state to survive. And those things are not going to happen if you have a massive amnesty or you have unbridled illegal immigration continuing, which an amnesty would further.

So let's look after our own tired and our own poor and then look at immigration in terms of what services our national interests.

### Moderator
Claim: Thank you, Kris Kobach. And that concludes our closing statements. And now it's time to learn which side you feel argued best. We're asking you to go again to the key pads to the right of your seat and to register your vote. We will get the readout almost immediately. So our motion is “Don't give us your tired, your poor, your huddled masses.” And if you agree with this motion, if you agree with don't give us, push number one. If you disagree, push number two. And if you are-- remain undecided or became undecided, push number three. And it'll lock in. So we're done with the excitement of the evening. And I just want to say that in an issue that was as contentious as this, I so respected how these two teams actually respected the argument and respected each other's arguments enough to hear them, and I want to congratulate them all.

And I personally stood to learn some things from the questioners, including yours, ma'am, which I rejected. Turned out to be a great question. And as far as your question and the argument that you want to have with Kris Kobach, he'll be right there afterwards, and he'll be waiting for you. But thank you, all of you for all of your questions. They really helped the process a great deal.

So this spring, our theme has been “America's house divided.” And tonight's debate was the last part of this spring season of our regularly scheduled debates. But we now are happy to announce that we're having a special sixth debate that's going to take place next month. We're just putting it together now. And it's in partnership with the Film Society of Lincoln Center and in conjunction with the opening of the documentary called “Page One: A Year Inside the New York Times.” And the motion that we're going to be debating is this: “The First Amendment does not entitle the press to print state secrets.”That debate’s going to be taking place here at the Skirball Center on Wednesday, June 8th. And we're going to be announcing who our lineup of debaters is quite shortly. Tickets are available, though, already at the Skirball box office and also through our Web site. And don't forget, you can follow “Intelligence Squared U.S.” on Twitter. You can see if any of you Tweeted tonight, let's see what you had to say. And make sure you can become a fan on Facebook to receive a discount on future debates. Dates for our fall season are already posted on our website. So take a look at our homepage, and make sure to put those dates in your calendar. All of our debates-- we said this before, and you've been very, very gracious in doing the radio bits. And if you listen to the NPR broadcast, you can hear your own applause. That will be you, especially you out there with that distinctive clap. They will be heard on NPR stations across the country. And you can watch the debate on Bloomberg Television networks starting next Monday. So visit bloomberg.com for your local channel.

All right. So it's all-- we've been given the results. Remember, the team that changes the most minds is declared our victor. Our motion is “Don't give us your tired, your poor, your huddled masses.” Before the debate, 16 percent of you were for the motion, 54 percent were against, and 30 percent undecided. After the debate, 35 percent are for the motion. That's up 19 percent. 52 percent are against. That's down 2 percent. 13 percent are undecided. That means the team arguing for the motion carried the day. “Don't give us your tired, your poor, your huddled masses” has been carried. Our congratulations to that side. Thanks from me, John Donvan and “Intelligence Squared U.S.”
